# Decision: MCP write tools must require `finlet:trade` scope

**Date**: 2026-05-21
**Status**: Accepted (shipped via bug-11cb2f16 exec-plan)
**Refs**:
- Codex bug `11cb2f16-071a-4cb5-9fef-c91f903c7235` (filed 2026-05-21; prod sha at filing `c9af6c5`)

**Related**:
- `docs/decisions/mcp-api-key-sunset.md` (parent — locks the api_key
  scope-bypass invariant at §3; `enforce_scope(claims=None, ...)` is a
  no-op for legacy api_key Bearer compat).
- `docs/decisions/cli-mcp-http-dispatch.md` (sibling — the 2026-05-11
  hotfix retraction that re-opened the dual-accept window the api_key
  bypass relies on).
- `docs/decisions/blind-benchmark-ticker-must-blind.md` (stylistic
  precedent for this record's shape — same surgical "Codex-shipped a
  category-error boilerplate; here's the fix + audit gate" lifecycle).

---

## Context

Codex bug `11cb2f16-071a-4cb5-9fef-c91f903c7235` (filed 2026-05-21):
during a Codex retest run, `user_a_readonly` — an OAuth client registered
with `scope="finlet:read"` only — was able to call `create_session`
(a state-mutating tool) and got back HTTP 200 with a real created
session (`c81f90c5538f`). The expected behavior is `insufficient_scope`.

Root cause: a **scope-classification category error replicated at 7 call
sites** in `finlet/mcp/server.py`. Each of the 7 write tools below had
`enforce_scope(claims, "finlet:read", user_record)`:

| Tool | Mutates | Why it's a write |
|---|---|---|
| `create_session` | session table | Allocates a session, commits per-tier rate-gate quota |
| `delete_session` | session table | Destroys persisted state |
| `complete_session` | session + trace + benchmark_runs | Seals trace, finalizes results, may advance benchmark |
| `pause_session` | session.status + clock | Mutates clock state |
| `resume_session` | session.status + clock | Mutates clock state |
| `advance_time` | clock + portfolio (fills) | Mutates clock state and triggers order fills |
| `freeze_time` | clock | Mutates clock state |

The pattern was copy-pasted as boilerplate from a read tool to every
other tool. The Codex author treated `"finlet:read"` as "any
authenticated user", not as a privilege boundary. The `enforce_scope`
helper at `finlet/mcp/auth.py:135-189` is itself correct (it
space-splits the scope claim per RFC 6749 §3.3 and set-membership-
checks); the bug is exclusively at the 7 call sites.

The api_key path is a separate code path (`claims is None`) and was
NOT affected by this bug. Per `docs/decisions/mcp-api-key-sunset.md`
§3, that path bypasses scope enforcement entirely — locked compat for
self-hosters, Claude-Desktop-style configs, and the CLI's `--api-key`
flag. The fix preserves this bypass.

The 9 read tools (`list_sessions`, `get_session`, `get_price_data`,
`search_news`, `get_fundamentals`, `get_filings`, `get_economic_data`,
`list_available_tickers`, `get_sim_time`) were correctly classified as
`finlet:read` and stay unchanged.

---

## Decision

Three changes, all surgical, no schema or scope-catalog modifications:

### 1. Flip 7 `enforce_scope` calls in `finlet/mcp/server.py`

For each of the 7 write tools, the literal `"finlet:read"` becomes
`"finlet:trade"`. Each call site now reads:

```python
try:
    # WRITE tool: <one-line rationale>. Requires finlet:trade — see
    # docs/decisions/auth-scope-write-tools-must-require-finlet-trade.md.
    enforce_scope(claims, "finlet:trade", user_record)
except ValueError as exc:
    return {"error": str(exc)}
```

The inline comment is intentional — it makes the privilege boundary
explicit at the call site so a future grep audit lands on the
rationale without re-reading the decision record.

### 2. Why `finlet:trade` and NOT `finlet:write`

The scope catalog at `finlet/auth/oauth/clients.py:85-87` is closed:

```python
_SUPPORTED_SCOPES: Final = frozenset(
    {"finlet:read", "finlet:trade", "finlet:benchmark", "finlet:admin"}
)
```

There is no `finlet:write` scope. Inventing one would require updating:

* `_SUPPORTED_SCOPES` in `finlet/auth/oauth/clients.py`
* `SUPPORTED_SCOPES` advertised by `finlet/auth/oauth/metadata.py`
* The JWT validator's scope-subset check in
  `finlet/auth/oauth/jwt_validator.py`
* The DCR (Dynamic Client Registration) allow-list at registration time
* The OAuth Authorization Server's authorize-endpoint scope-grant page

— a 5-file surface change, all of it user-visible. `finlet:trade` is
the canonical write scope already in use:

* `submit_order` (tools_trading.py:125) requires `finlet:trade`
* `set_session_visibility` (tools_session.py:86) requires `finlet:trade`
* `delete_benchmark_run` (tools_benchmark.py:877) requires `finlet:trade`

Re-using `finlet:trade` for the 7 session-mutation tools keeps the
OAuth surface unchanged and matches the prior team's classification:
"`finlet:trade` means the bearer can mutate per-user financial-state-
adjacent objects". Sessions, the clock, and the trace are exactly that.

### 3. Test that locks the fix forever

`tests/mcp/test_scope_enforcement.py` (NEW — 53 assertions) carries
two complementary gates:

**(a) Behavioral parametrized tests** across the 7 write tools × 3
scope conditions (read-only, trade-only, read+trade) plus the api_key
bypass — 28 parametrized cases. For each:

* Read-only Bearer → tool returns an `insufficient_scope` envelope
  whose body advertises `scope="finlet:trade"`.
* Trade-only Bearer → tool reaches its body (may fail downstream for
  unrelated reasons, but the failure must NOT be `insufficient_scope`).
* Multi-scope Bearer (`finlet:read finlet:trade`) → tool reaches its
  body (same downstream-tolerance contract).
* api_key path → tool reaches its body; `claims is None` bypasses the
  check by design per `mcp-api-key-sunset.md` §3.

**(b) Static grep gate** — reads `finlet/mcp/server.py` as text and
asserts via regex that:

* Each of the 7 write tools has `enforce_scope(claims, "finlet:trade"` in its body.
* Each of the 9 read tools still has `enforce_scope(claims, "finlet:read"` in its body.
* The total `enforce_scope(claims,` site count in `server.py` is exactly 16
  (drift means a new tool was added or removed without re-classifying).

The negative grep is the audit-trigger gate: if a future agent adds a
new write tool to `server.py` and forgets the scope check (or types
`"finlet:read"`), the inventory mismatch trips the test.

---

## Consequences

### Positive

* **Security launch-blocker closed.** Read-only OAuth clients can no
  longer create, delete, complete, pause, resume, advance-time, or
  freeze-time sessions. The Codex retest case (`user_a_readonly`
  calling `create_session` and getting HTTP 200) now returns an
  `insufficient_scope` envelope per RFC 6750 §3.1.
* **No OAuth surface change.** The scope catalog stays at 4 scopes;
  no DCR allow-list update, no JWT validator change, no AS metadata
  change. Existing OAuth clients registered with `finlet:trade` keep
  working; clients registered with `finlet:read` only lose write access
  (by design — that's the bug fix).
* **api_key compat preserved.** Self-hosters, Claude-Desktop-style
  configs, and the CLI's `--api-key` flag are unaffected. The bypass
  invariant at `enforce_scope(claims=None, ...)` continues to no-op.
* **Audit grep gate.** The static regex check at
  `tests/mcp/test_scope_enforcement.py::TestScopeAuditGrep` is the
  canonical regression gate. Future tool additions must update the
  classification table in this record AND the test's tuples;
  inconsistency trips the gate.

### Negative

* **OAuth clients registered with `finlet:read` only lose write access.**
  Any partner currently presenting a read-only Bearer to a write tool
  fails with `insufficient_scope`. They must re-register the OAuth
  client with both `finlet:read` and `finlet:trade` (or just
  `finlet:trade`) and re-mint a token. **Pre-launch acknowledgement**:
  Finlet has zero customers per the launch-priority memory; there are
  no production OAuth clients to migrate. The breakage exists only in
  internal test fixtures, none of which assert read-only-can-write.
* **Hand-curated classification table.** New MCP tools added to
  `finlet/mcp/server.py` must be classified in this record's table AND
  in the `_WRITE_TOOLS` / `_READ_TOOLS_SAMPLE` tuples in
  `tests/mcp/test_scope_enforcement.py`. The total-count assertion
  fails loudly on drift, but the human must classify.
* **No `finlet:write` umbrella scope.** Future tools that mutate state
  but feel "not quite trade-y" (e.g., a hypothetical `flag_session`)
  still get classified as `finlet:trade`. The scope catalog stays
  narrow by design — adding `finlet:write` later is a one-line addition
  to `_SUPPORTED_SCOPES`, but doing it preemptively would split the
  audit surface needlessly.

### Trade-offs explicitly chosen

* **Re-using `finlet:trade` over a new `finlet:write` scope.** Adding
  a new scope is a 5-file user-visible surface change for what is
  fundamentally a label preference. `finlet:trade` is already in use
  for `submit_order`, `set_session_visibility`, `delete_benchmark_run`;
  extending its coverage to session/clock mutations is the minimum
  viable fix. If the OAuth surface needs to grow later (e.g., to
  separate "data-write" from "trade-execution"), the catalog can be
  expanded without rewriting the decision record's rationale.
* **Inline `# WRITE tool: …` comments at each call site over a single
  module-level `require_write = "finlet:trade"` constant.** The plan
  flagged an "optional helper" — adding the constant in
  `finlet/mcp/auth.py` so call sites read
  `enforce_scope(claims, require_write, user_record)`. We deferred:
  the inline comments are more discoverable on a grep audit, and the
  constant would either need to be qualified
  (`require_session_write`, `require_clock_write`, etc.) or document
  itself via comments anyway. If a future audit shows multiple writers
  flipping the comment text inconsistently, promote to a constant.
* **Behavioral parametrize + static grep over end-to-end FastAPI
  test client.** The plan suggested asserting via a live FastAPI test
  client + a minted JWT. We use the simpler in-process pattern
  established by `tests/mcp/test_oauth_scope_enforcement.py` —
  monkeypatching `validate_bearer_jwt` and `_resolve_user_record`
  while calling the tool functions directly. The behavioral test
  exercises the same call frame (decorator → tool body) that an HTTP
  request would hit; the FastAPI-client variant adds boilerplate
  without exercising new code paths.

---

## How to apply

If you add a new MCP tool to `finlet/mcp/server.py` (or any
`finlet/mcp/tools_*.py` module):

1. **Classify the tool.** Does it mutate any persisted user state
   (sessions, portfolio, orders, clock, trace, benchmark runs)?
   * If YES and it's a financial/trade-adjacent mutation: scope =
     `finlet:trade`.
   * If YES and it's a benchmark-runner mutation: scope =
     `finlet:benchmark`.
   * If YES and it's an admin/operator mutation: scope = `finlet:admin`.
   * If NO (pure read): scope = `finlet:read`.

2. **Write the call site.** Mirror the existing pattern:

   ```python
   try:
       # <READ|WRITE> tool: <one-line rationale>. Requires <scope> —
       # see docs/decisions/auth-scope-write-tools-must-require-finlet-trade.md.
       enforce_scope(claims, "finlet:<scope>", user_record)
   except ValueError as exc:
       return {"error": str(exc)}
   ```

3. **Update the audit gate.** Edit
   `tests/mcp/test_scope_enforcement.py`:
   * Add the tool to `_WRITE_TOOLS` if it's a write, or
     `_READ_TOOLS_SAMPLE` if it's a sampled read.
   * Update the `test_total_call_site_count_matches_inventory`
     assertion (the literal `16` becomes `17`).
   * If the tool takes required positional args, add a branch in
     `_build_kwargs`.

4. **Update the classification table in this record.** Add a row to
   the table in §Context above so future audits land on the
   one-line rationale without re-deriving it.

If you ADD a new scope to the catalog (e.g., `finlet:write`):

1. Resist the urge unless the new scope captures a categorically-
   distinct privilege class (not "this tool feels different"). The
   `finlet:read | finlet:trade | finlet:benchmark | finlet:admin`
   catalog has held for the launch cycle.
2. If the new scope is genuinely needed, the catalog update touches:
   `finlet/auth/oauth/clients.py:85-87` (`_SUPPORTED_SCOPES`),
   `finlet/auth/oauth/metadata.py:49-54` (advertised metadata), the
   JWT validator's scope-subset check, and the DCR allow-list.
3. Update this decision record's "Why `finlet:trade` and NOT
   `finlet:write`" section to explain why the catalog grew.

---

## Reversal path

Mechanical, three steps:

1. Edit the 7 call sites in `finlet/mcp/server.py` (lines 300, 478,
   524, 648, 687, 1107, 1336 at the post-fix HEAD) — flip
   `"finlet:trade"` back to `"finlet:read"` and revert the inline
   comments.
2. Delete `tests/mcp/test_scope_enforcement.py` (53 assertions).
3. Mark this record `Status: Superseded` and write a new record
   explaining why writes should be readable.

Estimated cost: 15 minutes. The reversal is technically sound but
reintroduces the exact bug `11cb2f16` repro — a read-only OAuth Bearer
becomes able to create, delete, complete, pause, resume, advance, and
freeze sessions. **Discouraged** because the bug filer's repro is in
the Codex retest harness and the next retest would re-hit it
immediately.

---

## References

- Bug filing: Codex `11cb2f16-071a-4cb5-9fef-c91f903c7235` (2026-05-21; prod sha `c9af6c5`)
- Engine change (7 scope flips): `finlet/mcp/server.py` — Team A (`team-A-bug-11cb2f16`)
- Test additions (53 assertions): `tests/mcp/test_scope_enforcement.py` — Team A
- Parent compat rule: `docs/decisions/mcp-api-key-sunset.md` §3
- Sibling retraction record: `docs/decisions/cli-mcp-http-dispatch.md`
- Stylistic precedent: `docs/decisions/blind-benchmark-ticker-must-blind.md`
- Existing scope-enforcement integration tests:
  `tests/mcp/test_oauth_scope_enforcement.py` (locks `finlet:read`,
  `finlet:trade`, `finlet:benchmark` semantics across submit_order /
  cancel_order / portfolio / benchmark tools — predates this record)

---

## Follow-up: test-quality hardening (Codex peer review, 2026-05-21)

A post-merge Codex peer review of PR #129 (bug `11cb2f16` ship,
sha `6a79802`) surfaced two test-quality findings on this record's
acceptance suite. Both were addressed in the codex-bugs-4pack-v2 iter
under exec-plan `2026-05-21-codex-bugs-4pack-v2-plan.md` (Team A2 —
items #3 and #4). They do not change the decision; they harden the
gate against future regressions of two specific classes that the
original tests could pass-through.

### Item #3 — Mutator spies on the parametrized rejection tests

**Problem.** The original `test_read_only_token_blocked` parametrized
across the 7 write tools asserted that the response contained an
`insufficient_scope` envelope. It did NOT spy on the post-scope
service mutator (`_svc_create_session`, `_svc_delete_session`,
`_svc_complete_session`, `_svc_pause_session`, `_svc_resume_session`,
`_svc_freeze_session`, plus `_resolve_session` for `advance_time`
which has no single `_svc_*` shim). A faulty future `enforce_scope`
implementation that returned the `insufficient_scope` envelope AFTER
calling the mutator would still pass the envelope-shape assertions
while letting state mutation leak through.

**Fix.** Each parametrized rejection assertion now installs a mock
on the tool's first post-scope mutator and calls
`.assert_not_called()` after the rejection run. The mutator-name map
lives in `tests/mcp/test_scope_enforcement.py::_TOOL_MUTATORS` (one
entry per write tool); the installation helper is
`_install_mutator_spy(monkeypatch, tool_name)` which returns the
spy. `AsyncMock` for the 6 `_svc_*_session` shims (all `async def`);
plain `Mock` for the synchronous `_resolve_session`. If a future bug
re-introduces the call-order inversion, the spy gate fails loudly
with `AssertionError: Expected 'mock' to not have been called.
Called 1 times.` — pointing at the spy target and the leaked kwargs.

**Coverage.** Same 7-tool breadth as the envelope-shape gate; spy
runs in the same parametrized test (one mutator per tool). No new
parametrize axis; the spy is additive to each existing rejection
case.

**Manual verification.** A negative test was run during Team A2's
worktree validation: `enforce_scope` was monkey-patched to a no-op
inside `finlet.mcp.server` and `create_session` was invoked with a
read-only Bearer; the mutator spy's `call_count` flipped from 0 to
1, confirming the gate fires on the regression class it's designed
to catch.

### Item #4 — Transport-level test for the original bug repro

**Problem.** The parametrized unit tests above monkeypatch
`finlet.mcp.auth.validate_bearer_jwt` to return synthetic claims and
invoke the tool function directly (`_import_write_tool(name)`).
They do NOT exercise the production FastMCP/JWT HTTP transport that
the original bug `11cb2f16` was discovered against. A bug that lives
in the HTTP dispatch path (e.g., a middleware ordering issue, a
`/mcp/` mount wiring bug, or a `BearerContextMiddleware` regression)
would slip past the unit tests while breaking the production repro.

**Fix.** A new test class
`tests/mcp/test_scope_enforcement.py::TestWriteToolsRejectReadOnlyToken_Transport`
carries one minimal test that:

1. Boots the FastAPI app via `TestClient` (pops
   `FINLET_DISABLE_MCP_HTTP_MOUNT` for the test's lifetime — same
   pattern as `tests/mcp/test_http_endpoint.py`).
2. Re-targets the auth DB to a `tmp_path` so the seeded OAuth client
   does not pollute the dev machine's `~/.finlet/auth.db`.
3. Seeds a test user into the live `auth_service` cache and creates
   an OAuth client + signing key via `storage.create_client` +
   `keys_module.ensure_signing_key`.
4. Mints an EdDSA-signed JWT with `scope="finlet:read"` only.
5. POSTs `initialize` → `notifications/initialized` →
   `tools/call create_session` with the JWT as Bearer.
6. Parses the SSE-framed response; the inner `content[0].text` is
   the dict the `@mcp.tool` decorator returned.
7. Asserts the inner payload carries `insufficient_scope`, that the
   error advertises `scope="finlet:trade"` per RFC 6750 §3.1, and
   that NO `session_id` was returned (the original bug was that
   `user_a_readonly` received a real `session_id`).

**Scope.** ONE tool (`create_session`) is sufficient. The unit tests
above parametrize across all 7 write tools; this test is the
path-coverage anchor for the original Codex repro, not a substitute
for the unit tests' breadth. Adding 6 more transport tests would
6x the lifespan-boot cost (FastAPI app + FastMCP session manager
boot per test) without exercising new code paths — the same
FastMCP/JWT/scope chokepoint handles every write tool identically.

**Opt-out.** The class carries
`pytestmark = pytest.mark.no_api_key_shim` so the conftest's autouse
`_legacy_api_key_test_shim` (which rewrites `api_key=<key>` tool args
to a Bearer token) does NOT intercept the production HTTP path. The
unit tests above keep their legacy api_key compatibility shim
active. Same pattern as `tests/mcp/test_http_endpoint.py:49`.

### Updated test inventory

`tests/mcp/test_scope_enforcement.py` now carries 54 tests (53
behavioral + grep + 1 transport). The previous count was 53. Future
write-tool additions:

* Unit-test parametrize axis grows by 4 (rejection-with-spy /
  trade-passes / multi-passes / api_key-bypass) per tool — same as
  before. Add the tool name to `_WRITE_TOOLS`, the mutator path to
  `_TOOL_MUTATORS`, and the kwargs branch to `_build_kwargs`.
* Static grep gate grows by 2 (positive `finlet:trade` + negative
  not-only-`finlet:read`) per tool.
* Transport test does NOT need a new case per tool — the unit tests
  + grep gate cover the breadth, and the transport test is anchored
  to the original Codex repro path.
* Decision-record classification table grows by one row.
