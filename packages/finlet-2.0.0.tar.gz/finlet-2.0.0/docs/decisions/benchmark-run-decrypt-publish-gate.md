# Decision: Benchmark Run Decrypt → Publish Two-Step Gate

**Date**: 2026-05-20
**Status**: Accepted (shipped via blind-export benchmark redesign exec-plan)
**Related**:
- `docs/decisions/blind-benchmark-architecture.md` (parent — V1 architecture)
- `docs/decisions/blind-benchmark-envelope-fields-must-blind.md` (sibling — boundary contract for blind transforms)
- `docs/decisions/blinded-trace-persistence.md` (sibling — write-time blinding for traces)
- `docs/decisions/blind-mapping-serializer-poison.md` (sibling — runtime backstop for the mapping object)
- `docs/decisions/session-public-visibility.md` (analogue — session-scoped visibility model)

---

## Context

Blind Benchmark V1 (2026-05-19, `docs/decisions/blind-benchmark-architecture.md`) shipped a per-session opaque mapping (`T_NNNN` tickers + `Day_N` dates) gated by `session.config.blind=True`. The salt is `secrets.token_bytes(16)` generated server-side, used immediately to derive the mapping, then **discarded** (`finlet/core/blind_mapping.py:generate_mapping`). Only the derived `BlindMapping` Pydantic model persists, round-tripped through the `sessions.blind_mapping_json` TEXT column (migration `015_add_session_blind_mapping.py`). There is no way to regenerate the mapping from the salt; if the persisted mapping is lost, the blinded record is permanently unreadable in real-ticker form.

V1 had a single state transition for `BenchmarkRun`: `running → completed` (or `failed`). Completed runs were immediately addressable via `export_benchmark_results` MCP tool, and the leaderboard surface (`AgentProfile`) became visible based on `data_sharing_opted_in` set at `start_benchmark` time. There was **no owner-driven post-completion step** to unlock the blinded mapping for export, and no separate gate for making the run publicly addressable via an anonymous URL.

Two leak surfaces motivated the redesign:

1. **`export_benchmark_results` leaked real shape on blind runs** (Team C `3f4ae66`, fixing recon finding 1). The MCP tool called `build_export_dict(benchmark_run, profile, scenario_results)` WITHOUT threading the per-scenario `BlindMapping`, so blinded runs returned `scenario_id="bull_run"`, real session UUIDs, and real ISO `created_at` / `completed_at`. The `complete_session` finalization payload (Codex bug `ad919e11`, 2026-05-20) had been fixed via Team C's iter2 changes but the run-scope export was a parallel uncovered path.

2. **No two-step semantics for public publish.** Even if blind transform were applied uniformly, an owner who wanted to publish a benchmark run had no surface to (a) unlock the mapping for export, then (b) declare the run publicly addressable. The session-scoped `set_session_visibility` model handles per-session publish via `published` + `published_anonymous` + `published_at` columns, but there was no run-scoped analogue, no decrypt step, and no enforcement that public viewers see interpretable (real-ticker) data rather than opaque `T_NNNN`.

The redesign introduces a two-step gate: **decrypt → publish**. Decrypt flips a `decrypted_at` timestamp on the run; publish requires prior decrypt on blind runs only. Non-blind runs skip the decrypt step entirely.

---

## Decision

Add two owner-driven post-completion lifecycle actions to `BenchmarkRun`, gated by a strict ordering:

1. **`decrypt_benchmark_run(run)`** — flips `run.decrypted_at` from `None` to `now` (UTC) on a completed run. Idempotent (second call preserves the original timestamp). Single source of truth in `finlet/api/services/benchmark_service.py` (per `.claude/rules/api-routes.md` §Service-layer parity).

2. **`set_benchmark_visibility(run, *, public, anonymous=None)`** — flips `run.published`, `run.published_anonymous`, and `run.published_at`. **Refuses to publish a blind run before decrypt** (`run.blind=True AND run.decrypted_at IS None → ValueError("benchmark_run_publish_blocked: ...")`). Non-blind runs (`run.blind=False`) publish without any decrypt round-trip — there is no mapping to unlock.

Persistence: four new columns on `BenchmarkRunModel` (migration `021_add_benchmark_run_decrypt_publish.py`) — `decrypted_at` (nullable timestamp), `published` (indexed bool, default `False`), `published_anonymous` (bool, default `True`), `published_at` (nullable timestamp). Migration is idempotent (PRAGMA-table_info guard mirroring 020).

Surfaces (single service-layer code path consumed by all three):

| Surface | Decrypt | Visibility |
|---|---|---|
| REST owner-auth | `POST /v1/benchmark-runs/{id}/decrypt` (`routes_benchmark.py`) | `PATCH /v1/benchmark-runs/{id}/visibility` (`routes_benchmark.py`) |
| MCP owner-auth | `decrypt_benchmark_run(benchmark_run_id, ...)` | `set_benchmark_visibility(benchmark_run_id, public=, anonymous=)` |
| CLI owner-auth | `finlet benchmark decrypt <run_id>` | `finlet benchmark visibility <run_id> [--unpublish] [--attributed]` |
| Anonymous public | `GET /v1/public/benchmark-runs/{id}` + `GET .../export` (`routes_public_benchmark.py`) — 404 (not 403) on unpublished | (read-only) |

The `build_export_dict` invariant (`finlet/leaderboard/reporting.py`) raises `ValueError("build_export_dict_invariant: ...")` when `benchmark_run.blind=True AND blind_mapping IS None AND benchmark_run.decrypted_at IS None`. Decrypt is the explicit owner-driven opt-in to unblinded export, so the defensive raise no longer fires once `decrypted_at` is non-None. Pre-decrypt callers MUST pass `blind_mapping=` explicitly (the owner-auth `export_benchmark_results` MCP tool walks `run.scenario_results` and loads each scenario session's `blind_mapping` from `load_session().blind_mapping`).

Anonymous public export is decrypt-aware: if `run.decrypted_at IS None`, the response renders the blinded shape (`T_NNNN` / `Day_N`); if `decrypted_at IS NOT None`, the response renders the real shape (`AAPL` / `2024-01-01`).

---

## Justification

**The two-step gate is the only way to give the owner explicit consent over BOTH actions.** Publishing a blinded run "as-is" would leak nothing useful (every ticker is `T_NNNN`) but would also leak nothing INFORMATIVE — public viewers couldn't interpret the data. Publishing a decrypted run is a deliberate "I want the world to see my real-ticker performance" declaration. Conflating the two into a single `publish=True` action would force the owner to make a single choice with two consequences, and would also force the public read endpoint to lazy-decrypt on first access — which (a) hides a state mutation behind a GET request, and (b) lets a public viewer trigger a state flip the owner did not authorize. Both shapes are silent-corruption risks; the gate raises upstream at the service layer.

**Decrypt is irreversible and audit-traceable.** Once `decrypted_at` is non-None, the run is permanently unlockable. There is no `recrypt` action — the mapping was already exposed to whoever held the owner token at decrypt time, so re-locking it does nothing for the security model. The timestamp is preserved across idempotent re-calls so audit trails honestly reflect WHEN the owner first unlocked, not the most recent re-invocation. Publish (unlike decrypt) is reversible — `set_benchmark_visibility(..., public=False)` flips `published` back to `False` and the anonymous endpoint immediately 404s; the historical `published_at` is preserved so an ops audit can still see when the run was last public.

**Persisted mapping, not regenerated from seed (recon 1 — `finlet/core/blind_mapping.py:generate_mapping`).** The salt is `secrets.token_bytes(16)` and discarded. The mapping is the ONLY surviving artifact. This is intentional anti-cheat per V1 (`docs/decisions/blind-benchmark-architecture.md` "Server-only one-time-use salt"): prevents users from pre-computing the mapping offline, prevents replay attacks via known seeds, prevents forcing a seed that has been revealed on a prior session. The consequence is that `decrypt_benchmark_run` does NOT regenerate any state — it only flips a column. The mapping must already exist on disk via the per-session SQLite `sessions.blind_mapping_json` column (which it does, by V1 design). The fail-loud path is `benchmark_run_mapping_unrecoverable` in `export_benchmark_results` when both the live in-memory case and the `load_session(scenario_session_id)` fallback fail across every scenario.

**Non-blind shortcut preserves the V1 contract.** Non-blind runs publish without a decrypt round-trip. The gate only fires for `run.blind=True AND run.decrypted_at IS None`. This is the adversarial-review fix Team D applied during implementation (`6d6283d` commit body) — the initial design required decrypt for ALL runs, but a non-blind run has no mapping to unlock, so requiring decrypt would have been a no-op API ceremony that confused the public-export contract for non-blind runs.

**Single source of truth for the immutability invariant.** The gate raises at the service layer via `assert_run_immutable(run)` (per Team B's `baf2623`). The inline `if run.status != "completed"` raise at `finlet/mcp/tools_benchmark.py:483-490` was a Team C TODO; Team D removed it in favor of `assert_run_immutable(run)`. Grep `run.status != "completed"` in `tools_benchmark.py` returns 0 matches. Duplicating an invariant is a Codex-class bug — recorded in the `ce8de077` ancestry (`docs/decisions/complete-session-benchmark-idempotency.md`).

**Information-leakage parity on cross-user requests.** Owner-auth REST routes return 404 (not 403) when a run exists but is not owned by the caller. Mirrors the session surface (`get_user_session` in `finlet/api/deps.py`) — cross-user existence is not leakable via response code differences.

---

## Consequences

### Positive

- **Owner has explicit, auditable consent over both actions.** Decrypt timestamp is preserved across idempotent re-calls; publish timestamp refreshes on every publish event but never clears on un-publish. Ops audit can reconstruct the lifecycle exactly.
- **Public viewers ALWAYS see interpretable data.** Either the run is unpublished (404) or it is decrypted-then-published (real shape). There is no third state where a public viewer sees opaque `T_NNNN` and cannot interpret the run.
- **Build-time defensive raise prevents silent regression.** A future caller that forgets `blind_mapping=` on a blind, undecrypted run fails loud at `build_export_dict` (error code `build_export_dict_invariant`) instead of silently leaking real shape.
- **Single service-layer code path** (`finlet/api/services/benchmark_service.py`) consumed by REST + MCP + CLI. Adding a new surface (e.g., a future webhook or dashboard route) does not require re-deriving the invariant.

### Negative

- **Owner cannot publish a blind run "as-is" without decrypting first.** This is a deliberate constraint, not a bug — see the justification. The mitigation is that the owner can call decrypt and publish in two atomic actions; the gate enforces ordering but does not slow down the actual lifecycle.
- **Decrypt cannot be undone.** Once `decrypted_at` is non-None, the mapping is permanently exposed to anyone who can read the export. This is intentional — re-locking would not retract the prior exposure. Owners who want time-limited decrypts must call un-publish (`set_benchmark_visibility(..., public=False)`) when ready; decrypt itself stays flipped.
- **A future caller that loses access to `session.blind_mapping`** (e.g., a session DB file is deleted out-of-band) loses the ability to render the blinded run as real shape forever, even with `decrypted_at` set. This is the same persisted-mapping consequence as V1; we did NOT add a workaround because the workaround would be regenerating from salt, which we deliberately rejected for anti-cheat reasons. Mitigation: `benchmark_run_mapping_unrecoverable` structured error envelope tells the owner exactly which scenario session lost its mapping so they can restore from backup.

### Trade-offs explicitly chosen

- **Two columns (`decrypted_at` + `published_at`) over one combined state machine.** A unified state machine (`running → completed → decrypted → published`) would be more semantically tight but would force publish to imply decrypt (or fail). Two independent flags lets non-blind runs publish without decrypt, lets owners decrypt without publishing (e.g., to share via owner-auth API only), and lets the audit trail reconstruct both events independently. Cost: callers must understand the gate semantics, but the service-layer raise documents them at the source.
- **Defensive raise over silent-default.** A future caller forgetting `blind_mapping=` on a blind undecrypted run could have silently fallen back to "render real shape" (treating no-mapping as no-blinding-needed). We chose the loud raise because the wrong-shape behavior is exactly the leak the redesign closes — silent fallback would be silent regression. Cost: tests against `build_export_dict` directly must pass `blind_mapping=` explicitly even on non-blind fixtures (or set `decrypted_at`).
- **404 (not 403) on cross-user requests.** Information-leakage parity with the session surface. A 403 would leak the existence of the run to non-owners; 404 conflates "doesn't exist" with "exists but not yours". Cost: legitimate owner debugging is harder because the response doesn't distinguish — mitigation: structured-error envelopes on owner-auth paths echo the run_id back so the owner knows they got the right ID.

---

## Reversal path

Mostly mechanical. To revert to the V1 single-step contract:

1. Drop the four columns via a `022_remove_benchmark_run_decrypt_publish.py` migration (mirror 021's idempotency guard).
2. Remove `finlet/api/services/benchmark_service.py` and its callers (REST `routes_benchmark.py`, MCP tools `decrypt_benchmark_run` + `set_benchmark_visibility`, CLI `benchmark decrypt` + `benchmark visibility`).
3. Remove `finlet/api/routes_public_benchmark.py` and its `_PUBLIC_BENCHMARK_RE` keep-list entry in `finlet/api/deprecation.py`.
4. In `finlet/leaderboard/reporting.py:build_export_dict`, restore the original defensive raise (`benchmark_run.blind=True AND blind_mapping IS None`) without the `decrypted_at` relaxation.
5. Drop `tests/mcp/test_decrypt_visibility_tools.py`, `tests/api/test_routes_benchmark_visibility.py`, `tests/api/test_routes_public_benchmark.py`, `tests/e2e/test_benchmark_publish_gate.py`, `tests/e2e/test_benchmark_run_immutability.py`.

The owner-driven export path (`export_benchmark_results` MCP tool) still works post-reversal because Team C's `3f4ae66` already threads `blind_mapping` from `session.blind_mapping`; the reversal only removes the new owner-driven consent step, not the underlying blind correctness.

Estimated cost: 2-3 hours including migration + test deletion + integration retest. Not a one-SHA reversal because the new lifecycle columns + service layer + 4 routes + 2 MCP tools + 2 CLI commands form a coherent surface that needs symmetric removal.

---

## References

- Service layer: `finlet/api/services/benchmark_service.py` (`decrypt_benchmark_run`, `set_benchmark_visibility`) — Team D `6d6283d`
- DB schema: `finlet/db/leaderboard_models.py` + `finlet/db/migrations/versions/021_add_benchmark_run_decrypt_publish.py` — Team B `baf2623`
- Immutability invariant: `finlet/leaderboard/benchmark_state.py:assert_run_immutable` + `_transition_status` — Team B `baf2623`
- Defensive raise: `finlet/leaderboard/reporting.py:build_export_dict` — Team C `3f4ae66`, relaxed for decrypted runs in Team D `6d6283d`
- REST routes: `finlet/api/routes_benchmark.py` (owner-auth) + `finlet/api/routes_public_benchmark.py` (anonymous) — Team D `6d6283d`
- MCP tools: `finlet/mcp/tools_benchmark.py` (`decrypt_benchmark_run`, `set_benchmark_visibility` at EOF) — Team D `6d6283d`
- CLI commands: `finlet/cli.py` (`finlet benchmark decrypt`, `finlet benchmark visibility`) — Team D `6d6283d`
- Tests: `tests/e2e/test_benchmark_publish_gate.py` + `tests/e2e/test_benchmark_run_immutability.py` (Session 2 gate, T4+T5) — Team F `f12b19a`
- Persisted-mapping rationale (recon 1): `finlet/core/blind_mapping.py:generate_mapping` salt is `secrets.token_bytes(16)` and discarded — only the derived mapping persists; cannot be regenerated from seed
