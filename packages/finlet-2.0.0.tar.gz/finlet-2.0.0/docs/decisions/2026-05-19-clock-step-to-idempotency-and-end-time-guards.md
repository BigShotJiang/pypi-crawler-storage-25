# Decision: Clock.step_to is idempotent at current_time; explicit end_time error

Date: 2026-05-19
Status: shipped (MCP_BENCHMARK_FIXES batch, Team B — commit a15092b)

## Context

`step_to(target)` previously rejected `target <= current_time` as an
error, so an agent calling `advance_time(target_date=current_time)` as a
no-op got a `ValueError`. `_advance_to()` separately clamped targets past
`end_time` silently, masking the truncation.

## Decision

1. `step_to(target)` rejects only `target < current_time`. `target ==
   current_time` is an idempotent no-op (mode flips to STEPPING for
   consistency, no on_advance callback fires).
2. `step_to()` and `step()` raise `ValueError("Target time ... exceeds
   session end_time ...")` when the resulting target overshoots `end_time`.
3. `_advance_to()` keeps the silent clamp as defense-in-depth for the
   `play()` continuous-mode path (where strict-error would crash the
   simulation), now emits `sim_clock.advance_clamped_to_end` structured
   log when it triggers.

## Consequences

- Agents can safely call `advance_time` with the current sim time.
- Agents cannot silently overshoot end_time without an actionable error
  naming the bound.
- The `play()` continuous-mode path is unchanged.
- Two prior tests that relied on the silent clamp on `step_to`/`step`
  (`test_step_to_clamped_to_end`, `test_step_respects_end_time`) were
  replaced with explicit-raise tests.
