# Decision: Extract `security` Job from the CI Test Matrix

**Date:** 2026-05-06
**Status:** Accepted
**Source:** CI/deploy stability reform (Action 4a, Team B)

## Context

`.github/workflows/deploy.yml` ran a single `test` job under a Python matrix (`['3.12', '3.13']`). Inside that matrix it executed five distinct tools — gitleaks, bandit, semgrep, pip-audit, and pytest — on every push to main. Four of those five tools are not interpreter-version-dependent:

- **Gitleaks** scans the git history for secrets — operates on commit text, has no Python runtime.
- **Bandit** is a Python AST linter — its findings depend on source code, not on the running interpreter.
- **Semgrep (JS config)** lints frontend code — Python version is irrelevant.
- **pip-audit** queries the dependency graph against advisory feeds — same advisories regardless of interpreter.

Only **pytest** legitimately needs both 3.12 and 3.13 to verify interpreter-compat behavior of the codebase. Running the other four under the matrix doubled their runtime and doubled the surface for transient network failures (gitleaks API hiccups, semgrep ruleset fetches, pip-audit advisory database timeouts) — every flake had a 2× chance of red-lining a deploy.

The Codex audit on 2026-05-06 explicitly flagged this duplication as the highest-leverage matrix change. The Claude audit independently noted the same shape from a different angle (the e2e job already ran single-version, so there was an established precedent for non-matrixed jobs).

## Decision

Extract a new `security` job that runs gitleaks, bandit, semgrep, and pip-audit-allowlist once on Python 3.12. Keep the `test` matrix for `pytest` only (plus the closely-coupled ruff + mypy steps that consume project source and are cheap to re-run).

The `e2e` job now declares `needs: [test, security]` so deploy still blocks on every prior-existing check; the two upstream jobs run in parallel.

## Consequences

- **Roughly halved security-check wall time.** What ran twice now runs once. The matrix's `test` job stays parallel across 3.12/3.13 but no longer carries the security tools, so the matrix lane finishes faster too.
- **Halved security-check flakiness surface.** Network-dependent scans (gitleaks, semgrep, pip-audit) used to fail the entire deploy if either matrix lane hit a transient. With one execution, transient flakes still hurt, but the dice are rolled once instead of twice.
- **Single source of truth for security findings.** Previously a CVE allowlist or bandit rule change had to land identically in both matrix lanes' logs; now there is one canonical security log per run.
- **Clearer division of labor.** The `test` job is "interpreter compat + lint." The `security` job is "supply chain + secrets + static security scan." The `e2e` job is "integration." Adding a sixth tool to one job no longer requires reasoning about whether it's interpreter-dependent.
- **`needs: [test, security]` keeps deploy gated on both.** No reduction in safety — every check that ran before still runs and still blocks on failure. The only thing that changed is which job hosts each check.

### Alternatives Considered

1. **Leave the matrix as-is.** Rejected. The duplication was load-bearing on flakiness — one of the recurring deploy-failure modes was a transient gitleaks/pip-audit network hiccup on one lane while the other lane passed. Halving the surface is a measurable win.
2. **Move security into a single-version `test` job and keep the matrix only for pytest.** Rejected — this is what we did, conceptually, but doing it in-place inside the existing job would require conditional `if: matrix.python-version == '3.12'` guards on every security step. That obscures the intent. A separate job is honest about the structure.
3. **Run security tools on a separate workflow file (`security.yml`).** Rejected as premature. A separate workflow would need its own trigger filter, its own `paths-ignore`, and its own deploy-blocking wiring. The single-file structure with three jobs is simpler and keeps the gates obvious.
4. **Keep matrixed security, accept the cost.** Rejected. The Codex audit's framing was correct: the cost is real and the benefit is zero. There is no scenario where gitleaks finds a secret on Python 3.13 but not 3.12.
