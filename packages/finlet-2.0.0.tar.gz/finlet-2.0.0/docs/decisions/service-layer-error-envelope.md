# Decision: `ServiceError` as the Cross-Surface Error Envelope

**Date:** 2026-05-07
**Status:** Accepted
**Source:** MCP-First Migration Phase 2; Team A (commit `2321c53`)

## Context

REST routes raise `HTTPException(status_code, detail=str)` which FastAPI serializes as `{"detail": "..."}`. MCP tools return `{"error": str}` flat dicts (the shallow shape introduced by Phase 1's `_resolve_session` helper, see `docs/decisions/mcp-resolve-session-helper.md`). The two surfaces had divergent error shapes; agents that pattern-matched on one shape would break on the other.

Phase 2 needed to add four new gate-failure paths (per-tier session creation, per-user trade rate, per-user market-data rate, per-user Finnhub plugin rate) that fire from inside the service layer. Without a unified envelope, each gate would have had to know which surface called it and emit the matching shape — pushing transport coupling back into the service and defeating the point of Phase 2.

We also wanted a richer error shape for new MCP tools — code, message, and details — but ~30 existing MCP tests pattern-match `isinstance(result["error"], str)`. A breaking change there was off the table for Phase 2.

## Decision

A new module `finlet.api.services.errors` containing a frozen Pydantic `ServiceError` model with three converters:

```python
class ServiceError(BaseModel):
    model_config = ConfigDict(frozen=True)
    code: int                            # HTTP-style status (422, 429, 503, ...)
    message: str                         # agent-actionable, LLM-recoverable
    details: dict[str, Any] | None = None

    def to_http_exception(self) -> HTTPException: ...
    def to_mcp_dict(self) -> dict[str, dict[str, Any]]: ...   # NESTED
    def to_mcp_shallow(self) -> dict[str, str]: ...           # FLAT
```

- `to_http_exception()` -> `HTTPException(status_code=code, detail=message)` if `details` is `None`, else `HTTPException(status_code=code, detail={"message", "details"})`. Used by REST routes.
- `to_mcp_dict()` -> `{"error": {"code", "message", "details"}}` (nested). The recommended default for new MCP tools.
- `to_mcp_shallow()` -> `{"error": str}` (flat). Preserved for back-compat with Phase 1 callers (`_resolve_session`) and ~30 existing MCP tests.

Service functions raise / return `ServiceError(...)` once. Each surface materializes its own wire format at the boundary.

## Consequences

- Phase 2 routes use `to_mcp_shallow()` for MCP rate-limit conversions to avoid breaking existing pattern-match tests. The nested form is available but opt-in for now.
- Future MCP tools should default to `to_mcp_dict()` (nested) for richer error context. The shallow form is back-compat only and should not grow new callers.
- The model is JSON-serializable: enums get converted to int/str at the raise-site; `details` defaults to `None` and is surfaced even when absent in `to_mcp_dict` so agents can inspect it without a key-presence check.
- Frozen (immutable) — prevents accidental mutation between the raise-site and conversion-site, which was a real risk when error shapes were ad-hoc dicts.
- The `ServiceError` envelope is the contract that makes the Phase 2 "service owns the gate" pattern transport-agnostic. Sinking gates into the service (see `docs/decisions/mcp-billing-bypass-closed.md`) only works because the gate can fail in a shape both surfaces understand.

## Alternatives Considered

1. **Force the nested envelope on all MCP tools.** Rejected — would break Phase 1's `_resolve_session` callers and ~30 existing MCP tests that pattern-match `isinstance(result["error"], str)`. Phase 2 cannot regress those without a coordinated test refactor that wasn't in scope.
2. **Mirror REST's `HTTPException` in MCP.** Rejected — MCP cannot raise HTTP-specific exceptions; FastMCP serializes only dicts. The dict envelope IS the protocol for MCP, and the service layer must not depend on FastAPI types in code paths MCP also uses.
3. **Have the service raise a plain `Exception` and let each surface translate.** Rejected — every callsite in every surface would need its own translation logic, drifting independently. The whole point of `ServiceError` is to be the single shape the service emits.
