# Decision: Benchmark ticker must blind through per-session ticker_map

**Date**: 2026-05-21
**Status**: Accepted (shipped via bug-2cd01283 exec-plan)
**Refs**:
- Codex bug `2cd01283-a068-4e73-9cdc-6f2d7440cc6d` (filed 2026-05-21; prod sha at filing `91ce212`)

**Supersedes (in part):**
- `docs/decisions/blind-sse-event-blinding.md` §"Per-call-site coverage" — the implicit "SPY-as-universal" exception baked into the test gates (the SPY-exclusion comment blocks at `tests/e2e/test_blind_benchmark_zero_leak.py:2403-2413` and `tests/api/test_sse.py:429-434` are removed by Team C's `c-bug-2cd01283-tests` PR; this record is the canonical reversal artifact).

**Related**:
- `docs/decisions/blind-benchmark-architecture.md` (parent — V1 architecture; `BlindMapping` model + `apply_ticker` / `apply_date` primitives)
- `docs/decisions/blind-benchmark-envelope-fields-must-blind.md` (parent rule — body+envelope blinding rule that benchmark_ticker now substantively satisfies)
- `docs/decisions/blind-sse-event-blinding.md` (sibling — line 49 updated to note benchmark_ticker is now substantively mapped)
- `docs/decisions/blind-mapping-scenario-and-universe.md` (sibling — stylistic precedent for per-mapping forward transforms)

---

## Context

Codex bug `2cd01283-a068-4e73-9cdc-6f2d7440cc6d` (filed 2026-05-21) showed
that a fresh blind benchmark SSE stream against prod sha `91ce212` leaked
`session.config.benchmark_ticker = "SPY"` 11 times in the first 200 lines.
The agent under blind evaluation can anchor `Day_N` to the actual S&P 500
calendar from a single SPY occurrence, breaking the blind-benchmark
invariant.

Root cause: a **set-membership category error replicated at three layers**.

1. `apply_ticker(real, mapping)` in `finlet/core/blind_mapping.py` returns
   `mapping.ticker_map.get(real, real)` — passthrough when `real not in
   mapping.ticker_map`. The default `benchmark_ticker = "SPY"` is never in
   the per-session universe map, so `apply_ticker("SPY", mapping)` is a
   pass-through that returns `"SPY"` unchanged.

2. `session_response` in `finlet/api/services/session_service.py` calls
   `apply_ticker(benchmark_ticker, mapping)` and trusts that this
   substantively blinds. It does not, for `SPY`. The sibling
   `_apply_blind_to_response` (public-session view) omits `benchmark_ticker`
   from its config-walk entirely — a separate omission.

3. The architectural chokepoint `_detect_leak` (the helper consulted by
   `assert_no_real_blinded_data`) uses the same `value in
   mapping.ticker_map` set-membership check, so the backstop also misses
   `SPY`. Two test gates explicitly EXCLUDED `SPY` from the real-ticker
   grep set, encoding the wrong design ("SPY is universal — leaks
   nothing"); these comment blocks were therefore self-reinforcing
   documentation of the bug.

The prior design — "SPY is universal across all blind benchmarks, so its
appearance leaks no session-specific information" (commit note on the
blind-SSE shipment, 2026-05-21) — is the load-bearing premise that this
record reverses. The reversal is NOT because SPY identifies the SESSION
(it does not — every blind benchmark shares the same default benchmark
ticker), but because SPY anchors `Day_N` to the actual S&P 500 calendar,
which the agent can correlate to the scenario's wall-clock window and
therefore re-identify the scenario regime.

---

## Decision

Two changes, neither of which mutates the `BlindMapping` schema:

### 1. Per-session ticker_map seeds benchmark_ticker

Extend `generate_mapping` to seed the session's `benchmark_ticker` (default
`"SPY"`) into `ticker_map` at session creation, allocated the next opaque
`T_NNNN` id. If `benchmark_ticker` is already a universe entry (e.g., a
user picks `AAPL` as the benchmark and `AAPL` is also in the universe),
the existing opaque id is reused — no double-allocation. `reverse_ticker_map`
is rebuilt AFTER the benchmark add so the inverse stays symmetric.

This makes `apply_ticker("SPY", mapping)` substantively map `SPY` → `T_NNNN`
for any session created via `generate_mapping`, satisfying the
parent rule from `docs/decisions/blind-benchmark-envelope-fields-must-blind.md`
without a schema change.

### 2. Chokepoint defense in depth

Module-level frozenset in `finlet/core/blind_mapping.py`:

```python
_KNOWN_BENCHMARK_TICKERS = frozenset({
    "SPY", "QQQ", "IWM", "DIA", "VTI", "VOO",
    "VXUS", "BND", "TLT", "GLD", "EFA", "EEM",
})
```

A new branch in `_detect_leak` flags any string value in that set as a
`"real_benchmark_ticker"` leak class, ordered AFTER the O(1) ticker_map
check and BEFORE the regex-and-parse date check. This catches any
benchmark ticker that slips past the per-session mapping — e.g., a future
MCP path that constructs responses without going through
`generate_mapping`. The load-bearing fix is the per-session mapping; the
frozenset is the structural backstop.

### 3. Public-session response stanza

The public-session view (`_apply_blind_to_response` in
`finlet/api/services/session_service.py`) gains a 3-line stanza mirroring
its existing `universe` handling:

```python
benchmark_ticker = config_blinded.get("benchmark_ticker")
if isinstance(benchmark_ticker, str):
    config_blinded["benchmark_ticker"] = apply_ticker(benchmark_ticker, mapping)
```

The owner-view `session_response` stanza already existed in shape; it
becomes substantively correct once the `generate_mapping` change lands.

### 4. Tests strip SPY-exclusion + add positive-presence check

Leak-grep tests in `tests/e2e/test_blind_benchmark_zero_leak.py` and
`tests/api/test_sse.py` drop their SPY-exclusion comment blocks and add
`SPY` to the real-ticker grep set. A new positive-presence assertion
confirms `config.benchmark_ticker` in the captured SSE `session` event
starts with `"T_"` — guards against the silent-regression case where the
mapping is undone (so `SPY → SPY` again) but the SSE event never includes
benchmark_ticker, which would still pass an absence-only check.

---

## Consequences

### Positive

* **`apply_ticker("SPY", mapping)` now substantively maps SPY → `T_NNNN`**
  for any session created via `generate_mapping`. The parent rule from
  `blind-benchmark-envelope-fields-must-blind.md` is satisfied without a
  schema migration.
* **Defense in depth catches QQQ / IWM / DIA / VTI / VOO / VXUS / BND /
  TLT / GLD / EFA / EEM** — any known benchmark ETF that bypasses the
  per-session mapping (e.g., a future MCP path that constructs a response
  without going through `generate_mapping`) trips `_detect_leak` and the
  `assert_no_real_blinded_data` chokepoint.
* **Test gates no longer encode the bug.** The SPY-exclusion comment
  blocks were self-reinforcing documentation of the wrong design — they
  read as authoritative ("Team B's commit note: SPY is universal…") and
  would have nudged future readers to repeat the mistake. They are now
  removed; SPY is in the real-ticker grep set; the positive-presence
  check guards against silent regression.
* **No `BlindMapping` schema migration.** The change is a dict entry into
  the existing `ticker_map`, not a new field. Round-trip through
  `model_dump_json` / `model_validate_json` continues to work.

### Negative

* **Pre-existing blind sessions remain unfixed for their lifetime.**
  Sessions persisted on prod before this fix have stale `BlindMapping`
  JSON without the benchmark entry. They continue to leak `SPY` for the
  remainder of their ~days-long lifetime. Acceptable: prod blind sessions
  are short-lived; the next session creation gets the new mapping. Not
  worth a backfill migration.
* **`_KNOWN_BENCHMARK_TICKERS` is a hand-curated allowlist.** New
  benchmark ETFs added to the platform need to be added to the frozenset
  for the chokepoint defense to fire on them. The load-bearing fix is
  the per-session mapping (which picks up the new benchmark automatically
  via `generate_mapping`), so this is the secondary cost. Documented as
  a known-followup: any new benchmark added → also add to the frozenset.
* **The opaque-id allocation for benchmark_ticker uses the next `T_NNNN`
  slot.** This means the universe + benchmark namespace is unified
  (benchmark id is just another universe id, by content if not by
  semantics). An agent who counts opaque ids cannot distinguish
  benchmark from universe by id-shape alone — they have to read the
  `config.benchmark_ticker` field to know which `T_NNNN` is the
  benchmark. This is the intended trade-off (uniform namespace) but
  worth flagging.

### Trade-offs explicitly chosen

* **Per-session ticker_map extension over SHA-256-derived `B_XXXX`.**
  We considered a separate forward transform mirroring `apply_scenario`
  (SHA-256 hash → `B_XXXX` opaque label, cached in a new `benchmark_map`
  field). Rejected: the per-session ticker_map approach unifies the
  namespace with universe tickers and reuses the existing `apply_ticker`
  primitive — no new primitive, no new field, no new round-trip surface.
  The downside (universe + benchmark id-shape collision) is the
  intended trade-off.
* **`_KNOWN_BENCHMARK_TICKERS` frozenset over a dynamic registry.**
  We considered a dynamic registry that scans `BenchmarkPlugin`
  registrations or `config.benchmark_ticker` defaults across all
  sessions. Rejected: the chokepoint is defense in depth — the
  load-bearing fix is the per-session mapping, which picks up the
  benchmark automatically. The frozenset is a static list of the
  current-supported benchmark ETFs; updating it when a new benchmark
  ships is a one-line change.
* **Read-time stanza in `_apply_blind_to_response` over write-time
  blinding of `session.config.benchmark_ticker`.** Mirrors the existing
  pattern for `session.config.universe` — raw on disk, blinded at the
  public-viewer boundary. The dashboard and ops audit trail need the
  real benchmark ticker for debugging; read-time blinding keeps the
  audit trail intact at the cost of a per-emit `apply_ticker` call.

---

## How to apply

If you add a new benchmark ticker to the platform (e.g., adding
`SPXL` as a 3x-leveraged S&P benchmark option):

1. **Add to the universe-creation default path.** `generate_mapping`
   picks up `session.config.benchmark_ticker` automatically — no change
   needed if the new ticker flows through that field.
2. **Add to `_KNOWN_BENCHMARK_TICKERS`** in `finlet/core/blind_mapping.py`.
   Defense-in-depth backstop for any code path that bypasses
   `generate_mapping`. One-line addition to the frozenset.
3. **No test change required.** The existing leak-grep tests will pick
   up the new benchmark on the next blind-benchmark SSE walk because
   the per-session mapping substantively maps it. If a regression
   bypasses the mapping, the `_KNOWN_BENCHMARK_TICKERS` chokepoint
   catches it under `FINLET_BLIND_ASSERT=raise` in CI.

If you find another category of "real-data-leaked-by-default" string
type (e.g., a real index name like `S&P 500` or `Nasdaq`):

1. **Resist adding a one-off allowlist.** The `_KNOWN_BENCHMARK_TICKERS`
   frozenset is specifically for short-symbol identifiers that
   participate in the ticker namespace. A natural-language string is
   a different leak class.
2. **Consider a new forward transform** mirroring `apply_scenario` or
   `apply_universe` if the new category is structural; otherwise rely
   on the per-call-site wiring at the read boundary.
3. **Update the parent rule** in
   `docs/decisions/blind-benchmark-envelope-fields-must-blind.md`.

---

## Reversal path

Mechanical, three steps:

1. Remove the `benchmark_ticker` seeding from `generate_mapping` and
   the symmetric `reverse_ticker_map` rebuild.
2. Remove `_KNOWN_BENCHMARK_TICKERS` and its branch in `_detect_leak`.
3. Restore the SPY-exclusion comment blocks at
   `tests/e2e/test_blind_benchmark_zero_leak.py` and
   `tests/api/test_sse.py`, drop SPY from `real_universe_tickers` /
   `_REAL_TICKER_PATTERN`, drop the positive-presence assertion in the
   SSE subtest.

Estimated cost: 20 minutes. The reversal is technically sound but
reintroduces the exact bug `2cd01283` repro — SPY leaks 11x in the
first 200 lines of a fresh blind SSE stream. **Discouraged** because
the bug filer's repro is publicly known and the next blind benchmark
agent run would re-hit it.

---

## References

- Bug filing: Codex `2cd01283-a068-4e73-9cdc-6f2d7440cc6d` (2026-05-21; prod sha `91ce212`)
- Engine change (`generate_mapping` extension + `_KNOWN_BENCHMARK_TICKERS` + `_detect_leak` branch): `finlet/core/blind_mapping.py` — Team A (`team-A-bug-2cd01283-engine`)
- API change (`_apply_blind_to_response` stanza + `session_response` comment): `finlet/api/services/session_service.py` — Team B (`team-B-bug-2cd01283-api`)
- Test changes (SPY-exclusion strip + positive-presence assertion): `tests/e2e/test_blind_benchmark_zero_leak.py`, `tests/api/test_sse.py` — Team C (`team-C-bug-2cd01283-tests`)
- Parent rule: `docs/decisions/blind-benchmark-envelope-fields-must-blind.md`
- Sibling decision (line 49 cross-reference update): `docs/decisions/blind-sse-event-blinding.md`
- Stylistic precedent: `docs/decisions/blind-mapping-scenario-and-universe.md`
