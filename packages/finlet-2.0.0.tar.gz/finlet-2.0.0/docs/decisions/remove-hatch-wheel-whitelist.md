# Decision: Hatch Wheel Whitelist for Thin Client

**Status:** Superseded

**Date:** 2026-04-05 (original), 2026-04-06 (superseded)

## Context

The `[tool.hatch.build.targets.wheel]` `only-include` directive in `pyproject.toml` was originally added to limit the PyPI wheel to thin client files only (`finlet/__init__.py`, `finlet/cli.py`, `finlet/config.py`).

This broke the server deployment because `pip install .` on EC2 also used the wheel target, excluding all server subpackages (`finlet/core/`, `finlet/api/`, `finlet/plugins/`, etc.) and causing `ModuleNotFoundError` at runtime.

The whitelist was removed in commit `1d4b247` to unblock the server.

## Superseded

Wheel whitelist reinstated for thin client publishing; deploy scripts use editable installs to avoid the prior breakage. See `pyproject.toml` `[tool.hatch.build.targets.wheel]`.

The fix has two parts:

1. **`pyproject.toml`**: `[tool.hatch.build.targets.wheel]` `only-include` is back, scoping the wheel to thin client files only. This is what PyPI receives.
2. **`deploy/deploy.sh` and `deploy/rollback.sh`**: Changed from `pip install .` to `pip install -e ".[server]"`. Editable installs bypass the wheel target entirely — Python uses the source tree directly, so all server modules are available. The `[server]` extra pulls in all server dependencies.

Additionally, `.github/workflows/pypi-publish.yml` now includes a validation guard step that inspects the built wheel and fails the build if any server module is found in the thin client distribution.

## Decision

The wheel whitelist and editable install pattern coexist safely because they serve different contexts:
- **PyPI publish** (`hatch build`): Produces a thin client wheel with only 3 files.
- **Server deploy** (`pip install -e ".[server]"`): Editable install ignores wheel targets, uses full source tree.

This is the correct long-term pattern. No further changes needed unless the project migrates away from hatch.
