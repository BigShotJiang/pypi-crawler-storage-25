# Decision — Trade Ticket render-on-read (canonical store; bus events as triggers)

**Date:** 2026-05-02
**Status:** Accepted

---

## Context

`#tt-cash-balance` (the Trade Ticket panel's "Available Cash" header) has been the recurrence surface for three iterations of fixes against the same architectural bug class:

1. **v1 — `efdd44316` (2026-04-30).** Shipped `dashboard/dialog-state-mirror.js`. Closed three recurrence shapes for *true dialogs whose DOM lifecycle equals their visibility lifecycle*: pre-publish-gap (open-after-publish), mid-fill stale (panel open during fill), and shape-drift / transient-failure stomp.
2. **iter `20260502T142726Z7b36` Team A patch — `109686c`.** Added a post-submit `/portfolio` refetch + `portfolio:updated` republish inside `submitTradeTicket` so the next panel re-open primed from the post-fill cash. Closed the gap where the panel was closed by `submitTradeTicket()` BEFORE the post-submit IIFE republished. Phase 5.5 retest classified this patch as **patch-ineffective** — the persistent-DOM `<span>` rotted between close and next open because no subscriber kept it in sync while the panel was closed.
3. **v2 — `c712d98`, merged in `1cd2b5b` (2026-05-02).** Added a page-lifetime `portfolio:updated` subscriber inside `initTradeTicket()` that called `paintCash(payload.cash)` on every publish, regardless of panel visibility. **Regressed at deploy gate (run `25261964914`).** The existing journey-05 regression test at `tests/e2e/journey-05-trade.spec.ts:447-463` asserted that publishing `{ cash: 999999 }` after `closeTradeTicket()` MUST NOT mutate `#tt-cash-balance`; the v2 always-on subscriber painted the poison value. v2 was reverted as the first commit of v3.

Cross-link:
- v3 source doc: `docs/bug-hunt/refactor-queue/trade-ticket-state-sync-v3.md`.
- Parent ADR: `docs/decisions/dashboard-event-bus.md` — establishes the bus as a delivery layer; this ADR is consistent with that positioning (bus carries data; the panel's reader path doesn't trust it).
- Sibling ADRs: `docs/decisions/dialog-state-mirror-prime-ordering.md` (v1's prime-source contract).

The pattern across iterations: each patch added one publisher or one subscriber. The set of "places that read or write `#tt-cash-balance`" kept growing; the rules for which write should land on the DOM kept growing in lockstep. v4 would have surfaced as soon as the next surprising publisher/subscriber asymmetry was added.

## Decision

**The panel owns its read.** The Trade Ticket cash header is rendered from a single canonical store; bus events are repaint TRIGGERS, not value carriers.

Concretely, in `dashboard/trade-ticket.js`:

- `getCanonicalCash()` is the **only reader**. It returns `currentSession.portfolio_metrics.cash` if set; otherwise `bus.getLastPublished('portfolio:updated').cash`; otherwise `undefined`. Both upstream sources are SSE-fed and atomically mutated by post-fill paths — the panel never trusts a payload from an arbitrary publisher.
- `repaintCash()` is the **only writer**. It takes no value argument. It reads via `getCanonicalCash()` and writes the formatted dollar string to `#tt-cash-balance.textContent`. Refuse-clobber is baked in: if canonical is `undefined` or `NaN`, the function returns without painting (so a placeholder never overwrites a known-good value).
- The per-open `dialogStateMirror`'s `onOpen` and `onUpdate` callbacks call `repaintCash()` instead of `paintCash(value)`. Bus payloads are intentionally ignored; they exist solely to signal "something changed; re-read canonical."
- `fetchCashBalance()`'s terminal write atomically mutates `currentSession.portfolio_metrics.cash` first, then calls `repaintCash()` — making it consistent with every other publisher path.

The v2 always-on subscriber installed in `initTradeTicket` is gone (reverted in commit 1 of the v3 chain).

## Atomic-mutate-then-publish contract

Every `bus.publish('portfolio:updated', ...)` MUST be preceded by a write to `currentSession.portfolio_metrics.cash` in the same code path. This is what makes "canonical" actually canonical: by the time any subscriber's repaint runs, `currentSession` already holds the fresh value.

Audit method:

```
grep -rn "finletBus.publish.'portfolio:updated" dashboard/
```

Pre-v3 baseline (verified during recon, all clean):

| Publisher | Site | Mutation precedes publish at |
|-----------|------|-----------------------------|
| SSE `portfolio` event handler | `dashboard/app.js:1472` | `app.js:1456-1466` |
| SSE `orders` post-fill IIFE | `dashboard/app.js:1608` | `app.js:1595-1605` |
| `submitTradeTicket` post-submit IIFE | `dashboard/trade-ticket.js:484` | `trade-ticket.js:463-477` |

If a future change introduces a 4th publisher of `portfolio:updated`, it MUST mutate `currentSession.portfolio_metrics.cash` first, in the same function or IIFE, before the publish call. Reviewers should re-run the audit grep on every change to this surface and verify each match's preceding mutation.

## Why not a source predicate or a dedicated event

Two alternative designs were considered:

1. **Source predicate on the v2 subscriber.** Add a `source: 'sse' | 'post-fill-refetch'` field to every publisher's payload; the subscriber paints only when the source is on a whitelist. Rejected: introduces a new convention the linter cannot enforce. The next forgetful publisher omits `source` and either (a) gets ignored when it shouldn't, or (b) the predicate is permissive and the journey-05 test poison sneaks through. Same fundamental "panel trusts the publisher" failure mode, with extra ceremony.
2. **Dedicated `panel-cash:repaint` event.** Add a new event in `event-contract.md`; the panel listens to it instead of `portfolio:updated`; publishers fire both. Rejected: same shape as v2, just renamed. Different failure mode of the same shape will surface — what if a publisher fires the new event with a value that disagrees with canonical?

v3 inverts the trust direction: the panel reads canonical instead of trusting payloads. New publishers that don't update the canonical store harmlessly trigger a repaint of whatever IS canonical, instead of poisoning the DOM with whatever the publisher sent.

## Out of scope

- **Other slide-out panels.** The Trade Ticket is the only persistent-DOM bus-mirror surface today. If a second one appears (a sticky positions sidebar, an always-visible mini-card), revisit then.
- **`renderOnRead.js` extraction.** Single consumer; defer extraction until a second instance appears. Same break-even logic v1 used (3 instances before extraction). The reader pair (`getCanonicalCash` + `repaintCash`) is small enough to live next to its only consumer until that bar is met.
- **Server contract.** Publishers (`app.js` SSE portfolio handler, `app.js` SSE orders post-fill IIFE, `trade-ticket.js` post-submit IIFE) are correct — they all atomically mutate `currentSession.portfolio_metrics` before publishing. v3 codifies that pre-existing pattern as a contract; it does not change any publisher.
- **Future read-only consumer outside the panel.** No such consumer exists today. journey-05's poison test reads `#tt-cash-balance.textContent` specifically to verify the inverse contract. If a future consumer needs always-fresh cash, the right answer is for THAT consumer to read `getCanonicalCash()` (or `currentSession.portfolio_metrics.cash`) directly, not to hook `#tt-cash-balance`.

## Consequences

- `journey-05:447-463` (the poison-publish-after-close assertion) passes by construction: the panel never reads payload values, so a `bus.publish('portfolio:updated', { cash: 999999 })` while `currentSession.portfolio_metrics.cash !== 999999` cannot mutate the DOM.
- The iter `20260502T142726Z7b36` recurrence shape (panel rotted between close and next open) is closed: the post-submit IIFE atomically mutates `currentSession.portfolio_metrics.cash` BEFORE publishing, so the next `openTradeTicket()` → `repaintCash()` reads the fresh canonical value.
- The total LOC delta is small (~30 LOC net in `trade-ticket.js`), and is mostly subtractive vs. the v2 attempt.
- Future bug-hunt iterations on this surface should default to "what does the canonical store look like, and which publisher failed to mutate it?" rather than "which subscriber painted the wrong thing?"

## Test infrastructure — `window.currentSession` two-way alias

The render-on-read contract requires test harnesses (and any out-of-script-scope consumer) to be able to drive the canonical store the same way production publishers do: atomically mutate `currentSession.portfolio_metrics.cash` first, then `bus.publish('portfolio:updated', ...)`. The existing journey-05 tests reach for `window.currentSession` to perform that mutation (`tests/e2e/journey-05-trade.spec.ts:687-699` for the well-formed case, `:712-722` for the shape-drift case).

`dashboard/app.js` declares `currentSession` as a module-scope `let` (it's a classic `<script>`, not an ES module). Without an alias, `window.currentSession` is `undefined`; assignments to it create a separate window-only property; the module's reader (`getCanonicalCash()` → `currentSession.portfolio_metrics.cash`) never sees the test's mutation. The v3 deploy (sha `42ffd2e9`, run `25265689240`) failed on `journey-05:702` for exactly this reason: the test mutated a phantom `window.currentSession`, the module's binding stayed at the seeded `$100,000.00`, and the locator timed out at `$94,548.49`.

Fix: install a permanent two-way alias at `app.js:21-29` immediately after `let currentSession = null;`:

```js
Object.defineProperty(window, 'currentSession', {
    configurable: true,
    get() { return currentSession; },
    set(value) { currentSession = value; },
});
```

The descriptor closes over the module's lexical `currentSession`. Reads via `window.currentSession.portfolio_metrics.cash` route through the getter; writes via `window.currentSession = obj` route through the setter and rebind the module variable; property mutations on the returned object (the most common test pattern) reach the same object the module binding holds. All three rebind sites in `app.js` (`:1432, :1800, :2341`) and the SSE-mirroring `currentSession.portfolio_metrics.cash = X` writes (`app.js:1456-1466, :1595-1605`; `trade-ticket.js:298-308, :467-481`) become reflexively visible to `window.*` consumers without further plumbing.

This is purely a test-infrastructure concern; no production code path reads through `window.currentSession`. Production code uses the module's lexical binding directly (which is what `getCanonicalCash()` does). The alias is non-load-bearing for production correctness — its only consumer is the test harness's mutate-then-publish synthesis. Removing the alias would not break production but would re-break `journey-05:652`. Documented here so a future audit doesn't strip it as "unused".
