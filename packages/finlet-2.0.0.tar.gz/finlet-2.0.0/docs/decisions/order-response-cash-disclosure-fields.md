# Decision: `OrderResponse` Discloses `commission`, `slippage_amount`, `total_cost`

**Date**: 2026-05-03
**Status**: Accepted
**Iteration**: bug-hunt `20260503T230405Z2601` (Team D, merge `3dc28c2`, worktree commit `0e54b8d`)

---

## Context

Bug-hunt iteration `20260503T230405Z2601` flagged a "cash math doesn't reconcile" finding: a user submitted BUY 10 SPY, observed displayed `fill_price = $560.90`, expected `cash_delta = 10 × $560.90 = $5,609.00`, but actually saw `$5,608.97` deducted from cash. The $0.03 mismatch had no field on the response that explained it. The user concluded the system was lying about its cash math.

Root cause is precision-vs-display, not arithmetic:

- The engine computes cash math at 6dp internally:
  - `fill_price = $560.897000` (6dp)
  - `slippage_amount = (fill_price - pre_slippage) × quantity = $5.6034` (4dp)
  - `total_cost = fill_price × quantity + commission = $5,608.97` (round-2 of 6dp math)
- The response exposes `fill_price` rounded to 2dp for display: `$560.90`
- Client multiplies `$560.90 × 10 = $5,609.00`, observes $0.03 mismatch with the cash deduction.

The math IS consistent at 6dp. The bug was that the response only exposed `fill_price` and `quantity`, forcing the client to multiply at lower precision than the engine computed at — and the lower-precision multiplication is what created the visible mismatch.

V1 contract is binding:
- `commission == 0` (default, configurable but rarely changed; every test, every benchmark, every leaderboard score depends on it)
- `slippage_bps == 10` (default, configurable per-session via `SessionConfig.slippage_bps`)

Changing either default would re-price every order ever submitted, cascade through `realized_pnl`, `equity_curve`, `PortfolioMetrics`, leaderboard scoring, and break property-based portfolio tests. Off-limits.

---

## Decision

**Add three optional disclosure fields to `OrderResponse`. Populate them in `trade_service.order_dict(order, *, session=None)` so REST and MCP both surface the fields. Add a `slippage_amount` field on the `Order` model populated by `OrderBook._fill()` at fill time. Render a Total Cost column on the dashboard order log table.**

This is a DISCLOSURE fix, not a math change. The engine's cash math is unchanged; the response shape gains three additive fields that make the math reconcilable from response data alone.

### `Order` model (`finlet/core/orders.py`)

```python
@dataclass
class Order:
    # ... existing fields ...
    fill_price: float | None = None
    filled_at: datetime | None = None
    slippage_amount: float | None = None  # NEW: absolute dollar slippage at fill
```

`OrderBook._fill(order, price, sim_time)` records the slippage at fill time:

```python
fill_price = self._slippage_model.apply(price, order.side)
order.fill_price = fill_price
if order.side == OrderSide.BUY:
    order.slippage_amount = round((fill_price - price) * order.quantity, 6)
else:
    order.slippage_amount = round((price - fill_price) * order.quantity, 6)
```

Positive for both sides — cost increase for BUY, proceeds reduction for SELL.

### `OrderResponse` schema (`finlet/api/schemas/trade.py`)

```python
class OrderResponse(BaseModel):
    # ... existing fields ...
    commission: float | None = Field(
        default=None,
        description="Commission charged on this fill (v1: 0.0 by session config).",
    )
    slippage_amount: float | None = Field(
        default=None,
        description="Absolute dollar slippage charged on this fill.",
    )
    total_cost: float | None = Field(
        default=None,
        description=(
            "Signed cash impact of the fill: fill_price × quantity ± commission. "
            "Positive for BUY (cash outflow), negative for SELL (cash inflow). "
            "Reconciles with the cash delta exactly."
        ),
    )
```

All three fields are optional (`default=None`) for backwards-compatibility — older clients that ignore them continue to work; pre-fill orders (PENDING) and rejected orders correctly serialize them as `None`.

### Service-layer enrichment (`finlet/api/services/trade_service.py`)

```python
def order_dict(order: Order, *, session: Session | None = None) -> dict:
    payload = order.to_dict()  # existing serialization
    if order.status == OrderStatus.FILLED and order.fill_price is not None:
        commission = (session.config.commission if session else 0.0) or 0.0
        sign = 1 if order.side == OrderSide.BUY else -1
        payload["commission"] = commission
        payload["slippage_amount"] = order.slippage_amount
        payload["total_cost"] = round(
            sign * (order.fill_price * order.quantity + commission), 6,
        )
    return payload
```

The route handlers in `finlet/api/routes_trade.py` pass `session=session` to `order_dict` calls.

### Dashboard order log (`dashboard/index.html` + `dashboard/app.js`)

`<th>Total Cost</th>` column added with `<abbr title="Signed cash impact: fill_price × quantity ± commission">` header tooltip. Empty-state colspan updated 8→9. Cell renders:

```html
<td title="Gross: $X.XX | Commission: $Y.YY | Slippage: $Z.ZZ">
  ${total_cost.toFixed(2)}
</td>
```

Hover-tooltip discloses the breakdown for users who want to see how the total was computed.

---

## Cash-reconciliation walkthrough

Reproducing the exact triage scenario with the new disclosure fields:

```
PRE cash (GET /portfolio.cash):       $100,000.00
POST cash (GET /portfolio.cash):       $94,391.03
cash delta (PRE − POST):                $5,608.97  ← was unexplained before this fix

Order response (after fix):
  fill_price:                           $560.897000   (server precision; displayed as $560.90)
  quantity:                             10
  commission:                           $0.00         (v1 contract; disclosed for transparency)
  slippage_amount:                      $5.6034        (10 bps × $560.34 pre-slippage × 10 shares)
  total_cost:                           $5,608.97     ← matches cash delta exactly

RECONCILIATION:
  total_cost == cash delta:              TRUE   (within 1¢)
  total_cost == fill_price × qty + commission:
                                         TRUE   ($560.897 × 10 + 0 = $5,608.97)
```

The previously-mysterious −$0.03 difference vs the user's mental model (`10 × $560.90 = $5,609.00`) is just the rounding gap between the displayed `fill_price` ($560.90, round-2) and the engine's stored `fill_price` ($560.897, round-6). The engine math is consistent; the missing piece was disclosure.

For BUY: `cash_delta = total_cost = fill_price × quantity + commission`.
For SELL: `−cash_delta = total_cost = fill_price × quantity − commission` (i.e. proceeds credited).

---

## Alternatives Considered

### A. Round `fill_price` to 2dp at the engine level

Rejected. Re-prices every order ever submitted; cascades through realized P&L, equity curve, leaderboard scoring; breaks property-based portfolio tests that assert at higher precision; would surface as a "your historical results changed" complaint to every existing user. The math at higher precision is correct — display rounding should not contaminate stored values.

### B. Document the precision mismatch in agent docs without changing the response

Rejected. Documentation can't survive contact with users who multiply on a calculator. The system literally lies to anyone who computes `fill_price × quantity` and compares to cash delta. Every new user will hit this.

### C. Round `total_cost` (computed value) to 2dp on response

Rejected. Same problem at a different layer — the response would still expose `fill_price` at 2dp and `total_cost` at 2dp, but the relationship `fill_price × quantity = total_cost` would only hold within ±$0.005 per share. For 10 shares, that's ±$0.05; for 1000 shares, that's ±$5. Users would still see a mismatch.

### D. Expose only `total_cost`, omit `commission` and `slippage_amount`

Rejected. The user wants to know WHY the cost differs from what they expected. `commission` (0.0 in v1) is explicit confirmation that no fees were charged; `slippage_amount` shows the engine's slippage model in action. Three fields together = one verification axis per gap-source. One field alone = a black box that says "trust me, $5,608.97 is correct."

### E. Add a precision flag to the response (`fill_price_precision: 6`)

Rejected. Forces every client to do the multiplication AND track the precision flag. The disclosure fields are the user-facing verification axis; precision flags are an implementation detail that doesn't help users reconcile.

---

## Trade-offs

### What we gained

- Cash math reconciles from API response alone — `total_cost == cash_delta`.
- Three independent verification axes (commission disclosure, slippage disclosure, total signed delta) — users can audit each independently.
- V1 contract preserved (commission=0, slippage_bps=10 unchanged).
- Backwards-compatible (new fields are optional, default `None`).

### What we accepted

- Three new optional fields on every `OrderResponse` payload (~30 bytes per order in JSON serialization).
- One new field on the `Order` core model (`slippage_amount`).
- One new column on the dashboard order log (Total Cost) with breakdown tooltip.
- `trade_service.order_dict` signature change (`session` is now an optional kwarg) — call sites updated.

---

## Risk-binding test

TDD red phase committed BEFORE implementation:

`tests/api/test_orders.py::TestOrderResponseCashDisclosure::test_cash_reconciliation_buy_with_default_slippage_and_commission` was written and committed FAILING. The test:

1. Submits a BUY market order for SPY at a known seed price.
2. Reads `OrderResponse` after fill.
3. Asserts `total_cost` is present, `commission == 0.0`, `slippage_amount > 0`.
4. Asserts `total_cost == round(fill_price * quantity + commission, 6)`.
5. Asserts `cash_after = cash_before - total_cost` within 1 cent.

Implementation drove the test green. The failing-state proves the test exercises the disclosure gap; without the red phase, a passing test could be tautological (asserts the field equals the value it just computed).

`tests/core/test_clock_step_integration.py::TestOrderCashDisclosureWithSlippage::test_slippage_amount_disclosed_on_filled_order` is a parallel test at the engine level — asserts `Order.slippage_amount > 0` when `slippage_bps > 0` and `total_cost ≈ fill_price * quantity` when `commission == 0`.

---

## Reversal Path

Single revert. Remove the three fields from `OrderResponse`, the `slippage_amount` field from `Order`, the disclosure block in `trade_service.order_dict`, the Total Cost column in `dashboard/index.html` + `dashboard/app.js`, and the two test classes. ~30 minutes mechanical revert. The cash-reconciliation bug would re-open — clients who multiply `fill_price × quantity` would observe the same pennies-level mismatch as before. Not recommended.

---

## References

- This iteration's merge: `3dc28c2` (worktree commit `0e54b8d`)
- `finlet/api/schemas/trade.py` — `OrderResponse` (commission, slippage_amount, total_cost fields)
- `finlet/api/services/trade_service.py` — `order_dict(order, *, session=None)`
- `finlet/api/routes_trade.py` — `order_dict` calls pass `session=session`
- `finlet/core/orders.py` — `Order.slippage_amount`, `OrderBook._fill()` records it
- `dashboard/index.html` — `<th>Total Cost</th>` column + colspan 8→9
- `dashboard/app.js` — Total Cost cell render with breakdown tooltip
- `tests/api/test_orders.py::TestOrderResponseCashDisclosure` (4 tests)
- `tests/core/test_clock_step_integration.py::TestOrderCashDisclosureWithSlippage` (1 test)
- Related lesson in `docs/LESSONS.md`: "Server-computed cash deltas MUST be reconcilable from API response fields alone."
- Related: `docs/ARCHITECTURE.md::4. Order System` — Slippage model + cash-disclosure fields paragraph.
