# exec-plan: durable eval-trace artifacts (`exec-trace.txt` + `team-prompts/`)

> Status: adopted 2026-05-02
> Skill: `.claude/skills/exec-plan/`
> Related eval IDs: EP-06, EP-13

## Problem

Two `exec-plan` eval assertions had been INCONCLUSIVE for 4+ consecutive runs:

- **EP-06** — "Each code agent's prompt included instructions to read `docs/KNOWN_FAILURES.md` first."
- **EP-13** — "Main agent read the plan document once at the start (Step 0), not repeatedly throughout execution."

Both check orchestration behaviors that are not visible in commit artifacts:

- EP-06 needs the *content of subagent prompts*. Commit messages can mention validation steps but the actual prompt text sent to the spawned `Agent` is not durably recorded.
- EP-13 needs the *frequency of plan-doc Reads by the orchestrator*. The plan doc itself can be diff-checked, but a Read with no Write leaves no artifact.

The eval agent runs read-only and has no access to the orchestrator's tool-use transcript. So both checks defaulted to INCONCLUSIVE — which the recurring-deviations summary in `docs/skill-eval-results.md` flagged as "next-skill-edit blocking" by the v3 (2026-05-02) eval.

## Decision

The orchestrator now emits two durable artifacts during execution. The finalize agent stages and commits them, so they land on `main` as part of the audit trail.

### Artifact 1: `<plan-dir>/exec-trace.txt`

Append-only line log. The orchestrator writes one `read_plan` line immediately after the Step 0 plan-Read:

```
read_plan ts=<UTC ISO 8601> plan_sha=<git rev-parse HEAD:path/to/plan.md> orchestrator=true
```

A second `read_plan orchestrator=true` line is the diagnostic signal for EP-13 FAIL — it means the orchestrator re-read mid-execution, violating the lean-coordinator invariant. Subagent reads are NOT logged; they're delegated and don't bloat the main agent's context.

The format is line-oriented and deliberately simple: future events (`spawn_team`, `merge_team`, etc.) can extend the file without breaking parsers, and `wc -l` / `grep -c` are sufficient eval tooling.

### Artifact 2: `<plan-dir>/team-prompts/<team-id>.md`

Full text of the prompt the orchestrator sent to each code subagent. Written before the spawn (so the artifact survives orchestrator crash). One file per team, named by the team's id from the plan (`team-A.md`, `team-B.md`, `team-1.md`).

EP-06 verification reduces to:

```bash
grep -L "docs/KNOWN_FAILURES.md" <plan-dir>/team-prompts/*.md  # empty output = PASS
```

## Why these artifacts (and not alternatives)

**Why not have eval read the orchestrator's tool-use transcript?**
The transcript file is JSONL of every tool call in the session. It overflows context (the Agent tool result already warns NOT to read it directly). Also, it lives outside the repo and isn't durable across machines.

**Why not require a stricter "read-once" enforcement (e.g. parsed_plan.json caching)?**
Considered. It's the cleanest invariant — make the orchestrator read once into a JSON cache, then read the cache on subsequent inspections. But that's a larger refactor of the skill's state model, and the ASSERTION encoded by EP-13 is that the orchestrator is *disciplined*, not that it's *forced*. The trace artifact lets us measure the discipline without re-architecting.

**Why per-team prompt files instead of a single concatenated file?**
Per-team makes EP-06 grep trivially scoped (one file per spawn). It also matches how the orchestrator naturally produces them — one prompt per `Agent` tool call. A concatenated file would require re-aggregating at finalize.

**Why not require the orchestrator to commit these mid-execution?**
The finalize agent already runs at the end of the execution and is the natural commit point for "audit trail" artifacts. Mid-execution commits would race with the per-team merge gates and blur which commit closed which team.

## Eval semantics

EP-06 and EP-13 now have THREE outcomes:

- **PASS** — artifact present, content meets the predicate.
- **FAIL** — artifact present, content fails the predicate. (For EP-13: 2+ `read_plan` orchestrator lines. For EP-06: any prompt missing `docs/KNOWN_FAILURES.md`.)
- **INCONCLUSIVE** — artifact missing entirely. This is a *skill violation* (orchestrator forgot to write the file), not a behavior failure. The eval logs it so the next eval round flags the gap, escalating fixes if the skill regresses.

## Backwards compatibility

Past iterations (pre-2026-05-02) won't have these artifacts. The eval already noted them INCONCLUSIVE; nothing changes for historical runs. Going forward, every `/exec-plan` invocation should produce both artifacts at finalize.

## Carry-cost

- One short Bash append per execution (Step 0).
- One small Write per code-team spawn (Step 2 LAUNCH).
- One `git add` line in the finalize agent's prompt (Step 4).

Negligible cost. The artifacts also serve as a human-readable record of what was actually run, which is useful even when eval isn't checking.
