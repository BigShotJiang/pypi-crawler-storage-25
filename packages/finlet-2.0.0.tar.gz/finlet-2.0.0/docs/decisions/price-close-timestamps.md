# Decision: EOD Price Bars Use NYSE Market Close Timestamps

**Date:** 2026-03-31
**Status:** Accepted
**Source:** Launch Readiness Execution Plan, Team G (Issue 1)

## Context

EOD price bars in the PricePlugin used midnight UTC (00:00) as their timestamp. This meant the date ceiling enforcer could not distinguish between "market is open, today's close hasn't happened yet" and "market closed, today's close is available." An agent querying at 10:00 AM simulated time could see today's close price — a future data leak.

## Decision

Set EOD bar timestamps to NYSE market close time (16:00 ET) instead of midnight UTC. The UTC equivalent varies by DST: 21:00 UTC during EST (Nov-Mar), 20:00 UTC during EDT (Mar-Nov). This uses `ZoneInfo("America/New_York")` consistent with the existing clock module.

## Consequences

- The date ceiling enforcer now correctly hides same-day close data during simulated market hours (ceiling < close timestamp)
- After market close (ceiling >= 16:00 ET), the day's close becomes visible
- Existing parquet data is unaffected — timestamps are set at read time in `_read_local_parquet()`, not stored differently
- The enforcer's existing `<` comparison works correctly with close-time timestamps without modification
