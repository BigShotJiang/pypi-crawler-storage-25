# Decision: Patch the TradingView lightweight-charts Vendor Bundle to Route SVG `innerHTML` Through `window.trustedHTML()`

**Date**: 2026-04-27
**Status**: Accepted (reversible — re-apply on bundle upgrade)
**Iteration**: bug-hunt 20260428T031818Z2efa, Team D (commit `6d7c10e`)

---

## Context

Every page load of the Finlet dashboard logged a `[Finlet] Trusted Types default policy invoked — caller should use trustedHTML(): <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 35 19"...>` warning to the browser console. The site-wide Trusted Types policy (`trusted-types finlet-default default goog#html`) is enforced via `dashboard/api-utils.js`, and the named `finlet-default` policy is the safe path for HTML writes. The default-policy warning fires whenever an `innerHTML` write bypasses the named policy.

Audit results:

- All first-party dashboard JS already routed through `trustedHTML()`.
- The bypass came from the bundled vendor blob `dashboard/vendor/lightweight-charts.standalone.production.js` (TradingView's lightweight-charts library), which writes an internal SVG via raw `innerHTML` for chart watermark / branding rendering.
- The vendor blob is minified production output — there is no upstream "Trusted Types-aware" build mode that ships from TradingView at the time of writing.

---

## Decision

Patch the vendor file directly: replace the raw `innerHTML = svgString` write with `innerHTML = window.trustedHTML(svgString)`, falling back to the raw string if `window.trustedHTML` is unavailable (defensive).

The patch is a one-character-class change inside the minified bundle. The functional behavior is unchanged — the SVG renders identically.

---

## Why this and not the alternatives

- **Suppress the warning in `api-utils.js`.** Rejected — the warning is the symptom that surfaces real bypasses. Silencing it would hide a future first-party regression behind the existing vendor noise.
- **Add a third Trusted Types policy that allows raw SVG writes.** Rejected — every additional named policy is a new surface for a future XSS bypass. The named `finlet-default` policy already handles the SVG correctly; the vendor just wasn't using it.
- **Fork the entire lightweight-charts library and rebuild from source with Trusted Types support.** Rejected — multi-week effort for what is functionally a one-line fix.
- **Leave the warning in place.** Rejected — a noisy console on every page load trains users and on-call to ignore Trusted Types warnings, which makes the next real bypass invisible.

---

## Consequences

- The default-policy warning no longer fires on the happy path (login → dashboard → settings → leaderboard → back). Future warnings indicate genuine first-party bypasses, not vendor noise.
- **The patch is fragile by design.** Any `npm` upgrade, manual re-download, or vendor bundle refresh will overwrite the patch and reintroduce the warning. The fix MUST be re-applied on every dependency bump.
- The patch site is documented inline with a reference to this decision record so a future engineer who diffs the vendor file can see why the change exists.
- Integration test: a Playwright assertion that fails the build if `[Finlet] Trusted Types default policy invoked` appears in the console during the happy-path journey would catch a re-introduction. Not yet wired — tracked as follow-up.
- If TradingView ships an upstream Trusted Types-aware build, swap to the upstream version and remove the patch.

---

## References

- Triage: `docs/bug-hunt/20260428T031818Z2efa/triage.md` (F4)
- Plan: `docs/bug-hunt/20260428T031818Z2efa/plan.md` (Team D scope)
- Implementation: commit `6d7c10e` ([Team D]: bug-hunt 20260428T031818Z2efa — route SVG injection through trustedHTML)
- Related lesson: `docs/LESSONS.md` — "Vendor JS that writes innerHTML bypasses Trusted Types policies"
- Architecture: `docs/ARCHITECTURE.md` — Trusted Types vendor coverage block
