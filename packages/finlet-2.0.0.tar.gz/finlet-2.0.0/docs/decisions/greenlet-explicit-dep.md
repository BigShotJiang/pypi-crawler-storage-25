# Greenlet as Explicit Dependency

Date: 2026-04-05

## Context
During exec-plan Session 1, Team B added mypy-boto3-s3 as a dev dep. uv re-resolved dependencies and dropped greenlet from the venv. greenlet is a transitive of SQLAlchemy async and is required by finlet/db/engine.py — its removal caused 856 test failures.

## Decision
Add `greenlet>=3.0` as an explicit dependency in pyproject.toml under the `server` optional-dependencies extras group (where sqlmodel lives, since the thin client doesn't ship DB code).

## Consequences
- Prevents resolver drift from silently dropping greenlet again
- Makes the async DB runtime requirement visible in the project manifest
- Minor: one extra declared dep to keep in sync
