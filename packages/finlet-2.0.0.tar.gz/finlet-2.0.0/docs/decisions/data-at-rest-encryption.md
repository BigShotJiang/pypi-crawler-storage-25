# Decision: Data-at-Rest Encryption

**Date**: 2026-03-25
**Status**: Resolved
**Context**: Auth database (`auth.db`) contains PII — emails, API key hashes. Audit flagged unencrypted data at rest (C8).

## Options Evaluated

### 1. EBS Volume Encryption (chosen)

Already enabled in `deploy/aws/main.tf`:

```terraform
root_block_device {
  volume_size           = 8
  volume_type           = "gp3"
  delete_on_termination = false
  encrypted             = true   # <-- AES-256 via AWS-managed key
}
```

S3 backup buckets also use KMS server-side encryption (`aws:kms` with bucket keys enabled).

**Pros**:
- Transparent to the application — no code changes required
- AWS-managed key rotation and access control
- Covers all files on the volume, not just SQLite databases
- No performance overhead measurable at our scale
- Already in place

**Cons**:
- Does not protect against a compromised OS (root access reads decrypted files)
- Encryption key is tied to the AWS account

### 2. SQLCipher (rejected)

Would replace the SQLite engine with an encrypted variant.

**Pros**:
- Database file is encrypted even if extracted from the volume
- Defense-in-depth against OS compromise

**Cons**:
- No maintained `aiosqlcipher` driver — would require wrapping `pysqlcipher3` in async executors or forking `aiosqlite`
- Key management complexity: where to store the encryption passphrase? If it's in an env var on the same machine, an attacker with root access gets both the DB and the key
- Migration required for existing databases (dump + re-import under encryption)
- Build dependency on `libsqlcipher-dev` in CI and production
- Performance overhead on every query (~5-15% for typical workloads)

## Decision

**EBS encryption is sufficient.** The threat model for a single-instance deployment does not benefit meaningfully from SQLCipher. If an attacker gains OS-level access, application-layer encryption keys stored on the same host are equally compromised. EBS encryption protects against physical media theft, snapshot exposure, and volume detachment attacks — which are the realistic vectors.

If the deployment moves to multi-tenant or the threat model changes (e.g., untrusted operators with volume access), revisit SQLCipher or migrate to a managed database with TDE.

## Verification Checklist

- [x] EBS `encrypted = true` in `deploy/aws/main.tf` (line 119)
- [x] S3 backup bucket uses KMS encryption (lines 206-215)
- [x] S3 price data bucket uses KMS encryption (lines 295-302)
- [x] No unencrypted data stores identified
