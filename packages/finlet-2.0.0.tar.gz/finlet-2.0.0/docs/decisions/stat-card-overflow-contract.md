---
decision_at: 2026-05-05
category: dashboard-state-sync
supersedes_advice_in: docs/ARCHITECTURE.md:1025 (no-hyphenation bullet — text-overflow:ellipsis recommendation, never-min-width warning)
surfaced_by: bug-hunt 20260505T175445Z750b patch-ineffective signal `sim-time-card-truncates-with-ellipsis`
related_refactor_doc: docs/bug-hunt/refactor-queue/stat-card-overflow-contract.md
shipped_in: f1b3cf7e607198229cdf9de49bb63581c636470d
---

# Decision: Stat-Card Overflow Contract

## Decision

Overview `.stat-card` and `.stat-value` adopt a hard-fitting size contract:
- `.stat-card { min-width: 184px }` at desktop
- `.stat-card { min-width: 144px }` at mobile (`@media (max-width: 1024px)`)
- `.stat-value { text-overflow: clip }` (was `ellipsis`)
- `.stat-value { font-size: 16px }` inside the mobile breakpoint (added so the audit-comment math holds for #portfolio-value at the worst-case 13-char content).
- Test-enforced: `tests/e2e/journey-sim-time-tile.spec.ts` asserts `scrollWidth <= clientWidth` AND `getComputedStyle().textOverflow === 'clip'` at 1024/1200/1440 viewport widths after a session is created and a fill lands.

## Why

Two prior patches (CSS-only iter `20260503T230405Z2601`, JS-only iter `20260505T175445Z750b`) failed to close the SIM TIME card truncation cluster. The 150px min-width × 32px padding = 118px content area was 1-2px too narrow for `2025-05-05` rendered at 20px mono bold (~120px). The previous `text-overflow: ellipsis` fallback turned a 1-2px overshoot into a deceptive `…` glyph that hid the actual value from the user. Hard-cutoff (`clip`) is louder than deceptive truncation: a regression that overshoots the test assertion fails loudly, not silently.

## Contract

Two invariants enforced by `tests/e2e/journey-sim-time-tile.spec.ts`:
1. **Every `.stat-value` element on the dashboard fits its content** at desktop viewports (1024px / 1200px / 1440px). `scrollWidth <= clientWidth`. No silent truncation.
2. **Computed `text-overflow` is always `'clip'`**. A regression to `'ellipsis'` would re-introduce the deceptive-truncation failure mode this refactor closes.

## How to add a new stat-card

1. Pick the longest realistic content string the tile will ever render. Measure (or estimate) its width at 20px mono bold (~12px/char).
2. **If it fits within ~150px (i.e., ≤12 characters):** use `.stat-value` directly. The existing `min-width: 184px` + 32px padding + ~12.6 character headroom accommodates it.
3. **If it's longer than ~12 characters:** add a per-id font-size override at 16px (e.g., `#my-tile.stat-value { font-size: 16px }`). Do NOT widen the card per-tile — that breaks the grid uniformity and makes the audit-comment math wrong.
4. Update the audit comment in `dashboard/styles.css` immediately above `.stat-value {` with the new tile's expected content and measurement.
5. Add the new tile to the Playwright stub in `tests/e2e/journey-sim-time-tile.spec.ts` (the `portfolio_metrics` fixture in the viewport-sweep test) so the contract test exercises realistic content for it.

## Validation

- New Playwright spec passes at 1024/1200/1440 viewports.
- Existing `journey-sim-time-tile.spec.ts` em-dash regression test still passes.
- Visual check on `https://finlet.dev/index.html` post-deploy: SIM TIME card shows the full date, no `…`, no glyph cutoff.

## Failure mode this closes

A user views the dashboard. The SIM TIME card silently shows `2025-05-…` with a CSS-painted ellipsis that the user assumes is the actual value. With `text-overflow: clip` and the test-enforced `scrollWidth <= clientWidth` invariant, this failure mode is impossible: any tile that overshoots fails the test at CI time, before reaching prod; if a tile DOES overshoot in prod, the user sees a hard cutoff that's a visible bug, not a silent lie.
