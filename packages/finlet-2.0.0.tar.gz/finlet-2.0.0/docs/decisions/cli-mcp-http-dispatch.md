# Decision: CLI → MCP-over-HTTP via Cloud `/mcp` Endpoint

**Date:** 2026-05-11
**Status:** Superseded by [`docs/decisions/v2-pure-mcp-migration.md`](./v2-pure-mcp-migration.md) (2026-05-22). The human-facing CLI dispatch shim this record describes has been deleted; the cloud `/mcp` mount itself remains live for direct MCP-over-HTTP and REST consumers.
**Source:** v1.0.1 hotfix exec-plan — BLOCKER #A. Triggered by the v1.0.0 launch blind-walk (`docs/launch/blind-agent-coldstart-report-v1.0.0-fullwalk.md`).

## Context

v1.0.0 shipped on 2026-05-11 with the Phase 5 CLI dispatch architecture: every `finlet <command>` that hits an MCP tool spawns a fresh `finlet mcp serve` subprocess and exchanges JSON-RPC over its stdio. The blind-walk smoke test that ran against the freshly-tagged `finlet==1.0.0` PyPI release immediately surfaced two structural failures:

* **BLOCKER #A — Cloud-issued OAuth JWT cannot be validated by the spawned subprocess.** The CLI's `finlet auth login` flow (Phase 4d) writes a JWT minted by the cloud `/oauth/token` endpoint into `~/.finlet/credentials`. The CLI then forwards that JWT to the subprocess via `FINLET_OAUTH_BEARER` (per the now-superseded `cli-mcp-stdio-auth.md`). But the subprocess boots a fresh in-process JWKS using local signing keys — it has no way to know the cloud's signing keys. Every cloud-issued JWT silently fails JWT validation in the subprocess. The CLI is dead end-to-end against prod.

* **BLOCKER #B — Legacy `--api-key fnlt_*` is also dead.** The subprocess also has an empty `auth_service._keys` cache (no remote bootstrap), so even if the user passes `--api-key`, the subprocess's `validate_key` returns `None`. The Phase 4e Bearer-only cutover had additionally retired the api_key fallthrough from `_authenticate_oauth_or_key`, so even on the cloud side the CLI's legacy `--api-key` path wouldn't have worked.

The Phase 5 stdio-dispatch architecture is unsalvageable: any locally-spawned subprocess has no reasonable way to validate credentials that were minted by a remote authority. Reading the cloud's JWKS over HTTP into the subprocess on every spawn would be fragile (network failure on every CLI invocation), would defeat the spawn-per-command isolation Phase 5 was built around, and would still leave the api_key path broken (the subprocess has no way to validate an api_key without a network round-trip).

## Decision

**Mount FastMCP's `streamable_http_app` on the existing FastAPI application at `/mcp`, wrapped with the existing `BearerContextMiddleware` from Phase 4c.** The CLI swaps its stdio dispatch for `streamablehttp_client(f"{API_URL}/mcp", headers={"Authorization": f"Bearer {token}"})`, sending the same JWT or api_key as a Bearer header.

Concretely:

* `finlet/api/app.py::create_app` mounts `BearerContextMiddleware(mcp.streamable_http_app())` at `/mcp` AFTER the OAuth router and BEFORE the dashboard StaticFiles catch-all.
* The FastAPI lifespan enters `mcp.session_manager.run()` on startup and exits it on shutdown — Starlette mount does NOT propagate sub-app lifespans, so the parent's lifespan owns the FastMCP session manager's anyio task group.
* `mcp.settings.streamable_http_path` is mutated at app-build time to `"/"` so the inner Starlette app's route lives at `/` and `app.mount("/mcp", sub_app)` resolves the canonical URL (not `/mcp/mcp`).
* `mcp.settings.transport_security` is widened beyond the SDK default (loopback-only) to include `finlet.dev` and the test-harness hostnames (`testserver`, `test`). Extra hosts can be added at deploy time via the `FINLET_MCP_ALLOWED_HOSTS` env var.
* `Starlette.Mount("/mcp", ...)` only matches `/mcp/` and `/mcp/<path>`; a bare `/mcp` Route is inserted at the top of the route table that returns a 307 redirect to `/mcp/` so the public acceptance smoke (`curl -X POST https://finlet.dev/mcp`) resolves end-to-end without the caller adding a trailing slash. 307 is method-preserving, so the POST body is forwarded.

Alongside the mount, `finlet/mcp/auth.py::_authenticate_oauth_or_key` is updated to restore the api_key fallback (see [`mcp-api-key-sunset.md`](./mcp-api-key-sunset.md) RETRACTION 2026-05-11): try OAuth JWT validation first; on JWT validation failure or missing user record, fall back to `auth_service.validate_key(bearer)`. This makes `Authorization: Bearer fnlt_<key>` work on `/mcp` identically to how it works on REST.

The CLI is rewired by Team B (separate file ownership) in `finlet/cli_mcp_client.py` to dispatch via HTTP. Local `finlet mcp serve` is preserved as a self-host entry point but is no longer the CLI's default dispatch.

## Rationale

### Why mount the existing FastMCP instance, not stand up a separate process?

* **Single auth source of truth.** The FastAPI app already validates JWTs (`require_oauth`), validates api_keys (`require_api_key`), and hosts the OAuth Authorization Server (`/oauth/*`). Mounting the MCP transport in the same process means the same JWKS validates JWTs whether they come in over REST or MCP-over-HTTP. No JWKS-fetch fragility, no duplicate signing-key plumbing.
* **Single deployment unit.** The Hetzner production deploy (`docs/AGENT_OPS_STACK.md`) runs one Finlet process. Adding a second process for MCP would add a supervisor concern, port management, and a TLS termination point. Mounting at `/mcp` keeps the deploy shape unchanged.
* **No new dependencies.** `mcp.client.streamable_http` ships with the bare `mcp` package (already in `pyproject.toml::dependencies`). The CLI does NOT need the `[server]` extras to dispatch via HTTP — that closes the v1.0.0 BLOCKER #1 follow-up (CLI install size was bloated by server-only deps).

### Why is `BearerContextMiddleware` the right wrapper?

It was purpose-built in Phase 4c (`finlet/mcp/bearer_context.py:127-163`) to wrap FastMCP's HTTP transport. It runs BEFORE FastMCP's own auth middleware in the stack and lifts the raw `Authorization: Bearer <token>` value onto a Finlet-owned ContextVar. Every `@mcp.tool()` reads the token via `resolve_credential(...)`, which routes through `_authenticate_oauth_or_key` (Bearer JWT) and then falls back to `auth_service.validate_key` (api_key) per the v1.0.1 retraction. The middleware was never wired in production before v1.0.1 — it sat in the tree as the planned wiring point for the HTTP transport that Phase 4 deliberately deferred.

### Why retract Phase 4e's Bearer-only cutover instead of fixing the cloud `/mcp` mount alone?

The two BLOCKERs are entangled. Even with the `/mcp` mount, a user holding a legacy api_key would still be blocked: the cloud's `_authenticate_oauth_or_key` was Bearer-only post-Phase-4e. Retracting Phase 4e is pre-launch-safe (zero customers per `project_pre_launch_no_customers.md`) and matches the REST surface's contract — `Authorization: Bearer fnlt_<key>` works on REST today, and now also works on `/mcp`. Self-hosters and Claude-Desktop-style configs that bake an api_key into their JSON config get a smoother experience. The Phase 4e production-contract tests in `tests/mcp/test_oauth_dual_accept.py` and `tests/integration/test_mcp_oauth_e2e.py` continue to assert the rejection envelope for the tool-argument `api_key=` path (`resolve_credential(api_key=...)` is NOT changed — only `_authenticate_oauth_or_key(bearer)` is), so the test invariants are preserved.

### Why a 307 redirect for bare `/mcp` instead of mounting differently?

Starlette's `Mount("/mcp", app)` only matches `/mcp/` and `/mcp/<path>`. The bare `/mcp` URL would otherwise fall through to the dashboard StaticFiles catch-all at `/`. Three alternatives were considered:

1. **Mount under empty prefix `""`.** Doesn't work cleanly — Starlette's Mount asserts the path starts with `/`.
2. **Set FastMCP path to `/mcp` and mount at `""`.** Same problem; also requires reconfiguring the SDK's expected URL shape.
3. **Add a `Route("/mcp", ...)` redirect.** Clean, method-preserving, decouples the SDK's URL from our public URL. Selected.

The 307 redirect is method-preserving (RFC 7231 §6.4.7), so `curl -X POST /mcp -d @body.json` follows to `POST /mcp/` with the body intact. The MCP SDK's `streamablehttp_client` does the same. Public acceptance smoke (`curl -X POST https://finlet.dev/mcp -H "Authorization: Bearer fnlt_..."`) resolves end-to-end with no caller-side change.

### Consequences for self-host integrators

**None.** Local `finlet mcp serve` is preserved as a Typer subcommand and still spawns a stdio MCP server. Self-hosters who run their own Finlet instance can wire MCP-compatible clients (Claude Desktop, etc.) against either the stdio entry point OR their own deployment's `/mcp` HTTP endpoint. The `[server]` install extras stay scoped to self-host concerns (`uvicorn[standard]`, etc.); the CLI no longer needs them.

## Alternatives Considered

1. **Fetch the cloud's JWKS into the spawned subprocess on each spawn.** Rejected. Adds a mandatory network round-trip on every CLI invocation, fragile under flaky networks, doesn't fix the api_key path, defeats the Phase 5 spawn-per-command isolation goal.
2. **Run a persistent local daemon.** Rejected. Adds process supervision, IPC, and stale-state invalidation complexity. Each is its own decision; bundling them with the v1.0.1 hotfix inflates blast radius.
3. **Wire the CLI directly to REST (skip MCP).** Rejected. The agent-CRUD REST aliases are Phase 3-deprecated (`docs/decisions/mcp-canonical-surface.md`) — Sunset `2026-08-06`. Skipping MCP would re-tangle the migration. The MCP-over-HTTP path keeps MCP as the canonical agent surface and is a strict extension of the existing FastAPI app.
4. **Defer to v1.1 and ship v1.0.0 broken.** Rejected. v1.0.0 is unusable end-to-end against prod. A hotfix is the right vehicle.

## References

* `docs/launch/blind-agent-coldstart-report-v1.0.0-fullwalk.md` — the blind-walk report that surfaced both BLOCKERs.
* `docs/decisions/cli-mcp-stdio-auth.md` — the now-superseded Phase 5 stdio-dispatch architecture.
* `docs/decisions/mcp-api-key-sunset.md` RETRACTION 2026-05-11 — the matching api_key fallback retraction.
* `docs/decisions/mcp-oauth-2-1-auth-model.md` — Phase 4a five OAuth decisions, including the same-`UserRecord` binding the dual-accept depends on.
* `finlet/mcp/bearer_context.py:127-163` — `BearerContextMiddleware` (purpose-built in Phase 4c for the eventual HTTP wiring).
* RFC 7231 §6.4.7 — 307 Temporary Redirect (method-preserving).
* RFC 6750 §2.1 — `Authorization: Bearer <token>` syntax (governs both the OAuth and the api_key fallback path).
