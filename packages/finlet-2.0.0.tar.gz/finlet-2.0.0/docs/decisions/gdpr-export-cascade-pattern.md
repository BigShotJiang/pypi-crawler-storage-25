# Decision: GDPR Article 20 — Async cascade-walker export pattern

**Date:** 2026-05-14
**Status:** SHIPPED
**Source:** GDPR Export (Item F) requirements and 5-team execution plan. Replaces the legacy shallow stub at `POST /v1/settings/export-data`. This decision establishes the reference pattern that **Item G — account deletion (GDPR Article 17)** will reuse.

## Context

GDPR Article 20 grants every user the right to a portable copy of "the personal data concerning him or her, which he or she has provided to a controller, in a structured, commonly used and machine-readable format." The right is not satisfied by a partial dump — every user-scoped row in every database that Finlet owns must be enumerable. Article 20 is also a load-bearing **paid-GA gate**: shipping payment processing without it puts the business in violation in every EU jurisdiction.

At baseline (commit `ebdcd9d`, before Item F), Finlet exposed `POST /v1/settings/export-data` which returned a synchronous JSON dict dumping (a) the requester's `UserRecord`, (b) the in-memory `_user_settings` dict (lost on restart), (c) only the live in-memory sessions (not the persisted SQLite session DBs on disk), and (d) named API keys' metadata. The endpoint accepted any api_key, returned a non-deterministic snapshot, missed at least 12 user-scoped tables across auth.db / leaderboard.db / global.db / marketplace.db / per-session DBs, and silently scaled O(in-process sessions) instead of O(actual user data). The shallow stub never satisfied Article 20 — Item F's status in `REMAINING_TASKS.md` was the explicit "P0 before paid GA" flag.

Several shapes were available — Stripe-style customer-portal proxy, a synchronous per-table JSON dump, a Postgres `pg_dump`-equivalent. Each had a structural problem in Finlet's setting (multi-database SQLite layout, per-session DBs on disk, no Postgres to dump, agents driving the surface rather than humans). Decision was to design the surface around the load-bearing invariants — cross-user isolation, redaction discipline, completeness across every user-scoped table — and let the implementation shape fall out of those.

## Decision

A new async export pipeline at `finlet/gdpr/` plus an OAuth-Bearer-only endpoint pair at `/v1/account/export[/{job_id}]`. The legacy `/settings/export-data` stub + its `export_data()` service + the `ExportDataResponse | ExportUserInfo | ExportSessionInfo | ExportApiKeyInfo | ExportDataRequest` schemas are deleted in the same merge — no soft-deprecation period (the stub was undocumented, api_key-only, and never produced a GDPR-compliant dump, so the blast radius of "callers cached the URL" is zero).

### Five load-bearing pieces

1. **Audit table — `gdpr_export_requests` (migration `016_add_gdpr_export_requests`).** Domain-specific status table (matches the existing convention from `marketplace.AdminReview`). Columns: `{id, user_id, requested_at, completed_at, status, archive_size_bytes, archive_object_key, expires_at, ip_address, error_detail}`. State machine: `pending → running → success | failed`. The API layer creates the `pending` row BEFORE spawning the background task so a polling GET cannot race the audit write.
2. **Cascade walker registry — `finlet/gdpr/walkers/ALL_WALKERS`.** Explicit list (not auto-registration — matches the `_AUTH_TABLES` style of explicit registration). Each entry is `async def walk_*(user_id: str) -> list[WalkerResult]`, where `WalkerResult = {table_name, rows, schema_hash, redacted_columns}`. Scalar walkers return a single-element list; the per-session cascade walker returns `5 × N_sessions` entries. The flat-list output makes the runner's fan-out a uniform `for w in ALL_WALKERS: results.extend(await w(user_id))`. The registry covers 13+ auth-DB tables, 6 leaderboard/global tables, 5 marketplace tables (feature-flagged), the `subscriptions` billing table, and the per-session DB cascade across 5 tables for each session the user owns.
3. **Allowlist-only redaction with default-deny regex.** Each walker carries an explicit `_KEEP_*` set listing the columns it emits — columns not in the set are dropped, full stop. On top of the allowlist, `finlet/gdpr/walkers/_common.py:_DENY_RE` (`secret|hash|password|private_key|key_material|token$`) is asserted against every KEEP set at module import time via `_assert_keep_safe()`. A future schema change that introduces a `*_secret` column AND forgets to update the KEEP allowlist surfaces as an immediate `ValueError` at import time — before any production export runs.
4. **Archive — ZIP with one JSONL per table + `manifest.json` at root.** `finlet/gdpr/archive.py:build_archive()` is a pure function: stream-writes each table's JSONL to a temp file (one JSON object per line, `sort_keys=True` for diff-friendly outputs), then bundles into a ZIP with `ZIP_DEFLATED`. Manifest carries `{schema_version, generated_at, user_id, tables[{name, row_count, schema_hash, redacted_columns}]}`. The build is sync inside an `await asyncio.to_thread()` — CPU-bound ZIP construction doesn't belong on the event loop.
5. **Async job runner + S3 upload + presigned URL.** `finlet/gdpr/job_runner.py:run_gdpr_export_job(job_id, user_id)` drives one user through `pending → running → success | failed`. `finlet/gdpr/storage.py:GdprS3Storage` uploads to `gdpr-exports/{user_id}/{job_id}.zip` in the `FINLET_EXPORTS_BUCKET` bucket (separate from the parquet lake — own 24h lifecycle policy). The 24h presigned-URL TTL matches the bucket lifecycle so the URL cannot outlive its object. The URL itself is NEVER persisted — every successful poll re-mints a fresh URL, so a leaked URL in transit can't outlive the polling session.

### API surface (OAuth Bearer only)

* `POST /v1/account/export` → `202 Accepted` + `ExportJobResponse(job_id, status="pending")`. Idempotent: duplicate POST while a `pending` or `running` job exists for the same user returns the SAME `job_id` (NOT 429). Background task spawned via `asyncio.create_task(run_gdpr_export_job(job_id, user.id))` — fire-and-forget; the HTTP response does NOT block on completion. IP captured from `request.client.host` (with `X-Forwarded-For` fallback) onto the audit row.
* `GET /v1/account/export/{job_id}` → reflects the audit row's current state. Hot path: in-memory `_export_jobs` dict. Cold path (after process restart): `load_job_from_db()`. On `success` returns a freshly-minted 24h presigned URL + archive size + expiry timestamp. On `failed` returns the sanitized error summary. 404 for both missing AND foreign-owned jobs — identical response for "doesn't exist" vs "exists but not yours" prevents enumerating valid job IDs.

The OAuth injector at `finlet/auth/deps.py:require_oauth` returns a TUPLE `(UserRecord, OAuthClaims)`. Endpoint handlers MUST unpack via `user, _claims = auth` — writing `user: UserRecord = Depends(require_oauth)` TypeErrors at request time. (Documented gotcha — caught Team D pre-merge.)

### Cross-user isolation gate

`tests/gdpr/test_export_property.py` is the load-bearing test per the requirements doc. Hypothesis (`@given(num_tables=…, rows_per_table=…)`, `@settings(max_examples=50, deadline=None)`, pinned `--hypothesis-seed=12345`) seeds two synthetic users with deterministic markers across every user-scoped surface, drives the full export pipeline for `user_A` with a mocked S3 client, and asserts (a) every `user_A` marker appears in the archive, (b) zero `user_B` markers appear, and (c) the audit row reached `success`. The same property test exercises the entire `ALL_WALKERS` registry — any future walker that forgets to filter by `user_id` produces a Hypothesis-shrunk minimal-case failure on the next test run.

## Rationale

### Why async + audit table instead of a synchronous JSON dump?

The walker fan-out touches 4 databases (auth, leaderboard, global, marketplace) plus N per-session DBs on disk — each one a separate aiosqlite connection. A user with 50 sessions could push the export wall-clock past any reasonable HTTP timeout. The async job model lets the runner finish in the background while the user polls; the audit row is the durable handle that survives process restarts.

The audit table also serves the user's own GDPR posture — Article 20 implies the user is entitled to know that they made an export request, what they asked for, and when. The audit row IS that record. We walk it as part of the next export via `walk_gdpr_export_requests` (the user's own history is their data), with `error_detail` redacted because it can carry server-side trace info.

### Why allowlist-only redaction instead of "list-then-strip"?

A "list every column, then strip the sensitive ones" pattern (which is how the legacy shallow stub worked) is structurally fragile. Six months later, a schema migration adds `mfa_recovery_token_hash` to a model, no one remembers to update the strip list, and the next export ships every user's recovery token to themselves over a presigned URL. Allowlist-only fails closed — a new column is invisible to exports until somebody explicitly adds it to the KEEP set.

The default-deny regex is defense-in-depth on top. If a future agent's hand IS forced to add a column whose name matches the regex (because it really is the user's own data — e.g. `phone_hash_or_prefix`), the import-time `_assert_keep_safe()` call demands an explicit `exceptions` parameter. The deny posture is "opt out, not opt in" — same risk profile as the file-walking exclude lists in security tooling.

### Why a separate `finlet/gdpr/` package instead of folding into `finlet/api/services/`?

Three reasons. (1) The walker surface spans every database in the codebase — putting it under `finlet/api/services/` would force the api team to own the leaderboard + marketplace + per-session DBs, which they don't. (2) Item G (account deletion) will need the exact same cascade — the package boundary makes the contract reusable. (3) GDPR-specific code (audit table, sanitization rules, redaction regex) accumulates over time; a dedicated package keeps that growth scoped.

The api team still owns the HTTP surface (`finlet/api/routes_account.py`, `finlet/api/rate_limit/export.py`, `finlet/api/schemas/account.py`). The `finlet/gdpr/` package is consumed by those routes but never imports them.

### Why ZIP+JSONL instead of a single JSON blob, a tarball, or per-table CSVs?

* **JSONL beats CSV** because the cascade walker outputs include nested fields (`config_json`, `methods_json`, `redirect_uris` are all JSON-encoded strings on the SQLModel rows). Re-quoting them through a CSV escaper would mangle the round-trip; JSONL keeps them as opaque blobs.
* **One file per table beats a single blob** because users may want to import only specific tables into their own tooling. Per-table JSONL is greppable, line-by-line streamable, and a single `cat *.jsonl | jq -c '...'` can normalize the whole archive.
* **ZIP beats tar.gz** for ecosystem compatibility — every desktop OS opens a ZIP without installing anything. The compression delta vs gzip on JSONL text is in the noise (both are deflate-based).

### Why OAuth Bearer only, not api_key?

`docs/decisions/mcp-oauth-2-1-auth-model.md` and the Phase 4e Bearer-only cutover (2026-05-09) established that scope-bound, audience-bound JWT credentials are the privacy-sensitive entry shape on this codebase. GDPR Article 20 is the canonical "privacy-sensitive" operation — there is no business reason to issue a static api_key with implicit `gdpr:export` scope. By gating the endpoint behind `require_oauth`, future scope-narrowing work (e.g. requiring a dedicated `gdpr:export` scope in v1.1) lands without an api-key bypass path.

### Why presigned S3 URL with 24h TTL instead of streaming the ZIP through the API?

* The API process is FastAPI on a single uvicorn worker. Streaming a multi-MB ZIP would tie up that worker for the download duration — a single export blocks every other user's API traffic until the user closes the TCP connection.
* The 24h TTL matches the S3 bucket's object-lifecycle policy. The user gets a real download URL; if they close the laptop and reopen tomorrow, the URL is dead anyway — the bucket has reaped the object — so a fresh poll regenerates a fresh URL pointing to a fresh upload. (Re-export is cheap.)
* Presigned URLs leak via Referer headers if the user opens them in a browser tab. That's a documented v1 limitation. v2 mitigation would add password-bound `Content-Disposition: attachment` URLs or a server-side single-redeem token. Out of scope for v1.

### Why idempotent POST instead of 429-on-duplicate?

Mobile / flaky-connection scenarios produce duplicate POSTs — the user clicks "Export My Data," the response is slow, they click again. Returning 429 here is hostile (and easily worked around by waiting a minute, so 429 doesn't actually slow down abuse). Returning the SAME `job_id` matches the user's intent: "make sure my export is running." Concurrent walker fan-out for the same user is prevented by the `get_active_export_for_user` short-circuit in `finlet/api/rate_limit/export.py:get_or_create_export_job`.

## Consequences

### Reusable by Item G (account deletion)

The cascade-walker pattern carries forward directly. G will add `async def delete_for(user_id: str) -> int` to each `walk_*` module (returning rowcount), a sibling `gdpr_deletion_requests` audit table (mirror of `gdpr_export_requests`), and the same job-runner shape. Open question for G: "pre-delete export, or independent flow?" — see the carry-forward section in `GDPR_EXPORT_F_EXECUTION_PLAN.md`.

### Walker registry IS the completeness contract

`tests/gdpr/test_walker_registry.py` greps `finlet/db/` and `finlet/marketplace/models.py` for `user_id` columns and asserts every match has a corresponding walker in `ALL_WALKERS`. A future migration that adds a new user-scoped table fails this gate at PR time — the "did we miss anything" question is structurally enforced, not vibes-based.

### Redaction discipline carries

Walkers that touch credential material (key hashes, OAuth refresh tokens, TOTP secrets) MUST be allowlist-only. The default-deny regex catches the most common forgetfulness mode at import. The walker unit tests (`tests/gdpr/test_walkers.py`) additionally seed each redacted column and assert the value never appears in the walker's emitted row dicts.

### Cross-user property test is the production gate

Cross-user isolation is a single-line correctness invariant: "user_A's export contains user_A's data and only user_A's data, across every table the cascade touches." The Hypothesis property test runs 50 random `(num_tables, rows_per_table)` examples per run with a pinned seed. Any future walker that forgets to filter by `user_id` produces a deterministic shrunk-case failure pointing at the leaking table — far better than discovering the leak in production via a privacy complaint.

### Old stub callers see 404

The old `/v1/settings/export-data` is gone. The endpoint returns 404 from FastAPI's default router-miss handler — no soft-deprecation period, no `Deprecation` header, no `Sunset` date. Justification: the stub was undocumented (no `docs/ARCHITECTURE.md` keep-list entry), api_key-only (no OAuth surface), and produced non-GDPR-compliant JSON. Total external blast radius: zero. (Internal callers were the dashboard's now-cut settings.html "Export My Data" button — already removed by the 2026-05-06 launch cut.)

### Operational footprint

* New AWS bucket `finlet-exports` with 24h object-lifecycle policy. If bucket creation requires AWS console action on first deploy, the fallback is a prefix on `finlet-data` (env-controlled via `FINLET_EXPORTS_BUCKET`) — surface in PR description so ops creates the proper IaC bucket post-merge.
* New SSM/env variable: `FINLET_EXPORTS_BUCKET` (default `finlet-exports`).
* New structured log fields: `gdpr.export.job.start`, `gdpr.export.walkers.start`, `gdpr.export.archive.built`, `gdpr.export.s3.upload.done`, `gdpr.export.job.success | gdpr.export.job.failed`. All carry `job_id + user_id` bind tags so a single export's full lifecycle is `grep job_id=…` on the structured log.

### Test surface

* `tests/gdpr/test_walkers.py` — per-walker unit tests (one seed + assert redacted-column-absent + assert other-user-rows-not-returned per walker).
* `tests/gdpr/test_walker_registry.py` — schema-coverage gate (greps for `user_id` columns, asserts every one is covered).
* `tests/gdpr/test_archive.py` — ZIP structure + manifest shape + JSONL row fidelity.
* `tests/gdpr/test_storage.py` — boto3 mock — bucket + key + presigned URL TTL.
* `tests/gdpr/test_export_property.py` — Hypothesis cross-user isolation gate (this is THE load-bearing test).
* `tests/api/test_account_export.py` — endpoint smoke (POST 202 + idempotent re-POST + api_key→401 + GET 404 for foreign user + GET reflects pending→running→success).
* `tests/db/test_gdpr_export_requests_migration.py` — migration runs clean + round-trip insert.

## Excluded tables (intentional)

Four tables in the schema are intentionally NOT walked. The schema-coverage gate (`tests/gdpr/test_walker_registry.py::_INTENTIONALLY_EXCLUDED`) hard-codes this list — every entry must reference a table that ACTUALLY EXISTS (a stale exclusion fails the gate) and carries a one-line rationale. Future schema migrations that add a new user-scoped table cannot silently bypass the cascade; they must either add a walker or extend the exclusion dict with an explicit reason.

* **`idempotency_keys`** (`finlet/api/idempotency.py:IdempotencyKeyModel`) — request-level deduplication cache keyed by `(request key, session_id)`. No `user_id` column at the schema level; entries are transient (24h TTL) request-replay records, not personal data. Excluding it avoids leaking ephemeral request bodies that other walkers already cover at the source (the session's `idempotency_key` field IS exported on `OrderModel` etc.).
* **`rate_limit_entries`** (`finlet/db/auth_models.py:RateLimitEntry`) — persisted rate-limit state keyed by composite strings of the form `"reg:<ip>"` or `"sub:<user_id>"`. The key is a composite string, not a plain `user_id` foreign key — including it would require parsing the string and per the plan spec the explicit redaction set excludes it. The data is operational telemetry (per-key counters + expiry timestamps), not data the user "provided" under Article 20.
* **`oauth_keys`** (`finlet/auth/oauth/storage.py:OAuthKeyModel`) — global JWKS rotation set for the Authorization Server signing keys. NO `user_id` column — it's a single global registry shared across all users. Including it would leak global infrastructure secrets and the user has no Article 20 interest in the Issuer's private signing material. Rationale duplicated in `finlet/gdpr/walkers/auth.py:537` for in-code discoverability.
* **`dmca_designated_agents`** (`finlet/marketplace/models.py:DMCADesignatedAgent`) — global service-provider DMCA designated-agent registration (Finlet's own copyright.gov filing). NO `user_id` column — it's a Finlet-the-platform record, not a user-of-Finlet record. Including it would leak unrelated admin data. Rationale duplicated in `finlet/gdpr/walkers/marketplace.py:9` for in-code discoverability.

Item G (account deletion) inherits this exclusion list verbatim — the same four tables MUST NOT receive a `delete_for(user_id)` walker entry (deleting an `idempotency_keys` row by user_id would have to scan-and-parse the key column, and there's no per-user retention obligation; deleting `rate_limit_entries` rows by parsed key prefix would defeat the rate-limit's purpose; the two global tables have no user_id to filter on).

## Alternatives Considered

1. **In-memory synchronous JSON dump (the legacy stub).** Rejected — was already the baseline state and didn't satisfy Article 20. Misses 12+ user-scoped tables, loses data on restart, hangs the API worker on multi-session users.
2. **Stripe-customer-portal proxy for billing data + separate dump for everything else.** Rejected — fractures the user experience (two separate downloads for one Article 20 request). The Stripe customer-portal lets users see their data on Stripe's site but doesn't satisfy the "structured, commonly used, machine-readable format" requirement. The cascade walker treats Stripe IDs as the user's own data and dumps them alongside the rest.
3. **Per-user-passphrase ZIP encryption.** Considered. Rejected for v1 — adds a key-management surface the codebase doesn't have today (where does the passphrase come from? out-of-band email? user-prompt during request?). 24h presigned URL + private S3 bucket are sufficient for v1 launch. v1.1 candidate.
4. **Postgres-style `pg_dump` per user.** Not applicable — Finlet runs SQLite across multiple files. The cascade-walker pattern IS the SQLite-equivalent.
5. **Single JSON blob instead of ZIP+JSONL.** Considered. Rejected — agent-readable + human-greppable; nested per-table structure is easier with one file per table. ZIP+JSONL is also the convention used by every other GDPR Article 20 implementation we surveyed (GitHub, Stripe, Slack).
6. **Sync HTTP streaming response (chunked-encoding ZIP).** Considered. Rejected — ties up a uvicorn worker for the full download window; trivially DoSable by closing the client TCP connection mid-stream. Async job + presigned-URL hand-off scales O(workers) instead of O(active downloads).
7. **`gdpr_export_requests` in a separate database.** Considered. Rejected — same auth.db as other user-scoped audit tables (matches the established pattern that `AdminReview` etc. live in their own domain DB). Separating would force cross-DB joins to enumerate a user's own export history.
8. **MCP tool for `create_export` + `get_export_status`.** Out of scope for F. The MCP surface is the canonical agent surface; v1.1 candidate is adding `create_data_export` + `get_data_export_status` MCP tools backed by the same `/v1/account/export[/{job_id}]` service helpers. Tracked separately.
9. **24h presigned URL with refresh on poll.** This IS what shipped — the audit row stores the S3 key + expiry, and every `GET` re-mints a fresh URL from the key. Captured for the record because an earlier draft persisted the URL itself; the eventual decision was to NEVER persist URLs (so a leaked DB cannot leak download URLs to past exports).
10. **Soft-deprecation period for the old `/settings/export-data` stub.** Considered. Rejected — the stub was undocumented (no `docs/ARCHITECTURE.md` mention), api_key-only, and the only consumer (legacy dashboard's "Export My Data" button) was removed by the 2026-05-06 launch cut. There is no external surface to deprecate softly.

## Open Questions

1. **Notification on completion.** v1 ships polling-only. A future "your export is ready" email (or in-dashboard push) would let users walk away from the polling loop. v1.1 candidate; the audit row already carries `completed_at` so the wiring is straightforward.
2. **Per-IP rate limit on `POST /v1/account/export`.** v1 relies on the OAuth surface's per-user rate limits (already in place at `finlet/api/rate_limit/`). If abuse surfaces (an attacker with a stolen OAuth token spamming exports to enumerate the bucket), per-IP middleware can be added to the `/v1/account/*` prefix only. No abuse vector identified pre-launch.
3. **Archive content tampering detection.** The runner returns `archive_sha256` to its caller but does NOT yet persist it on the audit row. If we add a `archive_sha256` column, the user could compare the SHA in the manifest's `archive_sha256` field against an out-of-band attestation — useful for downstream legal-discovery use cases. Out of scope for v1; flagged for the G implementation when the schema migration boundary opens up again.
4. **Pre-deletion export (Item G overlap).** When the account-deletion endpoint ships, should the deletion flow auto-trigger an export first? Defer to G's brainstorm. The pattern carry-forward in `GDPR_EXPORT_F_EXECUTION_PLAN.md` flags this explicitly.
5. **Stripe customer deletion.** Article 17 (G's scope) requires anonymizing or deleting the Stripe customer alongside the local subscription row. F deliberately does NOT touch Stripe (we only EXPORT the customer_id, treating it as the user's own data). G will need a separate Stripe-side call (`stripe.Customer.delete()` or anonymize). Flagged for G.
6. **Large archives (>100MB).** v1 uses a single `put_object` call; a user with thousands of sessions could push past the boto3 `put_object` size limits. The runner is structured to swap in multipart upload at the `GdprS3Storage.upload_archive` boundary without changing the caller's surface — change is local. Pre-launch scale (zero customers) makes this a v1.1 problem.

## Implementation

Five sequential team merges against `origin/main`:

* **Team A** — migration `016_add_gdpr_export_requests` + `GdprExportRequest` SQLModel + `finlet/gdpr/__init__.py` skeleton + `finlet/gdpr/types.py` (shared `WalkerResult` + `ExportJobStatus` + `ExportJobRecord`).
* **Team B** — `finlet/gdpr/walkers/{auth,leaderboard,marketplace,billing,sessions}.py` + `_common.py` redaction primitives + `ALL_WALKERS` registry. Walker unit tests + registry coverage gate.
* **Team C** — `finlet/gdpr/archive.py:build_archive` + `finlet/gdpr/storage.py:GdprS3Storage` (boto3 lazy-init, parallel to but separate from `finlet/ingestion/s3_writer.py`).
* **Team D** — `finlet/api/routes_account.py` + `finlet/api/rate_limit/export.py` + `finlet/api/schemas/account.py` + `finlet/gdpr/state.py` (in-memory dict + audit-row dual-write helpers) + `finlet/gdpr/job_runner.py`. Endpoint smoke tests.
* **Team E** (this commit) — `tests/gdpr/test_export_property.py` Hypothesis property test + removal of the legacy `/settings/export-data` endpoint + `export_data()` service + `Export*` schemas + this decision record + `docs/ARCHITECTURE.md` GDPR subsection + `docs/REMAINING_TASKS.md` Item F marked SHIPPED.

## Cross-references

* `docs/decisions/gdpr-deletion-pattern.md` — Item G's decision record. Extends this pattern with Article 17 cascade deleters, salted-hash audit identifiers, Stripe-fail-loud cancellation, and the 24h grace executor. Shipped 2026-05-14.
* `docs/decisions/mcp-oauth-2-1-auth-model.md` — establishes the OAuth-Bearer-only convention this surface inherits.
* `docs/decisions/partition-completeness-invariant.md` — analogous "registry IS the contract" pattern from the parquet ingestion side.
* `finlet/gdpr/walkers/__init__.py` — `ALL_WALKERS` registry (the load-bearing list).
* `finlet/gdpr/walkers/_common.py` — `_DENY_RE` default-deny regex + `_assert_keep_safe()` import-time gate.
* `finlet/api/routes_account.py` — the OAuth-Bearer-only endpoint pair.
* `tests/gdpr/test_export_property.py` — the cross-user isolation gate (this decision's load-bearing test).
* `tests/gdpr/test_walker_registry.py` — the schema-coverage gate.

## Item G carry-forward (account deletion / GDPR Article 17)

G's plan should:

1. Mirror Team A's audit-row pattern: new `gdpr_deletion_requests` table in auth.db (migration `017_*`). Same status state machine (`pending → running → success | failed`), same audit-row writes from API + runner.
2. Reuse Team B's `ALL_WALKERS` cascade contract: add `async def delete_for(user_id: str) -> int` to each `walk_*` module (rowcount return); registry order doesn't need to match the export order (FK cascade may force a different sequence).
3. Reuse Team D's job-runner pattern. The pipeline is "for w in ALL_WALKERS: total += await w.delete_for(user_id); audit-row complete." Add Stripe-side `stripe.Subscription.cancel()` + `stripe.Customer.delete()` (or anonymize) BEFORE the local subscription-row deletion so a failed Stripe call rolls back cleanly.
4. Decision needed in G's brainstorm: "pre-delete export, or independent flow?" — if pre-delete export is mandatory, the F runner becomes a dependency of the G runner.
5. Decision needed in G's brainstorm: "soft-delete + 30-day grace period, or hard-delete?" — Article 17 doesn't require grace, but customer support workflow may. Flag in the G requirements doc.
