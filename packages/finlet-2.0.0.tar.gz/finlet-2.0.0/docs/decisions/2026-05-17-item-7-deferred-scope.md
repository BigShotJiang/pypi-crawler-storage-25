# Item 7 (Pydantic response_model schema-lock) — partial shipment, deferred scope

**Date:** 2026-05-17
**Decided by:** autonomous session under explicit user authorization (launch day)
**Shipped:** PR #95 (`ee9a53b`)

## Status

`routes_public_session.py` — 5 routes wired with `response_model=`, OpenAPI schema now locked for the launch-headline `/v1/public/sessions/{id}/*` surface. Verified live against prod `/openapi.json` post-deploy: `$ref` to `PublicSessionResponse` / `PortfolioResponse` / `PortfolioHistoryResponse` / `list[OrderResponse]` / `TraceResponse` for the five endpoints.

## Why the scope shrank from handoff Option B → "Option C+"

The original handoff listed 18-20 functions across 6 files for Option B. Pre-flight recon against HEAD `cd22aa4` showed **37 route functions** total, with a sharp ROI gradient:

| File | `response_model=` declared? | Pydantic model in `schemas/`? | Real schema-lock work? |
|---|---|---|---|
| `routes_public_session.py` (5 routes) | ❌ none | ✅ all 5 models existed (`PublicSessionResponse` at `schemas/session.py:100` + reusable `Portfolio/History/Trace/Order` models from earlier ships) | **Yes — wire decorators** |
| `routes_clock.py` (6 routes) | ✅ all declared (`ClockResponse`, `StepClockResponse`) | ✅ | Cosmetic only |
| `routes_trade.py` (4 routes) | ✅ all declared (`OrderResponse`) | ✅ | Cosmetic only |
| `routes_portfolio.py` (3 routes) | ✅ all declared (`Portfolio/History/Trace`) | ✅ | Cosmetic only |
| `routes_auth_mfa.py` (12 routes) | ❌ none | ❌ none (request models only in `schemas/auth_mfa.py`) | Yes — but 12 funcs, 7 distinct shapes, needs new module |
| `routes_market.py` session-scoped (5 routes) | ❌ none | n/a (returns `JSONResponse` + `X-RateLimit-*` headers via `_route_query_with_rate_limit`) | Complicated — JSONResponse refactor |
| `routes_market.py` public (1 route) | ✅ `TickerListResponse` | ✅ | Done |

The handoff's "Option B = 2-3h" implied uniform work across all 6 route files. Recon showed **only `routes_public_session.py` has a real OpenAPI-schema gap on the launch-headline surface**. `clock/trade/portfolio` are cosmetic (wire shape already locked through declared `response_model`); `auth_mfa/market session-scoped` would require new schema modules + JSONResponse handling — bigger than the handoff suggested.

Decision: **ship the launch-headline gap (`routes_public_session.py` only)** today; defer the rest post-launch with this record.

## Deferred — explicit follow-up scope (post-launch)

1. **`routes_auth_mfa.py` — 12 routes, 7 distinct response shapes, no models in `schemas/auth_mfa.py`.** Needs a new module (`schemas/auth_mfa_responses.py` or extension of existing) defining at minimum: `MessageResponse({"message": str})`, `TokenResponse({"session_token": str, "mfa_required": bool})`, `MFAStatusResponse({"totp_enabled": bool, "sms_enabled": bool, "phone_number": str | None})`, `TOTPSetupResponse({"secret": str, "qr_code_url": str})`, `StatusResponse({"status": str})`, `NewKeyResponse({"new_key": str})`. Plus: `validate_mfa_route` returns `JSONResponse` with HTTP-only cookie side-effect — needs a body-only model + manual `JSONResponse(content=Model(...).model_dump())` pattern (or a custom response class that allows cookie attachment).

2. **`routes_market.py` session-scoped (5 routes).** All return `JSONResponse` via `_route_query_with_rate_limit(result, user, "finnhub")` which wraps the plugin result with `X-RateLimit-*` headers. The headers are essential — they're how agents discover their remaining plugin rate budget. Options:
   - (a) Define response body Pydantic models (one per route per plugin), keep `JSONResponse` wrapping, return `JSONResponse(content=Model(...).model_dump(), headers=...)`.
   - (b) Custom FastAPI response class that combines `response_model` + injected headers.
   - (c) Move rate-limit hint into the body as `_rate_info: {...}` and drop the headers (breaking change — risky).
   Recommendation: (a) — minimal blast radius. Add models in `schemas/market_responses.py`.

3. **`routes_clock.py` + `routes_trade.py` + `routes_portfolio.py` — return-type annotation tightening (13 routes).** Currently `-> dict[str, Any]` with proper `response_model=ModelClass`. FastAPI uses `response_model` for OpenAPI schema + egress validation, so **wire shape is already locked**. Tightening the function-level return annotation to the model class is IDE-/mypy-friendly but does not change OpenAPI or the live API. Cosmetic. May land alongside item (1) or (2) for blast-radius batching.

## What stays out of scope (decision-record markers — DO NOT modify without separate record)

- **`finlet/api/serializers.py` helpers** (`portfolio_data`, `history_data`, `trace_data`) — return `dict[str, Any]`. They feed both REST (this PR) and SSE-stream responses (implied). Tightening their return type would cascade through SSE consumers. Leave as `dict[str, Any]`; let FastAPI validate at the route layer.
- **`finlet/api/services/session_service.py:public_session_response`** — explicit-key-allowlist dict builder. Stays as dict; `PublicSessionResponse.model_validate(dict)` happens at the egress boundary.
- **`finlet/errors.py` `to_mcp_dict` / `to_mcp_shallow`** — load-bearing error envelope. Out of Item 7 scope per the launch handoff. Touching cascades through every error path in every route + MCP tool.
- **`model_config = ConfigDict(extra='forbid')` on any response model** — would break on unexpected service dict keys. Pydantic v2 default `extra='ignore'` matches current FastAPI behavior (silent extra-key drop). Don't switch to `forbid` without an explicit decision record + E2E test sweep.

## Implementation notes (for the record)

- Branch: `refactor/item-7-public-session-pydantic-responses` (deleted post-merge).
- Files touched: `finlet/api/routes_public_session.py` (+11/-5), `tests/api/test_public_session.py` (+20/-1).
- All 5 endpoint tests gained a `Model.model_validate(payload)` round-trip assertion — fails fast if the service-dict shape drifts from the model.
- Pre-push pytest gate: 4852 passed, 1 skipped, 6 xpassed in 14m39s. CI on PR #95: lint (53s) + test (3.12) (23m13s) both green. Test (3.13) + security checks ran on deploy.yml after merge — all clean.
- **Deploy.yml first attempt FAILED** on a GitHub Actions billing trip: "recent account payments have failed or your spending limit needs to be increased." Code on main was clean (`ee9a53b`); deploy job couldn't start. User increased spending limit; `gh run rerun 25999033087 --failed` succeeded in 57s with the new defense-in-depth gates (MainPID flip 708203→710930, `/v1/health.git_sha=ee9a53b` confirmed at deploy time per PR #89/#90).
- **OpenAPI verification quirk:** the URL path `/v1/openapi.json` returns a stale Caddy-cached 404 (or possibly an old route that no longer exists); the canonical FastAPI OpenAPI is at `/openapi.json` (no `/v1` prefix). Verification must hit `https://finlet.dev/openapi.json`. See [[feedback-openapi-canonical-path]] memory entry.

## Acceptance evidence

```json
// curl https://finlet.dev/openapi.json | jq '.paths."/v1/public/sessions/{session_id}".get.responses."200".content."application/json".schema'
{ "$ref": "#/components/schemas/PublicSessionResponse" }
```

```json
// jq '.components.schemas.PublicSessionResponse'
{
  "required": ["id", "name", "status", "created_at", "config", "clock",
               "portfolio_metrics", "pending_orders", "trace_count"],
  "properties": { /* 11 fields incl. public, public_anonymous defaults */ }
}
```

Same `$ref` pattern verified for the 4 other endpoints (portfolio → `PortfolioResponse`, portfolio/history → `PortfolioHistoryResponse`, orders → `array of OrderResponse`, trace → `TraceResponse`).

## Related records

- Memory: `project_item_7_pydantic_shipped.md`
- Prior public-session view ship: `project_public_session_view_shipped.md` (the work that originally defined the 5 Pydantic models reused here)
