# Decision: Price Plugin Health Probe Asks Reachability-Only, Not Real-World Recency

**Date**: 2026-05-03
**Status**: Accepted (supersedes `docs/decisions/price-plugin-health-probe-s3-reachability.md` from 2026-05-01)
**Iteration**: bug-hunt `20260503T230405Z2601` (Team B, merge `cc20161`, worktree commit `b6cf709`)

---

## Context

Bug-hunt iteration `20260503T230405Z2601` flagged the dashboard's Plugin Health widget as broken: it reported `price.status = "degraded"` with message `"No price data available for the last 7 days. Run ingestion first."` while a MARKET BUY against the active session's simulated date (May 2025) simultaneously filled at $560.90 with no error. The user-visible state contradicted itself again — the data path worked end-to-end, but the health surface said the data path was broken.

This is the second iteration on this surface. The prior fix (iter `20260501T234103Z1a49` Team E, commit `76f4724`, decision record `price-plugin-health-probe-s3-reachability.md`) replaced a too-narrow check (disk cache only) with another too-narrow check (last-7-real-world-days S3 ingest only). The probe pinned reachability + recency to **real-world today**:

```python
PROBE_RECENT_DAYS = 7

today = datetime.now(timezone.utc).date()
for days_back in range(PROBE_RECENT_DAYS):
    check_date = today - timedelta(days=days_back)
    prefix = f"{self._prefix}/{check_date.isoformat()}"
    response = await asyncio.to_thread(
        self._s3_client.list_objects_v2,
        Bucket=self._bucket,
        Prefix=prefix,
        MaxKeys=1,
    )
    if response.get("Contents"):
        return (True, ...)
# all 7 days empty → DEGRADED + "Run ingestion first"
```

Finlet is an **agentic trading evaluation harness** (per `docs/ARCHITECTURE.md` and `MEMORY.md::project_finlet_positioning.md`). A live session has a **simulated ceiling time** that is independent of real-world today — sessions evaluate trades against historical partitions (e.g., May 2025 simulated dates while real-world today is May 2026). The engine's quote path scans `ceiling_date - 7 days .. ceiling_date` (see `_query_quote` at `finlet/plugins/price_plugin.py:336`), where `ceiling_date` is the **simulated** ceiling, not real-world today.

So `76f4724` closed the symptom ("disk-cache-only check is wrong") but missed the deeper conflation: it replaced a too-narrow check (disk cache only) with another too-narrow check (last-7-real-world-days ingest only), instead of asking the right question — **"is there ANY price data in the lake?"**. The engine's success path requires historical partitions, not today's ingest. The probe was checking the wrong invariant.

---

## Decision

**Drop the recent-window probe entirely. Check S3 reachability + at-least-one parquet under the canonical (unscoped) prefix. Session-independent, real-world-time-independent.**

### Implementation

`_check_s3_reachable()` in `finlet/plugins/price_plugin.py` is rewritten to issue exactly ONE `list_objects_v2` call against the canonical prefix:

```python
async def _check_s3_reachable(self) -> tuple[bool, int]:
    """
    Probe whether the data lake contains ANY parquet under the canonical prefix.

    Returns (reachable, has_any) where:
      - reachable = True iff S3 responded without an exception
      - has_any   = 1 iff at least one parquet exists under f"{self._prefix}/"

    Session-independent: the engine evaluates trades against simulated ceiling
    dates that may be months/years stale relative to real-world today, so a
    real-world-recency probe lies about historical data availability. The right
    question is "is the data lake populated AT ALL?", which is binary and
    session-independent.
    """
    try:
        response = await asyncio.to_thread(
            self._s3_client.list_objects_v2,
            Bucket=self._bucket,
            Prefix=f"{self._prefix}/",  # trailing slash to avoid name-stem-prefix collision
            MaxKeys=1,
        )
        return (True, 1 if response.get("KeyCount", 0) > 0 else 0)
    except (EndpointConnectionError, ClientError, BotoCoreError, Exception):
        return (False, 0)
```

### Three semantically-distinct outcomes

| Cache state | S3 state | Status | Message |
|---|---|---|---|
| Non-empty | (not checked) | HEALTHY | "" |
| Empty | Reachable, canonical prefix has any parquet | HEALTHY | "OK — S3 reachable, price data available" |
| Empty | Reachable, canonical prefix completely empty | DEGRADED | "No price data available. Run ingestion first." |
| Empty | Unreachable | DEGRADED | "S3 unreachable: price data store cannot be listed. Check network connectivity and AWS credentials." |

The `routes_health._check_price_data_status` translator continues to map the substring `"S3 unreachable"` → `s3_unreachable` for the top-level `data_status` field. The "S3 unreachable" wording is pinned as a fixed convention (see `docs/decisions/probe-message-sanitization-translator-coupling.md`).

The `PROBE_RECENT_DAYS = 7` constant is retained (with a deprecation comment) for backwards-compatible test imports. The probe no longer references it.

---

## Why caching the probe result for 60s is still load-bearing

Unchanged from the prior decision: the dashboard polls `/v1/plugins/health` every 2 seconds. Without the per-instance `_probe_cache` (TTL `PROBE_CACHE_TTL_SECONDS = 60`), every poll triggers an S3 `list_objects_v2` call — 30/min/instance, 1800/hr/instance. With the cache, the poll cost collapses to 1/min/instance.

---

## Alternatives Considered

### Option 2 — Parameterise lookback to 365 days

Rejected. Still encodes a real-world-recency assumption, just a more permissive one. Fails the same way for sessions running on dates older than one year (e.g., a backtest starting 2010). The fundamental architectural mistake is "probe pinned to real-world recency" — extending the loop is re-papering, not fixing.

### Option 3 — Session-aware probe

Rejected. Would require touching `finlet/plugins/base.py:246` (`_probe()` signature change to accept `session: Session | None`) and `finlet/api/routes_health.py:84-114` (pass the active session into the probe). The probe contract is currently session-independent, and changing it forces every plugin probe to reason about whether they need session context. The triage spec explicitly said "avoid this if simpler options work", and Option 1 DOES work because the actual question — "is the data lake populated?" — is session-independent.

### Adding an `or` clause on top of `76f4724`

Rejected. Extending "all 7 real-world days empty" to "BUT if disk cache is empty AND last query succeeded recently, return HEALTHY anyway" would re-paper over the same architectural mistake. The simplest fix that closes the root cause is to ask the right question.

---

## Trade-offs

### What we gained

- Health surface now matches the engine's data path. HEALTHY whenever the engine can fill orders against historical partitions.
- The probe is session-time-independent and real-world-time-independent — works correctly for any session's simulated ceiling.
- Two distinct failure modes (S3 unreachable vs. "data lake never populated") get distinct messages.
- Existing translator-stability + 60s cache invariants preserved.

### What we accepted

- A 60s window where the probe cache disagrees with reality. Acceptable for a non-critical-path probe.
- One `list_objects_v2` call per cold-start probe (mitigated by `MaxKeys=1` + immediate return).
- `PROBE_RECENT_DAYS = 7` constant is retained but unused — kept for backwards-compat test imports.

---

## Risk-binding test

The "drop the recency probe" fix could regress into "always HEALTHY because we stopped looking" if the S3-unreachable path is broken. New regression test `test_price_plugin_health_check_s3_unreachable_still_unhealthy` mocks `EndpointConnectionError` and asserts:

1. `status != HEALTHY`
2. `status == DEGRADED`
3. `"unreachable"` or `"connect"` substring in the message (so the `routes_health` translator still maps to `s3_unreachable`)

Without this test, the fix could silently regress into a tautological "HEALTHY no matter what" probe — the more permissive the question becomes, the more important the not-HEALTHY branches stay covered.

---

## Reversal Path

Single SHA. Restore the previous `_check_s3_reachable()` body (the 7-iteration date-scoped loop from `76f4724`) and swap the messages back to the recent-window wording. The new tests in `tests/plugins/test_price_plugin.py` would need updates to remove the canonical-prefix assertion and reinstate the date-scoped prefix assertion. ~10 minutes total revert. Not recommended — the prior probe lies about historical data availability.

---

## References

- This iteration's merge: `cc20161` (worktree commit `b6cf709`)
- Superseded decision record: `docs/decisions/price-plugin-health-probe-s3-reachability.md` (2026-05-01, iter `20260501T234103Z1a49` Team E, commit `76f4724`)
- `finlet/plugins/price_plugin.py` — `_check_s3_reachable()` and `_render_probe_health()`
- `finlet/api/routes_health.py` — `_check_price_data_status()` translator (unchanged)
- `tests/plugins/test_price_plugin.py` — `test_price_plugin_health_check_historical_data_only_real_world_recent_empty` (regression), `test_price_plugin_health_check_s3_unreachable_still_unhealthy` (risk-binding)
- Related lesson in `docs/LESSONS.md`: "A health probe that pins reachability/recency to real-world today is a structural lie when the engine operates on simulated time."
- Related: `docs/decisions/probe-message-sanitization-translator-coupling.md` (translator stability)
