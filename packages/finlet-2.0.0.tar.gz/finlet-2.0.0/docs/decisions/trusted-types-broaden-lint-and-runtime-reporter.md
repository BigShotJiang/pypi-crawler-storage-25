# Decision: Broaden Trusted Types Lint Coverage and Add Runtime Violation Reporter

**Date**: 2026-04-30
**Status**: Accepted

---

## Context

Three real-broken Trusted Types instances slipped into production across two bug-hunt iterations (`20260428T013300Z6e79`, `20260428T031818Z2efa`):

1. `trusted-types-default-svg` (commit `4908f98`) — SVG injection via the unnamed `default` policy from `dashboard/index.html`. The lint guard never fired because the offending HTML lived in the index template, not a `.js` file.
2. `google-sso-goog-html-csp` (commit `4908f98`) — Google's SSO bundle's `goog#html` policy creation was blocked by the CSP `trusted-types` allowlist. No CI smoke against the live CSP header caught it.
3. `trusted-types-vendor-svg` (commit `9c5a917`) — Vendor blob (`lightweight-charts.standalone.production.js`) bypassed `finlet-default` and triggered the default-policy `console.warn` on every page load. No production telemetry captured the recurrence.

Same shape across all three: a Trusted Types violation slips into production because the lint guard, the CSP allowlist, and the runtime policy each cover a different sink and the seams between them are unguarded. Each fix had been a per-instance patch; the convention was silent on the seams.

Audit of the dashboard tree under the proposed broader lint glob revealed EIGHT additional unguarded `innerHTML` writes in `dashboard/verify.html` (4 sites) and `dashboard/setup.html` (4 sites) — all written AFTER the lint shipped 2026-04-28, all latent regression vectors that the narrower glob hid.

## Decision

Close all three seams together in a single refactor (commit `bbbf7cc3`):

1. **Broaden the lint glob to `*.js` and `*.html`.** `scripts/lint-trusted-types.sh` now uses `find "$DASH_DIR" -type f \( -name '*.js' -o -name '*.html' \) -print0`. HTML-block scoping is implemented as an awk state-machine flag toggled by `<script>` / `</script>` tags (case-insensitive). Outside `<script>` blocks, HTML attribute writes like `onclick="..."` remain out of scope (CSP `script-src` already gates these).
2. **Broaden the lint regex to cover all Trusted Types-relevant DOM HTML sinks.** The previous `\.innerHTML[[:space:]]*=` predicate becomes `\.(innerHTML|outerHTML)[[:space:]]*=|\.insertAdjacentHTML[[:space:]]*\(|document\.write[[:space:]]*\(|\.createContextualFragment[[:space:]]*\(`. Same forgiveness rules apply (same-line or next-line `trustedHTML(`).
3. **Wrap the eight unguarded sites in `dashboard/verify.html` and `dashboard/setup.html` via `trustedHTML(...)`.** Mechanical wrap; no escape changes needed (all eight are static SVG/markup strings).
4. **Add a runtime Trusted Types violation reporter.** Each `default` policy callback in `dashboard/api-utils.js` (`createHTML`, `createScript`, `createScriptURL`) calls `reportClientError({type: 'trusted_types_violation', sink, sample, source})` in addition to `console.warn`, wrapped in try/catch so a telemetry failure can never block render. A top-level `document.addEventListener('securitypolicyviolation', ...)` handler POSTs the same payload — catches CSP-side violations the default policy doesn't see.

## Justification

**Lint coverage was strictly narrower than the convention.** The convention is "no bare HTML-sink writes outside `trustedHTML(...)`," not "no bare `innerHTML` writes in `.js` files." The lint shipped narrower than the convention because the initial implementation only had `.js` precedent to lint and `innerHTML` was the only sink in active use. Both narrowings have now produced production bugs. Closing the gap once is cheaper than three more per-instance patches.

**Runtime telemetry surfaces production reality.** `console.warn` is the right developer signal; it is the wrong production signal because production browsers run with consoles closed. The CSP `report-uri` endpoint exists at `/v1/csp-report` and the `client-error` endpoint exists at `/v1/telemetry/client-error` — both rate-limited, both wired to `structlog`. Adding the POST is a one-line change inside an existing try/catch boundary; the marginal cost of per-violation telemetry is near-zero, the value of catching a regression before the next bug-hunt walk is high.

**Atomic broadening + reporter is cheaper than two passes.** The audit step (running the broader lint against the unmodified tree) surfaces the eight `verify.html` + `setup.html` sites as failures. Wrapping them in the same SHA closes the audit. Splitting into two passes (broaden lint, then fix the surfaced sites) leaves a window where the lint is broken on main; doing both atomically preserves the green-main invariant.

## Consequences

### Positive

- All three recurrence shapes are structurally prevented at PR-time (lint) AND observable in production (telemetry).
- Future HTML-sink bugs in `.html` files are caught at commit-time instead of bug-hunt iteration.
- The eight previously-unguarded `verify.html` + `setup.html` writes are now wrapped — the email-verification error path and copy-button success state are no longer latent default-policy invocations.
- CSP-side violations (e.g., a future allowlist regression on `goog#html` or any new third-party policy) flow through the same telemetry channel via the `securitypolicyviolation` event.

### Negative

- Lint runtime grows slightly (additional `*.html` files in scope; awk state-machine adds one pass per HTML file). Negligible — dashboard has ~20 HTML files, awk is fast.
- Telemetry POST volume grows when a new violation lands in production. Mitigated by `/v1/telemetry/client-error`'s existing rate limiter.
- Vendor JS keeps the `// trusted-types-vendor-allowlist` marker convention; if a future bundle upgrade introduces a NEW vendor `innerHTML` write without the marker, the lint catches it but the runtime reporter will fire on every page load until the marker is added or the write is wrapped.

### Out of scope (deliberate)

- **Vendor JS replacement.** `lightweight-charts.standalone.production.js` continues to use the marker. Replacing the vendor library or wrapping its internal `innerHTML` is a separate ticket.
- **Comprehensive XSS audit.** This refactor closes the Trusted Types lint and runtime gaps. The `esc()` helper, user-data sanitization paths, and CSP `script-src` allowlist are separate concerns.
- **CSP `script-src` runtime gates.** The `'strict-dynamic' 'nonce-...'` directive already blocks `eval`, `new Function()`, and inline event handlers — this refactor does not duplicate that gate.

## Reversal path

Single SHA, mechanical, ~15 minutes. Lint-script changes are ~30 LOC of awk + glob (revert by restoring the original `find ... -name '*.js'` and the narrower `\.innerHTML\s*=` regex). The eight `trustedHTML(...)` wraps in `verify.html` + `setup.html` are mechanical to unwrap (the wrap is identity in browsers without Trusted Types — no behavior change to revert). The reporter addition in `api-utils.js` is one new try/catch block + one event listener (~25 LOC) — revert by deleting them. Named-policy + lint baseline that existed before this refactor remains intact.

## References

- Refactor queue spec: `docs/bug-hunt/refactor-queue/trusted-types.md` (`status: shipped`)
- Implementation: `scripts/lint-trusted-types.sh`, `dashboard/verify.html`, `dashboard/setup.html`, `dashboard/api-utils.js`, `dashboard/event-contract.md`
- Tests: `tests/dashboard/lint-trusted-types.spec.sh`, `tests/e2e/journey-trusted-types.spec.ts`
- Architecture context: `docs/ARCHITECTURE.md` ("Trusted Types pre-commit guard", "Trusted Types runtime telemetry")
- Sibling decisions: `docs/decisions/dashboard-event-bus.md`, `docs/decisions/trustedhtml-vendor-patch-tradingview.md`
- Bug-hunt iterations that surfaced the recurrence: `20260428T013300Z6e79`, `20260428T031818Z2efa`
