# Decision: Plugin Registration Order Determines Priority

**Date:** 2026-04-07
**Status:** Accepted
**Source:** v0.1.1 Launch Deployment

## Context

`PluginRegistry` supports multiple plugins for the same type (e.g., both FundamentalsPlugin and FinnhubPlugin serve `fundamentals`). `registry.get_plugin(type)` uses first-match resolution — the first plugin registered for a given type is returned as the default.

Before v0.1.1, FinnhubPlugin was registered before FundamentalsPlugin in `app.py:_register_plugins()`. Since FinnhubPlugin serves both `news` and `fundamentals` types, it silently became the default for fundamentals queries. Agents received Finnhub company profiles (live API) instead of S3 Parquet quarterly financials — wrong data source, no error.

## Decision

Registration order in `_register_plugins()` is now deliberate and documented:

1. **S3-backed plugins before live-API plugins** for the same type. S3 data is the primary source; live APIs are fallbacks.
2. **FundamentalsPlugin before FinnhubPlugin** — S3 Parquet quarterly financials are the default for `fundamentals` queries.
3. **EconPlugin before FredPlugin** — free government APIs (BLS, BEA, Treasury, Fed) are the default for `economic` queries.

## Consequences

- Adding a new plugin that shares a type with an existing plugin requires considering registration order explicitly.
- The pattern is: preferred source first, fallback second. Comments in `_register_plugins()` document the rationale for each ordering.
- Silent priority bugs are possible if registration order is changed without understanding first-match resolution. See `docs/lessons.md` lesson #46.
