# Decision: `PluginConfigUpdate.email` Accepts Empty String as Clear Sentinel

**Date**: 2026-05-02
**Status**: Accepted

---

## Context

The `close-patch-ineffective-2026-05-02` refactor (Team A) introduced a new `finlet plugins remove <name>` CLI subcommand. The semantics are: clear the calling user's per-plugin credentials and disable the plugin for that tenant. Both halves go through the canonical `PUT /v1/settings/plugins` endpoint that the dashboard already uses — there is no separate DELETE endpoint, and `update_plugin` (in `finlet/api/services/settings_service.py`) treats empty-string `api_key` and `email` as the "clear" path: the empty values are written into the per-user config, `registry.reload()` re-runs `initialize()` with the cleared identity, and the EDGAR plugin's `_initialized` flag flips to False — exactly the desired "removed" state.

The CLI's `plugins_remove` body sends `{plugin: name, api_key: "", email: "", enabled: false}`. That request hit a 422 from FastAPI's request-validation layer before ever reaching `update_plugin`.

The blocker was a Pydantic field validator on `PluginConfigUpdate.email` (in `finlet/api/schemas/settings.py`). The previous shape rejected ANY non-`None` value that did not contain `@`:

```python
@field_validator("email")
@classmethod
def email_must_contain_at(cls, v: str | None) -> str | None:
    if v is not None and "@" not in v:
        raise ValueError("email must contain an '@' sign")
    return v
```

So `email=""` (empty string) raised because `"@" not in ""` is True. The validator made the documented "clear identity" contract impossible to invoke from any client — CLI, dashboard, or third-party.

---

## Decision

Relax `PluginConfigUpdate.email_must_contain_at` to accept the empty string as a valid "clear" sentinel. Non-empty values still require `@` so well-formed emails continue to round-trip cleanly.

```python
@field_validator("email")
@classmethod
def email_must_contain_at(cls, v: str | None) -> str | None:
    # Empty string is a valid "clear" sentinel — the CLI's
    # ``plugins remove <name>`` command sends ``email=""`` to clear
    # the plugin's per-user identity. ``update_plugin`` treats empty
    # strings the same as a credential change and reloads the plugin
    # with the cleared config, yielding ``_initialized=False`` for
    # the calling tenant. Non-empty values must still contain an
    # ``@`` so well-formed emails round-trip cleanly.
    if v is not None and v != "" and "@" not in v:
        raise ValueError("email must contain an '@' sign")
    return v
```

The narrowing is from `v != None and "@" not in v` to `v != None and v != "" and "@" not in v`. One conjunct added; nothing else changed in the schema or in `update_plugin`.

---

## Alternatives Considered

### a. Introduce a separate `PluginConfigClear` schema

Split the route so credential-bearing writes go through `PluginConfigUpdate` (with the strict validator) and clear-only writes go through a new `PluginConfigClear` schema with no `email` validator.

**Rejected.** Both routes converge on the same `update_plugin` service method. A divergent schema would have forced a divergent endpoint (or content-type discrimination), and the empty-string-as-clear contract is already what `update_plugin` expects internally — the validator was the only barrier. Adding a parallel schema would multiply surface area for the same internal behavior.

### b. Use `email=None` instead of `email=""`

Have `plugins remove` send `{plugin: name, api_key: None, email: None, enabled: false}` so the strict validator's `v is not None` short-circuit lets it through.

**Rejected.** The existing `update_plugin` body distinguishes "not provided" (`None` — leave existing identity in place) from "explicit clear" (`""` — wipe the per-user identity and reload). Across the codebase `Optional[str]` fields are routinely treated as "field omitted from the partial update," and `update_plugin`'s own merge logic already reads `if email is not None: config[plugin]["identity"] = email` — flipping `None` to clear-semantics would invert that branch's meaning everywhere it's referenced. Empty-string is the existing internal clear sentinel; the validator was a request-layer mismatch with the service-layer contract, not a deliberate constraint.

### c. Drop the validator entirely

Let any non-`None` value pass; rely on downstream consumers (e.g. the EDGAR plugin's `set_identity()` call) to reject malformed emails.

**Rejected.** The `@` check catches typos at the request boundary and produces a clear 422 with an actionable message. Pushing the check downstream produces a 200-with-unhealthy-plugin shape that's harder to debug from a CLI tail.

---

## Trade-Offs

- **Validator coverage narrowed by exactly one value: empty string.** Any non-`None` non-empty value still must contain `@`. The set of rejected inputs went from `{v : v is not None and "@" not in v}` to `{v : v is not None and v != "" and "@" not in v}` — strict subset.
- **Empty string is now silently a clear request.** A client that intends to send a real address but accidentally sends `""` (e.g. from an empty form field) will clear the plugin instead of getting a validation error. Mitigation: `update_plugin` returns the post-reload `PluginHealthItem` with `health.status='unhealthy'` and a non-empty `health.message` so the client sees the live state in the response body — silent failure is impossible at the response layer even if it's silent at the validator.
- **CLI `plugins remove` is the only canonical caller of the empty-string path.** Dashboard's settings.js does not currently expose a "clear" affordance for plugin identity (the per-row delete button is not implemented). Third-party callers can use the same body shape if they need scriptable parity.

---

## Touched

- `finlet/api/schemas/settings.py` lines 38-51 (validator + comment)
- `finlet/cli.py` — new `plugins_remove` Typer command (the only caller that sends `email=""`)
- `tests/api/test_routes_settings.py::TestPlugins.test_update_plugin_clears_credentials_with_empty_strings` — new assertion that `PUT /v1/settings/plugins` with empty `api_key` + `email` round-trips to 200 with `health.status="unhealthy"` and a non-empty `health.message`
- `tests/test_cli.py::TestPluginsRemoveCommand` — 4 tests (happy path, missing API key, auth rejected, ConnectError) covering the new CLI path that exercises the empty-string body

---

## References

- Refactor doc: `docs/bug-hunt/refactor-queue/close-patch-ineffective-2026-05-02.md` (Signal 1)
- Cumulative merge: `5f18f8b` (Team A merge after Teams B + C; Team A sub-sha `6c72541`)
- Related ADR: `docs/decisions/refactor/plugin-config-propagation.md` — the canonical `PUT /v1/settings/plugins` write path that this validator change unblocks for the clear case
