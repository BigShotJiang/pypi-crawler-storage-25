---
title: Trade Ticket panel — page-lifetime always-on `portfolio:updated` subscriber
date: 2026-05-02
status: accepted
related:
  - docs/bug-hunt/refactor-queue/trade-ticket-state-sync-v2.md
  - docs/decisions/dialog-state-mirror-prime-ordering.md
  - docs/refactor/trade-ticket-state-sync/plan.md
  - docs/bug-hunt/pending_recurrences.jsonl
---

# Trade Ticket panel — page-lifetime always-on `portfolio:updated` subscriber

## Context

`trade-ticket-stale-cash` recurred for the third time across three iterations
(`20260428T031818Z2efa`, `20260429T052717Z1a13`, `20260429T232205Z17ff`,
`20260501T234103Z1a49`, and again in iter `20260502T142726Z7b36` Phase 5.5
retest of deploy `433c01c`). The Trade Ticket panel's
`#tt-cash-balance` element rotted at `$100,000.00` after a MARKET BUY 10 SPY
fill that should have left cash at `$94,846.45` (a `$5,153.55` divergence
matching the SPY cost basis). Key Metrics `Cash` tile updated correctly via
`renderPortfolio`; the bus's `portfolio:updated` publish fired with the
correct payload (assertion #4 PASS); only the panel's persistent-DOM cash
header was stale.

Root cause is a panel-vs-dialog assumption violation. `dashboard/trade-ticket.js`
is a slide-out `<aside>` (`dashboard/index.html:427`) — its DOM (including
`<span id="tt-cash-balance">`) is rendered once at page load and persists for
the page lifetime. `openTradeTicket()` only adds a CSS class.
The v1 `dialogStateMirror` (`efdd443`, 2026-04-30) was designed for true
dialogs whose DOM lifecycle equals their visibility lifecycle — it allocates
the bus subscription on `openTradeTicket()` and tears it down on
`closeTradeTicket()`. Between close and the next open, no subscriber keeps
`#tt-cash-balance` in sync. After `submitTradeTicket()` calls
`closeTradeTicket()` (line 379) BEFORE the post-submit refetch IIFE (line 408)
republishes through the bus, the persistent DOM rots.

The mirror remains correct for its design surface; the gap is that one
consumer needs an additional always-on subscription because its DOM persists.

## Decision

Install a module-level always-on `bus.subscribe('portfolio:updated', ...)` at
`initTradeTicket()` (called once per page load) that paints `#tt-cash-balance`
regardless of panel open/close state. Synchronously prime from
`bus.getLastPublished('portfolio:updated')` at init so a page-load that lands
AFTER the first SSE tick paints immediately. Layer this orthogonally over the
existing per-open `dialogStateMirror` — the mirror continues to own focus,
shape-drift refetch, refuseClobber, and transient-failure protection for the
visible lifetime of the panel.

Both subscribers paint via the existing `paintCash(cash)` so there is a single
shape. The always-on subscriber guards `typeof payload.cash === 'number' &&
!Number.isNaN(payload.cash)` before painting and intentionally does NOT capture
the unsubscribe closure (it lives for the page lifetime).

Code change is ~5 lines plus one regression test.
`dashboard/event-contract.md` documents the always-on subscriber convention
under `portfolio:updated`.

## Alternatives considered

**`panelStateMirror({...})` as a new convention module** — promote the
always-on pattern into `dashboard/dialog-state-mirror.js` as a separate
factory export with semantics (subscribe at install, always paint regardless
of visibility, per-open mirror layered on top owns focus/transient/refetch).

**Rejected as premature.** Cost: ~80 LOC new module + tests + documentation +
migration. Benefit: a future read-only persistent panel (sticky positions
sidebar, always-visible portfolio mini-card in a drawer) gets the convention
for free. There is currently exactly **one** consumer that needs this. The
v1 refactor's break-even was "shipped after 3 instances of the same shape" —
applying the same logic, defer the abstraction until a second persistent-DOM
panel surfaces.

**Lift the mirror's lifecycle to install-time** — change
`dialogStateMirror` itself to subscribe at install and treat open/close as
visibility-only. **Rejected** — would break the mirror's contract for true
dialogs (the focus/refuseClobber concerns are coupled to the visible
lifetime by design); the change would touch every consumer instead of one.

## Consequences

**Composes orthogonally with v1 mirror.** When a `portfolio:updated` publish
lands while the panel is open, both subscribers fire and `paintCash` is
invoked twice with the same value — accepted as a no-op double-paint. When
the panel is closed, only the always-on subscriber fires — the closed-panel
backstop. When the panel is open and the publisher omits a recognized shape,
the per-open mirror's shape-drift `refetch()` still fires through the
existing path.

**Reversal = single git revert.** The always-on `bus.subscribe(...)` call
returns an unsubscribe closure that is never invoked (intentional —
page-lifetime sub). Removing the call un-fixes the bug but breaks nothing
else; the v1 mirror continues to function as before. No schema, API, or
contract changes.

**No new public surface.** The always-on subscriber is private to
`initTradeTicket()` — no module export, no factory, no convention contract
that downstream depends on. Future consumers that need the same shape can
copy the 5-line pattern (or, on the second consumer, promote to
`panelStateMirror`).

## Triggers for revisit

Promote the always-on subscriber pattern into a `panelStateMirror({...})`
convention module on the SECOND persistent-DOM consumer that needs to mirror
live bus state across panel-open/close cycles. Concrete signals:

- A new slide-out `<aside>` with persistent DOM and a mirrored bus value
  (e.g., a sticky positions drawer, an always-visible portfolio sidebar,
  a notifications panel that mirrors `notifications:updated`).
- A second module-level `bus.subscribe(...)` at init time written by hand
  in any `dashboard/*.js` file with the same "guard payload, paint DOM,
  never unsubscribe" shape.

When either surfaces, extract the convention; migrate Trade Ticket and the
new consumer in the same commit; update `docs/event-contract.md` to point
at the factory instead of the inline pattern. The break-even is the same
as the v1 mirror's: pays back on the 3rd instance, preventive on the 4th.
