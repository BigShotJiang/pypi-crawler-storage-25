# Decision: `_resolve_session` Helper as the Canonical MCP Session-Resolution Pattern

**Date:** 2026-05-07
**Status:** Accepted
**Source:** MCP-First Migration Phase 1, audit finding C3 (commit `1076df9`, Team A)

## Context

MCP tools previously called `_get_session(session_id, user_id)` and `_default_session_id(user_id)` directly. Both helpers raise `ValueError` on not-found, wrong-owner, or "no/multiple sessions" failures. When that exception bubbled out of an `@mcp.tool()` async function, FastMCP wrapped it in a protocol-level error — agents pattern-match on dict shape (`{"error": "..."}`) and treat protocol errors as unrecoverable. The result: a wrong-owner `session_id` produced an opaque protocol failure instead of a recoverable, agent-readable error envelope.

## Decision

A new helper in `finlet/mcp/auth.py`:

```python
def _resolve_session(
    session_id: str | None, user_id: str | None
) -> tuple[Session, str] | dict[str, str]:
    try:
        sid = session_id or _default_session_id(user_id)
        session = _get_session(sid, user_id)
    except ValueError as e:
        return {"error": str(e)}
    return session, sid
```

All MCP tool callsites that previously paired `_default_session_id` + `_get_session` now call `_resolve_session` and inspect the return type:

```python
result = _resolve_session(session_id, user_id)
if isinstance(result, dict):
    return result   # error envelope — already in the agent-readable shape
session, sid = result
```

The underlying `_get_session` and `_default_session_id` primitives are kept for direct use **only** inside this helper (and re-exported from `mcp/server.py` for tests that exercise the raw exception paths).

## Consequences

- 18 paired-call sites in `finlet/mcp/server.py`, `finlet/mcp/tools_portfolio.py`, and `finlet/mcp/tools_trading.py` migrated.
- Wrong-owner / not-found / "no sessions" / "multiple sessions" failures now return `{"error": "..."}` dicts the agent can recover from without parsing FastMCP protocol errors.
- New mutating tools should reuse `_resolve_session`. Direct calls to `_get_session` / `_default_session_id` from tool bodies are a regression — `.claude/rules/mcp-server.md` codifies this rule.
- The dict envelope is intentionally shallow (`{"error": str}`) for backwards compatibility with existing MCP error-shape tests. The richer `{"error": {"code", "message", "details"}}` envelope used by REST is consumed by the CLI via `_print_error`; future Phase 2 work may unify both shapes.

## Alternatives Considered

1. **Catch `ValueError` per callsite.** Rejected — 18 duplicated try/except blocks, drift risk identical to the inline `_get_session` problem we were fixing.
2. **Make `_get_session` return the dict directly.** Rejected — `_get_session` has non-MCP callers (tests, internal utilities) that still expect the raw exception. Splitting at the helper layer keeps the primitive sharp.
