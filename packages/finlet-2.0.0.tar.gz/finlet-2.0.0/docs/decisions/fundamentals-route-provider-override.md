# Fundamentals Route — `?provider=` Override + Skip-Uninit Fallback

**Decision date:** 2026-04-29
**Iteration:** bug-hunt 20260429T232205Z17ff
**Author:** Team A
**Status:** Accepted; shipped in commit `783fe83`, merged at `72a2d5b`.

## Context

`GET /v1/sessions/{id}/market/fundamentals?ticker=SPY` returned a misleading `503` "Finnhub plugin not initialized. Provide 'api_key' config" even when the registered S3 fundamentals plugin was healthy and serving 21 cached files. The blind agent reproduced the failure across three variants (`?ticker=SPY`, `?ticker=SPY&provider=fundamentals_s3`, `?ticker=SPY&plugin=fundamentals_s3`), confirming the route always surfaced the Finnhub init error regardless of provider intent.

Root cause: `market_service.route_query()` ran the registered fallback chain unconditionally on plugin error. In production, FinnhubPlugin is registered as the second fundamentals plugin (per `plugin-registration-order.md`'s "free plugins before API-key plugins" convention) but never receives an API key — its `query()` returns an init error. When `FundamentalsPlugin` returned an actionable error (e.g., "S3 fundamentals data unreachable for AAPL"), `route_query` walked to FinnhubPlugin, which immediately responded with the stale "not initialized" error, masking the upstream plugin's real response.

## Decision

Two complementary changes:

### 1. Skip uninitialized fallback plugins

`market_service.route_query()` now skips fallback plugins whose `_initialized` flag is False once a prior plugin in the chain has already returned a response. This preserves the upstream plugin's actual error so the user sees the real failure, not a misleading downstream init error.

**Plugin contract:** every plugin sets `_initialized = True` after successful configuration in its `__init__` or initialization step. Plugins that need user-supplied credentials (e.g., FinnhubPlugin's `api_key`) leave `_initialized = False` until they receive valid config. Test plugins used in fallback-chain tests must set `_initialized = True` in their `__init__` to participate as a fallback target — without this they silently bypass the new short-circuit.

### 2. `?provider=` query param escape hatch

`routes_market.get_fundamentals` accepts an optional `?provider=<plugin_name>` query param that pins dispatch to a single plugin. When set, no fallback chain runs — only the named plugin is queried, and its response (success or error, including init errors) is returned as-is. Examples:
- `?provider=fundamentals_s3` → query S3 only; no fall-through to Finnhub even on error.
- `?provider=fundamentals_finnhub` → force-query Finnhub directly; useful when the user has a Finnhub key and wants real-time profile data instead of S3 quarterlies.
- Unknown provider name → 503 with the available provider list.

The pinned-uninit case is intentional: if you pin to an uninitialized plugin, you get the init error back as-is (not masked, not silently swapped). This is the diagnostic surface — operators can confirm config status without reasoning about the fallback chain.

## Rationale

The "skip-uninit" rule encodes an invariant that should always have been true: a fallback chain only makes sense if downstream plugins are eligible to serve the request. An uninitialized plugin is structurally unable to serve, so cascading to it produces a false signal. This is the kind of fix that, in retrospect, looks obvious — but the cascade pattern was the default in `query_plugin()`'s loop, and no test caught it because all test plugins were initialized.

The `?provider=` escape hatch addresses two real needs:
1. **Diagnosis.** When the chain is misbehaving, an operator can pin to a single plugin and see its raw response without reasoning about cascade ordering.
2. **Client-driven routing.** A future client (e.g., a benchmark agent) may want to explicitly query S3 for point-in-time quarterly financials AND Finnhub for current company profiles — same `fundamentals` type, different semantics. Pinning by provider name lets the client express intent without re-architecting the registry.

## Alternatives Considered

- **Reorder registration so FinnhubPlugin comes first.** Rejected — Finnhub is not the right default for fundamentals (no point-in-time quarterly data; live API call adds latency). The convention is "free plugins before API-key plugins" for a reason.
- **Make FinnhubPlugin's `query()` return a dummy "no data" response when uninitialized, deferring to the next plugin.** Rejected — this would hide the configuration mistake from the operator. An uninitialized plugin in the chain is itself a bug worth surfacing; we just shouldn't let its error mask another plugin's real response.
- **Remove FinnhubPlugin from the fundamentals fallback chain entirely.** Rejected — Finnhub does serve real fundamentals (company profiles, real-time data) when configured, and operators with a key should be able to use it. The skip-uninit rule preserves that path.
- **Add a `provider` field to the request body instead of a query param.** Rejected — `GET` requests have no body, and the existing market endpoints use query params for the typed inputs (`ticker`, `concept`, etc.). Consistency wins.

## Reversal Path

Single revert commit. `route_query`'s skip-uninit branch is ~10 lines; the `?provider=` query param is ~15 lines plus the route signature change. If the rule turns out to be too aggressive (e.g., a future plugin's `_initialized` flag flickers during runtime reconfig), the fix is to revisit the `_initialized` contract — not to roll back the skip. The provider override is purely additive; reverting it removes the diagnostic surface but breaks no production flow.

## Tests

- `tests/api/test_market_fundamentals_routing.py` (new, 5 cases): S3 success, S3 error skips uninit Finnhub, provider pin no-fallthrough, unknown provider 503, provider pin to uninit plugin surfaces init error.
- `tests/api/test_market_fallback.py`: existing test plugins now set `_initialized = True` in their `__init__` to reflect operational state.
- Validation: `pytest tests/api` 1224 passed; ruff clean; mypy clean.

## See Also

- `docs/decisions/plugin-registration-order.md` — "free plugins before API-key plugins" convention.
- `docs/ARCHITECTURE.md` — Plugin Routing section, updated 2026-04-29 to document the skip-uninit rule and `?provider=` query param.
- `docs/LESSONS.md` — "Plugin fallback chain pitfall" lesson.
- `docs/bug-hunt/20260429T232205Z17ff/triage.md` — original blind-agent finding.
