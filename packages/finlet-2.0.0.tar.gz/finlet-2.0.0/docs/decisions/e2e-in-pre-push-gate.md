# Decision: Add Playwright smoke to the pre-push gate

**Date**: 2026-05-03 (initial 3 journeys); 2026-05-04 (expanded to 6 journeys)
**Status**: Accepted

---

## Context

The pre-push hook (`scripts/git-hooks/pre-push`) ran ruff + mypy + pytest, but **never** ran any Playwright e2e tests. So Playwright regressions only surfaced after the push reached GitHub Actions, where the `e2e` job blocks `deploy`. When `e2e` failed, deploy was skipped silently — even though the merge to `main` had already happened.

This bit `bug-hunt 20260503T195318Z43db` directly. The skill claimed "fix shipped" because Phase 5's local pytest (3962 passed in 5:14) and the push both succeeded. Reality: a single Playwright failure on `tests/e2e/journey-06-settings.spec.ts:706` ("settings profile save persists via API" — a network-interception assertion) skipped the deploy step. Two patches landed in `main`, neither reached production. See `docs/bug-hunt/20260503T195318Z43db/deploy-failure-handoff.md` for the full systemic-gap writeup.

The systemic problem: **every** bug-hunt iteration's "fix shipped" report was conditionally a lie, because the loop's contract didn't include the gate that actually controls deploy. This will recur on every iteration where any e2e regression — including pre-existing flakes that have nothing to do with the patches — is on `main`.

The handoff doc identified two ways to close it:

1. Make the deploy-failure visible and blocking in the bug-hunt skill report. (Band-aid; the lie is just better-labelled.)
2. Add a thin e2e smoke (3-5 critical journeys) to the local pre-push gate, so the same class of regression is caught before push, not after. Full e2e suite stays in CI.

This decision adopts (2).

---

## Decision

Add a 4th step to `scripts/git-hooks/pre-push` that runs a Playwright smoke via `scripts/e2e-smoke.sh`. The smoke runs:

| # | Spec | Test | Why |
|---|------|------|-----|
| 1 | `tests/e2e/journey-03-login.spec.ts:43` | `correct credentials login and redirect to dashboard` | Login is the single point of failure for every other dashboard journey. If shared-nav.js, FinletAuth, or session storage break, this test breaks deterministically. |
| 2 | `tests/e2e/journey-05-trade.spec.ts:40` | `trade ticket panel opens and shows cash balance` | The Trade Ticket is the most heavily-shared dashboard surface (event bus, dirty tracker, dialog mirror, render-on-read for cash). It's the canary for any cross-cutting dashboard regression. |
| 3 | `tests/e2e/journey-06-settings.spec.ts:18` | `settings page loads with correct nav and breadcrumbs` | Settings cold-load sentinel — catches JS parse errors / missing-module imports that wipe the settings module before any handler binds (fail-mode of bug-hunt `20260503T195318Z43db`'s prior incarnation). |
| 4 | `tests/e2e/journey-06-settings.spec.ts:667` | `settings profile save persists via API` | This was the **exact test** that broke the bug-hunt deploy on 2026-05-03. Adding it to the pre-push gate is regression-aware: future shared-nav.js style breakages on settings.html will block the push, not the deploy. |
| 5 | `tests/e2e/journey-07-leaderboard.spec.ts:17` | `leaderboard page loads with correct nav, breadcrumbs, and content` | Added 2026-05-04 — the leaderboard is the surface most actively under iteration (component metrics + UI columns landed in `20260504T165106Z1ab2`); regressions here block deploy. |
| 6 | `tests/e2e/journey-16-benchmark-blindness.spec.ts:49` | `benchmark API responses intercepted for blindness` | Added 2026-05-04 after this exact test blocked Deploy Finlet on `214546c`. Security invariant: scenario names (`bull_run`, `vix_blowup`, ...) must NEVER leak into agent-visible API responses. The blindness test family is non-negotiable for an agentic-trading evaluation harness; whichever variant of the test trips first stays in the smoke. |

Each test is targeted by `spec:line` — a future test reorder won't accidentally pull in a different test.

The smoke is wired through `scripts/git-hooks/pre-push`, which is symlinked into `.git/hooks/pre-push` by `scripts/setup-git-hooks.sh`. A fresh `./scripts/setup-git-hooks.sh` install picks up the smoke automatically — no second install step.

As a side benefit, this decision also moves the canonical pre-push hook from `deploy/hooks/pre-push` (manually copied) to `scripts/git-hooks/pre-push` (symlinked by the installer). The `deploy/hooks/pre-push` copy is left in place for reference; future edits should land in `scripts/git-hooks/pre-push`.

---

## Cost

- **Per push:** ~90-120s on a developer M-series Mac with the dev server warm (estimate; actual wall-clock on the 6-journey set will be measured on first real push and tuned if it overruns ~120s).
- **Per push (no dev server, no auto-spawn):** <2s — the dev-server pre-flight curl probe to `/health` exits cleanly with an actionable skip message, no playwright spin-up.
- **Per dev:** none — playwright is already installed via `package.json` devDependencies.
- **Per CI:** zero — full e2e suite still runs unchanged.

The ~90-120s is paid by every push from every contributor. That's a meaningful tax on iteration speed. But it's an order of magnitude cheaper than a failed deploy: each of the three deploy-blocking incidents that motivated the smoke (and its 2026-05-04 expansion) wasted ~30 min of agent time + the user's attention to triage the handoff. One blocked push trades ~2 min for that ~30 min — a 15× win.

---

## Justification

- **Closes the bug-hunt "fix shipped" lie.** The skill's Phase 5 contract becomes truthful: tests passed locally → pushed → deploy will run.
- **Catches the most common regression class.** All three failures observed in the last six bug-hunt iterations were in either login, trade flow, or settings — never elsewhere.
- **Targets the specific test that broke the last deploy.** Test #3 is a regression test for the exact failure mode that triggered this decision.
- **Single retry dampens the dominant flake class.** The journey-06 failure was a network-interception race (Playwright `route()` registered after the Page object hydrates the form). One retry caught it ~80% of the time in manual reruns; CI configures `retries: 0`, so the smoke is more permissive than CI.
- **Skip-friendly for partial environments.** The smoke gracefully exits 0 when playwright isn't installed (`npm install` not run), when `tests/e2e/.auth/session.json` doesn't exist (global-setup hasn't run), or when no dev server is reachable on `${FINLET_SMOKE_BASE_URL:-http://localhost:8000}/health` (a 2s curl probe runs before playwright spin-up). Contributors who only touch backend Python aren't punished, and devs pushing without `finlet serve` running don't eat 30s of playwright global-setup wait followed by a confusing failure.
- **Doesn't replace CI's full e2e.** Three journeys catch the recurring regression class; the other 139 still need to run, just not on every push.

### Dev-server pre-flight

`scripts/e2e-smoke.sh` runs three skip gates before invoking playwright: (1) `SKIP_E2E_SMOKE=1` env override, (2) playwright installed in `node_modules`, (3) `tests/e2e/.auth/session.json` exists, and (4) the dev server answers `GET /health` within 2 seconds at `${FINLET_SMOKE_BASE_URL:-http://localhost:8000}`. Gate 4 was added because `tests/e2e/playwright.config.ts` pins `baseURL` to `http://localhost:8000`, and when no server answers, `tests/e2e/global-setup.ts` waits ~30 seconds before hard-failing — a slow and confusing failure mode that teaches contributors to set `SKIP_E2E_SMOKE=1` reflexively, silently re-opening the gap this decision closes. The 2s probe is cheap enough (<2s budget) that it doesn't add meaningful tax to the case where the smoke would have run anyway. `FINLET_SMOKE_BASE_URL` overrides the URL for non-default ports.

---

## Rejected Alternatives

### Run the full e2e suite (~5min) in pre-push
**Rejected.** A 5-minute pre-push gate is too expensive for the typical change. Devs will start using `--no-verify` to bypass it, defeating the purpose. The full suite belongs in CI where it doesn't block iteration.

### Do nothing; just improve the bug-hunt report wording
**Rejected.** The handoff doc already contains a stronger version of this report wording. The wording fix doesn't prevent the next "fix shipped" lie — it just makes the lie better-labelled. A wording fix doesn't change the failure rate; it changes the failure attribution. The actual fix is to stop the failure from happening.

### Run e2e in pre-commit instead of pre-push
**Rejected.** Pre-commit fires on every commit, including WIP and exploratory commits. 90s × 10-20 commits per session = 15-30 minutes of wasted time per session for changes that won't reach `main`. Pre-push fires once per push, when the change is actually about to be shared.

### Hand-pick a different 3 journeys (e.g., signup + dashboard + leaderboard)
**Rejected — explicit user instruction.** The user specified login + place-trade + settings-save. Settings-save is the regression test for the actual deploy failure that motivated this work; the other two are the user's pick of the highest-traffic surfaces.

### Pin to spec name strings instead of `spec:line`
**Rejected.** Spec names are easier to refactor accidentally (`test('settings profile save persists via API'` → `test('settings: profile save persists via API'` and the smoke silently runs zero tests). `spec:line` fails loudly if the test moves — playwright's CLI exits non-zero with "no tests found".

---

## Escape Hatch

```bash
SKIP_E2E_SMOKE=1 git push
```

The env var only skips step 4 (e2e smoke). Steps 1-3 (ruff, mypy, pytest) still run and still block on failure. Use only when the smoke is broken in a way unrelated to your change (e.g., dev server unavailable, playwright reinstall in progress).

---

## How to Add or Remove Journeys

Edit the `SPECS` array in `scripts/e2e-smoke.sh`:

```bash
SPECS=(
    "tests/e2e/journey-03-login.spec.ts:43"
    "tests/e2e/journey-05-trade.spec.ts:40"
    "tests/e2e/journey-06-settings.spec.ts:18"
    "tests/e2e/journey-06-settings.spec.ts:667"
    "tests/e2e/journey-07-leaderboard.spec.ts:17"
    "tests/e2e/journey-16-benchmark-blindness.spec.ts:49"
)
```

Each entry is `spec-path:line-of-the-test('...')-line`. To add a new journey:

1. Find the `test('...', ...)` line in the spec file (`grep -n "test('" tests/e2e/journey-XX.spec.ts`).
2. Append `tests/e2e/journey-XX.spec.ts:LINE` to the `SPECS` array.
3. Update the table in this decision doc.
4. Sanity-check the new wall-time budget — every added journey is paid by every push from every contributor. Stay under ~120s.

To remove a journey: delete its line and update the table here.

---

## Consequences

- **`docs/bug-hunt/*` deploy-failure reports stop being a lie for the login/trade/settings/leaderboard/benchmark-blindness regression class.** They may still lie for failures in the other ~136 e2e tests; the smoke is not exhaustive by design.
- **Pre-push wall time grows from ~5min to ~6.5-7min.** Devs may push less frequently. (This is fine; a push should always represent a believable-shippable change.)
- **The `deploy/hooks/pre-push` copy is now stale.** It still works if installed manually, but new edits should land in `scripts/git-hooks/pre-push`. A follow-up could delete `deploy/hooks/pre-push` once nothing references it (lessons doc, runbook).
- **If the smoke flakes more than ~5% of pushes, escalate.** A flaky pre-push gate teaches devs to use `SKIP_E2E_SMOKE=1` reflexively, which silently re-opens the gap this decision closes. Track flake rate; pull the trigger on either fixing the underlying flake or removing the offending journey from the SPECS array.

---

## 2026-05-04 expansion — journey-06 cold-load + journey-07 + journey-16

Three consecutive bug-hunt iterations had a regression slip past the smoke into the GH-Actions Deploy Finlet e2e gate:

| Iteration | Failed test | Outcome |
|-----------|-------------|---------|
| `20260503T195318Z43db` | `journey-06-settings.spec.ts:667` (settings save PUT intercept) | Original motivator — added `journey-06:667` to the smoke. |
| `20260503T230405Z2601` | `journey-06-settings.spec.ts:18` (settings cold-load) | Added `journey-06:18` to the smoke (sentinel for module-init-time JS errors). |
| `20260504T165106Z1ab2` | `journey-16-benchmark-blindness.spec.ts:49` (API blindness) | Added `journey-16:49` to the smoke. Also added `journey-07-leaderboard:17` because the leaderboard was the iteration's primary surface and a regression there would have been a fourth deploy-block. |

Pattern: the smoke's regression-aware contract is "every journey that has ever blocked a deploy stays in the SPECS array, plus any non-negotiable security invariant." Tests 1 and 2 (login, trade) were the user's pick of the highest-traffic surfaces; tests 3-6 are scar tissue from real deploy-blocks.

Memory `feedback_e2e_smoke_too_narrow.md` captured the meta-pattern (smoke kept being too narrow); this expansion is the durable response.
