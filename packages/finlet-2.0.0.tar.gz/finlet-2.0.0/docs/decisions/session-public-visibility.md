# Decision: Public Session Visibility — Two Booleans on `SessionModel`

**Date:** 2026-05-12
**Status:** SHIPPED
**Source:** Public session view exec plan; v1.0.4 website-gap recon item 3.

## Context

After the 2026-05-06 UI write-path launch cut (`docs/decisions/ui-removal-launch-cut.md`), the production dashboard became a read-only monitoring surface for authenticated agents. The v1.0.4 website-gap recon surfaced a follow-on gap: **the unauthenticated dashboard is a dead end**. A stranger arriving from HN, X, or r/algotrading lands at `finlet.dev`, sees a marketing landing page, but has no way to view a real session before signing up. The recon doc floated a `?demo=<id>` URL-param hack and a static-screenshot fallback; the user explicitly rejected both — the message was "build the real product, not a demo."

The product story Finlet markets — "see your AI agent's reasoning, positions, equity curve, full trace" — needs a real artifact to point at. The decision is: owners opt sessions into public visibility; anonymous visitors browse them read-only at a clean URL.

## Decision

Add two booleans to `SessionModel` (session DB, migration `014_add_session_public_columns`):

* `public: bool = Field(default=False, index=True)` — visibility flag. Private opt-in. Index because the anonymous read endpoints filter on `where public = True AND id = ?`.
* `public_anonymous: bool = Field(default=True)` — anonymous display mode. Owner chooses anonymous (default) vs attributed when publishing.

Public sessions expose all session data anonymously by default at `finlet.dev/sessions/<id>` and via the five `/v1/public/sessions/{id}/*` GET routes (no `Depends(require_user)`):

* `GET /v1/public/sessions/{id}` — session metadata (config, status, portfolio metrics)
* `GET /v1/public/sessions/{id}/portfolio` — current portfolio + positions
* `GET /v1/public/sessions/{id}/portfolio/history` — equity curve time series
* `GET /v1/public/sessions/{id}/orders` — order log
* `GET /v1/public/sessions/{id}/trace` — reasoning trace

Owner toggles visibility through three surfaces that share one service helper (`finlet/api/services/session_service.py::set_visibility`):

* REST `PATCH /v1/sessions/{id}/visibility` with body `{public: bool, anonymous: bool = True}`.
* MCP tool `set_session_visibility(session_id, public, anonymous=True)` — standard `_authenticate_oauth_or_key` + `_resolve_session` auth (per `finlet/mcp/auth.py:32`).
* CLI subcommand `finlet session publish <id> [--anonymous|--attributed] [--unpublish]` — prints the share URL on success.

The anonymous flag governs **ONLY** the `session.name` field on the public response. When `public_anonymous=True`, `name` is replaced with the literal string `"Anonymous Finlet session"`. All other fields (config, portfolio metrics, positions, orders, trace, equity curve) are exposed identically regardless of anonymous mode. When `public_anonymous=False`, `name` is exposed as-is (already owner-controlled free text).

## Rationale

### Why two booleans instead of a single visibility enum?

Two booleans allow future fields (`public_token` for unguessable share tokens, `share_expiry` for time-bounded links, `public_at` timestamp for moderation tools) to land as additive schema appends — no enum migration needed. A single `VisibilityMode` enum (`PRIVATE | PUBLIC_ANONYMOUS | PUBLIC_ATTRIBUTED`) would force an enum migration the moment v1.1 wants any of those richer modes. The two-boolean shape is also semantically cleaner: visibility and display-mode are orthogonal concerns. The cost is one extra column and one extra check in the publish flow — paid once, structurally durable.

### Why anonymous-by-default?

Privacy-conservative default. Owners who publish a session do not necessarily want their `session.name` (which they typed for their own bookkeeping — "Joe's Q4 momentum experiment v3") shown to a stranger. The opt-out (`--attributed`) is one flag; the opt-in to expose is explicit. This also matches the leaderboard-anonymous model (`finlet/leaderboard/`) which uses a pseudonymous 12-character user-display ID.

### Why allowlist serializer, not delete-from-full-dict?

`public_session_response()` builds the response dict by **explicitly listing the keys to include** (`_PUBLIC_SESSION_KEYS` tuple in `finlet/api/services/session_service.py`), not by computing `session_response()` and deleting `user_id`. Delete-from-full-dict is structurally fragile — a new PII field added to `SessionResponse` six months later silently leaks through the deletion list if no one remembers to update both sites. The allowlist fails closed: a new field is invisible to public consumers until it is explicitly added to the tuple. A property test (`tests/api/test_public_session_properties.py`) deep-inspects the response JSON and fails the build if `user_id`, `email`, `last_used_at`, or any idempotency key appears.

### Why no app-layer rate limit on `/v1/public/sessions/*`?

Per locked decision 7 in the exec plan: out of scope for v1. Anonymous rate-limit middleware does not exist today (rate limits in `finlet/api/rate_limit/` are per-user, keyed on `UserRecord.id`). The lowest-effort safe approach is to rely on the reverse-proxy (Caddy/Cloudflare) rate limit plus the existing `RequestSizeLimitMiddleware`. If abuse surfaces post-launch, per-IP middleware can be added to the new prefix only. Flagged in PR description so reviewers know the gap is intentional.

### Why no `Depends(require_user)` on the public read routes?

That would defeat the entire feature. The precedent for anonymous routes on the Finlet REST surface is `GET /v1/leaderboard` at `finlet/api/routes_leaderboard.py:38` (`"Get the public leaderboard (no auth required)"`). The new public-session routes follow the same pattern. The 404-vs-401 posture is load-bearing: anonymous PATCH visibility returns **401** (`require_user` dep); owner B PATCH-ing owner A's session returns **404** (info-leak parity with `get_user_session`); anonymous GET on a private session returns **404** (matches "not found"). Identical 404 for "not found" vs "not public" prevents enumerating valid session IDs.

## Privacy Posture

`/v1/public/sessions/*` responses NEVER expose:

* `user_id` — would let a scraper link multiple public sessions back to one account.
* Email address.
* `last_used_at` (or any auth-metadata timestamps).
* Idempotency keys, internal IDs, plugin health (reveals which API keys the owner has configured).
* `name`, when `public_anonymous == True` (replaced with the generic label).

The allowlist enforcement is in `_PUBLIC_SESSION_KEYS` (frozen tuple at `finlet/api/services/session_service.py`). A property test (`tests/api/test_public_session_properties.py`) walks the JSON deep-inspection and asserts that none of those keys appear anywhere in the response tree. This is the structural privacy audit point.

## Alternatives Considered

1. **`?demo=<id>` URL-param hack on the existing dashboard.** Rejected — explicitly by user. URL aesthetics are bad ("demo" suggests fake content), the feature wouldn't generalize (every page would need the demo branch), and the entire point of building this is that the agent-driven product is the real artifact.
2. **Static screenshot fallback section on `landing.html`.** Rejected — defers the problem. A screenshot is marketing material; it does not validate the product story. The HN visitor would still bounce because they can't click into a real session.
3. **Public-by-default visibility.** Rejected. Pre-launch with zero customers, surprise factor on launch is too high if existing test sessions go public retroactively. Privacy-conservative default is reversible per-session; public-by-default is not (you can't un-publish data that was crawled).
4. **Single `VisibilityMode` enum (`PRIVATE | PUBLIC_ANONYMOUS | PUBLIC_ATTRIBUTED`).** Considered. Rejected — every future field (`public_token`, `share_expiry`, `public_at`) costs an enum migration. Two orthogonal booleans are structurally cheaper to extend.
5. **Public token model (unguessable share URLs without database visibility flag).** Considered. Useful for v1.1 "private-but-shareable" sessions; orthogonal to the public-by-opt-in flow this decision ships. The two-boolean shape doesn't preclude adding a `public_token: str | None` field later.
6. **Forkable public sessions ("clone this config and run it with my agent").** Out of scope for v1 per handoff § 7 Q3 — adds a write-path. v1 ships share-only. Tracked as a v1.1 candidate.
7. **MCP `get_public_session(session_id)` tool for AI agents browsing the public surface.** Out of scope for v1 per handoff § 6. Anonymous read is HTTP-only for v1; only the owner-write surface (`set_session_visibility`) is exposed via MCP.

## Implementation

Three sequential PRs against `origin/main`:

* **Team A — Backend (PR #65, squash SHA `37ea32f`):** Schema migration `014_add_session_public_columns`, `SessionConfig.public` + `public_anonymous` fields, persistence layer column writes, `public_session_response()` allowlist serializer, 5 anonymous GET routes in `finlet/api/routes_public_session.py`, owner `PATCH /v1/sessions/{id}/visibility`, `session_service.set_visibility()` shared helper, MCP `set_session_visibility` tool, CLI `finlet session publish` subcommand, keep-list entry in `finlet/api/deprecation.py`, full test coverage (E2E, property-based, migration smoke).
* **Team B — Frontend (PR #66, squash SHA `cf81acc`):** New `dashboard/public.html` (auth-chrome-stripped clone of `index.html`), polling-based `dashboard/public.js`, `dashboard/renderers.js` extraction so authenticated dashboard + public view share one render path, `landing.html` top-nav `/pricing` link + curated public-session CTA in the `#demo` section, Starlette `Route` inserts in `finlet/api/app.py` for `/sessions/{id}` and `/public/{id}` (same pattern as `_serve_pricing`).
* **Team C — Docs (this commit):** This decision record + `docs/ARCHITECTURE.md` endpoint + data-model + MCP-tool entries + frontend page mention + migration list entry, `docs/REMAINING_TASKS.md` breadcrumb, `docs/PRIVACY_POLICY.md` opt-in publish paragraph, `.claude/rules/api-routes.md` keep-list entry.

## Cross-references

* `docs/decisions/ui-removal-launch-cut.md` — 2026-05-06 write-path cut that created the surface this feature operates on.
* `docs/decisions/mcp-canonical-surface.md` — MCP is the canonical agent surface; the new `set_session_visibility` MCP tool follows that contract.
* `finlet/api/routes_leaderboard.py:38` — precedent for anonymous public routes on the Finlet REST surface.
* `finlet/api/deprecation.py` — keep-list / sunset table; the `/public/sessions/*` pattern entry was added by Team A so the sunset middleware does not mark these routes deprecated.
* `.claude/rules/api-routes.md` — rules-file mirror of the keep-list, updated by Team C in the same drift-policy pattern as `/oauth/`.

## 2026-05-13 — Followup closures

Three followup items from the original ship closed via the `PUBLIC_SESSION_VIEW_FOLLOWUPS_EXEC_PLAN` (3 parallel teams against `origin/main`):

* **Curated landing CTA wired** (Team A, squash `15371fa`). The `{CURATED_SESSION_ID}` placeholder at `dashboard/landing.html:239` was replaced with the published anonymous session `4a2f92c0438f`. Live at `https://finlet.dev/sessions/4a2f92c0438f` — the public-visit name renders as `"Anonymous Finlet session"`; positions and orders are empty by design (CLI `finlet session create` does not auto-spawn an agent, so the equity curve shows the SPY buy-and-hold benchmark only). The session is anonymized and safe to point at from launch announcements.
* **Accept-routing flipped to HTML-by-default on `/sessions/{id}`** (Team C, squash `f6441dd`). The `_HtmlAcceptRoute.matches()` predicate previously required an explicit `text/html` Accept header to serve `dashboard/public.html`, so default `Accept: */*` and missing-Accept probe/curl traffic fell through to the deprecated JSON endpoint and received the `Deprecation`/`Sunset` headers from the 401 response — a bad UX for any external probe that hit the URL without setting Accept. The predicate is now flipped: default Accept (`*/*` or missing) routes to the public HTML; explicit `Accept: application/json` (without `text/html`) still routes to the deprecated JSON endpoint until the 2026-08-06 sunset. Coverage: `tests/api/test_public_session_accept_routing.py` (5 new tests) plus 7 existing JSON-path call-sites opted in with explicit `Accept: application/json`.
* **E2E coverage** (Team B, squash `7f6ab9c`). New `tests/e2e/journey-18-public-session.spec.ts` (2 tests, 351 LOC) verifies an anonymous visitor can load a published session, see the "Anonymous Finlet session" banner, and observe the equity curve and read-only panels render without 401s. Smoke set extended at `scripts/e2e-smoke.sh:257` so this journey is exercised on every pre-push and CI gate.

**Still deferred** — anonymous rate-limit middleware on `/v1/public/sessions/*` (followups handoff item 2). Per locked decision 7 above, the reverse-proxy floor (Caddy/Cloudflare) plus `RequestSizeLimitMiddleware` remain the v1 posture. No trigger conditions met: no abuse traffic observed, no per-IP rate-limit middleware exists app-side. Re-evaluate post-launch if the public surface is enumerated or scraped at volume.
