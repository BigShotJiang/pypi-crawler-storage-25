# Decision: Triage CLI bugs against working-tree state; mark `skipped-pypi-release-lag` when working tree is correct

**Date:** 2026-05-01
**Iteration:** bug-hunt `20260501T172055Z127b`
**Status:** Active until a release pipeline exists

## Context

`finlet` ships as both an in-repo source-of-truth and a pypi-published wheel
(`pip install finlet`). The pypi build is what real CLI users run; the in-repo
source is what bug-hunt iterations test, fix, and merge against.

There is currently **no automated release pipeline**. A pypi publish is a
manual `python -m build && twine upload` step gated on human action. As a
result, fixes that land on `main` do not reach pypi-installed CLIs until the
next manual release is cut.

This iteration produced two findings (1: `finlet portfolio` `AttributeError`,
4: `finlet plugins list` parity mismatch) where the blind agent's traceback
pointed at `/opt/homebrew/lib/python3.14/site-packages/finlet/cli.py` — the
pypi-installed version — but the working-tree code at the same callsite was
already correct because the bugs had been fixed in earlier iterations
(`cc6cddf` and `1a3c17e` respectively). The blind agent could not have known
this; it walked through the live product as a real user would.

If we had spun fix teams for these findings, they would have produced
"already fixed" no-op diffs, wasted token budget, and muddied the ledger.

## Decision

1. **Bug-hunt iterations triage CLI-only bugs against working-tree state
   first**, not against the pypi-installed CLI binary. If the working tree's
   code at the cited line is already correct, the bug is classified as
   `skipped-pypi-release-lag` in the iteration's `triage.json`, no fix team
   is spun, and the iteration's docs commit notes that the bug closes for
   real users only after the next pypi release.

2. **Triage diagnostic for pypi-release-lag**: compare the blind agent's
   traceback path against the working-tree's line numbers at the same call
   site. If they differ — typically because the pypi build has stale
   docstrings, signatures, or branches — suspect pypi-lag. Confirm by
   `git log --all --oneline -- <path>` against the cited callsite and
   looking for a recent fix commit.

3. **Mark the `retest` envelope `kind: null`** with a description that names
   the fix commit and explains why the retest cannot run from a clean-room
   blind walk against the live site. Phase 5.5 (targeted retest) skips
   `null` kinds.

4. **Track the release as a one-time follow-up** — every iteration that
   produces at least one `skipped-pypi-release-lag` finding adds an action
   item ("cut a pypi release after this iteration") to the iteration's
   `REMAINING_TASKS.md` close subsection. The next iteration verifies the
   release happened by re-walking the same path against the live product.

## Why not just fix it again

Re-shipping the same fix in a no-op diff is dishonest accounting — it
inflates the ledger, gives the appearance of velocity that isn't real, and
trains future iterations to ignore the "is this actually new code?" check.
The honest accounting is: the code is correct, the artifact in production
isn't, the bridge is the release process. Fixing the release process is a
single one-time action, not per-finding work.

## Why not block iterations until pypi releases automatically

Building an automated release pipeline (tag-driven trusted-publisher OIDC
flow on every merge to `main`) is a couple of hours of focused work. It is
the right long-term answer. But the bug-hunt loop runs on a faster cadence
than the operational backlog, and we don't want to halt iterations until
the release pipeline lands. The interim shape — triage against working
tree, mark `skipped-pypi-release-lag`, queue a manual release after the
iteration — closes the gap without blocking the loop.

## Single follow-up

**Cut a pypi release after iteration `20260501T172055Z127b`** so Findings 1
and 4 actually go away for real users. Verify by re-running `finlet
portfolio -s <sid>` and `finlet plugins list` against the live product
post-publish. If a third iteration in a row has `skipped-pypi-release-lag`
findings, escalate the release-pipeline build to top of queue.

## References

- Iteration triage: `docs/bug-hunt/20260501T172055Z127b/triage.json`
- Iteration close: `docs/REMAINING_TASKS.md` ("Bug Hunt 20260501T172055Z127b — Closed")
- Lessons: `docs/LESSONS.md` ("pypi-release-lag is a class of bug")
- Prior fix commits: `cc6cddf` (Finding 1), `1a3c17e` (Finding 4)
