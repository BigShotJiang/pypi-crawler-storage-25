# Decision: MCP `api_key` Tool-Argument Sunset — 90-Day Dual-Accept Window

## RETRACTION 2026-05-11 — Phase 4e Bearer-Only Cutover Reversed

**The Phase 4e Bearer-only cutover (Retraction 2026-05-09) is itself rescinded.** api_key authentication is once again accepted on the MCP tool surface via `Authorization: Bearer fnlt_<key>` HTTP headers and via the CLI's `--api-key` flag.

**Why retract twice in three days?** The v1.0.0 launch (PyPI publish at commit `cbff2e1`) was followed by a blind-walk smoke test (`docs/launch/blind-agent-coldstart-report-v1.0.0-fullwalk.md`) that surfaced BLOCKER #B: the legacy `--api-key` fallback was dead end-to-end. Two structural reasons:

1. The Phase 5 CLI dispatch architecture (`docs/decisions/cli-mcp-stdio-auth.md` — now SUPERSEDED by `cli-mcp-http-dispatch.md`) spawned a fresh `finlet mcp serve` subprocess for every tool call. That subprocess hosted a fresh in-process JWKS that did NOT know the cloud's OAuth signing keys. A cloud-issued JWT presented to the subprocess silently failed validation.

2. Even when the JWT path was sidelined, the Phase 4e cutover had retired the api_key fallthrough from `finlet/mcp/auth.py:_authenticate_oauth_or_key`. So `--api-key fnlt_*` couldn't route through the api_key path either — it always landed in the "Authentication required" envelope.

The v1.0.1 hotfix addresses both with one move: mount FastMCP's `streamable_http_app` on the existing FastAPI app at `/mcp` (so the CLI HTTPs against the cloud's JWKS instead of a subprocess's), AND restore the api_key fallback in `_authenticate_oauth_or_key`. The pre-launch zero-customer mandate (`project_pre_launch_no_customers.md`) makes the retraction safe — there are no consumers to break.

The dual-accept order now matches REST: OAuth JWT preferred; api_key Bearer accepted as compat. Scope enforcement continues to bypass on the api_key path (locked compat — api_keys carry no scope claim).

The Retraction 2026-05-09 entry below is preserved for historical context; treat it as superseded.

## Retraction (2026-05-09)

**The 90-day floor commitment is rescinded.** Finlet has not launched publicly; no api_key consumers exist on the MCP tool surface. Hard cutover ships immediately in Phase 4e (PR #36 / `[Team E1]: bearer-only cutover + Phase 4 SHIPPED`). The "<1% of MCP traffic OR 90 days, whichever is later" criterion in §Phase 5+ no longer applies — there is no traffic to protect.

The original record below is preserved for historical context. Do NOT use it as a current contract source.

---

**Date:** 2026-05-08
**Status:** Accepted
**Source:** MCP-First Migration Phase 4c (Team C1) — three contract points the user locked into the Phase 4c handoff sanity-check on 2026-05-08, captured here so C3 (deprecation log + log-line wording) and E1 (literal sunset date computation) read from one source.

## Context

Phase 4 introduces OAuth 2.1 Bearer authentication on the MCP tool surface (`finlet/mcp/tools_*.py`).  Today every tool carries an explicit `api_key: str | None = None` argument that funnels through `finlet/mcp/auth.py:_authenticate(api_key)`; the MCP spec 2025-11-25 calls this pattern out as token-passthrough — the exact anti-pattern paid GA forbids.  The Phase 4a decision record at `docs/decisions/mcp-oauth-2-1-auth-model.md` locks OAuth as the canonical agent auth (own AS via `mcp[auth]>=1.27.0`, EdDSA JWT, RFC 8707 Resource Indicators, Dynamic Client Registration).

Sub-phase 4c (Resource Server) needs a cutover window — every MCP tool must accept BOTH `api_key` (legacy) and Bearer JWT (canonical) for some bounded time so closed-beta clients don't break the moment the AS goes live.  Without a publicly-committed sunset date, deprecation drifts: integrators have no forcing function to migrate, and the MCP-First master plan's "remove `api_key` parameter from MCP tools entirely" deliverable (per Phase 4a §Consequences) keeps slipping.

The Phase 4a decision record lists "6 months from 4c merge" as the recommended sunset window.  In the Phase 4c handoff sanity-check on 2026-05-08, the user explicitly chose **90 days** instead — faster sunset, more pressure on integrators, and parity with the Phase 3 sunset window already in force on the deprecated REST agent-CRUD aliases (`docs/decisions/mcp-canonical-surface.md` — sunset `2026-08-06`, 90 days from 2026-05-08).

Two adjacent contract points were locked at the same time and are recorded here so the contract is single-sourced:

1. **Fail-mode** — what happens when neither auth credential is presented.
2. **Scope-vs-tier interaction** — what an OAuth scope claim means relative to the existing `UserTier` rate limits and feature flags.

## Decision

The three points the user locked on 2026-05-08:

### 1. Dual-accept window: 90 days from C3 merge SHA timestamp

Every MCP tool MUST accept BOTH:

* The legacy `api_key: str | None = None` argument (resolved via the existing `auth_service.validate_key(api_key)` path).
* An OAuth Bearer JWT (resolved via Team C1's `validate_bearer_jwt(token)` against the in-process JWKS).

…for **90 days** from the timestamp on the C3 merge SHA (the team that wires dual-accept into `finlet/mcp/tools_*.py` — see Team C3 in the Phase 4 exec plan).

Bearer is preferred when both credentials are presented (per A1 §4 — same `UserRecord` resolves through either path, so this is purely a tagging decision; the request still resolves to the same user).  When only `api_key` is presented, the tool path emits a `mcp_auth_deprecated_api_key` structured log entry (`tool`, `user_id`, `sunset_date`) so deprecation traffic can be measured.

The literal sunset date (C3 merge timestamp + 90 days) is computed by Team E1 and persisted into `docs/MCP_OAUTH_MIGRATION.md`.  The exec plan references "C3-merge-SHA + 90 days" as the contractual phrasing; substituting the literal date into the deprecation-log payload happens in E1, not C3.

Removal of the `api_key` parameter (the actual sunset enforcement) is **NOT** Phase 4 work — that is Phase 5+, after the 90-day deprecation traffic decays.  Phase 4c only adds the dual-accept layer and the deprecation log; nothing is deleted.

**Why 90 days and not 6 months?**  The user picked 90 days over the Phase 4a-recommended 6-month default to apply more pressure on integrators and to align with the existing 90-day Phase 3 sunset on REST agent-CRUD aliases.  Both deprecations now share a window length; both surface a `Sunset` / `mcp_auth_deprecated_api_key` signal at deprecation traffic time.

### 2. Fail-mode: fail-closed (401 on neither credential)

When an MCP tool is invoked with NEITHER an `api_key` argument NOR a Bearer JWT in the request context, the tool surface MUST return a 401-shaped error envelope (the existing `{"error": "Authentication required..."}` pattern from `_authenticate(api_key)` is the canonical wording).

There is **no anonymous tier**.  Phase 4 does NOT introduce an "unauthenticated public read-only" path.  Free-tier users authenticate just like paid-tier users; the tier check (`UserRecord.tier`) is downstream of authentication and gates rate limits + feature flags only.

This rule is the contract C3 reads when wiring `_authenticate_oauth_or_key(...)` (Team C2's new dual-accept resolver): if BOTH credentials are absent, raise the existing ValueError that `_authenticate(None)` already raises today — preserving behavior for closed-beta clients that already see this error path.

### 3. Scope-vs-tier: scopes are additional gates inside a tier

OAuth scopes (`finlet:read`, `finlet:trade`, `finlet:benchmark`, `finlet:admin` per `metadata.SUPPORTED_SCOPES`) are ADDITIONAL gates layered on top of the existing `UserTier` rate limits and feature flags.  They DO NOT bypass tier checks.

Concrete contract:

* A FREE-tier user holding a JWT with `scope="finlet:trade"` is still subject to the FREE-tier per-user trade rate limit (`check_trade_rate` in `finlet/api/services/trade_service.py`).  The scope grants the *capability* to invoke trade tools; the tier governs the *budget* for those invocations.
* A FREE-tier user holding a JWT with `scope="finlet:admin"` does NOT get admin features — the admin gate is a tier check (`UserRecord.tier == ENTERPRISE` or equivalent), and the JWT cannot grant a tier the user does not hold.  Issuing such a JWT is allowed (the OAuth client may have been registered with that scope), but the resulting tool calls fail at the tier gate.
* A user upgrading from FREE → BUILDER does NOT need to re-authorize OAuth clients to gain BUILDER-tier rate limits; the JWT carries the tier as a snapshot at issuance time, but the resource server SHOULD re-read `UserRecord.tier` rather than trusting the `finlet:tier` claim for budget decisions (the claim is the tier at issuance; the runtime budget is the tier NOW).

The `finlet:tier` claim in the JWT is informational — it lets the resource server short-circuit obvious mismatches (e.g., a stale FREE-tier JWT being presented after an account downgrade is detected on the next refresh anyway), but the authoritative tier check stays at the service layer.

This is the contract Team C4 reads when implementing the scope→tier mapping: scopes are necessary-but-not-sufficient for tool access; tier checks are sufficient-but-not-necessary (a FREE-tier user can call a tool even without a JWT during the dual-accept window via the api_key path, as long as their tier permits it).

## Consequences

### C3 (this exec plan, blocked by C2)

* Every MCP tool emits `mcp_auth_deprecated_api_key` structured log when it resolves auth via the api_key path.  Fields: `tool` (the tool name), `user_id` (the resolved `UserRecord.id`), `sunset_date` (the C3-merge-SHA + 90-day literal value, populated by E1 — until E1 lands, C3 may use a placeholder constant matching the 90-day intent).
* Tools accept Bearer in addition to api_key.  Bearer wins on both-present.  Neither-present → existing 401-shaped error envelope (fail-closed per §2 above).

### E1 (Phase 4e, after C3 merges)

* Computes the literal sunset date as `<C3 merge timestamp UTC> + 90 days` and substitutes it into:
  * `docs/MCP_OAUTH_MIGRATION.md` — the user-facing migration guide.
  * The `mcp_auth_deprecated_api_key` log payload (replace placeholder constant with literal date).
* Adds a section to `docs/MCP_OAUTH_MIGRATION.md` describing the fail-closed default and the scope-vs-tier interaction documented above.

### Phase 5+ (sunset enforcement — out of Phase 4 scope)

* Removes the `api_key` parameter from every `finlet/mcp/tools_*.py` tool.
* Updates `_authenticate(api_key)` in `finlet/mcp/auth.py` to no longer accept the legacy path.
* Removes the `mcp_auth_deprecated_api_key` log emission (the deprecation has completed).

The actual removal is gated on observed deprecation-log volume reaching <1% of MCP traffic (or 90 days, whichever is later — the date is a floor, not a ceiling).

### Telemetry contract

The `mcp_auth_deprecated_api_key` log line is the single source of truth for deprecation traffic.  Anyone running queries against the structured log stream during the sunset window can compute migration progress from the log alone — no separate metric pipeline is required.  The line's `tool` field segments by tool; the `user_id` field segments by integrator.  Aggregating by `tool` over time lets us answer "which tool is the slowest to migrate?"; aggregating by `user_id` lets us answer "which integrator needs an outreach nudge?".

### Lineage

This decision record cross-references:

* `docs/decisions/mcp-oauth-2-1-auth-model.md` (Phase 4a — locks OAuth 2.1 + DCR + RI as the canonical auth model; §4 locks same-`UserRecord` binding; §Consequences names the 6-month-default sunset window that this record replaces with 90 days).
* `docs/decisions/mcp-canonical-surface.md` (Phase 3 — locks MCP as the canonical agent surface and sets the 90-day Sunset window for REST agent-CRUD aliases — sunset `2026-08-06`).  The Phase 3 sunset is **independent** from this Phase 4 sunset: Phase 3 deprecates the REST→MCP redirect aliases; Phase 4 deprecates the `api_key` argument inside MCP tools.  Do not coalesce them — they touch different surfaces and may have different actual cutover dates if either slips.

The Phase 1 cookie-vs-Bearer auth contract at `docs/decisions/auth-login-cli-vs-api-key.md` is unaffected — that record governs the `finlet auth login` credential-verification mode for the CLI, which is preserved through Phase 4 (Phase 4d only adds OAuth as an additional CLI mode alongside).

## Alternatives Considered

1. **6-month sunset (the Phase 4a §Consequences recommendation).**  Rejected by user choice on 2026-05-08.  Longer windows reduce pressure on integrators and create a longer "dual-mode is the new normal" maintenance burden.  90 days matches Phase 3's window and gives consistent semantics across both deprecations.
2. **30-day sunset.**  Considered.  Rejected as too aggressive — closed-beta integrators (per Phase 4a §Context) include partner agent runtimes whose own release cycles are in the 4-6 week range; a 30-day window would force a rushed migration with no slack.
3. **No sunset, indefinite dual-accept.**  Rejected.  The whole point of Phase 4 is to remove token-passthrough; an indefinite dual-accept window is "Phase 4 not done."  The MCP spec 2025-11-25 calls token-passthrough out by name; paid GA needs to ship without it.
4. **Anonymous tier on tool calls (fail-open).**  Rejected.  Phase 4 has no scenario where unauthenticated tool calls are useful — every tool resolves through `_resolve_session(...)` or service-layer rate gates that need a `UserRecord`.  Fail-open would either silently break (NPE on `user.tier`) or require a synthetic guest user (introducing a parallel-identity concept rejected in Phase 4a §4).
5. **Scopes override tier.**  Rejected.  Tiers are a billing contract (FREE vs paid); allowing a JWT scope to escape tier limits would be a billing bypass.  The user's holding a `finlet:trade` scope means "agent X is allowed to invoke trade tools on behalf of user Y," not "user Y has paid for trade access."  Tier remains the budget arbiter.
6. **Tier overrides scope (no scope check).**  Rejected.  Without scope enforcement, an OAuth client registered with `scope="finlet:read"` could still trade — Phase 4 explicitly differentiates capability-by-scope from budget-by-tier.  Both layers run; both must permit the call.

## References

* MCP spec 2025-11-25 — token-passthrough prohibition (forces this whole sunset cycle).
* RFC 8594 — `Sunset` HTTP header semantics; the deprecation-log payload mirrors the wire-format intent (a date that downstream consumers treat as a contract boundary).
* RFC 6749 §3.3 — OAuth 2.0 scope semantics (granting capability, not budget).
* Phase 3 deprecation precedent: `finlet/api/deprecation.py`, `.claude/rules/api-routes.md`, `docs/decisions/mcp-canonical-surface.md` — the keep-list and sunset-date pattern this record follows.
* Phase 4a decision record: `docs/decisions/mcp-oauth-2-1-auth-model.md` (5 OAuth decisions, including same-`UserRecord` binding the dual-accept window depends on).
* Phase 4c handoff sanity-check, 2026-05-08 (user chose 90 days, locked fail-closed default and scopes-as-gates default in the same conversation).
