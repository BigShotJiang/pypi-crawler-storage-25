# Decision: direct submodule imports for `finlet/auth/oauth/`

**Status:** Accepted
**Date:** 2026-05-17
**Shipping PR:** #91 (squash `93da7a0`)

## Context

`finlet/auth/oauth/__init__.py` was a re-export shim from the MCP-First Phase 4b shipment (2026-05-08, PR #33). It pulled ~45 names from 11 submodules and re-exported them through the package root. The intent was a stable public API surface for both internal callers and external consumers of the OAuth Authorization Server.

In practice, six of the seven submodules inside the package were importing siblings through the package init — e.g. `from finlet.auth.oauth import storage` inside `authorize.py`. Python evaluates `__init__.py` before submodule code runs, so each submodule import of a sibling triggered a re-entry into the package init, which in turn was still importing all the other submodules. The pattern worked because Python caches partial modules during evaluation, but it left seven latent circular-import paths. The 2026-05-13 hygiene audit (Item 1) flagged this as boot-fragility: any new shim consumer added to a submodule, or any reordering of the `__init__.py` imports, could flip the package from "works" to "won't boot" with no test failure on the changed file — the failure would surface in unrelated callers.

This was launch-blocker-class risk: the failure mode is most likely to fire under the kind of small auth tweak that gets rushed in during launch week. Removing the vector altogether is cheap relative to the cost of triaging an ImportError on launch day.

## Decision

Gut the shim. `finlet/auth/oauth/__init__.py` keeps the package docstring (which documents the submodule layout) and nothing else — no `from … import …` lines, no `__all__`. Every consumer — intra-package, production, and test — imports directly from the submodule that owns the symbol.

Style guide for the package:
- **Symbol-level imports preferred:** `from finlet.auth.oauth.storage import insert_client, get_client, ...` over `import finlet.auth.oauth.storage as storage`. Loses one line of locality but makes the dependency surface explicit and lints cleanly.
- **Module aliases when the test is parameterizing module identity:** e.g. `import finlet.auth.oauth.keys as keys_module` is allowed where a test patches multiple attributes on the module object. Tests already used this pattern; preserved as-is.
- **No `from . import X` inside the package** — absolute paths only, to match the rest of `finlet/`.

## Consequences

Positive:
- 7 circular-import paths removed. The package can no longer be broken by adding a new shim consumer or reordering `__init__.py`.
- OAuth public API surface is now the union of submodule public names. External callers (none today; `finlet.auth.oauth` is L3, not part of `finlet`'s public API) would need to import from submodules.
- Reduced surface for the `auth` package: `__init__.py` shrinks from ~120 lines to ~30 (docstring only).

Negative:
- `from finlet.auth.oauth import MCP_RESOURCE_URI` no longer works. One test (`tests/auth/oauth/test_resource_indicator.py`) had to be rewritten to import from `finlet.auth.oauth.resource_indicator` directly. Future consumers will need to use submodule paths.
- The "browseable public API" affordance the shim provided (one place to read what the package exports) is lost. The docstring in `__init__.py` is the substitute — it still names every submodule and what each contains.

## Alternatives considered

- **(ii) Keep narrow public surface.** Re-export only the documented public API (e.g., `oauth_router`, `OAuthClaims`, `validate_bearer_jwt`, `MCP_RESOURCE_URI`) and require internal callers to use submodule paths. Rejected because the boundary between "public" and "internal" was not clearly drawn anywhere, and rolling out the discipline post-hoc would have required new convention documentation. Gutting the shim entirely is a clearer rule.
- **(iii) Status quo + adjust import order.** Reorder `__init__.py` so the cycles always resolve. Rejected because it preserves the fragility — any future edit could break the order without the change being obvious.

## Self-heal note for this shipment

First post-merge `deploy.yml` run on `93da7a0` failed at `test (3.12)` on the known hypothesis flake `test_archive_contains_only_target_user_rows` (`api_keys.key_hash` UNIQUE — also documented in `REMAINING_TASKS.md` 2026-05-16 carry-forward 2). `test (3.13)` passed; PR-gate `ci.yml` had already passed on the PR branch. `gh run rerun 25980977637 --failed` reran only the failed job; second attempt passed → deploy proceeded → prod `/v1/health.git_sha` flipped to `93da7a0`. The hypothesis flake fix remains open.

## References

- MCP-First Phase 4b decision record: `docs/decisions/mcp-oauth-2-1-auth-model.md`
- PR introducing this change: #91
