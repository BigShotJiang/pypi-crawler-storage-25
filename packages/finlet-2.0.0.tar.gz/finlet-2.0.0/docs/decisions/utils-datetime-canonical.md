# Decision: Canonical `ensure_utc` in `finlet/utils/datetime.py`

**Date:** 2026-05-14
**Status:** Accepted
**Context:** Hygiene batch 2026-05-13 (PR forthcoming)

## Problem

`_ensure_utc(dt)` — re-attach UTC tzinfo when SQLite drops it on reload — was duplicated across 4+ source files (`db/persistence.py`, `auth/service.py`, `auth/oauth/storage.py`, `leaderboard/benchmark_plugins.py`) with subtle divergence: `leaderboard/benchmark_plugins.py` used a strict `datetime → datetime` signature while the rest were None-tolerant. This is the I5 item in the hygiene audit.

## Decision

1. **Canonical location:** `finlet/utils/datetime.py`. Stdlib-only leaf (no `finlet.*` imports) → no import-cycle risk.
2. **Public name:** `ensure_utc` (no underscore) — it's exported from a shared utility module.
3. **`@overload` retained** so callers passing `datetime | None` get the matching return type.
4. **Call-site aliasing**: existing 34 call sites + `finlet/auth/__init__.py` re-export keep the `_ensure_utc` symbol. Each consumer imports as `from finlet.utils.datetime import ensure_utc as _ensure_utc`. Zero call-site churn; stable internal API contract preserved.
5. **Leaderboard semantically widens** from strict `datetime → datetime` to None-tolerant. Mypy clean after swap.

## Out of scope

`finlet/plugins/{fundamentals,news,price,sentiment}_plugin.py` retain local `_ensure_utc` copies — `finlet/plugins/` is plugin-team-owned per the file-ownership table. Follow-up tracked as I5-followup in `docs/REMAINING_TASKS.md`.

## Why this is the right shape

- Single source of truth for tz semantics across `db/`, `auth/`, `leaderboard/`.
- Future callers can `from finlet.utils.datetime import ensure_utc` without thinking about None-guards.
- The aliasing trick (`as _ensure_utc`) gave us cross-team unification without breaking the `auth/__init__.py` re-export — which would have rippled through every importer of `finlet.auth`.

## Consequences

- `rg "def _?ensure_utc" finlet/` currently returns 5 (canonical + 4 plugin copies). After I5-followup it will return 1.
- Plugin team gains zero-churn migration path when they get to it.
