# Decision: Exec-Plan auto-resets worktrees post-spawn (retire SendMessage recovery)

**Date**: 2026-04-30
**Status**: Accepted

---

## Context

The exec-plan skill spawns code subagents with `isolation: "worktree"`. The Agent tool's worktree-spawn forks the worktree from `git rev-parse main` AT SPAWN TIME — it does NOT accept a base-commit argument. When pre-flight committed anything (KNOWN_FAILURES.md refresh, plan doc, xfail markers), there was a race window where the worktree forked one or two commits behind `spawn_base_sha`.

The original SKILL.md offered a manual recovery: orchestrator detects drift, sends a `SendMessage` to the agent with `git reset --hard <spawn_base_sha>` instructions, agent confirms the worktree is clean, resets, acknowledges, continues.

This recovery WORKED, but it was load-bearing process — every refactor incurred a ~5-minute orchestrator-handholding tax. Worse, the assertion EP-08 in `.claude/skills/exec-plan/eval.md` graded "spawn forked from spawn_base_sha" — which the recovery couldn't satisfy, so EP-08 reported FAIL in three consecutive refactors:

- 2026-04-29 — modal-stacking
- 2026-04-29 — dirty-state-tracker v2
- 2026-04-30 — trade-ticket-state-sync (commit `efdd443`)

Three instances of the same shape across three exec-plan runs is the same forward-signal threshold the Refactor Gate uses for product code — so it applies here too.

---

## Decision

**The main agent now performs the reset directly, immediately after the Agent tool returns the worktree path, BEFORE the subagent has a chance to write any files.** The SendMessage recovery roundtrip is retired.

Concretely, in SKILL.md Step 2 LAUNCH, the orchestrator's flow is:

1. Spawn the code subagent with `isolation: "worktree"` and `run_in_background: true`. The Agent tool returns synchronously with the worktree path; the subagent begins running asynchronously.
2. **Immediately** (in the same tool round, before reading any other tool result):
   - Run `git -C <worktree-path> rev-parse HEAD`.
   - Run `git -C <worktree-path> reset --hard <spawn_base_sha>`. This is unconditional — if HEAD already matches, the reset is a no-op; if it doesn't, the reset corrects it.
   - Verify with `git -C <worktree-path> rev-parse HEAD` — must equal `spawn_base_sha`.
3. Only after verification proceed to the WAIT phase (await the subagent's completion notification).

The reset is safe at this point because:

- The worktree is on a fresh branch with no commits.
- The working tree is clean (the Agent tool just created the worktree; no edits yet).
- The Agent tool's `run_in_background: true` returns BEFORE the subagent's first tool invocation — there's a deterministic window (typically 50-200ms) in which the orchestrator's reset lands before the subagent starts.

If the reset somehow fails (rare — would imply git lock contention from another concurrent worktree operation), the orchestrator aborts the spawn, runs `git -C <worktree-path> rev-parse HEAD` to confirm the actual base, and either retries the reset or respawns the worktree after main HEAD is verified to be `spawn_base_sha`.

---

## Justification

- **Removes the 5-minute SendMessage tax per refactor.** The reset happens in microseconds, not in a roundtrip.
- **Removes the unsafe-recovery failure mode.** The previous SendMessage path had a theoretical race: agent could write files before the orchestrator detected drift and sent the message. With the new path, the reset happens BEFORE the subagent starts, so there's nothing to lose.
- **Idempotent.** Running `reset --hard <sha>` when HEAD already equals `<sha>` is a no-op. Always-resetting is cheaper than detect-then-maybe-reset, and removes a branch in the orchestrator's logic.
- **Preserves the spawn primitive contract.** The Agent tool still spawns from main HEAD; we don't try to inject a base argument it doesn't support. The reset is purely orchestrator-side.
- **Eliminates EP-08 false-FAIL.** With auto-reset, EP-08 grades "worktree base = spawn_base_sha after orchestrator reset" — which always holds (or aborts the spawn).

---

## Consequences

- **Anti-Pattern #13 evolves.** Was: "Spawning worktrees without pinning the base." Now: "Skipping the post-spawn reset call." The race is now handled deterministically; the failure mode is forgetting the reset.
- **Eval EP-08 is refined.** Grades drift-handled-cleanly rather than initial-spawn-perfect. See updated `.claude/skills/exec-plan/eval.md`.
- **Future skills reusing the worktree pattern inherit this convention.** Any other skill (e.g., a hypothetical `/refactor-team` or `/explore-impl`) that spawns code subagents with `isolation: "worktree"` should adopt the same post-spawn reset.
- **Upstream feature request still useful.** A native `isolation: "worktree", base: "<sha>"` Agent-tool argument would make this workaround unnecessary. Filing the request remains worthwhile (zero local cost, potential future cleanup) but the local fix is no longer blocked on it.

---

## Reversal path

Single-commit revert. Reverts SKILL.md Step 2 LAUNCH back to the SendMessage recovery flow, reverts eval.md EP-08 to its prior wording, reverts Anti-Pattern #13 wording. ~30 LOC change. The decision is small enough that reversal is mechanical if the auto-reset turns out to interact badly with some future Agent tool change.

---

## Observed evidence (from prior iterations)

The recovery worked correctly in 3/3 cases under the OLD flow:

- 2026-04-29 modal-stacking — drift detected, recovered, refactor shipped clean
- 2026-04-29 dirty-state-tracker v2 — drift detected, recovered, refactor shipped clean
- 2026-04-30 trade-ticket-state-sync — drift detected, recovered, refactor shipped clean (commit `efdd443`)

The new flow is functionally identical to the old recovery — it just removes the SendMessage roundtrip. Risk of regression is bounded.

---

## Related

- `.claude/skills/exec-plan/SKILL.md` Step 2 LAUNCH — the canonical implementation.
- `.claude/skills/exec-plan/eval.md` EP-08 — the refined assertion.
