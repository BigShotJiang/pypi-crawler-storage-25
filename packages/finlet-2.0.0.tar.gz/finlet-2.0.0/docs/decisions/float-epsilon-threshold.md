# Decision: Float Epsilon Threshold for Position Dust Cleanup

**Date**: 2026-03-28
**Status**: Resolved
**Context**: After many buy/sell cycles, floating-point arithmetic leaves tiny residual quantities (e.g., `1e-14`) on positions. These phantom positions pollute the portfolio, affect metric calculations, and confuse agents.

---

## Problem

`Position.quantity` is a Python `float`. Repeated buy/sell operations accumulate IEEE 754 rounding errors. The previous cleanup guard (`quantity <= 0`) only caught exact-zero and negative values, missing positive dust like `1e-14` or `2.2e-15`.

---

## Options Evaluated

### 1. Use `Decimal` for all quantities (rejected for now)

Replace `float` with `Decimal` throughout the portfolio, order, and position models.

**Pros**:
- Eliminates the root cause of float dust.
- Correct by construction.

**Cons**:
- Invasive change touching every model, serialization path, and test.
- `Decimal` has performance overhead and JSON serialization friction.
- Overkill for the current problem — dust is only an issue at cleanup boundaries, not during arithmetic.

### 2. Epsilon tolerance at cleanup boundary (accepted)

Add a constant `EPSILON = 1e-9` and treat any quantity below it as zero during position cleanup in `_execute_sell_unlocked()`.

**Pros**:
- Minimal, targeted change (one constant, one comparison).
- `1e-9` is 6 orders of magnitude above typical float dust (`~1e-15`) and 6 orders below any meaningful share quantity (`0.001` for fractional shares).
- Easy to understand, test, and adjust.

**Cons**:
- Does not fix the root cause — dust still accumulates, just gets cleaned up.
- If fractional share quantities go below `1e-9` in the future, the threshold would need revisiting.

### 3. Round quantities to N decimal places after each operation (rejected)

Apply `round(quantity, 9)` after every arithmetic operation on quantities.

**Pros**:
- Prevents dust from accumulating at all.

**Cons**:
- Must be applied consistently everywhere — easy to miss a code path.
- Rounding during intermediate arithmetic can compound errors differently than rounding at boundaries.
- More invasive than option 2 with no additional safety benefit for the current use case.

---

## Decision

Option 2: `EPSILON = 1e-9` at the cleanup boundary. The value `1e-9` was chosen because:

1. **Well above float noise floor**: IEEE 754 double-precision has ~15-16 significant digits. For quantities in the range of 1-10000 shares, dust appears at ~`1e-12` to `1e-14`. `1e-9` is safely above this.
2. **Well below meaningful quantities**: The smallest meaningful fractional share in real markets is `0.001` (some brokers). `1e-9` is 6 orders of magnitude smaller.
3. **Standard practice**: `1e-9` is a widely used epsilon in financial software for this purpose.

If Finlet later supports sub-penny fractional shares or switches to `Decimal`, this threshold should be revisited.

## Consequences

- Phantom positions are cleaned up immediately after sell execution.
- Portfolio metrics (position count, win rate) are no longer polluted by dust positions.
- Cash rounding remains a separate concern (deferred — see REMAINING_TASKS.md).
