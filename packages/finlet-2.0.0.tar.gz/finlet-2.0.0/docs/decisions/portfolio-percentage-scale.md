# Decision: Portfolio Percentage Metrics Use Percentage Scale, Not Decimal Fractions

**Date:** 2026-04-10
**Status:** Accepted
**Source:** FIELD_AUDIT_FIXES sprint, Team C

## Context

`PortfolioMetrics.total_return_pct` and related `*_pct` fields previously returned decimal-fraction values — e.g. a 7.31% return was represented as `0.0731`. The naming was misleading: the `_pct` suffix on the field implies percentage scale, but the value was a fraction.

Downstream renderers had to multiply by 100 to display correctly. Some callers did (the bull-run script, parts of the leaderboard reporting) and some did not (the dashboard, certain REST response schemas, a handful of leaderboard reporting paths). The result: the same portfolio would show `7.31%` in one place and `0.07%` in another. Field audit testing surfaced the dashboard and leaderboard mismatch as user-visible bugs.

## Decision

**All `*_pct` fields on `PortfolioMetrics` return percentage scale** — `5.0` means 5%, not `0.05`. This applies to:

- `unrealized_pnl_pct`
- `total_return_pct`
- `benchmark_return_pct`
- `alpha_vs_benchmark`

The convention propagates through the pipeline:

- `finlet/core/portfolio.py` — computes metrics in percentage scale
- `finlet/api/schemas/portfolio.py`, `finlet/api/schemas/session.py` — REST response schemas match
- `finlet/leaderboard/scoring.py` — `compute_composite_score()` accepts percentage-scale input; its sigmoid range mapping is calibrated accordingly
- `finlet/leaderboard/reporting.py` — no longer multiplies by 100 when rendering `return_pct`
- `dashboard/app.js` — renders `value + "%"` directly without `* 100`
- `scripts/run_bull_run.py` — divides by 100 for the fraction-scale column used in CSV export

`ScenarioResult.return_pct` and `ScenarioScore.total_return_pct` (stored in the leaderboard DB) also hold percentage-scale values.

## Consequences

- Clients consuming the REST API or MCP portfolio responses should render `value + "%"` and must NOT multiply by 100. This is a user-visible API contract change; external consumers of these fields need to adapt.
- The leaderboard DB stores percentage-scale values going forward. Historical leaderboard rows written before this change held decimal-fraction values. Because these rows are part of the composite-score training distribution and not user-visible raw numbers, they were not backfilled. Future `recalculate_rankings` runs may produce slightly different normalized scores until old rows roll out of the active window.
- Tests under `tests/core/test_portfolio.py` and related leaderboard/schema tests were updated to assert on percentage-scale values.
- The `_pct` naming now matches the value: the suffix means "percentage", and the number is the percentage.
