# Decision: structlog `cache_logger_on_first_use` Workaround for `tests/integration/`

**Date:** 2026-05-09
**Status:** Accepted (interim — proper fix tracked in `docs/REMAINING_TASKS.md` Phase 4d follow-up)
**Source:** MCP-First Migration Phase 4d Team D2 (commit `c013563` + fixups `a2f3fc5`, `6569c24`)

## Context

`tests/integration/` (added in Phase 4d/D2) is a new tier above `tests/api/` and `tests/mcp/` for true end-to-end flows that require a running HTTP/MCP server (not a `TestClient`). The session-scoped `live_server` fixture runs the FastAPI app via `uvicorn` programmatically; the lifespan calls `finlet.logging.configure_logging()`, which calls `structlog.configure(..., cache_logger_on_first_use=True, processors=[..., wrap_for_formatter])`.

Once a Finlet module-level logger has been resolved through that cached chain, `structlog.testing.capture_logs()` in any later test can NEVER inject its tap into that logger's chain — cached `BoundLoggerLazyProxy` instances do not re-bind on subsequent `configure(...)` calls. The cache lives in `BoundLoggerLazyProxy._logger`, which is set the first time the lazy proxy is dereferenced and then never refreshed.

Six attempted fixes were tried during D2 development, each leaving 8-10 deterministic cross-directory failures (`tests/mcp/test_oauth_dual_accept.py`, `tests/plugins/test_news_plugin.py`, `tests/plugins/test_price_plugin.py`):

1. Pre-emptive `structlog.reset_defaults()` before `live_server` boots.
2. Eager restore of `structlog.configure` after `create_app()` returns.
3. Monkeypatch on `finlet.logging.configure_logging` to make it a no-op.
4. Monkeypatch on `finlet.api.app.create_app` to skip lifespan logging setup.
5. Monkeypatch on `structlog.configure` held to teardown.
6. Function-scoped autouse fixture rebinding all module-level loggers.

All six failed because the cached proxies in modules imported during `create_app()` outlive any snapshot/restore cycle.

## Decision

A three-layer interim workaround, layered to avoid the irreducible cache-pollution problem:

### 1. `live_server` monkey-patches `structlog.configure` for `cache_logger_on_first_use=False`

```python
_orig_configure = _structlog.configure

def _no_cache_configure(*args: Any, **kwargs: Any) -> None:
    kwargs["cache_logger_on_first_use"] = False
    return _orig_configure(*args, **kwargs)

_structlog.configure = _no_cache_configure
```

Applied for the entire fixture lifetime (not just `create_app()`) because the lifespan runs lazily on the uvicorn thread, well after `create_app()` returns. With caching disabled, loggers used during create_app's plugin init dynamically rebuild their processor chain on every call, so future `capture_logs()` taps work.

### 2. `_redirect_home_for_session` rebinds `finlet.mcp.bearer_context.logger` per test

```python
import structlog as _structlog
_structlog.reset_defaults()
import finlet.mcp.bearer_context as _bc_mod
_bc_mod.logger = _structlog.get_logger("finlet.mcp.bearer_context")
```

The bearer_context module-level proxy was bound to the polluted JSON renderer chain during the live-server lifespan and ignored `capture_logs()` even after `reset_defaults()` (proxy resolution had already cached the polluted chain). Rebinding the module-level attribute forces a fresh `BoundLoggerLazyProxy` whose first deref happens INSIDE the active `capture_logs()` block.

### 3. `pytest_collection_modifyitems` forces integration tests to collect LAST

```python
def pytest_collection_modifyitems(config, items):
    integration_items = [item for item in items if "tests/integration/" in str(item.fspath)]
    other_items = [item for item in items if "tests/integration/" not in str(item.fspath)]
    items[:] = other_items + integration_items
```

Defense in depth — even if layers 1+2 leak, by ordering `tests/integration/` LAST any residual structlog pollution can no longer bleed forward into `capture_logs()`-using tests in `tests/mcp/` etc.

## Alternatives Considered

1. **Drop `cache_logger_on_first_use=True` from `finlet/logging.py`.** Correct long-term fix — see "Future Work" below. Rejected for D2 because Phase 4d scope is bounded to CLI + integration tests; the runtime-logging refactor is a separate work item with its own test surface and rollout risk.
2. **Subprocess uvicorn instead of in-process thread.** Would isolate structlog state cleanly. Rejected because subprocess startup overhead would multiply integration test runtime ~10x (the whole point of `live_server` is sub-1s per session).
3. **Snapshot-and-restore the structlog `_CONFIG` private state at fixture teardown.** Attempted (variant of #5 above); fails because cached `BoundLoggerLazyProxy._logger` instances held by Finlet modules outlive the snapshot.
4. **Force every test to use `caplog` (pytest-logging) instead of `capture_logs`.** Would require rewriting ~30 tests across `tests/mcp/`, `tests/plugins/`, etc. The structlog→stdlib bridge is fragile (some processors don't propagate). Rejected as scope creep.

## Consequences

- 8 integration tests in `tests/integration/test_mcp_oauth_e2e.py` pass deterministically.
- The cross-directory regression suite (8 tests in `tests/mcp/test_oauth_dual_accept.py` + 2 in `tests/plugins/test_{news,price}_plugin.py`) keeps passing because integration tests collect LAST.
- The conftest carries 60+ lines of inline rationale explaining why the workaround exists — future agents touching `tests/integration/conftest.py` see the context immediately.
- Test-infra ergonomics for the `tests/integration/` tier are slightly degraded — adding a new module-level structlog logger to a Finlet module that an integration test inspects via `capture_logs()` requires adding the rebind line to `_redirect_home_for_session`. Acceptable since the integration tier is small (8 tests today; expected to stay under ~30 through Phase 4e).

## Future Work

The proper structural fix is removing `cache_logger_on_first_use=True` from `finlet/logging.py` and switching to a non-caching processor chain. Tracked in `docs/REMAINING_TASKS.md` under the Phase 4d entry. Likely landing in Phase 4e or shortly after — Phase 4e already touches the auth/test surface for the api_key sunset flip, and consolidating the test-infra cleanup with that work avoids two churn waves on the same files.

When the underlying fix lands, this decision record can be marked `Superseded` and the conftest workaround code removed (the `pytest_collection_modifyitems` ordering can stay as defense in depth).

## Lineage

- `finlet/logging.py` — root cause (`cache_logger_on_first_use=True`)
- `tests/integration/conftest.py:62-87, 110-200, 264-283` — workaround sites
- `docs/decisions/auth-login-cli-vs-api-key.md` (Phase 4d addendum) — companion decision for the CLI side of D1/D2
- `docs/decisions/mcp-oauth-2-1-auth-model.md` (Phase 4a) — locks the OAuth model the integration tests exercise
