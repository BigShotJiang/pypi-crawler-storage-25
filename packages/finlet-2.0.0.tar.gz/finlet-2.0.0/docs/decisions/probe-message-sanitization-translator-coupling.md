# Probe Message Sanitization: Topology-Free Wording + Translator-Stability Coupling

**Status:** Adopted
**Date:** 2026-05-02
**Iteration:** bug-hunt `20260502T142726Z7b36` (Team B, commit `ad0adb0`, merge `59d56e3`)
**Files:** `finlet/plugins/price_plugin.py`, `finlet/plugins/news_plugin.py`, `finlet/plugins/fundamentals_plugin.py`, `finlet/api/routes_health.py`

## Context

A blind-agent walkthrough surfaced the internal Terraform-suffixed bucket name `finlet-data-cccdea31` leaking verbatim into user-facing plugin error copy whenever an S3 query failed. Three plugins (`price_plugin`, `news_plugin`, `fundamentals_plugin`) constructed user-facing error strings via f-strings that interpolated `self._bucket` and the `s3://` scheme directly. Two distinct problems collapsed into one finding:

1. **Info leak**: agents and dashboard consumers got infrastructure topology (bucket name, env-suffix, scheme) baked into the response payload. Free reconnaissance signal for attackers (env stage, naming convention, suffix format); zero actionable signal for honest users.
2. **Translator coupling**: the `routes_health._check_price_data_status` translator inspects the plugin error message for the substring `"S3 unreachable"` to map the failure mode to the `s3_unreachable` health code consumed by Settings + the dashboard Plugin Health widget. The error message is therefore not just user copy — it is also a load-bearing input to a downstream keying layer.

Sanitizing the error message naively (drop the bucket, keep the rest) would have been straightforward, but ad-hoc rewording would have silently broken the translator: a probe message of `"S3 connection failed"` reads fine to a human but maps to nothing in the translator and surfaces as a generic `unhealthy` instead of the specific `s3_unreachable`.

## Decision

**The user-facing plugin error wording is now a fixed convention with two coupled rules:**

### Rule 1: No infra topology in user-facing copy

Plugin error strings (and any user-facing message that surfaces upstream-failure context) MUST NOT contain:

- Bucket names (`finlet-data-cccdea31`, etc.)
- `s3://` URIs
- Env-suffixed identifiers (`-cccdea31`, `-prod`, etc.)
- IAM role ARNs
- File paths under `/opt`, `/var`, etc.
- Region codes
- IP addresses
- Internal hostnames

Operators get the full context via `structlog.bind(bucket=self._bucket, key=...)` structured logs (preserved in all S3-backed plugins). Users get an actionable but topology-free summary, e.g.:

- `"S3 unreachable: price data store cannot be listed. Check network connectivity and AWS credentials."`
- `"S3 price data unreachable for 'AAPL'. 3 date(s) failed to download. Check network connectivity and AWS credentials."`

### Rule 2: Pin the translator-keyed substring as a fixed convention

When a phrase in the error message is consumed by a downstream layer for keying — currently only `"S3 unreachable"` mapping to `s3_unreachable` in `routes_health._check_price_data_status` — that phrase is part of the response contract. Pin it. Any rewording of the user-visible part must preserve the translator-keyed substring verbatim.

Three plugins emit `"S3 unreachable"` today: `price_plugin._probe()`, `news_plugin` (S3 listing failures), and `fundamentals_plugin` (S3 listing failures). All three converge on the same wording so the translator behaves uniformly across plugin types.

## Alternatives Considered

### A. Drop the translator entirely; have plugins return a structured error code

Rejected for now. Would require changing `PluginResponse` to carry a discriminated `error_code` enum, updating every caller (plugin clients, Settings, Plugin Health widget, CLI), and migrating tests. Not justified by the immediate severity — the substring-based translator has worked since 2026-05-01 and the coupling is documented and lint-able. Worth revisiting only if a third translator-keyed substring emerges (the current translator owns one substring; two would still fit a regex; three or more is a code smell).

### B. Add a separate metadata field on the response (`error_topology = "S3"` etc.)

Rejected. Same migration cost as A, with the additional downside that the wording and the metadata can drift — two sources of truth for "what failed and why." The existing single-field substring approach is fragile but consistent.

### C. Sanitize via regex post-hoc in the response middleware

Rejected. A regex that strips `s3://` URIs and bucket-shaped tokens would be over-aggressive (false-positives on tickers like `S3-USD`) or under-aggressive (misses new env-suffix patterns). Source-side sanitization is precise and reviewable.

## Implementation

`price_plugin.py` (illustrative; same shape applied to `news_plugin.py` and `fundamentals_plugin.py`):

```python
# Generic copy: no infra topology (no bucket name, no s3:// scheme)
# leaks into user-facing error strings. Operators get the full
# path via structured logs; users get an actionable summary.
error = (
    f"S3 price data unreachable for '{ticker}'. "
    f"{s3_failures} date(s) failed to download. "
    f"Check network connectivity and AWS credentials."
)
```

Probe-side error in `_probe()`:

```python
return ProbeResult(
    status="degraded",
    message=(
        "S3 unreachable: price data store cannot be listed. "
        "Check network connectivity and AWS credentials."
    ),
)
```

The `routes_health._check_price_data_status` translator (unchanged) continues to map the substring `"S3 unreachable"` → `s3_unreachable`.

## Reversal Path

Single revert per plugin file (~3 mechanical reverts of f-string interpolation) to restore the leak; the translator is unchanged either way. Not recommended — re-introducing the leak is strictly worse on every axis (security, UX, accessibility for screen-reader users who hear the bucket name read out as gibberish).

## References

- Bug-hunt iteration `20260502T142726Z7b36` — Finding B (info-leak-in-error-copy)
- Triage report: `docs/bug-hunt/20260502T142726Z7b36/triage.md` (Finding B)
- Pinned wording in `routes_health._check_price_data_status` (the translator that consumes the substring)
- Lesson in `docs/LESSONS.md` ("No infra topology in user-facing error copy") — the class-of-mistake rule for future plugins
