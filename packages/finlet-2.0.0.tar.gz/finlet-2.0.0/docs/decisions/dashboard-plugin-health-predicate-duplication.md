---
date: 2026-05-06
status: accepted
related:
  - docs/bug-hunt/20260506T061637Z6594/plan.md
  - docs/bug-hunt/ledger.jsonl
  - finlet/plugins/base.py
  - dashboard/app.js
  - dashboard/settings.js
  - tests/dashboard/plugin-health-dot.spec.js
---

# Dashboard plugin-health predicate — accept duplication, pin both copies

## Context

Bug-hunt iteration `20260506T061637Z6594` surfaced one real-broken finding:
the canonical server enum at `finlet/plugins/base.py:135-140`
(`PluginHealthStatus = {HEALTHY, DEGRADED, UNHEALTHY}`) emits
`status='unhealthy'` for any plugin where `_initialized=False` (per the
base-class `health_check` fall-through at `:246-256`). Two dashboard
predicates consume that field:

- `dashboard/app.js:2458-2465` — `dotClass` ternary, sidebar Plugin Health panel.
- `dashboard/settings.js:1057-1060` — `healthClass` ternary, Settings → Plugins page.

Both predicates terminated with `: status === 'error' ? 'error' : 'unknown'` —
neither knew the canonical server vocabulary `'unhealthy'`. Three live plugins
(`fred`, `finnhub`, `edgar`) reached the predicates with `status='unhealthy'`,
fell through to the gray `'unknown'` bucket, and rendered as gray "Unknown"
dots instead of red "Error" — uninitialized plugins indistinguishable from
unknown-state plugins on the UI. (See iteration plan + triage for the live
API + live DOM evidence.)

The fix shipped by Team A (commit `407a1bb`, merge `89035a3`) extends both
predicates' error arms to `(status === 'error' || status === 'unhealthy') ? 'error' : 'unknown'`.
That's a one-line change in two files. The fix is correct.

This decision record explains why the fix LEFT the predicate duplicated in
two files instead of extracting a shared module.

## Decision

**Keep the predicate duplicated in `dashboard/app.js` and `dashboard/settings.js`.
Pin both copies with byte-equality assertions in
`tests/dashboard/plugin-health-dot.spec.js` so any drift between them breaks
the unit suite at `node --test` time. Do not extract a shared module
(`dashboard/plugin-health-predicate.js`) in this iteration.**

## Rationale

### 1. Refactor-gate trade-off — single bug, two copies, low recurrence cost

The convention used across prior bug-hunt iterations is the
"three-instance refactor gate": before extracting a shared module, the
duplication must have produced a recurring bug across at least three
iterations. This iteration is the FIRST instance of the predicate-drift bug.
Promoting a one-instance shape into a refactor would trigger:

- A new file (`dashboard/plugin-health-predicate.js`).
- Module-loading wiring in both `dashboard/index.html` and
  `dashboard/settings.html` (script include order, dependency on existing
  IIFE patterns or window-scope publication).
- A migration of the consumer call sites in both `app.js` and `settings.js`
  to delegate to the shared module.
- A new decision record documenting the shared module's contract and CSS
  bucket conventions.
- A new unit test for the shared module + an updated `node --test` suite to
  exercise both consumers via the module instead of inline.

Cumulative cost: ~3-4 files of churn, 100+ LOC migration, an additional
review cycle. Cumulative benefit: one byte-saved next time the same enum
gains a new value.

The byte-equality unit test in `tests/dashboard/plugin-health-dot.spec.js`
captures the same "drift between the two copies fails loudly" guarantee at
~1/10 the migration cost and zero risk of a parallel-extraction regression
in a category that already has multiple shipped refactors with
`category: dashboard-state-sync` (see refactor queue:
`stat-card-overflow-contract`, `trade-ticket-state-sync-v3`,
`plugin-config-propagation`).

### 2. The unit test pins the contract better than a shared module would

The new spec at `tests/dashboard/plugin-health-dot.spec.js` does two things
that a naive shared-module extraction would NOT do:

- Loads each dashboard JS file via `vm.createContext` + `fs.readFileSync`,
  extracts the predicate substring between fixed string anchors, and `eval`s
  the actual predicate body. Drift in either source file (typo, accidentally
  deleted arm, server-enum addition without a predicate update) breaks the
  assertions immediately.
- As belt-and-braces, asserts each extracted predicate string byte-for-byte
  against an authoritative copy at the top of the spec. A future predicate
  refactor must update both copies in lockstep or the byte-equality
  assertion fires.

A shared-module extraction would replace one file's duplication with
intra-test duplication (the test file would still need to assert the
shared-module contract holds for ALL canonical enum values + aliases) and
add a runtime indirection layer that no other dashboard module currently
needs. The unit test's value is the same in both architectures; the file
count is lower in the duplicated architecture.

### 3. The two predicates are byte-equivalent but not behaviorally identical

The two CSS bucket alphabets differ slightly:

- `dashboard/app.js` returns `'ok' | 'degraded' | 'error' | 'unknown'`,
  matching `dashboard/styles.css:1213-1228` (`--ok`, `--degraded`, `--error`,
  `--rate-limited`, `--unknown` — five buckets, one of which (`'rate-limited'`)
  the predicate does not currently emit but is reserved for future use).
- `dashboard/settings.js` returns `'healthy' | 'degraded' | 'error' | 'unknown'`,
  matching `dashboard/settings.css:711-721` (`--healthy`, `--degraded`,
  `--error`, `--unknown` — four buckets, no `--rate-limited` reservation).

A shared module that returns one canonical bucket name (e.g., `'ok'`) would
require either:

- Renaming one of the two CSS class systems (touching `styles.css` and
  `settings.css` in the same diff, expanding the blast radius) — OR
- A second tiny mapping function inside each consumer that maps the shared
  bucket onto the consumer-specific CSS class.

Neither path saves churn over keeping the predicate duplicated and
pinned. The duplication is honest about the fact that two different visual
systems consume the same server enum with two different bucket alphabets.

### 4. CLAUDE.md doc-touch rule is satisfied without ARCHITECTURE.md drift

If a shared module had been extracted, ARCHITECTURE.md would need a new
bullet documenting "all dashboard plugin-health predicates go through
`dashboard/plugin-health-predicate.js` — direct ternaries on
`status === 'healthy'` are forbidden". That bullet would join the existing
list of dashboard conventions (`form-dirty-tracker.js`,
`dialog-state-mirror.js`, `event-bus.js`, `onboarding.js` registries) — five
conventions today, six post-extraction. The marginal value of a sixth
convention for a single-file enum mapping is low; the marginal cost of
documenting the convention (and lint-enforcing it via a new
`scripts/lint-plugin-health-predicate.sh`) is real.

Keeping the predicate duplicated keeps ARCHITECTURE.md unchanged this
iteration (predicate alignment, no surface change). The unit test is the
contract; the contract lives next to the consumers.

## Consequences

### Positive

- Minimal blast radius: one-line change in each of two files plus one new
  test file. Zero ARCHITECTURE.md / CLAUDE.md / lint-script churn.
- Drift detection at unit-test time rather than runtime — the byte-equality
  assertion fires the moment either predicate diverges from the canonical
  copy in the spec.
- Each consumer keeps its consumer-specific CSS bucket alphabet without
  routing through a shared canonical name + reverse mapping.

### Negative / accepted risks

- **Drift risk between the two copies.** Mitigated by the byte-equality
  assertion in the spec — the only path for the two copies to drift without
  CI catching it is for a developer to update the spec's authoritative copy
  AND both source files in lockstep, which is the contract this decision
  enforces.
- **Recurrence risk on a third predicate copy.** If a future dashboard
  surface (e.g., `dashboard/marketplace.js` for a strategy-health badge,
  `dashboard/leaderboard.js` for an agent-status pill) adds a third
  predicate of the same shape, the three-instance refactor gate trips and
  this decision flips. At that point, extraction becomes net-positive (one
  shared module replaces three copies + the lint cost amortizes across
  three consumers).
- **Server-enum-addition risk.** If `PluginHealthStatus` gains a new value
  (e.g., `RATE_LIMITED`), both predicates' fall-through bucket changes
  silently for that new value. Mitigated by the test table being
  source-of-truth-driven (the spec exercises every enum value plus every
  alias) — a new enum value means a new row in the test table, which is
  caught at PR review time and at CI gate.

## Verdict — when this decision flips

Set `verdict: pending → flip` if any of the following becomes true:

1. A third dashboard surface adds the same predicate shape (`status === 'X' ? bucket : ...`)
   for `PluginHealthStatus` or any other server-emitted enum. At three
   instances the refactor gate routes to extraction.
2. The byte-equality assertion produces a false-positive twice in a quarter
   (i.e., predicates legitimately need to differ for reasons other than CSS
   bucket alphabet). At that point the spec's pinning model is the
   bottleneck and a shared module + per-consumer mapping function becomes
   the cleaner contract.
3. ARCHITECTURE.md gains another dashboard-convention entry that touches
   plugin-health (e.g., a third surface or a server-side enum convention
   that the dashboard must propagate). At that point the shared module is
   one of several dashboard-convention surfaces and naming it explicitly is
   net-positive for new-contributor onboarding.

Until any of those conditions hold, accept the duplication and let the unit
spec carry the contract.

## References

- Iteration plan: `docs/bug-hunt/20260506T061637Z6594/plan.md` (Team A spec
  — agent instructions explicitly forbid extracting a shared module:
  "Extracting the predicate to a shared module is OUT OF SCOPE for this
  iteration — do NOT refactor.").
- Server enum: `finlet/plugins/base.py:135-140` (`PluginHealthStatus`).
- Server fall-through: `finlet/plugins/base.py:246-256`
  (base-class `health_check` returns `UNHEALTHY` for `_initialized=False`).
- Predicate sources: `dashboard/app.js:2458-2465`,
  `dashboard/settings.js:1057-1060` (post-fix from `407a1bb`).
- Unit test: `tests/dashboard/plugin-health-dot.spec.js`.
- Refactor-queue precedents (dashboard-state-sync category):
  `docs/bug-hunt/refactor-queue/stat-card-overflow-contract.md`,
  `docs/bug-hunt/refactor-queue/trade-ticket-state-sync-v3.md`,
  `docs/bug-hunt/refactor-queue/plugin-config-propagation.md`.
