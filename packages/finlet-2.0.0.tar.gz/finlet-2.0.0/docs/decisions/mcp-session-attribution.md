# Decision: MCP Session Attribution via `user_id="mcp"`

**Date:** 2026-03-28
**Status:** Superseded by `mcp-auth-mandatory.md` (2026-03-30)
**Context:** MCP session lifecycle tools (create_session, list_sessions, get_session, delete_session)

## Problem

MCP tools need to create sessions, but MCP runs over stdio — a single-tenant, process-level trust model with no user authentication. The `Session` object requires a non-null `user_id` for ownership tracking.

## Decision

Use a fixed sentinel value `user_id="mcp"` for all sessions created via MCP tools.

## Rationale

- **Keeps `user_id` non-null.** Existing code (REST API, leaderboard, session ownership checks) expects `user_id` to always be present.
- **Clearly distinguishable.** If REST API sessions (with real user IDs) and MCP sessions coexist in the same store, they are trivially separable by `user_id`.
- **No user filter for MCP.** `list_sessions` shows all sessions regardless of `user_id` because stdio MCP is inherently single-tenant — there is only one client.
- **No auth bypass risk.** stdio transport is process-local. The MCP server is started by the user and communicates via stdin/stdout. There is no network attack surface.

## Consequences

- If MCP transport moves to HTTP (SSE/WebSocket) in the future, real authentication will be needed. The `user_id="mcp"` sentinel must be replaced with actual user identity from the transport layer.
- REST API session ownership checks (`user_id` matching) do not apply to MCP sessions. This is intentional — MCP trusts the client process.

## Alternatives Considered

- **Generate a UUID per MCP server instance:** Would work but adds complexity with no benefit — there's still no real identity behind it.
- **Use `None` / make `user_id` optional:** Would require null-safety changes throughout the codebase. Not worth it for a single use case.
- **Require API key auth for MCP:** Adds friction to the "MCP-first" developer experience. stdio is already trusted. Can be revisited for HTTP transport.
