# Decision: Clean-Room Isolation for /bug-hunt Blind Agent via Surgical Flags

**Date:** 2026-04-27
**Status:** Accepted
**Source:** /bug-hunt skill creation (BUG_HUNT_LOOP_PLAN, Team B)

## Context

The `/bug-hunt` skill runs a one-shot bug-hunt iteration against `finlet.dev`: a blind agent walks the live product, the operator chat triages broken-only findings, and the resulting plan is fed through `/plan-features` → `/exec-plan` for auto-merge and push. The blind agent leg has a hard correctness requirement — it must reach the product with **zero contamination from the operator's Claude Code environment**:

- No project memory (`CLAUDE.md`, `MEMORY.md`, `.claude/` rules) — the blind agent must not know it is testing Finlet.
- No allowlisted MCP servers (n8n, playwright, gmail, drive, etc.) — would short-circuit the "blind walks the product through its own browser" loop.
- No inherited skills, settings, or hooks — would bias the run.
- Same Anthropic subscription billing as the operator chat — running the blind agent on per-token API-key billing would force a separate billing relationship and eat into the prepaid agent-ops budget.

The obvious-looking flag for this in Claude Code is `--bare`. Investigation showed `--bare` strips config, but it **also forces API-key billing** and refuses to consume `CLAUDE_CODE_OAUTH_TOKEN`. That breaks the subscription-billing constraint above — every blind run would cost real per-token money on top of the $200/mo Max plan we already pay for.

We needed a way to get the isolation properties of `--bare` while staying on subscription billing.

## Decision

The `/bug-hunt` skill launches the blind agent via `claude --print` with a **surgical flag set** that achieves clean-room isolation without invoking `--bare`:

```
CLAUDE_CONFIG_DIR=$(mktemp -d) \
CLAUDE_CODE_OAUTH_TOKEN=$BUG_HUNT_OAUTH_TOKEN \
claude --print \
       --strict-mcp-config \
       --setting-sources "" \
       --append-system-prompt "$BLIND_AGENT_SYSTEM_PROMPT" \
       "$TASK"
```

Each flag does one thing:

- **`CLAUDE_CONFIG_DIR=$(mktemp -d)`** — points the harness at an empty, throwaway config directory. No inherited `~/.claude/` state (memory, skills, hooks, agents, allowlists).
- **`CLAUDE_CODE_OAUTH_TOKEN`** — long-lived OAuth token minted via `claude setup-token`, consumed in place of `ANTHROPIC_API_KEY`. Routes traffic through the operator's Anthropic subscription (Max plan) instead of API-key billing. See `reference_claude_oauth_token.md`.
- **`--strict-mcp-config`** — disables all MCP servers for this invocation. The blind agent's only browser is whatever it can reach via plain HTTP/CLI tools — no `mcp__playwright__*` shortcut.
- **`--setting-sources ""`** — empty allowlist for settings sources. No `settings.json` / `settings.local.json` / project rules layered in.
- **`--append-system-prompt`** — injects the blind-agent persona (clean-room QA tester walking finlet.dev) on top of the bare default system prompt.
- **`--print`** — single-shot non-interactive invocation. Output is captured by the launcher script and handed back to the operator chat for triage.

Together these flags reproduce the isolation surface of `--bare` while preserving subscription billing.

The implementation lives in `.claude/skills/bug-hunt/blind-launcher.sh`; secrets (the OAuth token) live in `.claude/skills/bug-hunt/secrets.env` (gitignored, with a `secrets.env.example` template checked in).

### Alternatives Considered

1. **`claude --bare`** — rejected. Forces API-key billing; would not consume `CLAUDE_CODE_OAUTH_TOKEN`. Running blind iterations on metered API-key billing on top of an already-paid Max subscription is a non-starter for a loop the operator expects to run dozens of times per launch cycle.
2. **Run the blind agent inside the same Claude Code chat (no isolation)** — rejected. The operator chat has full project context (`CLAUDE.md`, MEMORY, skills, MCP servers including playwright). The blind agent would not be blind — it would know the codebase, know it is testing Finlet, and have direct browser-automation MCP shortcuts that bypass the "walks the product as a real user would" invariant.
3. **Spawn the blind agent in a subagent / Task tool inside the operator chat** — rejected for the same reason as (2): subagents inherit the parent's project context and tool surface.
4. **Run the blind agent through a separate Anthropic API key on the same account** — rejected. Adds billing complexity (per-token vs. flat subscription), still requires manual config-dir scrubbing to achieve clean-room state, and offers no isolation benefit over the chosen flag set.

## Consequences

- **Operator must mint and store an OAuth token before first use.** Workflow: `claude setup-token` → copy the resulting `sk-ant-oat01-…` token → paste into `.claude/skills/bug-hunt/secrets.env` as `BUG_HUNT_OAUTH_TOKEN=…`. Tokens are long-lived (no 8-hour OAuth-stale problem on headless), but rotation is a manual step. See `reference_claude_oauth_token.md`.
- **Blind agent has no MCP servers.** That is the point — but it means the blind agent cannot use playwright/n8n/etc. for shortcuts. It must drive the product through whatever surface is reachable from a bare CLI (curl, browsers it spawns itself if at all, the `claude --print` text channel back to the operator).
- **Settings updates do not propagate to the blind agent automatically.** Because `CLAUDE_CONFIG_DIR` is a fresh tmpdir each run, any new global skill / hook / MCP server added by the operator after this date is invisible to the blind agent. That is desired (isolation), but reviewers should be aware: if a future change to the bug-hunt persona needs new tooling, it has to be wired through `--append-system-prompt` or via env vars exposed inside the launcher script, not by editing `~/.claude/`.
- **Future Claude Code releases that change `--bare` semantics do not affect this skill.** The skill avoids `--bare` entirely. If Anthropic later makes `--bare` honor `CLAUDE_CODE_OAUTH_TOKEN`, the surgical-flag set still works; we may revisit then for simplicity, but the current flag set is the durable contract.
- **Same pattern is reusable for any other clean-room skill** (red-team, blind UX research, fresh-eyes review). The flag combination is documented here as the canonical recipe.
