# Decision: Dialog-State-Mirror Prime Ordering — `primeFromCache` precedes `bus.getLastPublished`

**Date**: 2026-04-30
**Status**: Accepted

---

## Context

Three real-broken instances of the same "open-then-subscribe race" shape recurred on the Trade Ticket "Available Cash" header across three bug-hunt iterations (`20260428T031818Z2efa`, `20260429T052717Z1a13`, `20260429T232205Z17ff`). Each per-finding patch closed one specific gap (open-time fetch, shape-drift fallback, SSE-side mirror), but the underlying convention — "subscribe to bus, prime with last value on open, refetch on shape mismatch, refuse to clobber on transient failure, unsubscribe on close" — was missing. The refactor extracts this convention into `dashboard/dialog-state-mirror.js` (see `docs/refactor/trade-ticket-state-sync/plan.md`, merged in commit `efdd443`).

The mirror's `dialogStateMirror({...})` factory exposes two priming sources:

- `bus.getLastPublished(eventName)` — the new lastPublished cache on `window.finletBus` that retains the most recent payload per event name.
- `primeFromCache()` — a consumer-supplied callback that reads a "canonical already-known state" container (e.g., `currentSession.portfolio_metrics`).

The plan (`docs/refactor/trade-ticket-state-sync/plan.md`) listed the priming sequence as `bus.getLastPublished → primeFromCache` (last-published wins; cache is the fallback for the "no publish has happened yet" case). At implementation time recon flagged that ordering as wrong for the existing test surface.

Specifically, `tests/e2e/journey-05-trade.spec.ts` (the "available cash header never shows -- across open/close cycles" leak detector) publishes a poison value `{cash: 999999}` directly via `bus.publish('portfolio:updated', {cash: 999999})` while the dialog is closed. The poison is never written to `currentSession.portfolio_metrics`. With the spec's proposed ordering (`bus.getLastPublished` first), the next dialog open primes from the poison value and the subsequent leak-detector assertion fails because the dialog displays `$999,999` instead of the canonical session cash.

In production, the SSE handler at `dashboard/app.js:1431-1455` updates BOTH sources atomically — the publish to the bus AND the write to `currentSession.portfolio_metrics` happen inside the same listener callback. So in practice the two sources never disagree on real fills; the precedence only matters for synthetic test surfaces and any future code path that publishes without mirroring to `currentSession`.

---

## Decision

The mirror primes with `primeFromCache()` first; `bus.getLastPublished(eventName)` is the fallback when `primeFromCache()` returns `undefined`.

```js
// Inside dialogStateMirror({...}):
const cached = primeFromCache();
const lastPublished = (cached === undefined) ? bus.getLastPublished(eventName) : undefined;
const initialState = (cached !== undefined) ? cached : lastPublished;
// Then: bus.subscribe(...) BEFORE onOpen({initialState, refetch}).
```

The bus subscription still attaches BEFORE `onOpen` is invoked, so a concurrent publish during the open lifecycle lands on the live handler. The reordering is purely about which prime source wins when both are populated.

---

## Justification

**Production correctness is preserved.** The SSE `portfolio` handler in `dashboard/app.js:1431-1455` writes `cash` and `total_value` onto `currentSession.portfolio_metrics` in the same callback that calls `bus.publish('portfolio:updated', payload)`. Both sources are updated atomically; the consumer's `primeFromCache` reads from the canonical session container and gets the same data the bus publish carried. The race window where they disagree is zero on the SSE path.

**Synthetic test surfaces are protected.** journey-05's poison-value test (`bus.publish` without a session-state write) is exactly the shape an attacker — or a future buggy publisher — could produce. With `primeFromCache > bus.getLastPublished`, a poisoned bus cache is shadowed by the canonical session container; the dialog renders the trustworthy value. The leak-detector assertion holds.

**Cold-open backstop is preserved.** When `primeFromCache()` returns `undefined` (e.g., the consumer doesn't have a session-state container ready yet, or the caller passed a noop primer), the mirror falls back to `bus.getLastPublished(eventName)`. The cold-open shape (no prior publish AND no cached state) still reaches `onOpen` with `initialState: undefined` so the consumer can render a placeholder.

**The reversal cost is mechanical.** If a future consumer's `primeFromCache` returns a STALER value than the bus's lastPublished (mitigation below describes when this could happen), the order can be inverted in a single SHA without consumer changes — only the mirror module needs to swap the two reads, and unit tests #2 and #3 need their expectations swapped.

---

## Consequences

### Positive

- **journey-05 poison-value test passes without an explicit `bus.publish` cleanup step.** The leak detector remains a real test of "does the dialog stay correct across opens"; the canonical session container is the trust anchor.
- **Production fills behave identically under either ordering.** No user-visible change; the precedence only diverges on synthetic or buggy publisher paths.
- **Future consumers get a clear convention.** "Always populate `currentSession.portfolio_metrics` (or its analogue) on every SSE handler that also publishes" is the existing pattern in `app.js:1431-1455`. The mirror's prime ordering reinforces this — consumers that follow it never see staleness, consumers that don't will read the bus cache as a backstop.

### Negative

- **A future consumer whose `primeFromCache` returns a STALER value than the bus cache will surface the wrong state.** Concrete shape: a publisher that calls `bus.publish('event:X', payload)` WITHOUT atomically writing to the canonical session container. The mirror would prime from the stale session container; the next `onUpdate` (driven by the live bus subscription) would correct it within one publish cycle, but the open paint would briefly flash the stale value.
- **Mitigation:** Production code MUST always atomically update both sources in the same handler — this is the existing pattern in `app.js:1431-1455` and is now documented in `docs/decisions/dashboard-event-bus.md` references (the `lastPublished` cache section). New publishers added to the bus must follow the same pattern; reviewers should grep for `bus.publish` calls that don't touch `currentSession` and reject them.

### Trade-offs explicitly chosen

- **Trust the canonical session container over the bus cache.** The bus cache is a convenience for "dialog opened after a publish but the session container hasn't been updated yet" — that window is zero on the production SSE path. Treating the session container as the trust anchor is the conservative choice; it means a single buggy publisher can't corrupt every future dialog open by writing to the bus once.
- **Single-source-of-truth convention over symmetric prime sources.** A symmetric design ("either source wins") is harder to reason about — consumers would need to know which path produced their initial state. Choosing one as canonical and the other as fallback gives a single mental model: `primeFromCache()` is "what the page already knows"; `bus.getLastPublished()` is "what was published before you subscribed."

---

## Reversal path

Single SHA. Mechanical. To invert (i.e., bus cache > primeFromCache):

1. In `dashboard/dialog-state-mirror.js`, swap the two reads:
   ```js
   // From (current):
   const cached = primeFromCache();
   const lastPublished = (cached === undefined) ? bus.getLastPublished(eventName) : undefined;
   const initialState = (cached !== undefined) ? cached : lastPublished;
   // To:
   const lastPublished = bus.getLastPublished(eventName);
   const cached = (lastPublished === undefined) ? primeFromCache() : undefined;
   const initialState = (lastPublished !== undefined) ? lastPublished : cached;
   ```
2. In `tests/dashboard/dialog-state-mirror.spec.js`, update unit test #2 (`onOpen receives last-published payload when bus.getLastPublished has a value`) to assert that the bus payload wins over a populated `primeFromCache` — and unit test #3 (`onOpen falls back to primeFromCache when no last-published value`) to assert the inverse.
3. Re-run the journey-05 leak-detector test. If it fails on the poison-value step, the reversal must include a fix to the test's poison-publish step (either the test no longer publishes a synthetic poison, or the mirror gains an opt-in `trust: 'cache' | 'bus'` option).

Estimated cost: 30 minutes including the test update and a manual smoke pass.

---

## References

- Plan: `docs/refactor/trade-ticket-state-sync/plan.md`
- Spec: `docs/bug-hunt/refactor-queue/trade-ticket-state-sync.md`
- Implementation: `dashboard/dialog-state-mirror.js`, `dashboard/event-bus.js`, `dashboard/trade-ticket.js`, `dashboard/event-contract.md` — merged in commit `efdd443`
- SSE atomic-update reference: `dashboard/app.js:1431-1455` — publishes `portfolio:updated` AND mirrors `cash` + `total_value` onto `currentSession.portfolio_metrics`
- Tests: `tests/dashboard/dialog-state-mirror.spec.js` (10 unit tests), `tests/dashboard/event-bus.spec.js` (3 new `getLastPublished` tests appended), `tests/e2e/journey-05-trade.spec.ts` (leak-detector + live-update Playwright cases)
- Sibling decision (bus convention this builds on): `docs/decisions/dashboard-event-bus.md`
