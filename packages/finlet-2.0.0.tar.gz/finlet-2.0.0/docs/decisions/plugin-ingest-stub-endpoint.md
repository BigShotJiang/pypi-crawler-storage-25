# `POST /v1/plugins/{name}/ingest` Stub Endpoint

**Status:** Adopted (stub-only for iteration `20260502T142726Z7b36`; pipeline wiring TODO)
**Date:** 2026-05-02
**Iteration:** bug-hunt `20260502T142726Z7b36` (Team B endpoint scaffold, commit `ad0adb0`; Team C dashboard consumer, commit `2d200db`)
**Files:** `finlet/api/routes_plugins.py` (new), `finlet/api/app.py` (router registration), `dashboard/settings.js` (consumer + Ingest button), `dashboard/settings.html` (button affordance), `dashboard/settings.css` (styling)

## Context

A degraded plugin probe (`PricePlugin._probe()` and siblings) surfaces guidance like `"Run ingestion first"` to the user when the data lake has not been populated. The blind agent in iteration `20260502T142726Z7b36` flagged this as a dead-affordance contract bug: the documented recovery path had no UI button to actually run it. The user could read the message but had no way to act on it from the dashboard — they would need to drop into a CLI or operator console.

Two ways to close this:

1. **Wire the real ingest pipeline now.** `scripts/ingest_yfinance_prices.py` et al. are CLI scripts that take 8-12 hours to complete a bulk run; wrapping them in a job queue, persisting state, and exposing a status endpoint is multi-day work and out of scope for a one-iteration close.
2. **Ship a stub endpoint + the button now; wire the pipeline next iteration.** The affordance contract closes immediately (the button exists, the click reaches a real route, the toast confirms acceptance); the pipeline wiring becomes a tracked TODO in the next iteration.

Option 2 is consistent with the broader "documented recovery paths must have a UI affordance" rule (added to `docs/LESSONS.md` this iteration). The affordance contract is more important than implementation completeness — a stub endpoint that returns 202+job_id is honest about its state ("accepted, work happens asynchronously") and unblocks the dashboard side, while the `TODO(iteration 20260502T142726Z7b36)` markers in the source hold the next-iteration commitment.

## Decision

**Ship `POST /v1/plugins/{name}/ingest` as a stub endpoint for this iteration.** The endpoint:

- Lives in **`finlet/api/routes_plugins.py`** (new file, distinct from `routes_health.py` which owns `/plugins/health` + `/plugins/{name}/reload`). The split is deliberate so the ingest surface can grow into a fully-typed pipeline without bloating the health module.
- **Auth-gates via `Depends(require_user)`** (Bearer API key required) so anonymous traffic cannot enqueue ingest jobs. Even at the stub stage, leaving this open would invite log spam from any blind walker that hits the `/plugins/health` endpoint and discovers the affordance.
- **Returns `404` if the named plugin is not registered.** Avoids creating job IDs for typos — the dashboard treats a 404 as "this row's button is broken, surface the error."
- **Returns `202 Accepted` + `{"job_id": "<uuid>"}` on the happy path.** 202 (not 200) signals "request accepted, work happens asynchronously" — appropriate for the stub since no work happens at all yet, and appropriate for the eventual real pipeline since ingestion is genuinely asynchronous (8-12h for a bulk run).
- **Logs the request via `structlog`** with `plugin_ingest_requested` event, `plugin=name`, `job_id`, `user_id`, and `stub=True` so the next iteration can grep telemetry to confirm the affordance was being clicked before the pipeline lands.
- **Mints a UUID for the `job_id`** but does NOT persist it. The dashboard does not poll a job-status endpoint (none exists yet); it falls back to the existing 2s `/v1/plugins/health` poll to detect when the plugin transitions out of the degraded "Run ingestion first" state. This is intentional — it lets the stub be honest about not tracking jobs while still giving the user a meaningful "did my click work?" signal.

## Alternatives Considered

### A. No endpoint until the real pipeline ships

Rejected. The dead-affordance contract bug stays open until the pipeline lands (multi-day work), and the dashboard can't ship the Ingest button without a real route to POST to. The blind agent would re-flag the same issue every iteration in the meantime. Worse, it normalizes the pattern of "guidance copy without affordance" — every future plugin that needs operator action would have to wait for a backend before the dashboard could surface a button.

### B. Stub the endpoint inline inside `routes_health.py`

Rejected. The ingest pipeline is going to grow — job state, status polling, cancellation, per-plugin rate limits, batch ingest, dry-run mode. Cohabiting that future surface with `routes_health.py` (which is already 600+ lines and owns the health-probe + reload concerns) would create a god-file. The split into `routes_plugins.py` is one new file with a single endpoint today; the file grows naturally as the pipeline wiring lands without forcing a refactor.

### C. Return `501 Not Implemented` instead of `202`

Rejected. 501 reads to clients as "this endpoint is broken" — the dashboard would need a special case to treat it as "click acknowledged." 202 + job_id is the contract the eventual real pipeline will honor; using it now means the dashboard code is forward-compatible (no special-case branch to remove later). The `stub=True` log key is the operator-side signal that distinguishes a stub-202 from a real-202 during incident investigation.

### D. Skip the auth gate (no `require_user`) since it's a stub

Rejected. Even a stub that does no work is a footgun to leave open — any anonymous walker (search engine crawler, security scanner, bored visitor) that hits the affordance during a blind walk would log spam the production telemetry. Auth-gating from day one matches what the real pipeline will require and avoids a "wait, why is the route 401-ing now?" surprise when the pipeline lands.

## Implementation

The endpoint (full source in `finlet/api/routes_plugins.py`):

```python
@router.post("/plugins/{name}/ingest", status_code=202)
async def trigger_plugin_ingest(
    name: str,
    response: Response,
    user: UserRecord = Depends(require_user),
) -> dict[str, str]:
    registry = get_registry()
    if name not in registry._all_plugins:
        raise HTTPException(
            status_code=404,
            detail=f"No plugin named '{name}' is registered. ...",
        )
    job_id = uuid.uuid4().hex
    logger.info(
        "plugin_ingest_requested",
        plugin=name,
        job_id=job_id,
        user_id=user.id,
        stub=True,
    )
    return {"job_id": job_id}
```

Router registration in `finlet/api/app.py`:

```python
from finlet.api.routes_plugins import router as plugins_router
# ...mounted under the /v1 prefix alongside routes_health.
```

Dashboard consumer in `dashboard/settings.js`:

```javascript
function _pluginNeedsIngest(plugin) {
    const msg = (plugin.message || '').toLowerCase();
    return msg.includes('run ingestion');
}
// renders an Ingest button on each plugin row whose message matches;
// click POSTs to /v1/plugins/{name}/ingest, shows a non-blocking toast,
// and the row's normal 2s /v1/plugins/health poll detects when the
// ingest lands.
```

## Next Iteration TODO

Tracked in `finlet/api/routes_plugins.py` as `TODO(iteration 20260502T142726Z7b36)` markers:

1. Wire to the real ingest pipeline (`scripts/ingest_yfinance_prices.py` et al.) — likely via a job queue (RQ, Celery, or a simple async task with persisted state in the ops Postgres).
2. Persist job state (started_at, finished_at, exit code, log tail) in the ops database.
3. Expose `GET /v1/plugins/{name}/ingest/{job_id}` for status polling.
4. Add per-plugin rate limit (one ingest at a time per plugin per user; possibly globally one at a time per plugin to avoid concurrent S3 writers).
5. Add cancellation (`DELETE /v1/plugins/{name}/ingest/{job_id}`) for long-running ingests the operator wants to abort.
6. Update the dashboard to poll the job-status endpoint instead of inferring from `/plugins/health`.

## Reversal Path

Single revert of `finlet/api/routes_plugins.py` (new file) + the router registration line in `finlet/api/app.py` + the Ingest button in `dashboard/settings.js`/`.html`/`.css`. The dashboard reverts cleanly because the button is conditionally rendered (`_pluginNeedsIngest()` returns false → no button). ~10 minutes mechanical revert. Not recommended — would re-open the dead-affordance contract bug.

## References

- Bug-hunt iteration `20260502T142726Z7b36` — Finding D (dead-recovery-affordance)
- Triage report: `docs/bug-hunt/20260502T142726Z7b36/triage.md` (Finding D)
- Lesson in `docs/LESSONS.md` ("A documented recovery path MUST have a UI affordance — guidance copy without a button is a dead-affordance contract bug") — the class-of-mistake rule
- Sister rule in iteration `20260428T031818Z2efa` lessons: "If the action label promises X, the click handler must do X — partial promises are worse than no promise."
