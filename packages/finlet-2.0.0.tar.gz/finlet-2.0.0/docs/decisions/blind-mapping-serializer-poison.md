# Decision: BlindMapping Serializer Poison — Refuse Pickle / Deepcopy at Runtime

**Date**: 2026-05-20
**Status**: Accepted (shipped via blind-export benchmark redesign exec-plan)
**Related**:
- `docs/decisions/blind-benchmark-architecture.md` (parent — V1 architecture)
- `docs/decisions/blind-benchmark-envelope-fields-must-blind.md` (sibling — boundary contract for blind transforms)
- `docs/decisions/blinded-trace-persistence.md` (sibling — write-time trace blinding)
- `docs/decisions/benchmark-run-decrypt-publish-gate.md` (sibling — owner-driven lifecycle)

---

## Context

`BlindMapping` (`finlet/core/blind_mapping.py`) is the per-session opaque-ticker / opaque-date table:

```python
class BlindMapping(BaseModel):
    ticker_map: dict[str, str]          # AAPL -> T_0001
    reverse_ticker_map: dict[str, str]  # T_0001 -> AAPL  <-- the leak surface
    date_origin: datetime               # Day_1 anchor
    sector_map: dict[str, dict[str, str]] = Field(default_factory=dict)
```

The model carries the **reverse mapping** in `reverse_ticker_map`. This is required for the owner-side reveal path (`reverse_ticker(opaque_id, mapping)`) and for any input-side reverse mapping in MCP tool calls (e.g., `submit_order` accepting `T_0001` from the agent and translating to `AAPL` before dispatch). Without the reverse map, the agent's opaque ID could not be translated back into a real symbol.

The reverse map is also a perfect leak surface. If a `BlindMapping` instance is ever embedded in an agent-facing response — even by mistake, even buried under several layers of dict nesting — `json.dumps` happily serializes `reverse_ticker_map` and ships the entire opaque→real translation table to the agent. The leak is structurally identical to leaking the `ticker_map` (the agent gets the inverse function and can reconstruct any opaque id to its real symbol).

V1 had no structural guard against this. The reverse map was reachable from code paths that legitimately handled mappings (`apply_ticker`, `reverse_ticker`, the owner-auth MCP `reveal` tools), but there was no enforcement that the **object itself** could not be embedded in a response. Recon for this exec-plan (finding 1) checked reverse_ticker reachability: the existing call sites are safe today, but there is no schema guard preventing a future tool from accidentally wrapping a `BlindMapping` in a payload and serializing it. Codex-style failure mode: an engineer writes `return {"session": {"id": session.id, "mapping": session.blind_mapping}}` thinking they're returning a structural identifier; the JSON serializer ships the reverse map; the agent reconstructs the universe.

The blind-export redesign closes this structural gap with a runtime poison + a build-time assertion helper.

---

## Decision

`BlindMapping` overrides `__getstate__` to raise `TypeError`:

```python
class BlindMapping(BaseModel):
    def __getstate__(self) -> dict[str, Any]:
        raise TypeError(
            "BlindMapping is not pickle/deepcopy-serialisable. The only legitimate "
            "persistence path is model_dump_json() → blind_mapping_json column. "
            "If you're seeing this error from a response build path, you've "
            "accidentally embedded the per-session ticker dict in an "
            "agent-facing payload — strip it before serialise."
        )
```

This kills `pickle.dumps()` and `copy.deepcopy()`. Both Python serialization paths call `__getstate__` on instances that don't override it; overriding to raise makes the instance refuse to be embedded in any generic dict-walking serializer that bottoms out at `pickle`-style protocols.

A module-level helper `assert_not_in_response_dict(d)` recursively walks a payload dict/list and raises `TypeError` with a JSON-pointer-like path if any nested value is a `BlindMapping`:

```python
def assert_not_in_response_dict(d: Any, *, _path: str = "$") -> None:
    if isinstance(d, BlindMapping):
        raise TypeError(
            f"BlindMapping leaked into response payload at {_path}: ..."
        )
    if isinstance(d, dict):
        for k, v in d.items():
            assert_not_in_response_dict(v, _path=f"{_path}.{k}")
    elif isinstance(d, list):
        for i, v in enumerate(d):
            assert_not_in_response_dict(v, _path=f"{_path}[{i}]")
```

The helper is called at the service-layer boundary (and asserted by Team F's T5 tests) to catch accidental embedding BEFORE the payload reaches the JSON serializer.

**The legitimate persistence path is preserved.** Pydantic v2's `model_dump_json` reads `__pydantic_fields__` directly — NOT via `__getstate__`. The session persistence path (`finlet/db/persistence.py:save_session` → `sessions.blind_mapping_json` column) continues to work. `model_copy` also works (it does not go through `__getstate__`). Confirmed in Team A's REPL smoke tests (`3bc7a56` commit body):

- `pickle.dumps(mapping)` → raises TypeError
- `copy.deepcopy(mapping)` → raises TypeError
- `mapping.model_dump_json()` → succeeds, returns JSON string
- `BlindMapping.model_validate_json(s)` → succeeds, round-trips
- `mapping.model_copy()` → succeeds

---

## Justification

**Structural guard, not policy.** The existing V1 contract (don't embed `BlindMapping` in agent-facing responses) was a discipline that relied on every future engineer remembering it. The poison + helper are a structural guard: the discipline becomes a runtime assertion. A code path that accidentally embeds a `BlindMapping` fails loud (at pickle / deepcopy / `assert_not_in_response_dict` call sites) instead of silently leaking.

**Defense-in-depth against unknown-shape serialization paths.** The codebase has multiple serialization paths beyond `json.dumps`: `pickle` (used by some test fixtures, by `multiprocessing` IPC, by certain caching libraries), `copy.deepcopy` (used by anyone building a defensive payload copy), and various Pydantic round-trips. The poison makes the instance refuse the unsafe paths while letting the canonical persistence path through. We did not enumerate every possible future serialization path — we declared the instance opaque to generic serializers.

**The runtime backstop catches what tests can't enumerate.** Team F's `assert_not_in_response_dict` test (T5) calls the helper on every blind-mode response surface. The test enumerates the known surfaces today, but a future surface added without an `assert_not_in_response_dict` call still benefits from the poison: the moment any code path tries `pickle.dumps` or `copy.deepcopy` on a payload containing a `BlindMapping`, it fails. The poison and the helper are belt-and-braces: the helper catches it at build time on the call sites it covers, the poison catches it at runtime on every path the helper does not cover.

**Recon evidence justified the structural guard.** Recon 1 for this exec-plan walked `reverse_ticker_map` reachability across the codebase. Current call sites are safe (`reverse_ticker(opaque, mapping)` returns the real symbol, not the mapping object; `mapping.ticker_map[symbol]` returns an opaque id, not the mapping object). But there is no schema-level guard. A future tool returning `{"mapping": session.blind_mapping}` would compile, test green in any test that doesn't assert against the exact response shape, and ship the reverse map to the agent. The poison + helper close the gap at the structural level.

**Pydantic v2 serializer integrity preserved (confirmed in REPL).** The legitimate persistence path (`model_dump_json`) reads `__pydantic_fields__` directly. We confirmed: `model_dump_json` round-trip works, `model_copy` works, `model_validate_json` parses correctly. Only `pickle.dumps` and `copy.deepcopy` raise. This is the exact behavior we want — the canonical path is intact, the unsafe paths are blocked.

**Single source of truth for the walker.** `assert_not_in_response_dict` lives in `finlet/core/blind_mapping.py` alongside the model — adding a new dict-walking helper, or moving the helper, would create the kind of duplication that the Codex failure-mode review (Rule Zero Clause 2) explicitly targets.

---

## Consequences

### Positive

- **Structural guard against silent leakage.** A future tool that wraps a `BlindMapping` in a response dict fails at the first serialization attempt — pickle, deepcopy, or `assert_not_in_response_dict` call.
- **Belt-and-braces.** The poison catches runtime serialization paths the helper doesn't cover; the helper catches build-time embedding the poison can't (e.g., a code path that builds the dict but doesn't serialize it within the same call).
- **Canonical persistence path preserved.** `model_dump_json` round-trip works. The on-disk schema (`sessions.blind_mapping_json` TEXT column) is unaffected.
- **Clear failure message.** Both the poison TypeError and the helper TypeError include actionable guidance ("strip blind_mapping references before responding") + the JSON-pointer-like path in the helper case.

### Negative

- **A future caller that wants to `copy.deepcopy` a session (which embeds the mapping) fails.** This is intentional — deepcopying a session would also copy the mapping, which would propagate the leak surface. Callers who need a session copy must use `Session.model_copy()` (the Pydantic-native path that does NOT go through `__getstate__`) or copy specific fields explicitly. Cost: one extra hop for any code path that wants to "snapshot" a session.
- **Generic dict-walking debuggers may fail.** Test fixtures or debugging utilities that pickle entire test-state dicts (some pytest plugins do this for parallel test workers) will fail if the dict contains a `BlindMapping`. Mitigation: tests should construct mappings inline or use the Pydantic round-trip (`model_dump_json` → store the JSON string in the fixture).
- **The helper is opt-in at call sites.** Service-layer code must remember to call `assert_not_in_response_dict(payload)` for it to catch build-time leaks. Mitigation: Team F's T5 test enumerates the surfaces today; the poison is the runtime backstop for surfaces added later.

### Trade-offs explicitly chosen

- **Runtime poison over compile-time schema guard.** A schema-level guard (e.g., a Pydantic validator that refuses to serialize `BlindMapping` as a non-leaf field) would be more elegant but would require defining the guard at every possible parent schema. The runtime poison is universal — it applies to any code path that hits `__getstate__`, regardless of which schema (or no schema) was used to build the payload. Cost: the failure is at runtime, not at type-check time.
- **Refuse pickle/deepcopy entirely over allow-with-warning.** A warning-only approach would let a leak ship in production while emitting a structlog event no one reads. A loud `TypeError` halts the request and surfaces in CI / on-call. The leak is too serious for warning-only.
- **`__getstate__` raise over `__reduce__` / `__reduce_ex__` raise.** `__getstate__` is the canonical Pydantic v2 path for pickle protocol — overriding it gives the simplest blocking behavior. `__reduce__` would also work but is more general (covers protocol 0); the simpler override is sufficient because Pydantic models default to protocol 2+.

---

## Reversal path

Mechanical, single SHA:

1. In `finlet/core/blind_mapping.py`, remove the `__getstate__` override on `BlindMapping`.
2. Optionally remove `assert_not_in_response_dict` and its T5 call sites — but the helper is harmless to keep as a build-time check even without the runtime poison.
3. The reversal does not affect the persistence path (`model_dump_json` round-trip) or any current call site. It only re-enables pickle / deepcopy of `BlindMapping`, which would re-introduce the silent-leak surface.

Estimated cost: 15 minutes. The reversal is sound technically but reintroduces the structural gap this decision closes. Do not reverse unless you have a concrete reason to need pickle / deepcopy support (e.g., a multiprocessing IPC path that legitimately needs to ship the mapping across process boundaries — in which case, gate the pickle path behind a separate function rather than re-opening the runtime poison).

---

## References

- Recon 1: `reverse_ticker_map` reachability assessment — current sites safe but no schema guard
- Poison implementation: `finlet/core/blind_mapping.py:BlindMapping.__getstate__` — Team A `3bc7a56`
- Helper: `finlet/core/blind_mapping.py:assert_not_in_response_dict` — Team A `3bc7a56`
- Pydantic v2 serializer behavior: `model_dump_json` reads `__pydantic_fields__` directly; pickle / deepcopy go through `__getstate__`. Confirmed in Team A REPL smoke tests.
- Tests: T5 in Team F's gate (asserts no `BlindMapping` reachable from any blind-mode response payload)
- Persistence path: `finlet/db/persistence.py:save_session` → `sessions.blind_mapping_json` TEXT column (migration `015_add_session_blind_mapping.py`)
- Reverse-mapping consumers (currently safe): `finlet/core/blind_mapping.py:reverse_ticker`, `finlet/core/blind_mapping.py:reverse_date`, MCP input reverse-mapping for `submit_order` / `get_price_data` / `get_fundamentals` (per `blind-benchmark-envelope-fields-must-blind.md` Extension 2026-05-20)
