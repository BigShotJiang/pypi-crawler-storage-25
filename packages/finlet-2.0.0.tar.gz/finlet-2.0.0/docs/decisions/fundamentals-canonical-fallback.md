# Decision: Fundamentals canonical-as-fallback always-on + ingest ratchet guard + envelope `data_unavailable_at_simtime` status

Date: 2026-05-19
Status: shipped (FUNDAMENTALS_HERO_SAVE batch — Team A `34e0fa3`, Team B `1c1939c`, Team C `02d2f73`)

## Context

The 2026-05-18 launch-day fundamentals delta backfill on prod EC2 silently
clobbered `s3://finlet-data-cccdea31/fundamentals/quarterly/{AAPL,MSFT,
NVDA,AMZN,GOOGL,...}.parquet` with a narrow lookback window. Earliest
`filed_at` per ticker shrank from 2013-05-08 to 2024-11-14; the
~100KB+ parquets dropped to ~10KB containing only the most recent
seven quarters. Ingest crons had already been disabled
(`project_ingest_disk_cleanup_shipped.md`) so the blast radius was
bounded to that one manual run, but the data lake state was now
inconsistent with what `FundamentalsPlugin` advertised.

Codex's 2026-05-19 bug report surfaced the user-visible symptom: an
agent calling `get_fundamentals(ticker="NVDA")` at sim clock 2023-10-02
received an empty-success envelope (`items=[]`, `count=0`, no `error`
in the obvious places) and could not distinguish "this plugin is
healthy and returned nothing meaningful" from "this plugin failed."

Two pre-existing facts compounded the impact:

1. `_query_canonical_financials` only attempted the canonical S3 layer
   when the caller passed an SEC concept name (`force_s3=bool(concept)`
   at `fundamentals_plugin.py:1156`). MCP agents calling
   `get_fundamentals(ticker="NVDA")` without a `concept` parameter — the
   common case — silently fell through to the quarterly layer and
   never read the canonical history that has filings back to 2009.
2. The fallback-chain envelope at `market_service.py:243-253` did not
   carry an explicit `status` field. When the terminal-informational
   gate fired, the envelope looked like a successful empty result.

## Decision

Three orthogonal, all-additive changes ship together:

### 1. Canonical-as-fallback always-on (Team A — `finlet/plugins/fundamentals_plugin.py`)

`_query_canonical_financials` and `_query_canonical_latest` now call
`_read_canonical_data(ticker, force_s3=True)` unconditionally. The
`force_s3=bool(concept)` gate is gone.

The new fallback semantics:

- Canonical S3 is always attempted first.
- If canonical returns rows post-ceiling, they serve the request and
  the response stamps `metadata={"data_layer": "canonical"}`.
- If canonical returns no rows post-ceiling AND the caller did NOT pass
  a `concept`, fall through to the quarterly raw-data path and stamp
  `metadata={"data_layer": "quarterly"}` (the response is rebuilt via
  `model_copy(update={"metadata": ...})` so the existing quarterly
  response shape is preserved).
- If canonical returns no rows post-ceiling AND the caller DID pass a
  `concept`, preserve the existing canonical-empty error template (the
  quarterly layer doesn't carry concept-keyed data, so falling through
  wouldn't help).

The "at or before" / "Earliest available filing is YYYY-MM-DD" quarterly
error template (`fundamentals_plugin.py:511-514`) is preserved verbatim
so `market_service._is_terminal_informational_empty_result`'s substring
match still fires. `PluginResponse.source` stays `"fundamentals_s3"`
for both layers — the gate's source-string equality check
(`response.source != "fundamentals_s3"`) is unchanged.

A new `_normalize_canonical_items` helper exposes BOTH `concept` and
`field_name` keys on canonical-served items. A 15-entry mapping
(`_CANONICAL_CONCEPT_TO_FIELD_NAME`) covers the most common canonical
concepts (`revenue → total_revenue`, `net_income → net_income`,
`net_interest_income → net_interest_income`, etc.); unmapped concepts
default `field_name = concept`. The mapping is additive — `concept` is
preserved on every normalized item.

### 2. Ingest writer ratchet guard (Team B — `finlet/ingestion/s3_writer.py` + `scripts/ingest_fundamentals.py`)

`S3ParquetWriter.upload_to_key` gains an `allow_shrink: bool = False`
kwarg. When `emit_manifest=True`, `coverage` is a `CoverageTicker`, and
the parquet key already exists in S3, the writer:

1. Reads the existing manifest sidecar (`{key}.manifest.json`) via a
   new `_read_existing_manifest` helper.
2. Compares the existing manifest's `coverage.period_start` against the
   new `coverage.period_start`.
3. If the new value is later (i.e. the new write would shrink
   historical coverage) AND `allow_shrink=False`, raises
   `CoverageShrinkError` BEFORE the parquet PUT. No bytes land.
4. Equal-coverage and wider-coverage (earlier `period_start`) writes
   proceed normally, with structured-log breadcrumbs at
   `s3_writer.ratchet.{accepted, widened, shrink_allowed,
   manifest_read_failed}`.

The ratchet is FAIL CLOSED on manifest-read failure: any S3 error other
than `NoSuchKey`/`404` raises `CoverageShrinkError` rather than
silently proceeding. Callers can opt into overwriting with
`allow_shrink=True`. A first-write path (parquet key absent) skips
the manifest read entirely to avoid spurious `get_object` traffic and
to preserve existing test mocks that don't stub `get_object`.

`scripts/ingest_fundamentals.py` gains a `--allow-shrink` CLI flag; it
threads through `upload_ticker_parquet` to `upload_to_key`. When set,
the script emits a prominent `structlog.warning` and a stderr banner so
operators see what's happening.

The ratchet applies ONLY to `CoverageTicker`. Other coverage shapes
(`CoverageDate`, `CoverageSeries`, `CoverageSingleton`) flow through
unchanged — date-partitioned and series-partitioned uploads have
different shrinkage semantics (a smaller daily delta isn't a category
error) so they are intentionally out of scope for this guard.

### 3. Envelope `status="data_unavailable_at_simtime"` (Team C — `finlet/api/services/market_service.py`)

`route_query()` consumes the existing
`_is_terminal_informational_empty_result` gate (predicate unchanged)
and, when it fires, stamps three additional fields on the canonical
envelope:

- `status="data_unavailable_at_simtime"` — first-class field that
  unambiguously signals "the plugin is healthy, the gate ceiling
  filtered every row, and the agent should treat this as a
  data-unavailability response rather than a plugin failure or a
  successful empty result."
- `earliest_available` — ISO-date string parsed from the plugin error
  tail (`"Earliest available filing is YYYY-MM-DD"`) via the
  defensive regex `_EARLIEST_AVAILABLE_RE`. Returns `None` when the
  tail doesn't match (the gate may fire on the "at or before" branch
  with no embedded date) — the parser never raises.
- `data_layer` — surfaces `response.metadata["data_layer"]` from
  Team A's metadata when present. Lets agents trace which S3 layer
  served the response.

When `terminal_empty` is False (normal success OR a genuine plugin
error), the envelope shape is byte-identical to the pre-change contract
— `status`, `earliest_available`, and `data_layer` are absent. Agents
that pattern-matched on `result["items"]` or `result["error"]` continue
working unchanged.

## Why these choices

### Canonical-as-fallback over re-backfilling quarterly

The 2026-05-18 backfill clobbered quarterly. Two paths to restore
agent-visible coverage:

(A) Re-run the full historical backfill against quarterly to restore
the wide window.

(B) Wire canonical (which already has the full history back to 2009)
as a fallback so callers without a `concept` parameter automatically
benefit from the broader canonical layer.

(B) was chosen because:

- It's an additive code change — no S3 ops involved.
- It's faster to validate (Codex retest is a function call, not a
  multi-hour backfill).
- The underlying canonical data is already in S3 and was unaffected
  by the 2026-05-18 incident (the clobber hit `fundamentals/quarterly/`,
  not `fundamentals/canonical/`).
- It fixes a latent design bug regardless of the launch-day incident:
  the prior `force_s3=bool(concept)` gate meant that any caller without
  a `concept` parameter could never reach canonical, even though the
  plugin advertised `canonical=True` as the default. The gate was a
  silent behaviour difference between the API surface and reality.

(A) is preserved as a "nice-to-have" follow-up in REMAINING_TASKS for
tickers whose canonical coverage is incomplete (mid-cap and below where
the canonical ETL has not been run). The launch acceptance gate is
scoped to AAPL/MSFT/NVDA/AMZN/GOOGL which canonical covers in full.

### Ratchet guard in `s3_writer.py`, not `ingest_fundamentals.py`

The writer is the choke-point. Every ticker-scoped coverage upload —
not just `ingest_fundamentals.py` — gets the ratchet for free. Future
ingest scripts that write `CoverageTicker` data (an EDGAR mirror script,
a vendor-licensed feed migration, etc.) inherit the guard without
re-implementing it. Putting the ratchet in `ingest_fundamentals.py`
would have been a one-file fix today but would not protect against the
next ingest script that forgot to do its own pre-write coverage check.

### Scope ratchet to `CoverageTicker` only

The 2026-05-18 incident class was ticker-partitioned data. Other
coverage shapes have different shrinkage semantics:

- `CoverageDate` — date-partitioned uploads (`prices/daily/`,
  `news/daily/`). A re-run of yesterday's ingest legitimately
  overwrites the same `{date}.parquet`; "shrinkage" of the date range
  is not a category error.
- `CoverageSeries` — FRED/BLS time series. Shrinkage typically means a
  series ID was retired by the upstream; the writer is not the right
  layer to police that.
- `CoverageSingleton` — one-file reference data (sector tables,
  `ticker_universe.parquet`). Hand-curated; manual review is the
  natural guard.

Scoping the ratchet to `CoverageTicker` keeps the guard tight on the
class of bug that actually shipped — ticker-partitioned historical
coverage shrinkage — without false-positiving the legitimate
date-partitioned re-runs that ingest crons depend on.

### FAIL CLOSED on transient manifest-read errors

A guard that silently fails open is a non-guard. If the writer cannot
read the existing manifest to prove the new write is safe, it MUST
refuse the write. Operators can override with `--allow-shrink` after
inspecting the existing state by hand. The pattern matches the
defense-in-depth posture from the deploy-restart guard
(`docs/decisions/deploy-restart-defense-in-depth.md`): if the
post-condition cannot be verified, the operation fails loudly.

### Envelope `status` field is additive, not breaking

Existing agents pattern-match on `result["items"]` (empty vs
non-empty) and `result["error"]` (string vs absent). Both paths
continue to work — the new fields are appended after the existing
ones, never replacing or renaming. New agents and bug-report shapes
can pattern-match on `result["status"] == "data_unavailable_at_simtime"`
for an unambiguous signal. The 90-day deprecation discipline does not
apply because nothing was removed; this is the cleanest possible
expansion of the envelope contract.

## Alternatives considered + rejected

- **Broaden `_is_terminal_informational_empty_result`'s predicate to
  catch more empty-success shapes.** Rejected — the existing predicate
  is precise (it checks substring matches against literal error
  templates that the plugin owns). Broadening it would couple the
  service layer to ever more plugin error shapes. The fix is to surface
  the predicate's result, not to broaden it.
- **Stamp `status` on every fundamentals envelope, even successful
  responses.** Rejected — adds wire noise for the common case
  (`status="ok"` on every non-error response is signal-free). The
  current shape (`status` only when terminal-empty fires) means
  `status` is a meaningful diagnostic when present.
- **Auto-recover the 2026-05-18 quarterly clobber by re-running the
  full historical backfill before this PR lands.** Rejected — the
  canonical fallback covers the launch acceptance universe; backfilling
  quarterly is a multi-hour operation with its own ingest-cron-disabled
  prerequisite (re-enabling crons is blocked on the EDGAR insider
  hang from `project_ingest_edgar_insider_hang.md`). Backfill is in
  REMAINING_TASKS as a follow-up.
- **Track `coverage.period_end` shrinkage too.** Rejected for this
  pass — `period_end` legitimately advances on every successful daily
  delta ingest, so a tighter ratchet would false-positive. The
  2026-05-18 incident was `period_start` shrinkage exclusively. If a
  `period_end` regression class surfaces later, the ratchet helper has
  the necessary plumbing to add it incrementally.

## Consequences

- MCP agents calling `get_fundamentals(ticker="NVDA")` at any sim time
  within canonical's historical range (back to 2009-07 for the
  default-universe tickers) now receive non-empty results without
  needing to know about the canonical/quarterly distinction.
- `result.metadata.data_layer` and the envelope `data_layer` field
  give agents (and prod debuggers) one-step visibility into which
  layer served the response.
- Re-running `scripts/ingest_fundamentals.py` against a ticker whose
  manifest reports a wider historical window than the new fetch raises
  `CoverageShrinkError` and refuses the overwrite. Operators must
  inspect, then either re-run with `--allow-shrink` (data loss
  acknowledged) or fix the upstream query.
- Bug-report harnesses (Codex et al.) can now pattern-match on
  `status="data_unavailable_at_simtime"` to distinguish "data lake
  doesn't cover this sim time" from "plugin failed" — closes the
  empty-success ambiguity that surfaced this incident.
- One extra `get_object` per ticker-coverage upload (for the manifest
  read). With ingest crons currently disabled and manual deltas
  bounded, the cost is negligible. When crons re-enable, the cost
  scales linearly with the number of `CoverageTicker` uploads per run
  (current: ~10 tickers per fundamentals delta).

## Related work

- 2026-05-18 incident: `project_ingest_disk_cleanup_shipped.md` (ingest
  crons disabled), `project_data_backfill_pre_launch_shipped.md`
  (launch-day delta backfill context).
- 2026-05-19 sibling fix: `docs/decisions/2026-05-19-fundamentals-etf-and-s3-error-classification.md`
  (ETF/no-such-key/connection-error classification — orthogonal,
  shipped same day).
- 2026-05-19 sibling fix: `docs/decisions/mcp-benchmark-fundamentals-coverage.md`
  (deleted `_validate_coverage` fundamentals branch — orthogonal,
  shipped same day).
