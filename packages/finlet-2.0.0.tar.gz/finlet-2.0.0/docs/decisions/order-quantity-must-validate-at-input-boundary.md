# Order Quantity Must Validate at Input Boundary, Not Just at the Engine

- **Status:** Accepted
- **Date:** 2026-05-21
- **Bug:** Codex bug `4fa9160a-f2e6-4cf3-8799-11d99326d556`
- **Owners:** api team (Team C, exec-plan `codex bugs 4-pack`)

## Context

Codex's blind benchmark agent observed three pathological correctness
behaviors when calling `submit_order` from the MCP surface against a live
session:

1. `submit_order(quantity=0)` returned **HTTP 200** with `is_error: false`
   and a serialized order record carrying `status: REJECTED` —
   "successful" creation of a phantom rejected order.
2. `submit_order(quantity=-1)` same outcome: HTTP 200, phantom REJECTED.
3. `submit_order(quantity=1e9)` (huge-qty) was rejected by the cash
   check downstream, but the response carried
   `slippage_amount: 183236804.68751` — the engine had **computed
   slippage for one billion shares BEFORE the cash check**, then
   side-channeled that computation into the response envelope.

Each is a correctness defect in its own right:

- **Phantom REJECTED orders pollute the trace.** An agent that sums
  rejections, computes rejection-rate metrics, or trains on session
  history sees fake activity. Worse, a malicious agent could batch
  thousands of `quantity=0` calls to bloat session state at zero
  intended cost — a self-DoS amplifier.
- **The engine wasted compute on the 1e9 case.** Slippage math
  multiplies `(fill_price - pre_slippage_price) × quantity`. For
  rejected orders, that compute is sunk cost. For the largest of the
  three (1e15 shares used in the retest), it's also a likely
  arithmetic-overflow / underflow vector.
- **Slippage exposure is a side channel.** The agent learned the
  engine's internal slippage model output even though the order never
  filled — a leak of pricing internals to an agent that should only
  ever see the published rejection.

The engine's `validate_order` at `finlet/core/orders.py:65-77` already
contains the correct rule — `if order.quantity <= 0: return "must be
positive"` — and `OrderBook._submit_unlocked` honors it by marking the
order REJECTED with the documented reason. The defect was that this
**only fires after the MCP / REST boundary has accepted the call,
allocated session state, paid for auth + universe-check + slippage
math, and persisted the rejected order**. The boundary is the right
place to reject malformed input — the engine path is the wrong place
to discover it for the first time.

## Decision

Validate `quantity`, `limit_price`, and `stop_price` at the **input
boundary of every public surface** that accepts these fields:

1. **MCP surface (`finlet/mcp/tools_trading.py:submit_order`):** a
   gate at the TOP of the function — BEFORE `resolve_credential`,
   BEFORE `_resolve_user_record`, BEFORE `_resolve_session`. Reject
   non-numeric or non-positive values with the structured
   `{"error": "<reason>. See: finlet manual errors#order-rejected"}`
   envelope. `bool` is explicitly rejected because
   `isinstance(True, int)` is True in Python and `True <= 0` is False,
   so a bare `True` would otherwise pass the gate as `quantity=1`.

2. **REST surface (`finlet/api/routes_trade.py:OrderRequest`):**
   Pydantic `Field(gt=0)` constraints on `quantity`, `limit_price`,
   and `stop_price`. (Verified already present at HEAD as of
   2026-05-21 — the regression test in
   `tests/api/test_routes_trade_validation.py` pins it so future
   refactors can't quietly drop the constraint.)

3. **Engine invariant retained (`finlet/core/orders.py:validate_order`):**
   `OrderBook._submit_unlocked` still calls `validate_order` and
   still produces a REJECTED order with `reject_reason` set when an
   in-process caller (e.g. `strategies/ai_quantamental` direct
   driver, an integration test, a future REPL surface) bypasses MCP
   and REST. The boundary gates are an **outer ring** of defense, not
   a replacement.

4. **Response surface slippage scrub (`finlet/api/services/trade_service.py:order_dict`):**
   when an order's `status != "FILLED"`, force `slippage_amount = None`
   in the serialized dict regardless of any value the engine populated
   internally. The engine retains its precision for trace and audit
   paths; only the agent-visible response is scrubbed.

## Alternatives considered

### A. Tighten the engine to never compute slippage on rejected orders.

Rejected. The engine computes slippage as part of `_fill()`, which runs
before the cash check by design (the fill model needs the slippage-
adjusted fill price to know how much cash the order would consume).
Reordering slippage AFTER the cash check would require a two-phase
slippage model (estimate-then-confirm), which is invasive and adds a
correctness risk surface — extra synchronization between estimate and
confirm — to fix a leak that's better solved by scrubbing the response.

### B. Trust the engine to reject invalid input at the boundary too (status quo).

Rejected. The engine's rejection produces a persisted REJECTED record,
not a refusal-to-process. Refusal at the boundary is the right
semantic for "this input is structurally invalid" — the same way
Pydantic returns 422 for missing required fields rather than
constructing an empty model and letting the route fail downstream.

### C. Add a per-tier limit on max `quantity` (e.g. 1e6 shares).

Rejected for now. Correct in spirit but cross-cuts product strategy
(do we want a hard cap, or per-tier caps?). The boundary gate as
specified rejects the obvious correctness defects (≤0, non-numeric)
without prejudging the business policy. A future decision record can
layer a max-quantity per-tier cap on top of this one if needed.

## Consequences

### Pre-launch acknowledgement (MCP semantics change)

Before this fix:

```python
result = await submit_order(ticker="AAPL", side="BUY", quantity=0)
# {"status": "REJECTED", "reject_reason": "Order quantity must be positive, got 0.0", "id": "...", ...}
# session.orders now contains the phantom REJECTED order.
```

After this fix:

```python
result = await submit_order(ticker="AAPL", side="BUY", quantity=0)
# {"error": "quantity must be a positive number, got 0. See: finlet manual errors#order-rejected"}
# session.orders is unchanged — no phantom record.
```

REST does not change shape — Pydantic's 422 path was already correct;
the test addition just pins it.

This is a **breaking change in MCP response shape on invalid input**.
Per Finlet's pre-launch posture (no public consumers, no paid GA, see
project memory `[[project-pre-launch-no-customers]]`), no
backwards-compat shim is added. After paid GA, follow standard
discipline — extend rather than break.

### Engine internals unchanged

`validate_order`, `OrderBook._submit_unlocked`, and the slippage
model are unmodified. Strategies that drive the engine directly
(e.g. `strategies/ai_quantamental`) continue to see phantom REJECTED
orders for invalid input — that's the documented in-process contract
and there's no agent-surface side-channel concern in-process.

### Test coverage

- `tests/mcp/test_submit_order_validation.py` (NEW): 25 cases covering
  zero / negative / non-numeric `quantity`, zero / negative
  `limit_price` and `stop_price`, the bool-int trap, the
  None-passes-gate case, and two engine-invariant tests that pin
  `validate_order` continues to reject zero / negative.
- `tests/api/test_routes_trade_validation.py` (NEW): 18 cases — REST
  pydantic 422 on invalid quantity/limit_price/stop_price + 4 cases
  pinning `order_dict` scrubs `slippage_amount` to `None` on
  REJECTED / CANCELLED / PENDING and preserves it on FILLED.
- `tests/core/test_orders.py` (unchanged): the engine invariant tests
  `test_zero_quantity`, `test_negative_quantity`,
  `test_invalid_rejected`, `test_rejected_stored` continue to pass —
  validating that the engine ring of defense is intact.

### Scope-creep check (mandatory under Team C plan)

The exec-plan required deleting any existing test that asserted
phantom-REJECTED behavior on invalid input. **No such tests
exist** — every REJECTED-asserting test in the repo at spawn-base
`39942a1` rejects on:

- **Missing `limit_price` on LIMIT order** (`tests/api/test_trade.py:67`,
  `tests/api/test_bug8_limit_stop_fills.py:481,526`) — semantically
  correct, in scope of the engine's `validate_order` rule for missing
  required fields on LIMIT/STOP, not in scope of "invalid quantity".
- **Plugin-error / circuit-breaker rejection on a valid quantity**
  (`tests/api/test_trade_service.py:446,455,504,512`,
  `tests/api/test_clock_service_circuit.py:113,114,187`,
  `tests/api/test_e2e.py:503` (insufficient cash),
  `tests/api/test_e2e.py:607`) — all use `quantity >= 1`. These remain
  correct under the fix.
- **Engine-level invariant** (`tests/core/test_orders.py:166-175`,
  `tests/core/test_orders.py:559,561`, `tests/core/test_session.py:561`)
  — the engine ring of defense that this decision record explicitly
  preserves.

No test deletions were required; the existing REJECTED corpus is
correctly testing legitimate rejection paths.

## References

- Bug report: Codex retest `4fa9160a-f2e6-4cf3-8799-11d99326d556`
  (2026-05-21).
- Engine validation source: `finlet/core/orders.py:65-77` (preserved).
- MCP boundary gate: `finlet/mcp/tools_trading.py:submit_order` (new).
- REST boundary gate:
  `finlet/api/routes_trade.py:OrderRequest.{quantity,limit_price,stop_price}`
  (verified, regression test added).
- Response slippage scrub:
  `finlet/api/services/trade_service.py:order_dict` (modified).
- Related decision (defense-in-depth pattern):
  `docs/decisions/blind-benchmark-ticker-must-blind.md` —
  per-session map at the boundary + frozenset chokepoint at the
  engine, same architecture.

## Followups (Codex peer review, 2026-05-21)

After the original fix landed, Codex peer review surfaced three followup
items addressed in the `codex-bugs-4pack-v2` iteration (Team C2). Each
extends the original decision without changing its premise.

### Item #1 — `submit_order` persist atomicity (MUST-FIX)

The original implementation (PR #129) had **three separate persist blocks**
in `trade_service._submit_order` (well, the function `submit_order` itself
has the body that calls into the persistence at three points):

1. lines 231-243: persist PENDING (first persist, every order)
2. lines 273-281: persist REJECTED on plugin error (second persist, MARKET only)
3. lines 301-317: persist FILLED/REJECTED on fill outcome (third persist, MARKET only)

Each was wrapped in `try/except Exception` that silently logged. Failure mode:
persist #1 succeeds → memory mutates to FILLED via `session.fill_order` →
persist #3 fails silently (network glitch, disk-full, transient lock conflict) →
DB carries PENDING, memory carries FILLED. **Divergent state self-DoS**:
a subsequent agent call to `list_orders` shows FILLED, the agent submits a
SELL against the "position" that only exists in memory, the SELL is rejected
because the underlying engine state was reverted by a server restart that
reloaded from the PENDING DB row, and the agent loops.

**Surgical fix:** for MARKET-PENDING orders, **skip the first persist** so
the entire submit-then-fill sequence persists EXACTLY ONCE after fill/reject
is determined. A new helper `_persist_market_terminal(...)` performs the
single atomic write of order + session + position(+/-) + all new trace
entries.

On persist failure, a new helper `_rollback_market_persist_failure(...)`
inverts the in-memory mutation:

- `order.status` reverts to `OrderStatus.PENDING`
- `order.fill_price`, `order.filled_at`, `order.reject_reason`,
  `order.slippage_amount` are cleared
- If a portfolio mutation occurred (FILLED branch), cash is restored from a
  pre-fill snapshot, and the position is restored to its pre-fill quantity
  and avg_entry_price (or removed if it didn't exist pre-fill)

The agent then receives a deterministic error envelope:

```python
{"error": "Persist failed; order state reverted to PENDING. Retry the submission or contact support. See: finlet manual errors#order-rejected",
 "code": "persist_failed",
 "id": "<order-id>"}
```

LIMIT/STOP orders **retain the pre-fill persist** — their PENDING DB row is
the durable state until fill (no auto-fill path mutates after submit), and
no rollback is needed.

The rollback inverse is **inlined** (not extracted to `session.rollback_fill`)
because the engine does not currently expose a rollback_fill helper. Future
contributors: if the engine grows one, prefer it over the inline cleanup so
the inverse stays in one place. The inline code is commented with
"Codex item #1 atomicity invariant: memory must match DB after persist
failure" so the intent is preserved.

### Item #8 — finite-float gate

The original gate at the MCP boundary used `quantity <= 0`, which accepts
both `float("inf")` and `float("nan")` per IEEE 754 (inf > 0 is True; nan
comparisons are False but the engine's subsequent slippage math goes wild
on inf inputs — `inf × price = inf` then `inf > self._cash + 1e-9` triggers
an InsufficientCash with a meaningless error message). Similarly, pydantic's
`gt=0` accepts `inf` at the REST boundary unless `allow_inf_nan=False` is
explicitly set.

**Fix:** MCP gate adds `math.isfinite(quantity)` and the same for
`limit_price` / `stop_price`. REST adds `allow_inf_nan=False` to all three
pydantic Fields. The error message changes from "must be a positive number"
to "must be a finite positive number" to distinguish the new rejection
class.

### Item #9 — test name truth-in-naming

`test_huge_quantity_returns_error_with_no_slippage_leak` was actually
exercising `quantity=True` (a bool — `isinstance(True, int)` is True in
Python, but the gate's `isinstance(quantity, bool)` check rejects it first).
Renamed to `test_bool_quantity_returns_error_with_no_slippage_leak` for
truth-in-naming. New test `test_huge_finite_quantity_passes_gate_no_slippage_leak`
exercises the actual huge-finite-quantity path (1e15 shares) and asserts
the gate lets it through while downstream cash-check rejects with no
slippage leak. New tests `test_inf_nan_quantity_rejects_at_gate`,
`test_inf_nan_limit_price_rejects_at_gate`,
`test_inf_nan_stop_price_rejects_at_gate` cover the item #8 surface.

### Updated test coverage

- `tests/mcp/test_submit_order_validation.py`: renamed bool test + 4 new
  inf/nan test classes (quantity, limit_price, stop_price, +
  huge-finite passes-gate test).
- `tests/api/test_routes_trade_validation.py`: 3 new test classes
  exercising the REST `allow_inf_nan=False` 422 path on
  quantity/limit_price/stop_price.
- `tests/api/test_trade_service_atomicity.py` (NEW): 5 test cases
  exercising item #1's surgical persist atomicity + memory rollback —
  happy-path MARKET fill (asserts exactly 1 save_order call vs pre-fix 2),
  MARKET-FILLED persist-failure rollback (status PENDING, no position, cash
  restored), BUY-into-existing-position rollback (qty + avg restored),
  MARKET-plugin-error persist-failure rollback (status PENDING, no
  portfolio mutation), LIMIT order pre-fill persist preserved.

### Followup decision scope

Item #1 is a strictly internal refactor; the only externally observable
change is the new `code: "persist_failed"` error envelope on persist
failure (pre-fix the agent saw a successful FILLED response that didn't
match DB state — strictly worse). Per the pre-launch posture, no backwards-
compat shim is added.

Item #8 is a tightening at the boundary; pre-fix the engine silently
produced garbage on inf/nan inputs; post-fix the agent sees a
deterministic rejection with the manual anchor for self-service debugging.

Item #9 is test housekeeping; no production surface changed.
