# Decision: Cut UI Write Paths for Launch — Monitoring-Only Dashboard

**Date**: 2026-05-06
**Status**: Accepted

---

## Context

Finlet's product positioning is "agentic trading evaluation harness" — a benchmark for AI agents, not a trading SaaS for humans. The launch user is an LLM agent calling MCP tools or the `finlet` CLI. Memory `project_finlet_positioning.md` records this from 2026-03-30.

Despite that positioning, the dashboard at `dashboard/` ships a full human-facing trading SaaS UI: trade ticket, onboarding wizard, plugin install/configure UI, settings tabs, modals. ~24 bug-hunt iterations (ledger: `docs/bug-hunt/ledger.jsonl`) produced 69 real-broken findings. Bucketed by category:

| Category | Count | Iterations | Surface |
|---|---|---|---|
| dashboard-state-sync | 26 | 17 | trade ticket ↔ portfolio sync |
| onboarding-checklist | 10 | 8 | wizard + checklist |
| dirty-state-tracker | 5 | 5 | form-dirty banners |
| dead-affordance | 5 | 5 | buttons that do nothing |
| trusted-types | 4 | 3 | innerHTML in dashboard |
| plugin-registry-routing | 3 | 3 | Settings → Plugins tab |
| modal-stacking | 2 | 2 | wizard ↔ create-session overlay |
| aria-label-mismatch | 2 | 2 | nav button labels |
| password-form-aria | 2 | 2 | settings password form |
| price-discrepancy | 2 | 2 | trade ticket display math |

~65 of 69 ledger entries (94%) live in UI write paths. We've shipped 12 refactor docs targeting these surfaces with a 50% effectiveness rate (6 effective / 4 incomplete / 1 regressed / 1 verdict-pending). The pattern of "ship refactor → verdict incomplete → next iteration finds same category → ship another refactor" indicates we are patching the wrong layer: the surfaces themselves shouldn't exist for the launch user.

The most recent blind walkthrough (`docs/bug-hunt/20260507T042257Z3c76/blind_report.json`) made the misalignment vivid. The agent's #1 BROKEN finding was *"Finlet benchmark MCP tools not present in the tool registry"* — the actual product entry point was undiscoverable. The agent fell back to clicking the trade ticket UI to complete its task. We have been polishing the fallback while the front door is broken.

Comparable precedent: Claude Code shipped CLI-only for over a year before adding a desktop app. The CLI was solid first, the GUI was additive. Finlet has been doing the inverse: the UI got bug-hunt cycles while CLI/MCP discoverability languished.

---

## Decision

Cut all write-path UI surfaces from the launch dashboard. Move the cut code to `legacy/dashboard-ui/` at the repo root, preserved verbatim with git-mv (history intact). Production dashboard becomes monitoring-only: read-only widgets that show the state of agent-driven sessions.

### What is kept (production `dashboard/`)

Read-only surfaces that observe agent activity:

- Login + session cookie auth
- Equity curve (TradingView lightweight-charts)
- Positions table (read-only)
- Trade log (read-only)
- Sessions list (read-only — created via CLI/MCP)
- Plugin Health widget (read-only — plugins managed via CLI)
- Leaderboard
- API Key listing (mint via CLI; UI shows existing keys + revoke only)
- Marketing landing page with `curl` / MCP setup snippets

### What is cut (moved to `legacy/dashboard-ui/`)

Write-path surfaces an MCP/CLI user never touches:

- Trade ticket (order entry) — replace with `finlet order` CLI + MCP tool
- Onboarding wizard + checklist — replace with `finlet quickstart` CLI
- Plugin install/configure UI — replace with `finlet plugins install/configure` CLI
- Settings write tabs (API key creation, plugin config, password change)
- All modal-based create/edit flows
- Form-dirty tracker (dead with no forms)
- Dialog-state-mirror write-path consumers (read-only consumers stay)

### What survives but with reduced scope

- `scripts/lint-trusted-types.sh` — keep (defensive, even on read-only surfaces)
- `scripts/lint-event-bus.sh` — keep (still useful for read-only bus consumers)
- `dashboard/event-contract.md` — prune to only events the read-only surfaces consume
- `tests/e2e/` — write-path journeys move to `legacy/tests/e2e/` (kept executable but excluded from CI)

### Why `legacy/dashboard-ui/` not git-tag-only

Two restore mechanisms, different strengths:

- **Git tag `pre-ui-cut-2026-05-06`** — clean, full-tree snapshot, zero clutter on main. Restore via `git checkout pre-ui-cut-2026-05-06 -- dashboard/`.
- **`legacy/dashboard-ui/` directory** — visible, greppable, walkable. An agent that's never read this decision record but greps for "trade ticket" finds the legacy version and remembers it existed. Humans walking the repo see it. Discoverability beats compactness.

User explicitly requested "obvious spot" → directory wins. We do BOTH: tag is the safety net, dir is the discoverable surface.

`legacy/README.md` warns no one to modify; pre-commit hook (`scripts/lint-no-legacy-edits.sh`) blocks edits in `legacy/`. CI excludes `legacy/` from test runs and lint checks. `.gitattributes` marks `legacy/**` as `linguist-vendored` so it doesn't pollute repo language stats.

---

## Consequences

### Wins

- **~65 of 69 recurring bug categories retire.** `dashboard-state-sync`, `onboarding-checklist`, `dirty-state-tracker`, `dead-affordance`, `modal-stacking`, `aria-label-mismatch`, `password-form-aria`, `price-discrepancy` — all cease to be active categories. They remain in the historical ledger as evidence the cut was warranted.
- **Bug-hunt iterations get cheaper.** A monitoring-only dashboard has a much smaller blind-walk surface. Iterations should find ≤2 broken items each instead of 3-5.
- **CLI/MCP gets the engineering attention it should always have had.** The blind agent's #1 finding (MCP discoverability) becomes the next iteration's target.
- **Launch positioning honest.** "Agentic eval harness with monitoring dashboard" is what we say we are. "Trading SaaS with weird MCP bolt-on" is what we were shipping.

### Costs

- **Sunk-cost write-off.** Months of UI work effectively retired. Mitigated by `legacy/` preservation — nothing is destroyed, just deactivated.
- **Read-only-only feels limiting to first-time human visitors.** Marketing landing page must explicitly direct humans to `npm install -g finlet` or the MCP setup guide. Without this, finlet.dev visitors will think the product is broken when "Place trade" doesn't exist in the UI.
- **One-time migration cost.** A planned refactor (this doc + scope at `docs/bug-hunt/refactor-queue/ui-removal-launch-cut.md`) to do the move cleanly with file moves preserving git history.

### Reversibility

Fully reversible. To restore a write-path surface:

1. `git mv legacy/dashboard-ui/<surface>/* dashboard/<surface>/` (or copy from the tag)
2. Re-add to `dashboard/index.html` includes
3. Re-enable corresponding tests in CI config
4. Re-add to `dashboard/event-contract.md` if the surface uses bus events

Cost of reversal: roughly the same as cost of the cut. Decision is reversible at any time.

### Validation

Before declaring this refactor effective (verdict: effective on the queue doc):

- Next bug-hunt iteration's blind walk completes the "log in → place a trade" task entirely via CLI/MCP without touching the UI.
- Zero new entries in ledger.jsonl with the categories listed in the table above.
- finlet.dev `/health` returns 200 with the read-only dashboard rendering correctly.
- e2e read-only journeys (sessions list, equity curve render, plugin health load) pass on CI.

If the next blind walk still finds UI write paths (we missed something) or new bug categories specific to the read-only surface emerge, verdict is `incomplete` and the queue doc gets a follow-up scope.

---

## Related

- Bug-hunt skill: `.claude/skills/bug-hunt/SKILL.md`
- Bug-hunt ledger: `docs/bug-hunt/ledger.jsonl`
- Refactor scope (execution-ready): `docs/bug-hunt/refactor-queue/ui-removal-launch-cut.md`
- Project memory: `project_ui_cut_for_launch.md`
- Triggering blind report: `docs/bug-hunt/20260507T042257Z3c76/blind_report.json`
- Positioning: `project_finlet_positioning.md` (memory)
