# Decision: Fundamentals plugin distinguishes ETFs and classifies S3 errors

Date: 2026-05-19
Status: shipped (MCP_BENCHMARK_FIXES batch, Team C — commit 3098ac8)

## Context

`_download_from_s3()` collapsed `NoCredentialsError`, `ClientError(NoSuchKey)`,
`ConnectionError`, and any other exception into the single `bool` return
value `False`. The caller in `_query_list` then emitted "Check network
connectivity and AWS credentials" even when the actual cause was that the
ticker was an ETF (no per-issuer fundamentals exist for ETFs).

## Decision

1. `finlet/plugins/base.py` exposes `KNOWN_ETF_TICKERS: frozenset[str]`
   (22 most-traded US ETFs) and `is_known_etf(ticker) -> bool`. Additive
   only — no existing exports change.
2. `_download_from_s3()` returns `S3DownloadResult(ok, error_kind, error_message)`
   with `error_kind: Literal["none", "no_credentials", "no_such_key",
   "connection_error", "other"]`. Catches `NoCredentialsError`, `ClientError`
   (inspects `e.response["Error"]["Code"]` for `404`/`NoSuchKey`/`NoSuchBucket`),
   `EndpointConnectionError`, and `ConnectionError/TimeoutError/OSError`
   separately. Default catch-all stays for unknown errors.
3. The downstream tuple contract `(items, bool)` returned by `_read_ticker_data`
   is preserved (legacy tests patch it directly); the structured result is
   stashed on `self._last_s3_result` for the `_query_*` error-branch logic
   via `_classify_s3_failure_error` / `_classify_no_data_error` helpers.
4. Agent-visible messages now distinguish: ETF (with pointer to
   `get_price_data`), unknown ticker not in data lake, infra failure
   (credentials/connectivity).

## Consequences

- Agents querying ETFs get an actionable message, not a misleading
  "check AWS credentials" error.
- Real infra failures remain identifiable and ops-actionable.
- The ETF allowlist is a short, hand-curated constant. Non-allowlisted
  ETFs still get "not in data lake" (better than the old infra error);
  follow-up to expand from exchange ticker tables is open.
