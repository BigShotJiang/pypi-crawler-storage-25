# AI Quantamental Strategy — Subproject v1

> Date: 2026-05-19
> Status: Shipped (7-team exec-plan)
> Related: `docs/ARCHITECTURE.md` → `## Strategies`, `CLAUDE.md` File Ownership table (adds `strategies/` → `strategies` team)

A long-running AI-augmented trading strategy built as a Finlet subproject. Dual purpose: (a) generate a credible launch-video story via 12-month backfilled returns plus ongoing monthly content; (b) dogfood Finlet's MCP tool surface, session model, and order engine to surface bugs.

## Locked Decisions

### Strategy shape — quantamental hybrid, parallel quality + momentum screens with LLM as tiebreaker only

Two parallel rules-based screens (Novy-Marx gross profits/assets for quality; Jegadeesh-Titman 12-1 total return for momentum) → take the intersection → equal-weight 10-15 names. The LLM (Claude) is a tiebreaker on the ~30→10 narrowing pass, NOT a weighted factor in the selection score. Rules-based screens carry the alpha; the LLM is a marginal, contested edge per Lopez-Lira/Tang 2024. Rejected: Piotroski F-score standalone (lost 9.5%/yr on S&P 500 last decade), Magic Formula (underperformed SPY every year 2014-2024), pure technical analysis (deterministic — no "AI" framing value), LLM as load-bearing signal (lookahead-bias contamination risk).

### Nested package layout — `strategies/ai_quantamental/ai_quantamental/`

The subproject directory `strategies/ai_quantamental/` holds its own `pyproject.toml` + `README.md` at the root, and the importable Python package `ai_quantamental/` nested one level deep. `[tool.hatch.build.targets.wheel] packages = ["ai_quantamental"]` lets the subproject ship as its own distribution (`pip install -e strategies/ai_quantamental`) while presenting a clean `import ai_quantamental.screens.quality` namespace. Distribution name is `ai-quantamental` with `Private :: Do Not Upload` classifier — explicit signal this is not a public PyPI release. Hatchling's default `packages = ["finlet"]` in the root `pyproject.toml` excludes `strategies/` from the published Finlet thin-client wheel automatically. Rejected: `bots/quantamental/` and `examples/ai-quantamental/` directory names (less precise about purpose); flat layout without nested package (no clean way to host the subproject's own `pyproject.toml` without polluting Finlet's root package namespace).

### `report_bug` MCP tool re-uses `finlet:read` scope, NOT a new `finlet:telemetry`

The brainstorm originally proposed minting a fresh `finlet:telemetry` scope for the `report_bug` tool. The shipped implementation re-uses the existing `finlet:read` scope. Rationale: (a) adding a new scope expands the OAuth surface (DCR registration, scope-consent UI, scope-grant audit trail) for a closed-beta tool with one current consumer (this subproject); (b) `cancel_order` already follows this precedent — it's gated by `finlet:read` rather than `finlet:trade` because cancelling one's own pending order is a session-state operation, not a fresh write-path action; (c) the change is forward-compatible — a `finlet:telemetry` scope can be added in a follow-up without breaking the v1 contract because every JWT carrying `finlet:read` today would also be granted `finlet:telemetry` at scope-expansion time. Tool ownership and storage backing are unchanged: `finlet/mcp/tools_telemetry.py` for registration, `finlet/telemetry/bug_storage.py` for boto3 + JSON to `s3://finlet-bug-reports/` (follows `GdprS3Storage.upload_archive` pattern, NOT `S3ParquetWriter` — manifest discipline is for data-lake-shaped writes).

### Hosting — GH Actions monthly cron, not Hetzner

Originally scoped for Hetzner-hosted cron alongside the agent ops stack. Hetzner ops box was cancelled before this shipment (see `project_agent_ops_stack.md` retirement) — replaced with `.github/workflows/quantamental-rebalance.yml` triggered on `cron: '0 21 1 * *'` (21:00 UTC on the 1st of each month) plus `workflow_dispatch` for ops testing. GH Actions provides: free runner time (well within the 30-min per-run budget), auto-commit back to main as `finlet-bot[ai-quantamental]`, auto-opened GitHub issue on failure, OIDC AWS access via `AWS_DEPLOY_ROLE_ARN`. Idempotency marker at `s3://finlet-bug-reports/quantamental/last-rebalance.json` prevents re-runs inside the same month from double-trading.

### Sharpe targets — 0.6 base / 0.8 stretch

Brainstorm initially had Sharpe ≥0.8 as the base case, anchored on AQR-style QMJ Sharpe ~1.0 from Asness/Frazzini/Pedersen 2019. Revised down because that paper's Sharpe is long-short with leverage — long-only retail after costs strips roughly half the Sharpe. v1 base case is 0.6 (long-only equal-weight quality+momentum intersection after commission + 10bps slippage on Finlet's order engine), stretch is 0.8. Tracked alongside excess return vs SPY total return (positive over the 12-month backfill, tracked-not-gated) and max drawdown (<25% over the backfill window).

### Paper trading only — forever (for now)

No real brokerage integration. Tax modeling assumed zero. Universe is Finlet's curated US equity list (`scripts/ticker_lists/us_equities.txt`, ~236 tickers, S&P 500 + large/mid caps). No options, no futures, no shorts, no leverage. Monthly cadence, long-only, equal-weight. Revisit if results justify — trivial to graft a real-brokerage adapter onto the existing order engine.

## Out of Scope (v1)

- Future pip-packaging of `ai-quantamental` (deferred — CI-only is sufficient for v1)
- A general "strategies framework" abstraction — this is the first and only strategy
- Real-time intraday trading, multi-account bot operation, auto social-media posting, web dashboard for the bot
- Russell 3000 universe expansion, bank-specific quantamental factors (NIM, deposit growth), multi-strategy comparison harness — all deferred
- LLM as weighted factor in the selection score, real-time news ingestion, RAG against the corpus, claim that the LLM "predicts" returns

## Follow-ups (Tracked in REMAINING_TASKS.md)

1. Verify monthly cron fires `2026-06-01T21:00:00Z` — confirm auto-commit of `strategies/ai_quantamental/runs/2026-06.{md,json}`.
2. Backfill SPY benchmark data into `s3://finlet-data-cccdea31/prices/daily/SPY/` if missing.
3. Register `pytest.mark.network` marker in `strategies/ai_quantamental/pyproject.toml`.
4. Clean up lingering mypy error at `strategies/ai_quantamental/tests/test_metrics_ttm.py:197`.
