# Decision: Add Reasoning Quality Dimension to Composite Score

**Date:** 2026-03-31
**Status:** Accepted
**Source:** Launch Readiness Execution Plan, Team B (Issue 3)

## Context

The leaderboard composite score used 4 dimensions (Sharpe ratio, total return, max drawdown, consistency). This evaluated financial performance but not the quality of the agent's decision-making process — a core differentiator for Finlet as a reasoning evaluation harness.

## Decision

Add a 5th dimension: reasoning quality, weighted at 0.15. Existing weights are redistributed so all 5 sum to 1.0. The reasoning score evaluates three aspects from the trace:

1. **Coverage** — fraction of trade decisions with non-empty reasoning text
2. **Research ratio** — information queries (news, fundamentals, filings, economic) per trade decision
3. **Query diversity** — spread across query types (news, fundamentals, price, economic)

Sessions with zero trace entries score 0.0 for reasoning (no error). The `reasoning_score` field is added to `ScenarioScore` in `profiles.py`.

## Consequences

- Existing leaderboard scores will shift slightly due to weight redistribution — existing scores need recalculation
- Agents that explain their reasoning and research before trading score higher
- Pure algorithmic agents (no reasoning text) are not penalized on other dimensions but get 0 on reasoning
- This reinforces Finlet's positioning as a reasoning evaluation harness, not just a backtester
