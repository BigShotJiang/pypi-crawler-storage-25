# Session-Level Blind — Extend `create_session`, Don't Fork

> Date: 2026-05-22 (extended post-ship with Round 4 BLOCKER history + wall-clock redaction + atomicity reorder)
> Status: Shipped (multi-team exec-plan A→G + 6 fix commits, baseline SHA `b1a305f`, terminal SHA `e33cfb0`)
> Related:
> - `docs/decisions/blind-benchmark-architecture.md` (V1 — canonical 5-scenario benchmark blind)
> - `docs/decisions/blind-benchmark-envelope-fields-must-blind.md` (owner-view tools must blind)
> - `docs/decisions/blind-mapping-scenario-and-universe.md` (`BlindMapping` design)
> - `docs/decisions/session-public-visibility.md` (`public` + `public_anonymous` flags)
> - `docs/brainstorms/SESSION_LEVEL_BLIND_REQUIREMENTS.md` (requirements v2)
> - `docs/brainstorms/SESSION_LEVEL_BLIND_EXECUTION_PLAN.md` (exec-plan v12)
> - `docs/ARCHITECTURE.md` → "Blind Benchmark Mode" section + "Session-Level Blind Mode" extension at ~line 1620

Before this work, blind mode was only reachable via `start_benchmark(blind=True)` against the canonical 5-scenario `BENCHMARK_SCENARIOS` list. Dogfooding AI trading agents on ad-hoc custom periods / universes — the primary user story for Finlet — had no blind entry point. This decision record locks the choices that turned that single entry point into a session-level capability without forking the blind plumbing.

## Locked Decisions

### Extend `create_session`, do NOT add `create_blind_session`

`mcp__finlet__create_session` is the canonical session creation surface (REST `POST /v1/sessions` and CLI `finlet sessions create` derive from it). We add a `blind: bool = False` kwarg rather than introducing a parallel `create_blind_session` tool.

Rationale:
- Parallel tools double the agent's surface and force every downstream tool that resolves "the current session" to enumerate two creation paths.
- The blind / non-blind code paths share ~95% of validation, persistence, ownership, and rate-gate logic. Forking would mean drift across both paths.
- A boolean kwarg matches the existing `start_benchmark(blind=True)` idiom.
- MCP-first architecture (per `docs/ARCHITECTURE.md` → "MCP-First Tool-Use Contract") is preserved: REST + CLI signatures derive from MCP, not the other way around.

Rejected: separate `create_blind_session` MCP tool (cited in original v1 brainstorm before Codex Step 1.5 STRONG-SUGGESTION 9 softened it).

### Auto-generate session name `blind-{session.id[:8]}` at creation; reject name changes thereafter

When `blind=True`, the service sets `session.name = f"blind-{session.id[:8]}"` immediately after `Session.__init__` and BEFORE the first `save_session(session)`. User input on `name` is ignored. `configure_session(name=...)` returns 409 on blind sessions for the lifetime of the session.

Rationale:
- Owner-chosen names leak the agent's strategy intent, the regime under test ("covid-crash-stress-test"), or other adversarial signals to public viewers when the session is opted `public=True`.
- The eight-character session-id suffix is uniformly distributed and carries zero semantic content.
- Pinning the name at creation rather than at first-publish closes the leak window even if the owner forgets to opt the session public until later.

Rejected: allow owner to set a custom name and strip it at public-publish time (still leaks via authenticated public-viewer fetch before the strip; adds an additional code path); rename on `set_session_visibility(public=True)` (race window).

### Reuse existing blind plumbing — no fork of `BlindMapping`, `generate_mapping`, `_blind_mapping_for`, helpers

The session-level path attaches `BlindMapping` via the SAME `generate_mapping(universe, start, benchmark_ticker=...)` factory used by `create_scenario_session` (`finlet/leaderboard/benchmark_state.py`). The `@blind_error_mapper` decorator on MCP tools, the `assert_no_real_blinded_data` chokepoint, the `apply_ticker` / `apply_date` / `reverse_ticker` helpers, the `_KNOWN_BENCHMARK_TICKERS` frozenset defense, the SSE/trace blinding, the news short-circuit branch — all unchanged. Only the entry point widens.

Rationale:
- Forking the helpers would double the surface for the 5+ Codex blind-leak bug iterations already shipped (`ce8de077`, `50abd05e`, `d1baf1b8`/`ad919e11`/`53c9eccb`, `a93a7ff2`, `2cd01283`, the 4-pack v2, etc.). Every helper has been hardened against a specific real-world leak pattern; reusing them inherits all that hardening.
- The `_blind_mapping_for(session)` helper is the single source of truth for "is this session blinded? if so, give me the mapping." It is moved from `finlet/api/serializers.py` into `finlet/api/services/session_service.py` (Team A) so the import direction stays forward (services → serializers, not the reverse). `serializers.py` re-imports it for back-compat.

Rejected: dedicated `session_blind_mapping.py` module (creates a parallel implementation tree); leaving `_blind_mapping_for` in `serializers.py` and importing back from services (introduces a circular import).

### Nuke the hardcoded 50-ticker universe cap; enforce catalog membership instead

The previous `SessionCreateRequest.universe: Field(max_length=50)` cap was an arbitrary heuristic with no architectural justification. The real constraint is catalog membership: every requested ticker MUST appear in the union of `scripts/ticker_lists/us_equities.txt` (199 entries) + `scripts/ticker_lists/us_etfs.txt` (71 entries) — 270 tickers total, per `_UNIVERSE_SOURCES` in `finlet/api/routes_market.py`. The same gate fires on `configure_session(universe=...)` for non-blind sessions (`configure_session` rejects any `universe` change on blind sessions outright).

Off-catalog tickers get a specific actionable error: `"ticker '<X>' not in catalog — call list_available_tickers"`. The benchmark path is exempted via a private `_skip_catalog_check: bool = False` kwarg passed by `create_scenario_session` (BENCHMARK_SCENARIOS reference legacy non-catalog tickers; auditing those is a separate cleanup).

Rationale:
- The 50-cap was the only thing stopping a Pro-tier user from running a 200-ticker session that the data pipeline can serve trivially. Pricing tiers gate by feature (blind mode, leaderboard publish), not by an arbitrary universe-size knob.
- Catalog membership is the gate that actually matters: a ticker not in the catalog has no S3 backfill, no plugin coverage, no rate-limit budget. Failing fast at session create is friendlier than failing on the first `get_price_data`.
- The Free + Builder pricing cards are updated by Team G to advertise "Unlimited tickers per session".

Rejected: keep the 50-cap and add a tier-based override (complicates billing for zero correctness gain); raise the cap to 200 (still arbitrary); silent skip of off-catalog tickers (hides a typo).

### Visibility flags ARE the reveal lifecycle — no new decrypt tool

Custom blind sessions reveal to public viewers via the EXISTING `set_session_visibility(public=True, public_anonymous=False)` surface. Toggling `public_anonymous=False` reveals the real universe + dates to anonymous public viewers; toggling back re-blinds. There is no persisted `revealed_at` state, no new `decrypt_session` MCP tool, no `decrypted_universe` column.

Rationale:
- The benchmark `decrypt_benchmark_run` lifecycle exists because benchmark runs persist a `BenchmarkRunModel` row with its own `published` / `decrypted_at` columns and a publish-gate. Sessions do not have that lifecycle — they have visibility flags that are toggled live.
- Adding a parallel decrypt surface for sessions would create a second source of truth for "is this session revealed?" that downstream serializers and the dashboard Reveal toggle would have to merge.
- The owner ALWAYS sees real data on authenticated REST + dashboard surfaces today (per `_blind_mapping_for` returning `None` on those paths) — the owner-side reveal is already implicit.

Rejected: `decrypt_session` MCP tool (REPLACED in requirements v2 BLOCKER 2 resolution); `revealed_at` timestamp column (no consumer); persistent `decrypted_universe` snapshot (the universe is already on `session.config`).

### HEAD's mixed owner-surface audience contract is PRESERVED — reveal lifecycle harmonization deferred

The audience-behavior matrix in the requirements v2 doc oversimplified to "owner = real everywhere." The HEAD `b1a305f` reality is mixed: the authenticated owner sees REAL on `routes_session.py` (get/list/create/configure/visibility), `routes_portfolio.py` (`/portfolio`, `/portfolio/history`), `routes_clock.py`, `routes_trade.py` — but sees BLINDED on `routes_portfolio.py` (`/trace`), `routes_market.py` (`/price`, `/fundamentals`, `/filings`, `/search-news`), and `routes_sse.py`. The plan's "Audience contract" table (in the v12 Constraints section) is the precise authoritative breakdown.

This work does NOT harmonize that mix. Owners still see some REST surfaces real and some blinded; the harmonization is deferred to a future iteration with its own decision record (see "Deferred" below).

Rationale:
- Harmonizing would require either (a) blinding more surfaces (regressing dashboard UX for owners who want to inspect their own real positions) or (b) un-blinding `/trace`/`/market`/`/sse` for the owner (requires a new "owner-only" axis on `_blind_mapping_for` that today returns the same shape for owner and public-anonymous).
- (b) is the right end-state but is a larger refactor than this work's scope (extend the create surface, attach `BlindMapping` correctly, close known leak gaps).
- This work explicitly avoids overstating the audience guarantees in the requirements doc — Team F's requirements-doc correction (this iteration's docs/F deliverable) replaces the "owner = real" cells in the matrix with surface-by-surface accuracy.

### Catalog membership enforced on BOTH `create_session` AND `configure_session(universe=...)`, at the SERVICE layer only

The `configure_session` path was previously a back door: a non-blind session could be created with a clean universe, then re-configured with off-catalog tickers. Codex Step 10h BLOCKER 5 caught this. Both paths now apply the same `_validate_universe_in_catalog` check; the benchmark exemption via `_skip_catalog_check` is the only allowed bypass and is not exposed via REST request models (only `create_scenario_session` calls service-layer `create_session(_skip_catalog_check=True)` directly).

For BLIND sessions, `configure_session(universe=...)` is rejected outright (409) — the `BlindMapping` is built at create-time and changing the universe mid-session would either invalidate the mapping or require a re-seed that breaks the deterministic `T_NNNN` ↔ real-ticker correspondence the agent has been working with.

**Round 4 revert: schema-layer catalog enforcement REMOVED.** The Team C v1 implementation also ran the catalog check inside the Pydantic `validate_universe` validators in `finlet/api/routes_session.py` (both `SessionCreateRequest` and `SessionConfigureRequest`). Codex Round 4 flagged this as broken-by-design: Pydantic validators run BEFORE FastAPI's `Depends` resolution, so they don't have access to the authenticated `UserRecord` — which is where the unforgeable `is_internal_benchmark` bypass marker lives. With schema-layer enforcement in place, the `ApiDrivenStrategy` benchmark runner would 422 on every scenario submit because the validator would reject `BTC-USD` before the route handler could check `user.is_internal_benchmark`. The schema validators were downgraded to per-ticker shape gate ONLY (length + character validation); catalog membership is enforced at the service layer where the bypass marker is in scope. Docstrings on both validators now point to `finlet/api/services/session_service.py::_get_catalog` for the architectural note.

### Benchmark catalog bypass keyed on UNFORGEABLE `UserRecord.is_internal_benchmark` marker — NOT email

The `_skip_catalog_check=True` bypass that lets `ApiDrivenStrategy` submit benchmark scenarios with non-catalog tickers (`BTC-USD` and similar) is gated by an authenticated `UserRecord` flag, NOT by request body, header, or email.

Field: `finlet.auth.service.UserRecord.is_internal_benchmark: bool = False`.

Unforgeability argument (the three properties that make this safe):

1. **NOT a column on `ApiKeyModel`.** `_record_to_model` / `_model_to_record` in `finlet/auth/service.py` never round-trip this field through SQLite. DB-row injection (e.g. a malicious `UPDATE api_keys SET ...`) cannot set it. A reboot resets all in-memory state — the flag must be re-injected each process lifecycle.
2. **NOT exposed in any user-facing creation surface.** `RegisterRequest`, `create_key`, and `register_with_password` do not accept this field. Every user-facing registration path leaves it at the default `False`. There is no admin REST/CLI surface to flip it.
3. **Settable ONLY by `_inject_benchmark_api_key`.** This function in `finlet/leaderboard/api_strategy.py` builds the `UserRecord` directly (with `is_internal_benchmark=True`) and calls module-internal `AuthService.insert_record`. It is invoked at process startup by the in-memory benchmark runner and nowhere else.

**Why this is a BLOCKER history, not a brand-new design.** A prior fix (commit `620d825`) scoped the catalog bypass to the api-driven benchmark API key via `user.email == BENCHMARK_API_EMAIL` (the literal string `"benchmark@finlet.dev"`). Codex's BLOCKER follow-up caught that `/auth/register` normalises emails with `.strip().lower()` and does NOT blocklist any address, so any caller could register an account with `benchmark@finlet.dev`, mint a Builder-tier API key, and bypass the discovery catalog gate. The bypass moved from email-based to flag-based in commit `e33cfb0`.

`BENCHMARK_API_EMAIL` is RETAINED as a string constant in `finlet/leaderboard/api_strategy.py:1009` for log-provenance only — `_inject_benchmark_api_key` still uses it as the `UserRecord.email` field so benchmark-runner log lines carry a recognizable email anchor. The constant's docstring warns against reusing it as an authz marker.

Regression coverage:
- `tests/api/test_session_create_blind.py::test_forged_benchmark_email_cannot_bypass_catalog` — mints a key via `create_api_key(email=BENCHMARK_API_EMAIL, ...)` (i.e. forges the email) and asserts the `POST /sessions` response with an off-catalog ticker is 422, NOT 201.
- `tests/leaderboard/test_api_strategy.py::test_injected_user_carries_internal_benchmark_marker` — pins that `_inject_benchmark_api_key` sets `is_internal_benchmark=True` on the minted `UserRecord`.

Rejected alternatives: header marker (smuggleable by any client); request-body marker (defeats the entire scoping fix); `tier=ENTERPRISE` repurposing (collides with the admin-grant pattern documented in `reference_admin_grant_pattern.md`); per-API-key allowlist (introduces persisted state that DB-row injection could touch).

### `configure_session` atomicity — validate ALL inputs BEFORE mutating ANY state

The prior `configure_session` ordering assigned `session.name` first, THEN ran catalog validation on `universe` — when validation raised, the rename leaked into the in-memory session until the next reload. Codex Team A P2 caught this. The fix reorders all input validation (catalog check + `time_step` parse) BEFORE any of (`name` / `universe` / `time_step`) commit. The non-blind path (both kwargs present, off-catalog universe → `ValidationError` + `session.name` unchanged + `session.config.universe` unchanged) is locked by `tests/services/test_session_service.py::TestConfigureSessionAtomicity::test_universe_validation_runs_before_name_mutation`.

### Wall-clock audit fields REDACTED (not blinded) on blind responses

`session.created_at` and `session.updated_at` are WALL-CLOCK audit timestamps — NOT simulation dates. Running them through `apply_date(Day_N)` is a real information leak: an agent that knows today's wall-clock date PLUS the emitted `Day_N` offset can compute `Day_1 = wall_clock_today - (Day_N - 1) days` and reverse-derive the blind session's real `config.start_time`. The defensive ISO-date sweep in `session_response()` / `_apply_blind_to_response` would have caught `created_at` and applied the Day_N transform.

The fix (Codex Team B P1, commit `ff79ab7`) replaces these fields with the literal sentinel string `"redacted"` as the FINAL post-processing step in the blind path — after any defensive blind transform — so a future date-walking transform inserted above cannot re-leak. Owner-view (non-blind) responses still emit a real ISO-8601 timestamp.

Schema typing: `SessionResponse.created_at` and `PublicSessionResponse.created_at` were retyped from `datetime` to `str` so the `"redacted"` sentinel validates through FastAPI's `response_model`. Real ISO timestamps continue to validate unchanged because str accepts both shapes.

Rationale (why redact, not blind):
- `apply_date(Day_N)` is the right transform for SIMULATION dates (`config.start_time`, `clock.current_time`, `Day_N` is a sensible relative offset from `config.start_time`).
- For WALL-CLOCK audit timestamps, no Day-N offset makes sense — the field's semantic meaning is "when did the operator create this session in real time," which has no relationship to the simulation timeline. Emitting any transformed wall-clock value gives the agent computable signal.
- Redaction (a literal placeholder) gives the agent zero signal — the field exists in the response shape but carries no information.

Rejected: drop the field entirely (breaks `response_model` validation and breaks downstream consumers who key on its presence); emit `None` (mypy strictness + nullable semantics churn across the schema layer); emit the session id as a placeholder (still leaks creation-order metadata).

Regression coverage:
- `TestSessionResponseBlind.test_blind_session_response_redacts_wall_clock_created_at`
- `TestSessionResponseBlind.test_non_blind_session_response_preserves_created_at`
- `TestPublicSessionResponseWallClockRedaction.test_blind_public_session_redacts_created_at`
- `TestPublicSessionResponseWallClockRedaction.test_non_blind_public_session_preserves_created_at`

### `freeze_time` MCP clock-tool gap closed; clock-tool audit completed

`finlet/mcp/server.py::freeze_time` returned `_svc_freeze_session(session)` directly with REAL clock dates (`get_sim_time` and `advance_time` already applied `_blind_clock_dict` / `_blind_advance_result` helpers). Team B closes that gap by applying the appropriate existing helper, and audits all other clock-touching MCP tools (`step_time`, `play`, `pause_clock` if present) for the same pattern.

## Out of Scope (This Iteration)

- **Harmonizing HEAD's mixed owner-surface behavior** — owners still see some REST surfaces real and some blinded post-this-work, matching HEAD. A future iteration (with its own decision record) can introduce an "owner-only" axis on `_blind_mapping_for` so all owner-routed REST surfaces return real consistently. Not load-bearing for this work's acceptance.
- **Owner-visible "blind active" badge in the dashboard** — UX nicety. `SessionResponse.blind: bool` IS exposed at the top level of `session_response()` (mirroring `d["public"]`) so the dashboard CAN add the badge in a follow-up.
- **Leaderboard integration for custom blind sessions** — leaderboard stays scenario-locked. Custom blind sessions never produce a `BenchmarkRun` and therefore never appear on the leaderboard.
- **News short-circuit policy changes** — `search_news` continues short-circuiting in blind sessions via the existing `session.config.blind` branch.
- **`decrypt_session` MCP tool** — REPLACED by the visibility-flag-as-reveal model (above).
- **Landing-page hero copy rewrite** — deferred until this feature ships so the marketing copy can describe what actually works (a single follow-up direct Edit, not a planned feature).
- **Database migration for `revealed_at` / `decrypted_universe` columns** — not needed under the visibility-flag-as-reveal model.

## Deferred (Future Iteration)

- **Owner-surface audience harmonization** — introduce an "owner authenticated" axis on `_blind_mapping_for` so that `routes_portfolio.py::/trace`, `routes_market.py::*`, and `routes_sse.py` return REAL to the authenticated owner of a blind session. Today they return BLINDED for both the owner and public-anonymous viewer (HEAD behavior, preserved by this work).
- **Repositioning README + top-level pitch around blind benchmarking** — current "evaluation harness for AI trading agents" framing stands. Reconsider once dogfooding produces enough custom-blind sessions to validate the framing.
- **News-included blind sessions** — would require an LLM rewrite per session seed (V2 of the news anonymization track, parallel to the benchmark V2 news track).

## File Map (Production Code — Teams A through G + 6 fix commits)

- `finlet/api/services/session_service.py` — `create_session(blind: bool = False, _skip_catalog_check: bool = False, ...)`, `_blind_mapping_for(session)` moved here, `configure_session` catalog enforcement + blind-session rejection + validate-then-mutate atomicity, auto-name on blind, `BlindMapping` attached BEFORE first `save_session`, `_get_catalog()` unions `BENCHMARK_SCENARIOS` tickers, `session_response()` redacts wall-clock audit fields on blind responses.
- `finlet/api/serializers.py` — `_blind_mapping_for` re-imported from `session_service` for back-compat; `session_response()` populates `d["blind"]` at top level; `_apply_blind_to_response` redacts wall-clock audit fields on public-session payloads.
- `finlet/api/routes_session.py` — `SessionCreateRequest.blind: bool = False`, `SessionConfigureRequest.blind` rejected (config-only), explicit kwarg forwarding (no `_skip_catalog_check` smuggling), `max_length=50` removed from `universe` field on both request models, `validate_universe` validators downgraded to per-ticker shape gate ONLY (catalog enforcement moved to service layer — Round 4 revert), `skip_catalog = user.is_internal_benchmark` (unforgeable marker — Round 4 BLOCKER fix).
- `finlet/api/schemas/session.py` — `SessionConfigResponse.blind: bool = False` so nested `config.blind` round-trips; `SessionResponse.blind: bool` (already present, now populated); `SessionResponse.created_at: str` and `PublicSessionResponse.created_at: str` retyped from `datetime` to `str` so the `"redacted"` sentinel validates.
- `finlet/auth/service.py` — `UserRecord.is_internal_benchmark: bool = False` field (Round 4 BLOCKER unforgeable marker); NOT a column on `ApiKeyModel`, NOT exposed in any user-facing creation surface.
- `finlet/leaderboard/api_strategy.py` — `_inject_benchmark_api_key` sets `is_internal_benchmark=True` on the minted `UserRecord`; `BENCHMARK_API_EMAIL` constant retained for log provenance only with docstring warning against authz reuse.
- `finlet/mcp/server.py` — `create_session(blind: bool = False, ...)` kwarg, `freeze_time` blind wrap, `complete_session` non-benchmark blind wrap scoped to `status == "COMPLETED"`.
- `finlet/mcp/tools_session.py` — session-touching MCP tool success returns wrap through `_blind_mapping_for(session)`.
- `finlet/cli.py` — `finlet sessions create --blind` flag (dispatches MCP); CLI prints `response.config.universe` (post-normalization) not the local `--universe` input string.
- `finlet/leaderboard/benchmark_state.py` — `create_scenario_session` passes `_skip_catalog_check=True` to service-layer `create_session`.
- `finlet/billing/stripe_config.py` — `max_tickers=None` for FREE and BUILDER tiers.
- `dashboard/app.js`, `dashboard/index.html`, `dashboard/pricing.html` — universe-cap UI checks removed; Free + Builder cards advertise "Unlimited tickers per session".

## Test Coverage (Team E + fix-commit regression tests)

- Both-and leak gate: `assert_no_real_blinded_data` chokepoint AND serialized grep gate on every `@blind_error_mapper`-decorated MCP tool (enumerated dynamically at test runtime from `mcp._tool_manager.list_tools()`).
- Real-ticker grep: every user-universe ticker + `benchmark_ticker` + `_KNOWN_BENCHMARK_TICKERS` entries produce 0 hits on the serialized response.
- Real-date grep: every ISO date string within `[start_time, end_time]` produces 0 hits.
- SSE + persisted-trace replays against a custom blind session pass the same two-axis gate.
- `freeze_time` regression: explicit assertion that the response carries `Day_N` not the real ISO date.
- `configure_session(name=...)` and `(universe=...)` both return 409 on blind sessions.
- `configure_session(universe=[<off-catalog>])` returns the catalog-rejection error on NON-blind sessions.
- `tests/billing/`, `tests/auth/`, and rate-gate tests under `tests/api/` retain green (no paid-GA / Stripe-live regressions).
- Negative test: a fixture that intentionally bypasses blind plumbing MUST fail the leak gate loudly.
- Fixtures monkeypatch `FINLET_BLIND_ASSERT=raise` so `assert_no_real_blinded_data` raises rather than logging.
- **Round 4 BLOCKER regression:** `tests/api/test_session_create_blind.py::test_forged_benchmark_email_cannot_bypass_catalog` (forges the email, asserts 422); `tests/leaderboard/test_api_strategy.py::test_injected_user_carries_internal_benchmark_marker` (pins the marker on the injected `UserRecord`).
- **Wall-clock audit redaction regression:** `TestSessionResponseBlind.test_blind_session_response_redacts_wall_clock_created_at`, `TestSessionResponseBlind.test_non_blind_session_response_preserves_created_at`, `TestPublicSessionResponseWallClockRedaction.test_blind_public_session_redacts_created_at`, `TestPublicSessionResponseWallClockRedaction.test_non_blind_public_session_preserves_created_at`.
- **`configure_session` atomicity regression:** `tests/services/test_session_service.py::TestConfigureSessionAtomicity::test_universe_validation_runs_before_name_mutation` (both kwargs present, off-catalog universe → `ValidationError` + `session.name` unchanged + `session.config.universe` unchanged).
- **Test-quality fixes (Codex Team E 3 STRONGs):** bound-import patch, advance_time sweep coverage gap closed, real pause/resume reload exercised end-to-end.

## Codex Review History

10+ adversarial passes across plan iterations v1-v12 (Steps 1.5, 10a-10k) PLUS 4 post-merge Codex rounds against the shipped code. Plan-phase: Step 10h flagged BLOCKER 4 (parallel B-C merge-order leak window) — resolved by forcing B → C in the dependency graph. Step 10h BLOCKER 5 flagged the `configure_session` catalog-membership back door — resolved by Team A item 9. Step 10i BLOCKER 1 corrected `complete_session` MCP status case (`"completed"` → `"COMPLETED"`). Step 10j NIT 2 corrected route paths (`/price` not `/prices`). Step 10k BLOCKER 1 closed the REST `complete_session` benchmark_transition leak gap. Two-pass review structure (v1→v2 + v2→v3) per `feedback_two_pass_codex_review.md`.

Post-merge Codex rounds (fix commits):
- **Round 1 (Team A P1+P2 → `427ad87`):** catalog `BENCHMARK_SCENARIOS` union missing → `ApiDrivenStrategy` would 422 on every scenario; `configure_session` non-atomic mutation leaked a half-applied `name` rename on universe-validation failure.
- **Round 1 (Team B P1 → `ff79ab7`):** wall-clock audit fields (`created_at`, `updated_at`) routed through `apply_date(Day_N)` and emitted `Day_N` instead of REAL ISO — agent could reverse-derive `Day_1`. Redaction with `"redacted"` sentinel as final post-processing step.
- **Round 1 (Team D P1 → `a5f8693`):** CLI session_create printed local `--universe` input instead of `response.config.universe` — blind leak on CLI.
- **Round 1 (Team E 3 STRONGs → `f60a7ec`):** test quality fixes (bound-import patch, advance_time sweep, real pause/resume reload).
- **Round 2 STRONG (Team A → `620d825`):** prior catalog-union fix exposed `BENCHMARK_SCENARIOS` tickers to ALL users (global union too broad) → scope to api-driven path only via `user.email == BENCHMARK_API_EMAIL` literal check.
- **Round 4 BLOCKER (→ `e33cfb0`):** Round 2's email-based scoping is forgeable because `/auth/register` normalises emails with `.strip().lower()` and does NOT blocklist any address → introduced unforgeable `UserRecord.is_internal_benchmark` boolean marker; field NOT a column on `ApiKeyModel`, NOT exposed in any user-facing registration surface, settable only by `_inject_benchmark_api_key`. `BENCHMARK_API_EMAIL` retained for log provenance only.
