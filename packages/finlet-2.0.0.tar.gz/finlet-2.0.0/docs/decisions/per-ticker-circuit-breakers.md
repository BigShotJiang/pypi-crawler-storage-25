# Decision: Circuit Breakers Are Scoped Per (Plugin, Ticker)

**Date:** 2026-04-10
**Status:** Accepted
**Source:** FIELD_AUDIT_FIXES sprint, Team A

## Context

Circuit breakers in `PluginRegistry` were originally scoped per plugin — one `CircuitBreaker` instance per plugin serving all tickers. The breaker would trip after 5 consecutive failures from any ticker and block **every** ticker served by that plugin for the 60-second reset timeout.

This produced a cascading failure mode. A single stale or missing symbol (e.g. an MSFT data hole in the S3 Parquet, or a briefly flaky Finnhub response for one company) would trip the plugin-wide breaker, and agents trying to query unrelated tickers like AAPL or NVDA would all fail fast with the same generic outage. Healthy tickers were punished for another ticker's upstream issue.

Compounding the problem, the `_is_transient_error()` classifier routed S3 `NoSuchKey` and `"no data available for ticker"` strings through the retry loop and counted them as breaker failures. These are not transient — retrying a missing ticker cannot fix the absence — but they still contributed to the failure count and tripped the breaker for every other ticker.

## Decision

**Scope circuit breakers per `(plugin_name, ticker)` pair.** `PluginRegistry._circuit_breakers` is now a nested dict `{plugin_name: {ticker: CircuitBreaker}}`. `get_circuit_breaker(plugin_name, ticker)` is the single lookup helper; queries without a ticker (e.g. economic series, macro data, search-style catalogs) fall back to a per-plugin `__default__` breaker for backward compatibility. `reset_all_circuit_breakers()` walks the nested dict.

**Classify data-absent errors as permanent.** `_is_transient_error()` now routes `NoSuchKey`, `"no data for"`, and `"no data available for ticker"` substrings as **permanent** errors. They bypass the retry loop and do not count toward the breaker failure threshold. Only true transient failures (timeouts, connection errors, 429/5xx, rate-limited upstreams) count against the threshold.

## Consequences

- A failing ticker is contained to that ticker's breaker. Healthy tickers on the same plugin continue to route normally.
- Per-session state is still reset via `create_session()` -> `reset_all_circuit_breakers()`, so a breaker tripped during a previous session does not bleed into the next one.
- Memory footprint grows slightly: one `CircuitBreaker` instance per observed ticker per plugin instead of one per plugin. For the 201-ticker equity universe this is ~201 breakers per S3-backed plugin — trivial.
- Pre-existing tests that relied on the old single-breaker-per-plugin contract (`test_circuit_breaker.py`, `test_plugin_resilience.py`, `test_clock_service_circuit.py`) were updated to address the correct `(plugin_name, ticker)` pair.
- The fix required a companion change in `clock_service.refresh_prices_and_fill_orders()` (Team B) so that position tickers can still fetch 30-day history fallback data even when a specific ticker's breaker is OPEN — portfolio valuation must not freeze just because new orders cannot be placed.
