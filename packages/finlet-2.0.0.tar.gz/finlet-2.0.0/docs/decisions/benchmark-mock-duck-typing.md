# Decision: Benchmark Mock Plugins Use Duck Typing, Not DataPlugin Subclasses

**Date:** 2026-04-01
**Status:** Accepted
**Source:** Phase 2: Enforcer Credibility Chain, Team A specification

## Context

Phase 2 introduced deterministic mock plugins for EDGAR filings, FRED economic indicators, and Finnhub news/fundamentals to enable multi-source enforcer validation during benchmark runs. The question was whether these mock plugins should subclass the `DataPlugin` ABC or use duck typing (matching the interface without formal inheritance).

The existing `BenchmarkPricePlugin` already used duck typing successfully.

## Decision

All benchmark mock plugins (`BenchmarkEdgarPlugin`, `BenchmarkFredPlugin`, `BenchmarkFinnhubPlugin`) are duck-typed — they implement the same method signatures as `DataPlugin` (`query()`, `initialize()`, `health_check()`, `get_types()`) and return `PluginResponse`, but do not inherit from `DataPlugin`.

## Rationale

1. **No API key management needed.** `DataPlugin` subclasses inherit `requires_api_key`, `free_tier_limits`, and configuration logic that benchmark mocks don't need. Duck typing avoids inheriting unnecessary complexity.
2. **Deterministic data generation is fundamentally different.** Real plugins fetch from external APIs; benchmark mocks generate data from hash seeds. Forcing them into the same class hierarchy conflates two different concerns.
3. **Consistency with existing pattern.** `BenchmarkPricePlugin` was already duck-typed and working correctly. Diverging for the new plugins would create an inconsistency.
4. **PluginRegistry compatibility.** The registry routes queries by plugin type string and calls `plugin.query()` — it does not check `isinstance(plugin, DataPlugin)`. Duck typing is sufficient for registration and dispatch.

## Consequences

- Benchmark mock plugins must manually maintain interface compatibility — if `DataPlugin` adds a new abstract method, mocks won't fail at import time (they'll fail at call time instead). This is acceptable because benchmark tests run on every commit.
- New mock plugins should follow this same pattern until there's a reason to formalize a `BenchmarkPlugin` base class.
- The duck-typed plugins live in `finlet/leaderboard/benchmark_plugins.py`, separate from production plugins in `finlet/plugins/`.
