# Decision: Guard at Domain Layer, Catch at API Layer

**Date**: 2026-03-28
**Status**: Resolved
**Context**: Session mutations (order submission, clock operations, portfolio updates) need to be rejected when the session is not in ACTIVE status. The question is where to enforce this — in the domain model, at the API/MCP boundary, or both.

---

## Problem

Before this change, `submit_order()`, `process_pending_orders()`, and clock methods accepted calls regardless of session status. A completed session's trace, portfolio, and leaderboard submission could be corrupted by late mutations. The fix needed to work across all three access paths: REST API, MCP server, and direct engine usage (tests, CLI).

---

## Options Evaluated

### 1. Guard at API/MCP boundary only (rejected)

Add status checks in each FastAPI route and MCP tool handler before calling session methods.

**Pros**:
- Easy to implement — just add `if session.status != ACTIVE: return 409` in each handler.

**Cons**:
- Every new API route or MCP tool that mutates a session must remember to add the guard.
- Direct engine usage (tests, future CLI commands) bypasses the guard entirely.
- Duplicated logic across API and MCP layers.
- Violates "make illegal states unrepresentable" — the domain allows invalid operations.

### 2. Guard at domain layer, catch at API layer (accepted)

Session mutation methods raise `SessionNotActiveError` (a domain exception) if `self.status != SessionStatus.ACTIVE`. The API layer catches this exception and returns HTTP 409 Conflict. The MCP layer catches it and returns a structured error message.

**Pros**:
- Single source of truth — the domain model enforces its own invariants.
- Works for all access paths (API, MCP, direct engine, tests).
- New mutations are automatically guarded — they inherit the check from the Session method they call.
- Clean separation: domain raises, transport layer translates to the appropriate error format.
- Testable in isolation — unit tests can verify the guard without HTTP overhead.

**Cons**:
- Requires each transport layer (API, MCP) to catch and translate the exception. But this is a one-time addition per transport, not per-endpoint.

### 3. State machine with transition validation (rejected)

Implement a formal state machine that rejects invalid transitions and restricts which methods are callable in each state.

**Pros**:
- Most rigorous approach.
- Could prevent other invalid transitions (e.g., COMPLETED → ACTIVE).

**Cons**:
- Over-engineered for the current problem — we only need "must be ACTIVE to mutate."
- Adds complexity without proportional benefit at this stage.

---

## Decision

Option 2: domain-layer guard with transport-layer catch.

- `SessionNotActiveError` is raised by `Session._require_active()`, called at the top of every mutation method.
- FastAPI routes catch `SessionNotActiveError` → HTTP 409 with `{"error": {"code": "session_not_active", "message": "..."}}`.
- MCP tools catch `SessionNotActiveError` → return error text describing the session's current status.
- `session.complete()` sets status to COMPLETED and seals the trace (finalizes checksum), making the session permanently immutable.

## Consequences

- Completed sessions cannot have their traces, portfolios, or leaderboard submissions corrupted.
- The pattern is extensible — if new session states are added (e.g., EXPIRED), the guard can be updated in one place.
- Known limitation: the status check is not locked (TOCTOU window under extreme concurrency). Accepted because status transitions are infrequent and unidirectional. See REMAINING_TASKS.md.
