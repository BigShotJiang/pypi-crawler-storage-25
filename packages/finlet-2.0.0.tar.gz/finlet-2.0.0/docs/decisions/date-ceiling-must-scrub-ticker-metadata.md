# Decision: Date ceiling must scrub ticker-availability metadata rows

**Date**: 2026-05-21
**Status**: Accepted (shipped via bug-b25eba4d exec-plan)
**Refs**:
- Codex bug `b25eba4d-a325-41c4-b4fc-8278d439fe62` (filed 2026-05-21; prod sha at filing `c9af6c5`)

**Related**:
- `docs/decisions/blind-benchmark-envelope-fields-must-blind.md` (sibling — envelope-level fields scrubbed separately from `items[]`; this record applies the same shape to metadata rows for sim-time, not opaque blinding)
- `docs/decisions/blind-benchmark-architecture.md` (parent — V1 blind transform precedent for `_PER_ROW_DATE_FIELDS`)
- `finlet/core/enforcer.py:DateCeilingEnforcer` (the load-bearing chokepoint for `items[]` arrays whose semantic this record extends to metadata rows)

---

## Context

Codex bug `b25eba4d` (filed 2026-05-21) showed that
`list_available_tickers(session_id=<id>)` returned future wall-clock dates
on every ticker row, even when called inside an active session whose
sim-time was strictly before those wall-clock dates.

Concretely, a session at `sim_time = 2024-01-02T14:30:00Z` saw rows like:

```json
{
  "ticker": "AAPL",
  "earliest_price_date": "2020-01-01",
  "latest_price_date": "2026-05-17",
  "earliest_fundamentals_date": "2024-09-30",
  "latest_fundamentals_date": "2026-05-12",
  "last_updated_utc": "2026-05-21T19:01:59+00:00"
}
```

Three distinct date fields above sim-time (`latest_price_date`,
`latest_fundamentals_date`, `last_updated_utc`) — the agent under
evaluation can pivot from any of them to the actual calendar year, anchor
its trading clock to the data lake's update timestamp, and so re-identify
the wall-clock window the session is meant to look unanchored to.

### Root cause: enforcer vs metadata category error

The date-ceiling enforcer (`finlet.core.enforcer.DateCeilingEnforcer`) is
the chokepoint for `items[]` arrays. It walks per-item `timestamp` fields
from a hardcoded list (`TIMESTAMP_KEYS = ("timestamp", "date", "datetime",
"filed_at", "filedAt", "filing_date", "published_at", "created_at",
"time")`) and strips any item whose timestamp exceeds the ceiling.

Ticker-availability rows surfaced by `list_available_tickers` are NOT
`items[]`. They are metadata rows whose date-bearing fields live directly
on the row (no `timestamp` key). The enforcer therefore does not cap them,
and a non-blind session sees the raw S3 manifest aggregation timestamps.

The blind-benchmark team correctly identified the field list at
`finlet/api/services/market_service.py:_PER_ROW_DATE_FIELDS` (Codex bug
`50abd05e`, 2026-05-20) and routed those fields through `apply_date` for
blind mode. But the substitution only fires when `session.config.blind=True`.
For a non-blind session at sim-time 2024, those fields go out raw — the
leak Codex caught.

---

## Decision

Two changes, both in `finlet/api/services/market_service.py` and its two
call sites (`finlet/api/routes_market.py` and `finlet/mcp/server.py`).

### 1. New sibling chokepoint: `apply_ticker_metadata_ceiling`

A new pure function in `market_service.py`:

```python
def apply_ticker_metadata_ceiling(
    rows: list[dict[str, Any]],
    ceiling_time: datetime,
) -> list[dict[str, Any]]:
    """Cap every ISO-date metadata field on ticker-availability rows to ceiling_time."""
```

* Iterates `_PER_ROW_DATE_FIELDS` (the existing tuple from the blind-mode
  substitution) so the field list has ONE source of truth.
* Each tracked field's value is parsed (both pure `YYYY-MM-DD` dates and
  full ISO `YYYY-MM-DDTHH:MM:SS+00:00` datetimes are accepted) and capped
  to `ceiling_time` via the new helper `cap_iso_to_ceiling`.
* The shape of the re-emitted value matches the shape of the input —
  pure dates stay 10 characters; full ISO datetimes stay full ISO. The
  pydantic `TickerAvailability` response model's typing is preserved.
* Non-string and unparseable values pass through untouched (defensive: no
  silent mutation of malformed data the rest of the pipeline relies on).

### 2. Call-site wiring

The new helper runs UNCONDITIONALLY when a `session_id` is provided to
`list_available_tickers`, blind or non-blind. Three call sites:

* `finlet/api/routes_market.py:list_available_tickers` (REST handler) —
  after `get_ticker_availability()` cache read, before returning.
* `finlet/mcp/server.py:list_available_tickers` (MCP tool) — same.
* `finlet/api/services/market_service.py:apply_universe_blind_filter`
  (blind transform helper) — re-caps internally so blind mode is a
  strict superset of non-blind ceiling enforcement.

The envelope `cached_at` timestamp is also capped via the public scalar
helper `cap_iso_to_ceiling` so the YYYY-MM-DD regex grep gate doesn't
trip on it. In blind mode, the existing `apply_date` substitution
replaces this value with a `Day_N` token after the cap — the cap is the
defense-in-depth backstop for the non-blind path.

### Why the fix is at the metadata surface and NOT in the enforcer

The enforcer walks `items[]` arrays — it expects per-item `timestamp`
fields. Adding metadata-row support to the enforcer would conflate two
distinct invariants:

1. "Plugin response items past the ceiling are stripped." (current)
2. "Metadata rows about data-availability are capped to sim-time."
   (this record)

The invariants have different semantics and live in different parts of
the architecture:

* The enforcer's invariant is about HOT data flowing through the plugin
  chain. It runs once per plugin response; ceiling violations are an
  abuse signal worth logging.
* The metadata-row invariant is about a STATIC catalog that summarises
  the data lake's coverage. It runs once per `list_available_tickers`
  call; ceiling violations are a leak signal worth scrubbing.

Mirrors the precedent in
`docs/decisions/blind-benchmark-envelope-fields-must-blind.md` — envelope
fields are scrubbed separately from `items[]`. The blind transform layer
draws the same architectural boundary; we extend it here for sim-time
(non-blind) instead of opaque substitution (blind).

### Why the cap is at the metadata surface and NOT cached pre-cap

The cache at `finlet/api/routes_market.py:_AVAILABILITY_CACHE_TTL` is a
1-hour module-level singleton shared between blind and non-blind callers.
Caching the per-session ceiling-applied result would scale
O(sessions × tickers) and defeat the cache's purpose (the discovery
flow's pre-session call would also pollute the cache).

The ceiling runs AFTER cache read, on the per-call response. Per-call
cost is O(rows × fields) — ~250 tickers × 5 fields = 1250 string parses
per call. Negligible compared to the S3 manifest aggregation the cache
exists to avoid.

### Earliest-* fields treatment

Earliest-* fields (`earliest_price_date`, `earliest_fundamentals_date`)
are data-availability FLOORS, not leaks. A field saying "the earliest
filing for AAPL is 2024-09-30" is a fact about backend data coverage,
not a wall-clock-now signal.

BUT the bug-report payload had `earliest_fundamentals_date: "2024-09-30"`
appear AFTER `sim_time: 2024-01-02` — meaning the floor exceeds the
ceiling. That's a legitimate "you can't see any filings yet" signal in a
2024-01-02 sim. We cap earliest-* the same as latest-* for two reasons:

1. The grep gate is uniform — every tracked field <= sim-time. A row
   with `earliest_fundamentals_date: "2024-09-30"` at sim-time
   `2024-01-02` would trip the grep gate even though the field is
   semantically a lower bound.
2. From the agent's perspective, a ceiling-capped earliest-* value still
   communicates "the earliest data is at or before this date" — strictly
   less informative than the raw floor, but not misleading.

The PER_ROW_DATE_FIELDS tuple is the single source of truth for what
gets capped; future fields added there are captured automatically.

---

## Consequences

* Every session-scoped call to `list_available_tickers` now caps every
  date-bearing metadata field to sim-time. Calls without a `session_id`
  (the pre-creation discovery flow) still return the raw coverage
  rollup unchanged — by design, the discovery surface predates the
  session and cannot use a sim-time ceiling.
* The grep gate at `tests/e2e/test_date_ceiling_zero_leak.py` (NEW) is
  the load-bearing regression assertion. Any future change that adds a
  new date field to the coverage rollup MUST add the field name to
  `_PER_ROW_DATE_FIELDS` — the test will fail loudly otherwise.
* The unit test at `tests/core/test_date_ceiling_metadata.py` (NEW)
  covers the scalar `cap_iso_to_ceiling` helper and the
  `apply_ticker_metadata_ceiling` row helper in isolation. Parametric
  property-style coverage over a range of sim-times asserts the
  load-bearing invariant.
* `apply_universe_blind_filter` now invokes the ceiling cap before the
  opaque substitution — blind mode is a strict superset of non-blind
  enforcement. This is defense in depth: if a future regression breaks
  the opaque `apply_date` substitution, the worst-case leak is a date
  `<= sim_time` (not a future wall-clock date that exposes the calendar
  year).
* The pydantic `TickerAvailability` response model's typing is
  preserved — the cap helper returns the same string shape it receives.
  No schema migration is required.

---

## Reversal path

Two-step revert:

1. Remove the `apply_ticker_metadata_ceiling` call from
   `finlet/api/routes_market.py:list_available_tickers`,
   `finlet/mcp/server.py:list_available_tickers`, and
   `finlet/api/services/market_service.py:apply_universe_blind_filter`.
2. Remove the new helpers (`apply_ticker_metadata_ceiling`,
   `cap_iso_to_ceiling`, `_coerce_to_utc_datetime`) from
   `finlet/api/services/market_service.py`.

~30 lines of removal + 2 test files deleted. The blind-mode opaque
substitution at `apply_universe_blind_filter` continues to scrub
date fields in blind mode (independent invariant — unchanged by this
record).

---

## Open questions

None — the field list is `_PER_ROW_DATE_FIELDS` (single source of
truth), the chokepoint is the new helper (single call site per
surface), and the test gate exercises both blind and non-blind paths.

Future work: if a new ticker-metadata surface is added (e.g.
`get_ticker_coverage(session_id)`), it MUST also pipe through
`apply_ticker_metadata_ceiling`. The grep gate at
`tests/e2e/test_date_ceiling_zero_leak.py` SHOULD be extended to cover
the new surface in the same commit (mirrors the
`tests/e2e/test_blind_benchmark_zero_leak.py` extension pattern).

---

## Followups (Codex peer review, 2026-05-21)

### Item #5 — `earliest_*_date` semantic correction

The original implementation (PR #129, 2026-05-21) uniformly clamped ALL
date fields to the ceiling, including `earliest_*_date`. The docstring
acknowledged the clamp could be "strictly stricter than reality" (the
"Earliest-* fields treatment" section above), but the side effect is
that agents read `earliest_fundamentals_date: 2024-01-02` (sim-time) when
the canonical earliest is `2024-09-30`. The agent concludes fundamentals
exist at sim-time when they don't, queries the plugin chain, gets an
empty `items[]` after enforcer stripping, and is left confused ("the
metadata said filings exist but the data returns none").

**Followup:** `earliest_*_date` fields now return `None` when above
ceiling. `latest_*_date` and `last_updated_utc` continue to clamp (they
are max-bounds / metadata, not data-availability claims).

**Implementation:** new sibling helper
`finlet.api.services.market_service.cap_or_drop_iso_to_ceiling(value,
ceiling) -> str | None` mirrors `cap_iso_to_ceiling` but returns `None`
instead of clamping when `value > ceiling`. A new frozenset
`_EARLIEST_FIELDS = frozenset({"earliest_price_date",
"earliest_fundamentals_date"})` routes fields in
`apply_ticker_metadata_ceiling`. Members of `_EARLIEST_FIELDS` go through
the drop-above helper; everything else continues to go through
`cap_iso_to_ceiling`.

**Why two helpers instead of one with a flag.** Two helpers with clear
semantics > one helper with a flag. The semantic contract is different
("clamp to ceiling" vs "drop above ceiling"), and the call sites that
choose between them are not arbitrary — they map to the floor-vs-max
nature of the field. Encoding the choice as a frozenset membership keeps
the dispatcher in `apply_ticker_metadata_ceiling` declarative.

### Item #6 — docstrings

The original docstrings at `finlet/api/routes_market.py:670-679`,
`finlet/mcp/server.py:list_available_tickers`, and the `description=`
parameter of the OpenAPI Query stated: "When omitted (or the session is
not blind), the canonical full-universe response is returned unchanged."
The implementation as of PR #129 already capped date fields for any
session_id (blind or non-blind), and this iteration extends capping to
the unauth path. The docstrings/OpenAPI description are updated to
describe both surfaces accurately:

* `session_id` provided → cap to sim-time; earliest-* may become `None`.
* `session_id` omitted → cap to `datetime.now(timezone.utc)`;
  earliest-* may become `None`.
* Blind mode → opaque-substitute tickers + sector tags (additive).

### Item #7 — unauth discovery caps to wall-clock-now

The original implementation skipped capping when `session_id is None`
(the "discovery is unauth, no sim-time available" design). A read-token
holder could call discovery pre-session-creation and learn future
wall-clock dates like `latest_price_date: 2026-09-30`.

**Followup:** when `session_id is None`, apply the SAME cap with
`ceiling = datetime.now(timezone.utc)`. Eliminates future-wall-clock
leak. Preserves discovery UX — agents still see "latest=today" for
un-sessioned probes. Earlier dates above wall-clock-now also get the
earliest-* → `None` treatment, consistent with the session-scoped path.

**Why not coarse-bucket or omit entirely.** The data-availability
discovery surface is the standard way agents probe what tickers are
worth picking before session creation. Coarse-bucketing (e.g.
quarter-resolution) or omitting date fields would degrade the UX in a
way that doesn't buy any additional security beyond capping to today.
The leak Codex caught was the FUTURE date, not the present-day date.

### Test gate updates

`tests/e2e/test_date_ceiling_zero_leak.py` updates:

* `test_ticker_metadata_ceiling_zero_leak_no_session_passthrough`
  REMOVED — its assertion (`"2026-05-17" in blob`) encoded the old
  passthrough contract that this followup retires.
* `test_ticker_metadata_ceiling_no_session_caps_to_walltime` ADDED —
  stubs the cache with `2099-01-01` dates and asserts the unauth call
  caps `latest_*` to wall-clock-now and drops `earliest_*` to `None`.
* `test_ticker_metadata_earliest_fundamentals_returns_none_above_sim_time`
  ADDED — exercises the item-#5 semantic against the canonical bug
  payload (`earliest_fundamentals_date="2024-09-30"` at sim-time
  `2024-01-02T14:30:00Z`), asserts `earliest_fundamentals_date is None`
  and `earliest_price_date` (below sim-time) is preserved.

`tests/core/test_date_ceiling_metadata.py` updates:

* `TestCapOrDropIsoToCeiling` ADDED — covers the new helper in isolation
  (above/at/below ceiling, None passthrough, malformed string defensive
  passthrough, naive ceiling coercion, `_EARLIEST_FIELDS` frozenset
  membership invariant).
* `test_caps_every_date_field_on_a_single_row` UPDATED — the
  `earliest_fundamentals_date == "2024-01-02"` clamp assertion flipped
  to `earliest_fundamentals_date is None`.
