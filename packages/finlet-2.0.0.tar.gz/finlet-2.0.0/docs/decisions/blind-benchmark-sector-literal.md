# Blind Benchmark — Embedded Sector/Industry Literal (V1)

> Date: 2026-05-19
> Status: Shipped (Team A, Blind Benchmark V1)
> Related: `docs/decisions/blind-benchmark-architecture.md`, `finlet/core/blind_mapping.py` `_TICKER_SECTOR_TABLE`

## Decision

The blind-benchmark V1 sector/industry side-table is an **embedded Python literal** in `finlet/core/blind_mapping.py::_TICKER_SECTOR_TABLE`, hard-coded for the 6 default-universe tickers (AAPL/MSFT/NVDA/AMZN/GOOGL/BTC-USD). Source: `yfinance.Ticker(symbol).info` `sector` / `industry` fields, captured 2026-05-19, matched against the cached fixtures in `finlet/leaderboard/fixtures.py` for the same six tickers.

```python
_TICKER_SECTOR_TABLE: Final[dict[str, dict[str, str]]] = {
    "AAPL":    {"sector": "Technology",            "industry": "Consumer Electronics"},
    "MSFT":    {"sector": "Technology",            "industry": "Software—Infrastructure"},
    "NVDA":    {"sector": "Technology",            "industry": "Semiconductors"},
    "AMZN":    {"sector": "Consumer Cyclical",     "industry": "Internet Retail"},
    "GOOGL":   {"sector": "Communication Services","industry": "Internet Content & Information"},
    "BTC-USD": {"sector": "Cryptocurrency",        "industry": "Digital Asset"},
}
```

## Why

V1 scope is the 6 frozen `_DEFAULT_UNIVERSE` tickers (see `finlet/leaderboard/benchmarks.py`). The full universe of S3-backed tickers (~236 in `scripts/ticker_lists/us_equities.txt`) is NOT in scope because the 5 frozen `BENCHMARK_SCENARIOS` all use the same default universe. A runtime S3 sector/industry enrichment layer would add a network call + cache + cold-start latency on every `list_available_tickers` request without any V1 user-visible benefit. Locking sectors deterministically in the module also makes blind mapping output stable across deployments — there is no "today's S3 read returned slightly different sector strings" failure mode.

## Refresh Policy

- **Annual review** during the same exec-plan window as the next blind-benchmark feature work. Cross-check against `yfinance.Ticker(symbol).info` for each entry; update on drift (sector reclassifications, M&A renames).
- **Scenario-universe expansion** — any new ticker added to a `BenchmarkScenario.universe` MUST land with a matching `_TICKER_SECTOR_TABLE` entry in the same PR. A pre-commit guard or a property test that asserts `set(_DEFAULT_UNIVERSE) ⊆ _TICKER_SECTOR_TABLE.keys()` would lock this down — deferred (V2) because the universe has been stable since launch.
- **V2 migration to S3-backed lookup** — when the scenario universe expands beyond ~10 tickers or sector taxonomy needs runtime correction, replace the literal with a lookup against the canonical S3 sector partition (TBD path, parallel to `prices/daily/...` layout). Until then, the literal is the source of truth.

## Tradeoffs Accepted

- **Manual maintenance.** Drift between the literal and reality is possible. Mitigated by the annual review and the scenario-expansion gate above.
- **Sector taxonomy frozen at yfinance 2026-05-19.** If a ticker is reclassified (e.g., GOOGL moves from "Communication Services" to a new "Internet Platforms" category), the literal lags reality until the next refresh. Low-impact for blind mode — the agent only needs the tag to do structural reasoning, not to match a specific external taxonomy.
- **No runtime enrichment layer.** New tickers added to a scenario universe without a corresponding `_TICKER_SECTOR_TABLE` entry will surface in `apply_universe_blind_filter` with `KeyError` semantics — fail-loud is the V1 default. V2 S3-backed lookup would degrade gracefully to `{"sector": "Unknown", "industry": "Unknown"}` on miss.

## Out of Scope

- Runtime S3 sector enrichment (V2).
- A general "ticker metadata service" abstraction with sector + industry + market cap + listing exchange + ETF status (V2+).
- Cross-vendor sector taxonomy reconciliation (yfinance vs. Finnhub vs. SEC SIC codes).

## Follow-ups (Tracked in REMAINING_TASKS.md)

See "Sector embedded literal refresh policy" entry in REMAINING_TASKS.md V2 follow-up list.
