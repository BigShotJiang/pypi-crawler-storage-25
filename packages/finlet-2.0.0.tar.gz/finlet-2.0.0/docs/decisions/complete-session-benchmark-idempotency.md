# Decision: `complete_session` idempotency + benchmark coherence invariants

Date: 2026-05-19
Status: shipped (CODEX_BUG_CE8DE077 batch — Team A `f2d7486`, Team B `316321a`, Team C `5fcfc2b`)

## Context

GPT Codex (via MCP OAuth on `finlet.dev`) ran benchmark `45cda8d0-fae7-42c8-948d-5bfd7247bed6` and retried `complete_session` after manually deleting an unrelated stale session to "unblock" routing. The retry silently double-advanced the benchmark from scenario 1 (`bull_run`) past scenario 2 (`covid_crash`) directly to scenario 3 (`sideways_chop`). Scenario 2 was permanently skipped from the run and the leaderboard recorded scenario 1's bull-run metrics under scenario 2's slot — a silent data-integrity corruption of a paid-GA-blocking surface.

Bug report on S3:
`s3://finlet-bug-reports/bug-reports/24e0eab53dee/2026-05-19T19-00-06.826562+00-00-ce8de077-bd20-4925-aa24-4cc031cb7567.json`.

### How divergence happens (8 latent defects rolled up into one user-visible failure)

The bug surface was a Codex-class cluster — a single retry exposed eight independent latent defects that compounded:

| # | Severity | File:Line (pre-fix HEAD `949c93b`) | Defect |
|---|----------|-----------------------------------|--------|
| 1 | CRITICAL | `finlet/api/services/session_service.py:395-466` | `complete_session` docstring claims "Idempotent" but only the `session.complete()` call is guarded; benchmark advancement runs unconditionally on a re-call |
| 2 | CRITICAL | `finlet/api/services/session_service.py:450-466` | `bs_advance_scenario` + `create_scenario_session` are non-atomic; no try/except, no rollback. A failure mid-sequence leaves index incremented but `current_session_id` stale |
| 3 | HIGH | `finlet/leaderboard/benchmark_state.py:354-396` | `create_scenario_session` mutates `benchmark_run.current_session_id` in-memory BEFORE `_persist_run_update`. DB write failure → in-memory ≠ DB; restart rehydrates stale state |
| 4 | HIGH | `finlet/leaderboard/benchmark_state.py:265-300` | `advance_scenario` increments `current_scenario_index` and appends `scenario_results` in-memory BEFORE the two DB writes. Same race window as Bug 3 |
| 5 | HIGH | `finlet/mcp/auth.py:235-278` | `_default_session_id` benchmark-aware routing falls through to "Multiple sessions active" when `active_run.current_session_id` is stale (COMPLETED, deleted, or not owned) — agent gets a misleading diagnostic |
| 6 | HIGH | `finlet/api/services/session_service.py:314-330` | `delete_session` does not clear or refuse when the session is a benchmark's `current_session_id`. Orphan reference left dangling |
| 7 | MEDIUM | `finlet/api/services/session_service.py:435-447` | No coherence check that `session.config.start_time/end_time == BENCHMARK_SCENARIOS[run.current_scenario_index].start_time/end_time` before recording a `ScenarioResult`. Diverged state silently corrupts the leaderboard |
| 8 | MEDIUM | `finlet/core/clock.py:421-439` + `finlet/core/session.py:179-195` | `_advance_to` clamps only when advancing; `Session.complete()` freezes the clock without bounds-checking. A session can be persisted with `clock._current_time > config.end_time` |

The end-to-end Codex repro:

1. `complete_session(S1)` for `bull_run`. `session.complete()` froze S1's clock at `2024-03-31`. `bs_advance_scenario` persisted `current_scenario_index = 0 → 1`.
2. `create_scenario_session(run, 1)` raised (or its `_persist_run_update` failed) BEFORE `run.current_session_id` was updated to S2. Run state: `current_scenario_index=1` (covid_crash), `current_session_id=S1.id`, S1 status `COMPLETED`, S1 clock frozen at `2024-03-31`.
3. `_build_resume_hint` surfaced covid_crash scenario metadata + bull_run's frozen clock — exactly what the bug report's `original_progress_before_clear` recorded.
4. Codex called `get_session` without `session_id`. `_default_session_id` filtered S1 (COMPLETED), the benchmark routing's `candidate_sid=S1.id` fell out of `owned`, and the fallback raised "Multiple sessions active." Codex saw the unrelated session `3bbce28ec730`.
5. Codex deleted `3bbce28ec730` to "unblock" the benchmark.
6. Codex retried `complete_session(S1.id)`. `S1.status == COMPLETED` → `session.complete()` skipped (correct), but the benchmark-advancement block fell through and ran a second time. `bs_advance_scenario` advanced `current_scenario_index = 1 → 2` AND appended S1's bull-run metrics under covid_crash's slot. `create_scenario_session(run, 2)` succeeded, creating S3 (`sideways_chop`).
7. Final state: scenario 2 permanently skipped from the benchmark; leaderboard recorded S1's metrics as scenario 2's result.

## Decision

Seven production-code invariants ship together as a single coordinated cross-team batch. Numbering here corresponds to requirements doc §3 invariants 1-6 + 8; the requirements §3 Invariant 7 is a regression test (not a production-code invariant) and was delivered earlier as the prior Team D E2E test commit `7806da6`. Each invariant is enforced at the layer closest to the bug surface (engine for clock; leaderboard for persistence atomicity; API/MCP for idempotency, coherence, and routing). All changes are **additive** to the existing schema — no DB migration; the existing `BenchmarkScenarioResultModel.session_id` column at `finlet/db/leaderboard_models.py:87` is sufficient for idempotency detection.

### Invariant 1 — `complete_session` is truly idempotent

`finlet/api/services/session_service.py::complete_session` (line 419) adds an idempotency check immediately after the COMPLETED-skip block, BEFORE the benchmark-advancement runs. The check calls `get_recorded_result_for_session(benchmark_run, session.id)` (Team B primitive, `finlet/leaderboard/benchmark_state.py` (see lines 238, 295, 370, 505)). If a recorded `ScenarioResult` exists whose `session_id` matches, the function returns a `benchmark_transition` envelope rebuilt from the recorded result and the run's current `current_session_id`, WITHOUT re-running `bs_advance_scenario`.

Effect: calling `complete_session(s)` N times on the same `s` produces exactly one benchmark advancement. The second call reads back the recorded result and surfaces an identical-shape transition envelope so the agent's mental model is preserved.

### Invariant 2 — Atomic benchmark advancement OR rollback

`complete_session` (line 419) wraps the `bs_advance_scenario` + `create_scenario_session` sequence in try/except. On exception from `create_scenario_session`, calls `rollback_last_advance(run.run_id, scenario.id)` (Team B primitive, `finlet/leaderboard/benchmark_state.py` (see lines 238, 295, 370, 505)) which decrements `run.current_scenario_index`, removes the last `ScenarioResult` whose `scenario_id` matches, and DELETEs the matching `BenchmarkScenarioResultModel` row. The function then returns a structured `{"error": {"code": "complete_session_failed_recoverable", ...}}` envelope.

At the leaderboard layer, `advance_scenario` (line 370) and `create_scenario_session` (line 505) snapshot pre-mutation state and roll back in-memory mutations on DB-write failure. `advance_scenario` additionally deletes the persisted `BenchmarkScenarioResultModel` row when the first DB write succeeded but the second failed, via a new `delete_benchmark_scenario_result_by_run_and_scenario(run_id, scenario_id)` helper in `finlet/db/leaderboard_persistence.py` (line 318).

Effect: a transient DB-write failure cannot leave the run half-advanced. Either the full sequence (DB index increment + scenario result row + `current_session_id` update) succeeds, or all three are reverted atomically.

### Invariant 3 — Scenario/session coherence check

`complete_session` (line 419) asserts BEFORE recording a `ScenarioResult`:

- `session.config.start_time == BENCHMARK_SCENARIOS[run.current_scenario_index].start_time`
- `session.config.end_time == BENCHMARK_SCENARIOS[run.current_scenario_index].end_time`

On mismatch, returns `{"error": {"code": "scenario_session_mismatch", "message": "Benchmark <run_id> at scenario_index=<N> expects start=<X> end=<Y>; session has start=<A> end=<B>. The run is in an inconsistent state.", **extra}}`. NO `ScenarioResult` is recorded; NO advancement happens.

Effect: a diverged run (whose `current_scenario_index` and `current_session_id` no longer refer to the same scenario) refuses to record metrics rather than silently corrupting the leaderboard.

### Invariant 4 — `_default_session_id` stale-routing transparency

`finlet/mcp/auth.py::_default_session_id` (line 235) adds an explicit branch BEFORE the zero/multi fallback. If `user_id is not None AND active_run is not None AND active_run.current_session_id is not None AND candidate_sid NOT in owned`, raises `ValueError("benchmark_routing_stale: benchmark <run_id> has current_session_id <sid> which is no longer active (COMPLETED, deleted, or not owned). The run is in an inconsistent state. Resolve by completing or abandoning the benchmark, then retry.")`. The MCP wrapper (`auth.py::_resolve_session`) converts to the structured-error envelope.

Effect: when benchmark state has diverged, Codex sees `benchmark_routing_stale` with the offending run + session IDs and an actionable next step, NOT the misleading "Multiple sessions active" that pointed it at an unrelated session.

### Invariant 5 — `delete_session` refuses on benchmark-current

`finlet/api/services/session_service.py::delete_session` (line 314) imports `get_run_for_session` and checks BEFORE the delete. If a run is returned (i.e. the session being deleted is a benchmark's `current_session_id`), raises a structured `session_is_benchmark_current` error directing the agent to call `complete_session` first (or `delete_benchmark_run`).

Effect: an agent cannot silently corrupt benchmark state by deleting the session a run is pointing at. The error message guides the agent to the correct primitive (complete the scenario or abandon the run).

### Invariant 6 — Clock bounds invariant on `Session` lifecycle

Two changes in `finlet/core/`:

- `SessionConfig` (line 89): new Pydantic `model_validator(mode="after")` asserting `end_time is None OR start_time <= end_time`. Open-ended sessions (no `end_time`) remain legitimate per the existing `SessionConfig` docstring at `finlet/core/session.py:42-60`.
- `Session.complete()` (line 194): BEFORE `self.clock.freeze()`, if `self.config.end_time is not None AND self.clock.get_time() > self.config.end_time`, logs `session_complete_clock_past_end` via `structlog` AND calls a new `SimClock.clamp_to_end()` (line 310) helper that idempotently sets `_current_time = _end_time` when out-of-bounds.

Effect: a session cannot be persisted with `clock._current_time > config.end_time`. The frozen clock state always satisfies `start_time <= clock._current_time <= end_time` (or `end_time is None` for open-ended sessions). The clamp is defense-in-depth — the structured log signals that an upstream invariant (the date ceiling enforcer or the clock-advance clamp) failed to keep the clock in bounds during the session's lifetime.

### Invariant 8 — `_build_resume_hint` coherence guard

`finlet/mcp/tools_benchmark.py::_build_resume_hint` (line 56) adds a coherence check after fetching the live session. If `live_session.config.start_time != scenario.start_time` OR `live_session.config.end_time != scenario.end_time`, returns a structured `{"error": {"code": "benchmark_run_inconsistent_state", "message": "Benchmark <run_id> has current_session_id pointing at a session whose config does NOT match scenario index <N>. Scenario expects start=<X> end=<Y>; session has start=<A> end=<B>. The run is in an inconsistent state and must be recovered.", "run_id": ..., "scenario_index": ..., ...}}` envelope INSTEAD of the previous mixed `{scenario: {...}, clock: {...}}` payload.

Effect: the bug report's `original_progress_before_clear` (covid_crash scenario metadata + bull_run frozen clock) becomes impossible. Diverged runs surface as `benchmark_run_inconsistent_state` everywhere `_build_resume_hint` is called (`start_benchmark` lockout, `get_benchmark_progress`).

## Why these choices

### In-memory snapshot rollback (Invariants 2, 3) over multi-row DB transactions

`finlet/db/leaderboard_persistence.py` writes one table per call. There is no SQLAlchemy session shared across `save_benchmark_scenario_result` + `update_benchmark_run`, so wrapping the two writes in a `BEGIN ... COMMIT` would require lifting the persistence layer into the service. That refactor is larger than the bug it would close.

The chosen pattern — snapshot in-memory state, mutate, try the DB writes, restore on exception — gets the same atomicity guarantee with three lines of bookkeeping per function. The pattern matches the existing atomic-rollback shape from `start_benchmark` (`finlet/mcp/tools_benchmark.py:209-233` pre-fix), which Team B and Team A both mirror lexically for readability.

When the first DB write succeeded but the second failed, Team B's new `delete_benchmark_scenario_result_by_run_and_scenario(run_id, scenario_id)` cleans up the orphan row. This is the smallest possible escape hatch; we don't pretend the writes were transactional, we just provide a precise compensating action.

### Idempotency by query, not by schema (Invariant 1)

The natural shape for idempotency would be `BenchmarkRun.recorded_session_ids: list[str]` on the run dataclass + a matching `recorded_session_ids` JSON column on `BenchmarkRunModel`. We rejected this in favor of a query over the existing `BenchmarkScenarioResultModel.session_id` column (`finlet/db/leaderboard_models.py:87`) because:

- The column already exists and is already populated by `advance_scenario`. We are reading a fact the schema already records, not adding new state.
- A schema change requires a migration (we're pre-launch but still — every migration is a wire-shape change for the on-disk DB) and an out-of-band reconciliation if the two sources of truth ever diverge.
- The query is O(N) where N is the number of scenario_results on the run (max 5 per the frozen scenario list). Sub-millisecond at production scale.

Team B's new `get_recorded_result_for_session(run, session_id) -> ScenarioResult | None` helper exposes the query at the right layer; Team A imports it into `complete_session`.

### `delete_session` REFUSAL over silent state mutation (Invariant 5)

The alternative was to clear `run.current_session_id = None` on delete and let the orphan-cleanup path handle it. We picked refusal because:

- A surprising "delete succeeded and also mutated benchmark state behind your back" is exactly the kind of compound action Codex was tricked by in the original repro.
- Refusal with an actionable error (call `complete_session` first OR `delete_benchmark_run`) preserves the agent's mental model: each tool does one thing.
- The orphan-cleanup path from the prior MCP-benchmark fix (`docs/decisions/mcp-benchmark-fundamentals-coverage.md` D2) handles legitimate orphans — `current_session_id is None` AND `created_at < now-60s` — without depending on delete-time mutation. We don't need to add a second orphan-creation path.

A `force=True` override is intentionally deferred — there is no current use case (the legitimate "abandon the current scenario" flow is `delete_benchmark_run`), and adding force-flags pre-emptively is how silent-corruption surfaces grow. If a future operational need surfaces, file a follow-up.

### Clock clamp + warn (Invariant 6) over hard raise

A hard `raise ValueError("clock past end_time")` in `Session.complete()` would crash the lifecycle and leak the session in `RUNNING` state on the next call (because the `_lifecycle_lock` is released without state transition). The chosen clamp + structured warning has the same observable signal (the log fires on every out-of-bounds clock) without crashing the lifecycle.

The `SessionConfig` `model_validator` IS a hard raise — but at construction time, before any state has been committed. A bad config is unambiguously a programming error; an out-of-bounds clock at `complete()` time is a *symptom* (the date ceiling enforcer or the clock-advance clamp failed to keep the clock in bounds during the session's run). Defense-in-depth posture matches `docs/decisions/2026-05-19-session-end-time-defense-in-depth.md`.

### `_build_resume_hint` returns an error envelope (Invariant 7) over hybrid metadata

The previous mixed payload (scenario metadata for scenario N + clock from a session that belonged to scenario M) was the most expensive part of the bug — it made the inconsistent state *invisible* to Codex's mental model. Returning a structured error makes the inconsistency loud everywhere `_build_resume_hint` is called: `start_benchmark` lockout, `get_benchmark_progress`. The shape matches the existing `structured_error` envelope convention from `docs/decisions/2026-05-19-mcp-structured-error-envelope.md`.

## Rejected alternatives

**For Invariant 1** — implement idempotency via a Redis/in-memory dedup cache keyed on `(run_id, session_id)`. Rejected: introduces external state and a TTL question. The existing `BenchmarkScenarioResultModel` row IS the dedup key; we just had to query it.

**For Invariant 2** — switch `_persist_run_update` + `save_benchmark_scenario_result` to a shared SQLAlchemy session and wrap in `BEGIN ... COMMIT`. Rejected for this batch: refactor scope larger than the bug. Filed as an optional follow-up if the rollback-on-exception path proves insufficient under load.

**For Invariant 5** — silently clear `run.current_session_id = None` and proceed with delete. Rejected per the rationale above. The orphan-cleanup path is sufficient for legitimate orphans; we don't need delete-time mutation.

**For Invariant 6** — `raise ValueError("clock past end_time")` in `Session.complete()`. Rejected because crashing the lifecycle leaks RUNNING state. Clamp + warn is observable without being destructive.

**For Invariant 7** — keep the mixed payload but add a `coherent: bool` field. Rejected because adding a bool that callers must remember to check is a recipe for silent regressions. The error-envelope shape forces every call site to handle it.

**For all invariants** — implement a single new MCP tool `recover_benchmark_run` that detects and repairs every inconsistency. Captured as a NICE-TO-HAVE in REMAINING_TASKS for a future MCP-tools sprint. The current batch closes the bug surfaces; recovery surfacing is additive.

**For Invariant 2** — reorder `complete_session` to `create_scenario_session` first, THEN `bs_advance_scenario`. Rejected because it introduces a different coherence window: a successful create followed by a failed advance leaves the new session orphaned. The current order (advance first, then create-next, with rollback on create failure) is the smaller blast radius.

## Consequences

- **Schema unchanged.** No DB migration. The `BenchmarkScenarioResultModel.session_id` column does idempotency detection; existing rows continue to be valid.
- **MCP error envelopes gain five new structured-error codes:** `benchmark_routing_stale` (Invariant 4), `scenario_session_mismatch` (Invariant 3), `complete_session_failed_recoverable` (Invariant 2), `session_is_benchmark_current` (Invariant 5), `benchmark_run_inconsistent_state` (Invariant 7). All route through `finlet/mcp/_errors.py::structured_error` per `docs/decisions/2026-05-19-mcp-structured-error-envelope.md`. Top-level `"error"` key preserved for legacy callers.
- **Existing `complete_session` envelope shape unchanged on the success and benchmark-transition paths.** The idempotent-retry path returns the same `benchmark_transition` shape it would have returned on the first call, rebuilt from the recorded `ScenarioResult` — agents observe a no-op effect.
- **`Session.complete()` may now emit a `session_complete_clock_past_end` structured warning** when the clock was held past `config.end_time`. The warning is informational — the clamp keeps the persisted clock in bounds. Prod telemetry can alert on this log to surface upstream regressions in the date ceiling enforcer or the clock-advance clamp.
- **`delete_session` may now refuse with `session_is_benchmark_current` when the session is benchmark-current.** Agents that previously deleted benchmark sessions as part of cleanup must call `complete_session` first (or `delete_benchmark_run` to abandon the entire run). The error message instructs both alternatives.
- **`_default_session_id` returns specific stale-routing diagnostics** instead of the misleading "Multiple sessions active" when benchmark state is diverged. Agents that previously hit the multi-session ambiguity error against benchmark-related state now see `benchmark_routing_stale` and know exactly which run is in a bad state.
- **One extra query per `complete_session` call** (the idempotency `get_recorded_result_for_session` scan over the run's `scenario_results` list — bounded by the 5 frozen scenarios). Negligible cost.
- **One extra query per `delete_session` call** (the `get_run_for_session` lookup over `_active_runs`). Negligible cost.
- **Codex retest pass criteria** (mirrors §5 of the requirements doc):
  1. Calling `complete_session(s)` twice produces exactly ONE benchmark transition. Second call returns the same envelope as the first.
  2. Forced `create_scenario_session` failure (simulated) returns `complete_session_failed_recoverable`, not silent double-advance.
  3. Stale `current_session_id` produces `benchmark_routing_stale` on auto-resolve, NOT "Multiple sessions active."
  4. Deleting a benchmark-current session returns `session_is_benchmark_current` and the session is preserved.
  5. Diverged `(scenario_index, session.config)` returns `scenario_session_mismatch`, no scenario_result recorded.
  6. `Session.complete()` on an out-of-bounds clock clamps + warns; persisted clock state satisfies the bound.
  7. `_build_resume_hint` on diverged state returns `benchmark_run_inconsistent_state`, never mixes scenario + live-clock metadata.
  8. Full pytest suite green; no regressions.

## Related work

- Bug report: `s3://finlet-bug-reports/bug-reports/24e0eab53dee/2026-05-19T19-00-06.826562+00-00-ce8de077-bd20-4925-aa24-4cc031cb7567.json`
- Prior MCP benchmark harness fix: `docs/decisions/mcp-benchmark-fundamentals-coverage.md` (D1 deleted-fundamentals-branch, D2 atomic-rollback-on-`start_benchmark`, D3 benchmark-aware `_default_session_id` — orthogonal but related; today's batch extends D2/D3 to the `complete_session` and `delete_session` surfaces)
- Sibling defense-in-depth: `docs/decisions/2026-05-19-session-end-time-defense-in-depth.md` (`end_time` round-trip preservation), `docs/decisions/2026-05-19-clock-step-to-idempotency-and-end-time-guards.md` (clock `step_to` idempotency + advance-time end-bound guard)
- MCP error-envelope contract: `docs/decisions/2026-05-19-mcp-structured-error-envelope.md`
