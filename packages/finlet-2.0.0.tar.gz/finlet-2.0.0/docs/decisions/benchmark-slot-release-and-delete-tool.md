# Decision: Release Session Slot on COMPLETED + Expose delete_benchmark_run MCP Tool

**Date:** 2026-05-20
**Status:** Accepted
**Source:** Codex bug a3f6f22b (benchmark deadlock + missing escape hatch)

## Context

A free-tier (1/1 concurrent) user calling `complete_session` inside a benchmark run got wedged. Three coordinated bugs:

1. **`session_service.complete_session(session)`** marked the session COMPLETED and persisted, but did NOT decrement `user.active_sessions`. The downstream benchmark advancement tried `create_scenario_session` to build scenario 2 — the slot was still held, so `check_session_creation` (`finlet/api/rate_limit/session.py:28`) raised HTTPException(429). The atomic-rollback path then reverted the index, but the session was already COMPLETED and the slot stayed pinned.
2. **`session_service.delete_session(session, user)`** raised `session_is_benchmark_current` and instructed the user to call `delete_benchmark_run` — but that tool was not exposed over MCP (`finlet/mcp/server.py:73` only re-exported `start_benchmark`, `get_benchmark_progress`, `export_benchmark_results`).
3. The user therefore had no escape: `complete_session` failed on rollback, `delete_session` refused, `start_benchmark` saw `benchmark_already_active`, `delete_benchmark_run` did not exist as an agent-callable surface. Permanent lockout for free-tier users mid-benchmark.

## Decision

### 1. Add `_release_session_slot(session, user)` helper

Single source of truth for "release this session's concurrent-session slot." Lives in `finlet/api/services/session_service.py`. Two design choices:

- **Idempotent via a session-attached `_slot_released` flag.** `record_session_deleted` already clamps at `max(0, x-1)`, which protects against negative counters but NOT against silent desync. The flag prevents the COMPLETE→DELETE double-decrement that would otherwise let a follow-up `create_session` succeed past the cap.
- **Lazy attribute on `Session`, not a class field.** No DB schema change. Sessions loaded from disk start without the flag (`getattr(session, '_slot_released', False)` returns `False`); they would only get a duplicate decrement if the COMPLETED session is later explicitly deleted, which lands at the floor `max(0, 0-1) = 0` — acceptable post-restart drift.

### 2. Call `_release_session_slot` from BOTH `complete_session` and `delete_session`

`complete_session(session, user)` releases the slot BEFORE the benchmark advancement path runs, so `create_scenario_session` passes the rate gate even on 1/1-tier accounts. `delete_session` continues to release on delete, but the flag short-circuits if the COMPLETE path already released.

`user` is **optional** on `complete_session` to preserve backward compatibility with internal callers (legacy tests, the benchmark code path that doesn't have a UserRecord in hand). When `user=None`, the slot is not released — but those code paths also don't hit the rate gate, so the bug doesn't reproduce there.

### 3. Update the lying error message

`delete_session`'s `session_is_benchmark_current` error now reads:

> Either call complete_session (it will release the slot atomically before advancing) OR delete_benchmark_run to abandon the benchmark.

— truthful for the first time.

### 4. Expose `delete_benchmark_run` as `@mcp.tool()`

New tool in `finlet/mcp/tools_benchmark.py`. Authenticates via OAuth Bearer (Phase 4e contract) with `finlet:benchmark` scope (matches the rest of the benchmark tool suite). Returns:

- `benchmark_run_not_found` (structured error) for unknown OR cross-user run_ids (no existence leak — mirrors `export_benchmark_results`).
- `{"status": "deleted", "run_id": ..., "deleted_session_id": ...}` on success.

The tool cleans up the run's `current_session_id` session (if any) via the same primitives used by `start_benchmark`'s atomic-rollback path, then calls the internal `benchmark_state.delete_benchmark_run` (renamed to `_bs_delete_benchmark_run` at the import site to avoid the new MCP tool shadowing the internal name).

Re-exported from `finlet/mcp/server.py` so agents find it through the canonical server namespace.

## Consequences

- **Free-tier users can now complete benchmarks.** The 1/1 concurrent gate no longer wedges them mid-run.
- **Agents have a real escape hatch.** `delete_benchmark_run` over MCP is the documented "abandon the benchmark" path; the error message now matches reality.
- **Counter accuracy under COMPLETE→DELETE is preserved.** The flag prevents the silent desync that the `max(0, x-1)` floor was masking.
- **Persistence drift on process restart is bounded.** Restart loses the in-memory flag; worst case is one duplicated decrement that hits the floor at 0. The alternative (persisting the flag) would require a schema migration for an in-memory liveness signal — not worth it.
- **MCP tool surface adds one entry.** `delete_benchmark_run` joins the four existing benchmark tools (`start_benchmark`, `get_benchmark_progress`, `export_benchmark_results`). Tool count tracked in `docs/REMAINING_TASKS.md`.

## Alternatives Considered

- **Recount `user.active_sessions` from session statuses on every gate check.** Rejected: heavier hot path, doesn't help the in-memory flag invariant during a single advancement.
- **Make `complete_session` always release the slot regardless of `user`.** Rejected: most internal callers don't have a UserRecord, and forcing them to plumb one through is out of scope for a bug fix.
- **Persist the `_slot_released` flag to the DB.** Rejected: in-memory liveness signal, no migration justified.

## References

- Code: `finlet/api/services/session_service.py` (helper + complete_session signature + delete_session error message + delete_session call site)
- Code: `finlet/mcp/tools_benchmark.py` (new `delete_benchmark_run` tool + import rename)
- Code: `finlet/mcp/server.py` (re-export update + pass user to `_svc_complete_session`)
- Code: `finlet/api/routes_session.py` (REST route passes user)
- Tests: `tests/api/services/test_session_service_benchmark_slot_release.py` (regression)
- Tests: `tests/api/services/test_complete_then_delete_no_double_decrement.py` (flag invariant)
- Tests: `tests/mcp/test_delete_benchmark_run_tool.py` (tool registration + auth + happy path)
