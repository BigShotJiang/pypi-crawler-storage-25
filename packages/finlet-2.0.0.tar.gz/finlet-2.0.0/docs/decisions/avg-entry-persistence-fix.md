# Decision: Persist Positions Inside the `submit_order` Atomic Transaction

**Date**: 2026-04-14
**Status**: Accepted

---

## Context

The `/portfolio` REST endpoint and the `get_portfolio` MCP tool were returning `avg_entry_price = 0.0` for every position, even though order fills clearly recorded the fill price (visible in the `/orders` response and on trace entries). User-reported as critical — P&L attribution was impossible from the API side.

Investigation showed the MARKET auto-fill path in `finlet/api/services/trade_service.py::submit_order` persisted the order and the session, but did **not** persist positions. In-memory portfolio state was correct for the lifetime of the process, but on session reload (any process restart, or any handler that rebuilt the portfolio from the database) the positions table was empty — so the portfolio was reconstructed with no cost-basis information and every `avg_entry_price` defaulted to `0.0`. The bug was invisible at runtime in a single-process session because in-memory state was correct; it only surfaced across a reload boundary.

Three pre-execution hypotheses were eliminated during investigation:

1. **DB hydration bug** — ruled out. Hydration was reading an empty positions table correctly; the rows simply never existed.
2. **Pydantic `Field(..., exclude=True)` serialization** — ruled out by direct repro. `model_dump(mode="json")` emitted `avg_entry_price` correctly when the in-memory position had it.
3. **`@computed_field` collision** — ruled out. No field aliased or shadowed `avg_entry_price`.

The actual defect was a missing persistence call on a hot path.

---

## Decision

Add `save_position` / `delete_position` calls inside the existing atomic persist transaction in `finlet/api/services/trade_service.py::submit_order`, immediately after the order and session are persisted.

- When the in-memory position exists with non-zero quantity (BUY, partial SELL), call `save_position` to upsert the row.
- When a SELL zeroes the position out, call `delete_position` so the DB does not retain a stale row.

Both calls land inside the same `async with get_session_db(...) as db:` block that already persists the order and the session, so fill + order + session persistence are all part of the same transaction. The shared `Portfolio.to_dict()` path means one fix covers both the REST response and the MCP tool response.

---

## Consequences

- Positions now survive session reload. `avg_entry_price`, `realized_pnl`, `quantity`, and all computed fields (`market_value`, `cost_basis`, `unrealized_pnl`, `unrealized_pnl_pct`) reflect correct state in both the REST `/portfolio` response and the MCP `get_portfolio` tool response.
- The fill→persist atomic invariant is preserved: if any leg of the transaction fails, the order, the session, and the position state all roll back together. There is no window where an order reads as FILLED but the position is absent.
- New integration tests at `tests/api/test_portfolio.py::TestPositionResponseFields` (9 tests) and `tests/mcp/test_tools_portfolio.py` (3 tests) assert against the reloaded portfolio state rather than the in-process fixture, so they prevent the class of regression where a persistence call is missing on a hot path.

---

## Alternatives Considered

- **DB hydration fix (Hypothesis #1)** — would not have worked. The persistence rows never existed; hydration was reading an empty table correctly.
- **Pydantic `Field(..., exclude=True)` inspection (Hypothesis #2)** — ruled out via direct repro; `model_dump(mode="json")` was emitting `avg_entry_price` correctly when the in-memory position had it.
- **`@computed_field` collision (Hypothesis #3)** — ruled out; no field aliased or shadowed `avg_entry_price`.
- **Post-fill hook for position persistence** — persisting positions in a separate transaction triggered after `submit_order` returned would have introduced a second transaction boundary and broken the atomic session-mutation invariant. Inline inside the existing `async with get_session_db(...) as db:` block preserves atomicity.

---

## References

- Fix commit: `d6f7be6`
- Coverage commit: `9adb68a`
- Issue source: `docs/REMAINING_TASKS.md` §Critical #1 (user-reported)
