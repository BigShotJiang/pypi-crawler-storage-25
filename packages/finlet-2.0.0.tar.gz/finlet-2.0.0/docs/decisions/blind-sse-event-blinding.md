# Decision: Blind SSE Event Blinding — Per-Call-Site Wiring + Chokepoint Backstop

**Date**: 2026-05-21
**Status**: Accepted (shipped via blind-sse-defense-in-depth exec-plan)
**Refs**:
- Codex bug `a93a7ff2-39c2-48cb-8ddf-6a794686f342` (filed 2026-05-21 03:45 UTC; prod sha at filing `2e443d5`)

**Related**:
- `docs/decisions/blind-benchmark-architecture.md` (parent — V1 architecture)
- `docs/decisions/blind-benchmark-envelope-fields-must-blind.md` (sibling — body+envelope rule extended to owner-view + error + complete_session)
- `docs/decisions/benchmark-run-decrypt-publish-gate.md` (sibling — owner-driven lifecycle)
- `docs/decisions/blinded-trace-persistence.md` (sibling — write-time trace blinding + read-time `_blind_mapping_for` helper)
- `docs/decisions/blind-mapping-serializer-poison.md` (sibling — the existing `__getstate__` chokepoint pattern this builds on)
- `docs/decisions/blind-mapping-scenario-and-universe.md` (sibling — new `apply_universe` / `apply_scenario` / `apply_session_name` forward transforms shipped alongside)

---

## Context

Bug `a93a7ff2` (Codex, 2026-05-21 03:45 UTC) reproduced on prod sha `2e443d5`. The blind benchmark SSE stream `GET /v1/sessions/{id}/stream` leaked real tickers, real dates, and the scenario label `bull_run` across the `session`, `clock`, `portfolio`, `history`, and `orders` event types. Only the `trace` event was correctly blinded (closed by PR #117 / Codex bug `50abd05e` two days prior on 2026-05-19).

This is the **third surface-by-surface blind-leak repair in this area**:

1. PR #117 (2026-05-20, Codex bug `50abd05e`) — closed 8 owner-view tool surfaces + extended the zero-leak gate to 14 surfaces.
2. PR #118 (2026-05-20, Codex bugs `d1baf1b8` + `ad919e11` + `53c9eccb`) — `@blind_error_mapper` on 17 MCP tools + `complete_session` payload blinding + `list_available_tickers` correctness.
3. This PR (2026-05-21, Codex bug `a93a7ff2`) — SSE stream wiring + chokepoint backstop.

Each prior fix was a "patch the specific surface" repair that left structural debt: every new emit site is a new opportunity to forget `blind_mapping=`. The bug filer's repro grepped the SSE payload for `AAPL|MSFT|NVDA|AMZN|GOOGL|BTC-USD|SPY|2023|2024|bull_run` and found matches in 5 of 6 event types. The shared serializer (`trace_data`) already supported `blind_mapping=` (Team E `cc44af5` shipped this for REST owner-auth in the 2026-05-20 iteration); the SSE call site in `routes_sse.py:_generate_events` had it threaded for `trace` only.

A secondary structural leak surfaced during recon: `session.name = f"benchmark-{run_id}-{scenario.id}"` at `finlet/leaderboard/benchmark_state.py:640` embeds the scenario label (`bull_run`, `covid_crash`, etc.) into a persisted free-form name field. The existing `apply_ticker` / `apply_date` forward transforms did not cover scenario labels or universe lists. (See sibling decision `docs/decisions/blind-mapping-scenario-and-universe.md` for the new `apply_universe` / `apply_scenario` / `apply_session_name` forward transforms.)

A tertiary contract mismatch surfaced in the same recon: `export_benchmark_results` on a mid-run benchmark returned `benchmark_run_not_completed` (terminal-state guard fired first) instead of the bug filer's expected `assert_run_immutable` wording. Recon called this expected behavior — see "Consequences → Export error precedence documented" below.

---

## Decision

Two layers of defense, one primary + one backstop:

### Primary (per-call-site)

Every SSE serializer that emits ticker / date / session-name data accepts a `blind_mapping: BlindMapping | None = None` kwarg + applies it. The owner-view call sites in `finlet/api/routes_sse.py:_generate_events` pass `_blind_mapping_for(session)` from the shared helper in `finlet/api/serializers.py` (hoisted out of `routes_public_session.py` in the 2026-05-20 iteration; see `docs/decisions/blinded-trace-persistence.md`).

Extended this PR — three new serializer signatures:

| Serializer | Module | Previously | Now |
|---|---|---|---|
| `session_response(session, ...)` | `finlet/api/services/session_service.py` | No `blind_mapping` support | Accepts `blind_mapping`; substitutes `d["name"]` via `apply_session_name`, `d["config"]["universe"]` via `apply_universe`, `d["config"]["benchmark_ticker"]` via `apply_ticker`, `d["config"]["start_time"]` / `d["config"]["end_time"]` via `apply_date`. **Update (bug 2cd01283, 2026-05-21):** the `benchmark_ticker` substitution was a no-op for the default `SPY` prior to this fix because `SPY` lived outside the per-session universe map; `generate_mapping` now seeds `benchmark_ticker` into `ticker_map` so the call substantively maps `SPY → T_NNNN`. See `docs/decisions/blind-benchmark-ticker-must-blind.md`. |
| `clock_dict(session, ...)` | `finlet/api/services/clock_service.py` | No `blind_mapping` support | Accepts `blind_mapping`; substitutes `current_time` / `start_time` / `end_time` ISO dates via `apply_date` |
| `list_orders(session, ..., *, blind_mapping=)` | `finlet/api/services/trade_service.py` | No `blind_mapping` support | Accepts `blind_mapping`; substitutes order-row ticker fields via `apply_ticker` |

All 6 SSE emit sites in `routes_sse.py:_generate_events` now pass `blind_mapping=_blind_mapping_for(session)`:

- `session` event ← `session_response(session, blind_mapping=...)`
- `clock` event ← `clock_dict(session, blind_mapping=...)`
- `portfolio` event ← `_portfolio_data(session, blind_mapping=...)` (already supported, was not being passed — regression of PR #117 scope)
- `history` event ← `_history_data(session, blind_mapping=...)` (same)
- `orders` event ← `list_orders(session, blind_mapping=...)` (new support)
- `trace` event ← `trace_data(session, blind_mapping=...)` (already correct since `cc44af5`)

### Backstop (chokepoint)

Module-level helper in `finlet/core/blind_mapping.py`:

```python
def assert_no_real_blinded_data(payload: Any, mapping: BlindMapping) -> None:
    """Recursive walker. Raises TypeError if any string value matches a key in
    mapping.ticker_map OR matches an ISO-date within ±366 days of mapping.date_origin.
    Env-gated: FINLET_BLIND_ASSERT=raise (CI / e2e default) | log (prod default).
    """
```

Behavior:

- Recurses through dict / list / scalar.
- For each string scalar, checks (a) membership in `mapping.ticker_map.keys()` (real-ticker leak) and (b) whether the string is an ISO date that would have a non-None forward mapping in `apply_date` (a date within ±366 days of `mapping.date_origin`).
- Under `os.environ.get("FINLET_BLIND_ASSERT", "log")`:
  - `"raise"` — raises `TypeError` with a JSON-pointer-like path to the offending value (used in CI + e2e tests).
  - `"log"` (default) — emits `logger.error("real_blind_data_leaked", path=..., value=...)` and continues (used in prod to avoid 500-ing a paying customer on a defense-in-depth backstop).

Applied at `routes_sse.py:_generate_events` after building each event dict, **before** `_sse_event` formatting. Gated on `blind_mapping is not None` so non-blind sessions skip the walk entirely (zero overhead).

This mirrors the existing `assert_not_in_response_dict` backstop pattern (see `docs/decisions/blind-mapping-serializer-poison.md`) but checks for real-data leakage in payload string values rather than `BlindMapping` object embedding. Both helpers live in `finlet/core/blind_mapping.py` for single-source-of-truth.

---

## Consequences

### Positive

- **Chokepoint catches the next regression.** A future SSE event added without `blind_mapping=` wiring fails the chokepoint under `FINLET_BLIND_ASSERT=raise` (which is set in the e2e test environment). The CI gate at `tests/e2e/test_blind_benchmark_zero_leak.py` (extended this PR to exercise SSE events — see Team D `6ff70cf`) fails loud on every PR. The structural debt that drove three iterations of "fix each surface individually" is now bounded by a recursive walker that runs at the emit boundary.
- **Scenario label leaks now caught.** `bull_run` / `covid_crash` / `sideways_chop` / `vix_blowup` / `recovery_rally` are now substituted via `apply_scenario` at the read-time call site in `session_response`. The walker also flags any free-form string that contains these labels even if a future field is added without explicit transform.
- **E2E gate exercises SSE.** Prior gate exercised MCP tools + REST `/sessions/{id}/trace` only. Team D's `6ff70cf` extends the zero-leak gate to read N events of each SSE type and grep the concatenated payload for the bug filer's exact ticker / date / scenario regex set. This means the same Codex repro that surfaced `a93a7ff2` will now fail CI before it can ship.
- **Single source of truth for the helper.** `assert_no_real_blinded_data` lives alongside `assert_not_in_response_dict` and `apply_blind_to_trace_payload` in `finlet/core/blind_mapping.py`. Adding a new dict-walking helper, or moving any of them, would create the kind of duplication that the Codex failure-mode review (Rule Zero Clause 2) targets.
- **Export error precedence documented** (Team C `e128990`). `build_export_dict` terminal-state check fires before immutability check by design — a still-running run cannot be immutable yet. The test contract now accepts EITHER `benchmark_run_not_completed` OR `assert_run_immutable` as valid mid-run error responses. The bug filer's gate was over-specific; runtime behavior is correct.

### Negative

- **O(n) walk per push iteration in production (in log mode).** Every SSE event dict on a blind session is recursively walked. Cost: a typical event has ~10-50 string scalars; the walk is O(scalar count) with cheap dict membership checks. Negligible at the per-second SSE push cadence. In prod (`log` mode), a leak emits a structured log and continues; in CI (`raise` mode), it halts the test.
- **The chokepoint is opt-in at the call site.** Service-layer code MUST call `assert_no_real_blinded_data(payload, mapping)` for the backstop to fire. We chose to wire it at the SSE emit boundary specifically rather than at every serializer return because the SSE boundary is the highest-leverage chokepoint for the bug class — the per-call-site wiring is the primary defense, the SSE walker is the backstop. The same pattern is available for other emit boundaries (MCP, REST) if a future leak surfaces there; for now we kept the change focused on the SSE surface where the bug actually fired.
- **Prod log-only mode means a future leak ships silently the first time** (until the log is noticed). This is the chosen trade-off: a `raise` in prod would 500 a paying customer's SSE stream on a defense-in-depth backstop, which is worse than the leak we are guarding against. The expectation is: CI catches the regression at PR time (`raise` mode); the prod `log` mode is a final safety net for paths CI didn't enumerate. Operators should grep prod logs for `real_blind_data_leaked` as part of the standard SRE rotation.

### Trade-offs explicitly chosen

- **Per-call-site primary + backstop over backstop-only.** A backstop-only approach (every emit walks the payload, no per-call-site wiring) would be simpler but would shift all blinding work to the walker, which is O(n) per event vs. O(1) for a typed transform at the serializer. Per-call-site wiring is the cheap path; the backstop is the defense-in-depth catch for regressions.
- **Env-gated `raise` vs. `log` over always-raise.** Always-raise in prod is too aggressive — a future false-positive (e.g., a ticker symbol that happens to equal a substring of a legitimate non-ticker string field) would 500 customer SSE streams. The env gate lets us be aggressive in CI while staying conservative in prod.
- **Chokepoint at SSE emit boundary over per-serializer return.** Wiring at the emit boundary catches the union of all serializers; wiring at every serializer return would duplicate the walk across N serializers. The emit boundary is the single bottleneck.

---

## How to add a new SSE event

Any new event in `finlet/api/routes_sse.py:_generate_events` MUST:

1. **Pass `blind_mapping=_blind_mapping_for(session)`** to its serializer (use the helper exported from `finlet/api/serializers.py` — do not re-implement the "is this session blind and fully wired" predicate).
2. **Have the serializer accept the kwarg** (`blind_mapping: BlindMapping | None = None`) and apply blinding when non-None — use `apply_ticker` / `apply_date` / `apply_universe` / `apply_scenario` / `apply_session_name` from `finlet/core/blind_mapping.py`. Never embed the `BlindMapping` object itself in the response dict (see `docs/decisions/blind-mapping-serializer-poison.md`).
3. **Be included in the `assert_no_real_blinded_data` chokepoint loop** — the existing loop in `_generate_events` iterates over a fixed set of event dicts; add the new event dict to that set so the walker sees it before `_sse_event` formatting.
4. **Be exercised by `tests/e2e/test_blind_benchmark_zero_leak.py`** — the SSE subtest reads N events of each type; add the new type to the read loop and the concatenated grep blob.

Env-gated via `FINLET_BLIND_ASSERT` (`raise` in CI / e2e tests, `log` in prod). The default is `log` to keep prod conservative — set `raise` in CI by default in the test harness.

---

## Reversal path

Mechanical. To revert to per-call-site-only (drop the chokepoint backstop):

1. Remove `assert_no_real_blinded_data` and its call in `routes_sse.py:_generate_events`.
2. Keep the per-call-site wiring (`session_response`, `clock_dict`, `list_orders` accept `blind_mapping=`) — these are the primary defense and are independent of the backstop.

Estimated cost: 15 minutes. The reversal is sound technically but reintroduces the structural gap — a future SSE event added without `blind_mapping=` wiring would silently leak again, with no test gate to catch it beyond per-call-site coverage in the e2e suite.

The full reversal (drop everything in this PR) is **discouraged** because the bug filer's repro is publicly known and the next blind benchmark agent run would re-hit it.

---

## References

- Bug filing: Codex `a93a7ff2-39c2-48cb-8ddf-6a794686f342` (2026-05-21 03:45 UTC; prod sha `2e443d5`)
- BlindMapping extensions: `finlet/core/blind_mapping.py` (`apply_universe`, `apply_scenario`, `apply_session_name`, `assert_no_real_blinded_data`) — Team A `bac9b4f`
- SSE wiring + chokepoint: `finlet/api/routes_sse.py:_generate_events` — Team B `40f396d`
- Serializer extensions: `session_response`, `clock_dict`, `list_orders` — Team B `40f396d`
- Export error precedence: `finlet/leaderboard/reporting.py:build_export_dict` (terminal-state check fires before immutability check by design) — Team C `e128990`
- Zero-leak gate extension: `tests/e2e/test_blind_benchmark_zero_leak.py` — Team D `6ff70cf`
- Pre-flight: `chore(pre-flight) — KNOWN_FAILURES refresh` — `ab02c69`
- Prior chokepoint pattern: `assert_not_in_response_dict` + `BlindMapping.__getstate__` — see `docs/decisions/blind-mapping-serializer-poison.md`
- Single source of truth helper: `_blind_mapping_for(session)` in `finlet/api/serializers.py` — see `docs/decisions/blinded-trace-persistence.md`
- Scenario / universe / session-name transforms: see sibling `docs/decisions/blind-mapping-scenario-and-universe.md`
