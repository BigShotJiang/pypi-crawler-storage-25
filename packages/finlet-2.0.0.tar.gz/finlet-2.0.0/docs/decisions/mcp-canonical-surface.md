# Decision: MCP Canonical Product Surface; REST Demoted to Human/Operations Layer

**Date:** 2026-05-08
**Status:** Accepted
**Source:** MCP-First Migration Phase 3

## Context

By 2026-Q2 the agent ecosystem has converged on MCP. OpenAI Responses API, Gemini API, ChatGPT Apps SDK, Cursor, Windsurf, VS Code, GitHub Copilot, Replit, JetBrains, LangChain, and the Vercel AI SDK all speak MCP natively. The historical justification for shipping a parallel REST agent surface — "non-Anthropic agents need HTTP" — no longer holds. Continuing to maintain REST as a first-class agent surface costs us schema-drift, deprecated-route bit-rot (audit finding **H1**), and a wider attack surface for future gate regressions like the one Phase 2 closed.

Phase 2 of the MCP-First Migration (final commit `82959df`) sank all four cross-cutting gates — per-tier session creation, per-user trade rate, per-user market-data rate, per-user Finnhub plugin rate — into `finlet/api/services/*.py`. After Phase 2, both surfaces inherit identical gating by construction. That made REST safe to demote: any agent-CRUD route now goes through the same service-layer gate as its MCP twin, so deprecating the REST alias does not change the gating contract.

The 2026-05-06 MCP audit's finding **H1** (deprecated routes) had a policy half (declare a sunset cycle on the unversioned root-mount aliases) and a CLI half (rewire `finlet/cli.py` to call `/v1/...` or MCP-over-stdio). Phase 3 closes the policy half. The CLI half remains in Phase 5 (`finlet/cli.py` rewires to MCP-over-stdio) — clients on the deprecated routes still see them serve responses, but with a `Sunset` header that warns of the upcoming removal.

## Decision

**MCP is the canonical agent surface for Finlet.** REST is the human/operations layer (dashboard, SSE, webhooks, `/health`, OpenAPI mirror, browser auth). Agent-callable functionality lives in MCP tools as the source of truth; REST agent-CRUD routes are sunsetting.

**Sunset cycle on REST agent-CRUD aliases:**
- Sunset date: `2026-08-06` (90 days from 2026-05-08).
- Headers emitted by deprecated routes: `Deprecation: true`, `Sunset: 2026-08-06`, and `Link: <https://docs.finlet.dev/mcp/tools/{tool_name}>; rel="successor-version"` where a per-tool mapping exists, otherwise `Link: <https://docs.finlet.dev/mcp>; rel="successor-version"`.
- Routers stay dual-mounted (canonical `/v1/...` + deprecated unversioned aliases) for the 90-day window. No REST endpoint is deleted in Phase 3 — deletion is post-90-day cleanup.

**REST keep-list (no Sunset header).** Categories that stay live indefinitely because they are not agent surfaces:
- Auth / cookie endpoints (`/auth/*`, except `/auth/research-network/*` which IS deprecated — see exception below).
- Webhooks (`/billing/webhook` — Stripe pub-sub-to-server has no MCP equivalent).
- SSE streams (`/sessions/{id}/stream` — browser EventSource pattern).
- Ops / health (`/health`, `/plugins/health`, `/metrics`).
- Public legal (`/privacy`, `/terms`).
- Browser telemetry (`/csp-report`, `/telemetry/client-error`).
- Admin (`/admin/*`).
- Async job acceptance (`/plugins/{name}/ingest` — 202 + job_id pattern).
- OpenAPI mirror (`/openapi.json`, `/docs`, `/redoc`).
- Public read endpoints used by dashboard + leaderboard (`/leaderboard`, `/leaderboard/benchmarks`).
- Email magic-link callbacks (`/email/verify-token`).
- Root (`/`).

**Pattern exceptions** — deprecated despite the `/auth/` prefix match:
- `/auth/research-network/opt-in` and `/auth/research-network/opt-out` are NOT cookie-auth callbacks; they are agent-CRUD style mutations and emit Sunset headers like the rest of agent-CRUD.

The full keep-list (exact paths, prefixes, patterns, and the REST→MCP tool mapping) is canonical in `finlet/api/deprecation.py`. Path-scoped rules live in `.claude/rules/api-routes.md` so future API edits auto-load the policy. The mapping table itself is single-sourced in the code module; the rules file references the module rather than duplicating it.

CLI migration to `/v1/...` (audit H1's CLI half) is **out of Phase 3 scope** and stays in Phase 5, where the CLI rewires from REST-over-HTTP to MCP-over-stdio entirely. The CLI continues calling unversioned routes during the sunset window; users will see the Sunset header surface as a stderr warning once Phase 5 wires it through.

## Consequences

- The 90-day sunset window starts on the merge date. Downstream callers of unversioned agent-CRUD routes will see `Deprecation` and `Sunset` headers immediately and can migrate to `/v1/...` (today) or to MCP tools (canonical post-Phase-5).
- Dashboard read-only paths (`GET /sessions`, `GET /portfolio/*`) currently hit the unversioned mount and will see Sunset headers — the browser ignores them, so the UI is unaffected. Phase 6 docs work moves dashboard fetches to `/v1/...` for cleanliness; that is non-blocking.
- `finlet/cli.py` continues calling unversioned routes during the sunset window; it gets rewired in Phase 5 directly to MCP-over-stdio (skipping the `/v1/...` migration entirely). Users on a stale CLI past `2026-08-06` will start seeing 404s; the CLI must publish a tracking minor release before then.
- `tests/api/test_api_versioning.py` continues to pass — its existing two assertions test presence/absence of headers, not specific Sunset dates. The Phase 3 test suite (`tests/api/test_deprecation_headers.py`, owned by Team C) adds comprehensive keep-list and per-tool-link coverage.
- `finlet/api/services/*.py` is unchanged in Phase 3 — Phase 2 surface remains locked. The middleware refinement is purely additive on top of the service layer and consumes no service code.
- Drift policy: any change to the keep-list, prefixes, patterns, or REST→MCP tool mapping MUST update both `finlet/api/deprecation.py` AND `.claude/rules/api-routes.md` in the same PR. The rules file is path-scoped to `finlet/api/**` so future agents see the contract automatically.
- Next migration: Phase 4 (OAuth 2.1 + DCR) removes the `api_key` tool argument from MCP tools entirely — a separate auth-layer migration that runs in parallel with Phases 5/6.

## Alternatives Considered

1. **Delete unversioned agent-CRUD routes immediately.** Rejected — breaks `finlet/cli.py` and any downstream automation built against the unversioned mount before they have time to migrate. The 90-day Sunset window matches RFC 8594 expectations and gives integrators a documented path off.
2. **Make `Link` always point to the generic MCP docs URL.** Rejected — when a per-tool mapping exists, pointing readers at the exact MCP tool docs URL is more useful than a landing page. Falling back to the generic URL only when no mapping exists keeps the contract simple.
3. **Move the keep-list to a new top-level `docs/MCP_AS_PRODUCT_SURFACE.md`.** Rejected per the Phase 3 handoff brief. Path-scoped rules in `.claude/rules/api-routes.md` auto-load whenever an agent edits `finlet/api/**`, so the policy is enforced at the edit site rather than buried in a top-level doc nobody reads. The decision record (this file) captures the architectural rationale; the rules file captures the day-to-day policy.
4. **Sink REST→MCP tool mapping into `.claude/rules/api-routes.md` verbatim.** Rejected — the table is long enough (35+ rows) that maintaining two copies invites drift. Code module is canonical; rules file references it.
