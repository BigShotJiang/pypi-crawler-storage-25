# Copy API Key — Dead-Affordance Fix (Redirect on Cookie-Session Path)

**Status:** Accepted (2026-05-03)
**Triage iteration:** `bug-hunt 20260503T195318Z43db` (Team B)
**Affected files:** `dashboard/shared-nav.js`, `dashboard/mobile-nav.js` (inherits via `.click()` proxy)

## Context

The user-menu "Copy API Key" button (`#menu-copy-key` in the desktop user menu, `#nav-drawer-copy-key` in the mobile drawer) was a dead affordance for any user on the cookie-session auth path. Specifically:

- Signup-tab users: `FinletAuth.getApiKey()` returned the raw key from `_inMemoryApiKey` (populated by `saveAuth` in `dashboard/auth.js:815-821` during signup). Clipboard write worked.
- Just-created-key tab (Settings → Create New Key): the raw key was stored in `sessionStorage.finlet_created_api_key` for one-time display. Clipboard write worked.
- Logged-in tab (any cookie-session user): `_inMemoryApiKey === null` and `sessionStorage.finlet_created_api_key` is empty. The button silently did nothing useful — it surfaced a misleading toast ("No Key — Create a new API key in Settings") with no action behind the click.

The blind agent during triage observed the literal string `'session'` in `sessionStorage.finlet_api_key` and assumed it was a placeholder for a corrupted/null API key. It is not. That key is `AUTH_STORAGE_KEY` and stores a sentinel: `'cookie'` | `'memory'` | `'session'` indicating which auth-path lifecycle is active. The login flow (`dashboard/auth.js:760`) writes `'session'` AFTER a successful `POST /auth/login` because the cookie is what actually authenticates — `_inMemoryApiKey` is intentionally never populated on this path. The `saveAuth` function (`dashboard/auth.js:362-392`) further enforces this: after exchanging the API key for a cookie session at `POST /auth/session`, the in-memory key is intentionally discarded.

This is **load-bearing security**: API keys are stored hashed server-side; the plaintext is unrecoverable post-handshake by design. There is no `GET /v1/auth/apikey` or `GET /v1/user/apikey` endpoint, and there should never be one.

## Decision

When `FinletAuth.getApiKey()` returns null/empty:
1. Show an informational toast: "Open Settings to create a new key — Your existing key is not retrievable for security; create a new named key from Settings."
2. Redirect to `settings.html#api-keys` (Settings page deep-link to the API Keys tab — settings uses URL-hash navigation, validated against `dashboard/settings.html:91` `data-section="api-keys"` and `dashboard/settings.js:127-156` hash-driven `switchSection`).
3. On user-menu open (`shared-nav.js:278-298` trigger click), dynamically relabel `#menu-copy-key.textContent` to "Manage API Key" when `getApiKey()` returns null, "Copy API Key" otherwise. The button text now matches its semantics for the current auth path.

When a key IS in memory: existing clipboard-write + success-toast behavior is preserved.

The mobile drawer button (`#nav-drawer-copy-key`) is a thin proxy that calls `desktopCopyKey.click()` (`dashboard/mobile-nav.js:175-195`) — it inherits the fix automatically; no separate code path.

## Alternatives Rejected

1. **Remove the button entirely.** Cleaner for the security model but loses the convenience for fresh-signup users (the only path where clipboard-write actually succeeds and is genuinely useful for getting started fast).

2. **Auto-invoke `POST /v1/settings/api-keys/rotate` on click.** Destructive — rotating the key would break any existing agents already using the previous key in the wild. Users must opt in to rotation, never have it imposed on them by a click in a user menu.

3. **Add a server endpoint that returns the raw key.** This is the path the blind agent probed (`GET /api/user/apikey` → 404 in the harness). It would defeat the hash-only key storage invariant — any compromise of a session would expose every key the user has minted, not just the keys created within that session. Hash-only storage is the load-bearing security property; do not break it for UX convenience.

4. **Silent fail (status quo).** Status quo is the bug. A button that does nothing on click is a UX failure regardless of the implementation reason.

## Consequences

- The button is no longer dead. Every click does *something useful* — clipboard write OR redirect.
- The label tracks the actual semantics for the user's current auth path, eliminating the ambiguity that confused the blind agent.
- The clipboard never receives the literal sentinel string `'session'` — `getApiKey()` never returns that string by construction (it reads from `_inMemoryApiKey || sessionStorage.finlet_created_api_key`, neither of which holds the auth-path sentinel).
- Mobile drawer button inherits the fix via the existing `.click()` proxy in `mobile-nav.js:180`.
- No server-side change. No new endpoint, no destructive action on click. Hash-only key storage invariant preserved.

## Validation

- Manual: log in (cookie-session path), open user menu → button reads "Manage API Key"; click → redirect to `settings.html#api-keys` lands on the API Keys section.
- Manual: sign up (fresh signup path), open user menu → button reads "Copy API Key"; click → clipboard receives a real raw key (not the literal `'session'`).
- Manual: clipboard never contains the literal string `'session'`.
- `bash scripts/lint-trusted-types.sh` passes (no new raw `.innerHTML =` writes).

## References

- `dashboard/shared-nav.js:278-298` — user-menu trigger click handler with dynamic relabel.
- `dashboard/shared-nav.js:301-345` — copyKeyBtn click handler with clipboard-write + redirect dual path.
- `dashboard/auth.js:1641-1645` — `FinletAuth.getApiKey()` contract (`_inMemoryApiKey || sessionStorage.finlet_created_api_key || null`).
- `dashboard/auth.js:362-392` — `saveAuth()` discards `_inMemoryApiKey` after cookie-session handshake (load-bearing security).
- `dashboard/auth.js:760` — login flow writes the `'session'` sentinel into `AUTH_STORAGE_KEY` (NOT a key — the marker the blind agent confused).
- `finlet/api/services/settings_service.py:125-189` — `list_api_keys` (masked-only metadata) and `create_api_key` (returns raw key once on creation). No `read_api_key` exists by design.

---

## Addendum — Initial-Render Relabel (2026-05-06, bug-hunt `20260506T185234Z542e`)

**Status:** Accepted (2026-05-06)
**Triage iteration:** `bug-hunt 20260506T185234Z542e` (Team B, commit `74a368c`)
**Affected files:** `dashboard/shared-nav.js`

### Context

The original 2026-05-03 fix added the dual-label affordance — `#menu-copy-key.textContent = hasKey ? 'Copy API Key' : 'Manage API Key'` — but the relabel ran ONLY inside the trigger click handler's `if (isOpen)` branch. The static literal `'Copy API Key'` from `_buildHeaderHTML()` (line 198 at HEAD) was the cold-state ARIA accessible name for the entire interval between page load and the first user-menu toggle. Any aria-snapshot, screen-reader scan, or accessibility-tree dump in that interval read the wrong contract on the cookie-session auth path: the menuitem announced "Copy API Key" while the click was wired to redirect rather than copy. Surfaced by bug-hunt iteration `20260506T185234Z542e` blind agent (cold-state ARIA observation; click navigated to settings without copying).

### Decision

Extract the relabel into a named helper `_relabelCopyApiKeyButton(button)` and call it from BOTH:

1. `_initSharedUserMenu()` on initial mount (after `FinletAuth` is available — `auth.js` loads before `shared-nav.js` in `index.html`, satisfying the dependency-availability gate at mount time).
2. The trigger click handler's open-branch (preserves the original 2026-05-03 contract: a key minted while the menu was closed, e.g. after Settings → Create New Key, is reflected on the next open).

Idempotent helper, two call sites, single source-of-truth label. Both auth paths preserved end-to-end:
- cookie-session path (`getApiKey() → null`) → "Manage API Key" + click → redirect to `settings.html#api-keys`.
- signup/just-rotated path (`getApiKey() → non-null`) → "Copy API Key" + click → `clipboard.writeText(key)` + success toast.

### Alternatives Rejected

1. **Server-rendered initial label.** Would require a server-side auth-path detection and an SSR rendering path, neither of which exist in the dashboard's vanilla-JS pipeline. Out of proportion to the fix.
2. **Single label "Manage API Key" on ALL paths (collapse the dual semantics).** Would lose the convenience clipboard-copy on the signup/just-rotated path — exactly the only path where clipboard write actually succeeds and is the load-bearing UX for fresh-signup users. Rejected for the same reason as the original 2026-05-03 "remove the button entirely" rejection.
3. **Inline the relabel call inside `_initSharedUserMenu()` without extracting the helper.** Two near-identical call sites with different conditional shells will drift the moment one site adds a new edge case the other doesn't. Refactor to helper FIRST, then call from both sites. Helper signature `_relabelCopyApiKeyButton(button)` reads `FinletAuth.getApiKey()` internally and writes to `button.textContent` — no caller-side conditional logic.

### Consequences

- Cold-state ARIA accessible name on cookie-session auth is "Manage API Key" BEFORE any toggle. Screen-reader announcements, aria-snapshots, accessibility-tree dumps all read the correct contract on first paint.
- The trigger click handler's open-branch still re-runs the helper, so a key minted between page load and first toggle (e.g. user creates a key in Settings, returns to dashboard, opens the user menu) is reflected on the next open. The relabel is idempotent.
- Mobile drawer button (`#nav-drawer-copy-key`) inherits the fix via the existing `.click()` proxy in `mobile-nav.js:180` — no separate code path needed for the relabel since the desktop helper writes the desktop button's textContent and the mobile drawer never displays `#menu-copy-key` directly.
- No change to the click handler's behavior (clipboard write OR redirect) — only the LABEL rendering. Hash-only key storage invariant preserved.
- The dual-label affordance documented in the original record above remains load-bearing and intact.

### Validation

- 8 new `node:test` unit tests in `tests/dashboard/shared-nav.spec.js` cover both auth paths × both lifecycle moments (initial mount + click-to-open transition), idempotency on repeated calls, and defensive handling (FinletAuth undefined / `#menu-copy-key` absent).
- New Playwright spec `tests/e2e/journey-shared-nav.spec.ts` asserts the cookie-session live-site contract: collapsed-state and expanded-state ARIA accessible names BOTH read "Manage API Key", and the click navigates to `settings.html#api-keys` (not clipboard).
- `node --test tests/dashboard/shared-nav.spec.js` → 8/8 pass.
- Full dashboard unit suite (45 tests across event-bus, onboarding-checklist, shared-nav) → 45/45 pass.
- `bash scripts/lint-trusted-types.sh` → OK (0 bare HTML-sink writes — relabel writes via `textContent`, not `innerHTML`).
- `bash scripts/lint-event-bus.sh` → OK (0 direct event-bus bypasses).

### References

- `dashboard/shared-nav.js` (post-fix) — `_relabelCopyApiKeyButton(button)` helper + two call sites.
- `tests/dashboard/shared-nav.spec.js` — unit coverage of the initial-mount + open-branch lifecycle.
- `tests/e2e/journey-shared-nav.spec.ts` — Playwright cold-state ARIA assertion.
- `docs/bug-hunt/20260506T185234Z542e/triage.md` — the cold-state ARIA observation that surfaced the gap.
- `docs/LESSONS.md` (bug-hunt 20260506T185234Z542e section) — `initial-render-relabel` lesson generalizing this pattern beyond the user-menu surface.

---

## Addendum — Surface Unification via Parameterized Helper + Bus Subscriber (2026-05-07, refactor `aria-label-mismatch`)

**Status:** Accepted (2026-05-07)
**Refactor iteration:** `docs/bug-hunt/refactor-queue/aria-label-mismatch.md` (Team A, commit `b9ccf4a` on `origin/main`; local pre-rebase SHA was `18f54a8`)
**Affected files:** `dashboard/shared-nav.js`, `dashboard/mobile-nav.js`, `dashboard/auth.js`, `dashboard/event-contract.md`, `tests/dashboard/shared-nav.spec.js`, `tests/e2e/journey-shared-nav.spec.ts`

### Context

The 2026-05-06 addendum above closed the cold-state ARIA gap on the desktop user-menu button (`#menu-copy-key`), but the helper `_relabelCopyApiKeyButton()` was zero-arg and hard-coded `getElementById('menu-copy-key')`. The mobile nav drawer button (`#nav-drawer-copy-key`) — present as a static `<button … id="nav-drawer-copy-key">Copy API Key</button>` literal across four dashboard pages (`dashboard/{index,billing,leaderboard,settings}.html`) — had no relabel path at all. On the cookie-session auth path the drawer button shipped the stale "Copy API Key" literal from page-load until forever, while the desktop button (after Team B's 2026-05-06 fix) read "Manage API Key". `pending_recurrences.jsonl` recorded this as `shared-nav-collapsed-label-stale` (iteration `20260506T185234Z542e`, retest evidence: collapsed-state accessible name `'Copy API Key'` on cookie-session). A third drift site lived inside `dashboard/mobile-nav.js:188` — a hardcoded `'Copy API Key'` reset literal used after the clipboard-success-toast timeout — which would have flashed the wrong-state label to a signup-then-logout user within the same page session.

### Decision

Unify both surfaces under a closed enum + a bus-driven repaint, with no per-page plumbing change to add a new surface.

1. **Parameterize the helper.** `_relabelCopyApiKeyButton(buttonOrId)` accepts an HTMLElement, an id string, OR no argument (defaults to `#menu-copy-key`). The no-arg shape preserves the eight existing unit tests in `tests/dashboard/shared-nav.spec.js` (which call `env.sandbox._relabelCopyApiKeyButton()` with zero args). Tests 7 and 8 are retitled to reflect the new contract — relabel-on-click is no longer a separately tested code path because the bus subscriber is the sole repaint trigger after mount.

2. **Add the umbrella + closed enum.** New module-scope `var API_KEY_AFFORDANCE_IDS = ['menu-copy-key', 'nav-drawer-copy-key']` plus `_relabelAllApiKeyAffordances()` iterating the list. Adding a new surface (a 3rd in-page id, a future tier-aware affordance, etc.) is one entry in the enum; the umbrella's mount-time pass auto-discovers any present id and is a no-op for absent ids.

3. **Subscribe to a new `auth:state-change` bus event.** `dashboard/auth.js` gains a `_publishAuthStateChange()` helper called from `saveAuth` (after both cookie-session-success and in-memory-fallback paths mutate `_inMemoryApiKey`) and from `clearAuth` (logout / session-invalidate). The publish is defensively guarded — auth pages without `window.finletBus` (e.g. `auth.html`) silently no-op. The subscriber inside `_initSharedUserMenu()` re-runs the umbrella so any auth-state mutation atomically repaints both surfaces without a page reload. Note: Team A's review of the actual code found the scope doc's `setApiKey` reference was incorrect — `setApiKey` does not exist; the canonical mutation sites are `saveAuth` (auth.js:389) and `clearAuth` (auth.js:401). The publisher reads `FinletAuth.getApiKey()` (the public source-of-truth that includes the `sessionStorage.finlet_created_api_key` fallback) so the payload reflects the same surface subscribers read.

4. **Three call sites for the umbrella.** (a) `_initSharedUserMenu()` mount, (b) `initMobileNav()` mount (defensively, for pages where mobile-nav initializes after shared-nav), (c) the `auth:state-change` bus subscriber. All three are idempotent.

5. **Drop the legacy gates.** The `if (isOpen) _relabelCopyApiKeyButton()` branch at `shared-nav.js:298` is deleted — the bus subscriber covers any case where a key is minted between page load and the next user-menu open. The `mobile-nav.js:188` hardcoded clipboard-success reset literal is replaced by `window.SharedNav._relabelCopyApiKeyButton(drawerCopyKey)`. The `shared-nav.js:343` clipboard-success reset literal is similarly replaced by a helper call. Three drift sites collapse into one source-of-truth helper.

6. **Static HTML literals stay.** The `<button class="nav-drawer-action" id="nav-drawer-copy-key" type="button">Copy API Key</button>` literals in `dashboard/{index,billing,leaderboard,settings}.html` are intentionally NOT modified — they remain as graceful-degradation fallbacks for the rare case where JS fails to load. The umbrella's mount-time pass overrides the literal before paint, so on the cookie-session path the user never sees the stale "Copy API Key" string in normal operation. (Option A from the refactor scope; Option B — placeholder `aria-busy="true"` markup — was rejected as net-zero with extra plumbing risk.)

### Alternatives Rejected

1. **New module `dashboard/api-key-affordance.js`.** Same blast radius (still must edit `shared-nav.js` to drop the hard-coded helper, still must edit `mobile-nav.js` to consume the new module, still must edit `auth.js` to publish), plus +1 file + 4 `<script>`-tag edits across the dashboard pages for zero behavior gain. Both surfaces are already coupled to shared-nav (the desktop button via `_buildHeaderHTML`, the drawer button via `mobile-nav.js`'s `.click()` proxy). Keeping the umbrella in `shared-nav.js` keeps related code colocated.
2. **Remove the static HTML literals across the 4 pages and render the drawer button via JS hydration.** Net-zero correctness gain with extra plumbing risk (a new mount-time hydration path, a new failure mode if the umbrella runs after the user opens the drawer). The static literal as graceful-degradation fallback is the cheaper invariant.
3. **Re-using a generic `dashboard:state-change` event.** Rejected — auth-state is a distinct concern from generic UI state, and overloading a generic event would couple unrelated subscribers. The decision-record for `dashboard/event-bus.js` (`docs/decisions/dashboard-event-bus.md`) stipulates "many small events over one fat one"; `auth:state-change` is the small-event answer.

### Consequences

- **Single source-of-truth for API-key-affordance labels.** Every label site (`#menu-copy-key`, `#nav-drawer-copy-key`, the `mobile-nav.js` post-clipboard reset, the `shared-nav.js` post-clipboard reset) reads `FinletAuth.getApiKey()` through one helper. Drift between sites is no longer possible without removing the helper itself.
- **Adding a new surface is a one-line registry edit.** A future "Manage Subscription" / tier-aware button on the user menu, or a 5th dashboard page that introduces a new auth-state-dependent button, is one entry in `API_KEY_AFFORDANCE_IDS` (or, for an entirely new affordance, a sibling closed enum + sibling helper using the same bus event). The 4 static HTML files stay decoupled from JS plumbing.
- **The dual-label semantics from the original 2026-05-03 record remain load-bearing and intact.** `getApiKey() → null` → "Manage API Key" + redirect; `getApiKey() → non-null` → "Copy API Key" + clipboard write. Only surface unification changed; click semantics are unchanged.
- **The `auth:state-change` event is now the canonical signal for cross-component auth-state mutations.** Future consumers (e.g. analytics surfaces tracking "session established" events) subscribe through the same convention. Documented in `dashboard/event-contract.md` (7th entry) per the bus convention's "update contract in same commit" rule.
- **No server-side change.** Hash-only key storage invariant preserved end-to-end. No new endpoint, no destructive action on click.
- **The mobile drawer's `.click()` proxy in `mobile-nav.js:175-195` continues to work unchanged.** The proxy fires the desktop button's CLICK behavior (clipboard-write OR redirect, depending on `getApiKey()`); the drawer button now also has its own LABEL repainted via the umbrella, closing the previously-silent label-only divergence.

### Validation

- 13 unit tests in `tests/dashboard/shared-nav.spec.js` (was 8): the original 8 still pin the no-arg helper shape against `#menu-copy-key`; 5 new tests cover (a) parameterized id-string call, (b) parameterized element call, (c) umbrella iteration over the closed enum with idempotent missing-id handling, (d) `auth:state-change` bus subscriber repaint of both surfaces, (e) mobile-nav clipboard-success path consuming the helper instead of the static literal. Tests 7+8 are retitled to reflect the deletion of the `if (isOpen)` gate.
- 6 Playwright tests in `tests/e2e/journey-shared-nav.spec.ts` (was 1): cookie-session × desktop user-menu (existing), cookie-session × mobile drawer (new), signup × desktop user-menu (new), signup × mobile drawer (new), bus-repaint-on-logout (new), bus-repaint-on-key-set (new).
- `tests/e2e/journey-09-mobile.spec.ts` line 60 still passes — the assertion on `#nav-drawer-copy-key` visibility is unaffected by the label change.
- `bash scripts/lint-trusted-types.sh` — passes (relabel writes via `textContent`, not `innerHTML`).
- `bash scripts/lint-event-bus.sh` — passes (the new bus subscription uses `bus.subscribe`, not `addEventListener('finlet:…')`; the new publisher uses `bus.publish`, not `dispatchEvent(new CustomEvent(...))`).

### References

- `dashboard/shared-nav.js` — `API_KEY_AFFORDANCE_IDS` enum, parameterized `_relabelCopyApiKeyButton(buttonOrId)`, `_relabelAllApiKeyAffordances()` umbrella, `auth:state-change` bus subscriber, `window.SharedNav` exports for cross-module access.
- `dashboard/mobile-nav.js` — `initMobileNav()` mount-time umbrella call (defensive), `_relabelCopyApiKeyButton(drawerCopyKey)` swap at the post-clipboard reset site.
- `dashboard/auth.js` — `_publishAuthStateChange()` helper, called after `saveAuth`'s key mutations and after `clearAuth`'s logout path. Defensively guarded for auth-page contexts where `window.finletBus` is absent.
- `dashboard/event-contract.md` — `auth:state-change` section (7th canonical event).
- `docs/decisions/dashboard-event-bus.md` — the bus convention this refactor extends without modifying.
- `docs/bug-hunt/refactor-queue/aria-label-mismatch.md` — the refactor scope doc; status flipped to `shipped` in the same docs commit as this addendum.
- `docs/bug-hunt/pending_recurrences.jsonl` / `.resolved.jsonl` — `shared-nav-collapsed-label-stale` migrated from pending → resolved by this refactor.
