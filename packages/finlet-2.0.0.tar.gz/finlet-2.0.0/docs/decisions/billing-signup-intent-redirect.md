# Decision: Billing Signup → Checkout Deep-Link via Query-String Round-Trip

**Date:** 2026-05-13
**Status:** Accepted
**Source:** SETTINGS_AND_BILLING_RESTORE exec-plan, Team C (commit `83fe770`).

## Context

The restored billing UX needs a clean path from "anonymous visitor on `pricing.html`" to "authenticated user on Stripe Checkout for the chosen tier" in one fluid motion. The page sequence is:

1. Visitor clicks an upgrade CTA on `/pricing` for a specific tier.
2. Visitor is anonymous, so they must sign up (or log in) at `/auth`.
3. After successful auth, the visitor expects to land at Stripe Checkout for the tier they clicked — NOT at the dashboard with a fresh "choose your tier again" prompt.

The signup form lives in `dashboard/auth.html` + `dashboard/auth.js`. Stripe Checkout is initiated via a POST to `/v1/billing/checkout-session` from `dashboard/billing.js`. The two pages don't share a runtime context — the auth page reloads the dashboard after success.

We needed to carry the visitor's tier intent across the auth redirect without leaking it client-side or coupling the auth flow to billing internals.

## Decision

**Pass the tier intent via URL query string: `auth.html?from=signup&intent=subscribe&tier=<tier>`.**

`pricing.html`'s tier-button click handler constructs the URL. `auth.js` reads `URLSearchParams` at submit-success time; if `intent=subscribe` and `tier` is in the URL-allowlist for known tiers, it 302s to `billing.html?intent=subscribe&tier=<tier>`. `billing.js` reads its own query string at boot, validates `tier` against the same allowlist, and auto-fires the Stripe Checkout POST.

URL allowlist for the redirect target itself is enforced by `finlet/config.py:96` (`finlet.dev` + `localhost`) — the redirect target is always relative, but the allowlist defends against future absolute-URL drift.

## Rationale

### Why query-string round-trip (not cookies / localStorage)?

- **Stateless and crashable.** The intent is encoded in the URL; if the browser tab dies between auth and redirect, the user can refresh and the intent is preserved. Cookie/localStorage state would need explicit lifecycle management (set, read-once, clear) and either leak across tabs or drop on close.
- **No server changes needed.** The auth and billing endpoints stay tier-agnostic. Carrying intent server-side would require either a new "pending intent" column on the user/session model (overkill — this is a single-redirect lifetime) or a query-param echo on the auth response (still client-driven, just one extra hop).
- **Inspectable end-to-end.** Every transition is visible in the address bar; debugging the flow is "look at the URL." Cookie state needs DevTools application tab; localStorage needs a console snippet.
- **No PII leakage.** `tier` is a public enum (`free`, `agent`, `team`, …); it's not sensitive. Email/password never enter the URL at any step.
- **Same-origin redirect only.** The query-string is consumed at `auth.html` → `billing.html` on the same origin. There is no cross-origin handoff, no risk of leaking `intent` to a third party via Referer.

### Why allowlist the tier on both ends?

Defense-in-depth against an attacker crafting `auth.html?intent=subscribe&tier=<arbitrary>` and tricking a freshly signed-up user into hitting Stripe with a malformed tier. The allowlist ensures `tier` matches a known SKU before either page acts on it; a bad value falls through to the dashboard's default landing.

### Why fire Checkout from `billing.js`, not directly from `auth.js`?

`billing.js` owns the Stripe Checkout POST and the error envelope handling. If the auth page short-circuited to Stripe directly, it would either need to import billing.js's Checkout logic (coupling) or re-implement it (duplication). Routing through `billing.html` keeps one Checkout call site and lets the user see the billing UI (current state, tier comparison) for the half-second before Stripe redirects.

## Alternatives considered

- **Cookie-based intent (`finlet_signup_intent`).** Rejected: lifecycle management overhead; cross-tab bleed; drops on tab close.
- **localStorage with TTL.** Rejected: same problems as cookies plus storage-quota concerns and a "intent stale after 30 minutes" arbitrary cutoff.
- **Pending-intent server table.** Rejected: requires a new model, migration, expiry job, and an extra round-trip on every signup — disproportionate to the one-redirect lifetime.
- **OAuth `state` parameter abuse.** Rejected: `state` is reserved for CSRF protection in OAuth flows; conflating it with UX intent invites a security gotcha later.

## Consequences

- **Adding a new tier** is one entry in the `pricing.html` button list and one entry in the `auth.js`/`billing.js` allowlist (3 sites). Acceptable for a closed-enum-of-tiers product; we'd revisit if tiers became user-creatable.
- **The flow is observable to extensions** that read query params. Acceptable — `tier` is public.
- **A user can bookmark `auth.html?from=signup&intent=subscribe&tier=team`** and replay the flow. By design — bookmarking the tier-specific signup is a feature.

## Related

- `finlet/config.py:96` — URL allowlist (`finlet.dev` + `localhost`)
- `dashboard/auth.js`, `dashboard/billing.js` — both ends of the round-trip

## 2026-05-15 — Live mode activated

Stripe live-mode billing surface flipped on 2026-05-15. Real-card Builder $29 Checkout proven end-to-end on `https://finlet.dev`. The decision itself (query-string round-trip via `auth.html?from=signup&intent=subscribe&tier=...`) is unchanged — only the underlying Stripe configuration moved from test to live mode.
