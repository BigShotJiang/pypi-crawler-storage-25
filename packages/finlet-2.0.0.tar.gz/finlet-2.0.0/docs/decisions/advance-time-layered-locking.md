# Decision: Layered Locking for `advance_time` (Outer Step-Lock, Inner Fill-Lock)

**Date:** 2026-05-07
**Status:** Accepted
**Source:** MCP-First Migration Phase 1, audit finding C2 (commit `1076df9`, Team A)

## Context

The MCP `advance_time` tool has three branches: single-step (`steps == 1`), repeated-step batch (`steps > 1`), and absolute target (`target_date`). All three call `session.step()` / `session.step_to()` followed by `clock_service.refresh_prices_and_fill_orders(session)`, which delegates to `Session.process_pending_orders` — and that already acquires `session._tick_lock` internally.

Two concurrent `advance_time` calls on the same session could race their `step()` updates because the clock-step phase was lock-free, corrupting `session.clock` state and producing duplicate / interleaved trace entries. Naively wrapping the entire branch in `async with session._tick_lock:` deadlocks: `process_pending_orders` re-enters the same lock and `asyncio.Lock` is **non-reentrant**.

## Decision

Split each branch into two phases under different locks:

1. **Clock-step phase** (`session.step()` / `session.step_to()`) runs inside `async with session._tick_lock:`. Two concurrent `advance_time` calls serialize here.
2. **Fill phase** (`refresh_prices_and_fill_orders` → `process_pending_orders` → portfolio mutation, plus persistence) runs **outside** the outer lock. The inner `_tick_lock` acquisition inside `process_pending_orders` provides serialization. Two concurrent batches still cannot fill the same order twice — they queue at the inner lock.

A new helper `_post_step_persist_and_fill(session, sid, state, trace_count_before)` in `finlet/mcp/server.py` mirrors the post-step half of `_svc_advance_session` so the single-step and repeated-step branches can both apply the pattern with one function. The `target_date` branch inlines the pattern (the post-step ergonomics differ — start/end-time bookkeeping, `days_advanced` math).

## Consequences

- `tests/mcp/test_concurrency.py` covers `asyncio.gather(advance_time, submit_order)` and parallel `advance_time` calls without deadlock or state corruption.
- The pattern generalizes: any future MCP tool that mutates clock state and then triggers downstream work that already locks must split at the lock boundary. Re-entrance is the trap.
- This is a temporary accommodation — `Session._tick_lock` could be made re-entrant (`asyncio.RLock` does not exist in stdlib; would need a custom counter-based lock) but the layered pattern is simpler and more explicit. Revisit if more tools need the same split.
- REST `/clock/step-to` already runs inside route-handler context where this pattern is unnecessary; no parallel REST changes needed.

## Alternatives Considered

1. **Make `_tick_lock` re-entrant.** Rejected — adds a custom lock primitive; the layered split makes the lock topology explicit at every callsite that needs it.
2. **Skip the inner lock inside `process_pending_orders` when called from `advance_time`.** Rejected — `process_pending_orders` is called from REST, CLI, and other MCP tools; conditional locking is a correctness hazard.
3. **Run the fill phase synchronously inside the outer lock with a "no-op-if-held" sentinel.** Rejected — sentinel + lock state inspection violates `asyncio.Lock` API and is fragile under any future executor change.
