# Decision: Date-Partitioned Parquet with One File Per Day

**Date:** 2026-04-03
**Status:** Accepted
**Source:** Data Pipeline Implementation, Teams A-F

## Context

The S3 data lake stores 4 data types (prices, fundamentals, news, sentiment) as Parquet files. We needed a partitioning scheme that balances query performance, ingestion simplicity, and cost. Options considered:

1. **One file per ticker** -- simple writes but terrible read performance for date-range queries (must scan all ticker files).
2. **Date-partitioned, one file per ticker per day** -- fine-grained but creates millions of small files for a 500-ticker universe over 5+ years.
3. **Date-partitioned, one file per day (all tickers)** -- moderate file count, excellent read performance for the predominant access pattern (price lookups for a date range).
4. **Hive-style partitioning (year/month/day directories)** -- overkill for daily granularity; adds directory traversal overhead without meaningful benefit at this scale.

## Decision

Use **date-partitioned Parquet with one file per day containing all tickers** for time-series data (prices, news). Use **one file per ticker** for entity-scoped data (fundamentals, sentiment) where the access pattern is "all filings for AAPL" rather than "all fundamentals for 2024-03-15."

### S3 Path Scheme

| Data Type | S3 Path Pattern | Partitioned By |
|-----------|----------------|----------------|
| Prices | `prices/daily/{YYYY-MM-DD}.parquet` | Date (all tickers per file) |
| News | `news/daily/{YYYY-MM-DD}.parquet` | Date (all tickers per file) |
| Fundamentals | `fundamentals/quarterly/{TICKER}.parquet` | Ticker (all periods per file) |
| Sentiment | `sentiment/recommendations/{TICKER}.parquet` | Ticker (all dates per file) |

### Rationale

- **Prices/News by date:** The dominant query is "give me AAPL prices from 2024-01-15 to 2024-02-15" which maps to downloading ~30 files. Each file is small (500 tickers x 7 columns ~ 10-50 KB). Plugins use `asyncio.gather` to download date files concurrently.
- **Fundamentals/Sentiment by ticker:** The dominant query is "give me AAPL's latest quarterly financials" which maps to downloading 1 file. Filing history per ticker is small (8-12 quarters, 3 statement types, ~50 fields each).

## Consequences

- Daily ingestion writes exactly one file per date for prices and news (idempotent overwrite).
- Fundamentals and sentiment ingestion writes one file per ticker (idempotent overwrite).
- PricePlugin and NewsPlugin download date-range files concurrently via `asyncio.gather`.
- FundamentalsPlugin and SentimentPlugin download a single ticker file on first access.
- All 4 plugins cache downloaded Parquet files locally under `~/.finlet/cache/{type}/`.
- File count stays manageable: ~1,800 price files per year (trading days), vs. ~900K if partitioned per-ticker-per-day.
- Adding new tickers requires no structural changes -- they appear in the next daily file.
