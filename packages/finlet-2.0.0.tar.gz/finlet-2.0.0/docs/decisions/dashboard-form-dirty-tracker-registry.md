# Decision: Self-Enumerating Loader Registry for Dashboard Form-Dirty Tracker

**Date**: 2026-04-29
**Status**: Accepted

---

## Context

The v1 dirty-state-tracker refactor (commit `db7f637`, 2026-04-28; decision `dashboard-dirty-state-snapshot.md`) introduced a per-loader snapshot pattern: each async loader writes form fields, then calls `snapshotFields([...])` to rebase ownership of those fields into the clean baseline. The pattern is sound — it eliminates the *snapshot-too-early* shape — but the gate that delays `initFormTracking()` until loaders settle was implemented as a hand-maintained array:

```js
await Promise.allSettled([_profileLoaded, _notificationsLoaded, _appearanceLoaded]);
```

Bug-hunt iteration `20260429T052717Z1a13` recurred the false-positive banner shape. Root cause: the array enumerated 3 of 6 loader promises. `_mfaLoaded`, `_apiKeysLoaded`, and `_pluginsLoaded` were never captured into named variables, so they were silently absent from the gate. `initFormTracking()` ran while those three loaders were still in-flight; their writes landed after the rAF baseline pass and tripped the dirty banner.

The patch (commit `31c3255`) extended the array to all six promises. That closes this instance — but the failure shape is *forward-signal*: a 7th tab added next month would silently bypass the gate again, with no compile-time or test-time signal. The recurrence shape is not "missing snapshot," it's "drift between the loader set and the gate enumeration."

---

## Alternatives Considered

1. **Keep the static array, add a code-review checklist item.** Rejected — review checklists are forward-signal failures themselves; the recurrence shape we're closing IS a forgotten enumeration.
2. **Lint rule that scans for `function load*` and asserts each has a `_xLoaded` capture in the gate array.** Rejected — overfit to the current naming; brittle against rename or pattern drift.
3. **Single sentinel that loaders signal completion to (e.g., `loaderBarrier.signal()`).** Considered — equivalent expressive power to the registry, but requires every loader to know how many siblings exist (or requires a `loaderBarrier.expect(N)` declaration that re-introduces the same drift problem the registry eliminates).
4. **Self-enumerating loader registry — chosen.** Each loader pushes its promise into a registry at init time; the gate awaits the registry at execution time and re-drains until the registry stops growing. No central enumeration. A 7th tab is auto-gated the moment its loader calls `registerLoader(...)`.

---

## Decision

Extract dirty-state tracking into a new `dashboard/form-dirty-tracker.js` ES module exposing a self-enumerating loader registry. Public surface:

- `registerLoader(promise)` — every async loader calls this at the top with its promise
- `initFormTracker()` — awaits the registry, re-drains until stable, then sets up listeners
- `snapshotFields(ids)` — rebase a declared field set into the baseline (unchanged from v1)
- `snapshotAllTracked()` — rebase every tracked input (unchanged from v1)
- `setFieldDirty(id, bool)` — programmatic dirty toggle for non-input changes (e.g., theme card click)
- `discardChanges()` — reset to baseline

State (`originalValues`, `dirtyFields`, `loaderRegistry`, `_loaderUpdating`, `bannerEl`) lives inside the module. Backward-compat live getters for `dirtyFields` and `_loaderUpdating` remain on `window` so existing journey-06 tests keep working without rewrites.

`dashboard/settings.html` switches to `<script type="module" src="settings.js">`. `settings.js` shrinks by ~107 lines (1592 → 1485) as state moves out.

---

## Consequences

### Positive

- **Recurrence class structurally eliminated.** Adding a 7th loader requires only that the loader call `registerLoader(theirPromise)` — same convention every existing loader follows. Forgetting the call surfaces immediately as a banner flash on cold load (covered by the new Playwright tests). No hand-maintained array to forget.
- **Re-drain handles late registrants.** If a loader's promise spawns child loaders mid-await, the registry sees them and the gate keeps draining. No timing assumptions about "all loaders register synchronously."
- **Module boundary.** The tracker is now testable in isolation — 5 new unit tests in `tests/dashboard/` cover the registry contract (register-then-await, re-drain, idempotent init, snapshot semantics, dirty-toggle).
- **Low blast radius.** `settings.js` is the only consumer. Reversal path is a single revert (~15 minutes).

### Negative

- **`<script type="module">` semantics differ from classic scripts.** A script-scoped `const API_BASE = ...` no longer leaks to other scripts; `settings.js` re-derives `API_BASE` locally. This was the only behavioral change from the module conversion.
- **Live getters on `window` for `dirtyFields` / `_loaderUpdating` are a transitional concession.** Existing Playwright tests inspect these directly. Removing the getters requires migrating tests to use the public API (`__test__` exports) — tracked as cleanup once the next refactor touches these tests anyway.
- **Convention is still enforced by review.** A loader that forgets `registerLoader(...)` will reintroduce the bug for its tab. Mitigation: every existing loader is a worked example; the new Playwright cold-load tests fail loudly if a banner flashes during init for any tab.

### Trade-offs explicitly chosen

- **Re-drain over fixed-iteration await.** A fixed `Promise.allSettled(registry)` would miss promises registered during the await. Re-draining until the registry stops growing handles late registrants at the cost of a tiny loop — worth it.
- **Module extraction over "fix in place."** v1's decision record explicitly deferred extraction ("Settings is the only consumer today; if a second settings-style page emerges, the extraction is mechanical"). v2 forces the extraction now because the registry pattern needs a clear ownership boundary — the module IS the registry. Future settings-style pages get the registry for free.

---

## References

- Plan: `docs/refactor/dirty-state-tracker-v2/plan.md`
- v1 decision (superseded mechanism, same problem space): `docs/decisions/dashboard-dirty-state-snapshot.md`
- v1 enumeration patch (immediate fix before v2): commit `31c3255` (bug-hunt `20260429T052717Z1a13`, Team A)
- v2 implementation: `dashboard/form-dirty-tracker.js`, `dashboard/settings.js`, `dashboard/settings.html` — merged in commit `ed15c6c`
- Tests: 5 unit tests in `tests/dashboard/`, 3 cold-load Playwright regressions in `tests/e2e/journey-06-settings.spec.ts`
- Refactor queue entry: `docs/bug-hunt/refactor-queue/dirty-state-tracker.md`
