# Decision: HTTPS + GITHUB_TOKEN for Deploy Git Pulls & SSM Polling Loop

**Date**: 2026-03-26
**Status**: Resolved
**Context**: Deploy pipeline was silently failing — `git pull` never ran on the server, causing stale code to be reinstalled on every deploy. Root cause was five layered failures in the SSM execution environment: no `$HOME`, no `safe.directory`, no SSH host key, no SSH deploy key, and `aws ssm wait` timing out before the deploy finished.

---

## Problem 1: Git Authentication on SSM Root Shell

SSM Send-Command runs as root on the EC2 instance. The repository at `/opt/finlet` is owned by user `finlet`. Even after fixing `safe.directory`, root had no way to authenticate `git pull` over SSH:

- Root has no SSH deploy key for the GitHub repo.
- The `finlet` user's SSH key is not accessible to root without `sudo -u finlet`, which introduces its own permission chain issues (the finlet user lacks sudo).
- SSH agent forwarding is not available in SSM sessions.

### Options Evaluated

#### 1. SSH Deploy Key for Root (rejected)

Generate a new deploy key, install it in `/root/.ssh/`, add it to GitHub as a repo deploy key.

**Pros**:
- Familiar SSH-based workflow.
- Deploy key is scoped to the repository.

**Cons**:
- Requires manual key generation and installation on the server.
- Key must be rotated manually — no expiry mechanism.
- If the server is reprovisioned, the key must be re-installed.
- Adds a secret to manage outside of CI/CD.

#### 2. HTTPS + `secrets.GITHUB_TOKEN` (chosen)

Inject the GitHub Actions-provided `GITHUB_TOKEN` into the git remote URL as `https://x-access-token:${GITHUB_TOKEN}@github.com/...` before running `deploy.sh`.

**Pros**:
- Zero server-side key management. Token is generated fresh per workflow run.
- Token is short-lived (~1 hour), auto-scoped to the repository, and auto-revoked after the workflow completes.
- Works immediately on fresh/reprovisioned servers with no setup.
- No SSH infrastructure needed (no `known_hosts`, no key files, no agent).

**Cons**:
- Token is briefly present in the git remote URL on the server. Mitigated: `deploy.sh` could reset the remote URL after pull, though this is low-risk since the token expires quickly.
- Requires the SSM command to set the remote URL before `deploy.sh` runs (chicken-and-egg: if this logic were in `deploy.sh`, a broken `deploy.sh` couldn't deploy its own fix).

### Decision

**HTTPS with `GITHUB_TOKEN`**. The short-lived, auto-provisioned nature of the token eliminates key management entirely. The token injection is done in the `deploy.yml` SSM command (not in `deploy.sh`) to avoid the chicken-and-egg problem.

---

## Problem 2: SSM Command Timeout

`aws ssm wait command-executed` has a default timeout of ~2 minutes (120 seconds). A full Finlet deploy — git pull, pip install, migrations, service restart, health check — takes 3-6 minutes. The wait command would time out, the workflow step would fail, but the deploy would still be running on the server.

### Options Evaluated

#### 1. Increase `aws ssm wait` timeout (rejected)

`aws ssm wait` does not support a configurable timeout directly. The `--cli-read-timeout` and `--cli-connect-timeout` flags affect HTTP calls, not the polling duration. The waiter polls at fixed intervals with a fixed max attempts, and these are not configurable via CLI flags.

#### 2. Manual polling loop (chosen)

Replace `aws ssm wait` with a `for` loop that calls `aws ssm get-command-invocation` every 15 seconds, up to 40 iterations (10 minutes max). Check the `Status` field and break on terminal states (`Success`, `Failed`, `Cancelled`, `TimedOut`).

```bash
for i in $(seq 1 40); do
    CMD_STATUS=$(aws ssm get-command-invocation \
      --command-id "$COMMAND_ID" \
      --instance-id "$INSTANCE_ID" \
      --query "Status" --output text 2>/dev/null || echo "InProgress")
    if [ "$CMD_STATUS" = "Success" ]; then break; fi
    if [ "$CMD_STATUS" = "Failed" ] || [ "$CMD_STATUS" = "Cancelled" ] || [ "$CMD_STATUS" = "TimedOut" ]; then
      WAIT_FAILED=1; break
    fi
    sleep 15
done
```

**Pros**:
- Fully configurable timeout (interval x iterations).
- Can detect and handle specific failure modes (Failed vs TimedOut vs Cancelled).
- Uses a `WAIT_FAILED` flag to ensure SSM stdout/stderr is always retrieved before the step exits.

**Cons**:
- More verbose than a single `aws ssm wait` call.
- Slightly more API calls (one per poll iteration vs waiter's internal polling).

### Decision

**Manual polling loop with 15s intervals and 10-minute max**. The verbosity is worth the reliability. The `WAIT_FAILED` flag pattern ensures deploy errors always appear in CI logs.

---

## Implementation Summary

Changes in `deploy.yml` (SSM command, before `deploy.sh` runs):
- `export HOME=${HOME:-/root}` — ensure `$HOME` is set
- `git config --global --add safe.directory /opt/finlet` — allow root to operate on finlet-owned repo
- `mkdir -p /root/.ssh && ssh-keyscan github.com >> /root/.ssh/known_hosts` — trust GitHub SSH host key (kept as fallback)
- `git remote set-url origin https://x-access-token:${DEPLOY_TOKEN}@github.com/...` — HTTPS auth with GITHUB_TOKEN
- Replaced `aws ssm wait` with manual polling loop
- Added always-fetch pattern for SSM stdout/stderr

Changes in `deploy.sh`:
- `export HOME="${HOME:-/root}"` — same fix, defense-in-depth
- `git config --global --add safe.directory "$APP_DIR"` — same fix, defense-in-depth
- `mkdir -p "$HOME/.ssh" && ssh-keyscan github.com >> "$HOME/.ssh/known_hosts"` — SSH host key trust (fallback path)

The duplication between `deploy.yml` and `deploy.sh` is intentional: the workflow bootstraps the environment for the current deploy (solving the chicken-and-egg problem), and `deploy.sh` does the same for future manual invocations or cron-triggered deploys.
