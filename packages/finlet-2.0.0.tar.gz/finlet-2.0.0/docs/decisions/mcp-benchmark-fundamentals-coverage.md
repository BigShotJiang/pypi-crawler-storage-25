# Decision: MCP benchmark harness fix — price-only coverage, atomic rollback, benchmark-aware auto-resolve

Date: 2026-05-19
Status: shipped (MCP_BENCHMARK_HARNESS_FIX batch — Teams A/B/C)

## Context

GPT Codex (via MCP OAuth on finlet.dev) tried to run a benchmark and hit a
four-failure cascade that left the entire benchmark surface unusable plus an
orphan `benchmark_run` (`cade601d-2e1a-499f-b7f3-0079d5455905`) poisoning prod
state.

The triggering symptom was a misleading `data coverage insufficient for
requested start_time` error from `start_benchmark`. PR #109 (MCP_BENCHMARK_FIXES,
the structured-error envelope batch) is **innocent** — it did not introduce the
underlying bugs. Its structured envelopes are the only reason Codex could
diagnose them. The four failures pre-dated PR #109 and were latent behind
bare-string `{"error": "<string>"}` returns that swallowed every diagnostic
field. Reverting PR #109 would re-bury the bugs with a worse error shape; D5 in
the requirements document explicitly forbids it.

The four failures Codex hit, in cascade order:

1. `start_benchmark` returned `scenario_session_create_failed: data coverage
   insufficient for requested start_time` against the default universe
   (AAPL/MSFT/NVDA/AMZN/GOOGL/BTC-USD) and the first scenario `start_time`
   (2023-10-01). Real cause: `_validate_coverage` rejected on
   `earliest_fundamentals_date` (AAPL/MSFT/AMZN/GOOGL → 2024-09-30,
   NVDA → 2024-10-31); ALL 5 frozen scenarios pre-date the fundamentals window.
2. `get_benchmark_progress` returned scenario details with
   `session_id: null` because `create_benchmark_run` persisted at line 143 and
   `create_scenario_session` failed at line 298 — no rollback, leaked record.
3. Without `session_id`, MCP auto-resolution picked an unrelated stale
   2025-05-13 dev session in a `SPY/BND/GLD` universe.
4. `report_bug` failed with `NoSuchBucket` — `finlet-bug-reports` referenced in
   code but never provisioned.

This decision record covers the three **architectural** outcomes (D1, D2, D3).
The bucket provisioning (D4) is recorded as a deploy-time AWS infra change with
the follow-up lifecycle policy captured in `docs/REMAINING_TASKS.md`.

## Decision

### D1 — DELETE the fundamentals branch of `_validate_coverage`

The fundamentals coverage check is **wrong by design** and was removed outright
in `finlet/api/services/session_service.py`. Not deprecated, not made optional,
not flag-guarded. Deleted.

Fundamentals are point-in-time snapshots returned by yfinance. They have no
semantic notion of "start date." `earliest_fundamentals_date` from the S3
manifest is the earliest filing in the *current snapshot*, not a coverage claim
about historical reach. Validating `start_time >= earliest_fundamentals_date`
is comparing two different statements — "we have fundamentals data for ticker
X" vs. "we have fundamentals data **as of date Y** for ticker X."

Side effect: tickers with no fundamentals data at all still succeed at session
creation. Agents that call `get_fundamentals(ticker)` for those tickers get
empty results — which is the correct behavior given today's data lake and
already-handled by the date ceiling enforcer.

### D2 — Atomic rollback + orphan auto-cleanup

Two changes land together because the orphan cleanup pattern only earns its
keep with the rollback in place:

**Rollback (`finlet/mcp/tools_benchmark.py`):** wrap `create_scenario_session`
in try/except. On exception: call `delete_benchmark_run(run_id)` (in-memory +
SQLite) and return the structured error envelope unchanged. The just-persisted
`benchmark_run` record is removed atomically; the next `start_benchmark` call
no longer trips `benchmark_already_active` against a half-built run.

**Orphan auto-cleanup (`finlet/leaderboard/benchmark_state.py`):**
`get_active_run_for_user(user_id)` now skips and deletes any candidate run
where `status="running"` AND `current_session_id is None` AND
`created_at < now-60s`. The 60-second grace window allows a healthy
`start_benchmark` call to flip `current_session_id` (which happens within
milliseconds in the success path) without being clobbered by the cleanup
sweep. Any legitimately-young run mid-creation is safe.

This auto-recovers legacy orphans (including Codex's
`cade601d-2e1a-499f-b7f3-0079d5455905`) on the next `start_benchmark` call
post-deploy, without manual prod-DB intervention.

### D3 — Benchmark-aware `_default_session_id`

`finlet/mcp/auth.py::_default_session_id()` is the auto-resolve helper that
runs when an MCP tool caller omits `session_id`. Pre-fix behavior: walk the
caller's non-completed sessions and return whichever one happens to be there,
with an unhelpful `Multiple sessions active (N)` error when ambiguous.

New behavior: probe `get_active_run_for_user(user_id)` first. If it returns a
run with a valid `current_session_id` that resolves to a live session, prefer
that session. Otherwise fall back to the existing "exactly one
non-completed session" logic.

This closes a silent correctness bug: in a world where users have both a
benchmark session AND a dev session, the pre-fix auto-resolve picked one
arbitrarily and routed `submit_order` against the wrong portfolio.

## Rejected alternatives

**For D1** — keep the fundamentals check behind a feature flag.
Rejected because the check is semantically nonsense, not buggy. Flag-guarding
preserves the wrong invariant in the codebase and risks re-enabling it on a
future regression.

**For D1** — backfill historical fundamentals so the check passes.
Rejected as a *blocker* — captured separately in REMAINING_TASKS. Real
point-in-time fundamentals for pre-2024 scenarios needs SEC EDGAR ingestion
that scrubs yfinance's "current snapshot" mode. Multi-week effort. The check
is still wrong-by-design even with backfilled data — fixing the data without
fixing the check ships the same broken check behind a moving target.

**For D2** — reorder `create_benchmark_run` to run AFTER
`create_scenario_session`. Rejected because the scenario session needs
`run.id` to attach to. Constructing the run lazily would require threading the
run_id through every caller. Try/except + explicit delete is the smaller blast
radius.

**For D2** — add an `abandon_benchmark` MCP tool so callers manually clean up
their own orphans. Rejected as unnecessary — the 60-second orphan auto-cleanup
covers every observed failure mode without any agent-side cooperation. The
tool is captured as a deferred follow-up if a user actually asks for explicit
control.

**For D3** — make auto-resolve strict (always require explicit `session_id`).
Rejected because REST and CLI callers also depend on auto-resolve. Too
disruptive for a pre-launch fix. The benchmark-first preference is the
smallest behavior change that closes the wrong-portfolio bug.

## Consequences

- Pre-launch (zero MCP-OAuth paying users today) — no deprecation window
  needed for the `_validate_coverage` shape change. The fundamentals failure
  case is gone entirely; tests that previously asserted it have been removed
  per the requirements doc.
- `delete_benchmark_run(run_id)` is new public surface on `benchmark_state` and
  is the canonical rollback mechanism for any future operation that persists a
  benchmark run before constructing dependent state.
- Auto-resolve now silently prefers the active benchmark session over an
  unrelated dev session. Explicit `session_id=...` always wins — this only
  fires when the caller omits the parameter.
- Codex's orphan `cade601d-2e1a-499f-b7f3-0079d5455905` self-cleans on the
  first `start_benchmark` call after deploy.

## References

- Innocent (cleared) PR: #109 (MCP_BENCHMARK_FIXES structured error envelopes
  — its envelopes surfaced the bugs)
- Sibling decision record: `docs/decisions/2026-05-19-mcp-structured-error-envelope.md`
- Code: `finlet/api/services/session_service.py` (D1),
  `finlet/mcp/tools_benchmark.py` + `finlet/leaderboard/benchmark_state.py` (D2),
  `finlet/mcp/auth.py` (D3)
- AWS infra (D4): `finlet-bug-reports` bucket in `us-east-1` with
  AES256 encryption + public-access block. Lifecycle policy deferred —
  see `docs/REMAINING_TASKS.md`.
- Universe inconsistency (D6 in requirements): BTC-USD in `_DEFAULT_UNIVERSE`
  vs. excluded from canonical universe loader — also deferred to
  `docs/REMAINING_TASKS.md`.
