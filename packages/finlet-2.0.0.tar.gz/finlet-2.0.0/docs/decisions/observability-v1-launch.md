# Decision: Observability for v1.0.0 — Sentry YES

**Date:** 2026-05-10
**Status:** Accepted
**Source:** Launch v1.0.0 execution plan (Gate 4 / Team D)

## Decision

**YES — wire Sentry SDK in v1.0.0.** Free-tier coverage easily fits anticipated launch traffic, integration is ~30 lines, and the alternative (CloudWatch-only error visibility) blinds us to in-production stack traces during the highest-risk window of the project's lifetime.

## Context

At HEAD `d8e13dd`, error visibility on the production API surface is structlog → stdout → CloudWatch logs, plus the existing `_http_exception_handler` / `_validation_exception_handler` envelope wrappers in `finlet/api/app.py:316-347`. There is no centralized error tracker — every uncaught exception lands as a `request_completed status=500` line in CloudWatch with no stack trace, no breadcrumbs, no aggregation, no alerting.

The CSP allowlist in `finlet/api/security_middleware.py:218,222` already permits `https://browser.sentry-cdn.com` (script-src) and `https://*.ingest.sentry.io` (connect-src). Sentry was anticipated by an earlier session but never wired. v1.0.0 launch is the right window to close the gap.

What we accept by deferring (the "no" path):
- No 5xx aggregation. CloudWatch's structured-log query language can count `status=500` events but cannot group them by exception class, file:line, or release tag.
- No breadcrumbs. When the `submit_order` MCP tool fails, we see the final stack trace (if logged) but not the chain of HTTP calls / DB queries / plugin probes that preceded it.
- No release-pinned regressions. CloudWatch has no concept of "this regressed in v1.0.0 vs v0.9.5"; we'd rebuild that pivot manually from log timestamps.
- No alerting tier free-of-charge. CloudWatch Alarms on log-metric filters cost ~$0.10/alarm/month and require the operator to know which patterns to alarm on in advance.

The "we'll catch errors via CloudWatch alarms within 5 min of an alarm firing" claim is technically real but operationally weak — it requires alarms to be pre-defined for every error pattern we want to catch, and pre-launch we don't know which patterns will matter.

## Cost analysis

Sentry free tier ceilings (as of 2026-05):

| Resource | Free tier | v1.0.0 estimate | Headroom |
|----------|-----------|-----------------|----------|
| Errors | 5,000 events/mo | ≤100 users × ≤10 errors/mo = 1,000 events | 5x |
| Performance | 10,000 traces/mo | 0 (disabled — `traces_sample_rate=0.0`) | n/a |
| Replay sessions | 50/mo | 0 (no front-end replay this phase) | n/a |
| Cron monitors | 1 monitor | 0 | n/a |
| Retention | 30 days | sufficient for launch hardening | n/a |
| Members | unlimited | 1 (founder) | unlimited |

If we exceed the free tier, the next paid tier is the **Team plan at $26/mo for 50,000 events** — a 50x quota bump for ~$300/year. Even that is well under what a single-incident debugging session is worth. This is not a budget conversation; the free tier is fine.

Note: `traces_sample_rate=0.0` is deliberate. Performance monitoring is event-only on the free tier and would burn the same 5k/mo bucket on transaction events that are not as actionable as error events at v1.0.0 scale.

## Wiring complexity

Total: **3 files modified, 1 new test file, ~30 lines of code change**.

1. `pyproject.toml` — add `sentry-sdk[fastapi]>=2.0.0` to the `server` extra. The `[fastapi]` extra pulls in starlette + httpx auto-instrumentation, which means every FastAPI route handler and every outbound httpx call is automatically traced as a breadcrumb without per-route plumbing.
2. `finlet/api/app.py` — `sentry_sdk.init(...)` at the top of `create_app()`, gated on `SENTRY_DSN` env var being non-empty. No-op when DSN is absent (e.g., dev / CI / forks).
3. `finlet/api/middleware.py` — extend `CorrelationIDMiddleware.dispatch` to call `sentry_sdk.set_tag("request_id", request_id)` so Sentry events are filterable by the same correlation ID that structlog and CloudWatch already use. ~3 lines.
4. `tests/api/test_sentry_init.py` — new test file. Verifies (a) no DSN → no init call, (b) DSN set → init called with expected kwargs, (c) bad DSN doesn't raise during init (Sentry tolerates this internally — we just assert no traceback escapes our wrapper).

`sentry-sdk[fastapi]` provides:
- ASGIIntegration — auto-captures every unhandled exception in route handlers and middleware.
- StarletteIntegration — same for Starlette-level errors (CORS, middleware exceptions).
- HttpxIntegration — auto-traces outbound httpx calls (every plugin probe becomes a breadcrumb).
- LoggingIntegration — captures structlog `error` and `exception` calls as Sentry events.

We do NOT need to write custom integration code for any of these.

## PII redaction plan

**Non-negotiable.** PII redaction is implemented via the `before_send` hook on `sentry_sdk.init`. The hook receives every event before it leaves the process and returns either the (possibly mutated) event or `None` to drop it.

Strip list:
1. **`Authorization` header** — drop entirely. Never let a Bearer JWT or API key reach Sentry. Implemented by `del event.get("request", {}).get("headers", {})["Authorization"]` (case-insensitive scan).
2. **`Cookie` header** — drop entirely. Session cookies are equivalent to Bearer tokens for cookie-auth surface.
3. **`X-CSRF-Token` header** — drop. Less sensitive than Auth, but no reason to ship it.
4. **Request body on auth routes** — drop entirely if `request.url.path` matches any of:
   - `/v1/auth/*`
   - `/auth/*`
   - `/v1/billing/webhook` (signed payload — could leak Stripe customer data)
   - `/v1/billing/*`
   These routes can carry plaintext passwords (sign-in), recovery tokens, MFA codes, or Stripe customer IDs.
5. **Email addresses in breadcrumbs** — scrub `email` query params, JSON body fields, and form data. The hook walks `event["breadcrumbs"]` and replaces any value matching the regex `r"\S+@\S+\.\S+"` with `"[email-redacted]"`.
6. **`api_key`-shaped values** — any string starting with `flx_`, `sk-ant-oat`, or matching the JWT format `eyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+` is replaced with `"[token-redacted]"`. Catches stray API keys / OAuth bearer tokens / DCR registration tokens that might land in error context.
7. **`user.email` in user context** — set Sentry's `send_default_pii=False` so the SDK does not auto-attach the request's IP / cookies / user-context email by default.

The test file (`tests/api/test_sentry_init.py`) includes a `before_send` regression test that constructs a fake Sentry event with a known PII payload and asserts every item above is stripped.

`/health` is NOT excluded from event capture, but ASGIIntegration only sends events on **errors**, and `/health` should never error. If it does, that's a real incident and we want to see it.

## Recommendation + rationale

**Ship it.** The cost analysis is dominated by free-tier headroom (5x on the most-binding limit), the wiring is ~30 lines on a path with zero coupling to existing surfaces (gated on env var → no DSN, no init), and the asymmetry between "we have errors visible in real time on day 1" vs "we discover the 5xx pattern by reading CloudWatch logs three days later" is the difference between recovering from an incident in minutes vs hours.

The pre-launch / no-customers state from `project_pre_launch_no_customers.md` arguably loosens this — there are no users to embarrass — but the same property makes Sentry more valuable, not less: every error in the first 30 days is a free signal about which paths are fragile under real-world (not test) conditions. CloudWatch can give us that signal too, but only if we know in advance which patterns to filter on. Sentry shows us patterns we didn't know to look for.

The concrete failure mode this prevents: at v1.0.0 launch, a single regression in an MCP tool (e.g., `submit_order` raising on a malformed limit price) raises a stack trace in CloudWatch with no aggregation and no breadcrumb context. With Sentry: the same incident creates one event grouped by the exception class, with breadcrumbs showing the chain `request_started → plugin probe → DB write → exception`, plus the `request_id` tag for correlation with structlog output. The first surface lets us debug in minutes; the second forces us to grep through CloudWatch logs reverse-chronologically.

## Fallback if no

Not applicable — decision is YES. The fallback path is documented for completeness in case the SDK ever needs to be removed:

- CloudWatch log group: `/finlet/prod/api` (defined in `deploy/RUNBOOK.md`).
- structlog ERROR-level retained as the primary log surface (no behavior change — Sentry layers on top of structlog, not in place of it).
- Manual alarms via CloudWatch Metric Filter (filter pattern: `{ $.level = "error" }`) → SNS topic → email or Discord webhook.
- Sentry deferred to v1.1 (next minor cut) if removal becomes necessary.

## Implementation if yes

**Files modified:**
- `pyproject.toml` — adds `"sentry-sdk[fastapi]>=2.0.0"` to the `server` extra (one line in the dependency list).
- `finlet/api/app.py` — adds `_init_sentry()` helper invoked from `create_app()` at top, before any middleware registration. Reads `SENTRY_DSN` from env (no SSM call required — DSN is non-secret enough to be set as a plain env var on the EC2 instance, and SSM is hit indirectly via the deploy.yml env-injection step at `/finlet/prod/SENTRY_DSN`). No-op when DSN is empty / unset. Wired with: `traces_sample_rate=0.0`, `send_default_pii=False`, `environment=os.getenv("FINLET_ENV", "development")`, `release=<pyproject version>`, `before_send=_sentry_before_send`.
- `finlet/api/middleware.py` — `CorrelationIDMiddleware.dispatch` is extended to call `sentry_sdk.set_tag("request_id", request_id)` once per request after the contextvars binding. Only fires when Sentry is initialized (`sentry_sdk.Hub.current.client` is non-None); otherwise no-op.

**Test file created:**
- `tests/api/test_sentry_init.py` — covers:
  - `test_no_dsn_means_no_init` — `SENTRY_DSN` unset → `sentry_sdk.init` is NOT called.
  - `test_empty_dsn_means_no_init` — `SENTRY_DSN=""` → same.
  - `test_init_called_when_dsn_set` — `SENTRY_DSN=https://k@o.ingest.sentry.io/1` → `sentry_sdk.init` called once with expected kwargs.
  - `test_bad_dsn_does_not_raise` — `SENTRY_DSN="not-a-url"` → no traceback escapes `_init_sentry`.
  - `test_before_send_strips_authorization_header` — fake event with `Authorization: Bearer xxx` → header is removed.
  - `test_before_send_strips_cookie_header` — fake event with `Cookie: session=...` → header is removed.
  - `test_before_send_strips_auth_route_body` — fake event for `/v1/auth/sign-in` with a body → body is replaced with `"[redacted]"`.
  - `test_before_send_strips_jwt_in_breadcrumb` — fake event with a JWT-shaped string in a breadcrumb message → string is replaced with `"[token-redacted]"`.
  - `test_before_send_strips_email_in_breadcrumb` — fake event with `user@example.com` in breadcrumb data → replaced with `"[email-redacted]"`.

## Cross-references

- `finlet/api/security_middleware.py:218,222` — CSP allowlist for Sentry already in place.
- `finlet/api/middleware.py:CorrelationIDMiddleware` — correlation ID surface that gets a `request_id` tag.
- `docs/decisions/cli-mcp-stdio-auth.md` — established decision-record format used as the template here.
- `project_pre_launch_no_customers.md` (memory) — pre-launch posture that loosens reversibility constraints but does not change this decision.
