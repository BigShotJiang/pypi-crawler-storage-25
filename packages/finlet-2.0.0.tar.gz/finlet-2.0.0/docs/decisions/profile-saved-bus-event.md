# Decision: `profile:saved` Bus Event — Wizard-Advance vs Outcome-Event Split

**Date**: 2026-05-01
**Status**: Accepted
**Iteration**: bug-hunt 20260501T234103Z1a49 (Team D, merge `4924948`)

---

## Context

Bug-hunt iteration `20260501T234103Z1a49` flagged the onboarding "Set up profile" checklist row as broken: the row checked itself complete the moment the user picked an onboarding persona ("Retail Investor") in the wizard's Step 1 — but Settings > Profile still showed empty Display Name and Bio fields. The checklist UI claimed "✓ Set up profile" while the persisted profile state contradicted it.

This was the fifth recurrence of the onboarding-checklist shape. The 2026-04-30 registry refactor (commit `40368b2`, plan `docs/refactor/onboarding-checklist/plan.md`) closed three prior trigger gaps via the `CHECKLIST_STEPS` registry — but the `profile` step's trigger remained `null` because no `profile:saved` bus event existed. To preserve the documented affordance, the wizard's `handleNext()` reached in to `markStepComplete('profile')` on Step 1 advance.

That short-cut was the bug. Step 1 advance is a navigation event ("the user picked a persona and clicked Continue"); the checklist row's intent is an outcome event ("the user saved a profile in Settings > Profile"). Conflating the two created user-visible state divergence:

| User action | What the wizard did | What the checklist showed | What the persisted state was |
|---|---|---|---|
| Pick persona, click Continue | Advance to Step 2; mark `profile` complete | "✓ Set up profile" | Display Name = "", Bio = "" |
| Save real Display Name + Bio in Settings > Profile | (no checklist transition — already marked) | "✓ Set up profile" | Display Name = "<X>", Bio = "<Y>" |

A user could complete the wizard and never visit Settings; the checklist would say they were done. A user who DID save their profile got no UI feedback because the checklist had already pre-marked them.

---

## Decision

Introduce a new `profile:saved` bus event published from `dashboard/settings.js#saveProfile` AFTER a successful `PUT /v1/settings/profile`, gated on both `display_name` AND `bio` being non-empty. Change `CHECKLIST_STEPS[0].trigger` from `null` to `'profile:saved'` so the registry-driven subscriber owns the transition. Remove the `markStepComplete('profile')` reach-in from the wizard's `handleNext()`.

### Event surface

```js
// dashboard/event-contract.md
//
// profile:saved
//
// The user saved their Profile in Settings > Profile with non-empty
// Display Name AND non-empty Bio. The onboarding `Set up profile`
// checklist step subscribes to this event so the row flips to complete
// only after a real Profile save — NOT on persona pick in the
// onboarding wizard.
//
// Payload: { display_name: string, bio: string }
// Publisher: dashboard/settings.js#saveProfile (gated on both fields non-empty)
// Subscribers: dashboard/onboarding.js (CHECKLIST_STEPS registry-driven)
```

### Publisher (settings.js)

```js
async function saveProfile() {
    const display_name = document.getElementById('profile-name').value.trim();
    const bio = document.getElementById('profile-bio').value.trim();
    // ... PUT /v1/settings/profile, toast on success ...
    if (display_name && bio) {
        window.finletBus.publish('profile:saved', { display_name, bio });
    }
}
```

### Subscriber (onboarding.js)

The registry already drives subscribers — no per-row wiring change needed. `CHECKLIST_STEPS[0].trigger = 'profile:saved'` is the single line that hooks the bus.

```js
const CHECKLIST_STEPS = [
    {
        key: 'profile',
        label: 'Set up profile',
        trigger: 'profile:saved',  // was: null
        action: { type: 'noop' },
    },
    // ...
];
```

### Wizard handleNext

Removed the `markStepComplete('profile')` reach-in for `currentStep === 1`. The wizard still advances to Step 2 via `showStep(2)`; the checklist row only flips when the user later saves a real Profile.

---

## Why gate the publish on both fields non-empty

The triage retest (`triage.json items[5].retest.assertions[1]`) requires that selecting a persona alone does NOT mark profile complete; only a real Profile save with non-empty Display Name AND non-empty Bio does. The publisher gate enforces this contract at the source — the consumer doesn't need its own validation.

If a user saves Profile with only Display Name filled (Bio empty), no event fires; the checklist row stays unchecked. This matches the "Set up profile" affordance's documented intent: profile setup means *both* fields, not just one.

---

## Trade-offs

### What we gained

- Outcome state and UI state agree. The checklist no longer lies about persisted profile state.
- The wizard advance and the checklist completion are now distinct events with distinct triggers — navigation does not imply outcome.
- The `profile:saved` event is reusable: any future surface that wants to react to profile save (analytics, MFA prompts, persona refinement) can subscribe via the bus.
- The registry refactor's promise is upheld: adding/changing a checklist trigger is one line, not three.

### What we accepted

- Adds a new bus event (`profile:saved`) — the cache + subscriber overhead are negligible.
- A user who picks a persona and never saves a profile will see "0/4" on the checklist forever. This is the correct behavior, not a regression — they haven't done what the affordance promises.
- One more publisher to audit on each refactor pass. Mitigated by the gate-on-both-fields rule (single publish site, easy to grep).

### Alternatives considered and rejected

- **Subscribe to a generic `settings:saved` event with a `section` field.** Rejected: less explicit, harder to grep, harder for new contributors to discover the contract. A dedicated event per outcome is cheaper than a polymorphic one.
- **Add an outcome publisher for every existing checklist step in the same commit.** Rejected: scope creep. The other steps already have working triggers (`session:switched`, `order:filled`); only `profile` needed an outcome publisher this iteration.
- **Mark the row complete on Step 1 advance AND require a Settings save to "really" mark it.** Rejected: introduces a second piece of state ("preliminary mark" vs "real mark") that the registry pattern doesn't model. Cheaper to have one truth.

---

## Reversal path

Single SHA revert removes the `profile:saved` event from `event-contract.md`, restores `CHECKLIST_STEPS[0].trigger = null`, restores the `markStepComplete('profile')` call in `handleNext()`, and removes the publisher from `settings.js#saveProfile`. The unit tests in `tests/dashboard/onboarding-checklist.spec.js` would also revert. ~10 minutes total.

If the ledger surfaces a recurrence on the same shape (checklist marks an outcome on a navigation event), the next iteration's refactor pass should consider folding all CHECKLIST_STEPS triggers into a "wizard navigation triggers are forbidden" lint check on `dashboard/onboarding.js`.

---

## References

- Refactor commit: `4924948` (Team D merge, bug-hunt 20260501T234103Z1a49)
- `dashboard/onboarding.js` — `CHECKLIST_STEPS[0]` trigger change + `handleNext()` cleanup
- `dashboard/settings.js` — `saveProfile()` publisher with non-empty gate
- `dashboard/event-contract.md` — new `profile:saved` event documentation
- `tests/dashboard/onboarding-checklist.spec.js` — unit coverage for both negative (persona-only) and positive (settings-save) paths
- Related decision: `docs/decisions/onboarding-checklist-step-contract.md` — the registry refactor that this iteration extends
- Related lesson in `docs/LESSONS.md`: "Wizard-step advance ≠ outcome event"
