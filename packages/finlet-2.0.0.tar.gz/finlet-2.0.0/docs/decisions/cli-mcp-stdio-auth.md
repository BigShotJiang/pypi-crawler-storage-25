# Decision: CLI → MCP-over-stdio Auth via `FINLET_OAUTH_BEARER` Env Var

> **SUPERSEDED 2026-05-11** — replaced by [`cli-mcp-http-dispatch.md`](./cli-mcp-http-dispatch.md) (v1.0.1 hotfix). The v1.0.0 blind-walk showed that the cloud-issued OAuth JWT (and the legacy `--api-key`) cannot be validated by a locally-spawned `finlet mcp serve` subprocess — the subprocess hosts a fresh JWKS that doesn't know the cloud signing keys, and `auth_service._keys` is empty without a remote bootstrap. The CLI moved to cloud `/mcp` over HTTP for v1.0.1, then v2.0.0 deleted human-facing CLI tool dispatch entirely.
>
> **v2 note (2026-05-23):** this record's `FINLET_OAUTH_BEARER` env fallthrough is no longer current even for stdio. Default `finlet mcp serve` is a stdio bridge to hosted `/mcp` that reads `~/.finlet/credentials` or `FINLET_API_KEY` directly and sends an Authorization header. `finlet mcp serve --self-host` uses an in-process credential handoff; `finlet/mcp/bearer_context.py:resolve_credential` does not read process env.

**Date:** 2026-05-09
**Status:** Superseded 2026-05-11
**Source:** MCP-First Migration Phase 5 (Team F1).

## Context

Phase 4e (`docs/decisions/mcp-api-key-sunset.md` Retraction 2026-05-09) closed the 90-day api_key dual-accept window on the MCP tool surface. Every authenticated MCP tool now resolves identity through `finlet/mcp/bearer_context.py:resolve_credential`, which reads a per-request Bearer JWT from a ContextVar populated (on the HTTP transport) by `BearerContextMiddleware`.

Phase 5 rewires the Finlet CLI to call MCP tools via a spawned `finlet mcp serve` subprocess (stdio transport) instead of HTTP-ing to REST. The stdio transport carries no Authorization header — there is no ASGI middleware to populate the Bearer ContextVar. The CLI is the only consumer that knows the user's OAuth credentials (it loads them from `~/.finlet/credentials` per `docs/decisions/auth-login-cli-vs-api-key.md` Phase 4d Addendum). Phase 5 has to forward that JWT into the spawned subprocess in a way that:

1. Preserves the locked Phase 4e Bearer-only contract (no api_key parameter on tool calls; no new auth path on the MCP tool surface).
2. Does NOT change `finlet/mcp/auth.py` or any of `tools_*.py` (locked surfaces).
3. Is testable in pytest without depending on a real shell or terminal.

## Decision

**Pass the Bearer JWT to the spawned `finlet mcp serve` subprocess via the `FINLET_OAUTH_BEARER` environment variable.** The subprocess reads the env at boot and forwards it into `finlet/mcp/bearer_context.py:resolve_credential` as the bearer credential whenever the per-request ContextVar yields `None` (the stdio case).

The CLI builds the subprocess env in `finlet/cli_mcp_client.py:_build_subprocess_env(bearer_token)`:

* When `bearer_token` is non-empty, sets `FINLET_OAUTH_BEARER=<token>` on the subprocess env.
* When `bearer_token` is `None` or empty, **strips** any pre-existing `FINLET_OAUTH_BEARER` from the inherited parent env. This defends against a parent process accidentally holding a stale token: the CLI's resolved-None decision wins.

`bearer_context.py:resolve_credential` adds a strictly-additive fallthrough: if the per-request ContextVar yields `None` AND `os.environ.get("FINLET_OAUTH_BEARER")` is non-empty, the env value is treated as the Bearer JWT and runs through the existing `_authenticate_oauth_or_key` validator. **HTTP requests still take the ContextVar path first** — an env var accidentally set on a server process does NOT bypass per-request auth.

`finlet/cli.py:mcp_serve` (the renamed `finlet mcp serve` entry point) hydrates `auth_service._keys` via `auth_service.load_all()` BEFORE the FastMCP runloop starts. The auth-service cache is the source of truth `_authenticate_oauth_or_key` consults to map a JWT `sub` claim to a `UserRecord`; without it, `get_by_id` would always miss in this fresh-process subprocess and the tool would return the documented "Authentication required" envelope on every call.

## Rationale

### Why env-var passthrough (not argv, stdin, or config-file)?

* **Argv leaks to `ps`.** Every other process on the box can see the Bearer JWT via `ps auxw` or `/proc/<pid>/cmdline`. Operationally fatal for a production CLI.
* **Stdin would break the JSON-RPC protocol.** MCP stdio transport uses stdin/stdout for the JSON-RPC framed message stream. We could in principle define a "auth handshake before stream starts" but that's a custom protocol on top of the standard one — every MCP tool would need to know it.
* **Config-file injection re-creates the api_key file-mode-drift hazard.** `~/.finlet/credentials` is mode 0600 enforced; a per-spawn temp credential file would have to either redo the same enforcement (extra surface) or risk leaking the Bearer to a less-protected location.
* **Env var inherits shell secret-handling discipline.** Anyone who has ever `export GITHUB_TOKEN=...` knows what env-var-as-secret feels like. Tooling around `direnv` / 1Password CLI / Doppler all already understand this idiom. The MCP SDK's `StdioServerParameters.env` field is purpose-built for it.
* **Smallest testable surface.** A unit test patches one env var; an integration test asserts the subprocess sees the right value. No shell, no temp file, no fork-and-read dance.

### Why is the env-var read additive in `resolve_credential`?

The HTTP middleware path (`BearerContextMiddleware`) is the production auth surface for any HTTP-mounted MCP transport (e.g., the streamable_http transport per the master-plan Phase 4 architecture). Reading from the env var in the resolver could in principle let a server process accidentally inheriting `FINLET_OAUTH_BEARER` bypass per-request auth.

The mitigation: **the env var is consulted ONLY when the ContextVar is empty.** HTTP requests' `BearerContextMiddleware` always sets the ContextVar (to either the Bearer token or `None` for unauthenticated requests). The fallthrough never engages on the HTTP path. The env-var read fires exclusively on the stdio path, which has no ContextVar populator.

### Why hydrate `auth_service._keys` in `mcp_serve`, not in the resolver?

The resolver's job is to validate the JWT and resolve the `sub` claim. Loading every user's API-key record into memory would bloat the resolver's responsibilities and re-introduce the dual-write hazard the Phase 4a decision record §4 (same-`UserRecord` binding) rejected.

The cleaner shape: the auth-service cache is a process-level concern, owned by whichever subsystem boots the process. The FastAPI app boots it via the lifespan handler. The CLI's `finlet mcp serve` command IS that subsystem for stdio, so it owns the bootstrap call.

### Why spawn-per-command, not a persistent daemon?

* **Spawn-per-command is the simplest auth model.** Every command's auth state is scoped to its lifetime; no shared-daemon state to invalidate when the user runs `finlet auth logout`.
* **~200-500ms FastMCP boot tax per command is acceptable for v1.** The CLI is operator-facing, not request-rate-sensitive. A user typing `finlet session list` doesn't notice 300ms of boot time.
* **A persistent daemon would re-introduce a bunch of orthogonal concerns** (process supervisor, socket activation, cache invalidation on `auth login`, multi-tenant isolation if the user has multiple Finlet accounts on one machine). Each of those is its own decision; bundling them with Phase 5 inflates the migration's blast radius.

Future optimization: a persistent daemon mode (`finlet mcp serve --persistent`) would multiplex tool calls over a long-lived stdio session. Out of scope for Phase 5.

### Why `python -m finlet mcp serve`, not the `finlet` console script?

The wrapper invokes `sys.executable -m finlet mcp serve` rather than the `finlet` console script so the parent's Python interpreter (and therefore the parent's installed packages) is reused. No PATH-resolution races, no venv-mismatch surprises (e.g., user has `finlet` from a different venv on PATH while the CLI is running from the editable install).

## Alternatives Considered

1. **`--bearer-token <jwt>` CLI flag on `finlet mcp serve`.** Rejected — argv leaks to `ps`. Operationally fatal.
2. **`finlet mcp serve --auth-fd N` reading the JWT from a passed file descriptor.** Considered. Cross-platform fd inheritance is fiddly (Windows in particular). Env vars are universal; fd passing is a sharper tool than this problem needs.
3. **Subprocess reads `~/.finlet/credentials` directly.** Rejected — duplicates the credential-loading logic across two processes, doubles the risk of mode-drift bugs, and ties the MCP server to a specific credential layout (which would block hosted deployments where the server runs in a different user's home). The subprocess gets ONLY the resolved Bearer JWT; it never sees `~/.finlet/credentials`.
4. **A handshake message at the start of the stdio stream.** Rejected — invents a Finlet-specific MCP extension. The MCP SDK's existing `StdioServerParameters.env` field is the standard way to forward credentials.
5. **Convert `auth_service.get_by_id` to a fresh DB read every call (avoiding the cache-miss subprocess problem).** Rejected — perf regression on hot paths in the FastAPI app where the cache is the steady-state read path. Bootstrap-on-boot is the correct fix.

## Consequences

### Positive
* The CLI's MCP dispatch path is unit-testable without a real subprocess (mock `call_tool_sync`), without a real shell (env via `_build_subprocess_env`), and end-to-end testable with a real spawned subprocess (`tests/integration/test_cli_stdio_e2e.py`).
* `finlet auth login` → `finlet session list` → `finlet auth logout` works on a fresh install with no manual env-var management. Credential precedence (`--api-key` flag > env > `~/.finlet/credentials`) collapses to a single Bearer JWT before subprocess spawn.
* The HTTP MCP surface continues to work with no behavior change. The env-var fallthrough is on the stdio path only.

### Negative
* `FINLET_OAUTH_BEARER` is a new public env-var name. Any user who already has that set in their shell (unlikely) would have it overridden by the CLI's resolved token. The wrapper's `_build_subprocess_env` documents this overwrite behavior.
* The subprocess pays the auth.db migration cost on every command (`auth_service.load_all()` runs `create_auth_db()` which is idempotent but does a SQLite open). Negligible — single-digit ms — but it's a real cost.
* `time_in_force=DAY` is silently dropped on the MCP `submit_order` path because the MCP tool doesn't expose it. The CLI flag is preserved for ergonomic stability; future work should either extend the MCP tool's signature or document the constraint more loudly. Tracked under Phase 5 polish.

### Locked surfaces preserved
* `finlet/mcp/auth.py` unchanged.
* `finlet/mcp/server.py`, `finlet/mcp/_instance.py`, `finlet/mcp/tools_*.py` unchanged.
* `finlet/api/*` unchanged — REST surface continues to work identically.
* The 4 KEEP CLI commands (`serve`, `register`, `auth login`, `auth logout`) are bit-identical to pre-Phase-5.

### Plugins commands stay on REST
`finlet plugins list/add/remove` continue to call `/v1/plugins/health` and `/v1/settings/plugins` directly. Plugin management is operator/dashboard surface, not the agentic-trading surface the MCP tools expose; there are no MCP tools for tenant plugin-credential writes, and Phase 5 explicitly does not add any. If a future phase ships admin MCP tools, the plugins commands can move alongside.

## Cross-references

* `docs/decisions/mcp-oauth-2-1-auth-model.md` — Phase 4a, locks the OAuth 2.1 + DCR + Resource Indicators auth model the JWTs forwarded by `FINLET_OAUTH_BEARER` are minted under.
* `docs/decisions/mcp-api-key-sunset.md` (Retraction 2026-05-09) — Phase 4e closed the dual-accept window; this record assumes Bearer-only on the MCP tool surface.
* `docs/decisions/auth-login-cli-vs-api-key.md` (Phase 4d Addendum 2026-05-09) — locks the `~/.finlet/credentials` mode-0600 contract Phase 5's `_resolve_bearer_token` reads through.
