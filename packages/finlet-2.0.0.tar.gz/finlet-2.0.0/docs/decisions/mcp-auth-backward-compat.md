# Decision: MCP Auth with Backward-Compatible Optional API Key

**Date:** 2026-03-28
**Status:** Superseded by `mcp-auth-mandatory.md` (2026-03-30)

## Context

The MCP server had zero authentication — `user_id="mcp"` was hardcoded for all session creation, and `_get_session()` did raw dict lookup with no ownership check. Any connected MCP client could access, modify, or delete any session.

## Decision

All 14 MCP tools now accept an **optional** `api_key` parameter:

- **When provided:** The key is validated via `auth_service.validate_key()`. The tool operates under the authenticated user's `user_id`. `list_sessions` filters by that user. `_get_session()` enforces ownership.
- **When omitted:** Falls back to `user_id="mcp"` sentinel. This preserves the existing stdio trust model for local single-user development.

A shared `_authenticate(api_key)` helper centralizes the validation logic across all tools.

## Alternatives Considered

1. **Mandatory auth on all tools** — Would break all existing MCP client configurations. Rejected because backward compatibility matters for a tool aimed at AI agents that have saved MCP configs.
2. **Transport-level auth (e.g., mTLS, token in headers)** — FastMCP's stdio transport doesn't support custom headers. Would require a custom transport or switching to HTTP/SSE transport. Deferred for when remote multi-user MCP deployments are needed.
3. **Per-connection auth via init message** — FastMCP doesn't expose a connection-level auth hook. Would require forking or wrapping the transport layer.

## Consequences

- Existing single-user local setups continue to work with no changes
- Multi-user or remote deployments can enforce auth by requiring `api_key` on all calls
- Session ownership is enforced when authenticated — users cannot access other users' sessions
- The "mcp" sentinel user's sessions are isolated from authenticated users' sessions
- 26 tests cover the auth matrix (valid key, invalid key, no key, ownership enforcement)
