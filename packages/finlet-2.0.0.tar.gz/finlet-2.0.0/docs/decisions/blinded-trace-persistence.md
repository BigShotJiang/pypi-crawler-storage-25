# Decision: Blinded Trace Persistence — Write-Time Blinding (Not Read-Time-Only)

**Date**: 2026-05-20
**Status**: Accepted (shipped via blind-export benchmark redesign exec-plan)
**Related**:
- `docs/decisions/blind-benchmark-architecture.md` (parent — V1 architecture)
- `docs/decisions/blind-benchmark-envelope-fields-must-blind.md` (sibling — boundary contract for blind transforms)
- `docs/decisions/benchmark-run-decrypt-publish-gate.md` (sibling — owner-driven lifecycle)
- `docs/decisions/blind-mapping-serializer-poison.md` (sibling — runtime backstop for the mapping object)

---

## Context

Blind Benchmark V1 (`docs/decisions/blind-benchmark-architecture.md`) shipped a service-layer transform model: plugins emit real-shape data, the service layer (`finlet/api/services/market_service.py::_apply_blind_transform`) rewrites items + envelope to opaque `T_NNNN` / `Day_N` shapes before serialization. The transform applied at read time — every response to the agent was blinded as it left the boundary.

The reasoning trace (`Session.trace`) is the per-session ledger of every MCP tool call: `request_params`, `response_summary`, `sim_time` (the simulation clock at call time), `real_time` (wall-clock-now at call time), `action_type` (e.g., `query`, `order`, `clock`). Each entry is persisted to the per-session SQLite via `finlet/db/persistence.py:save_trace_entry`. The trace serves three audiences:

| Reader | Surface | Was real shape? | Should see |
|---|---|---|---|
| Agent under evaluation | MCP `get_trace` | Yes (Codex bug `50abd05e` — closed 2026-05-20) | Blinded |
| Session owner (authenticated) | REST `GET /sessions/{id}/trace` + dashboard | Yes — recon found this leak | Real (or blinded if owner-on-blind) |
| Anonymous public viewer | `/v1/public/sessions/{id}/trace` | Was blinded via Team D V1 serializers | Blinded |
| SSE owner-auth | `/sessions/{id}/stream` `trace` event | Yes — recon found this leak | Real (or blinded if owner-on-blind) |

V1 took a **read-time-only blinding** approach: traces were persisted as real-ticker / real-ISO shapes; the read surfaces (`get_trace` MCP tool, `serializers.trace_data`) applied `apply_ticker` / `apply_date` at render time when `session.config.blind=True`. Two leak surfaces were uncovered:

1. **REST owner-auth `GET /sessions/{id}/trace`** — the shared serializer `trace_data` already supported `blind_mapping` (Team D V1), but the owner-auth route never passed it. A blind-benchmark agent reading the REST endpoint as the session owner saw real tickers + real ISO dates (Codex bug `50abd05e` covered MCP `get_trace` but not the REST endpoint).
2. **SSE `/sessions/{id}/stream` `trace` event** — same shape: the SSE serializer call site dropped `blind_mapping`. Live trace streaming leaked real shape even when the agent was authenticated.

The recon for this exec-plan also surfaced a structural concern: if the on-disk persistence is real-shape and only the read surface blinds, then a future read surface that forgets to pass `blind_mapping=` regresses the entire blind-correctness contract. The leak is silent — tests against the existing read surfaces all pass, but a NEW reader inherits the bug.

The redesign moves blinding to **write-time**: traces persist pre-blinded (in `T_NNNN` / `Day_N` shape) when `session.config.blind=True`, regardless of read surface. The read surfaces still apply the transform (idempotent against already-blinded data), so non-blind sessions and pre-redesign data work unchanged.

---

## Decision

`save_trace_entry` gains a `blind_mapping: BlindMapping | None = None` kwarg. When non-None, `entry.request_params` and `entry.response_summary` are walked through `apply_blind_to_trace_payload` (`finlet/core/blind_mapping.py`) **before** the JSON dump. The walker mirrors the existing MCP read-time semantics (`finlet/mcp/tools_portfolio.py:_blind_trace_payload`):

- Dict keys named `ticker` (case-insensitive) → `apply_ticker` on string values.
- Dict keys matching `_DATE_KEY_PATTERN` (`_at$|_time$|timestamp|date`) → `apply_date` on string values that match `_ISO_DATE_RE`.
- `real_time` is exempt (wall-clock-now carries no market signal).
- Lists recurse element-wise; scalars forward unchanged.

When `blind_mapping=None` (default), the entry is persisted verbatim — non-blind sessions unchanged.

**`timestamp_sim` column stays as the real datetime.** SQL `ORDER BY timestamp_sim` needs a real datetime for monotonic ordering; read surfaces apply `apply_date` over the dict-converted entry at render time. The render-time transform is idempotent against already-blinded dict fields, so this works for both pre-redesign and post-redesign data.

**All 5 `save_trace_entry` call sites patched** to pass `blind_mapping=session.blind_mapping if session.config.blind else None`:

- `finlet/api/services/market_service.py:610` (plugin query persist)
- `finlet/api/services/trade_service.py:230` (order persist after submit)
- `finlet/api/services/trade_service.py:271` (rejected-via-plugin-error)
- `finlet/api/services/trade_service.py:307` (auto-fill-after-step)
- `finlet/api/services/clock_service.py:88` (`persist_new_traces` helper)

**REST + SSE owner-auth blinding wired (Team E `cc44af5`).** `finlet/api/serializers.py` hoists `_blind_mapping_for(session)` out of `routes_public_session.py` so REST + SSE + public-session share one source of truth (`finlet.api.serializers._blind_mapping_for`). `routes_portfolio.py:get_trace` and `routes_sse.py:_generate_events` now pass `blind_mapping=_blind_mapping_for(session)` to the shared serializer. `_blind_mapping_for` returns `session.blind_mapping` iff `session.config.blind=True` AND mapping is populated — opt-in only.

**Non-blind shape lock.** `tests/e2e/test_session_trace_nonblind_shape.py` (new in Team E) regression-tests the byte-for-byte non-blind shape contract so future refactors of `trace_data` cannot drift `sim_time` / `ticker` / pagination envelope for the dashboard's authenticated renderer.

---

## Justification

**Single source of truth on disk.** Read-time-only blinding means every read surface must remember to pass `blind_mapping=`. Adding a new read surface (e.g., a future webhook, a new dashboard widget, a debugging CLI command) silently regresses blind correctness if the developer forgets. Write-time blinding inverts the trust model: the on-disk shape IS the blinded shape; reading without `blind_mapping=` produces correct (blinded) output because the data is already blinded. The defense-in-depth read-time transform handles non-blind sessions and remains idempotent against already-blinded data.

**Read-time transform stays idempotent.** Opaque `T_NNNN` ids pass through `apply_ticker` unchanged (they're not in `mapping.ticker_map`); `Day_N` strings don't match `_ISO_DATE_RE` so `apply_date` is skipped. A pre-redesign session that has real-shape traces on disk still gets blinded at read time when the session is blind. A post-redesign session has blinded traces on disk; the read transform is a no-op. Either way, the read surface produces the correct shape.

**The 2 live leaks proved the read-time-only approach is fragile.** Recon for this exec-plan walked every blind-mode read surface in the codebase. The owner-auth REST `GET /sessions/{id}/trace` and SSE `trace` event were both shipping real shape on blind sessions because their route handlers dropped `blind_mapping=`. The shared serializer already supported the kwarg — the bugs were that two specific callers dropped it. With write-time blinding, the same future bug shape would be impossible: even if a new route dropped `blind_mapping=`, the underlying data is already blinded.

**Owner GDPR-export gets blinded form on undecrypted runs.** The blast radius: `finlet/gdpr/walkers.py` walks `Session.trace` for the data-export pipeline. On a blind session whose owner has NOT yet called `decrypt_benchmark_run`, the GDPR export reflects the blinded shape — `T_NNNN` and `Day_N`, not real tickers and ISO dates. This is the correct behavior for the anti-cheat contract: the owner has not yet declared "unlock the mapping", so the export-anywhere semantics MUST mirror "what was seen during the run". Once decrypted, future GDPR exports DO get real shape (the per-session DB still holds the canonical `blind_mapping`, and downstream readers can apply `reverse_ticker` / `reverse_date` if needed). Pre-existing GDPR test fixtures may need re-baselining — see "Follow-ups" in `docs/REMAINING_TASKS.md`.

**Defense-in-depth, not exclusivity.** Write-time blinding is the primary protection; the read-time transform stays in place as a backstop. This is the same pattern as `docs/decisions/blind-benchmark-envelope-fields-must-blind.md` (envelope-level transforms persist alongside body-level transforms — both run, both are idempotent). The grep gate at `tests/e2e/test_blind_benchmark_zero_leak.py` validates the union: no real ticker substring anywhere in the response blob, regardless of which layer applied the transform.

**T2 capture test** (`tests/e2e/test_blind_benchmark_zero_leak.py:_patch_persistence` from Team F `e9a04e7`) introspects each captured `save_trace_entry` call to assert `blind_mapping=` was passed — FAILS LOUD with the args + entry if Team A `3bc7a56` plumbing regresses on any of the 5 call sites. This is the test that protects against a future engineer dropping the kwarg silently.

---

## Consequences

### Positive

- **No silent regression from new readers.** A future read surface that forgets `blind_mapping=` still produces correct output for blind sessions because the data is already blinded on disk.
- **REST + SSE owner-auth trace surfaces now correctly blind** on owner-on-blind-session reads. Both Codex-class leaks (real tickers + real ISO dates leaking through routes that already had `blind_mapping=None` baked in) are closed.
- **Idempotent under read-time re-apply.** Non-blind sessions and pre-redesign data continue to work without migration; the read transform handles both shapes correctly.
- **Defense-in-depth.** Even if write-time blinding regresses on some future call site, the read-time transform catches the leak before it reaches the agent. The grep gate validates the union, not just one layer.
- **5-site mechanical contract.** Team F's `_patch_persistence` test captures every `save_trace_entry` call site; dropping `blind_mapping=` from any of the 5 sites fails T2 with an actionable message naming the regressed site.

### Negative

- **Pre-decrypt GDPR exports return blinded shape.** Owners who request an Article 20 data export on a not-yet-decrypted benchmark session get `T_NNNN` and `Day_N` in their trace export. This is the correct security-model behavior but requires explicit user-facing documentation in the dashboard's "Export My Data" flow. Mitigation: once the owner calls `decrypt_benchmark_run`, future exports render real shape; the export endpoint can be re-fetched after decrypt.
- **Per-session `BlindMapping` lookup at every trace persist.** `save_trace_entry` now needs `session.blind_mapping` in scope at every call site. We chose to thread it explicitly through the kwarg (rather than read from a globally-accessible session registry) because the explicit threading makes the dependency visible — a future engineer adding a new call site sees the kwarg in the function signature and is prompted to think about blind correctness.
- **Re-baselining cost on pre-existing fixtures.** Any test that wrote real-shape traces to a blind session and then asserts real-shape on read will fail post-shipment. Mitigation: the existing test suite was updated in-place during the exec-plan (Team A `3bc7a56` shipped with 569/569 core+db+e2e tests passing); future fixtures should follow the same pattern.

### Trade-offs explicitly chosen

- **Write-time-AND-read-time over write-time-only.** A write-time-only approach would remove the read transform entirely. We kept the read transform as belt-and-braces because: (1) pre-redesign data still exists on disk; the transform handles it. (2) The transform is cheap (recursive dict walk over per-entry payload). (3) A future bug that bypasses the write-time path (e.g., a direct SQL INSERT in a debugging script) still produces correct output because the read transform catches it.
- **`timestamp_sim` real datetime over blinded-on-disk.** SQL `ORDER BY` needs a real datetime for monotonic ordering. Blinding the column would either break ordering or require a parallel real-time column for sorting only. We chose to keep the column real and apply `apply_date` over the dict-converted entry at render time. Cost: the column itself is a wall-clock-date leak surface IF a future read path queries the column directly without going through the serializer. Mitigation: the read serializers (REST + SSE + MCP `get_trace`) all dict-convert via `_to_dict` before render, and the transform runs on the dict — direct column queries do not exist in the current codebase.
- **`real_time` exempt over blinded.** Wall-clock-now timestamps carry no market-data signal and the Reveal hot-swap relies on them staying stable. Same exemption as `docs/decisions/blind-benchmark-envelope-fields-must-blind.md`.

---

## Reversal path

Mechanical, reversible in one PR:

1. In `finlet/db/persistence.py:save_trace_entry`, drop the `blind_mapping` kwarg and the pre-persist walker call. Entries persist verbatim again.
2. In each of the 5 call sites (`trade_service.py:230/271/307`, `market_service.py:610`, `clock_service.py:88`), drop the `blind_mapping=` argument.
3. Keep the read-time transform in `serializers.trace_data` and `_blind_trace_payload` — these still apply on the dict-converted entry and produce the correct shape for sessions whose data is real on disk.
4. Revert `tests/e2e/test_blind_benchmark_zero_leak.py:_patch_persistence` to its pre-Team-F shape (drop the capture lists + T2 assertions).
5. Revert `tests/e2e/test_blind_trace_read_paths.py` (REST + SSE owner-auth coverage stays useful; only the write-time T2 piece needs to go).
6. Revert Team E's `cc44af5` plumbing — REST + SSE routes drop `blind_mapping=_blind_mapping_for(session)`. Owner-auth REST + SSE trace surfaces would then leak again on blind sessions; the reversal is only sound if you also accept the original V1 read-time-only correctness.

Estimated cost: 1-2 hours. The reversal is sound technically but reintroduces the 2 live leak surfaces this decision closed.

---

## References

- Write-time blinding: `finlet/core/blind_mapping.py:apply_blind_to_trace_payload` + `finlet/db/persistence.py:save_trace_entry` — Team A `3bc7a56`
- 5 call sites: `finlet/api/services/market_service.py:610`, `finlet/api/services/trade_service.py:230/271/307`, `finlet/api/services/clock_service.py:88` — Team A `3bc7a56`
- REST + SSE owner-auth wiring: `finlet/api/routes_portfolio.py:get_trace`, `finlet/api/routes_sse.py:_generate_events`, `finlet/api/serializers.py:_blind_mapping_for` — Team E `cc44af5`
- Non-blind shape lock: `tests/e2e/test_session_trace_nonblind_shape.py` — Team E `cc44af5`
- Persistence capture test: `tests/e2e/test_blind_benchmark_zero_leak.py:_patch_persistence` + T2 assertions — Team F `e9a04e7`
- Read-time read-path coverage: `tests/e2e/test_blind_trace_read_paths.py` — Team F `e9a04e7`
- Read-time MCP transform (pre-existing): `finlet/mcp/tools_portfolio.py:_blind_trace_payload`
- Real_time exemption: `finlet/api/serializers.py:97` (existing) + `finlet/mcp/tools_portfolio.py:_blind_trace_payload` (existing)
