# Decision: Repurpose "Save first strategy" Checklist Item to "Learn how to build a strategy"

**Date**: 2026-04-27
**Status**: Accepted (reversible — see Consequences)
**Iteration**: bug-hunt 20260428T031818Z2efa, Team A (commit `dd3377e`)

---

## Context

The Getting Started checklist on `dashboard/index.html` carried a row labeled "Save first strategy" with `data-checklist-key="strategy"`. The visible affordance promised to save a strategy. The click handler did something different: it called `window.openLeaderboardSubmitModal()`, which opens a modal titled "Submit to Leaderboard" with fields for Agent Name, Description, Model Used, and Strategy Category. No strategy is saved by that modal — it submits a leaderboard entry. The checklist counter also did not advance, so a user who clicked the row got the wrong dialog AND no progress credit.

Two underlying truths surfaced during triage:

1. **There is no save-strategy endpoint in Finlet.** The strategy concept is CLI/MCP-only at present (see `docs/REMAINING_TASKS.md`: "No web-based strategy builder or named strategy persistence — entire strategy layer is CLI/MCP-only"). Wiring the row to a real save flow was not possible within the scope of this iteration.
2. **The labeled affordance must do what its label promises.** A row that claims to save a strategy and instead opens a leaderboard form is a contract bug, not a UX rough edge. It propagates a wrong mental model into every subsequent feature the user tries.

---

## Decision

Rename the checklist row from "Save first strategy" to "Learn how to build a strategy" and route the click handler to `window.location.href = 'agent-guide.html#strategies'`. The handler also calls `markStepComplete('strategy')` so the checklist counter actually advances (the click counts as completing the step).

The `data-checklist-key="strategy"` attribute is retained for back-compat with prior session state stored in localStorage.

---

## Why this and not the alternatives

- **Wire to a real save-strategy flow.** Rejected — no endpoint exists. Building one is a multi-week feature, not a bug-hunt scope.
- **Remove the row entirely.** Rejected — the strategy concept is real and users need a discoverable entry point. Removing the row would push them to fish around the agent guide on their own.
- **Leave the wrong handler in place.** Rejected on first principles — documented affordances must do what they promise.

The repurpose is the only option that ships in a single commit AND keeps the checklist meaningful AND avoids lying to the user about what the click does.

---

## Consequences

- The "Learn how to build a strategy" row navigates to the canonical strategy guidance surface (`agent-guide.html#strategies`) and ticks the checklist counter.
- The underlying product gap (no save-strategy endpoint) remains and is recorded in `docs/REMAINING_TASKS.md`. When a save-strategy flow ships, this decision should be revisited: rename the row back to "Save first strategy" and wire the handler to the new endpoint. The `data-checklist-key="strategy"` attribute means existing localStorage state survives the change in both directions.
- The change is reversible — undo it by reverting `dd3377e` once the underlying product gap is closed.
- Future bug-hunt iterations that find the row should consult this record before re-flagging it as a misrouted affordance.

---

## References

- Triage: `docs/bug-hunt/20260428T031818Z2efa/triage.md` (F2)
- Plan: `docs/bug-hunt/20260428T031818Z2efa/plan.md` (Team A scope)
- Implementation: commit `dd3377e` ([Team A]: bug-hunt 20260428T031818Z2efa — fix onboarding checklist wiring)
- Related lesson: `docs/LESSONS.md` — "Documented affordances MUST do what their label promises"
