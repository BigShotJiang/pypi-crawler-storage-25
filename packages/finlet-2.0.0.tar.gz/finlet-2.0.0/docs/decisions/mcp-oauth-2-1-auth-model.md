# Decision: MCP OAuth 2.1 + DCR + Resource Indicators Auth Model

**Date:** 2026-05-08
**Status:** Accepted
**Source:** MCP-First Migration Phase 4a (Team A1).

## Context

MCP spec 2025-11-25 mandates OAuth 2.1 + Resource Indicators (RFC 8707) + Dynamic Client Registration (RFC 7591). Token-passthrough is explicitly forbidden, and Finlet's current `api_key` MCP tool argument (`finlet/mcp/tools_benchmark.py:26-175`, `finlet/mcp/tools_portfolio.py:15-110`, `finlet/mcp/tools_trading.py:31-148` per recon at HEAD `96ed4b5`) is exactly the pattern the spec language calls token-passthrough. Closed beta tolerates this; **paid GA does not**. Phase 4 unblocks paid GA.

Finlet's current dual-auth dependency injectors at `finlet/auth/deps.py:27-236` (`require_api_key`, `require_user`, `optional_user`) tag `request.state.auth_method` as `AUTH_METHOD_BEARER` or `AUTH_METHOD_COOKIE`. Phase 4 adds OAuth as a **third** parallel injector (`require_oauth`, tagging `AUTH_METHOD_OAUTH`) — replacement is rejected because it would break the 90-day dual-accept window before it starts. The user/cookie path (`finlet/auth/service.py`, `finlet/auth/cookie.py`, `finlet/auth/session_auth.py`, `finlet/auth/password.py` argon2-cffi, `finlet/auth/mfa/`) stays canonical for the dashboard / human path forever.

`UserRecord` at `finlet/auth/service.py:51-79` already carries `password_hash`, `secondary_key_hash`, `primary_key_expires_at`, `mfa_enabled`, `tier`, `research_network`, fingerprint fields, and the dual-key rotation state. The `validate_key` / `_maybe_promote_secondary` flow at `finlet/auth/service.py:461-497` is the canonical credential resolver. Whether OAuth tokens resolve to this same `UserRecord` or to a separate identity table is decided below.

The Finlet `pyproject.toml:1-92` server stack today pins `mcp>=1.2`, `cryptography>=46.0.6`, `argon2-cffi>=23.1.0`, FastAPI, SQLModel, alembic. There is no OAuth library — `authlib`, `oauthlib`, and `python-jose` are all absent. The migration chain at `finlet/db/migrations/versions/` runs from `001_initial_schema.py` to `013_add_named_api_keys.py`; the OAuth DB tables go in the next slot (014, owned by Team B1).

## Decision

The five decisions locked by this record are summarized in the matrix below; each is then justified in its own section.

| # | Decision | Locked value |
|---|----------|--------------|
| 1 | **AS topology** | **Own AS** built on `mcp[auth]>=1.27.0`'s `OAuthAuthorizationServerProvider` scaffold + `joserfc>=1.0` for JWT signing. Hosted (WorkOS / Stytch) is the documented fallback if Team B2 slips past 2026-06-12 (week 5 of Phase 4). |
| 2 | **DCR posture** | **Open registration** at `/oauth/register` with rate-limit (10/hour per IP, 100/day global), strict redirect URI validation (HTTPS exact-match), and PKCE-only enforcement. No admin allowlist. Allowlist mode is opt-in via env var `FINLET_OAUTH_DCR_ALLOWLIST_ONLY=1` for self-hosted operators (default off). |
| 3 | **OAuth library** | **`mcp[auth]>=1.27.0` (provider scaffold + Starlette routes) + `joserfc>=1.0` (JWT signing/verification + JWK).** Add to `pyproject.toml [project.optional-dependencies] server` in Team B1's PR. Authlib server-side AS is rejected; python-jose is rejected (abandoned). |
| 4 | **Identity binding** | OAuth tokens resolve to the **same `UserRecord`** at `finlet/auth/service.py:51-79`. JWT `sub` = `UserRecord.id`; the `oauth_clients` row is the *client* identity, distinct from the *user* identity. Separate `OAuthSubject` table is rejected. |
| 5 | **Token storage** | Access token = **15-minute EdDSA (Ed25519) JWT** signed by a key in a new `oauth_keys` table; key rotation cadence **90 days** (overlap window 30 days where both keys remain in JWKS). Refresh token = **opaque, 256-bit secret, SHA-256 hashed at rest, single-use rotation, 90-day absolute lifetime**. CLI persists access+refresh at `~/.finlet/credentials` (mode `0600`, JSON: `{"access_token", "refresh_token", "expires_at", "issuer"}`). Browser-issued tokens (Claude Desktop, Cursor, Windsurf) are managed by the client — Finlet never persists them. |

### 1. AS topology — own AS via `mcp[auth]` provider scaffold

**Locked: own AS in `finlet/auth/oauth/`.**

**Rationale.** As of 2026-05-08, the MCP Python SDK at v1.27.0 (released 2026-04-02 per `gh api repos/modelcontextprotocol/python-sdk/releases/latest`) ships a complete authorization-server scaffold under `mcp.server.auth`:

- `mcp.server.auth.provider.OAuthAuthorizationServerProvider` — Protocol-based abstract interface defining 9 methods the AS must implement (`get_client`, `register_client`, `authorize`, `load_authorization_code`, `exchange_authorization_code`, `load_refresh_token`, `exchange_refresh_token`, `load_access_token`, `revoke_token`).
- `mcp.server.auth.handlers/` — pre-built Starlette request handlers for `/authorize`, `/token`, `/register`, `/revoke`, `/.well-known/oauth-authorization-server`.
- `mcp.server.auth.routes.create_auth_routes(...)` — assembles the route list, returns `list[Route]` mountable directly into a Starlette/FastAPI app.
- The release notes for v1.27.0 explicitly call out "fix: add RFC 8707 resource validation to OAuth client" (PR #2069 by `felixweinberger`), and the `provider.py` token classes (`AuthorizationCode`, `AccessToken`, `AuthorizationParams`) carry a `resource: str | None = None  # RFC 8707 resource indicator` field.

This means Phase 4 does **not** need to hand-roll the OAuth state machine or the wire protocol. Team B1 implements the `OAuthAuthorizationServerProvider` subclass (storage adapter against Finlet's SQLite + the new `oauth_clients` / `oauth_authorizations` / `oauth_refresh_tokens` / `oauth_keys` tables); Team B2 wires `create_auth_routes(...)` into the FastAPI app and adds JWT issuance via `joserfc`. Total surface delta is bounded — the heavy lifting is in the SDK.

**Why this is "own AS" and not "vendor-hosted":**
- **Closed-source codebase, no vendor lock.** WorkOS and Stytch ship excellent DCR products, but their pricing model (per-MAU or per-token) layers a SaaS bill on top of Finlet's infra cost forever. Finlet at GA targets $0 free + $29/mo paid (per `project_finlet_pricing.md` memory note); a ~$0.05/MAU AS bill from a hosted vendor compresses gross margin by single-digit percent at scale.
- **MCP-native positioning.** The Phase 3 decision record `docs/decisions/mcp-canonical-surface.md` declares MCP the canonical agent surface. Owning the AS reinforces "MCP-native auth with OAuth 2.1" as a positioning lever — Finlet looks like a first-class MCP citizen, not a thin wrapper around someone else's identity layer.
- **The recipe is well-trodden.** WorkOS, Stytch, Cloudflare all shipped DCR rollouts in April 2026 with public reference implementations. The MCP Python SDK ships the protocol scaffold. The unknown territory is small: storage adapter, JWT signer, scope→tier mapping. Each is a Finlet-specific decision the vendor couldn't make for us anyway.
- **Audit trail and tier integration.** Finlet's `UserTier` enum at `finlet/auth/service.py:44-49` (`FREE`, `BUILDER`, `INSIGHTS`, `ENTERPRISE`) gates rate limits and feature flags throughout the app. A hosted AS would force every scope/tier check to round-trip through introspection (extra latency, extra failure mode); an own AS issues JWTs that already carry the tier as a custom claim, validated at the resource server with no out-of-band call.

**Fallback condition (documented escape hatch):** If Team B2 (AS endpoints + helpers, ~1.5 weeks) is not demoable by **2026-06-12** (week 5 of Phase 4 starting 2026-05-08), the orchestrator should pause Phase 4 and re-run this decision with hosted AS (WorkOS preferred — DCR + RI both production-shipped per their April 2026 blog post). The fallback shrinks Team B1 dramatically (no `oauth_clients` table; only a trust-store config), and Team C1 changes from "validate JWT against own JWKS" to "validate JWT against hosted JWKS." The Contract Lock URI `https://finlet.dev/mcp` and scope names remain the same — those are Finlet contracts, not vendor contracts.

**Alternatives considered and rejected:**

- **Hosted AS (WorkOS AuthKit, Stytch Connected Apps).** Rejected as the primary path because of the SaaS bill at GA, the loss of "MCP-native" positioning leverage, and the latency hit of round-tripping introspection for tier checks. **Held warm as the explicit fallback** above; the team should not relitigate vendor choice in 4b unless the fallback condition triggers.
- **Build the AS on Authlib's `AuthorizationServer` class directly.** Rejected. Authlib v1.7.2 (released 2026-05-06 per PyPI, BSD-3-Clause) ships server-side AS implementations for **Flask and Django only** — its `Starlette OAuth Client` and `FastAPI OAuth Client` modules are client-side only (`docs.authlib.org/en/latest/client/fastapi.html`). Wiring Authlib's Flask AS into a FastAPI app would require building a Starlette-compatible request/response adapter from scratch — strictly more work than implementing the MCP SDK's `OAuthAuthorizationServerProvider` Protocol, and it inherits Authlib's RFC 8707 gap (issue #524 — see decision #3).
- **Hand-roll the entire AS without a scaffold.** Rejected. The MCP spec is explicit about wire-format details (RFC 8414 metadata fields, RFC 7591 registration response shape, RFC 7636 PKCE S256 verification, RFC 8707 resource parameter handling); reinventing all of these for a single project invites spec drift and CVE exposure.

### 2. DCR posture — open with rate-limit + abuse heuristics

**Locked: open registration. No admin allowlist on the default deploy.**

**Rationale.** RFC 7591 §3 explicitly contemplates two modes: open dynamic registration (any client may self-register) and protected dynamic registration (registration is gated by an initial access token). The MCP spec 2025-11-25 mandates that the AS support DCR — what it doesn't mandate is whether registration is open or gated. WorkOS's April 2026 blog post on DCR rollout (`workos.com/blog/dynamic-client-registration-dcr-mcp-oauth`) recommends "CIMD-first with DCR as a compatibility fallback" and explicitly lists rate limiting on the registration endpoint as the primary abuse mitigation, not allowlisting. Stytch shipped open DCR at the same time. Cloudflare shipped open DCR via their April 2026 release.

The agent ecosystem reality is: a developer pointing Cursor at `https://finlet.dev/mcp` for the first time should be able to authorize and use the server in <60 seconds with no out-of-band human approval cycle. Allowlisting destroys that property — every new IDE + every new agent runtime version ships its own client, and a Finlet operator approving them by hand is a permanent cost center.

**Locked abuse mitigations on the open path:**
- **Rate-limit per IP at the registration endpoint:** 10 successful registrations per hour per IP, 100 successful registrations per day globally. Rejected requests (validation failures) do NOT count against the budget. Counter persists in SQLite (Team B1's storage adapter).
- **Strict redirect URI validation:** RFC 7591 §2 + RFC 8252 §7.1. HTTPS-only for non-loopback URIs, exact-match (no path prefix wildcards), no embedded credentials, no fragment. Loopback (`http://127.0.0.1:*` and `http://[::1]:*`) is allowed for native CLI clients per RFC 8252 §7.3.
- **PKCE required on the client metadata.** Registration requests with `token_endpoint_auth_method: "none"` (public clients — IDEs, CLIs) MUST also declare `code_challenge_methods` containing `S256`; `plain` is rejected at registration time. Confidential clients (`client_secret_post`) MAY skip PKCE per RFC 7636 §4.4.1, but Finlet enforces PKCE for all clients (defense in depth).
- **Grant-type allowlist on registered clients:** only `authorization_code` and `refresh_token` are permitted. Implicit, password, and client-credentials grants are rejected at registration time. (RFC 7591 §2.1 `grant_types` field validation.)
- **Optional allowlist override for self-hosted operators:** env var `FINLET_OAUTH_DCR_ALLOWLIST_ONLY=1` flips the registration endpoint to require an initial access token (RFC 7591 §3.1) before any client may register. Default off; documented for enterprise self-hosters who need it.

**Alternatives considered and rejected:**

- **Allowlist by default, open registration as opt-in.** Rejected. Inverts the agent-ecosystem ergonomic. Any Finlet user wanting to plug in a new client (Cursor v0.45 update, a new MCP-enabled VS Code extension, a fresh `claude mcp add` entry) would file a support ticket. Phase 4's whole point is removing the "API key as tool argument" friction; replacing it with "wait for admin approval" friction is no progress at all.
- **CIMD-first with DCR fallback (WorkOS recommendation).** Rejected. CIMD (Client-Initiated Metadata Discovery) presupposes the client knows the server's brand and pre-registers via marketing-driven flows. Finlet's expected primary integrators are agent runtimes that don't have a Finlet-specific CIMD path — they need DCR to work the same as it does against any other MCP server.
- **No rate limit, just strict validation.** Rejected. RFC 7591 §3 explicitly calls out storage DoS as the primary abuse vector for open registration. Without a rate limit, a single IP can register 10,000 throwaway clients overnight, bloating the `oauth_clients` table.

### 3. OAuth library — `mcp[auth]>=1.27.0` + `joserfc>=1.0`

**Locked: `mcp[auth]>=1.27.0` (provider scaffold + Starlette route handlers) + `joserfc>=1.0` (JWT signing, key management, JWS/JWK primitives).**

Add the following to `pyproject.toml [project.optional-dependencies] server` (Team B1's PR):

```toml
"mcp[auth]>=1.27.0",   # bumps existing mcp>=1.2 pin; adds OAuth provider scaffold
"joserfc>=1.0",        # JWT signing/verification, JWK, JWS — derived from Authlib, MIT
```

The current `pyproject.toml:34` line `"mcp>=1.2"` becomes `"mcp[auth]>=1.27.0"`. No other server-stack dependency is touched.

**Rationale by axis:**

- **Maturity.** `mcp[auth]` is the canonical SDK for the spec we're implementing — the same `felixweinberger` who maintains the Python SDK ships RFC 8707 fixes (PR #2069, v1.27.0 release notes). Tracking the SDK is the lowest-drift path. `joserfc` is the spec-purified successor to `authlib.jose` (per `jose.authlib.org/en/`), maintained by the same author (`lepture`); the migration from `authlib.jose` to `joserfc` is documented as the upgrade path (Authlib v1.7+ deprecates `authlib.jose`).

- **RFC 7591 DCR support.** `mcp[auth]` ships `mcp.server.auth.handlers.register.RegistrationHandler` — a complete RFC 7591 §3.1 registration handler with scope validation, grant-type allowlisting, secret generation. Inspected at `https://github.com/modelcontextprotocol/python-sdk/blob/main/src/mcp/server/auth/handlers/register.py`; the implementation is ~80 lines of well-tested code. Authlib's Flask DCR (`authlib.integrations.flask_oauth2.ClientRegistrationEndpoint`) cannot be wired into FastAPI without a Flask shim.

- **RFC 8707 Resource Indicators support.** `mcp[auth]>=1.27.0` carries `resource: str | None = None  # RFC 8707 resource indicator` fields on `AuthorizationCode`, `AccessToken`, and `AuthorizationParams` (verified by reading `src/mcp/server/auth/provider.py` on the v1.x branch). The release notes for v1.27.0 explicitly note the RFC 8707 fix (PR #2069). **Authlib does NOT support RFC 8707** — issue #524 has been open since 2023-01-16, the maintainer's last comment is from 2025-01-15 saying "Interested in working on a PR?" (verified via `gh api repos/authlib/authlib/issues/524`). Choosing Authlib server-side would force us to hand-roll RFC 8707 enforcement on top of an unmaintained-feature-area library, which is the opposite of "modern path default."

- **Async / FastAPI compatibility.** `mcp[auth]` ships Starlette `Route` objects via `mcp.server.auth.routes.create_auth_routes(...)` — directly mountable into FastAPI (FastAPI is built on Starlette). All handlers are `async def`. Authlib's server AS is Flask + Django; its Starlette / FastAPI integrations are client-side only (verified in `https://github.com/authlib/authlib` README features section). `joserfc` is sync (JWT operations are CPU-bound, not I/O-bound — running them in `asyncio.to_thread` if needed is trivial), and aligns with the rest of Finlet's `cryptography` usage.

- **License.** Both libraries are permissive: `mcp` is MIT (per `https://github.com/modelcontextprotocol/python-sdk/blob/main/LICENSE`), `joserfc` is BSD-3-Clause (matches Authlib's BSD-3-Clause, same author, same project family). No LGPL/GPL contamination on Finlet's `LicenseRef-Proprietary` distribution.

- **Install size.** `joserfc` source dist is ~150 kB (per PyPI), wheel ~250 kB. `mcp[auth]` adds Starlette (already a transitive of FastAPI, so net-zero) and `pydantic` extras (already a transitive). Net pyproject impact is one line bumped + one line added; no dependency tree explosion.

**Alternatives considered and rejected:**

- **`authlib>=1.7.2` server-side AS.** Rejected for three independent reasons: (a) Flask/Django-only server AS (no FastAPI/Starlette server adapter — verified in README features list); (b) RFC 8707 not implemented (issue #524 open since 2023); (c) Authlib v1.7.2 deprecates its own `authlib.jose` module in favor of `joserfc` — using Authlib means immediately migrating off `authlib.jose` to `joserfc` for JWT, so we'd carry both deps. Authlib stays available as a *client-side* OAuth library if we ever need third-party OAuth integrations (e.g., GitHub social login on the dashboard) — that's a separate, future decision.
- **`oauthlib>=3.2` + `requests-oauthlib` + `jwcrypto`.** Rejected. `oauthlib` is the workhorse server-side OAuth library underneath Flask-OAuthlib/Django-OAuth-Toolkit, but it's sync-only and requires a substantial framework adapter to wire into FastAPI. `requests-oauthlib` is purely a client-side library on top of `requests` (we use `httpx`). `jwcrypto` is a separate JWT library that doesn't interop with `oauthlib`'s token classes. Three libraries, three integration points, three failure modes — strictly worse than the `mcp[auth]` + `joserfc` two-library path.
- **`python-jose>=3.3`.** Rejected. The library is **abandoned** — multiple FastAPI ecosystem discussions (e.g., `https://github.com/fastapi/full-stack-fastapi-template/discussions/1188`) flag the maintenance gap; the FastAPI community has moved to PyJWT or Authlib/joserfc. CVE exposure on an unmaintained crypto library is a non-starter for a paid-GA product.
- **`PyJWT>=2.9` + hand-rolled OAuth wire protocol.** Rejected. PyJWT is a fine JWT library, but it's *only* JWT — every other piece of OAuth (RFC 8414 metadata, RFC 7591 DCR, RFC 7636 PKCE, RFC 8707 RI) becomes hand-rolled. The MCP SDK already ships these primitives; reinventing them adds risk without value. (We keep PyJWT as a fallback if `joserfc` ever stalls — they're API-similar enough that a swap is a few hours.)

### 4. Identity binding — same `UserRecord`

**Locked: OAuth tokens resolve to the same `UserRecord` at `finlet/auth/service.py:51-79` as API keys and cookie sessions. JWT `sub` claim = `UserRecord.id`. The `oauth_clients` row is the *client* identity (e.g., "Cursor v0.45 on alice's MacBook"), distinct from the *user* identity ("alice@example.com").**

**Rationale.**

- **Single source of truth for tier and feature flags.** `UserRecord.tier` (`FREE`/`BUILDER`/`INSIGHTS`/`ENTERPRISE`) gates rate limits across the app; `UserRecord.research_network` opt-in gates research-network features; `UserRecord.mfa_enabled`, `UserRecord.totp_secret_encrypted`, `UserRecord.sms_mfa_enabled` gate dashboard MFA flows. Forking identity into a parallel `OAuthSubject` table means duplicating all of this state and keeping it in sync — every tier change, every research-network opt-in/out, every MFA setting must propagate to the OAuth subject record. This is exactly the kind of dual-write hazard that produces silent drift bugs.
- **MFA inheritance for free.** When a user enables TOTP on their dashboard (the user-auth path that stays untouched per Phase 4 constraints), an OAuth client acting on their behalf inherits the MFA-protected state automatically because the `UserRecord` is the same record. With a separate `OAuthSubject` table, the MFA status either has to be re-replicated (drift hazard) or has to be looked up via a join on every request (latency + complexity).
- **Dual-accept layer is trivial.** Phase 4c's 90-day dual-accept window says: an MCP tool call must work with EITHER an `api_key` (legacy) OR a Bearer JWT (canonical). With same-`UserRecord` binding, the resolver is a one-line branch — `api_key` → `auth_service.validate_key(...)`, JWT → `auth_service.get_by_id(jwt['sub'])`. Both return a `UserRecord`; downstream code (rate limits, tier gates, ownership checks) sees an identical object. With a separate `OAuthSubject`, the dual-accept layer must resolve to a *common type* — either `OAuthSubject` wraps `UserRecord` (extra indirection, no benefit) or rate-limit/tier code must accept a union (every gate call site grows a branch).
- **Audit trail consistency.** `request.state.auth_method` already differentiates `bearer` vs `cookie`; adding `oauth` as a third tag is sufficient to log "this request came in via OAuth" without forking the user identity. The dual-accept window can be operationalized by simply counting requests by auth_method tag — no parallel-identity-table reconciliation required.

**The `oauth_clients` table is *not* a user-identity store.** It holds client metadata per RFC 7591 §2: `client_id`, `client_secret_hash` (for confidential clients), `client_name`, `redirect_uris`, `grant_types`, `scope`, `created_at`, `created_by_user_id` (FK to `UserRecord.id` — who registered this client), `metadata_json` (extension fields). When a user authorizes the client, the `oauth_authorizations` row joins `oauth_clients.client_id` with `UserRecord.id`. The JWT `sub` is the user, the JWT `client_id` claim (per RFC 9068 §2.2) is the client. Standard OAuth modeling.

**Alternatives considered and rejected:**

- **Separate `OAuthSubject` table.** Rejected. Duplicates identity state, breaks MFA inheritance, complicates dual-accept, and gains nothing — Finlet's threat model has no scenario where an OAuth user ought to be a *different* identity from the API-key user with the same email. (Hypothetically, a future "service account" concept could justify a separate identity, but service accounts don't have humans behind them and don't need MFA — they'd be a third path, not a replacement for user-bound OAuth.)
- **Issue OAuth tokens against API-key hashes (one-to-one mapping).** Rejected. Couples OAuth tokens to a specific API key's lifecycle — rotating the API key (`finlet/auth/service.py:_maybe_promote_secondary` flow) would also invalidate every OAuth token, which is the wrong semantics. OAuth tokens have their own lifecycle (refresh + key rotation); API key rotation is a separate concern.
- **Merge cookie sessions and OAuth tokens into a unified "session" abstraction.** Rejected (out of scope). Cookie sessions are short-lived browser sessions tied to CSRF tokens (`finlet/auth/cookie.py`, `finlet/auth/session_auth.py`); OAuth tokens are long-lived agent credentials with refresh semantics. The two should remain distinct concepts even though they both resolve to the same `UserRecord`. Phase 4 explicitly preserves `finlet/auth/cookie.py` (per the exec plan's "files explicitly NOT touched" list at lines 128-138).

### 5. Token storage — short JWT access, opaque refresh, owned key rotation

**Locked:**

- **Access token: 15-minute EdDSA (Ed25519) JWT.**
  - JWT shape per RFC 9068 §2 ("JWT Profile for OAuth 2.0 Access Tokens"): `iss`, `exp`, `aud` (= Resource Indicator URI `https://finlet.dev/mcp`), `sub` (= `UserRecord.id`), `client_id`, `iat`, `jti` (for replay detection if introspection is needed), `scope` (space-delimited string of granted scopes from `finlet:read finlet:trade finlet:benchmark finlet:admin`).
  - Custom claim: `finlet:tier` (= `UserRecord.tier` value), enabling resource-server tier gating without an introspection round-trip.
  - **Lifetime: 900 seconds (15 minutes).** Aligns with RFC 8725 §2.1 ("avoid using long lifetime tokens") and the MCP OAuth lifecycle guidance (5–60 minute access tokens, short by default for blast-radius containment). 15 minutes balances "short enough that revocation is approximated by expiry" against "not so short that refresh churn dominates the wire").
  - **Signing algorithm: EdDSA (Ed25519).** RFC 8725 §3.2 prohibits the `none` algorithm; recommended alternatives are RS256, ES256, EdDSA. EdDSA is selected because it produces smaller signatures (~64 bytes vs RS256's ~256 bytes), is faster to verify, has no parameter-choice footguns (Ed25519 curve is fixed), and is the de-facto modern signature standard. RS256 is the documented fallback if a downstream consumer (e.g., a vendor SDK) doesn't support EdDSA — `joserfc` supports both natively, and the AS metadata advertises whichever the deployment chose.
  - **Key rotation cadence: 90 days, 30-day overlap.** New key generated and added to JWKS at day 60 of the active key's lifetime; new tokens are signed with the new key starting day 90; the old key remains in JWKS until day 120 (covering tokens issued just before the cutover). Stored in a new `oauth_keys` table with columns `kid`, `algorithm`, `private_key_pem` (encrypted via existing `cryptography` infra used for MFA secret encryption), `public_key_jwk_json`, `created_at`, `rotated_in_at`, `expires_at`. JWT `kid` header references the active key.

- **Refresh token: 256-bit opaque, hashed at rest, single-use rotation.**
  - Format: 32 bytes from `secrets.token_bytes(32)`, urlsafe-base64-encoded → 43-character string.
  - **Hashed at rest.** SHA-256 hash of the raw token stored in `oauth_refresh_tokens.token_hash`; raw token returned to client only once at issuance. (Same pattern as `finlet/auth/service.py:81-82` `_hash_key` for API keys — no novel crypto.)
  - **Single-use rotation per RFC 6819 §5.2.2.3 + RFC 6749 §10.4.** When a refresh token is exchanged for a new access token, the old refresh token is invalidated (`oauth_refresh_tokens.consumed_at` set) and a fresh refresh token is issued. If the same refresh token is presented twice, the entire token family is revoked (refresh token reuse detection — sign of theft).
  - **Absolute lifetime: 90 days.** A refresh token issued on day 0 stops working on day 90 regardless of how often it's been rotated. Forces re-authorization at quarterly cadence, bounding the credential lifetime of a leaked refresh chain.
  - **Sliding lifetime: 30 days of inactivity.** A refresh token unused for 30 days is invalidated (`oauth_refresh_tokens.last_used_at` + grace check). Bounds the attack surface of a forgotten credential on a stolen laptop.

- **CLI persistence: `~/.finlet/credentials`, mode `0600`, JSON.**
  - Schema: `{"access_token": "<JWT>", "refresh_token": "<opaque>", "expires_at": "<ISO 8601 UTC>", "issuer": "https://finlet.dev", "client_id": "<the DCR-registered client_id>"}`.
  - **Mode 0600 enforced on read.** CLI errors loudly with a remediation message ("`chmod 600 ~/.finlet/credentials` and re-run") if the mode bits indicate the file is group- or world-readable. This is the existing audit-C4 contract (`docs/decisions/auth-login-cli-vs-api-key.md`) extended to OAuth tokens.
  - **Atomic write with mode set on creation.** New credentials file is written via `os.open(path, O_CREAT | O_WRONLY | O_TRUNC, 0o600)` followed by `os.fdopen(...)`, so the file never exists with looser bits even momentarily.

- **Browser-issued tokens (Claude Desktop, Cursor, Windsurf, VS Code extensions): client-managed, NOT persisted by Finlet.**
  - When a third-party MCP client completes the authorize+token flow, Finlet issues the access+refresh pair; the client stores them per its own credential manager. Finlet retains only the `oauth_authorizations` and `oauth_refresh_tokens` rows on the server side (for revocation and refresh validation). The `~/.finlet/credentials` path is exclusively the CLI's responsibility.

**Rationale.**

- **Why 15-minute access tokens?** RFC 8725 §2.1: "Long lifetimes increase the risk of compromised tokens being used after the legitimate session has ended." 15 minutes is short enough that revocation can be approximated by waiting for natural expiry (no introspection-on-every-call needed for typical operations), long enough that refresh isn't the dominant traffic pattern. The MCP OAuth lifecycle guidance (5–60 min) brackets this; 15 min is the conservative-by-default within the bracket. The choice is reversible: a single config constant change adjusts it without schema migrations.
- **Why EdDSA?** Smaller signatures, faster verification, no curve-choice footguns. RS256 has a well-known key-size gotcha (≤2048-bit keys are deprecated by NIST guidance); EdDSA's Ed25519 is fixed at 256-bit security level. ES256 is a fine alternative but EdDSA is the modern default in newer JWT deployments. `joserfc` and the `cryptography` library both ship Ed25519 first-class.
- **Why opaque refresh tokens?** A JWT refresh token would carry user identity in the unencrypted header/payload; an opaque token is just a random string with no information leak. Refresh-token-as-JWT is a common anti-pattern; refresh-token-as-opaque-secret is the RFC 6749 default.
- **Why single-use rotation?** RFC 6819 §5.2.2.3: refresh-token theft is detectable when the legitimate client presents a token that the AS has already invalidated. Single-use rotation makes theft self-disclosing; reuse → entire family revocation → user is forced to re-authorize, surfacing the breach.
- **Why 90-day key rotation, 30-day overlap?** Industry-standard cadence (matches AWS KMS recommendations, HashiCorp Vault defaults). The overlap window must exceed the longest-lived JWT's TTL — at 15 minutes, 30 days is enormous overkill for technical correctness, but it provides operational slack: an operator who forgets to rotate has a month of warning before tokens start failing.
- **Why mode 0600 on `~/.finlet/credentials`?** Same-as-API-key contract from audit C4. CI environments and shared dev machines have a documented history of leaking secrets via group-readable dotfiles; failing loudly on mode drift is a cheap and well-understood mitigation.

**Alternatives considered and rejected:**

- **Long-lived access tokens (1+ hours), no refresh.** Rejected. Inverts the security tradeoff — extends the blast radius of every leak by ~4×, and forces full re-authentication (browser flow + DCR if the client churned) at every expiry. The whole point of refresh tokens is to make the access token short.
- **JWT refresh tokens.** Rejected. Information leak (token contents are unencrypted JSON), makes single-use rotation harder (the AS would have to track JTIs separately from the token), no upside vs opaque.
- **HS256 (symmetric) signing.** Rejected per RFC 8725 §3.1: symmetric signing on a multi-resource architecture forces the resource server to share the signing secret with the AS, which is a horizontal escalation hazard. EdDSA / RS256 (asymmetric) lets the resource server verify with only the public key from JWKS, never seeing the signing key.
- **Static signing key (no rotation).** Rejected. CVE response would require redeploying every consumer simultaneously; rotation infra is already needed for normal hygiene.
- **Storing tokens in the OS keychain (macOS Keychain, GNOME Keyring, Windows Credential Manager) instead of `~/.finlet/credentials`.** Considered but deferred. The cross-platform keyring pattern is appealing but adds a runtime dependency (`keyring` package) and complicates headless / CI usage where no keyring service is available. Phase 4d may revisit if the file-mode contract proves friction-prone in user testing.

## Consequences

- **Phase 4b (B1–B4) implementation surface is now bounded.**
  - B1's migration `014_add_oauth_clients.py` creates 4 tables: `oauth_clients`, `oauth_authorizations`, `oauth_refresh_tokens`, `oauth_keys`. (The handoff brief and master plan said `010_...` — that was stale; the actual next slot at HEAD `96ed4b5` is `014`.)
  - B1's storage adapter implements the 9 methods of `OAuthAuthorizationServerProvider` against SQLite.
  - B2 wires `mcp.server.auth.routes.create_auth_routes(...)` into `finlet/api/app.py`, configures `ClientRegistrationOptions(enabled=True, default_scopes=["finlet:read"], valid_scopes=["finlet:read", "finlet:trade", "finlet:benchmark", "finlet:admin"])`, and adds Finlet-specific endpoints not covered by the SDK (`/oauth/jwks` if the SDK doesn't ship one, RFC 9728 protected resource metadata).
  - B3 implements DCR rate limiting + redirect URI validation as middleware on the `/register` route.
  - B4 wires the router into the FastAPI app and adds end-to-end tests against the MCP Inspector tool.
- **Phase 4c (C1–C4) leans on `joserfc` for token validation.**
  - C1's `jwt_validator.py` uses `joserfc.jwt.decode` with `algorithms=["EdDSA"]` (algorithm allowlist per RFC 8725 §3), `key=jwks_key_set`, and asserts `aud == "https://finlet.dev/mcp"`, `iss == "https://finlet.dev"`, `exp` not expired, `sub` resolves to a non-revoked `UserRecord`.
  - C2's mcp/auth.py Bearer path branches on `jwt → user_id → UserRecord` (this decision's identity-binding rule); `_authenticate(api_key)` retains its existing path for the dual-accept window.
  - C3 makes the `api_key` argument optional on every MCP tool; when Bearer is present, `api_key` is ignored.
  - C4's scope→tier mapping reads the `finlet:tier` claim from the JWT and combines it with the granted scope set; the mapping table is decided in C4 (out of A1's scope but bounded by the locked scope names above).
- **The 90-day dual-accept window is preserved.** Phase 4 does NOT remove `require_api_key` (`finlet/auth/deps.py:27-82`). It adds `require_oauth` alongside; tool dispatchers accept either source. Sunset cycle for API keys is set in 4e (recommend 6 months from 4c merge per master plan).
- **Migration documentation lineage.** Phase 4d (D1) appends an "OAuth-mode" addendum to `docs/decisions/auth-login-cli-vs-api-key.md` (the Phase 1 / audit C4 record). This decision record (the present file) is the architectural source; the C4 record is the user-facing CLI contract.
- **No code churn in Phase 2 / Phase 3 surface.** `finlet/api/services/*.py` (Phase 2) and `finlet/api/deprecation.py` + middleware (Phase 3) are explicitly NOT touched (per the exec plan's locked-files list at lines 128-138). The deprecation middleware will emit Sunset headers on `/auth/research-network/*` exactly as today; OAuth introduces new paths, not modifications to existing ones.
- **Authlib remains available for future client-side use.** This decision rejects Authlib for the *server-side AS*; it does not preclude using Authlib's `FastAPI OAuth Client` later for third-party social login on the dashboard (e.g., GitHub OAuth for `finlet.dev` user signup). That would be a separate, scoped decision.
- **Vendor risk is monitored, not eliminated.** Two upstream-dependency risks merit explicit watch:
  - `mcp[auth]` is at v1.27.0; the auth module is recent (Nov 2025) and PR #2069 (RFC 8707 fix) is still fresh. Team B2 should write integration tests against the MCP Inspector tool (not just unit tests) so any SDK-side drift surfaces fast.
  - `joserfc` is the spec-purified Authlib JOSE module, well-maintained and on the same release cadence as Authlib itself, but it's a younger library than its progenitor. Pin to `>=1.0` and watch for v2 migration notices.
- **The fallback to hosted AS remains warm.** If by 2026-06-12 (week 5) Team B2 has not produced a demoable AS, escalate to user, switch to hosted (WorkOS preferred), and update this decision record's section #1 with the hosted vendor pin.

## Alternatives Considered (cross-decision)

The five locked decisions above each have their own alternatives sections. A few cross-decision alternatives merit explicit naming and rejection here:

1. **Skip OAuth entirely; keep API keys forever.** Already rejected at the master-plan level — MCP spec 2025-11-25 mandates OAuth 2.1 for paid GA. Re-litigating in 4a would mean defying the migration's gating bet.
2. **Deliver Phase 4 as a single mega-PR.** Rejected. The exec plan sequences 12 teams (A1 → E1) across 5 sub-phases. Each sub-phase has natural review boundaries (decision → AS → RS → clients → cutover); bundling would compress review and inflate blast radius.
3. **Use the existing `finlet/auth/service.py` AuthService cache as the OAuth client store.** Rejected. AuthService is the *user* identity cache; client identity is a different concern. Mixing them would conflate the two namespaces and break the "client_id ≠ user_id" invariant that RFC 7591 + RFC 9068 require.
4. **Reuse cookie session tokens (`finlet/auth/session_auth.py`) as OAuth access tokens.** Rejected. Cookie sessions and JWT access tokens have orthogonal threat models (browser SOP + CSRF for cookies vs. Bearer + audience binding for JWTs). Sharing a token format would leak browser-session semantics into the agent path or vice versa.

## References

- MCP Authorization specification 2025-11-25: `https://modelcontextprotocol.io/specification/2025-11-25/basic/transports` (mandates OAuth 2.1, Streamable HTTP transport with Bearer auth).
- MCP authorization analysis (Den Delimarsky, April 2026): `https://den.dev/blog/mcp-authorization-resource/`.
- RFC 6749 — OAuth 2.0 Authorization Framework.
- RFC 6750 — Bearer Token Usage.
- RFC 6819 — OAuth 2.0 Threat Model (refresh-token reuse detection §5.2.2.3).
- RFC 7591 — OAuth 2.0 Dynamic Client Registration Protocol.
- RFC 7592 — OAuth 2.0 Dynamic Client Registration Management Protocol.
- RFC 7636 — Proof Key for Code Exchange (PKCE).
- RFC 8252 — OAuth 2.0 for Native Apps (loopback redirect URI rules §7.3).
- RFC 8414 — OAuth 2.0 Authorization Server Metadata.
- RFC 8707 — Resource Indicators for OAuth 2.0.
- RFC 8725 — JSON Web Token Best Current Practices (algorithm allowlisting §3, audience validation §3.10).
- RFC 9068 — JWT Profile for OAuth 2.0 Access Tokens.
- RFC 9728 — OAuth 2.0 Protected Resource Metadata (used by `mcp.server.auth.handlers.metadata.ProtectedResourceMetadataHandler`).
- WorkOS DCR rollout (April 2026): `https://workos.com/blog/dynamic-client-registration-dcr-mcp-oauth`.
- Stytch Connected Apps DCR (April 2026): `https://stytch.com/blog/mcp-oauth-dynamic-client-registration/`.
- Cloudflare DCR (April 2026): `https://blog.cloudflare.com/dynamic-client-registration-now-available/`.
- MCP Python SDK auth scaffold v1.27.0 release: `https://github.com/modelcontextprotocol/python-sdk/releases/tag/v1.27.0` (PR #2069 RFC 8707 fix).
- MCP Python SDK auth issue #702 (Starlette middleware vs OAuthAuthorizationServerProvider design discussion): `https://github.com/modelcontextprotocol/python-sdk/issues/702` — informs the choice to use the provider scaffold while keeping the option to add Starlette middleware sugar in B4 if developer ergonomics demand.
- Authlib RFC 8707 issue #524 (open since 2023-01-16, last maintainer comment 2025-01-15): `https://github.com/authlib/authlib/issues/524` — primary basis for rejecting Authlib server-side AS.
- Authlib v1.7.2 PyPI release (2026-05-06): `https://pypi.org/project/Authlib/` — supported RFC list (RFC 7591, 7592, 7636, 8414, 9068 all present; RFC 8707 absent).
- joserfc PyPI: `https://jose.authlib.org/en/` — successor to `authlib.jose`, BSD-3-Clause, JOSE primitives.
- Phase 1 lineage: `docs/decisions/auth-login-cli-vs-api-key.md` (audit C4 — `finlet auth login` credential-verification mode is preserved; Phase 4d adds OAuth mode alongside).
- Phase 3 lineage: `docs/decisions/mcp-canonical-surface.md` (MCP is the canonical agent surface; OAuth is the auth migration that completes the canonical positioning).
- Stdio downstream consumer history: `docs/decisions/cli-mcp-stdio-auth.md` records the original Phase 5 env-var handoff and is now superseded. Current v2 `finlet mcp serve` resolves `~/.finlet/credentials` or `FINLET_API_KEY` directly and forwards to hosted `/mcp`; self-host stdio uses an in-process credential handoff, not process env.
