# Decision: Partition Completeness Invariant via Sidecar Manifests

**Date:** 2026-04-14
**Status:** Implemented; rollout pending (code landed, `FINLET_PARTITION_VALIDATION=OFF` in prod)
**Source:** P0 #2 in `docs/codex-audit/08-adversarial-review-consolidated.md`

## Context

P0 #2 from the codex adversarial review: consumers of the S3 Parquet data lake cannot distinguish "no data for this partition" from "partial data silently written as if complete." S3 `put_object` is atomic, so torn *file* writes are not the risk. The risk is **partition-level completeness**: if yfinance returns 5 of 10 tickers for a date (rate limit, transient fetch failure, upstream change), the partial Parquet lands under the date key and consumers serve it as if it were whole. Eval results drift silently; the bias is undetectable downstream.

Prior to this decision, producers called `s3_client.put_object` directly in 10 ingest scripts, consumers checked only `local_path.exists()`, and the repo contained zero `_SUCCESS` markers or manifests. "Object exists" was being treated as "partition complete." Given ~240K existing partitions across 9 S3 prefixes and 6 consumer plugins, a correctness fix had to be backfill-compatible and rollout-gated.

## Decision

Every S3 Parquet write is paired with a sidecar JSON manifest at `{parquet_key}.manifest.json`. The manifest declares what the partition contains; consumers in STRICT mode fail closed on missing or mismatched manifests.

**Schema** (`finlet/ingestion/manifest.py`, `PartitionManifest` v1):

- `version: Literal[1]`
- `partition_key: str` — the parquet key
- `partition_type: PartitionType` — one of `date | ticker | series | singleton`
- `writer: str` — producer identifier (e.g. `ingest_yfinance_prices@<git-sha>`)
- `source: str` — data origin (`yfinance`, `databento`, `sec_edgar`, `fred`, `unknown_retroactive`, ...)
- `written_at: datetime`
- `row_count: int`
- `schema_hash: str` — `sha256:` prefix; key-order independent
- `parquet_sha256: str` — `sha256:` of the exact bytes put to S3
- `coverage: Coverage` — discriminated union over `CoverageDate | CoverageTicker | CoverageSeries | CoverageSingleton`, each with `universe_id: str | None` as a no-cost forward-compat hook for a future universe registry
- `retroactive: bool` — `True` only for manifests emitted by `scripts/backfill_manifests.py`

**Single chokepoint.** Every producer funnels through `S3ParquetWriter` (`finlet/ingestion/s3_writer.py`), which gained `upload_to_key` alongside `upload_date_partition` / `upload_partitioned` to cover ticker-, series-, and singleton-partitioned layouts. Direct `s3_client.put_object` is banned in ingest paths.

**Three-mode validation** via `FINLET_PARTITION_VALIDATION` env var, read once at process start through `settings.ingestion.partition_validation_mode`:

- `OFF` — skip validation (current default; preserves pre-invariant behavior).
- `WARN` — call `validate_partition`; log structured `partition_validation_failed` on mismatch; never raise.
- `STRICT` — call `validate_partition`; raise `PartitionValidationError` on any mismatch or missing manifest.

Consumer entry point: `validate_partition(s3_client, bucket, parquet_key, local_parquet_path, mode)` in `finlet/ingestion/manifest_reader.py`. Checks in order: manifest presence, `parquet_sha256` vs. observed bytes, `row_count` vs. observed, `schema_hash` vs. observed.

`universe_id` is producer-populated when a named universe drove the run (e.g. `us_equities_v1`); otherwise `None`. Consumers in v1 MUST treat it as opaque. Registry work is deferred — descriptive coverage already catches the audited failure mode.

## Alternatives Considered

- **Embedded Parquet metadata** — rejected. Backfilling ~240K existing parquet files to stamp retroactive manifests into their footers is 10-100x more expensive and risky than uploading tiny JSON sidecars. Also opaque to non-pyarrow tooling (`aws s3 cp ... | jq` is zero-friction against sidecars) and couples manifest schema versioning to Parquet schema.
- **DynamoDB partition registry** — rejected. Adds an external dependency (DynamoDB availability, IAM, quotas), a new failure mode (registry and lake out of sync), and no added correctness over sidecars co-located in the same bucket.
- **`_SUCCESS` marker file** (Hadoop-style) — rejected. Carries no row count, schema hash, or coverage information; only tells you "something finished writing." The audited failure mode (partial ticker coverage written as complete) still slips through.
- **Upfront universe registry with strict universe assertion** — deferred. That is a second invariant ("partition claims universe X, and X requires N tickers, and N matches") layered on top of the one this decision addresses. Descriptive coverage catches the failure mode we audited. Adding a registry later does not require a manifest schema migration — the `universe_id` field already exists.

## Consequences

- Every producer must funnel through `S3ParquetWriter`. New ingest scripts MUST use the writer; direct `put_object` is banned in ingest paths. Enforced by code review plus `rg "s3_client\.put_object" scripts/` returning zero matches.
- STRICT-mode consumers fail closed on missing / mismatched manifests — raising `PartitionValidationError`. WARN logs structured events; OFF preserves prior behavior.
- **Two-write failure mode.** Parquet is written first, manifest second. If manifest upload fails after 3 retries, `UploadResult.manifest_emitted=False` and `manifest_failures` lists the affected partition keys; the caller alerts. STRICT consumers on this partition fail closed until backfill re-emits. WARN / OFF match prior behavior. Deleting the parquet on manifest failure would create a worse state (data actually got to S3).
- **Retroactive manifests** (emitted by `scripts/backfill_manifests.py`) carry `retroactive=True`. Operators should treat STRICT confidence as lower on retroactive manifests until they age out or are re-verified at the next write; the ADR does not presume retroactive manifests have the same provenance as write-time ones.
- Memory / latency impact of STRICT is bounded: one extra `get_object` per partition read, plus a sha256 over the already-downloaded bytes and a `pq.read_table` the plugin would do anyway.
- Manifest schema evolution is independent of Parquet schema — the `version` field allows additive v2 fields without rewriting v1 sidecars.

## Rollout Plan

1. Code merged with `FINLET_PARTITION_VALIDATION=OFF` as the default (current state). No production impact.
2. Ops runs `scripts/backfill_manifests.py` against each S3 prefix:
   - `prices/daily/`
   - `news/daily/`
   - `fundamentals/quarterly/`
   - `edgar/filings/`
   - `edgar/insider_trades/`
   - `edgar/institutional_holdings/`
   - `economic/fred/`
   - `reference/sentiment/`
   - `reference/sectors.parquet`
   Estimated ~2 hours at 16 workers for ~240K partitions. Supports `--dry-run` and `--resume` with checkpointing every 1000 keys.
3. Flip `FINLET_PARTITION_VALIDATION=WARN` in prod. Observe `partition_validation_failed` structured events for 7 days. Investigate any false positives before proceeding.
4. If no false positives, flip to `STRICT`. This ADR is updated to "Rollout complete" only after STRICT has been stable for 7 more days.

**Current rollout state: NOT YET STARTED.** Code is on main; production runs in `OFF`.
