# Dashboard `llms.txt` Regen Pipeline + Freshness Guard

**Status:** Accepted (2026-05-15)
**Triage iteration:** `USER_MANUAL_OVERHAUL_EXECUTION_PLAN` (Team A foundation + Team D dashboard polish, merged 595390e)
**Affected files:** `finlet/manual/generate_llms_txt.py`, `dashboard/llms.txt`, `scripts/lint-llms-txt-fresh.sh`, `scripts/git-hooks/pre-commit`, `.github/workflows/ci.yml`.

## Context

`dashboard/llms.txt` is the agent-parseable site index served at `https://finlet.dev/llms.txt` per the llmstxt.org convention. Pre-overhaul it was hand-maintained — every change to a manual topic (rename, summary tweak, see-also update) required a second commit to keep the public index synchronized, and the two surfaces silently desynchronized whenever an author forgot the second step. Agents that scraped `llms.txt` on Monday saw a topic list that diverged from the registry the CLI actually shipped.

## Decision

Generate `dashboard/llms.txt` deterministically from the canonical `TOPIC_REGISTRY` in `finlet/manual/registry.py`, with a freshness gate at three layers: pre-commit, CI lint, and a writable `--write` mode for authors.

1. **Generator module.** `finlet/manual/generate_llms_txt.py` exposes two modes:
   - `python -m finlet.manual.generate_llms_txt --write` regenerates `dashboard/llms.txt` in place. Authoring path.
   - `python -m finlet.manual.generate_llms_txt --check` re-runs the generator into a buffer and diffs against the on-disk file. Exits 1 on drift, 0 on match.
   The generator is deterministic — same registry + same content produces identical bytes including trailing newlines. This is the property the gates exercise.

2. **Pre-commit hook (4th guard).** `scripts/git-hooks/pre-commit` (installed by `scripts/setup-git-hooks.sh`) gains a fourth lint after trusted-types, event-bus, and dashboard-form-dirty: `scripts/lint-llms-txt-fresh.sh` wraps `--check` and prints the remediation `python -m finlet.manual.generate_llms_txt --write` on drift. Authors who edit a topic .md without regenerating the index cannot commit.

3. **CI lint step.** `.github/workflows/ci.yml` runs the same `--check` invocation in the matrix job — catches drift introduced by a workspace that bypassed the local hook, and provides the canonical green/red badge for PR review.

4. **Positive paths allowlist.** `.github/workflows/ci.yml` flips from `paths-ignore` to a positive `paths` allowlist that explicitly includes `finlet/manual/**`, `dashboard/llms.txt`, and `scripts/lint-llms-txt-fresh.sh` so the freshness lint runs on the exact diff surface it gates.

## Alternatives Rejected

1. **Hand-maintained `dashboard/llms.txt` + reviewer-enforced regen.** Status quo pre-overhaul; the silent-desync failure mode is the bug we're closing.

2. **Server-side dynamic render at request time.** Would couple the public `/llms.txt` endpoint to the manual package import, eliminating the static-file simplicity that lets the dashboard ship without an extra route handler. Static + drift-gate is cheaper than dynamic + cache-invalidation.

3. **Regenerate on every `git push`.** A push-time hook can't be enforced for contributors who push directly without our hook installed; pre-commit + CI lint is the load-bearing pair. Push-time would also race CI for the publication artifact.

## Consequences

- `dashboard/llms.txt` is generated artifact, not authored. Authors edit `finlet/manual/<topic>.md` + `registry.py`; the generator owns the index render.
- Drift is impossible to land — pre-commit catches it locally, CI catches it on PR, and `--write` is the one-command remediation when the lint flags drift.
- The generator's deterministic property is testable: the CI `--check` step is the same code path an author runs locally; no environment-specific output drift.
- Adding a new manual topic is a 3-edit change: new `.md` file in `finlet/manual/`, new `TopicMeta` row in `registry.py`, run `--write` (or let pre-commit prompt for it). The public llms.txt picks up the new entry deterministically.
- Future "freshness timestamp on llms.txt" surface (recorded as a follow-up TODO) is an additive extension — the generator can emit a `generated_at` comment without breaking the determinism contract because the comment is part of the deterministic output.

## Verification

- `tests/test_manual_generate_llms_txt.py` — exercises both `--write` (idempotency) and `--check` (drift detection on a tampered file).
- `scripts/lint-llms-txt-fresh.sh` is invoked in three places: pre-commit hook, CI lint job, manual one-off run. All three call the same `--check` mode.
- `dashboard/llms.txt` on the live site (`curl https://finlet.dev/llms.txt`) matches the deterministic output for the current `main` HEAD — verifiable byte-for-byte.

## References

- `finlet/manual/generate_llms_txt.py` — the generator + `_llms_txt_body(base_url)` deterministic body builder.
- `finlet/manual/registry.py` — `TOPIC_REGISTRY` ordering owns the index ordering.
- `scripts/lint-llms-txt-fresh.sh` — the shell wrapper around `--check` invoked by both pre-commit and CI.
- `scripts/git-hooks/pre-commit` — 4th guard block (lines ~118-140).
- `.github/workflows/ci.yml` — positive paths allowlist + `--check` step.
- `docs/decisions/error-anchor-convention.md` — sibling decision: the canonical errors topic that this pipeline keeps synchronized with the public index.
