# Decision: Buffer-and-Replay for Equity Curve Chart-Init-vs-SSE-Data Race

**Date**: 2026-04-29
**Status**: Accepted

---

## Context

Bug-hunt iteration `20260429T052717Z1a13` flagged the Equity Curve panel as broken: after creating a session and placing a MARKET BUY for 5 AAPL (order filled at $209.44, cash correctly dropped to $98,952.81), the chart showed only the TradingView watermark — no equity line, no buy-and-hold benchmark, no data at all. The bug persisted across page reload.

Root cause: `renderEquityCurve(history, ordersData)` in `dashboard/app.js` had an early-return guard at the top:

```js
function renderEquityCurve(history, ordersData) {
    if (!equityChart) return; // chart library not loaded
    // ... render path ...
}
```

When the SSE `history` event fired before `initChart()` finished resolving (slow CDN, race-y init order, or any future code path calling `renderEquityCurve` first), the early return silently dropped the payload. The chart then sat empty — no replay mechanism, no error log, no observable signal that a payload had been lost.

This is a generic "consumer not ready" bug shape: the producer (SSE event listener) is event-driven and could fire any time after subscribe; the consumer (chart) has an asynchronous init that depends on a CDN bundle. Without a coordination mechanism, payloads in flight during the init window are lost.

---

## Decision

Buffer the latest history payload at the early-return site; replay it at the end of `initChart()` once the LightweightCharts series are ready.

### Implementation

```js
// Module-scope buffer for the most recent equity-history payload received
// before the chart was initialized. Always overwritten by latest history;
// never grows unbounded.
let _pendingEquityHistory = null;
let _pendingEquityOrders = null;

function renderEquityCurve(history, ordersData) {
    if (!equityChart) {
        // Chart not initialized yet. Buffer the latest payload so
        // initChart() can replay it. Always store the freshest history —
        // older buffers are silently overwritten.
        _pendingEquityHistory = history;
        _pendingEquityOrders = ordersData;
        return;
    }
    // ... render path ...
}

function initChart() {
    // ... chart setup ...

    // Replay any history payload that arrived before the chart was ready.
    if (_pendingEquityHistory != null) {
        const bufferedHistory = _pendingEquityHistory;
        const bufferedOrders = _pendingEquityOrders;
        _pendingEquityHistory = null;
        _pendingEquityOrders = null;
        renderEquityCurve(bufferedHistory, bufferedOrders);
    }
}
```

The buffer is module-scoped (single producer, single consumer), idempotent (always overwritten by latest), and bounded (one slot, never grows). Replay happens exactly once at the tail of `initChart()` and the buffer is cleared atomically before replay.

---

## Alternatives Considered

### (a) Hard-init order: load LightweightCharts synchronously before subscribing to SSE

Block SSE subscription until `initChart()` resolves. Conceptually clean — the consumer is always ready when the producer fires.

**Rejected because:**
- Requires reordering the dashboard bootstrap sequence (currently SSE subscribes early so we don't miss server events during init).
- Forces every dashboard surface that depends on LightweightCharts to wait for the same CDN load, even if they don't render until later.
- Doesn't help if a future code path calls `renderEquityCurve` BEFORE `initChart()` for any reason — the early-return would still drop the payload.
- Buffer-and-replay defends against the bug class (consumer-not-ready early return drops payload), not just this specific timing.

### (b) Re-fetch on init complete

At the end of `initChart()`, hit `/v1/sessions/{id}/portfolio/history` to grab a fresh history payload. Avoids module-scope state.

**Rejected because:**
- Extra network round-trip for data we already received via SSE.
- Race window between fetch start and SSE delivery is wider than the buffer-and-replay window.
- Doesn't help if the fetch fails or returns stale data — the SSE handler already had the freshest payload in its hand.

### (c) Buffer-and-replay (chosen)

Already described above. Cheapest, smallest blast radius, defends against the entire bug class.

---

## Consequences

### Positive

- Equity curve renders the first available history snapshot, no matter the order of `initChart` and SSE delivery.
- No extra network calls.
- Generalizes to any future code path that calls `renderEquityCurve` before init completes.
- The buffer is observable in tests via `window.__finletEquitySeries.data().length` — the regression test in `tests/e2e/journey-04-dashboard.spec.ts` exercises the full path (place MARKET BUY, advance clock, assert at least one rendered point).

### Negative

- Adds module-scope state (`_pendingEquityHistory`, `_pendingEquityOrders`). Mitigation: bounded to one slot, atomically cleared before replay, naming convention (`_pending*`) signals "internal staging".
- Buffer holds a reference to the payload until `initChart()` runs (possibly indefinitely if init never fires). Mitigation: `initChart()` is called unconditionally at startup; any path that doesn't reach it has a deeper bootstrap bug.
- Tests now read chart state via `window.__finletEquitySeries` (exposed for test introspection). Production code does not use these handles — they are test-only and named with `__` prefix to flag that.

---

## Reversal Path

Single revert. Three changes (buffer declarations, early-return write, init-tail replay) all live in `dashboard/app.js`. Revert removes ~25 LOC.

If the buffer-and-replay path causes a regression (e.g., infinite render loop because replay re-triggers the early-return), the fallback is option (a) — block SSE subscription until `initChart()` resolves.

---

## Related

- Bug-hunt iteration: `docs/bug-hunt/20260429T052717Z1a13/`
- Fix commit: `3379fdf` (Team C)
- Server-side gap (open follow-up): `docs/REMAINING_TASKS.md` — `Session.fill_order()` does not snapshot the portfolio after a fill, so the equity curve only updates on clock tick. Client-side buffer-and-replay shipped here is the defensive half; the engine snapshot-after-fill is the durable half.
- Lesson: `docs/LESSONS.md` — "Initialize the consumer before the producer when the consumer has an early-return guard. If you can't, buffer the latest payload and replay on init-complete."
