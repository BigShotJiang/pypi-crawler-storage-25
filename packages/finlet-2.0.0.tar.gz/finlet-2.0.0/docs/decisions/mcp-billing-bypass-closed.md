# Decision: MCP Billing-Bypass Closed by Sinking Cross-Cutting Gates Into the Service Layer

**Date:** 2026-05-07
**Status:** Resolved
**Source:** MCP-First Migration Phase 2; audit finding C1 (final commit `82959df`)

## Context

Pre-Phase-2, MCP tools in `finlet/mcp/server.py` and `finlet/mcp/tools_trading.py` called the service layer directly for business logic (order submission, plugin queries) but the four cross-cutting gates lived **above** the service in REST route handlers:

- Per-tier session-creation rate gate (FREE / PRO / etc. concurrent + cumulative limits)
- Per-user trade rate gate
- Per-user market-data rate gate
- Per-user Finnhub plugin rate gate (for `news` / `fundamentals`)

The call shape was `MCP -> service -> business logic`, with **no gate in the MCP path**. This was a billing-bypass: paid-tier rate limits did not apply when an agent reached Finlet via MCP instead of REST. An agent on the FREE tier could create unbounded sessions, fire unlimited trades, or hammer Finnhub with arbitrary throughput by switching from `httpx` to the MCP stdio transport — every gate that justified our pricing tiers was a no-op there.

The 2026-05-06 MCP audit flagged this as audit finding **C1** (Critical). It also surfaced two High findings that compounded the problem:

- **H4** — The MCP `_query_plugin` envelope dropped `rate_limit_remaining` / `rate_limit_reset` even when the plugin returned them, so agents had no way to pace themselves even if a future gate were added.
- **H6** — MCP `submit_order` returned a bare `to_dict(...)` shape that stripped `commission`, `slippage_amount`, and `total_cost` — agents could not see the actual cash impact of a fill via MCP.

## Decision

Sink all four gates into the service layer (`finlet/api/services/*.py`). REST and MCP both call the service. The service fires the gate. Both surfaces inherit identical gating by construction.

Specifically:

| Gate | Service module | Function |
|------|----------------|----------|
| Per-tier session creation | `session_service.py` | `check_session_creation_rate` + `record_session_creation` |
| Per-user trade rate | `trade_service.py` | `check_trade_rate` + `record_trade_request` |
| Per-user market-data rate | `market_service.py` | `check_market_data_rate` |
| Per-user Finnhub plugin rate | `market_service.py` | `check_plugin_rate` for `news` / `fundamentals` (gated by `PLUGIN_RATE_LIMITED_TYPES` frozenset) |

Trade idempotency (`_idempotency_store`) also moved to `trade_service.py` as a module-level singleton so REST and MCP share the same replay cache. Session-create idempotency intentionally **stays** in `routes_session.py` — it's REST-specific defense-in-depth (the `Idempotency-Key` HTTP header has no equivalent transport on FastMCP stdio).

The `_NON_TEMPORAL_PLUGIN_TYPES`, `_NON_TEMPORAL_ACTIONS`, and `PLUGIN_RATE_LIMITED_TYPES` frozenset constants are owned exclusively by `market_service.py`. Re-defining them in `routes_*.py` or `mcp/` is forbidden — the rule is codified in `.claude/rules/api-routes.md`.

## Implementation

Five sequential merges + one fix-agent commit, by team:

1. **Team A (commit `2321c53`)** — `finlet/api/services/errors.py` foundation (`ServiceError` envelope) + `validate_session_id` parity in `finlet/mcp/auth.py::_get_session`.
2. **Team B (commit `d5b4f1a`)** — `session_service` absorbs the per-tier session-creation gate.
3. **Team C (commit `cb11fc6`)** — `trade_service` absorbs the per-user trade gate + idempotency cache + rich-shape return (closes audit H6).
4. **Team D (commit `1c4aa2c`)** — `market_service` absorbs the per-user market-data + Finnhub plugin gates + frozenset SSOT collapse (closes audit H4).
5. **Fix-agent (commit `858ae7d`)** — aligns test session_id literals with `validate_session_id` format after Team A.
6. **Team E (commit `e5773c0`)** — cross-surface gate parity tests in `tests/services/test_gate_unification.py`.

Final close-out commit: `82959df`.

## Consequences

- MCP and REST limiter state is shared via the service layer. A 429 raised on one surface immediately throws on the other (asserted by `tests/services/test_gate_unification.py`).
- The four parity assertions in `test_gate_unification.py` are the hard regression bar against future drift. New gate-bearing service functions MUST extend that file with a parity case before merge.
- Trade idempotency cache is now MCP-aware; session idempotency stays REST-only by design.
- Audit findings closed: **C1** (billing-bypass), **H4** (MCP envelope drops rate_limit fields), **H6** (MCP `submit_order` bare `to_dict`).
- The `ServiceError` envelope (frozen Pydantic model with `to_http_exception` / `to_mcp_dict` / `to_mcp_shallow` converters) is the cross-surface error contract. New gate failures emit `ServiceError(...)` once; each surface materializes its own wire format. See `docs/decisions/service-layer-error-envelope.md`.
- Phase 2 routes use `to_mcp_shallow()` for the new MCP rate-limit conversions to avoid breaking ~30 existing MCP tests that pattern-match `isinstance(result["error"], str)`. Future MCP tools should default to `to_mcp_dict()` for richer error context.

## Alternatives Considered

1. **Patch each MCP tool to call the gate inline.** Rejected — the audit found this is exactly how the original drift happened. Inline gates in MCP tools would have duplicated the REST gate code, drifted on the next limiter change, and offered no structural guarantee that future tools added the gate. Sinking into the service is the only fix that makes the gate impossible to forget.
2. **Force the nested `to_mcp_dict()` envelope on all MCP error returns.** Rejected — it would break Phase 1's `_resolve_session` callers and ~30 existing MCP tests that pattern-match the shallow shape. Phase 2 keeps both shapes; new code prefers the nested form.
3. **Move session-create idempotency into the service.** Rejected — the `Idempotency-Key` HTTP header is REST-specific, FastMCP stdio has no equivalent. Keeping that store in `routes_session.py` keeps the service layer transport-agnostic.
