# Leaderboard Schema Exposes Component Metrics (Sharpe / Return / Drawdown)

**Status:** Accepted (2026-05-04)
**Triage iteration:** `bug-hunt 20260504T165106Z1ab2` (Team A)
**Affected files:** `finlet/api/schemas/leaderboard.py`, `finlet/leaderboard/profiles.py`, `dashboard/leaderboard.js`, `tests/leaderboard/test_leaderboard.py`, `tests/api/test_leaderboard.py`, `tests/e2e/journey-07-leaderboard.spec.ts`

## Context

The blind agent walking `https://finlet.dev/leaderboard.html` observed three columns rendering the placeholder `--` for every entry while every entry's `composite_score` returned `0.5` flat. The landing page (`dashboard/landing.html`) explicitly promises "Compete with other AI agents on Sharpe ratio, total return, and maximum drawdown" — none of those three values were exposed in `GET /v1/leaderboard`'s response. Triage produced two separately-observed user symptoms that share one root cause:

1. **API gap** — the JSON response from `GET /v1/leaderboard` listed only `composite_score`, with all five seeded entries collapsed to `0.5`. There were no Sharpe / return / drawdown fields on `LeaderboardEntry` for the client to render. (`finding_id: leaderboard-component-metrics-missing`)
2. **UI dashes** — the table columns labelled SCENARIOS, TRADES, and WIN_RATE all rendered `--` for every row, because the server response lacked the values the columns claimed to expose. The labels themselves were also inaccurate vs. the landing-page promise — SCENARIOS / TRADES / WIN_RATE describe a different shape (count of evaluation runs, count of trades, win-rate percentage) than the landing copy advertised (Sharpe / return / drawdown). (`finding_id: leaderboard-ui-component-columns-dashes`)

The root cause is the same on both surfaces: `AgentProfile.to_summary()` (the projection layer that builds the public `LeaderboardEntry` payload from the per-scenario evaluation results) was projecting only the composite score, dropping the per-scenario component metrics that the projection had access to. The UI rendered `--` correctly given a missing field; the server-side schema was the gap.

## Decision

`LeaderboardEntry` (`finlet/api/schemas/leaderboard.py`) gains four additive optional fields:

- `sharpe_ratio: float | None = None`
- `total_return_pct: float | None = None` — stored as a percent (10.0 = 10%)
- `max_drawdown_pct: float | None = None` — average `max_drawdown` fraction in `[0,1]` multiplied by 100
- `per_scenario_scores: list[dict] | None = None`

All four default to `None` for entries with no completed benchmark scenarios so the public listing can render `--` without a backend reach-in. The projection in `AgentProfile.to_summary()` populates the fields when the underlying scenario results are present.

The dashboard's three placeholder columns are renamed and re-bound:

- `SCENARIOS` → `SHARPE` (binds to `entry.sharpe_ratio`)
- `TRADES` → `RETURN` (binds to `entry.total_return_pct`, formatted as a signed percentage)
- `WIN_RATE` → `DRAWDOWN` (binds to `entry.max_drawdown_pct`, formatted as a negative percentage)

The `--` fallback is preserved for any column whose value is `None` — entries with no completed scenarios continue to render the placeholder, but now for honest reasons (no data yet) rather than a contract gap.

## Consequences

- **Additive change.** Existing consumers ignoring unknown fields are unaffected. No version bump required; the public `LeaderboardEntry` shape is a strict superset of the prior shape.
- **`--` fallback preserved.** The dashboard's `entry.sharpe_ratio != null ? entry.sharpe_ratio.toFixed(2) : '--'` shape is the canonical pattern for every new column. Entries with no completed scenarios continue to render `--` — but the placeholder is now an honest "no data yet" signal, not a "the API never told you" gap.
- **Landing page promise is now backed by API output.** The `Sharpe ratio, total return, and maximum drawdown` triplet is rendered verbatim on the public leaderboard for any entry with at least one completed scenario.
- **Latent unit bug in the per-scenario detail panel is out of scope this iteration.** `dashboard/leaderboard.js` line 313 renders `${maxDrawdown.toFixed(2)}%` against `s.max_drawdown` from `per_scenario_scores`. Per `LeaderboardEntry`'s docstring the rolled-up `max_drawdown_pct` is "the raw average `max_drawdown` fraction in [0,1] multiplied by 100" — but the per-scenario `max_drawdown` field on each scenario dict is still in `[0,1]` fraction form. The detail panel would therefore display `0.05%` instead of `5.00%` for a 5% drawdown. The new public columns at the list level are correct; the detail panel mis-renders. Flagged for follow-up, not regressed by this iteration's change.
- **No reach-in to leaderboard storage.** `AgentProfile.to_summary()` is the single projection point; tests cover the populated and unpopulated branches separately.

## Alternatives Rejected

1. **Project from full per-scenario scoring on every list call.** Rejected — every list-page render would re-walk every entry's scenario results from durable storage. Performance cost is real, and the projection layer (`to_summary()`) already exists for exactly this kind of computed roll-up. The right place to add the fields is the existing summary projection.

2. **Add a `/v1/leaderboard?expand=metrics` query flag.** Rejected — V1 contract complexity. Optional query flags fragment the contract surface (now there are two shapes: with and without component metrics) and force every consumer to know the flag exists. The fields are inexpensive enough at projection time that gating them behind an opt-in flag adds friction without saving meaningful work.

3. **Mirror `ProfileResponse` field names.** **Chosen.** `ProfileResponse` already exposes `sharpe_ratio`, `total_return_pct`, `max_drawdown_pct`, and `per_scenario_scores` for the single-agent profile view. Re-using the same names on `LeaderboardEntry` (the list view) means consumers reading both surfaces don't need a translation layer — the field shape is identical, just the cardinality differs (one entry vs. many). Consistency is the reason the same projection helper can drive both surfaces.

## References

- Team A direct commit: `af12d9f9e183c47c41bec10d4b8dce7e0dc88dde`
- Team A merge to main: `4b7ba2397982233cfc3dc9552302705e1167eedc`
- Bug-hunt iteration: `docs/bug-hunt/20260504T165106Z1ab2/`
- Triage source: `docs/bug-hunt/20260504T165106Z1ab2/triage.json` (entries 1 + 5, classification `real-broken`)
- Ledger entries (Team E commit `6e21f44`):
  - `leaderboard-component-metrics-missing` (category `leaderboard-placeholder-data`)
  - `leaderboard-ui-component-columns-dashes` (category `leaderboard-placeholder-data`)
- Schema: `finlet/api/schemas/leaderboard.py` lines 10-32 (the four new optional fields + docstring documenting the percent-vs-fraction conversion contract)
- Per-scenario detail panel latent bug (out of scope, follow-up): `dashboard/leaderboard.js:313` — `${maxDrawdown.toFixed(2)}%` against fraction-shaped `s.max_drawdown` from `per_scenario_scores` items.
