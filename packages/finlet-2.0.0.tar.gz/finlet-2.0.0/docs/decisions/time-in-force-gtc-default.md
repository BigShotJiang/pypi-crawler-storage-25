# Decision: TimeInForce Default is GTC (Backwards Compatible)

**Date:** 2026-04-06
**Status:** Accepted
**Source:** v0.1.0 Launch Execution, Team B

## Context

Orders previously had no time-in-force concept -- all pending orders persisted indefinitely until filled or cancelled. Adding DAY expiry required choosing a default that wouldn't break existing API consumers or stored orders.

## Decision

`TimeInForce` enum added with two values: `DAY` (expires at end of trading day) and `GTC` (good til cancelled). **GTC is the default.** This preserves the pre-existing behavior where orders remain pending across clock advances until filled or explicitly cancelled.

DAY orders are expired (status set to CANCELLED, reject_reason = "DAY order expired") during `OrderBook.process_pending_orders()` before fill attempts, when `sim_time.date() > order.submitted_at.date()`.

## Alternatives Considered

- **DAY as default** — More realistic (most real brokerages default to DAY), but would silently change behavior for all existing API consumers and MCP tool callers. Rejected because breaking backwards compatibility outweighs realism in an evaluation harness.
- **No default (required field)** — Would force all callers to specify TIF on every order. Rejected because it adds friction for no evaluation benefit; agents can always opt into DAY explicitly.

## Consequences

- All existing orders and API consumers continue to work without changes (GTC is the implicit prior behavior)
- New callers can opt into DAY expiry via `time_in_force: "DAY"` in REST API, MCP tools, or `--tif DAY` in CLI
- The `time_in_force` field is added to Order model, trade schema, routes_trade.py, session.py, and trade_service.py
