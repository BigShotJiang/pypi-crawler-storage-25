# Decision: Dashboard Modal Controller

**Date**: 2026-04-28
**Status**: Accepted

---

## Context

Two consecutive bug-hunt iterations (`20260428T013300Z6e79`, `20260428T163727Z4f4f`) shipped real-broken patches against modal stacking on the dashboard:

1. **`modal-stacking-leaderboard`** (`20260428T013300Z6e79`) — "Submit to Leaderboard" dialog blocked because the always-rendered "Create New Session" modal sat at the same `display:block` with no z-index coordination. User clicks landed on the wrong modal. Patched per-modal with `display:none` toggling on the older modal.
2. **Wizard-blocks-create-session** (`20260428T163727Z4f4f`) — onboarding wizard overlay (`#onboarding-overlay`, z-index 500, `pointer-events: auto`) sat above the spawned Create Session modal (z-index 300) and intercepted every click. `document.elementFromPoint(submitX, submitY)` returned the overlay, not the submit button. Patched with a one-off z-index bump.

Same shape across both iterations: two modals/overlays open simultaneously, the older is visually behind but pointer-events-active, the newer is unreachable. Each fix has been a per-modal hack. No convention existed for "newest modal owns the input layer."

Root cause: dashboard modals coordinated visibility manually. Each modal had its own hard-coded z-index (300, 400, 500, ...), its own show/hide mechanism (`classList.toggle('hidden')`, `display: block`, `removeAttribute('hidden')`), and its own pointer-events posture (some had `pointer-events: auto` even when "hidden"). There was no central authority that said "while modal X is open, modals Y and Z are pointer-events: none and behind X in z-order, regardless of how they were shown." Adding a new modal required a developer to know every other modal that might co-exist with theirs. Step (b) of any "find every modal that might collide" check failed silently every iteration. That was the recurrence.

Modal stacking is the third-most-touched dashboard surface (after onboarding and trade-ticket), so a third recurrence under the ad-hoc convention was a near-certainty.

---

## Decision

Introduce a single dashboard modal-controller authority, codified in `dashboard/modal-controller.js`, with declarative markup applied across all modal consumers.

### 1. The controller

```js
const closeHandle = window.finletModal.open('create-session-modal');
window.finletModal.close('create-session-modal');
window.finletModal.suppress('onboarding-overlay', 'create-session-modal');
window.finletModal.topmost();   // string | null
window.finletModal.isOpen('create-session-modal');  // boolean
```

The controller maintains an internal stack of currently-open modal IDs (`Array<string>`). On `open(id)`:

- pushes `id` onto the stack
- sets `element.style.zIndex = base + stack.length` where `base` is read from `--modal-base-z` (CSS var on `:root`, default `1000`)
- sets `element.style.pointerEvents = 'auto'`
- clears `element.style.display` (drops the belt-and-suspenders inline `display:none`)
- adds `.fl-modal--visible` class so CSS transitions fire
- forces every other open modal to `pointer-events: none` and a lower z-index

On `close(id)`: splices out, sets `display:none`, removes the visible class. The new topmost (if any) reclaims `pointer-events: auto` and the highest z-index. The `suppress(suppressor, target)` rule forces `suppressor` to `pointer-events: none` + `z-index: 0` whenever `target` is in the open stack — used by the onboarding overlay so it stops intercepting clicks while Create Session is open. The rule auto-restores when the target leaves the stack.

The controller mirrors `dashboard/event-bus.js`'s singleton + idempotent-attach module pattern. Only `window.finletModal` is exposed (`Object.freeze`'d); bare globals are not leaked.

### 2. Declarative markup

Every dashboard modal element MUST be tagged with:

- `data-modal-id="..."` attribute (the controller looks up by this ID)
- `.fl-modal` CSS class (defaults to `pointer-events: none; z-index: 0;`)

Per-modal hard-coded z-index values are forbidden. Z-order is owned by the controller and the `--modal-base-z` CSS variable.

### 3. Compat shim during incremental migration

A temporary CSS shim in `dashboard/styles.css` (`/* TEMP: compat shim — remove when ... */`, lines ~70-122) aliases legacy modifier classes (`modal-overlay--visible`, `session-details-panel--open`) to `.fl-modal--visible` so unmigrated consumers stay interactive. The settings page is the only remaining unmigrated consumer; once migrated, the shim can be deleted.

---

## Consequences

### Positive

- **Structural elimination of the recurrence shape.** Future modals cannot drift into the "wrong layer is interactive" bug class because z-order and pointer-events are owned centrally.
- **New modals are mechanical to add.** Tag with `data-modal-id` + `.fl-modal`; call `window.finletModal.open(id)`. No need to reason about every other modal that might co-exist.
- **`suppress()` makes overlay-vs-modal interactions explicit.** The onboarding overlay declares its suppression rule once; the controller enforces it across every overlap.
- **Reversal path is a single revert per merge commit (~30 minutes).** The controller is one file; consumer migrations are mechanical.

### Negative

- **One more dashboard module to load.** `dashboard/modal-controller.js` is a new file plus one `<script>` tag in pages that wire modals.
- **Compat shim in CSS until settings.html is migrated.** Tracked in `docs/REMAINING_TASKS.md`. Until then, two visibility paths coexist (legacy modifier classes + controller). Removing the shim is a single mechanical cleanup pass.
- **No runtime validation that a `data-modal-id` element has the `.fl-modal` class.** Convention enforced by review and the migrated consumer set. A future lint rule could grep for `data-modal-id` without `.fl-modal` and vice versa.

### Trade-offs explicitly chosen

- **Inline style + class hybrid over pure CSS class.** The controller writes `style.zIndex`, `style.pointerEvents`, `style.display` directly because the stack-position-driven values are dynamic. CSS transitions still fire off the `.fl-modal--visible` class.
- **No focus trapping (a11y) in this iteration.** Out of scope per the refactor plan; a future a11y pass can build on top of this controller.
- **`suppress()` registers persistently until the target closes.** No clear API yet — none of today's call sites need it. Adding a clear path is straightforward when the first consumer needs it.

---

## References

- Plan: `docs/refactor/modal-stacking/plan.md`
- Implementation: `dashboard/modal-controller.js`, `dashboard/styles.css` (CSS variables + compat shim), `dashboard/index.html` (declarative `data-modal-id` markup), `dashboard/app.js`, `dashboard/leaderboard-submit.js`, `dashboard/onboarding.js`
- Tests: e2e regression spec covering both recurrence shapes (leaderboard + create-session, wizard + create-session)
- Recurrence ledger: `docs/bug-hunt/ledger.jsonl`
- Refactor queue entry: `docs/bug-hunt/refactor-queue/modal-stacking.md`

---

## Addendum — Visibility-via-class contract (2026-05-05, bug-hunt `20260505T213116Z45f1` Team B)

### Context

The original 2026-04-28 controller decision flipped `z-index` and `pointer-events` on stack members but did NOT touch `display` / `visibility` / `opacity`. The semantic gap surfaced as a third recurrence in iteration `20260505T213116Z45f1`: opening Create Session while the onboarding wizard was on the stack (`suppress('onboarding', 'create-session')` registered) left the wizard visually painted on top of the new modal. Pointer-events flowed correctly to the create-session form, but the user saw two stacked dialogs. The blind-agent report ("Both dialogs were visible and active at the same time") matched the gap exactly: visible (yes — `display` still set by `.fl-modal--visible`) but only one interactive (`pointer-events: auto` on top, `pointer-events: none` on suppressed).

### Decision

`applyStackLayout()` additionally toggles a new `.fl-modal--hidden` class per stack-walk: top stack member → class removed; non-top members AND suppressed modals → class added. CSS rule `.fl-modal.fl-modal--hidden { display: none !important; }` is scoped to `.fl-modal` so non-`.fl-modal` surfaces (the trade-ticket `<aside class="trade-ticket">`, slide-out panels) are unaffected. `close()` also strips `.fl-modal--hidden` from the closed element so re-opening starts from a clean class set.

### `display: none` vs `visibility: hidden + opacity: 0` — trade-off

Chose `display: none !important`. Rationale:

- The original regression was paint-tree occlusion — the wizard's foreground paint sat on top of the new modal. `visibility: hidden + opacity: 0` keeps the element in the paint tree (just transparent + non-clickable), which would NOT have eliminated occlusion if a future paint glitch or composite-layer ordering issue surfaced; `display: none` removes the element from the paint tree entirely.
- CSS transitions on these modals only run between rest-state (`display: none`) and visible-state, never between two visible-state members of the stack — so dropping transitions on the underlying member when it gets hidden is acceptable. (The `.fl-modal--visible` class transition still fires on the top member because it never gets `.fl-modal--hidden`.)
- `!important` was used because legacy modifier-class consumers (the compat shim) set `display: flex !important` to override the controller's inline `display: ''`; the new `.fl-modal--hidden` rule must beat the shim until the shim is removed.

### Reversal path

If a future surface needs the hidden modal to remain in the paint tree (e.g., for a CSS layout calculation that depends on the offscreen modal's dimensions), swap the rule to:

```css
.fl-modal.fl-modal--hidden {
  visibility: hidden !important;
  opacity: 0 !important;
  pointer-events: none !important;
}
```

The `applyStackLayout()` class-toggle behavior stays unchanged — only the CSS rule body changes. Verify the leaderboard and create-session regression specs still pass after the swap.

### Trade-ticket exception (load-bearing for this scope)

The trade-ticket panel (`<aside class="trade-ticket" id="trade-ticket-panel">`) is a deliberate non-`.fl-modal` element; its visibility is owned by the `.trade-ticket--open` class managed in `dashboard/trade-ticket.js`, NOT by `window.finletModal`. The new `.fl-modal--hidden` rule is scoped to `.fl-modal.fl-modal--hidden` so the trade-ticket aside is explicitly outside its blast radius. Code paths that need to close the trade-ticket MUST call `closeTradeTicket()` directly; delegating via `window.finletModal.close('trade-ticket-modal')` is a silent no-op (the controller's `findElement(id)` returns null because that id doesn't exist; the actual id is `trade-ticket-panel` and the element lacks the `.fl-modal` class). Documented in `docs/ARCHITECTURE.md` trade-ticket section.

### References

- Implementation: `dashboard/modal-controller.js#applyStackLayout` (lines ~125-150), `dashboard/styles.css` (`.fl-modal.fl-modal--hidden` rule)
- Ledger: `docs/bug-hunt/ledger.jsonl` finding `modal-stacking-wizard-create-session-visible` (Team B, commit `3de270b`)
- Lesson: `docs/LESSONS.md` "pointer-events: none is not visibility"
