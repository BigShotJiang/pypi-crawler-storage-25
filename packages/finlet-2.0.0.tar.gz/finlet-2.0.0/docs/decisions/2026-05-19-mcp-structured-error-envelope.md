# Decision: MCP tool responses use a structured error envelope

Date: 2026-05-19
Status: shipped (MCP_BENCHMARK_FIXES batch, Team A — commit 1979a20)

## Context

Codex (GPT-5) drove Finlet's MCP benchmark tools during a head-to-head
evaluation and reported that on `start_benchmark` lockout and on
`get_benchmark_progress`, the bare `{"error": "<string>"}` returns omitted
every field needed to resume (session_id, scenario end_time, universe,
initial_capital, clock current_time, portfolio cash). Agents had to make
N follow-up tool calls to reconstruct context the server already knew.

## Decision

MCP tools that previously returned `{"error": "<string>"}` now return
`{"error": {"code": "<snake_case>", "message": "<human text>", **extra}}`.
The top-level `"error"` key is preserved so legacy callers that do
`if "error" in result` keep working unchanged; only the VALUE shape changes
from string to dict.

For benchmark tools specifically, error envelopes that occur on a session
carry a `resume_hint` extra field with the full canonical metadata. The
same canonical shape is returned from `get_benchmark_progress` on success
— single source of truth across error and success paths.

See `finlet/mcp/_errors.py:structured_error()` for the helper.

## Consequences

- Pre-launch (no consumers yet), no deprecation window needed.
- The structured envelope is the future-proof shape — adjacent MCP tool
  surfaces (tools_session, tools_portfolio, tools_market) should migrate
  to it incrementally; the helper is shared.
- Tests that previously asserted `result["error"] == "<string>"` had to
  update to `result["error"]["message"] == "<string>"` — 6 downstream
  test files updated in this batch.

## Out of scope (this batch)

Migration of `finlet/mcp/auth.py`, `finlet/mcp/bearer_context.py`,
`tools_session.py`, `tools_portfolio.py`, `tools_market.py` to the new
envelope. These continue to return flat strings; convert in a follow-up
when the surface is touched for another reason.
