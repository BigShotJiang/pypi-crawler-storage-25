# Decision: Dashboard Event Bus Convention

**Date**: 2026-04-28
**Status**: Accepted

---

## Context

Two consecutive bug-hunt iterations (`20260428T013300Z6e79`, `20260428T031818Z2efa`) shipped 14 real-broken patches against the dashboard. Cross-iteration recurrence analysis (see `docs/bug-hunt/POST_MORTEM_2026-04-28.md`, source ledger `docs/bug-hunt/ledger.jsonl`) found 10 of those 14 (71%) clustered in three categories:

- **onboarding-checklist** — 4 instances
- **dashboard-state-sync** — 3 instances
- **trusted-types** — 3 instances

Each iteration we patched one subscriber-to-event wiring at a time. Same shape, different file. The diagnosis: this was not 14 independent bugs — it was a missing-convention bug surfacing 14 different ways.

The dashboard had no event-bus convention. State changes propagated via four distinct mechanisms:

1. Direct `EventSource` consumers attached inside the consumer's open/close lifecycle (Trade Ticket).
2. Ad-hoc `window.dispatchEvent(new CustomEvent('finlet:portfolio-update', { detail }))` re-broadcast layered on top of SSE because the SSE handler couldn't be subscribed to directly.
3. `window.finletOnboarding?.markStepComplete?.('analysis')` reach-ins from the orders SSE handler at `dashboard/app.js:~1444`.
4. Bespoke per-row click wiring on the onboarding checklist with no contract for "row activated → mark step + advance counter."

When a feature shipped a new mutation, the author had to (a) pick a propagation mechanism, (b) find every consumer of the now-stale state, (c) wire each one manually, and (d) hope future authors found the wiring they didn't write. Step (b) failed silently every iteration. That was the recurrence.

For trusted-types specifically: the dashboard had a working `trustedHTML()` wrapper at `dashboard/api-utils.js:469`, but vendor bundles (TradingView lightweight-charts) and ad-hoc `innerHTML` calls bypassed it. There was no lint guard, so each new innerHTML call was one bug-hunt iteration away from a console violation.

---

## Decision

Introduce a single dashboard event-bus convention with the following shape, codified in `dashboard/event-bus.js` and contracted in `dashboard/event-contract.md`.

### 1. The bus

```js
const off = window.finletBus.subscribe('event:name', (payload) => { ... });
off(); // unsubscribe closure
window.finletBus.publish('event:name', payload);
```

Backed by `Map<event, Set<handler>>`. Subscriber errors are caught per-handler and `console.error`'d so one bad subscriber cannot break siblings. Iteration takes a snapshot before fan-out so a handler that unsubscribes mid-publish does not perturb the loop. The exposed surface is `Object.freeze`'d to prevent accidental mutation.

### 2. Four initial events (canonical contract)

Enumerated in `dashboard/event-contract.md`:

- `portfolio:updated` — full portfolio object (publisher: `app.js` SSE `portfolio` handler; subscribers: Trade Ticket cash header, future metric cards).
- `order:filled` — `{ ticker, quantity, side, fill_price }`, fields may be `null` if the SSE payload omitted them (publisher: `app.js` SSE `orders` handler on zero-to-one `filledCount` transition; subscribers: onboarding `analysis` step).
- `session:switched` — `{ session_id }` (publisher: `app.js` Create Session success branch; subscribers: onboarding `session` step).
- `onboarding:step-completed` — `{ step }` (publisher: `dashboard/onboarding.js`; subscribers: none initially — open for analytics surfaces).

Adding a new event requires updating `dashboard/event-contract.md` in the same commit. The contract is grep-validatable; the bus does not validate at runtime.

### 3. Onboarding state machine driven by `STEP_TRIGGERS`

`dashboard/onboarding.js` exposes a declarative `STEP_TRIGGERS` table mapping step keys to bus event names:

```js
const STEP_TRIGGERS = {
  profile: ...,
  session: 'session:switched',
  analysis: 'order:filled',
  strategy: null, // manual; checklist row click
};
```

Adding a new step requires only adding a row to `STEP_TRIGGERS` and the matching publisher elsewhere. No bespoke per-row click handlers. No `markStepComplete(...)` reach-ins from publishers.

### 4. Trusted-types pre-commit guard

`scripts/lint-trusted-types.sh` is a grep-based pre-commit hook that fails any commit which adds a bare `.innerHTML =` write under `dashboard/` outside a `trustedHTML(...)` wrap. Vendor files keep their patches via an explicit `// trusted-types-vendor-allowlist` comment marker. Install path: `scripts/setup-git-hooks.sh` symlinks `scripts/git-hooks/pre-commit` into `.git/hooks/`.

---

## Enforcement

The bus convention itself is now codified in a sibling pre-commit guard: `scripts/lint-event-bus.sh` (added 2026-05-05 in the convention-enforcement refactor). The script scans `dashboard/*.js` and `dashboard/*.html` (`<script>` blocks) for direct `addEventListener('finlet:...')` and `dispatchEvent(new CustomEvent('finlet:...'))` calls and rejects any match. The bus's own implementation (`dashboard/event-bus.js`) is allowlisted; future legitimate exceptions can opt out via the marker comment `// finlet-bus-lint-allowlist`. The pre-commit hook chains both lints in series — `scripts/git-hooks/pre-commit` runs `lint-trusted-types.sh --check` first, then `lint-event-bus.sh --check`; either failure blocks the commit. Install via `bash scripts/setup-git-hooks.sh` (idempotent symlink installer).

---

## Consequences

### Positive

- **Structural elimination of the three recurrence categories.** Future onboarding steps cannot drift because they're declarative. Future state-sync subscribers cannot miss the wiring because there is one convention. Future innerHTML writes are blocked at commit-time, not caught a bug-hunt iteration later.
- **Reversal path is a single revert per merge commit.** The bus module is one file; consumer migrations are mechanical. Rollback is ~30 minutes.
- **Lint guard prevents the next regression.** Trusted-types violations now fail at PR-time rather than after deploy.
- **Refactor pays for itself in 2-3 iterations.** Status quo cost was ~3 broken state-sync findings × ~1 hour patch = ~3 hours/iteration. Post-refactor: ~0 in those categories.

### Negative

- **One more dashboard module to load.** `dashboard/event-bus.js` is a new file plus one `<script>` tag in `index.html` (and any other page that wires bus consumers).
- **Runtime overhead.** `Map<event, Set<handler>>` lookup + iteration. Negligible at dashboard subscriber counts (single digits per event), but worth flagging for future high-frequency events.
- **No runtime validation of payload shape.** The contract doc is the validation. A typo in an event name silently no-ops; a missing payload field silently produces a `null`. Mitigated by: (a) the contract doc is grep-checkable, (b) every event has a publisher under `app.js` or `onboarding.js`, so the count of distinct event-name strings stays small, (c) Playwright E2E tests exercise the publisher-subscriber wiring end-to-end.

### Trade-offs explicitly chosen

- **Grep-based pre-commit hook over ESLint.** ESLint would give richer rule semantics and editor integration but requires standing up an ESLint config in a repo that has none and no JS bundler. A 50-line shell script ships in this iteration; an ESLint migration is a separate decision.
- **`Object.freeze` of the bus surface over module-pattern privacy.** No bundler means no module-pattern closure scope. Freezing the public object is the closest equivalent — accidental `window.finletBus.publish = ...` overwrites fail silently in non-strict mode and throw in strict. Tradeoff: privacy is convention-enforced, not language-enforced.
- **Single global `window.finletBus` over a module export.** Vanilla JS, no build step, no module imports across `<script>` tags — globals are how the dashboard already wires shared state. The bus follows the prevailing convention rather than introducing a competing one.

---

## References

- Motivation: `docs/bug-hunt/POST_MORTEM_2026-04-28.md`
- Plan: `docs/refactor/dashboard-event-bus/plan.md`
- Contract: `dashboard/event-contract.md`
- Implementation: `dashboard/event-bus.js`, `dashboard/app.js`, `dashboard/onboarding.js`, `dashboard/trade-ticket.js`
- Pre-commit guards: `scripts/lint-trusted-types.sh`, `scripts/lint-event-bus.sh` (sibling — codifies the bus convention since 2026-05-05), `scripts/git-hooks/pre-commit`, `scripts/setup-git-hooks.sh`
- Tests: `tests/dashboard/event-bus.spec.js` (node --test runner), `tests/e2e/journey-onboarding.spec.ts`, fill-driven cash-header case appended to `tests/e2e/journey-05-trade.spec.ts`
- Recurrence ledger: `docs/bug-hunt/ledger.jsonl`
