# Error Anchor Convention

**Status:** Accepted (2026-05-15)
**Triage iteration:** `USER_MANUAL_OVERHAUL_EXECUTION_PLAN` (Teams A + B1 + B2 + B3 + B4 + C, merged 595390e)
**Affected files:** `finlet/manual/errors.md` (source of truth) + ~200 error-envelope sites across `finlet/api/`, `finlet/billing/`, `finlet/auth/oauth/`, `finlet/mcp/`, `finlet/plugins/`.

## Context

Pre-overhaul, agent-facing error envelopes (REST `{"error": {"code", "message", "details"}}`, MCP `{"error": "..."}`, plugin `PluginResponse.error`) carried no machine-routable pointer back to authoritative docs. Per-error wording drifted between subsystems (REST `429` rate-limit string ≠ plugin rate-limit string ≠ MCP rate-limit string), so an agent that learned how to recover from one shape could not pattern-match the same failure on a different surface. The dashboard `setup.html` and `agent-guide.html` carried documentation that was hand-maintained and silently desynchronized from the live wording. Triage agents observing a 429 had no canonical doc anchor to link in a bug-hunt finding.

## Decision

Adopt a single kebab-case anchor namespace for all agent-facing errors, sourced from one document, suffix-appended to every envelope `detail` / `message` / `error` string.

1. **Single source of truth.** `finlet/manual/errors.md` defines 13 frozen kebab-case anchors, one per recoverable error class: `rate-limit`, `expired-token`, `missing-bearer`, `missing-scope`, `missing-api-key`, `plugin-timeout`, `plugin-malformed`, `plugin-rate-limit`, `transport-mismatch`, `port-conflict`, `date-ceiling-violation`, `invalid-session`, `order-rejected`. Each anchor has an `<a id="..."></a>` marker + a `##` heading with cause + recovery steps. The 13 are frozen by snapshot test (`tests/test_manual.py`) — renaming is a breaking contract change.

2. **Suffix convention.** Every error envelope's human-readable string ends with the literal suffix `See: finlet manual errors#<anchor>`. Example: `"Finnhub rate limit exceeded: 0/60 calls remaining, resets in 42 seconds. See: finlet manual errors#plugin-rate-limit"`. The suffix is appended at the call site, not by middleware — keeps the error string self-contained and grep-friendly. Anchor-suffixed sites total ~200 across REST (122 + billing), OAuth (33), MCP auth-required (19 dedup), and plugins (41).

3. **CLI surface for resolution.** `finlet manual errors#<anchor>` renders the anchored section locally (no network round-trip). The CLI's `manual` subcommand parses the URL-style suffix and dispatches to `registry.topic_to_json("errors")["sections"]` filtered by anchor — same data, same source.

4. **MCP `auth-required` dedup.** The 19 MCP tool sites that previously each minted their own `"Authentication required..."` string now reference the shared `_AUTH_REQUIRED_MESSAGE` constant in `finlet/mcp/auth.py`, which carries the `#missing-bearer` anchor suffix once. Eliminates per-tool drift.

## Alternatives Rejected

1. **Per-subsystem doc pages with bespoke anchor naming.** Would re-create the pre-overhaul drift — REST/billing/OAuth/MCP/plugin teams would each fork wording. The single `errors.md` is the load-bearing canonical surface; anchors are part of its public contract.

2. **HTTP-status-code-as-anchor (e.g. `#http-429`).** Conflates transport status with recovery semantics — a 429 from Finnhub rate-limit is recovered differently than a 429 from per-user trading rate-limit. The kebab-case anchor names recovery class, not status code.

3. **Machine-readable `error.details.anchor` field instead of string suffix.** Considered, but the existing envelope shape (`{"error": {"code", "message", "details"}}`) is consumed by ~200 sites and ~80 tests — adding a new structured field would have required diffing every consumer. The suffix is back-compat by construction: legacy clients see a longer string; new clients regex `See: finlet manual errors#(\S+)` and route.

## Consequences

- Every recoverable error class has exactly one canonical anchor. A triage agent observing a 429 cites `#plugin-rate-limit` or `#rate-limit` (per-user) and reaches the same recovery doc regardless of which subsystem surfaced the failure.
- Adding a new error class is a two-edit change: append the anchor + heading to `finlet/manual/errors.md`, append the suffix at the new throw site. The snapshot test in `tests/test_manual.py` catches drift between the registry and the live anchor count.
- The `finlet manual errors` CLI command is the operator's offline-first lookup — works on a plane, on an air-gapped CI runner, in a Docker image without network.
- The 13 frozen anchors are stable across `pip install finlet` upgrades. `CONTENT_VERSION` in `finlet/manual/registry.py` (currently `"1"`) bumps when the schema changes; agents can refuse to consume stale renders.

## Verification

- `tests/test_manual.py` — snapshot test asserts the exact 13 anchor IDs + ordering. Renaming or reordering breaks the gate.
- `tests/api/test_error_anchors.py` + `tests/billing/test_error_anchors.py` + `tests/auth/oauth/test_error_anchors.py` + `tests/plugins/test_error_anchors.py` — per-surface contract gates assert every error envelope's string carries a `See: finlet manual errors#<anchor>` suffix with one of the 13 valid anchors.
- `tests/test_cli_help.py` — `finlet manual errors#rate-limit` returns the anchored section, not the full errors topic.
- Generator drift gate: `python -m finlet.manual.generate_llms_txt --check` in CI ensures `dashboard/llms.txt` matches the registry — the public surface stays synchronized with the canonical errors topic.

## References

- `finlet/manual/errors.md` — canonical anchor document (13 frozen IDs).
- `finlet/manual/registry.py` — `topic_to_json("errors")` exposes the structured render.
- `finlet/mcp/auth.py:_AUTH_REQUIRED_MESSAGE` — the dedup constant for the 19-site MCP auth-required surface.
- `docs/decisions/dashboard-llms-txt-regen-pipeline.md` — sibling decision: the freshness lint that keeps the public llms.txt synchronized with the registry that backs these anchors.
