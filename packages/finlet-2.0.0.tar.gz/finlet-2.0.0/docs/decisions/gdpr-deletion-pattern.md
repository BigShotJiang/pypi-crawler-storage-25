# Decision: GDPR Article 17 — Account deletion cascade pattern

**Date:** 2026-05-14
**Status:** SHIPPED
**Source:** GDPR Deletion (Item G) requirements and 5-team execution plan. Extends and reuses the cascade-walker + audit-row pattern established by `docs/decisions/gdpr-export-cascade-pattern.md` (Item F, shipped 2026-05-14). Closes the last paid-GA blocker called out in F's decision record: "Item G (account deletion / GDPR Article 17) is expected to reuse this pattern."

## Context

GDPR Article 17 ("right to erasure") obliges a controller to delete every piece of personal data they hold about a user when the user requests it. The right is broader than Article 20 (data portability — Item F) in two ways: (1) it requires actual removal across every database, not just emission; (2) it has downstream effects on third-party processors (Stripe, in our case) that hold derivative data. The right is the second load-bearing **paid-GA gate** — shipping payment processing without a working Article 17 surface is a violation in every EU jurisdiction.

At baseline (commit `66747ea`, immediately before this decision merged), Finlet exposed `DELETE /settings/account` (api_key-gated, synchronous) which: (a) hashed-and-checked the user's password if they had one, (b) called `auth_service.delete_user(user_id)` which removed ONLY the `ApiKeyModel` row, (c) returned 204. This left orphaned rows in 28 other user-scoped tables: every leaderboard surface, every marketplace surface, every per-session DB, every OAuth token table, every MFA token table, the `subscriptions` row (still billing through Stripe), and the entire idempotency / rate-limit / verification-code surface. The stub also had no audit trail — once the api_key row was gone there was no evidence the user had ever requested deletion.

F's decision record established the cascade-walker pattern: an explicit registry of `async def walk_*(user_id: str) -> list[WalkerResult]` functions, one per user-scoped table, owned by a dedicated `finlet/gdpr/` package, gated by a property-based cross-user isolation test, and an audit table that records every state transition. G mirrors that pattern with an actual-delete cascade in place of a read-only walk — the structural choices are identical because the load-bearing question is identical ("does this surface know about every user-scoped table?"), and the test gates are identical ("did the cascade visit every relevant table without leaking across users?").

Several shapes were available — soft-delete (`deleted_at` columns everywhere), one-shot synchronous delete, immediate Stripe-side flow that anonymizes the customer rather than canceling. Each had a structural problem in Finlet's setting (no operational reason to retain soft-deleted personal data after the grace window; multi-DB SQLite layout makes synchronous delete reasonable in wall-clock terms but blocks the API worker on Stripe network calls; Stripe-side anonymization is a flow Stripe doesn't directly support — `stripe.Customer.delete()` is the canonical end-of-life call). The decision was to mirror F's async-job model with a 24-hour grace window for cancellation, hard-delete the local tables, and call Stripe's full cancellation API.

## Decision

A new async deletion pipeline at `finlet/gdpr/` (sibling to the export pipeline shipped by F) plus an OAuth-Bearer-only endpoint pair at `/v1/account/delete[/{job_id}]`. The legacy `DELETE /settings/account` is retained as a 410 Gone route (returns the actionable error pointing to the new endpoint pair) so existing OpenAPI consumers learn about the deprecation rather than seeing a generic 404.

### Ten load-bearing decisions

1. **D1 — Audit table is immutable.** A new `gdpr_deletion_requests` table (migration `017_add_gdpr_deletion_requests`) records every deletion request. Once the cascade completes the originating user's row is gone — but the audit row IS retained, with the plaintext `user_id` AND `email` replaced by salted SHA-256 hashes (`user_id_hash`, `email_hash`). The hashes prove the deletion happened without retaining identifiers an auditor or attacker could re-bind to a real user.
2. **D2 — Stripe failure is fail-loud.** `finlet.gdpr.stripe_cancellation.cancel_stripe_subscription` calls `stripe.Subscription.delete(subscription_id)` via `asyncio.to_thread`. ANY exception (network error, billing-state error, authentication) propagates up and the deletion job aborts at `failed` status with the sanitized error summary. A partial deletion (local row gone, Stripe still billing) is the worst failure mode — better to leave the local row intact and surface the failure than half-delete.
3. **D3 — Hard delete, no soft-delete columns.** Every cascade deleter calls `await db.delete(row)`. There are no `deleted_at` flags on user-scoped tables. Soft-delete would: (a) require adding a `deleted_at` column to 28+ tables; (b) propagate filter clauses (`WHERE deleted_at IS NULL`) into every read path forever; (c) leave personal data on disk past the grace window in violation of Article 17's literal reading.
4. **D4 — 24-hour grace window.** The deletion endpoint requires two POSTs: an initiation POST that mints a single-use 256-bit confirmation token and returns it, and a confirmation POST that supplies the token. After successful confirmation the audit row flips to `pending_execution` and a background task sleeps until the grace window elapses (default 24h, configurable). During the grace window the user can `DELETE /v1/account/delete/{job_id}` to cancel. Once the grace timer elapses the cascade runner fires. The grace window is operational — Article 17 doesn't mandate it — but customer-support workflows benefit from a "wait, undo that" affordance, and the cost is one extra audit-row state.
5. **D5 — Cascade order mirrors F's `ALL_WALKERS`.** `ALL_DELETERS` lists 29 deleters in the same logical order F walks (auth → leaderboard → marketplace → billing → per-session → composite-key tables). The deletion runner iterates in this order and emits per-table row counts to structured logs, so the post-mortem trace of any failed deletion has a stable, diff-friendly shape.
6. **D6 — Revoke OAuth refresh tokens FIRST.** Before the Stripe call or any other deleter, the runner calls `delete_oauth_refresh_tokens_for_user(user_id)` explicitly. Outstanding Bearer JWTs are short-lived (~1h) so this closes the "user mints a new session during deletion" attack window immediately. The same deleter appears first in `ALL_DELETERS` so the registry iteration is a zero-cost no-op on the second call (idempotent). The redundant explicit call is the DEFENSIVE ordering invariant — "OAuth revoke happens before anything else, no matter what someone reorders in the registry later."
7. **D7 — Cross-DB delete order respects FK-free indirection.** Finlet runs SQLite across 4 databases (auth, leaderboard, global, marketplace) plus per-session DBs. There are no real FK constraints across DB boundaries — `user_id` columns are "indexed strings" by convention. So delete order is a TASTE call rather than a CORRECTNESS call, but we still apply it: (a) leaderboard cascade deleters resolve `AgentProfile.id` before deleting child rows; (b) marketplace cascade deleters resolve `DeveloperProfile.id` before child rows; (c) `delete_users_for_user` (global DB) is the LAST leaderboard deleter because UserModel is the identity-of-record.
8. **D8 — Audit immutability extends to F's audit too.** `gdpr_export_requests` is NOT deleted by Article 17's cascade. The user's own export history IS evidence of GDPR compliance from Finlet's side, and Article 17's "right to erasure" does not extend to records that operators must retain for regulatory reasons. The property test asserts surviving F-audit rows after G's cascade runs.
9. **D9 — Legacy `DELETE /settings/account` is 410 Gone.** The legacy route is retained (not removed) so existing OpenAPI consumers see a deliberate `410 Gone` response with an actionable error message pointing them to `POST /v1/account/delete`. A 410 is appropriate because the resource was once available and is now deliberately retired — vs 404 which would suggest "never existed."
10. **D10 — `include_export` is a flag, not a separate endpoint.** The initiating POST accepts `{include_export: bool}` (default false). When true, the runner calls F's `run_gdpr_export_job` BEFORE the cascade fires and stashes the resulting `archive_object_key` on the deletion-audit row. The user can poll for the export URL via `GET /v1/account/delete/{job_id}` while the cascade runs. Folding the export into the deletion flow lets a user "give me my data, then delete me" in one request instead of two.

### Five load-bearing pieces

1. **Audit table — `gdpr_deletion_requests` (migration `017_add_gdpr_deletion_requests`).** Mirrors F's `gdpr_export_requests` shape with deletion-specific columns: `confirmation_token`, `confirmed_at`, `grace_started_at`, `grace_expires_at`, `started_at`, `canceled_at`, `include_export`, `archive_object_key` (export bundle), `stripe_subscription_canceled_at`, `user_id_hash`, `email_hash`. State machine: `pending_confirmation → pending_execution → running → success | failed | canceled`. The API layer creates the `pending_confirmation` row BEFORE returning the response so a polling GET cannot race the audit write.
2. **Cascade deleter registry — `finlet/gdpr/deleters/ALL_DELETERS`.** Explicit list of 29 deleters (vs F's 23 walkers — the difference is the two composite-key tables `idempotency_keys` and `rate_limit_entries` which have no walker because they're not user-scoped at the column level, but DO require a deleter because they carry user-attributable data via key prefix). Each deleter is `async def delete_<table>_for_user(user_id: str) -> int` returning rowcount. Pairing rule: every walker in F's `ALL_WALKERS` has a paired deleter EXCEPT walkers for tables that must survive deletion (F's audit table and global tables).
3. **Salted SHA-256 audit-identifier hashing — `finlet/gdpr/hashing.py`.** `hash_user_id_for_audit(user_id)` and `hash_email_for_audit(email)` return 64-character salted SHA-256 hexes. The salt comes from `FINLET_DELETION_HASH_SALT` (SSM-sourced in production, empty in dev). The `|` separator between salt and value stops salt-end/value-start ambiguity. The runner computes the hashes BEFORE the cascade fires (the user's email is unrecoverable once `ApiKeyModel` is gone) and persists them on the audit row at the `success` transition.
4. **Stripe-side cancellation — `finlet/gdpr/stripe_cancellation.py`.** Isolated module separate from `finlet/billing/service.py`. Calls `stripe.Subscription.delete()` via `asyncio.to_thread`, returns the UTC timestamp at which Stripe returned. If the user has no `SubscriptionModel` row (free tier) or the row has no `stripe_subscription_id` placeholder, returns `None` — successful no-op. Any exception propagates to the runner and aborts the job.
5. **Async job runner + grace executor — `finlet/gdpr/deletion_job_runner.py`.** Single async entrypoint `run_gdpr_deletion_job(job_id, user_id)` drives one user's deletion from `running` to `success | failed`. The 8-step pipeline: snapshot email → flip to `running` → revoke OAuth (D6) → cancel Stripe (D2) → iterate `ALL_DELETERS` → wipe per-session DB directories → flip audit row to `success`. A separate helper `schedule_grace_period_executor(job_id, user_id, grace_expires_at)` is the in-process sleep+run path called by the confirmation endpoint. `sweep_orphaned_pending_execution_jobs()` is the recovery path called at app startup to re-schedule jobs whose grace timer elapsed during downtime.

### API surface (OAuth Bearer only)

* `POST /v1/account/delete` — single endpoint, dual call shape. **First POST** (no `confirmation_token` in body, optional `include_export` flag): mint a job + single-use 256-bit token, persist the audit row in `pending_confirmation`, return `202` with the token + 24h expiry. **Second POST** (`confirmation_token` present, optional `job_id`): atomically validate + consume the token, flip the row to `pending_execution`, schedule the cascade runner. Token mismatch / wrong user / non-pending status → `401`. Idempotent for first-POST shape: a duplicate POST while a job is in any pre-terminal state returns the existing job's record.
* `GET /v1/account/delete/{job_id}` — poll the 6-state machine. Hot path: in-memory `_deletion_jobs` dict. Cold path: `load_deletion_job_from_db()`. On `success` with `include_export=True` and `archive_object_key` set, re-mints a fresh 24h presigned URL via F's `GdprS3Storage.generate_download_url`. 404 for missing AND foreign-owned jobs.
* `DELETE /v1/account/delete/{job_id}` — cancel a deletion job during the grace window. Valid in `pending_confirmation` or `pending_execution`. Returns `204` on success, `404` for missing/foreign, `409` for jobs that have already started running, completed, failed, or were previously canceled.
* `DELETE /v1/settings/account` — 410 Gone with the actionable error pointing to `POST /v1/account/delete`.

The OAuth injector contract (`auth: tuple[UserRecord, OAuthClaims] = Depends(require_oauth)` with `user, _claims = auth` unpacking) mirrors F's surface — same `require_oauth` dependency, same scope expectations.

### Cross-user isolation + completeness gate

`tests/gdpr/test_deletion_property.py` is the load-bearing test for G — the analog of F's `tests/gdpr/test_export_property.py`. Hypothesis (`@settings(max_examples=20, deadline=None)`, pinned `--hypothesis-seed=0`) seeds 2-4 synthetic users with N rows per table across every user-scoped surface, drives `run_gdpr_deletion_job` for `user_ids[0]` (Stripe stubbed to succeed), and asserts six invariants:

1. Every deleter in `ALL_DELETERS` returns 0 surviving rows for `user_ids[0]` after the cascade (idempotency-as-completeness gate — a second call would re-delete; 0 means there's nothing left).
2. Every other user's rows survive intact (cross-user isolation — direct-SELECT counters confirm the per-table row count is unchanged).
3. The `gdpr_deletion_requests` row for `user_ids[0]` exists with `status="success"` and both `user_id_hash` + `email_hash` populated as 64-character hex strings.
4. The `gdpr_export_requests` rows for ALL users survive untouched (F's audit table is immune to G's cascade).
5. `oauth_keys` + `dmca_designated_agents` rows survive untouched (global non-user-scoped tables).
6. `ALL_DELETERS` has at least 25 entries (registry-shrink gate — a future "accidentally emptied the list" change surfaces here, not in production).

The test exercises the FULL `ALL_DELETERS` registry. The CI budget is lower than F (max_examples=20 vs 50) because the deletion path is heavier — it mutates rather than reads, and each example seeds ~24 tables × N rows for ~4 users + runs the full runner.

## Rationale

### Why mirror F's pattern instead of inventing a new shape?

The cascade-walker pattern is structurally identical to what an account-deletion surface needs. F walks 23 tables; G needs to delete the same tables plus 2 composite-key tables that F intentionally skips (because they have no `user_id` column at the schema level). The contract is the same: "for every user-scoped row in every database, this surface MUST know about it." Inventing a new shape would multiply the test surface (the property-based isolation gate would need to be re-implemented), the audit-table convention would diverge (operators would have to learn two different audit shapes), and the pairing rule between walkers and deleters would be implicit rather than explicit.

The pattern reuse also lets F's registry-coverage gate (`tests/gdpr/test_walker_registry.py`) extend to G's deleters in the same module — adding a `user_id` column to a new table fails both the walker-coverage and deleter-coverage assertions in the same PR.

### Why 24-hour grace window?

Article 17 doesn't mandate a grace window. The decision was operational, not legal:

* **Customer support workflow.** Without a grace window, an accidental deletion (user clicks "delete account" while exploring settings) is irrecoverable — every row is gone. With a 24h grace, the user (or support) can `DELETE /v1/account/delete/{job_id}` and the cascade never fires.
* **Operational cost.** One extra audit-row state (`pending_execution`) plus a sleep-then-run executor. Both are cheap. The audit-row state survives process restart via `sweep_orphaned_pending_execution_jobs()` so a node bounce doesn't lose pending deletions.
* **Threat model.** A malicious actor with a stolen OAuth Bearer token cannot force-delete an account within the grace window — the user can cancel. They can ALSO race the grace timer if they have 24h of unfettered access, but that's already game over (they can also exfiltrate via Item F's export). The grace window adds operational forgiveness without changing the threat boundary.

### Why hard-delete instead of soft-delete?

Five reasons:

1. **Article 17 literal reading.** "Right to erasure" implies actual removal, not a `deleted_at` flag. EU regulators have litigated this — soft-delete with retention has been ruled non-compliant in DPA decisions.
2. **Schema cost.** Soft-delete requires `deleted_at` on every user-scoped table. That's a migration touching 24+ tables, plus a default `WHERE deleted_at IS NULL` on every read path that currently exists in the codebase. The blast radius is enormous compared to "row goes away."
3. **Read-path correctness.** Every existing query in the codebase assumes rows visible in the table belong to existing users. Soft-delete would force a global audit of every `select(...)` to add the `deleted_at IS NULL` filter — and a missed filter would leak deleted-but-not-purged data.
4. **Operational simplicity.** A failed cascade (D2 Stripe failure) currently leaves the local rows intact — operator can rerun. With soft-delete, the operator would have to disambiguate "soft-deleted because deletion succeeded" from "soft-deleted because deletion was partial."
5. **Audit row is enough.** The `gdpr_deletion_requests` row with `user_id_hash` is sufficient evidence the deletion happened. We don't need the original `user_id` value retained anywhere.

### Why salted SHA-256 hashes instead of plain SHA-256?

Plain SHA-256 of a user_id is reversible via rainbow tables for the small set of users on the platform. Salted SHA-256 with a per-environment salt (sourced from SSM) means an attacker who exfiltrates the audit table cannot bind the hashes back to plaintext user_ids without ALSO exfiltrating the salt. The salt source (`FINLET_DELETION_HASH_SALT`) is operational, not legal — Article 17 doesn't require salting — but the audit table will accumulate over the platform's lifetime and the cost of salting is one env var.

The `|` separator between salt and value prevents salt-end/value-start ambiguity: without it, `salt="abc"` + `value="defg"` and `salt="abcde"` + `value="fg"` would hash to the same value.

### Why is the legacy `DELETE /settings/account` a 410 Gone instead of being removed?

Three reasons:

1. **OpenAPI consumer signal.** A removed route returns 404 from FastAPI's default handler — no Deprecation header, no Sunset date, no message. Consumers see "endpoint doesn't exist" with no signal that it was deliberate. A 410 with the actionable error in the body tells the consumer "this WAS the endpoint; here's where to go now."
2. **Audit trail.** The 410 route emits structured logs on every call — `gdpr.deletion.legacy_route_called` with the user's id. Operators can grep for stale clients and reach out.
3. **Cheap to retain.** The route is one file (`routes_settings.py` lines 182-209), one test, and zero runtime overhead. Keeping it costs nothing; removing it loses the OpenAPI signal.

### Why include_export as a flag instead of a separate endpoint?

"Give me my data, then delete me" is a common Article 17 + Article 20 combo — a user who wants to leave the platform often wants their data first. Two separate endpoints would require: (a) the client polls for export completion, (b) the client then calls delete, (c) the client polls for delete completion. Three round-trips minimum, with race conditions if the user closes the laptop between (b) and (c).

The `include_export=true` flag folds the two into one flow: the runner triggers F's pipeline first, stashes the resulting `archive_object_key` on the deletion-audit row, then proceeds with the cascade. The user polls ONE endpoint (`GET /v1/account/delete/{job_id}`) and gets both the export URL (while the cascade runs) and the deletion status.

## Consequences

### Reusable by future Article 17-adjacent flows

The pattern carries forward to any future "delete user's data" surface — e.g. a partial-delete option ("delete my benchmark history but keep my account") could reuse `ALL_DELETERS` with a filter predicate. The runner's `for deleter in ALL_DELETERS:` loop is the only place that needs to grow a conditional.

### Deleter registry IS the completeness contract

`tests/gdpr/test_walker_registry.py::_INTENTIONALLY_EXCLUDED_FROM_DELETERS` mirrors the walker-side exclusion list. A future migration that adds a new user-scoped table fails this gate at PR time — the "did we miss anything" question is structurally enforced, not vibes-based. Excluding a new table requires either adding a deleter or extending the exclusion dict with an explicit reason.

### Stripe customer is canceled, not anonymized

`stripe.Subscription.delete()` cancels the subscription immediately and the customer record is RETAINED on Stripe's side (Stripe's contract — customer data is governed by their own data-retention policy). If a future EU jurisdiction requires customer-side anonymization, the helper at `finlet/gdpr/stripe_cancellation.py` is the single seam where that call would land (`stripe.Customer.delete()` or `stripe.Customer.update(metadata={'anonymized': true}, email=None)`).

### Audit row retention is unbounded

The `gdpr_deletion_requests` table accumulates one row per deletion. The hashes are 128 characters (two SHA-256 hexes) plus a uuid4 id and a handful of timestamp columns. At 200 bytes per row and 100,000 deletions, the table is 20MB — bounded growth, no operational concern. If the table ever grows past hundreds of millions of rows, the operational fix is a separate compaction job that retains the hashes + status + completed_at and drops the per-state-transition timestamps.

### Old `/settings/account` callers see 410

Internal callers were the legacy dashboard's settings page (cut to `legacy/dashboard-ui/` on 2026-05-06 launch cut). External callers are the api_key-gated `DELETE /settings/account` consumers, of which there are none — the endpoint was never publicly documented and was not part of any SDK. The blast radius of "callers cached the URL" is zero.

### Operational footprint

* New SSM parameter: `FINLET_DELETION_HASH_SALT` (32+ random bytes recommended). Empty in dev.
* New structured-log fields: `gdpr.deletion.job.start`, `gdpr.deletion.snapshot`, `gdpr.deletion.oauth_revoked`, `gdpr.deletion.stripe_canceled`, `gdpr.deletion.cascade_complete`, `gdpr.deletion.job.success | gdpr.deletion.job.failed`. All carry `job_id + user_id` bind tags so a single deletion's full lifecycle is `grep job_id=...` on the structured log.
* App startup adds one DB scan via `sweep_orphaned_pending_execution_jobs()` — reads `gdpr_deletion_requests WHERE status='pending_execution'`. Indexed on status; cost is constant-time + N for the rescheduled count.

### Test surface

* `tests/gdpr/test_hashing.py` — salted-SHA-256 unit tests (hash determinism, salt-changes-hash, case-folding for email, whitespace stripping).
* `tests/gdpr/test_deletion_job_runner.py` — runner orchestration (happy path, D2 Stripe-failure, D6 OAuth-revoke-first, audit-row hash population, per-session cleanup, grace executor sleep-then-run, sweeper).
* `tests/gdpr/test_stripe_cancellation.py` — Stripe SDK mocking (no-subscription returns None, subscription deletion returns timestamp, error propagates).
* `tests/gdpr/test_walker_registry.py` — deleter coverage gate (every user-scoped table has a deleter; excluded tables are documented; no stale exclusions).
* `tests/gdpr/test_deletion_property.py` — Hypothesis cross-user isolation + cascade-completeness gate (THE load-bearing test).
* `tests/api/test_routes_account_delete.py` — endpoint smoke (POST initiate → token; POST confirm → pending_execution; GET 404 for foreign; DELETE 204 cancels; idempotent re-POST; 410 on legacy route).
* `tests/db/test_gdpr_deletion_requests_migration.py` — migration runs clean + round-trip insert.

## Excluded tables (intentional)

Four tables in the schema are intentionally NOT deleted by `ALL_DELETERS`. The schema-coverage gate (`tests/gdpr/test_walker_registry.py::_INTENTIONALLY_EXCLUDED_FROM_DELETERS`) hard-codes this list — every entry must reference a table that ACTUALLY EXISTS (a stale exclusion fails the gate) and carries a one-line rationale. Future schema migrations that add a new user-scoped table cannot silently bypass the cascade; they must either add a deleter or extend the exclusion dict with an explicit reason.

| Table | Reason |
|-------|--------|
| `gdpr_export_requests` | F's audit table — must survive Article 17 deletion (D8 audit-immutability). The user's own export history IS evidence of GDPR compliance from Finlet's side. |
| `gdpr_deletion_requests` | G's OWN audit table — must survive (D8 — same rationale; meta-immutability). The runner WRITES the audit row but never deletes it. |
| `oauth_keys` | Global JWKS signing keys for the OAuth Authorization Server. No `user_id` column — single global registry shared across all users. Deleting these would break OAuth for every other user on the platform. |
| `dmca_designated_agents` | Global service-provider DMCA designated-agent registration (Finlet's own copyright.gov filing). No `user_id` column — Finlet-the-platform record, not user-of-Finlet record. |

This list mirrors F's `_INTENTIONALLY_EXCLUDED` walker-side exclusion list verbatim with one addition: `gdpr_deletion_requests` itself (which doesn't exist as a table in F's pre-G world).

## Cross-references

* `docs/decisions/gdpr-export-cascade-pattern.md` — F's decision record. Establishes the walker pattern G inherits. F was the prerequisite paid-GA gate; G is the second.
* `docs/decisions/mcp-oauth-2-1-auth-model.md` — establishes the OAuth-Bearer-only convention this surface inherits.
* `finlet/gdpr/deleters/__init__.py` — `ALL_DELETERS` registry (the load-bearing list).
* `finlet/gdpr/deletion_job_runner.py` — the async runner + grace executor + startup sweeper.
* `finlet/gdpr/stripe_cancellation.py` — isolated Stripe seam.
* `finlet/gdpr/hashing.py` — salted SHA-256 audit-identifier hashing.
* `finlet/api/routes_account.py` — OAuth-Bearer-only endpoint trio (`POST` initiate + confirm, `GET` poll, `DELETE` cancel).
* `tests/gdpr/test_deletion_property.py` — the cross-user isolation + cascade-completeness gate (this decision's load-bearing test).
* `tests/gdpr/test_walker_registry.py` — the deleter coverage gate.
