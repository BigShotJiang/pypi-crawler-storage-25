# Blind Benchmark V1 — Architecture

> Date: 2026-05-19
> Status: Shipped (6-team exec-plan A→F + self-heal)
> Related: `docs/ARCHITECTURE.md` → "Blind Benchmark Mode" under `## Leaderboard`, `docs/decisions/blind-benchmark-sector-literal.md`, `docs/decisions/blind-benchmark-envelope-fields-must-blind.md`

LLM agents pre-trained on financial news recognize specific tickers (NVDA, AAPL, BTC-USD) and dates (2020-02 = COVID, 2023-10 = AI rally) and exploit that memory in lieu of reasoning from market data. Blind Benchmark V1 maps tickers → `T_NNNN` opaque ids and dates → `Day_N` relative offsets per-session, so the agent cannot recognize the regime from the labels alone. The underlying numeric data (prices, fundamentals, ratios) and sector/industry tags remain visible — structural reasoning is preserved, era-recognition is neutralized.

## Locked Decisions

### Per-session opaque mapping (`T_NNNN` + `Day_N`)

Tickers are replaced with `T_NNNN` (zero-padded 4-digit numeric, e.g., `T_0001`, `T_0042`). Numeric ids are sort-stable and distinct from real ticker shapes. Dates are replaced with `Day_N` where `Day_1` is the scenario's `start_time` calendar date — this bounds the integer space and prevents the agent from inferring scenario era from absolute Day_N range. The mapping is deterministic given a salt, but the salt is fresh per session — two runs of the same scenario produce different mappings (Numerai-style anti-stitching). Rejected: stable-per-benchmark-run mapping (cheat surface across replays), `T42` / `Asset_A` shapes (less sort-stable), absolute `Day_N` (era-leak via integer range).

### Server-only one-time-use salt; only the derived mapping persists

The salt is generated server-side at session creation via `secrets.token_bytes(16)` in `finlet.core.blind_mapping.generate_mapping`, used immediately to derive the mapping, and discarded — it is NEVER exposed via API, CLI, or frontend. Anti-cheat: prevents users from pre-computing the mapping offline, prevents replay attacks via known seeds, prevents forcing a seed that has been revealed on a prior session. The derived `BlindMapping` Pydantic model is persisted as a `blind_mapping_json` TEXT column on the `sessions` table (~1KB for the V1 6-ticker default universe + a single `date_origin`); migration `finlet/db/migrations/session_versions/015_add_session_blind_mapping.py`. Tests inject a deterministic `seed` parameter; production callers MUST omit `seed`.

### Enforcer-first, service-layer transform second (defense-in-depth)

The `DateCeilingEnforcer` continues to operate on real dates BEFORE the blind transform. The transform is a service-layer concern, not a plugin-layer concern — plugins emit unblinded shapes, and `_apply_blind_transform` in `finlet/api/services/market_service.py` rewrites the response items + the surrounding envelope to opaque values. No plugin signature change. Rejected: per-plugin transform (5x duplication, risk of drift), contextvar (cleaner alternative but harder to test; session is in scope at the service layer anyway), pre-enforcer transform (enforcer needs real dates to filter post-ceiling data correctly).

### Three-audience model: AGENT (blinded via MCP), HUMAN OWNER (real), ANONYMOUS PUBLIC VIEWER (blinded)

| Audience | Surface | Sees |
|---|---|---|
| Agent under evaluation | MCP — data-plane (`get_price_data`, `get_fundamentals`, `get_filings`, `get_economic_data`, `list_available_tickers`) AND owner-view (`submit_order`, `cancel_order`, `get_portfolio`, `get_equity_curve`, `get_trace`, `advance_time`, `get_sim_time`, `complete_session`) | Blinded — `T_NNNN` tickers + `Day_N` dates on every response surface. `search_news` short-circuits with `{error: "tool unavailable in blind benchmark"}` (Team B `_NEWS_BLIND_BLOCK_ENVELOPE`). Owner-view blinding closed 2026-05-20 (Codex bug `50abd05e`). |
| Session owner (authenticated, dashboard/REST) | REST `/v1/sessions/{id}/*` + dashboard | Real ticker symbols + real ISO dates. The MCP agent surface above is the SAME authentication identity but blinds because `session.config.blind=True`; REST + dashboard intentionally do NOT key off `blind` because the human-on-dashboard audience needs real data. The dashboard public viewer offers a Reveal toggle that hot-swaps the endpoint family between `/v1/public/sessions/...` (blinded) and `/v1/sessions/...` (real). |
| Anonymous public viewer | `/v1/public/sessions/{id}/*` (Team D serializers) | Blinded — same `T_NNNN` + `Day_N` shapes as the agent. `PublicSessionResponse.blind: bool` signals to the dashboard renderer that Day_N integer x-axis is in play. |

The Reveal toggle is `sessionStorage`-backed and resets on refresh (safer default — requirements doc recommendation).

### V1 universe scope: 6 default-universe tickers only

Mapping covers `scenario.universe` only (AAPL/MSFT/NVDA/AMZN/GOOGL/BTC-USD). `list_available_tickers` in blind mode returns only the mapped scenario universe; out-of-universe ticker queries get the existing "not in universe" error. Sector/industry tags come from an embedded literal `_TICKER_SECTOR_TABLE` in `finlet/core/blind_mapping.py` (see `docs/decisions/blind-benchmark-sector-literal.md`).

### V1 owner-tools-via-MCP: CLOSED 2026-05-20 (Codex bug `50abd05e`)

A blind-benchmark AGENT calls MCP as the session owner (authenticated). Owner-routed MCP tools (`submit_order`, `cancel_order`, `get_portfolio`, `get_equity_curve`, `get_trace`, `advance_time`, `get_sim_time`, `complete_session`) used to flow through the authenticated path WITHOUT applying the blind transform (the assumption being that the human owner sees real data on their dashboard, and the public viewer route covered the third-party-viewer audience). On a blind-benchmark session that assumption was wrong: the AGENT runs AS the session owner, so its own portfolio / trace / clock / order responses leaked real tickers and dates — contradicting Critical Invariant 4 in the original plan ("zero leak via any tool the agent can call").

Closed 2026-05-20 by Codex bug `50abd05e` response (Teams A + B + D):

- Team A — trading axis (`finlet/mcp/tools_trading.py` + `finlet/api/services/trade_service.py`): input reverse-mapping (`reverse_ticker` on `submit_order`'s opaque ticker before the universe check) + output blinding (`_blind_order_dict` on the rich-shape order response). Non-enumerating error envelope for unknown opaque ids.
- Team B — data / clock / portfolio axis (`finlet/mcp/tools_portfolio.py`, `finlet/mcp/server.py` clock helpers, `finlet/api/services/session_service.py`'s `complete_session` wrap, `finlet/api/services/market_service.py`'s universe filter): `get_portfolio` / `get_equity_curve` / `get_trace` / `advance_time` / `get_sim_time` output blinding, `complete_session` `benchmark_transition.next_session` envelope re-blinded under the NEXT scenario's mapping, `list_available_tickers` emits the full opaque universe.
- Team D — gate hardening (`tests/e2e/test_blind_benchmark_zero_leak.py`): the zero-leak gate now exercises every owner-view tool listed above. The `real_time` field on trace entries is the documented exemption — the gate strips it from the blob before grep'ing.

See `docs/decisions/blind-benchmark-envelope-fields-must-blind.md` Extension 2026-05-20 for the decision record extension that locks owner-view surfaces into the "ALL response surfaces must blind" rule. The PUBLIC route (Team D, May 2026) remains the canonical third-party-viewer surface and is independently covered by `tests/api/test_public_session_blind_grep.py`.

## File Map

- `finlet/core/blind_mapping.py` — `BlindMapping` Pydantic model, `generate_mapping`, `apply_ticker`, `apply_date`, `reverse_ticker`, `reverse_date`, `_TICKER_SECTOR_TABLE`.
- `finlet/core/session.py` — `SessionConfig.blind: bool`, `Session.blind_mapping: BlindMapping | None`.
- `finlet/db/session_models.py` + `finlet/db/persistence.py` — `blind_mapping_json` TEXT column + save/load.
- `finlet/db/migrations/session_versions/015_add_session_blind_mapping.py` — schema migration.
- `finlet/db/migrations/versions/020_add_benchmark_run_blind.py` — `BenchmarkRunModel.blind` column.
- `finlet/api/services/market_service.py` — `_apply_blind_transform`, `apply_universe_blind_filter`, news short-circuit, envelope-level transform (ceiling_applied / rate_limit_reset / earliest_available / cached_at).
- `finlet/mcp/server.py` — wires `list_available_tickers` to the universe blind filter.
- `finlet/mcp/tools_benchmark.py` + `finlet/cli.py` — `start_benchmark(blind=True)` MCP param + `finlet benchmark start --blind` CLI flag.
- `finlet/leaderboard/benchmark_state.py` — `BenchmarkRun.blind`, mapping generation hooked into `create_scenario_session`.
- `finlet/api/services/session_service.py`, `finlet/api/serializers.py`, `finlet/api/services/trade_service.py`, `finlet/api/routes_public_session.py`, `finlet/api/schemas/session.py` — `blind_mapping` kwarg threaded through 3 public-viewer serializers + 5 anonymous routes; `PublicSessionResponse.blind: bool`.
- `dashboard/public.html`, `dashboard/public.js`, `dashboard/renderers.js`, `dashboard/styles.css` — blind banner, Reveal toggle (sessionStorage-backed, hot-swaps public↔auth endpoint families), Day_N timeScale formatter.
- `tests/e2e/test_blind_benchmark_zero_leak.py`, `tests/property/test_blind_mapping_invariants.py`, `tests/api/test_public_session_blind_grep.py` — zero-leak gate, property invariants, grep regressions.

## Out of Scope (V1)

- News anonymization beyond block-and-error (V2 — LLM rewrite per session seed).
- Filings `link` field stub URL (V2 — currently empty string).
- Sector/industry runtime S3 enrichment (V2 — currently embedded literal for 6 tickers; see sector-literal decision record).
- Blind track on leaderboard UI (V2 — once we have enough blind-run data).
- Backfilling blind mappings on existing completed sessions (V2).
- ~~Owner-tools-via-MCP blind extension (V2 — known gap above).~~ Closed 2026-05-20 (Codex bug `50abd05e`); see "V1 owner-tools-via-MCP" above.
- Forward Test Track + Synthetic / Counterfactual Track (separate architectures; blind work here is precondition).
- Per-scenario leakage score, publish-seed-on-close (deferred; cheat surface vs. research-credibility tradeoff).

## Follow-ups (Tracked in REMAINING_TASKS.md)

See REMAINING_TASKS.md "2026-05-19 — Blind Benchmark V1 — SHIPPED → Follow-ups" for the V2 work queue.
