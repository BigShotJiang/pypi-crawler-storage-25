# Decision: OrderRejected envelope contract (REST 422 + MCP envelope)

Date: 2026-05-22
Status: shipped (Codex bug 9a85b8bd, Team C — C1 + C2)

## Context

Codex (GPT-5) drove Finlet's `submit_order` tool during a benchmark and
hit two distinct failure shapes for what is logically the same outcome
(an order that cannot be placed):

1. **Insufficient cash:** the tool returned HTTP 201 / MCP 200 with the
   rich-shape order dict carrying `status: "REJECTED"` and a free-form
   `reject_reason`. Agents had to introspect the body to detect the
   rejection — the response *looked* successful at the transport layer.

2. **Plugin error (e.g. circuit breaker OPEN):** same 201/200 + body
   shape, with a different `reject_reason` string. Agents had no
   programmatic way to distinguish "you don't have enough cash" from
   "the upstream data source is down right now."

Both paths flowed through `_finalize` and returned a dict, so the
caller had no signal at the transport layer or in the envelope shape
that anything had gone wrong. Codex's post-run review flagged this as
a usability bug for agentic callers — the body-shape rejection is
ambiguous and hard to handle correctly.

The recon also surfaced four engineering issues alongside the contract
problem:

- **BLOCKER #1.** The broad `except Exception:` at
  `finlet/api/services/trade_service.py:368` swallows any exception
  raised inside the auto-fill try-block. Any new raise within lines
  276-367 would silently fall through to the PENDING-fallback persist.
- **BLOCKER #2.** `validate_order(order) -> str | None` returns error
  strings, not booleans — the actual REJECTED stamping happens inside
  `OrderBook._submit_unlocked` (orders.py:103-111). Any raise must
  happen at the stamping site, not at the validator.
- **BLOCKER #3.** `OrderBook.reject_unfillable_orders` (orders.py:196-211)
  is non-throwing on purpose: the clock-service save loop iterates the
  returned list to persist each rejection. Raising inside it would skip
  the save loop. This function MUST stay non-throwing.
- **BLOCKER #7.** The `@blind_error_mapper` decorator at
  `finlet/mcp/blind_error.py:298-326` re-raises any exception when the
  session has no blind mapping. A non-blind `OrderRejected` would escape
  this decorator entirely, surfacing as FastMCP's generic "Error executing
  tool" envelope instead of the canonical `{error, code, order_id}` shape.

## Decision

### Engine layer (`finlet/core/orders.py`, `finlet/errors.py`)

- New domain exception `OrderRejected(ValueError)` carries
  `(reason: str, code: str, order_id: str | None)`. `code` is constrained
  to `VALID_CODES = {"insufficient_cash", "insufficient_shares",
  "plugin_error", "validate_order_failed", "circuit_breaker_open"}`.
- `OrderRejected` subclasses `ValueError` so legacy engine raises
  (`portfolio.execute_buy/_sell` raise `ValueError("Insufficient cash:
  ...")`) stay back-compat — `isinstance(OrderRejected, ValueError)` is
  True, so existing handlers continue working. NEW handlers in the
  submit-order path MUST add `except OrderRejected: raise` ABOVE any
  `except ValueError` / `except Exception` so the domain raise propagates
  past the swallow site.
- `OrderBook._submit_unlocked` now PERSISTS the REJECTED record into
  `self._orders` and THEN raises `OrderRejected(code="validate_order_failed")`.
  `validate_order`'s return type (str | None) is unchanged — the raise
  happens at the stamping site, per BLOCKER #2.

### Service layer (`finlet/api/services/trade_service.py`)

- `trade_service.submit_order` adds `except OrderRejected: raise` BEFORE
  the broad `except Exception:` at line 368, so the domain raise
  propagates past the swallow site (BLOCKER #1).
- New helper `_record_rejection_then_raise(*, result, session_id,
  idempotency_key, code)` writes the rejection envelope to the
  idempotency cache (so a retry with the same key returns the same
  shape) and then raises `OrderRejected`. The REJECTED record is already
  durable in memory + DB (the caller invokes `_persist_market_terminal`
  first) — this helper sequences the cache write before the raise.
- Cash/shares rejection (after `session.fill_order` raised `ValueError`
  inside the auto-fill block): after `_persist_market_terminal` succeeds,
  the service detects `result.status == OrderStatus.REJECTED` and calls
  `_record_rejection_then_raise(code="insufficient_cash" | "insufficient_shares")`
  (code inferred from `reject_reason` substring).
- Plugin-error rejection (price plugin returned error): after
  `_persist_market_terminal` succeeds, the service calls
  `_record_rejection_then_raise(code="plugin_error")` instead of
  returning the `_finalize` dict.

### Surface layer (REST + MCP)

- REST (`finlet/api/routes_trade.py:submit_order_route`): `except OrderRejected`
  raises `HTTPException(status_code=422, detail={"error": e.reason,
  "code": e.code, "order_id": e.order_id, "doc": "See: finlet manual
  errors#order-rejected"})`. The 422 status differentiates rejection
  from server-side failure (5xx) and from input-validation failure (the
  pydantic gate also returns 422 but with a different detail shape).
- MCP (`finlet/mcp/blind_error.py`): the `@blind_error_mapper` decorator
  handles `OrderRejected` BEFORE the mapping-lookup re-raise path
  (BLOCKER #7). The envelope shape is `{error: <reason>, code: <code>,
  order_id: <id>}`, path-sanitized via `sanitize_paths`. On a blind
  session, `error` is re-blinded via `blind_string(reason, mapping)` so
  any embedded ticker or ISO-date in the reason string is masked.
- MCP (`finlet/mcp/tools_trading.py:submit_order`): explicit `except
  OrderRejected` is also present as defense-in-depth, producing the
  same envelope shape locally. If the decorator's exception path ever
  regresses, the explicit catch keeps the contract.

### Session layer (UNTOUCHED)

`finlet/core/session.py:reject_unfillable_orders` stays non-throwing
per BLOCKER #3 — the clock service's save loop relies on it returning
a list of rejected orders (not raising). The `code="circuit_breaker_open"`
slot in `VALID_CODES` is reserved for future use; today the circuit-breaker
path through `trade_service.submit_order` is shaped via `code="plugin_error"`
(the plugin returns the circuit-breaker error string).

## Rejected alternatives

- **Body-shape rejection (status quo).** Rejected because the response
  *looked* successful at the transport layer — Codex's review flagged
  the ambiguity as the primary usability bug.
- **HTTP 409 Conflict.** Rejected because 409 is for state-conflict
  (e.g. session not ACTIVE) — order rejection is a validation outcome.
- **HTTP 400 Bad Request.** Rejected because the request body is well-
  formed; the rejection is downstream of input validation.
- **HTTP 402 Payment Required for insufficient_cash.** Rejected for
  scope-discipline reasons — 422 with a structured `code` field is
  sufficient and keeps the surface contract uniform.
- **Add code field to body, keep 200/201.** Rejected because the body-
  shape rejection is the primary usability bug being fixed. Adding the
  code field alongside `status: "REJECTED"` would entrench the
  status-quo shape that Codex flagged.
- **Raise in `validate_order`.** Rejected per BLOCKER #2 — the validator
  is a pure function that returns strings; the stamping site
  (`_submit_unlocked`) is the natural raise point and where memory
  persistence happens.
- **Make `reject_unfillable_orders` raise.** Rejected per BLOCKER #3 —
  the clock-service save loop relies on it returning a list. Future
  refactor could thread persistence into this path, but it's out of
  scope for this PR.

## Pre-launch posture

Finlet is pre-launch with zero paying customers. The protective
contract `OrderRejected → 422 envelope` does NOT carry a dual-shape
back-compat window — the previous body-shape rejection (status: "REJECTED"
in a 201 body) is removed in the same PR. Post-launch contract changes
will require a sunset window per the standard policy in
`docs/decisions/mcp-canonical-surface.md`.

## Verification

- New unit tests in `tests/core/test_orders.py` lock the engine raise +
  persist-then-raise contract.
- Updated tests in `tests/api/test_trade_service.py` (circuit-breaker
  + generic plugin-error) lock the service raise via
  `pytest.raises(OrderRejected)`, with persistence assertions preserved
  (one `save_order` call + trace entry recorded).
- New MCP envelope tests in `tests/mcp/test_submit_order_validation.py`
  exercise the insufficient-cash, plugin-error, and blind-session paths.
- New REST 422 tests in `tests/api/test_routes_trade_validation.py`
  exercise the insufficient-cash and plugin-error paths.
- New `tests/mcp/test_cancel_order_envelope.py` locks the existing
  cancel-order envelope shape so future refactors that migrate cancel
  rejection to `OrderRejected` keep the `{error: str}` MCP boundary
  contract.
- Existing `tests/mcp/test_error_envelope_hygiene.py` grep gate
  (substrings: `/Users/`, `/home/`, `~/`, `/root`, `.finlet`,
  `errors.pydantic.dev`, `validation error for `, `Error executing tool `)
  continues to pass — `sanitize_paths` is applied to every OrderRejected
  envelope at the decorator chokepoint.
