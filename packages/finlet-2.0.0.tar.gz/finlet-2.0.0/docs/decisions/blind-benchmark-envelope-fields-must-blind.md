# Blind Benchmark — Envelope-Level Fields MUST Blind

> Date: 2026-05-19
> Status: Shipped (self-heal post Team F zero-leak gate)
> Related: `docs/decisions/blind-benchmark-architecture.md`, `finlet/api/services/market_service.py`, `tests/e2e/test_blind_benchmark_zero_leak.py`

## Decision

The blind-benchmark transform layer MUST cover **envelope-level fields**, not just `items[]`. Any wall-clock timestamp field or ISO-date string in a response that flows out of a blind session — regardless of whether it lives in the payload body or the surrounding metadata envelope — must be routed through `finlet.core.blind_mapping.apply_date` before serialization.

Concrete fields fixed in the self-heal pass:

| Surface | Field | Fix |
|---|---|---|
| `market_service.route_query` envelope | `ceiling_applied` | Was raw `ceiling.isoformat()`; now `apply_date(ceiling, mapping)` when `session.config.blind=True`. |
| `market_service.route_query` envelope | `rate_limit_reset` | Was raw `response.rate_limit_reset.isoformat()`; now `apply_date(...)` when blind. |
| `market_service.route_query` envelope | `earliest_available` (parsed from plugin error tail) | Was raw ISO; now `apply_date(...)` when blind. |
| `market_service.route_query` blind_block envelope | `ceiling_applied` | Was raw isoformat in the news short-circuit response; now `apply_date(...)`. |
| `_apply_blind_transform` economic items | `realtime_end`, `realtime_start` | Were untransformed; now `apply_date(...)`. FRED can surface either field. |
| `apply_universe_blind_filter` items | `cached_at` | Was untransformed ISO timestamp; now `apply_date(...)`. |

## Why

Team F's zero-leak gate (`tests/e2e/test_blind_benchmark_zero_leak.py`) greps for `_DEFAULT_UNIVERSE` ticker symbols AND the `\d{4}-\d{2}-\d{2}` date pattern across **every blinded MCP response** — body AND envelope. The initial Team B transform pass covered `items[]` only and treated the surrounding envelope (`ceiling_applied`, `rate_limit_reset`, `earliest_available`, the news short-circuit envelope, `cached_at`) as out-of-scope metadata. That was wrong-by-design: the agent reads the entire JSON response, and a raw ISO date in the envelope is identical-as-a-leak to an ISO date in `items[]`.

The gate caught **5 distinct envelope-level leak paths** that the unit-tier tests (which mocked only `items[]`) had missed:

1. `market_service.route_query` success envelope (Team B's primary surface) — 2 fields (`ceiling_applied`, `rate_limit_reset`).
2. `market_service.route_query` `data_unavailable_at_simtime` envelope — 1 field (`earliest_available`, parsed from `_parse_earliest_available(response.error)`).
3. `market_service.route_query` `_NEWS_BLIND_BLOCK_ENVELOPE` short-circuit — 1 field (`ceiling_applied` defaulted to raw ISO).
4. `_apply_blind_transform` economic-type items — 2 fields (`realtime_end`, `realtime_start`) that the field-list omitted.
5. `apply_universe_blind_filter` items — 1 field (`cached_at`) that the field-list omitted.

Each leak compiled and tested green in isolation. Only the end-to-end grep — `assert ticker NOT in json.dumps(resp); assert re.search(r"\d{4}-\d{2}-\d{2}", json.dumps(resp)) is None` — surfaced them. The pattern of "items mock returns the right shape but the envelope is built by the service layer with raw stdlib calls" is exactly the kind of Codex failure mode that adversarial review catches but Codex-style test-mocking misses.

## Pattern

For every new envelope field added to a blind-eligible MCP response surface:

1. Identify the field's **type**: is it a wall-clock ISO date string, a `datetime.isoformat()` call, or a structural identifier (e.g., a ticker)?
2. If type is ticker or wall-clock date → route through `apply_ticker(value, mapping)` or `apply_date(value, mapping)` when `session.config.blind=True` AND `session.blind_mapping is not None`.
3. If type is a structural identifier that is NOT a ticker (e.g., FRED `series_id`, scenario index, run_id) → leave unblinded; the requirements doc allows structural reasoning.
4. Add a grep regression to `tests/e2e/test_blind_benchmark_zero_leak.py` — exercise the surface, dump the response to JSON, assert no real-ticker substring and no `\d{4}-\d{2}-\d{2}` substring.

The grep gate is the only assertion that catches the full surface. Unit tests can mock `items[]` correctly while the envelope is leaking. Treat the grep as the load-bearing test; treat the field-level transform tests as documentation.

## Out of Scope

- Blanket sanitization of all `datetime.isoformat()` calls across the codebase — only the response surfaces that flow out of blind sessions need the transform.
- Reverse blinding on input — the agent submits orders with real tickers today (architectural gap for owner-tools-via-MCP, tracked in `docs/decisions/blind-benchmark-architecture.md` known gaps).
- New plugin types beyond price/news/fundamentals/filings/economic — V2 problem if scenarios add sentiment / alternative-data plugins to the agent surface.

## Follow-ups

- Any new field added to `PluginResponse.envelope` MUST follow the pattern above. The grep test will catch regressions, but the field-list documentation in `_apply_blind_transform` should be updated in the same PR.
- Consider extracting a generic `blind_isoformat(dt: datetime, session: Session) -> str` helper if the call sites multiply — V1 has 6 sites, all in `market_service.py`, so the inline pattern is fine.

## Extension 2026-05-20 — Owner-view tools included (Codex bug 50abd05e)

The original decision treated owner-view tool surfaces (`submit_order`,
`cancel_order`, `get_portfolio`, `get_equity_curve`, `get_trace`,
`advance_time`, `get_sim_time`, `complete_session`) as out of scope under
a "Reveal hot-swap contract" — the assumption being that authenticated
callers see real data and only the public viewer is blinded.

Codex bug `50abd05e` (2026-05-20) showed this assumption was incompatible
with the blind-benchmark feature: the agent under evaluation IS the
session owner, so it reaches the authenticated owner-view surface
directly. Owner-view leaks = the actual bug.

New scope: when `session.config.blind=True` AND `session.blind_mapping`
is populated, ALL response surfaces (owner-view and public-view) must
apply `apply_ticker` / `apply_date` to body items AND envelope fields.
The grep gate at `tests/e2e/test_blind_benchmark_zero_leak.py` now
exercises owner-view tools so a future regression trips the gate.

`real_time` (wall-clock-now timestamp on trace entries) remains exempt —
it carries no market-data signal and the gate strips it from the blob
before grep'ing. See `finlet/api/serializers.py:97` and
`finlet/mcp/tools_portfolio.py:_blind_trace_payload` for the exemption.

Input-side reverse-mapping: when `session.blind_mapping is not None`,
MCP tools that accept a ticker (`submit_order`, `get_price_data`,
`get_fundamentals`) reverse-map the agent-supplied opaque ticker to the
real symbol before dispatch. Unknown opaque ids return a generic error
that does NOT echo the supplied value or the real universe.

## Extension 2026-05-20 — Error paths + completion payload + metadata cross-validation

The original gate at `tests/e2e/test_blind_benchmark_zero_leak.py` exercised
the SUCCESS path of every MCP tool on a blind session. Codex's
2026-05-20 blind-benchmark dry-run found three orthogonal leak classes
that the success-only gate missed:

| Bug ID | Class | Symptom |
|---|---|---|
| `d1baf1b8` | Error envelope | `advance_time` overrun raised `ValueError` whose `str(e)` baked in `session.end_time.isoformat()`; the tool's `{"error": str(e)}` envelope leaked a real ISO date out of a blind session. |
| `ad919e11` | `complete_session` final payload | The `benchmark_complete` envelope shipped a rendered `results_table` string + an `export` dict whose `scenarios[].scenario_id` enumerated real scenario labels (`bull_run`, `covid_crash`, ...) and whose `created_at` / `completed_at` were raw ISO strings. The mid-run `benchmark_transition` envelope only — exercised by the original gate — masked the leak because the rendered table + export dict only get built at finalization. |
| `53c9eccb` | Metadata-vs-reality | `list_available_tickers` rows defaulted `has_prices=False` / `has_fundamentals=False` for synthesised-fallback rows. Agents saw `T_NNNN has_prices=False` while `get_price_data(T_NNNN)` actually succeeded — a divergence the agent could exploit as a side-channel into the real universe membership. |

The fixes shipped in PRs:

| PR | Fix |
|---|---|
| #117 (`73009e2`, 2026-05-20) | Closed 8 owner-view leaks + opaque-ticker input reverse-mapping; extended the gate to exercise 14 owner-view tools. |
| (this PR, Team A 2026-05-20) | `apply_universe_blind_filter` synthesised-fallback rows default `has_prices=True` / `has_fundamentals=True` — universe membership IS the positive availability signal. |
| (this PR, Team B 2026-05-20) | `@blind_error_mapper` decorator applied to every `@mcp.tool` handler — auto-blinds any `str(exc)` and any top-level `error` / `message` / `detail` string field in the success envelope when the session is blind. |
| (this PR, Team C 2026-05-20) | `complete_session` `benchmark_complete` envelope: `results_table` rendered from a shadow `ScenarioResult` list with `Scenario_N` scenario_ids; `export` built via `build_export_dict(blind_mapping=...)` which now blinds `scenarios[].scenario_id` / `scenarios[].session_id` / `created_at` / `completed_at`. |

### New invariant

> Error responses, the `complete_session` `benchmark_complete` payload
> (including `results_table` AND `export.scenarios[].*`), AND
> availability-metadata fields MUST all be blind-clean AND MUST agree
> with actual query results. The gate at
> `tests/e2e/test_blind_benchmark_zero_leak.py` enforces all three
> clauses.

### Test surfaces

Each clause is enforced by a dedicated test function in
`tests/e2e/test_blind_benchmark_zero_leak.py`:

| Clause | Test function | What it greps / asserts |
|---|---|---|
| Error envelopes are blind-clean | `test_blind_benchmark_error_paths_zero_leak` | 16 error cases across every owner-view tool (`start_benchmark` conflict, unknown opaque ticker on `get_price_data` / `get_fundamentals` / `get_filings` / `submit_order`, invalid `series_id` on `get_economic_data`, bogus `session_id` on every session-scoped tool, invalid order side, non-existent `order_id`, invalid interval + overrun `target_date` on `advance_time`, double-completion). Concatenated blob grep'd for `_FORBIDDEN_TICKERS` + `_ISO_DATE_RE`. |
| `complete_session` final envelope is blind-clean | `test_blind_benchmark_complete_session_payload_zero_leak` | Drives all 5 scenarios to completion. Greps `results_table` (string) for real ticker / ISO / scenario_id. Recurses through `export` (including `export.scenarios[]`), asserts every `scenarios[i].scenario_id.startswith("Scenario_")`, every `scenarios[i].session_id is None`, every `created_at` / `completed_at` starts with `Day_`. Full envelope grep'd as defense-in-depth. |
| Metadata matches reality | `test_blind_benchmark_metadata_matches_reality` | For every `list_available_tickers` row: cross-checks `has_prices` claim against `get_price_data` result (both directions). For `has_fundamentals` the negative direction is enforced (a `False` claim cannot be served items); the positive direction depends on MCP-layer plugin-dispatch wiring that is outside the blind-benchmark scope. |

### Drift policy

Adding a new MCP tool: in the same PR, add an error-path case to
`test_blind_benchmark_error_paths_zero_leak`. The grep is the
load-bearing assertion — the assertion lists are intentionally generic
so the new tool's response is folded into the blob without needing
per-tool helper code.

Adding a new field to the `benchmark_complete` envelope: in the same
PR, extend `test_blind_benchmark_complete_session_payload_zero_leak`'s
recursion to include the new field, or rely on the full-envelope grep
to catch a generic leak. Either way the test must be updated.

Adding a new availability column to `list_available_tickers`: extend
`test_blind_benchmark_metadata_matches_reality` with a cross-validation
pass for the new column, or document why it cannot be cross-validated
against a corresponding query tool.
