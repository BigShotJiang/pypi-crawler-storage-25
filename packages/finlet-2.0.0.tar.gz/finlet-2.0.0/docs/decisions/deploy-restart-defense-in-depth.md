# Decision: Defense-in-Depth Worker-Turnover Assertion on Every Deploy

**Date:** 2026-05-16
**Status:** Accepted
**Source:** Incident on run `25954130891` (deploy SHA `d0461d6`, USER_MANUAL_OVERHAUL gitleaks-fix) — `deploy.yml` reported success but `gunicorn` workers were still running pre-deploy code. Manual `aws ssm send-command` to restart `finlet` was required to recover. The follow-up release run `25955425335` (`9a88842`) did NOT reproduce the bug — so it is intermittent, not always-on.

## Context

`deploy/deploy.sh` runs `sudo systemctl restart finlet` and then loops `curl /v1/health` until it returns HTTP 200. The "success" condition was: HTTP 200 from `/v1/health`. **The script never asserted that the workers actually re-spawned with new code.**

On run `25954130891` the post-deploy probe later showed `MainPID 701238` with uptime exceeding the deploy's total runtime — i.e., workers were the SAME process as before the deploy, running pre-`d0461d6` code. `/v1/health` returned 200 anyway because the route didn't touch any of the user-manual changes. Job exit-code: 0. Deploy "success" reported. The bug was caught hours later only because `/mcp/` was still returning the pre-deploy `Deprecation: true` header.

Root cause for the original `systemctl restart` no-op is unknown (see handoff). Candidate hypotheses:

- `systemctl restart` returned without actually restarting (in-flight signal masked SIGTERM, or some systemd quirk under load)
- New PID started, crashed silently, and the master forked a child that re-inherited pre-restart imports somehow
- Race with the `git pull` step (workers re-spawned before the working tree update)

This decision does NOT root-cause the original bug. The fix is defense in depth: the script must REFUSE to declare success unless it can prove worker turnover happened AND workers serve the new code.

## Decision

Three complementary asserts land in one PR:

1. **Pre/post-restart MainPID flip** (`deploy/deploy.sh`): capture `systemctl show $SERVICE_NAME --property=MainPID --value` before and after `systemctl restart`. If `OLD_PID != "0" && OLD_PID == NEW_PID`, `die` immediately with a clear error message. Same check applied to `finlet-mcp` when enabled. The `"0"` guard handles cold-start (first-ever deploy on a fresh box has no service yet).
2. **`git_sha` field on `/v1/health`** (`finlet/api/routes_health.py`): a new `_build_git_sha()` helper runs `git rev-parse --short HEAD` once per worker (cached via `lru_cache(maxsize=1)`) with cwd `/opt/finlet` and a 2s subprocess timeout. The result lands in every `/v1/health` response. Local-dev fallback returns `"unknown"`.
3. **Post-deploy SHA verification** (`deploy/deploy.sh`): replace the health-check loop. Read `EXPECTED_SHA=$(git -C $APP_DIR rev-parse --short HEAD)`, then on every health response parse `git_sha` via `python3 -c 'import json'` and assert `ACTUAL_SHA == EXPECTED_SHA`. Two distinct `die` paths: one for "no HTTP 200 within retries" (falls through to rollback), one for "200 but SHA mismatch" (fails loudly via `die`).

Why both checks (not just one): they catch different failure modes. The MainPID flip catches the *original* observed bug (`systemctl restart` no-op'd). The SHA cross-check catches a hypothetical *new-master-but-stale-children* scenario where MainPID flipped but the workers somehow still hold pre-deploy module state.

## Why `/v1/health` and not a dedicated endpoint

Every field on `/v1/health` becomes a public API contract once shipped. `git_sha` is the minimum surface needed for the deploy check. The endpoint is already unauthenticated, already in the keep-list (see `.claude/rules/api-routes.md` "REST surface shrink"), and already polled by the deploy script — adding one field is the smallest viable change.

## Why `lru_cache` instead of capturing at module import time

`lru_cache(maxsize=1)` runs the subprocess on first call only, then returns the cached value for the worker's lifetime. Same effective behavior as module-import-time capture, but: (a) survives a corner case where `subprocess` is unavailable at import time, (b) makes the helper trivially testable via `_build_git_sha.cache_clear()`, (c) avoids work on workers that never serve `/v1/health` (e.g. a worker that dies during startup).

## What this does NOT cover

- Does NOT root-cause the original `systemctl restart` no-op. If the bug recurs with the new asserts in place, the deploy fails loudly via the MainPID `die` and we get a sharper signal for postmortem.
- Does NOT change rollback behavior. The "no HTTP 200" path still falls through to `rollback.sh` (the SHA-mismatch path uses `die` to fail loudly without auto-rollback — operator decides whether to restart or roll back).
- Does NOT touch `ci.yml` `paths` allowlist. The docs-paths-ignore drift is out of scope.

## References

- Memory: `feedback_deploy_restart_silent_failure.md`
- Bug occurrence: GitHub Actions run `25954130891`, deploy SHA `d0461d6`, dated 2026-05-16
- Code under change: `deploy/deploy.sh` (restart block + health loop), `finlet/api/routes_health.py` (`_build_git_sha` + field), `finlet/api/schemas/health.py` (`HealthCheckResponse.git_sha`), `tests/api/test_routes_health.py` (new test file).
