# Public-trace redaction chokepoint

**Status:** Accepted, 2026-05-22.

**Context.** Codex bug `9a7d7f07` (2026-05-22) reported a PII leak in
the anonymous public-session trace endpoint:

```
GET /v1/public/sessions/{id}/trace
```

For non-blind sessions with `public=True`, the response body included
every trace entry's `request_params` verbatim — and `request_params`
carried a `_user_id` field equal to the owner's `user.id`, smuggled in
by the API-layer market-service mutation at
`finlet/api/services/market_service.py:767`:

```python
plugin_rate_limited = plugin_type in PLUGIN_RATE_LIMITED_TYPES
if user is not None:
    await check_market_data_rate(user)
    if plugin_rate_limited:
        await check_plugin_rate(user, "finnhub")
        # Inject user ID so the plugin (or downstream) can correlate.
        params["_user_id"] = user.id   # ← in-place mutation
```

The same `params` dict was then handed to
`session.trace.record(... request_params=params)` and persisted via
`save_trace_entry` to `~/.finlet/sessions/{id}/session.db`. The blind
walker in `trace_data` is skipped for non-blind sessions, so the key
landed on disk AND on the wire.

Beyond `_user_id`, the broader leak class is: any owner-identifying
string anywhere in a trace payload — including under non-denylisted
keys (Codex STRONG #10), e.g. a debug note that mentions `user.id`
verbatim. Stripping just `_user_id` is necessary but not sufficient.

**Decision.** Two-layer fix:

1. **Write-time stop.** `finlet/api/services/market_service.py` no
   longer mutates the caller's `params` dict. The pre-fix comment said
   "the plugin (or downstream) can correlate", but a grep over
   `finlet/plugins/` confirms no plugin actually reads `_user_id` from
   `params` (the `finnhub_plugin.py:118` docstring mention is advisory
   only — per-user rate limiting fires at the API layer BEFORE plugin
   dispatch, see `market_service.py:762-765`). The mutation is removed.
   If a future plugin needs `user.id`, take it as a typed parameter on
   the plugin call instead of as a magic field smuggled through
   `params`.

2. **Read-time redactor (chokepoint).** A new module-level helper
   `_public_redact_payload(payload, *, owner_id)` in
   `finlet/api/serializers.py` runs recursively over trace payloads:

   - Drops dict keys matching the denylist
     (`user_id`, `email`, `phone`, `api_key`, `bearer_token`,
     `mfa_code`, `oauth_token`, `owner`) OR starting with `_`. The
     `_*`-prefix catches `_user_id` and any future API-layer
     pre-fix-style mutation.
   - Replaces string values at any depth that contain `owner_id` as
     a substring of length ≥ 8 chars with `"[REDACTED]"`. This is
     the load-bearing line for Codex STRONG #10 — owner-id under
     non-denylisted keys.

   The `trace_data` serializer takes two new kwargs:
   `public_surface: bool = False` and `owner_id: str | None = None`.
   When `public_surface=True`, the redactor runs AFTER the blind
   walker so blind + public_anonymous sessions get opaque tickers +
   `Day_N` dates AND no PII. If `public_surface=True` but
   `owner_id is None`, the serializer raises `ValueError` —
   fail-loud at integration sites.

3. **Route wiring.** `finlet/api/routes_public_session.py` updates
   the trace endpoint to opt in:

   ```python
   return trace_data(
       session,
       blind_mapping=_blind_mapping_for(session),
       public_surface=True,
       owner_id=session.user_id or "",
   )
   ```

   The `or ""` handles orphan sessions (no user_id) — the key-denylist
   pass still runs while the substring scan becomes a no-op.

**Grep gate.** `tests/api/test_public_session_pii_hygiene.py`
asserts both `_user_id` key absence AND the actual owner-id value
absence (≥8-char substring scan) on every public read endpoint
(`/v1/public/sessions/{id}/{trace,portfolio,history,orders}`). Test
fixtures use low-entropy multi-character ids (`user_alice_long_001` —
19 chars) to exercise the 8-char floor without tripping gitleaks.

**Why default-False kwarg.** The other two `trace_data` callers
(`routes_portfolio.get_trace` for the authenticated owner-view, and
`routes_sse._generate_events` for the SSE stream) stay unchanged.
Owner-view callers SHOULD see their own `user_id` (it's their session).
Default-False means no churn at existing callsites; only the
public-anonymous surface opts in. Per Codex STRONG #9: if SSE becomes
anonymous-public-readable in the future, set `public_surface=True` on
that call too.

**Scope. Explicitly DROPPED per Codex STRONG #8:** the benchmark
export surface (`build_export_dict` in
`finlet/leaderboard/reporting.py`) carries benchmark metadata +
scenario metrics only — no `request_params` / `response_summary`
payloads. A redactor over this surface is vacuous and was not added.

**Performance.** The redactor is a pure-Python recursive walker over
dicts/lists/strings; on a typical trace entry it inspects ~10-30
dict keys + ~10-50 string values. Overhead is negligible compared to
the existing blind walker (which runs the same shape walk for blind
sessions).

**Future regression catch.** If a new key is added to a trace payload
that contains owner-identifying data under a name not in the
denylist, the substring-value scan catches it as long as the owner
id's character length is ≥ 8 (real `user.id` values are UUIDs / long
opaque tokens — always well above the floor). The 8-char threshold
avoids false-positive matches on incidental short ids.

**References.**

- Codex bug 9a7d7f07 (2026-05-22).
- Codex STRONG #9: SSE future-readability contract.
- Codex STRONG #10: recursive value scan under innocuous keys.
- Codex STRONG #8: benchmark export DROPPED from scope.
- `tests/api/test_public_session_pii_hygiene.py` — grep gate.
- `finlet/api/serializers.py::_public_redact_payload` — implementation.
- `finlet/api/services/market_service.py:762-790` — write-time stop.
- `finlet/api/routes_public_session.py::get_public_session_trace` — wiring.
