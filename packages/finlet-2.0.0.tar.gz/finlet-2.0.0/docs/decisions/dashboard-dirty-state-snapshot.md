# Decision: Per-Loader Snapshot Pattern for Dashboard Settings Dirty-State Tracker

**Date**: 2026-04-28
**Status**: Accepted

---

## Context

Two consecutive bug-hunt iterations (`20260428T031818Z2efa`, `20260428T163727Z4f4f`) shipped real-broken patches against the Settings page dirty-state tracker:

1. **`settings-dirty-banner-onload`** (`20260428T031818Z2efa`) — Settings page Profile tab fired "You have unsaved changes" banner on every load before any user input. False-positive dirty state. Patched with a one-frame `requestAnimationFrame` deferral (commit `1f9c126`).
2. **Plugins-tab dirty banner** (`20260428T163727Z4f4f`) — same banner fired on initial Plugins tab load with zero user interaction. The Plugins tab uses a slower async chain (multiple `apiFetch` calls + dynamic card rendering) and the rAF deferral was not enough.

Same shape across both iterations: form-dirty tracker captured `originalValues` baseline before async loaders populated fields. After loaders completed, fields differed from baseline → tracker reported dirty → banner fired. The Profile-tab fix patched the symptom (one specific loader) without fixing the convention. Each loader has a different async depth, so "wait one frame longer" doesn't generalize.

Root cause: the tracker treated the form as a synchronous unit — snapshot once at mount, compare on every input change. Async loaders that populate fields after mount were an unmodeled state. The Notifications and Appearance loaders happened to call `markClean(...)` after their writes (which is why those tabs never tripped the bug); Profile, MFA, API Keys, and Plugins did not.

---

## Decision

Replace the single-shot `originalValues = readForm()` baseline with a per-loader snapshot pattern in `dashboard/settings.js`. Each async loader explicitly declares which fields it owns and snapshots them into `originalValues` AFTER its `await` resolves.

### 1. The helpers

```js
// Re-snapshot a declared set of input ids into originalValues; drop them from dirtyFields.
function snapshotFields(fieldIds) {
    fieldIds.forEach(id => {
        const el = document.getElementById(id);
        if (!el) return;
        originalValues[id] = (el.type === 'checkbox') ? el.checked : el.value;
        dirtyFields.delete(id);
    });
    updateUnsavedBanner();
}

// Re-snapshot every .form-input / .form-select / .form-textarea / .toggle-switch input
// (used after dynamic renders where the trackable-field set changes — Plugins cards, API Keys table).
function snapshotAllTracked() { ... }
```

### 2. Loader contract

Every async loader that writes form values MUST call `snapshotFields([...])` (or `snapshotAllTracked()` for dynamic-render loaders) immediately after its writes. The id list explicitly enumerates which fields the loader owns:

```js
async function loadProfile() {
    const data = await apiFetch('/profile');
    document.getElementById('profile-name').value = data.name;
    document.getElementById('profile-email').value = data.email;
    document.getElementById('profile-bio').value = data.bio;
    document.getElementById('profile-timezone').value = data.timezone;
    snapshotFields(['profile-name', 'profile-email', 'profile-bio', 'profile-timezone']);
}
```

### 3. Adding new fields

Adding a new tracked field to an existing loader requires updating that loader's `snapshotFields` id list in the same commit. Adding a new loader for a new settings tab requires the loader to call `snapshotFields([...])` after its writes — the convention is enforced by review against `dashboard/settings.js`'s existing call sites.

---

## Consequences

### Positive

- **Structural elimination of the recurrence shape.** Async-loader writes cannot trip the dirty banner because each loader rebases its own fields. The bug class is structurally impossible as long as the loader-contract is followed.
- **Explicit ownership.** Every loader declares the field set it populates; review can flag "loader writes to field X but doesn't snapshot it" as a missing call.
- **Generalizes across async depth.** Whether a loader awaits one fetch or four, the rebase happens after all writes — no dependence on rAF timing or microtask order.
- **Reversal path is a single revert per merge commit (~15 minutes).** The diff is mechanical (helpers + loader sites in `dashboard/settings.js`).

### Negative

- **Convention is enforced by review, not the language.** A new loader that forgets `snapshotFields(...)` will reintroduce the false-positive banner for its tab. Mitigation: every existing loader is a worked example; the helper docstrings (`dashboard/settings.js` lines ~118-129) explicitly call out the contract.
- **Field-list duplication.** Each loader's `snapshotFields` id array duplicates the field set the loader writes. If a loader adds a field but forgets to update the snapshot list, that field will trip a false-positive on cold load. Mitigation: the lists are short and co-located with the writes; review catches the drift.
- **The optional `dashboard/form-dirty-tracker.js` extraction** (called out as "optional, recommended" in the refactor plan) was deferred in this iteration. Settings is the only consumer today; if a second settings-style page emerges, the extraction is mechanical.

### Trade-offs explicitly chosen

- **Per-loader explicit snapshots over a "wait for all loaders to settle" sentinel.** A central sentinel would require every loader to register itself and signal completion; the per-loader pattern keeps the contract local to each loader and avoids a global completion barrier. Cost: the field-list duplication noted above.
- **Keep the `requestAnimationFrame` rebase in `initFormTracking`.** It's a belt-and-suspenders pass that catches any loader the convention missed; the per-loader snapshots are the primary mechanism, the rAF rebase is a fallback that absorbs un-converted call sites during incremental migration.
- **No runtime warning when a field is written without being snapshotted.** A future dev-mode wrapper around `el.value = ...` could log unsnapshotted writes, but it adds machinery without paying for itself given the small loader count.

---

## References

- Plan: `docs/refactor/dirty-state-tracker/plan.md`
- Implementation: `dashboard/settings.js` (helpers `snapshotFields` / `snapshotAllTracked` at lines ~130-156; loader call sites in `loadProfile`, `loadMfaStatus`, `loadApiKeys`, `loadPlugins`, `loadNotifications`, `loadAppearance`)
- Symptom-patch (superseded): commit `1f9c126` (one-frame rAF deferral)
- Refactor queue entry: `docs/bug-hunt/refactor-queue/dirty-state-tracker.md`
- Recurrence ledger: `docs/bug-hunt/ledger.jsonl`
