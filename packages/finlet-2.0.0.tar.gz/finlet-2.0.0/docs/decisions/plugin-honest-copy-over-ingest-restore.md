# Plugin Honest-Copy on Permanent-Degraded Health (over Restoring Cut Ingest UI)

**Status:** Adopted
**Date:** 2026-05-07
**Iteration:** bug-hunt `20260507T163535Z3ac5` (Team C, merge `38b41d7`)
**Files:** `finlet/plugins/news_plugin.py`, `finlet/plugins/sentiment_plugin.py`, `tests/plugins/test_news_plugin.py`, `tests/plugins/test_sentiment_plugin.py`

## Context

The 2026-05-06 UI write-path launch cut (commits `ce57ac8`, `d41aa95`; see `docs/decisions/ui-removal-launch-cut.md`) moved `dashboard/settings.js` (including the Plugin Ingest button affordance at lines `:995-1006`) to `legacy/dashboard-ui/settings.js`. The cut closed the dashboard write-path on plugin configuration; the production dashboard is now read-only for plugin status.

The cut did NOT touch any producer-side messages that referenced the cut affordance. Two plugin probes continued to emit DEGRADED health with copy that pointed at the now-cut button:

```python finlet/plugins/news_plugin.py:475-486
return PluginHealth(
    status=PluginHealthStatus.DEGRADED,
    message="No cached news data files found. Run ingestion first.",
)
```

```python finlet/plugins/sentiment_plugin.py:461-469
return PluginHealth(
    status=PluginHealthStatus.DEGRADED,
    message="No cached sentiment data files found. Run ingestion first.",
)
```

The blind agent in iteration `20260507T163535Z3ac5` flagged this as a permanent-degraded-no-action dead end: the dashboard's Plugin Health panel showed two persistent orange warnings with no UI path to act on the "Run ingestion first" guidance. A new user landing on the dashboard saw a broken-looking surface with no recourse.

Distinct from the iteration `20260502T142726Z7b36` `plugin-ingest-stub-endpoint.md` decision (which shipped a stub `POST /v1/plugins/{name}/ingest` + an Ingest button in `dashboard/settings.js` to close the dead-affordance contract by RESTORING the UI), the 2026-05-06 launch cut REMOVED the Ingest button entirely from production. The two decisions sit on opposite sides of the same fork: the earlier decision restored the UI affordance; this decision accepts that the UI is permanently cut and updates the producer-side message instead.

## Decision

**Update the producer-side messages in `news_plugin.py` and `sentiment_plugin.py` to honest no-op copy that does NOT promise an affordance.** The new copy:

- Removes the literal string `"Run ingestion first"` from both plugins.
- Tells the user the data feed is unavailable for the current launch scope.
- Does NOT instruct a "first" step that has no UI to act on.
- Preserves the `PluginHealthStatus.DEGRADED` classification (the data IS unavailable, the status is correct — only the message text changes).
- Preserves the existing `PluginHealthStatus.HEALTHY` fast-path message (`"OK — {N} cached files"`) verbatim, because the cache-populated path IS reachable when the data lake is populated.

The fix lives entirely in the plugin layer; no dashboard, route, or schema change is needed.

## Alternatives Considered

### A. Restore the Ingest button (revert the launch cut for this surface)

**Rejected.** The 2026-05-06 launch cut was a deliberate scope-narrowing decision (see `docs/decisions/ui-removal-launch-cut.md`) — production dashboard is read-only post-launch, plugin configuration moves entirely to the CLI (`finlet plugins add`, `finlet plugins remove`). Restoring the Ingest button on news_plugin and sentiment_plugin alone would create a partial-cut dashboard (some plugins have UI affordances, others don't) — confusing for users, awkward to maintain, and at odds with the launch-cut intent. The right way to restore plugin-config UI is a post-launch decision against the full launch scope, not a one-off restoration to close a single bug-hunt iteration.

### B. Hide the news_s3 + sentiment plugin rows from the Plugin Health panel entirely

**Rejected.** The plugins are still registered server-side; hiding them from the dashboard creates a different dead-end (user pip-installs the plugin, sees no UI feedback that anything happened). The plugin status SHOULD render — only the "Run ingestion first" guidance was bad. Hiding the rows would also degrade the operator experience (the panel is the canonical "is the data lake healthy?" surface for ops monitoring).

### C. Keep the message; add a `<details>` block with CLI instructions

**Rejected.** The message lives in the plugin's `PluginHealth.message` field — a plain string, not HTML. Adding a `<details>` block would either require server-side HTML rendering (banned by trusted-types; see `docs/decisions/dashboard-event-bus.md` and `scripts/lint-trusted-types.sh`) or a render-side parser that scans `message` for embedded markup (a new dashboard convention to maintain). The honest no-op copy achieves the same user-facing outcome (no false promise) without introducing markup-in-message.

### D. Leave the message as-is; add the Ingest button back to settings.js

This is functionally the same as Alternative A and was rejected for the same reason — it re-opens the launch-cut surface for a single bug.

## Consequences

**User-facing:** The Plugin Health panel still shows news_s3 and sentiment as DEGRADED (correct — the data IS unavailable for the launch scope), but the message text no longer points the user at a UI that doesn't exist. The orange warning remains, but it is no longer a dead-end contract bug.

**Operator-facing:** Ops staff investigating plugin health via `GET /v1/plugins/health` see the same DEGRADED status. The reason field is updated to honest copy that matches the launch-scope reality.

**Test coverage:** New regression tests in `tests/plugins/test_news_plugin.py` and `tests/plugins/test_sentiment_plugin.py` assert (a) the new message text, (b) the absence of the legacy `"Run ingestion first"` literal. Drift in either plugin's empty-cache message will fail the targeted test.

**Out of scope this iteration:** Parallel `Run ingestion first` surfaces in `finlet/plugins/price_plugin.py:910-918` and `finlet/plugins/fundamentals_plugin.py:1064-1071` are NOT touched. Both have a real cold-start S3-reachability path (see `docs/decisions/plugin-health-probe-reachability-only.md`) — the message is sometimes actionable for an ops user with S3 write access, even though there's no UI button. The decision to update those messages is deferred to a future iteration that can audit each producer-side affordance reference against the post-launch UI surface area.

## Reversibility

**High.** Single revert of `finlet/plugins/news_plugin.py` + `finlet/plugins/sentiment_plugin.py` (one literal string per file) plus the corresponding test files restores the prior message. The change is text-only; no schema, route, or contract change. ~5 minutes mechanical revert.

If the team later decides to restore the Ingest button affordance (Alternative A), the producer-side message can be reverted in the same change to point users at the restored UI. The decisions are not permanently coupled — this decision closes the dead-affordance contract gap WITHOUT taking a position on whether the UI should eventually return.

## References

- Bug-hunt iteration `20260507T163535Z3ac5` — Finding F4 (`plugin-permanent-degraded-news-sentiment`)
- Triage report: `docs/bug-hunt/20260507T163535Z3ac5/triage.md`
- Plan: `docs/bug-hunt/20260507T163535Z3ac5/plan.md` (Team C section)
- Sister decision (opposite fork): `docs/decisions/plugin-ingest-stub-endpoint.md` — the iteration `20260502T142726Z7b36` choice to RESTORE a UI affordance for the same dead-affordance contract gap, before the 2026-05-06 launch cut.
- Parent decision: `docs/decisions/ui-removal-launch-cut.md` — the 2026-05-06 launch cut that removed the Ingest button.
- Lesson distilled in `docs/LESSONS.md` (entry `[2026-05-07] When cutting a UI affordance, audit producer-side strings that assumed it existed`).
