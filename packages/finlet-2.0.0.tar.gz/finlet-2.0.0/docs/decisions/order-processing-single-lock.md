# Decision: Single-Lock Delegation for Order Processing

**Date**: 2026-03-28
**Status**: Resolved
**Context**: `Session.process_pending_orders` reimplemented the order-fill loop instead of delegating to `OrderBook.process_pending_orders`, creating a race condition under concurrent API calls.

---

## Problem

The `Session.process_pending_orders` method iterated pending orders without holding a lock, calling `OrderBook.try_fill` (acquires/releases lock) and then `Portfolio.execute_buy/sell` (acquires/releases lock) per order. Two separate locks acquired and released per order, with no enclosing lock protecting the full iteration.

### Race condition

1. Tick callback and API handler both call `session.process_pending_orders(prices)` concurrently.
2. Both get the same `pending_orders` snapshot (list of PENDING orders).
3. Both call `try_fill` on the same order -- the first succeeds, changes status to FILLED.
4. The second caller already has a reference to the same `Order` object. Between the fill and portfolio execution, the second caller could also fill and execute, causing double portfolio mutation for the same order.

### Atomicity gap

Even within a single call, the fill and portfolio mutation were two separate lock acquisitions. A crash or exception between them would leave the order marked FILLED but the portfolio not updated -- an inconsistent state.

---

## Options Evaluated

### 1. Add a session-level lock wrapping the entire loop (rejected)

Wrap the existing per-order loop in `async with self._lock`. This would prevent concurrent calls but would not fix the fundamental design issue of reimplementing logic that `OrderBook.process_pending_orders` already handles correctly.

**Cons**:
- Duplicates logic that already exists in `OrderBook`.
- Two lock hierarchies (session lock + order book lock) increase deadlock risk.
- The reimplemented loop diverges from `OrderBook` over time.

### 2. Delegate to OrderBook.process_pending_orders (accepted)

Rewrite `Session.process_pending_orders` to call `OrderBook.process_pending_orders(prices, sim_time)`, which fills all eligible orders atomically under a single lock acquisition. Portfolio mutations happen after the atomic fill batch, using the `fill_price` already set on each order.

**Pros**:
- Single lock acquisition for the entire batch (no per-order lock churn).
- Filled orders have status=FILLED, so no other caller can fill them again (idempotent).
- Single source of truth for fill logic -- no divergence risk.
- Simpler code in Session.

**Cons**:
- Portfolio mutations happen outside the OrderBook lock. This is acceptable because filled orders are already transitioned and won't be re-processed.

### 3. Move portfolio execution inside OrderBook (rejected)

Pass a callback or portfolio reference into `OrderBook.process_pending_orders` so everything happens under one lock.

**Cons**:
- Violates separation of concerns (OrderBook should not know about Portfolio).
- Makes OrderBook harder to test in isolation.
- Unnecessary -- the two-phase approach (atomic fill, then execute) is safe because fill is idempotent.

---

## Decision

Option 2: delegate to `OrderBook.process_pending_orders`. Additionally, wrap `portfolio.execute_buy/sell` in try/except -- if a portfolio execution fails (e.g., insufficient cash), the order is cancelled rather than left in an inconsistent filled-but-unexecuted state.

## Consequences

- Concurrent `process_pending_orders` calls are safe: the first acquires the lock and fills all eligible orders; the second finds nothing to fill.
- No money creation/destruction under concurrency (verified by property-based tests).
- 6 new tests added covering concurrent fills, portfolio consistency, and insufficient cash handling.
