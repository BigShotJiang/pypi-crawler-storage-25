# Decision: Price Plugin Health Probe Reflects S3 Reachability, Not Just Disk Cache

**Date**: 2026-05-01
**Status**: Accepted
**Iteration**: bug-hunt 20260501T234103Z1a49 (Team E, merge `76f4724`)

---

## Context

Bug-hunt iteration `20260501T234103Z1a49` flagged the dashboard's Plugin Health panel as broken: it reported `price` as `Degraded — No cached price data files found. Run ingestion first.` while a MARKET BUY of 1 SPY simultaneously filled at $548.80 with no error. The user-visible state contradicted itself — the data path worked end-to-end, but the health surface said the data path was broken.

Root cause: `PricePlugin._probe()` only inspected the local disk cache:

```python
async def _probe(self) -> tuple[PluginStatus, str]:
    parquets = list(self._cache_dir.glob("*.parquet"))
    if not parquets:
        return PluginStatus.DEGRADED, "No cached price data files found. Run ingestion first."
    return PluginStatus.HEALTHY, ""
```

On cold-start, the cache dir is empty even when S3 is fully reachable and serves quotes. `_query_quote` reads from S3 via `_read_date_range` (which writes the local cache as a side effect on first download); the disk cache is performance-optional, not a health gate. The probe was checking the wrong layer.

Two compounding issues with the prior probe:
1. **Wrong layer.** Disk cache hides the actual failure mode (S3 unreachable) and surfaces a misleading mode ("never populated") on cold-start.
2. **Wrong remediation copy.** "Run ingestion first" is a CLI-side imperative that hosted users on `finlet.dev` cannot act on — they have no `systemctl` access. Same shape as the "Restart server to apply" footgun closed in iter `20260501T172055Z127b`.

---

## Decision

Rewrite `_probe()` to reflect the actual data path (S3) with a short-lived per-instance cache that prevents amplifying poll traffic against AWS.

### Implementation

```python
PROBE_RECENT_DAYS = 7
PROBE_CACHE_TTL_SECONDS = 60

async def _probe(self) -> tuple[PluginStatus, str]:
    # Fast path: cache non-empty → HEALTHY without an S3 call.
    if list(self._cache_dir.glob("*.parquet")):
        return PluginStatus.HEALTHY, ""

    # Cold-start path: check S3 reachability via a recent-day prefix scan.
    # Cached on the instance for PROBE_CACHE_TTL_SECONDS so the dashboard's
    # 2s /v1/plugins/health poll does not amplify against AWS.
    now = monotonic()
    cached = self._probe_cache
    if cached and (now - cached["ts"]) < PROBE_CACHE_TTL_SECONDS:
        return cached["status"], cached["message"]

    try:
        for days_back in range(PROBE_RECENT_DAYS):
            date = (datetime.utcnow() - timedelta(days=days_back)).strftime("%Y/%m/%d")
            prefix = f"daily/{date}"
            response = await asyncio.to_thread(
                self._s3_client.list_objects_v2,
                Bucket=self._bucket,
                Prefix=prefix,
                MaxKeys=1,
            )
            if response.get("Contents"):
                self._probe_cache = {"ts": now, "status": PluginStatus.HEALTHY, "message": ""}
                return PluginStatus.HEALTHY, ""
        # S3 reachable but recent window empty → genuine "never populated"
        self._probe_cache = {
            "ts": now,
            "status": PluginStatus.DEGRADED,
            "message": "No cached price data files found. Run ingestion first.",
        }
        return self._probe_cache["status"], self._probe_cache["message"]
    except (EndpointConnectionError, ClientError, BotoCoreError) as e:
        self._probe_cache = {
            "ts": now,
            "status": PluginStatus.DEGRADED,
            "message": f"S3 unreachable: {type(e).__name__}",
        }
        return self._probe_cache["status"], self._probe_cache["message"]
```

### Three semantically-distinct outcomes

| Cache state | S3 state | Status | Message |
|---|---|---|---|
| Non-empty | (not checked) | HEALTHY | "" |
| Empty | Reachable, recent files exist | HEALTHY | "" |
| Empty | Reachable, recent window empty | DEGRADED | "No cached price data files found. Run ingestion first." |
| Empty | Unreachable | DEGRADED | "S3 unreachable: <ErrorClass>" |

`routes_health._check_price_data_status` translates the message substring `"S3 unreachable"` → `s3_unreachable` for the top-level `data_status` field.

---

## Why caching the probe result for 60s is the load-bearing line

The dashboard polls `/v1/plugins/health` every 2 seconds. Without the cache, every poll triggers an S3 `list_objects_v2` call — 30/min/instance, 1800/hr/instance. With the cache, the poll cost collapses to 1/min/instance.

60s was chosen because:
- It matches the dashboard's tolerable freshness for a health surface (a 1-minute lag in detecting an S3 outage is acceptable for a non-critical-path probe).
- It is short enough that operators see real degradation within the next dashboard auto-refresh cycle.
- It is per-instance (not Redis-backed), so multi-instance deployments (post-launch) will still issue at most N calls/min where N = instance count.

---

## Trade-offs

### What we gained

- Health surface now matches the actual data path. Plugin Health = HEALTHY when quotes succeed; DEGRADED only when the data path is genuinely broken.
- Two distinct failure modes (S3 unreachable vs. "never populated") get distinct error messages, so operators can act on the right thing.
- 60s cache keeps poll amplification bounded.

### What we accepted

- A 60s window where the probe cache disagrees with reality. Acceptable for a non-critical-path probe.
- One additional `boto3` call per cold-start probe (mitigated by `MaxKeys=1` + early termination on first hit).
- The probe's per-instance cache resets on instance restart. Acceptable; restart frequency is low.

### Alternatives considered and rejected

- **Probe via a real `_query_quote` call against a known-good ticker (e.g., SPY).** Rejected: introduces a market-data fetch on every health poll and depends on enforcer/clock state. The S3 prefix scan is cheaper and more directly targeted at "is the data path reachable?"
- **Probe via HEAD on the S3 bucket itself.** Rejected: bucket HEAD doesn't validate the prefix path that quotes actually use; it's possible (though unlikely) for the bucket to be reachable but the data prefix unreadable.
- **Drop the cache and rely on S3's own connection pooling.** Rejected: AWS billing is per-request, not per-connection. Even pooled connections cost money on every poll.

---

## Reversal path

Single SHA. Restore the previous `_probe()` body (cache-only check) and remove the `PROBE_*` constants and `_probe_cache` instance attribute. The new tests in `tests/api/test_plugin_health.py` and `tests/plugins/test_price_plugin.py` would need updates to remove the S3-mock fixture and the cache-TTL assertion. ~15 minutes total revert.

---

## References

- Refactor commit: `76f4724` (Team E merge, bug-hunt 20260501T234103Z1a49)
- `finlet/plugins/price_plugin.py` — `_probe()` at line ~762
- `finlet/api/routes_health.py` — `_check_price_data_status()` translator at lines 24-55
- `tests/api/test_plugin_health.py`, `tests/plugins/test_price_plugin.py` — coverage
- Related lesson in `docs/LESSONS.md`: "Plugin health probes must reflect the actual data path, not the convenience cache"
- Related memory: `feedback_s3_not_equals_queryable.md` — S3 backfill cache pitfall (2026-04-17)
