# Decision: MCP Requires Mandatory Authentication

**Date:** 2026-03-30
**Status:** Accepted (supersedes `mcp-auth-backward-compat.md` and `mcp-session-attribution.md`)

## Context

The previous MCP auth model (decided 2026-03-28) used an optional `api_key` parameter with a `user_id="mcp"` fallback for unauthenticated clients. This backward-compatible approach had a critical flaw: all unauthenticated MCP clients shared the same `user_id="mcp"`, meaning any unauthenticated client could see, modify, and delete sessions created by any other unauthenticated client.

This was acceptable for single-user local stdio development but became a real security concern as the product moved toward multi-user deployment.

## Decision

All 16 MCP tools now **require** the `api_key` parameter. Unauthenticated access is rejected with:

```
"Authentication required. Provide an api_key parameter to access Finlet MCP tools."
```

The `_authenticate()` helper no longer falls back to `user_id="mcp"`. If no `api_key` is provided or the key is invalid, the tool returns an error immediately.

## Consequences

- **Breaking change:** Existing MCP client configurations that relied on unauthenticated access must be updated to include an `api_key`. Clients need to register via `POST /auth/register` and pass the resulting key to every MCP tool call.
- **Eliminates shared namespace:** Each MCP client now has a unique, real `user_id`. Session isolation is enforced — no cross-user visibility.
- **Simplifies auth model:** No more dual-path (authenticated vs sentinel) logic. One code path for all clients.
- **Test impact:** All MCP tests updated to use authenticated access. Tests that previously relied on the "mcp" sentinel now provide a valid `api_key`.

## Alternatives Considered

1. **Keep optional auth with per-connection UUID** — Would isolate unauthenticated clients from each other but still allow anonymous session creation with no identity trail. Rejected because auth is cheap and identity is valuable.
2. **Transport-level auth** — FastMCP stdio doesn't support headers. Deferred until HTTP/SSE transport is adopted.
3. **Keep backward compatibility** — The shared namespace is a real security issue, not a theoretical one. Backward compat is not worth the risk.

## Migration Path

MCP clients must:
1. Register via `POST /v1/auth/register` (or use an existing account)
2. Add `api_key` parameter to every MCP tool call
3. Sessions created under the old "mcp" sentinel are orphaned — they can be cleaned up manually or will age out
