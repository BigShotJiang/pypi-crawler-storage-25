# Decision: `finlet auth login` is Session/CSRF Auth, Not API-Key Minting

**Date:** 2026-05-07
**Status:** Accepted
**Source:** MCP-First Migration Phase 1, audit finding C4 (commit `192333e`, Team B)

## Context

Before this fix, `_AUTH_REJECTED_MESSAGE` in the CLI told users that a rejected `FINLET_API_KEY` could be recovered with `finlet auth login` — but no such command existed. The available recovery paths were `finlet register` (mints a new account + API key) or the dashboard (creates additional API keys for an existing account). Pointing users at a non-existent command produced an unrecoverable error state.

The server has had `POST /auth/login` for credential-based authentication since the AUTH_OVERHAUL completed 2026-03-27. That endpoint returns a session cookie + CSRF token + tier metadata — **not** an API key. API keys are minted by `POST /v1/auth/register` or by the dashboard; `/auth/login` only verifies credentials and starts a browser-style cookie session.

## Decision

Add a new `finlet auth login` Typer subcommand under a new `auth_app` group:

- POSTs to `${FINLET_API_URL}/auth/login` with `{email, password}`.
- On success, prints user identity (`email`, `user_id`, `tier`) and the CSRF `expires_at`.
- Explicitly **does not** mint or surface an API key. The output reminds the user that `FINLET_API_KEY` (consumed by every other CLI command for Bearer auth) is a separate credential — issue one from the dashboard, or use `finlet register` for first-time setup.
- Surfaces structured `error.message` from rate-limit (429) and unauthorized (401) responses via `_print_error` (audit H7).
- MFA-required responses are detected and the user is pointed at the dashboard / authenticator app to complete the challenge — the CLI does not implement TOTP/SMS submission.

## Consequences

- The error message in `_AUTH_REJECTED_MESSAGE` now points at a real recovery path: `finlet auth login` to verify credentials, then issue a key from the dashboard.
- Two distinct credential types co-exist by design:
  - **API key** (`FINLET_API_KEY`): Bearer-style, machine-readable, used by every non-auth CLI command and currently passed as a tool argument to MCP. Phase 4 of the MCP-First migration replaces this with OAuth 2.1.
  - **Session cookie + CSRF token**: Browser-style, short-lived, used by the dashboard and `finlet auth login`. Will outlive the API-key surface — cookies remain the human/dashboard auth path post-Phase-4.
- Phase 4 (OAuth 2.1 + DCR) reuses the `finlet auth login` command name and turns it into a browser-opening OAuth flow that stores tokens in `~/.finlet/credentials`. The current implementation is the credential-verification version of that command; the long-term shape is the OAuth version.

## Alternatives Considered

1. **Rewrite `_AUTH_REJECTED_MESSAGE` to point at the dashboard only.** Rejected — leaves the documented `finlet auth login` recovery path missing, and the dashboard cannot verify credentials from CLI context (e.g., headless environments).
2. **Make `finlet auth login` mint and print a new API key.** Rejected — conflates two credential types, and `POST /auth/login` does not return an API key. Adding a credential-mint side-effect to login would silently rotate keys for users who run `finlet auth login` to verify a password.
3. **Add `finlet auth status` instead.** Rejected — does not address the documented `finlet auth login` recovery path. Could be added later as a complementary command.

## Addendum 2026-05-09: OAuth Login Mode (Phase 4d)

**Date:** 2026-05-09
**Status:** Accepted
**Source:** MCP-First Migration Phase 4d (Team D1) — extends this record with the OAuth-mode shape promised in the original "Consequences §3" line ("Phase 4 of the MCP-First migration replaces this with OAuth 2.1").

### Mode Flip

`finlet auth login` now selects between three modes based on which (if any) flag is supplied:

| Flag combination | Mode | Behaviour |
|------------------|------|-----------|
| _no flags_ | **OAuth Authorization Code Flow with PKCE** (canonical, default) | Opens browser → captures callback on loopback → exchanges code at `/oauth/token` → persists `~/.finlet/credentials` (mode 0600). |
| `--api-key=<key>` | API-key credential verification (legacy) | Calls an authenticated endpoint; reports whether the key works. Audit C4 invariant preserved — verification only, no minting. |
| `--email <addr> --password <pw>` | Email/password credential verification (legacy) | Calls `POST /auth/login`; prints user identity + tier. Audit C4 invariant preserved — verification only, no minting. |

OAuth is the default because the Phase 4a decision record (`docs/decisions/mcp-oauth-2-1-auth-model.md`) locks OAuth 2.1 as the canonical agent-auth surface. The two legacy modes coexist during the 90-day dual-accept window (`docs/decisions/mcp-api-key-sunset.md`) — both surface a structured deprecation trace at the resource server when consumed against MCP tools.

### Token Storage

OAuth credentials persist at `~/.finlet/credentials` with these rules:

- **Path** — `${HOME}/.finlet/credentials` resolved via `os.path.expanduser` so tests can redirect via `monkeypatch.setenv("HOME", ...)`.
- **POSIX mode 0600 enforced on read.** `_load_credentials()` raises `RuntimeError` if the mode bits drift to anything looser, with a remediation message naming `chmod 600` and `finlet auth logout && finlet auth login`. This contract matches the `~/.finlet/plugins.json` legacy and the Phase 4a decision record §5 token-storage contract.
- **JSON shape** — `{"access_token": <JWT>, "refresh_token": <opaque>, "expires_at": <epoch-int>}`. The schema is the minimum viable subset of the Phase 4a §5 spec; `issuer` and `client_id` fields are reserved for a future extension when DCR (first-run client registration) lands.
- **Atomic write at mode 0600.** Linux/macOS use `os.open(path, O_CREAT|O_WRONLY|O_TRUNC, 0o600)` followed by `os.fdopen(...)` plus an explicit `os.chmod` so the file never exists with looser bits. Windows logs a warning and writes without mode enforcement (NTFS ACLs are the cross-platform fallback per decision record §5).

### Refresh-Token Rotation Out of Scope for MVP

The MVP CLI does NOT implement automatic refresh-token rotation. When the access token expires, the user re-runs `finlet auth login` to mint a fresh pair. Rotation is a future improvement — the implementation outline:

1. `_api_headers(api_key=None)` reads `expires_at`; if past, calls `POST /oauth/token` with `grant_type=refresh_token` to mint a new access token (single-use rotation per Phase 4a decision record §5).
2. The new access + refresh tokens replace the file atomically.
3. RFC 6819 §5.2.2.3 reuse-detection contract — a stolen-and-reused refresh token revokes the entire family, surfacing the breach.

This is deliberately deferred to keep the D1 scope bounded. The 15-minute access-token lifetime is short enough that operator friction during the dual-accept window is bounded; `finlet auth login` is the recovery path.

### Client Identity (Option A — hardcoded `client_id`)

The CLI ships with a hardcoded `client_id = "finlet-cli"`. First-run Dynamic Client Registration (DCR via `POST /oauth/register`, decision record §2) is documented as Option B for a future phase — adopting it requires (a) persisting the registered `client_id` alongside credentials, (b) handling the first-run UX of "registering this CLI before logging you in", and (c) coordinating with B3's open-DCR rate-limit budget. The MVP avoids these costs by pre-allocating a stable client_id; the value is a public-by-default OAuth client (RFC 7591 — no `client_secret`, PKCE-only).

### Lineage

This addendum cross-references:

- `docs/decisions/mcp-oauth-2-1-auth-model.md` (Phase 4a — locks OAuth 2.1 + DCR + RI as the canonical agent auth model; §5 locks the 0600 file-mode contract this addendum implements).
- `docs/decisions/mcp-api-key-sunset.md` (Phase 4c — locks the 90-day dual-accept window + scope-vs-tier contract that the legacy `--api-key` and `--email/--password` modes preserve through).
- The Phase 1 origin of this record (above) — which already promised "Phase 4 of the MCP-First migration replaces this with OAuth 2.1." This addendum is the delivery of that promise.

### Logout

`finlet auth logout` deletes `~/.finlet/credentials` if present (idempotent otherwise). It does NOT call `POST /oauth/revoke` server-side — server-side revocation is a future improvement (the refresh token's 90-day absolute lifetime + 30-day sliding-inactivity window per decision record §5 bounds the credential lifetime even without explicit revocation).

## Phase 4e Addendum (2026-05-09): Dual-Accept Window Closed

Phase 4e (PR #36) ships Bearer-only enforcement on the MCP tool surface. The 90-day dual-accept commitment from the Phase 4d addendum is closed: there were no api_key consumers to protect. `finlet auth login` (OAuth path) is the only supported MCP authentication going forward. Legacy `finlet auth login --api-key=$KEY` (REST API key verification) remains supported for the REST surface — that surface is unchanged.
