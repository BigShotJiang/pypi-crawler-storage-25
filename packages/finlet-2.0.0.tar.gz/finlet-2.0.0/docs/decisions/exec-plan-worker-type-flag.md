# Decision: /exec-plan Accepts `--worker-type` to Route SWE Workers to Codex

**Date:** 2026-04-27
**Status:** Accepted
**Revised:** 2026-04-27 — original `/bug-hunt` blanket Codex routing reversed after benchmark review (see "Revision" below). Flag stays in place as a future hook.
**Source:** /bug-hunt skill creation (BUG_HUNT_LOOP_PLAN, Team A)

## Context

`/exec-plan` is the multi-team execution skill: a plan document declares teams (A, B, C, …), and the skill spawns one subagent per team in an isolated worktree, runs them in parallel, and sequentially merges with a micro-gate between each merge. Until this change, the worker subagent type was hard-coded — every team got the default `general-purpose` Claude subagent.

Two recent developments made the hard-coded type a constraint:

1. The Codex Claude Code plugin landed, exposing a `codex:codex-rescue` subagent that drives Codex GPT-5.5 for code-changing work. The original framing assumed GPT-5.5 produced stronger SWE deltas across the board; the post-ship benchmark review (see Revision) narrowed that claim to specific workload types.
2. The `/bug-hunt` loop wants Claude as the orchestrator (it stays in the operator chat, talks to the human, drives `/plan-features` and the merge cadence). The original plan also wanted Codex as the workers; that part was reversed — see Revision.

We needed a way to keep `/exec-plan` orchestration on Claude while leaving the option open to route per-team workers to a different subagent type when a workload actually fits.

## Decision

`/exec-plan` accepts an optional `--worker-type <subagent_type>` flag that overrides the default subagent type used when spawning per-team workers. Default behavior is unchanged — omitting the flag yields the same `general-purpose` Claude (Opus 4.7) workers as before.

The flag is a **future hook**. Codex routing is reserved for narrow cases where GPT-5.5's documented win conditions apply:

- Shell / CLI agent loops (Terminal-Bench 2.0 territory, +13.3 vs Opus)
- Desktop GUI / OSWorld-Verified workloads
- Long-context windows >200K tokens
- Token-efficiency-critical loops where GPT-5.5's ~72% efficiency edge actually shows up at scale

Bug-fix loops on Python/FastAPI/MCP/Pydantic/SQLModel code stay on Opus by default — that workload is SWE-Bench Pro and MCP Atlas territory, where Opus 4.7 leads GPT-5.5 (+5.7 on SWE-Bench Pro).

When invoked for one of the narrow cases above, the flag form is:

```
/exec-plan docs/brainstorms/<plan>.md --worker-type codex:codex-rescue
```

The flag is passed through to the `Agent` tool's `subagent_type` parameter when `/exec-plan` spawns each team's worker. Plan documents, merge gates, micro-gate logic, doc-update phase, and Step 4.5 skill-eval phase are all unchanged — the only difference is which executor runs inside the worktree.

The patch lives at `.claude/skills/exec-plan/skill.md` (commit `7649f73`, +12/-1).

## Revision (2026-04-27)

The original framing of this decision said `/bug-hunt` would invoke `/exec-plan` with a blanket `--worker-type codex:codex-rescue` override, routing every code worker to Codex GPT-5.5. That blanket override has been reversed.

Honest benchmark picture:

- **Opus 4.7 wins** on SWE-Bench Pro (+5.7) and MCP Atlas — the workloads that match realistic Finlet bug fixes (FastAPI routes, MCP tool handlers, Pydantic/SQLModel work).
- **GPT-5.5 wins** on Terminal-Bench 2.0 (+13.3, shell/CLI agent loops), OSWorld-Verified (desktop GUI), long-context >200K, and is ~72% more token-efficient.

None of GPT-5.5's win conditions match `/bug-hunt`'s workload. The blanket override was a downgrade, so it has been stripped from the `/bug-hunt` skill — workers there now default to Opus. The `--worker-type` flag itself stays in `/exec-plan` for the narrow cases above.

### Alternatives Considered

1. **Create a separate `/exec-plan-codex` skill** — rejected as duplication. The orchestration logic, merge gates, conflict handling, doc-update phase, and skill-eval phase are identical between Claude-workers and Codex-workers. Forking the skill would require keeping two copies in lockstep; every future improvement to merge logic or eval phase would need to be made twice. A single skill with a routing flag is the right shape.
2. **Auto-detect worker type from the plan document** (e.g., a `worker_type:` frontmatter key) — rejected for now as premature. The current call sites are `/bug-hunt` (always wants Codex) and direct human invocation (sometimes wants Codex, usually wants Claude). A CLI flag is the simplest interface that covers both. If we later end up with many plan-authored heuristics about which worker fits best, we can promote it to plan-document metadata.
3. **Globally swap `general-purpose` for `codex:codex-rescue` as the default** — rejected. Most `/exec-plan` invocations today are not Codex-appropriate (doc updates, infra tweaks, light refactors). The Claude default is correct for the broad case; Codex is the targeted opt-in.
4. **Wire Codex usage at the plan-document level** (each team declares its own worker type) — rejected as over-engineered for the current need. All teams in a single `/exec-plan` invocation today either all-want-Codex (bug-hunt fix runs) or all-want-Claude (everything else). Per-team override can be layered on top later if a real heterogeneous run shows up.

## Consequences

- **`/exec-plan` is now routable to any registered subagent type.** The flag accepts any string; future plugin subagents (e.g., a hypothetical `gemini:fix`) work without further changes to the skill.
- **`/bug-hunt` runs Opus workers by default.** The original justification — defaulting Codex for `/bug-hunt`'s SWE workload — was reversed after benchmark review (see Revision). Opus wins on SWE-Bench Pro and MCP Atlas, which is what bug-fix loops actually look like in this codebase.
- **The flag is a future hook, not the active path.** It exists for narrow workloads (Terminal-Bench shell loops, OSWorld GUI, long-context >200K, token-efficiency-critical loops) — none of which are the current `/exec-plan` call sites. Until such a workload shows up, the flag is dormant infrastructure.
- **Default behavior is unchanged.** Existing plan invocations, schedule routines, and docs that call `/exec-plan` without the flag continue to behave exactly as before. No migration required.
- **Worker-type compatibility is the caller's responsibility.** `/exec-plan` does not validate that the requested subagent type can handle the team prompt format — if a future subagent type rejects worktree paths or expects a different prompt schema, that is surfaced as a worker error, not caught up-front. For the current `codex:codex-rescue` and `general-purpose` types this is not an issue; both accept the existing prompt shape.
- **Doc-update and skill-eval phases continue to run on Claude regardless of `--worker-type`.** The flag scopes to per-team workers only. Orchestration, merge agents, the doc-update agent, and the eval agent remain Claude — that asymmetry is intentional and is the whole reason the flag exists rather than a global swap.
