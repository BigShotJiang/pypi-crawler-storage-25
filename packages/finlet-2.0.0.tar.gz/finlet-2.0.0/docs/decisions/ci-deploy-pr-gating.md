# Decision: PR-gated CI + Branch Protection on Main (Action 3 of CI/Deploy Stability Reform)

**Date:** 2026-05-06
**Status:** Accepted
**Source:** CI/deploy stability reform (Action 3 — PRs #12 / #14 / #15)

## Context

Until 2026-05-06, Finlet had a single GitHub Actions workflow (`.github/workflows/deploy.yml`) that triggered on every push to `main` and ran `test (matrix 3.12/3.13)` + `security` + `e2e` (Playwright) + `deploy via SSM`. There was no separate CI workflow, no PR gate, and no branch protection on `main`. `main` doubled as the test environment.

A 2026-05-06 audit of the last 100 Deploy Finlet runs surfaced two structural failure modes:

- **60.6% failure rate** (60/99 completed runs failed, worse than the 34.7% over the prior 50 runs).
- **47/60 failures (78%)** were the `e2e / Run Playwright E2E tests` step.
- **41/60 failures (68%)** were commits whose only meaningful change was `docs/`, skill-eval artifacts, or handoff markdown — they cannot logically affect runtime, but each ran the full ~25-min pipeline because `deploy.yml` had no `paths:` filter (Action 2 fixed that filter independently).

A separate observation: the bug-hunt loop was finding 3+ new dashboard regressions per iteration while the CI e2e job was passing cleanly on every push. The CI e2e gate was paying ~12 min per run for near-zero marginal signal — every regression bug-hunt found was one e2e didn't catch.

Two independent audits (Codex + Claude general-purpose) converged on splitting CI from deploy and gating PRs against a smaller, more reliable surface.

## Decision

Split CI from deploy along three axes:

1. **`.github/workflows/ci.yml`** triggers on `pull_request` to `main` and runs the `test` matrix only (Python 3.12 + 3.13: ruff lint → mypy → pytest ≥60% coverage). No e2e, no security, no deploy. Typical run time ~18-20 min.

2. **`.github/workflows/deploy.yml`** triggers only on `push` to `main` and runs `test` (matrix 3.12/3.13) + `security` (Gitleaks → Bandit → Semgrep JS → pip-audit-allowlist) → deploy via SSM. Push-only; never triggered by PR. Typical run time ~6-8 min.

3. **Branch protection on `main`** — required status checks are `test (3.12)` and `test (3.13)` from `ci.yml`. Direct push to main is rejected. Solo-dev policy: 0 required reviewers, no force-push, no deletion, allow auto-merge enabled. The `.claude/skills/exec-plan/skill.md` skill was updated to push merges via `gh pr create → gh pr checks --watch → gh pr merge --rebase --delete-branch` so it threads through the protected gate.

**E2E was deliberately dropped from CI gating** (PR #14, commit `17821b0`). The decision was driven by data: bug-hunt was finding 3+ regressions per iteration that CI e2e missed. We pay the e2e cost where it has signal:

- **Pre-push e2e smoke** (`scripts/e2e-smoke.sh`, 6 journeys) — local gate. Catches obvious regressions before push.
- **Bug-hunt loop** — post-deploy clean-room blind agent walkthrough against `https://finlet.dev`. The integration safety net.

## Consequences

- **Deploy critical path drops from ~25 min to ~6-8 min.** With matrix-duplicated security checks + e2e removed from `deploy.yml`, push-to-main now runs `test (matrix) + security + deploy` only. Combined with Action 2's `paths-ignore`, doc-only commits don't trigger deploys at all.

- **CI on PRs is fast (~18-20 min for the test matrix).** PRs to main run only `test (3.12)` and `test (3.13)`.

- **`main` is always-green by default.** Direct push is rejected by branch protection; every commit on main has cleared the test matrix at PR time.

- **`deploy.yml` only fires on push to main.** Removed the redundant e2e run that used to gate the merge AND the deploy. Deploy critical path is now a strict subset of what gated the PR plus the security scan.

- **Direct `git push origin main` is permanently blocked.** Every change — including doc-only commits, handoffs, and skill-eval artifacts — must land via PR. Agents and humans both go through the same gate. The exec-plan skill was migrated to the PR-push pattern; future skills that merge to main must follow.

- **Trade-off (accepted):** e2e regressions are not caught at CI, only at pre-push smoke or in the bug-hunt loop. The 60.6% deploy failure rate analysis showed e2e in CI was passing while bug-hunt found 3+ new bugs per iteration anyway, so the CI e2e gate was paying full cost for near-zero marginal signal. If the bug-hunt loop's regression-detection rate ever drops to zero for two consecutive iterations, revisit and consider re-introducing e2e to CI.

- **Branch protection is the load-bearing piece.** The split workflows are inert without enforcement — branch protection is what guarantees the test matrix actually runs on every change to main. If branch protection is ever disabled (even temporarily), revert `exec-plan/skill.md` to plain `git push` and re-add `e2e` + `paths:` to `ci.yml` simultaneously to restore some gate.

### Alternatives Considered

1. **Keep the single-workflow model and just remove e2e from `deploy.yml`.** Rejected — without a PR gate, regressions still land on main first and only fail the deploy after merge. The whole point of the reform was to make `main` always-green by default.

2. **Keep e2e in `ci.yml` as a required check.** Rejected — the bug-hunt vs CI-e2e signal-cost analysis showed CI e2e paying full cost for near-zero marginal signal. A flaky required check is worse than no required check; it teaches agents to retry rather than diagnose.

3. **Require PR reviews (1+ approver) before merge.** Rejected for now — solo dev pre-revenue. The architecture is "0 required reviewers, allow auto-merge" so the test matrix is the gate, not human review. Revisit when the second engineer joins.

4. **Require branches to be up to date with main before merging.** Rejected — adds rebasing churn for solo dev with no real safety benefit on a small repo. Revisit if multi-author conflicts become common.

5. **Run security on PRs as well.** Rejected — security on PRs would slow PR turnaround without catching anything that wouldn't be caught on the merge-to-main run. The security scan is a deploy-time gate, not a code-review gate.

6. **Self-hosted runners or alternate CI provider.** Out of scope (and explicitly excluded in the handoff). Multi-week project; the four-action reform plus Action 3 is a one-day reform.

## Reversal Path

Each piece is independently reversible:

- **Re-enable e2e in CI:** Add the `e2e` job back to `ci.yml` (mirror the original `deploy.yml` e2e job). Add `e2e` to required status checks in branch protection.
- **Disable branch protection:** Settings → Branches → main → delete the protection rule. Revert `.claude/skills/exec-plan/skill.md` to `git push origin main`.
- **Collapse back to one workflow:** Delete `ci.yml`, restore the `e2e` job in `deploy.yml`, restore the `pull_request` trigger on the unified workflow.

The full revert is one PR (revert `1190ee6` + `17821b0` + `0a457e0`) plus a settings change. Branch protection should always be the LAST piece touched (last to add, first to remove) so the gate is never absent while the workflows are mid-migration.

## Memory Reference

`/Users/justnau/.claude/projects/-Users-justnau-finlet/memory/feedback_pr_gated_ci.md` — short-form fact + Why + How to apply for future agents.
