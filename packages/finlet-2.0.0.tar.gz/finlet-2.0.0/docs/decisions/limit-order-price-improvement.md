# Decision: Limit Orders Fill at Better Price (Price Improvement)

**Date:** 2026-03-31
**Status:** Accepted
**Source:** Launch Readiness Execution Plan, Team C (Issue 6)

## Context

Limit orders were filling at the limit price regardless of the current market price. A BUY LIMIT at $100 when the market price was $95 would fill at $100 — the buyer overpaid. This contradicts standard exchange behavior where limit orders receive price improvement.

## Decision

Limit orders now fill at the better of the market price and limit price:
- **BUY LIMIT**: fills at `min(current_price, limit_price)` — buyer never pays more than the limit
- **SELL LIMIT**: fills at `max(current_price, limit_price)` — seller never receives less than the limit

This matches standard exchange behavior and is consistent with the existing STOP order fill logic which already used `current_price`.

## Consequences

- Agents with limit orders may see different fill prices than before (better, not worse)
- Slippage is applied to the improved price, not the limit price
- This is a behavioral change for the evaluation harness — agents designed around the old behavior will see improved performance, not degraded
