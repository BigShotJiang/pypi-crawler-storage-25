# Decision: BlindMapping — `apply_universe` / `apply_scenario` / `apply_session_name` Forward Transforms

**Date**: 2026-05-21
**Status**: Accepted (shipped via blind-sse-defense-in-depth exec-plan)
**Refs**:
- Codex bug `a93a7ff2-39c2-48cb-8ddf-6a794686f342` (sibling motivation — see sibling decision `docs/decisions/blind-sse-event-blinding.md`)

**Related**:
- `docs/decisions/blind-benchmark-architecture.md` (parent — V1 architecture; `BlindMapping` model + `apply_ticker` / `apply_date` primitives)
- `docs/decisions/blind-sse-event-blinding.md` (sibling — uses these transforms in `session_response` / `clock_dict` / `list_orders`)
- `docs/decisions/blind-mapping-serializer-poison.md` (sibling — runtime backstop for the mapping object)
- `docs/decisions/blind-benchmark-envelope-fields-must-blind.md` (sibling — body+envelope blinding rule that these new transforms extend to new field types)

---

## Context

Bug `a93a7ff2` surfaced a **new class of blind-data leak** that the existing forward transforms (`apply_ticker`, `apply_date`) did not cover: **scenario labels embedded in free-form name fields**.

Concretely: `session.name = f"benchmark-{run_id}-{scenario.id}"` is constructed at `finlet/leaderboard/benchmark_state.py:640` when the runner creates a scenario session. The `scenario.id` carries the human-readable label (`bull_run`, `covid_crash`, `sideways_chop`, `vix_blowup`, `recovery_rally`) which is a real-data signal — it tells the agent under evaluation which regime it is operating in. The SSE `session` event leaked this name field directly because `session_response(session)` had no `blind_mapping` support (see `docs/decisions/blind-sse-event-blinding.md`).

Recon also surfaced two structural gaps adjacent to scenario labels:

1. **Universe leaks via list fields.** `session.config.universe` is a `list[str]` of real ticker symbols (`["AAPL", "MSFT", ...]`). Today's `apply_ticker(real_ticker, mapping)` accepts a single string. Callers who needed to blind a universe list reached for `[apply_ticker(t, mapping) for t in universe]` inline — a pattern Codex agents could miss if they did not know about it. Vectorizing into a single transform makes the boundary contract obvious.
2. **No transform for free-form name fields.** `session.name` is the canonical free-form name field (the dashboard shows it in the session header). The agent reads the SSE `session` event including the name. The pattern `benchmark-<uuid>-<scenario_id>` is parseable; we just needed a transform that substitutes the scenario suffix without breaking the UUID prefix.

The blind-mapping primitive surface had to grow to match the new field types, alongside the SSE chokepoint shipped in the sibling decision.

---

## Decision

Add three new forward transforms on `BlindMapping` in `finlet/core/blind_mapping.py`:

### `apply_universe(real_universe: list[str]) -> list[str]`

Vectorized `apply_ticker`. Maps each real ticker through the per-session mapping; passes through unknown tickers unchanged (mirrors `apply_ticker` semantics). Used by `session_response` to blind `d["config"]["universe"]`.

### `apply_scenario(scenario_id: str) -> str`

Deterministic SHA-256 hash of `scenario_id` keyed off the session mapping → 4-hex `S_XXXX` opaque label. Cached in a new `scenario_map: dict[str, str]` field on `BlindMapping` (populated on first call per scenario_id). The cache is **per-mapping** (so cross-session correlation is impossible — same scenario_id maps to different `S_XXXX` across sessions) and **deterministic within a mapping** (same scenario_id always maps to the same opaque label within one session — required for cross-event consistency, e.g., the SSE `session` event and the SSE `trace` event must agree on the same opaque label).

### `apply_session_name(name: str) -> str`

Pattern-match on `benchmark-<uuid>-<scenario_id>` shape and substitute the scenario suffix with `apply_scenario`. Strings that don't match the pattern pass through unchanged (so non-benchmark session names — e.g., user-supplied dashboard session names — are not corrupted).

Regex: `r"^benchmark-([0-9a-f-]{36})-(.+)$"`. Match group 2 is the scenario_id; substituted via `apply_scenario`. Result: `benchmark-<uuid>-S_XXXX`.

### Persistence note

`session.name` continues to persist on-disk as the **raw** value (`benchmark-<uuid>-bull_run`). The dashboard and ops audit trail need the real name field for debugging — a blinded on-disk name would force every internal observer to reverse-lookup through the mapping to know which scenario a session is for. The blinding is applied at **READ time** in `session_response` when `blind_mapping is not None`.

This mirrors the existing pattern for `session.config` (raw on disk; blinded at the public viewer boundary). It is the **opposite** pattern from `save_trace_entry`, which blinds at write time (see `docs/decisions/blinded-trace-persistence.md`). The difference is justified: trace entries are agent-facing data that an authenticated owner can already see in real form via the REST surface; session names are operator-facing metadata that the operator needs to debug in real form. Read-time blinding for `session.name` keeps the audit trail intact; the SSE / public-view surfaces apply the blinding at the boundary.

---

## How to apply

| Field type | Use |
|---|---|
| Single ticker string | `apply_ticker(value, mapping)` (existing) |
| Single ISO date string | `apply_date(value, mapping)` (existing) |
| `list[str]` of tickers | `apply_universe(value, mapping)` (NEW) |
| Scenario id string | `apply_scenario(value, mapping)` (NEW) |
| Free-form name field that may embed a scenario | `apply_session_name(value, mapping)` (NEW) |
| Trace payload (nested dict/list) | `apply_blind_to_trace_payload(value, mapping)` (existing — see `docs/decisions/blinded-trace-persistence.md`) |

If a new field type emerges (e.g., a sector list), add a new vectorized forward transform alongside these and document it here. **Do not** inline the recursion at the call site — the forward-transform surface is the single boundary.

---

## Consequences

### Positive

- **Scenario labels can no longer be inlined into name fields without transformation.** The existing pattern (`session.name = f"benchmark-{run_id}-{scenario.id}"`) at `benchmark_state.py:640` continues to write the raw name; the read-time `apply_session_name` blinds it at every public-viewer / SSE / agent-facing surface.
- **Vectorized universe blinding has a named primitive.** Callers can use `apply_universe(real_universe, mapping)` directly instead of inlining `[apply_ticker(t, mapping) for t in real_universe]`. Codex agents are less likely to forget the boundary when the boundary has a named symbol.
- **Per-mapping scenario cache prevents cross-session correlation.** Same scenario_id maps to different `S_XXXX` across sessions (because the mapping is per-session) but to the same `S_XXXX` within one session (so SSE events agree). This matches the existing `apply_ticker` / `apply_date` semantics (per-session opacity).
- **Pattern-match on `benchmark-<uuid>-<scenario_id>` is conservative.** Strings that don't match the regex (e.g., a user-supplied dashboard session name like `"My Test Session"`) pass through unchanged. The transform does not corrupt non-benchmark name fields.

### Negative

- **`session.name` continues to be a leak surface for any read path that bypasses `session_response`.** If a future code path reads `session.name` directly from the model and embeds it in an agent-facing response without going through `apply_session_name`, the raw scenario label leaks. Mitigation: the SSE chokepoint (`assert_no_real_blinded_data`, see `docs/decisions/blind-sse-event-blinding.md`) catches this for SSE; the read-time transform is the primary defense for other surfaces; the e2e zero-leak gate exercises the SSE surface explicitly. Future surfaces that read `session.name` should be audited for `apply_session_name` wiring.
- **`scenario_map` is per-mapping state that grows over time.** Each unique scenario_id queried via `apply_scenario` is cached in `mapping.scenario_map`. The map grows monotonically within a session's lifetime. In practice the V1 benchmark has 5 scenarios, so the map is bounded at 5 entries per blind session. Not a memory concern at current scale; flagged for V2 if scenario count balloons.
- **Pattern-match regex is brittle to name-format changes.** If `benchmark_state.py` ever changes the `session.name` format (e.g., adds a timestamp suffix), `apply_session_name` regex needs to update in lockstep. Mitigation: a single source of truth (this decision + the constructor at `benchmark_state.py:640`); add a regression test that asserts the constructor's output matches the regex.

### Trade-offs explicitly chosen

- **Read-time `apply_session_name` over write-time blinding.** Write-time would persist the name as `benchmark-<uuid>-S_XXXX` on disk, breaking the operator audit trail (operators debugging session issues need to know which scenario a session is for without reverse-lookups). Read-time keeps the audit trail intact at the cost of a tiny per-emit blinding call. This is the **opposite** trade-off from `save_trace_entry` (which blinds at write time because trace payloads are agent-facing, not operator-facing).
- **SHA-256 derived `S_XXXX` over enumeration `Scenario_1` / `Scenario_2`.** Enumeration would leak ordering (the agent could infer "this is the third scenario I'm running" from `Scenario_3`). SHA-256 derivation gives the same opacity properties as `T_NNNN` and `Day_N` (deterministic within session, opaque across).
- **Single-mapping cache `scenario_map` over per-call recomputation.** The SHA-256 hash is deterministic, so per-call recomputation would produce the same result. Caching avoids the hash cost on hot paths (every SSE push includes the session name); the memory cost is bounded (5 entries today, low double-digits if scenarios grow).
- **Pattern-match regex over generic substring substitution.** A generic substring substitution would mis-blind any free-form text that happened to contain a scenario label (e.g., a user-supplied dashboard session name containing "covid"). The regex anchors on `benchmark-<uuid>-` prefix so only benchmark-constructed names are touched.

---

## Reversal path

Mechanical, single SHA:

1. Remove `apply_universe`, `apply_scenario`, `apply_session_name`, and `scenario_map` from `BlindMapping`.
2. Revert the three SSE serializer call sites that use the new transforms (`session_response` → drop `apply_universe` / `apply_session_name` calls; `clock_dict` is unaffected; `list_orders` is unaffected).
3. The reversal is technically sound but reintroduces the structural gap — scenario labels would leak through `session.name` on the SSE `session` event again, recreating bug `a93a7ff2`.

Estimated cost: 30 minutes.

---

## References

- Bug filing: Codex `a93a7ff2-39c2-48cb-8ddf-6a794686f342` (2026-05-21)
- Implementation: `finlet/core/blind_mapping.py` (`apply_universe`, `apply_scenario`, `apply_session_name`, `scenario_map`) — Team A `bac9b4f`
- Read-time call site: `finlet/api/services/session_service.py:session_response` — Team B `40f396d`
- Persistence (raw on disk): `finlet/leaderboard/benchmark_state.py:640` (unchanged — read-time blinding does not modify the persisted name)
- Sibling decision: `docs/decisions/blind-sse-event-blinding.md` (consumers of these new transforms)
- Sibling decision: `docs/decisions/blind-mapping-serializer-poison.md` (runtime backstop for the BlindMapping object itself)
- Sibling decision: `docs/decisions/blinded-trace-persistence.md` (write-time blinding pattern for trace payloads — the **opposite** pattern from session.name for justified reasons)
