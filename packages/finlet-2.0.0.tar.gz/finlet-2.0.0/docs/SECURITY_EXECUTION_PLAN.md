# Security Execution Plan — Finlet

**Date:** 2026-03-26
**Source:** `docs/CYBERSECURITY_READINESS_REPORT.md`
**Goal:** Compress ALL security remediation into a single work session. No "post-launch" delays — every finding gets fixed NOW.

---

## Overview

| Phase | Goal | Findings | Depends On | Parallelizable |
|-------|------|----------|------------|----------------|
| **Phase 1** | Eliminate launch blockers | C1, C2 | None | Yes (C1 and C2 are independent) |
| **Phase 2** | Close auth/account vulnerabilities | H1, H2, H3, H4, H5 | Phase 1 (C1 XSS fix hardens context for H1 key theft) | H1-H5 all parallelize |
| **Phase 3** | Harden middleware and infrastructure | M1, M2, M3, M5, M6, M7 | None (can start with Phase 1) | All parallelize |
| **Phase 4** | Backlog sweep — low findings | L1-L9 | Phase 1 (CSP changes in C1 affect L1 SRI) | All parallelize |
| **Phase 5** | Post-launch roadmap acceleration | SEC-H2, CSRF, session timeout, audit log, threat model doc, encryption at rest, SSRF | Phases 1-4 | Most parallelize (R1→R2 sequential) |
| **Phase 6** | Verification and sign-off | All | Phases 1-5 | Sequential (full test suite + manual review) |

---

## Phase 1: Critical — Eliminate Launch Blockers

**Goal:** Close the XSS-to-account-takeover chain and secure the MCP server. These are the only two findings that block launch.

### Finding C1: XSS-to-Account-Takeover Chain

**Complexity:** Medium (3 sub-tasks across frontend + backend)

**Sub-tasks:**

| # | Task | File(s) | Details |
|---|------|---------|---------|
| C1a | Fix `esc()` function — **5 copies across all dashboard JS** | `dashboard/billing.js:771-776`, `dashboard/auth.js:888-892`, `dashboard/leaderboard.js:191-196`, `dashboard/settings.js:1492-1496`, `dashboard/app.js:1344-1348` | Current impl uses `textContent`→`innerHTML` trick which escapes `<`, `>`, `&` but NOT `"` or `'`. Append `.replace(/"/g, '&quot;').replace(/'/g, '&#39;')` after `div.innerHTML` in all 5 copies. |
| C1b | Remove `'unsafe-inline'` from CSP `script-src` + externalize 1 inline script + add CSP violation reporting | `finlet/api/security_middleware.py:60`, `dashboard/index.html:139-142` | Remove `'unsafe-inline'` from CSP line 60. Only 1 inline `<script>` exists: the auth guard at `index.html:139-142` (`if (!FinletAuth.isAuthenticated()) { window.location.replace('auth.html'); }`). Move it to a new external JS file (e.g., `dashboard/auth-guard.js`). No nonce implementation needed — just externalize and remove. The inline `<style>` block (`style-src 'unsafe-inline'`) is separate and lower risk — keep for now. **Also add `report-to` and `report-uri` directives** to the CSP header pointing to a reporting endpoint (e.g., `POST /v1/csp-report`). Create a minimal CSP report handler that logs violations via structlog. This provides visibility into any CSP violations in production. |
| C1c | Audit all innerHTML / attribute injection points | All 5 dashboard JS files + HTML files | **Confirmed injection points (attribute context, user-controlled):** `settings.js:862` (`data-key-id="${esc(key.id)}"`), `settings.js:874` (`data-key-id` + `data-key-name` attributes), `leaderboard.js:137` (`aria-label` with `agentName` — user-generated), `settings.js:521` (`<img src="${esc(data.qr_code)}"` attribute context). Verify all use fixed `esc()`. Grep for any additional `innerHTML`, `outerHTML`, template literals in attribute contexts. |

**Implementation detail (from code audit):**
```js
// Current esc() — UNSAFE in attribute contexts
function esc(str) {
    if (!str) return '';
    const div = document.createElement('div');
    div.textContent = String(str);
    return div.innerHTML;  // Missing: " and ' escaping
}

// Fixed esc() — SAFE in all contexts
function esc(str) {
    if (!str) return '';
    const div = document.createElement('div');
    div.textContent = String(str);
    return div.innerHTML.replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}
```

**Agent team (4 agents):**
1. **Frontend Security Engineer** — Fixes `esc()` in all 5 files, audits all injection points, externalizes inline auth guard script (C1a, C1b dashboard side, C1c)
2. **Backend Security Engineer** — Removes `'unsafe-inline'` from CSP in `security_middleware.py` (C1b backend side)
3. **Security Test Writer** — Writes tests: XSS payloads (`"`, `'`, `<`, `>`, `&` in agent names, key names, strategy fields); CSP header validation; esc() unit tests in both element content and attribute contexts
4. **QA Watchdog** — Monitors progress, verifies no regressions, challenges completeness of injection point audit

**Files touched:**
- `dashboard/billing.js:771-776` (esc function fix)
- `dashboard/auth.js:888-892` (esc function fix)
- `dashboard/leaderboard.js:191-196` (esc function fix + injection point audit)
- `dashboard/settings.js:1492-1496` (esc function fix + injection point fixes at :521, :862, :874)
- `dashboard/app.js:1344-1348` (esc function fix)
- `dashboard/index.html:139-142` (externalize inline auth guard script)
- `dashboard/auth-guard.js` (new file — externalized auth guard)
- `finlet/api/security_middleware.py:60` (CSP fix)

**Acceptance criteria:**
- [ ] `esc()` escapes `<`, `>`, `&`, `"`, `'` — unit tests prove it in BOTH element content and attribute contexts
- [ ] All 5 copies of `esc()` are updated (billing.js, auth.js, leaderboard.js, settings.js, app.js)
- [ ] CSP `script-src` does NOT contain `'unsafe-inline'`
- [ ] Auth guard inline script externalized to `dashboard/auth-guard.js`
- [ ] All dashboard pages load without CSP violations in browser console
- [ ] Zero `innerHTML` assignments with unescaped user-controlled values in attribute contexts
- [ ] All `aria-*` and `data-*` attribute interpolations use fixed `esc()`
- [ ] XSS payload test suite passes (attempt attribute injection via agent name, key ID, QR code URL, strategy name)
- [ ] CSP includes `report-uri` and `report-to` directives
- [ ] CSP violation report endpoint (`POST /v1/csp-report`) logs violations via structlog

---

### Finding C2: MCP Server Has No Authentication

**Complexity:** Simple (docs+warning) / Complex (full auth)

**Key functions identified:**
- `_get_session(session_id)` at `server.py:40` — looks up sessions by ID with NO user ownership check
- `_default_session_id()` at `server.py:48` — returns any single session regardless of owner
- Contrast: `finlet/api/deps.py` has `get_user_session(session_id, user)` which enforces ownership

**Sub-tasks:**

| # | Task | File(s) | Details |
|---|------|---------|---------|
| C2a | Add startup warning log | `finlet/mcp/server.py`, `finlet/cli.py` (MCP CLI entry point) | At server startup, log a WARNING-level message: "MCP server is unauthenticated. Do not expose to network. Use stdio transport only." If bind address is not localhost/127.0.0.1/::1, log CRITICAL and refuse to start. Check `finlet/cli.py` for the `mcp` command entry point. |
| C2b | Add session ownership checks | `finlet/mcp/server.py` | Mirror the `get_user_session(session_id, user)` pattern from `finlet/api/deps.py` (not `routes_trade.py` — that's the consumer). Accept user identity via MCP metadata or environment variable (`FINLET_MCP_USER_ID`). Update `_get_session()` to enforce ownership. Update `_default_session_id()` to filter by user-owned sessions only. Update `get_sessions()` tool to only return user-owned sessions. |
| C2c | Document MCP security limitations | `docs/ARCHITECTURE.md` | Add a "Security Considerations" subsection to the MCP Server section documenting that MCP is unauthenticated over stdio and must never be network-exposed. |

**Agent team (3 agents):**
1. **MCP Security Engineer** — Implements startup warning, ownership checks (C2a, C2b)
2. **Security Test Writer** — Tests: ownership enforcement rejects wrong user, startup warning fires, non-localhost bind refused, `get_sessions()` only returns owned sessions
3. **QA Watchdog** — Verifies MCP tools still function correctly after auth is added, checks for regressions

**Files touched:**
- `finlet/mcp/server.py`
- `docs/ARCHITECTURE.md`
- `tests/` (new MCP auth tests)

**Acceptance criteria:**
- [ ] MCP server logs WARNING on startup about unauthenticated access
- [ ] Non-localhost bind address causes CRITICAL log + startup refusal
- [ ] All MCP tool calls enforce session ownership (mirror API pattern)
- [ ] `_default_session_id()` scoped to authenticated user's sessions only
- [ ] Documentation updated

---

## Phase 2: High — Close Auth and Account Vulnerabilities

**Goal:** Fix all authentication bypasses, account destruction risks, and credential handling weaknesses. These are the highest-impact findings after the launch blockers.

**Dependencies:** Phase 1 should complete first (the XSS fix in C1 reduces the blast radius of stolen keys, which is the precondition for H1).

### Finding H1: Account Deletion Lacks Authentication Verification

**Status — SUPERSEDED 2026-05-14 by GDPR Item G (Article 17 deletion pipeline).** The legacy `DELETE /settings/account` route is now 410 Gone (D9 in `docs/decisions/gdpr-deletion-pattern.md`). The replacement endpoint pair `POST /v1/account/delete` + `GET /v1/account/delete/{job_id}` + `DELETE /v1/account/delete/{job_id}` is OAuth-Bearer-only and gates deletion behind a single-use 256-bit confirmation token plus a 24-hour cancellable grace window — the original MFA-on-deletion fix proposed below is no longer required. See `docs/CYBERSECURITY_READINESS_REPORT.md` H1 mitigation note for the residual risk analysis. The Phase 2 tasks below are retained for the audit trail but are no-ops on current main.

**Complexity:** Medium

**Current state:** `DeleteAccountRequest` model at `routes_settings.py:82-83` accepts a `password: str` field that is never validated. The `delete_account()` handler at line 358-386 jumps straight to cleanup at line 369 — the `body.password` value is completely ignored.

**Key insight:** Finlet uses API keys, not passwords. The `password` field is misleading. The fix should use MFA re-verification (when MFA enabled) or a confirmation field (when MFA disabled), not password validation.

| # | Task | File(s) | Details |
|---|------|---------|---------|
| H1a | Redesign `DeleteAccountRequest` model | `finlet/api/routes_settings.py:82-83` | Replace `password: str` with `mfa_code: str | None = None` and `confirm: bool = False`. When MFA is enabled, require a valid `mfa_code`. When MFA is disabled, require `confirm: true` (the existing API key auth via `require_api_key` dependency is sufficient identity proof). |
| H1b | Add verification logic to `delete_account()` | `finlet/api/routes_settings.py:358-386` | Before the cleanup at line 369: check `user.mfa_enabled or user.sms_mfa_enabled`. If true, validate `body.mfa_code` using the same MFA validation path as sign-in (`routes_auth_mfa.py`). If false, require `body.confirm == True`. Reject with 403 if verification fails. |

**Agent team:** Shared with Phase 2 Auth Engineer A + Test Writer

**Files touched:**
- `finlet/api/routes_settings.py`

**Acceptance criteria:**
- [ ] `DELETE /settings/account` rejects requests without valid MFA code (when MFA enabled)
- [ ] `DELETE /settings/account` rejects requests without `confirm: true` (when MFA disabled)
- [ ] MFA validation uses same code path as sign-in MFA
- [ ] Tests cover: MFA-TOTP user, MFA-SMS user, no-MFA user, missing fields, invalid MFA code

---

### Finding H2: Unsalted SHA-256 API Key Hashing

**Complexity:** Simple (pre-launch — no migration needed)

**Current code at `auth.py:60-61`:**
```python
def _hash_key(key: str) -> str:
    return hashlib.sha256(key.encode()).hexdigest()
```

**Callers:** `AuthService.create_key()`, `AuthService.validate_key()` (line 225-227), `AuthService.revoke_key()` — all use `_hash_key()` to hash incoming keys for lookup in `self._keys` dict.

**Key insight from Implementation Planner:** Since this is pre-launch, there are no production keys to migrate. All existing dev keys can be regenerated. This eliminates the need for backward-compatible dual-hash lookup.

| # | Task | File(s) | Details |
|---|------|---------|---------|
| H2a | Replace `_hash_key()` with HMAC-SHA256 | `finlet/api/auth.py:60-61` | `hmac.new(SERVER_SECRET.encode(), key.encode(), hashlib.sha256).hexdigest()`. Load `SERVER_SECRET` from `finlet.config.Settings.security` as `key_hmac_secret`, backed by env var `FINLET_KEY_HMAC_SECRET`. |
| H2b | Add HMAC secret to config | `finlet/config.py` | Add `key_hmac_secret: str` to `SecurityConfig`. Load from `FINLET_KEY_HMAC_SECRET` env var. Generate a default for local dev. |

**Agent team:** Shared with Phase 2 Auth Engineer B

**Files touched:**
- `finlet/api/auth.py`
- `finlet/config.py`

**Acceptance criteria:**
- [ ] `_hash_key()` uses HMAC-SHA256 with server secret
- [ ] Key creation and validation still work end-to-end
- [ ] Same raw key + same secret = same hash (deterministic)
- [ ] Different server secrets produce different hashes
- [ ] `FINLET_KEY_HMAC_SECRET` loaded from config/env

---

### Finding H3: No Server-Side Account Lockout for Sign-In

**Complexity:** Simple

**Current code at `routes_auth_mfa.py:202-208`:**
```python
@router.post("/sign-in", status_code=200)
async def sign_in_route(body: SignInRequest) -> dict[str, Any]:
    """Sign in with an API key. If MFA is enabled, returns an MFA challenge."""
    try:
        return await sign_in(body.api_key)
    except InvalidMFACode as e:
        raise HTTPException(status_code=401, detail=str(e))
```
No rate limiting at all on this endpoint.

**Existing pattern to reuse:** `check_registration_rate` at `rate_limit.py:147` and `record_registration` at `rate_limit.py:177`.

| # | Task | File(s) | Details |
|---|------|---------|---------|
| H3a | Add `check_sign_in_rate()` and `record_sign_in_attempt()` | `finlet/api/rate_limit.py` | Follow exact pattern of `check_registration_rate` / `record_registration`. Key by IP address. Limit: 10 attempts per 15 minutes. |
| H3b | Wire rate limiter into sign-in route | `finlet/api/routes_auth_mfa.py:202-208` | Add `request: Request` parameter to `sign_in_route()`. Call `check_sign_in_rate(request.client.host)` at start. Call `record_sign_in_attempt(request.client.host)` after each attempt. |

**Agent team:** Shared with Phase 2 Auth Engineer A

**Files touched:**
- `finlet/api/routes_auth_mfa.py`
- `finlet/api/rate_limit.py`

**Acceptance criteria:**
- [ ] Sign-in rate limited to 10 attempts / 15 min per IP
- [ ] Rate limit uses server-side persistence (SQLite `RateLimitEntry`)
- [ ] 429 response includes retry timing
- [ ] 11th attempt within window returns 429
- [ ] Counter resets after window expires

---

### Finding H4: Google Sign-In Key Rotation as Denial of Service

**Complexity:** Simple

**Current code at `mfa.py:462-488` (`_google_sign_in_existing()`):**
```python
# No MFA — issue fresh key
saved = _snapshot_user_settings(existing_user)
await _revoke_user_key(existing_user)
new_key = await create_api_key(...)
```
Every Google sign-in for an existing user without MFA revokes the current key and issues a new one. An attacker with a linked Google account can cycle the victim's key repeatedly.

| # | Task | File(s) | Details |
|---|------|---------|---------|
| H4a | Stop automatic key rotation on Google sign-in | `finlet/auth/mfa.py:462-488` | In `_google_sign_in_existing()` at line 417: when user has no MFA enabled, do NOT revoke and reissue the key. Return a success response with existing user info (without exposing the raw key). Only issue a new key on first Google sign-in (new user creation) or explicit user request (forgot-key flow, settings page revoke). |

**Agent team:** Shared with Phase 2 Auth Engineer B (same agent as H2 — both touch `auth/mfa.py`)

**Files touched:**
- `finlet/auth/mfa.py`

**Acceptance criteria:**
- [ ] Repeated Google sign-ins for existing user do NOT rotate API key
- [ ] First Google sign-in for new user still creates a key
- [ ] Key rotation only via explicit user request (forgot-key, settings revoke)
- [ ] Tests verify repeated Google sign-in preserves same key

---

### Finding H5: Forgot-Key Flow Bypasses MFA

**Complexity:** Medium

**Current code at `mfa.py:124-158` (`verify_forgot_key()`):**
```python
async def verify_forgot_key(email: str, code: str) -> tuple[str, str]:
    if not await verify_code(email, code):
        raise InvalidCode(...)
    user = get_user_by_email(email)
    # Immediately issues new key — NO MFA CHECK
    saved = _snapshot_user_settings(user)
    await _revoke_user_key(user)
    new_key = await create_api_key(...)
```
Verifies email code but never checks if user has MFA enabled. If MFA is enabled, it should require MFA completion before issuing the new key.

| # | Task | File(s) | Details |
|---|------|---------|---------|
| H5a | Add MFA check after email code verification | `finlet/auth/mfa.py:124-158` | After verifying email code at line 132, check `user.mfa_enabled or user.sms_mfa_enabled`. If true, return an MFA challenge (same pattern as `sign_in()` at `mfa.py:289-300`) instead of issuing the key. |
| H5b | Add forgot-key MFA completion flow | `finlet/auth/mfa.py`, `finlet/api/routes_auth_mfa.py` | The MFA session created here should encode that it's a "forgot-key" flow (e.g., `flow_type="forgot_key"` in MFA session metadata) so that `validate_mfa()` knows to issue a new key upon completion rather than returning the existing one. `POST /auth/forgot-key/verify` returns MFA challenge → `POST /auth/mfa/validate` completes MFA → key issued. |

**Agent team:** Shared with Phase 2 Auth Engineer B (touches `auth/mfa.py` same as H4)

**Files touched:**
- `finlet/auth/mfa.py`
- `finlet/api/routes_auth_mfa.py`

**Acceptance criteria:**
- [ ] Forgot-key with MFA enabled returns MFA challenge, NOT a new key
- [ ] Forgot-key without MFA works as before (email code → key issued)
- [ ] Completing MFA after forgot-key correctly issues new key
- [ ] MFA session encodes `flow_type="forgot_key"` for correct downstream behavior
- [ ] Tests cover: MFA-enabled path, non-MFA path, invalid MFA code after forgot-key

---

### Phase 2 Agent Team Summary (4 agents total)

1. **Auth Engineer A** — H1 (account deletion auth) + H3 (sign-in rate limit). Touches: `routes_settings.py`, `routes_auth_mfa.py`, `rate_limit.py`
2. **Auth Engineer B** — H2 (HMAC key hashing) + H4 (Google sign-in no-rotate) + H5 (forgot-key MFA bypass). Touches: `auth.py`, `config.py`, `auth/mfa.py`, `routes_auth_mfa.py`
3. **Auth Test Writer** — Tests for all H1-H5
4. **QA Watchdog** — Cross-cutting review, edge case identification, regression monitoring

**Parallelism:** Auth Engineer A and Auth Engineer B work fully in parallel — no file conflicts. Both share `routes_auth_mfa.py` but on different functions (A: `sign_in_route`, B: MFA validation flow). Use worktree isolation to avoid merge conflicts.

**Note on file conflict:** Auth Engineer A (H3b) and Auth Engineer B (H5b) both touch `routes_auth_mfa.py`. H3b adds rate limiting to `sign_in_route()`, H5b modifies the MFA validation flow for forgot-key. These are different functions in the same file — worktree isolation with a merge step is required.

---

## Phase 3: Medium — Harden Middleware and Infrastructure

**Goal:** Close DoS vectors, prevent log injection, stop information leakage, fix HTML issues, and persist user settings.

**Dependencies:** None — can start in parallel with Phase 1.

### Finding M1: Request Size Limit Bypass via Chunked Transfer

**Complexity:** Medium

**Current code at `security_middleware.py:33-45` (`RequestSizeLimitMiddleware.dispatch`):**
```python
async def dispatch(self, request, call_next):
    content_length = request.headers.get("content-length")
    if content_length is not None:
        try:
            if int(content_length) > self.max_bytes:
                return Response(..., status_code=413)
        except ValueError:
            pass
    return await call_next(request)
```
Only checks `Content-Length` header. Chunked transfer encoding omits this header, bypassing the check.

| # | Task | File(s) | Details |
|---|------|---------|---------|
| M1a | Add streaming byte counter for missing Content-Length | `finlet/api/security_middleware.py:33-45` | When `content_length is None`, read `request.stream()` chunks with running byte count. Return 413 if cumulative bytes exceed `self.max_bytes`. Note: consuming the body stream means it must be re-provided to downstream handlers. |

**Implementation pattern:**
```python
if content_length is None:
    body = b""
    async for chunk in request.stream():
        body += chunk
        if len(body) > self.max_bytes:
            return Response(..., status_code=413)
```

**Files touched:** `finlet/api/security_middleware.py`

---

### Finding M2: Client-Supplied X-Request-ID Without Validation

**Complexity:** Simple

**Current code at `middleware.py:25`:**
```python
request_id = request.headers.get("X-Request-ID") or uuid.uuid4().hex
```
Accepts ANY string — enables log injection via control characters or oversized values.

| # | Task | File(s) | Details |
|---|------|---------|---------|
| M2a | Validate X-Request-ID format | `finlet/api/middleware.py:25` | Validate with `re.match(r'^[a-fA-F0-9-]{1,64}$', request_id)`. If invalid (control chars, too long, non-hex), generate new `uuid.uuid4().hex`. |

**Files touched:** `finlet/api/middleware.py`

---

### Finding M3: Sensitive Data in Stripe Error Messages

**Complexity:** Simple

**Current code at `routes_billing.py:155-156`:**
```python
detail=f"Stripe checkout failed: {e.user_message if hasattr(e, 'user_message') else str(e)}",
```
The `hasattr` check is correct but `str(e)` fallback leaks Stripe internals (API key prefixes, customer IDs).

| # | Task | File(s) | Details |
|---|------|---------|---------|
| M3a | Replace `str(e)` fallback with generic message | `finlet/api/routes_billing.py:155-156` | Change to: `getattr(e, 'user_message', None) or 'An unexpected payment error occurred. Please try again.'`. Audit all other Stripe exception handlers in the file for the same `str(e)` pattern. |

**Files touched:** `finlet/api/routes_billing.py`

---

### Finding M4: No Encryption at Rest for SQLite

**Complexity:** Complex (architectural decision)

**Assigned to Phase 5 as R7.** This requires an architectural decision (SQLCipher vs database migration) that benefits from the hardened foundation built in Phases 1-4. See Phase 5 R7 for full scope and acceptance criteria.

---

### Finding M5: Unclosed `<script>` Tag in index.html

**Complexity:** Simple

**Current code at `index.html:10`:** Missing `</script>` closing tag for lightweight-charts CDN script. Browser parses subsequent `<style>` block as script content.

| # | Task | File(s) | Details |
|---|------|---------|---------|
| M5a | Add closing `</script>` tag | `dashboard/index.html:10` | Add `</script>` after the opening tag. Can be bundled with Phase 1 C1b work (same file). |

**Files touched:** `dashboard/index.html`

---

### Finding M6: In-Memory Settings Store

**Complexity:** Medium

**Current code at `routes_settings.py:19-22`:**
```python
_user_settings: dict[str, dict[str, Any]] = {}
_user_api_keys: dict[str, list[dict[str, Any]]] = {}
```
Module-level dicts — server restarts lose all user profile data and plugin configurations.

| # | Task | File(s) | Details |
|---|------|---------|---------|
| M6a | Create `UserSettingsModel` SQLite table | `finlet/db/` (new migration) | Follow the `RateLimitEntry` pattern. Fields: `user_id` (PK), `settings_json` (TEXT), `updated_at` (datetime). |
| M6b | Replace dict lookups with DB queries | `finlet/api/routes_settings.py:19-22` | Replace `_user_settings` and `_user_api_keys` dict access with async SQLite queries. Migrate `_save_plugins_config` from file-based JSON to database storage. |

**Files touched:**
- `finlet/api/routes_settings.py`
- `finlet/db/` (new model, migration)

---

### Finding M7: MFA Not Mandatory

**Complexity:** Medium

| # | Task | File(s) | Details |
|---|------|---------|---------|
| M7a | Add soft MFA enforcement for paid tiers | `finlet/api/auth.py`, `finlet/api/routes_billing.py`, `dashboard/auth.js` | On tier upgrade, prompt MFA setup. On API calls from paid-tier users without MFA, return `X-Finlet-MFA-Warning` header (soft enforcement, not blocking). Add `mfa_required` flag to tier config. |
| M7b | Add grace period | `finlet/api/auth.py` | Track `mfa_grace_deadline` — prompt users to enable MFA within N days. After grace period, escalate to 403 for sensitive endpoints. |

**Files touched:**
- `finlet/api/auth.py`
- `finlet/api/routes_billing.py` (post-upgrade MFA prompt)
- `dashboard/auth.js` (UI MFA setup prompt)

---

### Phase 3 Agent Team (4 agents — M5 bundled with Phase 1)

1. **Middleware Engineer** — M1 (request size streaming), M2 (X-Request-ID validation)
2. **API Security Engineer** — M3 (Stripe errors), M7 (MFA enforcement)
3. **Persistence Engineer** — M6 (settings to SQLite)
4. **QA Watchdog** — Validates all middleware changes, tests for regressions

**Note:** M5 (unclosed script tag) bundled with Phase 1 C1b (same file: `dashboard/index.html`). M4 (encryption at rest) assigned to Phase 5 as R7 — requires architectural decision.

**Acceptance criteria for all Phase 3:**
- [ ] Chunked requests exceeding 1MB return 413
- [ ] Normal requests with `Content-Length > 1MB` still return 413 (no regression)
- [ ] Malformed X-Request-ID values rejected and regenerated as UUID
- [ ] Control characters in X-Request-ID do not reach logs
- [ ] No Stripe internal details in error responses (test with mock Stripe error without `user_message`)
- [ ] `</script>` tag present and lightweight-charts library loads correctly
- [ ] Settings survive server restart (create → restart → read back)
- [ ] Paid tier users see MFA warning header
- [ ] M4 assigned to Phase 5 as R7 (encryption at rest)

---

## Phase 4: Low — Backlog Sweep

**Goal:** Clear all low-priority findings in one pass. These are defense-in-depth improvements, not exploitable vulnerabilities.

**Dependencies:** Phase 1 must complete (CSP changes affect SRI strategy).

### Findings L1-L9

| # | Finding | File(s) | Complexity | Details |
|---|---------|---------|------------|---------|
| L1 | Missing SRI on local scripts | `dashboard/index.html:138, 413-414` | Simple | CDN script (lightweight-charts at line 10) already has SRI. Local scripts (`auth.js` line 138, `api-utils.js` line 413, `app.js` line 414) do not. Generate SHA-384 integrity hashes for each local JS file, add `integrity` and `crossorigin` attributes. Provides defense against CDN/proxy tampering. |
| L2 | No Cache-Control on sensitive responses | `finlet/api/security_middleware.py` | Simple | Zero `Cache-Control` headers in codebase (confirmed by grep). Add path-based logic in `SecurityHeadersMiddleware`: `sensitive_prefixes = ("/auth/", "/billing/", "/settings/")` → if match, set `Cache-Control: no-store`. |
| L3 | Plugin config file permissions | `finlet/api/routes_settings.py:222` | Simple | Current `_save_plugins_config()` calls `PLUGINS_CONFIG_PATH.write_text()` with no permission restriction (world-readable by default). Add `os.chmod(PLUGINS_CONFIG_PATH, 0o600)` after write. |
| L4 | Debug endpoints in non-production | `finlet/api/app.py:274-275` | Simple | Currently gated: `docs_url=None if _is_production else "/docs"`. Add defense-in-depth: also disable if running on non-localhost hostname, or add explicit IP allowlisting for docs endpoints. |
| L5 | Email enumeration via registration timing | `finlet/api/routes_auth.py:100-104` | Medium | Current code returns 409 for existing emails, proceeds to create for new — different timing and status code. **Recommended fix:** Return generic "Check your email for next steps" for both cases. Existing accounts get "you already have an account" email, new accounts get confirmation email. This is a UX design decision that normalizes both timing and response. |
| L6 | Backup code entropy (32-bit) | `finlet/api/mfa.py:153` | Simple | Current: `secrets.token_hex(4).upper()` = 32 bits. Change to `secrets.token_hex(5)` for 40 bits (or `secrets.token_hex(6)` for 48 bits). One-character change. |
| L7 | No security.txt | New file + route | Simple | Create `security.txt` with contact email, preferred disclosure method, GPG key (optional). Either serve as static file from `dashboard/.well-known/security.txt` or register as FastAPI route in `app.py`. |
| L8 | No CORS restriction on webhook | `finlet/api/app.py:286-292` | Simple | CORS configured globally via `CORSMiddleware`. `/billing/webhook` receives Stripe server-to-server calls — CORS is unnecessary noise. Add custom middleware that skips CORS for webhook paths, or configure Stripe IP allowlisting at Caddy level. |
| L9 | Stripe webhook rate limiting | `finlet/api/routes_billing.py:161-174` | Simple | Webhook has no rate limiting — relies on Stripe signature verification. Add Stripe IP allowlist (preferred — Stripe publishes IPs at their docs) at Caddy level, or add middleware rate limit on `/billing/webhook` path as fallback. |

### Phase 4 Agent Team (4 agents total)

1. **Backend Hardening Engineer A** — L2 (Cache-Control), L3 (file permissions), L4 (debug endpoints), L5 (email enumeration)
2. **Backend Hardening Engineer B** — L6 (backup code entropy), L8 (CORS webhook), L9 (webhook rate limit)
3. **Frontend Hardening Engineer** — L1 (SRI hashes), L7 (security.txt)
4. **QA Watchdog** — Validates all changes, ensures no functional regressions

**Note on L5:** This requires a UX design decision (generic response vs constant-time delay). The agent should implement the generic "Check your email" approach since it's more robust than timing normalization alone.

**Acceptance criteria for all Phase 4:**
- [ ] SRI hashes present on all local `<script>` tags (auth.js, api-utils.js, app.js)
- [ ] Sensitive endpoints (`/auth/*`, `/billing/*`, `/settings/*`) return `Cache-Control: no-store`
- [ ] `plugins.json` created with 0o600 permissions
- [ ] Debug endpoints return 404 in non-development (defense-in-depth beyond existing gate)
- [ ] Registration returns identical response for existing and new emails (anti-enumeration)
- [ ] Backup codes use 40-bit entropy (`secrets.token_hex(5)`)
- [ ] `/.well-known/security.txt` serves valid RFC 9116 content
- [ ] Webhook endpoint excluded from CORS middleware
- [ ] Webhook endpoint has Stripe IP allowlist or rate limiting

---

## Phase 5: Roadmap Acceleration — Post-Launch Items Done Now

**Goal:** Accelerate items the report marked as "post-launch" into this session. Since we're fixing everything in one pass, there's no reason to defer.

**Dependencies:** Phases 1-4 (these build on the hardened foundation).

### Items

| # | Task | Details | Complexity |
|---|------|---------|------------|
| R1 | Migrate localStorage to httpOnly cookies (SEC-H2) | Move API key storage from `localStorage` to httpOnly, Secure, SameSite=Strict cookies. Update `dashboard/api-utils.js` to send credentials. Update FastAPI to read auth from cookies. Keep `Authorization: Bearer` as fallback for API consumers. | Complex |
| R2 | Add CSRF protection for cookie-based auth | Once cookies carry auth (R1), add CSRF tokens. Use double-submit cookie pattern or Synchronizer Token Pattern. | Medium |
| R3 | Server-side session timeout/expiry | Add `last_active` timestamp to API key records. Expire sessions after configurable inactivity (default: 24h). Require re-authentication. | Medium |
| R4 | Documented threat model | Create `docs/THREAT_MODEL.md` covering: actors (malicious AI agents, credential stuffers, XSS attackers, insider threats), assets (API keys, user data, simulation data), trust boundaries (dashboard ↔ API, API ↔ plugins, MCP ↔ sessions). | Medium |
| R5 | Admin audit trail | Log all admin actions (marketplace approve/reject/suspend) to a dedicated audit table with actor, action, target, timestamp, IP. Make audit entries immutable (SQLite BEFORE trigger like TraceEntryModel). | Medium |
| R6 | Plugin URL allowlisting (SSRF assessment) | Review all `httpx` calls in plugins. Ensure plugin HTTP clients cannot be directed to internal/private IP ranges. Add URL validation that blocks RFC 1918, link-local, localhost, cloud metadata endpoints (169.254.169.254, fd00:ec2::254), DNS rebinding (resolve hostname before request, reject private IPs), and non-HTTP(S) schemes (file://, gopher://, ftp://). | Medium |
| R7 | SQLite encryption at rest (M4) | Evaluate and implement SQLCipher as drop-in replacement for `aiosqlite`, or plan migration to encrypted-at-rest database (e.g., PostgreSQL on AWS RDS). All SQLite database files (`session.db`, `auth.db`, `leaderboard.db`, `marketplace.db`) must be encrypted. TOTP secrets are already individually Fernet-encrypted — this covers the remaining plaintext data (emails, hashed API keys, session state). | Complex |

### Phase 5 Agent Team (7 agents total)

1. **Cookie Auth Engineer** — R1 (localStorage → httpOnly cookies) + R2 (CSRF protection)
2. **Session Security Engineer** — R3 (session timeout/expiry)
3. **Threat Model Author** — R4 (documented threat model) — **explicitly assigned, not floating**
4. **Audit Engineer** — R5 (admin audit trail)
5. **Plugin Security Engineer** — R6 (SSRF / URL allowlisting — expanded scope)
6. **Encryption Engineer** — R7 (SQLite encryption at rest — M4 from readiness report)
7. **QA Watchdog** — Cross-cutting validation, especially R1 cookie migration regression testing

### R1 Cookie Migration — Detailed Test Plan (Highest-Risk Change)

R1 is the most complex and highest-risk change in the entire plan. The following test plan is mandatory:

| # | Test | Details |
|---|------|---------|
| R1-T1 | Browser auth via cookie | Sign in via dashboard → verify httpOnly cookie set → subsequent API calls use cookie → verify localStorage no longer contains API key |
| R1-T2 | API consumer auth via Bearer | External API consumer sends `Authorization: Bearer <key>` → verify still works, no cookie required |
| R1-T3 | Cookie attributes | Verify cookie has `HttpOnly`, `Secure`, `SameSite=Strict` attributes. Verify `Path=/` or appropriate scope. |
| R1-T4 | Cookie expiry | Verify cookie expires after session timeout (aligns with R3). Verify expired cookie triggers re-auth. |
| R1-T5 | CSRF protection (R2) | Verify state-changing endpoints (`POST`, `PUT`, `DELETE`) reject requests without valid CSRF token when using cookie auth. Verify `GET` requests are exempt. |
| R1-T6 | Cross-origin rejection | Verify cookie is not sent on cross-origin requests (SameSite=Strict). Verify CORS policy blocks credential-bearing cross-origin requests. |
| R1-T7 | Dual-auth coexistence | Verify a request with BOTH cookie and Bearer header works (Bearer takes precedence). Verify API docs/OpenAPI schema still show Bearer auth. |
| R1-T8 | Logout | Verify logout clears cookie server-side. Verify stale cookie is rejected. |
| R1-T9 | Migration path | Verify users with existing localStorage keys are prompted to re-auth (cookie issued on next sign-in). No data loss. |

### R6 SSRF — Expanded Scope

The SSRF assessment must cover ALL of the following attack vectors:

| Vector | Validation |
|--------|-----------|
| RFC 1918 private IPs | Block `10.0.0.0/8`, `172.16.0.0/12`, `192.168.0.0/16` |
| Link-local | Block `169.254.0.0/16`, `fe80::/10` |
| Localhost | Block `127.0.0.0/8`, `::1` |
| Cloud metadata | Block `169.254.169.254` (AWS/GCP/Azure), `fd00:ec2::254` (AWS IMDSv2 IPv6) |
| DNS rebinding | Resolve hostname BEFORE making request, validate resolved IP is not private/blocked. Re-validate on redirect. |
| Scheme restriction | Only allow `http://` and `https://` schemes. Block `file://`, `gopher://`, `ftp://`, `dict://`, etc. |
| Redirect following | If `httpx` follows redirects, re-validate the redirect target URL against all above rules. |

**Acceptance criteria:**
- [ ] API keys no longer in localStorage; httpOnly cookies used for browser auth
- [ ] All R1-T1 through R1-T9 tests pass
- [ ] CSRF protection active for all state-changing endpoints when cookie auth is used
- [ ] Sessions expire after 24h inactivity
- [ ] `docs/THREAT_MODEL.md` exists and covers: actors (malicious AI agents, credential stuffers, XSS attackers, insider threats), assets (API keys, user data, simulation data), trust boundaries (dashboard-API, API-plugins, MCP-sessions)
- [ ] Admin actions logged to immutable audit table (SQLite BEFORE trigger blocks UPDATE/DELETE)
- [ ] Plugin HTTP clients reject requests to all SSRF vectors (private IPs, cloud metadata, DNS rebinding, non-HTTP schemes, malicious redirects)
- [ ] SQLite databases encrypted at rest (SQLCipher or equivalent) OR migration plan documented with timeline

---

## Phase 6: Verification and Sign-Off

**Goal:** Full verification that all findings are remediated, no regressions introduced, and the codebase passes all quality gates.

**Dependencies:** All previous phases.

### Verification Steps

| # | Task | Details |
|---|------|---------|
| V1 | Full test suite | Run `pytest` with coverage. All new security tests pass. Coverage does not regress. |
| V2 | Ruff lint | Zero lint errors. |
| V3 | Mypy type check | Zero type errors. |
| V4 | pip-audit | Zero new vulnerabilities. |
| V5 | Manual XSS testing | Attempt the specific attack chain from C1: inject XSS payload via agent name on leaderboard, verify CSP blocks execution, verify esc() escapes payload. |
| V6 | Security header audit | Verify all response headers (CSP, HSTS, X-Frame-Options, Cache-Control, etc.) match expected values. |
| V7 | Auth flow regression test | Full auth workflow: register → sign-in → MFA setup → MFA sign-in → forgot-key with MFA → account deletion with MFA. |
| V8 | MCP ownership test | Verify MCP tool calls reject sessions not owned by the authenticated user. |
| V9 | Rate limit validation | Verify sign-in rate limiting, registration rate limiting, webhook rate limiting all enforce correctly. |
| V10 | Documentation audit | Verify `docs/ARCHITECTURE.md`, `docs/REMAINING_TASKS.md`, `CLAUDE.md`, and `docs/decisions/` are all updated to reflect security changes. |

### Phase 6 Agent Team (4 agents total)

1. **Test Runner** — V1-V4 (automated quality gates)
2. **Security Auditor** — V5-V9 (manual security verification)
3. **Documentation Auditor** — V10 (docs completeness)
4. **QA Watchdog** — Final sign-off, challenges any gaps

**Acceptance criteria:**
- [ ] All automated tests pass (pytest, ruff, mypy, pip-audit)
- [ ] Manual XSS attack chain is confirmed blocked
- [ ] All auth flows work correctly with new security controls
- [ ] MCP ownership enforcement verified
- [ ] All documentation updated
- [ ] QA Watchdog signs off on completeness

---

## Dependency Graph

```
Phase 1 (Critical: C1, C2)
  ├── starts immediately, no dependencies
  ├── C1 and C2 run in parallel
  │
Phase 3 (Medium: M1-M7, excluding M5)
  ├── starts immediately, no dependencies (parallel with Phase 1)
  ├── M1 waits for C1b to merge (security_middleware.py conflict)
  ├── M2, M3, M6, M7 start immediately
  │
Phase 2 (High: H1-H5)            Phase 4 (Low: L1-L9)
  ├── starts when Phase 1 done      ├── starts when Phase 1 done
  ├── H1-H5 all parallelize         ├── L2-L9 all parallelize
  ├── (runs CONCURRENTLY             ├── L1 waits for C1b (SRI needs
  │    with Phase 4)                 │    final CSP/script layout)
  │                                  │
  └──────────┬───────────────────────┘
             │
Phase 5 (Roadmap: R1-R7)
  ├── starts when Phases 2+3+4 done
  ├── R1 → R2 (CSRF depends on cookie auth)
  ├── R3, R4, R5, R6, R7 all parallelize
  │
Phase 6 (Verification)
  └── starts when Phase 5 done
```

**Parallel execution summary:**
- **Wave 1:** Phase 1 + Phase 3 start simultaneously (M1 deferred until C1b merges)
- **Wave 2:** Phase 2 + Phase 4 start when Phase 1 completes (run concurrently)
- **Wave 3:** Phase 5 starts when Phases 2-4 complete
- **Wave 4:** Phase 6 starts when Phase 5 completes

---

## Total Agent Count Per Wave

| Wave | Phases | Agents | Notes |
|------|--------|--------|-------|
| Wave 1 | Phase 1 + Phase 3 | 4 + 4 = **8 agents** (2 QA watchdogs) | M5 bundled with Phase 1, M1 deferred until C1b merges |
| Wave 2 | Phase 2 + Phase 4 | 4 + 4 = **8 agents** (2 QA watchdogs) | Auth + backlog run concurrently |
| Wave 3 | Phase 5 | **7 agents** (1 QA watchdog) | R4 assigned, R7 (M4) added, R6 scope expanded |
| Wave 4 | Phase 6 | **4 agents** (1 QA watchdog) | Final verification |

**Peak concurrency:** 8 agents (Wave 1 and Wave 2)

---

## Finding-to-File Mapping (Agent Conflict Prevention)

This table ensures no two agents in the same wave write to the same file.

| File | Phase 1 | Phase 2 | Phase 3 | Phase 4 |
|------|---------|---------|---------|---------|
| `dashboard/billing.js:771-776` | C1a (esc fix) | — | — | — |
| `dashboard/auth.js:888-892` | C1a (esc fix) | — | — | — |
| `dashboard/leaderboard.js:191-196` | C1a (esc fix) + C1c (audit) | — | — | — |
| `dashboard/settings.js:1492-1496` | C1a (esc fix) + C1c (audit :521, :862, :874) | — | — | — |
| `dashboard/app.js:1344-1348` | C1a (esc fix) | — | — | — |
| `dashboard/index.html:139-142` | C1b (externalize script) | — | M5 (:10) | L1 (:138, :413-414) |
| `dashboard/auth-guard.js` | C1b (new file) | — | — | — |
| `dashboard/api-utils.js` | — | — | — | — |
| `finlet/api/security_middleware.py:60` | C1b (CSP) | — | M1 (:33-45) | L2 |
| `finlet/api/middleware.py:25` | — | — | M2 | — |
| `finlet/api/routes_settings.py` | — | H1 (:82-83, :358-386) | M6 (:21-23) | L3 (:222) |
| `finlet/api/routes_billing.py` | — | — | M3 (:155-156) | L9 (:161-174) |
| `finlet/api/auth.py:60-61` | — | H2 | M7 | — |
| `finlet/api/routes_auth_mfa.py` | — | H3 (:202-208), H5b | — | — |
| `finlet/auth/mfa.py` | — | H4 (:462-488), H5a (:124-158) | — | — |
| `finlet/api/routes_auth.py` | — | — | — | L5 (:100-104) |
| `finlet/api/mfa.py:152` | — | — | — | L6 |
| `finlet/api/app.py` | — | — | — | L4 (:226-227), L8 (:236-242) |
| `finlet/mcp/server.py` | C2 (:40-57) | — | — | — |
| `finlet/api/rate_limit.py` | — | H3 (new functions) | — | — |
| `finlet/config.py` | — | H2b (new field) | — | — |

**Conflicts requiring worktree isolation or sequential ordering:**

1. **`finlet/api/security_middleware.py`** — Phase 1 (C1b: CSP line 60) and Phase 3 (M1: lines 33-45). **Resolution: SEQUENTIAL.** Phase 3 Middleware Engineer MUST wait for Phase 1 C1b to merge before starting M1. The Phase 3 agent should start with M2 (`middleware.py`) first, then pick up M1 after C1b lands. This avoids merge conflicts entirely — no worktree isolation needed for this file.

2. **`dashboard/index.html`** — Phase 1 (C1b: lines 139-142), Phase 3 (M5: line 10), Phase 4 (L1: lines 138, 413-414). All different sections. M5 can run in Phase 3 (parallel with Phase 1) since it touches line 10 while C1b touches lines 139-142 — no overlap. L1 must wait for both.

3. **`finlet/api/routes_auth_mfa.py`** — Phase 2 Auth Engineer A (H3: `sign_in_route` at :202-208) and Auth Engineer B (H5b: MFA validation flow). Different functions in same file — **worktree isolation with merge step required**.

4. **`finlet/auth/mfa.py`** — Phase 2 Auth Engineer B handles both H4 (:462-488) and H5a (:124-158). Same agent, no conflict.

5. **`finlet/api/routes_settings.py`** — Phase 2 (H1) and Phase 3 (M6). Different waves, no conflict.

6. **`finlet/api/app.py`** — Phase 4 (L4 + L8). Same agent can handle both, no conflict.

---

## Risk Mitigation

| Risk | Mitigation |
|------|-----------|
| CSP `unsafe-inline` removal breaks dashboard | Only 1 inline script exists (auth guard). Externalize to `auth-guard.js` before removing `unsafe-inline`. CSP `report-to` endpoint provides production visibility into any violations missed during testing. |
| HMAC key hashing breaks auth | Pre-launch: no production keys exist, so no migration needed. All dev keys regenerated. Rollback: revert `_hash_key()` to plain SHA-256 (1-line change). |
| Cookie auth migration (R1) breaks API consumers | `Authorization: Bearer` header remains the primary auth method. Cookies are browser-only addition, not a replacement. Explicit test plan (R1-T1 through R1-T9) validates dual-auth coexistence. |
| Settings SQLite migration (M6) loses in-flight data | Accept data loss for in-memory settings (ephemeral by design). No migration needed — fresh table. |
| Rate limiting on sign-in causes lockout | 10 attempts per 15 min is generous. 429 response includes retry timing. Admin accounts exempt. |
| MCP ownership checks break existing MCP users | User identity via `FINLET_MCP_USER_ID` env var — backward-compatible (env var is optional, defaults to permissive if unset in dev). |
| SQLCipher integration (R7) breaks aiosqlite | SQLCipher is a drop-in replacement at the SQLite level. Test with existing schema + migrations before deploying. Rollback: revert to standard SQLite (data readable without key). |
| SSRF validation (R6) blocks legitimate plugin URLs | Allowlist known-good plugin endpoints (Finnhub API, FRED, SEC EDGAR, BLS, BEA, Treasury). Validate ONLY for dynamic/user-configured URLs, not hardcoded plugin endpoints. |

---

## Completion Checklist

- [ ] **Phase 1:** C1 (XSS chain) + C2 (MCP auth) — LAUNCH UNBLOCKED
- [ ] **Phase 2:** H1-H5 (auth vulnerabilities) — ALL HIGH FINDINGS CLOSED
- [ ] **Phase 3:** M1-M7 (middleware hardening) — ALL MEDIUM FINDINGS CLOSED
- [ ] **Phase 4:** L1-L9 (backlog sweep) — ALL LOW FINDINGS CLOSED
- [ ] **Phase 5:** R1-R7 (roadmap acceleration, includes M4 encryption at rest) — POST-LAUNCH ITEMS DONE
- [ ] **Phase 6:** Verification pass — ALL QUALITY GATES GREEN, QA SIGN-OFF
- [ ] **Documentation:** ARCHITECTURE.md, REMAINING_TASKS.md, CLAUDE.md, decisions/ all updated

---

*Plan authored by Security Architect agent. Revised to address all 6 QA Watchdog blocking items: M4 assigned to Phase 5 as R7, security_middleware.py conflict resolved as sequential, CSP report-uri/report-to added to C1b, R1 cookie migration test plan added (R1-T1 through R1-T9), R4 threat model explicitly assigned, R6 SSRF scope expanded to cover cloud metadata/DNS rebinding/scheme blocking. Implementation details integrated from Implementation Planner batches (Critical, High, Medium).*
