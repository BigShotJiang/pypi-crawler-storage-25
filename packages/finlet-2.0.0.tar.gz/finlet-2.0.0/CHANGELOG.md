# Changelog

All notable changes to Finlet are documented in this file.

The format is based on [Keep a Changelog 1.1.0](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [2.0.0] — 2026-05-22

Pure-MCP cutover. The CLI no longer dispatches agentic commands over
MCP-over-HTTP; agents wire `finlet mcp serve` over stdio through their
MCP client (Claude Desktop, Claude Code, Codex CLI, Cursor, Windsurf,
generic MCP client). The local CLI keeps only the operator surface
(`register`, `auth`, `plugins`, `serve`, `mcp serve`, `manual`) plus
the `finlet mcp serve` stdio bridge. Ships alongside the session-level
blind mode landed
2026-05-22 in PR [#134](https://github.com/finlet-dev/finlet/pull/134).

### Added (session-level blind mode — 2026-05-22)

- **`create_session(blind: bool = False)`** across MCP (canonical
  `mcp__finlet__create_session`) and REST (`POST /v1/sessions`).
  When `True`, the session is created with
  `name = "blind-{session.id[:8]}"` (auto-generated,
  immutable), a `BlindMapping` is attached BEFORE the first
  `save_session`, and every `@blind_error_mapper`-decorated MCP tool
  returns `T_NNNN` tickers + `Day_N` dates for that session. Same
  plumbing as the canonical 5-scenario benchmark blind path
  (`BlindMapping`, `assert_no_real_blinded_data`,
  `_KNOWN_BENCHMARK_TICKERS`, SSE/trace blinding). MCP-first; REST
  mirrors the same service-layer path. Decision record:
  `docs/decisions/session-level-blind-extends-create-session.md`.
  Architecture: `docs/ARCHITECTURE.md` → "Session-Level Blind Mode".
- **`SessionResponse.blind: bool`** populated at the top level of
  `session_response()` (mirrors the existing `public` field).
  Dashboards can render an owner-side "blind active" badge as a
  follow-up.
- **`freeze_time` MCP tool now blinds the clock response** for blind
  sessions. Closes a gap where `get_sim_time` and `advance_time`
  blinded but `freeze_time` returned real clock dates. Other
  clock-touching MCP tools audited for the same pattern.

### Changed (session-level blind mode — 2026-05-22)

- **Hardcoded 50-ticker per-session universe cap removed.** Catalog
  membership is the gate now: every requested ticker MUST be in
  `_UNIVERSE_SOURCES` (270 tickers — 199 US equities + 71 US ETFs).
  Off-catalog tickers get `"ticker '<X>' not in catalog — call
  list_available_tickers"`. Same check fires on
  `configure_session(universe=...)` for non-blind sessions (Codex
  Step 10h BLOCKER 5 closed the back door). Pricing tiers update:
  Free + Builder advertise "Unlimited tickers per session";
  `max_tickers=None` on both tiers in
  `finlet/billing/stripe_config.py`.
- **`configure_session` lockdown on blind sessions.** Both `universe`
  and `name` changes are rejected with 409 for blind sessions. The
  `BlindMapping` is built at create-time; changing the universe
  mid-session would invalidate the `T_NNNN` ↔ real-ticker
  correspondence the agent has been working with.
- **`_blind_mapping_for(session)` moved** from
  `finlet/api/serializers.py` into
  `finlet/api/services/session_service.py` (single source of truth).
  `serializers.py` re-imports it. Direction is forward (services →
  serializers).

### Changed (CLI surface — pure-MCP cutover)

- **CLI surface reduced to the MCP-bootstrap minimum.** Six command
  families survive: `finlet serve`, `finlet register`, `finlet auth`
  (`login` / `logout` / `status`), `finlet plugins` (`list` / `add` /
  `remove`), `finlet mcp serve`, `finlet manual`. Agentic commands
  are addressed through an MCP client wired to `finlet mcp serve`;
  hosted MCP-over-HTTP remains a secondary path for clients that
  support it. Operator and onboarding commands remain local; agent
  dispatch leaves the CLI.
- **Dashboard agent-guide rewritten for MCP-first onboarding.** The
  dashboard onboarding pages now point users at the canonical stdio
  setup (`finlet mcp serve`) and keep HTTP / REST variants as
  fallback paths where they are still supported.
- **`finlet manual quickstart` aligned to the canonical four-step
  MCP-first script.** The CLI walkthrough (and the `finlet/manual/`
  package) match what `dashboard/agent-guide.html` and
  `dashboard/llms.txt` advertise; the generator (`finlet.manual.
  generate_llms_txt --check`) is the drift gate.

### Removed

- **CLI agentic dispatch surface.** Deleted commands (12 entry points
  across 3 sub-apps + top-level):
  - `session` sub-app — `create`, `list`, `delete`, `publish`.
  - `benchmark` sub-app — `start`, `progress`, `decrypt`,
    `visibility`.
  - Top-level — `advance`, `order`, `portfolio`, `status`.
- **`finlet/cli_mcp_client.py`** (entire module) — the v1.0.1
  MCP-over-HTTP dispatcher and its `MCPDispatchError` surface. Agents
  now own their own MCP client.
- **Internal CLI helpers** retired alongside the dispatcher:
  `_dispatch_mcp_tool`, `_translate_mcp_error`, `_emit_envelope`,
  `_resolve_bearer_token`, `_AUTH_REQUIRED_MARKERS`,
  `_AUTH_REQUIRED_HINT`, `_AsyncioTimeoutError`,
  `_normalize_start_iso`, the top-level `import asyncio`, the
  `session_app` + `benchmark_app` Typer sub-apps and their
  `add_typer` registrations, and the
  `from finlet.cli_mcp_client import ...` import.
- **Stale module docstring** describing the deleted dispatch model
  rewritten to reflect the v2.0.0 operator-only surface.

### Migration notes

- **Wire agents to `finlet mcp serve`.** MCP clients (Claude Desktop,
  Claude Code, Codex CLI, Cursor, Windsurf, generic MCP) spawn the
  stdio bridge, which reads OAuth credentials from `~/.finlet/credentials`
  after `finlet auth login` and proxies to hosted `/mcp`. Base
  `pip install finlet` is sufficient for the canonical bridge;
  `pip install 'finlet[server]'` plus `finlet mcp serve --self-host`
  remains available for operators running their own API/auth/database
  stack. The 8-tab matrix in
  `dashboard/agent-guide.html` and `finlet manual client-matrix`
  document the copy-paste config blocks.
- **Headless clients can still use api_key env fallback.** The bundled
  stdio bridge accepts `FINLET_API_KEY` for CI / non-interactive
  environments. `finlet/cli.py` still wires `mcp serve`; only the
  per-tool convenience commands left.
- **Scripts that called `finlet session create`, `finlet order`,
  `finlet portfolio`, `finlet advance`, `finlet status`, `finlet
  benchmark *` migrate to calling MCP tools directly** (any MCP
  client SDK, or `curl` against `/mcp` with a JSON-RPC body). Tool
  names + argument shapes are unchanged.
- **No deprecation period.** Zero PyPI consumers exist on the v1.x
  CLI dispatch path at cutover time (pre-launch, no customers); the
  removal lands directly. See `[[project-pre-launch-no-customers]]`.

### PR references

- v2.0.0 pure-MCP cutover (this PR) — CLI surgery (Team A), CLI test
  trim + MCP visibility assertions (Team B), manual + registry +
  llms.txt regen (Team C), dashboard HTML examples + data-copy
  attributes (Team D), version bump + CHANGELOG repair (Team E,
  capstone).
- Session-level blind mode — PR [#134](https://github.com/finlet-dev/finlet/pull/134)
  (2026-05-22, prod sha `27d96ca`).

## [1.1.0] — 2026-05-16

USER_MANUAL_OVERHAUL ship. The `finlet manual` CLI subcommand and the
~200-anchor error-envelope convention become reachable to any operator
who `pip install finlet`. Minor (not patch) because the surface is
additive and user-visible.

### Added

- **`finlet manual` CLI subcommand** — seven topics (`quickstart`,
  `auth-model`, `session-lifecycle`, `transports`, `client-matrix`,
  `plugin-matrix`, `errors`) with `--list` / `--search` /
  `--format=json` modes and anchor-scoped lookups (e.g. `finlet
  manual errors#missing-bearer`). Hatchling artifacts directive
  `[tool.hatch.build.targets.wheel] artifacts = ["finlet/manual/*.md"]`
  ships the topic files inside the wheel; loader is
  `importlib.resources.files("finlet.manual")`.
- **Error-anchor convention** — 13 frozen kebab-case anchor IDs in
  `finlet/manual/errors.md`; ~200 error envelopes across REST,
  billing, OAuth, MCP, and named plugins suffix-appended with
  `See: finlet manual errors#<anchor>`.
- **`_AUTH_REQUIRED_MESSAGE` constant** in `finlet/mcp/auth.py`
  dedups the 19-site MCP auth-required surface.
- **Per-surface contract gates** —
  `tests/api/test_error_anchors.py`,
  `tests/billing/test_error_anchors.py`,
  `tests/auth/oauth/test_error_anchors.py`,
  `tests/plugins/test_error_anchors.py`.
- **`dashboard/llms.txt` regen pipeline + freshness guard** —
  deterministic generator in `finlet/manual/generate_llms_txt.py`
  with `--write` / `--check` modes. Three-layer drift gate:
  pre-commit hook (`scripts/lint-llms-txt-fresh.sh`), CI lint step
  (`.github/workflows/ci.yml`), and `--write` remediation.
- **CLI command see-also footers** — 10 `finlet` command docstrings
  gained `See: finlet manual <topic>` footers in their `--help`
  output.

### Changed

- **`dashboard/agent-guide.html` rewritten as an 8-tab matrix** —
  Claude Desktop, Claude Code, Cursor, Codex, Windsurf, VS Code,
  Generic MCP, REST. OAuth-first auth flip (was api_key-first
  pre-Phase-4e); api_key documented as headless/CI fallback. Five
  troubleshooting deep-links anchor at `finlet manual errors#<anchor>`.
- **`README.md:66` MCP config fix** — `args: ["mcp"]` →
  `args: ["mcp", "serve"]` (matches the Phase-5 Typer sub-app
  rename).
- **`finlet/api/deprecation.py` `/mcp(/.*)?$` whitelist** —
  prevents the legacy deprecation-header middleware from tagging MCP
  paths as deprecated alongside `/v1/` routes.
- **`.github/workflows/ci.yml`** flipped from `paths-ignore` to a
  positive paths allowlist to keep gates dormant on doc-only PRs.

### Architecture

- New decision records: `docs/decisions/error-anchor-convention.md`
  and `docs/decisions/dashboard-llms-txt-regen-pipeline.md`.

### PR references

- USER_MANUAL_OVERHAUL ship — PR [#85](https://github.com/finlet-dev/finlet/pull/85)
  (`734da2e`, merged 2026-05-15).
- gitleaks deploy-fix — PR [#86](https://github.com/finlet-dev/finlet/pull/86)
  (`d0461d6`).
- `release: bump to v1.1.0` — PR [#87](https://github.com/finlet-dev/finlet/pull/87)
  (`9a88842`, PyPI publish run `25955438689`).
- E2E gate — `tests/e2e/journey-19-agent-guide.spec.ts`.

## [1.0.4] — 2026-05-12

### Fixed

Per v1.0.3 blind-walk findings
(`docs/launch/blind-agent-coldstart-report-v1.0.3-fullwalk.md`):

- **F-1 (HIGH)** `dashboard/agent-guide.html` — "Auth path" tip no longer
  claims MCP-over-HTTP accepts `Authorization: Bearer fnlt_<api_key>`.
  Phase 4e shipped Bearer-only (OAuth JWT) enforcement on the MCP HTTP
  surface; the dashboard now correctly directs api_key clients to either
  the REST API at `https://finlet.dev/v1/...` or the bundled
  `finlet mcp serve` stdio bridge (which translates `FINLET_API_KEY`
  internally).
- **F-3 (MEDIUM)** CLI exits `EXIT_AUTH_REQUIRED` (2) on MCP auth
  failures with a friendlier "Run `finlet auth login` or set
  `FINLET_API_KEY=fnlt_<key>`" hint, instead of exit 0. Shell scripts
  can now detect auth-failed invocations. Same exit-code semantics
  applied to `finlet auth status` (not-logged-in / token-expired).
- **F-4 (LOW)** `/dashboard/` (with trailing slash) no longer 404s —
  both `/dashboard` and `/dashboard/` resolve to the same handler.
  Same fix applied to `/login`, `/login/`, `/pricing`, `/pricing/`.
- **F-5 (LOW)** `finlet mcp serve --help` reconciles `FINLET_API_KEY`
  (preferred, matches the published Claude Desktop and Generic MCP
  Client configs) and `FINLET_OAUTH_BEARER` (also accepted).
- **F-6 (LOW)** `finlet auth login --help` drops the "90-day dual-accept
  window" framing (that window was retracted pre-launch in v1.0.1) —
  `--api-key` mode reframed as a convenience for confirming an
  existing `FINLET_API_KEY` against Finlet's REST surface.

### Added

- **F-2 (MEDIUM)** `finlet --version` flag — prints the installed
  version via `importlib.metadata.version("finlet")` and exits 0.

## [1.0.3] — 2026-05-11

### Fixed

- `dashboard/agent-guide.html` — Generic MCP Client config block now uses
  `["mcp", "serve"]` subcommand (matches the Claude Desktop block fixed in
  v1.0.2). Cursor / Cline / Continue users following the Generic config
  block would have seen "MCP server crashed immediately" because bare
  `finlet mcp` prints help and exits 0. Docs-only patch; no PyPI re-publish.

## [1.0.2] — 2026-05-11

### Fixed (v1.0.1 blind-walk follow-up)
- **CLI traceback regression (BLOCKER #B v1.0.1):** `finlet/cli_mcp_client.py` now catches `BaseException` around `session.initialize()` and `session.call_tool()` and collapses anyio task-group `ExceptionGroup` instances into a single-line `MCPDispatchError`. Restores the v1.0.0 HIGH#5 clean-stream invariant on the HTTP dispatch path.
- **Claude Desktop config (HIGH #22 NEW):** `dashboard/agent-guide.html` Claude Desktop config block now passes `"args": ["mcp", "serve"]` (the actual self-host stdio command) instead of the bare `"args": ["mcp"]` which only printed help and exited.
- **Module `__version__` drift:** `finlet/__init__.py` bumped to "1.0.2" to match `pyproject.toml`. (v1.0.1 shipped with `__version__` stuck at "1.0.0".)

### Ops
- `.gitleaksignore` allowlists 3 v1.0.1 false-positives (test fixture + 2 doc examples) — unblocks the Deploy Finlet security gate.

## [1.0.1] — 2026-05-11

### Fixed
- **CLI MCP dispatch — BLOCKER #A:** CLI now dispatches MCP-over-HTTP to `https://finlet.dev/mcp` instead of spawning a local `finlet mcp serve` subprocess. Removes the requirement to install `[server]` extras and eliminates JWKS validation failures from cloud-issued tokens hitting locally-spawned servers.
- **API key auth on MCP — BLOCKER #B:** Retracted Phase 4e api_key sunset (pre-launch, zero customers). Both OAuth Bearer JWT and api_key Bearer (`fnlt_*`) now accepted on `/mcp`.
- **JSONRPC stream pollution (HIGH #11):** Side-effect of removing the local subprocess spawn — no stderr/stdout from a child can corrupt the JSONRPC channel.
- **Agent-guide MCP-auth contradiction (HIGH #12):** Reconciled — narrative + Claude Desktop config block now agree.
- **Free-tier concurrency claim (HIGH #13):** Marketing updated from "4 sessions per day" to "1 concurrent simulation" to match enforced policy.
- **CLI install footprint (MED #15):** Base `pip install finlet` is now sufficient — `[server]` extras moved to a Self-host (optional) subsection.
- **Undocumented trade-submit shape (MED #16):** Added `POST /v1/sessions/{id}/trade/order` curl example with the correct `ticker` field.
- **`finlet trade submit` ghost (MED #17):** Docs corrected to reference the actual `finlet order` command.

### Added
- `finlet auth status` command — reports local credential state without a server ping.
- `tests/mcp/test_http_endpoint.py` — integration suite for the cloud /mcp endpoint covering OAuth + api_key Bearer + no-auth paths.

### Architecture
- New decision record `docs/decisions/cli-mcp-http-dispatch.md`; superseded `cli-mcp-stdio-auth.md`; retracted `mcp-api-key-sunset.md` Phase 4e closure.

## [1.0.0] - 2026-05-10

Launch release. The 1.0.0 line consolidates the MCP-First migration (Phases 1–5)
into a single shipped surface: a FastMCP server exposing 16 agent-facing tools, an
OAuth 2.1 Authorization Server with Dynamic Client Registration and Resource Indicators,
Bearer-only authentication on the MCP tool surface, and a CLI that dispatches every
agentic command through a spawned `finlet mcp serve` subprocess over stdio.

### Added

- **MCP server with 16 tools** covering session lifecycle, trading
  (`submit_order`, `cancel_order`, `list_orders`), portfolio queries, market
  data lookups, and benchmark execution. The server is exposed under
  `finlet/mcp/` and mounts on the same FastAPI app that hosts the REST surface.
- **OAuth 2.1 Authorization Server** with Dynamic Client Registration
  (RFC 7591), Resource Indicators (RFC 8707), PKCE-only authorization-code
  flow, and EdDSA-signed JWT access tokens. Endpoints under `/oauth/*`:
  `authorize`, `token`, `register`, `jwks`, `metadata`. Backed by
  `finlet/auth/oauth/` with four new tables (`oauth_clients`, `oauth_codes`,
  `oauth_refresh_tokens`, `oauth_keys`) introduced via migration `014`.
- **OAuth Resource Server** in `finlet/mcp/auth.py` and
  `finlet/mcp/bearer_context.py`: every authenticated MCP tool resolves
  identity through `resolve_credential`, validates the JWT via
  `joserfc` pinned to EdDSA, and enforces per-tool scope gates inside
  the user's `UserTier`.
- **CLI OAuth login**: `finlet auth login` performs the browser-based
  authorization-code-with-PKCE flow and stores the resulting Bearer token
  at `~/.finlet/credentials` with mode 0600. `finlet auth logout` clears it.
- **CLI MCP-over-stdio dispatch**: `finlet session create/list/get`,
  `finlet trade submit/cancel`, `finlet portfolio`, and `finlet orders` now
  spawn `python -m finlet mcp serve` per command and dispatch JSON-RPC tool
  calls over stdio. Bearer tokens are forwarded into the subprocess via the
  `FINLET_OAUTH_BEARER` environment variable. See
  `docs/decisions/cli-mcp-stdio-auth.md`.
- **Service-layer parity gates** (`finlet/api/services/`): `session_service`,
  `trade_service`, `market_service`, and the unified `errors` module ensure
  REST and MCP tool surfaces apply identical validation, ownership, and
  error-envelope contracts.
- **API versioning + deprecation header policy** on the REST surface,
  refined in Phase 3 to align response timing and policy semantics across
  middleware paths.

### Changed

- **CLI auth flow**: `finlet` agentic commands no longer accept an
  `--api-key` flag for MCP-bound calls. The CLI loads a Bearer JWT from
  `~/.finlet/credentials` (or `FINLET_OAUTH_BEARER` env), passes it
  through to the spawned `finlet mcp serve` subprocess, and the subprocess
  authenticates the JWT via `_authenticate_oauth_or_key`.
- **CLI dispatch transport**: agentic commands moved from REST HTTP to
  spawned MCP subprocess over stdio. The 4 keep-list commands (`serve`,
  `register`, `auth login`, `auth logout`) remain bit-identical. Plugin
  management (`plugins list/add/remove`) continues to call the REST
  surface — operator surface, not agent surface.
- **MCP tool authentication contract**: every MCP tool now expects a Bearer
  JWT minted by the Finlet OAuth AS. The HTTP transport reads the token
  via `BearerContextMiddleware`; the stdio transport reads
  `FINLET_OAUTH_BEARER` from the subprocess env. Per-request precedence
  is unchanged: ContextVar wins on HTTP, env var fires only when the
  ContextVar is empty (the stdio case).
- **Authentication-required envelope** for MCP tools: a missing or invalid
  Bearer token returns the documented `{"error": "Authentication required"}`
  envelope as a 401. Previously this surfaced as a generic auth error.

### Removed

- **`api_key` authentication on the MCP tool surface**. Phase 4c shipped a
  90-day api_key dual-accept window alongside Bearer; Phase 4e retracted
  that window pre-launch (no consumers had migrated, see
  `docs/decisions/mcp-api-key-sunset.md` Retraction 2026-05-09).
  `api_key=<key>` arguments now return:
  `{"error": "api_key authentication is no longer supported on MCP tools.
  Run 'finlet auth login' to obtain an OAuth Bearer token. See
  docs/MCP_OAUTH_MIGRATION.md."}` as a 401. The api_key fallthrough is
  gone from `finlet/mcp/bearer_context.py:resolve_credential` and
  `finlet/mcp/auth.py:_authenticate_oauth_or_key`.
- **`finlet auth register` legacy alias**. The agentic onboarding flow
  is now `finlet register` (account) followed by `finlet auth login` (token).

### Migration notes

- **Upgrading from 0.1.x**: run `finlet auth login` to obtain a Bearer
  token. The api_key auth path is removed in 1.0.0; any agent or script
  passing `api_key=<key>` to MCP tools will receive a 401 with the
  cutover-message envelope above. The CLI's agentic commands handle
  Bearer-token forwarding automatically; no manual env-var management
  is required for interactive use.
- **Direct MCP tool consumers** (custom HTTP clients): swap the
  `Authorization: ApiKey <key>` header (or `api_key` argument) for
  `Authorization: Bearer <jwt>` where the JWT is minted by
  `POST /oauth/token` on the Finlet AS. Resource Indicator must be the
  Finlet MCP resource per RFC 8707.
- **CLI scripts that parsed REST JSON**: agentic commands now return
  MCP tool envelopes (JSON-RPC result format) rather than raw FastAPI
  JSON bodies. Operator commands (`plugins list/add/remove`) are
  unchanged.
- **`time_in_force=DAY` on `submit_order`**: the CLI flag is preserved
  for ergonomic stability but is silently dropped on the MCP path
  because the MCP tool does not currently expose it. Tracked under
  Phase 5 polish.

### PR references

- Phase 5 — CLI MCP-over-stdio rewire: PR [#37](https://github.com/finlet-dev/finlet/pull/37)
  (squash `d8e13dd`, 2026-05-10).
- Phase 4e — Bearer-only cutover (api_key sunset): atomic commit
  `cebd327` series (Team E1, 2026-05-09 — sunset clock retracted
  pre-launch with no consumers; no PR).
- Phase 4d — CLI OAuth login + 0600 credential storage: PR [#35](https://github.com/finlet-dev/finlet/pull/35)
  (2026-05-09).
- Phase 4c — OAuth Resource Server + 16 MCP tools dual-accept + scope
  enforcement: PR [#34](https://github.com/finlet-dev/finlet/pull/34)
  (2026-05-08).
- Phase 4b — OAuth Authorization Server (5 endpoints, 4 tables, EdDSA
  JWT minting): PR [#33](https://github.com/finlet-dev/finlet/pull/33)
  (2026-05-08).
- Phase 4a — OAuth 2.1 + DCR + Resource Indicators decision record:
  PR [#32](https://github.com/finlet-dev/finlet/pull/32) (2026-05-08).
- Phase 3 — Deprecation-header policy refinement on the REST API
  versioning surface: PR [#31](https://github.com/finlet-dev/finlet/pull/31)
  (2026-05-08).
- Phase 2 (service-layer parity) and Phase 1 (MCP correctness, CLI
  envelope, benchmark log redaction) shipped via sequential team
  commits to `main` ahead of Phase 3; see git history under
  `[Team A]`/`[Team B]`/`[Team C]` prefixes 2026-05-07.

## [0.1.1] - <prior>

Prior pre-launch state. See git history for details.
