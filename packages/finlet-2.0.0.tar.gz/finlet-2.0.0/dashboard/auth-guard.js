/* ============================================================
   Finlet — Auth Guard
   Centralized authentication check for all dashboard pages.
   Include this script BEFORE page-specific scripts.

   Behaviour:
   - Root URL (index.html) -> unauthenticated users go to landing.html
   - All other dashboard pages -> unauthenticated users go to auth.html

   Publishes a single hydration barrier promise as:
     window.__finletAuthGuardReady

   Page scripts MUST await this promise (or FinletAuth.ready()) before
   attaching click handlers / firing authenticated fetches. Awaiting
   isAuthenticated() alone is NOT enough — the marker can be present in
   sessionStorage before the CSRF token has been hydrated, which would
   cause state-changing requests to race past the CSRF middleware and
   receive 403 csrf_token_missing on a slow network.
   ============================================================ */

(function () {
    'use strict';

    function redirectToLogin() {
        var path = window.location.pathname;
        var page = path.substring(path.lastIndexOf('/') + 1) || 'index.html';
        // Root / index: show landing page instead of login wall
        if (page === '' || page === 'index.html') {
            window.location.replace('landing.html');
        } else {
            // Dashboard sub-pages (settings, billing, leaderboard, etc.):
            // require login.
            window.location.replace('auth.html');
        }
    }

    async function runGuard() {
        // Preferred path: delegate to FinletAuth.ready(), which caches the
        // in-flight /v1/auth/session/validate promise. This is the same
        // primitive page scripts await, so we share one network round-trip
        // across auth-guard + shared-nav + page init.
        if (typeof FinletAuth !== 'undefined' && typeof FinletAuth.ready === 'function') {
            try {
                var ok = await FinletAuth.ready();
                if (ok) return true;
            } catch (_e) { /* fall through */ }
        }

        // Fallback for any page that loaded auth-guard without auth.js
        // (should not happen in practice, but guard against it).
        try {
            var res = await fetch(window.location.origin + '/v1/auth/session/validate', {
                credentials: 'include',
            });
            if (res.ok) {
                // The probe returns 200 with {"valid": false} for
                // unauthenticated callers — must inspect the body, not
                // just the HTTP status. See auth-validate-401 regression
                // class in finlet/api/routes_auth_sessions.py.
                try {
                    var data = await res.json();
                    if (data && data.valid === true) {
                        if (data.csrf_token
                            && typeof FinletAuth !== 'undefined'
                            && typeof FinletAuth.setCsrfToken === 'function') {
                            FinletAuth.setCsrfToken(data.csrf_token);
                        }
                        return true;
                    }
                } catch (_e) { /* fall through to local-key check */ }
            }
        } catch (_e) { /* fall through */ }

        if (localStorage.getItem('finlet_api_key')) {
            return true;
        }
        return false;
    }

    // Kick off the hydration barrier immediately and expose the promise.
    // Resolves with true on success, false on failure (after triggering
    // the redirect).
    window.__finletAuthGuardReady = (async function () {
        var ok = await runGuard();
        if (!ok) {
            redirectToLogin();
            return false;
        }
        return true;
    })();
})();
