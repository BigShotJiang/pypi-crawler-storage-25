// API keys management (mint + listing + revoke).
// Extracted from legacy/dashboard-ui/settings.js during 2026-05-06 launch cut;
// the mint UX was restored 2026-05-10 (HIGH #6 + MEDIUM #9 of the v1.0.0
// blind-walk fixes — backend endpoint POST /v1/settings/api-keys already
// existed; the dashboard just lacked a button).
// See docs/decisions/ui-removal-launch-cut.md.

// State
let revokeKeyId = null;
let rotateKeyId = null;
let rotateKeyName = null;
// Raw key shown in the reveal modal. Held only for the lifetime of the modal
// (cleared on dismiss). NEVER logged, NEVER persisted client-side.
let _pendingRawKey = null;

// ============================================================
//  Init
// ============================================================
document.addEventListener('DOMContentLoaded', async () => {
    // Await the hydration barrier before binding any click handlers that
    // trigger state-changing requests (the revoke flow uses DELETE).
    const authOk = await awaitAuthReady();
    if (!authOk) {
        if (typeof FinletAuth !== 'undefined' && !FinletAuth.isAuthenticated()) {
            window.location.replace('auth.html');
        }
        return;
    }

    initSharedNav({
        activePage: 'api-keys',
        breadcrumbs: ['Dashboard', 'API Keys'],
    });

    initApiKeys();
});

// ============================================================
//  API Key Management
// ============================================================

function initApiKeys() {
    // Wire revoke modal buttons (the modal DOM is in api-keys.html).
    const cancelBtn = document.getElementById('revoke-cancel-btn');
    if (cancelBtn) {
        cancelBtn.addEventListener('click', () => closeModal('revoke-key-modal'));
    }
    const confirmBtn = document.getElementById('revoke-confirm-btn');
    if (confirmBtn) {
        confirmBtn.addEventListener('click', revokeApiKey);
    }

    // Wire rotate modal buttons.
    const rotateCancelBtn = document.getElementById('rotate-cancel-btn');
    if (rotateCancelBtn) {
        rotateCancelBtn.addEventListener('click', () => closeModal('rotate-key-modal'));
    }
    const rotateConfirmBtn = document.getElementById('rotate-confirm-btn');
    if (rotateConfirmBtn) {
        rotateConfirmBtn.addEventListener('click', rotateApiKey);
    }

    // Wire create-key modal buttons.
    const genBtn = document.getElementById('generate-key-btn');
    if (genBtn) {
        genBtn.addEventListener('click', openCreateKeyModal);
    }
    const createCancelBtn = document.getElementById('create-key-cancel-btn');
    if (createCancelBtn) {
        createCancelBtn.addEventListener('click', () => closeModal('create-key-modal'));
    }
    const createForm = document.getElementById('create-key-form');
    if (createForm) {
        createForm.addEventListener('submit', (ev) => {
            ev.preventDefault();
            createApiKey();
        });
    }

    // Wire reveal-modal buttons.
    const copyBtn = document.getElementById('reveal-key-copy-btn');
    if (copyBtn) {
        copyBtn.addEventListener('click', copyRevealedKey);
    }
    const doneBtn = document.getElementById('reveal-key-done-btn');
    if (doneBtn) {
        doneBtn.addEventListener('click', dismissRevealModal);
    }

    loadApiKeys();
}

function openCreateKeyModal() {
    const nameInput = document.getElementById('create-key-name');
    const errEl = document.getElementById('create-key-name-error');
    if (nameInput) nameInput.value = '';
    if (errEl) errEl.textContent = '';
    // Reset permissions to default "read-write".
    const rwRadio = document.querySelector('input[name="create-key-permissions"][value="read-write"]');
    if (rwRadio) rwRadio.checked = true;
    openModal('create-key-modal');
    if (nameInput) {
        // Defer focus so the modal-overlay transition doesn't yank it away.
        setTimeout(() => nameInput.focus(), 0);
    }
}

async function createApiKey() {
    const nameInput = document.getElementById('create-key-name');
    const errEl = document.getElementById('create-key-name-error');
    const submitBtn = document.getElementById('create-key-submit-btn');
    const name = (nameInput && nameInput.value || '').trim();

    if (errEl) errEl.textContent = '';
    if (!name) {
        if (errEl) errEl.textContent = 'Please enter a key name.';
        return;
    }
    if (name.length > 50) {
        if (errEl) errEl.textContent = 'Key name must be 50 characters or fewer.';
        return;
    }

    const permsEl = document.querySelector('input[name="create-key-permissions"]:checked');
    const permissions = (permsEl && permsEl.value) || 'read-write';

    if (submitBtn) {
        submitBtn.disabled = true;
        submitBtn.innerHTML = trustedHTML('<span class="settings-spinner"></span> Generating...');
    }

    const result = await apiRequest('/settings/api-keys', 'POST', { name, permissions });

    if (submitBtn) {
        submitBtn.disabled = false;
        submitBtn.textContent = 'Generate Key';
    }

    if (!result || !result.key) {
        // apiRequest already surfaced a toast on error; just stay on the form.
        return;
    }

    // Hand off to the reveal modal. The raw key is shown ONCE here and is
    // never logged or persisted. Closing the reveal modal clears the
    // in-memory copy and refreshes the listing (so the row appears with its
    // hashed prefix + revoke button).
    closeModal('create-key-modal');
    _pendingRawKey = result.key;
    const revealInput = document.getElementById('reveal-key-value');
    if (revealInput) revealInput.value = result.key;
    const copyBtn = document.getElementById('reveal-key-copy-btn');
    if (copyBtn) copyBtn.textContent = 'Copy to clipboard';
    openModal('reveal-key-modal');

    // Notify any other surface (e.g. shared-nav affordances) that the key set
    // changed. Payload carries only the metadata — never the raw key.
    if (window.finletBus && typeof window.finletBus.publish === 'function') {
        window.finletBus.publish('api_keys:updated', { action: 'created', key_id: result.id });
    }
}

async function copyRevealedKey() {
    if (!_pendingRawKey) return;
    const copyBtn = document.getElementById('reveal-key-copy-btn');
    try {
        if (navigator.clipboard && typeof navigator.clipboard.writeText === 'function') {
            await navigator.clipboard.writeText(_pendingRawKey);
        } else {
            // Legacy fallback: select the input and use document.execCommand.
            const input = document.getElementById('reveal-key-value');
            if (input) {
                input.select();
                input.setSelectionRange(0, _pendingRawKey.length);
                document.execCommand('copy');
            }
        }
        if (copyBtn) copyBtn.textContent = 'Copied!';
        showToast('API key copied to clipboard', 'success');
    } catch {
        showToast('Could not copy &mdash; select the field and copy manually', 'error');
    }
}

function dismissRevealModal() {
    // Clear the in-memory raw key and the input value so it can't be scraped
    // post-dismiss by a misbehaving extension.
    _pendingRawKey = null;
    const revealInput = document.getElementById('reveal-key-value');
    if (revealInput) revealInput.value = '';
    // Reset modal title back to the create-flow default so a subsequent mint
    // doesn't carry over the "rotated" copy from the rotate flow.
    const revealTitle = document.getElementById('reveal-key-modal-title');
    if (revealTitle) revealTitle.textContent = 'Your new API key';
    closeModal('reveal-key-modal');
    // Refresh the list so the new key shows up (hashed prefix only) with
    // its revoke button.
    loadApiKeys();
}

async function loadApiKeys() {
    const container = document.getElementById('api-key-list');
    if (!container) return;

    const data = await apiFetch('/settings/api-keys');

    if (!data || !data.keys || data.keys.length === 0) {
        container.innerHTML = trustedHTML(`
            <div class="api-key-empty">
                <div class="api-key-empty-icon">&#128273;</div>
                <div class="api-key-empty-title">No API keys yet</div>
                <div class="api-key-empty-desc">Click <strong>Generate New Key</strong> above to create your first API key.</div>
            </div>
        `);
        return;
    }

    // Filter to only show active keys first, then revoked
    const sortedKeys = [...data.keys].sort((a, b) => {
        if (a.status === 'active' && b.status !== 'active') return -1;
        if (a.status !== 'active' && b.status === 'active') return 1;
        return 0;
    });

    container.innerHTML = trustedHTML(`
        <table class="api-key-table">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Key</th>
                    <th>Created</th>
                    <th>Last Used</th>
                    <th>Status</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                ${sortedKeys.map(key => `
                    <tr data-key-id="${esc(key.id)}">
                        <td class="api-key-name-cell">${esc(key.name)}</td>
                        <td><span class="api-key-mono">${esc(key.prefix)}</span></td>
                        <td>${esc(formatDateShort(key.created_at))}</td>
                        <td>${key.last_used ? esc(formatRelativeTime(key.last_used)) : '<span style="color: var(--text-muted);">Never</span>'}</td>
                        <td><span class="api-key-status api-key-status--${key.status === 'active' ? 'active' : 'revoked'}">${esc(key.status)}</span></td>
                        <td class="api-key-actions-cell">
                            ${key.status === 'active'
                                ? `<button class="btn-settings btn-settings--sm" data-action="rotate-api-key" data-key-id="${esc(key.id)}" data-key-name="${esc(key.name)}">Rotate</button>
                                   <button class="btn-settings btn-settings--sm btn-settings--danger" data-action="revoke-api-key" data-key-id="${esc(key.id)}" data-key-name="${esc(key.name)}">Revoke</button>`
                                : ''
                            }
                        </td>
                    </tr>
                `).join('')}
            </tbody>
        </table>
    `);

    // Bind revoke buttons via event delegation instead of inline onclick
    container.querySelectorAll('[data-action="revoke-api-key"]').forEach(btn => {
        btn.addEventListener('click', () => {
            confirmRevokeKey(btn.dataset.keyId, btn.dataset.keyName);
        });
    });

    // Bind rotate buttons via event delegation (mirrors revoke wiring above).
    container.querySelectorAll('[data-action="rotate-api-key"]').forEach(btn => {
        btn.addEventListener('click', () => {
            confirmRotateKey(btn.dataset.keyId, btn.dataset.keyName);
        });
    });
}

function confirmRevokeKey(keyId, keyName) {
    revokeKeyId = keyId;
    const nameEl = document.getElementById('revoke-key-name');
    if (nameEl) nameEl.textContent = keyName;
    openModal('revoke-key-modal');
}

async function revokeApiKey() {
    if (!revokeKeyId) return;

    const btn = document.getElementById('revoke-confirm-btn');
    btn.disabled = true;
    btn.innerHTML = trustedHTML('<span class="settings-spinner"></span> Revoking...');

    const result = await apiRequest(`/settings/api-keys/${revokeKeyId}`, 'DELETE');

    btn.disabled = false;
    btn.textContent = 'Revoke Key';

    if (result) {
        const revokedId = revokeKeyId;
        closeModal('revoke-key-modal');
        showToast('API key revoked', 'success');
        if (window.finletBus && typeof window.finletBus.publish === 'function') {
            window.finletBus.publish('api_keys:updated', { action: 'revoked', key_id: revokedId });
        }
        loadApiKeys();
    }
    revokeKeyId = null;
}

function confirmRotateKey(keyId, keyName) {
    rotateKeyId = keyId;
    rotateKeyName = keyName;
    const nameEl = document.getElementById('rotate-key-name');
    if (nameEl) nameEl.textContent = keyName;
    openModal('rotate-key-modal');
}

async function rotateApiKey() {
    if (!rotateKeyId) return;

    const btn = document.getElementById('rotate-confirm-btn');
    if (btn) {
        btn.disabled = true;
        btn.innerHTML = trustedHTML('<span class="settings-spinner"></span> Rotating...');
    }

    // The /settings/api-keys/rotate endpoint takes no body — it rotates the
    // user's primary key server-side and returns the new raw key with a
    // grace-period window during which the prior key still authenticates.
    const result = await apiRequest('/settings/api-keys/rotate', 'POST');

    if (btn) {
        btn.disabled = false;
        btn.textContent = 'Rotate Key';
    }

    if (!result || !result.new_api_key) {
        // apiRequest already surfaced a toast on error; keep the modal open so
        // the user can retry or cancel.
        return;
    }

    const rotatedId = rotateKeyId;
    closeModal('rotate-key-modal');

    // Hand off to the same one-time reveal modal the create flow uses. Update
    // the title/copy so the user sees this is a rotated (not freshly minted)
    // key. The raw token is held in module scope for the modal lifetime only.
    _pendingRawKey = result.new_api_key;
    const revealInput = document.getElementById('reveal-key-value');
    if (revealInput) revealInput.value = result.new_api_key;
    const revealTitle = document.getElementById('reveal-key-modal-title');
    if (revealTitle) revealTitle.textContent = 'Your rotated API key';
    const copyBtn = document.getElementById('reveal-key-copy-btn');
    if (copyBtn) copyBtn.textContent = 'Copy to clipboard';
    openModal('reveal-key-modal');

    // Notify other surfaces (shared-nav affordances etc.) that the key set
    // changed. Payload carries only metadata — never the raw key. The
    // service-layer rotate response doesn't surface a `new_key_id` field, so
    // we publish the original (rotated) key's id; subscribers treat this as
    // a trigger to refresh, not as a value carrier.
    if (window.finletBus && typeof window.finletBus.publish === 'function') {
        window.finletBus.publish('api_keys:updated', { action: 'rotated', key_id: rotatedId });
    }

    rotateKeyId = null;
    rotateKeyName = null;
}

// ============================================================
//  Modal helpers (minimal — wraps window.finletModal if present).
// ============================================================

function openModal(id) {
    const modal = document.getElementById(id);
    if (!modal) return;
    if (window.finletModal && typeof window.finletModal.open === 'function') {
        window.finletModal.open(id);
    } else {
        modal.style.display = '';
        modal.classList.add('modal-overlay--visible');
    }
}

function closeModal(id) {
    const modal = document.getElementById(id);
    if (!modal) return;
    if (window.finletModal && typeof window.finletModal.close === 'function') {
        window.finletModal.close(id);
    } else {
        modal.classList.remove('modal-overlay--visible');
        modal.style.display = 'none';
    }
}

// ============================================================
//  Toast notifications (minimal copy from legacy settings.js).
// ============================================================

function showToast(message, type = 'info') {
    const container = document.getElementById('toast-container');
    if (!container) return;

    // Deduplicate
    const existing = container.querySelectorAll('.toast');
    for (const t of existing) {
        if (t.textContent === message) return;
    }

    const toast = document.createElement('div');
    toast.className = 'toast toast--' + type;
    toast.textContent = message;
    container.appendChild(toast);

    requestAnimationFrame(() => toast.classList.add('toast--visible'));

    setTimeout(() => {
        toast.classList.remove('toast--visible');
        setTimeout(() => toast.remove(), 300);
    }, 4000);
}

// ============================================================
//  Date formatting helpers (minimal copy from legacy settings.js).
// ============================================================

function formatDateShort(dt) {
    if (!dt) return '--';
    try {
        return new Date(dt).toISOString().slice(0, 10);
    } catch {
        return esc(String(dt));
    }
}

function formatRelativeTime(dt) {
    if (!dt) return '--';
    try {
        const diff = Date.now() - new Date(dt).getTime();
        const mins = Math.floor(diff / 60000);
        if (mins < 1) return 'just now';
        if (mins < 60) return `${mins}m ago`;
        const hours = Math.floor(mins / 60);
        if (hours < 24) return `${hours}h ago`;
        const days = Math.floor(hours / 24);
        return `${days}d ago`;
    } catch {
        return esc(String(dt));
    }
}
