/* ============================================================
   Finlet — Feedback & Error Reporting (Sentry Integration)

   Initializes the Sentry JS SDK for error tracking and provides
   a feedback widget that users can trigger from the footer or
   user menu. Falls back gracefully if Sentry SDK fails to load.

   Dependencies: loaded after api-utils.js (uses esc(), reportClientError())
   ============================================================ */

/**
 * Feedback module. Handles Sentry initialization and feedback widget.
 * If Sentry is unavailable, "Report a Bug" degrades to a mailto: link.
 */
var FinletFeedback = (function() {
    'use strict';

    var _sentryReady = false;
    var _feedbackIntegration = null;
    var FALLBACK_EMAIL = 'support@finlet.dev';

    /**
     * Initialize Sentry SDK if available and DSN is configured.
     * Called on DOMContentLoaded.
     */
    function init() {
        // Read DSN from <meta> tag
        var dsnMeta = document.querySelector('meta[name="sentry-dsn"]');
        var dsn = dsnMeta ? dsnMeta.getAttribute('content') : '';

        if (!dsn || dsn === 'YOUR_SENTRY_DSN_HERE' || typeof Sentry === 'undefined') {
            _sentryReady = false;
            _applyFallback();
            return;
        }

        try {
            // Initialize Sentry with feedback integration
            _feedbackIntegration = Sentry.feedbackIntegration({
                colorScheme: 'dark',
                buttonLabel: 'Report a Bug',
                submitButtonLabel: 'Send Report',
                cancelButtonLabel: 'Cancel',
                formTitle: 'Report a Bug',
                messagePlaceholder: 'Describe what happened. Include steps to reproduce if possible.',
                successMessageText: 'Thanks! Your report has been submitted.',
                showBranding: false,
                autoInject: false,
            });

            Sentry.init({
                dsn: dsn,
                integrations: [_feedbackIntegration],
                // Capture 10% of transactions for performance monitoring
                tracesSampleRate: 0.1,
                // Tag with environment
                environment: window.location.hostname === 'localhost' ? 'development' : 'production',
            });

            // Tag user if authenticated
            _tagSentryUser();

            _sentryReady = true;
        } catch (e) {
            console.warn('[Finlet] Sentry init failed, using fallback:', e);
            _sentryReady = false;
            _applyFallback();
        }
    }

    /**
     * Tag the current Sentry scope with user info if available.
     */
    function _tagSentryUser() {
        try {
            if (typeof Sentry === 'undefined') return;
            var user = (typeof FinletAuth !== 'undefined') ? FinletAuth.getUser() : null;
            if (user) {
                Sentry.setUser({
                    email: user.email || undefined,
                    id: user.id || undefined,
                });
            }
        } catch (_e) {
            // Non-critical
        }
    }

    /**
     * Open the Sentry feedback widget. If Sentry is unavailable,
     * opens a mailto: link instead.
     */
    function openFeedback() {
        if (_sentryReady && _feedbackIntegration) {
            try {
                var widget = _feedbackIntegration.createWidget();
                if (widget && typeof widget.open === 'function') {
                    widget.open();
                    return;
                }
            } catch (e) {
                console.warn('[Finlet] Sentry feedback widget failed, using fallback:', e);
            }
        }
        // Fallback: open mailto
        _openMailtoFallback();
    }

    /**
     * Apply fallback behavior to all feedback triggers.
     * Converts "Report a Bug" links/buttons to mailto: links.
     */
    function _applyFallback() {
        // Update footer links
        var footerLink = document.getElementById('footer-report-bug');
        if (footerLink) {
            footerLink.href = _buildMailtoUrl();
            footerLink.removeAttribute('data-feedback');
        }
    }

    /**
     * Open a pre-filled mailto: link as fallback.
     */
    function _openMailtoFallback() {
        window.location.href = _buildMailtoUrl();
    }

    /**
     * Build a mailto: URL with pre-filled subject and body.
     */
    function _buildMailtoUrl() {
        var subject = encodeURIComponent('Finlet Bug Report');
        var body = encodeURIComponent(
            'Description:\n\n' +
            'Steps to reproduce:\n1. \n2. \n3. \n\n' +
            '---\n' +
            'URL: ' + window.location.href + '\n' +
            'User Agent: ' + navigator.userAgent + '\n' +
            'Timestamp: ' + new Date().toISOString()
        );
        return 'mailto:' + FALLBACK_EMAIL + '?subject=' + subject + '&body=' + body;
    }

    /**
     * Check if Sentry is ready.
     */
    function isReady() {
        return _sentryReady;
    }

    return {
        init: init,
        openFeedback: openFeedback,
        isReady: isReady,
    };
})();

// Wire up click handlers once DOM is ready
document.addEventListener('DOMContentLoaded', function() {
    // Initialize Sentry
    FinletFeedback.init();

    // Wire up footer "Report a Bug" link
    var footerLink = document.getElementById('footer-report-bug');
    if (footerLink) {
        footerLink.addEventListener('click', function(e) {
            if (FinletFeedback.isReady()) {
                e.preventDefault();
                FinletFeedback.openFeedback();
            }
            // If not ready, href is already mailto: — let it through
        });
    }

    // Wire up user menu "Send Feedback" button
    var menuFeedback = document.getElementById('menu-feedback');
    if (menuFeedback) {
        menuFeedback.addEventListener('click', function(e) {
            e.preventDefault();
            FinletFeedback.openFeedback();
            // Close the user menu
            var menu = document.getElementById('user-menu');
            var trigger = document.getElementById('user-menu-trigger');
            if (menu) menu.classList.remove('user-menu--open');
            if (trigger) trigger.setAttribute('aria-expanded', 'false');
        });
    }
});
