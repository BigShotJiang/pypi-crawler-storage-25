/**
 * Mobile Navigation — Hamburger menu + slide-out drawer
 *
 * Handles:
 * - Hamburger button toggle
 * - Drawer open/close with backdrop
 * - Escape key to close
 * - Click-outside to close
 * - Focus trap inside drawer when open
 * - Syncs user info from desktop user-menu if present
 * - Respects prefers-reduced-motion
 *
 * Called by initSharedNav() after the header HTML (including #hamburger-btn)
 * has been injected into the DOM. Must not run as an IIFE because the
 * hamburger button does not exist until shared-nav.js creates it.
 */
// eslint-disable-next-line no-unused-vars
function initMobileNav() {
    'use strict';

    // Guard against double-init (initSharedNav calls us; prevent duplicate listeners)
    if (initMobileNav._initialized) return;

    const hamburgerBtn = document.getElementById('hamburger-btn');
    const navDrawer = document.getElementById('nav-drawer');
    const navBackdrop = document.getElementById('nav-backdrop');
    const drawerClose = document.getElementById('nav-drawer-close');

    // Bail if elements not found (e.g., auth page)
    if (!hamburgerBtn || !navDrawer) return;

    initMobileNav._initialized = true;

    const drawerCopyKey = document.getElementById('nav-drawer-copy-key');
    const drawerLogout = document.getElementById('nav-drawer-logout');

    // Relabel the drawer's API-key affordance to match the current auth
    // state at mount. The shared-nav `_initSharedUserMenu()` mount-time
    // pass already covers this for pages where shared-nav initializes
    // before mobile-nav, but calling the umbrella here is defensive in
    // case a future load order flips them — and it's idempotent (same
    // helper, same source-of-truth read).
    if (window.SharedNav && typeof window.SharedNav._relabelAllApiKeyAffordances === 'function') {
        window.SharedNav._relabelAllApiKeyAffordances();
    }

    let isOpen = false;
    let previouslyFocused = null;

    function openDrawer() {
        if (isOpen) return;
        isOpen = true;
        previouslyFocused = document.activeElement;
        document.body.classList.add('nav-open');
        hamburgerBtn.setAttribute('aria-expanded', 'true');
        hamburgerBtn.setAttribute('aria-label', 'Close navigation menu');
        navBackdrop.setAttribute('aria-hidden', 'false');

        // Prevent body scroll
        document.body.style.overflow = 'hidden';

        // Focus the close button
        requestAnimationFrame(function() {
            if (drawerClose) drawerClose.focus();
        });
    }

    function closeDrawer() {
        if (!isOpen) return;
        isOpen = false;
        document.body.classList.remove('nav-open');
        hamburgerBtn.setAttribute('aria-expanded', 'false');
        hamburgerBtn.setAttribute('aria-label', 'Open navigation menu');
        navBackdrop.setAttribute('aria-hidden', 'true');

        // Restore body scroll
        document.body.style.overflow = '';

        // Restore focus
        if (previouslyFocused && previouslyFocused.focus) {
            previouslyFocused.focus();
        }
    }

    function toggleDrawer() {
        if (isOpen) {
            closeDrawer();
        } else {
            openDrawer();
        }
    }

    // Hamburger button click
    hamburgerBtn.addEventListener('click', toggleDrawer);

    // Close button click
    if (drawerClose) {
        drawerClose.addEventListener('click', closeDrawer);
    }

    // Backdrop click
    if (navBackdrop) {
        navBackdrop.addEventListener('click', closeDrawer);
    }

    // Escape key
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape' && isOpen) {
            e.preventDefault();
            closeDrawer();
        }
    });

    // Focus trap inside drawer
    navDrawer.addEventListener('keydown', function(e) {
        if (e.key !== 'Tab' || !isOpen) return;

        var focusable = navDrawer.querySelectorAll(
            'a[href], button:not([disabled]), input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])'
        );
        if (focusable.length === 0) return;

        var first = focusable[0];
        var last = focusable[focusable.length - 1];

        if (e.shiftKey) {
            if (document.activeElement === first) {
                e.preventDefault();
                last.focus();
            }
        } else {
            if (document.activeElement === last) {
                e.preventDefault();
                first.focus();
            }
        }
    });

    // Close drawer on window resize if going above mobile breakpoint
    var resizeTimer;
    window.addEventListener('resize', function() {
        clearTimeout(resizeTimer);
        resizeTimer = setTimeout(function() {
            if (window.innerWidth > 768 && isOpen) {
                closeDrawer();
            }
        }, 100);
    });

    // Sync user info from desktop user menu (if available)
    function syncUserInfo() {
        var desktopEmail = document.getElementById('user-menu-email');
        var desktopAvatar = document.getElementById('user-avatar');
        var desktopTier = document.getElementById('user-menu-tier');

        var drawerEmail = document.getElementById('nav-drawer-user-email');
        var drawerAvatar = document.getElementById('nav-drawer-avatar');
        var drawerTier = document.getElementById('nav-drawer-user-tier');

        if (desktopEmail && drawerEmail && desktopEmail.textContent !== '--') {
            drawerEmail.textContent = desktopEmail.textContent;
        }
        if (desktopAvatar && drawerAvatar && desktopAvatar.textContent !== '?') {
            drawerAvatar.textContent = desktopAvatar.textContent;
        }
        if (desktopTier && drawerTier && desktopTier.textContent !== '--') {
            drawerTier.textContent = desktopTier.textContent;
        }
    }

    // Sync periodically (user data loads async)
    syncUserInfo();
    var syncInterval = setInterval(function() {
        syncUserInfo();
        var email = document.getElementById('nav-drawer-user-email');
        if (email && email.textContent !== '--') {
            clearInterval(syncInterval);
        }
    }, 1000);

    // After 30 seconds, stop trying
    setTimeout(function() { clearInterval(syncInterval); }, 30000);

    // Wire up drawer action buttons
    if (drawerCopyKey) {
        drawerCopyKey.addEventListener('click', function() {
            // Trigger the desktop copy key button if it exists
            var desktopCopyKey = document.getElementById('menu-copy-key');
            if (desktopCopyKey) {
                desktopCopyKey.click();
            } else if (typeof FinletAuth !== 'undefined' && FinletAuth.getApiKey) {
                // Fallback: copy directly
                var key = FinletAuth.getApiKey();
                if (key && navigator.clipboard) {
                    navigator.clipboard.writeText(key).then(function() {
                        drawerCopyKey.textContent = 'Copied!';
                        setTimeout(function() {
                            // Reset via the shared helper so the post-toast label
                            // respects the current auth state (matters if logout
                            // fires during the 2-second toast window). Fall back
                            // to a no-op if shared-nav hasn't loaded yet — the
                            // shared-nav mount-time pass + bus subscriber will
                            // catch up on the next auth tick.
                            if (window.SharedNav
                                && typeof window.SharedNav._relabelCopyApiKeyButton === 'function') {
                                window.SharedNav._relabelCopyApiKeyButton(drawerCopyKey);
                            }
                        }, 2000);
                    });
                }
            }
            closeDrawer();
        });
    }

    if (drawerLogout) {
        drawerLogout.addEventListener('click', function() {
            // Trigger the desktop logout button if it exists
            var desktopLogout = document.getElementById('menu-logout');
            if (desktopLogout) {
                desktopLogout.click();
            } else if (typeof FinletAuth !== 'undefined' && FinletAuth.logout) {
                FinletAuth.logout();
                window.location.replace('auth.html');
            }
        });
    }
}
