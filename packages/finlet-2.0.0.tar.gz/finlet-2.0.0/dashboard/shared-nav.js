/* ============================================================
   Finlet — Shared Navigation Component
   Injects a consistent header (logo, nav links, user menu,
   optional session selector) and breadcrumbs across all pages.

   Usage:
     initSharedNav({
       activePage: 'billing',
       breadcrumbs: ['Dashboard', 'Billing'],
       showSessionSelector: false,
       showRefreshStatus: false,
       showConnectionIndicator: false,
       showSimTime: false,
     });

   Pattern follows api-utils.js — plain script tag, no build step.
   ============================================================ */

/**
 * Canonical id list of every API-key affordance the dashboard renders.
 * Adding a new surface (a new mobile drawer, a new context menu, etc.)
 * is a one-line append here — the umbrella `_relabelAllApiKeyAffordances()`
 * iterates this list, so mount-time + bus-subscriber relabel paths all
 * pick up the new surface automatically.
 *
 * Both surfaces share the same dual-label semantics (see
 * docs/decisions/copy-api-key-dead-affordance.md):
 *   - `FinletAuth.getApiKey()` non-null  → "Copy API Key" (clipboard write)
 *   - `FinletAuth.getApiKey()` null      → "Manage API Key" (redirect to Settings)
 */
var API_KEY_AFFORDANCE_IDS = ['menu-copy-key', 'nav-drawer-copy-key'];

/**
 * Simple HTML entity escaper for safe insertion.
 * If a global esc() exists (from api-utils.js security upgrades),
 * we delegate to it; otherwise use a minimal fallback.
 */
function _navEsc(str) {
    if (typeof esc === 'function') return esc(str);
    if (!str) return '';
    var s = String(str);
    return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}

/**
 * Safe innerHTML setter. Uses trustedHTML() if available (Trusted Types),
 * otherwise sets innerHTML directly.
 */
function _navSetHTML(el, html) {
    el.innerHTML = trustedHTML(html);
}

/**
 * Initialize the shared navigation shell.
 * Finds a <header class="top-bar"> placeholder and injects the
 * standard nav HTML, then wires up the user menu.
 *
 * @param {Object} opts
 * @param {string} opts.activePage - Which nav link to highlight
 * @param {string[]} [opts.breadcrumbs] - Breadcrumb trail, e.g. ['Dashboard', 'Billing']
 * @param {boolean} [opts.showSessionSelector=false] - Show session dropdown
 * @param {boolean} [opts.showRefreshStatus=false] - Show refresh button
 * @param {boolean} [opts.showConnectionIndicator=false] - Show connection dot
 * @param {boolean} [opts.showSimTime=false] - Show sim time in header
 */
function initSharedNav(opts) {
    var activePage = (opts && opts.activePage) || 'dashboard';
    var breadcrumbs = (opts && opts.breadcrumbs) || null;
    var showSessionSelector = (opts && opts.showSessionSelector) || false;
    var showRefreshStatus = (opts && opts.showRefreshStatus) || false;
    var showConnectionIndicator = (opts && opts.showConnectionIndicator) || false;
    var showSimTime = (opts && opts.showSimTime) || false;

    // Build the header HTML
    var headerHTML = _buildHeaderHTML({
        activePage: activePage,
        showSessionSelector: showSessionSelector,
        showRefreshStatus: showRefreshStatus,
        showConnectionIndicator: showConnectionIndicator,
        showSimTime: showSimTime,
    });

    // Find the placeholder header and replace its content
    var header = document.querySelector('header.top-bar');
    if (header) {
        header.setAttribute('role', 'banner');
        _navSetHTML(header, headerHTML);
    }

    // Inject breadcrumbs if specified
    if (breadcrumbs && breadcrumbs.length > 1) {
        _injectBreadcrumbs(breadcrumbs);
    }

    // Initialize user menu behavior
    _initSharedUserMenu();

    // Initialize mobile nav (hamburger + drawer) now that #hamburger-btn exists
    if (typeof initMobileNav === 'function') {
        initMobileNav();
    }
}

/**
 * Build the header inner HTML string.
 */
function _buildHeaderHTML(opts) {
    var activePage = opts.activePage;
    var showSessionSelector = opts.showSessionSelector;
    var showRefreshStatus = opts.showRefreshStatus;
    var showConnectionIndicator = opts.showConnectionIndicator;
    var showSimTime = opts.showSimTime;

    var navLinks = [
        { href: 'index.html', label: 'Dashboard', key: 'dashboard' },
        { href: 'leaderboard.html', label: 'Leaderboard', key: 'leaderboard' },
        { href: 'api-keys.html', label: 'API Keys', key: 'api-keys' },
        { href: 'billing.html', label: 'Billing', key: 'billing' },
        { href: 'settings.html', label: 'Settings', key: 'settings' },
    ];

    // Build nav links with active state
    var navLinksHTML = navLinks
        .map(function(link) {
            var isActive = link.key === activePage;
            var activeClass = isActive ? ' header-nav-link--active' : '';
            var ariaCurrent = isActive ? ' aria-current="page"' : '';
            return '<a href="' + _navEsc(link.href) + '" class="header-nav-link' + activeClass + '"' + ariaCurrent + '>' + _navEsc(link.label) + '</a>';
        })
        .join('\n                ');

    // Hamburger button for mobile nav
    var hamburgerHTML =
        '<button class="hamburger-btn" id="hamburger-btn" type="button" aria-label="Open navigation menu" aria-expanded="false" aria-controls="nav-drawer">' +
            '<span class="hamburger-icon" aria-hidden="true">' +
                '<span></span>' +
                '<span></span>' +
                '<span></span>' +
            '</span>' +
        '</button>';

    // Session selector (only on pages that need it)
    var sessionSelectorHTML = '';
    if (showSessionSelector) {
        sessionSelectorHTML =
            '<div class="session-selector">' +
                '<select id="session-select" aria-label="Select trading session">' +
                    '<option value="">Select Session...</option>' +
                '</select>' +
                '<button class="btn-new-session" id="btn-new-session" type="button" aria-label="Create new session">' +
                    '<svg width="12" height="12" viewBox="0 0 12 12" fill="none" aria-hidden="true"><path d="M6 1v10M1 6h10" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/></svg>' +
                    '<span>New</span>' +
                '</button>' +
                '<span id="session-status" class="badge badge--idle" role="status" aria-live="polite" aria-label="Session status">--</span>' +
            '</div>';
    }

    // Refresh status (only on pages that need it)
    var refreshHTML = '';
    if (showRefreshStatus) {
        refreshHTML =
            '<div class="refresh-status">' +
                '<span id="last-updated"></span>' +
                '<button class="btn-refresh" id="btn-refresh" title="Refresh data" aria-label="Refresh dashboard data">' +
                    '<svg width="12" height="12" viewBox="0 0 12 12" fill="none" aria-hidden="true"><path d="M10 2v3H7" stroke="currentColor" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"/><path d="M2 10V7h3" stroke="currentColor" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"/><path d="M9.5 4.5A4 4 0 0 0 3 2.5L2 4M2.5 7.5A4 4 0 0 0 9 9.5l1-1.5" stroke="currentColor" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"/></svg>' +
                    'Refresh' +
                '</button>' +
            '</div>';
    }

    // Connection indicator
    var connectionHTML = '';
    if (showConnectionIndicator) {
        connectionHTML =
            '<div class="connection-indicator" id="connection-indicator" role="status" aria-live="polite" aria-label="Server connection status" title="Click to retry connection">' +
                '<span class="connection-dot connection-dot--connecting" id="connection-dot" aria-hidden="true"></span>' +
                '<span class="connection-label" id="connection-label">Connecting...</span>' +
            '</div>';
    }

    // Sim time
    var simTimeHTML = '';
    if (showSimTime) {
        simTimeHTML = '<span id="header-sim-time" class="sim-time-small" aria-label="Simulation time">--</span>';
    }

    // Trade button removed during 2026-05-06 launch cut — write-path UI moved to legacy/.
    // User menu
    var userMenuHTML =
        '<div class="user-menu" id="user-menu">' +
            '<button class="user-menu-trigger" id="user-menu-trigger" type="button" ' +
                'aria-haspopup="true" aria-expanded="false" aria-label="User menu">' +
                '<span class="user-avatar" id="user-avatar">?</span>' +
                '<span class="user-name" id="user-display-name">Account</span>' +
                '<span class="user-menu-chevron" aria-hidden="true">&#9660;</span>' +
            '</button>' +
            '<div class="user-menu-dropdown" role="menu" aria-label="User actions">' +
                '<div class="user-menu-info">' +
                    '<div class="user-menu-email" id="user-menu-email">--</div>' +
                    '<div class="user-menu-tier" id="user-menu-tier">--</div>' +
                '</div>' +
                '<div class="user-menu-actions">' +
                    '<button class="user-menu-item" role="menuitem" id="menu-copy-key">Copy API Key</button>' +
                    '<button class="user-menu-item" role="menuitem" id="menu-feedback">Send Feedback</button>' +
                    '<button class="user-menu-item user-menu-item--danger" role="menuitem" id="menu-logout">Sign Out</button>' +
                '</div>' +
            '</div>' +
        '</div>';

    return (
        hamburgerHTML +
        '<a href="index.html" class="logo" aria-label="Finlet home">Finlet</a>' +
        sessionSelectorHTML +
        '<div class="header-right">' +
            '<nav class="header-nav" aria-label="Primary navigation">' +
                navLinksHTML +
            '</nav>' +
            refreshHTML +
            connectionHTML +
            simTimeHTML +
            userMenuHTML +
        '</div>'
    );
}

/**
 * Inject breadcrumbs into the page.
 * Looks for the first element with class "page-container", "settings-layout",
 * or a <main> tag and prepends the breadcrumb nav before its first child.
 */
function _injectBreadcrumbs(crumbs) {
    // Find existing breadcrumb nav and remove it (avoid duplicates)
    var existing = document.querySelector('nav.breadcrumbs');
    if (existing) existing.remove();

    // Build breadcrumb HTML
    var parts = crumbs.map(function(crumb, i) {
        var isLast = i === crumbs.length - 1;
        if (isLast) {
            return '<span class="breadcrumb-current">' + _navEsc(crumb) + '</span>';
        }
        // First crumb links to dashboard
        var href = 'index.html';
        var sep = '<span class="breadcrumb-sep" aria-hidden="true">/</span>';
        return '<a href="' + _navEsc(href) + '">' + _navEsc(crumb) + '</a>' + sep;
    });

    var breadcrumbNav = document.createElement('nav');
    breadcrumbNav.className = 'breadcrumbs';
    breadcrumbNav.setAttribute('aria-label', 'Breadcrumb');
    _navSetHTML(breadcrumbNav, parts.join(''));

    // Insert into the page content area
    var container = document.querySelector('.page-container, .settings-layout, main');
    if (container) {
        container.insertBefore(breadcrumbNav, container.firstChild);
    }
}

/**
 * Initialize user menu toggle, copy API key, and sign out.
 * Extracted from app.js initUserMenu() to be shared across all pages.
 */
function _initSharedUserMenu() {
    var menu = document.getElementById('user-menu');
    var trigger = document.getElementById('user-menu-trigger');
    if (!menu || !trigger) return;

    // Populate user info from stored auth data
    var user = (typeof FinletAuth !== 'undefined') ? FinletAuth.getUser() : null;
    if (user) {
        var displayName = user.name || user.email || 'Account';
        var initial = (displayName.charAt(0) || '?').toUpperCase();
        _setUserMenuFields(initial, displayName, user.email || '--',
            (user.tier || 'free').charAt(0).toUpperCase() + (user.tier || 'free').slice(1) + ' tier');
    }

    // Fetch fresh user info
    _fetchSharedUserProfile();

    // Relabel every API-key affordance (#menu-copy-key + #nav-drawer-copy-key)
    // on initial mount (BEFORE any user interaction) so the collapsed-state
    // ARIA accessible name matches the click handler's actual semantics on
    // BOTH desktop and mobile drawer surfaces. The button is one affordance
    // with two semantics:
    //   - "Copy API Key" → clipboard write (signup/just-rotated path)
    //   - "Manage API Key" → redirect to Settings → API Keys (login path)
    // See docs/decisions/copy-api-key-dead-affordance.md.
    //
    // Without this, the static "Copy API Key" literal from _buildHeaderHTML
    // (and from the static HTML on each page) remains visible to screen
    // readers and aria-snapshots on cookie-session paths — a misleading
    // collapsed-state label.
    _relabelAllApiKeyAffordances();

    // Subscribe to auth:state-change so any future mutation (saveAuth /
    // clearAuth via FinletAuth.logout) repaints both surfaces atomically.
    // The subscription persists for the page lifetime — no teardown hook
    // is needed because the bus + this module share a per-page lifecycle.
    if (typeof window !== 'undefined' && window.finletBus
        && typeof window.finletBus.subscribe === 'function') {
        window.finletBus.subscribe('auth:state-change', _relabelAllApiKeyAffordances);
    }

    // Toggle dropdown. The bus subscriber above covers any case where a key
    // is minted between page load and menu open, so the previous gated
    // `if (isOpen) _relabelCopyApiKeyButton()` branch is no longer needed.
    trigger.addEventListener('click', function(e) {
        e.stopPropagation();
        var isOpen = menu.classList.toggle('user-menu--open');
        trigger.setAttribute('aria-expanded', String(isOpen));
    });

    // Close on outside click
    document.addEventListener('click', function(e) {
        if (!menu.contains(e.target)) {
            menu.classList.remove('user-menu--open');
            trigger.setAttribute('aria-expanded', 'false');
        }
    });

    // Close on Escape
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape' && menu.classList.contains('user-menu--open')) {
            menu.classList.remove('user-menu--open');
            trigger.setAttribute('aria-expanded', 'false');
            trigger.focus();
        }
    });

    // Copy API key
    //
    // The "Copy API Key" button is a dual-affordance entry point:
    //   - signup tab / just-created-key tab: FinletAuth.getApiKey() returns
    //     the raw key (from _inMemoryApiKey or sessionStorage.finlet_created_api_key)
    //     → clipboard write + toast.
    //   - logged-in (cookie session) path: getApiKey() returns null because
    //     the raw key is correctly never persisted client-side after the
    //     /auth/session handshake (only the literal sentinel 'cookie' lives
    //     in sessionStorage.finlet_api_key — that is NOT a key). In this
    //     state we redirect to Settings → API Keys so the user can mint a
    //     new named key. See docs/decisions/copy-api-key-dead-affordance.md.
    //
    // SECURITY: do NOT add a server endpoint that exposes raw keys. Stored
    // keys are hashed and the cleartext is intentionally unrecoverable.
    var copyKeyBtn = document.getElementById('menu-copy-key');
    if (copyKeyBtn) {
        copyKeyBtn.addEventListener('click', function() {
            var key = (typeof FinletAuth !== 'undefined') ? FinletAuth.getApiKey() : null;
            if (key) {
                navigator.clipboard.writeText(key).then(function() {
                    copyKeyBtn.textContent = 'Copied!';
                    if (typeof showToast === 'function') {
                        showToast({ type: 'success', title: 'Copied', message: 'API key copied to clipboard.' });
                    }
                    // Reset via the helper so the post-toast label respects
                    // the current auth state (matters if logout/key-rotate
                    // fires during the 2-second toast window).
                    setTimeout(function() { _relabelCopyApiKeyButton(copyKeyBtn); }, 2000);
                }).catch(function() {
                    if (typeof showToast === 'function') {
                        showToast({ type: 'error', title: 'Copy Failed', message: 'Check browser permissions.' });
                    }
                });
            } else {
                // No copyable key in memory — redirect to API Keys page
                // (no silent fail, no clipboard write of a sentinel string).
                if (typeof showToast === 'function') {
                    showToast({ type: 'info', title: 'Open API Keys to create a new key', message: 'Your existing key is not retrievable for security; create a new named key from API Keys.' });
                }
                window.location.href = 'api-keys.html';
            }
            menu.classList.remove('user-menu--open');
            trigger.setAttribute('aria-expanded', 'false');
        });
    }

    // Sign out
    var logoutBtn = document.getElementById('menu-logout');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', function() {
            if (typeof FinletAuth !== 'undefined') {
                FinletAuth.logout();
            } else {
                localStorage.removeItem('finlet_api_key');
                window.location.href = 'auth.html';
            }
        });
    }
}

/**
 * Set user menu display fields.
 * Populates both the desktop user menu AND the mobile nav drawer
 * user info elements so the drawer doesn't show stale "--" values.
 */
function _setUserMenuFields(initial, displayName, email, tierText) {
    // Desktop user menu elements
    var avatarEl = document.getElementById('user-avatar');
    var nameEl = document.getElementById('user-display-name');
    var emailEl = document.getElementById('user-menu-email');
    var tierEl = document.getElementById('user-menu-tier');
    if (avatarEl) avatarEl.textContent = initial;
    if (nameEl) nameEl.textContent = displayName;
    if (emailEl) emailEl.textContent = email;
    if (tierEl) tierEl.textContent = tierText;

    // Mobile nav drawer elements (BUG-11 fix)
    var drawerAvatarEl = document.getElementById('nav-drawer-avatar');
    var drawerEmailEl = document.getElementById('nav-drawer-user-email');
    var drawerTierEl = document.getElementById('nav-drawer-user-tier');
    if (drawerAvatarEl) drawerAvatarEl.textContent = initial;
    if (drawerEmailEl) drawerEmailEl.textContent = email;
    if (drawerTierEl) drawerTierEl.textContent = tierText;
}

/**
 * Relabel an API-key affordance button to match the click handler's
 * actual semantics for the current auth path. Idempotent — safe to
 * call on initial mount, on menu open, and on every `auth:state-change`
 * bus tick.
 *
 * The button is one affordance with two semantics:
 *   - "Copy API Key" → clipboard write (signup/just-rotated path,
 *     where FinletAuth.getApiKey() returns a non-null in-memory key).
 *   - "Manage API Key" → redirect to Settings → API Keys (cookie-
 *     session/login path, where the raw key is correctly never
 *     persisted client-side after the /auth/session handshake).
 *
 * The dual-label affordance is load-bearing — see
 * docs/decisions/copy-api-key-dead-affordance.md. DO NOT collapse to
 * a single label.
 *
 * @param {string|HTMLElement|null|undefined} buttonOrId
 *   - `undefined` / not provided → defaults to `#menu-copy-key`
 *     (preserves the legacy zero-arg call shape used by 8 existing
 *     unit tests).
 *   - string → treated as an element id, looked up via `getElementById`.
 *     Missing ids are silent no-ops.
 *   - HTMLElement (or any object with a writable `textContent`) → used
 *     directly. Lets call sites that already hold a button reference
 *     (e.g. the clipboard-success reset path on line ~343) avoid a
 *     redundant DOM lookup.
 */
function _relabelCopyApiKeyButton(buttonOrId) {
    var btn;
    if (buttonOrId == null) {
        btn = document.getElementById('menu-copy-key');
    } else if (typeof buttonOrId === 'string') {
        btn = document.getElementById(buttonOrId);
    } else {
        btn = buttonOrId;
    }
    if (!btn) return;
    var hasKey = (typeof FinletAuth !== 'undefined') && !!FinletAuth.getApiKey();
    btn.textContent = hasKey ? 'Copy API Key' : 'Manage API Key';
}

/**
 * Umbrella relabel — iterates every known API-key affordance id and
 * invokes the parameterized helper for each. Missing ids are silent
 * no-ops, so a page that doesn't include the mobile drawer button
 * (e.g. a future minimal layout) doesn't error.
 *
 * This is the single source of truth for "repaint every affordance to
 * match the current auth state". Called from:
 *   1. `_initSharedUserMenu()` mount (cold-paint after auth.js + DOM ready).
 *   2. `initMobileNav()` mount (mobile drawer relabel — defensive in case
 *      mobile-nav initializes after shared-nav under a future load order).
 *   3. The `auth:state-change` bus subscriber (see `_initSharedUserMenu`).
 */
function _relabelAllApiKeyAffordances() {
    for (var i = 0; i < API_KEY_AFFORDANCE_IDS.length; i++) {
        _relabelCopyApiKeyButton(API_KEY_AFFORDANCE_IDS[i]);
    }
}

/**
 * Fetch user profile from /auth/me and update the menu.
 */
async function _fetchSharedUserProfile() {
    try {
        var key = (typeof FinletAuth !== 'undefined') ? FinletAuth.getApiKey() : localStorage.getItem('finlet_api_key');
        if (!key) return;
        var res = await fetch(API_BASE + '/auth/me', {
            headers: { 'Authorization': 'Bearer ' + key },
        });
        if (!res.ok) return;
        var data = await res.json();

        var displayName = data.email || 'Account';
        var initial = (displayName.charAt(0) || '?').toUpperCase();
        _setUserMenuFields(initial, displayName, data.email || '--',
            (data.tier || 'free').charAt(0).toUpperCase() + (data.tier || 'free').slice(1) + ' tier');

        // Update stored user data
        if (typeof FinletAuth !== 'undefined') {
            var stored = FinletAuth.getUser() || {};
            FinletAuth.saveAuth(key, Object.assign({}, stored, data));
        }
    } catch (_e) {
        // /auth/me failed -- not critical, user menu shows cached data
    }
}

/**
 * Public helpers for sibling modules (mobile-nav.js consumes the
 * relabel helpers so the drawer's own click-handler reset path doesn't
 * carry a duplicate "Copy API Key" literal). Defensively created — if
 * `window.SharedNav` already exists (e.g. a future module adds entries
 * before this script loads), we extend it rather than clobber.
 */
if (typeof window !== 'undefined') {
    window.SharedNav = window.SharedNav || {};
    window.SharedNav._relabelCopyApiKeyButton = _relabelCopyApiKeyButton;
    window.SharedNav._relabelAllApiKeyAffordances = _relabelAllApiKeyAffordances;
}
