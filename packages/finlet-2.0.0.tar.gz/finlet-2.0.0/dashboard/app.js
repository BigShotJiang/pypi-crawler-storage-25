/* ============================================================
   Finlet Dashboard — Application Logic (v3)
   Error Handling, Loading States, Toast System, UX Polish
   WCAG AA Compliant
   ============================================================ */

// API_BASE is defined in api-utils.js (includes /v1/ prefix)
const HEALTH_CHECK_INTERVAL = 30000;
const STALE_DATA_THRESHOLD = 60000;
const SSE_MAX_RETRIES = 3;
let consecutiveErrors = 0;
let connectionStatus = 'connecting'; // 'connected' | 'connecting' | 'disconnected'
let lastSuccessfulConnection = null;
let lastDataUpdate = null;
let healthCheckTimer = null;
let staleCheckTimer = null;

// ---- State ----
let currentSessionId = null;
let currentSession = null;
// Two-way alias on window so external code (test harnesses, devtools,
// other module-scope scripts that don't share lexical scope) can read AND
// write the same object the module's `currentSession` binding points at.
// Reads via `window.currentSession.foo` and writes via
// `window.currentSession = obj` BOTH route through this descriptor.
Object.defineProperty(window, 'currentSession', {
    configurable: true,
    get() { return currentSession; },
    set(value) { currentSession = value; },
});
let sseSource = null;
let sseRetryCount = 0;
// Chart state (`equityChart`, `equitySeries`, `benchmarkSeries`,
// `equityYAxisAnchorSeries`, `_pendingEquityHistory`, `_pendingEquityOrders`)
// and `initChart()` were relocated to `dashboard/renderers.js` as part of the
// 2026-05-12 public-session-view refactor (Team B). They are declared as
// `var` there so they remain accessible from this file via the shared classic-
// script global scope.
let isTransitioning = false;

// ---- Init ----
document.addEventListener('DOMContentLoaded', async () => {
    // Auth guard fallback: redirect if not authenticated.
    // Primary guard is auth-guard.js (loaded before app.js). We await the
    // hydration barrier here so any POST triggered by the UI (e.g. create
    // session, clock controls) has a valid CSRF token ready.
    const authOk = await awaitAuthReady();
    if (!authOk) {
        if (typeof FinletAuth !== 'undefined' && !FinletAuth.isAuthenticated()) {
            window.location.replace('landing.html');
        }
        return;
    }

    initGlobalErrorBoundary();
    initChart();
    bindPanelToggles();
    initPanelCollapseState();
    initSharedNav({
        activePage: 'dashboard',
        showSessionSelector: true,
        showRefreshStatus: true,
        showConnectionIndicator: true,
        showSimTime: true,
    });
    initCreateSessionModal();
    bindEvents();
    fetchSessions().catch((err) => {
        console.warn('[Finlet] Failed to load sessions:', err);
    });
    startHealthCheck();
    startStaleDataCheck();
});

// ============================================================
//  Global Error Boundary
// ============================================================

function initGlobalErrorBoundary() {
    window.addEventListener('error', (event) => {
        console.error('[Finlet] Uncaught error:', event.error);
        showErrorBoundary(event.message || 'An unexpected error occurred');
    });

    window.addEventListener('unhandledrejection', (event) => {
        const reason = event.reason;
        const msg = reason?.message || '';

        // Suppress network/fetch errors (handled by dashFetch)
        if (reason instanceof TypeError && msg.includes('fetch')) {
            return;
        }
        // Suppress auth failures — the auth guard will redirect
        if (msg.includes('401') || msg.includes('403') || msg.includes('Unauthorized') || msg.includes('Forbidden')) {
            console.warn('[Finlet] Auth rejection suppressed:', msg);
            return;
        }
        // Suppress non-critical init errors (e.g., missing DOM elements on partial pages)
        if (msg.includes('null') || msg.includes('undefined') || msg.includes('Cannot read properties')) {
            console.warn('[Finlet] Non-critical rejection suppressed:', msg);
            return;
        }

        console.error('[Finlet] Unhandled promise rejection:', reason);
        showErrorBoundary(msg || 'An unexpected error occurred');
    });
}

// Track the element that triggered the error boundary so we can return focus
let errorBoundaryTriggerElement = null;

function showErrorBoundary(errorMessage) {
    let boundary = document.getElementById('error-boundary');
    if (!boundary) return;

    // Remember the currently focused element so we can return focus on close
    errorBoundaryTriggerElement = document.activeElement;

    const detailsEl = boundary.querySelector('.error-boundary__details-text');
    if (detailsEl) {
        detailsEl.textContent = errorMessage;
    }

    boundary.style.display = 'flex';

    // Set inert on background content to prevent screen reader access
    document.querySelectorAll('body > *:not(#error-boundary):not(script):not(link):not(style)').forEach(el => {
        el.setAttribute('inert', '');
    });

    // Focus the first focusable element inside the modal
    requestAnimationFrame(() => {
        const firstFocusable = getErrorBoundaryFocusableElements()[0];
        if (firstFocusable) firstFocusable.focus();
    });
}

function hideErrorBoundary() {
    const boundary = document.getElementById('error-boundary');
    if (boundary) boundary.style.display = 'none';

    // Remove inert from background content
    document.querySelectorAll('[inert]').forEach(el => {
        el.removeAttribute('inert');
    });

    // Return focus to the element that was focused before the modal opened
    if (errorBoundaryTriggerElement && typeof errorBoundaryTriggerElement.focus === 'function') {
        errorBoundaryTriggerElement.focus();
        errorBoundaryTriggerElement = null;
    }
}

function retryFromErrorBoundary() {
    hideErrorBoundary();
    // Re-initialize the dashboard
    fetchSessions();
    if (currentSessionId) {
        connectSSE(currentSessionId);
    }
}

/**
 * Get all focusable elements within the error boundary modal.
 */
function getErrorBoundaryFocusableElements() {
    const boundary = document.getElementById('error-boundary');
    if (!boundary) return [];
    return Array.from(boundary.querySelectorAll(
        'button:not([disabled]), [href], input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])'
    )).filter(el => el.offsetParent !== null);
}

/**
 * Focus trap handler for the error boundary modal.
 * Tab/Shift+Tab cycles through focusable elements inside the modal.
 * Escape closes the modal.
 */
function handleErrorBoundaryKeydown(e) {
    const boundary = document.getElementById('error-boundary');
    if (!boundary || boundary.style.display !== 'flex') return;

    if (e.key === 'Escape') {
        e.preventDefault();
        retryFromErrorBoundary();
        return;
    }

    if (e.key === 'Tab') {
        const focusable = getErrorBoundaryFocusableElements();
        if (focusable.length === 0) return;

        const first = focusable[0];
        const last = focusable[focusable.length - 1];

        if (e.shiftKey) {
            // Shift+Tab: if on first element, wrap to last
            if (document.activeElement === first) {
                e.preventDefault();
                last.focus();
            }
        } else {
            // Tab: if on last element, wrap to first
            if (document.activeElement === last) {
                e.preventDefault();
                first.focus();
            }
        }
    }
}

// ============================================================
//  Dashboard API Wrappers
//  Wrap the canonical apiFetch / apiPost from api-utils.js with
//  connection-status tracking and structured {ok, data} responses.
//  The raw helpers (return data | null) remain available for other pages.
// ============================================================

/**
 * Dashboard GET — delegates to the canonical apiFetch (api-utils.js),
 * then wraps the result in { ok, data } and feeds errors through
 * handleHttpError for toast / redirect behaviour.
 */
async function dashFetch(path) {
    try {
        const res = await fetch(`${API_BASE}${path}`, { headers: getAuthHeaders() });

        if (!res.ok) {
            return await handleHttpError(res, path);
        }

        updateConnectionStatus('connected');
        lastSuccessfulConnection = Date.now();
        const data = await res.json();
        return { ok: true, data };
    } catch (err) {
        console.error(`[Finlet] Network error on GET ${path}:`, err);
        updateConnectionStatus('disconnected');
        return {
            ok: false,
            status: 0,
            message: 'Unable to reach server',
            detail: err.message || 'Network error or server unreachable',
        };
    }
}

/**
 * Dashboard POST — delegates to the canonical apiPost (api-utils.js),
 * then wraps the result in { ok, data } and feeds errors through
 * handleHttpError for toast / redirect behaviour.
 */
async function dashPost(path, body = null) {
    try {
        const opts = { method: 'POST', headers: getAuthHeaders('POST') };
        if (body) opts.body = JSON.stringify(body);
        // authFetch auto-retries once on 401/403 csrf_token_missing,
        // invalidating stale hydration before the second attempt.
        const res = await authFetch(path, opts);

        if (!res.ok) {
            return await handleHttpError(res, path);
        }

        updateConnectionStatus('connected');
        lastSuccessfulConnection = Date.now();
        const data = await res.json();
        return { ok: true, data };
    } catch (err) {
        console.error(`[Finlet] Network error on POST ${path}:`, err);
        updateConnectionStatus('disconnected');
        return {
            ok: false,
            status: 0,
            message: 'Unable to reach server',
            detail: err.message || 'Network error or server unreachable',
        };
    }
}

/**
 * Handle HTTP error responses with user-friendly messages.
 */
async function handleHttpError(res, path) {
    let detail = '';
    try {
        const body = await res.json();
        detail = body.detail || body.message || body.error || JSON.stringify(body);
    } catch {
        try { detail = await res.text(); } catch { /* empty */ }
    }

    const result = { ok: false, status: res.status, detail };

    if (res.status === 401 || res.status === 403) {
        result.message = 'Session expired or invalid API key';
        showToast({ type: 'error', title: 'Authentication Failed', message: 'Redirecting to login...', duration: 2000 });
        console.warn(`[Finlet] Auth error on ${path}: ${res.status}`, detail);
        // Redirect to login after brief delay
        setTimeout(() => {
            if (typeof FinletAuth !== 'undefined') { FinletAuth.logout(); }
            else { window.location.replace('auth.html'); }
        }, 1500);
    } else if (res.status === 429) {
        const retryAfter = res.headers.get('Retry-After');
        const retryMsg = retryAfter ? ` Try again in ${retryAfter}s.` : ' Please slow down.';
        result.message = `Rate limited.${retryMsg}`;
        showToast({ type: 'warning', title: 'Rate Limited', message: result.message, duration: 8000 });
        console.warn(`[Finlet] Rate limited on ${path}. Retry-After: ${retryAfter}`);
    } else if (res.status === 404) {
        result.message = 'Resource not found';
        console.warn(`[Finlet] 404 on ${path}:`, detail);
    } else if (res.status === 422) {
        result.message = 'Invalid request data';
        showToast({ type: 'error', title: 'Invalid Request', message: detail || 'The server could not process the request.' });
        console.warn(`[Finlet] Validation error on ${path}:`, detail);
    } else if (res.status >= 500) {
        result.message = 'Server error — the team has been notified';
        showToast({ type: 'error', title: 'Server Error', message: `Something went wrong (${res.status}). Please try again.`, persistent: true });
        console.error(`[Finlet] Server error on ${path}: ${res.status}`, detail);
    } else {
        result.message = `Request failed (${res.status})`;
        showToast({ type: 'error', title: 'Request Failed', message: detail || `Unexpected error (${res.status})` });
        console.warn(`[Finlet] HTTP ${res.status} on ${path}:`, detail);
    }

    return result;
}

// User menu & auth are now handled by shared-nav.js (initSharedNav)

// ---- Panel Collapse ----
function initPanelCollapseState() {
    document.querySelectorAll('.panel-toggle').forEach(btn => {
        const panelId = btn.dataset.panel;
        const collapsed = localStorage.getItem(`finlet-panel-${panelId}`) === 'collapsed';
        // Clear any Unicode text content -- CSS ::after handles the triangle
        btn.textContent = '';
        if (collapsed) {
            const panel = document.getElementById(panelId);
            if (panel) panel.classList.add('panel--collapsed');
            btn.setAttribute('aria-expanded', 'false');
            updatePanelToggleLabel(btn, panelId, true);
        } else {
            updatePanelToggleLabel(btn, panelId, false);
        }
    });
}

/**
 * Update the aria-label on a panel toggle button based on collapsed state.
 * Uses the panel's title text if available for a descriptive label.
 */
function updatePanelToggleLabel(btn, panelId, isCollapsed) {
    const panel = document.getElementById(panelId);
    const titleEl = panel ? panel.querySelector('.panel-title') : null;
    const panelName = titleEl ? titleEl.textContent : panelId;
    btn.setAttribute('aria-label', (isCollapsed ? 'Expand ' : 'Collapse ') + panelName + ' panel');
}

function bindPanelToggles() {
    document.addEventListener('click', (e) => {
        const btn = e.target.closest('.panel-toggle');
        if (!btn) return;
        const panelId = btn.dataset.panel;
        const panel = document.getElementById(panelId);
        if (!panel) return;

        const isCollapsed = panel.classList.toggle('panel--collapsed');
        btn.textContent = ''; // CSS ::after handles the triangle indicator
        btn.setAttribute('aria-expanded', String(!isCollapsed));
        updatePanelToggleLabel(btn, panelId, isCollapsed);
        localStorage.setItem(`finlet-panel-${panelId}`, isCollapsed ? 'collapsed' : 'expanded');
    });
}

// ---- Event Bindings ----
function bindEvents() {
    // Event delegation for toggle elements (replaces inline onclick)
    document.addEventListener('click', (e) => {
        const toggle = e.target.closest('[data-toggle-target]');
        if (toggle) {
            const targetId = toggle.dataset.toggleTarget;
            const target = document.getElementById(targetId);
            if (target) {
                const expanded = target.classList.toggle('expanded');
                toggle.setAttribute('aria-expanded', expanded);
                toggle.textContent = expanded ? 'hide' : (toggle.classList.contains('reasoning-toggle') ? 'show' : 'details');
            }
        }
    });

    // Allow keyboard activation (Enter/Space) on toggle elements
    document.addEventListener('keydown', (e) => {
        if ((e.code === 'Enter' || e.code === 'Space') && e.target.matches('[data-toggle-target]')) {
            e.preventDefault();
            e.target.click();
        }
    });

    document.getElementById('session-select').addEventListener('change', (e) => {
        selectSession(e.target.value);
    });

    document.getElementById('btn-freeze').addEventListener('click', async () => {
        if (!currentSessionId) return;
        const btn = document.getElementById('btn-freeze');
        btn.classList.add('btn--loading');
        await dashPost(`/sessions/${currentSessionId}/clock/freeze`);
        btn.classList.remove('btn--loading');
    });

    document.getElementById('btn-step').addEventListener('click', async () => {
        if (!currentSessionId) return;
        const btn = document.getElementById('btn-step');
        btn.classList.add('btn--loading');
        const interval = document.getElementById('step-interval').value;
        await dashPost(`/sessions/${currentSessionId}/clock/step`, { interval });
        btn.classList.remove('btn--loading');
    });

    document.getElementById('btn-play').addEventListener('click', async () => {
        if (!currentSessionId) return;
        const btn = document.getElementById('btn-play');
        btn.classList.add('btn--loading');
        const speed = parseFloat(document.getElementById('play-speed').value);
        await dashPost(`/sessions/${currentSessionId}/clock/play`, { speed });
        btn.classList.remove('btn--loading');
    });

    document.getElementById('btn-stop').addEventListener('click', async () => {
        if (!currentSessionId) return;
        const btn = document.getElementById('btn-stop');
        btn.classList.add('btn--loading');
        await dashPost(`/sessions/${currentSessionId}/clock/stop`);
        btn.classList.remove('btn--loading');
    });

    // Manual refresh button — reconnects SSE to force fresh data
    const refreshBtn = document.getElementById('btn-refresh');
    if (refreshBtn) {
        refreshBtn.addEventListener('click', () => {
            if (currentSessionId) {
                refreshBtn.classList.add('btn--loading');
                connectSSE(currentSessionId);
                // Remove loading state after a short delay (SSE will push fresh data)
                setTimeout(() => refreshBtn.classList.remove('btn--loading'), 500);
            } else {
                fetchSessions();
            }
        });
    }

    // Connection indicator click/keyboard to retry
    const connIndicator = document.getElementById('connection-indicator');
    if (connIndicator) {
        connIndicator.style.cursor = 'pointer';
        const retryConnection = () => {
            updateConnectionStatus('connecting');
            checkHealth();
        };
        connIndicator.addEventListener('click', retryConnection);
        connIndicator.addEventListener('keydown', (e) => {
            if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                retryConnection();
            }
        });
    }

    // Error boundary retry
    const retryBtn = document.getElementById('error-boundary-retry');
    if (retryBtn) {
        retryBtn.addEventListener('click', retryFromErrorBoundary);
    }

    // Error boundary reload (replaces inline onclick)
    const reloadBtn = document.getElementById('error-boundary-reload');
    if (reloadBtn) {
        reloadBtn.addEventListener('click', () => location.reload());
    }

    // Error boundary details toggle
    const detailsToggle = document.getElementById('error-boundary-details-toggle');
    if (detailsToggle) {
        detailsToggle.addEventListener('click', () => {
            const details = document.getElementById('error-boundary-details');
            if (details) {
                const expanded = details.classList.toggle('expanded');
                detailsToggle.textContent = expanded ? 'Hide details' : 'Show details';
                detailsToggle.setAttribute('aria-expanded', String(expanded));
            }
        });
    }

    // Error boundary focus trap — Tab/Shift+Tab cycle, Escape to close
    document.addEventListener('keydown', handleErrorBoundaryKeydown);

    // Keyboard shortcuts
    document.addEventListener('keydown', (e) => {
        // Don't trigger shortcuts when typing in inputs/selects
        if (e.target.tagName === 'INPUT' || e.target.tagName === 'SELECT' || e.target.tagName === 'TEXTAREA') return;

        // Don't trigger shortcuts when the error boundary modal is open
        const errBoundary = document.getElementById('error-boundary');
        if (errBoundary && errBoundary.style.display === 'flex') return;

        if (e.code === 'Space') {
            e.preventDefault();
            if (!currentSessionId) return;
            const mode = document.getElementById('clock-mode').textContent.toLowerCase();
            if (mode === 'frozen' || mode === 'stepping') {
                const speed = parseFloat(document.getElementById('play-speed').value);
                dashPost(`/sessions/${currentSessionId}/clock/play`, { speed });
            } else {
                dashPost(`/sessions/${currentSessionId}/clock/freeze`);
            }
        } else if (e.code === 'ArrowRight') {
            e.preventDefault();
            if (!currentSessionId) return;
            const interval = document.getElementById('step-interval').value;
            dashPost(`/sessions/${currentSessionId}/clock/step`, { interval });
        } else if (e.code === 'Escape') {
            if (!currentSessionId) return;
            dashPost(`/sessions/${currentSessionId}/clock/stop`);
        }
    });
}

// ============================================================
//  Health Check & Connection Monitoring
// ============================================================

function startHealthCheck() {
    stopHealthCheck();
    scheduleHealthCheck();
}

function scheduleHealthCheck() {
    healthCheckTimer = setTimeout(async () => {
        await checkHealth();
        scheduleHealthCheck();
    }, HEALTH_CHECK_INTERVAL);
}

function stopHealthCheck() {
    if (healthCheckTimer) {
        clearTimeout(healthCheckTimer);
        healthCheckTimer = null;
    }
}

async function checkHealth() {
    try {
        const res = await fetch(`${API_BASE}/health`, {
            signal: AbortSignal.timeout(5000),
        });
        if (res.ok) {
            updateConnectionStatus('connected');
            lastSuccessfulConnection = Date.now();
        } else {
            updateConnectionStatus('disconnected');
        }
    } catch {
        updateConnectionStatus('disconnected');
    }
}

// ============================================================
//  Stale Data Warning
// ============================================================

function startStaleDataCheck() {
    if (staleCheckTimer) clearTimeout(staleCheckTimer);
    scheduleStaleDataCheck();
}

function scheduleStaleDataCheck() {
    staleCheckTimer = setTimeout(() => {
        updateLastUpdatedDisplay();
        scheduleStaleDataCheck();
    }, 5000);
}

function updateLastUpdatedDisplay() {
    const el = document.getElementById('last-updated');
    if (!el) return;

    if (!lastDataUpdate) {
        el.textContent = '';
        el.classList.remove('stale-warning');
        return;
    }

    const elapsed = Date.now() - lastDataUpdate;
    const seconds = Math.floor(elapsed / 1000);

    if (seconds < 5) {
        el.textContent = 'Updated just now';
    } else if (seconds < 60) {
        el.textContent = `Updated ${seconds}s ago`;
    } else {
        const minutes = Math.floor(seconds / 60);
        el.textContent = `Updated ${minutes}m ago`;
    }

    if (elapsed > STALE_DATA_THRESHOLD && currentSessionId) {
        el.classList.add('stale-warning');
    } else {
        el.classList.remove('stale-warning');
    }
}

// ============================================================
//  Loading State Manager
// ============================================================

function showLoading(elementId) {
    const el = document.getElementById(elementId);
    if (!el) return;
    // Don't replace content if already showing skeleton
    if (el.querySelector('.skeleton-container')) return;
    el.dataset.prevHtml = el.innerHTML;
    el.innerHTML = trustedHTML(getSkeletonFor(elementId));
}

function hideLoading(elementId) {
    const el = document.getElementById(elementId);
    if (!el) return;
    // Skeleton is removed when real content is rendered
    const skeleton = el.querySelector('.skeleton-container');
    if (skeleton) skeleton.remove();
}

function showEmptyState(elementId, message, opts) {
    const el = document.getElementById(elementId);
    if (!el) return;
    const headline = (opts && opts.headline) ? `<p class="empty-state__headline">${esc(opts.headline)}</p>` : '';
    const icon = (opts && opts.icon) ? `<div class="empty-state__icon">${opts.icon}</div>` : `<div class="empty-state__icon">
            <svg width="40" height="40" viewBox="0 0 40 40" fill="none" aria-hidden="true"><circle cx="20" cy="20" r="18" stroke="var(--text-muted)" stroke-width="1.5" stroke-dasharray="4 3"/><path d="M14 20h12M20 14v12" stroke="var(--text-muted)" stroke-width="1.5" stroke-linecap="round"/></svg>
        </div>`;
    const cta = (opts && opts.cta) ? opts.cta : '';
    el.innerHTML = trustedHTML(`<div class="empty-state">
        ${icon}
        ${headline}
        <div class="empty-state__text">${esc(message)}</div>
        ${cta}
    </div>`);
}

function showErrorState(elementId, message, retryFn) {
    const el = document.getElementById(elementId);
    if (!el) return;
    const retryId = `retry-${elementId}-${Date.now()}`;
    el.innerHTML = trustedHTML(`<div class="error-state">
        <div class="error-state__icon">
            <svg width="32" height="32" viewBox="0 0 32 32" fill="none"><circle cx="16" cy="16" r="14" stroke="var(--red)" stroke-width="1.5"/><path d="M16 10v8M16 22v0" stroke="var(--red)" stroke-width="2" stroke-linecap="round"/></svg>
        </div>
        <div class="error-state__text">${esc(message)}</div>
        ${retryFn ? `<button class="btn error-state__retry" id="${retryId}">Retry</button>` : ''}
    </div>`);
    if (retryFn) {
        const retryBtn = document.getElementById(retryId);
        if (retryBtn) retryBtn.addEventListener('click', retryFn);
    }
}

function getSkeletonFor(elementId) {
    switch (elementId) {
        case 'overview-grid':
            return `<div class="skeleton-container"><div class="overview-grid">${
                Array(8).fill('<div class="stat-card"><div class="skeleton skeleton--label"></div><div class="skeleton skeleton--value"></div></div>').join('')
            }</div></div>`;
        case 'positions-body':
            return `<tr class="skeleton-container"><td colspan="6"><div class="skeleton-rows">${
                Array(3).fill('<div class="skeleton skeleton--row"></div>').join('')
            }</div></td></tr>`;
        case 'orders-body':
            return `<tr class="skeleton-container"><td colspan="8"><div class="skeleton-rows">${
                Array(4).fill('<div class="skeleton skeleton--row"></div>').join('')
            }</div></td></tr>`;
        case 'equity-chart':
            return `<div class="skeleton-container skeleton--chart"></div>`;
        case 'trace-feed':
            return `<div class="skeleton-container">${
                Array(4).fill('<div class="skeleton-trace"><div class="skeleton skeleton--circle"></div><div class="skeleton-trace-lines"><div class="skeleton skeleton--line-short"></div><div class="skeleton skeleton--line-long"></div></div></div>').join('')
            }</div>`;
        case 'plugin-cards':
            return `<div class="skeleton-container">${
                Array(2).fill('<div class="skeleton skeleton--plugin-card"></div>').join('')
            }</div>`;
        default:
            return '<div class="skeleton-container"><div class="skeleton skeleton--block"></div></div>';
    }
}

// ============================================================
//  Sessions
// ============================================================

async function fetchSessions() {
    const result = await dashFetch('/sessions');
    if (!result.ok) {
        // Distinguish server-unreachable (no status) from auth/permission failures
        // (status present, e.g. 401/403/500). For auth/permission failures the
        // server IS reachable — fall through to the empty-sessions state so the
        // user sees the "create your first session" CTA rather than a misleading
        // "server isn't running" message.
        if (!result.status) {
            showFirstRunBanner({ serverDown: true });
        } else {
            showFirstRunBanner({ serverDown: false });
        }
        // Show per-widget error if it was a server error (not just unreachable)
        if (result.status && typeof showWidgetError === 'function') {
            showWidgetError('positions-body', 'Failed to load sessions.', () => fetchSessions());
            showWidgetError('orders-body', 'Failed to load sessions.', () => fetchSessions());
        }
        return;
    }

    const sessions = Array.isArray(result.data) ? result.data : (result.data.sessions || []);

    // Show first-run CTA when API is reachable but no sessions exist
    if (sessions.length === 0) {
        showFirstRunBanner({ serverDown: false });
    } else {
        hideFirstRunBanner();
    }

    const select = document.getElementById('session-select');
    const current = select.value;

    // Keep first default option, remove the rest
    while (select.options.length > 1) select.remove(1);

    sessions.forEach((s) => {
        const opt = document.createElement('option');
        opt.value = s.id;
        const clockTime = s.clock?.current_time || s.sim_time || '';
        const simTime = clockTime ? ` | ${formatDateShort(clockTime)}` : '';
        const name = s.name || s.config?.name || s.id;
        opt.textContent = `${name} (${s.status}${simTime})`;
        select.appendChild(opt);
    });

    // Restore selection
    if (current) select.value = current;

    // Auto-select first session on initial load when none is selected
    if (!currentSessionId && sessions.length > 0) {
        const firstId = sessions[0].id;
        select.value = firstId;
        selectSession(firstId);
    }
}

function selectSession(id) {
    const previousSession = currentSessionId;
    currentSessionId = id || null;
    disconnectSSE();
    stopFallbackPolling();

    if (currentSessionId) {
        // Show loading skeletons during transition
        if (previousSession !== currentSessionId) {
            isTransitioning = true;
            showSessionLoadingState();
        }

        connectSSE(currentSessionId);
        // Enable clock controls
        ['btn-freeze', 'btn-step', 'btn-play', 'btn-stop'].forEach(btnId => {
            const btn = document.getElementById(btnId);
            btn.disabled = false;
            btn.classList.remove('btn--disabled');
        });

        // Publish session:switched on the bus from the canonical "session
        // is now active" moment. This fires for ALL paths that activate a
        // session — dropdown change, auto-select on first load, post-
        // create selection, and refresh-after-API/CLI-create.
        // See dashboard/event-contract.md.
        try {
            if (window.finletBus && typeof window.finletBus.publish === 'function') {
                window.finletBus.publish('session:switched', { session_id: currentSessionId });
            }
        } catch (busErr) {
            console.error('[Finlet] session:switched publish error:', busErr);
        }
    } else {
        clearDashboard();
    }
}

function showSessionLoadingState() {
    // Show skeleton pulse on all stat values
    document.querySelectorAll('.stat-value').forEach(el => {
        el.textContent = '';
        el.classList.add('skeleton', 'skeleton--value-inline');
    });
    document.querySelectorAll('.stat-sub').forEach(el => {
        el.textContent = '';
    });
    // Show skeletons in data areas
    showLoading('positions-body');
    showLoading('orders-body');
    showLoading('trace-feed');
    showLoading('plugin-cards');
}

// ---- First Run Banner ----
// Two variants: "empty-sessions" (server reachable, zero sessions) and
// "server-down" (server unreachable). The banner template in index.html
// carries both copy variants gated by data-variant; this function flips
// the active one. Default is empty-sessions because the most common
// reason this banner shows is a fresh logged-in user with no sessions.
function showFirstRunBanner({ serverDown = false } = {}) {
    const banner = document.getElementById('first-run-banner');
    if (!banner) return;
    const state = serverDown ? 'server-down' : 'empty-sessions';
    banner.dataset.state = state;
    banner.querySelectorAll('[data-variant]').forEach((el) => {
        el.style.display = el.dataset.variant === state ? '' : 'none';
    });
    banner.style.display = 'block';
}

function hideFirstRunBanner() {
    const banner = document.getElementById('first-run-banner');
    if (banner) banner.style.display = 'none';
}

// ============================================================
//  Session Creation Modal
// ============================================================

const SESSION_TEMPLATES = {
    conservative: { name: 'Conservative ETF', tickers: ['SPY', 'BND', 'GLD'] },
    tech: { name: 'Tech Growth', tickers: ['AAPL', 'GOOGL', 'MSFT', 'NVDA', 'META'] },
    custom: { name: 'Custom', tickers: [] },
};

let selectedTemplate = 'conservative';

function initCreateSessionModal() {
    const modal = document.getElementById('create-session-modal');
    if (!modal) return;

    // Set default start date to 1 year ago
    const startDateInput = document.getElementById('session-start-date');
    if (startDateInput) {
        const oneYearAgo = new Date();
        oneYearAgo.setFullYear(oneYearAgo.getFullYear() - 1);
        startDateInput.value = oneYearAgo.toISOString().split('T')[0];
    }

    // "New" button in header
    const btnNew = document.getElementById('btn-new-session');
    if (btnNew) btnNew.addEventListener('click', () => openCreateSessionModal());

    // "Create Your First Session" CTA button
    const btnFirst = document.getElementById('btn-create-first-session');
    if (btnFirst) btnFirst.addEventListener('click', () => openCreateSessionModal());

    // Cancel button
    const btnCancel = document.getElementById('create-session-cancel');
    if (btnCancel) btnCancel.addEventListener('click', () => closeCreateSessionModal());

    // Click overlay to close
    modal.addEventListener('click', (e) => {
        if (e.target === modal) closeCreateSessionModal();
    });

    // Escape to close
    modal.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') closeCreateSessionModal();
    });

    // Template selection
    modal.querySelectorAll('.template-card').forEach(card => {
        card.addEventListener('click', () => {
            selectTemplate(card.dataset.template);
        });
    });

    // Form submission
    const form = document.getElementById('create-session-form');
    if (form) form.addEventListener('submit', handleCreateSession);
}

function selectTemplate(templateKey, opts = { seedName: true }) {
    selectedTemplate = templateKey;
    const modal = document.getElementById('create-session-modal');
    if (!modal) return;

    // Update selected state
    modal.querySelectorAll('.template-card').forEach(card => {
        card.classList.toggle('template-card--selected', card.dataset.template === templateKey);
    });

    // Show/hide custom universe input
    const customGroup = document.getElementById('custom-universe-group');
    if (customGroup) {
        customGroup.style.display = templateKey === 'custom' ? 'block' : 'none';
    }

    // Sync name field with the selected template. The default template
    // selection at modal-open time (seedName=false) leaves the name EMPTY
    // so the placeholder ("e.g. My First Simulation") prompts the user to
    // pick a meaningful name — preventing two consecutive opens from
    // defaulting to the same "Conservative ETF" string and producing
    // duplicate session names. User-driven template clicks (default
    // seedName=true) seed the field with the template name (or clear for
    // Custom), so switching templates after opening still follows the
    // template choice.
    const nameInput = document.getElementById('session-name');
    if (nameInput && opts.seedName) {
        nameInput.value = templateKey === 'custom'
            ? ''
            : SESSION_TEMPLATES[templateKey]?.name || '';
    }
}

function openCreateSessionModal() {
    const modal = document.getElementById('create-session-modal');
    if (!modal) return;

    // Reset form
    const form = document.getElementById('create-session-form');
    if (form) form.reset();

    // Reset template to conservative — but leave the name field EMPTY so
    // the placeholder prompts the user to choose a name, instead of
    // pre-filling "Conservative ETF" and producing duplicate session names
    // on consecutive opens.
    selectTemplate('conservative', { seedName: false });

    // Reset default values
    const capitalInput = document.getElementById('session-capital');
    if (capitalInput) capitalInput.value = '100000';

    const startDateInput = document.getElementById('session-start-date');
    if (startDateInput) {
        const oneYearAgo = new Date();
        oneYearAgo.setFullYear(oneYearAgo.getFullYear() - 1);
        startDateInput.value = oneYearAgo.toISOString().split('T')[0];
    }

    // Clear errors
    clearFormErrors();

    // Modal stack ownership lives in dashboard/modal-controller.js. The
    // controller flips display/visibility/pointer-events and the
    // .fl-modal--visible class drives the CSS transition. Consumer keeps
    // focus management because that's a UX concern, not a stack concern.
    window.finletModal.open('create-session');

    // Focus the name input
    const nameInput = document.getElementById('session-name');
    if (nameInput) setTimeout(() => nameInput.focus(), 100);
}

// Expose to window so external callers can delegate to the canonical
// Create Session modal. Avoids drifting between session-creation surfaces
// with mismatched fields and validators.
window.openCreateSessionModal = openCreateSessionModal;

function closeCreateSessionModal() {
    // Modal stack ownership lives in dashboard/modal-controller.js. The
    // controller removes .fl-modal--visible (CSS transition still runs)
    // and re-applies inline display:none. Consumer just owns focus.
    window.finletModal.close('create-session');

    // Return focus to the trigger button
    const btnNew = document.getElementById('btn-new-session');
    if (btnNew) btnNew.focus();
}

function clearFormErrors() {
    document.querySelectorAll('.form-error').forEach(el => { el.textContent = ''; });
    document.querySelectorAll('.form-input--error').forEach(el => { el.classList.remove('form-input--error'); });
}

function setFormError(fieldId, message) {
    const errorEl = document.getElementById(fieldId + '-error');
    const inputEl = document.getElementById(fieldId);
    if (errorEl) errorEl.textContent = message;
    if (inputEl) inputEl.classList.add('form-input--error');
}

function validateCreateSessionForm() {
    clearFormErrors();
    let valid = true;

    const name = document.getElementById('session-name').value.trim();
    if (!name) {
        setFormError('session-name', 'Session name is required');
        valid = false;
    } else if (name.length > 100) {
        setFormError('session-name', 'Name must be 100 characters or fewer');
        valid = false;
    }

    const capital = parseFloat(document.getElementById('session-capital').value);
    if (isNaN(capital) || capital <= 0) {
        setFormError('session-capital', 'Capital must be a positive number');
        valid = false;
    }

    if (selectedTemplate === 'custom') {
        const universeRaw = document.getElementById('session-universe').value.trim();
        if (!universeRaw) {
            setFormError('session-universe', 'Enter at least one ticker symbol');
            valid = false;
        } else {
            const tickers = universeRaw.split(',').map(t => t.trim().toUpperCase()).filter(Boolean);
            if (tickers.length === 0) {
                setFormError('session-universe', 'Enter at least one valid ticker symbol');
                valid = false;
            } else if (tickers.some(t => t.length > 10)) {
                setFormError('session-universe', 'Each ticker must be 10 characters or fewer');
                valid = false;
            }
        }
    }

    return valid;
}

async function handleCreateSession(e) {
    e.preventDefault();

    if (!validateCreateSessionForm()) return;

    const submitBtn = document.getElementById('create-session-submit');
    const btnText = submitBtn.querySelector('.btn-modal-text');
    const btnSpinner = submitBtn.querySelector('.btn-modal-spinner');
    const cancelBtn = document.getElementById('create-session-cancel');
    const inlineStatus = document.getElementById('create-session-status');

    // Show loading state. The POST /v1/sessions call can take ~25-30s
    // under load (cold-start + first-session bootstrap). Without visible
    // feedback the user stares at a motionless modal — so we show an
    // inline status row in the footer with a spinner + descriptive text
    // in addition to the small button spinner. Cancel is disabled to
    // prevent mid-flight close (which would leave server-side state
    // partially created with no client knowledge).
    submitBtn.disabled = true;
    btnText.textContent = 'Creating...';
    btnSpinner.style.display = 'inline-block';
    if (cancelBtn) cancelBtn.disabled = true;
    if (inlineStatus) inlineStatus.style.display = 'inline-flex';

    try {
        const name = document.getElementById('session-name').value.trim();
        const capital = parseFloat(document.getElementById('session-capital').value);
        const startDate = document.getElementById('session-start-date').value;

        let universe;
        if (selectedTemplate === 'custom') {
            universe = document.getElementById('session-universe').value
                .split(',').map(t => t.trim().toUpperCase()).filter(Boolean);
        } else {
            universe = SESSION_TEMPLATES[selectedTemplate].tickers;
        }

        // Build start_time as UTC ISO string
        const startTime = startDate
            ? new Date(startDate + 'T00:00:00Z').toISOString()
            : new Date(Date.now() - 365 * 24 * 60 * 60 * 1000).toISOString();

        const body = {
            name: name,
            start_time: startTime,
            initial_capital: capital,
            universe: universe,
        };

        const result = await dashPost('/sessions', body);

        if (result.ok) {
            showToast({ type: 'success', title: 'Session Created', message: `"${name}" is ready to go.`, duration: 4000 });
            closeCreateSessionModal();

            // Refresh session list and select the new session.
            // selectSession() publishes session:switched on the bus, which
            // covers UI-create, REST-create, and CLI-create flows uniformly.
            await fetchSessions();
            const newId = result.data?.id;
            if (newId) {
                const select = document.getElementById('session-select');
                if (select) {
                    select.value = newId;
                    selectSession(newId);
                }
            }
        }
        // dashPost already shows error toasts via handleHttpError
    } catch (err) {
        console.error('[Finlet] Failed to create session:', err);
        showToast({ type: 'error', title: 'Creation Failed', message: 'An unexpected error occurred. Please try again.' });
    } finally {
        // Reset button state + hide inline status
        submitBtn.disabled = false;
        btnText.textContent = 'Create Session';
        btnSpinner.style.display = 'none';
        if (cancelBtn) cancelBtn.disabled = false;
        if (inlineStatus) inlineStatus.style.display = 'none';
    }
}

// ============================================================
//  SSE (Server-Sent Events) Connection
// ============================================================

/**
 * Connect to the SSE stream for a session. Replaces the old polling loop.
 * EventSource handles automatic reconnection. After SSE_MAX_RETRIES
 * consecutive failures, falls back to REST polling as a defensive measure.
 */
function connectSSE(sessionId) {
    disconnectSSE();
    if (!sessionId) return;

    sseRetryCount = 0;
    updateConnectionStatus('connecting');

    // EventSource does not support custom headers, but cookie auth
    // is sent automatically. withCredentials ensures cookies are included.
    const url = `${API_BASE}/sessions/${sessionId}/stream`;
    sseSource = new EventSource(url, { withCredentials: true });

    // -- Session event --
    sseSource.addEventListener('session', (e) => {
        if (currentSessionId !== sessionId) return;
        try {
            const data = JSON.parse(e.data);
            currentSession = data;
            renderSession(data);
        } catch (err) {
            console.error('[Finlet] SSE session parse error:', err);
        }
    });

    // -- Clock event --
    sseSource.addEventListener('clock', (e) => {
        if (currentSessionId !== sessionId) return;
        try {
            const data = JSON.parse(e.data);
            renderClock(data);
        } catch (err) {
            console.error('[Finlet] SSE clock parse error:', err);
        }
    });

    // -- Portfolio event --
    sseSource.addEventListener('portfolio', (e) => {
        if (currentSessionId !== sessionId) return;
        try {
            const data = JSON.parse(e.data);
            renderPortfolio(data);
            // Mirror cash + selected metrics onto currentSession.portfolio_metrics
            // so synchronous read-side consumers see the post-fill value
            // without waiting for the next `session` SSE event. We only
            // mutate; we do not replace currentSession (other fields like
            // config/clock are owned by the `session` event handler).
            if (currentSession && data && typeof data === 'object') {
                if (!currentSession.portfolio_metrics || typeof currentSession.portfolio_metrics !== 'object') {
                    currentSession.portfolio_metrics = {};
                }
                if (typeof data.cash === 'number' && !Number.isNaN(data.cash)) {
                    currentSession.portfolio_metrics.cash = data.cash;
                }
                if (typeof data.total_value === 'number' && !Number.isNaN(data.total_value)) {
                    currentSession.portfolio_metrics.total_value = data.total_value;
                }
            }
            // Broadcast for read-only components that mirror portfolio
            // state (e.g. dashboard tiles re-render via renderPortfolio
            // above; this publish is for any future read-only dialog
            // mirror consumers). See dashboard/event-contract.md.
            try {
                window.finletBus.publish('portfolio:updated', data);
            } catch (busErr) {
                console.error('[Finlet] portfolio:updated publish error:', busErr);
            }
        } catch (err) {
            console.error('[Finlet] SSE portfolio parse error:', err);
        }
    });

    // -- History event --
    sseSource.addEventListener('history', (e) => {
        if (currentSessionId !== sessionId) return;
        try {
            const data = JSON.parse(e.data);
            // Store latest orders for equity curve overlay
            renderEquityCurve(data, window._latestOrdersData || null);
        } catch (err) {
            console.error('[Finlet] SSE history parse error:', err);
        }
    });

    // -- Orders event --
    sseSource.addEventListener('orders', (e) => {
        if (currentSessionId !== sessionId) return;
        try {
            const data = JSON.parse(e.data);
            window._latestOrdersData = data;
            renderOrders(data);

            // Toast for newly filled orders
            const orderList = Array.isArray(data) ? data : (data.orders || []);
            const filledCount = orderList.filter(o => (o.status || '').toUpperCase() === 'FILLED').length;
            if (filledCount > 0 && window._lastFilledCount !== undefined && filledCount > window._lastFilledCount) {
                const newFills = filledCount - window._lastFilledCount;
                showToast({ type: 'success', title: 'Order Filled', message: `${newFills} new order${newFills > 1 ? 's' : ''} filled.` });
            }

            window._lastFilledCount = filledCount;
        } catch (err) {
            console.error('[Finlet] SSE orders parse error:', err);
        }
    });

    // -- Trace event --
    sseSource.addEventListener('trace', (e) => {
        if (currentSessionId !== sessionId) return;
        try {
            const data = JSON.parse(e.data);
            renderTrace(data);
        } catch (err) {
            console.error('[Finlet] SSE trace parse error:', err);
        }
    });

    // -- Health event (plugin health or reconnect signal) --
    sseSource.addEventListener('health', (e) => {
        if (currentSessionId !== sessionId) return;
        try {
            const data = JSON.parse(e.data);
            // Server signals reconnect when max duration reached
            if (data.status === 'reconnect') {
                console.info('[Finlet] SSE server requests reconnect:', data.reason);
                connectSSE(sessionId);
                return;
            }
            // Error status from server
            if (data.status === 'error') {
                console.warn('[Finlet] SSE health error:', data.message);
                return;
            }
            // Normal plugin health data (array)
            if (Array.isArray(data)) {
                renderPlugins(data);
            }
        } catch (err) {
            console.error('[Finlet] SSE health parse error:', err);
        }
    });

    // -- Connection opened --
    sseSource.onopen = () => {
        sseRetryCount = 0;
        consecutiveErrors = 0;
        updateConnectionStatus('connected');
        lastSuccessfulConnection = Date.now();

        // Hide SSE connection-lost banner on successful reconnection
        if (typeof hideSSEBanner === 'function') {
            hideSSEBanner();
        }

        // Clear transition state on first data
        if (isTransitioning) {
            isTransitioning = false;
            document.querySelectorAll('.stat-value.skeleton').forEach(el => {
                el.classList.remove('skeleton', 'skeleton--value-inline');
                el.textContent = '--';
            });
        }
    };

    // -- Connection error (EventSource auto-retries) --
    sseSource.onerror = () => {
        sseRetryCount++;
        consecutiveErrors++;
        updateConnectionStatus('connecting');

        // Show SSE banner with exponential backoff countdown
        const backoffSeconds = Math.min(2 ** sseRetryCount, 60);
        if (typeof showSSEBanner === 'function') {
            showSSEBanner(backoffSeconds, () => {
                // Manual retry: reconnect SSE immediately
                connectSSE(sessionId);
            });
        }

        if (sseRetryCount > SSE_MAX_RETRIES) {
            console.warn('[Finlet] SSE failed after', SSE_MAX_RETRIES, 'retries, falling back to REST polling');
            disconnectSSE();
            updateConnectionStatus('disconnected');
            startFallbackPolling(sessionId);
        }
    };

    // Track SSE data updates for stale-data display
    sseSource.onmessage = () => {
        lastDataUpdate = Date.now();
        updateLastUpdatedDisplay();

        // Remove any remaining loading pulses
        document.querySelectorAll('.loading-pulse').forEach(el => el.classList.remove('loading-pulse'));

        // Add subtle refresh pulse to updated elements
        if (!isTransitioning) {
            document.querySelectorAll('.stat-value').forEach(el => {
                el.classList.add('data-refreshed');
                setTimeout(() => el.classList.remove('data-refreshed'), 300);
            });
        }
    };
}

/**
 * Close the current SSE connection.
 */
function disconnectSSE() {
    if (sseSource) {
        sseSource.close();
        sseSource = null;
    }
}

// ============================================================
//  Fallback REST Polling (used only when SSE fails)
// ============================================================

let _fallbackTimer = null;

function startFallbackPolling(sessionId) {
    stopFallbackPolling();
    scheduleFallbackFetch(sessionId);
}

function scheduleFallbackFetch(sessionId) {
    _fallbackTimer = setTimeout(async () => {
        if (!currentSessionId || currentSessionId !== sessionId) {
            stopFallbackPolling();
            return;
        }
        await fallbackPollNow(sessionId);
        scheduleFallbackFetch(sessionId);
    }, 2000);
}

function stopFallbackPolling() {
    if (_fallbackTimer) {
        clearTimeout(_fallbackTimer);
        _fallbackTimer = null;
    }
}

async function fallbackPollNow(sessionId) {
    if (!currentSessionId || currentSessionId !== sessionId) return;

    const [sessionRes, clockRes, portfolioRes, historyRes, ordersRes, traceRes, pluginHealthRes] = await Promise.all([
        dashFetch(`/sessions/${sessionId}`),
        dashFetch(`/sessions/${sessionId}/clock`),
        dashFetch(`/sessions/${sessionId}/portfolio`),
        dashFetch(`/sessions/${sessionId}/portfolio/history`),
        dashFetch(`/sessions/${sessionId}/trade/orders`),
        dashFetch(`/sessions/${sessionId}/trace`),
        dashFetch('/plugins/health'),
    ]);

    if (currentSessionId !== sessionId) return;

    const results = [sessionRes, clockRes, portfolioRes, historyRes, ordersRes, traceRes, pluginHealthRes];
    const anyOk = results.some((r) => r.ok);
    if (anyOk) {
        lastDataUpdate = Date.now();
        updateLastUpdatedDisplay();
        updateConnectionStatus('connected');
    }

    if (isTransitioning) {
        isTransitioning = false;
        document.querySelectorAll('.stat-value.skeleton').forEach(el => {
            el.classList.remove('skeleton', 'skeleton--value-inline');
            el.textContent = '--';
        });
    }

    if (sessionRes.ok && sessionRes.data) {
        currentSession = sessionRes.data;
        renderSession(sessionRes.data);
    }
    if (clockRes.ok && clockRes.data) renderClock(clockRes.data);
    if (portfolioRes.ok && portfolioRes.data) {
        renderPortfolio(portfolioRes.data);
    } else if (!portfolioRes.ok && portfolioRes.status) {
        // API error (not just empty) — show per-widget retry for positions
        if (typeof showWidgetError === 'function') {
            showWidgetError('positions-body', 'Failed to load positions.', () => fallbackPollNow(sessionId));
        }
    }
    if (historyRes.ok && historyRes.data) renderEquityCurve(historyRes.data, ordersRes.ok ? ordersRes.data : null);
    if (ordersRes.ok && ordersRes.data) {
        renderOrders(ordersRes.data);

        const orderList = Array.isArray(ordersRes.data) ? ordersRes.data : (ordersRes.data.orders || []);
        const filledCount = orderList.filter(o => (o.status || '').toUpperCase() === 'FILLED').length;
        if (filledCount > 0 && window._lastFilledCount !== undefined && filledCount > window._lastFilledCount) {
            const newFills = filledCount - window._lastFilledCount;
            showToast({ type: 'success', title: 'Order Filled', message: `${newFills} new order${newFills > 1 ? 's' : ''} filled.` });
        }
        window._lastFilledCount = filledCount;
    } else if (!ordersRes.ok && ordersRes.status) {
        if (typeof showWidgetError === 'function') {
            showWidgetError('orders-body', 'Failed to load orders.', () => fallbackPollNow(sessionId));
        }
    }
    if (traceRes.ok && traceRes.data) {
        renderTrace(traceRes.data);
    } else if (!traceRes.ok && traceRes.status) {
        if (typeof showWidgetError === 'function') {
            showWidgetError('trace-feed', 'Failed to load activity trace.', () => fallbackPollNow(sessionId));
        }
    }
    if (pluginHealthRes.ok) {
        renderPlugins(pluginHealthRes.data);
    } else if (pluginHealthRes.status) {
        if (typeof showWidgetError === 'function') {
            showWidgetError('plugin-cards', 'Failed to load plugin status.', () => fallbackPollNow(sessionId));
        }
    } else {
        renderPlugins(null);
    }

    document.querySelectorAll('.loading-pulse').forEach(el => el.classList.remove('loading-pulse'));
    fetchSessions();
}

// ---- Render: Session ----
function renderSession(session) {
    const statusEl = document.getElementById('session-status');
    const status = (session.status || '').toLowerCase();
    statusEl.textContent = session.status || '--';
    statusEl.className = 'badge badge--' + status;
}

// ---- Render: Clock ----
function renderClock(clock) {
    const simTime = clock.current_time || clock.sim_time || '--';
    const mode = (clock.mode || '').toLowerCase();

    // Overview SIM TIME card has min-width:150px (~12 chars at 20px mono);
    // the full 24-char `YYYY-MM-DD HH:MM:SS UTC` does not fit and the
    // unconditional `text-overflow: ellipsis` on `.stat-value` (added by
    // bug-hunt 20260503T230405Z2601 Team A to prevent em-dash artefacts)
    // would clip it to e.g. "2025-05-…". Render date-only on the tile and
    // expose the full timestamp via `title=` for hover tooltips. The
    // header bar's `#header-sim-time` keeps the full format unchanged.
    // See bug-hunt 20260505T175445Z750b Team C.
    const fullSimTime = formatDateTime(simTime);
    const shortSimTime = formatDateShort(simTime) || '--';
    const simEl = document.getElementById('sim-time');
    simEl.textContent = shortSimTime;
    simEl.setAttribute('title', fullSimTime);
    document.getElementById('header-sim-time').textContent = fullSimTime;

    const modeEl = document.getElementById('clock-mode');
    modeEl.textContent = clock.mode || '--';
    modeEl.className = 'badge badge--' + mode;

    // Highlight active control and update aria-labels
    const freezeBtn = document.getElementById('btn-freeze');
    const playBtn = document.getElementById('btn-play');
    freezeBtn.classList.toggle('btn--active', mode === 'frozen');
    playBtn.classList.toggle('btn--active', mode === 'continuous');

    // Update play/pause aria-label and visible text based on state
    if (mode === 'continuous') {
        playBtn.setAttribute('aria-label', 'Pause simulation (Space)');
        playBtn.textContent = 'Pause';
    } else {
        playBtn.setAttribute('aria-label', 'Start continuous simulation (Space)');
        playBtn.textContent = 'Play';
    }

    if (mode === 'frozen') {
        freezeBtn.setAttribute('aria-label', 'Unfreeze clock (Space)');
        freezeBtn.textContent = 'Unfreeze';
    } else {
        freezeBtn.setAttribute('aria-label', 'Freeze clock (Space)');
        freezeBtn.textContent = 'Freeze';
    }

    // Disable clock controls when no session
    const clockBtns = ['btn-freeze', 'btn-step', 'btn-play', 'btn-stop'];
    clockBtns.forEach(btnId => {
        document.getElementById(btnId).disabled = false;
        document.getElementById(btnId).classList.remove('btn--disabled');
    });
}

// `pnlArrow()` was relocated to `dashboard/renderers.js` (2026-05-12 Team B
// refactor). Function declarations are hoisted to the classic-script global
// scope, so call sites in this file resolve unchanged.

// ---- Render: Portfolio ----
function renderPortfolio(portfolio) {
    const totalValue = portfolio.total_value ?? 0;
    const cash = portfolio.cash ?? 0;
    const initialCapital = portfolio.initial_capital
        ?? currentSession?.config?.initial_capital ?? 100000;
    const totalPnl = (portfolio.realized_pnl ?? 0) + (portfolio.unrealized_pnl ?? 0);
    const totalReturnPct = portfolio.total_return_pct ?? (
        initialCapital > 0 ? ((totalValue - initialCapital) / initialCapital) * 100 : 0
    );
    // Note: both the backend field and the fallback expression return a
    // percentage-scale value (e.g. 5.0 for 5%).

    animateValue('portfolio-value', formatCurrency(totalValue));
    document.getElementById('cash-value').textContent = formatCurrency(cash);

    const pnlEl = document.getElementById('total-pnl');
    animateValue('total-pnl', pnlArrow(totalPnl) + formatCurrency(totalPnl, true));
    pnlEl.className = 'stat-value ' + pnlClass(totalPnl);

    const pnlPctEl = document.getElementById('total-pnl-pct');
    pnlPctEl.textContent = pnlArrow(totalReturnPct) + formatPct(totalReturnPct);
    pnlPctEl.className = 'stat-sub ' + pnlClass(totalReturnPct);

    // Return %
    const returnEl = document.getElementById('total-return');
    animateValue('total-return', pnlArrow(totalReturnPct) + formatPct(totalReturnPct));
    returnEl.className = 'stat-value ' + pnlClass(totalReturnPct);

    // Sharpe ratio: sign-prefix uses the rounded display value (2dp) so it
    // agrees with pnlClass; a raw -0.001 that displays "0.00" gets "+", not "-".
    const sharpeEl = document.getElementById('sharpe-ratio');
    const sharpe = portfolio.sharpe_ratio;
    const sharpeRounded = sharpe != null ? Math.round(sharpe * 100) / 100 : null;
    sharpeEl.textContent = sharpe != null ? `${pnlArrow(sharpe)}${sharpeRounded >= 0 ? '+' : ''}${sharpeRounded.toFixed(2)}` : '--';
    sharpeEl.className = 'stat-value ' + (sharpe != null ? pnlClass(sharpe) : '');

    // Max drawdown: dd is a fraction; multiply by 100 for percent display +
    // classification. A dd of 0 must render neutral (no arrow, no red).
    const ddEl = document.getElementById('max-drawdown');
    const dd = portfolio.max_drawdown;
    ddEl.textContent = dd != null ? `${pnlArrow(dd * 100)}${(dd * 100).toFixed(1)}%` : '--';
    ddEl.className = 'stat-value ' + (dd != null ? pnlClass(dd * 100) : '');

    // Win rate + trade count.
    //
    // `trade_count` counts CLOSED round-trip trades (sell fills only) — it
    // is the denominator of `win_rate`. `orders_filled` (added 2026-04-27)
    // counts ALL filled fills (buy + sell). When a user submits a BUY and
    // sees it FILL in the order log, `trade_count` is still 0 (no exit
    // yet). Showing "Win Rate 0.0% — 0 trades" in that state visibly
    // contradicts the order log. We therefore distinguish three cases:
    //   1. No fills at all                     → "0.0%" / "0 trades"
    //   2. Fills exist but no closed trades    → "N/A" / "X open fill(s)"
    //   3. At least one closed trade           → "Y%"  / "C closed · T total"
    const wrEl = document.getElementById('win-rate');
    const tcEl = document.getElementById('trade-count');
    const wr = portfolio.win_rate;
    const tc = portfolio.trade_count;
    const of = portfolio.orders_filled;

    if (tc == null) {
        wrEl.textContent = wr != null ? `${(wr * 100).toFixed(1)}%` : '--';
        tcEl.textContent = '--';
    } else if (tc === 0) {
        if (typeof of === 'number' && of > 0) {
            // Fills happened but nothing closed yet — "Win Rate 0% — 0 trades"
            // would contradict the order log. Be honest about the absence
            // of a denominator.
            wrEl.textContent = 'N/A';
            tcEl.textContent = `0 closed · ${of} filled`;
        } else {
            wrEl.textContent = wr != null ? `${(wr * 100).toFixed(1)}%` : '--';
            tcEl.textContent = '0 trades';
        }
    } else {
        wrEl.textContent = wr != null ? `${(wr * 100).toFixed(1)}%` : '--';
        if (typeof of === 'number' && of > tc) {
            tcEl.textContent = `${tc} closed · ${of} filled`;
        } else {
            tcEl.textContent = `${tc} ${tc === 1 ? 'trade' : 'trades'}`;
        }
    }

    // Positions
    const positions = portfolio.positions || {};
    const posArray = Array.isArray(positions)
        ? positions
        : Object.entries(positions).map(([ticker, pos]) => ({
            ticker,
            ...(typeof pos === 'object' ? pos : { quantity: pos }),
        }));
    renderPositions(posArray, totalValue);
}

// `renderPositions()`, `renderEquityCurve()`, `renderOrders()`, and
// `renderTrace()` were relocated to `dashboard/renderers.js` (2026-05-12
// public-session-view exec plan, Team B). Loaded as classic-script global
// function declarations before `app.js`, so call sites resolve unchanged.

// ---- Format: plugin latency badge ----
//
// Bug-hunt iteration 20260505T142400Z3330 (Team B). The blind agent
// observed the literal string `8es` on the price/fundamentals_s3/news_s3/
// sentiment plugin badges while econ correctly showed `349ms`. The live
// API response is a numeric `latency_ms` for all 8 plugins (econ ≈ 350ms,
// the four affected ones < 1ms because their probes hit a local cache
// only). The previous inline render used `Number(p.latency_ms).toFixed(0)`,
// which collapses any sub-1ms float to the literal string `0` and renders
// `0ms` — a value that visually reads as either a data error or a
// malformed unit (the blind agent's `8es` observation is consistent with a
// human-misread of `0ms` in the dashboard's small mono font: 0/8 and m/e
// are confusable glyphs at low rendering resolution).
//
// `formatLatency` returns a display string so the renderer no longer has
// to know about rounding rules:
//   - `null` for non-finite values (string `"8es"`, NaN, Infinity, etc.) —
//     defense-in-depth that keeps the badge from rendering literal junk if
//     the BE serializer ever produces something unexpected. The renderer
//     short-circuits the `<div class="plugin-latency">` element when this
//     is null, matching today's `latency_ms != null` gate semantics.
//   - `<1ms` for positive values that round to zero (sub-1ms probes that
//     hit a local cache). This is the actual fix for the blind-agent
//     finding — the badge now reads as a meaningful "fast" measurement
//     instead of `0ms`.
//   - `0ms` for an exact zero (only possible if the upstream probe truly
//     returned 0.0 — an explicit reading we should surface as such).
//   - `${rounded}ms` (integer) for everything ≥ 1.
function formatLatency(latencyMs) {
    if (latencyMs == null) return null;
    const n = Number(latencyMs);
    if (!Number.isFinite(n)) return null;
    if (n === 0) return '0ms';
    if (n > 0 && n < 1) return '<1ms';
    return `${Math.round(n)}ms`;
}

// ---- Render: Plugins ----
function renderPlugins(plugins) {
    const container = document.getElementById('plugin-cards');

    if (!plugins || (Array.isArray(plugins) && !plugins.length)) {
        if (typeof showContextEmptyState === 'function') {
            showContextEmptyState('plugin-cards', 'no-plugins');
        } else {
            setStaticHTML(container, '<div class="empty-state"><p class="empty-state__headline">Connect a data source</p><p class="empty-state__text">Add a market data plugin to power your trading agent.</p></div>');
        }
        return;
    }

    const pluginList = Array.isArray(plugins) ? plugins : [];
    if (!pluginList.length) {
        if (typeof showContextEmptyState === 'function') {
            showContextEmptyState('plugin-cards', 'no-plugins');
        } else {
            setStaticHTML(container, '<div class="empty-state"><p class="empty-state__headline">Connect a data source</p><p class="empty-state__text">Add a market data plugin to power your trading agent.</p></div>');
        }
        return;
    }

    container.innerHTML = trustedHTML(pluginList.map((p) => {
        // Mirror dashboard/settings.js:1043 — both surfaces consume the same
        // canonical /v1/plugins/health response, so a missing-status default
        // must mean the same thing on both. We default to 'unknown' (gray),
        // never 'healthy' (green), so missing data fails closed instead of
        // lying to the user. Color is derived ONLY from the canonical
        // `status` string — never from cache_count, files_found, or a
        // message-substring heuristic.
        const status = (p.status || 'unknown').toLowerCase();
        const dotClass = (status === 'healthy' || status === 'ok')
            ? 'ok'
            : (status === 'degraded' || status === 'rate-limited' || status === 'rate_limited')
                ? 'degraded'
                : (status === 'error' || status === 'unhealthy')
                    ? 'error'
                    : 'unknown';
        const statusLabel = dotClass === 'ok'
            ? 'Healthy'
            : dotClass === 'degraded'
                ? 'Degraded'
                : dotClass === 'error'
                    ? 'Error'
                    : 'Unknown';

        // formatLatency returns null for non-finite values; short-circuit
        // the badge when null so we never render `NaNms` or `8esms` if the
        // BE serializer ever drifts from the canonical numeric contract.
        const latencyDisplay = formatLatency(p.latency_ms);
        return `<div class="plugin-card" role="listitem">
            <div class="plugin-status-dot plugin-status-dot--${dotClass}" aria-hidden="true"></div>
            <span class="sr-only">Status: ${statusLabel}</span>
            <div class="plugin-info">
                <div class="plugin-name">${esc(p.name)}</div>
                <div class="plugin-type">${esc(p.plugin_type || p.type || '')}</div>
                ${p.message ? `<div class="plugin-message">${esc(p.message)}</div>` : ''}
            </div>
            <div class="plugin-meta">
                ${latencyDisplay !== null ? `<div class="plugin-latency">${esc(latencyDisplay)}<span class="sr-only"> response time</span></div>` : ''}
                ${p.rate_limit_remaining != null
                    ? `<div class="plugin-rate">${esc(String(p.rate_limit_remaining))} <span class="sr-only">API calls</span> remaining</div>`
                    : ''}
            </div>
        </div>`;
    }).join(''));
}

// `initChart()` was relocated to `dashboard/renderers.js` (2026-05-12
// public-session-view exec plan, Team B). Loaded as a classic-script
// global before `app.js`, so the `DOMContentLoaded` call site (which
// invokes `initChart()` unqualified) resolves unchanged.

// ---- Clear Dashboard ----
function clearDashboard() {
    currentSession = null;
    lastDataUpdate = null;
    document.getElementById('sim-time').textContent = '--';
    document.getElementById('header-sim-time').textContent = '--';
    document.getElementById('portfolio-value').textContent = '--';
    document.getElementById('cash-value').textContent = '--';
    document.getElementById('total-pnl').textContent = '--';
    document.getElementById('total-pnl-pct').textContent = '--';
    document.getElementById('total-return').textContent = '--';
    document.getElementById('sharpe-ratio').textContent = '--';
    document.getElementById('max-drawdown').textContent = '--';
    document.getElementById('win-rate').textContent = '--';
    document.getElementById('trade-count').textContent = '--';
    document.getElementById('clock-mode').textContent = '--';
    document.getElementById('session-status').textContent = '--';
    document.getElementById('session-status').className = 'badge badge--idle';
    // Disable clock controls
    ['btn-freeze', 'btn-step', 'btn-play', 'btn-stop'].forEach(btnId => {
        const btn = document.getElementById(btnId);
        btn.disabled = true;
        btn.classList.add('btn--disabled');
    });
    if (typeof showContextEmptyState === 'function') {
        showContextEmptyState('positions-body', 'no-positions');
        showContextEmptyState('orders-body', 'no-orders');
        showContextEmptyState('trace-feed', 'no-trace');
        // No-session path: distinguish "no active session" from "session has zero plugins".
        // The 'no-plugins' context (Connect a data source) is reserved for renderPlugins([])
        // when the backend reports an empty plugin list for an active session.
        // See bug-hunt 20260506T185234Z542e plugin-health-no-session-empty-state.
        showContextEmptyState('plugin-cards', 'no-session');
    } else {
        setStaticHTML(document.getElementById('positions-body'),
            '<tr class="empty-row"><td colspan="6"><div class="empty-state"><p class="empty-state__headline">No positions yet</p><p class="empty-state__text">Execute a buy order to open a position.</p></div></td></tr>');
        setStaticHTML(document.getElementById('orders-body'),
            '<tr class="empty-row"><td colspan="8"><div class="empty-state"><p class="empty-state__headline">No orders yet</p><p class="empty-state__text">Open a trade to place your first order.</p></div></td></tr>');
        setStaticHTML(document.getElementById('trace-feed'),
            '<div class="empty-state"><p class="empty-state__headline">No activity yet</p><p class="empty-state__text">When your agent queries data or submits trades, each step will appear here.</p></div>');
        setStaticHTML(document.getElementById('plugin-cards'),
            '<div class="empty-state"><p class="empty-state__headline">Select a session to see plugin status</p><p class="empty-state__text">Plugin health is reported per active session. Create or select one to view live status.</p></div>');
    }

    if (equitySeries) equitySeries.setData([]);
    if (benchmarkSeries) benchmarkSeries.setData([]);

    updateLastUpdatedDisplay();
}

// `formatCurrency()`, `formatPct()`, `formatDateTime()`, `formatDateShort()`,
// `toChartTime()`, `pnlClass()`, and `setStaticHTML()` were relocated to
// `dashboard/renderers.js` (2026-05-12 Team B refactor). All are loaded as
// classic-script globals before `app.js`, so call sites resolve unchanged.

// ---- Value Animation ----
function animateValue(elementId, newText) {
    const el = document.getElementById(elementId);
    if (!el) return;
    const oldText = el.textContent;
    if (oldText === newText || oldText === '--') {
        el.textContent = newText;
        return;
    }
    el.textContent = newText;
    el.classList.add('value-flash');
    setTimeout(() => el.classList.remove('value-flash'), 600);
}

// ============================================================
//  Connection Status — Enhanced
// ============================================================

function updateConnectionStatus(status) {
    if (connectionStatus === status) return;
    const prevStatus = connectionStatus;
    connectionStatus = status;
    const dot = document.getElementById('connection-dot');
    const label = document.getElementById('connection-label');
    if (!dot || !label) return;

    dot.className = 'connection-dot connection-dot--' + status;

    if (status === 'connected') {
        label.textContent = 'Connected';
    } else if (status === 'connecting') {
        label.textContent = 'Reconnecting...';
    } else {
        let disconnectedText = 'Disconnected';
        if (lastSuccessfulConnection) {
            const elapsed = Date.now() - lastSuccessfulConnection;
            const seconds = Math.floor(elapsed / 1000);
            if (seconds < 60) {
                disconnectedText += ` (${seconds}s ago)`;
            } else {
                const minutes = Math.floor(seconds / 60);
                disconnectedText += ` (${minutes}m ago)`;
            }
        }
        label.textContent = disconnectedText;
    }

    if (status === 'disconnected' && prevStatus !== 'disconnected') {
        showToast({ type: 'error', title: 'Connection Lost', message: 'Unable to reach the server. Retrying...', persistent: true, id: 'connection-lost' });
    }
    if (status === 'connected' && prevStatus === 'disconnected') {
        dismissToastById('connection-lost');
        if (typeof hideSSEBanner === 'function') hideSSEBanner();
        showToast({ type: 'success', title: 'Reconnected', message: 'Server connection restored.' });
    }
}

// ============================================================
//  Toast Notification System — Professional
// ============================================================

const TOAST_MAX_VISIBLE = 5;
let toastQueue = [];
let activeToasts = [];
let toastIdCounter = 0;

/**
 * Show a toast notification.
 * @param {Object} opts
 * @param {string} opts.type - 'success' | 'error' | 'warning' | 'info'
 * @param {string} opts.title - Bold title text
 * @param {string} opts.message - Description text
 * @param {number} [opts.duration=5000] - Auto-dismiss ms (0 = manual only)
 * @param {boolean} [opts.persistent=false] - Error toasts persist by default
 * @param {string} [opts.id] - Optional unique ID for deduplication/dismissal
 */
function showToast(opts) {
    // Handle legacy string-only calls: showToast(message, type)
    if (typeof opts === 'string') {
        const type = arguments[1] || 'info';
        opts = { type, title: '', message: opts };
    }

    const { type = 'info', title = '', message = '', duration, persistent, id } = opts;

    const container = document.getElementById('toast-container');
    if (!container) return;

    // Deduplicate by id or content
    const toastId = id || `toast-${++toastIdCounter}`;
    if (id) {
        const existing = activeToasts.find(t => t.id === id);
        if (existing) return; // Already showing this toast
    }

    // Check for content deduplication
    for (const t of activeToasts) {
        if (t.title === title && t.message === message) return;
    }

    // Determine effective duration
    const isPersistent = persistent !== undefined ? persistent : (type === 'error');
    const effectiveDuration = isPersistent ? 0 : (duration || 5000);

    // Queue if at capacity
    if (activeToasts.length >= TOAST_MAX_VISIBLE) {
        toastQueue.push({ type, title, message, duration: effectiveDuration, persistent: isPersistent, id: toastId });
        return;
    }

    createToastElement(container, { type, title, message, duration: effectiveDuration, persistent: isPersistent, id: toastId });
}

function createToastElement(container, opts) {
    const { type, title, message, duration, persistent, id } = opts;

    const toast = document.createElement('div');
    toast.className = `toast toast--${type}`;
    toast.setAttribute('role', 'alert');
    toast.setAttribute('aria-live', 'assertive');
    toast.dataset.toastId = id;

    const iconSvg = getToastIcon(type);

    toast.innerHTML = trustedHTML(`
        <div class="toast__icon">${iconSvg}</div>
        <div class="toast__content">
            ${title ? `<div class="toast__title">${esc(title)}</div>` : ''}
            ${message ? `<div class="toast__message">${esc(message)}</div>` : ''}
        </div>
        <button class="toast__close" aria-label="Dismiss notification">&times;</button>
        ${duration > 0 ? `<div class="toast__progress"><div class="toast__progress-bar toast__progress-bar--${type}" style="animation-duration: ${duration}ms"></div></div>` : ''}
    `);

    // Close button handler
    toast.querySelector('.toast__close').addEventListener('click', () => {
        dismissToast(toast, id);
    });

    container.appendChild(toast);

    // Track active toast
    activeToasts.push({ el: toast, id, title, message });

    // Trigger slide-in animation
    requestAnimationFrame(() => {
        requestAnimationFrame(() => {
            toast.classList.add('toast--visible');
        });
    });

    // Auto-dismiss
    if (duration > 0) {
        setTimeout(() => {
            dismissToast(toast, id);
        }, duration);
    }
}

function dismissToast(toastEl, id) {
    if (!toastEl || !toastEl.parentNode) return;
    toastEl.classList.remove('toast--visible');
    toastEl.classList.add('toast--dismissing');
    setTimeout(() => {
        if (toastEl.parentNode) toastEl.remove();
        activeToasts = activeToasts.filter(t => t.id !== id);
        // Process queue
        if (toastQueue.length > 0 && activeToasts.length < TOAST_MAX_VISIBLE) {
            const next = toastQueue.shift();
            const container = document.getElementById('toast-container');
            if (container) createToastElement(container, next);
        }
    }, 300);
}

function dismissToastById(id) {
    const toast = activeToasts.find(t => t.id === id);
    if (toast) {
        dismissToast(toast.el, id);
    }
}

function getToastIcon(type) {
    switch (type) {
        case 'success':
            return '<svg width="16" height="16" viewBox="0 0 16 16" fill="none"><circle cx="8" cy="8" r="7" stroke="var(--green)" stroke-width="1.5"/><path d="M5 8l2 2 4-4" stroke="var(--green)" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>';
        case 'error':
            return '<svg width="16" height="16" viewBox="0 0 16 16" fill="none"><circle cx="8" cy="8" r="7" stroke="var(--red)" stroke-width="1.5"/><path d="M6 6l4 4M10 6l-4 4" stroke="var(--red)" stroke-width="1.5" stroke-linecap="round"/></svg>';
        case 'warning':
            return '<svg width="16" height="16" viewBox="0 0 16 16" fill="none"><path d="M8 2L1 14h14L8 2z" stroke="var(--yellow)" stroke-width="1.5" stroke-linejoin="round"/><path d="M8 6v4M8 12v0" stroke="var(--yellow)" stroke-width="1.5" stroke-linecap="round"/></svg>';
        case 'info':
        default:
            return '<svg width="16" height="16" viewBox="0 0 16 16" fill="none"><circle cx="8" cy="8" r="7" stroke="var(--accent)" stroke-width="1.5"/><path d="M8 7v4M8 5v0" stroke="var(--accent)" stroke-width="1.5" stroke-linecap="round"/></svg>';
    }
}

// `traceIcon()` and `traceIconClass()` were relocated to
// `dashboard/renderers.js` (2026-05-12 Team B refactor). Loaded as
// classic-script globals before `app.js`, so call sites resolve unchanged.
