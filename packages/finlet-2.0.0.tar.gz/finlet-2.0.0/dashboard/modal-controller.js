// Modal controller — currently zero callers post-2026-05-06 launch cut. Retained for future read-only modal use. See docs/decisions/ui-removal-launch-cut.md.

/* ============================================================
   Finlet Dashboard — Modal Controller
   Single authority for modal stacking, visibility, and input layer.
   Replaces ad-hoc per-modal `display: block` / `classList.toggle` /
   per-modal hard-coded z-index dance with a centralized stack.

   Public surface:
       window.finletModal.open(id)        -> close handle (function)
       window.finletModal.close(id)       -> void (idempotent)
       window.finletModal.suppress(suppressor_id, while_open_id) -> void
       window.finletModal.topmost()       -> string | null
       window.finletModal.isOpen(id)      -> boolean

   Behaviour:
   - Internal stack: Array<string> of currently-open modal ids.
   - On open(id):
       * push id onto stack
       * set element.style.zIndex = base + stack.length
       * set element.style.pointerEvents = 'auto'
       * set element.style.display = ''   (clears the belt-and-suspenders
         inline `display:none`; CSS controls flex/block thereafter)
       * add `.fl-modal--visible` class so CSS transitions fire
       * every other modal in the stack drops to pointerEvents='none'
         and a lower z-index
   - On close(id):
       * splice id from stack (no-op if not present)
       * set element.style.display = 'none'
       * set element.style.pointerEvents = 'none'
       * remove `.fl-modal--visible`
       * the new topmost (if any) gets pointerEvents='auto' and the
         highest z-index
   - suppress(suppressor, target):
       * registers a suppression rule. While `target` is in the open
         stack, `suppressor` is forced pointerEvents='none' + z-index 0
         REGARDLESS of its open-state. When `target` leaves the stack,
         `suppressor`'s open-state is restored (if it is itself still
         open). The rule persists across multiple target open/close
         cycles until explicitly cleared (no clear API yet — none of
         today's call sites need it).

   Design notes:
   - Mirrors `dashboard/event-bus.js`'s singleton + idempotent-attach
     module pattern. Only `window.finletModal` is exposed; bare
     globals are not leaked.
   - Reads `--modal-base-z` from `:root` once per `open()` so theme
     stylesheets that override the variable still take effect.
   - Out of scope (per `docs/refactor/modal-stacking/plan.md`):
     several non-modal surfaces (slide-out asides, emergency
     overlays, toast containers, navigation drawers, user-menu
     dropdowns) are intentionally NOT given `data-modal-id` and
     are NOT referenced by this controller. See the plan document
     for the full exclusion list.
   ============================================================ */

(function () {
    'use strict';

    // Idempotent attach — mirror event-bus.js. If the controller is
    // somehow loaded twice, do not re-initialize. The first attached
    // instance owns the stack.
    if (window.finletModal) {
        return;
    }

    /** @type {Array<string>} */
    const stack = [];

    /**
     * Suppression rules: suppressor_id -> Set<target_id>.
     * If ANY target in the set is currently open, the suppressor is
     * forced pointer-events:none + z-index 0.
     * @type {Map<string, Set<string>>}
     */
    const suppressions = new Map();

    function getBaseZ() {
        const raw = getComputedStyle(document.documentElement)
            .getPropertyValue('--modal-base-z');
        const parsed = parseInt((raw || '').trim(), 10);
        return Number.isFinite(parsed) ? parsed : 1000;
    }

    function findElement(id) {
        // Modals are tagged with `data-modal-id="..."`. Return the
        // first matching element, or null. We do not throw on missing
        // elements — open/close becomes a no-op so unit-test churn and
        // dynamic-modal lifecycle (e.g. wizard) don't trip up the
        // controller.
        return document.querySelector('[data-modal-id="' + cssEscape(id) + '"]');
    }

    function cssEscape(value) {
        // `id` strings come from controlled call sites in our own code,
        // not user input, so a simple sanity-pass is sufficient. We
        // restrict to ascii word + dash characters and reject anything
        // else to keep the selector unambiguous.
        if (typeof value !== 'string') return '';
        if (!/^[A-Za-z0-9_-]+$/.test(value)) return '';
        return value;
    }

    function isSuppressed(id) {
        const targets = suppressions.get(id);
        if (!targets || targets.size === 0) return false;
        for (const target of targets) {
            if (stack.indexOf(target) !== -1) {
                return true;
            }
        }
        return false;
    }

    function applyStackLayout() {
        // Walk the open stack and assign z-index + pointer-events.
        // The topmost modal (last in stack) is the only one with
        // pointer-events:auto. Suppressed modals are forced down.
        //
        // Visibility (additive): non-top stack members AND suppressed
        // modals get the `.fl-modal--hidden` class so they are visually
        // removed (pointer-events alone left non-top members painted
        // on top of the newly-opened modal — see bug-hunt
        // 20260505T213116Z45f1 surface 2 / Team B). The top stack
        // member always has the class removed. CSS scopes the rule to
        // `.fl-modal.fl-modal--hidden` so non-fl-modal panels (e.g.
        // the trade-ticket aside) are unaffected.
        const baseZ = getBaseZ();
        const topId = stack.length > 0 ? stack[stack.length - 1] : null;

        for (let i = 0; i < stack.length; i++) {
            const id = stack[i];
            const el = findElement(id);
            if (!el) continue;
            const isTop = id === topId;
            const suppressed = isSuppressed(id);

            if (suppressed) {
                el.style.zIndex = '0';
                el.style.pointerEvents = 'none';
                el.classList.add('fl-modal--hidden');
                continue;
            }

            // Stack from bottom (base + 1) up to top (base + stack.length).
            el.style.zIndex = String(baseZ + (i + 1));
            el.style.pointerEvents = isTop ? 'auto' : 'none';
            if (isTop) {
                el.classList.remove('fl-modal--hidden');
            } else {
                el.classList.add('fl-modal--hidden');
            }
        }
    }

    function open(id) {
        if (typeof id !== 'string' || !id) {
            throw new TypeError('finletModal.open: id must be a non-empty string');
        }

        const el = findElement(id);
        if (!el) {
            // Unknown id — return a no-op close handle so callers do not
            // need to guard against missing elements during teardown.
            return function noop() {};
        }

        // If the modal is already in the stack, move it to the top.
        // Re-opening should bring it forward, not stack two copies.
        const existing = stack.indexOf(id);
        if (existing !== -1) {
            stack.splice(existing, 1);
        }
        stack.push(id);

        // Belt-and-suspenders preservation: clear the inline
        // `style="display:none"` set in HTML so CSS flex/block
        // declarations take over. Per the iteration `20260428T013300Z6e79`
        // decision, the inline `display:none` rest-state stays in HTML.
        // The controller flips it on open/close.
        el.style.display = '';
        el.classList.add('fl-modal--visible');

        applyStackLayout();

        // Return an idempotent close handle bound to this id.
        let closed = false;
        return function closeHandle() {
            if (closed) return;
            closed = true;
            close(id);
        };
    }

    function close(id) {
        if (typeof id !== 'string' || !id) {
            return;
        }

        const idx = stack.indexOf(id);
        if (idx === -1) {
            // Idempotent: closing a modal that is not open is a no-op.
            // We still null out inline state in case the element exists
            // and was hand-styled, so the closed visual is consistent.
            const elOff = findElement(id);
            if (elOff) {
                elOff.style.display = 'none';
                elOff.style.pointerEvents = 'none';
                elOff.classList.remove('fl-modal--visible');
                elOff.classList.remove('fl-modal--hidden');
            }
            return;
        }

        stack.splice(idx, 1);

        const el = findElement(id);
        if (el) {
            el.style.display = 'none';
            el.style.pointerEvents = 'none';
            el.style.zIndex = '';
            el.classList.remove('fl-modal--visible');
            el.classList.remove('fl-modal--hidden');
        }

        // Re-apply layout for whatever is left in the stack so the new
        // topmost reclaims pointer-events and any auto-restore from
        // closing a suppression target is honoured.
        applyStackLayout();
    }

    function suppress(suppressor_id, while_open_id) {
        if (typeof suppressor_id !== 'string' || !suppressor_id) {
            throw new TypeError('finletModal.suppress: suppressor_id must be a non-empty string');
        }
        if (typeof while_open_id !== 'string' || !while_open_id) {
            throw new TypeError('finletModal.suppress: while_open_id must be a non-empty string');
        }
        let targets = suppressions.get(suppressor_id);
        if (!targets) {
            targets = new Set();
            suppressions.set(suppressor_id, targets);
        }
        targets.add(while_open_id);

        // Re-apply layout immediately — the rule may already be active
        // (target already open) and the suppressor needs to drop now.
        applyStackLayout();
    }

    function topmost() {
        return stack.length > 0 ? stack[stack.length - 1] : null;
    }

    function isOpen(id) {
        if (typeof id !== 'string' || !id) return false;
        return stack.indexOf(id) !== -1;
    }

    // Expose the singleton. Only `window.finletModal` is the integration
    // point — no bare globals.
    window.finletModal = Object.freeze({
        open: open,
        close: close,
        suppress: suppress,
        topmost: topmost,
        isOpen: isOpen,
    });
})();
