/* ============================================================
   Finlet Dashboard — Event Bus
   Single-process pub/sub for cross-script state propagation.
   Replaces ad-hoc CustomEvent fan-out and direct reach-ins
   (e.g. window.finletOnboarding.markStepComplete()).

   Public surface:
       window.finletBus.publish(event, payload)
       window.finletBus.subscribe(event, handler) -> unsubscribe()
       window.finletBus.getLastPublished(event) -> payload | undefined

   Event names + payload shapes are documented in
   dashboard/event-contract.md. Do NOT publish events that are
   not in the contract.

   Design notes:
   - Backed by Map<string, Set<handler>>; O(1) subscribe/unsubscribe.
   - Subscriber errors are caught and console.error'd so one bad
     subscriber cannot break sibling subscribers (post-mortem
     2026-04-28: subscriber-fan-out failure was a recurrence root
     cause).
   - subscribe() returns an unsubscribe closure — the canonical
     pattern is: `const off = bus.subscribe(...); ... off();`
   - publish() also writes to a per-event lastPublished cache (one
     entry per event name, replaced on each publish). This lets a
     consumer that subscribes AFTER the most recent publish prime
     synchronously via getLastPublished(). Used by
     dashboard/dialog-state-mirror.js to close the open-then-
     subscribe race for dialogs (3 bug-hunt iterations:
     20260428T031818Z2efa, 20260429T052717Z1a13,
     20260429T232205Z17ff). Cache is bounded by event-name count.
   - Bare globals (`subscribe`, `publish`) are intentionally NOT
     exported. Only `window.finletBus` is the integration point.
   ============================================================ */

(function () {
    'use strict';

    /** @type {Map<string, Set<Function>>} */
    const handlers = new Map();

    /**
     * Per-event cache of the most recently published payload. Exists so
     * that consumers (e.g. dialogs that open AFTER an SSE tick has
     * already published) can prime synchronously instead of racing the
     * next publish. The cache is updated on every publish, even when
     * there are zero subscribers — this matches the bus's "publish
     * with no subscribers is a no-op" semantics for delivery while
     * preserving the value for late readers.
     *
     * @type {Map<string, *>}
     */
    const lastPublished = new Map();

    function subscribe(event, handler) {
        if (typeof event !== 'string' || !event) {
            throw new TypeError('finletBus.subscribe: event must be a non-empty string');
        }
        if (typeof handler !== 'function') {
            throw new TypeError('finletBus.subscribe: handler must be a function');
        }
        let set = handlers.get(event);
        if (!set) {
            set = new Set();
            handlers.set(event, set);
        }
        set.add(handler);

        // Return an unsubscribe closure. Idempotent — calling it
        // twice is a no-op rather than an error.
        let active = true;
        return function unsubscribe() {
            if (!active) return;
            active = false;
            const current = handlers.get(event);
            if (!current) return;
            current.delete(handler);
            if (current.size === 0) {
                handlers.delete(event);
            }
        };
    }

    function publish(event, payload) {
        if (typeof event !== 'string' || !event) {
            throw new TypeError('finletBus.publish: event must be a non-empty string');
        }
        // Cache every publish, regardless of subscriber count. Late
        // readers (e.g. a dialog that opens after the most recent SSE
        // tick) can read the cached value via getLastPublished().
        lastPublished.set(event, payload);

        const set = handlers.get(event);
        if (!set || set.size === 0) {
            // Publishing with no subscribers is a no-op for delivery,
            // not an error. The cache update above still happens.
            return;
        }
        // Snapshot subscribers before iteration so a handler that
        // unsubscribes itself (or another) does not perturb this loop.
        const snapshot = Array.from(set);
        for (const handler of snapshot) {
            try {
                handler(payload);
            } catch (err) {
                console.error('[finletBus] subscriber error for "' + event + '":', err);
            }
        }
    }

    /**
     * Read the most recent payload published for an event, or
     * `undefined` if no publish has happened. Used by
     * dashboard/dialog-state-mirror.js so dialogs that open AFTER
     * the most recent publish can prime synchronously without
     * racing the next publish.
     */
    function getLastPublished(event) {
        if (typeof event !== 'string' || !event) {
            throw new TypeError('finletBus.getLastPublished: event must be a non-empty string');
        }
        return lastPublished.has(event) ? lastPublished.get(event) : undefined;
    }

    // Expose the bus singleton. No bare globals — only window.finletBus.
    window.finletBus = Object.freeze({
        subscribe: subscribe,
        publish: publish,
        getLastPublished: getLastPublished,
    });
})();
