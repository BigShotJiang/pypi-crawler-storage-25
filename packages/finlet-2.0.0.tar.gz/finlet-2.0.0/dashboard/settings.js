// Settings page — password change.
// Builds on the api-keys.js pattern: awaits the auth hydration barrier
// before binding submit handlers, then wires the password form to
// PUT /v1/settings/password.
//
// Scope is intentionally narrow: password change only. API key
// management lives at api-keys.html. Profile / MFA / notifications
// / plugins / data export / account deletion were cut from
// production scope on 2026-05-06 (see docs/decisions/ui-removal-launch-cut.md).
//
// Backend contract: PUT /v1/settings/password with
//   { current_password, new_password }.
// OAuth-only accounts (no password_hash) get a backend 400 — we surface
// the backend message verbatim via toast + inline banner so the user
// can see why the form was rejected.

// ============================================================
//  Init
// ============================================================
document.addEventListener('DOMContentLoaded', async () => {
    // Await the hydration barrier before binding any click handlers that
    // trigger state-changing requests (the password update is a PUT).
    const authOk = await awaitAuthReady();
    if (!authOk) {
        if (typeof FinletAuth !== 'undefined' && !FinletAuth.isAuthenticated()) {
            window.location.replace('auth.html');
        }
        return;
    }

    initSharedNav({
        activePage: 'settings',
        breadcrumbs: ['Dashboard', 'Settings'],
    });

    initPasswordForm();
});

// ============================================================
//  Password change form
// ============================================================

function initPasswordForm() {
    const form = document.getElementById('password-form');
    if (!form) return;
    form.addEventListener('submit', (ev) => {
        ev.preventDefault();
        submitPasswordChange();
    });
}

function _clearPasswordErrors() {
    const ids = ['current-password-error', 'new-password-error', 'confirm-new-password-error'];
    for (const id of ids) {
        const el = document.getElementById(id);
        if (el) el.textContent = '';
    }
    const banner = document.getElementById('password-form-error');
    if (banner) {
        banner.textContent = '';
        banner.hidden = true;
    }
}

function _setFieldError(id, message) {
    const el = document.getElementById(id);
    if (el) el.textContent = message;
}

function _showFormErrorBanner(message) {
    const banner = document.getElementById('password-form-error');
    if (!banner) return;
    banner.textContent = message;
    banner.hidden = false;
}

async function submitPasswordChange() {
    _clearPasswordErrors();

    const currentInput = document.getElementById('current-password');
    const newInput = document.getElementById('new-password');
    const confirmInput = document.getElementById('confirm-new-password');
    const submitBtn = document.getElementById('password-submit-btn');

    const currentPassword = (currentInput && currentInput.value) || '';
    const newPassword = (newInput && newInput.value) || '';
    const confirmPassword = (confirmInput && confirmInput.value) || '';

    // Client-side validation: required, min length, match.
    let hasError = false;
    if (!currentPassword) {
        _setFieldError('current-password-error', 'Please enter your current password.');
        hasError = true;
    }
    if (!newPassword) {
        _setFieldError('new-password-error', 'Please enter a new password.');
        hasError = true;
    } else if (newPassword.length < 8) {
        _setFieldError('new-password-error', 'New password must be at least 8 characters.');
        hasError = true;
    }
    if (!confirmPassword) {
        _setFieldError('confirm-new-password-error', 'Please confirm the new password.');
        hasError = true;
    } else if (newPassword && confirmPassword !== newPassword) {
        _setFieldError('confirm-new-password-error', 'Passwords do not match.');
        hasError = true;
    }
    if (hasError) return;

    if (submitBtn) {
        submitBtn.disabled = true;
        submitBtn.innerHTML = trustedHTML('<span class="settings-spinner"></span> Updating...');
    }

    const result = await apiRequest('/settings/password', 'PUT', {
        current_password: currentPassword,
        new_password: newPassword,
    });

    if (submitBtn) {
        submitBtn.disabled = false;
        submitBtn.textContent = 'Update password';
    }

    if (!result) {
        // apiRequest already surfaced a toast on error. Mirror the most
        // recent toast message inline so the failure remains visible
        // after the toast auto-dismisses — particularly important for
        // the OAuth-only-account 400 ("No password set on this account")
        // path, where the user needs durable copy to understand why
        // the form was rejected.
        const lastToast = _readLastToastMessage();
        if (lastToast) _showFormErrorBanner(lastToast);
        return;
    }

    // Success — clear the form and toast.
    if (currentInput) currentInput.value = '';
    if (newInput) newInput.value = '';
    if (confirmInput) confirmInput.value = '';
    showToast('Password updated', 'success');
}

// Read the most recently rendered toast's text content. apiRequest
// surfaces backend error messages via showToast(...) but doesn't return
// the message string to the caller, so we read from the DOM. This is
// best-effort — if the toast has already dismissed by the time we look,
// the inline banner just stays empty (the toast itself already covered
// the user). No fallback message is fabricated.
function _readLastToastMessage() {
    const container = document.getElementById('toast-container');
    if (!container) return '';
    const toasts = container.querySelectorAll('.toast');
    if (!toasts || toasts.length === 0) return '';
    const last = toasts[toasts.length - 1];
    return (last && last.textContent) || '';
}

// ============================================================
//  Toast notifications
//  (minimal copy from api-keys.js — same convention)
// ============================================================

function showToast(message, type = 'info') {
    const container = document.getElementById('toast-container');
    if (!container) return;

    // Deduplicate
    const existing = container.querySelectorAll('.toast');
    for (const t of existing) {
        if (t.textContent === message) return;
    }

    const toast = document.createElement('div');
    toast.className = 'toast toast--' + type;
    toast.textContent = message;
    container.appendChild(toast);

    requestAnimationFrame(() => toast.classList.add('toast--visible'));

    setTimeout(() => {
        toast.classList.remove('toast--visible');
        setTimeout(() => toast.remove(), 300);
    }, 4000);
}
