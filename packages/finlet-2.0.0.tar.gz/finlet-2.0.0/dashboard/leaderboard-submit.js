// TODO(2026-05-06): rename to leaderboard-table.js — submission write-path
// moved to legacy/dashboard-ui/leaderboard-submit.js during launch cut.

/* ============================================================
   Finlet — Leaderboard (post-launch-cut stub)

   The submit-agent-to-leaderboard write path was removed in the
   2026-05-06 launch cut (see docs/decisions/ui-removal-launch-cut.md).
   The full submission logic + DOM lives in legacy/dashboard-ui/.

   This file is retained as a no-op stub so that:
     - The <script src="leaderboard-submit.js"> tag in index.html can
       remain until Team B prunes the include in their app.js + index.html
       trim pass.
     - Any historical caller of initLeaderboardSubmitModal() (e.g. an
       app.js call site Team B has not yet removed) gets a safe no-op
       instead of a ReferenceError on page load.

   Once Team B has removed the include + the init call, this file
   should also be moved to legacy/.
   ============================================================ */

function initLeaderboardSubmitModal() {
    // No-op: submission logic removed in 2026-05-06 launch cut.
}
