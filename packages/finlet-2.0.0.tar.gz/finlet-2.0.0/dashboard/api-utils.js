/* ============================================================
   Finlet — Shared API Utilities & Theme System
   Single source of truth for API_BASE, auth headers, and
   HTTP helper functions used across all dashboard pages.

   Supports dual auth:
   - Cookie-based session auth (httpOnly cookie + CSRF token)
   - Bearer token auth (fallback for API/CLI clients)
   Cookie sessions are validated via GET /auth/session/validate.

   Also includes theme management (dark/light/system).
   ============================================================ */

const API_BASE = window.location.origin + '/v1';

// State-changing HTTP methods that need CSRF tokens
const _STATE_CHANGING_METHODS = ['POST', 'PUT', 'DELETE', 'PATCH'];

// Track whether a valid cookie session exists so we can skip
// Bearer headers when cookies are handling auth.
let _cookieSessionValid = null; // null = not checked yet

/**
 * Check if a cookie-based session is active.
 * Caches the result for the page lifetime (reset on logout).
 */
async function hasCookieSession() {
    if (_cookieSessionValid !== null) return _cookieSessionValid;
    try {
        const res = await fetch(API_BASE + '/auth/session/validate', {
            credentials: 'include',
        });
        _cookieSessionValid = res.ok;
    } catch {
        _cookieSessionValid = false;
    }
    return _cookieSessionValid;
}

/**
 * Invalidate the cached cookie session state (call on logout).
 */
function resetCookieSessionCache() {
    _cookieSessionValid = null;
}

/**
 * Prime the cookie-session cache without firing a network call.
 * Used by FinletAuth.ready() after it has already validated the session
 * via /auth/session/validate — avoids a redundant second round-trip.
 */
function primeCookieSessionCache(isValid) {
    _cookieSessionValid = !!isValid;
}

/**
 * Hydration barrier: resolves when the session + CSRF token are ready
 * for state-changing requests. Page init code MUST await this before
 * binding click handlers that trigger POST/PUT/DELETE/PATCH.
 *
 * Priority order:
 *   1. window.__finletAuthGuardReady (set by auth-guard.js) if present
 *   2. FinletAuth.ready() if available
 *   3. Fallback: resolve immediately (degrades to previous behaviour)
 *
 * Returns true if authenticated, false otherwise. Pages that cannot
 * operate without auth should redirect to auth.html on false.
 */
async function awaitAuthReady() {
    // Prefer the auth-guard barrier ONLY if it is a live (truthy) promise.
    // invalidateHydration() sets it to null on stale-hydration errors so
    // that we fall through to FinletAuth.ready() and re-hydrate. A plain
    // `typeof !== 'undefined'` check would match null and await a stale
    // resolved value, masking the invalidation.
    if (window.__finletAuthGuardReady) {
        try { return await window.__finletAuthGuardReady; }
        catch { return false; }
    }
    if (typeof FinletAuth !== 'undefined' && typeof FinletAuth.ready === 'function') {
        try { return await FinletAuth.ready(); }
        catch { return false; }
    }
    // No hydration primitive available — assume the page already has auth.
    return true;
}

/**
 * Read server config injected by ConfigInjectionMiddleware.
 * The middleware injects a <script type="application/json" id="finlet-config">
 * tag into every HTML response. This is pure data — the browser never executes it.
 */
function getServerConfig() {
    const el = document.getElementById('finlet-config');
    if (!el) return {};
    try { return JSON.parse(el.textContent); }
    catch { return {}; }
}

/**
 * Escape HTML entities for safe insertion into HTML content and attributes.
 * Handles <, >, &, ", and ' to prevent XSS.
 */
function esc(str) {
    if (!str) return '';
    const div = document.createElement('div');
    div.textContent = String(str);
    return div.innerHTML.replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}

/**
 * Validate and escape a URL. Only allows http:, https:, and mailto: schemes.
 * Returns empty string for invalid/dangerous URLs.
 */
function escUrl(url) {
    if (!url) return '';
    try {
        const parsed = new URL(url);
        if (!['http:', 'https:', 'mailto:'].includes(parsed.protocol)) {
            return '';
        }
        return esc(url);
    } catch {
        return esc(url); // Relative URLs are fine, just escape them
    }
}

/**
 * Returns auth headers for API requests.
 *
 * For cookie-authenticated sessions:
 * - Includes X-CSRF-Token for state-changing methods
 * - Includes X-Requested-With for all requests
 * - Skips Bearer token when cookie session is active
 *
 * For Bearer-authenticated requests (fallback):
 * - Includes Authorization header with API key
 *
 * @param {string} [method='GET'] - HTTP method (used to decide CSRF inclusion)
 */
function getAuthHeaders(method) {
    const headers = {
        'Content-Type': 'application/json',
        'X-Requested-With': 'XMLHttpRequest',
    };

    // Include CSRF token for state-changing methods if we have a session
    if (method && _STATE_CHANGING_METHODS.includes(method.toUpperCase())) {
        const csrfToken = (typeof FinletAuth !== 'undefined' && FinletAuth.getCsrfToken)
            ? FinletAuth.getCsrfToken()
            : null;
        if (csrfToken) {
            headers['X-CSRF-Token'] = csrfToken;
        }
    }

    // Skip Bearer token when cookie session is active
    if (_cookieSessionValid) return headers;

    // Include Bearer token as fallback (when no cookie session is active)
    const apiKey = (typeof FinletAuth !== 'undefined' && FinletAuth.getApiKey)
        ? FinletAuth.getApiKey()
        : null;
    if (apiKey) {
        headers['Authorization'] = 'Bearer ' + apiKey;
    }
    return headers;
}

/**
 * Build fetch options with credentials: 'include' for cookie auth.
 */
function _fetchOpts(extra) {
    return Object.assign({ credentials: 'include' }, extra);
}

/**
 * Authenticated GET request. Returns parsed JSON or null on error.
 * Uses credentials: 'include' to send session cookies.
 */
async function apiFetch(path) {
    try {
        const res = await fetch(API_BASE + path, {
            headers: getAuthHeaders('GET'),
            credentials: 'include',
        });
        if (!res.ok) {
            if (res.status === 401 || res.status === 403) {
                showToast('Authentication failed -- please sign in again', 'error');
            }
            return null;
        }
        return await res.json();
    } catch {
        return null;
    }
}

/**
 * Extract a human-readable error message from a JSON error body.
 * Supports both response shapes used across the API:
 *   - FastAPI default: {"detail": "..."}
 *   - Middleware/structured: {"error": {"code": "...", "message": "..."}}
 */
function _extractErrorMessage(errBody, status) {
    if (errBody) {
        if (errBody.detail) return errBody.detail;
        if (errBody.error) {
            if (errBody.error.message) return errBody.error.message;
            if (errBody.error.code) return errBody.error.code;
        }
    }
    return 'Request failed (' + status + ')';
}

// Error codes that indicate the client's hydration state is stale and
// should be refreshed before retrying. Set of codes returned by the
// CSRF middleware and session auth middleware.
const _STALE_HYDRATION_CODES = new Set([
    'csrf_token_missing',
    'csrf_token_invalid',
    'session_expired',
    'session_not_found',
    'session_invalid',
]);

/**
 * Decide whether a failing response indicates stale client hydration.
 * If so, the caller should invalidate the hydration promise and retry
 * once. A 403 with code=csrf_token_missing after a successful login
 * typically means the CSRF token was never hydrated (the bug we're
 * fixing); re-running /auth/session/validate unblocks it.
 */
function _isStaleHydrationError(status, errBody) {
    if (status !== 401 && status !== 403) return false;
    const code = errBody && errBody.error && errBody.error.code;
    if (code && _STALE_HYDRATION_CODES.has(code)) return true;
    // Bare 401 without a structured error body: also treat as stale so
    // one-tab-logout flows pick up the new state on the next mutation.
    if (status === 401 && !code) return true;
    return false;
}

/**
 * Invalidate FinletAuth hydration (forget the cached ready() promise
 * and in-memory CSRF) so the next ready() call re-runs
 * /v1/auth/session/validate. No-op if FinletAuth is not loaded.
 */
function _invalidateAuthHydration() {
    if (typeof FinletAuth !== 'undefined'
        && typeof FinletAuth.invalidateHydration === 'function') {
        try { FinletAuth.invalidateHydration(); } catch { /* ignore */ }
    }
}

/**
 * Low-level fetch with retry-once on stale CSRF/auth.
 *
 * Drop-in replacement for raw `fetch(path, {method,headers,body})` on
 * state-changing requests. Identical to plain `fetch` in the happy
 * path, but on a 401/403 whose body matches _STALE_HYDRATION_CODES it:
 *   1. Calls FinletAuth.invalidateHydration() (nulls hydration cache +
 *      auth-guard barrier).
 *   2. Awaits awaitAuthReady() to re-hydrate CSRF + session.
 *   3. Retries the request ONCE with fresh headers.
 *
 * Callers that supply their own `headers` in `options` keep the
 * supplied headers on the FIRST attempt exactly as-is. On RETRY the
 * headers are recomputed via getAuthHeaders(method) so the fresh
 * X-CSRF-Token is included even if the caller provided its own headers
 * object (which would be stale after invalidation).
 *
 * Returns a standard Response object. Because retrying would consume
 * `res.body`, on retry the body stream from the first attempt is
 * abandoned — callers must not rely on the first response's body
 * surviving a retry (they never could anyway, since retry means they
 * get the second response).
 *
 * @param {string} path  Path relative to API_BASE, e.g. "/settings/api-keys".
 *                       Also accepts an absolute URL.
 * @param {RequestInit} [options]  Standard fetch options.
 */
async function authFetch(path, options) {
    const opts = Object.assign({ credentials: 'include' }, options || {});
    const method = (opts.method || 'GET').toUpperCase();
    // Preserve caller headers on first attempt; recompute on retry.
    const url = path.startsWith('http') ? path : (API_BASE + path);

    let res = await fetch(url, opts);
    if (res.ok) return res;
    // Only retry on potential stale-hydration status codes to avoid
    // consuming the body on errors we don't know about.
    if (res.status !== 401 && res.status !== 403) return res;

    // Clone so the caller can still read the ORIGINAL response body if
    // we decide not to retry. fetch Response bodies are single-use.
    const clone = res.clone();
    const errBody = await clone.json().catch(() => null);
    if (!_isStaleHydrationError(res.status, errBody)) return res;

    // Stale hydration: drop cache, re-hydrate, retry once with fresh
    // auth headers. Preserve any caller-supplied body / method.
    _invalidateAuthHydration();
    const authOk = await awaitAuthReady();
    if (!authOk) return res;

    const retryOpts = Object.assign({}, opts, {
        headers: getAuthHeaders(method),
    });
    return fetch(url, retryOpts);
}

/**
 * Execute a fetch with cookie credentials. On a stale-hydration 401/403
 * (e.g. csrf_token_missing because the cached CSRF was rotated by the
 * server), invalidate the hydration promise, re-await awaitAuthReady(),
 * and retry the request ONCE with fresh headers. If the retry still
 * fails, surface the error.
 *
 * Returns { ok, status, body } for the caller to interpret. body is
 * the parsed JSON (may be null if the body is empty or unparseable).
 *
 * This is the high-level helper used by apiPost/apiRequest. For raw
 * fetch migration, use authFetch() above instead.
 */
async function _fetchWithAuthRetry(path, method, body) {
    const opts = { method, headers: getAuthHeaders(method) };
    if (body !== null && body !== undefined) opts.body = JSON.stringify(body);
    const res = await authFetch(path, opts);
    if (res.ok) return { ok: true, status: res.status, body: null, res };
    const errBody = await res.json().catch(() => null);
    return { ok: false, status: res.status, body: errBody, res };
}

/**
 * Authenticated POST request. Returns parsed JSON or null on error.
 * Uses credentials: 'include' to send session cookies.
 *
 * On 401/403 with a stale-hydration error code, transparently invalidates
 * the cached hydration promise, re-hydrates via /auth/session/validate,
 * and retries the request once before surfacing the error.
 */
async function apiPost(path, body = null) {
    try {
        const result = await _fetchWithAuthRetry(path, 'POST', body);
        if (result.ok) {
            return await result.res.json();
        }
        showToast(_extractErrorMessage(result.body, result.status), 'error');
        return null;
    } catch {
        showToast('Network error -- check your connection', 'error');
        return null;
    }
}

/**
 * Authenticated request with any HTTP method. Returns parsed JSON or null on error.
 * Uses credentials: 'include' to send session cookies.
 *
 * On 401/403 with a stale-hydration error code, transparently invalidates
 * the cached hydration promise, re-hydrates via /auth/session/validate,
 * and retries the request once before surfacing the error.
 */
async function apiRequest(path, method, body = null) {
    try {
        const result = await _fetchWithAuthRetry(path, method, body);
        if (result.ok) {
            if (result.res.status === 204) return {};
            return await result.res.json();
        }
        if (result.status === 401) {
            showToast('Authentication failed -- please sign in again', 'error');
            return null;
        }
        showToast(_extractErrorMessage(result.body, result.status), 'error');
        return null;
    } catch {
        showToast('Network error -- check your connection', 'error');
        return null;
    }
}

/**
 * Report client-side errors to the server for monitoring.
 */
function reportClientError(errorData) {
    try {
        const payload = JSON.stringify({
            type: errorData.type || 'js_error',
            message: errorData.message || 'Unknown error',
            source: errorData.source || '',
            lineno: errorData.lineno || 0,
            colno: errorData.colno || 0,
            stack: errorData.stack || '',
            url: window.location.href,
            timestamp: new Date().toISOString()
        });
        navigator.sendBeacon('/v1/telemetry/client-error', payload);
    } catch (e) {
        // Silently fail — error reporting should never cause errors
    }
}

// ============================================================
//  Trusted Types Policy (progressive enhancement)
//  Provides DOM XSS protection in browsers that support it.
//  Falls back gracefully — esc() still works everywhere.
// ============================================================

/** @type {TrustedTypePolicy|null} */
let _finletPolicy = null;

if (window.trustedTypes && window.trustedTypes.createPolicy) {
    // Named policy: gate for pre-sanitized HTML (already escaped via esc())
    _finletPolicy = window.trustedTypes.createPolicy('finlet-default', {
        createHTML: function(input) {
            // Input MUST already be sanitized (via esc()) or be a known-static string.
            // This policy acts as a trust boundary — it does NOT re-escape,
            // because callers build full HTML with tags + escaped user data.
            return input;
        },
        createScriptURL: function(input) {
            // Only allow same-origin and trusted CDN URLs
            try {
                const url = new URL(input, window.location.origin);
                const trusted = [window.location.origin, 'https://cdn.jsdelivr.net', 'https://accounts.google.com'];
                if (trusted.some(function(t) { return url.origin === t; })) {
                    return input;
                }
            } catch (_e) { /* fall through */ }
            console.warn('[Finlet] Blocked untrusted script URL:', input);
            return 'about:blank';
        },
    });

    // Default policy: catches any innerHTML assignment NOT routed through
    // the named policy. Logs a warning AND reports to server-side telemetry
    // so we get a production signal for any caller that bypassed trustedHTML().
    try {
        window.trustedTypes.createPolicy('default', {
            createHTML: function(input) {
                if (typeof console !== 'undefined' && console.warn) {
                    console.warn('[Finlet] Trusted Types default policy invoked — caller should use trustedHTML():', input.substring(0, 120));
                }
                try {
                    var stack = (new Error()).stack || '';
                    var frame = stack.split('\n')[2] || '';
                    reportClientError({
                        type: 'trusted_types_violation',
                        sink: 'createHTML',
                        message: typeof input === 'string' ? input.substring(0, 120) : '',
                        source: frame.trim(),
                    });
                } catch (_e) { /* never block render */ }
                // Still sanitize to prevent XSS, even for untracked callers
                return input;
            },
            createScript: function(input) {
                console.warn('[Finlet] Blocked inline script via default policy');
                try {
                    var stack = (new Error()).stack || '';
                    var frame = stack.split('\n')[2] || '';
                    reportClientError({
                        type: 'trusted_types_violation',
                        sink: 'createScript',
                        message: typeof input === 'string' ? input.substring(0, 120) : '',
                        source: frame.trim(),
                    });
                } catch (_e) { /* never block render */ }
                return '';
            },
            createScriptURL: function(input) {
                console.warn('[Finlet] Default policy script URL:', input.substring(0, 120));
                try {
                    var stack = (new Error()).stack || '';
                    var frame = stack.split('\n')[2] || '';
                    reportClientError({
                        type: 'trusted_types_violation',
                        sink: 'createScriptURL',
                        message: typeof input === 'string' ? input.substring(0, 120) : '',
                        source: frame.trim(),
                    });
                } catch (_e) { /* never block render */ }
                return input;
            },
        });
    } catch (_e) {
        // Default policy may already exist (e.g., from a library); that's OK.
    }
}

// ============================================================
//  CSP-side Trusted Types violation listener
//  Catches violations the runtime `default` policy doesn't see
//  (e.g., third-party policy creation blocked by the CSP allowlist,
//   like the goog#html regression). Filtered to TT-only — does NOT
//   report on script-src or other non-TT directives.
// ============================================================
document.addEventListener('securitypolicyviolation', function(e) {
    try {
        if (e.effectiveDirective === 'trusted-types' ||
            e.violatedDirective === 'trusted-types' ||
            e.effectiveDirective === 'require-trusted-types-for' ||
            e.violatedDirective === 'require-trusted-types-for') {
            reportClientError({
                type: 'trusted_types_violation',
                sink: 'csp_securitypolicyviolation',
                message: ((e.blockedURI || '') + ' ' + (e.sample || '')).substring(0, 200),
                source: (e.sourceFile || '') + ':' + (e.lineNumber || 0),
            });
        }
    } catch (_e) { /* never block render */ }
});

/**
 * Create a TrustedHTML value from a string that is already safe
 * (either escaped via esc() or a known-static HTML fragment).
 * Falls back to returning the raw string in browsers without Trusted Types.
 *
 * @param {string} html - Pre-escaped or static HTML string
 * @returns {TrustedHTML|string}
 */
function trustedHTML(html) {
    if (_finletPolicy) {
        return _finletPolicy.createHTML(html);
    }
    return html;
}

// Global error handler
window.addEventListener('error', function(event) {
    reportClientError({
        type: 'js_error',
        message: event.message,
        source: event.filename,
        lineno: event.lineno,
        colno: event.colno,
        stack: event.error ? event.error.stack : ''
    });
});

// Unhandled promise rejection handler
window.addEventListener('unhandledrejection', function(event) {
    reportClientError({
        type: 'unhandled_rejection',
        message: event.reason ? String(event.reason) : 'Unhandled promise rejection',
        stack: event.reason && event.reason.stack ? event.reason.stack : ''
    });
});

// ============================================================
//  Theme System
//  Manages dark/light/system theme across all dashboard pages.
//  localStorage key: finlet_theme (values: 'dark' | 'light' | 'system')
// ============================================================

/**
 * Resolve a theme preference to an effective theme ('dark' or 'light').
 * 'system' is resolved via matchMedia.
 */
function resolveTheme(preference) {
    if (preference === 'system') {
        return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
    }
    return preference === 'light' ? 'light' : 'dark';
}

/**
 * Apply a theme preference to the document.
 * Sets data-theme attribute on <html> which triggers CSS custom property overrides.
 * Also updates TradingView chart colors if a chart exists.
 *
 * @param {string} preference - 'dark', 'light', or 'system'
 */
function applyTheme(preference) {
    const effective = resolveTheme(preference);
    document.documentElement.setAttribute('data-theme', effective);

    // Update TradingView chart if it exists on this page
    _applyChartTheme(effective);
}

/**
 * Update TradingView Lightweight Charts colors to match the current theme.
 * No-op if no chart is present on the page.
 */
function _applyChartTheme(effective) {
    // equityChart is defined in app.js on the main dashboard page
    if (typeof equityChart === 'undefined' || !equityChart) return;

    const isDark = effective === 'dark';
    try {
        equityChart.applyOptions({
            layout: {
                background: { type: 'solid', color: isDark ? '#161b22' : '#f6f8fa' },
                textColor: isDark ? '#9198a1' : '#59636e',
            },
            grid: {
                vertLines: { color: isDark ? '#21262d' : '#e1e4e8' },
                horzLines: { color: isDark ? '#21262d' : '#e1e4e8' },
            },
            rightPriceScale: {
                borderColor: isDark ? '#30363d' : '#d0d7de',
            },
            timeScale: {
                borderColor: isDark ? '#30363d' : '#d0d7de',
            },
        });
    } catch (e) {
        console.warn('[Finlet] Could not update chart theme:', e);
    }
}

/**
 * Listen for OS-level color scheme changes.
 * Only fires a theme update when the user's preference is 'system'.
 */
const _systemThemeQuery = window.matchMedia('(prefers-color-scheme: dark)');
_systemThemeQuery.addEventListener('change', () => {
    const preference = localStorage.getItem('finlet_theme') || 'dark';
    if (preference === 'system') {
        applyTheme('system');
    }
});

// Apply theme on script load (runs before DOMContentLoaded to prevent flash)
(function initTheme() {
    const preference = localStorage.getItem('finlet_theme') || 'dark';
    applyTheme(preference);
})();
