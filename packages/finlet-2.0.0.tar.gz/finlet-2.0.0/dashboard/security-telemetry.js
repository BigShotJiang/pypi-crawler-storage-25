/* ============================================================
   Finlet — Client-Side Security Telemetry
   Observes long tasks and DOM mutations (injected scripts/styles)
   and reports suspicious activity via sendBeacon.
   ============================================================ */

(function () {
    'use strict';

    var TELEMETRY_URL = '/v1/telemetry/client-security';

    // ── Rate-limit counters ──────────────────────────────────
    var longTaskReportCount = 0;
    var LONG_TASK_MAX_REPORTS = 5;

    var mutationReportCount = 0;
    var MUTATION_MAX_REPORTS = 10;

    // ── Trusted origins for injected scripts/styles ──────────
    var TRUSTED_ORIGINS = [
        window.location.origin,
        'https://accounts.google.com',
        'https://cdn.jsdelivr.net'
    ];

    function isTrustedOrigin(url) {
        if (!url) return true; // inline or same-origin (no src)
        try {
            var parsed = new URL(url, window.location.origin);
            return TRUSTED_ORIGINS.some(function (origin) {
                return parsed.origin === origin;
            });
        } catch (_e) {
            return false;
        }
    }

    function send(payload) {
        if (typeof navigator.sendBeacon === 'function') {
            navigator.sendBeacon(
                TELEMETRY_URL,
                new Blob([JSON.stringify(payload)], { type: 'application/json' })
            );
        }
    }

    // ── Long Task Observer (P3-9) ────────────────────────────
    if (typeof PerformanceObserver !== 'undefined') {
        try {
            var longTaskObserver = new PerformanceObserver(function (list) {
                var entries = list.getEntries();
                for (var i = 0; i < entries.length; i++) {
                    if (entries[i].duration > 200 && longTaskReportCount < LONG_TASK_MAX_REPORTS) {
                        longTaskReportCount++;
                        send({
                            type: 'long_task',
                            details: {
                                duration: Math.round(entries[i].duration),
                                name: entries[i].name,
                                start_time: Math.round(entries[i].startTime)
                            },
                            url: window.location.href,
                            timestamp: new Date().toISOString()
                        });
                    }
                }
            });
            longTaskObserver.observe({ entryTypes: ['longtask'] });
        } catch (_e) {
            // Browser does not support longtask entry type — silently skip
        }
    }

    // ── Mutation Observer (P3-10) ────────────────────────────
    if (typeof MutationObserver !== 'undefined') {
        var mutationObserver = new MutationObserver(function (mutations) {
            for (var m = 0; m < mutations.length; m++) {
                var addedNodes = mutations[m].addedNodes;
                for (var n = 0; n < addedNodes.length; n++) {
                    var node = addedNodes[n];
                    if (node.nodeType !== 1) continue; // Element nodes only

                    var isScript = node.tagName === 'SCRIPT';
                    var isStylesheet = node.tagName === 'LINK' &&
                        (node.getAttribute('rel') || '').toLowerCase() === 'stylesheet';

                    if (!isScript && !isStylesheet) continue;

                    var src = isScript ? node.src : node.href;

                    if (src && !isTrustedOrigin(src)) {
                        // Attach error handler for untrusted resources
                        (function (element, resourceUrl) {
                            element.addEventListener('error', function () {
                                if (mutationReportCount < MUTATION_MAX_REPORTS) {
                                    mutationReportCount++;
                                    send({
                                        type: 'mutation_observer',
                                        details: {
                                            tag: element.tagName.toLowerCase(),
                                            src: resourceUrl.substring(0, 500),
                                            error: 'load_failed_untrusted_origin'
                                        },
                                        url: window.location.href,
                                        timestamp: new Date().toISOString()
                                    });
                                }
                            });
                        })(node, src);

                        // Also report the injection itself
                        if (mutationReportCount < MUTATION_MAX_REPORTS) {
                            mutationReportCount++;
                            send({
                                type: 'mutation_observer',
                                details: {
                                    tag: node.tagName.toLowerCase(),
                                    src: src.substring(0, 500),
                                    event: 'untrusted_resource_injected'
                                },
                                url: window.location.href,
                                timestamp: new Date().toISOString()
                            });
                        }
                    }
                }
            }
        });
        mutationObserver.observe(document.documentElement, { childList: true, subtree: true });
    }
})();
