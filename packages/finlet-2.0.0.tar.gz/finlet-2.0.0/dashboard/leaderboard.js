/* ============================================================
   Finlet Leaderboard — Application Logic (v3)
   Error Handling & UX Polish
   WCAG AA Compliant
   ============================================================ */

// API_BASE is defined in api-utils.js (includes /v1/ prefix)

document.addEventListener('DOMContentLoaded', async () => {
    // Await the hydration barrier so the leaderboard fetch carries the
    // X-CSRF-Token on any subsequent state-changing action bound by the
    // shared nav (e.g. submit-to-leaderboard modal).
    const authOk = await awaitAuthReady();
    if (!authOk) {
        if (typeof FinletAuth !== 'undefined' && !FinletAuth.isAuthenticated()) {
            window.location.replace('auth.html');
        }
        return;
    }

    initSharedNav({
        activePage: 'leaderboard',
        breadcrumbs: ['Dashboard', 'Leaderboard'],
    });
    fetchLeaderboard();
});

async function fetchLeaderboard() {
    const container = document.getElementById('leaderboard-content');

    try {
        const res = await fetch(`${API_BASE}/leaderboard`, { headers: getAuthHeaders() });

        if (!res.ok) {
            if (res.status === 401 || res.status === 403) {
                container.innerHTML = trustedHTML(`<div class="leaderboard-empty" role="status">
                    <div class="error-state__icon">
                        <svg width="32" height="32" viewBox="0 0 32 32" fill="none" aria-hidden="true"><circle cx="16" cy="16" r="14" stroke="var(--yellow)" stroke-width="1.5"/><path d="M16 10v8M16 22v0" stroke="var(--yellow)" stroke-width="2" stroke-linecap="round"/></svg>
                    </div>
                    Authentication required. Enter your <abbr title="Application Programming Interface">API</abbr> key on the <a href="index.html">dashboard</a>.
                </div>`);
                showToast('Authentication required', 'warning');
            } else if (res.status === 429) {
                container.innerHTML = trustedHTML('<div class="leaderboard-empty" role="status">Rate limited. Please try again shortly.</div>');
                showToast('Rate limited — please wait before retrying', 'warning');
            } else if (res.status >= 500) {
                container.innerHTML = trustedHTML(`<div class="leaderboard-empty" role="status">
                    Server error (${esc(String(res.status))}). Please try again later.
                    <br><button class="btn" data-action="retry-leaderboard" style="margin-top: 12px">Retry</button>
                </div>`);
                const retryBtn = container.querySelector('[data-action="retry-leaderboard"]');
                if (retryBtn) retryBtn.addEventListener('click', fetchLeaderboard);
                showToast('Server error loading leaderboard', 'error');
            } else {
                container.innerHTML = trustedHTML('<div class="leaderboard-empty" role="status">Leaderboard not available</div>');
            }
            console.warn(`[Finlet] Leaderboard fetch failed: ${res.status}`);
            return;
        }

        const data = await res.json();
        const entries = Array.isArray(data) ? data : (data.entries || data.leaderboard || []);

        if (!entries.length) {
            container.innerHTML = trustedHTML(`<div class="leaderboard-empty" role="status">
                <div class="empty-state">
                    <div class="empty-state__icon">
                        <svg width="48" height="48" viewBox="0 0 48 48" fill="none" aria-hidden="true">
                            <path d="M16 34V22M24 34V14M32 34V26" stroke="var(--text-muted)" stroke-width="2" stroke-linecap="round"/>
                            <path d="M24 8l3 5h-6l3-5z" fill="var(--text-muted)" opacity="0.5"/>
                        </svg>
                    </div>
                    <p class="empty-state__headline">No agents ranked yet</p>
                    <p class="empty-state__text">Create a trading session and run your AI agent to appear on the leaderboard.</p>
                    <div class="empty-state__methodology">
                        <strong>How scoring works</strong><br>
                        Strategies are ranked by risk-adjusted returns (Sharpe ratio), total return, and consistency. Complete more scenarios to improve your composite score.
                    </div>
                    <a href="index.html" class="empty-state__cta">
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
                        Create a session
                    </a>
                </div>
            </div>`);
            return;
        }

        renderLeaderboard(entries, container);
    } catch (err) {
        console.error('[Finlet] Leaderboard fetch error:', err);
        container.innerHTML = trustedHTML(`<div class="leaderboard-empty" role="status">
            Could not connect to <abbr title="Application Programming Interface">API</abbr> server.
            <br><button class="btn" data-action="retry-leaderboard" style="margin-top: 12px">Retry</button>
        </div>`);
        const retryBtn = container.querySelector('[data-action="retry-leaderboard"]');
        if (retryBtn) retryBtn.addEventListener('click', fetchLeaderboard);
        showToast('Unable to reach server', 'error');
    }
}

function renderLeaderboard(entries, container) {
    // Sort by composite score descending
    entries.sort((a, b) => (b.composite_score ?? 0) - (a.composite_score ?? 0));

    const html = `
        <table class="leaderboard-table" aria-label="Agent leaderboard ranked by composite score">
            <caption class="sr-only">AI trading agent leaderboard showing rank, agent name, composite score, strategy, Sharpe ratio, total return, and max drawdown</caption>
            <thead>
                <tr>
                    <th scope="col">Rank</th>
                    <th scope="col">Agent</th>
                    <th scope="col" aria-sort="descending">Score</th>
                    <th scope="col">Sharpe</th>
                    <th scope="col">Strategy</th>
                    <th scope="col">Return</th>
                    <th scope="col">Drawdown</th>
                </tr>
            </thead>
            <tbody>
                ${entries.map((entry, i) => renderRow(entry, i)).join('')}
            </tbody>
        </table>
    `;

    container.innerHTML = trustedHTML(html);

    // Bind row click/keyboard handlers for agent profile view
    container.querySelectorAll('.leaderboard-row[data-agent-id]').forEach((row) => {
        row.addEventListener('click', () => {
            const agentId = row.getAttribute('data-agent-id');
            if (agentId) openAgentProfile(agentId);
        });
        row.addEventListener('keydown', (e) => {
            if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                const agentId = row.getAttribute('data-agent-id');
                if (agentId) openAgentProfile(agentId);
            }
        });
    });
}

function renderRow(entry, index) {
    const rank = index + 1;
    const rankClass = rank === 1 ? 'rank-cell--gold'
        : rank === 2 ? 'rank-cell--silver'
        : rank === 3 ? 'rank-cell--bronze'
        : '';
    const rankLabel = rank === 1 ? ' (Gold)'
        : rank === 2 ? ' (Silver)'
        : rank === 3 ? ' (Bronze)'
        : '';

    const agentName = esc(entry.agent_name || entry.name || 'Unknown');
    const model = esc(entry.model || entry.model_used || '');
    const score = entry.composite_score ?? 0;
    const strategy = esc(entry.strategy_category || entry.strategy || '');

    // Sharpe / return / drawdown metrics (populated when scenarios have run).
    // total_return_pct is stored as a percent (10.0 = 10%); max_drawdown_pct
    // is rescaled to percent server-side. Render with sign for return.
    const sharpe = entry.sharpe_ratio != null
        ? entry.sharpe_ratio.toFixed(2)
        : '--';
    const totalReturn = entry.total_return_pct != null
        ? `${entry.total_return_pct >= 0 ? '+' : ''}${entry.total_return_pct.toFixed(1)}%`
        : '--';
    const maxDrawdown = entry.max_drawdown_pct != null
        ? `-${entry.max_drawdown_pct.toFixed(1)}%`
        : '--';
    const returnClass = entry.total_return_pct != null
        ? (entry.total_return_pct >= 0 ? 'pnl-positive' : 'pnl-negative')
        : '';
    const drawdownClass = entry.max_drawdown_pct != null
        ? (entry.max_drawdown_pct > 0 ? 'pnl-negative' : '')
        : '';

    // Benchmark badge: entries with per_scenario_scores are benchmark-evaluated
    const hasBenchmark = (entry.per_scenario_scores && entry.per_scenario_scores.length > 0)
        || (entry.scenario_scores && entry.scenario_scores.length > 0);
    const benchmarkBadge = hasBenchmark
        ? '<span class="benchmark-badge" title="Evaluated via standardized benchmark scenarios">Benchmark</span>'
        : '';

    const agentId = esc(entry.id || '');

    return `<tr class="leaderboard-row" data-agent-id="${agentId}" role="button" tabindex="0" aria-label="View profile for ${esc(agentName)}">
        <td class="rank-cell ${rankClass}"><span aria-label="Rank ${rank}${rankLabel}">${rank}</span></td>
        <td>
            <div class="agent-name">${agentName} ${benchmarkBadge}</div>
            ${model ? `<div class="model-tag">${model}</div>` : ''}
        </td>
        <td class="score-cell">${score.toFixed(1)}</td>
        <td class="stat-cell">${sharpe}</td>
        <td>${strategy ? `<span class="strategy-tag">${strategy}</span>` : '--'}</td>
        <td class="stat-cell ${returnClass}">${totalReturn}</td>
        <td class="stat-cell ${drawdownClass}">${maxDrawdown}</td>
    </tr>`;
}

// ---- Agent Profile View ----

/**
 * Open the agent profile panel and fetch detailed profile data.
 * Hides the leaderboard table and shows the profile panel.
 */
async function openAgentProfile(agentId) {
    const contentEl = document.getElementById('leaderboard-content');
    const profilePanel = document.getElementById('agent-profile-panel');
    const profileBody = document.getElementById('agent-profile-body');
    const backBtn = document.getElementById('agent-profile-back');

    if (!contentEl || !profilePanel || !profileBody) return;

    // Hide leaderboard, show profile panel
    contentEl.style.display = 'none';
    profilePanel.style.display = '';
    profileBody.innerHTML = trustedHTML('<div class="leaderboard-loading" role="status">Loading agent profile...</div>');

    // Bind back button
    if (backBtn) {
        backBtn.onclick = function() {
            profilePanel.style.display = 'none';
            contentEl.style.display = '';
        };
    }

    // Fetch profile
    const profile = await apiFetch('/leaderboard/agents/' + encodeURIComponent(agentId));

    if (!profile) {
        profileBody.innerHTML = trustedHTML('<div class="leaderboard-empty" role="status">Could not load agent profile.</div>');
        return;
    }

    renderAgentProfile(profile, profileBody);
}

/**
 * Render the full agent profile view with per-scenario breakdown.
 */
function renderAgentProfile(profile, container) {
    const name = esc(profile.agent_name || 'Unknown');
    const model = esc(profile.model_used || '');
    const description = esc(profile.description || '');
    const strategy = esc(profile.strategy_category || '');
    const score = (profile.composite_score ?? 0).toFixed(2);
    const rank = profile.rank != null ? '#' + profile.rank : '--';
    const submittedAt = profile.submitted_at ? new Date(profile.submitted_at).toLocaleDateString() : '--';

    const scenarios = profile.per_scenario_scores || [];
    const hasBenchmark = scenarios.length > 0;

    const html = `
        <div class="agent-profile-card">
            <div class="agent-profile-card__header">
                <div>
                    <h2 class="agent-profile-card__name">${name}
                        ${hasBenchmark ? '<span class="benchmark-badge" title="Evaluated via standardized benchmark scenarios">Benchmark</span>' : ''}
                    </h2>
                    ${model ? `<div class="model-tag">${model}</div>` : ''}
                    ${description ? `<p class="agent-profile-card__desc">${description}</p>` : ''}
                </div>
                <div class="agent-profile-card__score-block">
                    <div class="agent-profile-card__score-label">Composite Score</div>
                    <div class="agent-profile-card__score-value">${esc(score)}</div>
                </div>
            </div>

            <div class="agent-profile-card__meta">
                <span class="agent-profile-card__meta-item">Rank: <strong>${esc(rank)}</strong></span>
                ${strategy ? `<span class="agent-profile-card__meta-item">Strategy: <span class="strategy-tag">${strategy}</span></span>` : ''}
                <span class="agent-profile-card__meta-item">Submitted: <strong>${esc(submittedAt)}</strong></span>
            </div>

            ${hasBenchmark ? renderScenarioBreakdown(scenarios) : '<div class="agent-profile-card__no-scenarios"><p>No per-scenario benchmark data available. This agent was submitted via legacy self-play.</p></div>'}
        </div>
    `;

    container.innerHTML = trustedHTML(html);
}

/**
 * Render the per-scenario breakdown table.
 * Color-codes performance: green for good, yellow for moderate, red for poor.
 */
function renderScenarioBreakdown(scenarios) {
    if (!scenarios || !scenarios.length) return '';

    const rows = scenarios.map((s) => {
        const scenarioId = esc(s.scenario_id || '--');
        const totalReturn = s.total_return_pct ?? 0;
        const sharpe = s.sharpe_ratio ?? 0;
        const maxDrawdown = s.max_drawdown ?? 0;
        const finalValue = s.final_value ?? 0;
        const reasoning = s.reasoning_score ?? 0;

        // Color coding based on performance thresholds
        const returnClass = totalReturn >= 5 ? 'scenario-metric--good'
            : totalReturn >= 0 ? 'scenario-metric--moderate'
            : 'scenario-metric--poor';
        const sharpeClass = sharpe >= 1.0 ? 'scenario-metric--good'
            : sharpe >= 0 ? 'scenario-metric--moderate'
            : 'scenario-metric--poor';
        const drawdownClass = maxDrawdown <= 10 ? 'scenario-metric--good'
            : maxDrawdown <= 20 ? 'scenario-metric--moderate'
            : 'scenario-metric--poor';

        return `<tr>
            <td class="scenario-id-cell">${scenarioId}</td>
            <td class="stat-cell ${returnClass}">${totalReturn.toFixed(2)}%</td>
            <td class="stat-cell ${sharpeClass}">${sharpe.toFixed(2)}</td>
            <td class="stat-cell ${drawdownClass}">${maxDrawdown.toFixed(2)}%</td>
            <td class="stat-cell">$${finalValue.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</td>
            <td class="stat-cell">${reasoning.toFixed(1)}</td>
        </tr>`;
    }).join('');

    return `
        <div class="scenario-breakdown">
            <h3 class="scenario-breakdown__title">Per-Scenario Breakdown</h3>
            <div class="scenario-breakdown__table-wrap">
                <table class="scenario-breakdown__table" aria-label="Per-scenario benchmark results">
                    <caption class="sr-only">Performance metrics for each benchmark scenario</caption>
                    <thead>
                        <tr>
                            <th scope="col">Scenario</th>
                            <th scope="col">Return</th>
                            <th scope="col">Sharpe</th>
                            <th scope="col">Max Drawdown</th>
                            <th scope="col">Final Value</th>
                            <th scope="col">Reasoning</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${rows}
                    </tbody>
                </table>
            </div>
            <div class="scenario-breakdown__legend">
                <span class="scenario-legend-item"><span class="scenario-legend-dot scenario-legend-dot--good"></span> Strong</span>
                <span class="scenario-legend-item"><span class="scenario-legend-dot scenario-legend-dot--moderate"></span> Moderate</span>
                <span class="scenario-legend-item"><span class="scenario-legend-dot scenario-legend-dot--poor"></span> Weak</span>
            </div>
        </div>
    `;
}

// ---- Simple toast for leaderboard page ----
function showToast(message, type) {
    const container = document.getElementById('toast-container');
    if (!container) return;

    // Deduplicate
    for (const t of container.querySelectorAll('.toast')) {
        if (t.querySelector('.toast__message')?.textContent === message) return;
    }

    const toast = document.createElement('div');
    toast.className = `toast toast--${type || 'info'}`;
    toast.setAttribute('role', 'alert');
    toast.innerHTML = trustedHTML(`
        <div class="toast__content">
            <div class="toast__message">${esc(message)}</div>
        </div>
        <button class="toast__close" aria-label="Dismiss">&times;</button>
    `);

    toast.querySelector('.toast__close').addEventListener('click', () => {
        toast.classList.remove('toast--visible');
        setTimeout(() => toast.remove(), 300);
    });

    container.appendChild(toast);
    requestAnimationFrame(() => {
        requestAnimationFrame(() => toast.classList.add('toast--visible'));
    });

    if (type !== 'error') {
        setTimeout(() => {
            toast.classList.remove('toast--visible');
            setTimeout(() => toast.remove(), 300);
        }, 5000);
    }
}
