/* ============================================================
   Finlet Auth — Client-Side Logic
   Redesigned: Google on top, email+password, 6-segment OTP,
   forgot-password flow, backup codes display.
   ============================================================ */

(function () {
    'use strict';

    var API_BASE = window.location.origin + '/v1';

    // ---- Auth State ----
    var AUTH_STORAGE_KEY = 'finlet_api_key';  // sessionStorage marker key
    var AUTH_USER_KEY = 'finlet_user';
    var AUTH_EXPIRY_KEY = 'finlet_auth_expiry';  // legacy localStorage cleanup

    // ---- Session Auth State (in-memory only — never in localStorage) ----
    var _csrfToken = null;
    var _hasSessionCookie = false;

    // ---- Hydration barrier ----
    // Single in-flight validation promise. Multiple concurrent callers of
    // requireAuth()/ready() share one /v1/auth/session/validate round-trip
    // instead of racing and double-firing the network request.
    var _hydrationPromise = null;

    // ---- DOM References (resolved on DOMContentLoaded) ----
    var els = {};

    // ---- MFA State ----
    var mfaSession = null;
    var mfaMethods = [];
    var mfaCurrentMethod = null;
    var pendingApiKey = null;

    // ---- Forgot Password State ----
    var forgotCurrentStep = 'email'; // 'email' | 'code' | 'newpw' | 'success'
    var _forgotResetCode = null;     // 6-digit code collected in the 'code' step

    // ---- Auth Config ----
    var authConfig = { google_enabled: false, sms_enabled: false };

    // ---- Google Sign-In retry tracking ----
    var googleInitRetries = 0;
    var GOOGLE_MAX_RETRIES = 10;

    // ---- In-memory API key for fallback ----
    var _inMemoryApiKey = null;

    // ============================================================
    // Init
    // ============================================================
    document.addEventListener('DOMContentLoaded', async function () {
        // If already authenticated and on auth page, validate server-side before redirect
        if (isAuthenticated() && window.location.pathname.endsWith('auth.html')) {
            var valid = await validateStoredAuth();
            if (valid) {
                redirectToDashboard();
                return;
            }
        }

        cacheElements();
        bindTabs();
        bindForms();
        bindToggles();
        bindLinks();
        bindMfa();
        bindForgotPassword();
        bindBackupCodes();
        initAllOtpGroups();
        applyDefaultTabFromUrl();

        // Load auth config to determine which features are available
        await loadAuthConfig();

        // Focus the first input
        var activeForm = document.querySelector('.auth-form--active');
        if (activeForm) {
            var firstInput = activeForm.querySelector('input:not([type="hidden"]):not([type="checkbox"])');
            if (firstInput) firstInput.focus();
        }
    });

    function cacheElements() {
        els = {
            // Tabs
            tabLogin: document.getElementById('tab-login'),
            tabSignup: document.getElementById('tab-signup'),
            authTabs: document.querySelector('.auth-tabs'),
            // Forms
            formLogin: document.getElementById('form-login'),
            formSignup: document.getElementById('form-signup'),
            formForgot: document.getElementById('form-forgot'),
            formMfa: document.getElementById('form-mfa'),
            formBackupCodes: document.getElementById('form-backup-codes'),
            // Login
            loginEmail: document.getElementById('login-email'),
            loginEmailError: document.getElementById('login-email-error'),
            loginPassword: document.getElementById('login-password'),
            loginPasswordError: document.getElementById('login-password-error'),
            loginAlert: document.getElementById('login-alert'),
            loginBtn: document.getElementById('login-btn'),
            // Signup
            signupEmail: document.getElementById('signup-email'),
            signupPassword: document.getElementById('signup-password'),
            signupResearch: document.getElementById('signup-research'),
            signupTerms: document.getElementById('signup-terms'),
            signupEmailError: document.getElementById('signup-email-error'),
            signupPasswordError: document.getElementById('signup-password-error'),
            signupTermsError: document.getElementById('signup-terms-error'),
            signupAlert: document.getElementById('signup-alert'),
            signupBtn: document.getElementById('signup-btn'),
            signupSuccess: document.getElementById('signup-success'),
            signupFields: document.getElementById('signup-fields'),
            signupStrengthFill: document.getElementById('signup-strength-fill'),
            signupStrengthLabel: document.getElementById('signup-strength-label'),
            signupPasswordStrength: document.getElementById('signup-password-strength'),
            goToDashboardBtn: document.getElementById('go-to-dashboard-btn'),
            // Forgot Password
            forgotEmail: document.getElementById('forgot-email'),
            forgotEmailError: document.getElementById('forgot-email-error'),
            forgotAlert: document.getElementById('forgot-alert'),
            forgotSendBtn: document.getElementById('forgot-send-btn'),
            forgotStepEmail: document.getElementById('forgot-step-email'),
            forgotStepCode: document.getElementById('forgot-step-code'),
            forgotStepNewpw: document.getElementById('forgot-step-newpw'),
            forgotStepSuccess: document.getElementById('forgot-step-success'),
            forgotOtpGroup: document.getElementById('forgot-otp-group'),
            forgotCodeError: document.getElementById('forgot-code-error'),
            forgotVerifyBtn: document.getElementById('forgot-verify-btn'),
            forgotResendBtn: document.getElementById('forgot-resend-btn'),
            forgotNewPassword: document.getElementById('forgot-new-password'),
            forgotNewpwError: document.getElementById('forgot-newpw-error'),
            forgotResetBtn: document.getElementById('forgot-reset-btn'),
            forgotGoLoginBtn: document.getElementById('forgot-go-login-btn'),
            forgotBackToLogin: document.getElementById('forgot-back-to-login'),
            // MFA
            mfaAlert: document.getElementById('mfa-alert'),
            mfaMethodSelector: document.getElementById('mfa-method-selector'),
            mfaMethodTabs: document.getElementById('mfa-method-tabs'),
            mfaTotpInput: document.getElementById('mfa-totp-input'),
            mfaTotpOtpGroup: document.getElementById('mfa-totp-otp-group'),
            mfaTotpError: document.getElementById('mfa-totp-error'),
            mfaSmsInput: document.getElementById('mfa-sms-input'),
            mfaSendSmsBtn: document.getElementById('mfa-send-sms-btn'),
            mfaSmsCodeField: document.getElementById('mfa-sms-code-field'),
            mfaSmsOtpGroup: document.getElementById('mfa-sms-otp-group'),
            mfaSmsError: document.getElementById('mfa-sms-error'),
            mfaBackupInput: document.getElementById('mfa-backup-input'),
            mfaBackupCode: document.getElementById('mfa-backup-code'),
            mfaBackupError: document.getElementById('mfa-backup-error'),
            mfaVerifyBtn: document.getElementById('mfa-verify-btn'),
            mfaUseBackup: document.getElementById('mfa-use-backup'),
            mfaBackToLogin: document.getElementById('mfa-back-to-login'),
            mfaRememberDevice: document.getElementById('mfa-remember-device'),
            // Google
            googleSigninLogin: document.getElementById('google-signin-login'),
            googleSigninSignup: document.getElementById('google-signin-signup'),
            googleLoginBtn: document.getElementById('google-login-btn'),
            googleSignupBtn: document.getElementById('google-signup-btn'),
            // Backup Codes
            backupCodesGrid: document.getElementById('backup-codes-grid'),
            backupDownloadBtn: document.getElementById('backup-download-btn'),
            backupCopyBtn: document.getElementById('backup-copy-btn'),
            backupContinueBtn: document.getElementById('backup-continue-btn'),
        };
    }

    // ============================================================
    // OTP 6-Segment Input Logic
    // ============================================================
    function initAllOtpGroups() {
        var groups = document.querySelectorAll('.otp-input-group');
        groups.forEach(function (group) {
            initOtpGroup(group);
        });
    }

    function initOtpGroup(group) {
        var inputs = group.querySelectorAll('.otp-input');
        inputs.forEach(function (input, idx) {
            input.addEventListener('input', function (e) {
                var val = input.value.replace(/[^0-9]/g, '');
                input.value = val ? val[0] : '';

                // Clear error state
                inputs.forEach(function (inp) { inp.classList.remove('otp-input--error'); });
                var errorEl = group.parentElement.querySelector('.auth-field-error');
                if (errorEl) {
                    errorEl.textContent = '';
                    errorEl.classList.remove('auth-field-error--visible');
                }

                // Update filled state
                if (val) {
                    input.classList.add('otp-input--filled');
                } else {
                    input.classList.remove('otp-input--filled');
                }

                // Auto-advance to next input
                if (val && idx < inputs.length - 1) {
                    inputs[idx + 1].focus();
                }

                // Auto-submit when all 6 digits entered
                if (val && idx === inputs.length - 1) {
                    var code = getOtpValue(group);
                    if (/^\d{6}$/.test(code)) {
                        // Trigger form submission or callback
                        var submitEvent = new CustomEvent('otp-complete', { detail: { code: code } });
                        group.dispatchEvent(submitEvent);
                    }
                }
            });

            input.addEventListener('keydown', function (e) {
                // Backspace: clear current and move back
                if (e.key === 'Backspace') {
                    if (!input.value && idx > 0) {
                        e.preventDefault();
                        inputs[idx - 1].value = '';
                        inputs[idx - 1].classList.remove('otp-input--filled');
                        inputs[idx - 1].focus();
                    } else {
                        input.classList.remove('otp-input--filled');
                    }
                }
                // Left arrow
                if (e.key === 'ArrowLeft' && idx > 0) {
                    e.preventDefault();
                    inputs[idx - 1].focus();
                }
                // Right arrow
                if (e.key === 'ArrowRight' && idx < inputs.length - 1) {
                    e.preventDefault();
                    inputs[idx + 1].focus();
                }
            });

            // Handle paste — distribute digits across boxes
            input.addEventListener('paste', function (e) {
                e.preventDefault();
                var paste = (e.clipboardData || window.clipboardData).getData('text');
                var digits = paste.replace(/[^0-9]/g, '');
                if (!digits) return;

                for (var i = 0; i < inputs.length && i < digits.length; i++) {
                    inputs[i].value = digits[i];
                    inputs[i].classList.add('otp-input--filled');
                }
                // Focus last filled or the next empty
                var focusIdx = Math.min(digits.length, inputs.length) - 1;
                if (focusIdx < inputs.length - 1) focusIdx++;
                inputs[focusIdx].focus();

                // Auto-submit if all 6 digits pasted
                if (digits.length >= 6) {
                    var code = getOtpValue(group);
                    if (/^\d{6}$/.test(code)) {
                        var submitEvent = new CustomEvent('otp-complete', { detail: { code: code } });
                        group.dispatchEvent(submitEvent);
                    }
                }
            });

            // Select all text on focus for easy overwrite
            input.addEventListener('focus', function () {
                input.select();
            });
        });
    }

    function getOtpValue(group) {
        var inputs = group.querySelectorAll('.otp-input');
        var code = '';
        inputs.forEach(function (inp) { code += inp.value; });
        return code;
    }

    function clearOtpGroup(group) {
        if (!group) return;
        var inputs = group.querySelectorAll('.otp-input');
        inputs.forEach(function (inp) {
            inp.value = '';
            inp.classList.remove('otp-input--filled', 'otp-input--error');
        });
    }

    function setOtpError(group) {
        if (!group) return;
        var inputs = group.querySelectorAll('.otp-input');
        inputs.forEach(function (inp) {
            inp.classList.add('otp-input--error');
        });
    }

    // ============================================================
    // Authentication Helpers
    // ============================================================
    function isAuthenticated() {
        if (_hasSessionCookie && _csrfToken) return true;
        var marker = sessionStorage.getItem(AUTH_STORAGE_KEY);
        if (marker) {
            // Restore CSRF token from sessionStorage after page navigation
            if (!_csrfToken) {
                var storedCsrf = sessionStorage.getItem('finlet_csrf');
                if (storedCsrf) _csrfToken = storedCsrf;
            }
            _hasSessionCookie = true;
            return true;
        }
        var legacyKey = localStorage.getItem(AUTH_STORAGE_KEY);
        var expiry = localStorage.getItem(AUTH_EXPIRY_KEY);
        if (!legacyKey) return false;
        if (expiry && Date.now() > parseInt(expiry, 10)) {
            clearAuth();
            return false;
        }
        return true;
    }

    async function validateStoredAuth() {
        try {
            var sessionRes = await fetch(API_BASE + '/auth/session/validate', {
                credentials: 'include',
            });
            if (sessionRes.ok) {
                // /v1/auth/session/validate is a probe: it returns 200 with
                // {"valid": false} for unauthenticated/stale-cookie callers
                // (no 401 spam on dashboard load — see auth-validate-401
                // regression class). We MUST inspect the body to distinguish
                // an authenticated session from an anonymous probe response.
                var sessionData = await sessionRes.json().catch(function () { return {}; });
                if (sessionData && sessionData.valid === true) {
                    _hasSessionCookie = true;
                    if (sessionData.csrf_token) {
                        _csrfToken = sessionData.csrf_token;
                        sessionStorage.setItem('finlet_csrf', _csrfToken);
                    }
                    return true;
                }
            }
        } catch (_e) {
            // Fall through
        }

        var key = localStorage.getItem(AUTH_STORAGE_KEY);
        if (!key) return false;
        try {
            var res = await fetch(API_BASE + '/auth/me', {
                headers: { 'Authorization': 'Bearer ' + key },
            });
            if (res.ok) return true;
            clearAuth();
            return false;
        } catch (_e) {
            return true;
        }
    }

    async function saveAuth(apiKey, user) {
        if (user) {
            sessionStorage.setItem(AUTH_USER_KEY, JSON.stringify(user));
        }

        try {
            var res = await fetch(API_BASE + '/auth/session', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                credentials: 'include',
                body: JSON.stringify({ api_key: apiKey }),
            });
            if (res.ok) {
                var data = await res.json();
                _csrfToken = data.csrf_token;
                _hasSessionCookie = true;
                sessionStorage.setItem(AUTH_STORAGE_KEY, 'cookie');
                if (_csrfToken) sessionStorage.setItem('finlet_csrf', _csrfToken);
                localStorage.removeItem(AUTH_STORAGE_KEY);
                localStorage.removeItem(AUTH_EXPIRY_KEY);
                _publishAuthStateChange();
                return;
            }
        } catch (_e) {
            // Fall back
        }

        sessionStorage.setItem(AUTH_STORAGE_KEY, 'memory');
        _inMemoryApiKey = apiKey;
        localStorage.removeItem(AUTH_STORAGE_KEY);
        localStorage.removeItem(AUTH_EXPIRY_KEY);
        _publishAuthStateChange();
    }

    function clearAuth() {
        _csrfToken = null;
        _hasSessionCookie = false;
        _hydrationPromise = null;
        sessionStorage.removeItem(AUTH_STORAGE_KEY);
        sessionStorage.removeItem(AUTH_USER_KEY);
        sessionStorage.removeItem('finlet_csrf');
        _inMemoryApiKey = null;
        localStorage.removeItem(AUTH_STORAGE_KEY);
        localStorage.removeItem(AUTH_EXPIRY_KEY);
        if (typeof resetCookieSessionCache === 'function') {
            resetCookieSessionCache();
        }
        fetch(API_BASE + '/auth/session', {
            method: 'DELETE',
            credentials: 'include',
        }).catch(function () { /* ignore */ });
        _publishAuthStateChange();
    }

    /**
     * Publish `auth:state-change` so consumers (currently
     * `dashboard/shared-nav.js` — the API-key affordance umbrella)
     * can repaint atomically when `_inMemoryApiKey` truthiness flips.
     *
     * Reads `FinletAuth.getApiKey()` (not the private `_inMemoryApiKey`
     * directly) so the publisher reflects the same source-of-truth the
     * subscriber reads — including the `sessionStorage.finlet_created_api_key`
     * fallback path. Defensively guarded: `auth.js` loads before
     * `event-bus.js` in `index.html`, so at module-eval time
     * `window.finletBus` is undefined; by the time `saveAuth` /
     * `clearAuth` actually run the bus IIFE has executed.
     *
     * Payload contract: `{ hasKey: boolean }` — see
     * `dashboard/event-contract.md` `auth:state-change` section.
     */
    function _publishAuthStateChange() {
        try {
            if (typeof window === 'undefined') return;
            if (!window.finletBus || typeof window.finletBus.publish !== 'function') return;
            var hasKey = !!(window.FinletAuth && typeof window.FinletAuth.getApiKey === 'function'
                && window.FinletAuth.getApiKey());
            window.finletBus.publish('auth:state-change', { hasKey: hasKey });
        } catch (_e) {
            // Bus failure must never break auth flow.
        }
    }

    async function logoutWithSession() {
        try {
            await fetch(API_BASE + '/auth/session', {
                method: 'DELETE',
                credentials: 'include',
                headers: {
                    'X-CSRF-Token': _csrfToken || '',
                    'X-Requested-With': 'XMLHttpRequest',
                },
            });
        } catch (_e) {
            // Best-effort
        }
        clearAuth();
    }

    function getStoredUser() {
        try {
            var raw = sessionStorage.getItem(AUTH_USER_KEY);
            return raw ? JSON.parse(raw) : null;
        } catch (_e) {
            return null;
        }
    }

    // ============================================================
    // Post-signup intent: subscribe to a paid tier (pricing.html → auth.html)
    //
    // The pricing.html Builder Subscribe button bounces anonymous visitors
    // here with `?from=signup&intent=subscribe&tier=builder`. After a
    // successful signup + saveAuth, this helper immediately POSTs to
    // /v1/billing/checkout and redirects to Stripe Checkout. On any
    // failure (Stripe not configured, allowlist mismatch, network) we
    // return false so the normal success state still renders and the
    // user can retry from billing.html.
    //
    // Returns: true if the redirect-to-Stripe was kicked off (caller
    // should NOT render the success card), false otherwise.
    // ============================================================
    async function _maybeStartIntentCheckout() {
        try {
            var params = new URLSearchParams(window.location.search);
            var intent = params.get('intent');
            if (intent !== 'subscribe') return false;
            var tier = (params.get('tier') || 'builder').toLowerCase();
            // Only allow tiers the backend currently exposes for self-serve checkout.
            if (tier !== 'builder') return false;

            var origin = window.location.origin;
            var body = {
                tier: tier,
                success_url: origin + '/billing.html?checkout=success',
                cancel_url: origin + '/pricing.html?checkout=canceled',
            };

            var headers = { 'Content-Type': 'application/json', 'X-Requested-With': 'XMLHttpRequest' };
            if (_csrfToken) headers['X-CSRF-Token'] = _csrfToken;

            var res = await fetch(API_BASE + '/billing/checkout', {
                method: 'POST',
                headers: headers,
                credentials: 'include',
                body: JSON.stringify(body),
            });

            if (!res.ok) return false;
            var data = await res.json().catch(function () { return null; });
            if (!data || !data.checkout_url) return false;

            window.location.href = data.checkout_url;
            return true;
        } catch (_e) {
            return false;
        }
    }

    function redirectToDashboard() {
        // If the caller arrived with a ?next= query param (e.g., redirected
        // here by /oauth/authorize when no session was present), honor it
        // ONLY if it parses to a same-origin URL.  Without the origin
        // check this would be an open-redirect bug.
        try {
            var rawNext = new URLSearchParams(window.location.search).get('next');
            if (rawNext) {
                var parsed = new URL(rawNext, window.location.origin);
                if (parsed.origin === window.location.origin) {
                    window.location.assign(parsed.href);
                    return;
                }
            }
        } catch (_e) {
            // Malformed ?next= → fall through to default.
        }
        window.location.href = 'index.html';
    }

    // ============================================================
    // Tab Switching
    // ============================================================
    function bindTabs() {
        var tabs = document.querySelectorAll('.auth-tab');
        tabs.forEach(function (tab) {
            tab.addEventListener('click', function () { switchTab(tab.dataset.tab); });
            tab.addEventListener('keydown', function (e) {
                if (e.key === 'ArrowRight' || e.key === 'ArrowLeft') {
                    e.preventDefault();
                    var allTabs = Array.from(tabs);
                    var idx = allTabs.indexOf(tab);
                    var next = e.key === 'ArrowRight'
                        ? allTabs[(idx + 1) % allTabs.length]
                        : allTabs[(idx - 1 + allTabs.length) % allTabs.length];
                    next.focus();
                    switchTab(next.dataset.tab);
                }
            });
        });
    }

    // Apply default tab based on URL signal (hash > query string > HTML default).
    // Landing page's "Get Started Free" CTA links to ?from=signup so strangers
    // arrive on the Create Account tab; "Sign In" links remain on the login tab.
    function applyDefaultTabFromUrl() {
        var hash = (window.location.hash || '').toLowerCase();
        if (hash === '#signup' || hash === '#create') {
            switchTab('signup');
            return;
        }
        if (hash === '#login' || hash === '#signin') {
            switchTab('login');
            return;
        }
        var search = (window.location.search || '').toLowerCase();
        if (search.indexOf('from=signup') !== -1) {
            switchTab('signup');
            return;
        }
        // No signal: leave HTML default (Sign In) untouched.
    }

    function switchTab(tabName) {
        document.querySelectorAll('.auth-tab').forEach(function (t) {
            var isActive = t.dataset.tab === tabName;
            t.classList.toggle('auth-tab--active', isActive);
            t.setAttribute('aria-selected', String(isActive));
        });

        if (els.authTabs) els.authTabs.style.display = '';

        var forms = { login: els.formLogin, signup: els.formSignup };
        Object.entries(forms).forEach(function (entry) {
            var name = entry[0];
            var form = entry[1];
            if (!form) return;
            form.classList.toggle('auth-form--active', name === tabName);
        });

        // Hide other forms
        if (els.formForgot) els.formForgot.classList.remove('auth-form--active');
        if (els.formMfa) els.formMfa.classList.remove('auth-form--active');
        if (els.formBackupCodes) {
            els.formBackupCodes.classList.remove('auth-form--active');
            els.formBackupCodes.style.display = 'none';
        }

        resetForgotState();

        if (tabName === 'signup') {
            resetSignupForm();
        }

        var activeForm = document.querySelector('.auth-form--active');
        if (activeForm) {
            var firstInput = activeForm.querySelector('input:not([type="hidden"]):not([type="checkbox"])');
            if (firstInput) firstInput.focus();
        }

        clearAllAlerts();
    }

    function resetForgotState() {
        forgotCurrentStep = 'email';
        if (els.forgotStepEmail) els.forgotStepEmail.style.display = 'block';
        if (els.forgotStepCode) els.forgotStepCode.style.display = 'none';
        if (els.forgotStepNewpw) els.forgotStepNewpw.style.display = 'none';
        if (els.forgotStepSuccess) els.forgotStepSuccess.style.display = 'none';
        if (els.forgotOtpGroup) clearOtpGroup(els.forgotOtpGroup);
        if (els.forgotBackToLogin) els.forgotBackToLogin.style.display = '';
    }

    function resetSignupForm() {
        if (els.signupFields) els.signupFields.style.display = '';
        if (els.signupSuccess) els.signupSuccess.classList.remove('auth-success--visible');
    }

    function showForgotForm() {
        document.querySelectorAll('.auth-form').forEach(function (f) { f.classList.remove('auth-form--active'); });
        document.querySelectorAll('.auth-tab').forEach(function (t) {
            t.classList.remove('auth-tab--active');
            t.setAttribute('aria-selected', 'false');
        });
        resetForgotState();
        els.formForgot.classList.add('auth-form--active');
        if (els.authTabs) els.authTabs.style.display = 'none';
        if (els.forgotEmail) els.forgotEmail.focus();
        clearAllAlerts();
    }

    // ============================================================
    // Link Bindings
    // ============================================================
    function bindLinks() {
        var showForgot = document.getElementById('show-forgot-password');
        if (showForgot) showForgot.addEventListener('click', showForgotForm);

        var switchToSignup = document.getElementById('switch-to-signup');
        if (switchToSignup) switchToSignup.addEventListener('click', function () { switchTab('signup'); });

        var switchToLogin = document.getElementById('switch-to-login');
        if (switchToLogin) switchToLogin.addEventListener('click', function () { switchTab('login'); });

        if (els.forgotBackToLogin) {
            els.forgotBackToLogin.addEventListener('click', function () { switchTab('login'); });
        }

        if (els.goToDashboardBtn) {
            els.goToDashboardBtn.addEventListener('click', redirectToDashboard);
        }
    }

    // ============================================================
    // Clipboard Helper
    // ============================================================
    function copyToClipboard(text, buttonEl) {
        if (!text) return;

        navigator.clipboard.writeText(text).then(function () {
            var originalText = buttonEl.textContent;
            buttonEl.textContent = 'Copied!';
            setTimeout(function () { buttonEl.textContent = originalText; }, 2000);
        }).catch(function () {
            // Fallback: create temp textarea
            var ta = document.createElement('textarea');
            ta.value = text;
            ta.style.position = 'fixed';
            ta.style.opacity = '0';
            document.body.appendChild(ta);
            ta.select();
            document.execCommand('copy');
            document.body.removeChild(ta);
            var originalText = buttonEl.textContent;
            buttonEl.textContent = 'Copied!';
            setTimeout(function () { buttonEl.textContent = originalText; }, 2000);
        });
    }

    // ============================================================
    // Password/Key Visibility Toggle
    // ============================================================
    function bindToggles() {
        document.querySelectorAll('.auth-password-toggle').forEach(function (btn) {
            btn.addEventListener('click', function () {
                var targetId = btn.dataset.target;
                var input = document.getElementById(targetId);
                if (!input) return;
                var isPassword = input.type === 'password';
                input.type = isPassword ? 'text' : 'password';
                btn.textContent = isPassword ? 'Hide' : 'Show';
                btn.setAttribute('aria-label', isPassword ? 'Hide password' : 'Show password');
            });
        });
    }

    // ============================================================
    // Password Strength Meter
    // ============================================================
    function checkPasswordStrength(password) {
        var score = 0;
        if (!password) return { score: 0, label: '', level: '' };
        if (password.length >= 8) score++;
        if (password.length >= 12) score++;
        if (/[A-Z]/.test(password) && /[a-z]/.test(password)) score++;
        if (/[0-9]/.test(password)) score++;
        if (/[^A-Za-z0-9]/.test(password)) score++;

        if (score <= 1) return { score: score, label: 'Weak', level: 'weak' };
        if (score <= 2) return { score: score, label: 'Fair', level: 'fair' };
        if (score <= 3) return { score: score, label: 'Good', level: 'good' };
        return { score: score, label: 'Strong', level: 'strong' };
    }

    function updatePasswordStrength(password) {
        var strength = checkPasswordStrength(password);
        if (!els.signupPasswordStrength) return;

        if (!password) {
            els.signupPasswordStrength.classList.remove('auth-password-strength--visible');
            return;
        }

        els.signupPasswordStrength.classList.add('auth-password-strength--visible');

        if (els.signupStrengthFill) {
            els.signupStrengthFill.className = 'auth-strength-bar-fill';
            if (strength.level) {
                els.signupStrengthFill.classList.add('auth-strength-bar-fill--' + strength.level);
            }
        }
        if (els.signupStrengthLabel) {
            els.signupStrengthLabel.className = 'auth-strength-label';
            els.signupStrengthLabel.textContent = strength.label;
            if (strength.level) {
                els.signupStrengthLabel.classList.add('auth-strength-label--' + strength.level);
            }
        }
    }

    // ============================================================
    // Form Submissions
    // ============================================================
    function bindForms() {
        // Login
        if (els.formLogin) {
            els.formLogin.addEventListener('submit', handleLogin);
            if (els.loginEmail) {
                els.loginEmail.addEventListener('blur', function (e) {
                    var related = e.relatedTarget;
                    if (related && (related.classList.contains('auth-link') ||
                        related.classList.contains('auth-tab') ||
                        related.classList.contains('auth-back-link'))) {
                        return;
                    }
                    validateEmail(els.loginEmail, els.loginEmailError);
                });
                els.loginEmail.addEventListener('input', function () {
                    clearFieldError(els.loginEmail, els.loginEmailError);
                });
            }
            if (els.loginPassword) {
                els.loginPassword.addEventListener('input', function () {
                    clearFieldError(els.loginPassword, els.loginPasswordError);
                });
            }
        }

        // Signup
        if (els.formSignup) {
            els.formSignup.addEventListener('submit', handleSignup);
            if (els.signupEmail) {
                els.signupEmail.addEventListener('blur', function (e) {
                    var related = e.relatedTarget;
                    if (related && (related.classList.contains('auth-link') ||
                        related.classList.contains('auth-tab') ||
                        related.classList.contains('auth-back-link'))) {
                        return;
                    }
                    validateEmail(els.signupEmail, els.signupEmailError);
                });
                els.signupEmail.addEventListener('input', function () {
                    clearFieldError(els.signupEmail, els.signupEmailError);
                });
            }
            if (els.signupPassword) {
                els.signupPassword.addEventListener('input', function () {
                    clearFieldError(els.signupPassword, els.signupPasswordError);
                    updatePasswordStrength(els.signupPassword.value);
                });
            }
            if (els.signupTerms) {
                els.signupTerms.addEventListener('change', function () {
                    clearFieldError(null, els.signupTermsError);
                });
            }
        }

        // Forgot password form
        if (els.formForgot) {
            els.formForgot.addEventListener('submit', handleForgotFormSubmit);
            if (els.forgotEmail) {
                els.forgotEmail.addEventListener('blur', function (e) {
                    var related = e.relatedTarget;
                    if (related && (related.classList.contains('auth-link') ||
                        related.classList.contains('auth-tab') ||
                        related.classList.contains('auth-back-link'))) {
                        return;
                    }
                    validateEmail(els.forgotEmail, els.forgotEmailError);
                });
                els.forgotEmail.addEventListener('input', function () {
                    clearFieldError(els.forgotEmail, els.forgotEmailError);
                });
            }
        }
    }

    // ---- Login Handler ----
    async function handleLogin(e) {
        e.preventDefault();
        clearAlert(els.loginAlert);

        var email = els.loginEmail ? els.loginEmail.value.trim() : '';
        var password = els.loginPassword ? els.loginPassword.value : '';

        // Validate
        var valid = true;
        if (!validateEmail(els.loginEmail, els.loginEmailError)) valid = false;
        if (!password) {
            showFieldError(els.loginPassword, els.loginPasswordError, 'Password is required.');
            valid = false;
        }
        if (!valid) return;

        setLoading(els.loginBtn, true);

        try {
            // Email+password login via POST /auth/login (session cookie flow)
            var res = await fetch(API_BASE + '/auth/login', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'XMLHttpRequest' },
                credentials: 'same-origin',
                body: JSON.stringify({ email: email, password: password }),
            });

            if (res.ok) {
                var data = await res.json().catch(function () { return {}; });

                if (data.mfa_required) {
                    mfaSession = data.mfa_session;
                    mfaMethods = data.mfa_methods || ['totp'];
                    showMfaChallenge();
                    return;
                }

                // Session cookie is set by the server; store CSRF token + user info
                _csrfToken = data.csrf_token || null;
                _hasSessionCookie = true;
                sessionStorage.setItem(AUTH_STORAGE_KEY, 'session');
                if (_csrfToken) sessionStorage.setItem('finlet_csrf', _csrfToken);
                sessionStorage.setItem(AUTH_USER_KEY, JSON.stringify({
                    user_id: data.user_id,
                    email: data.email || email,
                    tier: data.tier,
                }));
                redirectToDashboard();
            } else if (res.status === 401 || res.status === 403) {
                var errData = await res.json().catch(function () { return {}; });
                showAlert(els.loginAlert, 'error',
                    errData.detail || 'Invalid email or password. Please check your credentials.');
            } else if (res.status === 429) {
                var rateData = await res.json().catch(function () { return {}; });
                showAlert(els.loginAlert, 'warning',
                    rateData.detail || 'Rate limited. Please wait before trying again.');
            } else {
                showAlert(els.loginAlert, 'error',
                    'Server error (' + res.status + '). Please try again later.');
            }
        } catch (_e) {
            showAlert(els.loginAlert, 'error',
                'Cannot reach the Finlet server. Make sure it is running (finlet serve).');
        } finally {
            setLoading(els.loginBtn, false);
        }
    }

    // ---- Signup Handler ----
    async function handleSignup(e) {
        e.preventDefault();
        clearAlert(els.signupAlert);

        var valid = true;
        if (!validateEmail(els.signupEmail, els.signupEmailError)) valid = false;
        if (!validatePassword(els.signupPassword, els.signupPasswordError)) valid = false;
        if (!validateTerms()) valid = false;
        if (!valid) return;

        setLoading(els.signupBtn, true);

        try {
            var res = await fetch(API_BASE + '/auth/register', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    email: els.signupEmail.value.trim(),
                    password: els.signupPassword.value,
                    research_network: els.signupResearch.checked,
                }),
            });

            var data = await res.json().catch(function () { return {}; });

            if (res.status === 201 || res.ok) {
                var apiKey = data.api_key;

                await saveAuth(apiKey, {
                    email: els.signupEmail.value.trim(),
                    tier: data.tier || 'free',
                    research_network: data.research_network || false,
                });

                // Post-signup intent hook: if the user arrived via
                // pricing.html?from=signup&intent=subscribe&tier=...
                // (Builder Subscribe button on the pricing page bounced an
                // anonymous visitor here), kick off Stripe Checkout right
                // away instead of showing the success card. saveAuth above
                // established the cookie+CSRF session, so /v1/billing/checkout
                // will authenticate. On any failure we fall through to the
                // normal success state — the user can retry from
                // pricing.html or billing.html.
                var intentHandled = await _maybeStartIntentCheckout();
                if (intentHandled) return;

                // Show success state
                els.signupFields.style.display = 'none';
                els.signupSuccess.classList.add('auth-success--visible');

                // Hide tabs while showing success
                if (els.authTabs) els.authTabs.style.display = 'none';
            } else if (res.status === 409) {
                showAlert(els.signupAlert, 'warning',
                    escapeHtml(data.detail || 'An account with this email already exists.')
                    + ' <button type="button" class="auth-link" data-action="switch-to-login">Sign in instead</button>',
                    true);
                var switchBtn = els.signupAlert.querySelector('[data-action="switch-to-login"]');
                if (switchBtn) switchBtn.addEventListener('click', function () { switchTab('login'); });
            } else if (res.status === 429) {
                showAlert(els.signupAlert, 'warning',
                    data.detail || 'Registration rate limit reached. Please try again later.');
            } else if (res.status === 422) {
                var detail = data.detail;
                var msg = 'Invalid input. Please check your details.';
                if (Array.isArray(detail)) {
                    msg = detail.map(function (d) { return d.msg || d.message || JSON.stringify(d); }).join('. ');
                } else if (typeof detail === 'string') {
                    msg = detail;
                }
                showAlert(els.signupAlert, 'error', msg);
            } else {
                showAlert(els.signupAlert, 'error',
                    data.detail || 'Server error (' + res.status + '). Please try again.');
            }
        } catch (_e) {
            showAlert(els.signupAlert, 'error',
                'Cannot reach the Finlet server. Make sure it is running (finlet serve).');
        } finally {
            setLoading(els.signupBtn, false);
        }
    }

    // ============================================================
    // Forgot Password Flow
    // ============================================================
    function bindForgotPassword() {
        if (els.forgotResendBtn) {
            els.forgotResendBtn.addEventListener('click', handleForgotResend);
        }
        if (els.forgotGoLoginBtn) {
            els.forgotGoLoginBtn.addEventListener('click', function () { switchTab('login'); });
        }

        // OTP auto-submit for forgot password
        if (els.forgotOtpGroup) {
            els.forgotOtpGroup.addEventListener('otp-complete', function (e) {
                handleForgotVerifyCode();
            });
        }
    }

    function handleForgotFormSubmit(e) {
        e.preventDefault();
        if (forgotCurrentStep === 'email') {
            handleForgotSendCode();
        } else if (forgotCurrentStep === 'code') {
            handleForgotVerifyCode();
        } else if (forgotCurrentStep === 'newpw') {
            handleForgotResetPassword();
        }
    }

    async function handleForgotSendCode() {
        clearAlert(els.forgotAlert);
        if (!validateEmail(els.forgotEmail, els.forgotEmailError)) return;

        setLoading(els.forgotSendBtn, true);

        try {
            var res = await fetch(API_BASE + '/auth/forgot-password', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    email: els.forgotEmail.value.trim(),
                }),
            });

            var data = await res.json().catch(function () { return {}; });

            if (res.ok) {
                // If the backend indicates this is an OAuth-only account,
                // show a message directing them to use their OAuth provider.
                if (data.oauth_provider) {
                    showAlert(els.forgotAlert, 'info',
                        data.message || 'This account uses ' + data.oauth_provider + ' sign-in. Use the "Sign in with Google" button instead.');
                    return;
                }

                forgotCurrentStep = 'code';
                els.forgotStepEmail.style.display = 'none';
                els.forgotStepCode.style.display = 'block';
                if (els.forgotOtpGroup) {
                    clearOtpGroup(els.forgotOtpGroup);
                    var firstInput = els.forgotOtpGroup.querySelector('.otp-input');
                    if (firstInput) firstInput.focus();
                }
                showAlert(els.forgotAlert, 'info',
                    'If an account exists with that email, a verification code has been sent.');
            } else if (res.status === 429) {
                showAlert(els.forgotAlert, 'warning',
                    data.detail || 'Too many requests. Please try again later.');
            } else {
                showAlert(els.forgotAlert, 'error',
                    data.detail || 'Error (' + res.status + '). Please try again.');
            }
        } catch (_e) {
            showAlert(els.forgotAlert, 'error',
                'Cannot reach the Finlet server. Make sure it is running (finlet serve).');
        } finally {
            setLoading(els.forgotSendBtn, false);
        }
    }

    function handleForgotVerifyCode() {
        clearAlert(els.forgotAlert);

        var code = els.forgotOtpGroup ? getOtpValue(els.forgotOtpGroup) : '';
        if (!code || !/^\d{6}$/.test(code)) {
            showFieldError(null, els.forgotCodeError, 'Enter a valid 6-digit code.');
            if (els.forgotOtpGroup) setOtpError(els.forgotOtpGroup);
            return;
        }

        // Store the code for the next step — the backend verifies it
        // together with the new password in POST /auth/reset-password.
        _forgotResetCode = code;
        forgotCurrentStep = 'newpw';
        els.forgotStepCode.style.display = 'none';
        els.forgotStepNewpw.style.display = 'block';
        if (els.forgotNewPassword) els.forgotNewPassword.focus();
    }

    async function handleForgotResetPassword() {
        clearAlert(els.forgotAlert);

        var newPw = els.forgotNewPassword ? els.forgotNewPassword.value : '';
        if (!newPw || newPw.length < 8) {
            showFieldError(els.forgotNewPassword, els.forgotNewpwError,
                'Password must be at least 8 characters.');
            return;
        }

        setLoading(els.forgotResetBtn, true);

        try {
            var res = await fetch(API_BASE + '/auth/reset-password', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    email: els.forgotEmail.value.trim(),
                    code: _forgotResetCode,
                    new_password: newPw,
                }),
            });

            var data = await res.json().catch(function () { return {}; });

            if (res.ok) {
                _forgotResetCode = null;
                forgotCurrentStep = 'success';
                els.forgotStepNewpw.style.display = 'none';
                els.forgotStepSuccess.style.display = 'block';
                if (els.forgotBackToLogin) els.forgotBackToLogin.style.display = 'none';
                if (els.authTabs) els.authTabs.style.display = 'none';
                clearAlert(els.forgotAlert);
            } else if (res.status === 401) {
                // Code was invalid or expired — send user back to code step
                _forgotResetCode = null;
                forgotCurrentStep = 'code';
                els.forgotStepNewpw.style.display = 'none';
                els.forgotStepCode.style.display = 'block';
                if (els.forgotOtpGroup) clearOtpGroup(els.forgotOtpGroup);
                showAlert(els.forgotAlert, 'error',
                    data.detail || 'Invalid or expired code. Please request a new one.');
            } else {
                showAlert(els.forgotAlert, 'error',
                    data.detail || 'Password reset failed (' + res.status + ').');
            }
        } catch (_e) {
            showAlert(els.forgotAlert, 'error',
                'Cannot reach the Finlet server.');
        } finally {
            setLoading(els.forgotResetBtn, false);
        }
    }

    async function handleForgotResend() {
        clearAlert(els.forgotAlert);
        els.forgotResendBtn.disabled = true;

        try {
            var res = await fetch(API_BASE + '/auth/forgot-password', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    email: els.forgotEmail.value.trim(),
                }),
            });

            if (res.ok) {
                showAlert(els.forgotAlert, 'success', 'New verification code sent. Check your inbox.');
            } else if (res.status === 429) {
                var data = await res.json().catch(function () { return {}; });
                showAlert(els.forgotAlert, 'warning',
                    data.detail || 'Please wait before requesting another code.');
            } else {
                showAlert(els.forgotAlert, 'error', 'Failed to resend code. Please try again.');
            }
        } catch (_e) {
            showAlert(els.forgotAlert, 'error', 'Cannot reach the Finlet server.');
        } finally {
            setTimeout(function () { els.forgotResendBtn.disabled = false; }, 30000);
        }
    }

    // ============================================================
    // MFA Challenge
    // ============================================================
    function bindMfa() {
        if (els.formMfa) {
            els.formMfa.addEventListener('submit', function (e) {
                e.preventDefault();
                handleMfaVerify();
            });
        }
        if (els.mfaSendSmsBtn) {
            els.mfaSendSmsBtn.addEventListener('click', handleMfaSendSms);
        }
        if (els.mfaUseBackup) {
            els.mfaUseBackup.addEventListener('click', function () {
                switchMfaMethod('backup');
            });
        }
        if (els.mfaBackToLogin) {
            els.mfaBackToLogin.addEventListener('click', function () {
                mfaSession = null;
                mfaMethods = [];
                pendingApiKey = null;
                switchTab('login');
            });
        }

        // OTP auto-submit for TOTP
        if (els.mfaTotpOtpGroup) {
            els.mfaTotpOtpGroup.addEventListener('otp-complete', function () {
                handleMfaVerify();
            });
        }

        // OTP auto-submit for SMS
        if (els.mfaSmsOtpGroup) {
            els.mfaSmsOtpGroup.addEventListener('otp-complete', function () {
                handleMfaVerify();
            });
        }
    }

    function showMfaChallenge() {
        document.querySelectorAll('.auth-form').forEach(function (f) { f.classList.remove('auth-form--active'); });
        document.querySelectorAll('.auth-tab').forEach(function (t) {
            t.classList.remove('auth-tab--active');
            t.setAttribute('aria-selected', 'false');
        });
        if (els.authTabs) els.authTabs.style.display = 'none';
        els.formMfa.classList.add('auth-form--active');

        // Clear previous MFA inputs
        if (els.mfaTotpOtpGroup) clearOtpGroup(els.mfaTotpOtpGroup);
        if (els.mfaSmsOtpGroup) clearOtpGroup(els.mfaSmsOtpGroup);
        if (els.mfaBackupCode) els.mfaBackupCode.value = '';
        clearAlert(els.mfaAlert);

        // Build method tabs if multiple methods
        if (mfaMethods.length > 1) {
            els.mfaMethodSelector.style.display = 'block';
            els.mfaMethodTabs.innerHTML = trustedHTML('');
            var labels = { totp: 'Authenticator', sms: 'SMS', backup: 'Backup Code' };
            mfaMethods.forEach(function (method) {
                var btn = document.createElement('button');
                btn.type = 'button';
                btn.className = 'mfa-method-tab';
                btn.textContent = labels[method] || method;
                btn.dataset.method = method;
                btn.addEventListener('click', function () { switchMfaMethod(method); });
                els.mfaMethodTabs.appendChild(btn);
            });
        } else {
            els.mfaMethodSelector.style.display = 'none';
        }

        var defaultMethod = mfaMethods.includes('totp') ? 'totp' : mfaMethods[0];
        switchMfaMethod(defaultMethod);
    }

    function switchMfaMethod(method) {
        mfaCurrentMethod = method;
        clearAlert(els.mfaAlert);

        document.querySelectorAll('.mfa-method-tab').forEach(function (tab) {
            tab.classList.toggle('mfa-method-tab--active', tab.dataset.method === method);
        });

        if (els.mfaTotpInput) els.mfaTotpInput.style.display = method === 'totp' ? 'block' : 'none';
        if (els.mfaSmsInput) els.mfaSmsInput.style.display = method === 'sms' ? 'block' : 'none';
        if (els.mfaBackupInput) els.mfaBackupInput.style.display = method === 'backup' ? 'block' : 'none';

        if (els.mfaUseBackup) {
            els.mfaUseBackup.style.display = method === 'backup' ? 'none' : 'inline';
        }

        if (method === 'totp' && els.mfaTotpOtpGroup) {
            var firstInput = els.mfaTotpOtpGroup.querySelector('.otp-input');
            if (firstInput) firstInput.focus();
        }
        if (method === 'sms') {
            if (els.mfaSmsCodeField && els.mfaSmsCodeField.style.display !== 'none' && els.mfaSmsOtpGroup) {
                var smsFirst = els.mfaSmsOtpGroup.querySelector('.otp-input');
                if (smsFirst) smsFirst.focus();
            }
        }
        if (method === 'backup' && els.mfaBackupCode) els.mfaBackupCode.focus();
    }

    async function handleMfaSendSms() {
        setLoading(els.mfaSendSmsBtn, true);

        try {
            var res = await fetch(API_BASE + '/auth/mfa/sms/send', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ mfa_session: mfaSession }),
            });

            if (res.ok) {
                if (els.mfaSmsCodeField) els.mfaSmsCodeField.style.display = 'block';
                els.mfaSendSmsBtn.textContent = 'Resend code';
                if (els.mfaSmsOtpGroup) {
                    var firstInput = els.mfaSmsOtpGroup.querySelector('.otp-input');
                    if (firstInput) firstInput.focus();
                }
                showAlert(els.mfaAlert, 'success', 'SMS code sent.');
            } else if (res.status === 429) {
                var data = await res.json().catch(function () { return {}; });
                showAlert(els.mfaAlert, 'warning',
                    data.detail || 'Please wait before requesting another code.');
            } else {
                showAlert(els.mfaAlert, 'error', 'Failed to send SMS. Please try again.');
            }
        } catch (_e) {
            showAlert(els.mfaAlert, 'error', 'Cannot reach the server.');
        } finally {
            setLoading(els.mfaSendSmsBtn, false);
        }
    }

    async function handleMfaVerify() {
        clearAlert(els.mfaAlert);

        var code = '';
        var method = mfaCurrentMethod;

        if (method === 'totp') {
            code = els.mfaTotpOtpGroup ? getOtpValue(els.mfaTotpOtpGroup) : '';
            if (!code || !/^\d{6}$/.test(code)) {
                showFieldError(null, els.mfaTotpError, 'Enter a valid 6-digit code.');
                if (els.mfaTotpOtpGroup) setOtpError(els.mfaTotpOtpGroup);
                return;
            }
        } else if (method === 'sms') {
            code = els.mfaSmsOtpGroup ? getOtpValue(els.mfaSmsOtpGroup) : '';
            if (!code || !/^\d{6}$/.test(code)) {
                showFieldError(null, els.mfaSmsError, 'Enter a valid 6-digit code.');
                if (els.mfaSmsOtpGroup) setOtpError(els.mfaSmsOtpGroup);
                return;
            }
        } else if (method === 'backup') {
            code = els.mfaBackupCode ? els.mfaBackupCode.value.trim() : '';
            if (!code) {
                showFieldError(els.mfaBackupCode, els.mfaBackupError, 'Enter a backup code.');
                return;
            }
        }

        setLoading(els.mfaVerifyBtn, true);

        try {
            var body = {
                mfa_session: mfaSession,
                code: code,
            };
            if (els.mfaRememberDevice && els.mfaRememberDevice.checked) {
                body.remember_device = true;
            }

            var res = await fetch(API_BASE + '/auth/mfa/validate', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(body),
            });

            var data = await res.json().catch(function () { return {}; });

            if (res.ok) {
                var apiKey = pendingApiKey || data.api_key;
                if (apiKey) {
                    await saveAuth(apiKey, {
                        user_id: data.user_id,
                        email: data.email,
                        tier: data.tier,
                    });
                } else {
                    // Cookie-based MFA flow (no API key) — mark session
                    _hasSessionCookie = true;
                    _csrfToken = data.csrf_token || null;
                    sessionStorage.setItem(AUTH_STORAGE_KEY, 'session');
                    if (_csrfToken) sessionStorage.setItem('finlet_csrf', _csrfToken);
                }

                // If backup codes are returned, show them before continuing
                if (data.backup_codes && data.backup_codes.length > 0) {
                    showBackupCodes(data.backup_codes);
                    return;
                }

                redirectToDashboard();
            } else if (res.status === 400 || res.status === 401) {
                var errorEl = method === 'totp' ? els.mfaTotpError
                    : method === 'sms' ? els.mfaSmsError
                    : els.mfaBackupError;
                var inputEl = method === 'backup' ? els.mfaBackupCode : null;
                var otpGroup = method === 'totp' ? els.mfaTotpOtpGroup
                    : method === 'sms' ? els.mfaSmsOtpGroup : null;
                showFieldError(inputEl, errorEl,
                    data.detail || 'Invalid code. Please try again.');
                if (otpGroup) setOtpError(otpGroup);
            } else if (res.status === 429) {
                showAlert(els.mfaAlert, 'warning',
                    data.detail || 'Too many attempts. Please try again later.');
            } else {
                showAlert(els.mfaAlert, 'error',
                    data.detail || 'Verification failed (' + res.status + ').');
            }
        } catch (_e) {
            showAlert(els.mfaAlert, 'error', 'Cannot reach the Finlet server.');
        } finally {
            setLoading(els.mfaVerifyBtn, false);
        }
    }

    // ============================================================
    // Backup Codes Display
    // ============================================================
    var _currentBackupCodes = [];

    function bindBackupCodes() {
        if (els.backupDownloadBtn) {
            els.backupDownloadBtn.addEventListener('click', function () {
                downloadBackupCodes(_currentBackupCodes);
            });
        }
        if (els.backupCopyBtn) {
            els.backupCopyBtn.addEventListener('click', function () {
                var text = _currentBackupCodes.join('\n');
                copyToClipboard(text, els.backupCopyBtn);
            });
        }
        if (els.backupContinueBtn) {
            els.backupContinueBtn.addEventListener('click', redirectToDashboard);
        }
    }

    function showBackupCodes(codes) {
        _currentBackupCodes = codes;

        // Hide all forms, show backup codes
        document.querySelectorAll('.auth-form').forEach(function (f) { f.classList.remove('auth-form--active'); });
        if (els.authTabs) els.authTabs.style.display = 'none';

        // Build grid
        if (els.backupCodesGrid) {
            els.backupCodesGrid.innerHTML = trustedHTML('');
            codes.forEach(function (code) {
                var item = document.createElement('div');
                item.className = 'backup-code-item';
                item.textContent = code;
                els.backupCodesGrid.appendChild(item);
            });
        }

        els.formBackupCodes.style.display = 'block';
        els.formBackupCodes.classList.add('auth-form--active');
    }

    function downloadBackupCodes(codes) {
        var content = 'Finlet Backup Codes\n';
        content += 'Generated: ' + new Date().toISOString() + '\n';
        content += '---\n';
        codes.forEach(function (code) {
            content += code + '\n';
        });
        content += '---\n';
        content += 'Each code can only be used once.\n';
        content += 'Store these codes in a safe place.\n';

        var blob = new Blob([content], { type: 'text/plain' });
        var url = URL.createObjectURL(blob);
        var a = document.createElement('a');
        a.href = url;
        a.download = 'finlet-backup-codes.txt';
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    }

    // ============================================================
    // Google Sign-In
    // ============================================================
    async function loadAuthConfig() {
        var serverConfig = (typeof getServerConfig === 'function') ? getServerConfig() : {};
        if (serverConfig.google_client_id) {
            authConfig.google_enabled = serverConfig.google_enabled || false;
            authConfig.google_client_id = serverConfig.google_client_id;
        }

        if (authConfig.google_enabled && authConfig.google_client_id) {
            if (els.googleSigninLogin) els.googleSigninLogin.style.display = 'block';
            if (els.googleSigninSignup) els.googleSigninSignup.style.display = 'block';
            initGoogleIdentityServices(authConfig.google_client_id);
        } else {
            if (els.googleSigninLogin) els.googleSigninLogin.style.display = 'none';
            if (els.googleSigninSignup) els.googleSigninSignup.style.display = 'none';
        }
    }

    function initGoogleIdentityServices(clientId) {
        if (typeof google === 'undefined' || !google.accounts) {
            googleInitRetries++;
            if (googleInitRetries < GOOGLE_MAX_RETRIES) {
                setTimeout(function () { initGoogleIdentityServices(clientId); }, 500);
            } else {
                if (els.googleSigninLogin) els.googleSigninLogin.style.display = 'none';
                if (els.googleSigninSignup) els.googleSigninSignup.style.display = 'none';
            }
            return;
        }

        google.accounts.id.initialize({
            client_id: clientId,
            callback: handleGoogleCredentialResponse,
            auto_select: false,
            ux_mode: 'popup',
        });

        if (els.googleLoginBtn) {
            els.googleLoginBtn.addEventListener('click', initiateGoogleSignIn);
        }
        if (els.googleSignupBtn) {
            els.googleSignupBtn.addEventListener('click', initiateGoogleSignIn);
        }
    }

    function initiateGoogleSignIn() {
        if (typeof google === 'undefined' || !google.accounts) {
            var alertEl = getActiveAlertEl();
            showAlert(alertEl, 'error', 'Google Sign-In is not available. Please try again later.');
            return;
        }

        google.accounts.id.prompt(function (notification) {
            if (notification.isNotDisplayed()) {
                renderGoogleButtonFallback();
            }
        });
    }

    function renderGoogleButtonFallback() {
        var existing = document.getElementById('google-fallback-overlay');
        if (existing) existing.remove();

        var overlay = document.createElement('div');
        overlay.id = 'google-fallback-overlay';
        overlay.style.cssText = 'position:fixed;top:0;left:0;right:0;bottom:0;background:rgba(0,0,0,0.5);display:flex;align-items:center;justify-content:center;z-index:10000;';

        var card = document.createElement('div');
        card.style.cssText = 'background:var(--bg-primary,#fff);border-radius:12px;padding:32px;max-width:400px;width:90%;text-align:center;box-shadow:0 8px 32px rgba(0,0,0,0.3);';

        var title = document.createElement('p');
        title.textContent = 'Click below to sign in with Google';
        title.style.cssText = 'margin-bottom:20px;font-size:14px;color:var(--text-secondary,#666);';
        card.appendChild(title);

        var btnContainer = document.createElement('div');
        btnContainer.id = 'google-fallback-btn';
        btnContainer.style.cssText = 'display:flex;justify-content:center;';
        card.appendChild(btnContainer);

        var cancelBtn = document.createElement('button');
        cancelBtn.textContent = 'Cancel';
        cancelBtn.style.cssText = 'margin-top:16px;background:none;border:none;color:var(--text-muted,#999);cursor:pointer;font-size:13px;';
        cancelBtn.addEventListener('click', function () { overlay.remove(); });
        card.appendChild(cancelBtn);

        overlay.appendChild(card);
        overlay.addEventListener('click', function (e) {
            if (e.target === overlay) overlay.remove();
        });

        document.body.appendChild(overlay);

        google.accounts.id.renderButton(btnContainer, {
            type: 'standard',
            theme: 'outline',
            size: 'large',
            text: 'signin_with',
            shape: 'rectangular',
            width: 300,
        });
    }

    async function handleGoogleCredentialResponse(response) {
        var idToken = response.credential;
        if (!idToken) return;

        var fallbackOverlay = document.getElementById('google-fallback-overlay');
        if (fallbackOverlay) fallbackOverlay.remove();

        var activeBtn = document.querySelector('.auth-form--active .auth-btn--google');
        if (activeBtn) setLoading(activeBtn, true);

        var alertEl = getActiveAlertEl();
        showAlert(alertEl, 'info', 'Signing in with Google...');

        try {
            var res = await fetch(API_BASE + '/auth/google', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ id_token: idToken }),
            });

            var data = await res.json().catch(function () { return {}; });

            clearAlert(alertEl);

            if (res.ok) {
                if (data.mfa_required) {
                    pendingApiKey = data.api_key || null;
                    mfaSession = data.mfa_session;
                    mfaMethods = data.mfa_methods || ['totp'];
                    showMfaChallenge();
                } else if (data.api_key) {
                    await saveAuth(data.api_key, {
                        user_id: data.user_id,
                        email: data.email,
                        tier: data.tier,
                    });
                    redirectToDashboard();
                } else {
                    showAlert(alertEl, 'error', 'Google sign-in succeeded but no credentials were returned. Please try again.');
                }
            } else if (res.status === 503) {
                showAlert(alertEl, 'error',
                    'Google Sign-In is not configured on this server. Please use email and password.');
                if (els.googleSigninLogin) els.googleSigninLogin.style.display = 'none';
                if (els.googleSigninSignup) els.googleSigninSignup.style.display = 'none';
            } else if (res.status === 401) {
                showAlert(alertEl, 'error',
                    data.detail || 'Google authentication failed. Please try again.');
            } else {
                showAlert(alertEl, 'error',
                    data.detail || 'Google sign-in failed (' + res.status + ').');
            }
        } catch (_e) {
            clearAlert(alertEl);
            showAlert(getActiveAlertEl(), 'error', 'Cannot reach the Finlet server.');
        } finally {
            if (activeBtn) setLoading(activeBtn, false);
        }
    }

    // ============================================================
    // Validation
    // ============================================================
    function validateEmail(inputEl, errorEl) {
        if (!inputEl) return false;
        var email = inputEl.value.trim();
        if (!email) {
            showFieldError(inputEl, errorEl, 'Email is required.');
            return false;
        }
        var emailRe = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRe.test(email)) {
            showFieldError(inputEl, errorEl, 'Enter a valid email address.');
            return false;
        }
        clearFieldError(inputEl, errorEl);
        inputEl.classList.add('auth-input--success');
        return true;
    }

    function validatePassword(inputEl, errorEl) {
        if (!inputEl) return false;
        var pw = inputEl.value;
        if (!pw) {
            showFieldError(inputEl, errorEl, 'Password is required.');
            return false;
        }
        if (pw.length < 8) {
            showFieldError(inputEl, errorEl, 'Password must be at least 8 characters.');
            return false;
        }
        clearFieldError(inputEl, errorEl);
        return true;
    }

    function validateTerms() {
        if (!els.signupTerms || !els.signupTerms.checked) {
            showFieldError(null, els.signupTermsError,
                'You must agree to the Terms of Service and Privacy Policy.');
            return false;
        }
        clearFieldError(null, els.signupTermsError);
        return true;
    }

    // ============================================================
    // UI Helpers
    // ============================================================
    function showFieldError(inputEl, errorEl, message) {
        if (inputEl) {
            inputEl.classList.add('auth-input--error');
            inputEl.classList.remove('auth-input--success');
        }
        if (errorEl) {
            errorEl.textContent = message;
            errorEl.classList.add('auth-field-error--visible');
        }
    }

    function clearFieldError(inputEl, errorEl) {
        if (inputEl) {
            inputEl.classList.remove('auth-input--error');
            inputEl.classList.remove('auth-input--success');
        }
        if (errorEl) {
            errorEl.textContent = '';
            errorEl.classList.remove('auth-field-error--visible');
        }
    }

    function showAlert(alertEl, type, message, isHtml) {
        if (!alertEl) return;
        if (isHtml) {
            alertEl.innerHTML = trustedHTML(message);
        } else {
            alertEl.textContent = message;
        }
        alertEl.className = 'auth-alert auth-alert--' + type + ' auth-alert--visible';
    }

    function clearAlert(alertEl) {
        if (!alertEl) return;
        alertEl.textContent = '';
        alertEl.className = 'auth-alert';
    }

    function clearAllAlerts() {
        document.querySelectorAll('.auth-alert').forEach(function (el) { clearAlert(el); });
        document.querySelectorAll('.auth-field-error').forEach(function (el) {
            el.textContent = '';
            el.classList.remove('auth-field-error--visible');
        });
        document.querySelectorAll('.auth-input').forEach(function (el) {
            el.classList.remove('auth-input--error', 'auth-input--success');
        });
        document.querySelectorAll('.otp-input').forEach(function (el) {
            el.classList.remove('otp-input--error');
        });
    }

    function setLoading(btnEl, loading) {
        if (!btnEl) return;
        if (loading) {
            btnEl.classList.add('auth-btn--loading');
            btnEl.disabled = true;
        } else {
            btnEl.classList.remove('auth-btn--loading');
            btnEl.disabled = false;
        }
    }

    function escapeHtml(str) {
        if (!str) return '';
        var div = document.createElement('div');
        div.textContent = String(str);
        return div.innerHTML.replace(/"/g, '&quot;').replace(/'/g, '&#39;');
    }

    function getActiveAlertEl() {
        if (els.formLogin && els.formLogin.classList.contains('auth-form--active')) {
            return els.loginAlert;
        }
        if (els.formSignup && els.formSignup.classList.contains('auth-form--active')) {
            return els.signupAlert;
        }
        return els.loginAlert;
    }

    // ============================================================
    // Exported global functions (for dashboard integration)
    // ============================================================
    window.FinletAuth = {
        isAuthenticated: isAuthenticated,
        getApiKey: function () {
            if (_inMemoryApiKey) return _inMemoryApiKey;
            // Check for recently-created key stored by settings page
            try { return sessionStorage.getItem('finlet_created_api_key') || null; } catch (_e) { return null; }
        },
        getCsrfToken: function () {
            return _csrfToken;
        },
        setCsrfToken: function (token) {
            // Hydrate the CSRF token after page navigation (e.g. from
            // auth-guard.js calling /v1/auth/session/validate). Mirrors the
            // persistence pattern in validateStoredAuth(): memory + sessionStorage.
            if (!token) return;
            _csrfToken = token;
            _hasSessionCookie = true;
            try { sessionStorage.setItem('finlet_csrf', token); } catch (_e) { /* ignore */ }
        },
        hasSessionCookie: function () {
            return _hasSessionCookie;
        },
        getUser: getStoredUser,
        logout: async function () {
            await logoutWithSession();
            window.location.href = 'auth.html';
        },
        // Promise-returning hydration primitive. Resolves with true when the
        // in-memory auth state is usable (cookie+CSRF present, or legacy
        // Bearer key confirmed), false otherwise. Does NOT redirect. Callers
        // that want to redirect on failure should use requireAuth() below.
        //
        // The first caller kicks off validateStoredAuth(); every subsequent
        // caller awaits the same promise until it resolves. This prevents
        // duplicate /auth/session/validate requests when multiple page
        // scripts boot in parallel (auth-guard, shared-nav, settings.js, ...).
        ready: function () {
            if (_hydrationPromise) return _hydrationPromise;
            _hydrationPromise = (async function () {
                // Enter the re-hydration path if EITHER the normal auth
                // markers are present OR we have a confirmed session
                // cookie in memory. The latter matters after
                // invalidateHydration() wipes _csrfToken and sessionStorage
                // CSRF: isAuthenticated() would return false, but
                // _hasSessionCookie === true tells us a previous /validate
                // succeeded so we should re-fetch CSRF rather than bail.
                if (!isAuthenticated() && !_hasSessionCookie) return false;
                // Fast path: already fully hydrated (cookie + CSRF in memory).
                if (_hasSessionCookie && _csrfToken) return true;
                var valid = await validateStoredAuth();
                if (!valid) return false;
                // Prime the api-utils.js cookie-session cache WITHOUT
                // firing a second /auth/session/validate call. We just
                // validated; re-validating would waste a round-trip.
                if (typeof primeCookieSessionCache === 'function') {
                    try { primeCookieSessionCache(true); } catch (_e) { /* ignore */ }
                }
                return true;
            })();
            return _hydrationPromise;
        },
        // Drop the cached hydration promise and in-memory CSRF so the next
        // call to ready() hits /v1/auth/session/validate again. Triggered by
        // api-utils.js when the server returns 401/403 (auth/csrf errors),
        // which implies the session was invalidated out-of-band (logout in
        // another tab, server-side expiry, CSRF rotation).
        invalidateHydration: function () {
            _hydrationPromise = null;
            _csrfToken = null;
            try { sessionStorage.removeItem('finlet_csrf'); } catch (_e) { /* ignore */ }
            if (typeof resetCookieSessionCache === 'function') {
                try { resetCookieSessionCache(); } catch (_e) { /* ignore */ }
            }
            // CRITICAL: also null the auth-guard barrier promise. If we
            // don't, awaitAuthReady() preferentially returns the stale
            // (already-resolved) __finletAuthGuardReady, never falls
            // through to FinletAuth.ready(), and the retry POST after a
            // 403 csrf_token_missing fires with the same stale headers
            // as the first attempt -- defeating the entire retry path.
            if (typeof window !== 'undefined') {
                try { window.__finletAuthGuardReady = null; } catch (_e) { /* ignore */ }
            }
        },
        requireAuth: async function () {
            var ok = await window.FinletAuth.ready();
            if (!ok) {
                // Avoid redirect loops when already on the auth page.
                var path = window.location.pathname || '';
                if (!path.endsWith('auth.html')) {
                    window.location.href = 'auth.html';
                }
                return false;
            }
            return true;
        },
        saveAuth: saveAuth,
        clearAuth: clearAuth,
    };

})();
