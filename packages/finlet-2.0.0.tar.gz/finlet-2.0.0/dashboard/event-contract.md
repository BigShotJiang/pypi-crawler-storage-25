# Dashboard Event Bus — Contract

> Source of truth for every event published on `window.finletBus`.
> Adding a new event? Update this file in the same commit.
>
> Motivation: `docs/bug-hunt/POST_MORTEM_2026-04-28.md` — 10 of 14
> recurrence-clustered patches were missing-convention bugs around
> subscriber-to-event wiring. The bus + this contract eliminate the
> shape.
>
> Pruned during 2026-05-06 launch cut. Removed events: `order:filled`,
> `onboarding:step-completed`, `profile:saved`, `strategy:saved`
> (consumers moved to `legacy/dashboard-ui/`). See
> `docs/decisions/ui-removal-launch-cut.md`.

## Why a contract doc?

The bus does not validate event names or payload shapes at runtime.
This file is the validation. Publishers and subscribers MUST match
on both the event-name string and the payload object shape declared
here.

## Public API surface

```js
// Subscribe; returns an unsubscribe closure.
const off = window.finletBus.subscribe('event:name', (payload) => { ... });

// Later, when the consumer is torn down:
off();

// Publish a payload to all current subscribers.
window.finletBus.publish('event:name', payload);

// Read the most recent payload published for an event, or undefined
// if no publish has happened. Used by dashboard/dialog-state-mirror.js
// so dialogs that open AFTER the most recent publish can prime
// synchronously instead of racing the next publish.
const last = window.finletBus.getLastPublished('portfolio:updated');
```

Notes:
- Subscriber errors are caught and `console.error`'d. One bad
  subscriber does not break sibling subscribers.
- Publishing with no subscribers is a no-op for delivery; the
  `lastPublished` cache is still updated so a late subscriber can
  read the value via `getLastPublished()`.
- The subscribe snapshot is taken before iteration, so a handler
  that unsubscribes mid-publish does not perturb the loop.

## Last-published cache

The bus maintains a per-event cache of the most recently published
payload, exposed via `getLastPublished(event)`.

- Each `publish(event, payload)` writes `payload` to an internal
  `Map<string, payload>` keyed by event name. The cache is updated
  even when there are zero subscribers — the cache is independent
  of delivery.
- `getLastPublished(event)` returns the cached payload or `undefined`
  if no `publish` has happened for that event since page load.
- The cache lives inside the bus IIFE closure (per-page). Page
  reload clears it.
- Cache size is bounded by the number of distinct event names —
  currently 4 (`portfolio:updated`, `session:switched`,
  `auth:state-change`, `api_keys:updated`). No eviction policy is
  needed.
- Out of scope: payload TTL, multi-session cache invalidation. The
  `portfolio:updated` payload IS session-scoped on the publisher side
  (`app.js` only publishes for the active session), so a session
  switch is followed by an SSE tick that overwrites the cache.

Motivation: lets a consumer that subscribes AFTER a publish read
the most recent payload synchronously via `getLastPublished(event)`
instead of waiting for the next publish. The original use case
(Trade Ticket cash header dialog mirror) was cut for launch; the
cache pattern is preserved for future read-only surfaces.

## HTML safety pattern (cross-reference)

When a subscriber writes received payload data into the DOM, wrap
the HTML through `trustedHTML(html)` from
`dashboard/api-utils.js:469`. This is the canonical wrap pattern
the trusted-types lint guard (`scripts/lint-trusted-types.sh`)
keys off. Do not call any of the following sinks with a bare
string:

- `element.innerHTML = ...`
- `element.outerHTML = ...`
- `element.insertAdjacentHTML(position, ...)`
- `document.write(...)`
- `Range.createContextualFragment(...)`

The lint guard scans both `dashboard/**/*.js` and inline
`<script>` blocks inside `dashboard/**/*.html` (case-insensitive
`<script>...</script>` boundaries; HTML attribute contexts like
`onclick="..."` are out of scope here — they are handled by CSP
`script-src 'strict-dynamic'`). Same-line and next-line
`trustedHTML(...)` continuations are forgiven.

Any sink the lint missed is caught at runtime by the Trusted
Types `default` policy in `dashboard/api-utils.js:438-505`. The
policy callbacks (`createHTML`, `createScript`, `createScriptURL`)
log a `console.warn` AND POST a `{type: 'trusted_types_violation'}`
report to `/v1/telemetry/client-error` via `sendBeacon`. A
companion top-level `securitypolicyviolation` listener catches
CSP-side violations (e.g., a third-party policy creation blocked
by the allowlist) that the runtime `default` policy never sees,
filtered to TT-only directives so non-TT violations don't pollute
the telemetry channel. Both reporters are wrapped in try/catch so
a telemetry failure can never block page render.

---

## Events

### `portfolio:updated`

The portfolio mutated server-side and the dashboard SSE feed
delivered the new state. Any read-only consumer that displays
portfolio-derived data (metric cards, position rows) can
subscribe to refresh.

| Field | Type | Notes |
|-------|------|-------|
| `payload` | object | Full portfolio object as emitted by `/sessions/{id}/stream` `portfolio` event. Includes `cash`, `positions`, `total_value`, `pnl`, etc. |

- **Publishers:**
  - `dashboard/app.js` SSE `portfolio` event handler — every SSE tick. Mutates `currentSession.portfolio_metrics.cash` and `total_value` atomically before the publish.
- **Subscribers:**
  - Dashboard metric cards — `dashboard/app.js` `renderPortfolio` already runs inline.
  - Future read-only consumers can subscribe via `window.finletBus.subscribe('portfolio:updated', ...)` and read `getLastPublished('portfolio:updated')` for cold-open priming.

### `session:switched`

A session became active in the dashboard — either it was just
created, or the user picked a different one from the selector,
or the dashboard auto-selected the first session on page load.
Subscribers should re-fetch session-scoped state and reset any
per-session caches.

This event covers all transitions that result in a session being
the active one:
1. The user creates a new session via the Create Session modal
   (`app.js:handleCreateSession` success branch).
2. The user picks a different session from the session selector
   (`session-select` change handler).
3. The dashboard auto-selects the first session on initial load
   (`fetchSessions` when no current session is set).
4. A session created out-of-band (REST API, CLI, MCP tool) lands
   in the dashboard's session list on the next `fetchSessions`
   poll/refresh and gets selected.

The canonical publish site is `selectSession()` — every path that
activates a session funnels through it, so the bus event fires
once per "session is now active" moment regardless of the trigger.

If publishers ever need to distinguish "created" from "selected",
add a new `session:created` event rather than overloading this
one.

| Field | Type | Notes |
|-------|------|-------|
| `session_id` | string | The id of the now-active session. Required. |

- **Publisher:** `dashboard/app.js` (`selectSession` — the canonical session-activation site that all flows funnel through).
- **Subscribers:** none currently registered post-launch-cut. Open for read-only surfaces that need to reset per-session caches.

### `auth:state-change`

The user's auth state mutated client-side — specifically, the truthiness
of `FinletAuth.getApiKey()` flipped (a key was minted, a session was
established, a logout cleared the in-memory key). Subscribers that
render auth-state-dependent affordances (currently the API-key
affordance umbrella in shared-nav) repaint atomically on this tick.

The publish reads `FinletAuth.getApiKey()` (not the private
`_inMemoryApiKey` directly) so the payload reflects the same
source-of-truth the subscriber reads — including the
`sessionStorage.finlet_created_api_key` fallback path. Subscribers
should NOT trust the payload value as the rendering input; the umbrella
re-reads `FinletAuth.getApiKey()` at paint time. The payload is the
TRIGGER, the live read is the truth source — render-on-read pattern.

| Field | Type | Notes |
|-------|------|-------|
| `hasKey` | boolean | `true` when `FinletAuth.getApiKey()` returns a non-null key at publish time, `false` otherwise. Trigger only — subscribers re-read the source-of-truth. |

- **Publisher:** `dashboard/auth.js` — `_publishAuthStateChange()` is invoked from `saveAuth` (cookie-session success and in-memory fallback paths) and `clearAuth` (logout / session-invalidate). Both paths call the publisher AFTER the relevant `_inMemoryApiKey` mutation, so a subscriber's `getApiKey()` read on the same tick lands on the freshly-mutated value.
- **Subscribers:**
  - API-key affordance umbrella — `dashboard/shared-nav.js` (`_initSharedUserMenu` subscribes `_relabelAllApiKeyAffordances` to the bus). Repaints both `#menu-copy-key` (desktop user-menu) and `#nav-drawer-copy-key` (mobile drawer) atomically. Subscriber registration is idempotent at the page-lifetime level — no teardown needed since the bus + this module share a per-page lifecycle.

Note on auth-page load order: `dashboard/auth.html` does NOT load
`event-bus.js` (the bus is a dashboard-only concern). The publisher is
defensively guarded — when the bus is not present (auth.html flows),
the publish is a silent no-op. The first dashboard-page load after
`saveAuth` will paint the correct affordance via the mount-time pass.

### `api_keys:updated`

The signed-in user's set of API keys mutated client-side &mdash; either a
key was just minted via the dashboard Generate flow, an existing key
was revoked, or the user's primary key was rotated (old key retained
for a grace-period window, new key surfaced via the same one-time
reveal modal). Subscribers that render counters or affordances keyed
off the user's API-key population can refresh in response.

The payload is metadata only &mdash; the raw key from a mint or rotate
NEVER lands on the bus. The raw key flows directly from the
create/rotate response into the one-time reveal modal, is held in a
module-scoped variable for the lifetime of the modal, and is cleared
on dismiss. It is never logged, never persisted, and never published.

| Field | Type | Notes |
|-------|------|-------|
| `action` | string | `"created"` (mint), `"revoked"` (delete), or `"rotated"` (rotate the user's primary key with grace period). Required. |
| `key_id` | string | The opaque id of the affected key (e.g. `abc123...`). Required. Safe to log &mdash; this is the same id surfaced in the listing rows. For `"rotated"`, this is the id of the row the user clicked Rotate on (the rotate response does not surface a separate `new_key_id`); subscribers should treat the payload as a trigger to refresh, not a value carrier. |

- **Publisher:** `dashboard/api-keys.js` &mdash; `createApiKey()` (on a successful `POST /v1/settings/api-keys`, AFTER the reveal modal is opened with the raw key), `revokeApiKey()` (on a successful `DELETE /v1/settings/api-keys/{key_id}`, AFTER the revoke modal is closed), and `rotateApiKey()` (on a successful `POST /v1/settings/api-keys/rotate`, AFTER the reveal modal is opened with the new raw key). The publisher is guarded by `typeof window.finletBus.publish === 'function'` so future pages that do not include `event-bus.js` will silently no-op.
- **Subscribers:** none currently registered. Open for any read-only surface that wants to refresh on key-set changes (e.g. an account-summary tile that counts active keys).

---

## Adding a new event

1. Add a section above with name, payload shape, publisher, subscribers.
2. In the same commit, update the publisher to call `window.finletBus.publish(...)` with the documented payload.
3. If a subscriber must write user-supplied data into the DOM, wrap via `trustedHTML()`.
4. Prefer many small events over one fat one. Cheap to add, expensive to retrofit a payload field every consumer must guard against.

## Removing an event

1. Audit subscribers — `grep -rn "finletBus\.subscribe\(['\"]<event>" dashboard/` MUST return zero before removing the publisher.
2. Remove the publisher.
3. Remove the section here.

## Naming convention

`<noun>:<past-tense-verb>` — e.g. `portfolio:updated`, `session:switched`. Lowercase, colon-separated. The colon is the convention; do not use `.` or `/`.
