// Billing page — subscription + usage + invoices + manage portal + cancel.
//
// Mirrors api-keys.js init pattern (DOMContentLoaded → awaitAuthReady →
// initSharedNav → load data via apiFetch / apiRequest → trustedHTML render).
//
// Backend contract (finlet/api/routes_billing.py):
//   GET  /v1/billing/subscription    → SubscriptionResponse
//   GET  /v1/billing/usage           → UsageResponse
//   GET  /v1/billing/invoices        → InvoiceListResponse
//   GET  /v1/billing/portal?return_url=...  → { portal_url }
//   POST /v1/billing/cancel          → { status, message }
//   POST /v1/billing/validate-promo  → { valid, code, discount, description }
//
// Success/cancel URLs must be absolute and on the allowlist
// (localhost + finlet.dev are on the dev allowlist; see
//  finlet/config.py:96 BillingConfig.allowed_redirect_domains).

document.addEventListener('DOMContentLoaded', async () => {
    const authOk = await awaitAuthReady();
    if (!authOk) {
        if (typeof FinletAuth !== 'undefined' && !FinletAuth.isAuthenticated()) {
            window.location.replace('auth.html');
        }
        return;
    }

    initSharedNav({
        activePage: 'billing',
        breadcrumbs: ['Dashboard', 'Billing'],
    });

    initBillingPage();
});

function initBillingPage() {
    maybeShowSuccessBanner();

    // Wire buttons.
    const manageBtn = document.getElementById('manage-stripe-btn');
    if (manageBtn) manageBtn.addEventListener('click', openStripePortal);

    const cancelBtn = document.getElementById('cancel-sub-btn');
    if (cancelBtn) cancelBtn.addEventListener('click', openCancelModal);

    const keepBtn = document.getElementById('cancel-sub-keep-btn');
    if (keepBtn) keepBtn.addEventListener('click', () => closeModal('cancel-sub-modal'));

    const confirmBtn = document.getElementById('cancel-sub-confirm-btn');
    if (confirmBtn) confirmBtn.addEventListener('click', confirmCancelSubscription);

    const promoForm = document.getElementById('promo-form');
    if (promoForm) {
        promoForm.addEventListener('submit', (ev) => {
            ev.preventDefault();
            validatePromo();
        });
    }

    // Load in parallel.
    Promise.all([loadSubscription(), loadUsage(), loadInvoices()]).catch(() => {
        // Errors are surfaced inline by each loader; never bubble.
    });
}

// ============================================================
//  Success banner (post-Stripe Checkout return)
// ============================================================

function maybeShowSuccessBanner() {
    try {
        const params = new URLSearchParams(window.location.search);
        if (params.get('checkout') === 'success') {
            const banner = document.getElementById('billing-success-banner');
            if (banner) banner.style.display = '';
        }
    } catch {
        // ignore — banner is decorative.
    }
}

// ============================================================
//  Subscription
// ============================================================

async function loadSubscription() {
    const container = document.getElementById('billing-subscription');
    if (!container) return;

    const data = await apiFetch('/billing/subscription');
    if (!data) {
        container.innerHTML = trustedHTML(`
            <div class="settings-empty">
                Could not load subscription details. <button type="button" class="link-button" data-action="retry-sub">Retry</button>
            </div>
        `);
        const retry = container.querySelector('[data-action="retry-sub"]');
        if (retry) retry.addEventListener('click', loadSubscription);
        return;
    }

    const tier = String(data.tier || 'free');
    const status = String(data.status || 'inactive');
    const renewsAt = data.current_period_end
        ? formatDateLong(data.current_period_end)
        : null;
    const isPaid = status === 'active' && tier !== 'free';
    const isCanceled = status === 'canceled';

    let statusBadge;
    if (status === 'active') {
        statusBadge = `<span class="billing-badge billing-badge--active">Active</span>`;
    } else if (status === 'canceled') {
        statusBadge = `<span class="billing-badge billing-badge--canceled">Cancelled</span>`;
    } else if (status === 'past_due') {
        statusBadge = `<span class="billing-badge billing-badge--warning">Past Due</span>`;
    } else {
        statusBadge = `<span class="billing-badge">Free Plan</span>`;
    }

    let renewalLine = '';
    if (isPaid && renewsAt) {
        renewalLine = `<div class="billing-sub-row"><span class="billing-label">Renews</span><span class="billing-value">${esc(renewsAt)}</span></div>`;
    } else if (isCanceled && renewsAt) {
        renewalLine = `<div class="billing-sub-row"><span class="billing-label">Access until</span><span class="billing-value">${esc(renewsAt)}</span></div>`;
    }

    let upgradeCta = '';
    if (!isPaid) {
        upgradeCta = `
            <div class="billing-upgrade-cta">
                <p>You are on the free Explorer plan. Upgrade for more concurrent sessions, more tickers, and higher rate limits.</p>
                <a href="pricing.html" class="btn-settings btn-settings--primary">View Plans</a>
            </div>
        `;
    }

    container.innerHTML = trustedHTML(`
        <div class="billing-sub-grid">
            <div class="billing-sub-row">
                <span class="billing-label">Plan</span>
                <span class="billing-value billing-value--strong">${esc(tierDisplayName(tier))}</span>
            </div>
            <div class="billing-sub-row">
                <span class="billing-label">Status</span>
                <span class="billing-value">${statusBadge}</span>
            </div>
            ${renewalLine}
        </div>
        ${upgradeCta}
    `);

    // Enable Manage / Cancel buttons only when there's a paid subscription.
    const manageBtn = document.getElementById('manage-stripe-btn');
    const cancelBtn = document.getElementById('cancel-sub-btn');
    if (manageBtn) manageBtn.disabled = !isPaid && !isCanceled;
    if (cancelBtn) cancelBtn.disabled = !isPaid;
}

function tierDisplayName(tier) {
    const t = String(tier || '').toLowerCase();
    if (t === 'builder') return 'Builder ($29 / mo)';
    if (t === 'insights') return 'Insights ($99 / mo)';
    if (t === 'enterprise') return 'Enterprise ($499 / mo)';
    return 'Explorer (Free)';
}

// ============================================================
//  Usage
// ============================================================

async function loadUsage() {
    const container = document.getElementById('billing-usage');
    if (!container) return;

    const data = await apiFetch('/billing/usage');
    if (!data) {
        container.innerHTML = trustedHTML(`
            <div class="settings-empty">
                Could not load usage. <button type="button" class="link-button" data-action="retry-usage">Retry</button>
            </div>
        `);
        const retry = container.querySelector('[data-action="retry-usage"]');
        if (retry) retry.addEventListener('click', loadUsage);
        return;
    }

    const rows = [
        ['Sessions today', data.sessions_today, data.sessions_limit],
        ['Concurrent sessions', data.concurrent_sessions, data.concurrent_limit],
        ['API calls today', data.api_calls_today, data.api_calls_limit],
        ['Benchmarks today', data.benchmarks_today, data.benchmarks_limit],
    ];

    container.innerHTML = trustedHTML(`
        <table class="billing-usage-table">
            <thead>
                <tr><th>Metric</th><th>Used</th><th>Limit</th></tr>
            </thead>
            <tbody>
                ${rows.map(([label, used, limit]) => `
                    <tr>
                        <td>${esc(label)}</td>
                        <td>${esc(formatNumber(used))}</td>
                        <td>${esc(limit === null || limit === undefined ? 'Unlimited' : formatNumber(limit))}</td>
                    </tr>
                `).join('')}
            </tbody>
        </table>
    `);
}

function formatNumber(n) {
    if (n === null || n === undefined) return '--';
    const num = Number(n);
    if (!Number.isFinite(num)) return '--';
    return num.toLocaleString();
}

// ============================================================
//  Invoices
// ============================================================

async function loadInvoices() {
    const container = document.getElementById('billing-invoices');
    if (!container) return;

    const data = await apiFetch('/billing/invoices');
    if (!data) {
        container.innerHTML = trustedHTML(`
            <div class="settings-empty">
                Could not load invoices. <button type="button" class="link-button" data-action="retry-invoices">Retry</button>
            </div>
        `);
        const retry = container.querySelector('[data-action="retry-invoices"]');
        if (retry) retry.addEventListener('click', loadInvoices);
        return;
    }

    const invoices = (data.invoices || []);
    if (!invoices.length) {
        container.innerHTML = trustedHTML(`
            <div class="settings-empty">No invoices yet. Invoices appear here after your first payment.</div>
        `);
        return;
    }

    container.innerHTML = trustedHTML(`
        <table class="billing-invoice-table">
            <thead>
                <tr>
                    <th>Date</th>
                    <th>Description</th>
                    <th>Amount</th>
                    <th>Status</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                ${invoices.map(inv => `
                    <tr>
                        <td>${esc(formatDateShort(inv.date))}</td>
                        <td>${esc(inv.description || '--')}</td>
                        <td>${esc(formatCurrency(inv.amount))}</td>
                        <td><span class="billing-badge billing-badge--${esc(invoiceStatusClass(inv.status))}">${esc(inv.status || 'unknown')}</span></td>
                        <td>${inv.pdf_url
                            ? `<a href="${escUrl(inv.pdf_url)}" target="_blank" rel="noopener" class="link-button">View PDF</a>`
                            : ''}</td>
                    </tr>
                `).join('')}
            </tbody>
        </table>
    `);
}

function invoiceStatusClass(status) {
    const s = String(status || '').toLowerCase();
    if (s === 'paid') return 'active';
    if (s === 'open') return 'warning';
    if (s === 'void' || s === 'uncollectible') return 'canceled';
    return 'neutral';
}

function formatCurrency(amount) {
    if (amount === null || amount === undefined) return '--';
    const num = Number(amount);
    if (!Number.isFinite(num)) return '--';
    return '$' + num.toFixed(2);
}

// ============================================================
//  Manage Subscription (Stripe Customer Portal)
// ============================================================

async function openStripePortal() {
    const btn = document.getElementById('manage-stripe-btn');
    if (!btn || btn.disabled) return;

    const originalText = btn.textContent;
    btn.disabled = true;
    btn.innerHTML = trustedHTML('<span class="settings-spinner"></span> Loading...');

    try {
        const returnUrl = window.location.origin + '/billing.html';
        const path = '/billing/portal?return_url=' + encodeURIComponent(returnUrl);
        const data = await apiFetch(path);
        if (data && data.portal_url) {
            window.location.href = data.portal_url;
            return;
        }
        showToast('Could not open billing portal. Please try again.', 'error');
    } finally {
        btn.disabled = false;
        btn.textContent = originalText;
    }
}

// ============================================================
//  Cancel Subscription
// ============================================================

function openCancelModal() {
    const btn = document.getElementById('cancel-sub-btn');
    if (!btn || btn.disabled) return;
    openModal('cancel-sub-modal');
}

async function confirmCancelSubscription() {
    const confirmBtn = document.getElementById('cancel-sub-confirm-btn');
    if (!confirmBtn) return;

    const originalText = confirmBtn.textContent;
    confirmBtn.disabled = true;
    confirmBtn.innerHTML = trustedHTML('<span class="settings-spinner"></span> Cancelling...');

    const result = await apiRequest('/billing/cancel', 'POST');

    confirmBtn.disabled = false;
    confirmBtn.textContent = originalText;

    if (result) {
        closeModal('cancel-sub-modal');
        showToast(result.message || 'Subscription cancelled.', 'success');
        // Reload subscription state.
        loadSubscription();
    }
}

// ============================================================
//  Promo Code Validation (stub — read-only check)
// ============================================================

async function validatePromo() {
    const input = document.getElementById('promo-code-input');
    const status = document.getElementById('promo-status');
    if (!input || !status) return;

    const code = (input.value || '').trim();
    if (!code) {
        status.textContent = 'Enter a promo code to validate.';
        return;
    }

    status.textContent = 'Checking...';
    const data = await apiRequest('/billing/validate-promo', 'POST', { code });

    if (!data) {
        // apiRequest already surfaces a toast on error.
        status.textContent = '';
        return;
    }

    if (data.valid) {
        const detail = data.description || data.discount || 'Valid';
        status.textContent = 'Valid: ' + detail + '. Enter it at Stripe Checkout to apply.';
    } else {
        status.textContent = 'That code is not valid.';
    }
}

// ============================================================
//  Modal helpers (mirrors api-keys.js)
// ============================================================

function openModal(id) {
    const modal = document.getElementById(id);
    if (!modal) return;
    if (window.finletModal && typeof window.finletModal.open === 'function') {
        window.finletModal.open(id);
    } else {
        modal.style.display = '';
        modal.classList.add('modal-overlay--visible');
    }
}

function closeModal(id) {
    const modal = document.getElementById(id);
    if (!modal) return;
    if (window.finletModal && typeof window.finletModal.close === 'function') {
        window.finletModal.close(id);
    } else {
        modal.classList.remove('modal-overlay--visible');
        modal.style.display = 'none';
    }
}

// ============================================================
//  Toast (mirrors api-keys.js)
// ============================================================

function showToast(message, type = 'info') {
    const container = document.getElementById('toast-container');
    if (!container) return;

    const existing = container.querySelectorAll('.toast');
    for (const t of existing) {
        if (t.textContent === message) return;
    }

    const toast = document.createElement('div');
    toast.className = 'toast toast--' + type;
    toast.textContent = message;
    container.appendChild(toast);

    requestAnimationFrame(() => toast.classList.add('toast--visible'));

    setTimeout(() => {
        toast.classList.remove('toast--visible');
        setTimeout(() => toast.remove(), 300);
    }, 4000);
}

// ============================================================
//  Date formatting (mirrors api-keys.js)
// ============================================================

function formatDateShort(dt) {
    if (!dt) return '--';
    try {
        return new Date(dt).toISOString().slice(0, 10);
    } catch {
        return esc(String(dt));
    }
}

function formatDateLong(dt) {
    if (!dt) return '--';
    try {
        const d = new Date(dt);
        return d.toLocaleDateString(undefined, { year: 'numeric', month: 'long', day: 'numeric' });
    } catch {
        return esc(String(dt));
    }
}
