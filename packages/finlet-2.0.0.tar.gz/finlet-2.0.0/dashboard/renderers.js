// ============================================================
//  Finlet — Shared Renderers
// ============================================================
//
// Auth-agnostic render helpers shared by the authenticated dashboard
// (`app.js`) and the public read-only view (`public.js`). All DOM writes
// route through `trustedHTML()` (defined in `api-utils.js`) so the
// `scripts/lint-trusted-types.sh` pre-commit gate stays clean.
//
// History: extracted from `dashboard/app.js` 2026-05-12 as part of the
// public-session-view exec plan (Team B). Signatures intentionally
// unchanged — this is a pure relocation so behavior is preserved on the
// authenticated dashboard.
//
// Classic-script semantics: functions defined here are hoisted to the
// global object. Both `app.js` and `public.js` consume them as globals.
// The chart-state vars (`equityChart` etc.) live here too so that
// `renderEquityCurve()` can read them after `initChart()` runs.

// ---- Chart state (module-global, shared with app.js / public.js) ----
//
// These are intentionally NOT `let` so they become real globals readable
// from sibling classic scripts. `var` at top level of a classic script is
// hoisted to `window` exactly as we need. All four were originally `let`
// in app.js (lines 33-46); the move-to-renderers refactor changes them to
// `var` so cross-file access works without an explicit window.* alias.
//
// Pre-init buffering: a `history` payload that arrives before `initChart()`
// finishes is stashed in `_pendingEquityHistory` / `_pendingEquityOrders`.
// `initChart()` replays the buffer at the end of its own setup.
var equityChart = null;
var equitySeries = null;
var benchmarkSeries = null;
// Hidden anchor series used to enforce a minimum Y-axis range when the
// equity curve's data variance is too small relative to the session's
// initial capital. See `initChart()` and `renderEquityCurve()` for the
// low-variance guard logic. Bug-hunt 20260505T175445Z750b Team B.
var equityYAxisAnchorSeries = null;
var _pendingEquityHistory = null;
var _pendingEquityOrders = null;

// ---- Format helpers ----

function formatCurrency(value, showSign = false) {
    if (value == null || isNaN(value)) return '--';
    const abs = Math.abs(value);
    const formatted = abs.toLocaleString('en-US', {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2,
    });
    if (showSign) {
        return (value >= 0 ? '+$' : '-$') + formatted;
    }
    return (value < 0 ? '-$' : '$') + formatted;
}

function formatPct(value) {
    if (value == null || isNaN(value)) return '--';
    // Round to display precision (2dp) so a raw -0.0001 doesn't render as
    // "-0.00%" — it renders "+0.00%" matching its neutral classification.
    const rounded = Math.round(value * 100) / 100;
    return `${rounded >= 0 ? '+' : ''}${rounded.toFixed(2)}%`;
}

function formatDateTime(dt) {
    if (!dt || dt === '--') return '--';
    try {
        const d = new Date(dt);
        return d.toISOString().replace('T', ' ').slice(0, 19) + ' UTC';
    } catch {
        return esc(String(dt));
    }
}

function formatDateShort(dt) {
    if (!dt) return '';
    try {
        const d = new Date(dt);
        return d.toISOString().slice(0, 10);
    } catch {
        return esc(String(dt));
    }
}

function toChartTime(dt) {
    if (!dt) return 0;
    try {
        const d = new Date(dt);
        return Math.floor(d.getTime() / 1000);
    } catch {
        return 0;
    }
}

// ---- Blind benchmark mode helpers ----
//
// When `window.currentSession.blind === true`, the server returns
// timestamps as `Day_N` strings (and tickers as `T_NNNN` strings) so a
// public viewer cannot reverse-engineer the underlying dataset. The
// equity chart's x-axis switches to a numeric integer time mode (the
// Lightweight Charts library accepts numeric `time` values per its
// docs); other renderers paint whatever string they receive.

function _isBlindMode(session) {
    return !!(session && session.blind === true);
}

// Parse a Day_N timestamp string to its integer N. Returns null for
// non-matching strings so callers can fall back to toChartTime().
function _parseDayInteger(value) {
    if (typeof value !== 'string') return null;
    const m = /^Day_(\d+)$/.exec(value);
    if (!m) return null;
    const n = parseInt(m[1], 10);
    if (!isFinite(n) || n < 0) return null;
    return n;
}

// ---- P&L classification helpers ----
//
// Both classifiers operate on the value AS DISPLAYED (rounded to 2dp) so
// a raw -0.0001 that renders as "0.00%" classifies as neutral rather
// than negative. The fixes were shipped under bug-hunt iterations
// 20260505T142400Z3330 Team A and the surrounding P&L-display tidy.

function pnlArrow(value) {
    if (value == null || isNaN(value)) return '';
    const rounded = Math.round(value * 100) / 100;
    if (rounded > 0) return '▲ '; // up triangle
    if (rounded < 0) return '▼ '; // down triangle
    return '';
}

function pnlClass(value) {
    if (value == null || isNaN(value)) return '';
    const rounded = Math.round(value * 100) / 100;
    if (rounded > 0) return 'pnl-positive';
    if (rounded < 0) return 'pnl-negative';
    return '';
}

// ---- Trace icon helpers ----

function traceIcon(actionType) {
    switch (actionType) {
        case 'SEARCH': return 'S';
        case 'PRICE_QUERY': return 'P';
        case 'FUNDAMENTAL_QUERY': return 'F';
        case 'FILING_QUERY': return 'D';
        case 'ECONOMIC_QUERY': return 'E';
        case 'ORDER_SUBMIT': return 'O';
        case 'ORDER_FILL': return '$';
        case 'CLOCK_ADVANCE': return 'C';
        default: return '?';
    }
}

function traceIconClass(actionType) {
    switch (actionType) {
        case 'SEARCH': return 'trace-icon--search';
        case 'PRICE_QUERY': return 'trace-icon--price';
        case 'FUNDAMENTAL_QUERY': return 'trace-icon--search';
        case 'FILING_QUERY': return 'trace-icon--filing';
        case 'ECONOMIC_QUERY': return 'trace-icon--economic';
        case 'ORDER_SUBMIT':
        case 'ORDER_FILL': return 'trace-icon--trade';
        case 'CLOCK_ADVANCE': return 'trace-icon--clock';
        default: return '';
    }
}

/**
 * Set innerHTML from a trusted static string (no user data).
 * Use this instead of raw innerHTML to signal that the content is safe.
 * Lives here so both app.js and public.js can use it without re-defining.
 */
function setStaticHTML(el, html) {
    if (el) el.innerHTML = trustedHTML(html);
}

// ============================================================
//  Render: Positions
// ============================================================

function renderPositions(positions, totalValue) {
    const tbody = document.getElementById('positions-body');

    if (!positions.length) {
        if (typeof showContextEmptyState === 'function') {
            showContextEmptyState('positions-body', 'no-positions');
        } else {
            setStaticHTML(tbody, '<tr class="empty-row"><td colspan="6"><div class="empty-state"><p class="empty-state__headline">No positions yet</p><p class="empty-state__text">Execute a buy order to open a position.</p></div></td></tr>');
        }
        return;
    }

    tbody.innerHTML = trustedHTML(positions.map((p) => {
        const currentPrice = p.current_price ?? 0;
        const avgEntry = p.avg_entry_price ?? 0;
        const qty = p.quantity ?? 0;
        const unrealizedPnl = p.unrealized_pnl ?? ((currentPrice - avgEntry) * qty);
        const marketValue = p.market_value ?? (currentPrice * qty);
        const pctPortfolio = totalValue > 0 ? (marketValue / totalValue) * 100 : 0;
        const pnlPctStr = p.unrealized_pnl_pct != null
            ? ` (${p.unrealized_pnl_pct >= 0 ? '+' : ''}${p.unrealized_pnl_pct.toFixed(1)}%)`
            : '';

        return `<tr>
            <td>${esc(p.ticker)}</td>
            <td>${esc(String(qty))}</td>
            <td>${formatCurrency(avgEntry)}</td>
            <td>${formatCurrency(currentPrice)}</td>
            <td class="${pnlClass(unrealizedPnl)}">${pnlArrow(unrealizedPnl)}${formatCurrency(unrealizedPnl, true)}${pnlPctStr}</td>
            <td>${pctPortfolio.toFixed(1)}%</td>
        </tr>`;
    }).join(''));
}

// ============================================================
//  Render: Equity Curve
// ============================================================

function renderEquityCurve(history, ordersData) {
    if (!equityChart) {
        // Chart not initialized yet (initChart hasn't run, or the
        // LightweightCharts CDN hasn't finished loading). Buffer the
        // latest payload so initChart() can replay it. Always store the
        // freshest history — older buffers are silently overwritten.
        _pendingEquityHistory = history;
        _pendingEquityOrders = ordersData;
        return;
    }
    const snapshots = Array.isArray(history)
        ? history
        : (history.snapshots || history.equity_curve || history.data || []);

    if (!snapshots.length) return;

    // Blind-mode chart axis configuration. When the session is blinded,
    // the timestamps are Day_N strings and the x-axis switches to a
    // numeric integer time scale with a "Day {N}" tick formatter.
    // The Lightweight Charts library accepts numeric `time` values per
    // its docs — Day_N integers are fed directly as `{ time: N, value }`.
    const session = (typeof window !== 'undefined') ? window.currentSession : null;
    const blind = _isBlindMode(session);
    try {
        if (blind) {
            equityChart.applyOptions({
                timeScale: {
                    tickMarkFormatter: (time) => 'Day ' + time,
                    timeVisible: false,
                    secondsVisible: false,
                },
            });
        }
        // Non-blind path is the chart's initial config from initChart();
        // do NOT override timeScale here. The library calls
        // tickMarkFormatter as a function; passing null/undefined to
        // applyOptions throws "s.tickMarkFormatter is not a function"
        // on every tick render.
    } catch {
        // applyOptions can throw if the chart was disposed; skip silently.
    }

    // Time-extraction strategy:
    //   - blind: parse Day_N → integer N; if a snapshot isn't a Day_N
    //     string, fall back to the index in the array so the curve still
    //     plots monotonically (defensive — server should always send
    //     Day_N in blind mode).
    //   - non-blind: existing UTC-epoch seconds path.
    const equityData = snapshots.map((s, idx) => {
        const raw = s.timestamp || s.time;
        let t;
        if (blind) {
            const parsed = _parseDayInteger(raw);
            t = (parsed != null) ? parsed : idx;
        } else {
            t = toChartTime(raw);
        }
        return {
            time: t,
            value: s.total_value ?? s.value ?? 0,
        };
    }).sort((a, b) => a.time - b.time);

    // Deduplicate timestamps (Lightweight Charts requires unique times)
    const deduped = [];
    const seen = new Set();
    for (const pt of equityData) {
        if (!seen.has(pt.time)) {
            seen.add(pt.time);
            deduped.push(pt);
        }
    }

    equitySeries.setData(deduped);

    // Benchmark data if present. Time-extraction mirrors the equity
    // series above so the two share an x-axis in both blind + non-blind
    // modes.
    const benchmarkData = snapshots
        .filter((s) => s.benchmark_value != null)
        .map((s, idx) => {
            const raw = s.timestamp || s.time;
            let t;
            if (blind) {
                const parsed = _parseDayInteger(raw);
                t = (parsed != null) ? parsed : idx;
            } else {
                t = toChartTime(raw);
            }
            return { time: t, value: s.benchmark_value };
        })
        .sort((a, b) => a.time - b.time);

    if (benchmarkData.length) {
        const dedupedBench = [];
        const seenBench = new Set();
        for (const pt of benchmarkData) {
            if (!seenBench.has(pt.time)) {
                seenBench.add(pt.time);
                dedupedBench.push(pt);
            }
        }
        benchmarkSeries.setData(dedupedBench);
    }

    // Y-axis minimum-span guard. The chart's auto-scale fits Y to the
    // tightest data range across all series; when equity hovers within
    // a sub-cent window of starting capital (e.g., $99,999.94 ± $0.04
    // after a small first fill), the curve renders as a flat line with
    // every trajectory point invisible. We feed two anchor points
    // through a fully transparent series sharing the same right price
    // scale — the auto-scale union expands the visible range to include
    // them whenever real variance is below the threshold. When real
    // variance exceeds the threshold, the anchors are cleared and the
    // Y-axis tracks data naturally. See bug-hunt 20260505T175445Z750b
    // Team B.
    if (equityYAxisAnchorSeries) {
        // Reads via `window.currentSession` so the renderer works from
        // either app.js (authenticated dashboard) or public.js (public
        // read-only view) without forcing the same lexical scope.
        const cs = (typeof window !== 'undefined') ? window.currentSession : null;
        const anchor = (
            (cs && cs.config && typeof cs.config.initial_capital === 'number' && cs.config.initial_capital > 0)
                ? cs.config.initial_capital
                : (deduped.length > 0 ? deduped[0].value : 100000)
        );
        const minSpan = anchor * 0.10;
        let dataSpan = 0;
        if (deduped.length > 0) {
            let minVal = deduped[0].value;
            let maxVal = deduped[0].value;
            for (const pt of deduped) {
                if (pt.value < minVal) minVal = pt.value;
                if (pt.value > maxVal) maxVal = pt.value;
            }
            dataSpan = maxVal - minVal;
        }
        if (deduped.length > 0 && dataSpan < minSpan && anchor > 0) {
            // Reuse the equity series's first/last timestamps so the
            // anchor points sit inside the visible time window — the
            // chart's auto-scale only considers data in view.
            const firstTime = deduped[0].time;
            const lastTime = deduped[deduped.length - 1].time;
            const anchorPoints = (firstTime === lastTime)
                ? [{ time: firstTime, value: anchor * 0.95 }]
                : [
                    { time: firstTime, value: anchor * 0.95 },
                    { time: lastTime, value: anchor * 1.05 },
                ];
            equityYAxisAnchorSeries.setData(anchorPoints);
        } else {
            // Real variance exceeds threshold — clear the anchors so
            // the Y-axis tracks the data range natively.
            equityYAxisAnchorSeries.setData([]);
        }
    }

    equityChart.timeScale().fitContent();

    // Trade markers. Same time-extraction strategy as equity/benchmark
    // so markers line up on the x-axis in blind mode (Day_N integers).
    const orderList = ordersData ? (Array.isArray(ordersData) ? ordersData : (ordersData.orders || [])) : [];
    const filledOrders = orderList.filter(o => o.fill_price && (o.status || '').toUpperCase() === 'FILLED');
    const markers = filledOrders.map((o, idx) => {
        const side = (o.side || '').toUpperCase();
        const raw = o.filled_at || o.submitted_at || o.timestamp;
        let t;
        if (blind) {
            const parsed = _parseDayInteger(raw);
            t = (parsed != null) ? parsed : idx;
        } else {
            t = toChartTime(raw);
        }
        return {
            time: t,
            position: side === 'BUY' ? 'belowBar' : 'aboveBar',
            color: side === 'BUY' ? '#3fb950' : '#f85149',
            shape: side === 'BUY' ? 'arrowUp' : 'arrowDown',
            text: `${side} ${(o.ticker || '').toUpperCase()}`,
        };
    }).sort((a, b) => a.time - b.time);

    if (markers.length) {
        equitySeries.setMarkers(markers);
    } else {
        equitySeries.setMarkers([]);
    }
}

// ============================================================
//  Render: Orders
// ============================================================

function renderOrders(data) {
    const orders = Array.isArray(data) ? data : (data.orders || []);
    const tbody = document.getElementById('orders-body');

    if (!orders.length) {
        if (typeof showContextEmptyState === 'function') {
            showContextEmptyState('orders-body', 'no-orders');
        } else {
            setStaticHTML(tbody, '<tr class="empty-row"><td colspan="9"><div class="empty-state"><p class="empty-state__headline">No orders yet</p><p class="empty-state__text">Open a trade to place your first order.</p></div></td></tr>');
        }
        return;
    }

    tbody.innerHTML = trustedHTML(orders.map((o, i) => {
        const side = (o.side || '').toUpperCase();
        const status = (o.status || '').toUpperCase();
        const reasoning = o.reasoning || '';
        const reasoningId = `reasoning-${i}`;

        // Cash-disclosure cell: Total Cost with always-visible inline breakdown sub-line +
        // supplementary tooltip. Server populates these on FILLED orders only; pre-fill
        // orders show '--'.
        //
        // The inline sub-line is rendered whenever the user, reading the row, would
        // compute (Fill Price column) * (Qty column) and get a number that differs from
        // Total Cost. Two sources of perceived delta:
        //   (a) Fill Price column rounds fill_price to 2dp (formatCurrency precision),
        //       so a fill_price of $560.897 renders "$560.90"; nominal = 10 * 560.90 =
        //       $5,609.00 vs actual total_cost $5,608.97 yields a $0.03 perceived
        //       price-improvement delta even when commission is zero.
        //   (b) Commission/fees add (BUY) or subtract (SELL) from gross, producing an
        //       intrinsic delta independent of display rounding.
        // Both flow through the same delta computation: nominalGross (using displayed,
        // 2dp-rounded fill_price) minus total_cost. Half-cent epsilon avoids noisy
        // sub-lines when rounding-induced delta is below display precision. No `> 0`
        // filter on commission/slippage — price-improvement (negative-fee) cases are
        // also disclosed.
        let totalCostCell = '--';
        if (o.total_cost != null) {
            const breakdown = [];
            let inlineSubLine = '';
            if (o.fill_price != null && o.quantity != null) {
                const grossExact = o.fill_price * o.quantity;
                breakdown.push(`Gross: ${formatCurrency(grossExact)}`);
                // nominalGross uses the 2dp-displayed fill_price the user sees in the
                // Fill Price column. parseFloat(toFixed(2)) matches formatCurrency's
                // rounding behaviour without re-parsing the formatted string (avoids
                // locale separator issues from formatCurrency's toLocaleString).
                const displayedFillPrice = parseFloat(o.fill_price.toFixed(2));
                const nominalGross = displayedFillPrice * o.quantity;
                // favorableDelta > 0  => user got a better deal than nominal.
                //   For BUY: paid less than nominalGross (price improvement / rounding gain).
                //   For SELL: received more than nominalGross (rare — usually rounding).
                // favorableDelta < 0  => user got a worse deal than nominal.
                //   For BUY: paid more (commission added on top of gross).
                //   For SELL: received less (commission deducted from gross).
                // Default-to-BUY semantics when side is missing — total_cost on BUYs is
                // the cash spent, which is the dominant case.
                const isSell = (o.side || '').toUpperCase() === 'SELL';
                const favorableDelta = isSell
                    ? (o.total_cost - nominalGross)
                    : (nominalGross - o.total_cost);
                if (Math.abs(favorableDelta) >= 0.005) {
                    // Show actual fill_price (up to 4dp) so the user sees the precise
                    // figure the engine used. Trim trailing zeros beyond 2dp for
                    // readability ("560.897" not "560.8970", "560.90" not "560.9000").
                    const priceStr = o.fill_price.toFixed(4).replace(/(\.\d{2}\d*?)0+$/, '$1');
                    const absDelta = formatCurrency(Math.abs(favorableDelta));
                    // Direction-explicit copy:
                    //   favorableDelta > 0 — better than nominal => "price improvement"
                    //   favorableDelta < 0 — worse than nominal => "+ commission"
                    const annotation = favorableDelta > 0
                        ? `price improvement: ${absDelta}`
                        : `+ ${absDelta} commission`;
                    // Inline sub-line styling: display:block to drop below the total,
                    // smaller/muted to read as supplementary detail (matches existing
                    // muted-text pattern; --text-muted is the canonical CSS variable).
                    inlineSubLine = `<span class="order-cost-breakdown" style="display:block;font-size:0.85em;color:var(--text-muted);margin-top:2px;">= ${esc(String(o.quantity))} × $${esc(priceStr)} (${esc(annotation)})</span>`;
                }
            }
            // Tooltip breakdown components: include commission + slippage when present
            // (no `> 0` filter — negative values are also disclosed).
            if (o.commission != null) {
                breakdown.push(`Commission: ${formatCurrency(o.commission)}`);
            }
            if (o.slippage_amount != null) {
                breakdown.push(`Slippage: ${formatCurrency(o.slippage_amount)} (already in fill price)`);
            }
            const tooltip = breakdown.length ? breakdown.join(' · ') : '';
            totalCostCell = `<span data-cost-breakdown="${esc(tooltip)}" title="${esc(tooltip)}">${formatCurrency(o.total_cost)}</span>${inlineSubLine}`;
        }

        return `<tr>
            <td><time datetime="${esc(o.submitted_at || o.timestamp || '')}">${formatDateTime(o.submitted_at || o.timestamp)}</time></td>
            <td class="side-${esc(side.toLowerCase())}">${side === 'BUY' ? '▲ ' : side === 'SELL' ? '▼ ' : ''}${esc(side)}</td>
            <td>${esc(o.ticker)}</td>
            <td>${esc(String(o.quantity))}</td>
            <td>${esc((o.order_type || o.type || '').toUpperCase())}</td>
            <td class="status-${esc(status.toLowerCase())}">${esc(status)}</td>
            <td>${o.fill_price != null ? formatCurrency(o.fill_price) : '--'}</td>
            <td class="order-total-cost">${totalCostCell}</td>
            <td>${reasoning
                ? `<span class="reasoning-toggle" data-toggle-target="${reasoningId}" tabindex="0" role="button" aria-expanded="false" aria-controls="${reasoningId}">show</span>
                   <div class="reasoning-content" id="${reasoningId}" role="region" aria-label="Order reasoning">${esc(reasoning)}</div>`
                : '--'}</td>
        </tr>`;
    }).join(''));
}

// ============================================================
//  Render: Trace
// ============================================================

function renderTrace(data) {
    const entries = Array.isArray(data) ? data : (data.entries || data.trace || []);
    const feed = document.getElementById('trace-feed');

    if (!entries.length) {
        if (typeof showContextEmptyState === 'function') {
            showContextEmptyState('trace-feed', 'no-trace');
        } else {
            setStaticHTML(feed, '<div class="empty-state"><p class="empty-state__headline">No activity yet</p><p class="empty-state__text">When your agent queries data or submits trades, each step will appear here.</p></div>');
        }
        return;
    }

    feed.innerHTML = trustedHTML(entries.map((e, i) => {
        const actionType = (e.action_type || '').toUpperCase();
        const icon = traceIcon(actionType);
        const iconClass = traceIconClass(actionType);
        const detailsId = `trace-detail-${i}`;
        const summary = e.response_summary
            ? (typeof e.response_summary === 'string'
                ? e.response_summary
                : JSON.stringify(e.response_summary, null, 2))
            : '';
        const request = e.request_params
            ? (typeof e.request_params === 'string'
                ? e.request_params
                : JSON.stringify(e.request_params, null, 2))
            : '';

        return `<div class="trace-entry" role="article" aria-label="${esc(actionType.replace(/_/g, ' '))} trace entry">
            <div class="trace-icon ${iconClass}" aria-hidden="true">${icon}</div>
            <div class="trace-body">
                <div class="trace-header">
                    <span class="trace-type">${esc(actionType.replace(/_/g, ' '))}</span>
                    <time class="trace-time" datetime="${esc(e.timestamp_sim || e.sim_time || '')}">${formatDateTime(e.timestamp_sim || e.sim_time)}</time>
                    ${e.latency_ms ? `<span class="trace-time">${esc(String(e.latency_ms))}<span class="sr-only"> milliseconds</span>ms</span>` : ''}
                </div>
                ${e.reasoning ? `<div class="trace-summary">${esc(e.reasoning)}</div>` : ''}
                ${(request || summary) ? `
                    <span class="trace-expand" data-toggle-target="${detailsId}" tabindex="0" role="button" aria-expanded="false" aria-controls="${detailsId}">details</span>
                    <div class="trace-details" id="${detailsId}" role="region" aria-label="Trace details">` +
                    (request ? `Request:\n${esc(request)}\n\n` : '') +
                    (summary ? `Response:\n${esc(summary)}` : '') +
                    `</div>` : ''}
            </div>
        </div>`;
    }).join(''));
}

// ============================================================
//  Equity chart init
// ============================================================
//
// Sets up the TradingView Lightweight Charts widget. Originally lived in
// `app.js`; relocated here so `public.js` can call the same bootstrap.
// The post-init replay block at the bottom flushes any history payload
// that arrived before `initChart()` finished (the SSE-history vs CDN-
// load race documented in `app.js`).

function initChart() {
    const container = document.getElementById('equity-chart');
    if (typeof LightweightCharts === 'undefined') {
        console.warn('[Finlet] LightweightCharts not loaded — chart disabled');
        if (container) container.textContent = 'Chart library unavailable';
        return;
    }

    equityChart = LightweightCharts.createChart(container, {
        layout: {
            background: { type: 'solid', color: '#161b22' },
            textColor: '#9198a1',
            fontFamily: "'SF Mono', 'Cascadia Code', 'Fira Code', 'Consolas', monospace",
        },
        grid: {
            vertLines: { color: '#21262d' },
            horzLines: { color: '#21262d' },
        },
        crosshair: {
            mode: LightweightCharts.CrosshairMode.Normal,
        },
        rightPriceScale: {
            borderColor: '#30363d',
        },
        timeScale: {
            borderColor: '#30363d',
            timeVisible: true,
        },
        handleScroll: true,
        handleScale: true,
    });

    equitySeries = equityChart.addLineSeries({
        color: '#58a6ff',
        lineWidth: 2,
        title: 'Portfolio',
    });

    benchmarkSeries = equityChart.addLineSeries({
        color: '#9198a1',
        lineWidth: 1,
        lineStyle: LightweightCharts.LineStyle.Dashed,
        title: 'Buy & Hold',
    });

    // Y-axis minimum-span guard via hidden anchor series.
    //
    // TradingView's default Y-axis auto-scale fits the visible range
    // tightly to data. With low-variance equity points around the
    // starting capital (e.g., $100,000.00 ± a few cents after a small
    // first fill), the Y-axis collapses to a sub-cent window and the
    // equity curve looks like a flat line — every meaningful trajectory
    // point becomes invisible.
    //
    // The fix: a fully transparent line series shares the same right
    // price scale as the equity series. When renderEquityCurve()
    // detects low variance vs the session's initial_capital anchor, it
    // populates this series with two anchor points at [anchor*0.95,
    // anchor*1.05]. The chart's auto-scale takes the union of all
    // series' data ranges, so the visible Y-axis expands to a
    // meaningful window. When real equity variance exceeds the
    // threshold, the anchor series is cleared and the Y-axis tracks the
    // real data range naturally. See bug-hunt 20260505T175445Z750b
    // Team B; the autoscaleInfoProvider series option in the v4
    // standalone bundle does not engage on applyOptions, so we use the
    // anchor-series pattern (documented TradingView idiom) instead.
    equityYAxisAnchorSeries = equityChart.addLineSeries({
        color: 'rgba(0,0,0,0)', // fully transparent — pixels never drawn
        lineWidth: 1,
        priceLineVisible: false,
        lastValueVisible: false,
        crosshairMarkerVisible: false,
    });

    // Resize chart on container resize
    const resizeObserver = new ResizeObserver(() => {
        equityChart.applyOptions({
            width: container.clientWidth,
            height: container.clientHeight,
        });
    });
    resizeObserver.observe(container);

    // Expose chart handles on window for E2E tests. Module-scope `let`
    // variables aren't reachable via `window.X` in classic scripts, and the
    // equity-curve regression test (journey-04) needs to read the rendered
    // series points to verify the watermark-only state is fixed. No
    // production code uses these — they're for test introspection only.
    window.__finletChart = equityChart;
    window.__finletEquitySeries = equitySeries;
    window.__finletBenchmarkSeries = benchmarkSeries;
    // Hidden anchor series used by renderEquityCurve()'s low-variance
    // Y-axis guard. Exposed for the bug-hunt 20260505T175445Z750b
    // regression test; no production code uses it.
    window.__finletEquityAnchorSeries = equityYAxisAnchorSeries;
    // renderEquityCurve drives the low-variance Y-axis anchor logic;
    // the regression test invokes it directly with synthetic data so
    // the assertion is deterministic across session-state timing.
    window.__finletRenderEquityCurve = renderEquityCurve;

    // Replay any history payload that arrived before the chart was ready.
    // This closes the chart-init-vs-SSE-data race: if a 'history' SSE event
    // landed during the LightweightCharts CDN load (or any future code path
    // that calls renderEquityCurve before initChart), the buffered data is
    // rendered now. No extra fetch, no flicker — we just consume the buffer
    // we already have.
    if (_pendingEquityHistory != null) {
        const bufferedHistory = _pendingEquityHistory;
        const bufferedOrders = _pendingEquityOrders;
        _pendingEquityHistory = null;
        _pendingEquityOrders = null;
        renderEquityCurve(bufferedHistory, bufferedOrders);
    }
}
