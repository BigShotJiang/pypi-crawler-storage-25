/* ============================================================
   Finlet — Centralized Empty State & Widget Error Module
   Provides showEmptyState(containerId, context) and
   hideEmptyState(containerId) for all dashboard panels.

   Uses existing .empty-state CSS classes (styles.css:2016-2084).
   Loaded AFTER api-utils.js, BEFORE app.js.
   ============================================================ */

/**
 * Empty state configurations keyed by context.
 * Each entry has: headline, text, icon SVG, and optional CTA HTML.
 */
const EMPTY_STATE_CONFIGS = {
    'no-sessions': {
        headline: 'No sessions yet',
        text: 'Create one to get started.',
        icon: '<svg width="40" height="40" viewBox="0 0 40 40" fill="none" aria-hidden="true"><circle cx="20" cy="20" r="18" stroke="var(--text-muted)" stroke-width="1.5" stroke-dasharray="4 3"/><path d="M14 20h12M20 14v12" stroke="var(--text-muted)" stroke-width="1.5" stroke-linecap="round"/></svg>',
    },
    'no-orders': {
        headline: 'No orders yet',
        text: 'Open a trade to place your first order.',
        icon: '<svg width="40" height="40" viewBox="0 0 40 40" fill="none" aria-hidden="true"><path d="M10 12h20M10 20h14M10 28h8" stroke="var(--text-muted)" stroke-width="1.5" stroke-linecap="round"/><path d="M30 22l4 4-4 4" stroke="var(--text-muted)" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>',
    },
    'no-positions': {
        headline: 'No positions yet',
        text: 'Execute a buy order to open a position.',
        icon: '<svg width="40" height="40" viewBox="0 0 40 40" fill="none" aria-hidden="true"><rect x="6" y="8" width="28" height="24" rx="3" stroke="var(--text-muted)" stroke-width="1.5"/><path d="M6 16h28" stroke="var(--text-muted)" stroke-width="1.5"/><circle cx="20" cy="26" r="4" stroke="var(--text-muted)" stroke-width="1.5" stroke-dasharray="3 2"/></svg>',
    },
    'no-trace': {
        headline: 'No activity yet',
        text: 'When your agent queries data or submits trades, each step will appear here.',
        icon: '<svg width="40" height="40" viewBox="0 0 40 40" fill="none" aria-hidden="true"><path d="M12 10v20" stroke="var(--text-muted)" stroke-width="1.5" stroke-linecap="round" stroke-dasharray="3 3"/><circle cx="12" cy="14" r="3" stroke="var(--text-muted)" stroke-width="1.5"/><circle cx="12" cy="26" r="3" stroke="var(--text-muted)" stroke-width="1.5"/><path d="M18 14h12M18 26h8" stroke="var(--text-muted)" stroke-width="1.5" stroke-linecap="round"/></svg>',
    },
    'no-plugins': {
        headline: 'Connect a data source',
        text: 'Add a market data plugin to power your trading agent.',
        icon: '<svg width="40" height="40" viewBox="0 0 40 40" fill="none" aria-hidden="true"><rect x="8" y="8" width="10" height="10" rx="2" stroke="var(--text-muted)" stroke-width="1.5"/><rect x="22" y="8" width="10" height="10" rx="2" stroke="var(--text-muted)" stroke-width="1.5"/><rect x="8" y="22" width="10" height="10" rx="2" stroke="var(--text-muted)" stroke-width="1.5"/><rect x="22" y="22" width="10" height="10" rx="2" stroke="var(--text-muted)" stroke-width="1.5" stroke-dasharray="3 2"/></svg>',
    },
    'no-session': {
        headline: 'Select a session to see plugin status',
        text: 'Plugin health is reported per active session. Create or select one to view live status.',
        icon: '<svg width="40" height="40" viewBox="0 0 40 40" fill="none" aria-hidden="true"><rect x="8" y="8" width="10" height="10" rx="2" stroke="var(--text-muted)" stroke-width="1.5"/><rect x="22" y="8" width="10" height="10" rx="2" stroke="var(--text-muted)" stroke-width="1.5"/><rect x="8" y="22" width="10" height="10" rx="2" stroke="var(--text-muted)" stroke-width="1.5"/><rect x="22" y="22" width="10" height="10" rx="2" stroke="var(--text-muted)" stroke-width="1.5" stroke-dasharray="3 2"/></svg>',
    },
    'no-data': {
        headline: 'No data available',
        text: 'Try advancing the simulation clock.',
        icon: '<svg width="40" height="40" viewBox="0 0 40 40" fill="none" aria-hidden="true"><circle cx="20" cy="20" r="18" stroke="var(--text-muted)" stroke-width="1.5" stroke-dasharray="4 3"/><path d="M14 20h12M20 14v12" stroke="var(--text-muted)" stroke-width="1.5" stroke-linecap="round"/></svg>',
    },
};

/**
 * Show an empty state message in the given container.
 *
 * @param {string} containerId - DOM element ID to populate
 * @param {string} context - Key from EMPTY_STATE_CONFIGS (e.g., 'no-sessions', 'no-orders')
 */
function showContextEmptyState(containerId, context) {
    const el = document.getElementById(containerId);
    if (!el) return;

    const config = EMPTY_STATE_CONFIGS[context];
    if (!config) {
        console.warn('[Finlet] Unknown empty state context:', context);
        return;
    }

    // For table bodies, wrap in a table row
    const isTableBody = el.tagName === 'TBODY';
    const colspan = isTableBody ? el.closest('table')?.querySelector('thead tr')?.children.length || 6 : 0;

    const emptyHTML = [
        '<div class="empty-state">',
        '  <div class="empty-state__icon">' + config.icon + '</div>',
        '  <p class="empty-state__headline">' + (typeof esc === 'function' ? esc(config.headline) : config.headline) + '</p>',
        '  <p class="empty-state__text">' + (typeof esc === 'function' ? esc(config.text) : config.text) + '</p>',
        config.cta ? config.cta : '',
        '</div>',
    ].join('');

    const finalHTML = isTableBody
        ? '<tr class="empty-row"><td colspan="' + colspan + '">' + emptyHTML + '</td></tr>'
        : emptyHTML;

    el.innerHTML = trustedHTML(finalHTML);
}

/**
 * Hide/clear the empty state from a container.
 * Called before rendering real data.
 *
 * @param {string} containerId - DOM element ID to clear
 */
function hideContextEmptyState(containerId) {
    const el = document.getElementById(containerId);
    if (!el) return;

    // Only clear if it currently contains an empty-state
    const emptyState = el.querySelector('.empty-state');
    if (emptyState) {
        // For tbody, remove the empty-row tr
        const emptyRow = el.querySelector('.empty-row');
        if (emptyRow) {
            emptyRow.remove();
        } else if (emptyState.parentNode === el) {
            emptyState.remove();
        }
    }
}

/**
 * Show per-widget error state with a "Retry" button.
 * Reuses existing .error-state CSS classes.
 *
 * @param {string} containerId - DOM element ID to populate
 * @param {string} message - Error message to show
 * @param {Function} retryFn - Function to call when Retry is clicked
 */
function showWidgetError(containerId, message, retryFn) {
    const el = document.getElementById(containerId);
    if (!el) return;

    const retryId = 'retry-' + containerId + '-' + Date.now();
    const isTableBody = el.tagName === 'TBODY';
    const colspan = isTableBody ? el.closest('table')?.querySelector('thead tr')?.children.length || 6 : 0;

    const errorHTML = [
        '<div class="error-state">',
        '  <div class="error-state__icon">',
        '    <svg width="32" height="32" viewBox="0 0 32 32" fill="none" aria-hidden="true"><circle cx="16" cy="16" r="14" stroke="var(--red)" stroke-width="1.5"/><path d="M16 10v8M16 22v0" stroke="var(--red)" stroke-width="2" stroke-linecap="round"/></svg>',
        '  </div>',
        '  <div class="error-state__text">' + (typeof esc === 'function' ? esc(message) : message) + '</div>',
        retryFn ? '  <button class="btn error-state__retry" id="' + retryId + '">Retry</button>' : '',
        '</div>',
    ].join('');

    const finalHTML = isTableBody
        ? '<tr class="empty-row"><td colspan="' + colspan + '">' + errorHTML + '</td></tr>'
        : errorHTML;

    el.innerHTML = trustedHTML(finalHTML);

    if (retryFn) {
        const retryBtn = document.getElementById(retryId);
        if (retryBtn) retryBtn.addEventListener('click', retryFn);
    }
}

// ============================================================
//  SSE Connection-Lost Banner with Countdown
//  Shows a visible banner when SSE disconnects, with exponential
//  backoff countdown to next reconnection attempt.
// ============================================================

let _sseBannerCountdownTimer = null;
let _sseBannerEl = null;

/**
 * Show the SSE disconnection banner with a countdown to next retry.
 *
 * @param {number} retryInSeconds - Seconds until next reconnection attempt
 * @param {Function} retryNowFn - Function to trigger immediate reconnection
 */
function showSSEBanner(retryInSeconds, retryNowFn) {
    if (!_sseBannerEl) {
        _sseBannerEl = document.getElementById('sse-connection-banner');
    }
    if (!_sseBannerEl) return;

    // Clear any existing countdown
    if (_sseBannerCountdownTimer) {
        clearInterval(_sseBannerCountdownTimer);
        _sseBannerCountdownTimer = null;
    }

    _sseBannerEl.style.display = 'flex';
    let remaining = retryInSeconds;

    const countdownEl = _sseBannerEl.querySelector('.sse-banner__countdown');
    const retryBtn = _sseBannerEl.querySelector('.sse-banner__retry');

    if (countdownEl) {
        countdownEl.textContent = 'Reconnecting in ' + remaining + 's...';
    }

    if (retryBtn) {
        // Remove old listeners by replacing node
        const newBtn = retryBtn.cloneNode(true);
        retryBtn.parentNode.replaceChild(newBtn, retryBtn);
        newBtn.addEventListener('click', function () {
            hideSSEBanner();
            if (retryNowFn) retryNowFn();
        });
    }

    _sseBannerCountdownTimer = setInterval(function () {
        remaining--;
        if (remaining <= 0) {
            clearInterval(_sseBannerCountdownTimer);
            _sseBannerCountdownTimer = null;
            if (countdownEl) countdownEl.textContent = 'Reconnecting now...';
            return;
        }
        if (countdownEl) countdownEl.textContent = 'Reconnecting in ' + remaining + 's...';
    }, 1000);
}

/**
 * Hide the SSE disconnection banner and clear the countdown.
 */
function hideSSEBanner() {
    if (_sseBannerCountdownTimer) {
        clearInterval(_sseBannerCountdownTimer);
        _sseBannerCountdownTimer = null;
    }
    if (!_sseBannerEl) {
        _sseBannerEl = document.getElementById('sse-connection-banner');
    }
    if (_sseBannerEl) {
        _sseBannerEl.style.display = 'none';
    }
}
