// ============================================================
//  Finlet — Public Session View (anonymous read-only)
// ============================================================
//
// Polls the public-session endpoints (5 routes, all under
// `/v1/public/sessions/<id>/*`) every 2.5s and re-renders. Pure read-only:
// no SSE, no event bus, no auth headers, no mutations.
//
// Session ID resolution (in priority order):
//   1. `/sessions/<id>` (canonical short URL exposed in landing.html CTA)
//   2. `/public/<id>` (alias kept for crawlers + docs continuity)
//   3. `?id=<id>` query param (fallback for embed/share scenarios)
//
// Rendering: delegates to the auth-agnostic helpers in `renderers.js`
// (`renderPositions`, `renderOrders`, `renderTrace`, `renderEquityCurve`,
// plus the chart bootstrap `initChart()`). Identical visual output to the
// authenticated dashboard for the four data panels.
//
// Failure modes:
//   - 404 on first load → display "Session not found or not public" in
//     each panel and stop polling.
//   - 404 mid-session (owner unpublished) → same fallback; polling stops.
//   - Transient network errors → preserve last good render, keep polling.
//
// Trusted Types: every `innerHTML` write goes through `trustedHTML()`
// (defined in `api-utils.js`). Bare sinks are blocked by the pre-commit
// gate `scripts/lint-trusted-types.sh`.
//
// Event bus: explicitly NOT used. Direct subscriptions to the dashboard
// bus are blocked outside `event-bus.js` by `scripts/lint-event-bus.sh`.
// The public view is poll-only by design — no SSE, no bus.

const PUBLIC_API_BASE = window.location.origin + '/v1/public/sessions';
const AUTH_API_BASE = window.location.origin + '/v1/sessions';
const POLL_INTERVAL_MS = 2500;
const NOT_FOUND_TEXT = 'Session not found or not public';

let _publicSessionId = null;
let _pollTimer = null;
let _stopped = false;
let _firstLoad = true;

// ---- Blind benchmark state ----
//
// `session.blind === true` flips the page into "anonymized" mode: tickers
// rendered as T_NNNN and timestamps as Day_N. The public/unauth'd endpoint
// family already returns the blinded shape; this client just paints what
// it receives.
//
// The Reveal toggle is OWNER-ONLY. Ownership is detected by probing
// `/v1/sessions/{id}` with credentials (session cookie + any localStorage
// API key). 200 → owner → unhide the toggle. 401/403/404 → leave hidden.
//
// When the owner clicks Reveal, `_revealActive` flips to true and the
// poll loop switches to the AUTHENTICATED endpoint family
// (`/v1/sessions/{id}/*` with credentials) — the server returns the real
// data shape on the authenticated path. Reveal is SESSIONSTORAGE-backed
// (tab-scoped, clears on tab close). Mapping is never shipped to the
// client; the toggle is a hot-swap between two endpoint families.
let _revealActive = false;
let _ownerProbed = false; // idempotency guard — probe runs exactly once
let _bearerKey = null;    // optional Bearer token (localStorage finlet_api_key)

// ---- Session ID extraction ----

function extractSessionId() {
    const path = window.location.pathname || '';
    // Match `/sessions/<id>` and `/public/<id>`. The capture group accepts
    // any non-empty path segment; backend validates the format and returns
    // 404 for malformed IDs (same shape as unknown/private).
    const m = path.match(/^\/(?:sessions|public)\/([^\/?#]+)/);
    if (m && m[1]) {
        return m[1];
    }
    // Fallback: `?id=<value>` query param.
    try {
        const params = new URLSearchParams(window.location.search);
        const q = params.get('id');
        if (q) return q;
    } catch {
        // URLSearchParams unavailable — skip.
    }
    return null;
}

// ---- Public banner owner-label update ----

function updateOwnerLabel(session) {
    const el = document.getElementById('public-owner-label');
    if (!el) return;
    // Default banner text is the static "Anonymous Finlet session" string.
    // When the owner has opted out of anonymity, replace with the session
    // name (HTML-escaped — never inject raw user content).
    if (session && session.public_anonymous === false && session.name) {
        // textContent (not innerHTML) is sufficient for plain text — the
        // browser handles escaping automatically. We still keep the
        // updateOwnerLabel scope tight: any future formatted-text variant
        // must route through trustedHTML().
        el.textContent = String(session.name);
        document.title = `${session.name} — Finlet`;
    } else {
        el.textContent = 'Anonymous Finlet session';
        document.title = 'Public Session — Finlet';
    }
}

// ---- Blind benchmark banner + Reveal toggle ----

function updateBlindBanner(session) {
    const banner = document.getElementById('blind-banner');
    if (!banner) return;
    const isBlind = !!(session && session.blind === true);
    if (isBlind) {
        if (banner.hasAttribute('hidden')) banner.removeAttribute('hidden');
        // Probe ownership exactly once per page load (idempotent). The
        // probe is a single round-trip to /v1/sessions/{id}; 200 means
        // the requester owns the session and the Reveal toggle is shown.
        if (!_ownerProbed && _publicSessionId) {
            _ownerProbed = true;
            attemptOwnerReveal(_publicSessionId);
        }
    } else {
        if (!banner.hasAttribute('hidden')) banner.setAttribute('hidden', '');
    }
}

// Single round-trip ownership probe. Uses the authenticated session
// endpoint — the server already returns 200 if the requester owns the
// session, 404 otherwise. No new endpoint is added.
//
// Auth fallback strategy:
//   1. credentials: 'include' sends session cookies (the dashboard's
//      primary auth mechanism).
//   2. If a Bearer key is stashed in localStorage (CLI / API-key path),
//      add it as Authorization: Bearer.
async function attemptOwnerReveal(sessionId) {
    try {
        const headers = { 'Accept': 'application/json' };
        if (_bearerKey) {
            headers['Authorization'] = 'Bearer ' + _bearerKey;
        }
        const res = await fetch(`${AUTH_API_BASE}/${encodeURIComponent(sessionId)}`, {
            method: 'GET',
            credentials: 'include',
            headers,
        });
        if (res.status === 200) {
            const btn = document.getElementById('reveal-toggle');
            if (btn) btn.removeAttribute('hidden');
        }
        // 401/403/404 → not the owner, leave the toggle hidden.
    } catch {
        // Network error — leave hidden, no recovery needed.
    }
}

// Reveal toggle click handler. Flips _revealActive, persists to
// sessionStorage (tab-scoped — clears on tab close per spec), and
// triggers an immediate re-poll so the swap renders without waiting
// for the next tick.
function bindRevealToggle() {
    const btn = document.getElementById('reveal-toggle');
    if (!btn) return;
    btn.addEventListener('click', () => {
        _revealActive = !_revealActive;
        try {
            if (_publicSessionId) {
                const key = 'finlet_blind_reveal_' + _publicSessionId;
                if (_revealActive) {
                    sessionStorage.setItem(key, '1');
                } else {
                    sessionStorage.removeItem(key);
                }
            }
        } catch {
            // sessionStorage may throw in private-mode browsers; the
            // page remains usable, the toggle just won't persist across
            // refresh (spec already calls for tab-close reset).
        }
        btn.textContent = _revealActive ? 'Hide real data' : 'Reveal real data';
        // Immediate re-fetch so the UI swaps endpoint families now.
        pollOnce();
    });
}

// ---- Overview panel writer (textContent only — no innerHTML) ----

function setText(id, value) {
    const el = document.getElementById(id);
    if (el && value != null) el.textContent = value;
}

function renderOverview(session, portfolio) {
    if (!session || !portfolio) return;
    // Sim time
    const clock = session.clock || {};
    setText('sim-time', formatDateShort(clock.current_time || clock.sim_time) || '--');
    const simTimeEl = document.getElementById('sim-time');
    if (simTimeEl) {
        const dt = formatDateTime(clock.current_time || clock.sim_time);
        if (dt && dt !== '--') simTimeEl.setAttribute('title', dt);
    }

    const totalValue = portfolio.total_value ?? 0;
    const cash = portfolio.cash ?? 0;
    const initialCapital = portfolio.initial_capital
        ?? (session.config && session.config.initial_capital)
        ?? 100000;
    const totalPnl = (portfolio.realized_pnl ?? 0) + (portfolio.unrealized_pnl ?? 0);
    const totalReturnPct = portfolio.total_return_pct ?? (
        initialCapital > 0 ? ((totalValue - initialCapital) / initialCapital) * 100 : 0
    );

    setText('portfolio-value', formatCurrency(totalValue));
    setText('cash-value', formatCurrency(cash));

    const pnlEl = document.getElementById('total-pnl');
    if (pnlEl) {
        pnlEl.textContent = pnlArrow(totalPnl) + formatCurrency(totalPnl, true);
        pnlEl.className = 'stat-value ' + pnlClass(totalPnl);
    }
    const pnlPctEl = document.getElementById('total-pnl-pct');
    if (pnlPctEl) {
        pnlPctEl.textContent = pnlArrow(totalReturnPct) + formatPct(totalReturnPct);
        pnlPctEl.className = 'stat-sub ' + pnlClass(totalReturnPct);
    }

    const returnEl = document.getElementById('total-return');
    if (returnEl) {
        returnEl.textContent = pnlArrow(totalReturnPct) + formatPct(totalReturnPct);
        returnEl.className = 'stat-value ' + pnlClass(totalReturnPct);
    }

    setText('sharpe-ratio', portfolio.sharpe_ratio != null ? portfolio.sharpe_ratio.toFixed(2) : '--');
    setText('max-drawdown', portfolio.max_drawdown_pct != null ? formatPct(portfolio.max_drawdown_pct) : '--');
    setText('win-rate', portfolio.win_rate_pct != null ? formatPct(portfolio.win_rate_pct) : '--');
    if (portfolio.total_trades != null) {
        setText('trade-count', `${portfolio.total_trades} trades`);
    }
}

// ---- Not-found state ----

function showNotFoundState() {
    // Overview tiles → '--'
    ['sim-time', 'portfolio-value', 'cash-value', 'total-pnl', 'total-pnl-pct',
     'total-return', 'sharpe-ratio', 'max-drawdown', 'win-rate', 'trade-count']
        .forEach((id) => setText(id, '--'));

    const banner = document.getElementById('public-owner-label');
    if (banner) banner.textContent = NOT_FOUND_TEXT;
    document.title = 'Session not found — Finlet';

    // Empty-state copy in each panel
    const posBody = document.getElementById('positions-body');
    if (posBody) {
        posBody.innerHTML = trustedHTML(
            `<tr class="empty-row"><td colspan="6"><div class="empty-state">
                <p class="empty-state__headline">${esc(NOT_FOUND_TEXT)}</p>
                <p class="empty-state__text">This session may have been unpublished by its owner, or the URL is incorrect.</p>
            </div></td></tr>`
        );
    }
    const ordersBody = document.getElementById('orders-body');
    if (ordersBody) {
        ordersBody.innerHTML = trustedHTML(
            `<tr class="empty-row"><td colspan="9"><div class="empty-state">
                <p class="empty-state__headline">${esc(NOT_FOUND_TEXT)}</p>
                <p class="empty-state__text">This session may have been unpublished by its owner, or the URL is incorrect.</p>
            </div></td></tr>`
        );
    }
    const traceFeed = document.getElementById('trace-feed');
    if (traceFeed) {
        traceFeed.innerHTML = trustedHTML(
            `<div class="empty-state">
                <p class="empty-state__headline">${esc(NOT_FOUND_TEXT)}</p>
                <p class="empty-state__text">This session may have been unpublished by its owner, or the URL is incorrect.</p>
            </div>`
        );
    }
}

// ---- Fetch wrapper ----
//
// Returns:
//   {ok: true,  data: <json>}
//   {ok: false, status: 404, notFound: true}   ← session unknown OR private
//   {ok: false, status: <other>, notFound: false}
//
// When `_revealActive` is true (blind owner has clicked Reveal), routes
// requests to the AUTHENTICATED endpoint family (/v1/sessions/{id}/*)
// with credentials: 'include' (session cookie) + optional Bearer header.
// The server returns the real data shape on the authenticated path —
// no client-side mapping is needed. If reveal-auth fails (e.g. session
// cookie expired between probe and click), the request returns its
// natural status; the caller preserves last-good blinded render.
async function publicGet(path) {
    try {
        let url;
        let fetchOptions;
        if (_revealActive) {
            url = AUTH_API_BASE + path;
            const headers = { 'Accept': 'application/json' };
            if (_bearerKey) {
                headers['Authorization'] = 'Bearer ' + _bearerKey;
            }
            fetchOptions = {
                method: 'GET',
                credentials: 'include',
                headers,
            };
        } else {
            url = PUBLIC_API_BASE + path;
            fetchOptions = {
                method: 'GET',
                credentials: 'omit',
                headers: { 'Accept': 'application/json' },
            };
        }
        const res = await fetch(url, fetchOptions);
        if (res.status === 404) {
            return { ok: false, status: 404, notFound: true };
        }
        if (!res.ok) {
            return { ok: false, status: res.status, notFound: false };
        }
        const data = await res.json();
        return { ok: true, data };
    } catch {
        // Transient network error — caller preserves last-good render.
        return { ok: false, status: 0, notFound: false };
    }
}

// ---- Poll cycle ----

async function pollOnce() {
    if (_stopped || !_publicSessionId) return;

    const id = encodeURIComponent(_publicSessionId);
    // Issue the 5 reads in parallel — each endpoint is independent.
    const [sessionRes, portfolioRes, historyRes, ordersRes, traceRes] = await Promise.all([
        publicGet(`/${id}`),
        publicGet(`/${id}/portfolio`),
        publicGet(`/${id}/portfolio/history`),
        publicGet(`/${id}/orders`),
        publicGet(`/${id}/trace`),
    ]);

    // 404 on the session-summary endpoint is authoritative for "not
    // public / not found". The other endpoints share the same gate.
    if (sessionRes.notFound) {
        showNotFoundState();
        _stopped = true;
        if (_pollTimer) {
            clearInterval(_pollTimer);
            _pollTimer = null;
        }
        return;
    }
    if (!sessionRes.ok) {
        // Transient — preserve last-good render and try again on the next tick.
        return;
    }

    const session = sessionRes.data;
    // Capture the REAL blind state from the wire payload before any
    // local mutation. This drives the banner (which stays visible while
    // revealed because the page IS still a blind session) and the
    // owner-probe (which gates the Reveal button).
    const sessionIsBlind = !!(session && session.blind === true);

    // When the owner has clicked Reveal, the authenticated endpoint
    // returns REAL ticker/date strings even though the session's
    // underlying `config.blind` is still True (and SessionResponse.blind
    // mirrors config.blind). Override `session.blind` to false locally
    // so the renderers (e.g. renderEquityCurve's Day_N axis) paint the
    // real-shape data correctly. The blind-banner itself still surfaces
    // (the page IS a blind session) — only the chart-axis / time-mode
    // gating flips, which is driven by `window.currentSession.blind`.
    if (_revealActive) {
        session.blind = false;
    }
    // Expose for renderers.js's chart-anchor logic (reads
    // window.currentSession.config.initial_capital for the Y-axis guard).
    // Also surfaces `session.blind` to renderers.js's _isBlindMode helper
    // so renderEquityCurve can switch to Day_N integer time mode.
    window.currentSession = session;
    updateOwnerLabel(session);
    // Banner reflects the wire-shape `blind` flag (NOT the mutated local
    // session). Reveal active just hides the Day_N chart axis; the page
    // is still a blind benchmark session and the banner stays visible.
    updateBlindBanner({ blind: sessionIsBlind });

    if (portfolioRes.ok) {
        renderOverview(session, portfolioRes.data);
        const positions = (portfolioRes.data && portfolioRes.data.positions) || [];
        const posArray = Array.isArray(positions)
            ? positions
            : Object.entries(positions).map(([ticker, pos]) => ({
                ticker,
                ...(typeof pos === 'object' ? pos : { quantity: pos }),
            }));
        const totalValue = (portfolioRes.data && portfolioRes.data.total_value) || 0;
        renderPositions(posArray, totalValue);
    }

    if (historyRes.ok) {
        // Orders feed into the equity chart for trade markers.
        const ordersForChart = ordersRes.ok ? ordersRes.data : null;
        renderEquityCurve(historyRes.data, ordersForChart);
    }

    if (ordersRes.ok) {
        renderOrders(ordersRes.data);
    }

    if (traceRes.ok) {
        renderTrace(traceRes.data);
    }

    _firstLoad = false;
}

// ---- Reasoning / trace expand-collapse delegation ----
//
// Cloned from `app.js:bindEvents()`. Public.html ships the same
// `data-toggle-target` markup in its rendered HTML (via renderers.js), so
// the same delegated click handler unlocks the reasoning + trace
// expansions. No `finlet:*` bus events involved.
function bindToggles() {
    document.addEventListener('click', (e) => {
        const toggle = e.target.closest('[data-toggle-target]');
        if (!toggle) return;
        const targetId = toggle.dataset.toggleTarget;
        const target = document.getElementById(targetId);
        if (!target) return;
        const expanded = target.classList.toggle('expanded');
        toggle.setAttribute('aria-expanded', String(expanded));
        toggle.textContent = expanded
            ? 'hide'
            : (toggle.classList.contains('reasoning-toggle') ? 'show' : 'details');
    });
    document.addEventListener('keydown', (e) => {
        if ((e.code === 'Enter' || e.code === 'Space') && e.target.matches('[data-toggle-target]')) {
            e.preventDefault();
            e.target.click();
        }
    });
}

// ---- Bootstrap ----

document.addEventListener('DOMContentLoaded', () => {
    _publicSessionId = extractSessionId();
    bindToggles();
    bindRevealToggle();
    initChart();

    // Seed Reveal state from sessionStorage (tab-scoped — clears on tab
    // close). When the owner had Reveal active before refresh, the very
    // first poll fires against the authenticated endpoint family. The
    // probe + button-unhide still runs after the first session payload
    // confirms blind=true, so the button label tracks state correctly.
    if (_publicSessionId) {
        try {
            const stored = sessionStorage.getItem('finlet_blind_reveal_' + _publicSessionId);
            if (stored === '1') {
                _revealActive = true;
                const btn = document.getElementById('reveal-toggle');
                if (btn) btn.textContent = 'Hide real data';
            }
        } catch {
            // sessionStorage unavailable (private-mode) — proceed as
            // unreveal'd; no behavioural impact for non-owners.
        }
    }

    // Stash any locally-cached API key (Bearer fallback for the
    // CLI / API-only auth path). The dashboard primary auth is cookie
    // session, but a Bearer header is harmless when present and lets
    // pure-Bearer clients reveal without a cookie session.
    try {
        _bearerKey = localStorage.getItem('finlet_api_key') || null;
    } catch {
        _bearerKey = null;
    }

    if (!_publicSessionId) {
        // No ID in the URL — show the not-found state with a helpful note.
        // The `/public` route (no ID) lands here too; same UX.
        showNotFoundState();
        return;
    }

    // First poll fires immediately; subsequent ticks every POLL_INTERVAL_MS.
    pollOnce();
    _pollTimer = setInterval(pollOnce, POLL_INTERVAL_MS);
});
