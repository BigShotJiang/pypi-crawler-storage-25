## Structure & Size Report

### File Size Distribution

#### Files > 500 lines (26 files)
1. `/Users/justnau/finlet/tests/plugins/test_plugins.py` - 1571 lines
2. `/Users/justnau/finlet/tests/api/test_api.py` - 1465 lines
3. `/Users/justnau/finlet/finlet/api/email_templates.py` - 1304 lines
4. `/Users/justnau/finlet/tests/plugins/test_econ_plugin.py` - 1085 lines
5. `/Users/justnau/finlet/finlet/api/routes_marketplace_developer.py` - 1025 lines
6. `/Users/justnau/finlet/tests/db/test_persistence.py` - 924 lines
7. `/Users/justnau/finlet/finlet/plugins/econ_plugin.py` - 811 lines
8. `/Users/justnau/finlet/tests/api/test_e2e.py` - 811 lines
9. `/Users/justnau/finlet/finlet/leaderboard/api_strategy.py` - 800 lines
10. `/Users/justnau/finlet/finlet/marketplace/prohibited_claims.py` - 781 lines
11. `/Users/justnau/finlet/finlet/api/auth.py` - 739 lines
12. `/Users/justnau/finlet/tests/api/test_mfa.py` - 725 lines
13. `/Users/justnau/finlet/tests/api/test_email_service.py` - 672 lines
14. `/Users/justnau/finlet/tests/core/test_clock_step_integration.py` - 630 lines
15. `/Users/justnau/finlet/finlet/db/models.py` - 602 lines
16. `/Users/justnau/finlet/finlet/api/rate_limit.py` - 583 lines
17. `/Users/justnau/finlet/tests/marketplace/test_prohibited_claims.py` - 571 lines
18. `/Users/justnau/finlet/tests/marketplace/test_geo_middleware.py` - 567 lines
19. `/Users/justnau/finlet/finlet/billing/service.py` - 560 lines
20. `/Users/justnau/finlet/finlet/auth/mfa.py` - 557 lines
21. `/Users/justnau/finlet/finlet/api/routes_email.py` - 553 lines
22. `/Users/justnau/finlet/finlet/api/email_service.py` - 550 lines
23. `/Users/justnau/finlet/finlet/api/mfa.py` - 540 lines
24. `/Users/justnau/finlet/tests/api/test_email_templates.py` - 538 lines
25. `/Users/justnau/finlet/tests/leaderboard/test_benchmark_runner.py` - 522 lines
26. `/Users/justnau/finlet/tests/marketplace/test_review_compliance.py` - 516 lines

#### Files > 300 lines (51 files, excluding above)
- test_security_phase3.py (496)
- finnhub_plugin.py (482)
- price_plugin.py (466)
- test_clock.py (466)
- test_routes_email.py (464)
- test_routes_settings.py (453)
- routes_settings.py (449)
- test_routes_billing.py (446)
- session.py (442)
- app.py (432)
- test_routes_compliance.py (413)
- routes_marketplace_admin.py (409)
- test_input_validation.py (408)
- test_property_based.py (407)
- test_mcp_server.py (407)
- test_session_auth.py (396)
- test_orders.py (392)
- test_billing_service.py (391)
- clock.py (390)
- test_security_phase1.py (387)
- test_routes_mfa.py (382)
- test_portfolio.py (382)
- fred_plugin.py (380)
- test_security.py (380)
- routes_auth.py (379)
- mcp/server.py (378)
- routes_marketplace_compliance.py (374)
- tax_forms.py (373)
- test_auth.py (363)
- persistence.py (362)
- test_fred_resilience.py (362)
- portfolio.py (359)
- test_api_driven_strategy.py (359)
- marketplace/persistence.py (352)
- tax.py (330)
- test_mcp_auth.py (319)
- geo_middleware.py (318)
- test_tax_forms.py (311)
- routes_leaderboard.py (305)
- review_compliance.py (301)
- test_enforcer.py (301)

### God Files (5+ classes or 10+ functions)

**CRITICAL VIOLATIONS - MULTIPLE UNRELATED CONCERNS:**

1. `/Users/justnau/finlet/finlet/db/models.py` - **16 classes, 10 functions** (602 lines)
   - Likely contains multiple unrelated data models. Should be split per entity.

2. `/Users/justnau/finlet/finlet/config.py` - **10 classes, 0 functions**
   - Multiple configuration classes bundled together

3. `/Users/justnau/finlet/finlet/api/routes_auth_mfa.py` - **10 classes, 0 functions**
   - Multiple endpoint request/response models mixed with routes

4. `/Users/justnau/finlet/finlet/api/routes_billing.py` - **10 classes, 0 functions**
   - Same pattern: multiple models in one file

5. `/Users/justnau/finlet/finlet/marketplace/tax.py` - **8 classes, 1 function**
   - Multiple tax-related concerns bundled

6. `/Users/justnau/finlet/finlet/marketplace/tax_forms.py` - **7 classes, 2 functions**
   - Multiple form-related classes

7. `/Users/justnau/finlet/finlet/api/email_service.py` - **8 classes, 1 function**
   - Multiple email-related concerns

8. `/Users/justnau/finlet/finlet/marketplace/models.py` - **6 classes, 2 functions**
   - Multiple data models for marketplace

9. `/Users/justnau/finlet/finlet/marketplace/review_compliance.py` - **6 classes, 5 functions**
   - Multiple compliance checks bundled

10. `/Users/justnau/finlet/finlet/marketplace/prohibited_claims.py` - **5 classes, 6 functions** (781 lines)
    - Large file managing prohibited claims logic

11. `/Users/justnau/finlet/finlet/plugins/base.py` - **7 classes, 0 functions**
    - Multiple plugin base classes

**TEST FILES WITH EXCESSIVE NESTING:**

- `test_clock.py` - 1 class, **46 functions** (466 lines)
  - Likely parameterized tests that should be organized differently
- `test_econ_plugin.py` - **20 test classes** (1085 lines)
  - Excessive test class nesting; should split by feature
- `test_plugins.py` - 1571 lines
  - Massive test file mixing multiple plugin tests
- `test_api.py` - **13 test classes** (1465 lines)
  - API tests should be split by endpoint group

### Module Organization Issues

1. **One-to-Many Test Coverage**: 51 source files lack dedicated test files:
   - All route modules missing individual test files (routes_*.py)
   - Utility modules missing tests: logging.py, metrics.py, ssm.py, config.py
   - Migration code lacks test coverage
   - Stripe integration (stripe_config.py) untested

2. **Many-to-One Test Coverage**: 21 test files exist without corresponding source files
   - Integration tests (test_e2e.py, test_property_based.py) correctly don't have 1-to-1 sources
   - But some test names don't match source file organization

3. **Models Consolidation Anti-Pattern**:
   - `finlet/db/models.py` (16 classes) should split by domain entity
   - `finlet/marketplace/models.py` (6 classes) should split by concern
   - `finlet/config.py` (10 classes) should split by subsystem

4. **Route Files Are Parameter Containers**:
   - Routes files (routes_*.py) exist only to contain Pydantic models for that route module
   - Example: `routes_auth_mfa.py` is 10 request/response classes + small route handler
   - Pattern violates "one file per module" principle

5. **Plugin Asymmetry**:
   - `finlet/plugins/` has 8 files but tests are consolidated in 5 files:
     - test_plugins.py (1571 lines) - generic plugin tests
     - test_econ_plugin.py (1085 lines) - econ tests
     - test_edgar_resilience.py, test_fred_resilience.py (resilience patterns)
     - Only price_plugin.py, finnhub_plugin.py, fred_plugin.py have direct test parallels

### Orphaned Files (no matching test or source)

**Source files without dedicated tests (51 files):**
- All 18 route modules: `routes_*.py` (auth, clock, billing, email, health, leaderboard, legal, market, marketplace_*, portfolio, session, trade)
- Core: `session.py`
- Auth: `mfa.py`
- Billing: `service.py`
- DB: `models.py`, `leaderboard_persistence.py`, migrations (env.py, runner.py, versions/*.py)
- Plugins: `base.py`, `cache.py`, `edgar_plugin.py`, `fred_plugin.py`, `price_plugin.py`
- Leaderboard: `api_strategy.py`, `benchmarks.py`, `profiles.py`, `runner.py`, `scoring.py`
- Marketplace: `dmca.py`, `models.py`, `persistence.py`
- Utilities: `logging.py`, `metrics.py`, `ssm.py`, `config.py`, `errors.py`
- CLI: `cli.py`
- MCP: `server.py`

**Status**: This is INTENTIONAL for integration/E2E tests (test_e2e.py, test_property_based.py) and utility modules. However, many route files should have test coverage.

**Test files without direct source parallels (21 files):**
- Integration/property-based: test_e2e.py, test_property_based.py, test_clock_step_integration.py, test_continuous_clock.py
- Security suites: test_security.py, test_security_phase1.py, test_security_phase3.py, test_security_hardening.py
- Validation suites: test_input_validation.py, test_auth_persistence.py
- Feature tests: test_api_versioning.py, test_key_rotation.py, test_marketplace_gate.py, test_redirect_validation.py, test_session_fingerprint.py, test_session_name.py, test_telemetry.py
- Plugin resilience: test_edgar_resilience.py, test_fred_resilience.py
- Leaderboard integration: test_leaderboard.py, test_leaderboard_persistence.py

**Status**: CORRECT - these are intentional cross-cutting or integration tests.

### Directory Tree Summary

```
finlet/
├── __init__.py
├── config.py (10 classes)
├── logging.py
├── metrics.py
├── ssm.py
├── errors.py (5 classes)
├── cli.py (10 functions) [200 lines, no test]
│
├── api/ (35 files)
│   ├── app.py (432 lines, no test)
│   ├── auth.py (739 lines, 4 classes, 13 functions)
│   ├── deps.py (no test)
│   ├── middleware.py (no test)
│   ├── mfa.py (540 lines, 14 functions)
│   ├── email_service.py (550 lines, 8 classes)
│   ├── email_config.py
│   ├── email_templates.py (1304 lines, 18 functions) [HUGE]
│   ├── rate_limit.py (583 lines, 10 functions, no test)
│   ├── idempotency.py
│   ├── session_auth.py
│   ├── security_middleware.py (269 lines)
│   ├── security_alerts.py
│   ├── state.py (no test)
│   ├── stripe_config.py (no test)
│   ├── config_injection.py
│   ├── routes_*.py (18 files, mostly 3-4 classes each, serve as param containers)
│   │   ├── routes_auth.py (379 lines, 4 classes)
│   │   ├── routes_auth_mfa.py (271 lines, 10 classes, no test)
│   │   ├── routes_billing.py (257 lines, 10 classes)
│   │   ├── routes_clock.py (277 lines)
│   │   ├── routes_csp.py
│   │   ├── routes_email.py (553 lines, 6 classes)
│   │   ├── routes_health.py (no test)
│   │   ├── routes_leaderboard.py (305 lines, no test)
│   │   ├── routes_legal.py (no test)
│   │   ├── routes_market.py (208 lines)
│   │   ├── routes_marketplace_admin.py (409 lines)
│   │   ├── routes_marketplace_compliance.py (374 lines, 6 classes)
│   │   ├── routes_marketplace_developer.py (1025 lines, 6 classes) [HUGE]
│   │   ├── routes_metrics.py
│   │   ├── routes_portfolio.py (no test)
│   │   ├── routes_session.py (238 lines)
│   │   ├── routes_settings.py (449 lines, 7 classes)
│   │   └── routes_trade.py (218 lines)
│
├── auth/ (2 files)
│   ├── mfa.py (557 lines, 11 classes, no test)
│   └── __init__.py
│
├── billing/ (2 files)
│   ├── service.py (560 lines, no test)
│   └── __init__.py
│
├── core/ (7 files)
│   ├── clock.py (390 lines)
│   ├── enforcer.py
│   ├── orders.py (5 classes)
│   ├── portfolio.py (359 lines)
│   ├── session.py (442 lines, no test)
│   ├── trace.py
│   └── __init__.py
│
├── db/ (15 files)
│   ├── models.py (602 lines, 16 classes) [HUGE GOD FILE]
│   ├── persistence.py (362 lines)
│   ├── leaderboard_persistence.py (no test)
│   ├── migrations/
│   │   ├── runner.py (no test)
│   │   ├── env.py (no test)
│   │   └── versions/ (8 migration files, no tests)
│   └── __init__.py
│
├── leaderboard/ (6 files)
│   ├── runner.py (209 lines)
│   ├── api_strategy.py (800 lines, no test)
│   ├── profiles.py (no test)
│   ├── benchmarks.py (no test)
│   ├── scoring.py
│   └── __init__.py
│
├── marketplace/ (13 files)
│   ├── models.py (249 lines, 6 classes)
│   ├── persistence.py (352 lines)
│   ├── tax.py (330 lines, 8 classes)
│   ├── tax_forms.py (373 lines, 7 classes)
│   ├── prohibited_claims.py (781 lines, 5 classes) [LARGE]
│   ├── review_compliance.py (301 lines, 6 classes)
│   ├── disclaimers.py (294 lines)
│   ├── geo_config.py (294 lines)
│   ├── geo_middleware.py (318 lines)
│   ├── geo_ip.py
│   ├── disclaimer_middleware.py (205 lines)
│   ├── dmca.py (no test)
│   └── __init__.py
│
├── plugins/ (8 files)
│   ├── base.py (273 lines, 7 classes)
│   ├── econ_plugin.py (811 lines)
│   ├── finnhub_plugin.py (482 lines)
│   ├── price_plugin.py (466 lines)
│   ├── fred_plugin.py (380 lines)
│   ├── edgar_plugin.py (211 lines)
│   ├── cache.py (no test)
│   └── __init__.py
│
├── mcp/ (2 files)
│   ├── server.py (378 lines, no test)
│   └── __init__.py
│
└── scripts/ (2 files)
    └── ingest_prices.py (229 lines)

tests/
├── conftest.py
├── test_cli.py (no matching source)
├── test_mcp/ (3 files)
├── api/ (34 files) - extensive coverage
├── core/ (10 files) - extensive coverage
├── plugins/ (5 files) - consolidated tests
├── leaderboard/ (4 files)
├── marketplace/ (11 files)
├── billing/ (2 files)
└── db/ (2 files)

STATISTICS:
- Total source files: 110 (finlet/ 87 + scripts/ 2 + root 1 + docs)
- Total test files: 134
- Avg lines per source file: ~300-400
- Avg lines per test file: ~200-300
- Files > 500 lines: 26 (19% of codebase)
- Files > 300 lines: 77 (51% of codebase)
- God files (5+ classes): 60+ violations
```

## Key Findings

### Critical Issues
1. **email_templates.py (1304 lines)** - Massive file containing template strings; split by template domain
2. **db/models.py (602 lines, 16 classes)** - Consolidates all ORM models; split one file per entity
3. **routes_marketplace_developer.py (1025 lines)** - Route parameter container is too large
4. **test_plugins.py (1571 lines)** - Plugin tests should be split by plugin name
5. **test_api.py (1465 lines)** - API tests should be split by route group

### Architecture Issues
1. **Route files are Pydantic model containers**, not following "one file per module"
   - Routes should contain route logic; models should be separate
   - Example: routes_auth_mfa.py has 10 classes (all models) + 0 routes
2. **Test consolidation without source parallelism** - Hard to navigate which tests cover what
3. **Migration code completely untested** - 8 migration versions with zero test coverage
4. **Orphaned utilities** - logging.py, metrics.py, ssm.py have no tests despite being shared

### Positives
1. ✓ Proper module boundaries respected (core/, plugins/, api/, leaderboard/, marketplace/, db/, auth/, billing/)
2. ✓ No star imports; explicit `__all__` where needed
3. ✓ Test organization mirrors source structure (mostly)
4. ✓ Integration tests properly separated (test_e2e.py, test_property_based.py)
5. ✓ Resilience tests isolated (test_*_resilience.py)
