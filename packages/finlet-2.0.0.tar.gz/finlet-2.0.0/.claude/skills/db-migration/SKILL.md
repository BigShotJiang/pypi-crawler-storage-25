---
name: db-migration
description: Guide through a SQLite database schema change in Finlet. Use when the user needs to modify the database schema, add columns, create tables, or run migrations with SQLModel and aiosqlite.
disable-model-invocation: true
argument-hint: <migration-description>
---

# Database Migration

Guide a database schema change: $ARGUMENTS

## Steps

### 1. Modify the SQLModel

Update the relevant model in `finlet/db/`. SQLModel classes define both the Pydantic model and the database schema.

### 2. Create migration

Finlet uses Alembic for migrations:

```bash
alembic revision --autogenerate -m "$ARGUMENTS"
```

Review the generated migration in `alembic/versions/`.

### 3. SQLite limitations

SQLite has limited ALTER TABLE support:
- Can ADD COLUMN
- Cannot DROP COLUMN (before SQLite 3.35)
- Cannot ALTER COLUMN type
- For complex changes, may need to recreate the table

If the migration requires unsupported operations, create a manual migration that:
1. Creates a new table with the desired schema
2. Copies data from the old table
3. Drops the old table
4. Renames the new table

### 4. Backup first

Before running any migration on production data:
```bash
./deploy/backup-sqlite.sh
```

### 5. Apply migration

```bash
alembic upgrade head
```

### 6. WAL mode

Finlet uses SQLite WAL mode for concurrent read access. Verify WAL mode is preserved after migration.

### 7. Test

Write tests to verify:
- New schema works with existing data
- Migration is reversible (`alembic downgrade -1`)
- Application still functions correctly

## Reference

- `finlet/db/` — Database models and connection setup
- `deploy/backup-sqlite.sh` — Backup script
