# Debate — Eval Assertions

> Skill: debate
> Last updated: 2026-03-30

## Assertions

Each assertion is binary: PASS or FAIL. The post-exec eval agent checks these against execution artifacts (task outputs, commit history, file diffs, test results).

### Agent Structure
- [ ] **DB-01:** Exactly 5 agents were spawned: `arch-critic`, `comp-critic`, `code-defender`, `industry-defender`, `moderator`
- [ ] **DB-02:** The 4 debater agents ran in parallel (not sequentially)
- [ ] **DB-03:** Debaters sent reports to the main agent (team lead), NOT directly to the moderator
- [ ] **DB-04:** Main agent forwarded all 4 debater reports to the moderator in a SINGLE message

### Phase Compliance
- [ ] **DB-05:** Phase 0 (Constraints Gathering) occurred before any agents were spawned — main asked the user for known constraints and compiled a constraints block
- [ ] **DB-06:** Each debater's prompt included the constraints block from Phase 0
- [ ] **DB-07:** During Phase 1, main agent used only Agent/TeamCreate/SendMessage — no file reads, grep, or code exploration

### Output Structure
- [ ] **DB-08:** A readiness report file exists at `docs/brainstorms/{TOPIC}_READINESS_REPORT.md`
- [ ] **DB-09:** The report contains all mandatory sections: `## Verdict`, `## Consensus Points`, `## Contested Points` (table format), `## Critical Issues`, `## Improvement Opportunities`, `## Raw Reports`
- [ ] **DB-10:** The Verdict line is one of: READY, NOT READY, or CONDITIONAL
- [ ] **DB-11:** Every finding in the moderator's synthesis cites its source debater by name (e.g., "Per arch-critic: ...")

### Moderator Discipline
- [ ] **DB-12:** The moderator did NOT read any files from the repository — its only inputs were the debater reports forwarded by main
- [ ] **DB-13:** The moderator did not take sides — unresolved issues are reported as unresolved, not rationalized away

### Context Discipline
- [ ] **DB-14:** Main agent read only the verdict line from the final report, not the full report content
- [ ] **DB-15:** Main's final message to the user included the report file path and the `/plan-features --doc` invocation command

### Anti-Pattern Compliance
- [ ] **DB-16:** Debate produced a REPORT only — no planning or code execution occurred within the debate skill
