---
name: test-all
description: Run the full Finlet CI pipeline locally — linting, type checking, and tests. Use this skill whenever the user wants to run all tests, check if everything passes, verify CI locally, run the full test suite, or asks about test status. Also use before commits or deployments.
disable-model-invocation: true
allowed-tools: Bash(pytest *), Bash(ruff *), Bash(mypy *)
---

# Run Full CI Pipeline

Run the complete CI pipeline locally in the same order as GitHub Actions.

## Pipeline Steps (run in order, stop on first failure)

### 1. Lint with ruff

```bash
ruff check finlet/ tests/
```

If there are auto-fixable issues, report them but do NOT auto-fix unless asked. Show the exact errors.

### 2. Type check with mypy

```bash
mypy finlet/ --ignore-missing-imports
```

Report any type errors with file paths and line numbers.

### 3. Run test suite

```bash
pytest tests/ -v --tb=short
```

If `$ARGUMENTS` is provided, pass it to pytest as additional arguments:
```bash
pytest tests/ -v --tb=short $ARGUMENTS
```

## Reporting

After all steps complete, provide a summary:

```
CI Pipeline Results:
  Lint:  PASS/FAIL (N issues)
  Types: PASS/FAIL (N errors)
  Tests: PASS/FAIL (N passed, N failed, N skipped)
```

If any step fails, explain what failed and suggest specific fixes. Include file paths and line numbers for all failures.
