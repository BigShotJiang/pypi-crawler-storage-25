---
name: dashboard-dev
description: Start dashboard development workflow for Finlet's vanilla HTML/JS/CSS dashboard. Use when the user wants to work on the dashboard, add UI features, modify charts, or change the frontend.
disable-model-invocation: true
---

# Dashboard Development

Work on Finlet's dashboard in the `dashboard/` directory.

## Architecture

The dashboard is vanilla HTML/JS/CSS with NO build step:
- `index.html` — Main trading dashboard
- `app.js` — Core application logic, chart setup, API polling
- `styles.css` — Dark theme with CSS variables
- `auth.html/js/css` — Authentication pages
- `settings.html/js/css` — User settings
- `leaderboard.html/js` — Leaderboard view
- `billing.html/js/css` — Billing/subscription pages

### Key patterns
- **TradingView Lightweight Charts** loaded via CDN for financial charts
- **Dark theme** using CSS custom properties
- **2-second polling** for real-time data updates
- **Desktop-primary** design (mobile is secondary)
- **No framework** — vanilla JS with fetch API

## Development workflow

### 1. Start the server
```bash
finlet serve
```
This serves both the API and dashboard.

### 2. Make changes

Edit files in `dashboard/` directly. No build step needed — refresh the browser.

### 3. Test

- Verify the page loads without console errors
- Check that API calls succeed (Network tab)
- Verify charts render correctly
- Test auth flow if auth-related changes

## Conventions

- Use `fetch()` for API calls with proper error handling
- Follow existing CSS variable naming for theming
- Keep JavaScript vanilla — no npm packages, no bundler
- Dashboard connects to API at the same origin
