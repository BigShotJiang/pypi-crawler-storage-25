---
name: plugin-conventions
description: Finlet data plugin development conventions and patterns. Applies when writing or modifying plugins in finlet/plugins/ — covers the DataPlugin interface, PluginResponse format, error handling, and rate limit management.
user-invocable: false
---

# Plugin Development Conventions

These conventions apply when working on `finlet/plugins/`.

## DataPlugin Interface

Every plugin extends `DataPlugin` (from `finlet/plugins/base.py`):
- `plugin_type`: One of "price", "news", "fundamentals", "filings", "economic"
- `plugin_types`: List for multi-type plugins (e.g., Finnhub serves news + fundamentals)
- `name`: Human-readable name
- `requires_api_key`: Whether an API key is needed
- `free_tier_limits`: Rate limit info dict

## Required Methods

### `initialize(config) -> bool`
- Validate configuration (API keys, etc.)
- Set up `httpx.AsyncClient` for HTTP calls
- Return `True` if successful, `False` otherwise

### `query(params, ceiling_time) -> PluginResponse`
- Fetch data from the external source
- Filter ALL items by `ceiling_time` before returning
- Return `PluginResponse` with accurate `items_pre_filter` and `items_post_filter` counts
- Never expose filter delta to the agent

### `health_check() -> PluginHealth`
- Verify API connectivity
- Report rate limit status if applicable
- Return `PluginHealth` with status, message, and optional latency/rate limit info

## PluginResponse Structure

```python
PluginResponse(
    items=[...],                    # The actual data items
    source="plugin-name",           # Plugin name
    query_params={...},             # Echo of query parameters
    ceiling_applied=ceiling_time,   # The ceiling time used
    items_pre_filter=N,             # Count before ceiling filter
    items_post_filter=M,            # Count after ceiling filter
    rate_limit_remaining=X,         # Remaining API calls (optional)
    rate_limit_reset=datetime,      # When rate limit resets (optional)
)
```

## Error Handling
- Specific, actionable error messages (see finlet-conventions)
- Pass through rate limit info (remaining calls, reset time)
- Use 429 for rate limits, 503 for plugin unavailability
- Wrap fragile APIs (like Finnhub) in try/except with descriptive errors

## Built-in Plugins Reference
| Plugin | Type | Library | API Key | Notes |
|--------|------|---------|---------|-------|
| price | price | `pyarrow` | None | EOD OHLCV from Parquet files on S3 with local cache |
| EDGAR | filings | `edgartools` | None (needs User-Agent) | SEC filings, filter by `filedAt <= ceiling` |
| FRED | economic | `fredapi` | Free key | Use ALFRED vintage dates for point-in-time accuracy |
| Finnhub | news + fundamentals | `finnhub-python` | User key | 60 calls/min free tier |
| econ | economic | `httpx` | None | BLS, BEA, Treasury, Fed Board — FRED-compatible series IDs, no API key required for Treasury/Fed |
