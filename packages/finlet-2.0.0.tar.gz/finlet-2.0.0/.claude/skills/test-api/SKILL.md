---
name: test-api
description: Run Finlet API tests — routes, auth, session ownership, and middleware. Use when the user wants to test API endpoints, verify auth works, or check route behavior.
disable-model-invocation: true
allowed-tools: Bash(pytest *)
argument-hint: [test-pattern]
---

# Run API Tests

Run tests for the API layer (`finlet/api/`).

```bash
pytest tests/api/ -v --tb=short $ARGUMENTS
```

If tests fail, analyze the failures and focus on:
- Authentication (X-API-Key header validation)
- Session ownership enforcement
- Request/response validation (Pydantic models)
- Rate limiting behavior
- Error response format (correct HTTP status codes, actionable messages)
