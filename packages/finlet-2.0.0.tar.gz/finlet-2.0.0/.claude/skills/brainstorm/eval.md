# Brainstorm — Eval Assertions

> Skill: brainstorm
> Last updated: 2026-03-30

## Assertions

Each assertion is binary: PASS or FAIL. The post-exec eval agent checks these against execution artifacts (task outputs, commit history, file diffs, test results).

### Output Structure
- [ ] **BS-01:** A file exists at `docs/brainstorms/{TOPIC}_REQUIREMENTS.md` matching the topic of the brainstorm session
- [ ] **BS-02:** The requirements doc contains all mandatory sections: `## Constraints`, `## Features (priority order)`, `## Deferred Ideas`, `## Killed Ideas`
- [ ] **BS-03:** Each feature entry under `## Features` contains all 5 sub-sections: `Description`, `Success criteria`, `Out of scope`, `Research notes`, `Open decisions`
- [ ] **BS-04:** The doc header includes `> Brainstormed: [date]` and `> Status: Ready for /plan-features`
- [ ] **BS-05:** Features are numbered in explicit priority order (1, 2, 3...)

### Requirements Completeness
- [ ] **BS-06:** All 6 requirements questions are addressed in the output doc: what we're building, priority order, out of scope, hard constraints, decision-required items, success criteria — each either answered or explicitly marked as "open"
- [ ] **BS-07:** The final message to the user includes the exact `/plan-features --doc docs/brainstorms/{TOPIC}_REQUIREMENTS.md` invocation command

### Research Agent Behavior
- [ ] **BS-08:** Research agents returned structured verdicts (FEASIBLE/RISKY/INFEASIBLE, CLEAR/CONFLICT, or bullet points) — not raw file contents or search result dumps
- [ ] **BS-09:** Each research agent verdict is 5 lines or fewer
- [ ] **BS-10:** Research agents cite specific files or URLs in their verdicts, not vague references

### Context Discipline
- [ ] **BS-11:** During Phase 1 (Idea Exchange), main agent used NO tools — no file reads, no grep, no Agent calls. Only conversation with the user.
- [ ] **BS-12:** During Phase 2 (Research Gates), main agent used only the Agent tool to spawn research agents — no inline file reads, grep, or search
- [ ] **BS-13:** Main agent's total context growth for the session stayed under 200 lines (excluding user messages)
- [ ] **BS-14:** Phase 1 used fewer than 500 tokens of main's context

### Anti-Pattern Compliance
- [ ] **BS-15:** Main agent did not relay raw research output to the user — it summarized verdicts into a table format
- [ ] **BS-16:** The 6 requirements questions were woven into conversation, not asked all at once in a single message
