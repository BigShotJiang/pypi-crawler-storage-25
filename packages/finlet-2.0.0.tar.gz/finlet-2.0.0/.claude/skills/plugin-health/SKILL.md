---
name: plugin-health
description: Check the health status of all configured Finlet data plugins. Use when the user wants to verify plugin connectivity, check API keys, diagnose plugin issues, or see rate limit status.
disable-model-invocation: true
allowed-tools: Bash(python *)
---

# Check Plugin Health

Check the health and connectivity status of all configured data plugins.

## Steps

### 1. Read current plugin configuration

Check `finlet/plugins/__init__.py` to see which plugins are registered:
- PricePlugin (S3 Parquet via pyarrow + boto3)
- FinnhubPlugin (Finnhub API)
- EdgarPlugin (SEC EDGAR)
- FredPlugin (FRED API)

### 2. Check each plugin

For each registered plugin, verify:
- **API key configured**: Is the required API key set in environment?
- **Connectivity**: Can we reach the external API?
- **Rate limits**: What's the current rate limit status?
- **Response quality**: Does a sample query return valid data?

### 3. Report

Provide a table:
```
Plugin Health Report:
  Plugin      Status    Latency   Rate Limit    Notes
  price       healthy   120ms     N/A           S3 Parquet data lake
  finnhub     healthy   85ms      52/60         Resets in 45s
  edgar       healthy   200ms     N/A           User-Agent required
  fred        degraded  350ms     95/120        Slow response time
```

If any plugin is unhealthy, explain why and suggest fixes (missing API key, expired key, rate limit exhausted, network issue).
