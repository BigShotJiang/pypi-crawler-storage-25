---
name: test-leaderboard
description: Run Finlet leaderboard tests — rankings, scoring, and metrics. Use when the user wants to test leaderboard functionality or verify ranking calculations.
disable-model-invocation: true
allowed-tools: Bash(pytest *)
argument-hint: [test-pattern]
---

# Run Leaderboard Tests

Run tests for the leaderboard module (`finlet/leaderboard/`).

```bash
pytest tests/leaderboard/ -v --tb=short $ARGUMENTS
```

If tests fail, analyze failures focusing on ranking logic, metric calculations, and edge cases (empty portfolios, tied scores).
