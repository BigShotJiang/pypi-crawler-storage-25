# Execute Plan — Eval Assertions

> Skill: exec-plan
> Last updated: 2026-03-30

## Assertions

Each assertion is binary: PASS or FAIL. The post-exec eval agent checks these against execution artifacts (task outputs, commit history, file diffs, test results).

Entries marked `(RETIRED <date>)` are auto-PASS / skip — the eval agent must NOT report them as FAIL. IDs are preserved unrenumbered so historical eval results in `docs/skill-eval-results.md` stay decodable.

### Pre-Flight
- [ ] **EP-01:** A pre-flight agent was spawned before any code agents — it verified file existence, clean working tree, and ran the full test suite
- [ ] **EP-02:** `docs/KNOWN_FAILURES.md` was updated (or created) by the pre-flight agent with current test state before execution began
- [ ] **EP-03:** Pre-flight agent returned a structured verdict: READY + known failures count, or BLOCKED + reason

### Agent Execution
- [ ] **EP-04:** All code agents were spawned with `isolation: "worktree"` — no code agents ran on main directly
- **EP-05 (RETIRED 2026-04-29):** Watchdog presence. Removed because the watchdog pattern was retired 2026-04-02. Do not check.
- [ ] **EP-06:** Each code agent's prompt included instructions to read `docs/KNOWN_FAILURES.md` first. **Verifiable via `<plan-dir>/team-prompts/<team-id>.md` artifacts** written by the orchestrator at spawn time (see SKILL.md Step 2 LAUNCH). PASS = every `<plan-dir>/team-prompts/*.md` body contains the literal string `docs/KNOWN_FAILURES.md` (case-sensitive). FAIL = any team prompt missing the reference. INCONCLUSIVE = the `team-prompts/` directory does not exist (skill violation; orchestrator forgot to persist prompts) — note the gap in results so the next eval surfaces it. Do not regress to "couldn't verify" without checking the artifact first.
- [ ] **EP-07:** Each code agent's commit message starts with `[Team X]:` (matching their team designation)
- [ ] **EP-08:** Worktree base integrity. Each code subagent's worktree HEAD was reset to `spawn_base_sha` immediately after spawn (orchestrator runs `git -C <wt> reset --hard <spawn_base_sha>` BEFORE the subagent's first tool round) AND, for sequential teams sharing files, the next team's worktree was not spawned until the previous team's commit had landed on main. PASS includes the case where the Agent tool's initial worktree HEAD differed from `spawn_base_sha` and the orchestrator's auto-reset corrected it before the subagent wrote anything. FAIL is reserved for: orchestrator skipped the post-spawn reset; reset failed and the subagent proceeded on a stale base; a sequential team forked from pre-merge code. See `docs/decisions/exec-plan-worktree-auto-reset.md`.

### Validation Gates
- [ ] **EP-09:** A test gate agent ran after each session completed (per-session, not per-team)
- [ ] **EP-10:** Test gate agents differentiated between new failures and pre-existing known failures from `docs/KNOWN_FAILURES.md`
- [ ] **EP-11:** A session checkpoint ran after each session: full test suite, plan doc updated with completed teams, status reported to user

### Context Discipline
- [ ] **EP-12:** Main agent did not read source files, run tests, resolve merge conflicts, grep, or write/edit code — all delegated to specialized agents
- [ ] **EP-13:** Main agent read the plan document once at the start (Step 0), not repeatedly throughout execution. **Verifiable via `<plan-dir>/exec-trace.txt` artifact** written by the orchestrator immediately after the Step 0 plan read (see SKILL.md Step 0). PASS = `exec-trace.txt` contains exactly ONE line beginning with `read_plan ` AND `orchestrator=true`. FAIL = 2+ such lines (orchestrator re-read mid-execution, violating the lean-coordinator invariant). INCONCLUSIVE = the file does not exist (skill violation; orchestrator forgot to record the trace). Subagent reads of the plan are NOT counted — only orchestrator reads enter `exec-trace.txt`. Do not regress to "couldn't verify" without checking the artifact first.

### Finalization
- [ ] **EP-14:** A doc update agent updated project documentation after execution: `docs/ARCHITECTURE.md`, `docs/REMAINING_TASKS.md`, `docs/KNOWN_FAILURES.md`, and decision records if applicable
- [ ] **EP-15:** Doc update changes were committed with a message that (a) starts with `docs:` or `Update docs`, AND (b) names the iteration/plan (e.g., `docs: bug-hunt 20260428T013300Z6e79 — record fixes for ...` or `Update docs after Data Pipeline Session 3 execution`). The verb after the prefix is unconstrained — `record fixes for`, `stamp completion`, `update after`, etc. all PASS. The only FAILs are: missing iteration name, or commit message that doesn't reference the docs work.
- [ ] **EP-16:** `TeamDelete` was called after all work was merged and teammates shut down — no orphaned teams left active
- [ ] **EP-17:** If `TeamDelete` failed due to active teammates, `shutdown_request` was sent to each remaining teammate before retrying

### Anti-Pattern Compliance
- **EP-18 (RETIRED 2026-04-29):** Watchdog non-persistence. Same reason as EP-05.
- [ ] **EP-19:** Known failures from `docs/KNOWN_FAILURES.md` were NOT reported as regressions by any agent or gate

### Codex Adversarial Gates
- [ ] **EP-20:** After each team merge in Step 2, the main orchestrator ran `/codex review` against the team's just-merged diff (`main~1..main`) as a PARALLEL gate alongside the test gate. Per-team Codex findings (BLOCKER / STRONG-SUGGESTION / NIT) are logged in `<plan-dir>/codex-diff-reviews/<team-id>.md` OR surfaced in the final summary. PASS = the artifact directory exists with one file per merged team, OR the final summary explicitly enumerates per-team Codex diff-review results. FAIL = N teams merged but fewer than N Codex diff-reviews are recorded. INCONCLUSIVE = no Codex binary available (note in summary, do not silently skip the gate).

- [ ] **EP-21:** After deploy-verify success in Step 4, the main orchestrator ran a Codex consult-mode adversarial RETEST against the deployed surface for each bug/feature the plan claims to have fixed. The retest probes ORIGINAL repro + ≥3 variations per claimed fix (different inputs, adjacent code paths, downstream surfaces, hygiene re-check, interaction with adjacent recent fixes). Results are recorded in the final summary as `codex_retest: N variations × M bugs all PASS at sha <sha>` OR (on FAIL) follow-up bug-reports are filed via `mcp__finlet__report_bug` AND surfaced via PushNotification. PASS = retest ran and results are reported. FAIL = deploy-verify succeeded but no retest results in the summary. NOT_APPLICABLE = local-only run (push skipped) OR purely doc/skill PR with no behavioral surface.
