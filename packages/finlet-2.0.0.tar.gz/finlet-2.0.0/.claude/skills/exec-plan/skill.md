---
name: exec-plan
description: Execute an execution plan document by orchestrating worktree subagents, enforcing sequential merge gates, and tracking progress. Main agent stays lean — all work delegated.
user_invocable: true
---

# Execute Plan

State machine that reads an execution plan document and mechanically executes it — launching worktree subagents, enforcing sequential merge gates with targeted tests, and tracking progress.

## Invocation

```
/exec-plan [path to execution plan] [--worker-type <subagent_type>]
```

Examples:
- `/exec-plan docs/brainstorms/EXECUTION_PLAN.md`
- `/exec-plan docs/brainstorms/WEBSOCKET_PLAN.md`
- `/exec-plan docs/brainstorms/BUG_HUNT_LOOP_PLAN.md --worker-type codex:codex-rescue`

## Core Principle: Main Agent Does Nothing

Main is a coordinator. It reads the plan doc (once), launches subagents, receives completion notifications, routes decisions, reports to user.

Main does NOT read source files, run tests, resolve merge conflicts, grep/explore, or write/edit code. ALL of that is delegated to specialized subagents.

## Pipeline

### Step 0: Parse the Plan

Read the execution plan document. Extract:
- Team list with dependencies
- Session grouping
- File conflict table
- Per-team specs (files, validation, agent instructions)

If the plan is missing required sections (file conflict table, validation commands, "read these first" lists), STOP and tell the user: "This plan is missing [X]. Run `/plan-features` to generate a complete plan."

**Trace this read.** Immediately after the single Read of the plan, append one line to `<plan-dir>/exec-trace.txt` (create if missing). Format:

```
read_plan ts=<UTC ISO 8601> plan_sha=<git rev-parse HEAD:path/to/plan.md or "untracked"> orchestrator=true
```

Durable audit trail for EP-13. Orchestrator MUST NOT append a second `read_plan` line — re-reading the plan post-Step-0 is the exact behavior EP-13 forbids. Mid-execution state goes in memory or via subagent (subagent reads don't enter `exec-trace.txt`). See `docs/decisions/exec-plan-eval-trace-artifacts.md`.

### Step 0.5: Set the watchdog — MANDATORY before any subagent spawn

`CronCreate` a watchdog before pre-flight. No time-estimate exception — every exec-plan invocation sets one. See [[feedback-watchdog-cron]].

```
CronCreate(
  cron: "3,13,23,33,43,53 * * * *",
  prompt: "<watchdog probe — see template below>",
  recurring: true,
)
```

The watchdog prompt MUST:
- Run probes INLINE via a single `bash -c` chain (do NOT spawn a subagent — ~40k cold-start tax for schemas + CLAUDE.md, ~14× more expensive than inline).
- Emit ONE line: `WATCHDOG: <DONE|ACTIVE|HUNG> | local=<sha> prod=<sha> pr=<state> deploy=<state> td_mtime_age=<s>`.
- Define DONE precisely (e.g., `local==prod AND PR is MERGED AND deploy=success`).
- Define HUNG precisely (e.g., `latest team output mtime > 1200s AND no commit on the team's worktree branch`).
- Default to ACTIVE.

The watchdog ACTION block MUST:
- DONE → `PushNotification` with shipped sha + `CronDelete` itself.
- HUNG → `PushNotification` + `SendMessage` to stuck agent with resume instructions (e.g., "commit via `git -C $(pwd) commit -am '[Team X]: ...'` and report DONE").
- ACTIVE → silent.

`CronDelete` after Step 4 push lands and prod sha flips. Don't leave it firing.

### Step 1: Pre-Flight Check

Spawn a **pre-flight agent** (general-purpose) to:
- Verify all files referenced in the plan exist
- Check no uncommitted changes in working tree
- Run full test suite on current main
- **Update `docs/KNOWN_FAILURES.md`** — read if exists, add NEW pre-existing failures, remove ones that now pass. Living reference, not regenerated per run.
- **Add `@pytest.mark.xfail` markers** to all known failing tests with `reason=` from KNOWN_FAILURES.md. The marker is the enforcement; KNOWN_FAILURES.md is the human reference.
- **Pin and report `spawn_base_sha`.** After all pre-flight commits land, capture `git rev-parse HEAD` and return as `spawn_base_sha`. Main passes this to every Step 2 code subagent so worktrees fork from a known clean base.

Format for `docs/KNOWN_FAILURES.md`:
```markdown
# Known Test Failures
> Last updated: [date] by pre-flight check

| Test | File | Reason | Since |
|------|------|--------|-------|
| test_name | path/to/test.py | One-line reason | [date first seen] |
```

Returns: READY + known failures count + spawn_base_sha, or BLOCKED + reason. Known failures are pre-existing, not blockers — execution proceeds.

### Step 1.5: Argument parsing

Parse `--worker-type <subagent_type>`. If set, pass as `subagent_type` to Step 2 spawns; otherwise default. Reject unknown flags: "Unknown flag: ..." and abort.

### Step 2: Execute Session Groups

For each session group in the plan:

#### Sequential Teams (shared file conflicts)

Process one at a time, in dependency order:

```
For each team in sequence:
  1. LAUNCH  — spawn code subagent in worktree
  2. WAIT    — subagent completes and notifies automatically
  3. MERGE   — merge worktree branch to main
  4. TEST    — run targeted tests on main after merge
  5. NEXT    — only proceed to next team if tests pass
```

**1. LAUNCH: Code Subagents**

For each batch of agents (parallel or sequential), spawn all **code subagents** with `isolation: "worktree"` and `run_in_background: true`.

If `--worker-type <type>` was passed, spawn with `subagent_type: <type>`; otherwise default (typically `general-purpose`).

**Pin the worktree base — auto-reset, no exceptions.** The Agent tool's `isolation: "worktree"` forks from `git rev-parse main` at spawn and accepts no base-commit arg. Pre-flight commits race the spawn → worktree can fork behind `spawn_base_sha`. See [[feedback-exec-plan-worktree-resolution]]:

  1. **Spawn** code subagent with `isolation: "worktree"` and `run_in_background: true`. Tool returns synchronously with worktree path; subagent runs async.
  2. **Immediately** (same tool round, before reading any other result), run:
     ```bash
     git -C <worktree-path> rev-parse HEAD                # observe pre-reset
     git -C <worktree-path> reset --hard <spawn_base_sha> # unconditional
     git -C <worktree-path> rev-parse HEAD                # verify post-reset
     ```
     Third command MUST equal `spawn_base_sha`. If not, abort and respawn.
  3. **Only then** await completion.

Unconditional reset: worktree is on a fresh branch with clean tree, subagent hasn't started — reset-when-equal is a cheap no-op, removes a branch in orchestrator logic. See `docs/decisions/exec-plan-worktree-auto-reset.md`.

**If auto-reset fails** (rare — git lock contention): abort, `git -C <wt> rev-parse HEAD` to confirm state, respawn after main HEAD == `spawn_base_sha`.

**Last-resort fallback** (Agent tool broken, reset fails repeatedly): replace merge step with per-file cherry-pick scoped to the team's `Files touched` list to avoid inheriting stale `.gitignore` / `KNOWN_FAILURES.md` / artifacts.

**Coordinator Bash CWD discipline.** After spawning a worktree subagent, orchestrator's OWN Bash can silently inherit the worktree as CWD. Coordinator git ops then operate on worktree branch — `git merge worktree-agent-X` reports "Already up to date" while `main` is untouched. CWD drift is invisible. See [[feedback-bash-cwd-sticky]].

- **Always use `git -C /Users/justnau/finlet <op>` for coordinator git ops** — `rev-parse`, `merge`, `branch --show-current`, `status`, `log`, `push`.
- **Verify before any merge:** `git -C /Users/justnau/finlet rev-parse --show-toplevel` must print `/Users/justnau/finlet`, not a `.claude/worktrees/` path.

Code agent prompt template:
```
You are [Team Name].

[Paste the team's spec from the plan: blocked-by, read-these-first,
files-touched, deliverable, validation, agent instructions]

CRITICAL RULES:
- Read `docs/KNOWN_FAILURES.md` first — do NOT report these as issues
- Read the "Read these files first" list BEFORE writing any code
- Follow existing patterns in those files
- You MUST `git add` and `git commit` all your changes before finishing
- Your commit message must start with "[Team X]:"
- Run the validation commands from your spec before finishing
- If validation fails, fix the issue and re-commit

When done, report: DONE + commit hash + validation results
OR: BLOCKED + what went wrong
```

**Persist each team's prompt as an artifact.** Before each spawn, write the full prompt to `<plan-dir>/team-prompts/<team-id>.md` (e.g. `team-A.md`, `team-1.md`). Create directory if missing. Write BEFORE spawn — durable through orchestrator crash. Durable audit trail for EP-06. See `docs/decisions/exec-plan-eval-trace-artifacts.md`.

Subagents terminate automatically. Main receives completion notification — no polling.

**2. SEQUENTIAL MERGE WITH MICRO-GATES**

Merge each subagent's work as it completes. Each merge gets TWO parallel gates: test (catches behavioral breaks) + **Codex diff review** (catches scope creep + diff-only defects tests don't see). See [[feedback-codex-three-checkpoints]].

```
For each completed subagent:
  1. Verify commit exists on worktree branch:
     - `git log [worktree-branch] --oneline -1`
     - If NO commit: ALERT — do NOT clean up, work would be lost
  2. Merge to main: `git merge [worktree-branch]`
  3. Run TWO gates IN PARALLEL:
     a. TEST GATE: `uv run pytest tests/ -q --timeout=120` (or team's validation scope)
     b. CODEX DIFF REVIEW: `/codex review` against `main~1..main`
        - Prompt: see "Codex diff-review prompt" below
        - Classification: BLOCKER / STRONG-SUGGESTION / NIT
  4. Wait for BOTH:
     - TEST FAIL or CODEX BLOCKER → stop, fix (fix agent on main or amend), re-run failed gate
     - TEST PASS + only STRONG/NIT → log to `<plan-dir>/codex-diff-reviews/<team-id>.md`, proceed
     - STRONG-SUGGESTIONs do NOT block next merge; final summary surfaces them for triage before PR push (Step 4 substep 4)
```

Tests prove behavior; Codex diff-review proves intent. Catches scope creep, missed tests for new paths, commit-message lies, hidden regressions, lint-fix slippage.

**Codex diff-review prompt (Step 2 micro-gate):**

> "You are reviewing the diff for ONE team's just-merged commit on a multi-team exec-plan. The team's spec — what they were SUPPOSED to touch, what they were SUPPOSED to deliver — is in `<plan-dir>/team-prompts/<team-id>.md`. Read it. Then read the diff (`git diff main~1..main`). Attack the diff with these specific lenses: (a) Scope creep — does the diff touch files NOT in the team's declared `Files touched` list? Each unscoped file is a BLOCKER unless justified inline in the commit message. (b) Missed tests — does the diff add a new code path (new branch, new function, new helper) without a test that exercises it? Each missed test is a STRONG-SUGGESTION. (c) Commit message lies — does the message say 'X fix' while the diff includes Y unrelated change? BLOCKER. (d) Hidden regressions — defaults flipped, log levels lowered, error swallowing introduced, fallback path silently shortened. (e) Hygiene — high-entropy fixtures (random hex ≥8 chars), secrets/tokens in test data, leak surfaces newly exposed. (f) Lint-fix slippage — comments removed without justification, type hints weakened, public API surface widened. (g) Plan-claim drift — the plan's recon evidence (file:line cites) no longer matches the diff after the team's edits. Output BLOCKER / STRONG-SUGGESTION / NIT. Be brutal; tell me what's wrong."

**Never trust agent self-reports.** "DONE" = "claims done, pending verification." Verify on main: `git log` for commit, test run, Codex diff review. See [[feedback-never-trust-agent-reports]].

### Step 3: Session Checkpoint

After all teams in a session merge:

1. Spawn a **checkpoint agent** to run full test suite, update plan doc (mark completed teams), report status.

2. Report to user:
   ```
   Session N complete.
   Teams merged: [list]
   Tests: X passed, Y failed
   Next session: [teams] — proceed? (y/n)
   ```

3. Wait for user confirmation before next session.

### Step 4: Finalize

After all sessions complete (includes Step 4.5 post-execution eval before cleanup):

1. Spawn a **finalize agent** (no worktree — runs directly on main) to:
   - Run full test suite once more
   - Run linter and type checker
   - Run `uv run ruff check --fix` on shared/generated files (like `schemas/__init__.py`) and commit — agents don't write lint-clean code for aggregated files
   - Update plan doc (mark all COMPLETED, add completion date)
   - **Stage eval-trace artifacts.** `git add <plan-dir>/exec-trace.txt <plan-dir>/team-prompts/`. Commit message: `exec-plan: stage eval-trace artifacts for <plan-name>`. If missing, surface gap in report — do NOT create empty placeholders.
   - Clean up worktrees: `git worktree remove -f -f <path>` (double-force required — Agent tool writes lock reason; single-force rejected), then `git worktree prune`
   - List orphaned branches

2. Spawn a **doc update agent** (no worktree — runs directly on main). **Non-negotiable** — stale docs mislead:
   - Update `docs/ARCHITECTURE.md` for new modules, moved files, changed dependencies, new endpoints, schema changes
   - Update `docs/REMAINING_TASKS.md` — mark completed, add newly discovered
   - Add/update decision record in `docs/decisions/` for non-trivial technical decisions
   - Update `docs/KNOWN_FAILURES.md` — remove fixed failures, remove the corresponding `@pytest.mark.xfail` markers
   - Commit: "Update docs after [plan name] execution"

3. **Step 4.5: Post-Execution Eval** (skip silently if no eval files exist)

   Runs only if a skill used during execution has `eval.md` in its `.claude/skills/[name]/`.

   **Strict ordering gate (EP-14 / EP-15):** Eval MUST NOT start until doc-update has either (a) produced a docs commit observable via `git log --oneline -1 -- docs/ ARCHITECTURE.md REMAINING_TASKS.md KNOWN_FAILURES.md decisions/`, OR (b) returned "no doc changes needed" with justification. Do NOT batch eval and doc-update in parallel — eval races, samples stale state, false-positive in `docs/skill-eval-results.md`.

   Spawn a **eval agent** (general-purpose, no worktree, read-only):
   ```
   You are the post-execution eval agent.

   Skills used: [list from plan doc]
   Execution summary: [task completion, test results, commits]

   For each skill with eval.md in .claude/skills/[name]/:
   1. Read eval.md
   2. Check each assertion against execution artifacts (git log, file state, test results)
   3. For each FAIL: record skill, assertion ID, expected vs actual

   Append to docs/skill-eval-results.md:

   ### [DATE] — [SKILL NAME]
   - **[ID] FAIL:** Expected [X]. Got [Y]. → Fix: [skill change]

   ### [DATE] — All Pass (if all pass)
   Skills checked: [list].

   Do NOT fix skills. Only observe and record.
   ```

   **Context:** eval receives only skills list + eval.md paths + execution summary. NOT the full transcript.

   **Non-blocking:** failures recorded but do NOT block cleanup or final report.

4. **Push to origin via PR.** Branch protection on `main` requires PR + green CI; direct push rejected. Run after Step 4.5 eval so eval commit goes up too. Direct main-agent Bash — no subagent. See [[feedback-pr-gated-ci]].

   ```bash
   PR_BRANCH="exec-plan/$(basename "$PLAN_PATH" .md)-$(date -u +%Y%m%dT%H%M%SZ)"
   git -C /Users/justnau/finlet push origin main:refs/heads/$PR_BRANCH
   PR_URL=$(gh pr create \
     --title "exec-plan: $(basename "$PLAN_PATH" .md)" \
     --body "Auto-generated by /exec-plan from \`$PLAN_PATH\`. Each commit corresponds to one team in the plan." \
     --base main \
     --head "$PR_BRANCH")
   echo "PR opened: $PR_URL"
   PR_NUM=$(echo "$PR_URL" | grep -oE '[0-9]+$')
   gh pr checks "$PR_NUM" --watch     # blocks until checks resolve
   gh pr merge "$PR_NUM" --rebase     # rebase preserves [Team X]: per-team commits
   git -C /Users/justnau/finlet fetch origin main
   git -C /Users/justnau/finlet pull --ff-only origin main
   ```

   **Why rebase, not squash:** preserves `[Team X]:` per-team commit provenance for blame/rollback.

   **CI behavior:** PRs to main trigger `ci.yml` (paths-allowlisted to `finlet/`, `dashboard/`, `tests/`, `pyproject.toml`, `deploy/`, `.github/workflows/`, `scripts/`, `.security/`). Diff outside allowlist → ci.yml skipped, PR auto-merges. Flaky check → `gh run rerun <run-id> --failed`. Do NOT `--admin` or disable branch protection.

   **Do NOT fall back to `git push origin main`.** If PR flow fails, surface error in final summary and stop.

   Skip with "push: skipped — local-only run" only if: no remote, user said "stay local", or pre-flight reports non-main branch.

5. **Codex retest auto-loop (REQUIRED after deploy-verify success).** After PR merged AND `/v1/health` `git_sha` confirms prod is live on new SHA, run a Codex adversarial retest against deployed surface BEFORE final summary. Catches "fix is partial" failure mode where tests + diff-review pass but deployed behavior is still broken. See [[feedback-codex-three-checkpoints]] and [[feedback-deploy-restart-silent-failure]].

   **When to run:**
   - ALWAYS after successful deploy-verify on remote-pushed runs.
   - SKIP for local-only runs (no deployed surface).
   - SKIP if merged diff is pure doc/skill (no `.py` / `.ts` / runtime-code).

   **Invocation:** `/codex` in consult mode (NOT `/codex review` — artifact is deployed surface, not diff). Pass plan path + prod SHA + claimed-fixed list.

   **Adversarial retest prompt:**

   > "You are doing a CODEX RETEST against a freshly-deployed fix. Plan: `<plan-doc-path>`. Prod SHA: `<sha>`. The plan claims to have fixed the following at `<sha>`: [list — bug IDs or feature names]. Your job is to try to break the deployed fix. For each claimed bug/feature, run the ORIGINAL repro plus AT LEAST 3 variations that probe adjacent surfaces. Examples of variation: (a) same bug with different inputs (BUY → SELL, cash → shares, valid ticker → blind-mapping ticker), (b) the same defect class on an adjacent code path (Bug 3 fixed snapshot drift on advance_time → check submit_order, complete_session, refresh_prices for the same live-clock-read race), (c) downstream surfaces (REST + MCP + SSE + benchmark export — each can have its own implementation of the same contract), (d) hygiene re-check (does the fix leak owner_id under a different key name? does the new error envelope path-sanitize?), (e) interaction with adjacent recent fixes (does fix A interfere with the invariant fix B added two weeks ago?). Report PASS/FAIL per variation. Be ADVERSARIAL — assume the fix is partial. Output: per-bug PASS/FAIL with evidence (HTTP status, response body, log excerpt). Anything that FAILS becomes a new bug-report filed via `mcp__finlet__report_bug` OR (if MCP unavailable) a markdown handoff at `<plan-dir>/codex-retest-followups.md`."

   **Outcomes:**
   - **All PASS** → final summary: "Codex retest: N variations × M bugs all PASS at sha `<sha>`."
   - **Any FAIL** → file follow-up bug-reports immediately; final summary + `PushNotification`: "Codex retest found N partial-fix defects in <bug-id-list>. Recommend re-running /plan-features."
   - **Codex unreachable** → log `codex_retest: skipped (codex CLI unavailable)`. Do NOT block — deploy already shipped.

6. Final summary to user: per-team commits + SHAs; test counts (pass/fail/skip/xfail/xpass); Codex diff-review per team (BLOCKER/STRONG/NIT); Codex retest per claimed fix; main SHA + prod SHA; deferred STRONG-SUGGESTIONs for triage.

## Agent Roster

| Agent | When | Isolation | Purpose |
|-------|------|-----------|---------|
| Pre-flight | Step 1 | None | Verify codebase, update KNOWN_FAILURES.md, add xfail markers |
| Code agent | Step 2 | Worktree | Implement team spec |
| Fix agent | Step 2 (on failure) | None | Fix integration breaks after merge |
| Checkpoint | Step 3 | None | Full test suite + plan doc update |
| Finalize | Step 4 | None (main) | Final validation + ruff --fix + cleanup |
| Doc update | Step 4 | None (main) | Update ARCHITECTURE.md, REMAINING_TASKS.md, decisions/, KNOWN_FAILURES.md |
| Eval | Step 4.5 | None | Check skill eval.md assertions, append failures to results doc |
| Push (via PR) | Step 4.4 | None (main) | feature branch → `gh pr create` → `--watch` → `--rebase`. Direct push blocked. |
| Codex diff review | Step 2 per merge | None (main inline) | `/codex review` against `main~1..main`. Parallel with test gate. |
| Codex retest | Step 4.5 | None (main inline) | `/codex` consult vs deployed surface. ORIGINAL repro + ≥3 variations per fix. |

**Main spawns all subagents. Main runs Codex inline (no subagent — fast text).**

## Pre-Cleanup Commit Check

Before ANY worktree cleanup:
1. `git log [worktree-branch] --oneline -1` to confirm a commit exists
2. If NO commit: **ALERT main agent, do NOT clean up** — work would be lost
3. Only cleanup after commit has merged to main

**Cleanup command:** `git worktree remove -f -f <path>` (double-force). Single-force is rejected on locked worktrees (Agent tool writes lock reason). Work already preserved on main per commit-check.

## Error Recovery

### Code agent doesn't commit
Pre-cleanup commit check catches it. Spawn agent to check state + commit, or respawn.

### Merge conflict
Attempt resolution. If unresolvable, report conflicting files + both versions; ask user.

### Test gate fails after merge
Spawn fix agent on main, `git revert`, or continue (user's call).

### Agent goes silent / times out (>10 min, no completion notification)
- `git log [worktree-branch] --oneline -1`
- Uncommitted changes → spawn agent to commit + finish
- No changes → respawn

## Test Gating Strategy

**xfail = enforcement, KNOWN_FAILURES.md = reference.**

- Pre-flight adds `@pytest.mark.xfail` markers to known failing tests
- Gates run `uv run pytest tests/ -q --timeout=120` unfiltered — xfail handles known failures (xpass = good news, xfail = expected, not a blocker)
- KNOWN_FAILURES.md is reference only; does NOT drive test filtering
- Doc-update agent removes fixed failures from BOTH KNOWN_FAILURES.md AND the xfail marker

**Playwright config note (Finlet-specific):** Config lives at `tests/e2e/playwright.config.ts`, not repo root. Always pass `--config=tests/e2e/playwright.config.ts` explicitly to `npx playwright test`.

## Main Context Budget

6-team plan: plan read ~200 lines (once) + ~10 lines/team + ~20 lines/checkpoint ≈ ~300 lines total. Vast majority of main's context remains for follow-up work.

## Anti-Patterns

1. **Main reading files.** Never. Use Explore agents.
2. **Main running tests.** Never. Use gate/checkpoint agents.
3. **Main resolving conflicts.** Never. Use fix agents.
4. **Reporting known failures as regressions.** Pre-flight adds xfail; if a gate flags one, the marker is missing — fix the marker.
5. **Launching from stale base.** Sequential teams wait for previous team to land on main before worktree spawn.
6. **Big-bang merge then validate.** Merge + test after EACH agent — catch breaks at the source, not 8 teams deep.
7. **Trusting agent self-reports.** "DONE" = "claims done." Verify on main via `git log` + test run. See [[feedback-never-trust-agent-reports]].
8. **Cleaning up worktrees without commit check.** Silent work loss is the worst failure mode.
9. **Finalize in a worktree.** Worktrees create cherry-pick conflicts for trivial changes. Run on main.
10. **Skipping `ruff --fix` post-merge.** Agents don't write lint-clean code for generated/aggregated files.
11. **Skipping the post-execution eval.** Non-blocking, minimal overhead; skipping = undetected skill drift, repeated failure modes.
12. **Filtering tests by KNOWN_FAILURES.md in gate logic.** Gate runs pytest unfiltered; xfail markers handle it.
13. **Skipping the post-spawn worktree reset.** See Step 2 LAUNCH + `docs/decisions/exec-plan-worktree-auto-reset.md`. Skip = agent re-commits gitignored files, misses plan files, merge regresses pre-flight changes.
14. **Trusting Bash CWD after worktree spawn.** Use `git -C /Users/justnau/finlet <op>` for ALL coordinator git ops. See [[feedback-bash-cwd-sticky]].
15. **Bypassing PR flow with `git push origin main` or `gh pr merge --admin`.** Branch protection requires PR + green CI; `--admin` defeats the gate. Fix CI, don't bypass.

## Quality Checklist

- [ ] If `--worker-type` was passed, every code subagent spawn used it (verify by inspecting the spawn calls in main's transcript).
