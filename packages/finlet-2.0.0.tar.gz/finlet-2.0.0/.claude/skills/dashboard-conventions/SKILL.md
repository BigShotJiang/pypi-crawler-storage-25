---
name: dashboard-conventions
description: Finlet dashboard development conventions — vanilla HTML/JS/CSS patterns, TradingView charts, dark theme, and API integration. Applies when modifying files in dashboard/.
user-invocable: false
---

# Dashboard Conventions

These conventions apply when working on `dashboard/`.

## Architecture
- **No build step**: Vanilla HTML/JS/CSS served directly
- **No npm packages**: All external libs via CDN
- **TradingView Lightweight Charts**: Financial charting via CDN script tag
- **Dark theme**: CSS custom properties for all colors

## Patterns
- **API calls**: Use `fetch()` with proper error handling and auth headers
- **Polling**: 2-second interval for real-time data updates
- **Desktop-primary**: Optimize for desktop, mobile is best-effort
- **CSS variables**: All theme colors defined as custom properties in `styles.css`

## File organization
- One HTML file per page/view
- Matching JS file for logic (e.g., `leaderboard.html` + `leaderboard.js`)
- Shared styles in `styles.css`, page-specific in `<page>.css`
