---
name: plan-features
description: Generate execution plan documents for multi-team agent work. Analyzes file conflicts, builds dependency graphs, and produces structured plans that drive flawless parallel execution.
user_invocable: true
---

# Plan Features

Generate a structured execution plan document that enables multi-team agent work with worktree isolation. The plan is the product — execution is mechanical downstream.

## Invocation

```
/plan-features [description of features/changes] [--doc path/to/requirements.md] [--output path/to/plan.md]
```

Examples:
- `/plan-features "add WebSocket support for real-time portfolio updates"`
- `/plan-features --doc docs/brainstorms/SECURITY_ROADMAP.md --output docs/brainstorms/EXECUTION_PLAN.md`
- `/plan-features "refactor plugin system to support async initialization and health checks"`

## What This Skill Produces

A single markdown document containing everything an executor needs to run teams without ambiguity:

1. **File Conflict Table** — which files each team touches (determines merge order)
2. **Dependency Graph** — what blocks what (determines parallelism)
3. **Critical Path** — the longest sequential chain
4. **Per-Team Specs** — files, deliverables, validation, "read these first" lists
5. **Risk Register** — what could break and how to mitigate
6. **Session Grouping** — how to batch teams for execution

## Process

### Step 1: Understand the Scope

Read the user's feature description or requirements doc. If the scope is ambiguous, ask clarifying questions BEFORE proceeding:
- What's in scope vs out of scope?
- Any hard constraints (prohibited libraries, deadline, legal)?
- Any prior decisions already made?
- What test infrastructure exists?

### Step 1.5: Codex Requirements Pre-Review (REQUIRED when invoked with `--doc <path>`)

Submit the requirements doc to Codex for adversarial review BEFORE any recon. ~2 min, highest-leverage upstream gate. See [[feedback-codex-three-checkpoints]].

**When to run:**
- ALWAYS when `--doc <path>` is supplied.
- SKIP for inline `/plan-features "<description>"` (no doc to review).
- SKIP for pure bug-report dumps (e.g., `findings.md` from `/bug-hunt`) — downstream recon + Step 10 carry the load.

**Invocation:** `/codex review <doc-path>`. Fallback to `codex:codex-rescue` subagent if `/codex` unavailable.

**Adversarial prompt:**

> "Adversarial review of a REQUIREMENTS DOC about to feed into `/plan-features`. The doc says what we want to build; planning has not started. Your job is to find what's wrong with the REQUIREMENTS before any architecture work commits to them. Look for: (a) scope ambiguity — phrases like 'support X' without a concrete acceptance test; (b) missing user goals — what does the user actually want that the doc doesn't say; (c) unrealistic constraints stated as requirements; (d) hidden assumptions ('we already have Y' — do we?); (e) requirements that contradict each other; (f) requirements that contradict existing architecture (call out the conflict, don't try to resolve it); (g) over-specified requirements that lock in an implementation when the goal is a behavior; (h) under-specified test plans — the acceptance criteria are vague or absent. Output BLOCKER / STRONG-SUGGESTION / NIT. Be brutal; tell me what's wrong."

**Classification:**
- **BLOCKER** — amend the doc in place BEFORE Step 2.
- **STRONG-SUGGESTION** — incorporate OR document deferral in `## Codex review (Step 1.5)` section.
- **NIT** — log for post-merge follow-up.

**Author the v2 requirements doc.** Amend in place, append `## Codex review (Step 1.5) — findings + responses` section, bump metadata.

**Clean review:** zero findings → section reads "No findings against requirements doc." Proceed; metadata bump optional.

### Step 2: Codebase Reconnaissance

Spawn an Explore agent to map affected areas: files/modules touched, existing patterns, test coverage, current middleware/hook/plugin stack order. Most important step — the file list drives everything.

**Attribution rule (REQUIRED — PF-17):** Every recon finding MUST be attributed to:
- `path/to/file.ext:line_number` or `:line_start-line_end`, or
- A concrete symbol/function/class with its containing file (e.g., `_sell_unlocked() in finlet/core/portfolio.py`)

**Reject** directory-level (`finlet/core/`) or vague ("the codebase", "various files") attributions. Send back with: "Re-attribute every finding to file:line or symbol+file."

**Carry-forward rule:** Plan "Read these files first" lists, "Files touched" entries, and prose referencing existing code MUST preserve the file:line / symbol attribution.

**Predicate-verification rule (REQUIRED — PF-18, MUST):** Every "current state" claim about specific file:line behavior — "X runs BEFORE Y", "the predicate at line N rejects Z", "counter increments at check-time", "order is A → B → C" — MUST be backed by EITHER:

- **(a)** A fenced code block with QUOTED EXCERPT from HEAD, with file:line in the info string:

  ````markdown
  ```python finlet/api/routes_session.py:108-124
  # 112  cached = await _idempotency_store.get(cache_key)
  # 113  if cached:
  # 114      return cached  # idempotency-first
  # 124  await check_session_creation(user)  # quota only on cache miss
  ```
  ````

  OR

- **(b)** A paragraph ending with `(verified by recon agent against HEAD <SHA>)` where `<SHA>` matches the iteration baseline:

  > At `finlet/api/routes_session.py:108-124`, idempotency lookup runs at 112-121 and `check_session_creation` runs at 124 only on cache miss. (verified by recon agent against HEAD `17f1f2d`)

Recon MUST NOT paraphrase from memory or from the blind agent's symptom report — derive from HEAD lines. See [[feedback-agents-hallucinate-specific-file-paths]].

**Reroute rule:** If recon cannot quote/paraphrase against HEAD, demote to `needs-investigation` BEFORE spawning a fix team.

**Codex parallel recon reconciliation (REQUIRED — PF-19, MUST):**

If the input doc's directory contains `codex_recon.md` (e.g., bug-hunt Phase 3.5), reconcile both recons BEFORE writing team specs. Independence is the load-bearing value — reading only one defeats the parallelism.

Detect: `[ -f "$(dirname <input-doc>)/codex_recon.md" ]`. If present:

1. **Union surgery-surface citations.** "Read these files first" MUST be the UNION; single-agent citations attributed: `path:lines — [why; cited only by Codex recon]`.

2. **Files-touched union.** "Files touched" MUST also be the union. Over-touch and verify > under-touch and ship a patch-ineffective fix.

3. **Root-cause disagreement → demote to `needs-investigation`.** Do NOT spawn a fix team. (Scope disagreement is union territory — see rule 4.)

4. **Scope disagreement is union territory.** Take the union, list both files, proceed. Team prompt MUST explicitly say "surgery surface includes parallel surfaces X, Y; do NOT scope down to one."

5. **Empty / missing `codex_recon.md`.** Treat as Phase 3.5 skipped; Claude recon sole source. Log: "Codex recon empty for finding N; Claude recon sole source."

6. **Plan body cites both.** Each team spec's "Recon evidence" MUST include excerpts from BOTH recons when they cite different ranges, with `// Claude recon` or `// Codex recon` attribution per fenced block.

Outside bug-hunt (direct `/plan-features --doc` with no Codex artifact) → no-op; Claude recon sole source.

### Step 3: Decompose into Teams

Break the work into teams where each team:
- Has a single, clear deliverable
- Touches a bounded set of files
- Can be validated independently
- Maps to one worktree agent

**Sizing rule:** If a team touches >8 files, it's too big. Split it.

**Naming rule:** Teams get letter codes (A, B, C) for the main plan or numbered codes (Team 1, Team 2) for sub-plans. Names should be descriptive: "Team J: httpOnly Cookie Auth" not "Team J".

### Step 4: Build the File Conflict Table

This is the MOST CRITICAL artifact. It determines merge order.

```markdown
### Shared File Conflicts
| File | Touched by Teams |
|------|-----------------|
| `path/to/shared_file.py` | A, C, D |
| `path/to/other_file.js` | B, C |
```

**Rule:** If two teams touch the same file, they CANNOT run in parallel (worktree merge conflicts). They must be sequenced, and the merge order matters.

### Step 5: Build the Dependency Graph

Two types of dependencies:
1. **Logical** — Team B's work requires Team A's output to exist
2. **File conflict** — Teams touch the same files (from Step 4)

```markdown
### Dependency Chain
- Team A (independent) ── can start immediately
- Team B (blocked by A) ── A's output is B's input
- Team C (blocked by A, B) ── touches files modified by both
```

### Step 6: Identify the Critical Path

The longest chain of sequential dependencies. This determines minimum execution time.

```markdown
### Critical Path
Team A → Team C → Team D → Team F
```

### Step 7: Write Per-Team Specs

Each team spec MUST include ALL of the following:

```markdown
### Team X: [Descriptive Name]
**Blocked by:** [Team(s) or "none — can start immediately"]

**Read these files first:** (CRITICAL — prevents agents from building on stale assumptions)
- `path/to/file.py:line_start-line_end` — [why: current auth system]
- `path/to/other.py:line_start-line_end` — [why: middleware stack order]

**Recon evidence (REQUIRED if any "current state" claim about file:line behavior is being asserted):**

```python path/to/file.py:line_start-line_end
# quoted excerpt as it exists at HEAD <baseline-SHA>
```

OR a paraphrase ending with `(verified by recon agent against HEAD <baseline-SHA>)`. This subsection is the load-bearing proof that the surgery surface exists in the shape the plan claims.

**Files touched:**
- New: `path/to/new_file.py` — [description]
- Modified: `path/to/existing.py` — [what changes]

**Deliverable:** [One sentence: what exists after this team finishes]

**Validation:**
- [ ] `specific test command` passes
- [ ] `specific lint command` passes
- [ ] [Manual check if applicable]

**Agent instructions:**
- You MUST `git add` + `git commit` before finishing
- Follow existing patterns in [specific file]
- [Any team-specific constraints]
```

**Worked example — quoted-excerpt form:**

`````markdown
### Team B: CLI session create — idempotency before rate limit

**Blocked by:** none.

**Read these files first:**
- `finlet/api/routes_session.py:108-165` — current order of idempotency vs quota vs counter.

**Recon evidence (verified by recon agent against HEAD `17f1f2d`):**

```python finlet/api/routes_session.py:108-124
112  cached = await _idempotency_store.get(cache_key)
113  if cached: return cached  # idempotency-first
124  await check_session_creation(user)  # quota on cache miss
```

```python finlet/api/routes_session.py:158-165
158  session = await create_session(user, payload)
162  await record_session_created(user)  # counter AFTER insert
```

Order at HEAD: idempotency lookup → quota on miss → session insert → counter. Plan's named root cause ("counter increments at check-time before insert") contradicts HEAD (counter is post-insert at line 162). Demoting to `needs-investigation`.
`````

If recon contradicts the plan's named root cause, surface in plan body and reroute to `needs-investigation`.

### Step 8: Risk Register

```markdown
## Risk Register
| Risk | Likelihood | Impact | Mitigation |
|------|-----------|--------|------------|
| Team X breaks Y | Medium | High | [specific mitigation] |
```

Focus on:
- Merge conflicts between teams
- Breaking existing functionality
- Test regressions
- External dependency issues

### Step 9: Session Grouping

Group teams into execution sessions based on:
- Dependency chains (sequential teams in the same session)
- Parallel opportunities (independent teams in the same session)
- Natural breakpoints (good commit points between sessions)

**Merge model:** Each team merges to main individually with a targeted test gate. Teams can *work* parallel but *merge* one at a time. Session checkpoint = full test suite after all session teams merged.

```markdown
## Session Plan

### Session 1
**Sequential:** Team A → Team C → Team D (shared file conflicts)
**Merge order:** A → tests → C → tests → D → tests
**Parallel after D:** Teams E, F, G — each merges and gates independently
**Session checkpoint:** Full test suite after all Session 1 teams merged

### Session 2
**Sequential:** Team H → Team I (depends on Session 1 output)
**Session checkpoint:** Full test suite after all Session 2 teams merged
```

**Key principle:** validate after EACH team merges (catches integration breaks at the source) — session checkpoint is sanity check, per-merge micro-gate is the enforcement.

### Step 10: Codex Adversarial Review (REQUIRED — TWO-PASS HARD GATE before handoff)

MUST submit the plan to Codex adversarial review **TWICE** before exec-plan handoff: v1 → v2 (Step 10a), then v2 → v3 (Step 10b). Both passes are HARD gates with equal weight. Skipping EITHER is a planning bug. ~$10 + 4 min for both passes vs 90+ min to re-iterate a defective ship. See [[feedback-two-pass-codex-review]] and [[project-codex-bugs-3pack-2026-05-22-shipped]].

---

#### Step 10a: First-pass Codex review (v1 → v2)

**Invocation:** `/codex review <plan-doc-path>`. Codex reads the rendered plan, NOT the codebase. Its job is to attack the plan.

If `/codex` unavailable, spawn `codex:codex-rescue` subagent with the adversarial prompt: "Adversarial review of this execution plan. Find what's wrong before we spawn teams. Look for: (a) wrong root cause hypotheses, (b) team scopes that won't actually fix the named bug, (c) test design that asserts a string instead of a behavior, (d) file:line claims that contradict HEAD, (e) hidden file conflicts not in the conflict table, (f) hygiene issues — high-entropy test fixtures that will trip gitleaks, secrets in plan-doc examples, future-leak surfaces not gated. Be brutal. Tell me what's wrong; do not tell me what's right." If neither path reachable, FAIL — surface the gap and do NOT proceed.

**Output classification:**
1. **BLOCKER** — must be fixed in v2.
2. **STRONG-SUGGESTION** — address in v2 unless explicitly deferred.
3. **NIT** — log for post-merge follow-up.

**Author v2.** Amend BLOCKERs in place. Incorporate STRONG-SUGGESTIONs or document one-line rationale for deferral. Bump metadata. Append `## Codex review (Step 10a) — v1 findings + v2 responses` section enumerating each finding + response.

---

#### Step 10b: Second-pass Codex review (v2 → v3) — TARGETED AT v2 AMENDMENTS

After v2 exists, RUN A SECOND CODEX REVIEW. Same invocation + fallback. Prompt MUST target v2 amendments:

> "Second-pass adversarial review of an execution plan. First pass (Step 10a) produced N BLOCKERs in `## Codex review (Step 10a)`. v2 amended those in place — added helper functions, restructured raise sites, decoupled teams, redrew the file conflict table, changed test designs. Attack THE v2 AMENDMENTS — the new attack surfaces.
>
> Look for: (a) NEW current-state claims that contradict HEAD (PF-18 re-arms on every v2 amendment), (b) v2 BLOCKER fixes that introduce NEW bugs (wrong `except` placement, broken invariants, persist-then-raise dropping audit trail), (c) NEW hygiene issues from v2's added code/tests, (d) decoupling claims with hidden dependencies (teams 'independent' but transitively-shared file or CLAUDE.md rule), (e) test designs that assert the WRONG thing for the BLOCKER they gate (test asserts key X absence when BLOCKER was about key Y), (f) Step 10a STRONG-SUGGESTIONs 'deferred with rationale' whose rationale is wrong on inspection.
>
> Critique the FULL plan if needed; v2 amendments are the prime target. Be brutal."

**Author v3.** Amend NEW BLOCKERs (do not re-litigate v1 BLOCKERs). Incorporate-or-defer for STRONG-SUGGESTIONs. Append `## Codex review (Step 10b) — v2 findings + v3 responses` section. Bump metadata to v3.

**Clean Step 10b (green path):** zero new findings → v3 = v2 with metadata bumped; section reads "No new BLOCKERs against v2 amendments." Invocation IS the gate — do NOT skip.

**No Step 10c.** Workflow stops at v3. If v2→v3 re-triggers PF-18, spot-check the new claim only.

---

#### Handoff rules

**Handoff to exec-plan is v3, never v1 or v2.** If only v1 or v2 exists on disk, reject: "Step 10a/10b not run to completion — re-invoke /codex review before /exec-plan."

PF-19 (parallel recon reconciliation) is INDEPENDENT of Step 10a/10b — PF-19 runs during Step 2; Steps 10a/10b attack the rendered plan after Steps 2-9.

## Output Format

The plan document MUST follow this structure:

```markdown
# [Feature Name] — Execution Plan

> Generated from [source]. Last updated: [date]

## Constraints
- [Hard constraints from user]
- [Discovered constraints from recon]

## File Conflict Table
[Step 4 output]

## Dependency Graph
[Step 5 output]

## Critical Path
[Step 6 output]

---

## Teams

### Team A: [Name]
[Step 7 spec]

---

### Team B: [Name]
[Step 7 spec]

---

[...more teams...]

## Risk Register
[Step 8 output]

## Session Plan
[Step 9 output]
```

## Plan Validation Step (REQUIRED — post-generation, pre-handoff to exec-plan)

MUST scan rendered plan body for unverified "current state" claims. Reject if any found. HARD assertion — failure to scan is a planning bug.

**Scan rule:** flag prose asserting "current state" at a specific file:line:

- `currently does X` / `currently runs X` / `current order is X` + `file.ext:N` cite
- `the predicate at line N rejects/accepts Z`
- `runs X BEFORE Y` / `runs X AFTER Y` with line cites
- `the counter increments at <time>` with a line cite
- Line-anchored assertions in "Read these files first" beyond pointer scope

For each flagged claim, verify EITHER (a) a `**Recon evidence**` fenced block whose info string cites the same `file:line` (quoted from HEAD), OR (b) a paragraph ending `(verified by recon agent against HEAD <SHA>)` with body paraphrasing the cited range.

If neither present → UNVERIFIED. Reject with: "Re-run recon for cited ranges and either embed the quoted excerpt or author a recon-paraphrase tagged with the baseline SHA. If recon contradicts the claim, demote to `needs-investigation`."

**Out-of-scope:** pure file-and-range pointers (`routes_session.py:80-150 — current order of idempotency vs quota`) are pointers, not assertions; no recon needed.

**Scan tooling:** `grep -nE '(currently|current order|runs .* (BEFORE|AFTER)|increments at|the predicate at line)' <plan>.md` — loud, not sound; planner reviews each match against the team spec.

## Quality Checklist (verify before delivering)

- [ ] Every team has "Read these files first" list
- [ ] Every team has "You MUST git add + git commit" in agent instructions
- [ ] Every team has specific validation commands
- [ ] File conflict table accounts for ALL shared files
- [ ] No team touches >8 files
- [ ] Dependencies match the file conflict table
- [ ] Critical path is the longest chain
- [ ] Session grouping respects all dependency constraints
- [ ] Every "current state" claim has quoted-excerpt or `(verified by recon agent against HEAD <SHA>)` proof. UNVERIFIED blocks handoff. (PF-18)
- [ ] If `codex_recon.md` exists, every team spec's "Read these files first" AND "Files touched" is the UNION of both recons with single-agent attribution. (PF-19)
- [ ] Step 10a ran, v2 on disk with `## Codex review (Step 10a)` section. (PF-20)
- [ ] Step 10b ran, v3 on disk with `## Codex review (Step 10b)` section. Handoff is v3. (PF-21)

## Anti-Patterns

1. **Missing file conflict table.** Parallel agents → merge conflicts.

2. **No "read these first" list.** Agents build on training-data assumptions.

3. **No commit instruction.** Worktree cleanup loses uncommitted work.

4. **Vague validation.** "Tests pass" ≠ validation. Specific command + expected count required.

5. **Teams >8 files.** Split.

6. **"Follow existing patterns" without a pointer.** Useless.

7. **Parallel teams sharing files.** If two teams touch the same file, they're SEQUENTIAL.

8. **Numeric claims without `grep -c` / `wc -l` backing.** Eyeballed counts produce wrong blast-radius. Recon must run the command.

9. **"Current state" claims unverified against HEAD.** Quote or paraphrase from HEAD — never from the blind agent's symptom report. (PF-18)

10. **Reading only Claude recon when `codex_recon.md` exists.** Wasted parallelism. Union both per PF-19.

11. **Skipping Step 10 — either pass.** ~$10 + 4 min vs 90+ min rework. The most negative-EV step to skip. See [[project-codex-bugs-4pack-v2-shipped]] and [[project-codex-bugs-3pack-2026-05-22-shipped]].
