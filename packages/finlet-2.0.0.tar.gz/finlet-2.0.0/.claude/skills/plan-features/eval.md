# Plan Features — Eval Assertions

> Skill: plan-features
> Last updated: 2026-05-22 (PF-20 + PF-21 added — two-pass Codex adversarial review hard gate)

## Assertions

Each assertion is binary: PASS or FAIL. The post-exec eval agent checks these against execution artifacts (task outputs, commit history, file diffs, test results).

### Output Structure
- [ ] **PF-01:** The plan document contains a `## File Conflict Table` section with a markdown table showing which files each team touches
- [ ] **PF-02:** The plan document contains a `## Dependency Graph` section showing logical and file-conflict dependencies
- [ ] **PF-03:** The plan document contains a `## Critical Path` section identifying the longest sequential chain
- [ ] **PF-04:** The plan document contains a `## Risk Register` section with a markdown table (Risk, Likelihood, Impact, Mitigation)
- [ ] **PF-05:** The plan document contains a `## Session Plan` section grouping teams into execution batches with validation gates between sessions

### Per-Team Spec Completeness
- [ ] **PF-06:** Every team has a "Read these files first" list with specific file paths and reasons (not just "read the relevant files")
- [ ] **PF-07:** Every team has "You MUST `git add` + `git commit`" in its agent instructions
- [ ] **PF-08:** Every team has specific validation commands — actual runnable commands (e.g., `uv run pytest tests/api/test_auth.py -x -q`), not vague "run tests"
- [ ] **PF-09:** Every team has a `Blocked by` field (either specific team names or "none — can start immediately")
- [ ] **PF-10:** Every team has a single-sentence `Deliverable` statement

### Sizing and Structure
- [ ] **PF-11:** No team touches more than 8 files
- [ ] **PF-12:** Teams have letter codes (A, B, C) or numbered codes with descriptive names (e.g., "Team J: httpOnly Cookie Auth")

### Consistency
- [ ] **PF-13:** The dependency graph is consistent with the file conflict table — teams that share files are sequenced, never parallelized
- [ ] **PF-14:** The session grouping respects all dependency constraints from the dependency graph
- [ ] **PF-15:** The critical path is actually the longest chain in the dependency graph (not an arbitrary subset)

### Anti-Pattern Compliance
- [ ] **PF-16:** Numeric claims in the plan (line ranges, file counts, test counts, importers) match ground truth. Eval samples up to 5 specific claims (file:line pointers, range references) and verifies via `grep -n` / `wc -l` against the live tree. PASS if all sampled claims match; FAIL only on actual divergence (e.g., "lines 100-150" but the function is at 80-130). Inline grep output in the plan is not required — the test is accuracy, not evidence preservation.
- [ ] **PF-17:** An Explore agent performed codebase reconnaissance (Step 2) — main did not read files or grep inline
- [ ] **PF-18:** Every "current state" claim in a team spec — prose that asserts what code at a specific `file:line` range currently does (orderings, predicates, contracts, counter-increment timing, "X runs BEFORE/AFTER Y", "currently does X") — is backed by EITHER (a) a fenced code block whose info string cites the same `file:line` range and whose body is quoted from HEAD, OR (b) a paragraph ending with the literal tag `(verified by recon agent against HEAD <SHA>)` where `<SHA>` matches the iteration baseline (spawn-base / pre-flight SHA). Eval scans the plan body for "current state" patterns (regex: `currently`, `current order`, `runs .* (BEFORE|AFTER)`, `increments at`, `the predicate at line`) cross-referenced against `file:line` cites within the same paragraph or the team spec's `**Read these files first**` section; for each flagged paragraph, verifies an associated quoted excerpt or `(verified by recon agent ...)` tag exists in the same team spec. PASS if every flagged "current state" claim has its proof; FAIL on any unverified claim. File-and-range pointers WITHOUT behavioral assertions (e.g., `routes_session.py:80-150 — current order of idempotency vs quota`) do not require proof — they're "what to read" pointers, not "what the code does" claims. The proof requirement triggers only when the plan asserts a SPECIFIC behavior, ordering, predicate, or contract at the cited lines.

### Two-Pass Codex Adversarial Review (Step 10)
- [ ] **PF-20:** Step 10a (first-pass Codex review against v1) ran and v2 exists on disk. The plan body MUST contain a `## Codex review (Step 10a) — v1 findings + v2 responses` section enumerating each Codex finding (BLOCKER / STRONG-SUGGESTION / NIT) with its in-v2 response (amended-in-place / deferred-with-rationale / logged-for-followup). PASS if the section is present with at least one finding-response pair (or an explicit "No BLOCKERs found in v1." line). FAIL if the section is missing OR the plan is still labeled v1 with no Codex review section.

- [ ] **PF-21:** Step 10b (second-pass Codex review against v2) ran and v3 exists on disk. The plan body MUST contain a `## Codex review (Step 10b) — v2 findings + v3 responses` section. The green path is permitted: if Codex's second pass returned zero new BLOCKERs and zero new STRONG-SUGGESTIONs, the section reads "No new BLOCKERs against v2 amendments" and v3 = v2 with metadata bumped. PASS if the section is present and the doc metadata reflects v3. FAIL if v2 is the latest revision on disk (Step 10b not invoked) OR the section is missing. The handoff to exec-plan is v3, never v1 or v2.

### Requirements Doc Pre-Review (Step 1.5)
- [ ] **PF-22:** When `/plan-features` was invoked with `--doc <path>` (requirements doc exists on disk before planning starts), Step 1.5 Codex requirements pre-review ran. The requirements doc MUST contain a `## Codex review (Step 1.5) — findings + responses` section, OR (clean-review green path) the literal line "No findings against requirements doc." PASS = section present with finding-response pairs or the green-path line. FAIL = `--doc <path>` was supplied AND no Step 1.5 section exists. INCONCLUSIVE / NOT_APPLICABLE = invocation was `/plan-features "<inline>"` with no doc, OR the doc is a `findings.md` bug-report dump (Codex has no requirements to review).
