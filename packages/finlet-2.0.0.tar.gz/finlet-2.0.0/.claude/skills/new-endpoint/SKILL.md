---
name: new-endpoint
description: Scaffold a new FastAPI REST endpoint for Finlet. Use when the user wants to add a new API route, create a new endpoint, or extend the REST API. Also use when adding new functionality that needs an HTTP interface.
disable-model-invocation: true
argument-hint: <method> <path> [description]
---

# Create a New FastAPI Endpoint

Scaffold a new REST API endpoint following Finlet's conventions.

## Arguments

- `$0` — HTTP method (GET, POST, PUT, DELETE)
- `$1` — Route path (e.g., `/sessions/{session_id}/analytics`)
- `$2` — Optional description of what the endpoint does

## Steps

### 1. Determine route file

Check if an existing route file covers this domain (read `finlet/api/` for existing `routes_*.py` files). If this fits an existing domain, add to that file. Otherwise, create a new `routes_$DOMAIN.py`.

### 2. Create the endpoint

Follow patterns from existing routes in `finlet/api/`:

```python
from fastapi import APIRouter, Depends, HTTPException
from finlet.api.deps import get_current_user, get_session

router = APIRouter(prefix="/sessions/{session_id}", tags=["domain"])

@router.$0("$1")
async def endpoint_name(
    session_id: str,
    user=Depends(get_current_user),
    session=Depends(get_session),
):
    ...
```

### 3. Conventions (NON-NEGOTIABLE)

- **Session ownership**: Use `Depends(get_session)` — it enforces user owns the session
- **Pydantic models**: Request/response bodies use Pydantic models, not raw dicts
- **Error responses**: Use specific HTTP status codes (422, 404, 429, 503) with actionable messages
- **Async only**: All endpoint functions must be `async def`
- **Type hints**: Full type annotations on all parameters and return types

### 4. Register the router

If you created a new route file, register it in `finlet/api/app.py`:
```python
from finlet.api.routes_domain import router as domain_router
app.include_router(domain_router)
```

### 5. Write tests

Create or extend `tests/api/test_routes_$DOMAIN.py`:
- Test successful request with valid auth
- Test unauthorized access (missing/invalid API key)
- Test session ownership enforcement
- Test validation errors (bad input)
- Test edge cases specific to this endpoint

### 6. Verify

```bash
pytest tests/api/ -v -k "test_$DOMAIN"
```

## Reference

- `finlet/api/deps.py` — dependency injection (auth, session lookup)
- `finlet/api/routes_session.py` — good example of CRUD endpoints
- `finlet/api/routes_trade.py` — good example of business logic endpoints
