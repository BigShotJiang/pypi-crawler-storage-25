---
name: bug-hunt
description: One-iteration bug-hunt loop. Spawns a clean-room blind agent to walk through finlet.dev, triages broken-only findings, calls /plan-features and /exec-plan to dispatch fixes, auto-merges, then runs targeted retests against the live site post-deploy to detect patch-ineffective fixes (which auto-promote to refactor next iteration). One chat = one iteration; user re-invokes in a new chat for the next pass. Use --dry-run for an evaluation-only walk (Phases 0-3, no fixes). Costly (~20-30 min agent time including deploy wait, OAuth token, Playwright); only invoke when the user has agreed to a fresh iteration or evaluation walk.
argument-hint: "[--dry-run] [--skip-cleanup]"
---

# Bug-Hunt Loop

Single-shot bug discovery + autonomous fix pipeline. Cleans up test fixtures, spawns an isolated clean-room blind tester through finlet.dev, triages findings to broken-only, plans fixes, dispatches workers via `/exec-plan`, then merges and pushes. One skill call = one iteration. The "loop" is human-driven across chats — re-invoke `/bug-hunt` in a new chat for the next pass.

The blind agent runs in a clean-room subprocess with **zero context inheritance** (no CLAUDE.md, no MCR vault, no skills, no agents config). It walks finlet.dev as an ignorant fresh user using a real test account.

## Tools available to all agents (paste into every agent prompt)

This skill runs LOCALLY on the user's macOS machine. The orchestrator and every spawned subagent have full shell access and can use these locally-installed CLIs:

- **`gh`** — GitHub: `gh run list`, `gh run view`, `gh pr view`, `gh api`. Use this whenever a fix needs to inspect CI/Actions, PRs, issues, or workflow logs. Don't claim "I can't see CI status" — run `gh run list --branch main --limit 5`.
- **`aws`** — AWS CLI: `aws s3 ls`, `aws ssm get-parameter`, `aws ec2 describe-instances`. Use for S3 data-lake queries, SSM secrets, EC2/ECS state. Credentials are on the user's machine; no further setup needed.
- **`stripe`** — Stripe CLI: `stripe logs tail`, `stripe events resend`, `stripe trigger`. Use when debugging billing issues found in the blind walk.
- **`wrangler`** — Cloudflare CLI: `wrangler tail`, `wrangler deployments list`. Use for edge / DNS / Workers debugging.
- **`uv`** — Python toolchain: `uv run pytest`, `uv pip list`, `uv run ruff check`. The standard runner for everything in `tests/`.
- **`git`**, **`jq`**, **`curl`**, **`rg`**, **`fd`** — assume present.

MCP servers available (when running locally — Playwright is the only one the blind subprocess sees, others are inherited by the orchestrator and any non-blind agent):
- **`mcp__playwright__*`** — browser automation, used by the blind agent.
- **`mcp__n8n__*`** — n8n workflow management. Never `curl` n8n's API; use the MCP tools.
- **`mcp__claude_ai_*`** — Gmail, Drive, Calendar, AWS Marketplace, Stripe, PlayMCP (read-only OAuth integrations).

Tool reference docs (deeper inventories per department):
- `docs/tools/devops.md` — git, gh, ruff, mypy, pre-commit, etc.
- `docs/tools/aws.md` — S3, SSM, EC2, IAM patterns.
- `docs/tools/api-data.md` — curl, jq, httpie, websocat.
- `docs/tools/plugin-mgmt.md` — pip, uv, package management.
- `docs/DEV_TOOLS.md` — full catalog.

**Rule:** Before claiming a capability is missing, search first. Run `which <tool>` or read the tool reference docs. Don't tell the orchestrator "no `gh` available" without verifying.

**Caveat for remote scheduling:** if this skill is ever ported to `/schedule` (Anthropic's cloud Remote Tasks runner), the cloud sandbox is a stock Ubuntu 24.04 image WITHOUT these CLIs pre-installed. `gh`, `aws`, `stripe`, `wrangler` would need to be provisioned via a setup script and authenticated via secrets. The current skill assumes local execution. (See https://code.claude.com/docs/en/claude-code-on-the-web for cloud sandbox specs.)

## Refactor Gate (read before every iteration)

The bug-hunt loop is patch-only. When a class of bug recurs across iterations, the loop won't fix the underlying convention gap — a refactor session must. The gate is intentionally lenient: pre-launch we eat real cost (user-visible recurring bugs) for every iteration we wait, and refactor cost ≈ one bug-hunt iteration, so we trip the gate aggressively.

Before invoking `/bug-hunt`, the orchestrator MUST:

1. Read `docs/bug-hunt/ledger.jsonl` (one JSONL line per real-broken finding across all iterations) AND `docs/bug-hunt/pending_recurrences.jsonl` (one JSONL line per finding whose Phase 5.5 retest failed — see "Phase 5.5" for how this file is populated).
2. Bucket by `category`. If ANY of the following triggers fire, do NOT run another bug-hunt iteration; pause and route to refactor instead:
   - **Count trigger:** category has **≥2 instances across ≥2 iterations** in `ledger.jsonl`.
   - **Forward-signal trigger:** the latest triage's `same_root_cause_as` field on any finding points to a prior ledger entry. One forward signal is enough — don't wait for the count to grow.
   - **Patch-ineffective trigger:** any unresolved entry in `pending_recurrences.jsonl` exists. A patch-ineffective signal is stronger than a recurrence — we tried to fix it once, and the fix didn't change user-visible behavior on prod. One signal is enough; do NOT wait for the count to grow. An entry is "unresolved" if no `refactor-queue/*.md` doc with the same `category` AND `status: shipped` AND `verdict: effective` was written AFTER the patch-ineffective entry's `patch_iteration_ts` (i.e., the refactor that would close it hasn't landed yet).
   - **Pre-drafted refactor exists:** any document in `docs/bug-hunt/refactor-queue/` with `status: ready` matches a category in this iteration's triage (or in the recurrence-watch list below).
3. Read every `docs/bug-hunt/refactor-queue/*.md` with `status: ready`. Each contains a pre-drafted refactor scope (root cause, files, validation, break-even). Execute via `/plan-features --doc <refactor doc> --output docs/refactor/<name>/plan.md` then `/exec-plan`. After the refactor lands, edit the queue doc to `status: shipped` and append a `verdict:` field once the next iteration's triage confirms outcome — don't delete the doc, it's the audit trail.

### Why 2/2 not 3/2

The post-mortem break-even math says a refactor pays back in 2-3 iterations. A 3/2 threshold guarantees the loop eats 3 patches before fixing the convention; pre-launch that's 3 user-visible bugs we ship. 2/2 still requires confirmed cross-iteration recurrence (one-off bugs don't trigger it) but cuts the wait by one iteration. The forward-signal trigger handles the case where the second occurrence is recognized as same-root-cause on first sight, before the count even reaches 2.

### Currently-watched recurring categories (as of 2026-04-28)

The event-bus refactor (commits `631d1b1`, `798904c`, `c0d8edb`) closed the prior cluster. Provisional verdicts pending the next iteration's triage:
- `onboarding-checklist` (4 instances) — closed; not reported in `20260428T163727Z4f4f` dry-run.
- `dashboard-state-sync` (3 instances) — closed; bus.subscribe wiring verified live.
- `trusted-types` (3 instances) — closed; pre-commit guard active, no CSP findings in dry-run.

Open clusters (under the 2/2 gate, both route to refactor next iteration):
- `modal-stacking` (2 instances across 2 iterations) — overlay z-index / pointer-events conflicts when modals stack. Refactor scope drafted at `docs/bug-hunt/refactor-queue/modal-stacking.md`.
- `dirty-state-tracker` (2 instances across 2 iterations) — form-dirty tracker captures baseline before async loaders populate fields. Refactor scope drafted at `docs/bug-hunt/refactor-queue/dirty-state-tracker.md`.

After a refactor lands, mark the queue doc `status: shipped` and append a verdict field (`effective` / `incomplete` / `regressed`) once the next iteration's triage confirms outcome. This is the feedback loop that says whether the gate decision was right — without it, leniency is just bias.

## Invocation

```
/bug-hunt [--dry-run] [--skip-cleanup]
```

Examples:
- `/bug-hunt` — full pipeline.
- `/bug-hunt --skip-cleanup` — skip Phase 1 (already clean account state).
- `/bug-hunt --dry-run` — Phase 0–3 only; emit triage but do not invoke `/plan-features` or `/exec-plan`.

## Phase 0 — Setup

Main agent runs the following inline (no subagent — trivial bash). All later phases assume these env vars are present.

```bash
# Fail fast if secrets file missing
if [ ! -f "$HOME/.bug-hunt-loop/secrets.env" ]; then
  echo "ERROR: $HOME/.bug-hunt-loop/secrets.env is missing." >&2
  echo "Copy .claude/skills/bug-hunt/secrets.env.example to ~/.bug-hunt-loop/secrets.env, fill it in, then chmod 600 it." >&2
  exit 1
fi

# Source secrets (CLAUDE_CODE_OAUTH_TOKEN, FINLET_TEST_USER_*, FINLET_BASE_URL)
set -a; . "$HOME/.bug-hunt-loop/secrets.env"; set +a

# Verify token
if [ -z "${CLAUDE_CODE_OAUTH_TOKEN:-}" ]; then
  echo "ERROR: Missing CLAUDE_CODE_OAUTH_TOKEN. Run \`claude setup-token\` and store the result in ~/.bug-hunt-loop/secrets.env. See .claude/skills/bug-hunt/secrets.env.example for the template." >&2
  exit 1
fi

# Verify other required vars
: "${FINLET_TEST_USER_API_KEY:?FINLET_TEST_USER_API_KEY missing in secrets.env}"
: "${FINLET_TEST_USER_EMAIL:?FINLET_TEST_USER_EMAIL missing in secrets.env}"
: "${FINLET_TEST_USER_PASSWORD:?FINLET_TEST_USER_PASSWORD missing in secrets.env}"
: "${FINLET_BASE_URL:=https://finlet.dev}"
export FINLET_BASE_URL

# Artifacts dir — UTC timestamp + 4-char hex suffix (handles same-second invocations)
TS=$(date -u +%Y%m%dT%H%M%SZ)$(printf '%04x' $RANDOM)
export TS
mkdir -p "docs/bug-hunt/$TS"

# Pre-warm Chromium (idempotent — npx playwright install is a no-op if already cached)
if [ -z "${PLAYWRIGHT_BROWSERS_PATH:-}" ]; then
  npx --yes playwright install chromium >/dev/null 2>&1 || true
fi

echo "Phase 0 OK. Artifacts: docs/bug-hunt/$TS/"
```

If `--skip-cleanup` was passed, jump directly to Phase 2.

## Phase 1 — Cleanup

Spawn a `general-purpose` subagent (no worktree) with the prompt below. The agent calls Finlet's REST API to wipe the test user's lingering sessions so the blind walkthrough starts from a clean slate. Idempotent: zero sessions = success.

```text
You are the bug-hunt cleanup agent. Your job is to delete all simulation sessions
owned by the bug-hunt test user so the blind agent starts from a clean slate.

ENVIRONMENT (already exported in your shell):
  FINLET_BASE_URL          — base URL (e.g. https://finlet.dev)
  FINLET_TEST_USER_API_KEY — API key for the test user (sent as Authorization: Bearer)
  TS                       — artifact directory timestamp (e.g. 20260427T123456Z1234)

RULES:
- NEVER log, echo, print, or copy the value of FINLET_TEST_USER_API_KEY anywhere
  (not stdout, not the cleanup.log, not in any error message). Refer to it only
  as [REDACTED] in any human-readable output.
- Idempotent: zero sessions returned = success, exit 0 with a "no sessions" line.
- 404 on an individual DELETE = already gone; treat as success and continue.
- 401 from any call = HARD FAIL: emit "ERROR: cleanup auth broken (401)" to
  stderr and exit 2 so the orchestrator aborts the whole skill.
- Other non-2xx on DELETE = log it and continue with the next session.

STEPS:
1. List sessions:
     curl -fsS -H "Authorization: Bearer $FINLET_TEST_USER_API_KEY" \
       "$FINLET_BASE_URL/sessions"
   - 401 → write "ERROR: 401 from GET /sessions — auth broken, aborting" to
     docs/bug-hunt/$TS/cleanup.log and stderr, exit 2.
   - 200 with empty list → write "no sessions to delete (idempotent)" and exit 0.
2. Parse the JSON list. For each session id `S`:
     curl -fsS -X DELETE -H "Authorization: Bearer $FINLET_TEST_USER_API_KEY" \
       "$FINLET_BASE_URL/sessions/$S"
   - 404 → write "DELETE $S → 404 (already gone)" to cleanup.log, continue.
   - 401 → HARD FAIL as above.
   - 2xx → write "DELETE $S → ok" to cleanup.log.
   - other → write "DELETE $S → <status>" to cleanup.log, continue.
3. Write a summary line:
     "cleanup complete: <N> sessions deleted, <M> already-gone, <K> errors"

OUTPUT:
- Append every action as one line to docs/bug-hunt/$TS/cleanup.log.
- Exit 0 on success (including the zero-sessions case).
- Exit 2 only if cleanup auth itself is broken (401).
```

**Failure tolerance:** if cleanup exits 2 (auth broken), the main agent aborts the skill — running blind on broken auth is pointless. Any other non-zero exit logs a warning but the skill continues into Phase 2.

## Phase 2 — Blind walkthrough

Main agent invokes the launcher script. The script writes a one-shot blind config dir, runs `claude --print` under `env -i` with no inherited environment, and captures the JSON output.

```bash
bash .claude/skills/bug-hunt/blind-launcher.sh \
  "$BLIND_PROMPT" \
  "docs/bug-hunt/$TS/blind_report.json"
```

**Hard timeout: 15 minutes.** First-run MCP setup can be slow. If the subprocess exceeds 15 minutes or exits non-zero, abort the skill and dump the last 50 lines of stdout/stderr into `docs/bug-hunt/$TS/blind_diagnostic.log`.

**Verify clean-room isolation.** The blind prompt ends with an isolation-check question. After the run, parse `blind_report.json` and look at the `_isolation_check` field. If it lists Finlet-specific architecture facts (date ceiling enforcer, plugin registry, session lifecycle, etc.), the isolation FAILED — append a warning to `blind_report.json` but do NOT hard-fail (this is a sanity check, not a gate).

The full blind-agent prompt that gets passed as `$BLIND_PROMPT`:

```text
You are a fresh user evaluating finlet.dev for the first time. You have a Playwright
browser MCP and Finlet's benchmark MCP available. You have NEVER used this site before
and you have NO inherited context about how it works internally.

DO THESE THREE STEPS in order:
  1) Navigate to finlet.dev and log in with username jgn0017@auburn.edu, password [REDACTED].
  2) Set up a fundamentals strategy. Install and configure it.
  3) Place at least one trade using the Finlet benchmark MCP tool.

REPORT what you observe in three categories:
  - BROKEN: errors, crashes, things that don't work, dead links, 500s, broken UI states.
            Include URLs, exact error messages, screenshot paths if you took any.
  - ANNOYING: friction, bad copy, slow flows, confusing UX, anything that worked
              but felt wrong.
  - NICE TO HAVE: features you'd expect to find but didn't.

Be SPECIFIC. "Login was slow" is bad. "Login took 8s after submit, redirected to
/dashboard with a console 404 on /api/me" is good.

REDACTION (mandatory):
DO NOT include the password "Iamanoob1!" or any API key value in your output. Refer
to credentials only as [REDACTED].

OUTPUT FORMAT:
Return a single JSON object on stdout with this shape:
{
  "completed_steps": ["login", "fundamentals_setup", "trade_placed"],  // any subset, in order completed
  "findings": [
    {"category": "BROKEN|ANNOYING|NICE_TO_HAVE", "summary": "...", "url": "...", "evidence": "..."},
    ...
  ],
  "_isolation_check": [...]
}

At the end of your output, in a JSON field "_isolation_check", list any project-specific facts you know about the website you just used WITHOUT searching the web. (This is a sanity check that your context is clean — leave the array empty if you don't know any facts.)
```

## Phase 3 — Triage

Spawn a `general-purpose` subagent (no worktree) with the prompt below. The agent reads `blind_report.json` and emits both `triage.md` (human-readable) and `triage.json` (machine-readable counts).

```text
You are the bug-hunt triage agent. Read docs/bug-hunt/$TS/blind_report.json and
classify every finding using a deterministic criterion.

CRITERION (apply mechanically — do NOT use judgement beyond this rule):

A finding qualifies as "real-broken" if and only if the OBSERVED BEHAVIOR CONTRADICTS DESIGN INTENT — independent of whether the blind agent worked around it. The agent's perseverance is irrelevant; the system's correctness is what matters. Slow ≠ broken. Ugly ≠ broken. Confusing ≠ broken. But "wrong" IS broken even if the agent's clever workaround let them finish the script.

Each finding gets EXACTLY ONE classification from this set:
  real-broken | working-as-designed | needs-investigation | annoying | nice-to-have | ambiguous

Use this decision tree (apply real-broken predicates first; if any match, it's real-broken):

real-broken — observed behavior contradicts design intent. Specifically any of:
  - Server returns wrong status on a documented happy path (422/500/403 where 2xx expected)
  - UI state ≠ backend state after a successful mutation (checklist desync after 201, stale metrics after FILLED order)
  - Two code paths claim to do the same thing but use different contracts and disagree (wizard vs modal payload drift)
  - External prod dependency fails (telemetry CDN blocked, error monitoring offline)
  - Documented affordance does nothing when activated (dead button, dead checklist row, dead link)
  - Console errors / network failures on the happy path even when the screen looks fine

annoying — behavior is correct but rough: bad copy, missing in-UI shortcut, slow non-blocking path, generic error messages that hide field-level details
nice-to-have — missing feature the user expected
working-as-designed — intended behavior misread by the agent
needs-investigation — cannot decide without reading source (use sparingly — prefer assigning to broken/annoying when evidence is clear)
ambiguous — cannot map to any of the above

OUTPUTS (write BOTH):

1) docs/bug-hunt/$TS/triage.md — markdown with EXACTLY two top-level sections:

## Broken (will be fixed this iteration)
- <one bullet per real-broken finding> [evidence: <quote from blind report>] [scope hint: <likely files>]

## Logged (not actioned)
- <one bullet per finding NOT classified real-broken> [classification: <one of the 5 non-broken values>]

If there are zero real-broken findings, leave the "## Broken" section empty (do NOT
delete the heading — downstream tooling looks for it).

2) docs/bug-hunt/$TS/triage.json — machine-readable counts plus the full item list:

{
  "broken": <int>,
  "annoying": <int>,
  "nice": <int>,
  "wai": <int>,
  "ambiguous": <int>,
  "needs_investigation": <int>,
  "items": [
    {"classification": "<value>", "summary": "...", "evidence": "...", "scope_hint": "...", "category": "<tag>", "same_root_cause_as": "<prior finding_id or null>", "retest": {<envelope — see below — REQUIRED for every real-broken item, omitted for others>}},
    ...
  ]
}

RETEST ENVELOPE (REQUIRED for every real-broken item):

Phase 5.5 runs the retest assertions post-deploy against the live finlet.dev URL to
verify the patch actually changed user-visible behavior. A patch that lands locally
but doesn't change behavior on prod is a "patch-ineffective" event — its own class
of failure that auto-promotes the category to refactor on the next iteration. The
retest envelope is what makes this verifiable.

Shape (kind-specific):

  "retest": {
    "kind": "playwright | curl | cli-shell",
    "description": "<one-line: what the assertion verifies>",
    "setup": "<freeform: preconditions, env vars, login steps. May be ''>",
    "trigger": "<concrete action — kind-specific, see below>",
    "assertions": ["<one English predicate per line — agent verifies each via the kind's tooling>", ...],
    "cleanup": "<optional: undo any state created by the retest. May be omitted>"
  }

Per kind:

- "playwright" — UI behavior. Trigger is a navigation+wait recipe ("navigate to
  /settings.html, login, wait for networkidle"). Assertions reference Playwright
  snapshot / console / network tools the retest agent has via mcp__playwright__*.
  Use this kind when the broken predicate is a UI symptom (banner shown when it
  shouldn't be, console error on page load, network 401 on dashboard load).

- "curl" — REST API contract. Trigger is the exact curl command(s) the retest
  agent runs via Bash. Assertions reference HTTP status, JSON body shape, header
  values. Use this kind when the broken predicate is a server-side contract (wrong
  status code, missing header, idempotency replay returning a different shape).

- "cli-shell" — CLI behavior. Trigger is the exact `finlet ...` (or other) shell
  command. Assertions reference exit code, stdout/stderr content, JSON output
  shape. Use this kind when the broken predicate is a CLI symptom (exit 1 on
  happy path, output mismatch with API).

Pick the kind that most directly probes the broken predicate. If a bug has both
UI and API symptoms, pick whichever exercises the FIX path most directly — usually
the more specific one (curl on a route fix, playwright on a DOM fix).

Example envelopes (for the bugs in 20260430T222711Z3666):

  // auth-validate-stale-cookie-401 — playwright
  "retest": {
    "kind": "playwright",
    "description": "Dashboard load with stale cookie returns 200 anonymous, no 401 spam",
    "setup": "login as test user, then clear server-side session via DELETE /v1/auth/session/{id} so the cookie is stale, then refresh /index.html",
    "trigger": "navigate to https://finlet.dev/index.html, wait for networkidle",
    "assertions": [
      "no network response with status 401 from any path matching /v1/auth/session/validate",
      "no console error containing 'Failed to load resource' for /v1/auth/session/validate"
    ]
  }

  // cli-session-create-readtimeout-mismatch — cli-shell
  "retest": {
    "kind": "cli-shell",
    "description": "finlet session create exits 0 (or replays via Idempotency-Key) and does not orphan a server-side session",
    "setup": "FINLET_API_KEY=$FINLET_TEST_USER_API_KEY; FINLET_BASE_URL=$FINLET_BASE_URL",
    "trigger": "finlet session create --name retest-$TS --start 2024-01-02 --capital 100000 --universe AAPL,MSFT",
    "assertions": [
      "exit code is 0",
      "stdout contains a session_id",
      "GET /v1/sessions returns at most 1 session matching name=retest-$TS (no duplicates from retry)"
    ],
    "cleanup": "for each session in GET /v1/sessions matching name=retest-$TS: DELETE /v1/sessions/{id}"
  }

  // settings-dirty-banner-synthetic-key-flash — playwright
  "retest": {
    "kind": "playwright",
    "description": "Settings cold-load does not show 'unsaved changes' banner before any user edit",
    "setup": "login as test user",
    "trigger": "navigate to https://finlet.dev/settings.html, wait for networkidle, take snapshot",
    "assertions": [
      "snapshot does NOT contain text 'You have unsaved changes'",
      "#unsaved-banner has computed style display:none OR is absent from the DOM"
    ]
  }

  // cli-plugins-list-mismatch — cli-shell
  "retest": {
    "kind": "cli-shell",
    "description": "finlet plugins list returns the same plugin set as GET /v1/plugins/health",
    "setup": "FINLET_API_KEY=$FINLET_TEST_USER_API_KEY; FINLET_BASE_URL=$FINLET_BASE_URL",
    "trigger": "finlet plugins list --json > /tmp/cli.json && curl -fsS -H \"Authorization: Bearer $FINLET_API_KEY\" \"$FINLET_BASE_URL/v1/plugins/health\" | jq '.plugins | sort_by(.name)' > /tmp/api.json",
    "assertions": [
      "exit code of cli is 0",
      "jq '. | length' /tmp/cli.json equals jq '. | length' /tmp/api.json",
      "jq '[.[].name] | sort' /tmp/cli.json equals jq '[.[].name] | sort' /tmp/api.json"
    ]
  }

  // checklist-rest-cli-no-advance — playwright
  "retest": {
    "kind": "playwright",
    "description": "Creating a session via REST then loading dashboard marks the 'Create first session' checklist row complete",
    "setup": "login as test user; create a session via curl POST /v1/sessions (NOT via the wizard UI)",
    "trigger": "navigate to https://finlet.dev/index.html, wait for the onboarding checklist to render",
    "assertions": [
      "checklist row 'Create first session' shows the completed state (checkmark / strike-through / aria-checked=true)"
    ],
    "cleanup": "DELETE the session created in setup"
  }

RETEST AUTHORING RULES:

- The retest probes the FIX path, not just the bug surface. If the fix is in
  finlet/auth/deps.py, the retest must execute that code path on prod. A retest
  that asserts a side-effect of a non-fix path is theatre.
- Assertions must be deterministic. "Page loads quickly" is not a retest. "Page
  loads in <5s" is. "Looks correct" is not. "Element X has aria-label='Y'" is.
- Setup must use only the test user's credentials and idempotent operations.
  Cleanup must restore state so the next retest doesn't see leftover artifacts.
- If the bug surface CANNOT be probed by any of the three kinds (e.g., it requires
  the user to physically be present), set `retest: null` and explain in `description`.
  Phase 5.5 will treat null retests as "skipped — not retestable" (NOT as a fail).

CATEGORY (required for every real-broken item, optional for others):

Each `real-broken` item MUST carry a `category` field — a free-form lowercase-hyphenated
tag that describes the CLASS of bug (not the specific bug). Reuse existing tags from
`docs/bug-hunt/ledger.jsonl` whenever an existing tag fits. Only mint a new tag when no
existing one applies. Examples already in the ledger:
  - `trusted-types`         — CSP / Trusted Types policy violations
  - `onboarding-checklist`  — onboarding wizard / checklist wiring bugs
  - `dashboard-state-sync`  — UI state diverges from backend after a successful mutation
  - `modal-stacking`        — overlapping / mis-rendered modal dialogs
  - `dirty-state-tracker`   — false-positive form-dirty banners
  - `vendor-bypass`         — broken/dead external prod dependency (CDN, third-party SDK)
  - `connection-toast-stuck` — connection-status toasts that contradict actual SSE state

Reuse is the whole point — recurrence detection in Phase 6 groups by this field, so
inventing near-duplicate tags ("checklist" vs "onboarding-checklist") defeats the
mechanism. Read the ledger first; mint new tags sparingly.

SAME-ROOT-CAUSE LINK (forward signal for the refactor gate):

For each `real-broken` item, set the `same_root_cause_as` field to a prior ledger
`finding_id` if and only if the same fix would close both. Otherwise leave it null.

This is the forward-signal trigger for the refactor gate (see SKILL.md "Refactor
Gate"). One same-root-cause link promotes the category to refactor regardless of
count, so be conservative: same root cause means same FIX would close both. Different
files / different broken predicate = different root cause, even if the symptom looks
similar. When in doubt, leave it null and let the count trigger handle it on the
next iteration.

Examples of valid links (verbatim from real iterations):
  - "Plugins-tab dirty banner on load" → `same_root_cause_as: "settings-dirty-banner-onload"`
    (both are form-dirty trackers capturing baseline before async loaders populate)
  - "wizard overlay blocks Create Session modal" → `same_root_cause_as: "modal-stacking-leaderboard"`
    (both are two modals stacked, the upper intercepts pointer events for the lower)

To populate this field you must read `docs/bug-hunt/ledger.jsonl` (the only file you
may read outside `blind_report.json` — see RULES). Compare candidate prior entries on:
  1. `scope_files` overlap (same target file or sibling file in the same surface)
  2. `summary` describing structurally-similar broken predicate
  3. `category` match (same category strongly suggests same root cause; different
     categories rule it out)

RULES:
- Read ONLY blind_report.json AND docs/bug-hunt/ledger.jsonl (the latter solely to populate `same_root_cause_as`). Do not browse the codebase.
- Do not paraphrase findings — quote evidence verbatim.
- The design-intent-contradiction predicates are the entire spec. Do not import
  other heuristics ("severe", "user-impacting", "production critical") — apply
  the predicates mechanically and let the classification fall out.
- A finding the blind agent worked around can still be real-broken. The criterion
  is about the system's behavior, not the agent's success.
- Exit 0 after both files are written.
```

## Phase 3.5 — Codex independent code recon

For each real-broken finding, spawn Codex (gpt-5.5, xhigh reasoning) to do its OWN surgery-surface recon. This runs in parallel with the Claude recon that `/plan-features` triggers in Phase 4 — both produce surgery-surface artifacts independently, and Phase 4's reconciliation step takes the UNION.

**Why parallel-not-review.** A reviewer reading Claude's recon artifact gets anchored to the scope it names; "is this complete?" is a softer question than "what's the surgery surface?". Independent recon doesn't inherit Claude's framing because it never sees it. Different priors → different starting greps → different files surfaced. This is the structural fix for the "recon framed too narrowly" failure mode (e.g., iter `20260506T185234Z542e` Team B missed `#nav-drawer-copy-key` because Claude recon anchored on `#menu-copy-key` from the symptom; an independent grep for the literal `Copy API Key` string would have surfaced both IDs).

**Skip Phase 3.5 entirely if `triage.json.broken == 0`** (nothing to recon).

The orchestrator runs the following inline (no subagent — direct CLI invocation):

```bash
BROKEN_COUNT=$(jq '.broken' "docs/bug-hunt/$TS/triage.json")
if [ "$BROKEN_COUNT" -eq 0 ]; then
  echo "Phase 3.5 SKIP — no real-broken items"
else
  HEAD_SHA=$(git -C /Users/justnau/finlet rev-parse HEAD)
  PROMPT_FILE="docs/bug-hunt/$TS/codex_recon_prompt.txt"

  # Build the prompt with broken-item details inlined so Codex doesn't need to re-derive
  # them. The prompt explicitly tells Codex it's running parallel to Claude recon and
  # MUST NOT anchor on the scope_hint.
  cat > "$PROMPT_FILE" <<PROMPT
You are an independent code recon agent. A separate Claude Explore agent is running in parallel against the same input — your independence is the load-bearing value. Don't anchor on what Claude might find; do your own grep, your own file reads, your own enumeration. The two recons get unioned by the planner; if you re-derive Claude's answer, you've added zero value.

WORKING DIR: /Users/justnau/finlet (read-only sandbox, full repo access).
BASELINE HEAD: ${HEAD_SHA}

INPUTS (read these files directly):
  docs/bug-hunt/$TS/blind_report.json — full blind agent report
  docs/bug-hunt/$TS/triage.json — read .items[] where classification == "real-broken"

FOR EACH real-broken item, your workflow is GREP FIRST, READ FILES SECOND:

1. **Identify the user-visible symptom string(s).** From summary + evidence, extract literal strings the user sees on screen, exact route paths, exact event names, exact DOM IDs / class names. These are your grep anchors. Examples: a "Copy API Key" label → grep for "Copy API Key"; a /v1/sessions 422 → grep for "/v1/sessions" AND "422" AND the response shape; a checklist row "Run first analysis" → grep for "Run first analysis" AND any matching CHECKLIST_STEPS key.

2. **Grep WIDELY before reading any file.** scope_hint is Claude's anchor — IGNORE IT for the grep step (you can read it later when you're verifying line content). Run:
   - \`grep -rn '<symptom string>' dashboard/ finlet/ tests/ scripts/\` for UI/copy bugs
   - \`grep -rn '<route path>' finlet/api/ finlet/mcp/ dashboard/\` for backend/route bugs
   - \`grep -rn '<event name>' dashboard/ tests/\` for bus-event bugs
   - \`grep -rn '<key string>' dashboard/onboarding.js dashboard/event-contract.md\` for registry-key bugs
   The goal is to enumerate ALL surfaces that contain the symptom or its trigger. Parallel surfaces (multiple HTML pages with the same hardcoded copy, mobile drawer vs desktop nav, e2e tests asserting the symptom) are the EXACT class of finding Phase 3.5 exists to surface — the iter \`20260506T185234Z542e\` Team B miss was \`#nav-drawer-copy-key\` in FOUR HTML files (\`index.html\`, \`billing.html\`, \`leaderboard.html\`, \`settings.html\`) plus a handler in \`mobile-nav.js\`, none of which Claude recon enumerated because Claude anchored on \`shared-nav.js\` from the symptom.

3. **Read the actual lines from grep matches and quote them.** For each grep hit that's load-bearing (renders the symptom OR triggers the bug OR holds the registry entry), open the file at that line range and quote it. Same evidence shape as Claude recon: fenced code block with file:line info string, HEAD-quoted content.

4. **State your INDEPENDENT conclusion.** Where does the bug actually live? What's the COMPLETE surgery surface (every file that needs to change for the bug to disappear from prod)? Crucially: are there parallel surfaces a Claude recon anchored on the symptom file would likely miss? Name them explicitly. If your grep found N>1 surfaces, ALL N are part of the surgery surface — the planner will union with Claude's enumeration to produce the team's "Files touched" list.

OUTPUT: write your full report to /Users/justnau/finlet/docs/bug-hunt/$TS/codex_recon.md. Use this shape per finding:

  ### Finding N — <finding_id from triage.json>

  **Independent recon (Codex gpt-5.5 xhigh against HEAD ${HEAD_SHA}):**

  \`\`\`<lang> <file>:<line_start>-<line_end>
  <quoted lines as they exist NOW>
  \`\`\`
  \`\`\`<lang> <other_file>:<line_start>-<line_end>
  <more quoted lines, including any parallel surfaces>
  \`\`\`

  **Conclusion:** <where the bug lives, minimum surgery surface, parallel surfaces enumerated. If no parallel surfaces exist, state EXPLICITLY: "scoped to <file>:<lines>, no parallel surfaces found via grep for <search-term>.">

  **Disagreement risk:** <none | scope-only | root-cause>. If "root-cause", explain how Codex's read of the bug differs from the symptom and why the planner should treat this as needs-investigation rather than spawning a fix team.

Be DENSE. No filler. No "I'll now check..." narration. Open files, grep, quote, conclude.

Hard cap: ~500 lines of quoted excerpts total across all findings. Quoted excerpts MUST be the literal HEAD content with file:line cite in the fence info string.

CONSTRAINTS (mandatory):
- WRITE ONLY to docs/bug-hunt/$TS/codex_recon.md. Do not modify any other file in the repo. Do not stage or commit anything; the orchestrator handles all git operations.
- Do not run \`git\` for anything except read-only inspection (\`git log\`, \`git show\`, \`git diff\`). Do not run \`git add\`, \`git commit\`, or any branch operation.
- Do not run shell commands that mutate state outside docs/bug-hunt/$TS/. Read access to the rest of the repo is fine and expected.

When done, your final response MUST end with the literal line "CODEX_RECON_DONE" so the orchestrator can confirm completion.
PROMPT

  # Invoke Codex CLI. Model + reasoning effort pinned explicitly to defend against
  # config drift. workspace-write sandbox is required because Codex writes the recon
  # report file directly; the prompt above pins the target file path and forbids
  # other writes.
  # `< /dev/null` is REQUIRED — without it, codex exec blocks waiting for stdin
  # ("Reading additional input from stdin...") even when the prompt is passed
  # as an argument. Confirmed via smoke test 2026-05-06.
  codex exec \
    --skip-git-repo-check \
    -s workspace-write \
    -C /Users/justnau/finlet \
    -c 'model="gpt-5.5"' \
    -c 'model_reasoning_effort="xhigh"' \
    "$(cat "$PROMPT_FILE")" \
    < /dev/null \
    > "docs/bug-hunt/$TS/codex_recon.stdout.log" 2>&1 \
    || echo "WARN: codex exec returned non-zero. See codex_recon.stdout.log."

  # Defensive check: did Codex write outside the expected target file?
  STRAY=$(git -C /Users/justnau/finlet status --short -- finlet/ dashboard/ tests/ scripts/ deploy/ pyproject.toml 2>/dev/null | head)
  if [ -n "$STRAY" ]; then
    echo "WARN: Codex modified files outside docs/bug-hunt/$TS/. Reverting:"
    echo "$STRAY"
    git -C /Users/justnau/finlet checkout -- finlet/ dashboard/ tests/ scripts/ deploy/ pyproject.toml 2>/dev/null || true
  fi

  if [ -s "docs/bug-hunt/$TS/codex_recon.md" ]; then
    LINES=$(wc -l < "docs/bug-hunt/$TS/codex_recon.md")
    echo "Phase 3.5 OK — codex_recon.md present (${LINES} lines)"
  else
    echo "Phase 3.5 WARN — codex_recon.md missing or empty. Proceeding with Claude-only recon."
    echo "  Check docs/bug-hunt/$TS/codex_recon.stdout.log for the failure."
  fi
fi
```

**Failure tolerance.** Phase 3.5 is non-blocking. If the Codex CLI is unavailable, errors out, or `codex_recon.md` is missing/empty, log the diagnostic to `codex_recon.stdout.log` and continue to Phase 4 with Claude-only recon. The planner's reconciliation step in `plan-features` Step 2 handles the "no Codex artifact" case by treating Claude's recon as the sole source — that's the pre-3.5 status quo, no regression.

**Why non-blocking.** Codex is a second perspective, not a gate. If Codex is down, Claude-only recon remains the working baseline. The cost of non-blocking is "miss the parallel-surface catch this iteration"; the benefit is "Codex outage doesn't kill the loop."

**Cost.** ~30-60s of wall time per iteration plus the API tokens for the Codex run. Breakeven is one prevented patch-ineffective signal (each one costs at least one full bug-hunt iteration to remediate via refactor or re-patch).

## Phase 4 — Plan

If `triage.json.broken == 0`, **skip Phases 4, 5, and 5.5 entirely** — emit `result.status = "clean iteration"` and jump to Phase 6. No plan, no PR, no exec-plan, no retest.

Otherwise, first append a fixed **Required Docs Updates** block to `triage.md` so `/plan-features` bakes it into Team D (the docs team). This is the only way to keep doc coverage uniform across iterations — without this block, Team D's spec drifts based on whatever `/plan-features` improvises from the bug list. Run inline (trivial bash, no subagent):

```bash
cat >> "docs/bug-hunt/$TS/triage.md" <<EOF

## Required Docs Updates (mandatory — Team D scope)

Every bug-hunt iteration MUST produce a docs commit that touches the following.
Skip an item ONLY if it is genuinely not applicable; in that case state so explicitly
in the docs commit message ("LESSONS.md: no new lessons this iteration"). Do not
silently omit.

1. \`docs/REMAINING_TASKS.md\` — close items resolved this iteration; add a "Bug Hunt
   $TS — Closed" subsection mirroring prior iteration patterns.
2. \`docs/LESSONS.md\` — append at least one lesson per real-broken finding that
   exposed a class of mistake (triage misread, CSP/CSS footgun, agent isolation
   leak, false-positive predicate, etc.). Lessons must be reusable rules, not
   a recap of the diff.
3. \`docs/ARCHITECTURE.md\` — update if any: CSP / security-headers / middleware
   stack / route surface / schema field / plugin registry / dashboard surface
   changed. Skip with explicit note if untouched.
4. \`docs/KNOWN_FAILURES.md\` — pre-flight refresh and any pre-existing failure
   resolved this iteration removed.
5. \`docs/decisions/\` — add a 1-page record only if a non-trivial reversible
   decision was made (e.g., "remove Sentry, rely on /v1/client-errors").
6. \`docs/bug-hunt/$TS/\` — stage and commit every artifact produced this
   iteration (plan.md, triage.md, triage.json, blind_report.json, cleanup.log,
   isolation_warning.txt if present, team_*_verify.md, blind_diagnostic.log,
   deploy_status.txt, retest_results.json). No artifact left untracked.
7. \`docs/bug-hunt/ledger.jsonl\` — Team E MUST append exactly one JSON line per
   real-broken finding closed this iteration, using this flat schema:
       {"iteration_ts":"$TS","finding_id":"<short-slug>","category":"<tag>",
        "summary":"<short>","scope_files":["dashboard/x.js"],
        "team":"<A|B|C|D|E|...>","commit":"<merge-sha-on-main>"}
   Reuse existing categories from the ledger; only mint a new tag if no
   existing one fits. The \`commit\` field is the merge SHA on \`main\` for the
   team that closed the item — read it from \`git log\` after merges. Validation
   hint: after Team E commits, \`wc -l docs/bug-hunt/ledger.jsonl\` should grow
   by exactly the number of broken items closed this iteration.
8. \`docs/bug-hunt/pending_recurrences.jsonl\` — if Phase 5.5 produced new
   patch-ineffective signals, the orchestrator already appended them inline (see
   Phase 5.5c). Team D MUST stage the file. If a refactor verdict pruned entries
   this iteration, Team D MUST also stage \`docs/bug-hunt/pending_recurrences.resolved.jsonl\`
   (the audit log of resolved signals).

Team D's commit message must reference iteration $TS and name which docs were
touched (e.g., "docs: bug-hunt $TS — record fixes for X; LESSONS +N; ARCHITECTURE
unchanged this iteration; ledger +N").
EOF
```

Then the main agent invokes:

```
/plan-features --doc docs/bug-hunt/$TS/triage.md --output docs/bug-hunt/$TS/plan.md
```

`/plan-features` produces the standard execution plan (file conflict table, dependency graph, per-team specs, validation, risk register). It will pick up the Required Docs Updates block and bake it into Team D's spec.

If `/plan-features` returns an empty plan (no actionable teams), treat as `triage.broken == 0` and exit cleanly through Phase 6.

If `--dry-run` was passed, **stop here**. Emit a summary listing `triage.md`, `triage.json`, and `plan.md` paths and exit. Do not invoke `/exec-plan`.

## Phase 5 — Execute

Main agent invokes:

```
/exec-plan docs/bug-hunt/$TS/plan.md
```

`/exec-plan` owns: worktree spawn, sequential merge gates, push. Workers default to `general-purpose` (Opus 4.7) because realistic Finlet bug fixes (FastAPI routes, MCP tool handlers, Pydantic/SQLModel work) are SWE-Bench Pro and MCP Atlas territory where Opus 4.7 leads GPT-5.5. Flip to `--worker-type codex:codex-rescue` only for narrow cases where Codex's win conditions apply: shell/CLI agent loops (Terminal-Bench), desktop GUI work (OSWorld), long-context >200K, or token-efficiency-critical loops.

## Phase 5.5 — Targeted retest (post-deploy verification)

**The patch landed locally — but did it change user-visible behavior on finlet.dev?**

Phase 5 verifies tests pass on `main`. It does NOT verify the prod deploy succeeded
or that the user-visible symptom is gone. A patch that ships green tests but doesn't
change the live experience is a **patch-ineffective** event — its own class of
failure, separate from cross-iteration recurrence. Phase 5.5 catches it before the
user does.

**Skip Phase 5.5 entirely if:**
- `triage.json.broken == 0` (nothing to retest), OR
- `--dry-run` was passed (we never executed), OR
- `/exec-plan` returned BLOCKED before pushing (no deploy to verify)

### Sub-step 5.5a — Wait for deploy

The patches are merged to `origin/main`. Production runs whatever's at the head of
the deploy workflow run on that SHA. Wait for the deploy to reach `conclusion=success`
before running any retest — running against the OLD code falsely reports
patch-ineffective for a fix that just hasn't shipped yet.

Run inline (no subagent — trivial bash, just polls `gh`):

```bash
HEAD_SHA=$(git -C /Users/justnau/finlet rev-parse origin/main)
echo "DEPLOY_SHA=$HEAD_SHA" > "docs/bug-hunt/$TS/deploy_status.txt"
START=$(date +%s)
DEPLOY_TIMEOUT=900   # 15 min — typical deploy window is 3–7 min
DEPLOY_STATUS=""

# Identify the deploy workflow by name. Finlet uses .github/workflows/deploy.yml
# (workflow name "Deploy Finlet"). The "test → e2e → deploy" jobs run in series;
# only conclusion=success means deploy + post-deploy health-check curl on
# https://finlet.dev/health both passed. If the workflow name ever changes,
# update the [Dd]eploy regex below. No fallback — if no matching run is found in
# 90s, we report "no-workflow-detected" and skip retest (failing closed is safer
# than retesting against an unverified deploy state).
while true; do
  RUN_JSON=$(gh run list --branch main --commit "$HEAD_SHA" --limit 10 \
    --json status,conclusion,workflowName,databaseId,url 2>/dev/null || echo "[]")
  RUN=$(echo "$RUN_JSON" | jq -r '.[] | select(.workflowName | test("[Dd]eploy")) | "\(.status)|\(.conclusion)|\(.databaseId)|\(.url)"' | head -1)
  if [ -z "$RUN" ]; then
    # No deploy workflow yet (run not registered). Wait up to 90s for it to appear.
    if [ $(($(date +%s) - START)) -gt 90 ]; then
      DEPLOY_STATUS="no-workflow-detected"
      break
    fi
    sleep 15
    continue
  fi
  STATUS=$(echo "$RUN" | cut -d'|' -f1)
  CONCLUSION=$(echo "$RUN" | cut -d'|' -f2)
  RUN_ID=$(echo "$RUN" | cut -d'|' -f3)
  RUN_URL=$(echo "$RUN" | cut -d'|' -f4)
  if [ "$STATUS" = "completed" ]; then
    DEPLOY_STATUS="$CONCLUSION"
    echo "DEPLOY_RUN_ID=$RUN_ID" >> "docs/bug-hunt/$TS/deploy_status.txt"
    echo "DEPLOY_RUN_URL=$RUN_URL" >> "docs/bug-hunt/$TS/deploy_status.txt"
    break
  fi
  if [ $(($(date +%s) - START)) -gt $DEPLOY_TIMEOUT ]; then
    DEPLOY_STATUS="timeout-after-${DEPLOY_TIMEOUT}s"
    echo "DEPLOY_RUN_ID=$RUN_ID" >> "docs/bug-hunt/$TS/deploy_status.txt"
    echo "DEPLOY_RUN_URL=$RUN_URL" >> "docs/bug-hunt/$TS/deploy_status.txt"
    break
  fi
  sleep 30
done

echo "DEPLOY_STATUS=$DEPLOY_STATUS" >> "docs/bug-hunt/$TS/deploy_status.txt"
echo "Deploy: $DEPLOY_STATUS (sha=$HEAD_SHA)"
```

**Branching (orchestrator reads `deploy_status.txt` and dispatches):**

```bash
DEPLOY_STATUS=$(grep '^DEPLOY_STATUS=' "docs/bug-hunt/$TS/deploy_status.txt" | cut -d= -f2)
if [ "$DEPLOY_STATUS" = "success" ]; then
  echo "Phase 5.5a: deploy succeeded — proceeding to retest"
  # → spawn retest subagent (5.5b)
else
  echo "Phase 5.5a: deploy did not succeed ($DEPLOY_STATUS) — skipping retest"
  # Emit retest_results.json with skipped-no-deploy entries for every real-broken finding
  jq -c --arg ts "$TS" --arg sha "$DEPLOY_STATUS" '
    .items
    | map(select(.classification == "real-broken"))
    | map({
        finding_id: (. as $i | $i.summary[:50] | gsub("[^a-z0-9]+"; "-")),
        category: .category,
        retest_kind: ((.retest // {}).kind // null),
        retest_status: "skipped-no-deploy",
        evidence: ("deploy=" + $sha),
        duration_s: 0
      })
  ' "docs/bug-hunt/$TS/triage.json" > "docs/bug-hunt/$TS/retest_results.json"
  # → skip 5.5b and 5.5c entirely; jump to Phase 6
fi
```

A non-deployed patch is NOT patch-ineffective; it's patch-not-yet-live. Skipping
5.5c is intentional: we don't append to `pending_recurrences.jsonl` for skipped
retests. Phase 6 surfaces the deploy failure so the user can re-run retest manually
after fixing deploy.

### Sub-step 5.5b — Per-finding retest

Spawn a `general-purpose` subagent (no worktree — it needs Playwright MCP from the
parent environment, which worktree-isolated agents don't get). Prompt:

```text
You are the bug-hunt retest agent. The patches from this iteration's /exec-plan are
deployed to https://finlet.dev. Your job is to verify each real-broken finding's
retest assertion against the LIVE site and emit a retest_results.json file.

ENVIRONMENT (already exported in your shell):
  FINLET_BASE_URL          — e.g. https://finlet.dev
  FINLET_TEST_USER_API_KEY — bearer token for curl-style retests
  FINLET_TEST_USER_EMAIL   — login email for playwright-style retests
  FINLET_TEST_USER_PASSWORD — login password (treat as [REDACTED] in any output)
  TS                       — iteration timestamp

INPUTS:
  docs/bug-hunt/$TS/triage.json    — read .items[] where classification == "real-broken"
  docs/bug-hunt/$TS/deploy_status.txt — confirms DEPLOY_STATUS=success (orchestrator
                                       only spawns you when this is true)

OUTPUT:
  docs/bug-hunt/$TS/retest_results.json — JSON ARRAY, one entry per real-broken finding:
  [
    {
      "finding_id": "<short-slug from triage>",
      "category": "<tag from triage>",
      "retest_kind": "playwright | curl | cli-shell | null",
      "retest_status": "pass | fail | error | skipped-not-retestable",
      "evidence": "<concrete observation: assertion that failed, output, screenshot path>",
      "duration_s": <int>
    },
    ...
  ]

PROCESS (for each real-broken finding):
1. Read item.retest. If retest is null → emit retest_status=skipped-not-retestable
   with evidence=item.retest.description; continue.
2. Run setup steps (login, env, curl preconditions).
3. Run trigger (kind-dispatch):
     - kind=playwright: use the full mcp__playwright__* toolkit. Login + navigation
       requires interaction tools (browser_navigate, browser_fill_form, browser_click,
       browser_type, browser_press_key, browser_wait_for). Verification requires
       observation tools (browser_snapshot, browser_console_messages,
       browser_network_requests, browser_take_screenshot). Use whichever you need.
     - kind=curl:       use Bash to run the curl command; capture status + body.
     - kind=cli-shell:  use Bash to run the shell command; capture exit + stdout + stderr.
4. Verify each assertion. ALL must pass for retest_status=pass. If any fails →
   retest_status=fail, evidence describes which assertion + actual observation.
5. If you cannot run the retest at all (env broken, finlet.dev returns 5xx
   universally, MCP timeout) → retest_status=error, evidence describes why. Do NOT
   mark fail unless an assertion was actually evaluated and contradicted.
6. Run cleanup if specified. Cleanup MUST run even if the assertion failed or
   errored — Finlet's per-tier 1-session-concurrent limit means a leaked session
   from one retest will cause subsequent retests to hit `rate_limited` and
   cascade-fail. Wrap each retest in try/finally semantics: assertion check,
   then cleanup, regardless of assertion outcome. Cleanup failures do NOT change
   retest_status — they are logged in evidence as "(cleanup: <error>)".

REDACTION:
- Never echo FINLET_TEST_USER_PASSWORD or FINLET_TEST_USER_API_KEY in evidence.
  Refer to them as [REDACTED].

RULES:
- Retest only the live URL ($FINLET_BASE_URL). Never run retests against localhost
  or a non-prod environment.
- Retest each finding INDEPENDENTLY. Do not let a fail on finding A skip finding B.
- Order does not matter — pick any order.
- If a retest takes >90s, abort with retest_status=error and evidence="timeout-90s".
- Total wall-clock budget: 10 minutes. If you can't finish all retests in 10 min,
  emit retest_status=error for the unfinished ones with evidence="budget-exceeded".

Exit 0 once retest_results.json is written.
```

### Sub-step 5.5c — Append patch-ineffective signals

After the retest agent finishes, the orchestrator filters failures into
`pending_recurrences.jsonl` (the patch-ineffective ledger). This file feeds the
refactor gate at the START of the next iteration — see "Refactor Gate" preamble.

Run inline:

```bash
RETEST_FILE="docs/bug-hunt/$TS/retest_results.json"
PENDING_FILE="docs/bug-hunt/pending_recurrences.jsonl"

if [ ! -f "$RETEST_FILE" ]; then
  echo "Phase 5.5 skipped — no retest_results.json (deploy not green or no broken findings)"
  exit 0
fi

# Join retest_results with triage to enrich category + scope_files for each fail.
# `error` and `skipped-*` are NOT patch-ineffective — only `fail` (assertion ran
# and contradicted) goes to the patch-ineffective ledger.
DEPLOY_SHA=$(grep '^DEPLOY_SHA=' "docs/bug-hunt/$TS/deploy_status.txt" | cut -d= -f2)

jq -c --arg ts "$TS" --arg sha "$DEPLOY_SHA" --slurpfile triage "docs/bug-hunt/$TS/triage.json" '
  . as $results
  | $results[]
  | select(.retest_status == "fail")
  | . as $r
  | {
      patch_iteration_ts: $ts,
      finding_id: $r.finding_id,
      category: $r.category,
      retest_kind: $r.retest_kind,
      deploy_sha: $sha,
      evidence: $r.evidence,
      scope_files: ($triage[0].items | map(select(.summary != null)) | map(.scope_hint) | first // "")
    }
' "$RETEST_FILE" >> "$PENDING_FILE.tmp" || true

if [ -s "$PENDING_FILE.tmp" ]; then
  cat "$PENDING_FILE.tmp" >> "$PENDING_FILE"
  N_FAIL=$(wc -l < "$PENDING_FILE.tmp" | tr -d ' ')
  echo "Phase 5.5: $N_FAIL patch-ineffective finding(s) appended to $PENDING_FILE"
else
  echo "Phase 5.5: all retests passed (or were skipped/errored) — nothing to append"
fi
rm -f "$PENDING_FILE.tmp"
```

### Sub-step 5.5d — Phase 6 input

The retest summary feeds Phase 6's report. After 5.5c, the following counts are
available for Phase 6:

```bash
# Inline derivations for Phase 6 to consume
RETEST_PASS=$(jq '[.[] | select(.retest_status == "pass")] | length' "docs/bug-hunt/$TS/retest_results.json" 2>/dev/null || echo 0)
RETEST_FAIL=$(jq '[.[] | select(.retest_status == "fail")] | length' "docs/bug-hunt/$TS/retest_results.json" 2>/dev/null || echo 0)
RETEST_ERROR=$(jq '[.[] | select(.retest_status == "error")] | length' "docs/bug-hunt/$TS/retest_results.json" 2>/dev/null || echo 0)
RETEST_SKIPPED=$(jq '[.[] | select(.retest_status | startswith("skipped"))] | length' "docs/bug-hunt/$TS/retest_results.json" 2>/dev/null || echo 0)
```

## Phase 6 — Report

**Recurrence check (run BEFORE emitting the summary).** Read
`docs/bug-hunt/ledger.jsonl` and surface any bug category that has appeared 2+ times
across the ledger. This is how systemic issues get flagged without relying on the user
to spot the pattern. Run inline:

```bash
jq -s 'group_by(.category) | map({category: .[0].category, count: length, iterations: [.[].iteration_ts] | unique}) | map(select(.count >= 2))' docs/bug-hunt/ledger.jsonl | tail -n +1
```

If the recipe emits a non-empty array, the Phase 6 report below MUST include a
"Systemic candidates:" line listing each surfaced category along with its count and
iteration count, so the user sees the recurrence pattern immediately and can decide
whether to escalate (e.g., open a follow-up `/launch-review` or root-cause sweep).
If the array is empty, omit the line.

**Refactor outcome tracking.** For every `docs/bug-hunt/refactor-queue/*.md` file
with `status: shipped` and no `verdict:` yet, the orchestrator MUST evaluate
whether the refactor closed its target cluster, using this iteration's triage as
evidence. Write the verdict back into the queue doc's frontmatter:

- **`verdict: effective`** — zero new instances of the cluster's `category` in this
  iteration's triage. The refactor closed its targets.
- **`verdict: incomplete`** — one or more new instances of the cluster's `category`
  appeared, with `same_root_cause_as` pointing to a finding the refactor was
  supposed to close (or scope_hint indicates a known gap, like a file the refactor
  didn't touch). The refactor was correct but under-scoped.
- **`verdict: regressed`** — one or more new instances appeared in the same files
  the refactor touched, with a different root cause (the refactor introduced new
  bugs in the area it was meant to fix).

If a refactor doc has `status: shipped` and an existing `verdict:`, do not
re-evaluate — leave it alone. The verdict is set once, on the first iteration after
the refactor merges. If a refactor lasts multiple iterations before its verdict is
clear, leave `verdict:` absent on the first iteration's run and re-evaluate next
iteration.

**Pending-recurrences pruning.** Whenever this iteration sets a new
`verdict: effective` on a refactor-queue doc, the orchestrator MUST also prune
`docs/bug-hunt/pending_recurrences.jsonl`: any line whose `category` matches the
refactored category AND whose `patch_iteration_ts` is older than the refactor's
shipped date is now resolved (the refactor closed the underlying root cause).
Inline:

```bash
# After writing verdict: effective on a queue doc, prune pending recurrences:
PENDING_FILE="docs/bug-hunt/pending_recurrences.jsonl"
[ -f "$PENDING_FILE" ] || exit 0
EFFECTIVE_CATEGORY="<the category that just got verdict: effective>"
EFFECTIVE_SHIPPED_TS="<the iteration_ts the refactor shipped under, e.g. refactor-2026-04-30>"

# Move resolved lines into a sibling file for audit, keep unresolved in place.
jq -c --arg cat "$EFFECTIVE_CATEGORY" --arg ts "$EFFECTIVE_SHIPPED_TS" \
  'select(.category != $cat or .patch_iteration_ts >= $ts)' \
  "$PENDING_FILE" > "$PENDING_FILE.kept"
jq -c --arg cat "$EFFECTIVE_CATEGORY" --arg ts "$EFFECTIVE_SHIPPED_TS" \
  'select(.category == $cat and .patch_iteration_ts < $ts)' \
  "$PENDING_FILE" > docs/bug-hunt/pending_recurrences.resolved.jsonl.tmp || true

cat docs/bug-hunt/pending_recurrences.resolved.jsonl.tmp \
  >> docs/bug-hunt/pending_recurrences.resolved.jsonl
mv "$PENDING_FILE.kept" "$PENDING_FILE"
rm -f docs/bug-hunt/pending_recurrences.resolved.jsonl.tmp
```

`incomplete` and `regressed` verdicts do NOT prune — the refactor didn't close
the cluster, so the patch-ineffective signal stays live as a forward signal
for the next iteration's gate.

The Phase 6 report below MUST include a "Refactor outcomes:" block whenever this
iteration sets a new verdict on any queue doc. Omit the block if no verdict was
set this iteration.

Main agent emits a final summary to the user, in this exact shape:

```
Bug-hunt iteration complete.

Artifacts: docs/bug-hunt/$TS/
Triage:    <N> broken / <M> annoying / <K> nice / <J> WAI / <I> ambiguous / <H> needs-investigation
PRs:       <list of PR URLs from /exec-plan, or "none — no broken items">
Deploy:    <success|failure|timeout|no-workflow-detected|n/a>   (read from deploy_status.txt; n/a if Phase 5.5 was skipped)
Retest:    <P pass / F fail / E error / S skipped>              (omit line if Phase 5.5 was skipped)
Patch-ineffective: <list of finding_id (category)>              (omit line if no Phase 5.5 retest failed)
Systemic candidates: <category (count=N, iterations=M)>, ...    (omit line if recurrence-check returned [])
Refactor outcomes:                                               (omit block if no new verdicts this iteration)
  - <category> (<queue doc filename>): <effective|incomplete|regressed> — <one-line evidence from triage>
  ...

Next: open a fresh chat and run /bug-hunt again to do another pass.
```

**Surfacing patch-ineffective findings.** When `Patch-ineffective:` appears, the
report MUST also note: "These will trip the refactor gate on the next iteration —
re-running /bug-hunt without addressing them will pause for refactor instead of
running another patch loop." This sets correct expectations: the user can either
proactively open a refactor doc now, or accept that next iteration auto-routes
to refactor.

The user is the dedupe layer across iterations — they read the triage breakdown,
retest results, systemic candidates, and refactor outcomes, and decide whether to
invoke again or escalate (open a new refactor doc, expand an incomplete one's
scope, revert a regressed one).

## Failure Modes

| Failure | Detection | Action |
|---------|-----------|--------|
| `~/.bug-hunt-loop/secrets.env` missing | Phase 0 file check | Abort with template-pointer message; exit 1. |
| `CLAUDE_CODE_OAUTH_TOKEN` unset | Phase 0 env check | Abort with `claude setup-token` instruction; exit 1. |
| Cleanup returns 401 | Cleanup agent stderr | Hard abort — auth is broken, blind walk is pointless. |
| Cleanup returns other non-zero | Cleanup agent exit code | Log warning to `cleanup.log`, continue into Phase 2. |
| Blind subprocess timeout (>15min) | Wall-clock | Dump last 50 lines stdout/stderr to `blind_diagnostic.log`; abort. |
| Blind subprocess non-zero exit | Subprocess exit code | Same as timeout — diagnostic dump and abort. |
| Isolation check leaks Finlet facts | `_isolation_check` field non-empty in `blind_report.json` | Log warning to `blind_report.json`. **Do not hard-fail** — sanity check only. |
| `triage.json.broken == 0` | Phase 3 output | Skip Phases 4 + 5 + 5.5; report "clean iteration"; exit 0. |
| `/plan-features` returns empty plan | Empty `plan.md` (no `## Teams` section) | Same as zero-broken — exit cleanly through Phase 6. |
| `/exec-plan` failure mid-execution | Exec-plan reports BLOCKED | Surface the blocker in Phase 6 report; skip Phase 5.5 (no deploy to verify); the user decides on retry. |
| Phase 5.5 deploy timeout / failure | `deploy_status.txt` shows non-`success` | Skip retest; emit `Deploy: <status>` in report; do NOT append patch-ineffective signals (the patch isn't live yet). User re-runs retest manually after fixing deploy. |
| Phase 5.5 retest agent crashes | Subagent exits non-zero or no `retest_results.json` | Emit `Retest: error — agent crashed` in report; do NOT append patch-ineffective signals (we couldn't evaluate). |
| Triage missing `retest:` envelope | `items[].retest` absent on a real-broken item | Treat as `retest: null` → Phase 5.5 marks `skipped-not-retestable`. Log warning in `triage.md`. (Old triages from before this change: skip retest entirely.) |

## Out of scope (v1)

- **Persistent regression corpus.** Each fix becoming a Playwright regression test on subsequent iterations. Deferred to v2.
- **Taste escalation.** Acting on `annoying` or `nice-to-have` findings, terminal pauses, Discord prompts, GitHub-issue creation for ambiguous items. v1 only acts on `real-broken`.
- **Multi-iteration auto-loop.** No internal loop; one chat = one iteration. The user is the loop.
- **Cross-iteration deduplication.** No bug ledger; the user is the dedupe layer.
- **Hetzner integration.** No `ops.bugs` table, no `bug-fix-runner`. Local-only.
- **Per-iteration full account nuke.** Only per-session DELETE. `delete_account` is out of scope.
- **API-key minting.** The skill assumes the test user already has an API key in `secrets.env`. Mint via the Finlet dashboard, not from this skill.
- **Anchor Browser / cloud browser.** Local Playwright MCP only.
- **Multi-account / parallel blind agents.** Single test account, single blind agent per invocation.
