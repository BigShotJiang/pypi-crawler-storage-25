#!/usr/bin/env bash
set -euo pipefail

# Clean-room blind agent launcher. Spawns `claude --print` under `env -i` so the
# subprocess inherits ZERO ambient context (no CLAUDE.md, no MCR vault, no skills,
# no agents, no project .mcp.json). Verified flags: `-p`/`--print`. Verified MCP
# launch: `finlet mcp` (typer command at finlet/cli.py:562 → run transport=stdio).
# Usage: blind-launcher.sh "<prompt>" "<output_path>"

if [ "$#" -ne 2 ] || [ -z "${1:-}" ] || [ -z "${2:-}" ]; then
  echo "usage: blind-launcher.sh <prompt> <output_path>" >&2
  exit 1
fi

PROMPT="$1"
OUTPUT_PATH="$2"

# OAuth token (sourced from ~/.bug-hunt-loop/secrets.env in Phase 0). Fail fast
# rather than letting `claude` silently fall back to anon/API-key billing.
if [ -z "${CLAUDE_CODE_OAUTH_TOKEN:-}" ]; then
  echo "ERROR: CLAUDE_CODE_OAUTH_TOKEN is not set in the parent environment." >&2
  echo "Source ~/.bug-hunt-loop/secrets.env before invoking blind-launcher.sh." >&2
  exit 1
fi

# Resolve repo root: prefer git, fall back to relative walk from this script.
if ! REPO_ROOT=$(git rev-parse --show-toplevel 2>/dev/null); then
  REPO_ROOT=$(cd "$(dirname "$0")/../../.." && pwd)
fi

# Per-blind-run config dir. Cleaned up unconditionally on exit.
BLIND_DIR=$(mktemp -d -t bug-hunt-blind-XXXXXX)
trap 'rm -rf "$BLIND_DIR"' EXIT

# Blind MCP config: Playwright (verbatim from project .mcp.json) + Finlet stdio.
cat > "$BLIND_DIR/mcp.json" <<JSON
{
  "mcpServers": {
    "playwright": {
      "command": "npx",
      "args": ["@playwright/mcp@latest"]
    },
    "finlet": {
      "command": "finlet",
      "args": ["mcp"],
      "cwd": "$REPO_ROOT"
    }
  }
}
JSON

# Blind settings: explicitly allowlist the two MCPs and Bash. No other tools.
cat > "$BLIND_DIR/settings.json" <<JSON
{
  "permissions": {
    "allow": ["mcp__playwright", "mcp__finlet", "Bash(*)"]
  }
}
JSON

# Clean-room invocation. `env -i` strips inherited env; HOME + CLAUDE_CONFIG_DIR
# both point at BLIND_DIR to kill any inherited ~/.claude/ config.
env -i \
  PATH="$PATH" \
  HOME="$BLIND_DIR" \
  CLAUDE_CONFIG_DIR="$BLIND_DIR" \
  CLAUDE_CODE_OAUTH_TOKEN="${CLAUDE_CODE_OAUTH_TOKEN}" \
  claude --print \
    --mcp-config "$BLIND_DIR/mcp.json" \
    --strict-mcp-config \
    --settings "$BLIND_DIR/settings.json" \
    --setting-sources "" \
    --disable-slash-commands \
    --permission-mode bypassPermissions \
    --output-format json \
    "$PROMPT" \
  > "$OUTPUT_PATH"
