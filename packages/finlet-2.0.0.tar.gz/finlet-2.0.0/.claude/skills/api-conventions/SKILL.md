---
name: api-conventions
description: Finlet API development conventions and patterns. Applies when writing or modifying FastAPI routes, MCP tools, or CLI commands — covers authentication, session ownership, error responses, and route organization.
user-invocable: false
---

# API Development Conventions

These conventions apply when working on `finlet/api/`, `finlet/mcp/`, and `finlet/cli.py`.

## Authentication
- All endpoints require a valid `Authorization: Bearer <key>` header (FastAPI `HTTPBearer` scheme)
- Use the `require_api_key` dependency for protected endpoints; it validates the Bearer token and returns a `UserRecord`
- Use `optional_api_key` for public endpoints that gain features with auth
- API keys are 32-char hex tokens, SHA-256 hashed before storage, persisted to SQLite with in-memory cache
- Registration is rate-limited to 5 per hour per IP
- Session ownership is enforced — keys can only access their own sessions

## Route Organization
- One route file per resource domain: `routes_session.py`, `routes_clock.py`, etc.
- Each route file defines a FastAPI `APIRouter`
- Routers are registered in `finlet/api/app.py`

## Error Responses
- `422` — Validation errors (Pydantic)
- `404` — Missing sessions/orders
- `429` — Rate limits (pass through from plugins with reset timing)
- `503` — Plugin unavailability

## Session Ownership
- Every endpoint that accesses a session must verify ownership
- Use the dependency injection pattern from `finlet/api/deps.py`
- Never allow cross-user session access

## MCP Server
- Tools mirror REST API functionality
- Each tool has a clear description to help LLMs understand when to use it
- Include example parameter values in descriptions
- Tool names: `get_price_data`, `search_news`, `get_fundamentals`, `get_filings`, `get_economic_data`, `submit_order`, `get_portfolio`, `get_sim_time`, `advance_time`, `freeze_time`

## CLI (typer)
- `finlet serve` — Start API server + serve dashboard
- `finlet session create/list` — Session management
- `finlet plugins list/add` — Plugin management
- `finlet mcp serve` — Start MCP server over stdio (Phase 5, 2026-05-09 — also the dispatch target the agentic-trading CLI commands spawn)

## Middleware
- Security middleware in `finlet/api/security_middleware.py`
- Rate limiting in `finlet/api/rate_limit.py`
- All middleware is async
