---
name: new-mcp-tool
description: Add a new MCP tool to Finlet's FastMCP server. Use when the user wants to add a new tool for LLM agents, extend the MCP interface, or expose new functionality to AI trading agents.
disable-model-invocation: true
argument-hint: <tool-name>
---

# Add a New MCP Tool

Add a tool to Finlet's FastMCP server at `finlet/mcp/server.py`.

## Arguments

- `$ARGUMENTS` — Tool name in snake_case (e.g., `get_earnings_calendar`)

## Steps

### 1. Read the existing MCP server

Read `finlet/mcp/server.py` to understand current tool patterns and the FastMCP setup.

### 2. Add the tool

```python
@mcp.tool()
async def $ARGUMENTS(
    param1: str,
    param2: int = 10,
) -> str:
    """Clear description of what this tool does and when an LLM should use it.

    Include example parameter values to help LLMs understand expected input.
    Example: param1="AAPL", param2=30
    """
    ...
```

### 3. Tool description conventions

The tool description is critical — it's how LLMs decide when to call it:
- First sentence: what the tool does
- Second sentence: when to use it
- Include parameter examples inline
- Mention any constraints (rate limits, data availability)

### 4. Implementation conventions

- **Async only**: All tool functions must be `async def`
- **Return strings**: MCP tools return string responses for LLM consumption
- **Actionable errors**: If something fails, return a helpful error string, not a generic one
- **Use the session**: Access the active session's clock, portfolio, and plugins
- **Respect ceiling_time**: All data queries must pass through the enforcer

### 5. Write tests

Add tests for the new tool's logic. Test:
- Happy path with valid parameters
- Error handling with invalid parameters
- Ceiling time enforcement on returned data

### 6. Verify

```bash
pytest tests/ -v -k "mcp"
```

## Reference

- `finlet/mcp/server.py` — existing MCP server and tools
- `finlet/mcp/__init__.py` — MCP module setup
