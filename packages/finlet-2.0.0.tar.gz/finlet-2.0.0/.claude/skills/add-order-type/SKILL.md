---
name: add-order-type
description: Scaffold a new order type in Finlet's trading engine. Use when the user wants to add a new order type like TRAILING_STOP, OCO, or BRACKET to the order system.
disable-model-invocation: true
argument-hint: <order-type-name>
---

# Add a New Order Type

Add a new order type `$ARGUMENTS` to Finlet's trading engine.

## Steps

### 1. Add to OrderType enum

In `finlet/core/orders.py`, add the new type to the `OrderType` enum.

### 2. Implement fill logic

In the OrderBook class, add fill logic for the new order type:
- When does it trigger?
- What price does it fill at?
- What are the edge cases?

### 3. Add API route support

Update `finlet/api/routes_trade.py` to accept the new order type in request validation.

### 4. Add MCP tool support

Update `finlet/mcp/server.py` to document the new order type in the `submit_order` tool description.

### 5. Write tests

In `tests/core/test_orders.py`:
- Test order creation with new type
- Test fill conditions
- Test cancellation
- Test edge cases (price gaps, market hours boundaries)

### 6. Update documentation

If the new order type has non-obvious behavior, add a note to `docs/ARCHITECTURE.md` under the Order System section.

### 7. Verify

```bash
pytest tests/core/test_orders.py tests/api/test_routes_trade.py -v
```

## Reference

- `finlet/core/orders.py` — OrderType enum, Order model, OrderBook
- `docs/ARCHITECTURE.md` — Order system specification
