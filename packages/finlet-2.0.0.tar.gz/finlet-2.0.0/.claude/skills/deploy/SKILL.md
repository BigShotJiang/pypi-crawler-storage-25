---
name: deploy
description: Deploy Finlet to production. Runs pre-deploy safety checks, pushes to main to trigger CI/CD, and monitors the deployment.
disable-model-invocation: true
allowed-tools: Bash(git *), Bash(gh *), Bash(curl *), Bash(pytest *), Bash(ruff *), Bash(mypy *)
---

# Deploy Finlet to Production

**WARNING: This deploys to the live production server at finlet.dev.**

## Pre-Deploy Checklist

Before pushing, verify ALL of these pass:

1. **Tests pass**: `pytest -v`
2. **Lint clean**: `ruff check finlet/ tests/`
3. **Types clean**: `mypy finlet/ --ignore-missing-imports`
4. **On main branch**: `git branch --show-current` must be `main`
5. **Working tree clean**: `git status` shows no uncommitted changes
6. **Up to date**: `git pull origin main` has no conflicts

If ANY check fails, stop and report the issue. Do NOT proceed with deployment.

## Deploy

Push to main triggers the GitHub Actions pipeline:

```bash
git push origin main
```

## Monitor

1. **Watch CI**: `gh run list --limit 1` — wait for the run to complete
2. **Check run status**: `gh run view <run-id>` — verify all jobs pass
3. **Health check**: After CI completes, wait 60 seconds then:
   ```bash
   curl -sf https://finlet.dev/health
   ```
4. Expected healthy response includes `"status": "healthy"` and `"db_connected": true`

## If Deployment Fails

1. Check CI logs: `gh run view <run-id> --log-failed`
2. If the app is down, refer to `deploy/RUNBOOK.md` for rollback procedures
3. Quick rollback: revert the commit and push again

## Reference

See [deploy/RUNBOOK.md](../../deploy/RUNBOOK.md) for full operational procedures.
