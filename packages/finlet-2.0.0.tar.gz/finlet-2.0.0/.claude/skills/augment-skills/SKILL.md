---
name: augment-skills
description: Audit external skill repos (default obra/superpowers) against Finlet's local skills, propose augmentations that don't clobber the Finlet trio, and install only after explicit user approval. Use when the user wants to evaluate adopting upstream skills, refresh against a known external repo, or check for new skills to absorb.
user_invocable: true
---

# Augment Skills

Pull, diff, and selectively install skills from external Claude Code skill/plugin repos to **augment** (never replace) Finlet's local skill set. Designed around the Finlet trio rule: `brainstorm`, `plan-features`, and `exec-plan` are load-bearing for the multi-team model and MUST NOT be overwritten.

## Invocation

```
/augment-skills [source] [--mode propose|install] [--allow name1,name2]
```

Defaults:
- `source` = `obra/superpowers` (Jesse Vincent's plugin-namespaced skill pack, MIT)
- `mode` = `propose` (always default — never install without an explicit second pass)
- `allow` = empty (no skills auto-installed; must be listed by name)

Examples:
- `/augment-skills` — audit `obra/superpowers` against `.claude/skills/`, write a proposal report, do nothing else.
- `/augment-skills obra/superpowers --mode install --allow test-driven-development,systematic-debugging` — install exactly those two plugin-namespaced skills.

## Hard Rules (Non-Negotiable)

1. **Trio is sacred.** Never propose installing anything that would shadow `brainstorm`, `plan-features`, or `exec-plan`. If an upstream skill has the same name, list it under `CONFLICTS` and skip.
2. **Plugin-namespaced only.** Prefer installs that go into `~/.claude/plugins/` so they appear as `plugin:skill-name` and cannot collide with project-local skills. Reject any install path that would write into `.claude/skills/` of this repo unless the user explicitly opts in via `--into-repo`.
3. **No silent installs.** `--mode install` requires `--allow` with a non-empty, comma-separated list of exact skill names. An empty allowlist is a hard error.
4. **Pre-finals freeze:** if today's date is on or before the user's finals deadline (currently 2026-04-28), refuse `--mode install` unless `--force` is also passed. Print "blocked by finals freeze; rerun with --force if you accept the risk."
5. **Audit-only against unknown sources.** Sources outside an allowlist (`obra/superpowers`, `anthropics/skills`, `claude-plugins-official`) require `--unsafe-source` and only support `--mode propose`.

## Phase 1: Inventory (always)

1. Read every `SKILL.md` under `.claude/skills/*/` and capture: `name`, `description`, `user_invocable`. This is the **local** set.
2. Resolve the source:
   - `obra/superpowers` -> `claude plugin marketplace info superpowers` (already registered per decision #1216 ground-truth check). Fallback: `git ls-remote https://github.com/obra/superpowers.git` for sanity.
   - Other GitHub orgs -> shallow `git clone --depth 1` into `/tmp/augment-skills-<sha>` and read `skills/*/SKILL.md`.
3. For each upstream skill, record `name`, `description`, file path, and a one-line capability summary.

## Phase 2: Diff & Classify

For each upstream skill, classify into exactly one bucket:

- **TRIO_PROTECTED** — name matches `brainstorm`, `plan-features`, or `exec-plan`. Skip with a "would clobber trio" note.
- **DUPLICATE** — same name as another local skill (not in the trio). Compare descriptions; default to keeping local. Flag for user.
- **AUGMENTATION_RECOMMENDED** — fills a known gap (TDD, systematic-debugging, code-review, subagent-driven-development). Mark with confidence H/M/L.
- **AUGMENTATION_OPTIONAL** — useful but not blocking. Mark for `--allow` consideration.
- **SKIP** — not applicable to Finlet's stack (e.g., non-Python tooling we don't use).

## Phase 3: Report (write to disk)

Write `docs/skill-augmentation/{ISO_DATE}-{source-slug}.md` with:

- Summary counts per bucket.
- Full table of upstream skills with their classification + reasoning.
- Recommended `--allow` invocation for the next run.
- Any source-version pin (commit SHA or marketplace version) so the install phase is reproducible.

This file is the handoff artifact between `--mode propose` and `--mode install`.

## Phase 4: Install (only when `--mode install`)

For each name in `--allow`:

1. Verify it's classified `AUGMENTATION_RECOMMENDED` or `AUGMENTATION_OPTIONAL` in the most recent report. If not, abort and tell the user to re-run propose.
2. For `obra/superpowers`: `claude plugin install <skill>@superpowers`.
3. For other plugin marketplaces: install via the marketplace command, never by copying files.
4. After install, list the new plugin path under `~/.claude/plugins/` and confirm `claude /<skill>` resolves.
5. Append an install record to the same report file under `## Installed`.

## Phase 5: Log & Notify

1. Insert a row into `ops.cto_decisions` with `event_type='augment_skills'`, `action='proposed'` or `'installed'`, `inputs.source`, `outputs.report_path`, `outputs.installed[]`.
2. Post a <=8-line summary to Discord channel `1497462256613593189` citing the report path and decision row id.
3. If anything was installed, also append to `docs/lessons.md` so future agents know the skill set changed.

## Anti-Patterns

- **Don't sync.** This is augmentation, not mirroring. Upstream is upstream; we curate.
- **Don't install in `--mode propose` "to save a step".** The two-phase split exists so the user has a chance to veto the allowlist.
- **Don't grep upstream skills for "AI" or "agent" and bulk-import.** Read the descriptions; classify deliberately.
- **Don't auto-update.** Re-running `/augment-skills` against the same source after install does NOT bump versions. Removal/upgrade is a separate manual step (out of scope for this skill).
