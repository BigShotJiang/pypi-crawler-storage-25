---
name: doc-architecture
description: Update ARCHITECTURE.md after code changes to keep documentation in sync. Use when the user has made structural changes and needs to update the architecture docs.
disable-model-invocation: true
context: fork
---

# Update Architecture Documentation

Update `docs/ARCHITECTURE.md` to reflect recent code changes.

## Steps

### 1. Review recent changes

```bash
git diff HEAD~5 --stat
git log --oneline -10
```

### 2. Read current architecture doc

Read `docs/ARCHITECTURE.md` in full.

### 3. Identify gaps

Compare the code changes against the architecture doc:
- Are new modules documented?
- Are changed interfaces reflected?
- Are removed features cleaned up?
- Are new invariants captured?

### 4. Update the doc

Make targeted updates to `docs/ARCHITECTURE.md`:
- Add sections for new components
- Update descriptions for changed components
- Remove references to deleted components
- Keep the existing structure and tone

### 5. Verify accuracy

Cross-reference updated doc against actual code to ensure accuracy. The architecture doc is the source of truth — it must be correct.
