---
name: fix-issue
description: Fix a GitHub issue end-to-end — read the issue, implement the fix, write tests, and create a commit. Use when the user wants to fix a specific GitHub issue, resolve a bug report, or implement a feature request from an issue.
disable-model-invocation: true
argument-hint: <issue-number>
allowed-tools: Bash(gh *), Bash(pytest *), Bash(git *)
---

# Fix GitHub Issue

Fix issue #$ARGUMENTS end-to-end.

## Steps

### 1. Read the issue

```bash
gh issue view $ARGUMENTS
```

Understand the problem, expected behavior, and any reproduction steps.

### 2. Research the codebase

Find the relevant files using the issue description. Read the code to understand the current behavior and what needs to change.

### 3. Implement the fix

- Follow all Finlet conventions (see `/finlet-conventions` skill)
- Make minimal, focused changes — fix the bug, don't refactor surrounding code
- Add type hints to any new code

### 4. Write or update tests

- Add a test that would have caught this bug
- Verify existing tests still pass
- Mock external APIs — no real network calls

### 5. Verify

```bash
pytest tests/ -v --tb=short
ruff check finlet/ tests/
mypy finlet/ --ignore-missing-imports
```

### 6. Create a commit

Stage only the files you changed and commit with a message referencing the issue:

```
Fix #$ARGUMENTS: <brief description of what was fixed>
```

Do NOT push — let the user decide when to push.
