"""${PLUGIN_NAME} data plugin for Finlet."""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Any

import httpx
import structlog

from finlet.core.enforcer import PluginResponse
from finlet.plugins.base import (
    DataPlugin,
    PluginHealth,
    PluginHealthStatus,
    PluginType,
)

logger = structlog.get_logger()


class ${CLASS_NAME}Plugin(DataPlugin):
    """${PLUGIN_NAME} data plugin.

    Provides ${PLUGIN_TYPE} data from ${DATA_SOURCE}.
    """

    plugin_type: str = PluginType.${PLUGIN_TYPE_UPPER}
    name: str = "${plugin_name}"
    requires_api_key: bool = True
    free_tier_limits: dict[str, Any] = {"calls_per_minute": 5}

    def __init__(self) -> None:
        self._client: httpx.AsyncClient | None = None
        self._api_key: str = ""

    async def initialize(self, config: dict[str, Any]) -> bool:
        """Initialize with API key and set up HTTP client."""
        self._api_key = config.get("api_key", "")
        if self.requires_api_key and not self._api_key:
            logger.error("missing_api_key", plugin=self.name)
            return False

        self._client = httpx.AsyncClient(
            base_url="https://api.example.com",
            headers={"Authorization": f"Bearer {self._api_key}"},
            timeout=30.0,
        )
        logger.info("plugin_initialized", plugin=self.name)
        return True

    async def query(
        self, params: dict[str, Any], ceiling_time: datetime
    ) -> PluginResponse:
        """Query data, filtering all results to ceiling_time."""
        if not self._client:
            raise RuntimeError(f"{self.name}: plugin not initialized. Call initialize() first.")

        # TODO: Implement actual API call
        response = await self._client.get("/data", params=params)
        response.raise_for_status()
        raw_items = response.json().get("data", [])

        # Filter by ceiling_time — this is NON-NEGOTIABLE
        items_pre = len(raw_items)
        items = [
            item for item in raw_items
            if datetime.fromisoformat(item["timestamp"]).replace(
                tzinfo=timezone.utc
            ) <= ceiling_time
        ]

        return PluginResponse(
            items=items,
            source=self.name,
            query_params=params,
            ceiling_applied=ceiling_time,
            items_pre_filter=items_pre,
            items_post_filter=len(items),
        )

    async def health_check(self) -> PluginHealth:
        """Check API connectivity and rate limits."""
        if not self._client:
            return PluginHealth(
                status=PluginHealthStatus.UNHEALTHY,
                message=f"{self.name}: not initialized",
            )

        try:
            start = datetime.now(timezone.utc)
            response = await self._client.get("/health")
            latency = (datetime.now(timezone.utc) - start).total_seconds() * 1000

            if response.status_code == 200:
                return PluginHealth(
                    status=PluginHealthStatus.HEALTHY,
                    message=f"{self.name}: operational",
                    latency_ms=latency,
                )
            else:
                return PluginHealth(
                    status=PluginHealthStatus.DEGRADED,
                    message=f"{self.name}: HTTP {response.status_code}",
                    latency_ms=latency,
                )
        except httpx.HTTPError as e:
            return PluginHealth(
                status=PluginHealthStatus.UNHEALTHY,
                message=f"{self.name}: {e}",
            )
