---
name: new-plugin
description: Scaffold a new Finlet data plugin from the DataPlugin abstract class. Use when creating a new data source integration (price, news, fundamentals, filings, or economic data).
disable-model-invocation: true
argument-hint: <plugin-name> <plugin-type>
---

# Create a New Finlet Data Plugin

Scaffold a complete data plugin for Finlet. Arguments: `$ARGUMENTS[0]` is the plugin name, `$ARGUMENTS[1]` is the plugin type (price, news, fundamentals, filings, or economic).

## Steps

1. **Read the base class** at `finlet/plugins/base.py` to understand the `DataPlugin` ABC, `PluginType` enum, `PluginHealth`, and `PluginRegistry`

2. **Read an existing plugin** for reference patterns:
   - Price data: `finlet/plugins/price_plugin.py` (S3 Parquet via pyarrow)
   - News/fundamentals: `finlet/plugins/finnhub_plugin.py`
   - Filings: `finlet/plugins/edgar_plugin.py`
   - Economic data: `finlet/plugins/fred_plugin.py`

3. **Create the plugin file** at `finlet/plugins/$ARGUMENTS[0]_plugin.py`:
   - Import `DataPlugin`, `PluginType`, `PluginHealth`, `PluginHealthStatus` from `finlet.plugins.base`
   - Import `PluginResponse` from `finlet.core.enforcer`
   - Set `plugin_type = PluginType.$ARGUMENTS[1].upper()`
   - Set `name`, `requires_api_key`, `free_tier_limits`
   - Implement `initialize()` — validate config, set up HTTP client (use `httpx.AsyncClient`)
   - Implement `query()` — fetch data, filter by `ceiling_time`, return `PluginResponse`
   - Implement `health_check()` — verify API connectivity, return `PluginHealth`
   - Use `structlog.get_logger()` for logging

4. **Register in `finlet/plugins/__init__.py`** — import and add to the registry

5. **Critical conventions** (from ARCHITECTURE.md):
   - All error messages must be **specific and actionable** (e.g., "AlphaVantage: No data for ticker 'XYZ'. Check symbol at alphavantage.co" not "Data not found")
   - Filter all response items by `ceiling_time` — items with timestamps after ceiling are stripped
   - Items without timestamps are excluded by default
   - Never expose filter counts to the agent (leaks future data existence)
   - Use `httpx.AsyncClient` for async HTTP (no sync I/O)
   - All datetimes in UTC

6. **Write tests** at `tests/plugins/test_$ARGUMENTS[0]_plugin.py`:
   - Mock external API calls (no real network in tests)
   - Test `initialize()` with valid and invalid configs
   - Test `query()` with ceiling_time filtering
   - Test `health_check()` healthy and unhealthy states
   - Test edge cases: empty responses, rate limits, malformed data

7. **Run tests**: `pytest tests/plugins/ -v`

## Reference

See [template.py](template.py) for a starter template.
