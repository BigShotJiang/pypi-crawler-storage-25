---
name: dep-audit
description: Run a security audit and dependency check on Finlet's Python dependencies. Use when the user wants to check for vulnerabilities, audit packages, or update outdated dependencies.
disable-model-invocation: true
allowed-tools: Bash(pip *), Bash(pip-audit *), Bash(uv *)
---

# Dependency Audit

Run a security and freshness audit of Finlet's Python dependencies.

## Steps

### 1. Check for known vulnerabilities

```bash
pip-audit
```

If pip-audit is not installed: `pip install pip-audit`

### 2. Check for outdated packages

```bash
pip list --outdated
```

### 3. Report

For each issue found:
- **Vulnerability**: Package name, CVE ID, severity, affected version, fixed version
- **Outdated**: Package name, current version, latest version, whether upgrade is safe

### 4. Fix recommendations

- For vulnerabilities: upgrade to the fixed version immediately
- For outdated packages: check changelog for breaking changes before upgrading
- Update `pyproject.toml` with new version constraints
- Run `pytest tests/ -v` after any dependency change
