---
name: finlet-conventions
description: Core Finlet development conventions and patterns. Applies when writing or modifying any Finlet code — covers datetime handling, error messages, async patterns, type hints, and the date ceiling enforcer.
user-invocable: false
---

# Finlet Development Conventions

These conventions apply to ALL code in the Finlet project.

## Datetime Handling
- All datetimes stored and processed in **UTC** internally
- Convert to local time only for display in the dashboard
- Use `datetime.datetime` with `tzinfo=datetime.timezone.utc`
- Never use naive datetimes

## Date Ceiling Enforcer
- Every piece of data flowing from a plugin to an agent passes through the enforcer
- Items with timestamps after the ceiling are **stripped**
- Items without timestamps are **excluded by default**
- **Never** expose filter counts to agents (leaks future data existence)
- This is defense-in-depth — plugins also filter, but we don't trust them

## Error Messages
- All error messages to agents must be **specific and actionable**
- Good: `"Finnhub rate limit exceeded: 0/60 calls remaining, resets in 42 seconds"`
- Bad: `"API error"`
- Good: `"PricePlugin: No data available for ticker 'INVALID'. Check ticker symbol against supported universe"`
- Bad: `"Data not found"`

## Async Patterns
- Async functions everywhere — no sync I/O in the hot path
- Use `httpx.AsyncClient` for HTTP calls
- Use `aiosqlite` for database operations
- Use `asyncio.Lock()` for concurrency-sensitive operations (portfolio, order book)

## Code Structure
- One file per module, no god files
- Use Pydantic models / dataclasses for all shared data structures
- Type hints on all function signatures
- Use `structlog` for logging (not stdlib `logging`)

## Testing
- pytest + pytest-asyncio
- Mock external APIs — no real network calls in tests
- Test edge cases: market hours boundaries, order fills at price gaps, enforcer stripping future data, portfolio metrics with no trades
