---
name: test-engine
description: Run Finlet core engine tests — clock, enforcer, portfolio, orders, and sessions. Use when the user wants to test core engine code, verify clock behavior, test the enforcer, or check order/portfolio logic.
disable-model-invocation: true
allowed-tools: Bash(pytest *)
argument-hint: [test-pattern]
---

# Run Engine Tests

Run tests for the core engine (`finlet/core/`).

```bash
pytest tests/core/ -v --tb=short $ARGUMENTS
```

If tests fail, analyze the failures and suggest specific fixes. Focus on:
- Clock mode transitions and time advancement
- Enforcer stripping future data correctly
- Portfolio metric calculations
- Order state machine transitions (PENDING -> FILLED/CANCELLED/REJECTED)
- Concurrency safety (asyncio.Lock usage)
