---
name: ops-runbook
description: Quick access to Finlet operational procedures from the runbook. Use when the user asks about operations, rollback procedures, server management, or incident response.
context: fork
agent: Explore
argument-hint: [topic]
---

# Operations Runbook Reference

Look up operational procedures from `deploy/RUNBOOK.md` related to: $ARGUMENTS

## Steps

1. Read `deploy/RUNBOOK.md`
2. Find the section most relevant to the user's query
3. Summarize the relevant procedures clearly
4. Include exact commands from the runbook
5. Flag any destructive operations that require caution
