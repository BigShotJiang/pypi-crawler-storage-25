---
name: explain-engine
description: Explain Finlet's core engine architecture — simulation clock, date ceiling enforcer, portfolio engine, and order system. Use when the user asks how Finlet works, wants to understand the architecture, or is onboarding to the codebase.
context: fork
agent: Explore
---

# Explain Finlet Engine

Research and explain Finlet's core engine architecture based on $ARGUMENTS.

## Steps

1. Read `docs/ARCHITECTURE.md` for the authoritative architecture specification
2. Read relevant source files in `finlet/core/`:
   - `clock.py` — Simulation clock (FROZEN, STEPPING, CONTINUOUS modes)
   - `enforcer.py` — Date ceiling enforcer (defense-in-depth against future data leakage)
   - `portfolio.py` — Portfolio engine (positions, cash, metrics, equity curve)
   - `orders.py` — Order system (MARKET, LIMIT, STOP orders)
   - `session.py` — Session container (owns clock, portfolio, trace log)
3. Explain with analogies and ASCII diagrams where helpful
4. Highlight the key invariants and safety mechanisms
