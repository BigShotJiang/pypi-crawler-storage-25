---
name: deploy-status
description: Check Finlet's current deployment status, health, and recent CI runs. Use when the user asks about deployment health, service status, whether the app is up, or recent CI/CD activity.
disable-model-invocation: true
allowed-tools: Bash(curl *), Bash(gh *)
---

# Check Deployment Status

Check the current state of Finlet's production deployment.

## Steps

### 1. Health check

```bash
curl -sf https://finlet.dev/health
```

Expected healthy response includes `"status": "healthy"` and `"db_connected": true`.

### 2. Recent GitHub Actions runs

```bash
gh run list --limit 5
```

Check for any recent failures.

### 3. Report

Provide a clear status summary:
- Is the service up and healthy?
- What was the last deployment and its status?
- Any recent failures in CI?
- If unhealthy, suggest checking `deploy/RUNBOOK.md` for troubleshooting
