---
name: review-pr
description: Review a pull request for correctness, conventions compliance, and test coverage. Use when the user wants to review a PR, check code quality, or get feedback on changes before merging.
disable-model-invocation: true
context: fork
agent: Explore
argument-hint: <pr-number>
allowed-tools: Bash(gh *)
---

# Review Pull Request

Review PR #$ARGUMENTS for correctness and Finlet convention compliance.

## PR Context

- PR diff: !`gh pr diff $ARGUMENTS 2>/dev/null || echo "Could not fetch PR diff"`
- PR description: !`gh pr view $ARGUMENTS 2>/dev/null || echo "Could not fetch PR"`
- Changed files: !`gh pr diff $ARGUMENTS --name-only 2>/dev/null || echo "Could not list files"`

## Review Checklist

For each changed file, verify:

### Correctness
- Does the code do what the PR description claims?
- Are there any logic errors or edge cases missed?
- Are error paths handled properly?

### Finlet Conventions
- All datetimes in UTC?
- Error messages specific and actionable?
- Async everywhere (no sync I/O)?
- Type hints on all new functions?
- Pydantic models for data structures?
- Date ceiling enforcer not bypassed?

### Tests
- Are new features covered by tests?
- Are edge cases tested?
- External APIs mocked (no real network calls)?

### Security
- Session ownership enforced on new endpoints?
- No secrets or API keys in the diff?
- Input validation present?

## Output

Provide a structured review:
1. **Summary**: One-line assessment (approve/request changes)
2. **Issues**: Specific problems with file paths and line numbers
3. **Suggestions**: Optional improvements (clearly marked as non-blocking)
