---
name: ui-flow-mcp
description: "Visual E2E testing using Playwright MCP — AI agent observes browser state adaptively. Use for exploratory testing on new pages, major redesigns, or when you need an intelligent observer. For regression testing, use /ui-flow (Playwright CLI) instead."
user_invocable: true
---

> **Exploratory testing mode.** This skill uses Playwright MCP with AI agents that observe and adapt to browser state. Use for discovery on new/redesigned pages. For fast regression runs, use `/ui-flow` (Playwright CLI, 2-5 min).

# E2E UX Flow Test Suite

Runs all 15 UX journeys (3 CLI + 12 browser) against the live Finlet server, collects results, and reports a summary. Designed for fix-and-rerun cycles: run once, fix failures, run `/ui-flow --failed-only` until green.

## Invocation

```
/ui-flow                     # Run all 15 journeys
/ui-flow --batch cli         # Run only CLI journeys (13-15)
/ui-flow --batch 1           # Run only Browser Batch 1
/ui-flow --batch 2           # Run only Browser Batch 2
/ui-flow --batch 3           # Run only Browser Batch 3
/ui-flow --batch 4           # Run only Browser Batch 4
/ui-flow --journey 7         # Run only journey 7
/ui-flow --failed-only       # Re-run journeys with status FAIL or PASS_WITH_BUGS
```

## Architecture

- **Playwright MCP** handles all browser interactions (single instance, sequential within each batch)
- **Gmail MCP** handles email verification (Journey 12 -- forgot password flow)
- **Bash** handles CLI journeys (13-15, parallel)
- **Test plan** with all element IDs, selectors, and expected behaviors lives in `docs/plans/e2e_ux_testing_plan.md` -- it is the source of truth
- **5 agents total**: 1 CLI agent (all 3 CLI journeys) + 4 browser agents (one per batch)
- CLI agent runs concurrently with browser batches. Browser batches run sequentially (batch 1 then 2 then 3 then 4).

## Pipeline

### Step 0: Pre-flight

Run these commands in order before launching any agents:

1. **Kill existing server** on port 8000:
   ```bash
   lsof -ti:8000 | xargs kill 2>/dev/null
   ```

2. **Check session count** -- if over 500, warn user and archive:
   ```bash
   COUNT=$(ls ~/.finlet/sessions/ 2>/dev/null | wc -l)
   if [ "$COUNT" -gt 500 ]; then
     echo "WARNING: $COUNT sessions found. Archiving to prevent slowdown."
     mv ~/.finlet/sessions/ ~/.finlet/sessions_backup_$(date +%s)/
     mkdir -p ~/.finlet/sessions/
   fi
   ```

3. **Start server**:
   ```bash
   cd /Users/justnau/finlet && FINLET_SSM_ENABLED=0 FINLET_CORS_ORIGINS='*' uv run uvicorn finlet.api.app:create_app --factory --host 0.0.0.0 --port 8000 &
   SERVER_PID=$!
   ```

4. **Wait for health** -- poll `GET http://localhost:8000/v1/health` up to 30 seconds:
   ```bash
   for i in $(seq 1 30); do
     curl -sf http://localhost:8000/v1/health && break
     sleep 1
   done
   ```

5. **Detect email provider** -- check server startup logs for "console" email provider. If detected, store `EMAIL_PROVIDER=console` and note that Journey 12 will be limited (no real email delivery). Otherwise `EMAIL_PROVIDER=smtp`.

6. **Create output directories** and wipe screenshots for full runs:
   ```bash
   mkdir -p tests/e2e-ux-results/screenshots
   # For full runs only:
   rm -f tests/e2e-ux-results/screenshots/*.png
   ```

7. **Get test email** -- call `gmail_get_profile` MCP tool, store the returned email address as `TEST_EMAIL`. This is used in signup/login prompts across all journeys.

8. **Set test password**: `TEST_PASSWORD=TestPass!2026secure`

After pre-flight, the main agent has three template variables to inject into batch prompts:
- `{TEST_EMAIL}` -- the Gmail address
- `{TEST_PASSWORD}` -- `TestPass!2026secure`
- `{EMAIL_PROVIDER}` -- `console` or `smtp`

### Step 1: Parse Arguments

Parse `$ARGUMENTS` to determine which journeys to run:

| Argument | Journeys |
|----------|----------|
| (none) | All 15 |
| `--batch cli` | 13, 14, 15 |
| `--batch 1` | 1, 2 |
| `--batch 2` | 3, 4, 5 |
| `--batch 3` | 6, 7, 8 |
| `--batch 4` | 9, 10, 11, 12 |
| `--journey N` | Journey N only |
| `--failed-only` | Read `summary.json`, filter for journeys with status `FAIL` or `PASS_WITH_BUGS`, run only those batches, then merge results back |

### Step 2: Execute Journeys

Dispatch agents using the locked-in prompts from the "Batch Prompts" section below. Fill in `{TEST_EMAIL}`, `{TEST_PASSWORD}`, and `{EMAIL_PROVIDER}` before dispatching. **Do NOT rewrite, improvise, or abbreviate the prompts. They are dispatched verbatim with only the template variables replaced.**

Execution order:
- Launch CLI agent in background (runs all 3 CLI journeys in parallel via Bash)
- Launch Browser Batch 1 agent, wait for completion
- Launch Browser Batch 2 agent, wait for completion
- Launch Browser Batch 3 agent, wait for completion
- Launch Browser Batch 4 agent, wait for completion
- Collect CLI agent results (should be done by now)

Total: **5 agents** (1 CLI + 4 browser).

### Step 3: Collect Results

Each agent reports back with per-journey results including:
- **Status**: `PASS`, `PASS_WITH_BUGS`, or `FAIL`
- **Bugs**: array of bug descriptions (for `PASS_WITH_BUGS`)
- **Screenshots**: saved to `tests/e2e-ux-results/screenshots/{NN}-{name}.png`
- **Console errors**: browser console errors captured
- **Network failures**: failed HTTP requests (4xx/5xx)
- **Failure details**: if `FAIL`, the specific step that failed and why
- **Duration**: `duration_s` per journey

### Step 4: Write State

Write `tests/e2e-ux-results/summary.json` and `tests/e2e-ux-results/REPORT.md`.

**`summary.json` schema (tri-state)**:
```json
{
  "timestamp": "2026-03-29T...",
  "total": 15,
  "passed": 10,
  "passed_with_bugs": 3,
  "failed": 2,
  "journeys": [
    {"id": 1, "name": "Landing Page", "status": "PASS", "duration_s": 4.2},
    {"id": 5, "name": "Trade Flow", "status": "PASS_WITH_BUGS", "duration_s": 12.1, "bugs": ["Trade ticket form causes page reload", "No visible trade button"]},
    {"id": 13, "name": "CLI -- finlet serve", "status": "FAIL", "duration_s": 8.0, "failure": "GET /v1/auth/register returned 404 not 405"}
  ]
}
```

**State update rules:**

| Scenario | summary.json | REPORT.md | screenshots/ |
|----------|-------------|-----------|-------------|
| Full run (`/ui-flow`) | Overwrite all | Overwrite | Wipe + regenerate all |
| Partial re-run (`--failed-only`, `--batch`, `--journey`) | Merge updated entries, carry forward untouched | Overwrite with this run only | Delete + regenerate only re-run journeys |

`summary.json` is always exactly 15 entries. `REPORT.md` is always one run's worth of data. No accumulation.

### Step 5: Update Docs (mandatory)

This step is NOT optional. After all results are collected, **spawn a dedicated doc-update agent** that:
1. Reads `tests/e2e-ux-results/REPORT.md` (the run just completed)
2. Reads `docs/REMAINING_TASKS.md` (current task tracking)
3. Adds new bugs discovered in this run as tasks
4. Cross-references existing items -- if a bug from REMAINING_TASKS now passes, mark it resolved
5. Does NOT remove items that were not tested in this run (partial runs leave untested items alone)

### Step 6: Report

Output a summary table with the results to the user. Include journey ID, name, status, duration, and details for any non-PASS journey. End with counts (passed / passed_with_bugs / failed) and a suggested next command (`/ui-flow --failed-only` if there are failures).

---

## Batch Prompts

These prompts are **LOCKED IN**. The main agent dispatches them verbatim with only `{TEST_EMAIL}`, `{TEST_PASSWORD}`, and `{EMAIL_PROVIDER}` replaced. Do not rewrite, abbreviate, or improvise.

---

### Prompt: CLI Batch (Journeys 13-15)

```
You are an E2E test agent running CLI journeys 13, 14, and 15 against the Finlet server at http://localhost:8000.

Record the start time before the first journey and end time after the last. Report duration_s for each journey.

TEST_EMAIL: {TEST_EMAIL}
TEST_PASSWORD: {TEST_PASSWORD}
SCREENSHOT_DIR: tests/e2e-ux-results/screenshots

Run all 3 journeys via Bash. They are independent -- run them in parallel.

--- JOURNEY 13: CLI -- finlet serve ---

Steps:
1. Verify server is already running: curl -sf http://localhost:8000/v1/health (should return 200)
2. Verify dashboard served: curl -s -o /dev/null -w "%{http_code}" http://localhost:8000/landing.html (expect 200)
3. Verify API docs: curl -s -o /dev/null -w "%{http_code}" http://localhost:8000/docs (expect 200)
4. Verify auth endpoint exists: curl -s -o /dev/null -w "%{http_code}" http://localhost:8000/v1/auth/register (expect 404 -- FastAPI returns 404, not 405, for GET on POST-only routes. This is correct behavior.)
5. Record all status codes.

Pass criteria: Health 200, landing 200, docs 200, auth endpoint returns 404 (confirming route exists but GET not allowed).

--- JOURNEY 14: CLI -- Session Lifecycle ---

Steps:
1. Register a CLI test user:
   curl -s -X POST http://localhost:8000/v1/auth/register \
     -H "Content-Type: application/json" \
     -d '{"email":"cli-test-'$(date +%s)'@finlet.dev","password":"CliTestPass!2026"}'
2. Parse api_key from the JSON response.
3. Create session:
   uv run finlet session create \
     --name "CLI Test" \
     --start 2024-01-01 \
     --capital 50000 \
     --universe "AAPL,MSFT" \
     --api-key "$API_KEY"
   Verify output contains "Session created:" and a session ID (12-char hex, NOT a UUID).
   Parse the session ID.
4. List sessions:
   uv run finlet session list --api-key "$API_KEY"
   Verify "CLI Test" appears in output.
5. Delete session:
   uv run finlet session delete "$SESSION_ID" --api-key "$API_KEY"
   Verify output contains "Session deleted:".
6. List again -- verify "CLI Test" does not appear or output says "No active sessions."
7. Delete nonexistent session:
   uv run finlet session delete "000000000000" --api-key "$API_KEY"
   Verify output contains "not found" and exit code is 1.

Pass criteria: Full create/list/delete lifecycle works, error case handled.

--- JOURNEY 15: CLI -- Plugins Lifecycle ---

Steps:
1. List plugins:
   uv run finlet plugins list
   Verify output contains "Plugins:" header.
   Verify 4 built-in plugins: price [price], edgar [filings], fred [economic], finnhub [news+fundamentals].
2. Add plugin:
   uv run finlet plugins add finnhub --api-key "test-key-123"
   Verify output: "Plugin 'finnhub' configured. Restart server to apply."
3. Verify config:
   cat ~/.finlet/plugins.json
   Verify JSON contains finnhub entry with api_key "test-key-123".
4. List again -- verify finnhub shows "configured" status.
5. Add another:
   uv run finlet plugins add edgar --email "test@example.com"
   Verify output: "Plugin 'edgar' configured. Restart server to apply."
6. Verify config updated -- both finnhub and edgar entries present.
7. Clean up: restore original plugins.json or remove test entries.

Pass criteria: List shows plugins with types/status, add persists config, status updates.

--- REPORT FORMAT ---

For each journey, report:

JOURNEY: [number] -- [name]
STATUS: PASS | PASS_WITH_BUGS | FAIL
DURATION_S: [seconds]
BUGS: [list of bug descriptions, or "none"]
FAILURE_DETAIL: [if FAIL -- which step failed and the error message]
CONSOLE_OUTPUT: [relevant stdout/stderr snippets]

Do NOT attempt to fix failures. Report them accurately.
```

---

### Prompt: Browser Batch 1 (Journeys 1-2)

```
You are an E2E test agent running browser Journeys 1 and 2 against the Finlet server at http://localhost:8000.

FIRST: Use ToolSearch to load Playwright MCP tools (query: "playwright browser") so you can call browser_navigate, browser_click, browser_snapshot, browser_take_screenshot, browser_fill_form, browser_type, browser_press_key, browser_wait_for, browser_console_messages, browser_network_requests, browser_navigate_back, browser_resize, browser_evaluate.

Record the start time before each journey and end time after. Report duration_s for each.

TEST_EMAIL: {TEST_EMAIL}
TEST_PASSWORD: {TEST_PASSWORD}
SCREENSHOT_DIR: tests/e2e-ux-results/screenshots

Run journeys sequentially (Playwright is a single browser instance).

--- JOURNEY 1: Landing Page ---

Steps:
1. browser_navigate to http://localhost:8000/landing.html
2. browser_wait_for network idle
3. browser_take_screenshot to SCREENSHOT_DIR/01-landing-initial.png
4. browser_snapshot -- verify ALL of:
   - Page title is "Finlet -- AI Trading Agent Backtesting Platform"
   - Hero section section.landing-hero with h1 containing "Backtest your AI agent"
   - Navigation nav.landing-nav with links:
     - a.landing-nav-link[href="#features"] (Features)
     - a.landing-nav-link[href="#demo"] (Demo)
     - a.landing-nav-link[href="#how-it-works"] (How It Works)
     - a.landing-nav-cta[href="auth.html"] (Get Started)
   - Hero CTA a.landing-btn-primary[href="auth.html"] with text "Get Started Free"
   - Secondary CTA a.landing-btn-secondary[href="#demo"] with text "See It in Action"
   - Trust badges in div.landing-hero-trust (3 span children)
   - Features section section.landing-features#features
5. browser_console_messages -- record all errors
6. browser_network_requests -- flag any 4xx/5xx
7. Click a.landing-btn-primary[href="auth.html"] ("Get Started Free") -- verify navigates to auth.html
8. browser_take_screenshot to SCREENSHOT_DIR/01-landing-cta-click.png
9. browser_navigate_back -- verify returns to landing.html
10. browser_take_screenshot to SCREENSHOT_DIR/01-landing-final.png

Pass criteria: Page loads < 3s, all nav works, no JS exceptions, no failed requests.

--- JOURNEY 2: Sign Up Flow ---

Steps:
1. browser_navigate to http://localhost:8000/auth.html
2. browser_take_screenshot to SCREENSHOT_DIR/02-signup-initial.png
3. Verify login tab is active by default: #tab-login has class auth-tab--active (browser_snapshot)
4. Click #tab-signup (the tab with data-tab="signup") to switch to Create Account
5. browser_take_screenshot to SCREENSHOT_DIR/02-signup-tab.png
6. Test empty submission -- click #signup-btn with no fields filled, verify validation errors:
   - #signup-email-error shows email validation error
   - #signup-password-error shows password error
   - #signup-terms-error shows terms error
7. browser_take_screenshot to SCREENSHOT_DIR/02-signup-validation-empty.png
8. Test invalid input -- enter "notanemail" in #signup-email + "short" in #signup-password, verify:
   - #signup-email-error shows email format error
   - #signup-password-error shows minimum length error
   - Password strength meter #signup-password-strength shows "Weak" via #signup-strength-label
   - Strength bar #signup-strength-fill has class auth-strength-bar-fill--weak
9. browser_take_screenshot to SCREENSHOT_DIR/02-signup-validation-invalid.png
10. Fill valid form:
    - #signup-email: {TEST_EMAIL}
    - #signup-password: {TEST_PASSWORD}
    - Check #signup-research checkbox (Research Network)
    - Check #signup-terms checkbox (Terms)
    - Verify strength bar shows "Strong" (#signup-strength-label text, auth-strength-bar-fill--strong class)
11. browser_take_screenshot to SCREENSHOT_DIR/02-signup-filled.png
12. Submit -- click #signup-btn
13. browser_wait_for network idle
14. Verify POST /v1/auth/register returned 201 (browser_network_requests)
15. Verify success state -- #signup-success has class auth-success--visible, #signup-fields is hidden
16. browser_take_screenshot to SCREENSHOT_DIR/02-signup-success.png
17. Click #go-to-dashboard-btn ("Go to Dashboard") -- verify redirect to index.html
18. browser_take_screenshot to SCREENSHOT_DIR/02-signup-redirect.png
19. browser_console_messages -- collect errors

Pass criteria: Validation catches errors, registration returns 201, redirect works.

--- REPORT FORMAT ---

For each journey, report:

JOURNEY: [number] -- [name]
STATUS: PASS | PASS_WITH_BUGS | FAIL
DURATION_S: [seconds]
BUGS: [list of bug descriptions, or "none"]
SCREENSHOTS: [list of screenshot paths taken]
CONSOLE_ERRORS: [list or "none"]
NETWORK_FAILURES: [list or "none"]
FAILURE_DETAIL: [if FAIL -- which step failed and the error message]

Do NOT attempt to fix failures. Report them accurately.
```

---

### Prompt: Browser Batch 2 (Journeys 3-5)

```
You are an E2E test agent running browser Journeys 3, 4, and 5 against the Finlet server at http://localhost:8000.

FIRST: Use ToolSearch to load Playwright MCP tools (query: "playwright browser") so you can call browser_navigate, browser_click, browser_snapshot, browser_take_screenshot, browser_fill_form, browser_type, browser_press_key, browser_wait_for, browser_console_messages, browser_network_requests, browser_navigate_back, browser_resize, browser_evaluate.

Record the start time before each journey and end time after. Report duration_s for each.

TEST_EMAIL: {TEST_EMAIL}
TEST_PASSWORD: {TEST_PASSWORD}
SCREENSHOT_DIR: tests/e2e-ux-results/screenshots

Run journeys sequentially. You MUST be logged in before starting. If not already logged in, navigate to http://localhost:8000/auth.html, fill #login-email with {TEST_EMAIL} and #login-password with {TEST_PASSWORD}, click #login-btn, and wait for redirect to index.html.

--- JOURNEY 3: Login Flow ---

Steps:
1. browser_evaluate: sessionStorage.clear(); localStorage.clear();
2. browser_navigate to http://localhost:8000/auth.html
3. browser_take_screenshot to SCREENSHOT_DIR/03-login-initial.png
4. Test empty submission -- click #login-btn with no fields, verify:
   - #login-email-error shows email required error
   - #login-password-error shows password required error
5. browser_take_screenshot to SCREENSHOT_DIR/03-login-validation.png
6. Test wrong password -- fill #login-email with {TEST_EMAIL} + #login-password with "WrongPassword123!", submit via #login-btn, verify #login-alert shows error "Invalid email or password"
7. browser_take_screenshot to SCREENSHOT_DIR/03-login-wrong-pw.png
8. Fill correct credentials in #login-email ({TEST_EMAIL}) and #login-password ({TEST_PASSWORD}), submit via #login-btn
9. browser_wait_for URL change to index.html
10. browser_take_screenshot to SCREENSHOT_DIR/03-login-success.png
11. browser_evaluate: verify auth state -- !!sessionStorage.getItem('finlet_api_key') || !!sessionStorage.getItem('finlet_user')
12. browser_console_messages -- collect errors

Pass criteria: Wrong creds show error in #login-alert, correct creds login + redirect + set session auth.

--- JOURNEY 4: Dashboard -- Sessions + Clock Controls ---

Steps:
1. Navigate to http://localhost:8000/index.html (login first if needed)
2. browser_take_screenshot to SCREENSHOT_DIR/04-dashboard-initial.png
3. browser_snapshot -- verify ALL of:
   - Shared nav via header.top-bar with nav.header-nav containing links:
     - a.header-nav-link[href="index.html"] (Dashboard, should have header-nav-link--active)
     - a.header-nav-link[href="leaderboard.html"] (Leaderboard)
     - a.header-nav-link[href="marketplace.html"] (Marketplace)
     - a.header-nav-link[href="billing.html"] (Billing)
     - a.header-nav-link[href="settings.html"] (Settings)
   - Session selector #session-select
   - Session status badge #session-status
   - User menu #user-menu with trigger #user-menu-trigger
   - Connection indicator #connection-indicator with #connection-dot and #connection-label
   - Refresh button #btn-refresh
   - Sim time display #header-sim-time
   - First-run banner #first-run-banner visible (no sessions yet) OR session selector populated
4. Click #btn-new-session (or #btn-create-first-session if first-run banner showing) to open create session modal
5. Verify #create-session-modal has class modal-overlay--visible
6. browser_take_screenshot to SCREENSHOT_DIR/04-session-modal.png
7. Fill form:
   - #session-name: "E2E Test Session"
   - Keep default template conservative (template card with data-template="conservative" should have template-card--selected)
   - #session-capital: keep default 100000
   - #session-start-date: keep default (1 year ago)
8. browser_take_screenshot to SCREENSHOT_DIR/04-session-filled.png
9. Submit via #create-session-submit -- verify POST /v1/sessions succeeds
10. browser_wait_for #create-session-modal to lose class modal-overlay--visible
11. Verify session appears in #session-select dropdown (more than 1 option)
12. browser_take_screenshot to SCREENSHOT_DIR/04-session-created.png
13. Test clock controls:
    - Freeze: Click #btn-freeze, verify #clock-mode text updates to "frozen" (case-insensitive), verify POST /v1/sessions/{id}/clock/freeze called
    - browser_take_screenshot to SCREENSHOT_DIR/04-clock-freeze.png
    - Step: Click #btn-step, verify sim time advances, verify POST /v1/sessions/{id}/clock/step called
    - browser_take_screenshot to SCREENSHOT_DIR/04-clock-step.png
    - Play: Click #btn-play, verify #clock-mode changes to "continuous" or "playing", verify POST /v1/sessions/{id}/clock/play called
    - browser_take_screenshot to SCREENSHOT_DIR/04-clock-play.png
    - Stop: Click #btn-stop, verify POST /v1/sessions/{id}/clock/stop called
    - browser_take_screenshot to SCREENSHOT_DIR/04-clock-stop.png
14. Verify polling -- check browser_network_requests for repeated GET /v1/sessions/{id} calls
15. browser_console_messages -- collect errors

Pass criteria: Session created, clock controls work, polling active.

--- JOURNEY 5: Trade Flow ---

Steps:
1. Navigate to dashboard, select session (login if needed). Step clock forward several days via #btn-step to ensure price data is available.
2. browser_take_screenshot to SCREENSHOT_DIR/05-trade-pre.png
3. Click #btn-trade to open trade ticket slide-out panel. NOTE: If #btn-trade is not visible, this is BUG -- log it as a bug, then try browser_evaluate: openTradeTicket() as a workaround to continue testing.
4. Verify #trade-ticket-panel has class trade-ticket--open
5. Verify #trade-ticket-backdrop has class trade-ticket-backdrop--visible
6. Verify cash balance #tt-cash-balance shows a dollar amount (from GET /v1/sessions/{id}/portfolio)
7. browser_take_screenshot to SCREENSHOT_DIR/05-trade-ticket-open.png
8. Test empty submission -- click #tt-submit without filling fields, verify #tt-error shows validation message like "Symbol must be 1-5 uppercase letters."
9. browser_take_screenshot to SCREENSHOT_DIR/05-trade-validation.png
10. Try the "Test Trade" quick-fill button #tt-test-trade -- click it and check if fields auto-fill (#tt-symbol, #tt-quantity, #tt-order-type, #tt-side-buy). If it does NOT auto-fill, log as BUG and fill manually.
11. Fill trade (manually if #tt-test-trade did not work):
    - Type a valid ticker from the session's universe in #tt-symbol (e.g., "SPY" for conservative template)
    - Type "1" in #tt-quantity
    - Select "MARKET" in #tt-order-type
    - Check #tt-side-buy radio
12. browser_take_screenshot to SCREENSHOT_DIR/05-trade-filled.png
13. Submit via #tt-submit -- verify POST /v1/sessions/{id}/trade/order returns 201. NOTE: If the form causes a page reload instead of AJAX submission, log as BUG.
14. Verify #trade-ticket-panel loses class trade-ticket--open (auto-closes on success)
15. Verify toast notification appears (success type)
16. browser_take_screenshot to SCREENSHOT_DIR/05-trade-submitted.png
17. Verify order appears in orders table body #orders-body (wait for next poll cycle or trigger #btn-refresh)
18. browser_take_screenshot to SCREENSHOT_DIR/05-order-log.png
19. Verify position appears in positions table body #positions-body (if order filled)
20. browser_take_screenshot to SCREENSHOT_DIR/05-positions.png
21. browser_console_messages -- collect errors

Pass criteria: Trade submits, appears in order log, position created. If the journey completes but bugs are found (e.g., missing button, form reload), report PASS_WITH_BUGS.

--- REPORT FORMAT ---

For each journey, report:

JOURNEY: [number] -- [name]
STATUS: PASS | PASS_WITH_BUGS | FAIL
DURATION_S: [seconds]
BUGS: [list of bug descriptions, or "none"]
SCREENSHOTS: [list of screenshot paths taken]
CONSOLE_ERRORS: [list or "none"]
NETWORK_FAILURES: [list or "none"]
FAILURE_DETAIL: [if FAIL -- which step failed and the error message]

Do NOT attempt to fix failures. Report them accurately.
```

---

### Prompt: Browser Batch 3 (Journeys 6-8)

```
You are an E2E test agent running browser Journeys 6, 7, and 8 against the Finlet server at http://localhost:8000.

FIRST: Use ToolSearch to load Playwright MCP tools (query: "playwright browser") so you can call browser_navigate, browser_click, browser_snapshot, browser_take_screenshot, browser_fill_form, browser_type, browser_press_key, browser_wait_for, browser_console_messages, browser_network_requests, browser_navigate_back, browser_resize, browser_evaluate.

Record the start time before each journey and end time after. Report duration_s for each.

TEST_EMAIL: {TEST_EMAIL}
TEST_PASSWORD: {TEST_PASSWORD}
SCREENSHOT_DIR: tests/e2e-ux-results/screenshots

Run journeys sequentially. You MUST be logged in before starting. If not already logged in, navigate to http://localhost:8000/auth.html, fill #login-email with {TEST_EMAIL} and #login-password with {TEST_PASSWORD}, click #login-btn, and wait for redirect to index.html.

--- JOURNEY 6: Settings Page ---

Steps:
1. Navigate to http://localhost:8000/settings.html (login if needed)
2. browser_take_screenshot to SCREENSHOT_DIR/06-settings-initial.png
3. browser_snapshot -- verify ALL of:
   - Shared nav with a.header-nav-link--active[href="settings.html"] highlighted
   - Breadcrumbs nav.breadcrumbs with "Dashboard / Settings"
   - Sidebar nav with .settings-nav-item[data-section] buttons for all sections:
     - [data-section="profile"] (active by default, has settings-nav-item--active)
     - [data-section="security"]
     - [data-section="api-keys"]
     - [data-section="plugins"]
     - [data-section="notifications"]
     - [data-section="appearance"]
     - [data-section="data-privacy"]
   - Active section #section-profile has class settings-section--active
4. Verify Profile section fields populated:
   - #profile-name (display name input)
   - #profile-email (email input)
   - #profile-bio (bio textarea) with char count #bio-char-count
   - #profile-timezone (timezone select)
   - Save button #save-profile-btn
5. browser_take_screenshot to SCREENSHOT_DIR/06-settings-profile.png
6. Edit display name -- type "E2E Test User" in #profile-name
7. Verify unsaved changes banner #unsaved-banner appears (class unsaved-banner--visible)
8. Navigate to API Keys section -- click .settings-nav-item[data-section="api-keys"]
9. Verify #section-api-keys now has class settings-section--active
10. browser_take_screenshot to SCREENSHOT_DIR/06-settings-apikeys.png
11. Navigate to Plugins section -- click .settings-nav-item[data-section="plugins"]
12. Verify #section-plugins now has class settings-section--active
13. browser_take_screenshot to SCREENSHOT_DIR/06-settings-plugins.png
14. Navigate to Security section -- click .settings-nav-item[data-section="security"]
15. Verify MFA UI elements: #totp-status, #totp-enable-btn, #sms-status, #sms-enable-btn
16. browser_take_screenshot to SCREENSHOT_DIR/06-settings-security.png
17. Navigate through remaining sections: notifications ([data-section="notifications"]), appearance ([data-section="appearance"]), data-privacy ([data-section="data-privacy"])
18. browser_console_messages -- collect errors

Pass criteria: All 7 sections render, profile fields populated, section navigation works, unsaved banner triggers on edit.

--- JOURNEY 7: Leaderboard Page ---

Steps:
1. Navigate to http://localhost:8000/leaderboard.html (login if needed)
2. browser_take_screenshot to SCREENSHOT_DIR/07-leaderboard-initial.png
3. browser_snapshot -- verify:
   - Shared nav with a.header-nav-link--active[href="leaderboard.html"] highlighted
   - Breadcrumbs nav.breadcrumbs with "Dashboard / Leaderboard"
   - Content container #leaderboard-content present
   - Either:
     - table.leaderboard-table with thead columns: Rank, Agent, Score, Scenarios, Strategy, Trades, Win Rate
     - OR empty state div.leaderboard-empty with "No agents ranked yet" message and CTA a.empty-state__cta[href="index.html"] ("Create a session")
   - Toast container #toast-container present
4. Verify nav highlights Leaderboard as active (header-nav-link--active class)
5. browser_console_messages -- collect errors
6. browser_network_requests -- verify GET /v1/leaderboard called

Pass criteria: Page loads, table or empty state renders, no JS errors.

--- JOURNEY 8: Billing Page ---

Steps:
1. Navigate to http://localhost:8000/billing.html (login if needed)
2. browser_take_screenshot to SCREENSHOT_DIR/08-billing-initial.png
3. browser_snapshot -- verify ALL of:
   - Shared nav with a.header-nav-link--active[href="billing.html"] highlighted
   - Breadcrumbs nav.breadcrumbs with "Dashboard / Billing"
   - Plan cards: .plan-card[data-tier] for tiers: free, builder, insights, enterprise
   - Each card has a .plan-btn[data-tier] button
   - Billing period toggle buttons: #toggle-monthly, #toggle-annual
   - Monthly toggle has class toggle-btn--active by default
   - Price display elements .price-amount[data-monthly] showing monthly prices
   - Usage grid #usage-grid
   - Usage period display #usage-period
   - Invoice table body #invoice-body
   - Invoice pagination #invoice-pagination
   - Payment section with #payment-empty or #payment-card-display
   - Stripe portal button #btn-manage-stripe
   - Promo code input #promo-code with apply button #btn-apply-promo
   - Toast container #toast-container
4. Verify current plan (Explorer/free) marked:
   - .plan-card[data-tier="free"] has class plan-card--current
   - Its button has class plan-btn--current with text "Current Plan" and is disabled
5. Click #toggle-annual -- verify:
   - #toggle-annual gets class toggle-btn--active, aria-checked="true"
   - #toggle-monthly loses class toggle-btn--active, aria-checked="false"
   - .price-amount elements update to show annual prices (from data-annual attribute)
   - .plan-savings elements become visible (display: block)
6. browser_take_screenshot to SCREENSHOT_DIR/08-billing-annual.png
7. Click #toggle-monthly -- verify prices revert:
   - .price-amount elements show monthly prices (from data-monthly attribute)
   - .plan-savings elements hidden (display: none)
8. browser_take_screenshot to SCREENSHOT_DIR/08-billing-monthly.png
9. browser_console_messages -- collect errors

Pass criteria: Plan cards render, toggle updates prices, current plan marked.

--- REPORT FORMAT ---

For each journey, report:

JOURNEY: [number] -- [name]
STATUS: PASS | PASS_WITH_BUGS | FAIL
DURATION_S: [seconds]
BUGS: [list of bug descriptions, or "none"]
SCREENSHOTS: [list of screenshot paths taken]
CONSOLE_ERRORS: [list or "none"]
NETWORK_FAILURES: [list or "none"]
FAILURE_DETAIL: [if FAIL -- which step failed and the error message]

Do NOT attempt to fix failures. Report them accurately.
```

---

### Prompt: Browser Batch 4 (Journeys 9-12)

```
You are an E2E test agent running browser Journeys 9, 10, 11, and 12 against the Finlet server at http://localhost:8000.

FIRST: Use ToolSearch to load Playwright MCP tools (query: "playwright browser") AND Gmail MCP tools (query: "gmail") so you can call all browser_* tools and gmail_search_messages, gmail_read_message, gmail_get_profile.

Record the start time before each journey and end time after. Report duration_s for each.

TEST_EMAIL: {TEST_EMAIL}
TEST_PASSWORD: {TEST_PASSWORD}
EMAIL_PROVIDER: {EMAIL_PROVIDER}
SCREENSHOT_DIR: tests/e2e-ux-results/screenshots

Run journeys sequentially. You MUST be logged in before starting Journey 9. If not already logged in, navigate to http://localhost:8000/auth.html, fill #login-email with {TEST_EMAIL} and #login-password with {TEST_PASSWORD}, click #login-btn, and wait for redirect to index.html.

--- JOURNEY 9: Mobile Responsive ---

Steps:
1. browser_resize to 375x812 (iPhone viewport)
2. Navigate to http://localhost:8000/index.html (login if needed)
3. browser_take_screenshot to SCREENSHOT_DIR/09-mobile-dashboard.png
4. Verify hamburger menu visible -- #hamburger-btn is visible (check via browser_evaluate: getComputedStyle(document.getElementById('hamburger-btn')).display !== 'none'). NOTE: If #hamburger-btn does not exist, this is a known bug (shared-nav.js destroys it). Log as BUG and attempt workaround if possible.
5. Click #hamburger-btn -- verify:
   - document.body has class nav-open
   - #hamburger-btn has aria-expanded="true"
   - #nav-backdrop has aria-hidden="false"
   - Nav drawer #nav-drawer is visible
   - Drawer user info synced: #nav-drawer-user-email, #nav-drawer-avatar, #nav-drawer-user-tier
   - Close button #nav-drawer-close is visible
   - Drawer action buttons: #nav-drawer-copy-key, #nav-drawer-logout
6. browser_take_screenshot to SCREENSHOT_DIR/09-mobile-nav-open.png
7. Close drawer via #nav-drawer-close button -- verify:
   - document.body loses class nav-open
   - #hamburger-btn has aria-expanded="false"
8. Re-open drawer, navigate to billing by clicking the billing link in the drawer
9. browser_take_screenshot to SCREENSHOT_DIR/09-mobile-billing.png
10. Verify no horizontal overflow: browser_evaluate('document.body.scrollWidth <= window.innerWidth')
11. Navigate to http://localhost:8000/auth.html (clear auth first to test auth page mobile layout)
12. browser_take_screenshot to SCREENSHOT_DIR/09-mobile-auth.png
13. browser_resize to 1440x900 (restore desktop)

Pass criteria: Hamburger works, drawer opens/closes, no overflow, pages stack correctly.

--- JOURNEY 10: Auth Guard ---

Steps:
1. browser_evaluate -- clear all auth state:
   sessionStorage.clear();
   localStorage.clear();
   document.cookie.split(';').forEach(c => {
     document.cookie = c.trim().split('=')[0] + '=;expires=Thu, 01 Jan 1970 00:00:00 GMT;path=/';
   });
2. Navigate to http://localhost:8000/index.html
3. browser_wait_for URL change (should redirect to landing.html per auth-guard.js)
4. Verify current URL contains landing.html
5. browser_take_screenshot to SCREENSHOT_DIR/10-authguard-dashboard.png
6. Navigate to http://localhost:8000/settings.html
7. browser_wait_for URL change (should redirect to auth.html)
8. Verify current URL contains auth.html
9. browser_take_screenshot to SCREENSHOT_DIR/10-authguard-settings.png
10. Navigate to http://localhost:8000/billing.html -- verify redirect to auth.html
11. Navigate to http://localhost:8000/leaderboard.html -- verify redirect to auth.html
12. Navigate to http://localhost:8000/landing.html -- verify NO redirect (public page, stays on landing.html)
13. browser_take_screenshot to SCREENSHOT_DIR/10-authguard-landing-ok.png
14. Navigate to http://localhost:8000/auth.html -- verify NO redirect (public page, stays on auth.html)
15. Re-authenticate for subsequent journeys: login via #login-email ({TEST_EMAIL}), #login-password ({TEST_PASSWORD}), #login-btn

Pass criteria: Protected pages redirect (index.html -> landing.html, others -> auth.html), public pages accessible.

--- JOURNEY 11: Keyboard Shortcuts ---

Steps:
1. Navigate to dashboard, select a session (login if needed)
2. Click somewhere on the page body (not an input) to ensure focus is on the document
3. Verify #clock-mode shows "frozen" (freeze the clock first via #btn-freeze if needed)
4. Press Space (browser_press_key with key Space) -- verify:
   - POST /v1/sessions/{id}/clock/play was called (browser_network_requests)
   - #clock-mode text changes (no longer "frozen")
5. browser_take_screenshot to SCREENSHOT_DIR/11-kb-space-play.png
6. Press Space again -- verify:
   - POST /v1/sessions/{id}/clock/freeze was called
   - #clock-mode text returns to "frozen"
7. browser_take_screenshot to SCREENSHOT_DIR/11-kb-space-freeze.png
8. Press ArrowRight (browser_press_key with key ArrowRight) -- verify:
   - POST /v1/sessions/{id}/clock/step was called
9. browser_take_screenshot to SCREENSHOT_DIR/11-kb-arrow-step.png
10. Press Escape (browser_press_key with key Escape) -- verify:
    - POST /v1/sessions/{id}/clock/stop was called
11. browser_take_screenshot to SCREENSHOT_DIR/11-kb-escape-stop.png
12. Click into #session-select (an input/select element), press Space -- verify shortcut does NOT fire (no clock API call made)
13. browser_console_messages -- collect errors

Pass criteria: Space toggles play/freeze, ArrowRight steps, Escape stops, suppressed in input/select/textarea elements.

--- JOURNEY 12: Forgot Password Flow (Gmail MCP) ---

EMAIL_PROVIDER is "{EMAIL_PROVIDER}".

If EMAIL_PROVIDER is "console":
  - Steps 1-12 below can be executed (UI flow through code entry screen).
  - Steps 13-14 (Gmail MCP email retrieval) will NOT work -- the server logs OTP to stdout instead of sending email. Report this journey as PASS_WITH_BUGS with bug: "Email provider is console -- cannot retrieve OTP via Gmail MCP. Full forgot-password flow requires SMTP provider."
  - Skip steps 15-29.

If EMAIL_PROVIDER is "smtp":
  - Execute ALL steps including Gmail MCP retrieval.

Steps:
1. browser_evaluate -- clear auth state (sessionStorage, localStorage, cookies)
2. Navigate to http://localhost:8000/auth.html
3. Click #show-forgot-password link (below the login form)
4. Verify #form-forgot has class auth-form--active, tab indicators are hidden
5. Verify #forgot-step-email is visible (display: block)
6. browser_take_screenshot to SCREENSHOT_DIR/12-forgot-step1.png
7. Enter {TEST_EMAIL} in #forgot-email
8. Click #forgot-send-btn ("Send Verification Code")
9. browser_wait_for network idle -- verify POST /v1/auth/forgot-password returns 200
10. Verify #forgot-alert shows info message "If an account exists with that email, a verification code has been sent."
11. Verify #forgot-step-email is hidden, #forgot-step-code is visible
12. browser_take_screenshot to SCREENSHOT_DIR/12-forgot-code-sent.png
13. Gmail MCP: Wait 5-10 seconds, then gmail_search_messages with query "in:anywhere from:finlet OR subject:verification OR subject:reset newer_than:2m". If not found, retry up to 3 times with 10 second waits. Also try "in:spam" as a fallback -- verification emails frequently land in spam.
14. Gmail MCP: gmail_read_message to get the email body, extract the 6-digit OTP code (regex: \b\d{6}\b)
15. Enter the OTP code into #forgot-otp-group: fill each .otp-input field (6 individual inputs) with one digit each. The 6th digit triggers auto-submit.
16. browser_take_screenshot to SCREENSHOT_DIR/12-forgot-step2-code.png
17. If auto-submit did not trigger, click #forgot-verify-btn
18. Verify #forgot-step-code is hidden, #forgot-step-newpw is visible
19. Enter new password "NewTestPass!2026" in #forgot-new-password
20. browser_take_screenshot to SCREENSHOT_DIR/12-forgot-step3.png
21. Click #forgot-reset-btn
22. browser_wait_for network idle -- verify POST /v1/auth/reset-password returns 200
23. Verify #forgot-step-newpw is hidden, #forgot-step-success is visible
24. browser_take_screenshot to SCREENSHOT_DIR/12-forgot-step4-success.png
25. Click #forgot-go-login-btn ("Back to Sign In")
26. Verify #form-login has class auth-form--active
27. Login with new password: fill #login-email with {TEST_EMAIL}, #login-password with "NewTestPass!2026", click #login-btn
28. browser_wait_for URL change to index.html
29. browser_take_screenshot to SCREENSHOT_DIR/12-forgot-login-new-pw.png

Pass criteria: All 4 steps complete, Gmail MCP retrieves real OTP, password actually reset and works. If EMAIL_PROVIDER is console, PASS_WITH_BUGS after step 12.

--- REPORT FORMAT ---

For each journey, report:

JOURNEY: [number] -- [name]
STATUS: PASS | PASS_WITH_BUGS | FAIL
DURATION_S: [seconds]
BUGS: [list of bug descriptions, or "none"]
SCREENSHOTS: [list of screenshot paths taken]
CONSOLE_ERRORS: [list or "none"]
NETWORK_FAILURES: [list or "none"]
FAILURE_DETAIL: [if FAIL -- which step failed and the error message]

Do NOT attempt to fix failures. Report them accurately.
```

---

## Important Notes

### Playwright MCP -- Single Instance
The Playwright MCP controls one browser. Browser journeys MUST run sequentially within each batch. Never attempt to run two browser journeys in parallel -- it will cause state corruption.

### Ephemeral Agents
Each batch agent runs its journeys, reports, and dies. No agent persists across batches. This prevents state leakage and keeps context clean.

### Test Plan Is the Source of Truth
All element IDs, selectors, URLs, expected text, and validation criteria live in `docs/plans/e2e_ux_testing_plan.md`. If the test plan and this skill file ever conflict, the test plan wins.

## Anti-Patterns

1. **Running browser journeys in parallel.** Playwright MCP is a single browser instance. Sequential only.
2. **Attempting to fix failures inline.** Agents report and die. Fixing happens between runs.
3. **Rewriting or improvising batch prompts.** The prompts are locked in. Fill template variables and dispatch verbatim.
4. **Not checking server health first.** If the server is down, all 15 journeys fail with connection errors.
5. **Skipping ToolSearch for MCP tools.** Browser agents MUST load Playwright tools before attempting any browser interaction.
6. **Spawning one agent per journey.** Use one agent per batch (5 agents total), not 15.
7. **Skipping the doc-update step.** Step 5 is mandatory. Bugs must flow into REMAINING_TASKS.md.
