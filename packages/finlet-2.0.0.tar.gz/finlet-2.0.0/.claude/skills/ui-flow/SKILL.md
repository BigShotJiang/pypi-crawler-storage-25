---
name: ui-flow
description: Run the full E2E UX flow test suite using Playwright CLI. Repeatable test run — execute journeys, review failures, fix code, re-run until green. Use when the user wants to test the UI, run E2E browser tests, verify UX flows, or check the dashboard.
user_invocable: true
---

# E2E UX Flow Test Suite

Runs all 15 UX journeys (3 CLI + 12 browser) against the live Finlet server using Playwright Test. Designed for fix-and-rerun cycles: run once, fix failures, run `/ui-flow --failed-only` until green.

## Invocation

```
/ui-flow                     # Run all 15 journeys
/ui-flow --batch cli         # Run only CLI journeys (13-15)
/ui-flow --batch 1           # Run only Browser Batch 1 (journeys 1-2)
/ui-flow --batch 2           # Run only Browser Batch 2 (journeys 3-5)
/ui-flow --batch 3           # Run only Browser Batch 3 (journeys 6-8)
/ui-flow --batch 4           # Run only Browser Batch 4 (journeys 9-12)
/ui-flow --journey 7         # Run only journey 7
/ui-flow --failed-only       # Re-run journeys that failed last run
```

## Architecture

- **Playwright Test** (`npx playwright test`) runs all browser and CLI journeys as TypeScript test files
- **Test files** live in `tests/e2e/journey-{NN}-{name}.spec.ts`
- **Shared fixtures** in `tests/e2e/fixtures.ts` provide: `takeScreenshot`, `login`, `collectConsoleErrors`, `collectNetworkFailures`
- **Config** at `tests/e2e/playwright.config.ts` — sequential execution, JSON reporter, chromium only
- **1 agent total** — the main agent runs pre-flight, executes `npx playwright test`, and collects results
- **No MCP tools needed** — everything runs via Bash

## Journey Map

| Journey | File | Type | Batch |
|---------|------|------|-------|
| 1. Landing Page | `journey-01-landing.spec.ts` | Browser | 1 |
| 2. Sign Up Flow | `journey-02-signup.spec.ts` | Browser | 1 |
| 3. Login Flow | `journey-03-login.spec.ts` | Browser | 2 |
| 4. Dashboard + SSE | `journey-04-dashboard.spec.ts` | Browser | 2 |
| 5. Trade Flow | `journey-05-trade.spec.ts` | Browser | 2 |
| 6. Settings Page | `journey-06-settings.spec.ts` | Browser | 3 |
| 7. Leaderboard + Submission | `journey-07-leaderboard.spec.ts` | Browser | 3 |
| 8. Billing Page | `journey-08-billing.spec.ts` | Browser | 3 |
| 9. Mobile Responsive | `journey-09-mobile.spec.ts` | Browser | 4 |
| 10. Auth Guard | `journey-10-authguard.spec.ts` | Browser | 4 |
| 11. Keyboard Shortcuts | `journey-11-keyboard.spec.ts` | Browser | 4 |
| 12. Forgot Password | `journey-12-forgot-password.spec.ts` | Browser | 4 |
| 13. CLI — finlet serve | `journey-13-cli-serve.spec.ts` | CLI/API | CLI |
| 14. CLI — Session Lifecycle | `journey-14-cli-session.spec.ts` | CLI | CLI |
| 15. CLI — Plugins Lifecycle | `journey-15-cli-plugins.spec.ts` | CLI | CLI |

## Pipeline

### Step 0: Pre-flight

Run these commands before launching tests:

1. **Kill existing server** on port 8000:
   ```bash
   lsof -ti:8000 | xargs kill 2>/dev/null
   ```

2. **Check session count** — if over 500, warn user and archive:
   ```bash
   COUNT=$(ls ~/.finlet/sessions/ 2>/dev/null | wc -l)
   if [ "$COUNT" -gt 500 ]; then
     echo "WARNING: $COUNT sessions found. Archiving."
     mv ~/.finlet/sessions/ ~/.finlet/sessions_backup_$(date +%s)/
     mkdir -p ~/.finlet/sessions/
   fi
   ```

3. **Start server**:
   ```bash
   cd /Users/justnau/finlet && FINLET_SSM_ENABLED=0 FINLET_CORS_ORIGINS='*' uv run uvicorn finlet.api.app:create_app --factory --host 0.0.0.0 --port 8000 &
   ```

4. **Wait for health** — poll up to 30 seconds:
   ```bash
   for i in $(seq 1 30); do curl -sf http://localhost:8000/v1/health && break; sleep 1; done
   ```

5. **Create output directories**:
   ```bash
   mkdir -p tests/e2e-ux-results/screenshots
   ```

6. **Set test credentials** as environment variables:
   ```bash
   export TEST_EMAIL="e2e-$(date +%s)@finlet.dev"
   export TEST_PASSWORD="TestPass!2026secure"
   ```

### Step 1: Parse Arguments & Build Playwright Command

Map `/ui-flow` arguments to Playwright CLI flags:

| Argument | Playwright Command |
|----------|-------------------|
| (none) | `npx playwright test --config tests/e2e/playwright.config.ts` |
| `--batch cli` | `npx playwright test --config tests/e2e/playwright.config.ts --grep "Journey 1[345]"` |
| `--batch 1` | `npx playwright test --config tests/e2e/playwright.config.ts --grep "Journey [12]:"` |
| `--batch 2` | `npx playwright test --config tests/e2e/playwright.config.ts --grep "Journey [345]:"` |
| `--batch 3` | `npx playwright test --config tests/e2e/playwright.config.ts --grep "Journey [678]:"` |
| `--batch 4` | `npx playwright test --config tests/e2e/playwright.config.ts --grep "Journey (9|10|11|12):"` |
| `--journey N` | `npx playwright test --config tests/e2e/playwright.config.ts --grep "Journey N:"` |
| `--failed-only` | `npx playwright test --config tests/e2e/playwright.config.ts --last-failed` |

### Step 2: Execute Tests

Run the constructed Playwright command via Bash. Use a 10-minute timeout for full runs:

```bash
cd /Users/justnau/finlet && TEST_EMAIL="$TEST_EMAIL" TEST_PASSWORD="$TEST_PASSWORD" \
  npx playwright test --config tests/e2e/playwright.config.ts [FLAGS]
```

Playwright handles:
- Sequential test execution (workers: 1)
- Screenshots on every test (saved to `tests/e2e-ux-results/screenshots/`)
- JSON results (saved to `tests/e2e-ux-results/playwright-results.json`)
- Console output with pass/fail per test

### Step 3: Collect Results & Write State

After Playwright finishes, read `tests/e2e-ux-results/playwright-results.json` and transform into `summary.json`:

```bash
# Read the Playwright JSON output and generate summary.json
```

Write `tests/e2e-ux-results/summary.json` with this schema:
```json
{
  "timestamp": "ISO8601",
  "total": 15,
  "passed": 10,
  "passed_with_bugs": 3,
  "failed": 2,
  "duration_s": 120,
  "journeys": [
    {"id": 1, "name": "Landing Page", "status": "PASS", "duration_s": 4.2},
    {"id": 5, "name": "Trade Flow", "status": "PASS_WITH_BUGS", "duration_s": 12.1, "bugs": ["..."]},
    {"id": 13, "name": "CLI — finlet serve", "status": "FAIL", "duration_s": 8.0, "failure": "..."}
  ]
}
```

Write `tests/e2e-ux-results/REPORT.md` with human-readable results.

**State update rules:**

| Scenario | summary.json | REPORT.md | screenshots/ |
|----------|-------------|-----------|-------------|
| Full run | Overwrite all | Overwrite | Wipe + regenerate |
| Partial re-run | Merge updated entries | Overwrite with this run only | Regenerate only re-run journeys |

### Step 4: Update Docs (mandatory)

Spawn a dedicated doc-update agent that:
1. Reads `tests/e2e-ux-results/REPORT.md`
2. Reads `docs/REMAINING_TASKS.md`
3. Adds new bugs as tasks
4. Cross-references — if a prior bug now passes, mark resolved
5. Does NOT remove items not tested in this run

### Step 5: Report

Output a summary table to the user:

| # | Journey | Status | Duration | Details |
|---|---------|--------|----------|---------|
| 1 | Landing Page | PASS | 4.2s | — |
| 5 | Trade Flow | PASS_WITH_BUGS | 12.1s | Form reload bug |

End with counts and suggested next command.

---

## Test File Conventions

- All test files import from `./fixtures` (NOT `@playwright/test` directly)
- Test describe blocks use format: `Journey N: Name` (for `--grep` filtering)
- Screenshots saved to `tests/e2e-ux-results/screenshots/{NN}-{name}.png`
- CLI journeys use `execSync` with `uv run finlet ...` commands
- Browser journeys use Playwright's `page` fixture
- Tests are self-contained — each can run independently

## Important Notes

### Test Files Are the Source of Truth
All element IDs, selectors, URLs, expected text, and validation criteria now live in the Playwright test files at `tests/e2e/journey-*.spec.ts`. The old test plan at `docs/plans/e2e_ux_testing_plan.md` is a reference but the test code is authoritative.

### SSE Replaces Polling
The dashboard uses Server-Sent Events (SSE) via `GET /v1/sessions/{id}/stream` for all real-time data. Journey 4 verifies SSE is active; fallback to polling is a bug.

### Playwright — Single Browser Instance
Tests run sequentially (workers: 1) to avoid state corruption. This is intentional — journeys build on each other (signup → login → dashboard → trade).

### Speed
Full suite runs in 2-5 minutes (vs 30-60 minutes with MCP approach). Individual journeys complete in seconds.

## Anti-Patterns

1. **Running with workers > 1.** Sequential execution prevents auth state conflicts.
2. **Fixing failures inline.** Run the suite, read the report, fix code, re-run.
3. **Editing this skill instead of the test files.** The `.spec.ts` files are the tests. This skill is just the orchestrator.
4. **Skipping pre-flight.** If the server is down, all tests fail.
5. **Skipping the doc-update step.** Step 4 is mandatory.

## Known Gaps (Not Covered)

1. **MCP Tools** (pause_session, resume_session, cancel_order, get_equity_curve) — MCP-only, test via `pytest tests/mcp/`.
2. **SSE Reconnection & Fallback** — SSE activity is verified but deliberate kill/reconnect is not tested.
3. **Email Verification Flow** (POST /email/verify-token) — Separate from forgot-password OTP flow.
4. **MFA Setup/Disable** — Journey 6 checks MFA elements exist but doesn't test full TOTP flow.
5. **Forgot Password OTP Retrieval** — Journey 12 verifies UI flow to code entry; full OTP retrieval requires SMTP provider.
