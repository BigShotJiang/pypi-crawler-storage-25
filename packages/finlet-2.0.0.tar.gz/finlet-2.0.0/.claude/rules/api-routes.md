---
paths:
  - "finlet/api/**"
---

# API Route Rules

## FastAPI Patterns
- Each route file: `router = APIRouter(tags=[...])` — registered in app.py
- Request/response models as Pydantic `BaseModel` in the same route file
- Use `HTTPException` for errors with specific detail messages
- Thin route handlers — delegate business logic to core/domain modules

## Authentication
- All endpoints require `X-API-Key` via Bearer scheme (`require_api_key` dependency)
- `UserRecord`: id, email, tier, MFA status — injected via `Depends`
- Session ownership enforced via `get_user_session(session_id, user)` in deps.py
- Returns 404 for both missing AND unauthorized sessions (no info leakage)
- Registration rate-limited: 5/hour/IP

## Middleware Stack (ordered)
- `CorrelationIDMiddleware`: X-Request-ID binding to structlog context
- `SecurityHeadersMiddleware`: X-Frame-Options, CSP, HSTS, etc.
- `RequestSizeLimitMiddleware`: 413 for bodies > 1MB
- `CORSMiddleware`: configurable origins
- Marketplace: `GeoBlockMiddleware`, `DisclaimerInjectionMiddleware`

## State Management
- `state.py`: `get_sessions()`, `get_registry()`, `get_sessions_lock()`
- Sessions dict and plugin registry are module-level singletons
- App lifespan: init_engines -> load_all_keys -> load_all_sessions -> run_migrations

## Error Codes
- 404: missing/unauthorized sessions or orders
- 422: validation errors
- 429: rate limits (pass through plugin details with reset timing)
- 503: plugin unavailability

## Service-layer parity (Phase 2 of MCP-First Migration)
- Cross-cutting gates (per-tier session creation, per-user trade rate, per-user
  market-data rate, per-user Finnhub plugin rate) live in
  `finlet/api/services/*.py`. REST routes pass `user` into the service and
  consume the canonical envelope; they do NOT call `check_*_rate` /
  `record_*` functions directly.
- The frozenset constants `_NON_TEMPORAL_PLUGIN_TYPES`,
  `_NON_TEMPORAL_ACTIONS`, and `PLUGIN_RATE_LIMITED_TYPES` are owned by
  `finlet.api.services.market_service` only. Re-defining them in
  `routes_*.py` or `mcp/` is forbidden — both surfaces import or rely on the
  service-layer source of truth.
- REST-specific concerns that stay in the route layer: `JSONResponse`
  wrapping, `X-RateLimit-*` headers (built from `get_plugin_rate_info`),
  cookie-session translation.

## General
- Use `structlog.get_logger()` for logging
- Async route handlers — no sync I/O

## REST surface shrink (Phase 3 of MCP-First Migration)
- MCP is the canonical agent surface; the unversioned REST root-mount aliases
  (e.g. `/sessions`, `/sessions/{id}/trade/order`, `/market/price`) are
  deprecated. Decision record: `docs/decisions/mcp-canonical-surface.md`.
- Sunset date: `2026-08-06` (90 days from 2026-05-08). Deprecated agent-CRUD
  routes emit `Deprecation: true`, `Sunset: 2026-08-06`, and
  `Link: <https://docs.finlet.dev/mcp/tools/{tool_name}>; rel="successor-version"`
  (RFC 5988-compliant). Routes with no per-tool mapping fall back to
  `Link: <https://docs.finlet.dev/mcp>; rel="successor-version"`.
- Keep-list — exact paths (no Sunset header):
  ```
  /
  /health
  /plugins/health
  /metrics
  /privacy
  /terms
  /csp-report
  /telemetry/client-error
  /billing/webhook
  /openapi.json
  /email/verify-token
  /leaderboard
  /leaderboard/benchmarks
  /.well-known/oauth-authorization-server  (added 2026-05-17 — RFC 8414 §3 root-mount alias for OAuth AS metadata; mirrors /oauth/.well-known/oauth-authorization-server payload via finlet/auth/oauth/router.py's well_known_router)
  ```
- Keep-list — prefixes (no Sunset header):
  ```
  /auth/         (EXCEPT /auth/research-network/ — see Pattern Exceptions)
  /admin/
  /docs
  /redoc
  /openapi
  /oauth/        (added 2026-05-08 — Phase 4b OAuth AS endpoints; see docs/decisions/mcp-oauth-2-1-auth-model.md)
  ```
- Keep-list — patterns (no Sunset header):
  - **SSE:** path matches `^/sessions/[^/]+/stream$` (i.e., `startswith("/sessions/") AND endswith("/stream")`).
  - **Plugin job acceptance:** path matches `^/plugins/[^/]+/ingest$` (i.e., `startswith("/plugins/") AND endswith("/ingest")`).
  - **Public session view:** path matches `^/public/sessions/[^/]+(/.*)?$` (added 2026-05-12 — the 5 anonymous read routes on the `/v1/public/sessions/{id}/*` surface, mirrored in `finlet/api/deprecation.py`; see `docs/decisions/session-public-visibility.md`).
  - **Public benchmark run view:** path matches `^/public/benchmark-runs/[^/]+(/.*)?$` (added 2026-05-20 — the 2 anonymous read routes on the `/v1/public/benchmark-runs/{id}/*` surface, mirrored in `finlet/api/deprecation.py`).
- Pattern exceptions — these ARE deprecated despite prefix match:
  - `/auth/research-network/opt-in` (POST) — Link → generic MCP URL.
  - `/auth/research-network/opt-out` (POST) — Link → generic MCP URL.
- Deprecated agent-CRUD groups (not exhaustive — see `finlet/api/deprecation.py`
  for the canonical mapping table): `/sessions`, `/sessions/{id}/trade/*`,
  `/sessions/{id}/clock/*`, `/sessions/{id}/portfolio*`,
  `/sessions/{id}/market/*`, `/market/*`, `/settings/*`, `/email/preferences`,
  `/billing/{subscription,invoices,usage}`, `/leaderboard/submit*`,
  `/auth/research-network/*`.
- The REST→MCP tool mapping (per-tool Link target) is canonical in
  `finlet/api/deprecation.py`. This rules file documents the keep-list +
  policy; consult the code module for the exact (method, path) → tool name
  table. Do NOT duplicate the mapping table here — single source of truth in
  the code module.
- Drift policy: any change to the keep-list, prefixes, patterns, exceptions,
  or REST→MCP tool mapping MUST update both `finlet/api/deprecation.py` AND
  this file in the same PR. PR review checks both surfaces line-by-line.

## SSE event blinding
- Any new SSE event in `finlet/api/routes_sse.py:_generate_events` MUST (a) pass `blind_mapping=_blind_mapping_for(session)` to its serializer, (b) have the serializer accept the kwarg and apply blinding when non-None (via `apply_ticker` / `apply_date` / `apply_universe` / `apply_scenario` / `apply_session_name` from `finlet/core/blind_mapping.py`), and (c) be included in the `assert_no_real_blinded_data(payload, mapping)` chokepoint loop before `_sse_event` formatting. Env-gated via `FINLET_BLIND_ASSERT` (`raise` in CI, `log` in prod).
- Extend the SSE subtest in `tests/e2e/test_blind_benchmark_zero_leak.py` to cover new event types.
- See `docs/decisions/blind-sse-event-blinding.md`, `docs/decisions/blind-mapping-scenario-and-universe.md`.

## Public PII redaction
- Any new public/anonymous read surface emitting `request_params` or `response_summary` payloads MUST route through `trace_data(... public_surface=True, owner_id=session.user_id or "")`. The redactor (`_public_redact_payload` in `finlet/api/serializers.py`) drops denylist keys + leading-underscore keys, and scrubs string values containing `owner_id` as a substring of length ≥ 8. Composition order: blind walker FIRST, then PII redactor. Service-layer write-path companion: do NOT mutate caller's `params` dict to inject identifiers — that flows verbatim into persisted trace.
- Grep gate: `tests/api/test_public_session_pii_hygiene.py` (asserts `_user_id` key absence AND owner-id ≥8-char substring absence on every public read endpoint). If SSE becomes anonymous-public-readable, set `public_surface=True` on its trace serializer too.
- See `docs/decisions/public-trace-redaction-chokepoint.md`.
