---
paths:
  - "deploy/**"
  - ".github/**"
---

# Deploy & Ops Rules

## Infrastructure
- Systemd services: `finlet.service` (API), `finlet-mcp.service` (MCP)
- Caddy reverse proxy (Caddyfile)
- fail2ban integration for brute-force protection
- logrotate config for log management
- SQLite backup script (`backup-sqlite.sh`)

## Deployment Scripts
- `deploy.sh`: production deployment
- `rollback.sh`: rollback to previous version
- `RUNBOOK.md`: operational procedures
- `aws/user-data.sh`: cloud-init bootstrap (one-time server setup)

## CI/CD Pipeline (.github/workflows/)
- Pipeline order: ruff lint -> mypy type check -> pip-audit -> pytest -> deploy
- All checks must pass before deploy

## AWS
- AWS deployment configs in `deploy/aws/`

## Conventions
- Shell scripts must be POSIX-compatible where possible
- Always test rollback procedures when changing deploy scripts
- Security: no secrets in config files — use environment variables
