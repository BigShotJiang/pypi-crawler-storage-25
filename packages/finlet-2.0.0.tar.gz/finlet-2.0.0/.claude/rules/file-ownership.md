---
paths:
  - "**"
---

## File Ownership (Agent Teams)
- `finlet/core/` + `tests/core/` → engine
- `finlet/plugins/` + `tests/plugins/` → plugins
- `finlet/api/`, `finlet/mcp/`, `finlet/cli.py` + `tests/api/`, `tests/mcp/`, `tests/test_cli.py` → api
- `finlet/auth/` + `tests/auth/` → api (auth is L2, owned by api team)
- `finlet/billing/` + `tests/billing/` → api (billing is L2, owned by api team)
- `finlet/gdpr/` + `tests/gdpr/` → api (GDPR L2, owned by api team)
- `finlet/leaderboard/` + `tests/leaderboard/` → leaderboard
- `finlet/marketplace/` + `tests/marketplace/` → marketplace
- `dashboard/` → dashboard
- `finlet/db/`, `finlet/utils/`, `pyproject.toml`, `README.md` → infra
- `deploy/`, `.github/` → ops
- `docs/` → docs
- `strategies/` → strategies
