---
paths:
  - "finlet/mcp/**"
---

# MCP Server Rules

## FastMCP Patterns
- Single `server.py` using `FastMCP` from `mcp.server.fastmcp`
- Server name: "finlet" with descriptive instructions string
- Tools registered as decorated async functions

## Tool Registration
- Each tool has a clear description helping LLMs understand when to use it
- Include example parameter values in descriptions
- Tools: get_price_data, search_news, get_fundamentals, get_filings, get_economic_data
- Trading: submit_order, get_portfolio
- Clock: get_sim_time, advance_time, freeze_time

## Shared Logic
- Reuse state from `finlet.api.state` (get_sessions, get_registry)
- Reuse `DateCeilingEnforcer` from core — every data response is enforced
- Interval map: 1m, 5m, 15m, 30m, 1h, 4h, 1d, 1w -> seconds
- `_get_session()` helper validates session exists

## Error Handling
- Return specific, actionable error messages (same standard as API/plugins)
- Plugin errors surfaced with rate limit details when applicable

## Error envelope hygiene
- MCP responses MUST never leak developer-machine filesystem paths or pydantic library shapes — every `@blind_error_mapper`-wrapped tool result (success body, blinded-error body, raw return) runs through `finlet.mcp.error_envelope.sanitize_paths` at the chokepoint. Pydantic `ValidationError` raised before the decorator is caught by the FastMCP boundary patch in `finlet/mcp/_fastmcp_patches.py` (applied once via `apply_validation_boundary_patch()`).
- Grep gate: `tests/mcp/test_error_envelope_hygiene.py` (substrings: `/Users/`, `/home/`, `~/`, `/root`, `.finlet`, `errors.pydantic.dev`, `validation error for `, `Error executing tool `).
- See `docs/decisions/mcp-error-envelope-hygiene.md`.

## Scope enforcement
- Every MCP tool that mutates session/portfolio/clock state MUST call `enforce_scope(claims, "finlet:trade", user_record)`. Reads use `finlet:read`; benchmark mutations use `finlet:benchmark`. The api_key path (`claims is None`) bypasses scope per `docs/decisions/mcp-api-key-sunset.md` §3.
- Audit grep: `tests/mcp/test_scope_enforcement.py::TestScopeAuditGrep`.
- See `docs/decisions/auth-scope-write-tools-must-require-finlet-trade.md`.

## Clock snapshot consistency (MCP plumbing)
- Every `advance_time` branch in `finlet/mcp/server.py` MUST capture `committed_time = session.clock.get_time()` INSIDE the `_tick_lock` slice and thread it through `_post_step_persist_and_fill(..., committed_time=...)`. The `_assert_clock_snapshot_consistency(result_dict)` helper runs at every return path (target-date, batched-steps, single-step). Env-gated `FINLET_CLOCK_CONSISTENCY_ASSERT` (`raise` in CI, `log` in prod).
- See `docs/decisions/advance-time-snapshot-isolation.md`.

## Service-layer parity (Phase 2 of MCP-First Migration)
- `tools_trading.submit_order` resolves a `UserRecord` and delegates to
  `finlet.api.services.trade_service.submit_order(...)` — the service owns the
  per-user trade rate gate (`check_trade_rate`), idempotency cache,
  `record_trade_request`, and the rich-shape response build (commission /
  slippage_amount / total_cost). MCP returns the service's dict directly — do
  NOT re-wrap with `to_dict(result)`; doing so reverts to the bare shape and
  re-opens audit H6.
- `_query_plugin` resolves a `UserRecord` (when `user_id != _MCP_SENTINEL`,
  the unauth-fallback marker defined at `finlet/mcp/server.py:81`) and
  delegates to `finlet.api.services.market_service.route_query(..., user=user_record)`.
  The service owns the per-user market-data rate gate
  (`check_market_data_rate`), the per-user Finnhub plugin gate
  (`check_plugin_rate(user, "finnhub")`), the post-success records
  (`record_market_data_request` + `record_plugin_request`), and the canonical
  envelope. MCP envelope MUST include `rate_limit_remaining` and
  `rate_limit_reset` propagated from the service envelope (closes audit H4).
  The only adaptation is renaming `ceiling_applied` → `ceiling`.
- `HTTPException` from the service-level rate gate is converted to the
  MCP-shallow envelope (`{"error": "<message>"}`) via
  `ServiceError(...).to_mcp_shallow()` so existing tests that pattern-match on
  `isinstance(result["error"], str)` keep working.
- The frozenset constants `_NON_TEMPORAL_PLUGIN_TYPES`,
  `_NON_TEMPORAL_ACTIONS`, and `PLUGIN_RATE_LIMITED_TYPES` live ONLY in
  `finlet.api.services.market_service`. Re-defining them in `mcp/server.py`
  (or any `mcp/` submodule) is forbidden — both surfaces share one source of
  truth.
- `_resolve_user_record(user_id) -> UserRecord | None` lives in `mcp/auth.py`
  (NOT `mcp/server.py`) so tool submodules can import it cycle-safely.

## General
- Async functions only
- Use structlog for logging
- CLI entry point: `finlet mcp serve` starts server over stdio (Phase 5, 2026-05-09 — the previous bare `finlet mcp` is now a Typer sub-app; the agentic-trading CLI commands spawn this same subcommand for tool dispatch)
