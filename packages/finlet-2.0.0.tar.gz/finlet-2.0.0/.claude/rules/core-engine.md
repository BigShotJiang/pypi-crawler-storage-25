---
paths:
  - "finlet/core/**"
---

# Core Engine Rules

## Simulation Clock (clock.py)
- Three modes: FROZEN, STEPPING, CONTINUOUS — clock ONLY moves forward on explicit advance
- `freeze()`, `step(interval)`, `step_to(datetime)`, `play(speed)`, `get_time()`
- Market hours awareness: skip weekends/after-hours when configured
- All times stored in UTC — convert only for display

## Date Ceiling Enforcer (enforcer.py)
- Every plugin response passes through `DateCeilingEnforcer` — no exceptions
- Items with timestamps > ceiling are stripped; items without timestamps excluded by default
- Log stripped count internally but NEVER expose to the agent (leaks future data existence)
- `PluginResponse` model lives here, not in plugins

## Order System (orders.py)
- Types: MARKET, LIMIT, STOP with BUY/SELL sides
- Status flow: PENDING -> FILLED | CANCELLED | REJECTED
- `OrderBook` uses `asyncio.Lock()` to serialize submissions and fills
- v1: no slippage, no partial fills, no short selling, no commission
- Semantic order rejection (insufficient cash/shares, plugin error, validate-order failure) MUST raise `finlet.errors.OrderRejected` AFTER persisting the REJECTED record. `code` must be one of `OrderRejected.VALID_CODES`. `OrderRejected` subclasses `ValueError` for back-compat, but `except ValueError` / `except Exception` in the submit-order path MUST add `except OrderRejected: raise` above it. `Session.reject_unfillable_orders` stays non-throwing per the clock-service save-loop invariant.
- See `docs/decisions/order-rejected-envelope-contract.md`.

## Blind mapping (blind_mapping.py)
- Any new ticker or wall-clock-date field on a response surface that flows out of a blind session (`session.config.blind=True`) MUST route through `apply_ticker` / `apply_date` — body items AND envelope fields. The `BlindMapping` object MUST NEVER be embedded in a response dict; callers use forward transforms only. Runtime backstop: `BlindMapping.__getstate__` raises on pickle/deepcopy + `assert_not_in_response_dict(d)` helper.
- `session.config.benchmark_ticker` is a tracked ticker field — `generate_mapping` seeds it into the per-session `ticker_map`. Defense in depth: `_KNOWN_BENCHMARK_TICKERS` frozenset trips the chokepoint on any known benchmark ETF; append new benchmark tickers here.
- Grep gate: `tests/e2e/test_blind_benchmark_zero_leak.py` (load-bearing; field-level unit tests with mocked `items[]` can pass while envelope leaks).
- See `docs/decisions/blind-benchmark-envelope-fields-must-blind.md`, `docs/decisions/blind-mapping-serializer-poison.md`, `docs/decisions/blind-benchmark-ticker-must-blind.md`.

## Clock snapshot consistency (core plumbing)
- Any response returning BOTH a clock time AND a portfolio/fill/order-timestamp/price-ceiling field MUST pin `committed_time` inside `_tick_lock`. Live reads of `session.clock.get_time()` for response fields after lock release are forbidden — they race parallel `advance_time` / `step` calls and produce torn responses.
- `Session.process_pending_orders(prices, *, sim_time=...)` accepts the committed time, which drives the price-plugin ceiling, fallback start date, snapshot timestamp, DAY-order expiry, `order.filled_at` stamps, and benchmark-progress log. `Session.reject_unfillable_orders` is out of scope.
- See `docs/decisions/advance-time-snapshot-isolation.md`.

## Portfolio (portfolio.py)
- Tracks cash, positions (with avg_entry_price), realized/unrealized P&L
- Computed metrics: total_value, sharpe_ratio, max_drawdown, win_rate
- Equity curve: time series of `EquitySnapshot` for charting
- All mutations protected by `asyncio.Lock()` for concurrency safety
- Uses Pydantic `computed_field` for derived values

## Session (session.py)
- Lifecycle: CREATED -> ACTIVE -> PAUSED -> ACTIVE -> COMPLETED
- Each session owns: clock, portfolio, order book, trace log, user_id
- `SessionConfig`: start_time, end_time, initial_capital, universe, time_step

## General
- Async functions only — no sync I/O
- Use `structlog.get_logger()` for logging
- Pydantic models for all data structures
- One file per module
