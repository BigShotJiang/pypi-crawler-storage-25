---
paths:
  - "dashboard/**"
---

# Dashboard Rules

## Technology
- Vanilla HTML + JavaScript + CSS — no build step, no framework
- Served as static files by FastAPI
- TradingView Lightweight Charts (free, MIT) via CDN for price/equity curves

## Pages
- `index.html`: Main dashboard — session selector, overview, charts, tables
- `auth.html` + `auth.js` + `auth.css`: Authentication flow
- `leaderboard.html` + `leaderboard.js`: Leaderboard display
- `settings.html` + `settings.js` + `settings.css`: User settings
- `billing.html` + `billing.js` + `billing.css`: Billing/subscription

## Design
- Dark theme by default, CSS variables for theming
- Desktop-primary layout
- Polls session state every 2 seconds

## Dashboard Views
- Session selector: dropdown/sidebar listing sessions
- Overview panel: sim time, portfolio value, cash, P&L, clock controls
- Equity curve: portfolio value over sim time with buy-and-hold benchmark
- Positions table: open positions with color-coded P&L
- Order log: scrollable table with expandable reasoning
- Reasoning trace: timeline/feed of agent actions
- Plugin health: status cards per plugin

## API Integration
- All data fetched from FastAPI REST endpoints
- Bearer token auth via stored API key
- Error states shown to user with actionable messages

## Event bus
- All cross-component dashboard wiring goes through `window.finletBus.subscribe(event, handler) → unsubscribe` and `window.finletBus.publish(event, payload)`. Direct `addEventListener('finlet:...')` / `dispatchEvent(new CustomEvent('finlet:...'))` are forbidden — wire through the bus and update `dashboard/event-contract.md` in the same commit when adding an event name.
- Pre-commit gates: `scripts/lint-trusted-types.sh` (bare `.innerHTML =` outside `trustedHTML(...)`), `scripts/lint-event-bus.sh` (direct addEventListener/dispatchEvent under `dashboard/` outside `event-bus.js`). Install via `scripts/setup-git-hooks.sh`.
- See `docs/decisions/dashboard-event-bus.md`.
