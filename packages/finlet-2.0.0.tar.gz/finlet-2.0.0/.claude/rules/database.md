---
paths:
  - "finlet/db/**"
---

# Database Rules

## SQLModel + aiosqlite
- Models extend `SQLModel` with `table=True`
- Async engines via `create_async_engine` with `aiosqlite` driver
- WAL mode enabled on all connections via SQLAlchemy event listeners
- Engines created once at startup (`init_engines()`), cached, disposed on shutdown

## Database Layout
- Per-session: `~/.finlet/sessions/{session_id}/session.db`
- Global auth: `~/.finlet/auth.db` (users, API keys)
- Global leaderboard: in `~/.finlet/finlet.db`
- Marketplace: `~/.finlet/marketplace.db`

## Models (models.py)
- `SessionModel`, `OrderModel`, `PositionModel`, `PortfolioSnapshotModel`, `TraceEntryModel`
- `ApiKeyModel` for auth persistence
- `_utcnow()` helper for consistent UTC timestamps
- `_new_id()` via `uuid.uuid4()` for primary keys

## Persistence (persistence.py)
- Save after each mutation — no batching or background flushing
- `save_session()`, `load_all_sessions()`, `delete_session_db()`
- Uses `structlog.get_logger()` for logging

## Migrations (migrations/)
- Alembic-based, programmatic runner (no subprocess calls)
- `render_as_batch=True` always for SQLite compatibility
- Existing DBs without alembic_version are stamped at baseline
- `run_migrations()` called at app startup
- `migrate_session_db()` for lazy per-session migration

## General
- Async only — no sync database operations
- `asyncio.Lock` guards engine creation to prevent races
