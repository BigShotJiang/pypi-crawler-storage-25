---
paths:
  - "finlet/marketplace/**"
---

# Marketplace Rules

## Compliance-First Architecture
- All marketplace code must reference LEGAL_REQUISITES.md for requirements
- FTC, SEC, and state-level regulations govern marketplace behavior
- When in doubt, block/restrict rather than allow

## Geo-blocking (geo_middleware.py, geo_config.py, geo_ip.py)
- OFAC-sanctioned countries blocked — returns HTTP 451
- UK blocked (FCA risk)
- X-Forwarded-For trust: configure via FINLET_TRUSTED_PROXY_COUNT
- Exempt paths: health, docs, legal endpoints bypass geo-blocking

## Financial Disclaimers (disclaimer_middleware.py, disclaimers.py)
- Auto-injected into all /marketplace/* responses via middleware
- Platform-controlled — developers cannot remove or modify
- Context-aware: different disclaimers for listings, purchases, search, leaderboard

## Reviews (review_compliance.py)
- FTC Consumer Review Rule compliance (effective Oct 2024)
- Verified purchase required, no sentiment filtering, no self-reviews
- Sort by recency, not rating — admin can only hide for ToS violations

## Tax (tax.py, tax_forms.py)
- Stripe Tax API for sales tax calculation
- Tax shown before payment (FTC pre-purchase transparency)
- All Stripe calls async via httpx

## Models & Persistence
- SQLModel tables in `~/.finlet/marketplace.db`
- DeveloperProfile, OnboardingSteps, StrategyListing, etc.
- Stripe Connect for developer payouts

## Prohibited Claims (prohibited_claims.py)
- Automated scanning for SEC-violating claims in strategy descriptions
- Block guaranteed return claims, misleading performance statements

## General
- Use `structlog.get_logger()` for logging
- Async functions only
- Use Pydantic models for request/response validation
