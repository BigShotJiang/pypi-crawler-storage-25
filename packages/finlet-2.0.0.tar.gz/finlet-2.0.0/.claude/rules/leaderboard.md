---
paths:
  - "finlet/leaderboard/**"
---

# Leaderboard Rules

## Scoring (scoring.py)
- Composite score: 0.30*sharpe + 0.25*return + 0.25*(1-drawdown) + 0.20*consistency
- Consistency = 1 - (std_dev / mean) of per-scenario returns
- All values min-max normalized to [0,1] relative to all entries

## Benchmark Scenarios (benchmarks.py)
- Frozen dataclass `BenchmarkScenario`: id, name, time period, universe, capital
- 5 standard scenarios with default universe (AAPL, MSFT, etc.)
- Scenarios are immutable — never modify existing benchmarks

## Runner (runner.py)
- Executes all scenarios for a leaderboard submission
- Self-play mode: deterministic pseudo-prices (seeded random walk)
- Reproducible without real market data APIs
- Uses core Session, OrderBook, Portfolio directly

## Profiles (profiles.py)
- `AgentProfile` with `ScenarioScore` per benchmark
- Persisted to SQLite via leaderboard_persistence.py

## API Strategy (api_strategy.py)
- Drives agent strategies against the benchmark runner

## Rate Limits
- Benchmark submissions limited to 10/day/user to prevent abuse

## General
- Async functions where applicable
- Uses stdlib `logging` in runner (not structlog — legacy)
