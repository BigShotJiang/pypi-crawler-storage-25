---
paths:
  - "tests/**"
---

# Testing Rules

## Framework
- pytest + pytest-asyncio
- Root conftest at `tests/conftest.py` — shared fixtures (opt-in, no autouse)
- Local conftest fixtures override root fixtures per pytest scoping rules

## Fixtures (from root conftest)
- `test_app`: TestClient with mocked lifespan (patches slow startup ops)
- `api_key` / `auth_headers`: creates API key + Bearer header for a test user
- `isolated_sessions`: clean session dict per test
- `mock_registry`: PluginRegistry with no real plugins
- `_run_async()`: helper to run async coroutines from sync test code

## Mocking
- Mock ALL external APIs — no real network calls in tests
- Mock plugin responses, not the enforcer (enforcer is part of the contract)
- Use `unittest.mock.patch` or `pytest-mock` for patching

## Edge Cases to Test
- Market hours boundaries (weekends, after-hours transitions)
- Order fills at price gaps
- Date ceiling enforcer stripping future data
- Portfolio metrics with no trades (division by zero guards)
- Session ownership checks (user A cannot access user B's session)
- Rate limit boundaries

## Conventions
- Test files mirror source structure: `tests/core/`, `tests/plugins/`, etc.
- One test file per source module
- Descriptive test names: `test_enforcer_strips_future_items`
- Use `pytest.raises` for expected exceptions

## CI Pipeline
- ruff lint -> mypy type check -> pip-audit -> pytest -> deploy
