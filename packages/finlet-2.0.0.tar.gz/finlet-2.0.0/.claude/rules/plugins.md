---
paths:
  - "finlet/plugins/**"
---

# Plugin Rules

## DataPlugin Interface (base.py)
- All plugins extend `DataPlugin` ABC with: `initialize()`, `query()`, `health_check()`
- `plugin_type`: price | news | fundamentals | filings | economic
- `PluginRegistry` manages loading and routing queries by type
- `CircuitBreaker` per plugin prevents cascading failures (threshold=5, reset=60s)

## PluginResponse Format
- Return `PluginResponse` from `finlet.core.enforcer` — NOT a custom format
- Include: items, source, query_params, ceiling_applied, items_pre_filter, items_post_filter
- Include rate_limit_remaining and rate_limit_reset when applicable

## Date Ceiling Enforcer
- Every query receives `ceiling_time` — filter data to this boundary
- This is defense-in-depth: plugins filter AND the core enforcer re-filters

## Error Messages — MUST be specific and actionable
- Good: "Finnhub rate limit exceeded: 0/60 calls remaining, resets in 42 seconds"
- Bad: "API error"
- Good: "PricePlugin: No data available for ticker 'INVALID'. Check ticker symbol against supported universe"
- Bad: "Data not found"

## Built-in Plugins
- **price_plugin** (S3 Parquet via pyarrow + boto3): OHLCV from Databento DBEQ.BASIC + Quandl WIKI data lake
- **edgar_plugin** (edgartools): SEC filings. Filter by `filedAt <= ceiling`
- **fred_plugin** (fredapi): Economic data. Use ALFRED vintage dates for point-in-time accuracy
- **finnhub_plugin** (finnhub-python): News + fundamentals. 60 calls/min free tier
- **econ_plugin**: Economic indicators aggregation

## General
- Use `structlog.get_logger()` — not stdlib logging
- Use `httpx` for async HTTP calls
- Async functions only — no sync I/O

## S3 write chokepoint
- All S3 writes funnel through `S3ParquetWriter`. New ingest scripts must use `upload_date_partition` / `upload_partitioned` / `upload_to_key` with `emit_manifest=True`. Direct `s3_client.put_object` for writes is banned in `scripts/ingest_*.py` — the manifest sidecar is the partition-completeness invariant.
- See `docs/decisions/partition-completeness-invariant.md`.
