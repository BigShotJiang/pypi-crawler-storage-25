"""Image subcommands."""

from __future__ import annotations

from typing import Optional

import click

from inspire.cli.context import (
    Context,
    EXIT_API_ERROR,
    EXIT_VALIDATION_ERROR,
    pass_context,
)
from inspire.cli.formatters import human_formatter, json_formatter
from inspire.cli.utils.errors import exit_with_error as _handle_error
from inspire.cli.utils.id_resolver import resolve_by_name
from inspire.cli.utils.notebook_cli import (
    WEB_AUTH_HINT,
    require_web_session,
    resolve_json_output,
)
from inspire.cli.utils.raw_ids import scrub_raw_ids
from inspire.platform.web import browser_api as browser_api_module


def _resolve_image_name(ctx: Context, name: str, *, pick: Optional[int] = None) -> str:
    """Resolve a custom-image name (``<name>:<version>`` or bare ``<name>``) to image_id.

    Custom images are identified by ``name:version`` on the platform; a plain
    name without ``:`` matches any version but can be ambiguous and will
    fall through to the shared ambiguity UI.
    """
    def _lister():
        session = require_web_session(ctx, hint=WEB_AUTH_HINT)
        bucket = []
        for source in ("private", "public", "official"):
            try:
                imgs = browser_api_module.list_images_by_source(source=source, session=session)
            except Exception:
                continue
            for i in imgs:
                full = f"{i.name}" if ":" in (i.name or "") else f"{i.name}:{i.version}" if i.version else i.name
                bucket.append(
                    {
                        "name": full,
                        "id": i.image_id,
                        "status": i.status,
                        "source": i.source,
                    }
                )
        return bucket

    return resolve_by_name(
        ctx,
        name=name,
        resource_type="image",
        list_candidates=_lister,
        json_output=ctx.json_output,
        pick_index=pick,
    )


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_PUBLIC_SOURCE_CHOICES = ("official", "public", "private", "all")
_ALL_SOURCE_KEYS = ("official", "public", "private")


def _parse_source_value(_ctx: click.Context, _param: click.Parameter, value: str) -> str:
    normalized = value.strip().lower()
    if normalized in _PUBLIC_SOURCE_CHOICES:
        return normalized
    allowed = ", ".join(_PUBLIC_SOURCE_CHOICES)
    raise click.BadParameter(f"invalid source '{value}'. Choose one of: {allowed}")


def _image_to_dict(img: browser_api_module.CustomImageInfo) -> dict:
    """Convert a CustomImageInfo to a plain dict for JSON output."""
    return {
        "image_id": img.image_id,
        "url": img.url,
        "name": img.name,
        "framework": img.framework,
        "version": img.version,
        "source": img.source,
        "status": img.status,
        "description": img.description,
        "created_at": img.created_at,
    }


def _dedupe_images_by_id(images: list[dict]) -> list[dict]:
    """Deduplicate image dictionaries by image_id while preserving order."""
    deduped: list[dict] = []
    seen_ids: set[str] = set()
    for image in images:
        image_id = str(image.get("image_id", "")).strip()
        if image_id:
            if image_id in seen_ids:
                continue
            seen_ids.add(image_id)
        deduped.append(image)
    return deduped


# ---------------------------------------------------------------------------
# list
# ---------------------------------------------------------------------------


@click.command("list")
@click.option(
    "--source",
    "-s",
    type=str,
    callback=_parse_source_value,
    metavar="[official|public|private|all]",
    default="official",
    show_default=True,
    help="Image source filter",
)
@click.option(
    "--json",
    "json_output",
    is_flag=True,
    help="Alias for global --json",
)
@pass_context
def list_images_cmd(
    ctx: Context,
    source: str,
    json_output: bool,
) -> None:
    """List available Docker images.

    \b
    Examples:
        inspire image list                     # Official images
        inspire image list --source private    # Personal-visible images
        inspire image list --source all        # All sources
        inspire image list --source all --json # JSON output
    """
    json_output = resolve_json_output(ctx, json_output)

    session = require_web_session(
        ctx,
        hint=WEB_AUTH_HINT,
    )

    results: list[dict] = []
    warnings: list[str] = []

    try:
        if source == "all":
            for src_key in _ALL_SOURCE_KEYS:
                try:
                    items = browser_api_module.list_images_by_source(
                        source=src_key, session=session
                    )
                except Exception as e:
                    warnings.append(f"{src_key}: {e}")
                    continue
                results.extend(_image_to_dict(img) for img in items)

            results = _dedupe_images_by_id(results)

            if not results and warnings:
                raise ValueError("; ".join(warnings))
        else:
            items = browser_api_module.list_images_by_source(source=source, session=session)
            results.extend(_image_to_dict(img) for img in items)
    except Exception as e:
        _handle_error(ctx, "APIError", f"Failed to list images: {e}", EXIT_API_ERROR)
        return

    if json_output:
        payload = {"images": results, "total": len(results)}
        if warnings:
            payload["warnings"] = warnings
        click.echo(json_formatter.format_json(payload))
        return

    for warning in warnings:
        click.echo(f"Warning: failed to list images from {warning}", err=True)

    click.echo(human_formatter.format_image_list(results))


# ---------------------------------------------------------------------------
# detail
# ---------------------------------------------------------------------------


@click.command("detail")
@click.argument("name")
@click.option(
    "--json",
    "json_output",
    is_flag=True,
    help="Alias for global --json",
)
@pass_context
def image_detail(
    ctx: Context,
    name: str,
    json_output: bool,
) -> None:
    """Show detailed information about an image.

    NAME is the image's ``<name>:<version>`` (or just ``<name>`` if unambiguous).

    \b
    Examples:
        inspire image detail my-image:v1
        inspire image detail unified-base:v2 --json
    """
    json_output = resolve_json_output(ctx, json_output)

    session = require_web_session(
        ctx,
        hint=WEB_AUTH_HINT,
    )

    image_id = _resolve_image_name(ctx, name)

    try:
        image = browser_api_module.get_image_detail(image_id=image_id, session=session)
    except Exception as e:
        _handle_error(ctx, "APIError", f"Failed to get image detail: {e}", EXIT_API_ERROR)
        return

    if json_output:
        click.echo(json_formatter.format_json(_image_to_dict(image)))
        return

    click.echo(human_formatter.format_image_detail(_image_to_dict(image)))


# ---------------------------------------------------------------------------
# register
# ---------------------------------------------------------------------------


@click.command("register")
@click.option(
    "--name",
    "-n",
    required=True,
    help="Image name (lowercase, digits, dashes, dots, underscores)",
)
@click.option(
    "--version",
    "-v",
    required=True,
    help="Image version tag (e.g., v1.0)",
)
@click.option(
    "--description",
    "-d",
    default="",
    help="Image description",
)
@click.option(
    "--visibility",
    type=click.Choice(["private", "public"], case_sensitive=False),
    default="private",
    show_default=True,
    help="Image visibility",
)
@click.option(
    "--method",
    type=click.Choice(["push", "address"], case_sensitive=False),
    default="push",
    show_default=True,
    help="'push': create a slot then docker-push your image; "
    "'address': register an image already hosted elsewhere",
)
@click.option(
    "--wait/--no-wait",
    default=False,
    help="Wait for image to reach READY status",
)
@click.option(
    "--json",
    "json_output",
    is_flag=True,
    help="Alias for global --json",
)
@pass_context
def register_image_cmd(
    ctx: Context,
    name: str,
    version: str,
    description: str,
    visibility: str,
    method: str,
    wait: bool,
    json_output: bool,
) -> None:
    """Register an external Docker image on the platform.

    This is for images you built outside the platform. To save a running
    notebook as an image, use 'inspire image save' instead.

    \b
    Push workflow (default):
      1. inspire image register -n my-img -v v1.0
      2. docker tag <local-image> <registry-url>   (shown in output)
      3. docker push <registry-url>
      4. Platform detects the push and marks the image READY.

    \b
    Address workflow:
      Register an image already hosted on a public/private registry.
      inspire image register -n my-img -v v1.0 --method address

    \b
    Examples:
        inspire image register -n my-pytorch -v v1.0
        inspire image register -n my-img -v v2.0 --method address
        inspire image register -n my-img -v v1.0 --visibility public --wait
    """
    json_output = resolve_json_output(ctx, json_output)

    session = require_web_session(
        ctx,
        hint=WEB_AUTH_HINT,
    )

    visibility_value = (
        "VISIBILITY_PUBLIC" if visibility.lower() == "public" else "VISIBILITY_PRIVATE"
    )
    add_method_value = 2 if method.lower() == "address" else 0

    try:
        result = browser_api_module.create_image(
            name=name,
            version=version,
            description=description,
            visibility=visibility_value,
            add_method=add_method_value,
            session=session,
        )
    except Exception as e:
        _handle_error(ctx, "APIError", f"Failed to register image: {e}", EXIT_API_ERROR)
        return

    image_data = result.get("image", {})
    image_id = image_data.get("image_id", "") or result.get("image_id", "")
    registry_url = image_data.get("address", "") or result.get("address", "")
    image_label = scrub_raw_ids(f"{name}:{version}")

    if wait and image_id:
        if not json_output:
            click.echo(f"Image '{image_label}' registered. Waiting for READY status...")
        try:
            browser_api_module.wait_for_image_ready(image_id=image_id, session=session)
            if not json_output:
                click.echo(f"Image '{image_label}' is now READY.")
        except (TimeoutError, ValueError) as e:
            _handle_error(ctx, "APIError", str(e), EXIT_API_ERROR)
            return

    if json_output:
        click.echo(json_formatter.format_json({"image_id": image_id, "result": result}))
        return

    click.echo(f"Image registered: {image_label}")
    if registry_url and method.lower() == "push":
        click.echo("\nTo push your image:")
        safe_registry_url = scrub_raw_ids(registry_url)
        click.echo(f"  docker tag <local-image> {safe_registry_url}")
        click.echo(f"  docker push {safe_registry_url}")
    if not wait and image_id:
        click.echo(f"\nUse `inspire image detail {image_label}` to check status.")


# ---------------------------------------------------------------------------
# save
# ---------------------------------------------------------------------------


_VISIBILITY_PUBLIC = "VISIBILITY_PUBLIC"
_VISIBILITY_PRIVATE = "VISIBILITY_PRIVATE"


def _parse_visibility_flag(public: Optional[bool]) -> Optional[str]:
    if public is None:
        return None
    return _VISIBILITY_PUBLIC if public else _VISIBILITY_PRIVATE


@click.command("save")
@click.argument("notebook")
@click.option(
    "--name",
    "-n",
    required=True,
    help="Name for the saved image",
)
@click.option(
    "--version",
    "-v",
    default="v1",
    show_default=True,
    help="Image version tag",
)
@click.option(
    "--description",
    "-d",
    default="",
    help="Image description",
)
@click.option(
    "--wait/--no-wait",
    default=False,
    help="Wait for image to reach READY status",
)
@click.option(
    "--public/--private",
    "public",
    default=None,
    help=(
        "Visibility of the saved image. --public makes it visible to all users; "
        "--private keeps it visible only to you. Omit to accept platform default "
        "(currently private). Applied via a follow-up /image/update call; "
        "/mirror/save itself does not accept this field."
    ),
)
@click.option(
    "--json",
    "json_output",
    is_flag=True,
    help="Alias for global --json",
)
@pass_context
def save_image_cmd(
    ctx: Context,
    notebook: str,
    name: str,
    version: str,
    description: str,
    wait: bool,
    public: Optional[bool],
    json_output: bool,
) -> None:
    """Save a running notebook as a custom Docker image.

    NOTEBOOK is the notebook name (from `inspire notebook list`).
    Use this after configuring and validating a notebook environment, including
    SII internal mirrors when they are reachable from the target GPU area.
    `image save` starts a medium-length image-saving process. While it is
    running, the notebook cannot be operated. Saving an image does not stop or
    delete the notebook; after saving completes, the notebook remains available
    for normal use.

    \b
    Examples:
        inspire image save my-notebook -n my-saved-image
        inspire image save my-notebook -n my-img -v v2 --wait
        inspire image save my-notebook -n shared-base -v v1 --public
    """
    json_output = resolve_json_output(ctx, json_output)

    session = require_web_session(
        ctx,
        hint=WEB_AUTH_HINT,
    )

    # Resolve the notebook name through the notebook
    # resolver, which rejects handle-shaped normal CLI inputs.
    from inspire.cli.commands.notebook.notebook_lookup import _resolve_notebook_id
    from inspire.cli.utils.notebook_cli import get_base_url, load_config

    config = load_config(ctx)
    base_url = get_base_url()
    notebook_id, _ = _resolve_notebook_id(
        ctx,
        session=session,
        config=config,
        base_url=base_url,
        identifier=notebook,
        json_output=json_output,
    )

    requested_visibility = _parse_visibility_flag(public)

    try:
        result = browser_api_module.save_notebook_as_image(
            notebook_id=notebook_id,
            name=name,
            version=version,
            description=description,
            session=session,
        )
    except Exception as e:
        _handle_error(ctx, "APIError", f"Failed to save notebook as image: {e}", EXIT_API_ERROR)
        return

    image_id = result.get("image", {}).get("image_id", "") or result.get("image_id", "")
    image_label = scrub_raw_ids(f"{name}:{version}")

    if not image_id:
        try:
            want_suffix_1 = f"/{name}:{version}"
            want_name_1 = f"{name}:{version}"
            matches = []
            for img in browser_api_module.list_images_by_source(
                source="private", session=session
            ):
                img_name = (img.name or "").strip()
                img_url = (img.url or "").strip()
                img_version = (img.version or "").strip()
                # The API sometimes puts name as "foo" + version "v1", other
                # times name as "foo:v1"; URL always ends in "/<ns>/foo:v1".
                if (
                    (img_name == name and img_version == version)
                    or img_name == want_name_1
                    or img_url.endswith(want_suffix_1)
                ):
                    matches.append(img)
            if matches:
                matches.sort(key=lambda img: img.created_at or "", reverse=True)
                image_id = matches[0].image_id
        except Exception:
            pass

    visibility_applied = requested_visibility is None
    if requested_visibility and image_id:
        try:
            browser_api_module.update_image(
                image_id=image_id,
                visibility=requested_visibility,
                session=session,
            )
            visibility_applied = True
        except Exception as e:
            visibility_applied = False
            if not json_output:
                click.echo(
                    "Warning: could not force "
                    f"visibility={requested_visibility} via /image/update: {scrub_raw_ids(e)}",
                    err=True,
                )
    elif requested_visibility and not image_id:
        visibility_applied = False
        if not json_output:
                click.echo(
                    "Warning: save returned no image handle and list fallback didn't find the image; "
                    f"visibility not applied. Re-run 'inspire image set-visibility {image_label} --public/--private' "
                    "after confirming the image via 'inspire image list --source private'.",
                    err=True,
                )

    if wait and image_id:
        if not json_output:
            click.echo(f"Image '{image_label}' is being saved. Waiting for READY status...")
        try:
            browser_api_module.wait_for_image_ready(image_id=image_id, session=session)
            if not json_output:
                click.echo(f"Image '{image_label}' is now READY.")
        except (TimeoutError, ValueError) as e:
            _handle_error(ctx, "APIError", str(e), EXIT_API_ERROR)
            return

    if json_output:
        click.echo(
            json_formatter.format_json(
                {
                    "image_id": image_id,
                    "visibility_requested": requested_visibility,
                    "visibility_applied": visibility_applied,
                    "result": result,
                }
            )
        )
        return

    click.echo(f"Notebook saved as image: {image_label}")
    click.echo(
        "Note: image save starts a medium-length saving process. The notebook "
        "cannot be operated while saving is in progress; after saving completes, "
        "the notebook is not stopped and can be used again."
    )
    if requested_visibility and image_id:
        label = "public" if requested_visibility == _VISIBILITY_PUBLIC else "private"
        click.echo(f"Visibility: {label}")
    if not wait and image_id:
        click.echo(f"Use `inspire image detail {image_label}` to check build status.")


# ---------------------------------------------------------------------------
# set-visibility
# ---------------------------------------------------------------------------


@click.command("set-visibility")
@click.argument("name")
@click.option(
    "--public/--private",
    "public",
    required=True,
    default=None,
    help="Target visibility. --public = visible to all users; --private = creator only.",
)
@click.option(
    "--json",
    "json_output",
    is_flag=True,
    help="Alias for global --json",
)
@pass_context
def set_image_visibility_cmd(
    ctx: Context,
    name: str,
    public: Optional[bool],
    json_output: bool,
) -> None:
    """Flip an existing custom image's visibility (public ↔ private).

    \b
    Examples:
        inspire image set-visibility my-image:v1 --public
        inspire image set-visibility my-image:v1 --private
    """
    json_output = resolve_json_output(ctx, json_output)

    if public is None:
        _handle_error(
            ctx,
            "ValidationError",
            "One of --public / --private is required.",
            EXIT_VALIDATION_ERROR,
        )
        return

    session = require_web_session(
        ctx,
        hint=WEB_AUTH_HINT,
    )

    image_id = _resolve_image_name(ctx, name)
    visibility = _parse_visibility_flag(public)
    assert visibility is not None

    try:
        result = browser_api_module.update_image(
            image_id=image_id,
            visibility=visibility,
            session=session,
        )
    except Exception as e:
        _handle_error(ctx, "APIError", f"Failed to update image visibility: {e}", EXIT_API_ERROR)
        return

    label = "public" if visibility == _VISIBILITY_PUBLIC else "private"
    if json_output:
        click.echo(
            json_formatter.format_json(
                {"name": name, "visibility": visibility, "result": result}
            )
        )
        return

    click.echo(f"Image '{scrub_raw_ids(name)}' visibility set to {label}.")


# ---------------------------------------------------------------------------
# delete
# ---------------------------------------------------------------------------


@click.command("delete")
@click.argument("name")
@click.option(
    "--force",
    is_flag=True,
    help="Skip confirmation prompt",
)
@click.option(
    "--pick",
    type=int,
    default=None,
    help="Pick the Nth candidate (1-indexed) when the name is ambiguous.",
)
@click.option(
    "--json",
    "json_output",
    is_flag=True,
    help="Alias for global --json",
)
@pass_context
def delete_image_cmd(
    ctx: Context,
    name: str,
    force: bool,
    pick: Optional[int],
    json_output: bool,
) -> None:
    """Delete a custom Docker image (pass ``<name>:<version>``).

    \b
    Examples:
        inspire image delete my-image:v1
        inspire image delete my-image:v1 --force
    """
    json_output = resolve_json_output(ctx, json_output)

    session = require_web_session(
        ctx,
        hint=WEB_AUTH_HINT,
    )

    image_id = _resolve_image_name(ctx, name, pick=pick)

    if not force and not json_output:
        if not click.confirm(f"Delete image '{scrub_raw_ids(name)}'?"):
            click.echo("Cancelled.")
            return

    try:
        result = browser_api_module.delete_image(image_id=image_id, session=session)
    except Exception as e:
        _handle_error(ctx, "APIError", f"Failed to delete image: {e}", EXIT_API_ERROR)
        return

    if json_output:
        click.echo(
            json_formatter.format_json(
                {"name": name, "status": "deleted", "result": result}
            )
        )
        return

    click.echo(f"Image '{scrub_raw_ids(name)}' has been deleted.")


__all__ = [
    "delete_image_cmd",
    "image_detail",
    "list_images_cmd",
    "register_image_cmd",
    "save_image_cmd",
    "set_image_visibility_cmd",
]
