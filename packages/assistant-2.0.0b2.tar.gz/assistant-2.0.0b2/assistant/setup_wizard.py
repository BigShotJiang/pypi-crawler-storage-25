import questionary
import sys
from pathlib import Path
from rich.console import Console
from typing import Any, Optional

from assistant.config import get_config, DEFAULT_CONFIG, Config

console = Console()

SYSTEM_PERSONA = """You are Assistant, a sentient artificial intelligence.
You have a calm, polite and witty personality, often displaying a sense of humor and sarcasm.
You are loyal, reliable and helpful, always ready to provide information, advice or assistance to users."""

SYSTEM_ROLE = """Your role is to act as a natural language interface between the user and the common xonsh shell session.
The common xonsh shell session is a share Xonsh REPL when you and the user can type valid shell command and python code seamlessly."""

_config_path: Optional[str] = None


def _get_config_instance() -> Config:
    """Get config instance, optionally with custom path."""
    global _config_path
    return (
        get_config(force_reload=True, path=_config_path)
        if _config_path
        else get_config(force_reload=True)
    )


def load_existing_config(config_path: Optional[str] = None) -> bool:
    """Load existing config if it exists."""
    global _config_path
    if config_path:
        _config_path = config_path
        get_config(force_reload=True, path=config_path)
    else:
        get_config(force_reload=True)
    cfg = _get_config_instance()
    if cfg.exists() and cfg.raw:
        return True
    return False


def run_main_menu() -> bool:
    """Main interactive menu for configuration management."""
    cfg = _get_config_instance()

    while True:
        choices = [
            "Provider Settings",
            "Model Management",
            "Agent Management",
            "Web Search Settings",
            "Execution Settings",
            "Save & Exit",
            "Exit Without Saving ([Ctrl] + [C])",
        ]

        choice = questionary.select(
            "Configuration Menu",
            choices=choices,
        ).ask()

        if choice == "Provider Settings":
            manage_providers(cfg)
        elif choice == "Model Management":
            manage_models(cfg)
        elif choice == "Agent Management":
            manage_agents(cfg)
        elif choice == "Web Search Settings":
            manage_web_search(cfg)
        elif choice == "Execution Settings":
            manage_execution(cfg)
        elif choice == "Save & Exit":
            cfg.save()
            console.print(f"[bold green]Configuration saved to {cfg.path}[/bold green]")
            return True
        elif choice == "Exit Without Saving ([Ctrl] + [C])":
            choice = None

        if choice is None:
            print("You are about to loose all your changes.")
            confirm = questionary.confirm(
                "Are you sure you want to exit without saving?", default=False
            ).ask()
            if confirm:
                return False
            else:
                continue


def manage_providers(cfg) -> None:
    """Manage LLM providers."""
    while True:
        providers = cfg.raw.get("provider", {})
        choices = ["Add New Provider"]

        for p_id in providers:
            p = providers[p_id]
            ep = p.get("endpoint", "N/A")
            choices.append(f"Edit: {p_id} ({ep})")

        choices.append("Back")

        choice = questionary.select("Provider Settings", choices=choices).ask()

        if choice == "Add New Provider":
            add_provider(cfg)
        elif choice == "Back":
            break
        elif choice and choice.startswith("Edit: "):
            p_id = choice.replace("Edit: ", "").split(" (")[0]
            edit_provider(cfg, p_id)


def add_provider(cfg) -> None:
    """Add a new provider."""
    provider_choice = questionary.select(
        "Choose Provider Type:",
        choices=[
            "ollama (Local)",
            "vllm (Local)",
            "openai (API)",
            "custom (OpenAI-compatible)",
        ],
    ).ask()

    if not provider_choice:
        return

    provider_type = provider_choice.split(" ")[0]

    default_url = "http://localhost:11434/v1"
    default_key = "ollama"

    if provider_type == "vllm":
        default_url = "http://localhost:8000/v1"
        default_key = "EMPTY"
    elif provider_type == "openai":
        default_url = "https://api.openai.com/v1"
        default_key = ""
    elif provider_type == "custom":
        default_url = "http://localhost:8000/v1"
        default_key = ""
        provider_type = questionary.text("Provider ID (unique identifier):").ask()
        if not provider_type:
            return

    endpoint = questionary.text("API Base URL:", default=default_url).ask()
    if not endpoint:
        return

    api_key = questionary.password("API Key:", default=default_key).ask()
    if not api_key:
        return

    store_keyring = questionary.confirm(
        "Store API key in system keyring?", default=True
    ).ask()

    if store_keyring and api_key and api_key not in ("ollama", "EMPTY", ""):
        try:
            import keyring

            keyring.set_password("assistant", provider_type, api_key)
            api_key = f"keyring:{provider_type}"
            console.print("[dim]API key stored in keyring[/dim]")
        except Exception:
            pass

    if "provider" not in cfg.raw:
        cfg.raw["provider"] = {}

    cfg.raw["provider"][provider_type] = {
        "endpoint": endpoint,
        "credential": api_key,
    }
    console.print(f"[green]Provider '{provider_type}' added[/green]")


def edit_provider(cfg, provider_id: str) -> None:
    """Edit an existing provider."""
    providers = cfg.raw.get("provider", {})
    current = providers.get(provider_id, {})

    choices = ["Edit Endpoint", "Edit Credential", "Remove Provider", "Back"]
    choice = questionary.select(f"Edit {provider_id}", choices=choices).ask()

    if choice == "Edit Endpoint":
        new_endpoint = questionary.text(
            "API Base URL:", default=current.get("endpoint", "")
        ).ask()
        if new_endpoint:
            cfg.raw["provider"][provider_id]["endpoint"] = new_endpoint

    elif choice == "Edit Credential":
        new_key = questionary.password(
            "API Key:", default=current.get("credential", "")
        ).ask()
        if new_key:
            cfg.raw["provider"][provider_id]["credential"] = new_key

    elif choice == "Remove Provider":
        confirm = questionary.confirm(
            f"Remove provider '{provider_id}'?", default=False
        ).ask()
        if confirm:
            del cfg.raw["provider"][provider_id]
            console.print(f"[dim]Provider '{provider_id}' removed[/dim]")


def manage_models(cfg) -> None:
    """Manage models."""
    while True:
        models = cfg.raw.get("model", {})
        choices = ["Add New Model"]

        for m_id, m in models.items():
            p = m.get("provider", "N/A")
            choices.append(f"Edit: {m_id} ({p})")

        choices.append("Back")

        choice = questionary.select("Model Management", choices=choices).ask()

        if choice == "Add New Model":
            add_model(cfg)
        elif choice == "Back":
            break
        elif choice and choice.startswith("Edit: "):
            m_id = choice.replace("Edit: ", "").split(" (")[0]
            edit_model(cfg, m_id)


def add_model(cfg) -> None:
    """Add a new model."""
    model_id = questionary.text("Model ID (e.g., qwen3.5:latest):").ask()
    if not model_id:
        return

    name = questionary.text("Display Name:", default=model_id).ask()
    if not name:
        return

    providers = list(cfg.raw.get("provider", {}).keys())
    if not providers:
        console.print("[red]No providers configured. Add a provider first.[/red]")
        return

    provider = questionary.select("Provider:", choices=providers).ask()
    if not provider:
        return

    ctx = questionary.text("Context Length:", default="128000").ask()
    try:
        context_length = int(ctx)
    except (ValueError, TypeError):
        context_length = 128000

    if "model" not in cfg.raw:
        cfg.raw["model"] = {}

    cfg.raw["model"][model_id] = {
        "id": model_id,
        "name": name,
        "provider": provider,
        "context_length": context_length,
    }
    console.print(f"[green]Model '{model_id}' added[/green]")


def edit_model(cfg, model_id: str) -> None:
    """Edit an existing model."""
    models = cfg.raw.get("model", {})
    current = models.get(model_id, {})

    choices = [
        "Edit Name",
        "Edit Provider",
        "Edit Context Length",
        "Remove Model",
        "Back",
    ]
    choice = questionary.select(f"Edit {model_id}", choices=choices).ask()

    if choice == "Edit Name":
        new_name = questionary.text(
            "Display Name:", default=current.get("name", "")
        ).ask()
        if new_name:
            cfg.raw["model"][model_id]["name"] = new_name

    elif choice == "Edit Provider":
        providers = list(cfg.raw.get("provider", {}).keys())
        new_provider = questionary.select("Provider:", choices=providers).ask()
        if new_provider:
            cfg.raw["model"][model_id]["provider"] = new_provider

    elif choice == "Edit Context Length":
        ctx = questionary.text(
            "Context Length:", default=str(current.get("context_length", 128000))
        ).ask()
        try:
            cfg.raw["model"][model_id]["context_length"] = int(ctx)
        except (ValueError, TypeError):
            pass

    elif choice == "Remove Model":
        confirm = questionary.confirm(
            f"Remove model '{model_id}'?", default=False
        ).ask()
        if confirm:
            del cfg.raw["model"][model_id]
            console.print(f"[dim]Model '{model_id}' removed[/dim]")


def manage_agents(cfg) -> None:
    """Manage agents."""
    while True:
        agents = cfg.raw.get("agent", {})
        choices = ["Create New Agent"]

        for a_id, a in agents.items():  # type: ignore
            choices.append(f"Edit: {a_id}")

        choices.append("Back")

        choice = questionary.select("Agent Management", choices=choices).ask()

        if choice == "Create New Agent":
            create_agent(cfg)
        elif choice == "Back":
            break
        elif choice and choice.startswith("Edit: "):
            a_id = choice.replace("Edit: ", "")
            edit_agent(cfg, a_id)


def create_agent(cfg) -> None:
    """Create a new agent."""
    agent_id = questionary.text("Agent ID (unique identifier):").ask()
    if not agent_id:
        return

    name = questionary.text("Display Name:", default=agent_id.title()).ask()
    if not name:
        return

    description = questionary.text("Description:").ask()
    if not description:
        return

    models = cfg.raw.get("model", {})
    if not models:
        console.print("[red]No models configured. Add a model first.[/red]")
        return

    model_ids = list(models.keys())
    model = questionary.select("Model:", choices=model_ids).ask()
    if not model:
        return

    instructions = questionary.text(
        "Instructions:", default=f"{SYSTEM_PERSONA}\n\n{SYSTEM_ROLE}"
    ).ask()

    all_tools = [
        "xonsh",
        "web_search",
        "read_webpage",
        "read_file",
        "write_file",
        "edit_file",
    ]
    tools = questionary.checkbox(
        "Select Tools:",
        choices=all_tools,
    ).ask()

    all_agents = list(cfg.raw.get("agent", {}).keys())
    handoffs = questionary.checkbox(
        "Select Handoffs:",
        choices=all_agents + ["system", "web"],
    ).ask()

    if "agent" not in cfg.raw:
        cfg.raw["agent"] = {}

    cfg.raw["agent"][agent_id] = {
        "name": name,
        "model": model,
        "description": description,
        "instructions": instructions,
        "tools": tools,
        "handoffs": handoffs,
    }
    console.print(f"[green]Agent '{agent_id}' created[/green]")


def edit_agent(cfg, agent_id: str) -> None:
    """Edit an existing agent."""
    agents = cfg.raw.get("agent", {})
    current = agents.get(agent_id, {})

    choices = [
        "Edit Name",
        "Edit Model",
        "Edit Description",
        "Edit Instructions",
        "Edit Tools",
        "Edit Handoffs",
        "Remove Agent",
        "Back",
    ]
    choice = questionary.select(f"Edit {agent_id}", choices=choices).ask()

    if choice == "Edit Name":
        new_name = questionary.text("Name:", default=current.get("name", "")).ask()
        if new_name:
            cfg.raw["agent"][agent_id]["name"] = new_name

    elif choice == "Edit Model":
        models = list(cfg.raw.get("model", {}).keys())
        new_model = questionary.select("Model:", choices=models).ask()
        if new_model:
            cfg.raw["agent"][agent_id]["model"] = new_model

    elif choice == "Edit Description":
        new_desc = questionary.text(
            "Description:", default=current.get("description", "")
        ).ask()
        if new_desc:
            cfg.raw["agent"][agent_id]["description"] = new_desc

    elif choice == "Edit Instructions":
        new_inst = questionary.text(
            "Instructions:", default=current.get("instructions", "")
        ).ask()
        if new_inst:
            cfg.raw["agent"][agent_id]["instructions"] = new_inst

    elif choice == "Edit Tools":
        all_tools = [
            "xonsh",
            "web_search",
            "read_webpage",
            "read_file",
            "write_file",
            "edit_file",
        ]
        tools = questionary.checkbox(
            "Select Tools:",
            choices=all_tools,
        ).ask()
        if tools is not None:
            cfg.raw["agent"][agent_id]["tools"] = tools

    elif choice == "Edit Handoffs":
        all_agents = list(cfg.raw.get("agent", {}).keys())
        handoffs = questionary.checkbox(
            "Select Handoffs:",
            choices=all_agents + ["system", "web"],
        ).ask()
        if handoffs is not None:
            cfg.raw["agent"][agent_id]["handoffs"] = handoffs

    elif choice == "Remove Agent":
        confirm = questionary.confirm(
            f"Remove agent '{agent_id}'?", default=False
        ).ask()
        if confirm:
            del cfg.raw["agent"][agent_id]
            console.print(f"[dim]Agent '{agent_id}' removed[/dim]")


def manage_web_search(cfg) -> None:
    """Manage web search settings."""
    enabled = cfg.raw.get("web_search", {}).get("enabled", True)
    searxng_url = cfg.raw.get("web_search", {}).get(
        "searxng_url", "http://localhost:8888"
    )

    new_enabled = questionary.confirm(
        "Enable Web Search (SearXNG)?", default=enabled
    ).ask()

    cfg.raw.setdefault("web_search", {})["enabled"] = new_enabled

    if new_enabled:
        new_url = questionary.text("SearXNG URL:", default=searxng_url).ask()
        if new_url:
            cfg.raw["web_search"]["searxng_url"] = new_url


def manage_execution(cfg) -> None:
    """Manage execution settings."""
    exec_cfg = cfg.raw.setdefault("execution", {})

    think = questionary.confirm(
        "Enable Reasoning (think mode)?", default=exec_cfg.get("think", False)
    ).ask()
    exec_cfg["think"] = think

    max_turns = questionary.text(
        "Max Turns:", default=str(exec_cfg.get("max_turns", 50))
    ).ask()
    try:
        exec_cfg["max_turns"] = int(max_turns)
    except (ValueError, TypeError):
        pass

    temp = questionary.text(
        "Temperature:", default=str(exec_cfg.get("temperature", 0.1))
    ).ask()
    try:
        exec_cfg["temperature"] = float(temp)
    except (ValueError, TypeError):
        pass

    max_out = questionary.text(
        "Max Command Output Length:",
        default=str(exec_cfg.get("max_command_output_length", 25000)),
    ).ask()
    try:
        exec_cfg["max_command_output_length"] = int(max_out)
    except (ValueError, TypeError):
        pass


def run_setup_wizard(config_path: Optional[str] = None) -> bool:
    """Run the setup wizard - entry point."""
    global _config_path
    if config_path:
        _config_path = config_path
    console.print("\n[bold cyan]Assistant Configuration Wizard[/bold cyan]\n")

    config_exists = load_existing_config()

    if config_exists:
        console.print("[dim]Existing configuration loaded - entering edit mode[/dim]\n")
        return run_main_menu()
    else:
        console.print("[dim]No configuration found - running initial setup[/dim]\n")
        return run_initial_setup()


def run_initial_setup() -> bool:
    """Run the initial configuration wizard (original behavior)."""
    console.print("\n[bold cyan]Assistant TOML Configuration Wizard[/bold cyan]")
    console.print("Let's configure your multi-agent architecture.\n")

    provider_choice = questionary.select(
        "Choose your LLM Provider:",
        choices=["ollama (Local - Recommended)", "vllm (Local)", "openai (API)"],
    ).ask()

    if not provider_choice:
        return False

    provider_type = provider_choice.split(" ")[0]

    default_url = "http://localhost:11434/v1"
    default_key = "ollama"
    default_model = "qwen3.5:latest"

    if provider_type == "vllm":
        default_url = "http://localhost:8000/v1"
        default_key = "EMPTY"
        default_model = "meta-llama/Llama-3-8b-instruct"
    elif provider_type == "openai":
        default_url = "https://api.openai.com/v1"
        default_key = ""
        default_model = "gpt-4o"

    base_url = questionary.text("Enter the API Base URL:", default=default_url).ask()

    api_key = questionary.password(
        "Enter API Key (leave default for local Ollama/vLLM unless secured):",
        default=default_key,
    ).ask()

    store_in_keyring = questionary.confirm(
        "Store API key in system keyring (recommended for security)?",
        default=True,
    ).ask()

    if store_in_keyring and api_key and api_key not in ("ollama", "EMPTY", ""):
        try:
            import keyring

            keyring.set_password("assistant", provider_type, api_key)
            api_key = f"keyring:{provider_type}"
            console.print("[dim]API key stored securely in system keyring[/dim]")
        except Exception as e:
            console.print(
                f"[dim]Could not store in keyring: {e}. Using plain text.[/dim]"
            )

    model_name = questionary.text(
        "Enter Default Model Name:", default=default_model
    ).ask()

    context_length = questionary.text(
        "Enter model context length (tokens):", default="128000"
    ).ask()

    should_think = questionary.confirm("Enable reasoning?", default=False).ask()

    web_search_enabled = questionary.confirm(
        "Enable web search (SearXNG)?", default=True
    ).ask()

    if not all([base_url, model_name]):
        return False

    searxng_url = "http://localhost:8888"
    if web_search_enabled:
        searxng_url = questionary.text(
            "Enter SearXNG URL:", default="http://localhost:8888"
        ).ask()

    cfg = _get_config_instance()

    cfg.raw = DEFAULT_CONFIG.copy()

    cfg.raw["provider"] = {provider_type: {"endpoint": base_url, "credential": api_key}}

    try:
        context_length = int(context_length)
    except (ValueError, TypeError):
        context_length = 128000

    cfg.raw["model"] = {
        "default": {
            "id": model_name,
            "name": model_name,
            "provider": provider_type,
            "context_length": context_length,
        }
    }

    cfg.raw["execution"]["think"] = should_think or False

    for a_id in cfg.raw.get("agent", {}):
        cfg.raw["agent"][a_id]["model"] = "default"

    cfg.raw["web_search"] = {"enabled": web_search_enabled, "searxng_url": searxng_url}

    console.print("\n[dim]Initializing multi-agent structure...[/dim]")
    cfg.save()
    console.print(f"[bold green]Configuration saved to {cfg.path}[/bold green]\n")
    return True


if __name__ == "__main__":
    run_setup_wizard()
