import warnings
from typing import Union, List, Dict

try:
    import tiktoken
except ImportError:
    tiktoken = None

import warnings
from typing import Union, List, Dict

try:
    import tiktoken
except ImportError:
    tiktoken = None

from xonsh.built_ins import XSH


def get_kernel_interface():
    """
    Returns the kernel interface if it exists, otherwise returns None.
    """
    if hasattr(XSH.shell, "shell"):
        shell = XSH.shell.shell
        if hasattr(shell, "kernel_interface"):
            return XSH.shell.shell.kernel_interface
    return None


def get_spinner():
    """
    Returns the spinner from the kernel interface if it exists, otherwise returns None.
    """
    kernel_interface = get_kernel_interface()
    if kernel_interface and hasattr(kernel_interface, "spinner"):
        return kernel_interface.spinner
    return None


def say(text):
    """If spinner from kernel interface exists, use it to say text, otherwise print text.

    Args:
        text (str): The text to say.
    """
    spinner = get_spinner()
    if spinner:
        spinner.info(text)
    else:
        print(text)


def count_tokens(text: str, encoding_name: str = "cl100k_base") -> int:
    """
    Count tokens in text using tiktoken.

    Args:
        text: Text to count tokens for
        encoding_name: Tiktoken encoding to use (default: cl100k_base for GPT-4/GPT-3.5)

    Returns:
        Token count as integer

    Falls back to heuristic (len(text) // 4) if tiktoken unavailable.
    """
    if not text:
        return 0

    if tiktoken is None:
        warnings.warn("tiktoken not available, using heuristic estimation")
        return len(text) // 4

    try:
        encoding = tiktoken.get_encoding(encoding_name)
        return len(encoding.encode(text))
    except Exception:
        warnings.warn(f"Failed to load {encoding_name}, using heuristic estimation")
        return len(text) // 4


def count_message_tokens(
    message: Dict[str, Union[str, List]], encoding_name: str = "cl100k_base"
) -> int:
    """
    Count tokens in a message dict with role, content, and optionally tool_calls.

    Args:
        message: Dict with 'role', 'content', and optional 'tool_calls'
        encoding_name: Tiktoken encoding to use

    Returns:
        Token count for the message
    """
    tokens = count_tokens(message.get("content", "") or "", encoding_name)

    if "tool_calls" in message and message["tool_calls"]:
        for tc in message["tool_calls"]:
            if isinstance(tc, dict) and "function" in tc:
                func = tc["function"]
                tokens += count_tokens(func.get("arguments", "") or "", encoding_name)

    tokens += 4

    return tokens


def count_messages_tokens(
    messages: List[Dict[str, Union[str, List]]], encoding_name: str = "cl100k_base"
) -> int:
    """
    Count total tokens in a list of messages.

    Args:
        messages: List of message dicts
        encoding_name: Tiktoken encoding to use

    Returns:
        Total token count
    """
    if not messages:
        return 0

    total = 0
    for msg in messages:
        total += count_message_tokens(msg, encoding_name)

    total += 3

    return total


def count_tokens(text: str, encoding_name: str = "cl100k_base") -> int:
    """
    Count tokens in text using tiktoken.

    Args:
        text: Text to count tokens for
        encoding_name: Tiktoken encoding to use (default: cl100k_base for GPT-4/GPT-3.5)

    Returns:
        Token count as integer

    Falls back to heuristic (len(text) // 4) if tiktoken unavailable.
    """
    if not text:
        return 0

    if tiktoken is None:
        warnings.warn("tiktoken not available, using heuristic estimation")
        return len(text) // 4

    try:
        encoding = tiktoken.get_encoding(encoding_name)
        return len(encoding.encode(text))
    except Exception:
        warnings.warn(f"Failed to load {encoding_name}, using heuristic estimation")
        return len(text) // 4


def count_message_tokens(
    message: Dict[str, Union[str, List]], encoding_name: str = "cl100k_base"
) -> int:
    """
    Count tokens in a message dict with role, content, and optionally tool_calls.

    Args:
        message: Dict with 'role', 'content', and optional 'tool_calls'
        encoding_name: Tiktoken encoding to use

    Returns:
        Token count for the message
    """
    tokens = count_tokens(message.get("content", "") or "", encoding_name)

    if "tool_calls" in message and message["tool_calls"]:
        for tc in message["tool_calls"]:
            if isinstance(tc, dict) and "function" in tc:
                func = tc["function"]
                tokens += count_tokens(func.get("arguments", "") or "", encoding_name)

    tokens += 4

    return tokens


def count_messages_tokens(
    messages: List[Dict[str, Union[str, List]]], encoding_name: str = "cl100k_base"
) -> int:
    """
    Count total tokens in a list of messages.

    Args:
        messages: List of message dicts
        encoding_name: Tiktoken encoding to use

    Returns:
        Total token count
    """
    if not messages:
        return 0

    total = 0
    for msg in messages:
        total += count_message_tokens(msg, encoding_name)

    total += 3

    return total
