from typing import Any, Optional
from openai import OpenAI

from assistant.nlp.providers import BaseProvider


class OpenAIProvider(BaseProvider):
    def create_client(self, base_url: str, api_key: str) -> OpenAI:
        return OpenAI(base_url=base_url, api_key=api_key)

    def build_chat_kwargs(
        self,
        model: str,
        messages: list,
        temperature: float,
        think: bool,
        tools: Optional[list] = None,
    ) -> dict:
        kwargs = {
            "model": model,
            "messages": messages,
            "temperature": temperature,
        }
        if tools:
            kwargs["tools"] = tools
            kwargs["tool_choice"] = "auto"
        return kwargs

    def extract_thinking(self, response: Any) -> str:
        reasoning = getattr(response.choices[0].message, "reasoning_content", None)
        if reasoning:
            return reasoning.strip()
        return ""
