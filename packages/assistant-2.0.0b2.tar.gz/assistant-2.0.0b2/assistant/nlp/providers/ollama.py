from typing import Any, Optional
from openai import OpenAI

from assistant.nlp.providers import BaseProvider


class OllamaProvider(BaseProvider):
    def create_client(self, base_url: str, api_key: str) -> OpenAI:
        return OpenAI(base_url=base_url, api_key=api_key)

    def build_chat_kwargs(
        self,
        model: str,
        messages: list,
        temperature: float,
        think: bool,
        tools: Optional[list] = None,
    ) -> dict:
        kwargs = {
            "model": model,
            "messages": messages,
            "temperature": temperature,
        }
        if think:
            kwargs["extra_body"] = {"think": True}
        if tools:
            kwargs["tools"] = tools
            kwargs["tool_choice"] = "auto"
        return kwargs

    def extract_thinking(self, response: Any) -> str:
        msg = response.choices[0].message
        if hasattr(msg, "thinking") and msg.thinking:
            return msg.thinking.strip()
        if hasattr(msg, "model_extra") and msg.model_extra:
            reasoning = msg.model_extra.get("reasoning")
            if reasoning:
                return reasoning.strip()
        return ""
