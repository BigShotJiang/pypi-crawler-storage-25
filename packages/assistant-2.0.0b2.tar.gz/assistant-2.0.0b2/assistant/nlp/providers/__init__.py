from abc import ABC, abstractmethod
from typing import Any, Optional


class BaseProvider(ABC):
    @abstractmethod
    def create_client(self, base_url: str, api_key: str) -> Any:
        pass

    @abstractmethod
    def build_chat_kwargs(
        self,
        model: str,
        messages: list,
        temperature: float,
        think: bool,
        tools: Optional[list] = None,
    ) -> dict:
        pass

    @abstractmethod
    def extract_thinking(self, response: Any) -> str:
        pass


def get_provider(provider_type: str) -> BaseProvider:
    if provider_type == "ollama":
        from assistant.nlp.providers.ollama import OllamaProvider

        return OllamaProvider()
    elif provider_type == "openai":
        from assistant.nlp.providers.openai import OpenAIProvider

        return OpenAIProvider()
    else:
        from assistant.nlp.providers.ollama import OllamaProvider

        return OllamaProvider()
