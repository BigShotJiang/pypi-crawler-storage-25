import os

# import attr
import requests
import random
import threading

from xonsh.built_ins import XSH

from halo import Halo

# from assistant.agent import query_agent
from assistant.nlp.think import let_me_think_about_it, sorry_unable_to_think

try:
    from assistant.listen.interface import ListenInterface

    is_listen_interface = True
except (ModuleNotFoundError, ImportError) as e:
    is_listen_interface = False

try:
    from assistant.say.interface import SayInterface

    is_say_interface = True
except (ModuleNotFoundError, ImportError) as e:
    is_say_interface = False


class ModernHalo(Halo):
    _running_lock = None

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        import threading

        self._running_lock = threading.Lock()

    def start(self, text=None):
        """Starts the spinner on a separate thread."""
        if text is not None:
            self.text = text
        if self._spinner_id is not None:
            return self
        if not (self.enabled and self._check_stream()):
            return self
        self._hide_cursor()

        self._stop_spinner = threading.Event()
        self._spinner_thread = threading.Thread(target=self.render)
        self._spinner_thread.daemon = True
        self._render_frame()
        self._spinner_id = self._spinner_thread.name
        try:
            self._spinner_thread.start()
        except RuntimeError:
            pass
        return self

    def stop(self) -> "ModernHalo":
        with self._running_lock:
            super().stop()
        return self


# @attr.s(auto_attribs=True, frozen=True)
# class PredictReturn:
#     success: bool
#     unparse: str = None
#     error_message: str = None


def get_random_thinking_sentence():
    """
    Returns a random sentence to indicate that the assistant is thinking about a response.
    """
    return random.choice(let_me_think_about_it)


def get_random_sorry_sentence():
    """
    Returns a random sentence to indicate that the assistant is unable to think about a response.
    """
    return random.choice(sorry_unable_to_think)


class AssistantInterface:
    nlp_host = "localhost"
    nlp_port = "5085"
    interface = None

    def __init__(
        self,
        nlp_host=nlp_host,
        nlp_port=nlp_port,
        verbose=False,
        callbacks=[],
        **kwargs,
    ):
        self.nlp_host = nlp_host
        self.nlp_port = nlp_port
        self.spinner = ModernHalo(spinner="dots13", color="cyan")
        self.set_assistant(verbose=verbose, callbacks=callbacks)
        self.is_asr = self.set_asr()
        self.is_tts = self.set_tts()

    def set_assistant(self, verbose=False, callbacks=[]):
        from assistant.as_client import AgentClient

        self.agent_client = AgentClient()

    def set_asr(self):
        if not is_listen_interface:
            self.listen_interface = None
            return is_listen_interface
        self.listen_interface = ListenInterface()
        return is_listen_interface

    def set_tts(self):
        if not is_say_interface:
            self.say_interface = None
            return is_say_interface
        self.say_interface = SayInterface()
        return is_say_interface

    # def is_ollama_up(self):
    #     # We don't manually check ollama anymore because AgentClient falls back transparently.
    #     return True

    # def is_nlp_server_up(self):
    #     # Keep for backward compatibility
    #     return True

    def assistant(self, query, on_event=None):
        answer = None
        try:
            answer = self.agent_client.chat(
                query, os.environ.get("USER", "anonymous"), on_event=on_event
            )
        except Exception as e:
            answer = "An error occured: " + str(e)
        return answer or ""

    def get_intro(self, prompt_into="Assistant?"):
        """
        Returns the introduction prompt for the assistant.

        Returns:
        str: The introduction prompt for the assistant.
        """
        return self.assistant(prompt_into) or get_random_sorry_sentence()

    def say(self, sentence: str | list[str]):
        if isinstance(sentence, str):
            sentence = sentence.split("\n")
        if self.is_tts:
            self.say_interface.say(sentence)
