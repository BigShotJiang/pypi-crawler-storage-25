import os
import sys
import tempfile
import signal
import threading
import subprocess
import time

_sigttou_received = threading.Event()


def _get_known_tuis() -> set:
    """Get the set of known TUI commands from config."""
    from assistant.config import get_config

    cfg = get_config()
    return set(cfg.tuis)


def _get_first_command(code: str) -> str:
    """Extract the first executable command from code, handling pipes and chaining."""
    if not code or not code.strip():
        return ""

    first_cmd = code.strip().split("\n")[0] if code.strip() else ""

    # Split on shell operators to get just the first command
    for sep in (";", "&&", "||", "|"):
        if sep in first_cmd:
            first_cmd = first_cmd.split(sep)[0]
            break

    # Also handle redirects
    for redirect in (">>", ">", "2>>", "2>"):
        if redirect in first_cmd:
            first_cmd = first_cmd.split(redirect)[0]
            break

    return first_cmd.strip()


def _is_tui_invocation(segment: str, known_tuis: set) -> bool:
    """Check if a specific command segment is a TUI invocation, handling batch modes."""
    parts = segment.strip().split()
    if not parts:
        return False
    cmd_base = parts[0].lower()
    if cmd_base in known_tuis:
        # Handle batch mode for specific commands
        if cmd_base == "top":
            for p in parts[1:]:
                if p == "-b" or p.startswith("-b"):
                    return False
        return True
    return False


def _is_simple_shell_command(code: str) -> bool:
    """Check if code is a simple external shell command (not Python/xonsh-specific).

    Returns True for commands like: git diff, ls -la, cat file, echo hello
    Returns False for Python code, xonsh captures, assignments, multi-line scripts.
    """
    stripped = code.strip()
    if not stripped:
        return False
    # Multi-line code is likely Python or complex bash (handled elsewhere)
    if "\n" in stripped:
        return False
    # Xonsh-specific syntax
    if any(s in stripped for s in ["$(", "!(", "@(", "${", "$["]):
        return False
    # Python keywords / syntax at the start of the line
    first_token = stripped.split()[0] if stripped.split() else ""
    _python_keywords = {
        "import",
        "from",
        "def",
        "class",
        "return",
        "yield",
        "lambda",
        "raise",
        "try",
        "except",
        "finally",
        "with",
        "assert",
        "del",
        "global",
        "nonlocal",
        "pass",
        "break",
        "continue",
    }
    if first_token in _python_keywords:
        return False
    # Python function calls / assignments: x = ..., foo(...)
    # But allow shell commands with VAR=val syntax (e.g., GIT_PAGER=cat git diff)
    if "=" in stripped and "==" not in stripped:
        lhs = stripped.split("=", 1)[0].strip()
        # If LHS is a valid Python identifier, check further
        if lhs.isidentifier():
            # Python uses `x = val` (spaces around =). Shell uses `VAR=val cmd` (no spaces).
            # If format is `VAR=val something_else`, it's a shell env prefix.
            rhs = stripped.split("=", 1)[1]
            # Shell: no space before =, and there are more tokens after VAR=val
            if " " in stripped.split("=")[0]:
                # `x = 42` → Python assignment (space before =)
                return False
            elif " " in rhs and not rhs.startswith(" "):
                # `GIT_PAGER=cat git diff` → shell env prefix (tokens after val)
                pass  # allow
            else:
                return False
    # Python function calls: f(x), math.sin(x)
    if stripped.endswith(")"):
        if "(" in stripped:
            caller = stripped.split("(", 1)[0].strip()
            if all(c.isalnum() or c in "_." for c in caller) and caller:
                return False

    # print(...) is Python
    if stripped.startswith("print(") or stripped.startswith("print ("):
        return False
    return True


def _handle_cd_in_command(code: str) -> tuple[bool, str]:
    """Handle cd commands in shell code, executing them in the parent process.

    Returns a tuple of (handled, remaining_code).
    - handled=True means cd was executed and remaining_code is what should run
    - handled=False means no cd was found to handle
    """
    import re as _re

    cd_pattern = _re.compile(r"^\s*cd\s+(\S+)\s*(?:&&\s*)?(.*)", _re.IGNORECASE)
    match = cd_pattern.match(code)
    if match:
        target_dir = match.group(1)
        remaining = match.group(2).strip()

        # Expand ~ to HOME
        if target_dir.startswith("~"):
            target_dir = os.path.expanduser(target_dir)

        try:
            os.chdir(target_dir)
            home = os.environ.get("HOME", "~")
            cwd = os.getcwd().replace(home, "~")
            print(f"[cd to {cwd}]")
        except FileNotFoundError:
            return True, f'echo "cd: {target_dir}: No such file or directory"'
        except Exception as e:
            return True, f'echo "cd: {target_dir}: {e}"'

        if remaining:
            return True, remaining
        else:
            return True, 'echo ""'

    return False, code


def _has_tui_command(code: str) -> bool:
    """Check if code contains a known TUI command (at start or after pipe/chain).

    Returns True if:
    - First command is a known TUI (htop, vim, less, etc.)
    - Any segment after a pipe is a known TUI (e.g., "cat file | less")
    - Any segment after && or || is a known TUI (e.g., "ls && vim file")

    Returns False for non-TUI pipes/chains (e.g., "cat file | head", "echo test | grep foo")
    """
    if not code or not code.strip():
        return False

    first_cmd = _get_first_command(code).lower()
    known_tuis = _get_known_tuis()

    if _is_tui_invocation(first_cmd, known_tuis):
        return True

    for sep in ["|", "&&", "||"]:
        if sep in code:
            for segment in code.split(sep):
                if _is_tui_invocation(segment, known_tuis):
                    return True

    return False


# Bash control structures that indicate complex/multi-line bash
_BASH_CONTROL_KEYWORDS = {
    # Conditionals
    "if",
    "then",
    "else",
    "elif",
    "fi",
    # Loops
    "for",
    "while",
    "until",
    "do",
    "done",
    # Case statements
    "case",
    "esac",
    "in",
    # Functions
    "function",
}


def _is_complex_bash(code: str) -> bool:
    """Detect if code contains complex bash structures that xonsh cannot parse.

    Xonsh's execer.exec() can only handle simple single-line shell commands.
    Multi-line structures with if/fi, for/done, etc. will raise SyntaxError.

    Returns True if the code should be executed via subprocess instead of xonsh.
    """
    import re

    if not code or not code.strip():
        return False

    lines = code.strip().split("\n")

    # Single line - check for complex bash on single line (semicolon separated)
    if len(lines) == 1:
        # Check for line continuation character
        if lines[0].rstrip().endswith("\\"):
            return True
        # Check for heredoc
        if "<<" in lines[0]:
            return True
        # Check for control keywords separated by semicolons
        stripped = lines[0].strip().lower()
        # Split on semicolons to check each segment
        segments = re.split(r";", stripped)
        for seg in segments:
            seg = seg.strip()
            if not seg:
                continue
            words = seg.split()
            if words and words[0] in _BASH_CONTROL_KEYWORDS:
                return True
        return False

    # Multi-line code - check for bash control structures
    for line in lines:
        stripped = line.strip().lower()
        # Skip empty lines and comments
        if not stripped or stripped.startswith("#"):
            continue

        # Check for control keywords at start of line or after semicolon
        words = re.split(r"[;|&]", stripped)[0].split()
        if words and words[0] in _BASH_CONTROL_KEYWORDS:
            return True

        # Check for heredoc markers
        if "<<" in stripped:
            return True

    return False


def _sigttou_handler(signum, frame):
    _sigttou_received.set()


XONSH_TOOL = {
    "type": "function",
    "function": {
        "name": "xonsh",
        "description": (
            "Execute shell commands or Python code.\n"
            "IMPORTANT - Use this tool correctly:\n"
            "1. For SIMPLE shell commands (echo, ls, cat, grep, date, sensors, etc.): write them directly\n"
            "2. For Python code: write Python code with print()\n"
            "3. For COMPLEX BASH scripts (if/then/fi, for/done, while/done, case/esac, multi-line with pipes & conditionals):\n"
            "   - You MUST wrap them in: $(cat << 'BASH'\\nYOUR_BASH_CODE\\nBASH)\n"
            "   - Example: $(cat << 'BASH'\\necho test\\nif true; then echo ok; fi\\nBASH)\n"
            "   - Or use Python subprocess: import subprocess; subprocess.run('your command', shell=True)\n"
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "code": {
                    "type": "string",
                    "description": "Shell command or Python code to execute.",
                }
            },
            "required": ["code"],
        },
    },
}

MEMORY_SEARCH_TOOL = {
    "type": "function",
    "function": {
        "name": "memory_search",
        "description": "Search the persistent memory database for relevant information.",
        "parameters": {
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": "The search query to look for in memory.",
                }
            },
            "required": ["query"],
        },
    },
}

MEMORY_ADD_TOOL = {
    "type": "function",
    "function": {
        "name": "memory_add",
        "description": "Add new information to the persistent memory database.",
        "parameters": {
            "type": "object",
            "properties": {
                "text": {
                    "type": "string",
                    "description": "The text to store in memory.",
                }
            },
            "required": ["text"],
        },
    },
}

WEB_SEARCH_TOOL = {
    "type": "function",
    "function": {
        "name": "web_search",
        "description": "Search the web using SearXNG. Returns search results with titles, URLs, and snippets. Use for finding current information, news, documentation, or any web content.",
        "parameters": {
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": "The search query.",
                },
                "num_results": {
                    "type": "integer",
                    "description": "Maximum number of results to return (1-10).",
                    "default": 5,
                },
            },
            "required": ["query"],
        },
    },
}

READ_WEBPAGE_TOOL = {
    "type": "function",
    "function": {
        "name": "read_webpage",
        "description": (
            "Fetch and extract readable text content from a web page URL. "
            "Returns the main textual content of the page, stripped of HTML tags and scripts. "
            "Useful for reading documentation, articles, API references, etc."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "url": {
                    "type": "string",
                    "description": "The full URL of the web page to read.",
                },
                "max_length": {
                    "type": "integer",
                    "description": "Maximum number of characters to return (default: 8000).",
                    "default": 8000,
                },
            },
            "required": ["url"],
        },
    },
}

READ_FILE_TOOL = {
    "type": "function",
    "function": {
        "name": "read_file",
        "description": (
            "Read the contents of a file from the local filesystem. "
            "Returns the file contents with line numbers. "
            "Use start_line and end_line to read specific sections of large files."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "path": {
                    "type": "string",
                    "description": "Absolute or relative path to the file to read.",
                },
                "start_line": {
                    "type": "integer",
                    "description": "First line to read (1-indexed, inclusive). Omit to start from beginning.",
                },
                "end_line": {
                    "type": "integer",
                    "description": "Last line to read (1-indexed, inclusive). Omit to read to end.",
                },
            },
            "required": ["path"],
        },
    },
}

EDIT_FILE_TOOL = {
    "type": "function",
    "function": {
        "name": "edit_file",
        "description": (
            "Edit a file by replacing exact text content. "
            "Specify the file path, the exact text to find (old_text), and the replacement text (new_text). "
            "The old_text must match exactly (including whitespace and indentation). "
            "Only the first occurrence is replaced by default; set replace_all to true to replace all occurrences."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "path": {
                    "type": "string",
                    "description": "Absolute or relative path to the file to edit.",
                },
                "old_text": {
                    "type": "string",
                    "description": "The exact text to find in the file. Must match exactly including whitespace.",
                },
                "new_text": {
                    "type": "string",
                    "description": "The replacement text.",
                },
                "replace_all": {
                    "type": "boolean",
                    "description": "If true, replace all occurrences. Default: false (replace first only).",
                    "default": False,
                },
            },
            "required": ["path", "old_text", "new_text"],
        },
    },
}

WRITE_FILE_TOOL = {
    "type": "function",
    "function": {
        "name": "write_file",
        "description": (
            "Create or overwrite a file with the given content. "
            "Parent directories are created automatically if they don't exist. "
            "Use this to create new files or completely replace existing file contents."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "path": {
                    "type": "string",
                    "description": "Absolute or relative path to the file to write.",
                },
                "content": {
                    "type": "string",
                    "description": "The full content to write to the file.",
                },
                "create_dirs": {
                    "type": "boolean",
                    "description": "If true (default), create parent directories if they don't exist.",
                    "default": True,
                },
            },
            "required": ["path", "content"],
        },
    },
}


def _run_interactive(code: str, reset: bool = True) -> int:
    """Run *code* as a shell command with full foreground terminal control.

    Unlike plain subprocess.run(shell=True), this function:
    1. Resets the terminal to a sane state (in case a prior process left it in
       raw mode after being killed).
    2. Gives the child its own process group (os.setpgid).
    3. Transfers the controlling terminal to that group (os.tcsetpgrp) so TUI
       programs such as nvim, htop, less, etc. work correctly.
    4. Reclaims the terminal when the child exits.
    """
    our_pgid = os.getpgrp()

    # Open controlling terminal; fall back to simple run if unavailable.
    try:
        tty_fd = os.open("/dev/tty", os.O_RDWR)
    except OSError:
        return subprocess.run(code, shell=True).returncode

    # Reset terminal only if explicitly requested (e.g., if a prior TUI was killed).
    if reset:
        subprocess.run(["stty", "sane"], stdin=tty_fd, stderr=subprocess.DEVNULL)

        # Also reset VT100 terminal emulator state (ANSI).
        # We disable mouse tracking and bracketed paste that may have been left active.
        reset_seq = (
            b"\x1b[?2004l\x1b[?1000l\x1b[?1001l\x1b[?1002l\x1b[?1003l"
            b"\x1b[?1005l\x1b[?1006l\x1b[?1015l\x1b[?1016l"
        )
        try:
            os.write(tty_fd, reset_seq)
        except OSError:
            pass

    # Ignore SIGTTOU in *parent* while we call tcsetpgrp (otherwise we'd
    # send ourselves SIGTTOU when changing the terminal foreground group).
    old_ttou = signal.signal(signal.SIGTTOU, signal.SIG_IGN)
    returncode = 1
    try:
        proc = subprocess.Popen(
            code,
            shell=True,
            stdin=sys.stdin,
            stdout=sys.stdout,
            stderr=sys.stderr,
            preexec_fn=lambda: os.setpgid(0, 0),  # child owns its process group
        )
        child_pgid = proc.pid  # after setpgid(0,0), pgid == pid

        # Hand the terminal to the child's group
        try:
            os.tcsetpgrp(tty_fd, child_pgid)
        except OSError:
            pass

        try:
            proc.wait()
        except KeyboardInterrupt:
            proc.send_signal(signal.SIGINT)
            proc.wait()

        returncode = proc.returncode
    finally:
        # Reclaim the terminal and restore signal handler
        try:
            os.tcsetpgrp(tty_fd, our_pgid)
        except OSError:
            pass
        os.close(tty_fd)
        signal.signal(signal.SIGTTOU, old_ttou)

    return returncode


def _execute_complex_bash(
    code: str,
    orig_term_attrs,
    known_tuis: set,
    run_interactive_fn,
) -> dict:
    """Execute complex bash code that xonsh cannot parse (multi-line with if/fi, etc.).

    Uses subprocess to run the code with similar TUI detection as the main execute_xonsh.
    """
    import re as _re
    import termios as _termios
    import tempfile

    # Check if any known TUI command is being EXECUTED (not just mentioned in a script)
    # Only treat as TUI if it's the first command or a standalone command with proper delimiters
    # This prevents false positives like "top -bn1" in a script being detected as TUI
    import re

    code_lower = code.lower()
    has_tui = False

    # Get first non-empty, non-comment line
    first_cmd = ""
    for line in code.strip().split("\n"):
        stripped = line.strip()
        if stripped and not stripped.startswith("#"):
            first_cmd = stripped.split(";")[0].split("&")[0].split("|")[0].strip()
            break

    if first_cmd:
        for tui in known_tuis:
            if first_cmd.startswith(tui + " ") or first_cmd == tui:
                has_tui = True
                break

    if has_tui:
        try:
            rc = run_interactive_fn(code, reset=False)
            return {
                "content": f"[interactive] Command exited with code {rc}.",
                "is_error": rc != 0,
            }
        except Exception as e:
            return {"content": f"Interactive fallback failed: {e}", "is_error": True}

    # Non-TUI complex bash - run with subprocess and capture output
    with (
        tempfile.TemporaryFile(mode="w+") as tmp_out,
        tempfile.TemporaryFile(mode="w+") as tmp_err,
    ):
        try:
            # Run the bash code via subprocess, redirecting stdout/stderr to temp files
            proc = subprocess.run(
                code,
                shell=True,
                stdout=tmp_out,
                stderr=tmp_err,
                text=True,
            )
            returncode = proc.returncode
        except Exception as e:
            return {"content": f"Subprocess execution failed: {e}", "is_error": True}

        tmp_out.seek(0)
        tmp_err.seek(0)
        out = tmp_out.read().strip()
        err = tmp_err.read().strip()

        # Check for TUI-related indicators in output (same logic as main execute_xonsh)
        combined = out + "\n" + err
        needs_interactive = False

        # 1) SIGTTOU/SIGTTIN suspension
        sigttou_match = _re.search(
            r"pid (\d+) was suspended with signal.*SIG(?:TTOU|TTIN)", combined
        )
        if sigttou_match:
            suspended_pid = int(sigttou_match.group(1))
            try:
                os.kill(suspended_pid, signal.SIGTERM)
                time.sleep(0.02)
                os.kill(suspended_pid, signal.SIGKILL)
            except (ProcessLookupError, PermissionError):
                pass
            needs_interactive = True

        # 2) Terminal attributes changed
        if not needs_interactive and orig_term_attrs is not None:
            try:
                new_attrs = _termios.tcgetattr(sys.stdin.fileno())
                if new_attrs != orig_term_attrs:
                    _termios.tcsetattr(
                        sys.stdin.fileno(), _termios.TCSAFLUSH, orig_term_attrs
                    )
                    needs_interactive = True
            except (_termios.error, OSError, ValueError):
                pass

        # 3) Output contains TTY warnings
        if not needs_interactive:
            t_lower = combined.lower()
            if _re.search(
                r"(not to a terminal|pas sur un terminal|inappropriate ioctl|not a terminal|pas un terminal)",
                t_lower,
            ):
                needs_interactive = True
            elif (
                t_lower.strip().startswith("vim") or t_lower.strip().startswith("nvim")
            ) and "terminal" in t_lower:
                needs_interactive = True

        if needs_interactive:
            try:
                rc = run_interactive_fn(code)
                return {
                    "content": f"[interactive] Command exited with code {rc}.",
                    "is_error": rc != 0,
                }
            except Exception as e:
                return {
                    "content": f"Interactive fallback failed: {e}",
                    "is_error": True,
                }

        res = out
        if err:
            res += f"\nError: {err}"

        from assistant.config import get_config

        cfg = get_config()
        max_len = cfg.max_command_output_length
        if len(res) > max_len:
            res = (
                res[:max_len]
                + "\n...[OUTPUT TRUNCATED] Output too large. Please explore it by window using tools like 'head', 'tail', 'grep' and such."
            )

        return {"content": res, "is_error": returncode != 0}


def _execute_python_code(code: str, ctx: dict) -> None:
    """Execute Python code (statements or expressions) in xonsh context.

    Tries exec() first (statements: def, class, import, assignments),
    then eval() (expressions: variable names, calculations).
    """
    import builtins as _builtins

    code = code.strip()
    if not code:
        return

    exec_error = None
    try:
        exec(code, ctx, ctx)
    except SyntaxError as e:
        exec_error = e
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        return

    if exec_error is not None:
        try:
            result = eval(code, ctx, ctx)
            if result is not None:
                print(repr(result), file=sys.stdout)
        except SyntaxError:
            pass
        except Exception as e:
            print(f"Error: {e}", file=sys.stderr)


def execute_xonsh(args: dict) -> dict:
    """Execute code in the persistent xonsh environment.

    Detects interactive/TUI commands via three mechanisms:
    1. Xonsh SIGTTOU/SIGTTIN suspension message (gping, htop)
    2. Terminal attributes changed (nvim, vi set raw mode)
    3. Output contains 'not to a terminal' warning (vim, less)
    On detection, kills the stuck process and re-runs interactively.
    """
    import re as _re
    import termios as _termios

    code = args.get("code", "")
    try:
        import builtins

        # Ensure xonsh environment is initialized
        if not (
            hasattr(builtins, "__xonsh__") and hasattr(builtins.__xonsh__, "execer")
        ):
            from xonsh.main import setup

            setup()

        # Check again after setup()
        if not (
            hasattr(builtins, "__xonsh__") and hasattr(builtins.__xonsh__, "execer")
        ):
            return {"content": "Xonsh environment not ready.", "is_error": True}

        execer = builtins.__xonsh__.execer
        ctx = builtins.__xonsh__.ctx

        # Disable pagers so tools like git/man don't invoke less/more
        # which would change terminal attributes and trigger interactive detection.
        _pager_vars = {
            "GIT_PAGER": "cat",
            "PAGER": "cat",
            "MANPAGER": "cat",
            "GIT_TERMINAL_PROMPT": "0",
        }
        _pager_env_backup = {k: os.environ.get(k) for k in _pager_vars}
        _xonsh_env_backup = {}
        for _k, _v in _pager_vars.items():
            os.environ[_k] = _v
        # Also set in xonsh's own env (xonsh may not read os.environ for subprocess env)
        try:
            if hasattr(builtins, "__xonsh__") and hasattr(builtins.__xonsh__, "env"):
                _xenv = builtins.__xonsh__.env
                for _k, _v in _pager_vars.items():
                    _xonsh_env_backup[_k] = _xenv.get(_k)
                    _xenv[_k] = _v
        except Exception:
            pass

        try:
            # Save terminal state before execution
            try:
                orig_term_attrs = _termios.tcgetattr(sys.stdin.fileno())
            except (_termios.error, OSError, ValueError):
                orig_term_attrs = None

            # PRE-DETECTION 1: Check if it's a known TUI command (at start or after pipe/chain)
            is_tui = _has_tui_command(code)

            if is_tui:
                try:
                    rc = _run_interactive(code, reset=False)
                    return {
                        "content": f"[interactive] Command exited with code {rc}.",
                        "is_error": rc != 0,
                    }
                except Exception as e:
                    return {
                        "content": f"Interactive fallback failed: {e}",
                        "is_error": True,
                    }

            # PRE-DETECTION 2: If it's complex bash (multi-line with if/fi, for/done, etc.),
            # execute via subprocess instead of xonsh execer which cannot parse these structures
            if _is_complex_bash(code):
                return _execute_complex_bash(
                    code, orig_term_attrs, _get_known_tuis(), _run_interactive
                )

            # Detect if this is a simple external shell command vs Python/xonsh code.
            # Simple shell commands are run via subprocess.run for reliable output capture.
            # Xonsh's execer in uncaptured mode connects subprocesses to saved terminal fds,
            # which bypasses our dup2 redirect and leaks output to the terminal.
            _use_subprocess = _is_simple_shell_command(code)

            if _use_subprocess:
                import subprocess as _sp

                # Handle cd commands in the parent process before running via subprocess
                cd_handled, remaining_code = _handle_cd_in_command(code)
                if cd_handled:
                    if not remaining_code:
                        return {"content": "", "is_error": False}
                    # Execute the remaining part (without cd)
                    code = remaining_code

                try:
                    result = _sp.run(
                        code,
                        shell=True,
                        capture_output=True,
                        text=True,
                        env=os.environ,
                        timeout=30,
                    )
                    out = result.stdout.strip()
                    err = result.stderr.strip()

                    # Clean up ANSI codes
                    out = _re.sub(r"\x1b\]0;[^\x07]*\x07", "", out)
                    out = _re.sub(r"\x1b\[[0-9;]*[a-zA-Z]", "", out)
                    out = out.strip()

                    res = out
                    if err:
                        res += f"\nError: {err}"

                    from assistant.config import get_config

                    cfg = get_config()
                    max_len = cfg.max_command_output_length
                    if len(res) > max_len:
                        res = (
                            res[:max_len]
                            + "\n...[OUTPUT TRUNCATED] Output too large. Please explore it by window using tools like 'head', 'tail', 'grep' and such."
                        )

                    return {"content": res, "is_error": result.returncode != 0}
                except _sp.TimeoutExpired:
                    return {
                        "content": "[timeout] Command did not complete in 30s.",
                        "is_error": True,
                    }
                except Exception as e:
                    err_msg = str(e)
                    if "git" in code.lower() and "commit" in code.lower():
                        return {
                            "content": f'git commit failed: {err_msg}\n\nTip: Use \'git commit -m "message"\' with double quotes, or use -m multiple times for multiline: git commit -m "title" -m "description"',
                            "is_error": True,
                        }
                    return {"content": f"Execution error: {err_msg}", "is_error": True}

            # --- Python / xonsh-specific code path (execer) ---
            out = ""
            err = ""

            try:
                with (
                    tempfile.TemporaryFile(mode="w+") as tmp_out,
                    tempfile.TemporaryFile(mode="w+") as tmp_err,
                ):
                    saved_out_fd = os.dup(1)
                    saved_err_fd = os.dup(2)
                    saved_out = sys.stdout
                    saved_err = sys.stderr

                    try:
                        os.dup2(tmp_out.fileno(), 1)
                        os.dup2(tmp_err.fileno(), 2)
                        sys.stdout = os.fdopen(os.dup(1), "w")
                        sys.stderr = os.fdopen(os.dup(2), "w")

                        # Isolate terminal: prevent xonsh from putting the process in the foreground
                        # by masking os.tcsetpgrp. TUI commands are caught by pre-detection,
                        # SIGTTIN (background process reading terminal), and post-exec attr checks.
                        _orig_tcsetpgrp = os.tcsetpgrp

                        def _mock_tcsetpgrp(fd, pgrp):
                            pass

                        os.tcsetpgrp = _mock_tcsetpgrp

                        try:
                            _execute_python_code(code, ctx)
                        finally:
                            os.tcsetpgrp = _orig_tcsetpgrp
                            try:
                                if orig_term_attrs is not None:
                                    _termios.tcsetattr(
                                        sys.stdin.fileno(),
                                        _termios.TCSANOW,
                                        orig_term_attrs,
                                    )
                            except Exception:
                                pass

                        sys.stdout.flush()
                        sys.stderr.flush()
                    finally:
                        sys.stdout.close()
                        sys.stderr.close()
                        sys.stdout = saved_out
                        sys.stderr = saved_err
                        os.dup2(saved_out_fd, 1)
                        os.dup2(saved_err_fd, 2)
                        os.close(saved_out_fd)
                        os.close(saved_err_fd)

                    tmp_out.seek(0)
                    tmp_err.seek(0)
                    out = tmp_out.read().strip()
                    err = tmp_err.read().strip()

                # Post-execution analysis
                combined = out + "\n" + err
                needs_interactive = False

                # 1) SIGTTOU/SIGTTIN suspension (gping, htop)
                sigttou_match = _re.search(
                    r"pid (\d+) was suspended with signal.*SIG(?:TTOU|TTIN)", combined
                )
                if sigttou_match:
                    suspended_pid = int(sigttou_match.group(1))
                    try:
                        os.kill(suspended_pid, signal.SIGTERM)
                        import time as _time

                        _time.sleep(0.02)
                        os.kill(suspended_pid, signal.SIGKILL)
                    except (ProcessLookupError, PermissionError):
                        pass
                    needs_interactive = True

                # 2) Terminal attributes changed (nvim, vi)
                if not needs_interactive and orig_term_attrs is not None:
                    try:
                        new_attrs = _termios.tcgetattr(sys.stdin.fileno())
                        if new_attrs != orig_term_attrs:
                            _termios.tcsetattr(
                                sys.stdin.fileno(), _termios.TCSAFLUSH, orig_term_attrs
                            )
                            needs_interactive = True
                    except (_termios.error, OSError, ValueError):
                        pass

                # 3) Output contains TTY warnings (vim, less, nvim)
                if not needs_interactive:
                    t_lower = combined.lower()
                    if _re.search(
                        r"(not to a terminal|pas sur un terminal|inappropriate ioctl|not a terminal|pas un terminal)",
                        t_lower,
                    ):
                        needs_interactive = True
                    elif (
                        t_lower.strip().startswith("vim")
                        or t_lower.strip().startswith("nvim")
                    ) and "terminal" in t_lower:
                        needs_interactive = True

                if needs_interactive:
                    try:
                        rc = _run_interactive(code)
                        return {
                            "content": f"[interactive] Command exited with code {rc}.",
                            "is_error": rc != 0,
                        }
                    except Exception as e:
                        return {
                            "content": f"Interactive fallback failed: {e}",
                            "is_error": True,
                        }

                res = out
                if err:
                    res += f"\nError: {err}"

                # Clean up xonsh terminal title sequences and other ANSI codes
                import re as _re2

                res = _re2.sub(r"\x1b\]0;[^\x07]*\x07", "", res)
                res = _re2.sub(r"\x1b\[[0-9;]*[a-zA-Z]", "", res)
                res = res.strip()

                from assistant.config import get_config

                cfg = get_config()
                max_len = cfg.max_command_output_length
                if len(res) > max_len:
                    res = (
                        res[:max_len]
                        + "\n...[OUTPUT TRUNCATED] Output too large. Please explore it by window using tools like 'head', 'tail', 'grep' and such."
                    )

                return {"content": res, "is_error": False}

            except Exception as e:
                err_msg = str(e)
                if "git" in code.lower() and "commit" in code.lower():
                    return {
                        "content": f'git commit failed: {err_msg}\n\nTip: Use \'git commit -m "message"\' with double quotes, or use -m multiple times for multiline: git commit -m "title" -m "description"',
                        "is_error": True,
                    }
                return {"content": f"Execution error: {err_msg}", "is_error": True}

        finally:
            # Restore pager environment variables
            for _k, _orig in _pager_env_backup.items():
                if _orig is None:
                    os.environ.pop(_k, None)
                else:
                    os.environ[_k] = _orig
            # Restore xonsh env
            try:
                if (
                    _xonsh_env_backup
                    and hasattr(builtins, "__xonsh__")
                    and hasattr(builtins.__xonsh__, "env")
                ):
                    _xenv = builtins.__xonsh__.env
                    for _k, _orig in _xonsh_env_backup.items():
                        if _orig is None:
                            _xenv.pop(_k, None)
                        else:
                            _xenv[_k] = _orig
            except Exception:
                pass

    except Exception as e:
        return {"content": f"Execution error: {e}", "is_error": True}


def execute_memory_search(args: dict) -> dict:
    query = args.get("query", "")
    from assistant.memory import memory

    try:
        results = memory.search(query=query, limit=5)
        entries = results.get("results", [])
        if not entries:
            return {"content": "No matching memories found.", "is_error": False}
        res_str = "\n".join(f"- {e['memory']}" for e in entries)
        return {"content": res_str, "is_error": False}
    except Exception as e:
        return {"content": f"Memory search error: {e}", "is_error": True}


def execute_memory_add(args: dict) -> dict:
    text = args.get("text", "")
    from assistant.memory import memory

    try:
        msg = [{"role": "assistant", "content": text}]
        memory.add(msg)
        return {"content": "Successfully added to memory.", "is_error": False}
    except Exception as e:
        return {"content": f"Memory add error: {e}", "is_error": True}


def execute_web_search(args: dict) -> dict:
    import urllib.parse
    import urllib.request
    import json

    from assistant.config import get_config

    cfg = get_config()
    query = args.get("query", "")
    num_results = min(max(args.get("num_results", 5), 1), 10)

    if not query:
        return {"content": "Error: Empty search query.", "is_error": True}

    searxng_url = cfg.searxng_url.rstrip("/")

    try:
        params = urllib.parse.urlencode({"q": query, "format": "json"})
        url = f"{searxng_url}/search?{params}"

        req = urllib.request.Request(url, headers={"User-Agent": "Assistant/1.0"})
        with urllib.request.urlopen(req, timeout=15) as response:
            data = json.loads(response.read().decode("utf-8"))

        results = data.get("results", [])[:num_results]

        if not results:
            return {"content": "No results found.", "is_error": False}

        formatted = []
        for i, r in enumerate(results, 1):
            title = r.get("title", "No title")
            link = r.get("url", "")
            snippet = r.get("content", "")
            engine = r.get("engine", "unknown")
            formatted.append(
                f"{i}. {title}\n   URL: {link}\n   {snippet}\n   (Source: {engine})"
            )

        return {"content": "\n".join(formatted), "is_error": False}

    except urllib.error.URLError as e:
        return {
            "content": f"SearXNG connection error: {e}. Is SearXNG running at {searxng_url}?",
            "is_error": True,
        }
    except json.JSONDecodeError as e:
        return {"content": f"JSON parse error: {e}", "is_error": True}
    except Exception as e:
        return {"content": f"Web search error: {e}", "is_error": True}


def execute_read_webpage(args: dict) -> dict:
    """Fetch a web page and extract its readable text content."""
    import urllib.request
    import re as _re
    from html.parser import HTMLParser

    url = args.get("url", "")
    max_length = min(max(args.get("max_length", 8000), 500), 50000)

    if not url:
        return {"content": "Error: No URL provided.", "is_error": True}

    # Ensure URL has a scheme
    if not url.startswith(("http://", "https://")):
        url = "https://" + url

    try:
        req = urllib.request.Request(
            url,
            headers={
                "User-Agent": "Mozilla/5.0 (X11; Linux x86_64; rv:128.0) Gecko/20100101 Firefox/128.0",
                "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
                "Accept-Language": "en-US,en;q=0.5",
            },
        )
        with urllib.request.urlopen(req, timeout=20) as response:
            content_type = response.headers.get("Content-Type", "")
            charset = "utf-8"
            if "charset=" in content_type:
                charset = content_type.split("charset=")[-1].split(";")[0].strip()
            raw = response.read()
            html = raw.decode(charset, errors="replace")

        # Simple HTML to text extraction
        # Remove script/style blocks
        html = _re.sub(
            r"<script[^>]*>.*?</script>", "", html, flags=_re.DOTALL | _re.IGNORECASE
        )
        html = _re.sub(
            r"<style[^>]*>.*?</style>", "", html, flags=_re.DOTALL | _re.IGNORECASE
        )
        html = _re.sub(r"<!--.*?-->", "", html, flags=_re.DOTALL)

        # Extract title
        title_match = _re.search(
            r"<title[^>]*>(.*?)</title>", html, _re.DOTALL | _re.IGNORECASE
        )
        title = title_match.group(1).strip() if title_match else ""

        # Convert some HTML elements to text markers
        html = _re.sub(
            r"<br\s*/?>|</p>|</div>|</li>|</tr>", "\n", html, flags=_re.IGNORECASE
        )
        html = _re.sub(r"<li[^>]*>", "• ", html, flags=_re.IGNORECASE)
        html = _re.sub(r"<h[1-6][^>]*>", "\n## ", html, flags=_re.IGNORECASE)
        html = _re.sub(r"</h[1-6]>", "\n", html, flags=_re.IGNORECASE)

        # Strip remaining HTML tags
        text = _re.sub(r"<[^>]+>", "", html)

        # Decode HTML entities
        import html as _html_mod

        text = _html_mod.unescape(text)

        # Clean up whitespace
        lines = [line.strip() for line in text.split("\n")]
        lines = [line for line in lines if line]  # remove empty lines
        text = "\n".join(lines)

        # Collapse multiple blank lines
        text = _re.sub(r"\n{3,}", "\n\n", text)
        text = text.strip()

        if not text:
            return {
                "content": f"Page at {url} returned no readable text content.",
                "is_error": False,
            }

        # Prepend title if found
        if title:
            text = f"Title: {title}\n\n{text}"

        # Truncate
        if len(text) > max_length:
            text = (
                text[:max_length]
                + "\n\n...[CONTENT TRUNCATED] Use a larger max_length or extract specific sections."
            )

        return {"content": text, "is_error": False}

    except urllib.error.HTTPError as e:
        return {
            "content": f"HTTP error {e.code}: {e.reason} for URL: {url}",
            "is_error": True,
        }
    except urllib.error.URLError as e:
        return {"content": f"URL error: {e.reason} for URL: {url}", "is_error": True}
    except Exception as e:
        return {"content": f"Error reading webpage: {e}", "is_error": True}


def execute_read_file(args: dict) -> dict:
    """Read the contents of a file from the local filesystem."""
    path = args.get("path", "")
    start_line = args.get("start_line", None)
    end_line = args.get("end_line", None)

    if not path:
        return {"content": "Error: No file path provided.", "is_error": True}

    path = os.path.expanduser(path)

    if not os.path.isabs(path):
        path = os.path.abspath(path)

    if not os.path.exists(path):
        return {"content": f"Error: File not found: {path}", "is_error": True}

    if os.path.isdir(path):
        return {
            "content": f"Error: Path is a directory, not a file: {path}",
            "is_error": True,
        }

    try:
        with open(path, "r", encoding="utf-8", errors="replace") as f:
            lines = f.readlines()

        total_lines = len(lines)

        # Apply line range
        if start_line is not None:
            start_line = max(1, start_line)
        else:
            start_line = 1

        if end_line is not None:
            end_line = min(total_lines, end_line)
        else:
            end_line = total_lines

        if start_line > total_lines:
            return {
                "content": f"Error: start_line ({start_line}) exceeds total lines ({total_lines}).",
                "is_error": True,
            }

        selected = lines[start_line - 1 : end_line]

        # Format with line numbers
        numbered = []
        for i, line in enumerate(selected, start=start_line):
            numbered.append(f"{i:>4}: {line.rstrip()}")

        result = f"File: {path} ({total_lines} lines total, showing {start_line}-{end_line})\n"
        result += "\n".join(numbered)

        # Truncate if too large
        from assistant.config import get_config

        cfg = get_config()
        max_len = cfg.max_command_output_length
        if len(result) > max_len:
            result = (
                result[:max_len]
                + "\n...[OUTPUT TRUNCATED] Use start_line/end_line to read specific sections."
            )

        return {"content": result, "is_error": False}

    except PermissionError:
        return {
            "content": f"Error: Permission denied reading file: {path}",
            "is_error": True,
        }
    except Exception as e:
        return {"content": f"Error reading file: {e}", "is_error": True}


def execute_edit_file(args: dict) -> dict:
    """Edit a file by replacing exact text content."""
    path = args.get("path", "")
    old_text = args.get("old_text", "")
    new_text = args.get("new_text", "")
    replace_all = args.get("replace_all", False)

    if not path:
        return {"content": "Error: No file path provided.", "is_error": True}

    if not old_text:
        return {"content": "Error: old_text cannot be empty.", "is_error": True}

    path = os.path.expanduser(path)

    if not os.path.isabs(path):
        path = os.path.abspath(path)

    if not os.path.exists(path):
        return {"content": f"Error: File not found: {path}", "is_error": True}

    if os.path.isdir(path):
        return {
            "content": f"Error: Path is a directory, not a file: {path}",
            "is_error": True,
        }

    try:
        with open(path, "r", encoding="utf-8") as f:
            content = f.read()

        # Count occurrences
        count = content.count(old_text)

        if count == 0:
            return {
                "content": "Error: old_text not found in file. Make sure it matches exactly, including whitespace and indentation.",
                "is_error": True,
            }

        # Perform replacement
        if replace_all:
            new_content = content.replace(old_text, new_text)
            replaced_count = count
        else:
            new_content = content.replace(old_text, new_text, 1)
            replaced_count = 1

        with open(path, "w", encoding="utf-8") as f:
            f.write(new_content)

        return {
            "content": f"Successfully replaced {replaced_count} occurrence(s) in {path}.",
            "is_error": False,
        }

    except PermissionError:
        return {
            "content": f"Error: Permission denied writing to file: {path}",
            "is_error": True,
        }
    except Exception as e:
        return {"content": f"Error editing file: {e}", "is_error": True}


def execute_write_file(args: dict) -> dict:
    """Create or overwrite a file with the given content."""
    path = args.get("path", "")
    content = args.get("content", "")
    create_dirs = args.get("create_dirs", True)

    if not path:
        return {"content": "Error: No file path provided.", "is_error": True}

    path = os.path.expanduser(path)

    if not os.path.isabs(path):
        path = os.path.abspath(path)

    if os.path.isdir(path):
        return {
            "content": f"Error: Path is a directory, not a file: {path}",
            "is_error": True,
        }

    try:
        # Create parent directories if needed
        parent = os.path.dirname(path)
        if create_dirs and parent and not os.path.exists(parent):
            os.makedirs(parent, exist_ok=True)

        existed = os.path.exists(path)

        with open(path, "w", encoding="utf-8") as f:
            f.write(content)

        line_count = content.count("\n") + (
            1 if content and not content.endswith("\n") else 0
        )
        action = "Overwrote" if existed else "Created"
        return {
            "content": f"{action} {path} ({line_count} lines, {len(content)} bytes).",
            "is_error": False,
        }

    except PermissionError:
        return {
            "content": f"Error: Permission denied writing to: {path}",
            "is_error": True,
        }
    except Exception as e:
        return {"content": f"Error writing file: {e}", "is_error": True}


# Central Registry
TOOL_REGISTRY = {
    "xonsh": {"spec": XONSH_TOOL, "fn": execute_xonsh},
    "memory_search": {"spec": MEMORY_SEARCH_TOOL, "fn": execute_memory_search},
    "memory_add": {"spec": MEMORY_ADD_TOOL, "fn": execute_memory_add},
    "web_search": {"spec": WEB_SEARCH_TOOL, "fn": execute_web_search},
    "read_webpage": {"spec": READ_WEBPAGE_TOOL, "fn": execute_read_webpage},
    "read_file": {"spec": READ_FILE_TOOL, "fn": execute_read_file},
    "edit_file": {"spec": EDIT_FILE_TOOL, "fn": execute_edit_file},
    "write_file": {"spec": WRITE_FILE_TOOL, "fn": execute_write_file},
}
