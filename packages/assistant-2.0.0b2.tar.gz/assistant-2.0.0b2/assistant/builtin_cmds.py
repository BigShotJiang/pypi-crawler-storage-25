"""Implements a simple echo command for xonsh."""

from rich.markdown import Markdown
from xonsh.built_ins import XSH
from xonsh.tools import unthreadable

# TODO: fix built in not loaded in assistant shell or command mode


def echo(args, stdin, stdout, stderr, env):
    """A simple echo command."""
    opts = _echo_parse_args(args)
    if opts is None:
        return
    if opts["help"]:
        print(ECHO_HELP, file=stdout)
        return 0
    ender = opts["end"]
    args = map(str, args)
    if opts["escapes"]:
        args = map(lambda x: x.encode().decode("unicode_escape"), args)
    print(*args, end=ender, file=stdout)
    return 0, None


def _echo_parse_args(args):
    out = {"escapes": False, "end": "\n", "help": False}
    if "-e" in args:
        args.remove("-e")
        out["escapes"] = True
    if "-E" in args:
        args.remove("-E")
        out["escapes"] = False
    if "-n" in args:
        args.remove("-n")
        out["end"] = ""
    if "-h" in args or "--help" in args:
        out["help"] = True
    return out


ECHO_HELP = """Usage: echo [OPTIONS]... [STRING]...
Echo the STRING(s) to standard output.
  -n             do not include the trailing newline
  -e             enable interpretation of backslash escapes
  -E             disable interpretation of backslash escapes (default)
  -h  --help     display this message and exit
This version of echo was written in Python for the xonsh project: http://xon.sh
Based on echo from GNU coreutils: http://www.gnu.org/software/coreutils/"""

"""A pwd implementation for xonsh."""
import os


def pwd(args, stdin, stdout, stderr, env):
    """A pwd implementation"""
    e = env["PWD"]
    if "-h" in args or "--help" in args:
        print(PWD_HELP, file=stdout)
        return 0
    if "-P" in args:
        e = os.path.realpath(e)
    print(e, file=stdout)
    return 0, None


PWD_HELP = """Usage: pwd [OPTION]...
Print the full filename of the current working directory.
  -P, --physical   avoid all symlinks
      --help       display this help and exit
This version of pwd was written in Python for the xonsh project: http://xon.sh
Based on pwd from GNU coreutils: http://www.gnu.org/software/coreutils/"""


def echo_fn(args, stdin=None):
    """Echo the STRING(s) to standard output."""
    if args is None:
        args = []
    if "-h" in args or "--help" in args:
        print(ECHO_HELP)
        return 0
    ender = "\n"
    if "-n" in args:
        args.remove("-n")
        ender = ""
    print(*args, end=ender)
    return 0


def pwd_fn(args, stdin=None):
    """Print the full filename of the current working directory."""
    if args is None:
        args = []
    if "-h" in args or "--help" in args:
        print(PWD_HELP)
        return 0
    if "-P" in args:
        print(os.path.realpath(os.getcwd()))
    else:
        print(os.getcwd())
    return 0


def assistant_fn(args, stdin=None):
    import subprocess

    shell = XSH.shell.shell

    if args is None:
        args = []

    if args and args[0] in ("-h", "--help", "help"):
        output = """# Help for the `assistant` command
```text
Usage: assistant [SUBCOMMAND]
Direct assistant commands:
  -h, --help      Show this help
  version         Show version
```
"""
        shell.log_response(Markdown(output))
        return 0

    if args and args[0] in ("version", "--version"):
        from assistant import __version__

        shell.log_response(Markdown(f"Assistant version {__version__}"))
        return 0

    response = None
    if not args:
        response = shell.kernel_interface.assistant("Assistant?")

    if response is None and args is not None:
        response = shell.kernel_interface.assistant("assistant " + " ".join(args))

    if response:
        shell.log_response(Markdown(response))
    return 0


# @unthreadable
def listen_fn(args, stdin=None):
    """Listen for assistant: listen only one sentence by default
    You can type listen to listen for one sentence.
    To listen continuously, type listen start (or stop to stop).
    """
    shell = XSH.shell.shell
    if args is None:
        args = []
    if args:
        if args[0] == "-h" or args[0] == "--help":
            output = """# Help for the `listen` command
```text
Usage: `listen [OPTIONS]... [INT]...`
Listen for one sentence by default.
You can type listen to listen for one sentence.
To listen continuously, type `listen start` (or `stop` to stop).
You can also specify the number of sentences to listen for.
```
"""
            shell.log_response(Markdown(output))
            return 0

        if not shell.kernel_interface.is_asr:
            output = """# Module Not Found Error
To speak with Assistant, you need to install the listen module.

Run the following command:
```shell
pip install -r stt-listen
```
"""
            shell.log_response(Markdown(output))
            return 0

        if not shell.kernel_interface.listen_interface.is_asr_server_up():
            output = """# Connection Error
Could not reach the Automatic Speech Recognition Server.

Please make sure it is up and running and that it is listening on the right port on localhost.

To start the server, run the following command (outside of Assistant in a separate process):

```shell
uvicorn listen.Wav2Vec.as_service:app --port 5063
```
"""
            shell.log_response(Markdown(output))
            return 0

        try:
            if args[0] == "start":
                try:
                    shell.start_listening()
                except (KeyboardInterrupt, EOFError):
                    shell.stop_listening()
                    return 0
                return 0
            elif args[0] == "stop":
                shell.stop_listening()
                shell.log_response(Markdown("# Stopped listening"))
                return 0
            else:
                n = int(args[0])
                shell.log_response(Markdown(f"Listening for {n} sentences..."))
                return 0
        except ValueError:
            shell.log_response(Markdown("Usage: `listen [OPTIONS]... [INT]...`"))
            return 0
    else:
        if not shell.kernel_interface.is_asr:
            output = """# Module Not Found Error
To speak with Assistant, you need to install the listen module.

Run the following command:
```shell
pip install -r stt-listen
```
"""
            shell.log_response(Markdown(output))
            return 0
        if not shell.kernel_interface.listen_interface.is_asr_server_up():
            output = """# Connection Error
Could not reach the Automatic Speech Recognition Server.

Please make sure it is up and running and that it is listening on the right port on localhost.

To start the server, run the following command (outside of Assistant in a separate process):

```shell
uvicorn listen.Wav2Vec.as_service:app --port 5063
```
"""
            shell.log_response(Markdown(output))
            return 0
        shell.kernel_interface.spinner.text = "Listening..."
        shell.kernel_interface.spinner.start()
        query = shell.kernel_interface.listen_interface.listen()
        shell.kernel_interface.spinner.stop()
        shell.kernel_interface.spinner.info("Stopped listening.")
        if query:
            shell.log_query(Markdown(f"> {query}"))
            answer = shell.kernel_interface.session_assistant(query)
            if answer:
                shell.say(answer)
            else:
                shell.log_response(Markdown("Assistant failed to reply."))
        else:
            shell.log_response(Markdown(f"# Nothing heard\nTranscript: '{query}'"))
    return 0


def say_fn(args, stdin=None):
    """say something"""
    shell = XSH.shell.shell
    if args is None:
        args = []
    if args:
        if args[0] == "-h" or args[0] == "--help":
            output = """# Help for the `say` command
```text
Usage: `say [OPTIONS]... [STRING]...`
Say something.

Options:

stop: stop speaking
```
"""
            shell.log_response(Markdown(output))
            return 0
        elif args[0] == "stop":
            shell.stop_speaking()
            shell.log_response(Markdown("stop"))
            return 0
        else:
            shell.say(" ".join(args))
            return 0
    else:
        shell.log_response(Markdown("Usage: `say [OPTIONS]... [STRING]...`"))
        return 1


def memory_fn(args, stdin=None):
    """Interact with assistant memory."""
    from assistant.memory import memory

    shell = XSH.shell.shell

    if args is None:
        args = []

    if not args or args[0] == "list":
        memories = memory.get_all()
        if not memories:
            shell.log_response(Markdown("No memories stored."))
        else:
            n = min(len(memories), 10)
            lines = [f"Last {n} memories (of {len(memories)} total):\n"]
            for i, mem in enumerate(memories[-n:], 1):
                display = mem[:120] + "..." if len(mem) > 120 else mem
                lines.append(f"  {i}. {display}\n")
            shell.log_response(Markdown("\n".join(lines)))
        return 0

    subcmd = args[0]

    if subcmd in ("-h", "--help", "help"):
        shell.log_response(Markdown(MEMORY_HELP))
        return 0
    elif subcmd == "search":
        if len(args) < 2:
            shell.log_response(Markdown("Usage: memory search <query>"))
            return 1
        query = " ".join(args[1:])
        results = memory.search(query=query, limit=5)
        entries = results.get("results", [])
        if not entries:
            shell.log_response(Markdown("No matching memories found."))
        else:
            lines = [f"Found {len(entries)} matching memories:\n"]
            for i, entry in enumerate(entries, 1):
                mem = entry.get("memory", "")
                display = mem[:120] + "..." if len(mem) > 120 else mem
                lines.append(f"  {i}. {display}\n")
            shell.log_response(Markdown("\n".join(lines)))
        return 0
    elif subcmd == "add":
        if len(args) < 2:
            shell.log_response(Markdown("Usage: memory add <text>"))
            return 1
        text = " ".join(args[1:])
        import json

        filepath = memory.filepath
        try:
            data = json.loads(filepath.read_text())
        except Exception:
            data = []
        data.append(f"user: {text}")
        if len(data) > 100:
            data = data[-100:]
        filepath.write_text(json.dumps(data, indent=2))
        shell.log_response(Markdown(f"Memory added: {text}"))
        return 0
    elif subcmd == "count":
        shell.log_response(Markdown(f"Total memories: {memory.count()}"))
        return 0
    elif subcmd == "clear":
        memory.clear()
        shell.log_response(Markdown("All memories cleared."))
        return 0
    else:
        shell.log_response(Markdown(f"Unknown subcommand: {subcmd}\n\n{MEMORY_HELP}"))
        return 1


MEMORY_HELP = """Usage: memory [SUBCOMMAND]

Subcommands:
  list           Show recent memories (default)
  search <query> Search memories
  add <text>     Add a memory manually
  count          Show total memory count
  clear          Clear all memories
  help           Show this help"""


def config_fn(args, stdin=None):
    """Run the configuration wizard."""
    from assistant.setup_wizard import run_setup_wizard

    shell = XSH.shell.shell
    if args is None:
        args = []

    if args and args[0] in ("-h", "--help", "help"):
        output = """# Help for the `config` command
```text
Usage: `config [PATH]`
Run the interactive configuration wizard to manage:
  - Providers (add/edit/remove)
  - Models (add/edit/remove)
  - Agents (create/edit/disable)
  - Web search settings
  - Execution settings

Arguments:
  PATH    Optional path to config file (default: ~/.assistant/config.toml)
```
"""
        shell.log_response(Markdown(output))
        return 0

    config_path = None
    if args and not args[0].startswith("-"):
        config_path = args[0]

    run_setup_wizard(config_path)
    return 0


def help_fn(args, stdin=None):
    """Show available built-in commands."""
    shell = XSH.shell.shell
    if args is None:
        args = []

    if args and args[0] in BUILTIN_COMMANDS:
        cmd = BUILTIN_COMMANDS[args[0]]
        output = f"  {args[0]:12s} {cmd['description']}"
        if cmd.get("usage"):
            output += f"\n\n{cmd['usage']}"
        shell.log_response(Markdown(output))
        return 0

    lines = ["Available built-in commands:\n"]
    for name, info in BUILTIN_COMMANDS.items():
        lines.append(f"  {name:12s} {info['description']}")
    lines.append("\nType 'help <command>' for detailed usage.")
    lines.append("Natural language queries are processed by the AI agent.")
    shell.log_response(Markdown("\n".join(lines)))
    return 0


def reset_fn(args, stdin=None):
    """Reset the agent conversation context."""
    shell = XSH.shell.shell
    try:
        client = shell.kernel_interface.agent_client
        client.reset()
        shell.log_response(Markdown("Conversation context has been reset."))
    except Exception as e:
        shell.log_response(Markdown(f"Error resetting context: {e}"))
    return 0


BUILTIN_COMMANDS = {
    "help": {
        "fn": help_fn,
        "description": "Show available commands",
        "usage": "Usage: help [command]",
    },
    "config": {
        "fn": config_fn,
        "description": "Run the configuration wizard",
        "usage": "Usage: config",
    },
    "memory": {
        "fn": memory_fn,
        "description": "Interact with assistant memory (list/search/add/clear/count)",
        "usage": MEMORY_HELP,
    },
    "reset": {
        "fn": reset_fn,
        "description": "Reset the agent conversation context",
        "usage": "Usage: reset",
    },
    "assistant": {
        "fn": assistant_fn,
        "description": "Direct assistant commands (start/stop/restart services, etc.)",
        "usage": "Usage: assistant [SUBCOMMAND]",
    },
    "listen": {
        "fn": listen_fn,
        "description": "Listen for speech input (requires ASR module)",
        "usage": "Usage: listen [start|stop|INT]",
    },
    "say": {
        "fn": say_fn,
        "description": "Text-to-speech output (requires TTS module)",
        "usage": "Usage: say [stop|STRING...]",
    },
    "exit": {
        "fn": None,
        "description": "Exit the shell",
        "usage": "Usage: exit",
    },
    "clear": {
        "fn": None,
        "description": "Clear the screen",
        "usage": "Usage: clear",
    },
    "echo": {
        "fn": echo_fn,
        "description": "Echo the STRING(s) to standard output",
        "usage": ECHO_HELP,
    },
    "pwd": {
        "fn": pwd_fn,
        "description": "Print the current working directory",
        "usage": PWD_HELP,
    },
}
