# import warnings
# warnings.filterwarnings("ignore", category=DeprecationWarning, module="prompt_toolkit.eventloop.utils", lineno=118)

from symtable import Symbol
import os, sys, re
import time
import xonsh.tools as xt
import subprocess
import threading
import asyncio

from io import StringIO
from contextlib import redirect_stderr, redirect_stdout
from rich.console import Console
from rich.markdown import Markdown
from rich.panel import Panel
from rich.text import Text
from rich.syntax import Syntax
from rich.live import Live

# from prompt_toolkit.auto_suggest import AutoSuggestFromHistory
# from prompt_toolkit.completion import merge_completers
from prompt_toolkit.shortcuts import clear
from prompt_toolkit.key_binding import KeyBindings
from prompt_toolkit.keys import Keys

# from prompt_toolkit.key_binding import KeyBindings
# from prompt_toolkit.filters import Condition
from xonsh.events import events
from xonsh.platform import HAS_PYGMENTS

# from xonsh.jobs import jobs  # removed in newer xonsh
from xonsh.shells.ptk_shell import PromptToolkitShell

# from xonsh.base_shell import Tee  # removed in newer xonsh
from xonsh.built_ins import XSH
from assistant import ASSISTANT_PATH, I18N
from assistant.nlp.interface import AssistantInterface

# from assistant.ptk_shell.completer import AssistantCompleter
# from assistant.ptk_shell.bindings import load_assistant_bindings

# from assistant.nlp.chains.callback_handlers import InputOutputAsyncCallbackHandler  # nlp removed
# from assistant.execer import AssistantExecer
from assistant import codecache

# from assistant.procs.specs import AssistantSubprocSpec
# from assistant.procs.pipelines import AssistantCommandPipeline
from assistant.nlp.exit import exit_please
from assistant.nlp.clear import clear_please
from assistant.builtin_cmds import BUILTIN_COMMANDS


def _get_known_tuis() -> set:
    """Get the set of known TUI commands from config."""
    from assistant.config import get_config

    cfg = get_config()
    return set(cfg.tuis)


class AssistantShell(PromptToolkitShell):
    console = Console()
    error_console = Console(stderr=True, style="bold red")

    def __init__(self, no_intro=False, **kwargs):
        super().__init__(**kwargs)
        callbacks = []
        self.is_listening = False
        self.is_speaking = False
        self.is_debug = bool(
            XSH.env.get(
                "DEBUG",
                True if os.environ.get("DEBUG", "False").lower() == "true" else False,
            )
        )
        self.no_intro = no_intro
        # callbacks.append(InputOutputAsyncCallbackHandler())  # nlp removed
        self.kernel_interface = AssistantInterface(
            verbose=self.is_debug, callbacks=callbacks
        )
        if self.kernel_interface.is_asr:
            self.asr_stop_event = threading.Event()
            self.bg_listen_thread = threading.Thread(
                target=self.listen, args=(self.asr_stop_event,)
            )
        # if self.kernel_interface.is_tts:
        # self.tts_stop_event = threading.Event()
        # self.bg_speak_thread = threading.Thread(target=self.speak, kwargs={"stop_event": self.tts_stop_event})
        self.last_seen = None
        # self.pt_completer = merge_completers([self.pt_completer, AssistantCompleter()]) # TODO: fix https://github.com/xonsh/xonsh//issues/4986
        self.pt_completer = None
        # self.execer = AssistantExecer()
        # self.subproc_spec_cls = AssistantSubprocSpec
        # jobs.pipeline_class = AssistantCommandPipeline  # jobs module removed
        self._register_builtins()

    def _register_builtins(self):
        """Register built-in commands as xonsh aliases for LLM visibility."""
        for name, cmd_info in BUILTIN_COMMANDS.items():
            fn = cmd_info.get("fn")
            if fn is not None:
                XSH.aliases[name] = fn

    def default(self, line, raw_line=None):
        """Implements code execution."""
        line = line if line.endswith("\n") else line + "\n"
        if not self.need_more_lines:  # this is the first line
            if not raw_line:
                self.src_starts_with_space = False
            else:
                self.src_starts_with_space = raw_line[0].isspace()
        try:
            with (
                StringIO() as stdout_buf,
                StringIO() as stderr_buf,
                redirect_stdout(stdout_buf),
                redirect_stderr(stderr_buf),
            ):
                src, code = self.push(line)
                if "SyntaxError" in stderr_buf.getvalue():
                    raise SyntaxError(stderr_buf.getvalue())
        except Exception as e:
            src, code = line, None
            raise e
        if code is None:
            return  # Should probably feed src to LM instead

        events.on_precommand.fire(cmd=src)

        env = XSH.env
        hist = XSH.history  # pylint: disable=no-member
        ts1 = None
        enc = env.get("XONSH_ENCODING")
        err = env.get("XONSH_ENCODING_ERRORS")
        # tee = Tee(encoding=enc, errors=err)  # Tee removed
        ts0 = time.time()
        # Initialize variables that may be skipped by pre-detection
        exc_info = (None, None, None)
        tee_out = ""
        is_pre_detected = False
        try:
            # OS-level fd capture to grab subprocess output
            import tempfile, os, sys, termios

            # Save terminal state BEFORE execution — TUI programs (nvim, vi)
            # modify terminal attributes (raw mode etc.). We compare after.
            try:
                orig_term_attrs = termios.tcgetattr(sys.stdin.fileno())
            except (termios.error, OSError, ValueError):
                orig_term_attrs = None

            needs_interactive = False
            is_pre_detected = False
            # PRE-DETECTION: If it's a well-known TUI, skip the capture phase entirely
            cmd_base = raw_line.strip().split()[0].lower() if raw_line.strip() else ""
            if cmd_base in _get_known_tuis():
                needs_interactive = True
                is_pre_detected = True

            if not needs_interactive:
                with (
                    tempfile.TemporaryFile(mode="w+") as tmp_out,
                    tempfile.TemporaryFile(mode="w+") as tmp_err,
                ):
                    # Save original fds
                    saved_stdout_fd = os.dup(1)
                    saved_stderr_fd = os.dup(2)
                    saved_stdout = sys.stdout
                    saved_stderr = sys.stderr

                    try:
                        # Redirect OS-level fds
                        os.dup2(tmp_out.fileno(), 1)
                        os.dup2(tmp_err.fileno(), 2)

                        # Also redirect Python-level sys.stdout/stderr
                        sys.stdout = os.fdopen(os.dup(1), "w")
                        sys.stderr = os.fdopen(os.dup(2), "w")

                        # Isolate terminal: prevent xonsh from putting the process in the foreground
                        # by masking os.tcsetpgrp, and ensure writes to /dev/tty trigger SIGTTOU (TOSTOP).
                        _orig_tcsetpgrp = os.tcsetpgrp

                        def _mock_tcsetpgrp(fd, pgrp):
                            pass

                        os.tcsetpgrp = _mock_tcsetpgrp

                        try:
                            orig_lflag = orig_term_attrs[3] if orig_term_attrs else 0
                            if orig_term_attrs:
                                attrs = termios.tcgetattr(sys.stdin.fileno())
                                attrs[3] = attrs[3] | termios.TOSTOP
                                termios.tcsetattr(
                                    sys.stdin.fileno(), termios.TCSANOW, attrs
                                )
                        except Exception:
                            pass

                        try:
                            exc_info = codecache.run_compiled_code(
                                code, self.ctx, None, "single"
                            )
                        except NameError as e:
                            # TODO : fix e
                            raise e
                        finally:
                            os.tcsetpgrp = _orig_tcsetpgrp
                            try:
                                if orig_term_attrs:
                                    attrs = termios.tcgetattr(sys.stdin.fileno())
                                    attrs[3] = orig_lflag
                                    termios.tcsetattr(
                                        sys.stdin.fileno(), termios.TCSANOW, attrs
                                    )
                            except Exception:
                                pass

                        sys.stdout.flush()
                        sys.stderr.flush()
                    finally:
                        # Restore Python-level tracking first
                        sys.stdout.close()
                        sys.stderr.close()
                        sys.stdout = saved_stdout
                        sys.stderr = saved_stderr

                        # Restore OS-level fds
                        os.dup2(saved_stdout_fd, 1)
                        os.dup2(saved_stderr_fd, 2)
                        os.close(saved_stdout_fd)
                        os.close(saved_stderr_fd)

                    # Read captured output
                    tmp_out.seek(0)
                    tmp_err.seek(0)
                    _out = tmp_out.read()
                    _err = tmp_err.read()
                    tee_out = _out + _err

            # --- Interactive command detection (3 checks) ---
            if not needs_interactive:
                # 1) Xonsh suspended a child with SIGTTOU/SIGTTIN (e.g. gping, htop)
                _sigttou_m = re.search(
                    r"pid (\d+) was suspended with signal.*SIG(?:TTOU|TTIN)", tee_out
                )
                if _sigttou_m:
                    _suspended_pid = int(_sigttou_m.group(1))
                    import signal as _sig

                    try:
                        os.kill(_suspended_pid, _sig.SIGTERM)
                        time.sleep(0.02)
                        os.kill(_suspended_pid, _sig.SIGKILL)
                    except (ProcessLookupError, PermissionError):
                        pass
                    needs_interactive = True

                # 2) Terminal attributes changed (e.g. nvim/vi set raw mode)
                if not needs_interactive and orig_term_attrs is not None:
                    try:
                        new_term_attrs = termios.tcgetattr(sys.stdin.fileno())
                        if new_term_attrs != orig_term_attrs:
                            # Restore terminal to its original state
                            termios.tcsetattr(
                                sys.stdin.fileno(), termios.TCSAFLUSH, orig_term_attrs
                            )
                            needs_interactive = True
                    except (termios.error, OSError, ValueError):
                        pass

                # 3) Output contains TTY warnings (vim/nvim/less)
                if not needs_interactive:
                    t_lower = tee_out.lower()
                    # Catch English/French "not a terminal" variants
                    if re.search(
                        r"(not to a terminal|pas sur un terminal|inappropriate ioctl|not a terminal|pas un terminal)",
                        t_lower,
                    ):
                        needs_interactive = True
                    # Catch cases where nvim/vim just mentions terminal in an error context
                    elif (
                        t_lower.strip().startswith("vim")
                        or t_lower.strip().startswith("nvim")
                    ) and "terminal" in t_lower:
                        needs_interactive = True
                    # BELT AND SUSPENDERS: If it's a known TUI and it exited suspiciously fast/cleanly, trigger it anyway.
                    else:
                        cmd_base = raw_line.strip().split()[0].lower()
                        if cmd_base in ("vi", "vim", "nvim", "htop", "gping"):
                            needs_interactive = True

            if needs_interactive:
                from assistant.tools import _run_interactive

                # If pre-detected, skip aggressive terminal reset (prevent screen clearing)
                hist.last_cmd_rtn = _run_interactive(
                    raw_line.strip(), reset=(not is_pre_detected)
                )
                # Ensure we don't route to NLP if it was 0, but provide dummy output for history
                tee_out = "[interactive]"

            ts1 = time.time()
            if exc_info != (None, None, None):
                raise exc_info[1]
            if hist is not None and hist.last_cmd_rtn is None:
                hist.last_cmd_rtn = 0  # returncode for success
        except xt.XonshError as e:
            if str(e.args[0]).strip() != "":
                self.log_error(str(e.args[0]).strip())
            if hist is not None and hist.last_cmd_rtn is None:
                hist.last_cmd_rtn = 1  # return code for failure
        except NameError as e:
            raise e
        except (SystemExit, KeyboardInterrupt) as err:
            raise err
        except BaseException:
            import traceback

            traceback.print_exc()
            if hist is not None and hist.last_cmd_rtn is None:
                hist.last_cmd_rtn = 1  # return code for failure
        finally:
            save_to_history = True
            if hist.last_cmd_rtn == 0:
                # Only log tool command/output if it was NOT a pre-detected TUI
                # This prevents showing redunant "Command/Output" panels for vi/nvim.
                if tee_out.strip() != "" and not is_pre_detected:
                    # self.log_tool_command(raw_line.strip())
                    print(tee_out.strip())
            else:
                # t = tee_out.split(": ")
                # if all(
                #     item in t
                #     for item in ["xonsh", "subprocess mode", "command not found"]
                # ):
                #     self._route_to_nlp(raw_line, hist)
                # else:
                self._route_to_nlp(raw_line, hist)
            if save_to_history:
                self._append_history(
                    inp=src,
                    ts=[ts0, ts1],
                    spc=self.src_starts_with_space,
                    tee_out=tee_out,
                    cwd=self.precwd,
                )
            # self.accumulated_inputs += src
            if (
                tee_out
                and env.get("XONSH_APPEND_NEWLINE")
                and not tee_out.endswith(os.linesep)
            ):
                print(os.linesep, end="")
            # tee.close()  # tee removed
            self._fix_cwd()
        if XSH.exit:  # pylint: disable=no-member
            self.set_last_seen()
            if self.kernel_interface.is_asr and self.is_listening:
                self.stop_listening()
            return True

    def is_line_which_builtin(self, line) -> bool:
        llss = line.lower().strip().split()
        builtin_names = list(BUILTIN_COMMANDS.keys()) + ["which", "pwd"]
        return (
            True
            if llss[0] == "which" and len(llss) > 1 and llss[1] in builtin_names
            else False
        )

    def _route_to_nlp(self, raw_line, hist=None):
        """Route input to the NLP agent. Used when xonsh can't parse the input."""
        if not raw_line or not raw_line.strip():
            return
        # if self.kernel_interface.is_nlp_server_up():
        # Accumulator for streaming output
        live_ctx = {"live": None, "chunks": []}

        def _on_event(event):
            etype = event.get("type", "")
            if etype == "status":
                self.kernel_interface.spinner.text = event["text"]
                self.kernel_interface.spinner.start()  # Ensure spinner is visible
            elif etype == "thinking":
                self.kernel_interface.spinner.stop()
                self.log_thinking(event["text"])
                self.kernel_interface.spinner.start()
            elif etype == "tool_command":
                self.kernel_interface.spinner.stop()
                self.log_tool_command(
                    event.get("tool", "unknown"), event["command"], event.get("args")
                )
                # self.kernel_interface.spinner.start()
            elif etype == "tool_output_stream":
                # Live-stream output chunks
                self.kernel_interface.spinner.stop()
                chunk = event.get("chunk", "")
                if chunk:
                    live_ctx["chunks"].append(chunk)
                    output_so_far = "".join(live_ctx["chunks"]).strip()
                    if live_ctx["live"] is None:
                        # self.kernel_interface.spinner.stop()
                        live_ctx["live"] = Live(
                            Panel(
                                Text(output_so_far, style="dim"),
                                title=Text("📤 Output", style="bold green"),
                                border_style="green",
                                padding=(0, 1),
                            ),
                            console=self.console,
                            refresh_per_second=8,
                        )
                        # live_ctx["live"].start()
                    else:
                        live_ctx["live"].update(
                            Panel(
                                Text(output_so_far, style="dim"),
                                title=Text("📤 Output", style="bold green"),
                                border_style="green",
                                padding=(0, 1),
                            )
                        )
            elif etype == "tool_output":
                # Stop live display if active
                self.kernel_interface.spinner.stop()
                if live_ctx["live"] is not None:
                    live_ctx["live"].stop()
                    live_ctx["live"] = None
                    live_ctx["chunks"] = []
                else:
                    # No streaming happened, show static panel
                    self.kernel_interface.spinner.stop()
                    self.log_tool_output(event["output"], event.get("is_error", False))
                # self.kernel_interface.spinner.start()

        self.kernel_interface.spinner.text = "Recalling memories..."
        self.kernel_interface.spinner.start()
        response = self.kernel_interface.assistant(raw_line.strip(), on_event=_on_event)
        self.kernel_interface.spinner.stop()
        # Clean up any lingering live context
        if live_ctx["live"] is not None:
            live_ctx["live"].stop()
        if response and response.strip():
            if hist is not None:
                hist.last_cmd_rtn = 0
            self.say(response.strip())
        # else:
        #     self.log_error(Markdown(f"NLP server is not available."))

    def _try_builtin(self, line):
        """Try to dispatch a built-in command. Returns True if handled."""
        parts = line.strip().split()
        if not parts:
            return False
        cmd_name = parts[0].lower()
        if cmd_name in BUILTIN_COMMANDS:
            cmd_info = BUILTIN_COMMANDS[cmd_name]
            fn = cmd_info.get("fn")
            if fn is not None:
                fn(parts[1:] if len(parts) > 1 else [])
                return True
        return False

    def singleline(
        self, auto_suggest=None, enable_history_search=True, multiline=False, **kwargs
    ):
        """Reads a single line of input from the shell. The store_in_history
        kwarg flags whether the input should be stored in PTK's in-memory
        history.
        """
        events.on_pre_prompt_format.fire()
        env = XSH.env

        if next_command := env.get("XONSH_PROMPT_NEXT_CMD", ""):
            env["XONSH_PROMPT_NEXT_CMD"] = ""

        # mouse_support = env.get("MOUSE_SUPPORT")
        # auto_suggest = auto_suggest if env.get("XONSH_PROMPT_AUTO_SUGGEST") else None
        refresh_interval = env.get("PROMPT_REFRESH_INTERVAL")
        refresh_interval = refresh_interval if refresh_interval > 0 else None
        complete_in_thread = env.get("COMPLETION_IN_THREAD")
        completions_display = env.get("COMPLETIONS_DISPLAY")
        complete_style = self.completion_displays_to_styles[completions_display]

        # complete_while_typing = env.get("UPDATE_COMPLETIONS_ON_KEYPRESS")
        # if complete_while_typing:
        #     # PTK requires history search to be none when completing while typing
        #     enable_history_search = False
        if HAS_PYGMENTS:
            self.styler.style_name = env.get("XONSH_COLOR_STYLE")
        # completer = None if completions_display == "none" else self.pt_completer

        # events.on_timingprobe.fire(name="on_pre_prompt_tokenize")

        # clear prompt level cache
        env["PROMPT_FIELDS"].reset()

        get_bottom_toolbar_tokens = self.bottom_toolbar_tokens
        if env.get("UPDATE_PROMPT_ON_KEYPRESS"):
            get_prompt_tokens = self.prompt_tokens
            get_rprompt_tokens = self.rprompt_tokens
        else:
            get_prompt_tokens = self.prompt_tokens()
            get_rprompt_tokens = self.rprompt_tokens()
            if get_bottom_toolbar_tokens:
                get_bottom_toolbar_tokens = get_bottom_toolbar_tokens()
        events.on_timingprobe.fire(name="on_post_prompt_tokenize")

        # if env.get("VI_MODE"):
        #     editing_mode = EditingMode.VI
        # else:
        #     editing_mode = EditingMode.EMACS

        # if env.get("XONSH_HISTORY_MATCH_ANYWHERE"):
        #     self.prompter.default_buffer._history_matches = MethodType(
        #         _cust_history_matches, self.prompter.default_buffer
        #     )
        # elif (
        #     self.prompter.default_buffer._history_matches
        #     is not self._history_matches_orig
        # ):
        #     self.prompter.default_buffer._history_matches = self._history_matches_orig

        # menu_rows = env.get("COMPLETIONS_MENU_ROWS", None)
        # if menu_rows:
        #     # https://github.com/xonsh/xonsh/pull/4477#pullrequestreview-767982976
        #     menu_rows += 1

        prompt_args = {
            "default": next_command,
            # "mouse_support": mouse_support,
            # "auto_suggest": auto_suggest,
            "message": get_prompt_tokens,
            "rprompt": get_rprompt_tokens,
            "bottom_toolbar": get_bottom_toolbar_tokens,
            # "completer": completer,
            "multiline": multiline,
            # "editing_mode": editing_mode,
            # "prompt_continuation": self.continuation_tokens,
            # "enable_history_search": enable_history_search,
            # "reserve_space_for_menu": menu_rows,
            # "key_bindings": self._key_bindings_merge,
            "complete_style": complete_style,
            # "complete_while_typing": complete_while_typing,
            # "include_default_pygments_style": False,
            "refresh_interval": refresh_interval,
            "complete_in_thread": complete_in_thread,
            "input_processors": None,
        }
        if env["ENABLE_ASYNC_PROMPT"]:
            # once the prompt is done, update it in background as each future is completed
            # prompt_args["pre_run"] = self.prompt_formatter.start_update
            pass
        else:
            for attr, val in self.get_lazy_ptk_kwargs():
                if attr != "key_bindings":
                    prompt_args[attr] = val

        # Use default PTK keybindings

        # If multiline is enabled, PTK3 handles Enter to submit
        # and Shift+Enter for newline (Esc+Enter also submits)
        # This is handled automatically when multiline=True

        cursor_shape = env.get("XONSH_PROMPT_CURSOR_SHAPE")
        if cursor_shape:
            prompt_args["cursor"] = cursor_shape

        events.on_pre_prompt.fire()
        line = self.prompter.prompt(**prompt_args)
        events.on_post_prompt.fire()
        return line

    def cmdloop(self, intro=None):
        """Enters a loop that reads and execute input from user."""
        if intro:
            self.say(intro)

        # Set environment to handle Ctrl+C and Ctrl+D correctly
        env = XSH.env
        env["IGNOREEOF"] = False  # Allow Ctrl+D to exit immediately
        env["XONSH_AUTOPAIR"] = False  # Disable auto-pairing of quotes/brackets

        _paragraph = ""

        while not XSH.exit:
            self.kernel_interface.spinner.stop()
            raw_line = None
            try:
                # Use multiline=False for now (Enter sends immediately)
                # Multiline with Shift+Enter doesn't work reliably in all terminals
                line = self.singleline(auto_suggest=None, multiline=False)
            except EOFError:
                # Ctrl+D was pressed - exit the shell
                XSH.exit = True
                _paragraph = ""
                break
            except KeyboardInterrupt:
                # Ctrl+C was pressed - cancel current line, don't exit
                _paragraph = ""
                continue

            if self.is_debug:
                self.error_console.print(f"[debug] Received line: {repr(line)}")

            if line is None or line == "\x04":
                if self.is_debug:
                    self.error_console.print("[debug] Exiting on EOF condition")
                break

            if line.strip() == "":
                if _paragraph:
                    _paragraph += "\n"
                continue  # Empty enter, just show a new prompt

            if any(
                [
                    line.strip().endswith("\\"),
                    line.strip().endswith("\\n"),
                ]
            ):
                _paragraph += line + "\n"
                continue

            if _paragraph:
                line = _paragraph + line
                _paragraph = ""

            try:
                if line.lower() in exit_please:
                    XSH.exit = True
                elif line.lower() in clear_please:
                    clear()
                    self.kernel_interface.agent_client.clear_context()
                elif self.is_line_which_builtin(line):
                    self.log_response(Markdown(f"Using builtin function."))
                elif self._try_builtin(line):
                    pass  # Builtin command was executed
                else:
                    # Looks like a shell/code command — go through xonsh
                    raw_line = line
                    line = self.precmd(line)
                    try:
                        self.default(line, raw_line)
                    except (Exception, SyntaxError, NameError):
                        # Natural language — route directly to NLP, skip xonsh parser
                        self._route_to_nlp(line)
            except SystemExit:
                # Exit command was called
                XSH.exit = True
                break
            except KeyboardInterrupt:
                # self.reset_buffer()
                # self.log_error(
                #     Markdown(
                #         "# KeyboardInterrupt\n[Ctrl] + [C]: cannot be used to exit a shell.\n\nTry to ask nicely with exit or be rude: [Ctrl] + [D]"
                #     )
                # )
                continue
            except EOFError:
                if XSH.env.get("IGNOREEOF"):
                    print('Use "exit" to leave the shell.', file=sys.stderr)
                else:
                    break
            except (xt.XonshError, xt.XonshCalledProcessError) as xe:
                if XSH.env.get(
                    "DEBUG",
                    (
                        True
                        if os.environ.get("DEBUG", "False").lower() == "true"
                        else False
                    ),
                ):
                    raise xe
                else:
                    self.handle_xonsh_error(xe, raw_line)
            except NameError as ne:
                # Route to NLP — likely natural language input
                if raw_line:  # and self.kernel_interface.is_nlp_server_up():
                    self._route_to_nlp(raw_line)
                elif XSH.env.get(
                    "DEBUG",
                    (
                        True
                        if os.environ.get("DEBUG", "False").lower() == "true"
                        else False
                    ),
                ):
                    raise ne
                else:
                    self.handle_name_error(ne, raw_line)
            except SyntaxError as se:
                # Route to NLP — likely natural language input
                if raw_line:  # and self.kernel_interface.is_nlp_server_up():
                    self._route_to_nlp(raw_line)
                elif XSH.env.get(
                    "DEBUG",
                    (
                        True
                        if os.environ.get("DEBUG", "False").lower() == "true"
                        else False
                    ),
                ):
                    raise se
                else:
                    self.handle_syntax_error(se, raw_line)
            except Exception as e:
                if XSH.env.get(
                    "DEBUG",
                    (
                        True
                        if os.environ.get("DEBUG", "False").lower() == "true"
                        else False
                    ),
                ):
                    raise e
                else:
                    _e = f"""{type(e).__name__}: {str(e)}"""
                    self.handle_other_exceptions(_e, raw_line)

    def set_last_seen(self):
        last_seen_file = os.path.join(ASSISTANT_PATH, "history", ".last_seen")
        try:
            os.mkdir(os.path.join(ASSISTANT_PATH, "history"))
        except FileExistsError:
            pass
        with open(last_seen_file, "w") as f:
            f.write(subprocess.check_output(["date"]).decode("utf-8").strip())

    def _get_term_width(self):
        """Get terminal width, with a sensible fallback."""
        try:
            return os.get_terminal_size().columns
        except OSError:
            return 80

    def _print_separator(self, label, color):
        """Print a labeled separator line: 'Label ────────────────'"""
        width = self._get_term_width()
        max_label = width - 12  # Keep at least some rule chars
        if len(label) > max_label:
            label = label[: max_label - 1] + "…"
        rule_len = max(width - len(label) - 2, 4)
        line = f"{label} {'─' * rule_len}"
        self.console.print(Text(line, style=f"bold {color}"))

    def _print_rule(self, color):
        """Print a closing separator line."""
        width = self._get_term_width()
        self.console.print(Text("─" * width, style=f"dim {color}"))

    def log_query(self, query):
        self._print_separator("Query", "blue")
        self.console.print(Text(query, style="italic blue"))
        self._print_rule("blue")

    def log_response(self, response):
        self._print_separator("Assistant", "cyan")
        if isinstance(response, str):
            response = Markdown(response)
        self.console.print(response)
        self._print_rule("cyan")

    def log_thinking(self, text):
        """Display agent's inner thoughts in a dim Panel."""
        panel = Panel(
            Text(text, style="dim italic"),
            title=Text("💭 Thinking", style="dim bold"),
            border_style="dim",
            padding=(0, 1),
        )
        self.console.print(panel)

    def log_tool_command(self, tool_name, command, args=None):
        """Display the command/code being executed in a syntax-highlighted Panel."""
        cmd_display = command.strip()

        title_text = "⚙ Command"
        style = "yellow"

        if tool_name == "xonsh":
            title_text = "⚙ Shell"
            style = "yellow"
        elif tool_name == "web_search":
            title_text = "🔍 Web Search"
            style = "blue"
        elif tool_name in ("memory_search", "memory_add"):
            title_text = "🧠 Memory"
            style = "magenta"
        elif tool_name.startswith("transfer_to_"):
            target = tool_name.replace("transfer_to_", "")
            title_text = f"🔀 Handoff → {target}"
            style = "cyan"

        try:
            if tool_name == "xonsh":
                content = Syntax(
                    cmd_display,
                    "python",
                    theme="monokai",
                    line_numbers=False,
                    word_wrap=True,
                )
            else:
                content = Text(cmd_display, style="bold")
        except Exception:
            content = Text(cmd_display, style="bold")

        panel = Panel(
            content,
            title=Text(title_text, style=f"bold {style}"),
            border_style=style,
            padding=(0, 1),
        )
        self.console.print(panel)

    def log_tool_output(self, output, is_error=False):
        """Display tool execution output in a Rich Panel."""
        border = "red" if is_error else "green"
        title_style = "bold red" if is_error else "bold green"
        title_text = "❌ Error" if is_error else "📤 Output"
        content = (
            Text(output.strip(), style="dim")
            if output and output.strip()
            else Text("(no output)", style="dim italic")
        )
        panel = Panel(
            content,
            title=Text(title_text, style=title_style),
            border_style=border,
            padding=(0, 1),
        )
        self.console.print(panel)

    # def speak(self, sentence: str | list[str], stop_event: threading.Event):
    #     is_tts = self.kernel_interface.is_tts
    #     if isinstance(sentence, str):
    #         sentence = sentence.split("\n")

    #     for sentence in sentence:
    #         if is_tts and not stop_event.is_set():
    #             # self.kernel_interface.spinner.info("Speaking...")
    #             self.is_speaking = True
    #             self.kernel_interface.say(sentence)
    #             self.is_speaking = False
    #             # self.kernel_interface.spinner.info("Stopped speaking.")
    #         self.log_response(Markdown(sentence))

    def say(self, response: str | list[str]):
        if isinstance(response, str):
            response = response.split("\n")

        # self.bg_speak_thread.daemon = True
        # self.bg_speak_thread = threading.Thread(target=self.speak, kwargs={"sentence": response, "stop_event": self.tts_stop_event})
        # self.bg_speak_thread.start()
        # self.bg_speak_thread.join()
        is_tts = self.kernel_interface.is_tts

        if not is_tts:
            self.log_response(Markdown("\n".join(response)))
            return

        try:
            for sentence in response:
                self.kernel_interface.spinner.stop()
                self.log_response(Markdown(sentence))
                time.sleep(0.01)
                self.kernel_interface.spinner.text = (
                    "Synthesizing speech... (Press [Ctrl] + [C] to stop)"
                )
                self.kernel_interface.spinner.start()
                self.is_speaking = True
                for (
                    _sentence
                ) in self.kernel_interface.say_interface.engine.split_sentences(
                    sentence
                ):
                    # self.log_response(Markdown(_sentence))

                    try:
                        asyncio.run(
                            self.kernel_interface.say_interface.engine.tts(
                                _sentence,
                                language=(
                                    "EN-NEWEST"
                                    if I18N.lower() == "en"
                                    else I18N.upper()
                                ),
                                speaker=(
                                    "en-newest"
                                    if I18N.lower() == "en"
                                    else I18N.lower()
                                ),
                                style_wav=f"{self.kernel_interface.say_interface.engine.config['tts']['speaker_wav']}",
                                save_output=False,
                            )
                        )
                    except (ConnectionRefusedError, OSError):
                        pass  # Server is not active or something
                    except Exception as tts_e:
                        raise tts_e
                    self.kernel_interface.spinner.text = (
                        "Speaking... (Press [Ctrl] + [C] to stop)"
                    )

                try:
                    self.kernel_interface.say_interface.engine.playback_engine.wait_done()
                except KeyboardInterrupt:
                    self.kernel_interface.spinner.stop()
                    self.kernel_interface.say_interface.engine.playback_engine.stop()
                    break
                # self.kernel_interface.say(sentence)
                self.kernel_interface.spinner.stop()
                self.is_speaking = False
                # self.kernel_interface.spinner.info("Stopped speaking.")
                # self.log_response(Markdown(sentence))
        except KeyboardInterrupt:
            self.kernel_interface.spinner.stop()
            self.kernel_interface.say_interface.engine.playback_engine.stop()
            self.is_speaking = False

    # def stop_speaking(self):
    #     self.tts_stop_event.set()
    #     self.is_speaking = False
    #     try:
    #         self.bg_speak_thread.join(1)
    #         self.tts_stop_event = threading.Event()
    #         self.bg_speak_thread = threading.Thread(target=self.speak, kwargs={"stop_event": self.tts_stop_event})
    #     except Exception:
    #         pass
    #     # self.kernel_interface.spinner.info("Stopped speaking.")
    #     return self.is_speaking

    def log_error(self, error):
        self._print_separator("Error", "red")
        self.error_console.print(error)
        self._print_rule("red")

    def handle_xonsh_error(self, error, raw_line):
        # Handle the NameError here using your LLM or any other logic.
        self.log_error(Markdown(f"# Xonsh\nYou said '{raw_line}' but {error}"))

    def handle_name_error(self, error, raw_line):
        # Handle the NameError here using your LLM or any other logic.
        self.log_error(Markdown(f"# NameError\nYou said '{raw_line}' but {error}"))

    def handle_syntax_error(self, error, raw_line):
        # Handle the SyntaxError here using your LLM or provide guidance.
        self.log_error(Markdown(f"# SyntaxError\nYou said '{raw_line}' but {error}"))

    def handle_other_exceptions(self, error, raw_line):
        # Handle other exceptions as needed using your logic.
        self.log_error(
            Markdown(
                f"# Exception\nYou said '{raw_line}' but assistant raised {error}.\nPlease excuse this inconvenience. You can try to running Assistant using DEBUG=True for more information about this error."
            )
        )

    def listen(self, stop_event):
        while not stop_event.is_set():
            if self.kernel_interface.listen_interface.is_asr_server_up():
                self.kernel_interface.spinner.info("Listening...")
                # It will take time to get the query
                query = self.kernel_interface.listen_interface.listen()
                # Therefor we shall assert stop_event isn't set to proceed
                self.kernel_interface.spinner.info("Stopped listening.")
                if stop_event.is_set():
                    break
                if query:
                    self.log_query(query)
                    answer = self.kernel_interface.assistant(query)
                    if answer:
                        self.say(answer)
                    else:
                        self.log_error(Markdown("Assistant failed to reply."))
                else:
                    self.log_error(Markdown("Nothing heard."))
            else:
                self.log_error(Markdown("ASR Server is not up."))
            if stop_event.is_set():
                break

    def start_listening(self):
        """Start listening for user input.

        Returns:
        bool: True if the listen server is up, False otherwise.
        """
        if not self.kernel_interface.is_asr:
            self.log_error(
                Markdown("#Connection Error\nCould not reach the ASR Server.")
            )
            return False
        self.kernel_interface.spinner.info("Listening continuously...")
        # try:
        #     self.bg_listen_thread.join(1)
        # except Exception:
        #     pass
        # self.asr_stop_event = threading.Event()
        # self.bg_listen_thread = threading.Thread(target=self.listen, args=(self.asr_stop_event,))
        # self.bg_listen_thread.daemon = True
        # self.bg_listen_thread.start()
        should_exit = False
        try:
            while not should_exit:
                self.is_listening = True
                self.kernel_interface.spinner.info("Listening...")
                query = self.kernel_interface.listen_interface.listen()
                self.is_listening = False
                self.kernel_interface.spinner.info("Stopped listening.")
                if query and len(query.split()) > 1:
                    self.log_query(query)
                    time.sleep(
                        0.1
                    )  # just to make sure the query is logged before the spinner starts
                    answer = self.kernel_interface.assistant(query)
                    if answer:
                        self.say(answer)
                    else:
                        self.log_error(Markdown("Assistant failed to reply."))
                else:
                    self.log_error(Markdown("Nothing heard."))
        except (KeyboardInterrupt, EOFError) as end:
            should_exit = True
            self.log_error(Markdown("Stopped listening."))
            raise end
        except Exception as e:
            should_exit = True
            self.log_error(Markdown("Assistant failed to reply."))
            if XSH.env.get(
                "DEBUG",
                True if os.environ.get("DEBUG", "False").lower() == "true" else False,
            ):
                raise e

        self.is_listening = False
        self.kernel_interface.spinner.info("Stopped listening.")
        return self.is_listening

    def stop_listening(self):
        self.asr_stop_event.set()
        try:
            self.bg_listen_thread.join(1)
            self.asr_stop_event = threading.Event()
            self.bg_listen_thread = threading.Thread(
                target=self.listen, args=(self.asr_stop_event,)
            )
        except Exception:
            pass
        self.is_listening = False
        self.kernel_interface.spinner.info("Stopped listening.")
        return self.is_listening
