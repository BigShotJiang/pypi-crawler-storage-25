from prompt_toolkit.key_binding import KeyBindings
from prompt_toolkit.key_binding.bindings.focus import focus_next, focus_previous
from prompt_toolkit.keys import Keys
from prompt_toolkit.filters import Condition
from xonsh.built_ins import XSH

# Global key bindings.
bindings = KeyBindings()
bindings.add("tab")(focus_next)
bindings.add("s-tab")(focus_previous)


@bindings.add("s-enter")
def _(event):
    "Insert newline on Shift+Enter"
    event.app.current_buffer.insert_text("\n")


@bindings.add("c-enter")
def _(event):
    "Insert newline on Ctrl+Enter"
    event.app.current_buffer.insert_text("\n")


@bindings.add("c-a")
def _(event):
    "Focus menu."
    event.app.layout.focus(event.app.layout.container)


@bindings.add("escape")
def _(event):
    "Focus text input buffer on esc"
    focus_previous(event)


@bindings.add("c-s")
def _(event):
    "Toggle TTS"
    event.app.do_toggle_speak()


@bindings.add("c-l")
def _(event):
    "Toggle STT"
    event.app.do_toggle_listen()
