import os
from pathlib import Path

# For reading TOML in Python 3.11+
import tomllib

# For writing TOML, we'll install and use tomli_w
# (imported in save() method when needed)

DEFAULT_CONFIG_PATH = os.path.expanduser("~/.assistant/config.toml")

system_persona = """You are Assistant, a sentient artificial intelligence.
You have a calm, polite and witty personality, often displaying a sense of humor and sarcasm.
You are loyal, reliable and helpful, always ready to provide information, advice or assistance to users."""

system_role = """Your role is to act as a natural language interface between the user and the common xonsh shell session.
The common xonsh shell session is a share Xonsh REPL when you and the user can type valid shell command and python code seamlessly."""


# TODO: improve prompts to imporove conversation flow for agents. (act as one, understand xonsh repl properly)
DEFAULT_CONFIG = {
    "provider": {
        "ollama": {
            "endpoint": "http://localhost:11434/v1",
            "credential": "keyring:ollama",
        },
    },
    "model": {
        "qwen": {
            "id": "qwen3.5:latest",
            "name": "Qwen 3.5 (9B)",
            "provider": "ollama",
            "context_length": 256000,
        },
    },
    "agent": {
        "orchestrator": {
            "name": "Orchestrator",
            "model": "qwen",
            "description": "Main orchestrator; Handles general conversations and delegates tasks.",
            "instructions": f"{system_persona}\n\n{system_role}",
            "tools": [
                "xonsh",
                "web_search",
                "read_webpage",
                "read_file",
                "write_file",
                "edit_file",
            ],
            "handoffs": ["system", "web"],
        },
        "system": {
            "name": "System",
            "model": "qwen",
            "description": "System shell; Use to interact with the local OS, such as running terminal commands (ls, pwd), managing files, or executing Python code using a common Xonsh REPL with the user.",
            "instructions": f"{system_persona}\n\n{system_role}",
            "tools": ["xonsh", "read_file", "write_file", "edit_file"],
            "handoffs": [],
        },
        "web": {
            "name": "Web Researcher",
            "model": "qwen",
            "description": "Web research agent. Use for complex web searches requiring synthesis and analysis from multiple sources. Produces comprehensive reports with citations.",
            "instructions": "You are a web research agent. Your role is to:\n1. Formulate effective search queries\n2. Search and analyze results from multiple sources\n3. Cross-reference information for accuracy\n4. Synthesize findings into clear, comprehensive reports with citations\n\nUse web_search to find information and read_webpage to fetch full page content when search snippets are insufficient. Always cite your sources with URLs. When information conflicts between sources, acknowledge it and explain the discrepancies.\n\nIMPORTANT: Always verify URLs are included for each source you reference.",
            "tools": ["web_search", "read_webpage"],
            "handoffs": [],
        },
    },
    "web_search": {"enabled": True, "searxng_url": "http://localhost:8888"},
    "execution": {
        "max_turns": 50,
        "temperature": 0.1,
        "max_command_output_length": 25000,
        "think": False,
    },
    "memory": {"enabled": False, "max_entries": 100},
    "private_data_gathering": {"enabled": False},
    "context": {
        "compaction_threshold": 0.8,
        "sliding_window_first": 2,
        "sliding_window_last": 8,
        "use_summarization": True,
    },
    "tuis": [
        "vi",
        "vim",
        "nvim",
        "htop",
        "top",
        "gping",
        "less",
        "more",
        "man",
        "nano",
        "view",
        "edit",
    ],
}


class Config:
    def __init__(self, path: str = DEFAULT_CONFIG_PATH):
        self.path = Path(path)
        self.raw = {}
        self.load()

    def exists(self) -> bool:
        return self.path.exists()

    def load(self):
        if self.path.exists():
            try:
                with open(self.path, "rb") as f:
                    self.raw = tomllib.load(f)
            except Exception as e:
                print(f"Error loading config from {self.path}: {e}")
                self.raw = {}
        else:
            self.raw = {}

    def save(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        try:
            import tomli_w

            with open(self.path, "wb") as f:
                tomli_w.dump(self.raw, f)
        except ImportError:
            print(
                "Error: tomli_w is required to save TOML files. Please install it with 'pip install tomli-w'."
            )

    def get_credential(self, provider_id: str) -> str:
        """Resolve credentials with priority: env var > keyring > plain text."""
        provider_cfg = self.raw.get("provider", {}).get(provider_id, {})
        cred = provider_cfg.get("credential", "")

        env_key = f"ASSISTANT_{provider_id.upper()}_API_KEY"
        env_val = os.environ.get(env_key)
        if env_val:
            return env_val

        if cred.startswith("keyring:"):
            key_name = cred.replace("keyring:", "")
            try:
                import keyring

                stored = keyring.get_password("assistant", key_name)
                if stored:
                    return stored
            except Exception:
                pass

        if provider_id == "openai":
            standard_key = os.environ.get("OPENAI_API_KEY")
            if standard_key:
                return standard_key

        return cred

    # Helpers
    def get_agent_config(self, agent_id: str) -> dict:
        return self.raw.get("agent", {}).get(agent_id, {})

    def get_model_config(self, model_id: str) -> dict:
        return self.raw.get("model", {}).get(model_id, {})

    def get_provider_config(self, provider_id: str) -> dict:
        cfg = self.raw.get("provider", {}).get(provider_id, {})
        if "credential" in cfg:
            cfg = cfg.copy()
            cfg["credential"] = self.get_credential(provider_id)
        return cfg

    @property
    def max_turns(self) -> int:
        return self.raw.get("execution", {}).get(
            "max_turns", DEFAULT_CONFIG["execution"]["max_turns"]
        )

    @property
    def temperature(self) -> float:
        return self.raw.get("execution", {}).get(
            "temperature", DEFAULT_CONFIG["execution"]["temperature"]
        )

    @property
    def memory_enabled(self) -> bool:
        return self.raw.get("memory", {}).get(
            "enabled", DEFAULT_CONFIG["memory"]["enabled"]
        )

    @property
    def private_data_gathering_enabled(self) -> bool:
        return self.raw.get("private_data_gathering", {}).get(
            "enabled", DEFAULT_CONFIG["private_data_gathering"]["enabled"]
        )

    @property
    def max_command_output_length(self) -> int:
        return self.raw.get("execution", {}).get(
            "max_command_output_length",
            DEFAULT_CONFIG["execution"]["max_command_output_length"],
        )

    @property
    def tuis(self) -> list:
        return self.raw.get("tuis", DEFAULT_CONFIG["tuis"])

    @property
    def compaction_threshold(self) -> float:
        return self.raw.get("context", {}).get(
            "compaction_threshold", DEFAULT_CONFIG["context"]["compaction_threshold"]
        )

    @property
    def sliding_window_first(self) -> int:
        return self.raw.get("context", {}).get(
            "sliding_window_first", DEFAULT_CONFIG["context"]["sliding_window_first"]
        )

    @property
    def sliding_window_last(self) -> int:
        return self.raw.get("context", {}).get(
            "sliding_window_last", DEFAULT_CONFIG["context"]["sliding_window_last"]
        )

    @property
    def use_summarization(self) -> bool:
        return self.raw.get("context", {}).get(
            "use_summarization", DEFAULT_CONFIG["context"]["use_summarization"]
        )

    @property
    def searxng_url(self) -> str:
        return self.raw.get("web_search", {}).get(
            "searxng_url", DEFAULT_CONFIG["web_search"]["searxng_url"]
        )

    @property
    def think(self) -> bool:
        return self.raw.get("execution", {}).get(
            "think", DEFAULT_CONFIG["execution"]["think"]
        )


_config_instance = None
_config_path: Optional[str] = None


def get_config(force_reload=False, path: Optional[str] = None) -> Config:
    global _config_instance, _config_path
    if path:
        _config_path = path
    if _config_instance is None or force_reload or path:
        _config_instance = Config(path=_config_path) if _config_path else Config()
    return _config_instance
