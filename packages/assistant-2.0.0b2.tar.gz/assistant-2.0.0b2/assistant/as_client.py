import os
import requests
import json
import builtins
import subprocess

from rich.console import Console

try:
    from assistant.agent import Orchestrator
    from assistant.config import get_config
except ImportError as e:
    Orchestrator = None
    print(f"Warning: Failed to import Orchestrator: {e}")

console = Console()


class AgentClient:
    """
    Client for interacting with the Assistant Agent Service.
    Automatically falls back to local Orchestrator if the service is unreachable.
    """

    def __init__(self, host="0.0.0.0", port=5068):
        self.service_url = f"http://{host}:{port}/api/v1"
        self.orchestrator = None
        self.context = []

        # Check if service is up
        r = None
        try:
            r = requests.get(f"http://{host}:{port}/health", timeout=1)
        except requests.exceptions.RequestException:
            pass

        if r and r.status_code == 200:
            console.print(
                f"[dim]Connected to Assistant Service at {self.service_url}[/dim]"
            )
        else:
            # console.print(
            #     "[dim]Service not found, falling back to local Orchestrator[/dim]"
            # )
            if Orchestrator:
                try:
                    self.orchestrator = Orchestrator()
                except Exception as e:
                    console.print(
                        f"[bold red]Failed to load Orchestrator fallback: {e}[/bold red]"
                    )
            else:
                console.print(
                    "[bold red]Failed to load Orchestrator fallback (ImportError)![/bold red]"
                )

    def chat(self, message: str, user_id: str = "anonymous", on_event=None) -> str:
        if self.orchestrator:
            self.context = self.orchestrator.chat(
                user_input=message,
                user_id=user_id,
                context_messages=self.context,
                on_event=on_event,
            )
            if self.context and self.context[-1].get("role") == "assistant":
                return self.context[-1].get("content", "")
            return ""
        else:
            try:
                payload = {
                    "message": message,
                    "user_id": user_id,
                    "context": self.context,
                }
                r = requests.post(f"{self.service_url}/chat", json=payload)
                if r.status_code == 200:
                    data = r.json()
                    self.context = data.get("context", [])
                    return data.get("message", "")
                else:
                    return f"Error from service: {r.status_code} {r.text}"
            except Exception as e:
                return f"Connection error: {e}"

    def reset(self):
        self.context = []

    def clear_context(self):
        """Clear context and create a new session with compaction."""
        if self.orchestrator and hasattr(self.orchestrator, "reset_session"):
            self.orchestrator.reset_session(context_messages=self.context)
        self.context = []
