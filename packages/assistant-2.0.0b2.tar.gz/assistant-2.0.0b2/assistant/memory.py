import json
from pathlib import Path
from typing import List, Dict, Any


class SimpleJSONMemory:
    """A lightweight persistent memory replacing the heavy mem0ai implementation."""

    def __init__(self, filepath: str = "~/.assistant/memory.json"):
        self.filepath = Path(filepath).expanduser()
        self.filepath.parent.mkdir(parents=True, exist_ok=True)
        if not self.filepath.exists():
            self.filepath.write_text("[]")

    def search(
        self, query: str, user_id: str = "anonymous", limit: int = 5
    ) -> Dict[str, Any]:
        """Search memory by returning the most recent entries."""
        try:
            content = self.filepath.read_text()
            data = json.loads(content) if content else []
            # Keep things simple for immediate startup: return the most recent memories
            memories = data[-limit:] if data else []
            return {"results": [{"memory": m} for m in memories]}
        except Exception as e:
            print(f"Memory parse error: {e}")
            return {"results": []}

    def add(self, messages: List[Dict[str, Any]], user_id: str = "anonymous") -> None:
        """Add the latest user-assistant exchange to memory."""
        try:
            content = self.filepath.read_text()
            data = json.loads(content) if content else []
            if not isinstance(data, list):
                data = []

            # Extract the last few text messages from the list
            exchange = []
            for msg in messages[-3:]:  # At most grab the immediate context
                role = msg.get("role", "unknown")
                content_msg = msg.get("content")
                if content_msg and role in ["user", "assistant"]:
                    exchange.append(f"{role}: {content_msg}")

            if exchange:
                data.append("\n".join(exchange))
                # Keep only last 100 exchanges
                if len(data) > 100:
                    data = data[-100:]
                self.filepath.write_text(json.dumps(data, indent=2))
        except Exception:
            pass

    def get_all(self) -> List[str]:
        """Return all stored memories."""
        try:
            content = self.filepath.read_text()
            data = json.loads(content) if content else []
            return data if isinstance(data, list) else []
        except Exception:
            return []

    def count(self) -> int:
        """Return the number of stored memories."""
        return len(self.get_all())

    def clear(self) -> None:
        """Clear all stored memories."""
        self.filepath.write_text("[]")


# Create a singleton instance to replace the old mem0 memory instance
memory = SimpleJSONMemory()
