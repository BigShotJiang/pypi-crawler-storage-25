"""FastAPI service to host the Orchestrator."""

import os
import uvicorn
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import List, Dict, Any, Optional

from assistant.agent import Orchestrator

app = FastAPI(title="Assistant Agent Service")
orchestrator = Orchestrator()


class ChatRequest(BaseModel):
    message: str
    user_id: str = "anonymous"
    context: Optional[List[Dict[str, Any]]] = None


class ChatResponse(BaseModel):
    message: str
    context: List[Dict[str, Any]]


@app.post("/api/v1/chat", response_model=ChatResponse)
async def chat_endpoint(req: ChatRequest):
    try:
        updated_context = orchestrator.chat(
            user_input=req.message, user_id=req.user_id, context_messages=req.context
        )

        # The last message should be the assistant's reply
        if updated_context and updated_context[-1].get("role") == "assistant":
            reply = updated_context[-1].get("content", "")
        else:
            reply = ""

        return ChatResponse(message=reply, context=updated_context)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/health")
async def health_check():
    return {"status": "ok", "service": "assistant-agent"}


if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5068))
    print(f"Starting Assistant Agent Service on port {port}...")
    uvicorn.run(app, host="0.0.0.0", port=port)
