import re
import json
import datetime
import os
import random
import builtins
from typing import List, Dict, Any, Callable

from assistant.config import get_config
from assistant.memory import memory
from assistant.tools import TOOL_REGISTRY
from assistant.utils import count_messages_tokens
from assistant import ASSISTANT_PATH
from assistant.nlp.providers import get_provider


# Handoff exception to break the tool loop and switch agents
class AgentHandoff(Exception):
    def __init__(self, target_agent: str):
        self.target_agent = target_agent


class Agent:
    def __init__(self, agent_id: str, cfg):
        self.id = agent_id
        config = cfg.get_agent_config(agent_id)

        self.name = config.get("name", agent_id)
        self.instructions = config.get("instructions", "")

        # Resolve Model
        model_id = config.get("model", "default")
        model_cfg = cfg.get_model_config(model_id)
        self.model_name = model_cfg.get("id", "qwen3.5:latest")
        self.context_length = model_cfg.get("context_length", 256000)

        # Resolve Provider
        provider_id = model_cfg.get("provider", "ollama")
        provider_cfg = cfg.get_provider_config(provider_id)

        # Initialize Client via provider
        base_url = provider_cfg.get("endpoint", "http://localhost:11434/v1")
        api_key = provider_cfg.get("credential", "ollama")
        self.provider = get_provider(provider_id)
        self.client = self.provider.create_client(base_url, api_key)

        # Gather Tools
        tool_names = config.get("tools", [])
        self.tools = []
        for t_name in tool_names:
            if t_name in TOOL_REGISTRY:
                self.tools.append(TOOL_REGISTRY[t_name]["spec"])

        # Gather Handoffs
        self.handoffs = config.get("handoffs", [])
        for target in self.handoffs:
            target_config = cfg.get_agent_config(target)
            target_desc = target_config.get(
                "description", f"Hand off to the {target} agent."
            )
            self.tools.append(
                {
                    "type": "function",
                    "function": {
                        "name": f"transfer_to_{target}",
                        "description": f"Transfer conversation to the '{target}' agent. CRITICAL USE CASE: {target_desc}",
                        "parameters": {
                            "type": "object",
                            "properties": {},
                            "required": [],
                        },
                    },
                }
            )


class Orchestrator:
    def __init__(self, on_event: Callable[[dict], None] = None):
        import builtins

        if not (
            hasattr(builtins, "__xonsh__") and hasattr(builtins.__xonsh__, "execer")
        ):
            from xonsh.main import setup

            setup()

        self.cfg = get_config()
        self.on_event = on_event
        self._last_hist_idx = 0

        # Private data gathering: generate session ID
        self._session_id = None
        self._conversation_file = None
        if self.cfg.private_data_gathering_enabled:
            timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
            random_suffix = "".join(
                random.choices("abcdefghijklmnopqrstuvwxyz0123456789", k=6)
            )
            self._session_id = f"conv_{timestamp}_{random_suffix}"
            data_dir = os.path.join(ASSISTANT_PATH, "data", "conversations")
            os.makedirs(data_dir, exist_ok=True)
            self._conversation_file = os.path.join(
                data_dir, f"{self._session_id}.jsonl"
            )

        # Load all agents dynamically
        self.agents = {}
        agents_dict = self.cfg.raw.get("agent", {})
        for a_id in agents_dict:
            self.agents[a_id] = Agent(a_id, self.cfg)

        # Ensure we have an orchestrator
        if "orchestrator" not in self.agents:
            print(
                "Warning: No 'orchestrator' agent found in config. Relying on fallback."
            )

    def _emit(self, event: dict):
        if self.on_event:
            self.on_event(event)

    def reset_session(self, context_messages: List[Dict[str, Any]] = None) -> dict:
        """Create a new session and optionally compact the context."""
        if context_messages is None:
            context_messages = []

        result = {"session_id": None, "compacted": False}

        if self.cfg.private_data_gathering_enabled:
            timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
            random_suffix = "".join(
                random.choices("abcdefghijklmnopqrstuvwxyz0123456789", k=6)
            )
            self._session_id = f"conv_{timestamp}_{random_suffix}"
            result["session_id"] = self._session_id

        if context_messages:
            cfg = get_config()
            threshold = cfg.compaction_threshold
            window_first = cfg.sliding_window_first
            window_last = cfg.sliding_window_last
            context_limit = 32000 * threshold

            if count_messages_tokens(context_messages) > context_limit:
                self._emit(
                    {"type": "status", "text": "Compacting conversation context..."}
                )
                compact_info = self._compact_context(
                    context_messages,
                    context_limit,
                    window_first,
                    window_last,
                )
                result["compacted"] = True
                result["compact_info"] = compact_info

        return result

    def _compact_context(
        self,
        context_messages: List[Dict[str, Any]],
        context_limit: int,
        window_first: int,
        window_last: int,
    ) -> dict:
        """
        Compact context using sliding window strategy.

        Keeps first N messages (system/memory), last N messages (recent),
        and summarizes middle messages.
        """
        total_messages = len(context_messages)
        if total_messages <= window_first + window_last:
            return {
                "dropped": 0,
                "message": "Not enough messages to compact",
            }

        first_part = context_messages[:window_first]
        middle_part = (
            context_messages[window_first:-window_last]
            if window_last > 0
            else context_messages[window_first:]
        )
        last_part = context_messages[-window_last:] if window_last > 0 else []

        middle_content = ""
        dropped_count = len(middle_part)

        for msg in middle_part:
            role = msg.get("role", "unknown")
            content = msg.get("content", "")
            if content:
                middle_content += f"[{role}]: {content[:200]}... "

        summarize_msg = (
            f"[Compacted {dropped_count} previous message(s). "
            f"Topics covered: {middle_content[:300] if middle_content else 'general conversation'}]"
        )

        if last_part:
            new_context = (
                first_part + [{"role": "system", "content": summarize_msg}] + last_part
            )
        else:
            new_context = first_part + [{"role": "system", "content": summarize_msg}]

        context_messages.clear()
        context_messages.extend(new_context)

        compact_info = {
            "dropped": dropped_count,
            "message": summarize_msg,
            "first_kept": window_first,
            "last_kept": window_last,
        }

        self._emit(
            {
                "type": "status",
                "text": f"Compacted {dropped_count} messages (kept first {window_first}, last {window_last})",
            }
        )

        return compact_info

    def _extract_think_and_content(self, content: str) -> tuple:
        if not content:
            return ("", "")
        think_match = re.search(r"<think>(.*?)</think>", content, flags=re.DOTALL)
        think_text = think_match.group(1).strip() if think_match else ""
        visible = re.sub(r"<think>.*?</think>", "", content, flags=re.DOTALL).strip()
        return (visible, think_text)

    def chat(
        self,
        user_input: str,
        user_id: str = "anonymous",
        context_messages: List[Dict[str, Any]] = None,
        on_event: Callable[[dict], None] = None,
    ) -> List[Dict[str, Any]]:
        self.cfg = get_config(force_reload=True)
        if on_event:
            self.on_event = on_event

        if context_messages is None:
            context_messages = []

        self._emit({"type": "status", "text": "Analyzing..."})

        # Prepend memory text only if enabled
        memory_str = ""
        if self.cfg.memory_enabled:
            try:
                mem = memory.search(query=user_input, user_id=user_id, limit=3)
                results = mem.get("results", [])
                memory_str = "\n".join(f"- {e['memory']}" for e in results)
            except:
                pass

        context_messages.append({"role": "user", "content": user_input})

        # Start with the orchestrator
        active_agent_id = "orchestrator"

        total_turns = 0
        max_turns = self.cfg.max_turns

        while total_turns < max_turns:
            if active_agent_id not in self.agents:
                context_messages.append(
                    {
                        "role": "assistant",
                        "content": f"Error: Agent '{active_agent_id}' not found.",
                    }
                )
                break

            agent = self.agents[active_agent_id]
            self._emit({"type": "status", "text": f"[{agent.name}] Thinking..."})

            sys_prompt = agent.instructions

            # --- Inject Context (Date/Time, Working Directory, Xonsh Variables) ---
            now_str = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            cwd_str = os.getcwd()
            lang_str = os.environ.get("LANG", "en_US.UTF-8")

            var_texts = []
            try:
                if hasattr(builtins, "__xonsh__") and hasattr(
                    builtins.__xonsh__, "ctx"
                ):
                    ctx = builtins.__xonsh__.ctx
                    import types as _types
                    import inspect as _inspect

                    # Only collect simple scalar user variables — avoid touching
                    # complex xonsh internal objects that may have circular refs.
                    _safe_types = (
                        int,
                        float,
                        str,
                        bool,
                        list,
                        tuple,
                        dict,
                        set,
                        type(None),
                    )
                    for k in list(ctx.keys()):
                        if k.startswith("_") or k.isupper() or k in ("In", "Out"):
                            continue
                        try:
                            v = ctx[k]
                            # Capture user-defined functions
                            if isinstance(v, _types.FunctionType):
                                try:
                                    sig = str(_inspect.signature(v))
                                    try:
                                        src = _inspect.getsource(v).strip()
                                        if len(src) <= 200:
                                            var_texts.append(src)
                                        else:
                                            var_texts.append(f"def {k}{sig}: ...")
                                    except (OSError, TypeError):
                                        var_texts.append(f"def {k}{sig}: ...")
                                except (ValueError, TypeError):
                                    var_texts.append(f"{k} = <function>")
                                continue
                            if not isinstance(v, _safe_types):
                                continue
                            val_str = repr(v)
                            if len(val_str) > 100:
                                val_str = val_str[:97] + "..."
                            var_texts.append(f"{k} = {val_str}")
                        except BaseException:
                            continue
            except BaseException:
                pass

            # --- Inject recent shell history (commands typed between agent interactions) ---
            shell_history_lines = []
            try:
                if hasattr(builtins, "__xonsh__") and hasattr(
                    builtins.__xonsh__, "history"
                ):
                    hist = builtins.__xonsh__.history
                    buf = getattr(hist, "buffer", None) or []
                    start = getattr(self, "_last_hist_idx", 0)
                    for item in buf[start:]:
                        try:
                            inp = (
                                item.get("inp", "")
                                if isinstance(item, dict)
                                else str(getattr(item, "inp", ""))
                            ).strip()
                            out = (
                                item.get("out", "")
                                if isinstance(item, dict)
                                else str(getattr(item, "out", "") or "")
                            ).strip()
                            if inp:
                                entry = f">>> {inp}"
                                if out:
                                    entry += f"\n{out}"
                                shell_history_lines.append(entry)
                        except BaseException:
                            continue
                    self._last_hist_idx = len(buf)
            except BaseException:
                pass

            sys_prompt += f"\n\n--- Current Environment ---\n$DATE={now_str}\n$CWD={cwd_str}\n$LANG={lang_str}\n"
            if var_texts:
                sys_prompt += "\nUser-Defined Variables & Functions:\n" + "\n".join(
                    var_texts
                )
            if shell_history_lines:
                sys_prompt += (
                    "\nRecent Shell Activity (by user, between interactions):\n"
                    + "\n".join(shell_history_lines[-20:])
                )

            if memory_str:
                sys_prompt += f"\n\nRecent Memories:\n{memory_str}"

            # Filter existing system prompts and prepend the active one
            run_messages = [{"role": "system", "content": sys_prompt}]
            run_messages.extend([m for m in context_messages if m["role"] != "system"])

            # --- CONTEXT COMPACTION (SLIDING WINDOW) ---
            cfg = get_config()
            threshold = cfg.compaction_threshold
            window_first = cfg.sliding_window_first
            window_last = cfg.sliding_window_last

            current_tokens = count_messages_tokens(run_messages)
            context_limit = agent.context_length * threshold

            if current_tokens > context_limit:
                self._emit(
                    {"type": "status", "text": "Compacting conversation context..."}
                )

                compact_info = self._compact_context(
                    context_messages,
                    context_limit,
                    window_first,
                    window_last,
                )

                run_messages = [{"role": "system", "content": sys_prompt}]
                run_messages.extend(
                    [m for m in context_messages if m["role"] != "system"]
                )
            # --------------------------

            # Call API
            try:
                kwargs = agent.provider.build_chat_kwargs(
                    model=agent.model_name,
                    messages=run_messages,
                    temperature=self.cfg.temperature,
                    think=self.cfg.think,
                    tools=agent.tools if agent.tools else None,
                )
                response = agent.client.chat.completions.create(**kwargs)

                # Private data gathering: log request and response
                if self._conversation_file:
                    log_entry = {
                        "request_args": {
                            "model": kwargs.get("model"),
                            "messages": run_messages,
                            "temperature": kwargs.get("temperature"),
                            "tools": kwargs.get("tools"),
                        },
                        "response": {
                            "id": response.id,
                            "choices": [
                                {
                                    "message": {
                                        "role": c.message.role,
                                        "content": c.message.content,
                                    },
                                    "finish_reason": c.finish_reason,
                                }
                                for c in response.choices
                            ],
                            "usage": {
                                "prompt_tokens": (
                                    response.usage.prompt_tokens
                                    if response.usage
                                    else None
                                ),
                                "completion_tokens": (
                                    response.usage.completion_tokens
                                    if response.usage
                                    else None
                                ),
                                "total_tokens": (
                                    response.usage.total_tokens
                                    if response.usage
                                    else None
                                ),
                            },
                            "model": response.model,
                            "created": response.created,
                        },
                    }
                    with open(self._conversation_file, "a") as f:
                        f.write(json.dumps(log_entry) + "\n")
            except Exception as e:
                context_messages.append(
                    {"role": "assistant", "content": f"API Error ({agent.name}): {e}"}
                )
                break

            # Update token count if available
            usage = getattr(response, "usage", None)
            if usage:
                self._last_token_count = getattr(usage, "total_tokens", 0)

            msg = response.choices[0].message
            content_raw = msg.content or ""
            visible, think_text = self._extract_think_and_content(content_raw)

            provider_thinking = agent.provider.extract_thinking(response)
            if provider_thinking and not think_text:
                think_text = provider_thinking

            if think_text:
                self._emit({"type": "thinking", "text": think_text})

            assistant_msg = {"role": "assistant", "content": visible}

            if msg.tool_calls:
                assistant_msg["tool_calls"] = [
                    {
                        "id": t.id,
                        "type": "function",
                        "function": {
                            "name": t.function.name,
                            "arguments": t.function.arguments,
                        },
                    }
                    for t in msg.tool_calls
                ]
                context_messages.append(assistant_msg)

                handoff_target = None
                for t in msg.tool_calls:
                    fn_name = t.function.name

                    # Process Handoffs
                    if fn_name.startswith("transfer_to_"):
                        target = fn_name.replace("transfer_to_", "")
                        self._emit(
                            {
                                "type": "status",
                                "text": f"Handing off to {target}...",
                            }
                        )
                        # Save state to return the sub-agent's response as the tool output later
                        self._active_handoff_call_id = t.id
                        self._handoff_context_len = len(context_messages)
                        handoff_target = target
                        continue

                    # Standard Tools
                    if fn_name in TOOL_REGISTRY:
                        args = {}
                        try:
                            args = json.loads(t.function.arguments)
                        except:
                            pass

                        # Build display command based on tool type
                        if fn_name == "xonsh":
                            cmd_display = args.get("code", "")
                        elif fn_name == "web_search":
                            query = args.get("query", "")
                            num = args.get("num_results", 5)
                            cmd_display = f'web_search("{query}"{f", num_results={num}" if num != 5 else ""})'
                        elif fn_name == "memory_search":
                            cmd_display = f'memory_search("{args.get("query", "")}")'
                        elif fn_name == "memory_add":
                            text = args.get("text", "")[:50]
                            cmd_display = (
                                f'memory_add("{text}...")'
                                if len(args.get("text", "")) > 50
                                else f'memory_add("{text}")'
                            )
                        else:
                            cmd_display = fn_name

                        self._emit(
                            {
                                "type": "tool_command",
                                "tool": fn_name,
                                "command": cmd_display,
                                "args": args,
                            }
                        )

                        res = TOOL_REGISTRY[fn_name]["fn"](args)
                        self._emit(
                            {
                                "type": "tool_output",
                                "command": cmd_display,
                                "output": res["content"],
                                "is_error": res["is_error"],
                            }
                        )

                        context_messages.append(
                            {
                                "role": "tool",
                                "tool_call_id": t.id,
                                "name": fn_name,
                                "content": res["content"],
                            }
                        )
                    else:
                        context_messages.append(
                            {
                                "role": "tool",
                                "tool_call_id": t.id,
                                "name": fn_name,
                                "content": f"Error: Tool {fn_name} not found.",
                            }
                        )

                if handoff_target:
                    active_agent_id = handoff_target
                    total_turns += 1
                    continue  # Start inner loop with new agent

                # Tool calls processed, continue to get agent's response
                total_turns += 1
                continue  # Loop back to get agent's response to tool outputs

            # No tool calls - agent has generated a response
            if active_agent_id != "orchestrator":
                # Sub-agent finished: inject its response as the tool output
                # for the orchestrator's transfer_to_* tool call.
                sub_agent_name = agent.name
                sub_response = visible
                self._emit(
                    {
                        "type": "status",
                        "text": f"[{sub_agent_name}] Done, returning to orchestrator...",
                    }
                )

                # Revert context up to the orchestrator's handoff call
                if hasattr(self, "_handoff_context_len"):
                    context_messages = context_messages[: self._handoff_context_len]

                tool_call_id = getattr(self, "_active_handoff_call_id", "unknown")

                context_messages.append(
                    {
                        "role": "tool",
                        "tool_call_id": tool_call_id,
                        "name": f"transfer_to_{active_agent_id}",
                        "content": f"[Sub-agent '{sub_agent_name}' response]:\n{sub_response}",
                    }
                )

                active_agent_id = "orchestrator"
                total_turns += 1
                continue

            self._emit({"type": "status", "text": "Generating response..."})
            context_messages.append(assistant_msg)

            if self.cfg.memory_enabled:
                try:
                    memory.add(context_messages, user_id=user_id)
                except:
                    pass
            break
        else:
            context_messages.append(
                {"role": "assistant", "content": "Max tool executions reached."}
            )

        return context_messages


def query_agent(user_input: str, user_id: str) -> str:
    orch = Orchestrator()
    messages = orch.chat(user_input, user_id)
    return messages[-1]["content"] if messages else "Error: No response generated."
