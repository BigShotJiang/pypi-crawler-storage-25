"""Tests for assistant/tools.py execution logic."""

import pytest
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from assistant.tools import (
    _get_first_command,
    _is_complex_bash,
    _get_known_tuis,
    _has_tui_command,
    _is_simple_shell_command,
)


class TestGetFirstCommand:
    """Tests for _get_first_command function."""

    def test_simple_command(self):
        assert _get_first_command("ls") == "ls"
        assert _get_first_command("sensors") == "sensors"
        assert _get_first_command("echo hello") == "echo hello"

    def test_pipe(self):
        assert _get_first_command("sensors | grep temp") == "sensors"
        assert _get_first_command("ls | head -5") == "ls"
        assert _get_first_command("cat file | grep pattern") == "cat file"

    def test_and_chaining(self):
        assert _get_first_command("echo a && echo b") == "echo a"
        assert _get_first_command("make && make install") == "make"

    def test_or_chaining(self):
        assert _get_first_command("sensors || echo fallback") == "sensors"
        assert _get_first_command("cmd1 || cmd2") == "cmd1"

    def test_semicolon(self):
        assert _get_first_command("echo a; echo b") == "echo a"
        assert _get_first_command("ls; pwd") == "ls"

    def test_redirects(self):
        assert _get_first_command("sensors 2>/dev/null") == "sensors 2"
        assert _get_first_command("echo hi > file.txt") == "echo hi"
        assert _get_first_command("cmd >> log.txt") == "cmd"
        assert _get_first_command("cmd 2> error.txt") == "cmd 2"

    def test_complex_with_redirects(self):
        assert _get_first_command("sensors 2>/dev/null || echo fallback") == "sensors 2"
        assert _get_first_command("echo a | cat > file") == "echo a"

    def test_tui_commands(self):
        assert _get_first_command("htop") == "htop"
        assert _get_first_command("top -bn1") == "top -bn1"
        assert _get_first_command("vim file.txt") == "vim file.txt"
        assert _get_first_command("less file.txt") == "less file.txt"

    def test_empty_and_whitespace(self):
        assert _get_first_command("") == ""
        assert _get_first_command("   ") == ""
        assert _get_first_command("\n\n") == ""


class TestIsComplexBash:
    """Tests for _is_complex_bash function."""

    def test_simple_commands(self):
        assert _is_complex_bash("ls") is False
        assert _is_complex_bash("echo hello") is False
        assert _is_complex_bash("sensors | grep temp") is False
        assert _is_complex_bash("cmd1 && cmd2") is False

    def test_if_fi(self):
        assert _is_complex_bash("if true; then echo ok; fi") is True
        assert _is_complex_bash("if command -v sensors; then sensors; fi") is True
        assert _is_complex_bash("if [ -f file ]; then cat file; fi") is True

    def test_for_done(self):
        assert _is_complex_bash("for i in 1 2 3; do echo $i; done") is True
        assert _is_complex_bash("for f in *.txt; do echo $f; done") is True

    def test_while_done(self):
        assert _is_complex_bash("while read line; do echo $line; done") is True

    def test_case_esac(self):
        assert _is_complex_bash("case $var in a) echo a;; esac") is True

    def test_function(self):
        assert _is_complex_bash("function foo { echo bar; }") is True

    def test_multiline(self):
        code = """echo line1
echo line2
echo line3"""
        assert _is_complex_bash(code) is False

    def test_multiline_with_if(self):
        code = '''echo "start"
if command -v sensors; then
    sensors
fi
echo "end"'''
        assert _is_complex_bash(code) is True


class TestKnownTuis:
    """Tests for _get_known_tuis function."""

    def test_contains_expected_tuis(self):
        expected = {
            "vi",
            "vim",
            "nvim",
            "htop",
            "top",
            "gping",
            "less",
            "more",
            "man",
            "nano",
            "view",
            "edit",
        }
        assert _get_known_tuis() == expected

    def test_has_top(self):
        assert "top" in _get_known_tuis()

    def test_has_vim(self):
        assert "vim" in _get_known_tuis()

    def test_has_htop(self):
        assert "htop" in _get_known_tuis()


class TestHasTuiCommand:
    """Tests for _has_tui_command function - detecting TUI in pipes correctly."""

    def test_simple_tui(self):
        assert _has_tui_command("htop") is True
        assert _has_tui_command("vim file.txt") is True
        assert _has_tui_command("less file.txt") is True
        assert _has_tui_command("top") is True

    def test_non_tui_commands(self):
        assert _has_tui_command("ls") is False
        assert _has_tui_command("cat file.txt") is False
        assert _has_tui_command("echo hello") is False
        assert _has_tui_command("grep pattern file") is False

    def test_pipe_to_head(self):
        """cat file | head should NOT be interactive."""
        assert _has_tui_command("cat file.txt | head") is False
        assert _has_tui_command("ls | head -5") is False
        assert _has_tui_command("sensors | head -1") is False
        assert _has_tui_command("cat $f | head") is False

    def test_pipe_to_tail(self):
        """cat file | tail should NOT be interactive."""
        assert _has_tui_command("cat file.txt | tail") is False
        assert _has_tui_command("ls | tail -5") is False
        assert _has_tui_command("cat $f | tail") is False

    def test_pipe_to_grep(self):
        """cat file | grep should NOT be interactive."""
        assert _has_tui_command("cat file.txt | grep pattern") is False
        assert _has_tui_command("ls | grep .py") is False
        assert _has_tui_command("sensors | grep temp") is False

    def test_pipe_to_awk(self):
        """cat file | awk should NOT be interactive."""
        assert _has_tui_command("cat file.txt | awk '{print $1}'") is False
        assert _has_tui_command("echo test | awk '{print $1}'") is False

    def test_pipe_to_sed(self):
        """cat file | sed should NOT be interactive."""
        assert _has_tui_command("cat file.txt | sed 's/foo/bar/'") is False

    def test_pipe_to_less(self):
        """cat file | less SHOULD be interactive."""
        assert _has_tui_command("cat file.txt | less") is True
        assert _has_tui_command("ls | less") is True
        assert _has_tui_command("echo test | less") is True

    def test_pipe_to_more(self):
        """cat file | more SHOULD be interactive."""
        assert _has_tui_command("cat file.txt | more") is True
        assert _has_tui_command("ls | more") is True

    def test_pipe_to_vim(self):
        """echo test | vim SHOULD be interactive."""
        assert _has_tui_command("echo test | vim -") is True
        assert _has_tui_command("cat file.txt | vim -") is True
        assert _has_tui_command("ls | vim -") is True

    def test_pipe_to_man(self):
        """man command SHOULD be interactive."""
        assert _has_tui_command("man ls") is True
        assert _has_tui_command("cat file.txt | man cat") is True

    def test_multiple_pipes(self):
        """Multiple pipes with non-TUI should NOT be interactive."""
        assert _has_tui_command("cat file.txt | grep foo | head") is False
        assert _has_tui_command("ls | grep .py | head -10") is False
        assert _has_tui_command("echo test | grep a | grep b") is False

    def test_multiple_pipes_with_tui(self):
        """Multiple pipes WITH TUI at end SHOULD be interactive."""
        assert _has_tui_command("cat file.txt | grep foo | less") is True
        assert _has_tui_command("ls | grep .py | less") is True
        assert _has_tui_command("echo test | grep a | vim -") is True

    def test_and_chaining(self):
        """&& chaining should not trigger interactive for non-TUI."""
        assert _has_tui_command("ls && echo done") is False
        assert _has_tui_command("cat file && grep pattern") is False
        assert _has_tui_command("make && make install") is False

    def test_and_chaining_with_tui(self):
        """&& chaining with TUI SHOULD be interactive."""
        assert _has_tui_command("ls && vim file.txt") is True
        assert _has_tui_command("echo test && less file.txt") is True

    def test_or_chaining(self):
        """|| chaining should not trigger interactive for non-TUI."""
        assert _has_tui_command("ls || echo failed") is False

    def test_or_chaining_with_tui(self):
        """|| chaining with TUI SHOULD be interactive."""
        assert _has_tui_command("ls || vim file.txt") is True

    def test_tui_with_args(self):
        """TUI with arguments should be detected (except batch mode)."""
        assert _has_tui_command("vim +10 file.txt") is True
        assert _has_tui_command("less +100 file.txt") is True

    def test_empty_and_whitespace(self):
        assert _has_tui_command("") is False
        assert _has_tui_command("   ") is False
        assert _has_tui_command("\n\n") is False


class TestAgentCommonCommands:
    """Tests for common commands run by agents, ensuring they are NOT interactive."""

    def test_system_info(self):
        assert _has_tui_command("sensors") is False
        assert _has_tui_command("nvidia-smi") is False
        assert _has_tui_command("df -h") is False
        assert _has_tui_command("du -sh") is False
        assert _has_tui_command("free -m") is False
        assert _has_tui_command("uname -a") is False
        assert _has_tui_command("uptime") is False
        assert _has_tui_command("lsblk") is False
        assert _has_tui_command("lscpu") is False

    def test_file_reading(self):
        assert _has_tui_command("cat /etc/os-release") is False
        assert _has_tui_command("cat /proc/cpuinfo") is False
        assert _has_tui_command("find . -name '*.py'") is False
        assert _has_tui_command("which python") is False

    def test_network(self):
        assert _has_tui_command("curl -s http://example.com") is False
        assert _has_tui_command("wget -qO- http://example.com") is False
        assert _has_tui_command("ip addr") is False
        assert _has_tui_command("hostname") is False

    def test_python_tools(self):
        assert _has_tui_command("pip list") is False
        assert _has_tui_command("pip show pkg") is False
        assert _has_tui_command("python --version") is False

    def test_coreutils(self):
        assert _has_tui_command("wc -l file") is False
        assert _has_tui_command("sort file") is False
        assert _has_tui_command("uniq file") is False
        
    def test_git(self):
        assert _has_tui_command("git log --oneline -10") is False
        assert _has_tui_command("git status") is False
        assert _has_tui_command("git diff") is False


class TestBatchModeOverride:
    """Test batch mode arguments specific to TUI commands."""

    def test_top_batch(self):
        assert _has_tui_command("top -bn1") is False
        assert _has_tui_command("top -b -n 5") is False
        assert _has_tui_command("top -b") is False
        assert _has_tui_command("top") is True
        assert _has_tui_command("top -d 1") is True


class TestIsSimpleShellCommand:
    """Tests for _is_simple_shell_command function."""

    def test_basic_shell_commands(self):
        assert _is_simple_shell_command("ls") is True
        assert _is_simple_shell_command("ls -la") is True
        assert _is_simple_shell_command("cat /etc/os-release") is True
        assert _is_simple_shell_command("echo hello world") is True
        assert _is_simple_shell_command("pwd") is True
        assert _is_simple_shell_command("whoami") is True

    def test_git_commands(self):
        assert _is_simple_shell_command("git status") is True
        assert _is_simple_shell_command("git diff") is True
        assert _is_simple_shell_command("git diff assistant/tools.py") is True
        assert _is_simple_shell_command("git log --oneline -10") is True
        assert _is_simple_shell_command("git diff HEAD -- file.py") is True

    def test_pipes_and_chains(self):
        assert _is_simple_shell_command("git diff | head -100") is True
        assert _is_simple_shell_command("cat file | grep pattern") is True
        assert _is_simple_shell_command("ls && echo done") is True
        assert _is_simple_shell_command("cmd1 || cmd2") is True

    def test_redirects(self):
        assert _is_simple_shell_command("git diff 2>&1 | head") is True
        assert _is_simple_shell_command("echo hello > /dev/null") is True

    def test_python_code_rejected(self):
        assert _is_simple_shell_command("import os") is False
        assert _is_simple_shell_command("from pathlib import Path") is False
        assert _is_simple_shell_command("print('hello')") is False
        assert _is_simple_shell_command("print (x)") is False
        assert _is_simple_shell_command("def foo():") is False
        assert _is_simple_shell_command("class Foo:") is False
        assert _is_simple_shell_command("return 42") is False
        assert _is_simple_shell_command("x = 42") is False
        assert _is_simple_shell_command("result = subprocess.run(...)") is False

    def test_xonsh_syntax_rejected(self):
        assert _is_simple_shell_command("$(ls)") is False
        assert _is_simple_shell_command("!(git status)") is False
        assert _is_simple_shell_command("@(cmd)") is False
        assert _is_simple_shell_command("${HOME}") is False

    def test_multiline_rejected(self):
        assert _is_simple_shell_command("line1\nline2") is False
        assert _is_simple_shell_command("") is False
        assert _is_simple_shell_command("   ") is False

    def test_env_vars_in_commands(self):
        """Shell commands with VAR=val syntax should be allowed."""
        assert _is_simple_shell_command("GIT_PAGER=cat git diff") is True
        assert _is_simple_shell_command("LANG=C sort file") is True
