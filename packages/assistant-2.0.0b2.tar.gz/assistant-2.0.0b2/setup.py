#!/usr/bin/env python
import setuptools
from assistant import __version__

catchphrase = "Your very own Assistant. Because you deserve it."
fail_catchphrase = "Where am I? Hey! It's me Assistant."

try:
    with open("README.md", "r", encoding="utf-8") as fh:
        long_description = fh.read()
except (IOError, OSError):
    long_description = fail_catchphrase

required_packages = [
    "pygments",
    "xonsh",
    "prompt_toolkit>3.0.36",
    # 'attrs',
    "questionary",
    # 'websockets',
    "colorama",
    "rich",
    "halo",
    "requests",
    "openai",
    "ollama",
    # 'textual',
    # 'requests',
    "tomli-w",
    "tiktoken",
    "keyring",
]

packaged_modules = [
    "assistant",
    "assistant.ptk_shell",
    "assistant.say",
    "assistant.listen",
    "assistant.entry_points",
    "assistant.procs",
    "assistant.nlp",
    "assistant.nlp.providers",
]

setuptools.setup(
    name="assistant",
    version=__version__,
    license="MIT",
    author="Danny Waser",
    author_email="danny@waser.tech",
    description=catchphrase,
    long_description=long_description,
    long_description_content_type="text/markdown",
    python_requires=">=3.8,<4",
    install_requires=required_packages,
    packages=packaged_modules,
    # package_dir={"xontrib": "xontrib"},
    # package_data={"xontrib": ["*.xsh"]},
    platforms="any",
    entry_points={
        "console_scripts": [
            "assistant = assistant.entry_points.run_assistant:run",
            # 'manager = assistant.manager.__main__:run'
        ]
    },
    url="https://gitlab.com/waser-technologies/technologies/assistant",
    project_urls={
        "Documentation": "https://gitlab.com/waser-technologies/technologies/assistant/blob/master/README.md",
        "Code": "https://gitlab.com/waser-technologies/technologies/assistant",
        "Issue tracker": "https://gitlab.com/waser-technologies/technologies/assistant/issues",
    },
    classifiers=[
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Natural Language :: English",
        "Natural Language :: French",
        "Topic :: System :: Shells",
        "Programming Language :: Unix Shell",
        "Topic :: Terminals",
    ],
)
