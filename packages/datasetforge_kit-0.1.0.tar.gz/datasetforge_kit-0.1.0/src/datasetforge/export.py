from __future__ import annotations

from collections.abc import Mapping
from pathlib import Path
from typing import Any
import csv
import json

from .config import ExportConfig


def _fieldnames(records: list[dict[str, Any]]) -> list[str]:
    fieldnames: list[str] = []
    seen: set[str] = set()
    for record in records:
        for field in record.keys():
            if field not in seen:
                seen.add(field)
                fieldnames.append(field)
    return fieldnames


def export_records(records: list[dict[str, Any]], config: ExportConfig, *, include_metadata: dict[str, Any] | None = None) -> Path:
    path = Path(config.path)
    path.parent.mkdir(parents=True, exist_ok=True)
    if config.format == "json":
        payload: Any = records
        if config.include_metadata and include_metadata is not None:
            payload = {"metadata": include_metadata, "records": records}
        path.write_text(json.dumps(payload, indent=config.indent, ensure_ascii=True) + "\n", encoding="utf-8")
        return path
    if config.format == "csv":
        fieldnames = _fieldnames(records)
        with path.open("w", newline="", encoding="utf-8") as handle:
            writer = csv.DictWriter(handle, fieldnames=fieldnames)
            writer.writeheader()
            for record in records:
                writer.writerow({field: record.get(field) for field in fieldnames})
        return path
    if config.format == "parquet":
        try:
            import pyarrow as pa
            import pyarrow.parquet as pq
        except ImportError as exc:
            raise RuntimeError("parquet export requires 'pyarrow' to be installed") from exc
        table = pa.Table.from_pylist(records)
        pq.write_table(table, path)
        return path
    raise ValueError(f"unsupported export format: {config.format}")
