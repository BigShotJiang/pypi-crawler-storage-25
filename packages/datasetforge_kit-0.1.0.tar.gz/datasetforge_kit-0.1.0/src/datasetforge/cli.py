from __future__ import annotations

from pathlib import Path
from typing import Any
import argparse
import json
import sys

from .config import PipelineConfig, example_config, load_config, save_config
from .core import run_pipeline
from .metadata import build_dataset_card
from .schema import infer_schema, validate_records
from .connectors import load_source
from .transforms import apply_transforms


def _print_json(data: Any) -> None:
    sys.stdout.write(json.dumps(data, indent=2, ensure_ascii=True) + "\n")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="datasetforge", description="Convert messy data into ML-ready datasets.")
    subparsers = parser.add_subparsers(dest="command", required=True)

    init_parser = subparsers.add_parser("init-config", help="Write an example config file.")
    init_parser.add_argument("--path", required=True, help="Where to write the config file.")

    run_parser = subparsers.add_parser("run", help="Run the pipeline.")
    run_parser.add_argument("--config", required=True, help="Path to the config JSON.")
    run_parser.add_argument("--strict", action="store_true", help="Fail on validation errors.")

    inspect_parser = subparsers.add_parser("inspect", help="Inspect the source payload.")
    inspect_parser.add_argument("--config", required=True, help="Path to the config JSON.")

    schema_parser = subparsers.add_parser("schema", help="Infer the transformed schema.")
    schema_parser.add_argument("--config", required=True, help="Path to the config JSON.")

    validate_parser = subparsers.add_parser("validate", help="Validate transformed records.")
    validate_parser.add_argument("--config", required=True, help="Path to the config JSON.")

    card_parser = subparsers.add_parser("card", help="Generate a dataset card.")
    card_parser.add_argument("--config", required=True, help="Path to the config JSON.")
    card_parser.add_argument("--output", help="Optional output path for the card markdown.")

    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)

    if args.command == "init-config":
        save_config(example_config(), args.path)
        return 0

    config = load_config(args.config)

    if args.command == "inspect":
        source = load_source(config.source)
        _print_json(source.metadata)
        return 0

    if args.command == "schema":
        source = load_source(config.source)
        records = apply_transforms(source.records, config.transforms)
        _print_json(infer_schema(records))
        return 0

    if args.command == "validate":
        source = load_source(config.source)
        records = apply_transforms(source.records, config.transforms)
        errors = validate_records(
            records,
            required_fields=config.validation.required_fields,
            field_types=config.validation.field_types,
            allowed_values=config.validation.allowed_values,
        )
        _print_json({"valid": not errors, "errors": errors})
        return 1 if errors else 0

    if args.command == "card":
        result = run_pipeline(config)
        card_text = result.card_path.read_text(encoding="utf-8")
        if args.output:
            Path(args.output).parent.mkdir(parents=True, exist_ok=True)
            Path(args.output).write_text(card_text, encoding="utf-8")
        else:
            sys.stdout.write(card_text)
        return 0

    if args.command == "run":
        if args.strict:
            source = load_source(config.source)
            records = apply_transforms(source.records, config.transforms)
            errors = validate_records(
                records,
                required_fields=config.validation.required_fields,
                field_types=config.validation.field_types,
                allowed_values=config.validation.allowed_values,
            )
            if errors:
                _print_json({"valid": False, "errors": errors})
                return 1
        result = run_pipeline(config)
        _print_json(
            {
                "export_path": str(result.export_path),
                "metadata_path": str(result.metadata_path),
                "card_path": str(result.card_path),
                "manifest_path": str(result.manifest_path),
                "version_id": result.version_id,
                "validation_error_count": len(result.validation_errors),
                "validation_errors": result.validation_errors,
            }
        )
        if args.strict and result.validation_errors:
            return 1
        return 0

    parser.error(f"unknown command: {args.command}")
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
