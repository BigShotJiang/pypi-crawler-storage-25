from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any
from urllib import parse, request
import json

from .config import SourceConfig

_COMMON_RECORD_KEYS = ("records", "results", "items", "data", "rows")


@dataclass(slots=True)
class SourceResult:
    records: list[dict[str, Any]]
    metadata: dict[str, Any]


def _extract_by_path(data: Any, path: str | None) -> Any:
    if not path:
        return data
    current = data
    for part in path.split("."):
        if isinstance(current, dict) and part in current:
            current = current[part]
        else:
            raise KeyError(f"records_key '{path}' was not found in source payload")
    return current


def _resolve_records(data: Any, records_key: str | None) -> list[dict[str, Any]]:
    payload = _extract_by_path(data, records_key)
    if isinstance(payload, list):
        return [dict(item) if isinstance(item, dict) else {"value": item} for item in payload]
    if isinstance(payload, dict):
        for key in _COMMON_RECORD_KEYS:
            if key in payload:
                nested = payload[key]
                if isinstance(nested, list):
                    return [dict(item) if isinstance(item, dict) else {"value": item} for item in nested]
        return [dict(payload)]
    raise TypeError("source payload must resolve to a list or dict of records")


class JSONFileConnector:
    def load(self, source: SourceConfig) -> SourceResult:
        path = Path(source.location)
        if not path.exists():
            raise FileNotFoundError(path)
        if source.line_delimited or path.suffix.lower() in {".jsonl", ".ndjson"}:
            records = []
            for line in path.read_text(encoding=source.encoding).splitlines():
                stripped = line.strip()
                if stripped:
                    records.append(json.loads(stripped))
        else:
            payload = json.loads(path.read_text(encoding=source.encoding))
            records = _resolve_records(payload, source.records_key)
        metadata = {
            "source_kind": source.kind,
            "location": str(path),
            "record_count": len(records),
            "line_delimited": source.line_delimited,
        }
        return SourceResult(records=records, metadata=metadata)


class RESTAPIConnector:
    def load(self, source: SourceConfig) -> SourceResult:
        url = source.location
        if source.params:
            parsed = parse.urlsplit(url)
            query = dict(parse.parse_qsl(parsed.query))
            query.update({key: str(value) for key, value in source.params.items()})
            url = parse.urlunsplit(parsed._replace(query=parse.urlencode(query, doseq=True)))
        payload_bytes = None
        headers = dict(source.headers)
        if source.body is not None:
            payload_bytes = json.dumps(source.body).encode(source.encoding)
            headers.setdefault("Content-Type", "application/json")
        req = request.Request(url=url, data=payload_bytes, headers=headers, method=source.method.upper())
        with request.urlopen(req, timeout=source.timeout) as response:
            raw = response.read()
            payload = json.loads(raw.decode(source.encoding))
            records = _resolve_records(payload, source.records_key)
            metadata = {
                "source_kind": source.kind,
                "location": url,
                "status_code": getattr(response, "status", None),
                "headers": dict(response.headers.items()),
                "record_count": len(records),
                "bytes_received": len(raw),
            }
        return SourceResult(records=records, metadata=metadata)


def load_source(source: SourceConfig) -> SourceResult:
    if source.kind == "json_file":
        return JSONFileConnector().load(source)
    if source.kind == "rest_api":
        return RESTAPIConnector().load(source)
    raise ValueError(f"unsupported source kind: {source.kind}")
