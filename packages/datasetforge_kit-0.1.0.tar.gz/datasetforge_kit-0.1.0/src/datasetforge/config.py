from __future__ import annotations

from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Literal
import json

SourceKind = Literal["json_file", "rest_api"]
ExportFormat = Literal["csv", "json", "parquet"]


def _as_list(value: Any) -> list[Any]:
    if value is None:
        return []
    if isinstance(value, list):
        return value
    if isinstance(value, tuple):
        return list(value)
    return [value]


@dataclass(slots=True)
class SourceConfig:
    kind: SourceKind
    location: str
    records_key: str | None = None
    line_delimited: bool = False
    method: str = "GET"
    headers: dict[str, str] = field(default_factory=dict)
    params: dict[str, Any] = field(default_factory=dict)
    body: dict[str, Any] | None = None
    timeout: float = 30.0
    encoding: str = "utf-8"

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "SourceConfig":
        return cls(
            kind=data["kind"],
            location=data["location"],
            records_key=data.get("records_key"),
            line_delimited=bool(data.get("line_delimited", False)),
            method=data.get("method", "GET"),
            headers=dict(data.get("headers", {})),
            params=dict(data.get("params", {})),
            body=data.get("body"),
            timeout=float(data.get("timeout", 30.0)),
            encoding=data.get("encoding", "utf-8"),
        )

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(slots=True)
class TransformConfig:
    flatten_separator: str | None = "."
    rename: dict[str, str] = field(default_factory=dict)
    select: list[str] = field(default_factory=list)
    drop: list[str] = field(default_factory=list)
    missing_tokens: list[Any] = field(default_factory=lambda: ["", "null", "N/A"])
    fill_values: dict[str, Any] = field(default_factory=dict)
    dedupe_keys: list[str] = field(default_factory=list)
    fuzzy_dedupe_keys: list[str] = field(default_factory=list)
    fuzzy_threshold: float = 0.0

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "TransformConfig":
        return cls(
            flatten_separator=data.get("flatten_separator", "."),
            rename=dict(data.get("rename", {})),
            select=[str(item) for item in _as_list(data.get("select", []))],
            drop=[str(item) for item in _as_list(data.get("drop", []))],
            missing_tokens=list(data.get("missing_tokens", ["", "null", "N/A"])),
            fill_values=dict(data.get("fill_values", {})),
            dedupe_keys=[str(item) for item in _as_list(data.get("dedupe_keys", []))],
            fuzzy_dedupe_keys=[str(item) for item in _as_list(data.get("fuzzy_dedupe_keys", []))],
            fuzzy_threshold=float(data.get("fuzzy_threshold", 0.0)),
        )

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(slots=True)
class ValidationConfig:
    required_fields: list[str] = field(default_factory=list)
    field_types: dict[str, str] = field(default_factory=dict)
    allowed_values: dict[str, list[Any]] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "ValidationConfig":
        return cls(
            required_fields=[str(item) for item in _as_list(data.get("required_fields", []))],
            field_types={str(key): str(value) for key, value in dict(data.get("field_types", {})).items()},
            allowed_values={str(key): list(value) for key, value in dict(data.get("allowed_values", {})).items()},
        )

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(slots=True)
class ExportConfig:
    format: ExportFormat = "json"
    path: str = "dist/dataset.json"
    indent: int = 2
    include_metadata: bool = False

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "ExportConfig":
        return cls(
            format=data.get("format", "json"),
            path=data.get("path", "dist/dataset.json"),
            indent=int(data.get("indent", 2)),
            include_metadata=bool(data.get("include_metadata", False)),
        )

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(slots=True)
class VersioningConfig:
    enabled: bool = False
    directory: str | None = None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "VersioningConfig":
        return cls(
            enabled=bool(data.get("enabled", False)),
            directory=data.get("directory"),
        )

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(slots=True)
class PipelineConfig:
    name: str = "datasetforge"
    source: SourceConfig = field(default_factory=lambda: SourceConfig(kind="json_file", location="data/input.json"))
    transforms: TransformConfig = field(default_factory=TransformConfig)
    validation: ValidationConfig = field(default_factory=ValidationConfig)
    export: ExportConfig = field(default_factory=ExportConfig)
    versioning: VersioningConfig = field(default_factory=VersioningConfig)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "PipelineConfig":
        return cls(
            name=data.get("name", "datasetforge"),
            source=SourceConfig.from_dict(dict(data["source"])),
            transforms=TransformConfig.from_dict(dict(data.get("transforms", {}))),
            validation=ValidationConfig.from_dict(dict(data.get("validation", {}))),
            export=ExportConfig.from_dict(dict(data.get("export", {}))),
            versioning=VersioningConfig.from_dict(dict(data.get("versioning", {}))),
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "source": self.source.to_dict(),
            "transforms": self.transforms.to_dict(),
            "validation": self.validation.to_dict(),
            "export": self.export.to_dict(),
            "versioning": self.versioning.to_dict(),
        }


def load_config(path: str | Path) -> PipelineConfig:
    data = json.loads(Path(path).read_text(encoding="utf-8"))
    return PipelineConfig.from_dict(data)


def save_config(config: PipelineConfig, path: str | Path) -> None:
    destination = Path(path)
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(json.dumps(config.to_dict(), indent=2, ensure_ascii=True) + "\n", encoding="utf-8")


def example_config() -> PipelineConfig:
    return PipelineConfig(
        name="sample-dataset",
        source=SourceConfig(kind="json_file", location="data/input.json"),
        transforms=TransformConfig(
            flatten_separator=".",
            rename={"user.name": "name"},
            select=["id", "name", "score"],
            missing_tokens=["", "null", "N/A"],
            fill_values={"score": 0},
            dedupe_keys=["id"],
        ),
        validation=ValidationConfig(required_fields=["id", "name"], field_types={"id": "integer"}),
        export=ExportConfig(format="csv", path="dist/sample-dataset.csv"),
        versioning=VersioningConfig(enabled=True, directory="dist/versions"),
    )
