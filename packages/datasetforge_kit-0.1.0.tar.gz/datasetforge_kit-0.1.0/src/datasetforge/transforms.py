from __future__ import annotations

from collections.abc import Iterable, Mapping
from copy import deepcopy
from difflib import SequenceMatcher
from typing import Any
import json

from .config import TransformConfig


def flatten_record(record: Mapping[str, Any], separator: str = ".") -> dict[str, Any]:
    flattened: dict[str, Any] = {}

    def _walk(value: Any, prefix: str) -> None:
        if isinstance(value, Mapping):
            for key, nested in value.items():
                next_prefix = f"{prefix}{separator}{key}" if prefix else str(key)
                _walk(nested, next_prefix)
            return
        if isinstance(value, list):
            for index, nested in enumerate(value):
                next_prefix = f"{prefix}{separator}{index}" if prefix else str(index)
                _walk(nested, next_prefix)
            return
        flattened[prefix] = value

    _walk(dict(record), "")
    return flattened


def _normalize_missing(value: Any, missing_tokens: Iterable[Any]) -> Any:
    if isinstance(value, dict):
        return {key: _normalize_missing(nested, missing_tokens) for key, nested in value.items()}
    if isinstance(value, list):
        return [_normalize_missing(item, missing_tokens) for item in value]
    return None if value in set(missing_tokens) else value


def _record_signature(record: Mapping[str, Any], keys: list[str] | None = None) -> str:
    if keys:
        data = {key: record.get(key) for key in keys}
    else:
        data = dict(record)
    return json.dumps(data, sort_keys=True, default=str, ensure_ascii=True)


def _similarity(left: Mapping[str, Any], right: Mapping[str, Any], keys: list[str]) -> float:
    left_text = "|".join(str(left.get(key, "")) for key in keys)
    right_text = "|".join(str(right.get(key, "")) for key in keys)
    return SequenceMatcher(None, left_text.lower(), right_text.lower()).ratio()


def apply_transforms(records: list[dict[str, Any]], config: TransformConfig) -> list[dict[str, Any]]:
    transformed = [deepcopy(record) for record in records]
    if config.flatten_separator:
        transformed = [flatten_record(record, config.flatten_separator) for record in transformed]
    if config.missing_tokens:
        transformed = [_normalize_missing(record, config.missing_tokens) for record in transformed]
    if config.rename:
        renamed = []
        for record in transformed:
            updated = dict(record)
            for old_name, new_name in config.rename.items():
                if old_name in updated:
                    updated[new_name] = updated.pop(old_name)
            renamed.append(updated)
        transformed = renamed
    if config.select:
        transformed = [{key: record.get(key) for key in config.select if key in record} for record in transformed]
    if config.drop:
        drop_set = set(config.drop)
        transformed = [{key: value for key, value in record.items() if key not in drop_set} for record in transformed]
    if config.fill_values:
        filled = []
        for record in transformed:
            updated = dict(record)
            for key, value in config.fill_values.items():
                if updated.get(key) is None:
                    updated[key] = value
            filled.append(updated)
        transformed = filled
    if config.dedupe_keys:
        deduped = []
        seen: set[str] = set()
        for record in transformed:
            signature = _record_signature(record, config.dedupe_keys)
            if signature not in seen:
                seen.add(signature)
                deduped.append(record)
        transformed = deduped
    if config.fuzzy_dedupe_keys and config.fuzzy_threshold > 0:
        deduped = []
        for record in transformed:
            if any(_similarity(record, existing, config.fuzzy_dedupe_keys) >= config.fuzzy_threshold for existing in deduped):
                continue
            deduped.append(record)
        transformed = deduped
    return transformed
