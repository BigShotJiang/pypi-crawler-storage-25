from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any
import json

from .config import ExportConfig, PipelineConfig, save_config
from .connectors import load_source
from .export import export_records
from .metadata import build_dataset_card, build_metadata, content_hash, write_json
from .schema import infer_schema, validate_records
from .transforms import apply_transforms


@dataclass(slots=True)
class PipelineResult:
    config: PipelineConfig
    source_metadata: dict[str, Any]
    schema: dict[str, Any]
    validation_errors: list[str]
    records: list[dict[str, Any]]
    export_path: Path
    metadata_path: Path
    card_path: Path
    manifest_path: Path
    version_id: str | None


def _resolve_output_paths(config: PipelineConfig, records: list[dict[str, Any]], schema: dict[str, Any]) -> tuple[Path, Path, Path, Path, str | None]:
    export_path = Path(config.export.path)
    version_id = None
    if config.versioning.enabled:
        version_id = content_hash(config, records, schema)[:12]
        root = Path(config.versioning.directory or export_path.parent)
        export_path = root / config.name / version_id / export_path.name
    metadata_path = export_path.with_name("metadata.json")
    card_path = export_path.with_name("dataset-card.md")
    manifest_path = export_path.with_name("manifest.json")
    return export_path, metadata_path, card_path, manifest_path, version_id


def run_pipeline(config: PipelineConfig) -> PipelineResult:
    source_result = load_source(config.source)
    transformed_records = apply_transforms(source_result.records, config.transforms)
    validation_errors = validate_records(
        transformed_records,
        required_fields=config.validation.required_fields,
        field_types=config.validation.field_types,
        allowed_values=config.validation.allowed_values,
    )
    schema = infer_schema(transformed_records)
    export_path, metadata_path, card_path, manifest_path, version_id = _resolve_output_paths(config, transformed_records, schema)
    export_config = ExportConfig(
        format=config.export.format,
        path=str(export_path),
        indent=config.export.indent,
        include_metadata=config.export.include_metadata,
    )
    metadata = build_metadata(config, source_result.metadata, schema, transformed_records, validation_errors, version_id)
    exported_path = export_records(transformed_records, export_config, include_metadata=metadata)
    write_json(metadata_path, metadata, indent=config.export.indent)
    card_path.write_text(build_dataset_card(metadata, schema, transformed_records, config), encoding="utf-8")
    manifest = {
        "name": config.name,
        "version_id": version_id,
        "content_hash": metadata["content_hash"],
        "config": config.to_dict(),
        "export_path": str(exported_path),
        "metadata_path": str(metadata_path),
        "card_path": str(card_path),
    }
    write_json(manifest_path, manifest, indent=config.export.indent)
    save_config(config, export_path.with_name("config.snapshot.json"))
    return PipelineResult(
        config=config,
        source_metadata=source_result.metadata,
        schema=schema,
        validation_errors=validation_errors,
        records=transformed_records,
        export_path=exported_path,
        metadata_path=metadata_path,
        card_path=card_path,
        manifest_path=manifest_path,
        version_id=version_id,
    )
