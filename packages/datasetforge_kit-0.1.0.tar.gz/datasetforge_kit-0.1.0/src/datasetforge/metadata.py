from __future__ import annotations

from dataclasses import asdict
from hashlib import sha256
from pathlib import Path
from typing import Any
import json

from .config import PipelineConfig


def _stable_json(data: Any) -> str:
    return json.dumps(data, sort_keys=True, ensure_ascii=True, separators=(",", ":"), default=str)


def content_hash(config: PipelineConfig, records: list[dict[str, Any]], schema: dict[str, Any]) -> str:
    digest = sha256()
    digest.update(_stable_json(config.to_dict()).encode("utf-8"))
    digest.update(_stable_json(records).encode("utf-8"))
    digest.update(_stable_json(schema).encode("utf-8"))
    return digest.hexdigest()


def build_dataset_card(metadata: dict[str, Any], schema: dict[str, Any], sample_records: list[dict[str, Any]], config: PipelineConfig) -> str:
    lines = [
        f"# {config.name}",
        "",
        "## Summary",
        f"- Source: {metadata.get('source', {}).get('kind', config.source.kind)}",
        f"- Records: {metadata.get('record_count', len(sample_records))}",
        f"- Export format: {config.export.format}",
        f"- Content hash: {metadata.get('content_hash', 'n/a')}",
        "",
        "## Fields",
    ]
    fields = schema.get("fields", {})
    if fields:
        for name, info in fields.items():
            lines.append(f"- {name}: {info.get('resolved_type', 'unknown')}")
    else:
        lines.append("- No fields detected.")
    lines.extend([
        "",
        "## Sample",
    ])
    if sample_records:
        lines.append("```json")
        lines.append(json.dumps(sample_records[:3], indent=2, ensure_ascii=True))
        lines.append("```")
    else:
        lines.append("- No sample records.")
    return "\n".join(lines) + "\n"


def build_metadata(config: PipelineConfig, source_metadata: dict[str, Any], schema: dict[str, Any], records: list[dict[str, Any]], validation_errors: list[str], version_id: str | None) -> dict[str, Any]:
    metadata = {
        "name": config.name,
        "source": source_metadata,
        "record_count": len(records),
        "schema": schema,
        "validation_error_count": len(validation_errors),
        "validation_errors": validation_errors,
        "content_hash": content_hash(config, records, schema),
        "version_id": version_id,
        "transforms": config.transforms.to_dict(),
        "export": config.export.to_dict(),
    }
    return metadata


def write_json(path: str | Path, data: Any, indent: int = 2) -> Path:
    destination = Path(path)
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(json.dumps(data, indent=indent, ensure_ascii=True) + "\n", encoding="utf-8")
    return destination
