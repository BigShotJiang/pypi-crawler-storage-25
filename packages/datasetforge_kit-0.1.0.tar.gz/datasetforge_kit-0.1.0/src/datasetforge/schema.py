from __future__ import annotations

from collections import defaultdict
from collections.abc import Mapping
from typing import Any
import re

_JSON_TYPES = {
    type(None): "null",
    bool: "boolean",
    int: "integer",
    float: "number",
    str: "string",
    dict: "object",
    list: "array",
}


def value_type(value: Any) -> str:
    if isinstance(value, bool):
        return "boolean"
    if isinstance(value, int) and not isinstance(value, bool):
        return "integer"
    if isinstance(value, float):
        return "number"
    if isinstance(value, str):
        return "string"
    if isinstance(value, dict):
        return "object"
    if isinstance(value, list):
        return "array"
    if value is None:
        return "null"
    return type(value).__name__


def resolve_type(observed: set[str]) -> str:
    if not observed:
        return "null"
    if observed <= {"null"}:
        return "null"
    if observed <= {"null", "integer"}:
        return "integer"
    if observed <= {"null", "integer", "number"}:
        return "number"
    if observed <= {"null", "boolean"}:
        return "boolean"
    if observed <= {"null", "string"}:
        return "string"
    if observed <= {"null", "object"}:
        return "object"
    if observed <= {"null", "array"}:
        return "array"
    return "|".join(sorted(observed))


def infer_schema(records: list[dict[str, Any]], max_examples: int = 3) -> dict[str, Any]:
    field_stats: dict[str, dict[str, Any]] = defaultdict(lambda: {"observed_types": set(), "null_count": 0, "non_null_count": 0, "examples": []})
    for record in records:
        for field, value in record.items():
            stats = field_stats[field]
            stats["observed_types"].add(value_type(value))
            if value is None:
                stats["null_count"] += 1
            else:
                stats["non_null_count"] += 1
                if len(stats["examples"]) < max_examples and value not in stats["examples"]:
                    stats["examples"].append(value)
    inferred = {}
    total = len(records)
    for field, stats in sorted(field_stats.items()):
        observed_types = sorted(stats["observed_types"])
        inferred[field] = {
            "observed_types": observed_types,
            "resolved_type": resolve_type(set(observed_types)),
            "required": stats["null_count"] == 0 and stats["non_null_count"] > 0,
            "null_count": stats["null_count"],
            "non_null_count": stats["non_null_count"],
            "examples": stats["examples"],
        }
    return {"record_count": total, "fields": inferred}


def _matches_type(value: Any, expected: str) -> bool:
    actual = value_type(value)
    if expected == actual:
        return True
    if expected == "number" and actual == "integer":
        return True
    if expected == "string" and actual not in {"null", "object", "array"}:
        return True
    return False


def validate_records(
    records: list[dict[str, Any]],
    required_fields: list[str] | None = None,
    field_types: dict[str, str] | None = None,
    allowed_values: dict[str, list[Any]] | None = None,
) -> list[str]:
    required_fields = required_fields or []
    field_types = field_types or {}
    allowed_values = allowed_values or {}
    errors: list[str] = []
    for index, record in enumerate(records, start=1):
        for field in required_fields:
            if field not in record or record[field] is None or record[field] == "":
                errors.append(f"record {index}: missing required field '{field}'")
        for field, expected_type in field_types.items():
            if field in record and not _matches_type(record[field], expected_type):
                errors.append(f"record {index}: field '{field}' expected {expected_type} but got {value_type(record[field])}")
        for field, allowed in allowed_values.items():
            if field in record and record[field] not in allowed:
                errors.append(f"record {index}: field '{field}' has value {record[field]!r} which is not allowed")
    return errors
