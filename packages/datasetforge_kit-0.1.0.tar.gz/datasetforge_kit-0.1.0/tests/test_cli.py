from __future__ import annotations

from pathlib import Path
import json
import tempfile
import unittest

from datasetforge.cli import main


class CliTests(unittest.TestCase):
    def test_init_and_schema_command(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            root = Path(tmpdir)
            config_path = root / "datasetforge.config.json"
            input_path = root / "input.json"
            input_path.write_text(json.dumps([{"id": 1, "user": {"name": "Ada"}}]), encoding="utf-8")

            init_code = main(["init-config", "--path", str(config_path)])
            self.assertEqual(init_code, 0)
            self.assertTrue(config_path.exists())

            payload = json.loads(config_path.read_text(encoding="utf-8"))
            payload["source"]["location"] = str(input_path)
            payload["export"]["path"] = str(root / "out.json")
            config_path.write_text(json.dumps(payload), encoding="utf-8")

            schema_code = main(["schema", "--config", str(config_path)])
            self.assertEqual(schema_code, 0)

    def test_run_command(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            root = Path(tmpdir)
            input_path = root / "input.json"
            input_path.write_text(json.dumps([{"id": 1, "user": {"name": "Ada"}}]), encoding="utf-8")
            config_path = root / "config.json"
            config_path.write_text(
                json.dumps(
                    {
                        "name": "cli-demo",
                        "source": {"kind": "json_file", "location": str(input_path)},
                        "transforms": {"flatten_separator": ".", "rename": {"user.name": "name"}, "select": ["id", "name"]},
                        "validation": {"required_fields": ["id", "name"], "field_types": {"id": "integer"}},
                        "export": {"format": "json", "path": str(root / "out.json"), "include_metadata": False},
                        "versioning": {"enabled": False},
                    }
                ),
                encoding="utf-8",
            )
            code = main(["run", "--config", str(config_path)])
            self.assertEqual(code, 0)
            self.assertTrue((root / "out.json").exists())


if __name__ == "__main__":
    unittest.main()
