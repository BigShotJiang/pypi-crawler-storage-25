from __future__ import annotations

from pathlib import Path
import json
import tempfile
import unittest

from datasetforge.config import ExportConfig, PipelineConfig, SourceConfig, TransformConfig, ValidationConfig, VersioningConfig, load_config, save_config
from datasetforge.core import run_pipeline
from datasetforge.transforms import flatten_record


class CoreTests(unittest.TestCase):
    def test_flatten_record(self) -> None:
        record = {"user": {"name": "Ada"}, "metrics": [{"score": 3}, {"score": 4}]}
        flattened = flatten_record(record)
        self.assertEqual(flattened["user.name"], "Ada")
        self.assertEqual(flattened["metrics.0.score"], 3)
        self.assertEqual(flattened["metrics.1.score"], 4)

    def test_run_pipeline_creates_outputs(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            root = Path(tmpdir)
            input_path = root / "input.json"
            input_path.write_text(
                json.dumps(
                    [
                        {"id": 1, "user": {"name": "Ada"}, "score": None},
                        {"id": 1, "user": {"name": "Ada"}, "score": None},
                        {"id": 2, "user": {"name": "Grace"}, "score": 7},
                    ]
                ),
                encoding="utf-8",
            )
            config = PipelineConfig(
                name="demo",
                source=SourceConfig(kind="json_file", location=str(input_path)),
                transforms=TransformConfig(
                    flatten_separator=".",
                    rename={"user.name": "name"},
                    select=["id", "name", "score"],
                    fill_values={"score": 0},
                    dedupe_keys=["id"],
                ),
                validation=ValidationConfig(required_fields=["id", "name"], field_types={"id": "integer"}),
                export=ExportConfig(format="json", path=str(root / "output.json"), include_metadata=True),
                versioning=VersioningConfig(enabled=True, directory=str(root / "versions")),
            )
            result = run_pipeline(config)
            self.assertEqual(result.validation_errors, [])
            self.assertTrue(result.export_path.exists())
            self.assertTrue(result.metadata_path.exists())
            self.assertTrue(result.card_path.exists())
            self.assertTrue(result.manifest_path.exists())
            payload = json.loads(result.export_path.read_text(encoding="utf-8"))
            self.assertEqual(len(payload["records"]), 2)
            self.assertEqual(payload["records"][0]["name"], "Ada")
            self.assertEqual(payload["records"][0]["score"], 0)
            self.assertTrue(result.version_id)
            snapshot_path = result.export_path.with_name("config.snapshot.json")
            self.assertTrue(snapshot_path.exists())

    def test_config_round_trip(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            path = Path(tmpdir) / "config.json"
            config = PipelineConfig(
                name="round-trip",
                source=SourceConfig(kind="json_file", location="input.json"),
            )
            save_config(config, path)
            loaded = load_config(path)
            self.assertEqual(loaded.name, config.name)
            self.assertEqual(loaded.source.location, config.source.location)


if __name__ == "__main__":
    unittest.main()
