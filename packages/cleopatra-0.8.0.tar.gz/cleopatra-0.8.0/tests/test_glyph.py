"""Tests for cleopatra.glyph.Glyph base class.

Covers initialization, properties, kwargs merging, figure/axes creation,
tick computation, color scale normalization, colorbar creation,
tick adjustment, point overlay, and animation saving.
"""

from __future__ import annotations

import matplotlib.colors as mcolors
import matplotlib.pyplot as plt
import numpy as np
import pytest
from matplotlib.colorbar import Colorbar
from matplotlib.figure import Figure

from cleopatra.glyph import MAX_DISCRETE_LEVELS, SUPPORTED_VIDEO_FORMAT, Glyph
from cleopatra.styles import DEFAULT_OPTIONS as STYLE_DEFAULTS
from cleopatra.styles import ColorScale, MidpointNormalize


def _make_options(**overrides) -> dict:
    """Build a default_options dict with optional overrides."""
    opts = STYLE_DEFAULTS.copy()
    opts["vmin"] = None
    opts["vmax"] = None
    opts.update(overrides)
    return opts


def _make_glyph(**overrides) -> Glyph:
    """Create a Glyph with standard defaults and optional overrides."""
    kwargs = {}
    opts = _make_options()
    for key in list(overrides):
        if key in ("fig", "ax"):
            kwargs[key] = overrides.pop(key)
        elif key in opts:
            kwargs[key] = overrides.pop(key)
    return Glyph(default_options=_make_options(), **kwargs)


class TestInit:
    """Tests for Glyph.__init__."""

    def test_default_state(self):
        """Test that a fresh Glyph has None fig/ax and vmin/vmax."""
        g = Glyph(default_options=_make_options())
        assert g.fig is None, "fig should be None"
        assert g.ax is None, "ax should be None"
        assert g.vmin is None, "vmin should be None"
        assert g.vmax is None, "vmax should be None"
        assert g.ticks_spacing is None, "ticks_spacing should be None"

    def test_with_fig_ax(self):
        """Test that passing fig/ax stores them on the instance."""
        fig, ax = plt.subplots()
        g = Glyph(default_options=_make_options(), fig=fig, ax=ax)
        assert g.fig is fig, "Should store the provided figure"
        assert g.ax is ax, "Should store the provided axes"

    def test_kwargs_override_defaults(self):
        """Test that kwargs override default_options values."""
        g = Glyph(default_options=_make_options(), cmap="plasma")
        assert g.default_options["cmap"] == "plasma", (
            f"Expected cmap='plasma', got '{g.default_options['cmap']}'"
        )

    def test_invalid_kwarg_raises(self):
        """Test that an unknown kwarg raises ValueError."""
        with pytest.raises(ValueError, match="not_a_real_option"):
            Glyph(default_options=_make_options(), not_a_real_option=42)

    def test_default_options_are_copied(self):
        """Test that modifying glyph options doesn't affect the original dict."""
        opts = _make_options()
        g = Glyph(default_options=opts)
        g.default_options["cmap"] = "viridis"
        assert opts["cmap"] == "coolwarm_r", "Original dict should not be mutated"


class TestProperties:
    """Tests for Glyph properties."""

    def test_vmin_vmax_readable(self):
        """Test vmin/vmax properties return set values."""
        g = Glyph(default_options=_make_options())
        g._vmin = 1.0
        g._vmax = 10.0
        assert g.vmin == 1.0, f"Expected vmin=1.0, got {g.vmin}"
        assert g.vmax == 10.0, f"Expected vmax=10.0, got {g.vmax}"

    def test_default_options_property(self):
        """Test default_options returns the internal dict."""
        g = Glyph(default_options=_make_options())
        assert isinstance(g.default_options, dict), "Should return a dict"
        assert "cmap" in g.default_options, "Should contain cmap key"

    def test_anim_before_animate_raises(self):
        """Test accessing anim before animate() raises ValueError."""
        g = Glyph(default_options=_make_options())
        with pytest.raises(ValueError, match="animate"):
            _ = g.anim

    def test_anim_after_setting(self):
        """Test anim property returns stored animation."""
        g = Glyph(default_options=_make_options())
        sentinel = object()
        g._anim = sentinel
        assert g.anim is sentinel, "Should return the stored _anim"


class TestMergeKwargs:
    """Tests for Glyph._merge_kwargs."""

    def test_valid_kwargs_applied(self):
        """Test that valid kwargs update default_options."""
        g = Glyph(default_options=_make_options())
        g._merge_kwargs({"gamma": 0.8, "midpoint": 5})
        assert g.default_options["gamma"] == 0.8, (
            f"Expected gamma=0.8, got {g.default_options['gamma']}"
        )
        assert g.default_options["midpoint"] == 5, (
            f"Expected midpoint=5, got {g.default_options['midpoint']}"
        )

    def test_invalid_key_raises(self):
        """Test that invalid key raises ValueError."""
        g = Glyph(default_options=_make_options())
        with pytest.raises(ValueError, match="bogus_key"):
            g._merge_kwargs({"bogus_key": 99})

    def test_empty_kwargs_noop(self):
        """Test that empty kwargs dict does nothing."""
        g = Glyph(default_options=_make_options())
        original_cmap = g.default_options["cmap"]
        g._merge_kwargs({})
        assert g.default_options["cmap"] == original_cmap, "Should be unchanged"


class TestCreateFigureAxes:
    """Tests for Glyph.create_figure_axes."""

    def test_returns_figure_and_axes(self):
        """Test that create_figure_axes returns (Figure, Axes)."""
        g = Glyph(default_options=_make_options())
        fig, ax = g.create_figure_axes()
        assert isinstance(fig, Figure), f"Expected Figure, got {type(fig)}"
        assert ax is not None, "Should return Axes"
        plt.close(fig)

    def test_respects_figsize(self):
        """Test that figsize from default_options is used."""
        g = Glyph(default_options=_make_options(figsize=(12, 4)))
        fig, ax = g.create_figure_axes()
        w, h = fig.get_size_inches()
        assert (w, h) == (12.0, 4.0), f"Expected (12,4), got ({w},{h})"
        plt.close(fig)


class TestGetTicks:
    """Tests for Glyph.get_ticks."""

    def test_evenly_divisible(self):
        """Test ticks when vmax is evenly divisible by spacing."""
        g = Glyph(default_options=_make_options())
        g._default_options["vmin"] = 0.0
        g._default_options["vmax"] = 10.0
        g._default_options["ticks_spacing"] = 2.0
        ticks = g.get_ticks()
        expected = np.arange(0, 12, 2)
        np.testing.assert_array_almost_equal(ticks, expected)

    def test_not_evenly_divisible(self):
        """Test ticks when vmax is not evenly divisible by spacing."""
        g = Glyph(default_options=_make_options())
        g._default_options["vmin"] = 0.0
        g._default_options["vmax"] = 7.0
        g._default_options["ticks_spacing"] = 3.0
        ticks = g.get_ticks()
        assert ticks[0] == 0.0, f"First tick should be 0.0, got {ticks[0]}"
        assert ticks[-1] >= 7.0, f"Last tick should be >= 7.0, got {ticks[-1]}"

    def test_single_tick_spacing_equals_range(self):
        """Test when ticks_spacing equals the full range."""
        g = Glyph(default_options=_make_options())
        g._default_options["vmin"] = 0.0
        g._default_options["vmax"] = 5.0
        g._default_options["ticks_spacing"] = 5.0
        ticks = g.get_ticks()
        assert len(ticks) >= 2, f"Should have at least 2 ticks, got {len(ticks)}"
        assert ticks[0] == 0.0, f"First tick should be 0.0, got {ticks[0]}"


class TestCreateNormAndCbarKw:
    """Tests for Glyph._create_norm_and_cbar_kw."""

    @pytest.fixture()
    def glyph(self):
        """Create a Glyph with all color scale options available."""
        return Glyph(default_options=_make_options())

    def test_linear_returns_none_norm(self, glyph):
        """Test that linear color scale returns None norm."""
        glyph._default_options["color_scale"] = "linear"
        ticks = np.array([0.0, 5.0, 10.0])
        norm, cbar_kw = glyph._create_norm_and_cbar_kw(ticks)
        assert norm is None, f"Linear should return None norm, got {type(norm)}"
        assert "ticks" in cbar_kw, "cbar_kw should contain ticks"

    def test_power_returns_power_norm(self, glyph):
        """Test that power color scale returns PowerNorm."""
        glyph._default_options["color_scale"] = "power"
        glyph._default_options["gamma"] = 0.3
        ticks = np.array([0.0, 5.0, 10.0])
        norm, cbar_kw = glyph._create_norm_and_cbar_kw(ticks)
        assert isinstance(norm, mcolors.PowerNorm), (
            f"Expected PowerNorm, got {type(norm)}"
        )

    def test_sym_lognorm(self, glyph):
        """Test that sym-lognorm returns SymLogNorm with formatter."""
        glyph._default_options["color_scale"] = "sym-lognorm"
        ticks = np.array([0.0, 5.0, 10.0])
        norm, cbar_kw = glyph._create_norm_and_cbar_kw(ticks)
        assert isinstance(norm, mcolors.SymLogNorm), (
            f"Expected SymLogNorm, got {type(norm)}"
        )
        assert "format" in cbar_kw, "sym-lognorm should include a formatter"

    def test_boundary_norm_with_default_bounds(self, glyph):
        """Test boundary-norm with no explicit bounds uses ticks."""
        glyph._default_options["color_scale"] = "boundary-norm"
        glyph._default_options["bounds"] = None
        ticks = np.array([0.0, 5.0, 10.0])
        norm, cbar_kw = glyph._create_norm_and_cbar_kw(ticks)
        assert isinstance(norm, mcolors.BoundaryNorm), (
            f"Expected BoundaryNorm, got {type(norm)}"
        )

    def test_boundary_norm_with_custom_bounds(self, glyph):
        """Test boundary-norm with user-provided bounds."""
        glyph._default_options["color_scale"] = "boundary-norm"
        glyph._default_options["bounds"] = [0, 3, 6, 9]
        ticks = np.array([0.0, 5.0, 10.0])
        norm, cbar_kw = glyph._create_norm_and_cbar_kw(ticks)
        assert isinstance(norm, mcolors.BoundaryNorm), (
            f"Expected BoundaryNorm, got {type(norm)}"
        )
        np.testing.assert_array_equal(cbar_kw["ticks"], [0, 3, 6, 9])

    def test_midpoint_returns_midpoint_normalize(self, glyph):
        """Test midpoint scale returns MidpointNormalize."""
        glyph._default_options["color_scale"] = "midpoint"
        glyph._default_options["midpoint"] = 5.0
        ticks = np.array([0.0, 5.0, 10.0])
        norm, cbar_kw = glyph._create_norm_and_cbar_kw(ticks)
        assert isinstance(norm, MidpointNormalize), (
            f"Expected MidpointNormalize, got {type(norm)}"
        )

    def test_invalid_color_scale_string_raises(self, glyph):
        """An unrecognised color_scale string raises `ValueError`."""
        glyph._default_options["color_scale"] = "rainbow-magic"
        ticks = np.array([0.0, 5.0, 10.0])
        with pytest.raises(ValueError, match="Invalid color_scale"):
            glyph._create_norm_and_cbar_kw(ticks)

    def test_non_string_color_scale_raises_valueerror_not_attributeerror(self, glyph):
        """A non-string color_scale (e.g. an int) raises `ValueError`, not `AttributeError`.

        Regression for the case where `color_scale.lower()` blew up with
        `AttributeError: 'int' object has no attribute 'lower'`.
        """
        glyph._default_options["color_scale"] = 1
        ticks = np.array([0.0, 5.0, 10.0])
        with pytest.raises(ValueError, match="Invalid color_scale"):
            glyph._create_norm_and_cbar_kw(ticks)

    def test_colorscale_member_accepted(self, glyph):
        """Passing a `ColorScale` member directly works."""
        glyph._default_options["color_scale"] = ColorScale.POWER
        ticks = np.array([0.0, 5.0, 10.0])
        norm, cbar_kw = glyph._create_norm_and_cbar_kw(ticks)
        assert isinstance(norm, mcolors.PowerNorm)

    @pytest.mark.parametrize(
        "scale",
        ["Linear", "POWER", "Sym-Lognorm", "Boundary-Norm", "Midpoint"],
    )
    def test_case_insensitive(self, glyph, scale):
        """Test that color_scale matching is case-insensitive.

        Args:
            scale: Color scale name with mixed case.
        """
        glyph._default_options["color_scale"] = scale
        ticks = np.array([0.0, 5.0, 10.0])
        norm, cbar_kw = glyph._create_norm_and_cbar_kw(ticks)
        assert "ticks" in cbar_kw, f"Should produce cbar_kw for scale '{scale}'"


class TestCreateColorBar:
    """Tests for Glyph.create_color_bar."""

    def test_creates_colorbar(self):
        """Test that create_color_bar returns a Colorbar."""
        g = Glyph(default_options=_make_options())
        fig, ax = plt.subplots()
        im = ax.imshow(np.arange(9).reshape(3, 3))
        ticks = np.array([0.0, 4.0, 8.0])
        cbar = g.create_color_bar(ax, im, {"ticks": ticks})
        assert isinstance(cbar, Colorbar), f"Expected Colorbar, got {type(cbar)}"
        plt.close(fig)

    def test_respects_orientation(self):
        """Test that horizontal orientation is applied."""
        g = Glyph(
            default_options=_make_options(cbar_orientation="horizontal")
        )
        fig, ax = plt.subplots()
        im = ax.imshow(np.arange(9).reshape(3, 3))
        cbar = g.create_color_bar(ax, im, {"ticks": np.array([0, 4, 8])})
        assert cbar.orientation == "horizontal", (
            f"Expected horizontal, got {cbar.orientation}"
        )
        plt.close(fig)


    def test_single_axes_uses_gridspec(self):
        """Test that single-axes figure uses gridspec for colorbar.

        Test scenario:
            A figure with one axes should use use_gridspec=True
            for optimal colorbar layout.
        """
        g = Glyph(default_options=_make_options())
        fig, ax = plt.subplots()
        im = ax.imshow(np.arange(9).reshape(3, 3))
        cbar = g.create_color_bar(ax, im, {"ticks": np.array([0, 4, 8])})
        assert cbar is not None, "Colorbar should be created"
        plt.close(fig)

    def test_subplot_colorbar_does_not_steal_space(self):
        """Test that colorbar on subplot doesn't break sibling axes.

        Test scenario:
            Create a 1x2 subplot, add an image and colorbar to each.
            Both axes should retain their images — the second colorbar
            should not steal space from the first axes via gridspec.
        """
        g = Glyph(default_options=_make_options())
        fig, axes = plt.subplots(1, 2, figsize=(10, 4))

        im1 = axes[0].imshow(np.arange(9).reshape(3, 3))
        g.create_color_bar(axes[0], im1, {"ticks": np.array([0, 4, 8])})

        im2 = axes[1].imshow(np.arange(9, 0, -1).reshape(3, 3))
        g.create_color_bar(axes[1], im2, {"ticks": np.array([1, 5, 9])})

        assert len(axes[0].images) == 1, (
            f"First axes should have 1 image, got {len(axes[0].images)}"
        )
        assert len(axes[1].images) == 1, (
            f"Second axes should have 1 image, got {len(axes[1].images)}"
        )
        assert len(fig.axes) == 4, (
            f"Expected 4 axes (2 plot + 2 colorbar), got {len(fig.axes)}"
        )
        plt.close(fig)

    def test_subplot_colorbars_independent(self):
        """Test that each subplot's colorbar is independent.

        Test scenario:
            Two subplots with different data ranges should each get
            their own colorbar with correct tick values.
        """
        g1 = Glyph(default_options=_make_options())
        g2 = Glyph(default_options=_make_options())
        fig, axes = plt.subplots(1, 2)

        im1 = axes[0].imshow(np.zeros((3, 3)))
        ticks1 = np.array([0.0])
        cbar1 = g1.create_color_bar(axes[0], im1, {"ticks": ticks1})

        im2 = axes[1].imshow(np.ones((3, 3)) * 100)
        ticks2 = np.array([100.0])
        cbar2 = g2.create_color_bar(axes[1], im2, {"ticks": ticks2})

        assert cbar1 is not cbar2, "Colorbars should be different objects"
        plt.close(fig)

    def test_three_subplots_all_visible(self):
        """Test colorbar works correctly with 3+ subplots.

        Test scenario:
            1x3 subplot layout, each with an image and colorbar.
            All 3 axes should retain their images.
        """
        g = Glyph(default_options=_make_options())
        fig, axes = plt.subplots(1, 3, figsize=(15, 4))

        for i, ax in enumerate(axes):
            data = np.random.RandomState(i).rand(5, 5)
            im = ax.imshow(data)
            g.create_color_bar(ax, im, {"ticks": np.array([0.0, 0.5, 1.0])})

        for i, ax in enumerate(axes):
            assert len(ax.images) == 1, (
                f"Axes {i} should have 1 image, got {len(ax.images)}"
            )
        assert len(fig.axes) == 6, (
            f"Expected 6 axes (3 plot + 3 colorbar), got {len(fig.axes)}"
        )
        plt.close(fig)

    def test_2x2_grid_subplots(self):
        """Test colorbar on a 2x2 grid of subplots.

        Test scenario:
            4 subplots in a 2x2 grid, each with colorbar.
            All should render independently.
        """
        g = Glyph(default_options=_make_options())
        fig, axes = plt.subplots(2, 2, figsize=(10, 10))

        for ax in axes.flat:
            im = ax.imshow(np.random.RandomState(42).rand(4, 4))
            g.create_color_bar(ax, im, {"ticks": np.array([0.0, 0.5, 1.0])})

        for i, ax in enumerate(axes.flat):
            assert len(ax.images) == 1, (
                f"Axes {i} should have 1 image, got {len(ax.images)}"
            )
        plt.close(fig)


class TestAdjustTicks:
    """Tests for Glyph.adjust_ticks."""

    def test_adjust_x_ticks(self):
        """Test adjust_ticks on x axis applies formatter."""
        g = Glyph(default_options=_make_options())
        fig, ax = plt.subplots()
        ax.plot([0, 1, 2], [0, 1, 2])
        g.ax = ax
        g.fig = fig
        g.adjust_ticks(axis="x", multiply_value=10, add_value=5, fmt="{0:.0f}")
        formatter = ax.xaxis.get_major_formatter()
        assert formatter is not None, "Formatter should be set"
        plt.close(fig)

    def test_adjust_y_ticks(self):
        """Test adjust_ticks on y axis applies formatter."""
        g = Glyph(default_options=_make_options())
        fig, ax = plt.subplots()
        ax.plot([0, 1, 2], [0, 1, 2])
        g.ax = ax
        g.fig = fig
        g.adjust_ticks(axis="y", multiply_value=2)
        formatter = ax.yaxis.get_major_formatter()
        assert formatter is not None, "Formatter should be set"
        plt.close(fig)

    def test_hide_x_axis(self):
        """Test adjust_ticks with visible=False hides the axis."""
        g = Glyph(default_options=_make_options())
        fig, ax = plt.subplots()
        ax.plot([0, 1], [0, 1])
        g.ax = ax
        g.fig = fig
        g.adjust_ticks(axis="x", visible=False)
        assert not ax.get_xaxis().get_visible(), "x-axis should be hidden"
        plt.close(fig)

    def test_hide_y_axis(self):
        """Test adjust_ticks with visible=False hides the y-axis."""
        g = Glyph(default_options=_make_options())
        fig, ax = plt.subplots()
        ax.plot([0, 1], [0, 1])
        g.ax = ax
        g.fig = fig
        g.adjust_ticks(axis="y", visible=False)
        assert not ax.get_yaxis().get_visible(), "y-axis should be hidden"
        plt.close(fig)


class TestPlotPointValues:
    """Tests for Glyph._plot_point_values static method."""

    def test_creates_text_per_point(self):
        """Test that one text artist is created per point."""
        fig, ax = plt.subplots()
        points = np.array([[10.0, 0, 0], [20.0, 1, 1], [30.0, 2, 2]])
        texts = Glyph._plot_point_values(ax, points, "blue", 12)
        assert len(texts) == 3, f"Expected 3 text artists, got {len(texts)}"
        plt.close(fig)

    def test_text_positions(self):
        """Test that text is placed at (col, row) coordinates."""
        fig, ax = plt.subplots()
        points = np.array([[99.0, 3.0, 5.0]])
        texts = Glyph._plot_point_values(ax, points, "red", 10)
        pos = texts[0].get_position()
        assert pos == (5.0, 3.0), f"Expected position (5, 3), got {pos}"
        plt.close(fig)

    def test_empty_points_returns_empty_list(self):
        """Test that empty points array returns empty list."""
        fig, ax = plt.subplots()
        points = np.empty((0, 3))
        texts = Glyph._plot_point_values(ax, points, "red", 10)
        assert len(texts) == 0, f"Expected 0 text artists, got {len(texts)}"
        plt.close(fig)


class TestSaveAnimation:
    """Tests for Glyph.save_animation."""

    def test_unsupported_format_raises(self):
        """Test that unsupported format raises ValueError."""
        g = Glyph(default_options=_make_options())
        with pytest.raises(ValueError, match="not supported"):
            g.save_animation("output.webm")

    def test_no_anim_raises(self):
        """Test that saving without animate() raises ValueError."""
        g = Glyph(default_options=_make_options())
        with pytest.raises(ValueError, match="animate"):
            g.save_animation("output.gif")

    @pytest.mark.parametrize("ext", SUPPORTED_VIDEO_FORMAT)
    def test_supported_formats_accepted(self, ext):
        """Test that all supported formats don't raise ValueError on format check.

        Args:
            ext: File extension to test.

        Test scenario:
            We test that the format validation passes. The actual save
            will fail because there's no real animation, but the
            ValueError for unsupported format should NOT be raised.
        """
        g = Glyph(default_options=_make_options())
        g._anim = None
        with pytest.raises(ValueError, match="animate"):
            g.save_animation(f"output.{ext}")


class TestSupportedVideoFormat:
    """Tests for module-level SUPPORTED_VIDEO_FORMAT constant."""

    def test_contains_expected_formats(self):
        """Test that all expected formats are present."""
        expected = {"gif", "mov", "avi", "mp4"}
        assert set(SUPPORTED_VIDEO_FORMAT) == expected, (
            f"Expected {expected}, got {set(SUPPORTED_VIDEO_FORMAT)}"
        )


class TestLevelsToBounds:
    """Tests for `Glyph._levels_to_bounds` static method."""

    def test_none_returns_none(self):
        """`levels=None` produces `None`: continuous-norm path is selected."""
        result = Glyph._levels_to_bounds(None, 0.0, 1.0)
        assert result is None, f"Expected None for levels=None, got {result!r}"

    def test_int_creates_linspace(self):
        """`levels=int` produces `int` linearly-spaced edges between vmin/vmax."""
        result = Glyph._levels_to_bounds(5, 0.0, 1.0)
        assert result is not None, "int levels should produce an array"
        assert len(result) == 5, f"Expected 5 edges, got {len(result)}"
        assert result[0] == pytest.approx(0.0)
        assert result[-1] == pytest.approx(1.0)

    def test_list_sorted_ascending(self):
        """Unsorted explicit edges are returned sorted ascending."""
        result = Glyph._levels_to_bounds([5.0, 1.0, 3.0], 0.0, 10.0)
        np.testing.assert_array_equal(result, [1.0, 3.0, 5.0])

    def test_ndarray_passthrough(self):
        """A numpy array of edges is converted to float and sorted."""
        result = Glyph._levels_to_bounds(np.array([2, 1, 3]), 0.0, 10.0)
        np.testing.assert_array_equal(result, [1.0, 2.0, 3.0])
        assert result.dtype == np.float64

    def test_int_with_negative_range(self):
        """`levels=int` works for negative-to-positive vmin/vmax."""
        result = Glyph._levels_to_bounds(3, -1.0, 1.0)
        np.testing.assert_array_almost_equal(result, [-1.0, 0.0, 1.0])

    def test_explicit_edges_with_negative_values(self):
        """Explicit edges spanning negative-to-positive values are sorted ascending."""
        result = Glyph._levels_to_bounds([3.0, -2.0, 1.0, -5.0], -10.0, 10.0)
        np.testing.assert_array_equal(result, [-5.0, -2.0, 1.0, 3.0])

    @pytest.mark.parametrize("bad", [0, 1, -3, MAX_DISCRETE_LEVELS + 1, 10**9])
    def test_int_levels_out_of_range_raises(self, bad):
        """An integer `levels` outside `[2, MAX_DISCRETE_LEVELS]` raises.

        Args:
            bad: An integer level count that should be rejected.
        """
        with pytest.raises(ValueError, match=r"`levels` as an integer must be between"):
            Glyph._levels_to_bounds(bad, 0.0, 1.0)

    def test_int_levels_at_bounds_ok(self):
        """The min (2) and max (`MAX_DISCRETE_LEVELS`) integer levels are accepted."""
        assert len(Glyph._levels_to_bounds(2, 0.0, 1.0)) == 2
        assert len(Glyph._levels_to_bounds(MAX_DISCRETE_LEVELS, 0.0, 1.0)) == (
            MAX_DISCRETE_LEVELS
        )


class TestCreateNormAndCbarKwLevelsExtend:
    """Tests for the levels/extend branches added in CLEO-3."""

    @pytest.fixture()
    def glyph(self):
        """Create a Glyph configured for linear color scale."""
        return Glyph(default_options=_make_options())

    def test_levels_int_under_linear_creates_boundary_norm(self, glyph):
        """`color_scale='linear', levels=4` switches to a `BoundaryNorm`."""
        glyph._default_options["color_scale"] = "linear"
        glyph._default_options["levels"] = 4
        ticks = np.array([0.0, 5.0, 10.0])
        norm, cbar_kw = glyph._create_norm_and_cbar_kw(ticks)
        assert isinstance(norm, mcolors.BoundaryNorm), (
            f"Expected BoundaryNorm under linear+levels, got {type(norm)}"
        )
        assert len(cbar_kw["ticks"]) == 4

    def test_levels_list_under_linear(self, glyph):
        """A list of edges under `linear` produces a `BoundaryNorm`."""
        glyph._default_options["color_scale"] = "linear"
        glyph._default_options["levels"] = [0.0, 0.5, 1.0]
        ticks = np.array([0.0, 0.5, 1.0])
        norm, cbar_kw = glyph._create_norm_and_cbar_kw(ticks)
        assert isinstance(norm, mcolors.BoundaryNorm)
        np.testing.assert_array_almost_equal(cbar_kw["ticks"], [0.0, 0.5, 1.0])

    def test_levels_under_boundary_norm_with_explicit_bounds_wins(self, glyph):
        """`boundary-norm` with explicit `bounds` ignores `levels`."""
        glyph._default_options["color_scale"] = "boundary-norm"
        glyph._default_options["bounds"] = [0, 10, 20]
        glyph._default_options["levels"] = [0, 5, 10, 15]
        ticks = np.array([0.0, 10.0, 20.0])
        norm, cbar_kw = glyph._create_norm_and_cbar_kw(ticks)
        assert isinstance(norm, mcolors.BoundaryNorm)
        np.testing.assert_array_equal(cbar_kw["ticks"], [0, 10, 20])

    def test_levels_under_boundary_norm_no_explicit_bounds(self, glyph):
        """`boundary-norm` with no `bounds` falls through to `levels`."""
        glyph._default_options["color_scale"] = "boundary-norm"
        glyph._default_options["bounds"] = None
        glyph._default_options["levels"] = [0, 1, 2]
        ticks = np.array([0.0, 1.0, 2.0])
        norm, cbar_kw = glyph._create_norm_and_cbar_kw(ticks)
        assert isinstance(norm, mcolors.BoundaryNorm)
        np.testing.assert_array_equal(cbar_kw["ticks"], [0.0, 1.0, 2.0])

    def test_extend_auto_resolves_to_neither_when_no_levels(self, glyph):
        """`extend=None, levels=None` -> `cbar_kw['extend'] == 'neither'`."""
        glyph._default_options["color_scale"] = "linear"
        glyph._default_options["levels"] = None
        glyph._default_options["extend"] = None
        ticks = np.array([0.0, 1.0])
        _, cbar_kw = glyph._create_norm_and_cbar_kw(ticks)
        assert cbar_kw["extend"] == "neither"

    def test_extend_auto_resolves_to_both_when_levels_set(self, glyph):
        """`extend=None, levels=[...]` -> `cbar_kw['extend'] == 'both'`."""
        glyph._default_options["color_scale"] = "linear"
        glyph._default_options["levels"] = [0.0, 0.5, 1.0]
        glyph._default_options["extend"] = None
        ticks = np.array([0.0, 0.5, 1.0])
        _, cbar_kw = glyph._create_norm_and_cbar_kw(ticks)
        assert cbar_kw["extend"] == "both"

    @pytest.mark.parametrize(
        "explicit", ["neither", "both", "min", "max"]
    )
    def test_extend_explicit_value_passes_through(self, glyph, explicit):
        """Any allowed explicit `extend` value is forwarded as-is.

        Args:
            explicit: One of the allowed extend keywords.
        """
        glyph._default_options["color_scale"] = "linear"
        glyph._default_options["extend"] = explicit
        ticks = np.array([0.0, 1.0])
        _, cbar_kw = glyph._create_norm_and_cbar_kw(ticks)
        assert cbar_kw["extend"] == explicit


class TestCreateColorBarKwargsMerge:
    """Tests for `create_color_bar` merging of `cbar_kwargs`."""

    def test_user_label_replaces_default(self):
        """`cbar_kwargs={'label': ...}` flows through `cbar.set_label`."""
        g = Glyph(
            default_options=_make_options(
                cbar_label="Default", cbar_kwargs={"label": "Custom"}
            )
        )
        fig, ax = plt.subplots()
        im = ax.imshow(np.arange(9).reshape(3, 3))
        cbar = g.create_color_bar(ax, im, {"ticks": np.array([0, 4, 8])})
        assert cbar.ax.get_ylabel() == "Custom", (
            f"Expected user label 'Custom', got {cbar.ax.get_ylabel()!r}"
        )
        plt.close(fig)

    def test_user_shrink_overrides_default(self):
        """User-supplied `shrink` survives the defaults merge."""
        g = Glyph(
            default_options=_make_options(
                cbar_length=0.9, cbar_kwargs={"shrink": 0.3}
            )
        )
        fig, ax = plt.subplots()
        im = ax.imshow(np.arange(9).reshape(3, 3))
        cbar = g.create_color_bar(ax, im, {"ticks": np.array([0, 4, 8])})
        cbar_h = cbar.ax.get_position().height
        ax_h = ax.get_position().height
        assert cbar_h <= ax_h * 0.6, (
            f"User shrink=0.3 should produce a shorter colorbar, "
            f"got ratio {cbar_h / ax_h:.3f}"
        )
        plt.close(fig)

    def test_invalid_cbar_kwargs_type_raises(self):
        """Non-dict `cbar_kwargs` raises a clear `TypeError`."""
        g = Glyph(
            default_options=_make_options(cbar_kwargs="not-a-dict")
        )
        fig, ax = plt.subplots()
        im = ax.imshow(np.arange(9).reshape(3, 3))
        with pytest.raises(TypeError, match="cbar_kwargs must be a dict"):
            g.create_color_bar(ax, im, {"ticks": np.array([0, 4, 8])})
        plt.close(fig)

    def test_none_cbar_kwargs_is_noop(self):
        """`cbar_kwargs=None` falls back to the cleopatra defaults."""
        g = Glyph(default_options=_make_options(cbar_kwargs=None))
        fig, ax = plt.subplots()
        im = ax.imshow(np.arange(9).reshape(3, 3))
        cbar = g.create_color_bar(ax, im, {"ticks": np.array([0, 4, 8])})
        assert isinstance(cbar, Colorbar)
        plt.close(fig)


class TestSaveAnimationVideoBranch:
    """Tests covering the FFmpeg fallback path of `save_animation`."""

    def test_ffmpeg_missing_raises_friendly_error(self, monkeypatch, tmp_path):
        """A missing FFmpeg binary surfaces as `FileNotFoundError` with URL."""
        from matplotlib.animation import FuncAnimation
        from unittest.mock import MagicMock

        g = Glyph(default_options=_make_options())
        anim = MagicMock(spec=FuncAnimation)
        anim.save = MagicMock(side_effect=FileNotFoundError("ffmpeg not found"))
        g._anim = anim

        target = tmp_path / "movie.mp4"
        with pytest.raises(FileNotFoundError, match="ffmpeg.org"):
            g.save_animation(str(target))
