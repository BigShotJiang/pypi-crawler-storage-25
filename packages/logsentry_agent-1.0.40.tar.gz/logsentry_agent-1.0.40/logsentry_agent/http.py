from __future__ import annotations

import base64
import hashlib
import json
import os
import socket
import ssl
import time
from dataclasses import dataclass
from email.utils import parsedate_to_datetime
from typing import Any
from urllib.parse import urlparse

import requests
from cryptography import x509
from cryptography.hazmat.primitives import serialization

from logsentry_agent.config import SecurityConfig
from logsentry_agent.signer import compute_body_hash, sign_request
from logsentry_agent.utils.timeparse import default_timezone, now_in_timezone


def build_headers(
    *,
    agent_id: str,
    secret: str,
    body: bytes,
    nonce: str,
    timestamp: str,
    key_id: str | None = None,
    idempotency_token: str | None = None,
) -> dict:
    body_hash = compute_body_hash(body)
    signature = sign_request(secret, agent_id, timestamp, nonce, body_hash)
    headers = {
        "X-Agent-Id": agent_id,
        "X-Agent-Timestamp": timestamp,
        "X-Agent-Nonce": nonce,
        "X-Agent-Signature": signature,
        "X-Agent-Content-SHA256": body_hash,
        "Content-Type": "application/json",
    }
    if key_id:
        headers["X-Agent-Key-Id"] = key_id
    if idempotency_token:
        headers["X-Idempotency-Key"] = idempotency_token
    return headers


@dataclass
class SendResult:
    status: str
    response: requests.Response | None = None
    retry_after_seconds: float | None = None
    error: str | None = None
    auth_failed: bool = False
    inactive_agent: bool = False
    tenant_inactive: bool = False
    status_code: int | None = None


def _parse_retry_after(response: requests.Response) -> float | None:
    header = response.headers.get("Retry-After")
    if not header:
        return None
    try:
        return float(header)
    except ValueError:
        try:
            parsed = parsedate_to_datetime(header)
        except (TypeError, ValueError):
            return None
        if parsed.tzinfo is None:
            parsed = parsed.replace(tzinfo=default_timezone())
        delta = parsed - now_in_timezone()
        return max(delta.total_seconds(), 0.0)


def _is_tls_required(endpoint: str, security: SecurityConfig) -> bool:
    parsed = urlparse(endpoint)
    if parsed.scheme == "https":
        return False
    if (
        parsed.scheme == "http"
        and security.allow_insecure_localhost_http
        and parsed.hostname in {"localhost", "127.0.0.1"}
    ):
        return False
    return True


def _peer_spki_sha256(endpoint: str) -> str | None:
    parsed = urlparse(endpoint)
    if parsed.scheme != "https" or not parsed.hostname:
        return None
    port = parsed.port or 443
    context = ssl.create_default_context()
    with socket.create_connection((parsed.hostname, port), timeout=5) as sock:
        with context.wrap_socket(sock, server_hostname=parsed.hostname) as secure_sock:
            cert_der = secure_sock.getpeercert(binary_form=True)
    cert = x509.load_der_x509_certificate(cert_der)
    spki = cert.public_key().public_bytes(
        encoding=serialization.Encoding.DER,
        format=serialization.PublicFormat.SubjectPublicKeyInfo,
    )
    digest = hashlib.sha256(spki).digest()
    return base64.b64encode(digest).decode("ascii")


def _pin_validation(endpoint: str, security: SecurityConfig | None) -> tuple[bool, str | None]:
    if not security or not security.tls_pins_spki_sha256:
        return True, None
    try:
        observed = _peer_spki_sha256(endpoint)
    except Exception as exc:
        if security.pin_enforcement == "enforce":
            return False, f"TLS pin check failed: {exc}"
        return True, f"TLS pin check warning: {exc}"
    if observed in security.tls_pins_spki_sha256:
        return True, None
    message = "TLS pin mismatch detected. Update tls_pins_spki_sha256 for this endpoint cert."
    if security.pin_enforcement == "enforce":
        return False, message
    return True, message


def send_payload(
    *,
    endpoint: str,
    agent_id: str,
    secret: str,
    payload: dict[str, Any],
    retry_max_seconds: int,
    security: SecurityConfig | None = None,
    key_id: str | None = None,
    idempotency_token: str | None = None,
) -> SendResult:
    body = json.dumps(payload, separators=(",", ":")).encode("utf-8")
    if security and security.require_tls and _is_tls_required(endpoint, security):
        return SendResult(status="fatal", error="TLS required for non-local endpoints.")
    pin_ok, pin_message = _pin_validation(endpoint, security)
    if not pin_ok:
        return SendResult(status="fatal", error=pin_message)
    cert = None
    verify = str(security.ca_bundle_path) if security and security.ca_bundle_path else True
    if security and security.mtls_enabled:
        if not security.client_cert_path or not security.client_key_path:
            return SendResult(status="fatal", error="mTLS enabled but client cert/key not set.")
        cert = (str(security.client_cert_path), str(security.client_key_path))
    timestamp = str(int(time.time()))
    nonce = f"{int.from_bytes(os.urandom(12), 'big'):024x}"
    headers = build_headers(
        agent_id=agent_id,
        secret=secret,
        body=body,
        nonce=nonce,
        timestamp=timestamp,
        key_id=key_id,
        idempotency_token=idempotency_token,
    )
    try:
        response = requests.post(
            endpoint, data=body, headers=headers, timeout=10, cert=cert, verify=verify
        )
    except requests.RequestException as exc:
        return SendResult(status="retry", error=str(exc))
    status_code = response.status_code
    if 200 <= response.status_code < 300:
        return SendResult(
            status="ok", response=response, status_code=status_code, error=pin_message
        )
    if response.status_code == 429:
        retry_after = _parse_retry_after(response)
        return SendResult(
            status="retry",
            response=response,
            retry_after_seconds=retry_after,
            status_code=status_code,
        )
    if response.status_code in {401, 403}:
        error_detail = response.text.strip() if response.text else None
        error_code = ""
        if response.text:
            try:
                body = response.json()
            except ValueError:
                body = None
            if isinstance(body, dict):
                code = body.get("code")
                if isinstance(code, str):
                    error_code = code.strip().lower()
        detail_text = (error_detail or "").lower()
        inactive_agent = error_code == "agent_inactive" or "agent is inactive" in detail_text
        tenant_inactive = error_code == "tenant_inactive" or "tenant is inactive" in detail_text
        return SendResult(
            status="fatal",
            response=response,
            auth_failed=not (inactive_agent or tenant_inactive),
            inactive_agent=inactive_agent,
            tenant_inactive=tenant_inactive,
            error=error_detail,
            status_code=status_code,
        )
    if response.status_code >= 500:
        return SendResult(status="retry", response=response, status_code=status_code)
    return SendResult(status="retry", response=response, status_code=status_code)
