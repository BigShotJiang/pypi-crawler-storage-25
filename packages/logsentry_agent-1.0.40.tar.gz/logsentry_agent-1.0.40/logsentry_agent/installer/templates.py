from __future__ import annotations

from pathlib import Path


def _posix(path: Path) -> str:
    return path.as_posix()


def render_agent_config(
    *,
    agent_id: str,
    endpoint: str,
    state_dir: Path,
    source: str,
    file_paths: list[str],
) -> str:
    spool_path = state_dir / "spool.db"
    state_path = state_dir / "state.json"
    lines = [
        f"agent_id: {agent_id}",
        "shared_secret: ${LOGSENTRY_AGENT_SECRET}",
        f"endpoint: {endpoint}",
        f"state_path: {_posix(state_path)}",
        f"spool_path: {_posix(spool_path)}",
        "sources:",
        f"  - {source}",
    ]
    if source == "file" and file_paths:
        lines.extend(["file:", "  paths:"])
        for path in file_paths:
            lines.append(f"    - {path}")
    return "\n".join(lines) + "\n"


def render_env_file(secret: str) -> str:
    return f"LOGSENTRY_AGENT_SECRET={secret}\n"


def render_systemd_unit(
    *,
    service_name: str,
    user: str,
    group: str,
    env_path: Path,
    config_path: Path,
    venv_dir: Path,
    working_dir: Path,
) -> str:
    _ = service_name
    bin_path = venv_dir / "bin" / "logsentry-agent"
    return "\n".join(
        [
            "[Unit]",
            "Description=LogSentry Agent",
            "After=network-online.target",
            "Wants=network-online.target",
            "",
            "[Service]",
            "Type=simple",
            f"User={user}",
            f"Group={group}",
            f"EnvironmentFile={_posix(env_path)}",
            f"ExecStart={_posix(bin_path)} --config {_posix(config_path)} run",
            f"WorkingDirectory={_posix(working_dir)}",
            "Restart=always",
            "RestartSec=5",
            "NoNewPrivileges=true",
            "PrivateTmp=true",
            "ProtectSystem=strict",
            "ProtectHome=true",
            f"ReadWritePaths={_posix(working_dir)}",
            f"ReadOnlyPaths={_posix(config_path.parent)}",
            "",
            "[Install]",
            "WantedBy=multi-user.target",
            "",
        ]
    )
