from logsentry_agent.http import SendResult
from logsentry_agent.run import CircuitBreaker, _update_fail_closed_window


def test_circuit_breaker_opens_and_blocks_until_cooldown():
    breaker = CircuitBreaker(threshold=2, open_seconds=30, half_open_probe_count=1)
    now = 100.0
    breaker.failure(now)
    assert breaker.state == "closed"
    breaker.failure(now)
    assert breaker.state == "open"
    assert breaker.allow(now + 1) is False


def test_circuit_breaker_half_open_probe_success_closes():
    breaker = CircuitBreaker(threshold=1, open_seconds=10, half_open_probe_count=1)
    breaker.failure(10.0)
    assert breaker.state == "open"
    assert breaker.allow(21.0) is True
    assert breaker.state == "half_open"
    breaker.success()
    assert breaker.state == "closed"
    assert breaker.consecutive_failures == 0


def test_circuit_breaker_half_open_probe_failure_reopens():
    breaker = CircuitBreaker(threshold=1, open_seconds=10, half_open_probe_count=1)
    breaker.failure(10.0)
    assert breaker.allow(21.0) is True
    breaker.failure(21.0)
    assert breaker.state == "open"
    assert breaker.allow(22.0) is False


def test_fail_closed_window_activates_after_threshold():
    result = SendResult(status="retry")
    first_failure, lockout, elapsed = _update_fail_closed_window(
        result=result,
        first_failure_epoch=None,
        now_epoch=100.0,
        limit_seconds=30,
    )
    assert first_failure == 100.0
    assert lockout is False
    assert elapsed == 0.0

    first_failure, lockout, elapsed = _update_fail_closed_window(
        result=result,
        first_failure_epoch=first_failure,
        now_epoch=131.0,
        limit_seconds=30,
    )
    assert first_failure == 100.0
    assert lockout is True
    assert elapsed == 31.0


def test_fail_closed_window_clears_on_success():
    first_failure, lockout, elapsed = _update_fail_closed_window(
        result=SendResult(status="ok"),
        first_failure_epoch=50.0,
        now_epoch=120.0,
        limit_seconds=30,
    )
    assert first_failure is None
    assert lockout is False
    assert elapsed == 0.0
