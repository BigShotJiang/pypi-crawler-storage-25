from pathlib import Path

from logsentry_agent.config import load_config


def test_reliability_stop_sending_after_fail_seconds_from_file(tmp_path: Path):
    config_path = tmp_path / "agent.yml"
    config_path.write_text(
        """
agent_id: "agent"
shared_secret: "secret"
endpoint: "http://localhost:8002/v1/ingest"
reliability:
  stop_sending_after_fail_seconds: 120
""".strip(),
        encoding="utf-8",
    )

    config = load_config(config_path)
    assert config.reliability is not None
    assert config.reliability.stop_sending_after_fail_seconds == 120


def test_reliability_stop_sending_after_fail_seconds_env_overrides(tmp_path: Path, monkeypatch):
    monkeypatch.setenv("LOGSENTRY_STOP_SENDING_AFTER_FAIL_SECONDS", "45")
    config_path = tmp_path / "agent.yml"
    config_path.write_text(
        """
agent_id: "agent"
shared_secret: "secret"
endpoint: "http://localhost:8002/v1/ingest"
reliability:
  stop_sending_after_fail_seconds: 120
""".strip(),
        encoding="utf-8",
    )

    config = load_config(config_path)
    assert config.reliability is not None
    assert config.reliability.stop_sending_after_fail_seconds == 45


def test_invalid_spool_path_from_file(tmp_path: Path):
    invalid_spool = tmp_path / "dead-letter.db"
    config_path = tmp_path / "agent.yml"
    config_path.write_text(
        f"""
agent_id: "agent"
shared_secret: "secret"
endpoint: "http://localhost:8002/v1/ingest"
invalid_spool_path: "{invalid_spool.as_posix()}"
""".strip(),
        encoding="utf-8",
    )

    config = load_config(config_path)
    assert config.invalid_spool_path == invalid_spool


def test_invalid_spool_path_env_overrides_file(tmp_path: Path, monkeypatch):
    env_invalid_spool = tmp_path / "from-env.db"
    monkeypatch.setenv("LOGSENTRY_INVALID_SPOOL_PATH", str(env_invalid_spool))
    config_path = tmp_path / "agent.yml"
    config_path.write_text(
        """
agent_id: "agent"
shared_secret: "secret"
endpoint: "http://localhost:8002/v1/ingest"
invalid_spool_path: "/tmp/from-file.db"
""".strip(),
        encoding="utf-8",
    )

    config = load_config(config_path)
    assert config.invalid_spool_path == env_invalid_spool
