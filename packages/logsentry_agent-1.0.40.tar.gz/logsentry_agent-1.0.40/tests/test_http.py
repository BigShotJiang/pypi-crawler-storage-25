from logsentry_agent.config import SecurityConfig
from logsentry_agent.http import send_payload


class FakeResponse:
    def __init__(self, status_code: int, headers: dict | None = None, text: str = ""):
        self.status_code = status_code
        self.headers = headers or {}
        self.text = text

    def json(self):
        import json

        if not self.text:
            raise ValueError("No JSON body")
        return json.loads(self.text)


def test_retry_after_honored(monkeypatch):
    def fake_post(*args, **kwargs):  # noqa: ARG001
        return FakeResponse(429, {"Retry-After": "3"})

    monkeypatch.setattr("requests.post", fake_post)
    result = send_payload(
        endpoint="http://localhost:8002/v1/ingest",
        agent_id="agent",
        secret="secret",
        payload={"events": []},
        retry_max_seconds=10,
        security=SecurityConfig(require_tls=False),
    )
    assert result.status == "retry"
    assert result.retry_after_seconds == 3.0


def test_retry_after_missing_falls_back_to_backoff(monkeypatch):
    def fake_post(*args, **kwargs):  # noqa: ARG001
        return FakeResponse(429)

    monkeypatch.setattr("requests.post", fake_post)
    result = send_payload(
        endpoint="http://localhost:8002/v1/ingest",
        agent_id="agent",
        secret="secret",
        payload={"events": []},
        retry_max_seconds=10,
        security=SecurityConfig(require_tls=False),
    )
    assert result.status == "retry"
    assert result.retry_after_seconds is None


def test_auth_failure_is_fatal(monkeypatch):
    def fake_post(*args, **kwargs):  # noqa: ARG001
        return FakeResponse(401)

    monkeypatch.setattr("requests.post", fake_post)
    result = send_payload(
        endpoint="http://localhost:8002/v1/ingest",
        agent_id="agent",
        secret="secret",
        payload={"events": []},
        retry_max_seconds=10,
        security=SecurityConfig(require_tls=False),
    )
    assert result.status == "fatal"
    assert result.auth_failed is True


def test_inactive_agent_failure_is_non_auth_pause(monkeypatch):
    def fake_post(*args, **kwargs):  # noqa: ARG001
        return FakeResponse(403, text="Agent is inactive.")

    monkeypatch.setattr("requests.post", fake_post)
    result = send_payload(
        endpoint="http://localhost:8002/v1/ingest",
        agent_id="agent",
        secret="secret",
        payload={"events": []},
        retry_max_seconds=10,
        security=SecurityConfig(require_tls=False),
    )
    assert result.status == "fatal"
    assert result.auth_failed is False
    assert result.inactive_agent is True


def test_inactive_tenant_failure_disables_auth_pause(monkeypatch):
    def fake_post(*args, **kwargs):  # noqa: ARG001
        return FakeResponse(403, text='{"code":"tenant_inactive","detail":"Tenant is inactive."}')

    monkeypatch.setattr("requests.post", fake_post)
    result = send_payload(
        endpoint="http://localhost:8002/v1/ingest",
        agent_id="agent",
        secret="secret",
        payload={"events": []},
        retry_max_seconds=10,
        security=SecurityConfig(require_tls=False),
    )
    assert result.status == "fatal"
    assert result.auth_failed is False
    assert result.tenant_inactive is True


def test_server_error_is_retry(monkeypatch):
    def fake_post(*args, **kwargs):  # noqa: ARG001
        return FakeResponse(500)

    monkeypatch.setattr("requests.post", fake_post)
    result = send_payload(
        endpoint="http://localhost:8002/v1/ingest",
        agent_id="agent",
        secret="secret",
        payload={"events": []},
        retry_max_seconds=10,
        security=SecurityConfig(require_tls=False),
    )
    assert result.status == "retry"


def test_tls_required_rejects_insecure_endpoint():
    result = send_payload(
        endpoint="http://example.com/v1/ingest",
        agent_id="agent",
        secret="secret",
        payload={"events": []},
        retry_max_seconds=10,
        security=SecurityConfig(require_tls=True),
    )
    assert result.status == "fatal"


def test_send_payload_enforce_pin_mismatch_fails(monkeypatch):
    monkeypatch.setattr("logsentry_agent.http._peer_spki_sha256", lambda endpoint: "observed-pin")
    result = send_payload(
        endpoint="https://example.com/v1/ingest",
        agent_id="agent",
        secret="secret",
        payload={"events": []},
        retry_max_seconds=10,
        security=SecurityConfig(
            require_tls=True,
            tls_pins_spki_sha256=["different-pin"],
            pin_enforcement="enforce",
        ),
    )
    assert result.status == "fatal"
    assert result.error is not None


def test_send_payload_report_only_pin_mismatch_allows(monkeypatch):
    monkeypatch.setattr("logsentry_agent.http._peer_spki_sha256", lambda endpoint: "observed-pin")

    class _Response:
        status_code = 200
        headers = {}
        text = ""

    monkeypatch.setattr("requests.post", lambda *args, **kwargs: _Response())
    result = send_payload(
        endpoint="https://example.com/v1/ingest",
        agent_id="agent",
        secret="secret",
        payload={"events": []},
        retry_max_seconds=10,
        security=SecurityConfig(
            require_tls=True,
            tls_pins_spki_sha256=["different-pin"],
            pin_enforcement="report_only",
        ),
    )
    assert result.status == "ok"
    assert result.error is not None
