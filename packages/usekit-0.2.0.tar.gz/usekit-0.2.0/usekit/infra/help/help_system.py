# Path: usekit.infra.help.help_system.py
# -----------------------------------------------------------------------------------------------
#  MOSA Help System - Memory-Oriented Software Architecture Documentation
#  Created by: THE Little Prince × ROP × FOP
# -----------------------------------------------------------------------------------------------

from typing import Optional, Literal
import textwrap


# ===============================================================================
# Help Topics
# ===============================================================================

HELP_TOPICS = {
    "overview": "MOSA 전체 개요",
    "alias": "축약 체계 (Alias Mapping)",
    "action": "액션 목록 (read, write, ...)",
    "object": "포맷 목록 (json, yaml, ...)",
    "location": "위치 목록 (base, sub, ...)",
    "pattern": "패턴 매칭 사용법",
    "walk": "재귀 검색 (walk) 사용법",
    "keydata": "중첩 경로 탐색 (keydata)",
    "examples": "사용 예시",
    "quick": "빠른 시작 가이드",
}


# ===============================================================================
# Help Content - Overview & Alias
# ===============================================================================

HELP_OVERVIEW = """
╔══════════════════════════════════════════════════════════════════════════╗
║                                                                          ║
║  MOSA - Memory-Oriented Software Architecture                           ║
║  인간의 기억 구조를 모방한 소프트웨어 아키텍처                          ║
║                                                                          ║
╚══════════════════════════════════════════════════════════════════════════╝

🎯 핵심 구조
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    USE.[ACTION].[OBJECT].[LOCATION]
    
    예시: u.rjb()  →  use.read.json.base()

📚 주요 개념
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    • ACTION   : 무엇을 할지 (read, write, update, delete, exists)
    • OBJECT   : 어떤 포맷인지 (json, yaml, txt, csv, ...)
    • LOCATION : 어디서 할지 (base, sub, now, tmp, ...)

🔍 도움말 보기
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    u.help()              # 전체 개요
    u.help("alias")       # 축약 체계
    u.help("action")      # 액션 목록
    u.help("examples")    # 사용 예시
    u.help("quick")       # 빠른 시작

💡 철학
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    "코드는 기능이 아니라 기억이다"
    "사용자가 함수를 기억하는 게 아니라, 함수가 사용자의 기억을 따른다"
"""


HELP_ALIAS = """
╔══════════════════════════════════════════════════════════════════════════╗
║  축약 체계 (Alias Mapping)                                               ║
╚══════════════════════════════════════════════════════════════════════════╝

🎯 축약 원칙
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    1. 첫 글자 기반 - 겹치지 않게 설계
    2. 고정 알리아스 - 자주 쓰는 것은 2-3자로 고정
    3. 동적 확장 - 새 포맷은 u.r("fmt") 방식

📊 ACTION (첫 글자)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    DATA I/O:
    • r - read       u.rj()    읽기
    • w - write      u.wj()    쓰기
    • u - update     u.uj()    업데이트
    • d - delete     u.dj()    삭제
    • e - exists     u.ej()    존재 확인
    
    탐색:
    • p - path       u.pj()    경로 반환
    • f - find       u.fj()    검색
    • l - list       u.lj()    목록
    • g - get        u.gj()    값 가져오기
    • s - set        u.sj()    값 설정
    
    실행:
    • x - exec       u.x()     실행
    • i - import     u.i()     임포트
    • n - rerun      u.n()     재실행
    • q - quit       u.q()     종료

📦 OBJECT (포맷)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    일반 포맷:
    • j - json       u.rj()    ⭐⭐⭐ 최우선
    • y - yaml       u.ry()    ⭐⭐⭐
    • t - txt        u.rt()    ⭐⭐⭐
    • c - csv        u.rc()    ⭐⭐
    • m - markdown   u.rm()    ⭐⭐
    
    특수 포맷:
    • p - pickle     u.rp()    Python pickle
    • s - sql        u.rs()    SQL query
    • d - ddl        u.rd()    DDL script
    
    동적 포맷:
    • 새 포맷       u.r("toml")     TOML
                    u.r("ini")      INI
                    u.r("xml")      XML

📍 LOCATION (위치)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    • b - base       u.rjb()   기본 디렉토리
    • s - sub        u.rjs()   하위 디렉토리
    • n - now        u.rjn()   현재 디렉토리
    • d - dir        u.rjd()   사용자 지정
    • t - tmp        u.rjt()   임시 디렉토리
    • c - cus        u.rjc()   커스텀 프리셋

🎨 조합 예시
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    고정 알리아스:
    u.rj()          # read json base (기본)
    u.rjb()         # read json base (명시적)
    u.rjs()         # read json sub
    u.wyt()         # write yaml tmp
    
    동적 확장:
    u.r("toml")     # read toml
    u.r("toml")s    # read toml sub
    u.w("ini")b     # write ini base

💡 기억법
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    u.[r/w/u/d/e][j/y/t/c/m][b/s/n/d/t/c]
       ↑          ↑          ↑
     액션       포맷       위치
"""


HELP_ACTION = """
╔══════════════════════════════════════════════════════════════════════════╗
║  액션 목록 (Actions)                                                     ║
╚══════════════════════════════════════════════════════════════════════════╝

📖 DATA I/O (5개)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    read (r)
        파일 읽기
        예시: u.rj()  u.rj(name="config")
        
    write (w)
        파일 쓰기
        예시: u.wj(data={"key": "value"})
        
    update (u)
        파일 업데이트
        예시: u.uj(data={"new": "data"})
        
    delete (d)
        파일 삭제
        예시: u.dj(name="old_file")
        
    exists (e)
        파일 존재 확인
        예시: u.ej(name="config")  # True/False

🔍 탐색 (5개)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    path (p)
        파일 경로 반환
        예시: u.pj(name="config")  # Path 객체
        
    find (f)
        패턴 검색
        예시: u.fj(name="user_*")
        
    list (l)
        디렉토리 목록
        예시: u.lj()  # 모든 json 파일
        
    get (g)
        값 가져오기 (read 별칭)
        예시: u.gj(name="config", keydata="user/email")
        
    set (s)
        값 설정 (update 별칭)
        예시: u.sj(name="config", keydata="user/name", data="Alice")

⚙️ 실행 (4개)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    exec (x)
        코드 실행
        예시: u.x(code="print('hello')")
        
    import (i)
        모듈 동적 임포트
        예시: u.i(module="pandas")
        
    rerun (n)
        이전 명령 재실행
        예시: u.n()  u.n(3)  # 3번째 명령
        
    quit (q)
        종료
        예시: u.q()
"""

# Path: usekit.infra.help_system.py (Part 2)
# -----------------------------------------------------------------------------------------------
#  MOSA Help System - Pattern, Walk, Keydata
# -----------------------------------------------------------------------------------------------

HELP_PATTERN = """
╔══════════════════════════════════════════════════════════════════════════╗
║  패턴 매칭 (Pattern Matching)                                            ║
╚══════════════════════════════════════════════════════════════════════════╝

🎯 패턴 문자
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    *       0개 이상의 문자 매칭
    ?       정확히 1개 문자 매칭
    %       SQL LIKE 스타일 (* 와 동일)
    [abc]   a, b, c 중 하나
    [a-z]   a부터 z까지 하나

📖 사용 예시
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    # 모든 user 파일
    u.rj(name="user_*")
    [user_001.json, user_002.json, user_alice.json]
    
    # 특정 길이
    u.rj(name="log_????")
    [log_2024.json, log_2025.json]
    
    # SQL LIKE 스타일
    u.rj(name="%test%")
    [my_test_file.json, test_config.json]
    
    # 조합
    u.rj(name="user_[0-9]*.json")
    [user_001.json, user_123.json]

🔄 walk와 조합
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    # 현재 디렉토리만
    u.rj(name="user_*")
    base/user_001.json
    base/user_002.json
    
    # 하위 디렉토리까지
    u.rj(name="user_*", walk=True)
    base/user_001.json
    base/subdir/user_002.json
    base/subdir/deep/user_003.json

📊 반환 형태
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    # read: 파일별 결과 리스트
    [
        {"file": "user_001", "path": "...", "data": {...}},
        {"file": "user_002", "path": "...", "data": {...}}
    ]
    
    # exists: 하나라도 있으면 True
    True / False
    
    # delete: 상세 결과
    {
        "deleted": [Path(...), Path(...)],
        "failed": [],
        "total": 2,
        "success": 2
    }

⚠️ 안전성 (delete 전용)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    # 위험한 패턴 차단
    u.dj(name="*")              # ❌ ValueError
    u.dj(name="**")             # ❌ ValueError
    u.dj(name="*.*")            # ❌ ValueError
    u.dj(name="*_*", walk=True) # ❌ ValueError
    
    # 안전한 패턴
    u.dj(name="temp_*")         # ✅ OK
    u.dj(name="old_20241107_*") # ✅ OK
"""


HELP_WALK = """
╔══════════════════════════════════════════════════════════════════════════╗
║  재귀 검색 (walk)                                                        ║
╚══════════════════════════════════════════════════════════════════════════╝

🎯 개념
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    walk=False (기본값)
        지정된 디렉토리만 검색
        
    walk=True
        하위 디렉토리까지 재귀 검색

📂 디렉토리 구조 예시
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    base/
    ├── config.json
    ├── user_001.json
    └── subdir/
        ├── user_002.json
        └── deep/
            └── user_003.json

📖 사용 예시
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    # walk=False (기본)
    u.rj(name="user_*")
    결과: [user_001.json]  # base/ 만
    
    # walk=True
    u.rj(name="user_*", walk=True)
    결과: [
        user_001.json,         # base/
        user_002.json,         # base/subdir/
        user_003.json          # base/subdir/deep/
    ]

🔗 loc와의 관계
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    loc와 walk는 독립적!
    
    • loc: "어디서" 검색할지 (base/sub/now/tmp/...)
    • walk: "얼마나 깊이" 검색할지 (True/False)
    
    예시:
    u.rjs(name="config_*")              # sub/ 만
    u.rjs(name="config_*", walk=True)   # sub/ 및 하위
    u.rjt(name="temp_*", walk=True)     # tmp/ 및 하위

⚡ 성능 고려
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    walk=True는 모든 하위 디렉토리를 검색하므로
    파일이 많을 경우 느릴 수 있습니다.
    
    • 정확한 위치를 알면: walk=False (기본값)
    • 어디 있는지 모르면: walk=True
    • 특정 범위 검색: loc 조합
"""


HELP_KEYDATA = """
╔══════════════════════════════════════════════════════════════════════════╗
║  중첩 경로 탐색 (keydata)                                                ║
╚══════════════════════════════════════════════════════════════════════════╝

🎯 개념
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    keydata는 중첩된 데이터 구조 내의 특정 경로를 지정합니다.
    
    구분자: "/" (슬래시)
    배열: [인덱스] 또는 /인덱스

📊 데이터 예시
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    {
        "user": {
            "name": "Alice",
            "email": "alice@example.com",
            "profile": {
                "age": 25,
                "city": "Seoul"
            }
        },
        "items": [
            {"id": 1, "name": "Item A"},
            {"id": 2, "name": "Item B"}
        ]
    }

📖 사용 예시
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    # 단일 키
    u.rj(name="config", keydata="user")
    결과: {"name": "Alice", "email": "...", "profile": {...}}
    
    # 중첩 경로
    u.rj(name="config", keydata="user/email")
    결과: "alice@example.com"
    
    # 더 깊은 경로
    u.rj(name="config", keydata="user/profile/city")
    결과: "Seoul"
    
    # 배열 인덱스
    u.rj(name="config", keydata="items[0]")
    u.rj(name="config", keydata="items/0")
    결과: {"id": 1, "name": "Item A"}
    
    # 배열 + 키
    u.rj(name="config", keydata="items[0]/name")
    결과: "Item A"

🔧 Operations별 동작
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    read
        keydata 경로의 값 반환
        u.rj(name="config", keydata="user/email")
        
    update
        keydata 경로의 값만 업데이트 (나머지 유지)
        u.uj(name="config", keydata="user/email", data="new@example.com")
        
    delete
        keydata 경로만 삭제 (파일은 유지)
        u.dj(name="config", keydata="user/temp_data")
        
    exists
        keydata 경로 존재 여부 확인
        u.ej(name="config", keydata="user/email")

⚙️ 고급 옵션
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    default
        keydata 없을 때 기본값
        u.rj(keydata="user/phone", default="N/A")
        
    recursive
        재귀적으로 모든 매칭 경로 탐색
        u.rj(keydata="email", recursive=True)
        
    find_all
        모든 매칭 값 반환 (리스트)
        u.rj(keydata="items/*/name", find_all=True)
        
    create_missing
        중간 경로 자동 생성 (update/write)
        u.uj(keydata="new/deep/path", data="value", create_missing=True)

🎨 Pattern + keydata 조합
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    # 여러 파일의 특정 필드만 읽기
    u.rj(name="user_*", keydata="email")
    [
        {"file": "user_001", "data": "alice@example.com"},
        {"file": "user_002", "data": "bob@example.com"}
    ]
    
    # 여러 파일의 특정 필드 삭제
    u.dj(name="user_*", keydata="profile/temp_data")
    {
        "deleted": [Path(...), Path(...)],
        "success": 2
    }
"""

# Path: usekit.infra.help_system.py (Part 3)
# -----------------------------------------------------------------------------------------------
#  MOSA Help System - Examples, Quick Start & Helper Function
# -----------------------------------------------------------------------------------------------

HELP_EXAMPLES = """
╔══════════════════════════════════════════════════════════════════════════╗
║  사용 예시 (Examples)                                                    ║
╚══════════════════════════════════════════════════════════════════════════╝

🎯 기본 사용
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    # 읽기
    data = u.rj()                    # config.json 읽기 (기본)
    data = u.rj(name="users")        # users.json 읽기
    
    # 쓰기
    u.wj(data={"key": "value"})      # dumps 쓰기
    u.wj(data={"key": "value"}, name="new_file")
    
    # 업데이트
    u.uj(data={"new": "data"})       # 병합
    
    # 삭제
    u.dj(name="old_file")            # 파일 삭제
    
    # 존재 확인
    if u.ej(name="config"):
        print("파일 있음")

📍 위치 지정
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    # 하위 디렉토리
    u.rjs(name="config")             # data/json/json_sub/config.json
    
    # 현재 디렉토리
    u.rjn(name="local")              # 실행경로
    
    # 임시 디렉토리
    u.wjt(data={"temp": "data"})     # tmp/config.json

🎨 패턴 매칭
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    # 모든 user 파일 읽기
    users = u.rj(name="user_*")
    for user in users:
        print(user["file"], user["data"])
    
    # 특정 패턴 검색
    logs = u.rj(name="log_2024*", walk=True)
    
    # 임시 파일 삭제
    result = u.djt(name="temp_*")
    print(f"삭제: {result['success']}개")

🔍 keydata 활용
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    # 중첩 경로 읽기
    email = u.rj(name="config", keydata="user/email")
    
    # 중첩 경로 업데이트
    u.uj(name="config", keydata="user/name", data="Bob")
    
    # 배열 접근
    first_item = u.rj(keydata="items[0]/name")
    
    # 여러 파일의 특정 필드
    emails = u.rj(name="user_*", keydata="email")

🔄 재귀 검색
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    # 모든 하위 디렉토리 검색
    configs = u.rj(name="config_*", walk=True)
    
    # 특정 디렉토리 기준 재귀 검색
    u.rjs(name="settings_*", walk=True)

🎭 실전 예시
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    # 1. 사용자 데이터 관리
    # 새 사용자 추가
    u.wj(name="user_alice", data={
        "name": "Alice",
        "email": "alice@example.com",
        "created": "2024-11-07"
    })
    
    # 이메일만 업데이트
    u.uj(name="user_alice", keydata="email", data="newemail@example.com")
    
    # 모든 사용자 이메일 조회
    emails = u.rj(name="user_*", keydata="email")
    
    # 2. 설정 파일 관리
    # 기본 설정 읽기
    config = u.rj(name="config")
    
    # 특정 설정 업데이트
    u.uj(keydata="database/host", data="localhost")
    
    # 3. 임시 데이터 정리
    # 오래된 임시 파일 삭제
    result = u.djt(name="cache_*")
    print(f"{result['success']}개 파일 삭제")
    
    # 4. 로그 분석
    # 최근 로그 파일 찾기
    logs = u.rj(name="log_20241107_*", walk=True)
    for log in logs:
        print(log["path"])

💎 고급 패턴
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    # 조건부 업데이트
    if u.ej(name="config"):
        u.uj(data={"updated": "2024-11-07"})
    else:
        u.wj(data={"created": "2024-11-07"})
    
    # 배치 처리
    for user_file in u.lj():
        data = u.rj(name=user_file)
        # 처리 로직
        u.uj(name=user_file, data=processed_data)
    
    # 백업 생성
    data = u.rj(name="important")
    u.wjt(name=f"backup_{datetime.now():%Y%m%d}", data=data)
"""


HELP_QUICK = """
╔══════════════════════════════════════════════════════════════════════════╗
║  빠른 시작 가이드 (Quick Start)                                          ║
╚══════════════════════════════════════════════════════════════════════════╝

⚡ 5분 만에 시작하기
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

1️⃣ 가장 기본 (JSON 파일) - small -> big -> option
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    # 쓰기
    u.wj(data={"name": "Alice", "age": 25})
    
    # 읽기
    data = u.rj()
    print(data["name"])  # Alice
    
    # 업데이트
    u.uj(data={"age": 26})
    
    # 삭제
    u.dj()

2️⃣ 이름 지정하기
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    # 파일명 지정
    u.wj(data={"alice": {...}},name="users")
    u.rj(name="users")
    
    # 확장자는 자동 추가됨 (users.json)     
    # 파일명 미지정시 가상메모리(dumps)

3️⃣ 위치 바꾸기
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    u.rjb()    # base 디렉토리 (기본)
    u.rjs()    # sub 디렉토리 (yaml 지정 경로)
    u.rjn()    # 현재 디렉토리 ()     
    u.rjd()   # 특정 경로 디렉토리 (user/)
    u.rjt()    # 임시 디렉토리 (tmp/)     
    u.rjc( cus= "use01")    # 생략시 data/custom

4️⃣ 여러 파일 다루기
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    # user_로 시작하는 모든 파일
    users = u.rj(name="user_*")
    for user in users:
        print(user["file"], user["data"])

5️⃣ 중첩 데이터 접근
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    # 데이터: {"user": {"profile": {"email": "a@b.com"}}}
    
    # 이메일만 읽기
    email = u.rj(keydata="user/profile/email")
    
    # 이메일만 업데이트
    u.uj(keydata="user/profile/email", data="new@example.com")

📝 다른 포맷 사용
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    u.wy()     # YAML
    u.wt()     # Text
    u.wc()     # CSV
    u.wm()     # Markdown

🎯 핵심 패턴 3가지
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    1. 기본 사용
       u.rj()  u.wj()  u.uj()  u.dj()
    
    2. 이름 + 위치
       u.rjs(name="config")
    
    3. 패턴 + keydata
       u.rj(name="user_*", keydata="email")

💡 외우기 쉬운 방법
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    u.[무엇을][어떤포맷][어디서] / 동사 목적어 부사
    
    u.r j b    →  use.read.json.base
      ↑ ↑ ↑
      읽기/쓰기  json/yaml  base/sub
      
    예시:
    u.rjb()    read json base
    u.wys()    write yaml sub
    u.ujt()    update json tmp

🚀 바로 시작하기
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    # 1단계: 데이터 쓰기
    u.wj(data={"hello": "MOSA"})
    
    # 2단계: 데이터 읽기
    print(u.rj())
    
    # 3단계: 수정하기
    u.uj(data={"version": "1.0"})
    
    # 완료! 🎉

📚 더 알아보기
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    u.help("examples")    # 더 많은 예시
    u.help("pattern")     # 패턴 매칭 상세
    u.help("keydata")     # keydata 상세
"""


# ===============================================================================
# Help Display Function
# ===============================================================================

def show_help(topic: Optional[str] = None) -> None:
    """
    MOSA 도움말 표시
    
    Args:
        topic: 도움말 주제 (없으면 전체 개요)
    """
    if topic is None:
        print(HELP_OVERVIEW)
        print("\n📚 사용 가능한 도움말 주제:")
        print("━" * 74)
        for key, desc in HELP_TOPICS.items():
            print(f"  u.help('{key:12s}')  # {desc}")
        return
    
    topic = topic.lower().strip()
    
    help_map = {
        "overview": HELP_OVERVIEW,
        "alias": HELP_ALIAS,
        "action": HELP_ACTION,
        "pattern": HELP_PATTERN,
        "walk": HELP_WALK,
        "keydata": HELP_KEYDATA,
        "examples": HELP_EXAMPLES,
        "quick": HELP_QUICK,
    }
    
    if topic in help_map:
        print(help_map[topic])
    else:
        print(f"❌ '{topic}' 주제를 찾을 수 없습니다.\n")
        print("📚 사용 가능한 주제:")
        for key, desc in HELP_TOPICS.items():
            print(f"  • {key:12s} - {desc}")


# ===============================================================================
# Export
# ===============================================================================

__all__ = [
    "HELP_TOPICS",
    "HELP_OVERVIEW",
    "HELP_ALIAS",
    "HELP_ACTION",
    "HELP_PATTERN",
    "HELP_WALK",
    "HELP_KEYDATA",
    "HELP_EXAMPLES",
    "HELP_QUICK",
    "show_help",
]