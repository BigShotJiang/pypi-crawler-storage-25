#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};

use crate::{phoneme::Phoneme, prosody::ProsodicPhoneme};

/// Word と `Phoneme` リストのペア。
#[derive(Debug, Clone, PartialEq)]
#[cfg_attr(feature = "serde", derive(Serialize, Deserialize))]
pub struct WordPhonemePair {
    pub word: String,
    pub phonemes: Vec<Phoneme>,
}

/// Word と `Phoneme` リストに加えて、未知語かどうか・OpenJTalk などで無視されるかどうかを表すフラグをもつ構造体。
#[derive(Debug, Clone, PartialEq)]
#[cfg_attr(feature = "serde", derive(Serialize, Deserialize))]
pub struct WordPhonemeMap {
    /// Word (表層系・辞書エントリを意味しない)
    pub word: String,
    pub phonemes: Vec<Phoneme>,

    /// 元となった形態素について、MeCab が未知語 (`MECAB_UNK_NODE`) と判定したかどうか。
    ///
    /// NJDの処理によって複数の形態素が結合された場合は、その中に1つでも未知語が含まれていれば `true` となる。
    pub is_unknown: bool,

    /// `pyopenjtalk` のパイプラインで無視される対象 ("記号,空白") として空白 (`sp`) に置き換えられたか、
    /// または NJD/JPCommon の処理結果として音素が1つも割り当てられなかったかどうか。
    ///
    /// (e.g., 先頭の `ー` など、他の形態素に長音として吸収されず破棄されたケース)
    pub is_ignored: bool,
}

/// Word と `Phoneme` リスト、未知語・無視フラグに加えて、Mecab の解析情報をもつ構造体。
#[derive(Debug, Clone, PartialEq)]
#[cfg_attr(feature = "serde", derive(Serialize, Deserialize))]
pub struct WordPhonemeDetail {
    /// Word (表層系・辞書エントリを意味しない)
    pub word: String,
    pub phonemes: Vec<Phoneme>,

    /// Mecab が出力した features。
    /// 既知語は 12 列、未知語は 8 列 (read, pron, acc, chain_rule がない)
    pub features: Vec<String>,

    /// 品詞
    pub pos: String,
    /// 品詞細分類1
    pub pos_group1: String,
    /// 品詞細分類2
    pub pos_group2: String,
    /// 品詞細分類3
    pub pos_group3: String,

    /// 活用型
    pub ctype: String,
    /// 活用形
    pub cform: String,

    /// 原形
    pub orig: String,
    /// 読み
    pub read: String,
    /// 発音形式
    pub pron: String,

    /// アクセント核位置 (0: 平板型, 1-n: n番目のモーラにアクセント核)
    pub accent_nucleus: i32,
    /// モーラ数
    pub mora_count: i32,
    /// アクセント結合規則 (C1-C5/F1-F5/P1-P2 等)
    pub chain_rule: String,
    /// アクセント句連結フラグ
    pub chain_flag: i32,

    /// 元となった形態素について、MeCab が未知語 (`MECAB_UNK_NODE`) と判定したかどうか。
    ///
    /// NJDの処理によって複数の形態素が結合された場合は、その中に1つでも未知語が含まれていれば `true` となる。
    pub is_unknown: bool,

    /// `pyopenjtalk` のパイプラインで無視される対象 ("記号,空白") として空白 (`sp`) に置き換えられたか、
    /// または NJD/JPCommon の処理結果として音素が1つも割り当てられなかったかどうか。
    ///
    /// (e.g., 先頭の `ー` など、他の形態素に長音として吸収されず破棄されたケース)
    pub is_ignored: bool,
}

/// プロソディ情報つきの [ProsodicPhoneme] のリストや表層系、未知語・無視フラグ、Mecab の解析情報を表す構造体。
#[derive(Debug, Clone, PartialEq)]
#[cfg_attr(feature = "serde", derive(Serialize, Deserialize))]
pub struct WordPhonemeProsody {
    /// Word (表層系・辞書エントリを意味しない)
    pub word: String,
    pub phonemes: Vec<ProsodicPhoneme>,

    /// 品詞
    pub pos: String,
    /// 品詞細分類1
    pub pos_group1: String,
    /// 品詞細分類2
    pub pos_group2: String,
    /// 品詞細分類3
    pub pos_group3: String,

    /// 活用型
    pub ctype: String,
    /// 活用形
    pub cform: String,

    /// 原形
    pub orig: String,
    /// 読み
    pub read: String,
    /// 発音形式
    pub pron: String,

    /// アクセント核位置 (0: 平板型, 1-n: n番目のモーラにアクセント核)
    pub accent_nucleus: i32,
    /// モーラ数
    pub mora_count: i32,
    /// アクセント結合規則 (C1-C5/F1-F5/P1-P2 等)
    pub chain_rule: String,
    /// アクセント句連結フラグ
    pub chain_flag: i32,

    /// 元となった形態素について、MeCab が未知語 (`MECAB_UNK_NODE`) と判定したかどうか。
    ///
    /// NJDの処理によって複数の形態素が結合された場合は、その中に1つでも未知語が含まれていれば `true` となる。
    pub is_unknown: bool,

    /// `pyopenjtalk` のパイプラインで無視される対象 ("記号,空白") として空白 (`sp`) に置き換えられたか、
    /// または NJD/JPCommon の処理結果として音素が1つも割り当てられなかったかどうか。
    ///
    /// (e.g., 先頭の `ー` など、他の形態素に長音として吸収されず破棄されたケース)
    pub is_ignored: bool,
}
