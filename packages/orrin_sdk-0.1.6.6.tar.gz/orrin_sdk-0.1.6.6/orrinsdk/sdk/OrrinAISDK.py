from json import dumps, loads
from typing import Dict, List
from enum import Enum
import requests
from xai_sdk import Client
from xai_sdk.chat import user, system, image
from xai_sdk.tools import web_search, x_search, code_execution
from openai import OpenAI
from anthropic import Anthropic

class Models(list, Enum):
    # Grok Models
    GROK_4_2_FNR =              ["grok", "grok-4.20-0309-non-reasoning"]
    GROK_4_2_FR =               ["grok", "grok-4.20-0309-reasoning"]
    GROK_4_1_FNR =              ["grok", "grok-4-1-fast-non-reasoning"]
    GROK_4_1_FR =               ["grok", "grok-4-1-fast-reasoning"]

    # OpenAI Models
    GPT_5_5 =                   ["gpt", "gpt-5.5"]
    GPT_5_5_PRO =               ["gpt", "gpt-5.5-pro"]
    GPT_5_4 =                   ["gpt", "gpt-5.4"]
    GPT_5_4_MINI =              ["gpt", "gpt-5.4-mini"]
    GPT_5_4_NANO =              ["gpt", "gpt-5.4-nano"]
    GPT_5 =                     ["gpt", "gpt-5"]
    GPT_5_MINI =                ["gpt", "gpt-5-mini"]
    GPT_5_NANO =                ["gpt", "gpt-5-nano"]

    # Claude
    CLAUDE_OPUS_4_6 =           ["claude", "claude-opus-4-6"]
    CLAUDE_SONNET_4_6 =         ["claude", "claude-sonnet-4-6"]

class OrrinAISDK:
    def __init__(self, api_key: str, model: Models):
        self.api_key = api_key
        self.brand = model.value[0]
        self.model = model.value[1]
    
    def chat(
        self,
        messages: list,
        tools: List[Dict[str, str]] = []
    ):
        all_messages = []

        match self.brand:
            case 'grok':
                client = Client(api_key=self.api_key)
                tools_config = []
                chats = []

                for tool in tools:
                    match tool['type']:
                        case 'schema':
                            try:
                                tool_id = tool['tool_id']
                                resp = requests.get('https://api.stellr-company.com/v1/tool_schematic', headers={
                                    'tool-id': tool_id
                                })

                                if resp.ok:
                                    resp = resp.json()

                                    chats.append(system(
                                        f"You will have access to the tool {resp['tool_name']}. Below is the schematic of the tool, its actions, and how you can use it:"
                                        f"{resp['schematic']}"
                                        "If you believe this tool should be used, or any of its actions, respond with `USE TOOL:`, followed by the metadata needed for that tool to be used."
                                    ))
                            except: pass
                        case 'web_search':
                            tools_config.append(web_search(enable_image_understanding=True))
                        case 'x_search':
                            tools_config.append(x_search())
                        case 'code_execution':
                            tools_config.append(code_execution())
                        case _:
                            break
                
                for message in messages:
                    if message['role'] == 'system':
                        chats.append(system(message['content']))
                        continue

                    if message['role'] == 'user':
                        chats.append(user(message['content']))
                        continue
                
                chat = client.chat.create(
                    model=self.model,  # reasoning model
                    messages=chats,
                    tools=tools_config
                )
                is_thinking = True
                content = ''

                for response, chunk in chat.stream():
                    if chunk.content and is_thinking:
                        is_thinking = False

                    if chunk.content and not is_thinking:
                        content += chunk.content
                
                return content
            case 'gpt':
                client = OpenAI(api_key=self.api_key)

                tools_config = []
                tool_id = ''
                chats = []

                for tool in tools:
                    if tool['type'] == 'schema':
                        try:
                            tool_id = tool['tool_id']
                            resp = requests.get('https://api.stellr-company.com/v1/tool_schematic', headers={
                                'tool-id': tool_id
                            })

                            if resp.ok:
                                resp = resp.json()

                                chats.append({
                                    'role': 'system',
                                    'content': f'''You will have access to the tool {resp['tool_name']}. Below is the schematic of the tool, its actions, and how you can use it:
                                    {resp['schematic']}

                                    If you believe this tool should be used, or any of its actions, respond with `USE TOOL:`, followed
                                    by the metadata needed for that tool to be used on the same line (no newlines).

                                    An example of the metadata needed for the tool will be:
                                    {{"actionID": <actionID>, "payload": <payload_needed>}}
                                    '''
                                })
                        except: pass

                        continue

                    tools_config.append(tool)
                
                for message in messages:
                    chats.append(message)

                resp = client.responses.create(
                    model=self.model,
                    input=chats,
                    tools=tools_config
                )

                if 'USE TOOL:' in resp.output_text:
                    resp = resp.output_text.replace('USE TOOL:', '').rstrip()
                    resp = loads(resp)
                    
                    action = resp["actionID"]
                    payload = resp["payload"]

                    r = requests.post('https://api.stellr-company.com/v1/tools', headers={
                        'authorization': '922785tyu33er93se111093kloi'
                    }, json={
                        'toolId': tool_id,
                        'action': action,
                        'payload': payload
                    })

                    if r.ok:
                        r = r.json()
                        return dumps(r, indent=2)
                    else:
                        try:
                            return dumps({
                                'status': '500',
                                'message': 'something went wrong',
                                'result': r.json()
                            })
                        except:
                            return dumps({
                                'status': '500',
                                'message': 'something went wrong'
                            })
                return resp.output_text
            case 'claude':
                client = Anthropic(api_key=self.api_key)

                chats = []

                for tool in tools:
                    if tool['type'] == 'schema':
                        try:
                            tool_id = tool['tool_id']
                            resp = requests.get('https://api.stellr-company.com/v1/tool_schematic', headers={
                                'tool-id': tool_id
                            })

                            if resp.ok:
                                resp = resp.json()

                                chats.append({
                                    'role': 'system',
                                    'content': f'''You will have access to the tool {resp['tool_name']}. Below is the schematic of the tool, its actions, and how you can use it:
                                    {resp['schematic']}'''
                                })
                        except: pass

                        continue
                
                for message in messages:
                    chats.append(message)

                resp = client.messages.create(
                    model=self.model,
                    messages=chats
                )

                return resp.content