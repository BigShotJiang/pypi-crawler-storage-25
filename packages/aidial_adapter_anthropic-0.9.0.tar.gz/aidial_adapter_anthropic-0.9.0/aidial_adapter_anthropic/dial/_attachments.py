from __future__ import annotations

import inspect
from collections.abc import AsyncIterator, Callable, Sequence
from contextlib import suppress
from dataclasses import dataclass, field
from typing import (
    Generic,
    Protocol,
    TypeVar,
    assert_never,
    runtime_checkable,
)

from aidial_sdk.chat_completion import (
    Attachment,
    InputAudio,
    InputFile,
    MessageContentAudioPart,
    MessageContentFilePart,
    MessageContentImagePart,
    MessageContentRefusalPart,
    MessageContentTextPart,
)
from pydantic import BaseModel

from aidial_adapter_anthropic._utils.list import aiter_to_list
from aidial_adapter_anthropic._utils.resource import Resource
from aidial_adapter_anthropic.adapter._errors import UserError, ValidationError
from aidial_adapter_anthropic.dial._message import (
    BaseMessage,
    HumanToolResultMessage,
    SystemMessage,
)
from aidial_adapter_anthropic.dial.resource import (
    AttachmentResource,
    DialResource,
    UnsupportedContentType,
    URLResource,
)
from aidial_adapter_anthropic.dial.storage import FileStorage

_T = TypeVar("_T", covariant=True)
_Txt = TypeVar("_Txt", covariant=True)
_Config = TypeVar("_Config", bound=BaseModel, contravariant=True)

AttachmentSourceMessage = BaseMessage | HumanToolResultMessage


@runtime_checkable
class Handler(Protocol, Generic[_T]):
    def __call__(self, resource: Resource) -> _T: ...


@runtime_checkable
class HandlerWithConfig(Protocol, Generic[_T, _Config]):
    def __call__(self, resource: Resource, config: _Config | None) -> _T: ...


@dataclass
class AttachmentProcessor(Generic[_T, _Config]):
    supported_types: dict[str, set[str]]
    """MIME type to file extensions mapping"""

    handler: Handler[_T] | HandlerWithConfig[_T, _Config]

    def handle(self, resource: Resource, config: _Config | None) -> _T:
        sig = inspect.signature(self.handler)
        params = list(sig.parameters.values())

        with_config = (
            len(params) >= 2
            and params[1].kind
            in (
                inspect.Parameter.POSITIONAL_ONLY,
                inspect.Parameter.POSITIONAL_OR_KEYWORD,
            )
        ) or any(p.kind is inspect.Parameter.VAR_KEYWORD for p in params)

        if with_config:
            return self.handler(resource, config)  # type: ignore
        return self.handler(resource)  # type: ignore


@dataclass
class WithResources(Generic[_T]):
    payload: _T
    resources: list[DialResource] = field(default_factory=list)

    @staticmethod
    def transpose(xs: list[WithResources[_T]]) -> WithResources[list[_T]]:
        resources = [r for x in xs for r in x.resources]
        payload = [x.payload for x in xs]
        return WithResources(payload=payload, resources=resources)


@dataclass
class AttachmentProcessors(Generic[_Txt, _T, _Config]):
    attachment_processors: Sequence[AttachmentProcessor[_T, _Config]]
    text_handler: Callable[[str], _Txt]
    file_storage: FileStorage | None
    config: _Config | None = field(default=None)

    @property
    def supported_types(self) -> dict[str, set[str]]:
        ret: dict[str, set[str]] = {}
        for processor in self.attachment_processors:
            for mime_type, file_exts in processor.supported_types.items():
                ret.setdefault(mime_type, set()).update(file_exts)
        return ret

    @property
    def supported_mime_types(self) -> list[str]:
        return list(self.supported_types)

    @property
    def supported_image_types(self) -> list[str]:
        return [t for t in self.supported_mime_types if t.startswith("image/")]

    def _text_handler(self, text: str) -> WithResources[_Txt]:
        return WithResources(self.text_handler(text))

    async def process_system_message(
        self, message: SystemMessage
    ) -> list[_Txt]:
        def _gen():
            match content := message.content:
                case str():
                    if content:
                        yield self.text_handler(content)
                case list():
                    for part in content:
                        match part:
                            case MessageContentTextPart(text=text):
                                if text:
                                    yield self.text_handler(text)
                            case _:
                                assert_never(part)
                case _:
                    assert_never(content)

        return list(_gen())

    async def process_attachments(
        self, message: AttachmentSourceMessage
    ) -> WithResources[list[_T | _Txt]]:
        ret = await aiter_to_list(self._process_attachments_iter(message))
        ret = ret or [self._text_handler(" ")]
        return WithResources.transpose(ret)

    async def _process_attachments_iter(
        self, message: AttachmentSourceMessage
    ) -> AsyncIterator[WithResources[_T | _Txt]]:
        if not isinstance(message, SystemMessage):
            for attachment in message.attachments:
                yield await self._handle_dial_resource(
                    AttachmentResource(
                        attachment=attachment,
                        entity_name="attachment",
                        supported_types=self.supported_mime_types,
                    ),
                )

        content = message.content

        match content:
            case str():
                if content:
                    yield self._text_handler(content)
            case list():
                for part in content:
                    match part:
                        case MessageContentTextPart(text=text):
                            if text:
                                yield self._text_handler(text)
                        case MessageContentImagePart(image_url=image_url):
                            yield await self._handle_dial_resource(
                                URLResource(
                                    url=image_url.url,
                                    entity_name="image content part",
                                    supported_types=self.supported_image_types,
                                ),
                            )
                        case MessageContentFilePart(file=file):
                            attachment = _file_content_part_to_attachment(file)
                            yield await self._handle_dial_resource(
                                AttachmentResource(
                                    attachment=attachment,
                                    entity_name="file content part",
                                    supported_types=self.supported_mime_types,
                                ),
                            )
                        case MessageContentAudioPart(
                            input_audio=InputAudio(data=data, format=format)
                        ):
                            attachment = Attachment(
                                data=data, type=f"audio/{format}"
                            )
                            yield await self._handle_dial_resource(
                                AttachmentResource(
                                    attachment=attachment,
                                    entity_name="audio content part",
                                    supported_types=self.supported_mime_types,
                                ),
                            )
                        case MessageContentRefusalPart():
                            raise ValidationError(
                                "Refuse content parts aren't supported"
                            )
                        case _:
                            assert_never(part)
            case _:
                assert_never(content)

    async def _download_resource(self, dial_resource: DialResource) -> Resource:
        try:
            return await dial_resource.download(self.file_storage)
        except UnsupportedContentType as e:
            raise UserError(
                f"Unsupported media type: {e.type}",
                _get_usage_message(self.get_file_exts(e.supported_types)),
            ) from None

    async def _handle_resource(self, resource: Resource) -> _T:
        for processor in self.attachment_processors:
            if resource.type in processor.supported_types:
                return processor.handle(resource, self.config)

        raise UserError(
            f"Unsupported media type: {resource.type}",
            _get_usage_message(self.get_file_exts(self.supported_mime_types)),
        )

    async def _handle_dial_resource(
        self, dial_resource: DialResource
    ) -> WithResources[_T]:
        resource = await self._download_resource(dial_resource)
        message = await self._handle_resource(resource)
        return WithResources(message, resources=[dial_resource])

    def get_file_exts(self, mime_types: list[str]) -> list[str]:
        return [
            file_ext
            for mime_type, file_exts in self.supported_types.items()
            if mime_type in mime_types
            for file_ext in file_exts
        ]


def _file_content_part_to_attachment(file: InputFile) -> Attachment:
    if (file_data := file.file_data) is None:
        raise ValidationError("File content part must have file_data field")

    resource = None
    with suppress(Exception):
        resource = Resource.from_data_url(file_data) or Resource.from_base64(
            "application/pdf", file_data
        )

    if resource is None:
        raise ValidationError(
            f"Invalid file content part: file_data must be a valid data URL or base64 string: {file_data[:30]}..."
        ) from None

    return Attachment(data=resource.data_base64, type=resource.type)


def _get_usage_message(supported_exts: list[str]) -> str:
    document_hint = ""
    if "pdf" in supported_exts:
        document_hint = '- "Summarize the document" for a PDF document'

    return f"""
The application answers queries about attached files.
Attach file(s) and ask questions about them in the same message.

Supported attachment types: {", ".join(supported_exts)}.

Examples of queries:
- "Describe this picture" for an image
- "What are in these images? Is there any difference between them?" for multiple images
{document_hint}
""".strip()
