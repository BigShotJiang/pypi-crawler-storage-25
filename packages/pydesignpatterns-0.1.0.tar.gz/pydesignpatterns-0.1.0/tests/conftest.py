"""Shared fixtures for pypatterns tests."""
