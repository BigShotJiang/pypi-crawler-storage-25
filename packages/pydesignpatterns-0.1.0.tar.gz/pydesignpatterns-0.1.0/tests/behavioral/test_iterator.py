"""Tests for the Iterator pattern."""

from collections.abc import Iterator

import pytest

from pypatterns.behavioral.iterator import (
    BatchIterator,
    FilterIterator,
    IterableCollection,
    MappingIterator,
    PeekableIterator,
)


class NumberRange(IterableCollection[int]):
    def __init__(self, start: int, end: int) -> None:
        self.start = start
        self.end = end

    def create_iterator(self) -> Iterator[int]:
        return iter(range(self.start, self.end))


class TestIterableCollection:
    def test_create_iterator(self) -> None:
        coll = NumberRange(0, 3)
        assert list(coll.create_iterator()) == [0, 1, 2]

    def test_for_loop(self) -> None:
        coll = NumberRange(1, 4)
        assert list(coll) == [1, 2, 3]


class TestPeekableIterator:
    def test_peek_without_consuming(self) -> None:
        it = PeekableIterator([1, 2, 3])
        assert it.peek() == 1
        assert it.peek() == 1
        assert next(it) == 1

    def test_iteration(self) -> None:
        it = PeekableIterator([1, 2, 3])
        assert list(it) == [1, 2, 3]

    def test_peek_then_iterate(self) -> None:
        it = PeekableIterator([1, 2])
        it.peek()
        assert list(it) == [1, 2]

    def test_has_next(self) -> None:
        it = PeekableIterator([1])
        assert it.has_next()
        next(it)
        assert not it.has_next()

    def test_peek_empty_raises(self) -> None:
        it = PeekableIterator([])
        with pytest.raises(StopIteration):
            it.peek()


class TestFilterIterator:
    def test_filters_elements(self) -> None:
        it = FilterIterator([1, 2, 3, 4, 5], lambda x: x % 2 == 0)
        assert list(it) == [2, 4]

    def test_no_matches(self) -> None:
        it = FilterIterator([1, 3, 5], lambda x: x % 2 == 0)
        assert list(it) == []

    def test_all_match(self) -> None:
        it = FilterIterator([2, 4, 6], lambda x: x % 2 == 0)
        assert list(it) == [2, 4, 6]


class TestMappingIterator:
    def test_maps_elements(self) -> None:
        it = MappingIterator([1, 2, 3], lambda x: x * 2)
        assert list(it) == [2, 4, 6]

    def test_type_conversion(self) -> None:
        it = MappingIterator([1, 2, 3], str)
        assert list(it) == ["1", "2", "3"]

    def test_empty(self) -> None:
        it = MappingIterator([], lambda x: x)
        assert list(it) == []


class TestBatchIterator:
    def test_even_batches(self) -> None:
        it = BatchIterator([1, 2, 3, 4], batch_size=2)
        assert list(it) == [[1, 2], [3, 4]]

    def test_uneven_batches(self) -> None:
        it = BatchIterator([1, 2, 3, 4, 5], batch_size=2)
        assert list(it) == [[1, 2], [3, 4], [5]]

    def test_single_batch(self) -> None:
        it = BatchIterator([1, 2], batch_size=5)
        assert list(it) == [[1, 2]]

    def test_empty(self) -> None:
        it = BatchIterator([], batch_size=2)
        assert list(it) == []

    def test_invalid_batch_size(self) -> None:
        with pytest.raises(ValueError):
            BatchIterator([1], batch_size=0)
