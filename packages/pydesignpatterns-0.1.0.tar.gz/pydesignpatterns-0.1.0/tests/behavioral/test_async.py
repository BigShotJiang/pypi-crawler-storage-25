"""Tests for async variants of patterns."""

import pytest

from pypatterns.behavioral.chain_of_responsibility import AsyncHandler, async_chain
from pypatterns.behavioral.command import AsyncCommandInvoker
from pypatterns.behavioral.mediator import AsyncEventMediator
from pypatterns.behavioral.observer import AsyncSubject

# --- Async Observer ---

class AsyncLogger:
    def __init__(self) -> None:
        self.events: list[str] = []

    async def update(self, event: str) -> None:
        self.events.append(event)


class TestAsyncSubject:
    @pytest.mark.asyncio
    async def test_notify(self) -> None:
        subject = AsyncSubject[str]()
        logger = AsyncLogger()
        subject.subscribe(logger)
        await subject.notify("hello")
        assert logger.events == ["hello"]

    @pytest.mark.asyncio
    async def test_callable_observer(self) -> None:
        subject = AsyncSubject[int]()
        received: list[int] = []

        async def handler(x: int) -> None:
            received.append(x)

        subject.subscribe(handler)
        await subject.notify(42)
        assert received == [42]

    @pytest.mark.asyncio
    async def test_multiple_observers_concurrent(self) -> None:
        subject = AsyncSubject[str]()
        log: list[str] = []

        async def h1(e: str) -> None:
            log.append("h1")

        async def h2(e: str) -> None:
            log.append("h2")

        subject.subscribe(h1)
        subject.subscribe(h2)
        await subject.notify("event")
        assert sorted(log) == ["h1", "h2"]

    @pytest.mark.asyncio
    async def test_unsubscribe(self) -> None:
        subject = AsyncSubject[str]()
        logger = AsyncLogger()
        subject.subscribe(logger)
        subject.unsubscribe(logger)
        await subject.notify("ignored")
        assert logger.events == []

    @pytest.mark.asyncio
    async def test_empty_notify(self) -> None:
        subject = AsyncSubject[str]()
        await subject.notify("nothing")  # should not raise


# --- Async Chain of Responsibility ---

class AsyncPassThrough(AsyncHandler[str]):
    async def handle(self, request: str) -> str | None:
        return await super().handle(request)


class AsyncUpperCase(AsyncHandler[str]):
    async def handle(self, request: str) -> str | None:
        return await super().handle(request.upper())


class AsyncFilter(AsyncHandler[str]):
    async def handle(self, request: str) -> str | None:
        if "spam" in request:
            return None
        return await super().handle(request)


class TestAsyncHandler:
    @pytest.mark.asyncio
    async def test_single_handler(self) -> None:
        h = AsyncPassThrough()
        assert await h.handle("test") == "test"

    @pytest.mark.asyncio
    async def test_chain(self) -> None:
        head = async_chain(AsyncFilter(), AsyncUpperCase())
        assert await head.handle("hello") == "HELLO"
        assert await head.handle("spam") is None

    @pytest.mark.asyncio
    async def test_rshift(self) -> None:
        h1 = AsyncFilter()
        h2 = AsyncUpperCase()
        result = h1 >> h2
        assert result is h1
        assert await h1.handle("hi") == "HI"


# --- Async Command ---

class AsyncAddCommand:
    def __init__(self, receiver: list[str], value: str) -> None:
        self.receiver = receiver
        self.value = value

    async def execute(self) -> None:
        self.receiver.append(self.value)

    async def undo(self) -> None:
        self.receiver.remove(self.value)


class TestAsyncCommandInvoker:
    @pytest.mark.asyncio
    async def test_submit(self) -> None:
        items: list[str] = []
        invoker = AsyncCommandInvoker()
        await invoker.submit(AsyncAddCommand(items, "a"))
        assert items == ["a"]

    @pytest.mark.asyncio
    async def test_undo(self) -> None:
        items: list[str] = []
        invoker = AsyncCommandInvoker()
        await invoker.submit(AsyncAddCommand(items, "a"))
        await invoker.undo()
        assert items == []

    @pytest.mark.asyncio
    async def test_redo(self) -> None:
        items: list[str] = []
        invoker = AsyncCommandInvoker()
        await invoker.submit(AsyncAddCommand(items, "a"))
        await invoker.undo()
        await invoker.redo()
        assert items == ["a"]

    @pytest.mark.asyncio
    async def test_undo_empty_raises(self) -> None:
        invoker = AsyncCommandInvoker()
        with pytest.raises(IndexError):
            await invoker.undo()


# --- Async Event Mediator ---

class TestAsyncEventMediator:
    @pytest.mark.asyncio
    async def test_notify(self) -> None:
        mediator = AsyncEventMediator()
        received: list[str] = []

        async def handler(sender: object, **kw: object) -> None:
            received.append("handled")

        mediator.on("click", handler)
        await mediator.notify(self, "click")
        assert received == ["handled"]

    @pytest.mark.asyncio
    async def test_kwargs(self) -> None:
        mediator = AsyncEventMediator()
        data: dict = {}

        async def handler(sender: object, **kw: object) -> None:
            data.update(kw)

        mediator.on("data", handler)
        await mediator.notify(self, "data", value=42)
        assert data == {"value": 42}

    @pytest.mark.asyncio
    async def test_off(self) -> None:
        mediator = AsyncEventMediator()
        log: list[str] = []

        async def handler(sender: object, **kw: object) -> None:
            log.append("x")

        mediator.on("e", handler)
        mediator.off("e", handler)
        await mediator.notify(self, "e")
        assert log == []

    @pytest.mark.asyncio
    async def test_empty_notify(self) -> None:
        mediator = AsyncEventMediator()
        await mediator.notify(self, "nope")  # should not raise
