"""Tests for the Strategy pattern."""

from pypatterns.behavioral.strategy import Strategy, StrategyContext


class SortAscending:
    def execute(self, data: list[int]) -> list[int]:
        return sorted(data)


class SortDescending:
    def execute(self, data: list[int]) -> list[int]:
        return sorted(data, reverse=True)


class TestStrategy:
    def test_protocol_compliance(self) -> None:
        assert isinstance(SortAscending(), Strategy)

    def test_callable_not_strategy(self) -> None:
        # A plain callable doesn't have .execute, so it's not a Strategy
        assert not isinstance(sorted, Strategy)


class TestStrategyContext:
    def test_with_callable(self) -> None:
        ctx = StrategyContext[list[int], list[int]](sorted)
        assert ctx.execute([3, 1, 2]) == [1, 2, 3]

    def test_with_strategy_object(self) -> None:
        ctx = StrategyContext[list[int], list[int]](SortAscending())
        assert ctx.execute([3, 1, 2]) == [1, 2, 3]

    def test_swap_strategy(self) -> None:
        ctx = StrategyContext[list[int], list[int]](SortAscending())
        assert ctx.execute([3, 1, 2]) == [1, 2, 3]

        ctx.set_strategy(SortDescending())
        assert ctx.execute([3, 1, 2]) == [3, 2, 1]

    def test_swap_to_callable(self) -> None:
        ctx = StrategyContext[list[int], list[int]](SortAscending())
        ctx.set_strategy(lambda x: list(reversed(x)))
        assert ctx.execute([3, 1, 2]) == [2, 1, 3]

    def test_strategy_property(self) -> None:
        strategy = SortAscending()
        ctx = StrategyContext[list[int], list[int]](strategy)
        assert ctx.strategy is strategy

    def test_with_string_strategy(self) -> None:
        ctx = StrategyContext[str, str](str.upper)
        assert ctx.execute("hello") == "HELLO"
