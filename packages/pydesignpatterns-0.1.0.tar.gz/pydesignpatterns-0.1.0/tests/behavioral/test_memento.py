"""Tests for the Memento pattern."""

import time

import pytest

from pypatterns.behavioral.memento import Caretaker, Memento, Originator


class Editor(Originator[str]):
    def __init__(self) -> None:
        self.content: str = ""

    def save(self) -> Memento[str]:
        return Memento(state=self.content, timestamp=time.time())

    def restore(self, memento: Memento[str]) -> None:
        self.content = memento.state


class TestMemento:
    def test_is_immutable(self) -> None:
        m = Memento(state="hello", timestamp=1.0)
        with pytest.raises(AttributeError):
            m.state = "changed"  # type: ignore[misc]

    def test_stores_state(self) -> None:
        m = Memento(state={"hp": 100}, timestamp=1.0)
        assert m.state == {"hp": 100}

    def test_has_timestamp(self) -> None:
        before = time.time()
        m = Memento(state="x", timestamp=time.time())
        assert m.timestamp >= before


class TestOriginator:
    def test_save_and_restore(self) -> None:
        editor = Editor()
        editor.content = "hello"
        memento = editor.save()
        editor.content = "changed"
        editor.restore(memento)
        assert editor.content == "hello"


class TestCaretaker:
    def test_backup_and_undo(self) -> None:
        editor = Editor()
        caretaker = Caretaker[str]()

        editor.content = "v1"
        caretaker.backup(editor)

        editor.content = "v2"
        caretaker.backup(editor)

        editor.content = "v3"
        caretaker.undo(editor)
        assert editor.content == "v2"
        caretaker.undo(editor)
        assert editor.content == "v1"

    def test_undo_empty_raises(self) -> None:
        caretaker = Caretaker[str]()
        editor = Editor()
        with pytest.raises(IndexError):
            caretaker.undo(editor)

    def test_history_count(self) -> None:
        caretaker = Caretaker[str]()
        editor = Editor()
        assert caretaker.history_count == 0
        caretaker.backup(editor)
        assert caretaker.history_count == 1

    def test_clear(self) -> None:
        caretaker = Caretaker[str]()
        editor = Editor()
        caretaker.backup(editor)
        caretaker.clear()
        assert caretaker.history_count == 0
