"""Tests for the Command pattern."""

import pytest

from pypatterns.behavioral.command import Command, CommandInvoker, SimpleCommand


class AddCommand(SimpleCommand):
    def __init__(self, receiver: list[str], value: str) -> None:
        self.receiver = receiver
        self.value = value

    def execute(self) -> None:
        self.receiver.append(self.value)

    def undo(self) -> None:
        self.receiver.remove(self.value)


class TestCommand:
    def test_protocol_compliance(self) -> None:
        assert isinstance(AddCommand([], "x"), Command)

    def test_execute(self) -> None:
        items: list[str] = []
        cmd = AddCommand(items, "hello")
        cmd.execute()
        assert items == ["hello"]

    def test_undo(self) -> None:
        items: list[str] = ["hello"]
        cmd = AddCommand(items, "hello")
        cmd.undo()
        assert items == []


class TestCommandInvoker:
    def test_submit_executes(self) -> None:
        items: list[str] = []
        invoker = CommandInvoker()
        invoker.submit(AddCommand(items, "a"))
        assert items == ["a"]

    def test_undo(self) -> None:
        items: list[str] = []
        invoker = CommandInvoker()
        invoker.submit(AddCommand(items, "a"))
        invoker.submit(AddCommand(items, "b"))
        invoker.undo()
        assert items == ["a"]

    def test_redo(self) -> None:
        items: list[str] = []
        invoker = CommandInvoker()
        invoker.submit(AddCommand(items, "a"))
        invoker.undo()
        assert items == []
        invoker.redo()
        assert items == ["a"]

    def test_undo_empty_raises(self) -> None:
        invoker = CommandInvoker()
        with pytest.raises(IndexError):
            invoker.undo()

    def test_redo_empty_raises(self) -> None:
        invoker = CommandInvoker()
        with pytest.raises(IndexError):
            invoker.redo()

    def test_submit_clears_redo(self) -> None:
        items: list[str] = []
        invoker = CommandInvoker()
        invoker.submit(AddCommand(items, "a"))
        invoker.undo()
        invoker.submit(AddCommand(items, "b"))
        assert not invoker.can_redo

    def test_history(self) -> None:
        invoker = CommandInvoker()
        cmd = AddCommand([], "a")
        invoker.submit(cmd)
        assert len(invoker.history) == 1
        assert invoker.history[0] is cmd

    def test_can_undo_redo(self) -> None:
        invoker = CommandInvoker()
        assert not invoker.can_undo
        assert not invoker.can_redo
        invoker.submit(AddCommand([], "a"))
        assert invoker.can_undo
        invoker.undo()
        assert invoker.can_redo
