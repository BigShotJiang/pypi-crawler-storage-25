"""Tests for the Observer pattern."""

import pytest

from pypatterns.behavioral.observer import Observer, Subject


class LogObserver:
    def __init__(self) -> None:
        self.events: list[str] = []

    def update(self, event: str) -> None:
        self.events.append(event)


class TestObserverProtocol:
    def test_protocol_compliance(self) -> None:
        assert isinstance(LogObserver(), Observer)

    def test_callable_not_observer(self) -> None:
        assert not isinstance(lambda x: x, Observer)


class TestSubject:
    def test_subscribe_and_notify(self) -> None:
        subject = Subject[str]()
        observer = LogObserver()
        subject.subscribe(observer)
        subject.notify("hello")
        assert observer.events == ["hello"]

    def test_multiple_observers(self) -> None:
        subject = Subject[str]()
        obs1 = LogObserver()
        obs2 = LogObserver()
        subject.subscribe(obs1)
        subject.subscribe(obs2)
        subject.notify("event")
        assert obs1.events == ["event"]
        assert obs2.events == ["event"]

    def test_unsubscribe(self) -> None:
        subject = Subject[str]()
        observer = LogObserver()
        subject.subscribe(observer)
        subject.unsubscribe(observer)
        subject.notify("ignored")
        assert observer.events == []

    def test_unsubscribe_unknown_raises(self) -> None:
        subject = Subject[str]()
        with pytest.raises(ValueError):
            subject.unsubscribe(LogObserver())

    def test_notify_with_no_observers(self) -> None:
        subject = Subject[str]()
        subject.notify("nothing")  # should not raise

    def test_callable_as_observer(self) -> None:
        subject = Subject[int]()
        received: list[int] = []
        subject.subscribe(received.append)
        subject.notify(42)
        assert received == [42]

    def test_no_duplicate_subscribe(self) -> None:
        subject = Subject[str]()
        observer = LogObserver()
        subject.subscribe(observer)
        subject.subscribe(observer)
        assert subject.observer_count == 1

    def test_observer_count(self) -> None:
        subject = Subject[str]()
        assert subject.observer_count == 0
        subject.subscribe(LogObserver())
        assert subject.observer_count == 1

    def test_multiple_notifications(self) -> None:
        subject = Subject[int]()
        results: list[int] = []
        subject.subscribe(results.append)
        subject.notify(1)
        subject.notify(2)
        subject.notify(3)
        assert results == [1, 2, 3]
