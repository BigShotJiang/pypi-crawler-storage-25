"""Tests for the State pattern."""

import pytest

from pypatterns.behavioral.state import Context, State


class LockedState(State["Phone"]):
    def handle(self) -> str:
        return "Phone is locked"


class UnlockedState(State["Phone"]):
    def handle(self) -> str:
        return "Phone is unlocked"


class Phone(Context):
    pass


class TestState:
    def test_initial_state(self) -> None:
        phone = Phone(LockedState())
        assert phone.request() == "Phone is locked"

    def test_transition(self) -> None:
        phone = Phone(LockedState())
        phone.transition_to(UnlockedState())
        assert phone.request() == "Phone is unlocked"

    def test_state_property(self) -> None:
        locked = LockedState()
        phone = Phone(locked)
        assert phone.state is locked

    def test_state_knows_context(self) -> None:
        phone = Phone(LockedState())
        assert phone.state.context is phone

    def test_transition_updates_context(self) -> None:
        phone = Phone(LockedState())
        unlocked = UnlockedState()
        phone.transition_to(unlocked)
        assert unlocked.context is phone

    def test_detached_state_raises(self) -> None:
        state = LockedState()
        with pytest.raises(RuntimeError):
            _ = state.context
