"""Tests for the Visitor pattern."""

import pytest

from pypatterns.behavioral.visitor import visitor


@visitor
class TypePrinter:
    def visit_int(self, element: int) -> str:
        return f"int:{element}"

    def visit_str(self, element: str) -> str:
        return f"str:{element}"

    def visit_float(self, element: float) -> str:
        return f"float:{element}"


class TestVisitorDecorator:
    def test_dispatch_int(self) -> None:
        p = TypePrinter()
        assert p.visit(42) == "int:42"

    def test_dispatch_str(self) -> None:
        p = TypePrinter()
        assert p.visit("hello") == "str:hello"

    def test_dispatch_float(self) -> None:
        p = TypePrinter()
        assert p.visit(3.14) == "float:3.14"

    def test_unknown_type_raises(self) -> None:
        p = TypePrinter()
        with pytest.raises(NotImplementedError, match="TypePrinter"):
            p.visit([1, 2, 3])

    def test_multiple_instances_independent(self) -> None:
        p1 = TypePrinter()
        p2 = TypePrinter()
        assert p1.visit(1) == "int:1"
        assert p2.visit("x") == "str:x"
