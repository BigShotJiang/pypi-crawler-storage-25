"""Tests for the Chain of Responsibility pattern."""

import pytest

from pypatterns.behavioral.chain_of_responsibility import Handler, chain


class PassThroughHandler(Handler[str]):
    def handle(self, request: str) -> str | None:
        return super().handle(request)


class UpperCaseHandler(Handler[str]):
    def handle(self, request: str) -> str | None:
        return super().handle(request.upper())


class FilterHandler(Handler[str]):
    """Filters out requests containing 'spam'."""

    def handle(self, request: str) -> str | None:
        if "spam" in request.lower():
            return None
        return super().handle(request)


class TestHandler:
    def test_single_handler(self) -> None:
        h = PassThroughHandler()
        assert h.handle("hello") == "hello"

    def test_chain_with_rshift(self) -> None:
        h1 = FilterHandler()
        h2 = UpperCaseHandler()
        h1 >> h2
        assert h1.handle("hello") == "HELLO"
        assert h1.handle("buy spam") is None

    def test_set_next_returns_next(self) -> None:
        h1 = PassThroughHandler()
        h2 = PassThroughHandler()
        result = h1.set_next(h2)
        assert result is h2

    def test_rshift_returns_self(self) -> None:
        h1 = PassThroughHandler()
        h2 = PassThroughHandler()
        result = h1 >> h2
        assert result is h1


class TestChainFunction:
    def test_chain_multiple(self) -> None:
        h1 = FilterHandler()
        h2 = UpperCaseHandler()
        h3 = PassThroughHandler()
        head = chain(h1, h2, h3)
        assert head is h1
        assert head.handle("hello") == "HELLO"

    def test_chain_single(self) -> None:
        h = PassThroughHandler()
        head = chain(h)
        assert head is h
        assert head.handle("test") == "test"

    def test_chain_empty_raises(self) -> None:
        with pytest.raises(ValueError):
            chain()

    def test_chain_filters(self) -> None:
        head = chain(FilterHandler(), UpperCaseHandler())
        assert head.handle("spam alert") is None
        assert head.handle("good message") == "GOOD MESSAGE"
