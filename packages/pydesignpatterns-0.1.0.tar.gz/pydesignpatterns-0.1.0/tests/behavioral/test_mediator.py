"""Tests for the Mediator pattern."""

import pytest

from pypatterns.behavioral.mediator import Colleague, EventMediator, Mediator


class TestMediator:
    def test_protocol_compliance(self) -> None:
        assert isinstance(EventMediator(), Mediator)


class TestColleague:
    def test_mediator_property(self) -> None:
        mediator = EventMediator()
        col = type("C", (Colleague,), {})()
        col.mediator = mediator
        assert col.mediator is mediator

    def test_no_mediator_raises(self) -> None:
        col = type("C", (Colleague,), {})()
        with pytest.raises(RuntimeError):
            _ = col.mediator


class TestEventMediator:
    def test_on_and_notify(self) -> None:
        mediator = EventMediator()
        received: list[str] = []
        mediator.on("click", lambda sender, **kw: received.append("clicked"))
        mediator.notify(self, "click")
        assert received == ["clicked"]

    def test_multiple_handlers(self) -> None:
        mediator = EventMediator()
        log: list[str] = []
        mediator.on("save", lambda s, **kw: log.append("handler1"))
        mediator.on("save", lambda s, **kw: log.append("handler2"))
        mediator.notify(self, "save")
        assert log == ["handler1", "handler2"]

    def test_notify_unknown_event_is_noop(self) -> None:
        mediator = EventMediator()
        mediator.notify(self, "nonexistent")  # should not raise

    def test_off_removes_handler(self) -> None:
        mediator = EventMediator()
        log: list[str] = []
        def handler(s: object, **kw: object) -> None:
            log.append("x")

        mediator.on("e", handler)
        mediator.off("e", handler)
        mediator.notify(self, "e")
        assert log == []

    def test_kwargs_passed_to_handler(self) -> None:
        mediator = EventMediator()
        received: dict = {}
        mediator.on("data", lambda s, **kw: received.update(kw))
        mediator.notify(self, "data", value=42)
        assert received == {"value": 42}

    def test_events_property(self) -> None:
        mediator = EventMediator()
        mediator.on("a", lambda s, **kw: None)
        mediator.on("b", lambda s, **kw: None)
        assert sorted(mediator.events) == ["a", "b"]
