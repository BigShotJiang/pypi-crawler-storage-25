"""Tests for the Template Method pattern."""

import pytest

from pypatterns.behavioral.template_method import TemplateMethod


class ConcreteAlgorithm(TemplateMethod):
    def __init__(self) -> None:
        self.steps: list[str] = []

    def step_one(self) -> None:
        self.steps.append("one")

    def step_two(self) -> None:
        self.steps.append("two")

    def step_three(self) -> None:
        self.steps.append("three")


class AlgorithmWithHooks(TemplateMethod):
    def __init__(self) -> None:
        self.steps: list[str] = []

    def step_one(self) -> None:
        self.steps.append("one")

    def step_two(self) -> None:
        self.steps.append("two")

    def step_three(self) -> None:
        self.steps.append("three")

    def hook_before(self) -> None:
        self.steps.append("before")

    def hook_after(self) -> None:
        self.steps.append("after")


class TestTemplateMethod:
    def test_steps_execute_in_order(self) -> None:
        algo = ConcreteAlgorithm()
        algo.template_method()
        assert algo.steps == ["one", "two", "three"]

    def test_hooks_are_called(self) -> None:
        algo = AlgorithmWithHooks()
        algo.template_method()
        assert algo.steps == ["before", "one", "two", "three", "after"]

    def test_abstract_class_cannot_be_instantiated(self) -> None:
        with pytest.raises(TypeError):
            TemplateMethod()  # type: ignore[abstract]

    def test_partial_implementation_fails(self) -> None:
        class Incomplete(TemplateMethod):
            def step_one(self) -> None:
                pass

            def step_two(self) -> None:
                pass
            # Missing step_three

        with pytest.raises(TypeError):
            Incomplete()  # type: ignore[abstract]
