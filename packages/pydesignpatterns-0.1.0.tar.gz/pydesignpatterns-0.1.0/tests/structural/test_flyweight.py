"""Tests for the Flyweight pattern."""

from pypatterns.structural.flyweight import Flyweight, FlyweightFactory, flyweight


class TestFlyweight:
    def test_shared_state(self) -> None:
        fw = Flyweight({"name": "Oak", "color": "green"})
        assert fw.shared_state == {"name": "Oak", "color": "green"}

    def test_operation_combines_state(self) -> None:
        fw = Flyweight({"type": "tree"})
        result = fw.operation(x=10, y=20)
        assert result["shared"] == {"type": "tree"}
        assert result["unique"] == {"x": 10, "y": 20}

    def test_repr(self) -> None:
        fw = Flyweight("shared")
        assert "shared" in repr(fw)


class TestFlyweightFactory:
    def test_creates_flyweight(self) -> None:
        factory = FlyweightFactory[str, dict]()
        fw = factory.get_or_create("oak", {"name": "Oak"})
        assert fw.shared_state == {"name": "Oak"}

    def test_reuses_flyweight(self) -> None:
        factory = FlyweightFactory[str, str]()
        fw1 = factory.get_or_create("a", "data_a")
        fw2 = factory.get_or_create("a", "data_a")
        assert fw1 is fw2

    def test_different_keys_different_flyweights(self) -> None:
        factory = FlyweightFactory[str, str]()
        fw1 = factory.get_or_create("a", "data_a")
        fw2 = factory.get_or_create("b", "data_b")
        assert fw1 is not fw2

    def test_get_existing(self) -> None:
        factory = FlyweightFactory[str, str]()
        factory.get_or_create("x", "data")
        fw = factory.get("x")
        assert fw.shared_state == "data"

    def test_get_missing_raises(self) -> None:
        factory = FlyweightFactory[str, str]()
        import pytest
        with pytest.raises(KeyError):
            factory.get("missing")

    def test_contains(self) -> None:
        factory = FlyweightFactory[str, str]()
        factory.get_or_create("x", "data")
        assert "x" in factory
        assert "y" not in factory

    def test_len(self) -> None:
        factory = FlyweightFactory[str, str]()
        assert len(factory) == 0
        factory.get_or_create("a", "1")
        factory.get_or_create("b", "2")
        assert len(factory) == 2

    def test_keys(self) -> None:
        factory = FlyweightFactory[str, str]()
        factory.get_or_create("a", "1")
        factory.get_or_create("b", "2")
        assert sorted(factory.keys) == ["a", "b"]


class TestFlyweightDecorator:
    def test_cached_instances(self) -> None:
        @flyweight
        class TreeType:
            def __init__(self, name: str, color: str) -> None:
                self.name = name
                self.color = color

        a = TreeType("Oak", "green")
        b = TreeType("Oak", "green")
        assert a is b

    def test_different_args_different_instances(self) -> None:
        @flyweight
        class TreeType:
            def __init__(self, name: str) -> None:
                self.name = name

        a = TreeType("Oak")
        b = TreeType("Birch")
        assert a is not b
        assert a.name == "Oak"
        assert b.name == "Birch"
