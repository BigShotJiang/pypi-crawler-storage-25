"""Tests for the structural Decorator pattern."""

from pypatterns.structural.decorator import ComponentProto, DecoratorBase, stackable


class ConcreteComponent(ComponentProto):
    def operation(self) -> str:
        return "base"


class BracketDecorator(DecoratorBase):
    def operation(self) -> str:
        return f"[{self._wrapped.operation()}]"


class StarDecorator(DecoratorBase):
    def operation(self) -> str:
        return f"*{self._wrapped.operation()}*"


class TestDecoratorBase:
    def test_default_delegation(self) -> None:
        component = ConcreteComponent()
        decorated = DecoratorBase(component)
        assert decorated.operation() == "base"

    def test_wrapped_property(self) -> None:
        component = ConcreteComponent()
        decorated = DecoratorBase(component)
        assert decorated.wrapped is component

    def test_single_decorator(self) -> None:
        component = ConcreteComponent()
        decorated = BracketDecorator(component)
        assert decorated.operation() == "[base]"

    def test_stacked_decorators(self) -> None:
        component = ConcreteComponent()
        decorated = StarDecorator(BracketDecorator(component))
        assert decorated.operation() == "*[base]*"


class TestStackable:
    def test_stackable_applies_in_order(self) -> None:
        component = ConcreteComponent()
        decorated = stackable(BracketDecorator, StarDecorator)(component)
        # BracketDecorator first (inner), then StarDecorator (outer)
        assert decorated.operation() == "*[base]*"

    def test_stackable_single(self) -> None:
        component = ConcreteComponent()
        decorated = stackable(BracketDecorator)(component)
        assert decorated.operation() == "[base]"

    def test_stackable_empty(self) -> None:
        component = ConcreteComponent()
        decorated = stackable()(component)
        assert decorated.operation() == "base"
