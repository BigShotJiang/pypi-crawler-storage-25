"""Tests for the Proxy pattern."""

import pytest

from pypatterns.structural.proxy import (
    LazyProxy,
    LoggingProxy,
    ProtectiveProxy,
    Proxy,
    lazy_proxy,
    logging_proxy,
    protective_proxy,
)


class Service:
    def __init__(self) -> None:
        self.value = 42

    def greet(self, name: str) -> str:
        return f"Hello, {name}!"

    def __repr__(self) -> str:
        return "Service()"


class TestProxy:
    def test_delegates_method(self) -> None:
        proxy = Proxy(Service())
        assert proxy.greet("world") == "Hello, world!"

    def test_delegates_attribute(self) -> None:
        proxy = Proxy(Service())
        assert proxy.value == 42

    def test_set_attribute(self) -> None:
        svc = Service()
        proxy = Proxy(svc)
        proxy.value = 99
        assert svc.value == 99

    def test_repr(self) -> None:
        proxy = Proxy(Service())
        assert "Proxy(Service())" in repr(proxy)


class TestLazyProxy:
    def test_defers_creation(self) -> None:
        created = []

        def factory() -> Service:
            created.append(True)
            return Service()

        proxy = LazyProxy(factory)
        assert len(created) == 0
        proxy.greet("test")
        assert len(created) == 1

    def test_creates_once(self) -> None:
        call_count = []

        def factory() -> Service:
            call_count.append(1)
            return Service()

        proxy = LazyProxy(factory)
        proxy.greet("a")
        proxy.greet("b")
        assert len(call_count) == 1

    def test_repr_before_creation(self) -> None:
        proxy = LazyProxy(Service)
        assert "not yet created" in repr(proxy)

    def test_repr_after_creation(self) -> None:
        proxy = LazyProxy(Service)
        proxy.value  # trigger creation
        assert "Service()" in repr(proxy)

    def test_lazy_proxy_helper(self) -> None:
        proxy = lazy_proxy(Service)
        assert proxy.greet("x") == "Hello, x!"


class TestProtectiveProxy:
    def test_allowed_access(self) -> None:
        proxy = ProtectiveProxy(Service(), guard=lambda name: name != "value")
        assert proxy.greet("test") == "Hello, test!"

    def test_denied_access(self) -> None:
        proxy = ProtectiveProxy(Service(), guard=lambda name: name != "value")
        with pytest.raises(PermissionError, match="value"):
            proxy.value

    def test_protective_proxy_helper(self) -> None:
        proxy = protective_proxy(Service(), guard=lambda n: n == "greet")
        assert proxy.greet("ok") == "Hello, ok!"


class TestLoggingProxy:
    def test_logs_access(self) -> None:
        logs: list[str] = []
        proxy = LoggingProxy(Service(), logger=logs.append)
        proxy.greet("test")
        assert len(logs) == 1
        assert "greet" in logs[0]

    def test_logging_proxy_helper(self) -> None:
        logs: list[str] = []
        proxy = logging_proxy(Service(), logger=logs.append)
        proxy.value
        assert "value" in logs[0]
