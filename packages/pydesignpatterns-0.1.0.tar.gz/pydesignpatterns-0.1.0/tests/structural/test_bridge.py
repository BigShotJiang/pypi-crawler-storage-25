"""Tests for the Bridge pattern."""

from pypatterns.structural.bridge import Abstraction, RefinedAbstraction


class TV:
    def operation_impl(self) -> str:
        return "TV output"


class Radio:
    def operation_impl(self) -> str:
        return "Radio output"


class RemoteControl(Abstraction):
    pass


class AdvancedRemote(RefinedAbstraction):
    def refined_operation(self) -> str:
        return f"Advanced: {self.impl.operation_impl()}"


class TestAbstraction:
    def test_delegates_to_impl(self) -> None:
        remote = RemoteControl(TV())
        assert remote.operation() == "TV output"

    def test_swap_impl(self) -> None:
        remote = RemoteControl(TV())
        assert remote.operation() == "TV output"
        remote.impl = Radio()
        assert remote.operation() == "Radio output"

    def test_impl_property(self) -> None:
        tv = TV()
        remote = RemoteControl(tv)
        assert remote.impl is tv


class TestRefinedAbstraction:
    def test_refined_operation(self) -> None:
        remote = AdvancedRemote(TV())
        assert remote.refined_operation() == "Advanced: TV output"

    def test_base_operation_still_works(self) -> None:
        remote = AdvancedRemote(Radio())
        assert remote.operation() == "Radio output"
