"""Tests for the Composite pattern."""

from pypatterns.structural.composite import Composite, Leaf


class FileLeaf(Leaf[int]):
    def __init__(self, size: int) -> None:
        self.size = size

    def operation(self) -> int:
        return self.size


class Directory(Composite[int]):
    def operation(self) -> int:
        return sum(child.operation() for child in self)


class TestLeaf:
    def test_operation(self) -> None:
        leaf = FileLeaf(100)
        assert leaf.operation() == 100


class TestComposite:
    def test_add_and_operation(self) -> None:
        root = Directory()
        root.add(FileLeaf(100)).add(FileLeaf(200))
        assert root.operation() == 300

    def test_nested_composite(self) -> None:
        sub = Directory()
        sub.add(FileLeaf(50)).add(FileLeaf(50))

        root = Directory()
        root.add(FileLeaf(100))
        root.add(sub)
        assert root.operation() == 200

    def test_remove(self) -> None:
        root = Directory()
        leaf = FileLeaf(100)
        root.add(leaf)
        root.remove(leaf)
        assert root.operation() == 0

    def test_iadd_operator(self) -> None:
        root = Directory()
        root += FileLeaf(42)
        assert root.operation() == 42

    def test_len(self) -> None:
        root = Directory()
        assert len(root) == 0
        root.add(FileLeaf(1))
        root.add(FileLeaf(2))
        assert len(root) == 2

    def test_iteration(self) -> None:
        root = Directory()
        leaves = [FileLeaf(i) for i in range(3)]
        for leaf in leaves:
            root.add(leaf)
        assert list(root) == leaves

    def test_empty_composite(self) -> None:
        root = Directory()
        assert root.operation() == 0
