"""Tests for the Adapter pattern."""

import pytest

from pypatterns.structural.adapter import Adapter, adapt


class LegacyPrinter:
    def print_old(self, text: str) -> str:
        return f"[OLD] {text}"

    def status(self) -> str:
        return "ready"


class TestAdapter:
    def test_mapped_method(self) -> None:
        adapter = Adapter(adaptee=LegacyPrinter(), mapping={"print_text": "print_old"})
        assert adapter.print_text("hi") == "[OLD] hi"

    def test_unmapped_method_falls_through(self) -> None:
        adapter = Adapter(adaptee=LegacyPrinter(), mapping={})
        assert adapter.status() == "ready"

    def test_unknown_attribute_raises(self) -> None:
        adapter = Adapter(adaptee=LegacyPrinter(), mapping={})
        with pytest.raises(AttributeError):
            adapter.nonexistent()


class TestAdaptFunction:
    def test_adapt_with_mapping(self) -> None:
        adapted = adapt(LegacyPrinter(), print_text="print_old")
        assert adapted.print_text("hello") == "[OLD] hello"

    def test_adapt_passthrough(self) -> None:
        adapted = adapt(LegacyPrinter())
        assert adapted.status() == "ready"
