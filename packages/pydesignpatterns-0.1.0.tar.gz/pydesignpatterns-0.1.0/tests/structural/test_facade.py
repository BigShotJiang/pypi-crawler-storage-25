"""Tests for the Facade pattern."""

from pypatterns.structural.facade import Facade


class SubsystemA:
    def op_a(self) -> str:
        return "A"


class SubsystemB:
    def op_b(self) -> str:
        return "B"


class MyFacade(Facade):
    def __init__(self) -> None:
        self.a = SubsystemA()
        self.b = SubsystemB()

    def simple_operation(self) -> str:
        return f"{self.a.op_a()}+{self.b.op_b()}"


class TestFacade:
    def test_simplifies_subsystems(self) -> None:
        facade = MyFacade()
        assert facade.simple_operation() == "A+B"

    def test_subsystems_accessible(self) -> None:
        facade = MyFacade()
        assert facade.a.op_a() == "A"
        assert facade.b.op_b() == "B"
