"""Tests for the Prototype pattern."""

from pypatterns.creational.prototype import Prototype, PrototypeRegistry, prototype


@prototype
class Shape:
    def __init__(self, x: int, y: int) -> None:
        self.x = x
        self.y = y
        self.tags: list[str] = []


class TestPrototypeDecorator:
    def test_clone_creates_copy(self) -> None:
        original = Shape(1, 2)
        cloned = original.clone()
        assert cloned.x == 1
        assert cloned.y == 2
        assert cloned is not original

    def test_clone_is_deep(self) -> None:
        original = Shape(1, 2)
        original.tags.append("red")
        cloned = original.clone()
        cloned.tags.append("blue")
        assert original.tags == ["red"]
        assert cloned.tags == ["red", "blue"]

    def test_modify_clone_not_original(self) -> None:
        original = Shape(1, 2)
        cloned = original.clone()
        cloned.x = 99
        assert original.x == 1


class TestPrototypeProtocol:
    def test_decorated_class_satisfies_protocol(self) -> None:
        s = Shape(0, 0)
        assert isinstance(s, Prototype)


class TestPrototypeRegistry:
    def test_register_and_clone(self) -> None:
        registry = PrototypeRegistry[str]()
        registry.register("origin", Shape(0, 0))
        cloned = registry.clone("origin")
        assert hasattr(cloned, "x")
        assert cloned.x == 0  # type: ignore[attr-defined]

    def test_cloned_is_independent(self) -> None:
        registry = PrototypeRegistry[str]()
        original = Shape(5, 10)
        registry.register("point", original)
        cloned = registry.clone("point")
        cloned.x = 99  # type: ignore[attr-defined]
        assert original.x == 5

    def test_unknown_key_raises(self) -> None:
        registry = PrototypeRegistry[str]()
        import pytest
        with pytest.raises(KeyError):
            registry.clone("nope")

    def test_unregister(self) -> None:
        registry = PrototypeRegistry[str]()
        registry.register("a", Shape(1, 1))
        registry.unregister("a")
        assert "a" not in registry

    def test_contains(self) -> None:
        registry = PrototypeRegistry[str]()
        registry.register("x", Shape(0, 0))
        assert "x" in registry
        assert "y" not in registry

    def test_keys(self) -> None:
        registry = PrototypeRegistry[str]()
        registry.register("a", Shape(0, 0))
        registry.register("b", Shape(1, 1))
        assert sorted(registry.keys) == ["a", "b"]
