"""Tests for the Builder pattern."""

from typing import Self

import pytest

from pypatterns.creational.builder import Builder, Director


class House:
    def __init__(self) -> None:
        self.walls: int = 0
        self.roof: str = ""
        self.garage: bool = False


class HouseBuilder(Builder[House]):
    def __init__(self) -> None:
        self._house = House()

    def set_walls(self, count: int) -> Self:
        self._house.walls = count
        return self

    def set_roof(self, material: str) -> Self:
        self._house.roof = material
        return self

    def set_garage(self, has_garage: bool) -> Self:
        self._house.garage = has_garage
        return self

    def build(self) -> House:
        house = self._house
        self._house = House()
        return house


class TestBuilder:
    def test_build_simple(self) -> None:
        builder = HouseBuilder()
        house = builder.set_walls(4).set_roof("tile").build()
        assert house.walls == 4
        assert house.roof == "tile"
        assert house.garage is False

    def test_fluent_chaining(self) -> None:
        builder = HouseBuilder()
        result = builder.set_walls(4)
        assert result is builder

    def test_build_resets(self) -> None:
        builder = HouseBuilder()
        house1 = builder.set_walls(4).build()
        house2 = builder.set_walls(2).build()
        assert house1.walls == 4
        assert house2.walls == 2
        assert house1 is not house2

    def test_builder_is_abstract(self) -> None:
        with pytest.raises(TypeError):
            Builder()  # type: ignore[abstract]

    def test_full_build(self) -> None:
        house = (
            HouseBuilder()
            .set_walls(6)
            .set_roof("metal")
            .set_garage(True)
            .build()
        )
        assert house.walls == 6
        assert house.roof == "metal"
        assert house.garage is True


class TestDirector:
    def test_construct(self) -> None:
        builder = HouseBuilder()
        director = Director(builder)
        builder.set_walls(4).set_roof("wood")
        house = director.construct()
        assert house.walls == 4

    def test_swap_builder(self) -> None:
        builder1 = HouseBuilder()
        builder2 = HouseBuilder()
        director = Director(builder1)
        assert director.builder is builder1
        director.builder = builder2
        assert director.builder is builder2
