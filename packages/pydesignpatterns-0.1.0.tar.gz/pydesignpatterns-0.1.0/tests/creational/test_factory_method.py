"""Tests for the Factory Method pattern."""

import pytest

from pypatterns.creational.factory_method import Creator, Registry, registry_factory


class Product:
    def __init__(self, name: str = "default") -> None:
        self.name = name


class ConcreteCreatorA(Creator[Product]):
    def factory_method(self) -> Product:
        return Product("A")


class ConcreteCreatorB(Creator[Product]):
    def factory_method(self) -> Product:
        return Product("B")


class TestCreator:
    def test_factory_method(self) -> None:
        creator = ConcreteCreatorA()
        product = creator.factory_method()
        assert product.name == "A"

    def test_some_operation(self) -> None:
        creator = ConcreteCreatorB()
        product = creator.some_operation()
        assert product.name == "B"

    def test_creator_is_abstract(self) -> None:
        with pytest.raises(TypeError):
            Creator()  # type: ignore[abstract]


class TestRegistry:
    def test_register_and_create(self) -> None:
        reg = Registry[str, Product]()
        reg.register("a", lambda: Product("A"))
        product = reg.create("a")
        assert product.name == "A"

    def test_register_class(self) -> None:
        reg = Registry[str, Product]()
        reg.register("default", Product)
        product = reg.create("default")
        assert product.name == "default"

    def test_create_unknown_key_raises(self) -> None:
        reg = Registry[str, Product]()
        with pytest.raises(KeyError):
            reg.create("unknown")

    def test_unregister(self) -> None:
        reg = Registry[str, Product]()
        reg.register("a", Product)
        reg.unregister("a")
        assert "a" not in reg

    def test_contains(self) -> None:
        reg = Registry[str, Product]()
        reg.register("a", Product)
        assert "a" in reg
        assert "b" not in reg

    def test_keys(self) -> None:
        reg = Registry[str, Product]()
        reg.register("a", Product)
        reg.register("b", Product)
        assert sorted(reg.keys) == ["a", "b"]

    def test_create_with_args(self) -> None:
        reg = Registry[str, Product]()
        reg.register("custom", Product)
        product = reg.create("custom", "custom_name")
        assert product.name == "custom_name"


class TestRegistryFactory:
    def test_creates_registry(self) -> None:
        reg: Registry[str, Product] = registry_factory()
        assert isinstance(reg, Registry)
        reg.register("x", Product)
        assert reg.create("x").name == "default"
