"""Tests for the Singleton pattern."""

import threading

from pypatterns.creational.singleton import (
    resettable_singleton,
    singleton,
    thread_safe_singleton,
)


class TestSingleton:
    def test_same_instance(self) -> None:
        @singleton
        class Config:
            pass

        a = Config()
        b = Config()
        assert a is b

    def test_preserves_init(self) -> None:
        @singleton
        class Config:
            def __init__(self) -> None:
                self.value = 42

        a = Config()
        assert a.value == 42

    def test_preserves_class_name(self) -> None:
        @singleton
        class MyClass:
            pass

        assert MyClass.__name__ == "MyClass"


class TestThreadSafeSingleton:
    def test_same_instance(self) -> None:
        @thread_safe_singleton
        class Database:
            pass

        a = Database()
        b = Database()
        assert a is b

    def test_thread_safety(self) -> None:
        @thread_safe_singleton
        class Service:
            pass

        instances: list[object] = []

        def create() -> None:
            instances.append(Service())

        threads = [threading.Thread(target=create) for _ in range(20)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        assert all(inst is instances[0] for inst in instances)


class TestResettableSingleton:
    def test_same_instance(self) -> None:
        @resettable_singleton
        class Cache:
            pass

        a = Cache()
        b = Cache()
        assert a is b

    def test_reset_creates_new_instance(self) -> None:
        @resettable_singleton
        class Cache:
            pass

        a = Cache()
        Cache.reset()  # type: ignore[attr-defined]
        b = Cache()
        assert a is not b

    def test_after_reset_still_singleton(self) -> None:
        @resettable_singleton
        class Cache:
            pass

        Cache.reset()  # type: ignore[attr-defined]
        a = Cache()
        b = Cache()
        assert a is b
