"""Tests for the Abstract Factory pattern."""

import pytest

from pypatterns.creational.abstract_factory import AbstractFactory, AbstractProduct


class Button(AbstractProduct):
    pass


class WindowsButton(Button):
    def operation(self) -> str:
        return "WindowsButton"


class MacButton(Button):
    def operation(self) -> str:
        return "MacButton"


class Checkbox(AbstractProduct):
    pass


class WindowsCheckbox(Checkbox):
    def operation(self) -> str:
        return "WindowsCheckbox"


class MacCheckbox(Checkbox):
    def operation(self) -> str:
        return "MacCheckbox"


class GUIFactory(AbstractFactory):
    def create_button(self) -> Button:
        raise NotImplementedError

    def create_checkbox(self) -> Checkbox:
        raise NotImplementedError


class WindowsFactory(GUIFactory):
    def create_button(self) -> Button:
        return WindowsButton()

    def create_checkbox(self) -> Checkbox:
        return WindowsCheckbox()


class MacFactory(GUIFactory):
    def create_button(self) -> Button:
        return MacButton()

    def create_checkbox(self) -> Checkbox:
        return MacCheckbox()


class TestAbstractFactory:
    def test_windows_factory(self) -> None:
        factory = WindowsFactory()
        btn = factory.create_button()
        cb = factory.create_checkbox()
        assert btn.operation() == "WindowsButton"
        assert cb.operation() == "WindowsCheckbox"

    def test_mac_factory(self) -> None:
        factory = MacFactory()
        btn = factory.create_button()
        cb = factory.create_checkbox()
        assert btn.operation() == "MacButton"
        assert cb.operation() == "MacCheckbox"

    def test_factory_produces_consistent_family(self) -> None:
        factory: GUIFactory = WindowsFactory()
        btn = factory.create_button()
        cb = factory.create_checkbox()
        assert isinstance(btn, WindowsButton)
        assert isinstance(cb, WindowsCheckbox)

    def test_abstract_product_is_abstract(self) -> None:
        with pytest.raises(TypeError):
            AbstractProduct()  # type: ignore[abstract]
