"""Adapter pattern — Allows objects with incompatible interfaces to collaborate.

Provides a generic Adapter class and a functional ``adapt()`` helper.

See Also:
    https://refactoring.guru/design-patterns/adapter
"""

from typing import Any


class Adapter[Target]:
    """Generic adapter that wraps an adaptee and maps its attributes to a target interface.

    Example::

        class LegacyPrinter:
            def print_old(self, text: str) -> str:
                return f"[OLD] {text}"

        adapter = Adapter[Printer](
            adaptee=LegacyPrinter(),
            mapping={"print": "print_old"},
        )
        result = adapter.print("hello")  # calls adaptee.print_old("hello")
    """

    def __init__(self, adaptee: object, mapping: dict[str, str]) -> None:
        self._adaptee = adaptee
        self._mapping = mapping

    def __getattr__(self, name: str) -> Any:
        if name.startswith("_"):
            raise AttributeError(name)
        mapped_name = self._mapping.get(name, name)
        return getattr(self._adaptee, mapped_name)


def adapt(adaptee: object, /, **attr_map: str) -> Any:
    """Create an adapter from an object with an attribute mapping.

    Each keyword argument maps ``target_attr=source_attr``.

    Example::

        adapted = adapt(legacy_printer, print_text="print_old")
        adapted.print_text("hello")  # calls legacy_printer.print_old("hello")
    """
    return Adapter(adaptee=adaptee, mapping=attr_map)


__all__ = ["Adapter", "adapt"]
