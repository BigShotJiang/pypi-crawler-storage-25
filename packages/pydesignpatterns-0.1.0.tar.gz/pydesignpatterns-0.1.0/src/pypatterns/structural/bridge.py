"""Bridge pattern — Splits abstraction from implementation.

Lets you develop them independently and combine at runtime.

See Also:
    https://refactoring.guru/design-patterns/bridge
"""

from abc import ABC, abstractmethod
from typing import Protocol


class Implementor(Protocol):
    """Protocol for the implementation side of the bridge.

    Any object with an ``operation_impl()`` method satisfies this protocol.
    """

    def operation_impl(self) -> str: ...


class Abstraction[I: Implementor]:
    """Abstraction that delegates work to an Implementor.

    Example::

        class RemoteControl(Abstraction[Device]):
            def toggle_power(self) -> str:
                return self.impl.operation_impl()

        class TV:
            def operation_impl(self) -> str:
                return "TV on"

        remote = RemoteControl(TV())
        remote.toggle_power()  # "TV on"
    """

    def __init__(self, impl: I) -> None:
        self._impl = impl

    @property
    def impl(self) -> I:
        """Return the current implementation."""
        return self._impl

    @impl.setter
    def impl(self, impl: I) -> None:
        """Swap the implementation at runtime."""
        self._impl = impl

    def operation(self) -> str:
        """Delegate to the implementation."""
        return self._impl.operation_impl()


class RefinedAbstraction[I: Implementor](Abstraction[I], ABC):
    """Extended abstraction that adds behavior on top of the base abstraction.

    Subclass this to add extra functionality while still delegating
    core work to the implementor.
    """

    @abstractmethod
    def refined_operation(self) -> str:
        """Additional operation specific to the refined abstraction."""
        ...


__all__ = ["Implementor", "Abstraction", "RefinedAbstraction"]
