"""Proxy pattern — Provides a substitute or placeholder for another object.

Includes lazy-loading, protective, and logging proxy variants.

See Also:
    https://refactoring.guru/design-patterns/proxy
"""

from collections.abc import Callable
from typing import Any

from pypatterns._types import Factory, Predicate


class Proxy[T]:
    """Generic proxy that delegates attribute access to a subject.

    Example::

        proxy = Proxy(real_service)
        proxy.do_something()  # delegates to real_service.do_something()
    """

    def __init__(self, subject: T) -> None:
        object.__setattr__(self, "_subject", subject)

    def __getattr__(self, name: str) -> Any:
        return getattr(object.__getattribute__(self, "_subject"), name)

    def __setattr__(self, name: str, value: Any) -> None:
        setattr(object.__getattribute__(self, "_subject"), name, value)

    def __repr__(self) -> str:
        return f"Proxy({object.__getattribute__(self, '_subject')!r})"


class LazyProxy[T]:
    """Proxy that defers object creation until first attribute access.

    Example::

        proxy = LazyProxy(lambda: ExpensiveService())
        # ExpensiveService is not created yet
        proxy.do_work()  # now it's created and the call is delegated
    """

    def __init__(self, factory: Factory[T]) -> None:
        object.__setattr__(self, "_factory", factory)
        object.__setattr__(self, "_instance", None)

    def _get_instance(self) -> T:
        instance = object.__getattribute__(self, "_instance")
        if instance is None:
            factory = object.__getattribute__(self, "_factory")
            instance = factory()
            object.__setattr__(self, "_instance", instance)
        return instance

    def __getattr__(self, name: str) -> Any:
        return getattr(self._get_instance(), name)

    def __setattr__(self, name: str, value: Any) -> None:
        setattr(self._get_instance(), name, value)

    def __repr__(self) -> str:
        instance = object.__getattribute__(self, "_instance")
        if instance is None:
            return "LazyProxy(<not yet created>)"
        return f"LazyProxy({instance!r})"


class ProtectiveProxy[T]:
    """Proxy that checks a guard before allowing attribute access.

    Example::

        proxy = ProtectiveProxy(
            service,
            guard=lambda name: name != "secret_method",
        )
        proxy.public_method()   # OK
        proxy.secret_method()   # raises PermissionError
    """

    def __init__(self, subject: T, guard: Predicate[str]) -> None:
        object.__setattr__(self, "_subject", subject)
        object.__setattr__(self, "_guard", guard)

    def __getattr__(self, name: str) -> Any:
        guard = object.__getattribute__(self, "_guard")
        if not guard(name):
            raise PermissionError(f"Access denied to '{name}'")
        return getattr(object.__getattribute__(self, "_subject"), name)

    def __repr__(self) -> str:
        return f"ProtectiveProxy({object.__getattribute__(self, '_subject')!r})"


class LoggingProxy[T]:
    """Proxy that logs all attribute access.

    Example::

        logs: list[str] = []
        proxy = LoggingProxy(service, logger=logs.append)
        proxy.do_work()  # logs "Accessing 'do_work'"
    """

    def __init__(self, subject: T, logger: Callable[[str], None] | None = None) -> None:
        object.__setattr__(self, "_subject", subject)
        object.__setattr__(self, "_logger", logger or print)

    def __getattr__(self, name: str) -> Any:
        logger = object.__getattribute__(self, "_logger")
        logger(f"Accessing '{name}'")
        return getattr(object.__getattribute__(self, "_subject"), name)

    def __repr__(self) -> str:
        return f"LoggingProxy({object.__getattribute__(self, '_subject')!r})"


def lazy_proxy[T](factory: Factory[T]) -> LazyProxy[T]:
    """Create a lazy proxy from a factory callable."""
    return LazyProxy(factory)


def protective_proxy[T](subject: T, guard: Predicate[str]) -> ProtectiveProxy[T]:
    """Create a protective proxy with an access guard."""
    return ProtectiveProxy(subject, guard)


def logging_proxy[T](subject: T, logger: Callable[[str], None] | None = None) -> LoggingProxy[T]:
    """Create a logging proxy that records attribute access."""
    return LoggingProxy(subject, logger)


__all__ = [
    "Proxy",
    "LazyProxy",
    "ProtectiveProxy",
    "LoggingProxy",
    "lazy_proxy",
    "protective_proxy",
    "logging_proxy",
]
