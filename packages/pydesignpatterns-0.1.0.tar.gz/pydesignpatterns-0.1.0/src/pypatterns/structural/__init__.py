"""Structural design patterns."""

from pypatterns.structural.adapter import Adapter, adapt
from pypatterns.structural.bridge import Abstraction, Implementor, RefinedAbstraction
from pypatterns.structural.composite import Component, Composite, Leaf
from pypatterns.structural.decorator import ComponentProto, DecoratorBase, stackable
from pypatterns.structural.facade import Facade
from pypatterns.structural.flyweight import Flyweight, FlyweightFactory, flyweight
from pypatterns.structural.proxy import (
    LazyProxy,
    LoggingProxy,
    ProtectiveProxy,
    Proxy,
    lazy_proxy,
    logging_proxy,
    protective_proxy,
)

__all__ = [
    "Abstraction",
    "Adapter",
    "Component",
    "ComponentProto",
    "Composite",
    "DecoratorBase",
    "Facade",
    "Flyweight",
    "FlyweightFactory",
    "Implementor",
    "LazyProxy",
    "Leaf",
    "LoggingProxy",
    "ProtectiveProxy",
    "Proxy",
    "RefinedAbstraction",
    "adapt",
    "flyweight",
    "lazy_proxy",
    "logging_proxy",
    "protective_proxy",
    "stackable",
]
