"""Decorator pattern (structural) — Attaches new behaviors to objects by wrapping them.

This is the GoF structural Decorator, not Python's ``@decorator`` syntax.
It enables runtime behavior stacking on objects.

See Also:
    https://refactoring.guru/design-patterns/decorator
"""

from abc import ABC, abstractmethod
from collections.abc import Callable
from typing import Any


class ComponentProto(ABC):
    """Abstract component interface that decorators wrap."""

    @abstractmethod
    def operation(self) -> str:
        """Execute the component's primary operation."""
        ...


class DecoratorBase(ComponentProto):
    """Base decorator that wraps a component and delegates by default.

    Subclass and override ``operation()`` to add behavior.

    Example::

        class LoggingDecorator(DecoratorBase):
            def operation(self) -> str:
                result = self._wrapped.operation()
                return f"[LOG] {result}"

        component = ConcreteComponent()
        decorated = LoggingDecorator(component)
        result = decorated.operation()  # "[LOG] ..."
    """

    def __init__(self, wrapped: ComponentProto) -> None:
        self._wrapped = wrapped

    @property
    def wrapped(self) -> ComponentProto:
        """Return the wrapped component."""
        return self._wrapped

    def operation(self) -> str:
        """Delegate to the wrapped component."""
        return self._wrapped.operation()


def stackable(*decorators: type[DecoratorBase]) -> Callable[[ComponentProto], ComponentProto]:
    """Apply multiple decorators in order (left to right = inner to outer).

    Example::

        wrapped = stackable(LoggingDecorator, CachingDecorator)(component)
        # Equivalent to: CachingDecorator(LoggingDecorator(component))
    """

    def apply(component: ComponentProto) -> ComponentProto:
        result: Any = component
        for decorator_cls in decorators:
            result = decorator_cls(result)
        return result

    return apply


__all__ = ["ComponentProto", "DecoratorBase", "stackable"]
