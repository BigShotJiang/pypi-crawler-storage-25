"""Flyweight pattern — Shares common state between multiple objects to save memory.

See Also:
    https://refactoring.guru/design-patterns/flyweight
"""

from typing import Any


class Flyweight[T]:
    """Wraps intrinsic (shared) state of type T.

    Extrinsic (unique) state is passed to operations, not stored.

    Example::

        tree_type = Flyweight({"name": "Oak", "color": "green", "texture": "rough"})
        tree_type.operation(x=10, y=20)  # extrinsic state passed at call time
    """

    def __init__(self, shared_state: T) -> None:
        self._shared_state = shared_state

    @property
    def shared_state(self) -> T:
        """Return the shared intrinsic state."""
        return self._shared_state

    def operation(self, **unique_state: Any) -> dict[str, Any]:
        """Combine shared and unique state for an operation."""
        return {"shared": self._shared_state, "unique": unique_state}

    def __repr__(self) -> str:
        return f"Flyweight({self._shared_state!r})"


class FlyweightFactory[K, T]:
    """Manages and reuses Flyweight instances by key.

    If a flyweight with the given key already exists, it is reused.

    Example::

        factory = FlyweightFactory[str, dict]()
        fw1 = factory.get_or_create("oak", {"name": "Oak", "color": "green"})
        fw2 = factory.get_or_create("oak", {"name": "Oak", "color": "green"})
        assert fw1 is fw2  # same instance reused
    """

    def __init__(self) -> None:
        self._flyweights: dict[K, Flyweight[T]] = {}

    def get_or_create(self, key: K, shared_state: T) -> Flyweight[T]:
        """Return an existing flyweight or create a new one."""
        if key not in self._flyweights:
            self._flyweights[key] = Flyweight(shared_state)
        return self._flyweights[key]

    def get(self, key: K) -> Flyweight[T]:
        """Return an existing flyweight.

        Raises:
            KeyError: If no flyweight exists for the given key.
        """
        return self._flyweights[key]

    def __contains__(self, key: K) -> bool:
        return key in self._flyweights

    def __len__(self) -> int:
        """Return the number of cached flyweights."""
        return len(self._flyweights)

    @property
    def keys(self) -> list[K]:
        """Return all cached flyweight keys."""
        return list(self._flyweights.keys())


def flyweight[T](cls: type[T]) -> type[T]:
    """Decorator that caches instances by their ``__init__`` arguments.

    Example::

        @flyweight
        class TreeType:
            def __init__(self, name: str, color: str):
                self.name = name
                self.color = color

        a = TreeType("Oak", "green")
        b = TreeType("Oak", "green")
        assert a is b
    """
    cache: dict[tuple[Any, ...], T] = {}

    original_new = cls.__new__
    original_init = cls.__init__  # type: ignore[misc]

    def __new__(cls_inner: type[T], *args: Any, **kwargs: Any) -> T:
        key = (args, tuple(sorted(kwargs.items())))
        if key not in cache:
            instance = original_new(cls_inner)
            cache[key] = instance
        return cache[key]

    def __init__(self: Any, *args: Any, **kwargs: Any) -> None:
        if not hasattr(self, "_flyweight_initialized"):
            original_init(self, *args, **kwargs)
            self._flyweight_initialized = True

    cls.__new__ = __new__  # type: ignore[assignment]
    cls.__init__ = __init__  # type: ignore[assignment]
    return cls


__all__ = ["Flyweight", "FlyweightFactory", "flyweight"]
