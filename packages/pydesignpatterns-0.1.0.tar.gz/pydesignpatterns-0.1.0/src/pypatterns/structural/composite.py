"""Composite pattern — Composes objects into tree structures.

Lets you treat individual objects and compositions uniformly.

See Also:
    https://refactoring.guru/design-patterns/composite
"""

from abc import ABC, abstractmethod
from collections.abc import Iterator
from typing import Self


class Component[T](ABC):
    """Abstract component in a tree structure.

    Both leaves and composites implement ``operation()``.
    """

    @abstractmethod
    def operation(self) -> T:
        """Execute this component's primary operation."""
        ...


class Leaf[T](Component[T]):
    """Terminal node in a composite tree.

    Example::

        class FileLeaf(Leaf[int]):
            def __init__(self, size: int):
                self.size = size
            def operation(self) -> int:
                return self.size
    """


class Composite[T](Component[T]):
    """Container node that holds children and delegates operations.

    Supports ``add``, ``remove``, iteration, ``+=`` operator, and ``len()``.

    Example::

        class Directory(Composite[int]):
            def operation(self) -> int:
                return sum(child.operation() for child in self)

        root = Directory()
        root.add(FileLeaf(100)).add(FileLeaf(200))
        assert root.operation() == 300
    """

    def __init__(self) -> None:
        self._children: list[Component[T]] = []

    def add(self, child: Component[T]) -> Self:
        """Add a child component. Returns self for chaining."""
        self._children.append(child)
        return self

    def remove(self, child: Component[T]) -> Self:
        """Remove a child component. Returns self for chaining.

        Raises:
            ValueError: If the child is not found.
        """
        self._children.remove(child)
        return self

    def __iadd__(self, other: Component[T]) -> Self:
        """Add a child via ``+=`` operator."""
        self._children.append(other)
        return self

    def __iter__(self) -> Iterator[Component[T]]:
        """Iterate over children."""
        return iter(self._children)

    def __len__(self) -> int:
        """Return the number of direct children."""
        return len(self._children)


__all__ = ["Component", "Leaf", "Composite"]
