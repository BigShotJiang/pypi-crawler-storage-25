"""Facade pattern — Provides a simplified interface to a complex subsystem.

See Also:
    https://refactoring.guru/design-patterns/facade
"""

from abc import ABC


class Facade(ABC):
    """Base class for facades that simplify access to complex subsystems.

    Subclass and compose subsystem objects, then expose simplified methods.

    Example::

        class VideoConverter(Facade):
            def __init__(self):
                self.codec = CodecFactory()
                self.mixer = AudioMixer()
                self.encoder = BitrateEncoder()

            def convert(self, filename: str, format: str) -> str:
                # Simplified interface hiding codec/mixer/encoder complexity
                codec = self.codec.extract(filename)
                audio = self.mixer.fix(codec)
                result = self.encoder.encode(audio, format)
                return result
    """


__all__ = ["Facade"]
