"""Prototype pattern — Copies existing objects without depending on their classes.

Provides a Protocol, a decorator for auto-cloning, and a registry for named prototypes.

See Also:
    https://refactoring.guru/design-patterns/prototype
"""

import copy
from typing import Protocol, Self, runtime_checkable


@runtime_checkable
class Prototype(Protocol):
    """Protocol requiring a ``clone()`` method that returns a copy of the object."""

    def clone(self) -> Self: ...


def prototype[T](cls: type[T]) -> type[T]:
    """Decorator that adds a ``clone()`` method to a class via ``copy.deepcopy``.

    Example::

        @prototype
        class Shape:
            def __init__(self, x: int, y: int):
                self.x = x
                self.y = y

        original = Shape(1, 2)
        cloned = original.clone()
        assert cloned.x == 1
        assert cloned is not original
    """

    def clone(self: T) -> T:
        return copy.deepcopy(self)

    cls.clone = clone  # type: ignore[attr-defined]
    return cls


class PrototypeRegistry[K]:
    """A registry that stores named prototypes and clones them on demand.

    Example::

        registry = PrototypeRegistry[str]()

        @prototype
        class Circle:
            def __init__(self, radius: float):
                self.radius = radius

        registry.register("big_circle", Circle(100.0))
        registry.register("small_circle", Circle(5.0))

        my_circle = registry.clone("big_circle")
        my_circle.radius = 50.0  # modify without affecting the original
    """

    def __init__(self) -> None:
        self._prototypes: dict[K, object] = {}

    def register(self, key: K, obj: object) -> None:
        """Register an object as a named prototype."""
        self._prototypes[key] = obj

    def unregister(self, key: K) -> None:
        """Remove a prototype by key.

        Raises:
            KeyError: If the key is not registered.
        """
        del self._prototypes[key]

    def clone(self, key: K) -> object:
        """Clone the prototype registered under ``key``.

        Uses the object's ``clone()`` method if available, otherwise falls back
        to ``copy.deepcopy``.

        Raises:
            KeyError: If no prototype is registered for the given key.
        """
        obj = self._prototypes[key]
        if hasattr(obj, "clone"):
            return obj.clone()  # type: ignore[union-attr]
        return copy.deepcopy(obj)

    def __contains__(self, key: K) -> bool:
        return key in self._prototypes

    @property
    def keys(self) -> list[K]:
        """Return all registered prototype keys."""
        return list(self._prototypes.keys())


__all__ = ["Prototype", "prototype", "PrototypeRegistry"]
