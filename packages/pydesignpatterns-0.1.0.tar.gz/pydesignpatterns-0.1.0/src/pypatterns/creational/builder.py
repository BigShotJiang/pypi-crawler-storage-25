"""Builder pattern — Constructs complex objects step by step.

Separates construction from representation, allowing different
representations from the same construction process.

See Also:
    https://refactoring.guru/design-patterns/builder
"""

from abc import ABC, abstractmethod
from typing import Self


class Builder[T](ABC):
    """Abstract builder that defines steps for constructing a product of type T.

    Subclasses implement the build steps and the ``build()`` method.
    All step methods return ``Self`` for fluent method chaining.

    Example::

        class HouseBuilder(Builder[House]):
            def __init__(self):
                self._house = House()

            def set_walls(self, count: int) -> Self:
                self._house.walls = count
                return self

            def set_roof(self, material: str) -> Self:
                self._house.roof = material
                return self

            def build(self) -> House:
                house = self._house
                self.reset()
                return house

            def reset(self) -> Self:
                self._house = House()
                return self

        house = HouseBuilder().set_walls(4).set_roof("tile").build()
    """

    @abstractmethod
    def build(self) -> T:
        """Construct and return the final product."""
        ...

    def reset(self) -> Self:
        """Reset the builder to start a new construction. Override as needed."""
        return self


class Director[T]:
    """Director that orchestrates a builder to construct a product.

    The director knows the order of construction steps.
    It works with any builder that follows the ``Builder`` interface.

    Example::

        director = Director(HouseBuilder())
        director.builder.set_walls(4).set_roof("tile")
        house = director.construct()
    """

    def __init__(self, builder: Builder[T]) -> None:
        self._builder = builder

    @property
    def builder(self) -> Builder[T]:
        """Return the current builder."""
        return self._builder

    @builder.setter
    def builder(self, builder: Builder[T]) -> None:
        """Replace the current builder."""
        self._builder = builder

    def construct(self) -> T:
        """Execute the build and return the product."""
        return self._builder.build()


__all__ = ["Builder", "Director"]
