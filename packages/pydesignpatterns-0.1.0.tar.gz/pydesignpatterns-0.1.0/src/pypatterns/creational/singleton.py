"""Singleton pattern — Ensures a class has only one instance.

Provides decorator-based singletons, which are more Pythonic than metaclass approaches.

See Also:
    https://refactoring.guru/design-patterns/singleton
"""

import functools
import threading
from typing import Any


def singleton[T](cls: type[T]) -> type[T]:
    """Decorator that makes a class a singleton.

    Subsequent calls to the constructor return the same instance.

    Example::

        @singleton
        class Config:
            def __init__(self):
                self.debug = False

        a = Config()
        b = Config()
        assert a is b
    """
    instance: T | None = None

    @functools.wraps(cls, updated=())
    class Wrapper(cls):  # type: ignore[valid-type]
        def __new__(cls_inner: type, *args: Any, **kwargs: Any) -> T:
            nonlocal instance
            if instance is None:
                instance = super().__new__(cls_inner)
            return instance

    Wrapper.__qualname__ = cls.__qualname__
    return Wrapper  # type: ignore[return-value]


def thread_safe_singleton[T](cls: type[T]) -> type[T]:
    """Decorator that makes a class a thread-safe singleton.

    Uses a threading.Lock to ensure only one instance is created
    even under concurrent access.

    Example::

        @thread_safe_singleton
        class Database:
            pass
    """
    instance: T | None = None
    lock = threading.Lock()

    @functools.wraps(cls, updated=())
    class Wrapper(cls):  # type: ignore[valid-type]
        def __new__(cls_inner: type, *args: Any, **kwargs: Any) -> T:
            nonlocal instance
            if instance is None:
                with lock:
                    if instance is None:
                        instance = super().__new__(cls_inner)
            return instance

    Wrapper.__qualname__ = cls.__qualname__
    return Wrapper  # type: ignore[return-value]


def resettable_singleton[T](cls: type[T]) -> type[T]:
    """Decorator that makes a class a singleton with a reset capability.

    Adds a `reset()` class method that clears the cached instance,
    which is useful for testing.

    Example::

        @resettable_singleton
        class Cache:
            pass

        a = Cache()
        Cache.reset()
        b = Cache()
        assert a is not b
    """
    instance: T | None = None

    @functools.wraps(cls, updated=())
    class Wrapper(cls):  # type: ignore[valid-type]
        def __new__(cls_inner: type, *args: Any, **kwargs: Any) -> T:
            nonlocal instance
            if instance is None:
                instance = super().__new__(cls_inner)
            return instance

        @classmethod
        def reset(cls_inner: type) -> None:
            """Clear the cached singleton instance."""
            nonlocal instance
            instance = None

    Wrapper.__qualname__ = cls.__qualname__
    return Wrapper  # type: ignore[return-value]


__all__ = ["singleton", "thread_safe_singleton", "resettable_singleton"]
