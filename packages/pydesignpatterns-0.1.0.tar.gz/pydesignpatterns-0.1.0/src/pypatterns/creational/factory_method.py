"""Factory Method pattern — Provides an interface for creating objects in a superclass.

Includes a typed Registry for plugin/factory systems.

See Also:
    https://refactoring.guru/design-patterns/factory-method
"""

from abc import ABC, abstractmethod
from typing import Any

from pypatterns._types import Factory


class Creator[T](ABC):
    """Abstract creator that declares the factory method.

    Subclasses implement ``factory_method`` to produce concrete products.

    Example::

        class Dialog(Creator[Button]):
            pass

        class WindowsDialog(Dialog):
            def factory_method(self) -> Button:
                return WindowsButton()
    """

    @abstractmethod
    def factory_method(self) -> T:
        """Create and return a product instance."""
        ...

    def some_operation(self) -> T:
        """Business logic that uses the factory method."""
        return self.factory_method()


class Registry[K, T]:
    """A typed factory registry that maps keys to factory callables.

    Example::

        registry = Registry[str, Animal]()
        registry.register("dog", Dog)
        registry.register("cat", lambda: Cat("whiskers"))
        animal = registry.create("dog")
    """

    def __init__(self) -> None:
        self._factories: dict[K, Factory[T] | type[T]] = {}

    def register(self, key: K, factory: Factory[T] | type[T]) -> None:
        """Register a factory callable or class under the given key."""
        self._factories[key] = factory

    def unregister(self, key: K) -> None:
        """Remove a registered factory by key."""
        del self._factories[key]

    def create(self, key: K, *args: Any, **kwargs: Any) -> T:
        """Create an instance using the factory registered under ``key``.

        Raises:
            KeyError: If no factory is registered for the given key.
        """
        factory = self._factories[key]
        if args or kwargs:
            return factory(*args, **kwargs)  # type: ignore[call-arg]
        return factory()

    def __contains__(self, key: K) -> bool:
        return key in self._factories

    @property
    def keys(self) -> list[K]:
        """Return all registered keys."""
        return list(self._factories.keys())


def registry_factory[K, T]() -> Registry[K, T]:
    """Create and return a new typed Registry instance.

    Example::

        animals = registry_factory[str, Animal]()
        animals.register("dog", Dog)
    """
    return Registry[K, T]()


__all__ = ["Creator", "Registry", "registry_factory"]
