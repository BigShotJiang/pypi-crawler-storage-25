"""Abstract Factory pattern — Produces families of related objects.

Lets you create groups of related objects without specifying their concrete classes.

See Also:
    https://refactoring.guru/design-patterns/abstract-factory
"""

from abc import ABC, abstractmethod


class AbstractFactory(ABC):
    """Abstract base for factories that produce families of related objects.

    Subclasses implement one ``create_*`` method per product in the family.

    Example::

        class GUIFactory(AbstractFactory):
            @abstractmethod
            def create_button(self) -> Button: ...
            @abstractmethod
            def create_checkbox(self) -> Checkbox: ...

        class WindowsFactory(GUIFactory):
            def create_button(self) -> Button:
                return WindowsButton()
            def create_checkbox(self) -> Checkbox:
                return WindowsCheckbox()
    """


class AbstractProduct(ABC):
    """Optional base for products created by an abstract factory.

    Provides a common interface for product families.
    """

    @abstractmethod
    def operation(self) -> str:
        """Execute the product's primary operation."""
        ...


__all__ = ["AbstractFactory", "AbstractProduct"]
