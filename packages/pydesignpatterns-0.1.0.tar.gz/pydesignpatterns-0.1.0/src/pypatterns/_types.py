"""Shared type aliases for pypatterns. Python 3.12+ type statement syntax."""

from collections.abc import Awaitable, Callable

type Factory[T] = Callable[[], T]
type Predicate[T] = Callable[[T], bool]
type Listener[T] = Callable[[T], None]
type AsyncListener[T] = Callable[[T], Awaitable[None]]
