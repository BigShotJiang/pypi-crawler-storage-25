"""pypatterns — All 23 GoF design patterns as reusable, Pythonic implementations."""

__version__ = "0.1.0"

from pypatterns.behavioral import *  # noqa: F401, F403
from pypatterns.creational import *  # noqa: F401, F403
from pypatterns.structural import *  # noqa: F401, F403
