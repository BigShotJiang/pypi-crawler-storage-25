"""State pattern — Lets an object alter behavior when its internal state changes.

See Also:
    https://refactoring.guru/design-patterns/state
"""

from abc import ABC, abstractmethod


class State[C](ABC):
    """Abstract state that defines behavior for a specific context state.

    Generic on context type ``C`` so states can call back into the context.

    Example::

        class LockedState(State["Phone"]):
            def handle(self) -> str:
                return "Phone is locked"

            def next_state(self) -> State["Phone"]:
                return UnlockedState()
    """

    _context: C | None = None

    @property
    def context(self) -> C:
        """Return the context this state belongs to.

        Raises:
            RuntimeError: If state is not attached to a context.
        """
        if self._context is None:
            raise RuntimeError("State is not attached to a context")
        return self._context

    @context.setter
    def context(self, ctx: C) -> None:
        self._context = ctx

    @abstractmethod
    def handle(self) -> str:
        """Execute behavior for this state."""
        ...


class Context[S: State]:  # type: ignore[type-arg]
    """Context that maintains a current state and delegates behavior.

    Example::

        phone = Context(LockedState())
        phone.request()           # "Phone is locked"
        phone.transition_to(UnlockedState())
        phone.request()           # "Phone is unlocked"
    """

    def __init__(self, initial_state: S) -> None:
        self._state = initial_state
        self._state.context = self  # type: ignore[assignment]

    @property
    def state(self) -> S:
        """Return the current state."""
        return self._state

    def transition_to(self, state: S) -> None:
        """Transition to a new state."""
        self._state = state
        self._state.context = self  # type: ignore[assignment]

    def request(self) -> str:
        """Delegate to the current state's handle method."""
        return self._state.handle()


__all__ = ["State", "Context"]
