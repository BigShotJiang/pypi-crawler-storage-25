"""Command pattern — Turns requests into stand-alone objects.

Supports execute, undo/redo, and command history.

See Also:
    https://refactoring.guru/design-patterns/command
"""

from abc import ABC, abstractmethod
from typing import Protocol, runtime_checkable


@runtime_checkable
class Command(Protocol):
    """Protocol for command objects. Requires ``execute()`` and ``undo()``."""

    def execute(self) -> None: ...
    def undo(self) -> None: ...


class SimpleCommand(ABC):
    """Abstract base for simple commands with execute/undo.

    Example::

        class PrintCommand(SimpleCommand):
            def __init__(self, message: str):
                self.message = message
                self.executed = False

            def execute(self) -> None:
                print(self.message)
                self.executed = True

            def undo(self) -> None:
                if self.executed:
                    print(f"Undo: {self.message}")
                    self.executed = False
    """

    @abstractmethod
    def execute(self) -> None: ...

    @abstractmethod
    def undo(self) -> None: ...


class CommandInvoker:
    """Stores and executes commands with undo/redo support.

    Example::

        invoker = CommandInvoker()
        invoker.submit(AddTextCommand(doc, "hello"))
        invoker.submit(AddTextCommand(doc, " world"))
        invoker.undo()   # undoes " world"
        invoker.redo()   # re-applies " world"
    """

    def __init__(self) -> None:
        self._history: list[Command] = []
        self._redo_stack: list[Command] = []

    def submit(self, cmd: Command) -> None:
        """Execute a command and add it to history."""
        cmd.execute()
        self._history.append(cmd)
        self._redo_stack.clear()

    def undo(self) -> None:
        """Undo the last command.

        Raises:
            IndexError: If there's nothing to undo.
        """
        if not self._history:
            raise IndexError("Nothing to undo")
        cmd = self._history.pop()
        cmd.undo()
        self._redo_stack.append(cmd)

    def redo(self) -> None:
        """Redo the last undone command.

        Raises:
            IndexError: If there's nothing to redo.
        """
        if not self._redo_stack:
            raise IndexError("Nothing to redo")
        cmd = self._redo_stack.pop()
        cmd.execute()
        self._history.append(cmd)

    @property
    def history(self) -> tuple[Command, ...]:
        """Return the command history as a tuple."""
        return tuple(self._history)

    @property
    def can_undo(self) -> bool:
        return len(self._history) > 0

    @property
    def can_redo(self) -> bool:
        return len(self._redo_stack) > 0


@runtime_checkable
class AsyncCommand(Protocol):
    """Protocol for async command objects."""

    async def execute(self) -> None: ...
    async def undo(self) -> None: ...


class AsyncCommandInvoker:
    """Async command invoker with undo/redo support."""

    def __init__(self) -> None:
        self._history: list[AsyncCommand] = []
        self._redo_stack: list[AsyncCommand] = []

    async def submit(self, cmd: AsyncCommand) -> None:
        await cmd.execute()
        self._history.append(cmd)
        self._redo_stack.clear()

    async def undo(self) -> None:
        if not self._history:
            raise IndexError("Nothing to undo")
        cmd = self._history.pop()
        await cmd.undo()
        self._redo_stack.append(cmd)

    async def redo(self) -> None:
        if not self._redo_stack:
            raise IndexError("Nothing to redo")
        cmd = self._redo_stack.pop()
        await cmd.execute()
        self._history.append(cmd)

    @property
    def can_undo(self) -> bool:
        return len(self._history) > 0

    @property
    def can_redo(self) -> bool:
        return len(self._redo_stack) > 0


__all__ = [
    "Command", "SimpleCommand", "CommandInvoker",
    "AsyncCommand", "AsyncCommandInvoker",
]
