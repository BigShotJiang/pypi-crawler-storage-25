"""Visitor pattern — Separates algorithms from the objects they operate on.

Provides double-dispatch via a ``@visitor`` decorator using ``functools.singledispatch``.

See Also:
    https://refactoring.guru/design-patterns/visitor
"""

import functools
from abc import ABC, abstractmethod
from collections.abc import Callable
from typing import Any, Protocol, runtime_checkable


@runtime_checkable
class Visitable(Protocol):
    """Protocol for objects that accept a visitor."""

    def accept(self, visitor: Any) -> Any: ...


class BaseVisitor(ABC):
    """Abstract visitor base class.

    Subclass and define ``visit_*`` methods for each element type.

    Example::

        class AreaVisitor(BaseVisitor):
            def visit_circle(self, circle: Circle) -> float:
                return 3.14 * circle.radius ** 2

            def visit_rectangle(self, rect: Rectangle) -> float:
                return rect.width * rect.height
    """

    @abstractmethod
    def visit(self, element: Any) -> Any:
        """Visit an element. Override or use @visitor decorator."""
        ...


def visitor(cls: type) -> type:
    """Decorator that adds singledispatch-based ``visit()`` to a class.

    Methods named ``visit_<type>`` are auto-registered for dispatch.

    Example::

        @visitor
        class Printer:
            def visit_int(self, element: int) -> str:
                return f"int: {element}"

            def visit_str(self, element: str) -> str:
                return f"str: {element}"

        p = Printer()
        p.visit(42)       # "int: 42"
        p.visit("hello")  # "str: hello"
    """

    @functools.singledispatch
    def _dispatch(element: Any, self: Any) -> Any:
        raise NotImplementedError(
            f"{cls.__name__} has no visitor for {type(element).__name__}"
        )

    # Find visit_<typename> methods and register them
    type_map: dict[str, type] = {}
    for name in dir(cls):
        if name.startswith("visit_") and callable(getattr(cls, name)):
            type_name = name[6:]  # strip "visit_"
            type_map[name] = _resolve_builtin_type(type_name)

    for method_name, target_type in type_map.items():
        method = getattr(cls, method_name)

        def make_handler(m: Callable) -> Callable:
            def handler(element: Any, self: Any) -> Any:
                return m(self, element)
            return handler

        _dispatch.register(target_type, make_handler(method))

    def visit(self: Any, element: Any) -> Any:
        return _dispatch(element, self)

    cls.visit = visit  # type: ignore[attr-defined]
    return cls


def _resolve_builtin_type(name: str) -> type:
    """Resolve a type name string to a Python type."""
    builtins: dict[str, type] = {
        "int": int,
        "float": float,
        "str": str,
        "bool": bool,
        "list": list,
        "dict": dict,
        "tuple": tuple,
        "set": set,
        "bytes": bytes,
        "none": type(None),
    }
    if name in builtins:
        return builtins[name]
    # Try to find in global scope — for custom types, users should
    # register manually or the type must be importable
    import sys
    for module in sys.modules.values():
        if hasattr(module, name):
            candidate = getattr(module, name)
            if isinstance(candidate, type):
                return candidate
    raise TypeError(f"Cannot resolve type '{name}' for visitor dispatch")


__all__ = ["Visitable", "BaseVisitor", "visitor"]
