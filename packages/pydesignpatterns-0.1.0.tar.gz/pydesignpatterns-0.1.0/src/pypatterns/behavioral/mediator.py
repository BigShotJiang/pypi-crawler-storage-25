"""Mediator pattern — Reduces chaotic dependencies between objects.

Forces objects to collaborate through a central mediator instead of
communicating directly.

See Also:
    https://refactoring.guru/design-patterns/mediator
"""

import asyncio
from abc import ABC
from collections.abc import Awaitable, Callable
from typing import Any, Protocol, runtime_checkable


@runtime_checkable
class Mediator(Protocol):
    """Protocol for mediator objects."""

    def notify(self, sender: object, event: str, /, **kwargs: Any) -> None: ...


class Colleague(ABC):
    """Base class for objects that communicate through a mediator.

    Example::

        class Button(Colleague):
            def click(self) -> None:
                self.mediator.notify(self, "click")
    """

    def __init__(self, mediator: Mediator | None = None) -> None:
        self._mediator = mediator

    @property
    def mediator(self) -> Mediator:
        """Return the mediator.

        Raises:
            RuntimeError: If no mediator is set.
        """
        if self._mediator is None:
            raise RuntimeError("No mediator set")
        return self._mediator

    @mediator.setter
    def mediator(self, mediator: Mediator) -> None:
        self._mediator = mediator


class EventMediator:
    """Concrete mediator that routes events by name to registered handlers.

    Example::

        mediator = EventMediator()
        mediator.on("click", lambda sender, **kw: print(f"{sender} clicked"))
        mediator.notify(button, "click")
    """

    def __init__(self) -> None:
        self._handlers: dict[str, list[Callable[..., None]]] = {}

    def on(self, event: str, handler: Callable[..., None]) -> None:
        """Register a handler for an event."""
        self._handlers.setdefault(event, []).append(handler)

    def off(self, event: str, handler: Callable[..., None]) -> None:
        """Remove a handler for an event.

        Raises:
            ValueError: If the handler is not registered.
        """
        self._handlers[event].remove(handler)

    def notify(self, sender: object, event: str, /, **kwargs: Any) -> None:
        """Notify all handlers registered for the given event."""
        for handler in self._handlers.get(event, []):
            handler(sender, **kwargs)

    @property
    def events(self) -> list[str]:
        """Return all registered event names."""
        return list(self._handlers.keys())


class AsyncEventMediator:
    """Async event mediator that notifies handlers concurrently.

    Example::

        mediator = AsyncEventMediator()
        mediator.on("save", async_save_handler)
        await mediator.notify(self, "save", data=payload)
    """

    def __init__(self) -> None:
        self._handlers: dict[str, list[Callable[..., Awaitable[None]]]] = {}

    def on(self, event: str, handler: Callable[..., Awaitable[None]]) -> None:
        self._handlers.setdefault(event, []).append(handler)

    def off(self, event: str, handler: Callable[..., Awaitable[None]]) -> None:
        self._handlers[event].remove(handler)

    async def notify(self, sender: object, event: str, /, **kwargs: Any) -> None:
        handlers = self._handlers.get(event, [])
        if handlers:
            await asyncio.gather(*(h(sender, **kwargs) for h in handlers))

    @property
    def events(self) -> list[str]:
        return list(self._handlers.keys())


__all__ = ["Mediator", "Colleague", "EventMediator", "AsyncEventMediator"]
