"""Memento pattern — Saves and restores an object's previous state.

See Also:
    https://refactoring.guru/design-patterns/memento
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass


@dataclass(frozen=True)
class Memento[T]:
    """Immutable snapshot of state with a timestamp.

    Example::

        memento = Memento(state={"hp": 100, "level": 5})
        print(memento.state)      # {"hp": 100, "level": 5}
        print(memento.timestamp)  # 1711929600.123
    """

    state: T
    timestamp: float


class Originator[T](ABC):
    """Object whose state can be saved and restored via mementos.

    Example::

        class Editor(Originator[str]):
            def __init__(self):
                self.content = ""

            def save(self) -> Memento[str]:
                return Memento(state=self.content, timestamp=time.time())

            def restore(self, memento: Memento[str]) -> None:
                self.content = memento.state
    """

    @abstractmethod
    def save(self) -> Memento[T]:
        """Create a memento capturing the current state."""
        ...

    @abstractmethod
    def restore(self, memento: Memento[T]) -> None:
        """Restore state from a memento."""
        ...


class Caretaker[T]:
    """Manages a history of mementos for an originator.

    Example::

        caretaker = Caretaker()
        caretaker.backup(editor)
        editor.content = "new content"
        caretaker.undo(editor)  # restores previous content
    """

    def __init__(self) -> None:
        self._history: list[Memento[T]] = []

    def backup(self, originator: Originator[T]) -> None:
        """Save the originator's current state."""
        self._history.append(originator.save())

    def undo(self, originator: Originator[T]) -> None:
        """Restore the originator to the last saved state.

        Raises:
            IndexError: If there's no saved state.
        """
        if not self._history:
            raise IndexError("No mementos to restore")
        memento = self._history.pop()
        originator.restore(memento)

    @property
    def history_count(self) -> int:
        """Return the number of saved mementos."""
        return len(self._history)

    def clear(self) -> None:
        """Clear all saved mementos."""
        self._history.clear()


__all__ = ["Memento", "Originator", "Caretaker"]
