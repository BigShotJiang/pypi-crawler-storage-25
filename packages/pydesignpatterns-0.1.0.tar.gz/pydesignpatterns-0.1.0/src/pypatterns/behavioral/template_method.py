"""Template Method pattern — Defines the skeleton of an algorithm in a base class.

Subclasses override specific steps without changing the algorithm's structure.
Optional hooks allow subclasses to extend behavior at predefined points.

See Also:
    https://refactoring.guru/design-patterns/template-method
"""

from abc import ABC, abstractmethod


class TemplateMethod(ABC):
    """Abstract base class that defines a template method algorithm.

    The ``template_method`` calls abstract steps and optional hooks in order.
    Subclasses must implement the abstract steps; hooks have default no-op implementations.

    Example::

        class DataMiner(TemplateMethod):
            def __init__(self, path: str):
                self.path = path
                self.raw_data: str = ""
                self.data: list[str] = []

            def step_one(self) -> None:
                # Extract: read raw data
                self.raw_data = open(self.path).read()

            def step_two(self) -> None:
                # Transform: parse into lines
                self.data = self.raw_data.splitlines()

            def step_three(self) -> None:
                # Load: analyze data
                print(f"Analyzed {len(self.data)} records")

            def hook_before(self) -> None:
                print(f"Starting mining of {self.path}")

        miner = DataMiner("data.csv")
        miner.template_method()
    """

    def template_method(self) -> None:
        """Execute the algorithm steps in order."""
        self.hook_before()
        self.step_one()
        self.step_two()
        self.step_three()
        self.hook_after()

    @abstractmethod
    def step_one(self) -> None:
        """First required step of the algorithm."""
        ...

    @abstractmethod
    def step_two(self) -> None:
        """Second required step of the algorithm."""
        ...

    @abstractmethod
    def step_three(self) -> None:
        """Third required step of the algorithm."""
        ...

    def hook_before(self) -> None:
        """Optional hook called before the algorithm starts."""

    def hook_after(self) -> None:
        """Optional hook called after the algorithm completes."""


__all__ = ["TemplateMethod"]
