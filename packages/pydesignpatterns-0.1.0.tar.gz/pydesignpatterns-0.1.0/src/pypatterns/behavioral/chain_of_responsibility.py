"""Chain of Responsibility pattern — Passes requests along a chain of handlers.

Each handler decides to process the request or pass it to the next handler.
Supports the ``>>`` operator for building chains.

See Also:
    https://refactoring.guru/design-patterns/chain-of-responsibility
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Self


class Handler[T](ABC):
    """Abstract handler in a chain of responsibility.

    Subclass and implement ``handle()`` to process or pass requests.
    Use ``>>`` to chain handlers together.

    Example::

        class SpamFilter(Handler[str]):
            def handle(self, request: str) -> str | None:
                if "spam" in request:
                    return None  # filtered out
                return super().handle(request)

        class Logger(Handler[str]):
            def handle(self, request: str) -> str | None:
                print(f"Log: {request}")
                return super().handle(request)

        chain = SpamFilter() >> Logger()
        chain.handle("hello")      # logged
        chain.handle("buy spam")   # filtered
    """

    def __init__(self) -> None:
        self._next: Handler[T] | None = None

    def set_next(self, handler: Handler[T]) -> Handler[T]:
        """Set the next handler in the chain. Returns the next handler."""
        self._next = handler
        return handler

    def __rshift__(self, other: Handler[T]) -> Self:
        """Chain handlers with ``>>``. Returns self (head of chain)."""
        self.set_next(other)
        return self

    @abstractmethod
    def handle(self, request: T) -> T | None:
        """Process or pass the request.

        Call ``super().handle(request)`` to pass to the next handler.
        Return ``None`` to stop the chain.
        """
        if self._next:
            return self._next.handle(request)
        return request


def chain[T](*handlers: Handler[T]) -> Handler[T]:
    """Build a chain from multiple handlers. Returns the first handler.

    Example::

        head = chain(AuthHandler(), LogHandler(), BusinessHandler())
        head.handle(request)
    """
    if not handlers:
        raise ValueError("At least one handler is required")
    for i in range(len(handlers) - 1):
        handlers[i].set_next(handlers[i + 1])
    return handlers[0]


class AsyncHandler[T](ABC):
    """Async handler in a chain of responsibility.

    Same as ``Handler`` but with ``async handle()``.
    """

    def __init__(self) -> None:
        self._next: AsyncHandler[T] | None = None

    def set_next(self, handler: AsyncHandler[T]) -> AsyncHandler[T]:
        self._next = handler
        return handler

    def __rshift__(self, other: AsyncHandler[T]) -> Self:
        self.set_next(other)
        return self

    @abstractmethod
    async def handle(self, request: T) -> T | None:
        if self._next:
            return await self._next.handle(request)
        return request


def async_chain[T](*handlers: AsyncHandler[T]) -> AsyncHandler[T]:
    """Build an async chain from multiple handlers."""
    if not handlers:
        raise ValueError("At least one handler is required")
    for i in range(len(handlers) - 1):
        handlers[i].set_next(handlers[i + 1])
    return handlers[0]


__all__ = ["Handler", "AsyncHandler", "chain", "async_chain"]
