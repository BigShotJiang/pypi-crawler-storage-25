"""Observer pattern — Defines a subscription mechanism for event notification.

Supports both Protocol-based observers and plain callables.

See Also:
    https://refactoring.guru/design-patterns/observer
"""

import asyncio
from collections.abc import Awaitable, Callable
from typing import Protocol, runtime_checkable


@runtime_checkable
class Observer[T](Protocol):
    """Protocol for observer objects.

    Any object with an ``update(event: T) -> None`` method satisfies this protocol.
    """

    def update(self, event: T) -> None: ...


class Subject[T]:
    """Observable subject that notifies subscribers of events.

    Accepts both ``Observer`` protocol objects and plain callables.

    Example::

        subject = Subject[str]()

        # Subscribe with a callable
        messages: list[str] = []
        subject.subscribe(lambda msg: messages.append(msg))

        # Subscribe with an Observer object
        class Logger:
            def __init__(self):
                self.logs: list[str] = []
            def update(self, event: str) -> None:
                self.logs.append(event)

        logger = Logger()
        subject.subscribe(logger)

        subject.notify("hello")
        assert messages == ["hello"]
        assert logger.logs == ["hello"]
    """

    def __init__(self) -> None:
        self._observers: list[Observer[T] | Callable[[T], None]] = []

    @property
    def observer_count(self) -> int:
        """Return the number of subscribed observers."""
        return len(self._observers)

    def subscribe(self, observer: Observer[T] | Callable[[T], None]) -> None:
        """Add an observer to the notification list."""
        if observer not in self._observers:
            self._observers.append(observer)

    def unsubscribe(self, observer: Observer[T] | Callable[[T], None]) -> None:
        """Remove an observer from the notification list.

        Raises:
            ValueError: If the observer is not subscribed.
        """
        self._observers.remove(observer)

    def notify(self, event: T) -> None:
        """Notify all subscribed observers with the given event."""
        for observer in self._observers:
            if isinstance(observer, Observer):
                observer.update(event)
            else:
                observer(event)


@runtime_checkable
class AsyncObserver[T](Protocol):
    """Protocol for async observer objects."""

    async def update(self, event: T) -> None: ...


class AsyncSubject[T]:
    """Observable subject with async notification.

    Notifies all observers concurrently using ``asyncio.gather``.

    Example::

        subject = AsyncSubject[str]()

        async def handler(msg: str) -> None:
            print(msg)

        subject.subscribe(handler)
        await subject.notify("hello")
    """

    def __init__(self) -> None:
        self._observers: list[AsyncObserver[T] | Callable[[T], Awaitable[None]]] = []

    @property
    def observer_count(self) -> int:
        return len(self._observers)

    def subscribe(self, observer: AsyncObserver[T] | Callable[[T], Awaitable[None]]) -> None:
        if observer not in self._observers:
            self._observers.append(observer)

    def unsubscribe(self, observer: AsyncObserver[T] | Callable[[T], Awaitable[None]]) -> None:
        self._observers.remove(observer)

    async def notify(self, event: T) -> None:
        """Notify all observers concurrently."""
        coros = []
        for observer in self._observers:
            if isinstance(observer, AsyncObserver):
                coros.append(observer.update(event))
            else:
                coros.append(observer(event))
        if coros:
            await asyncio.gather(*coros)


__all__ = ["Observer", "Subject", "AsyncObserver", "AsyncSubject"]
