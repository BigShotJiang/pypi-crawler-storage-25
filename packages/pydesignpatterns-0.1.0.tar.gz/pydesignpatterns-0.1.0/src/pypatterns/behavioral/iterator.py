"""Iterator pattern — Enhanced iterators beyond Python's built-in protocol.

Provides PeekableIterator, FilterIterator, BatchIterator, and more.

See Also:
    https://refactoring.guru/design-patterns/iterator
"""

from abc import ABC, abstractmethod
from collections.abc import Callable, Iterable, Iterator
from typing import Self


class IterableCollection[T](ABC):
    """Abstract collection that creates iterators.

    Example::

        class NumberRange(IterableCollection[int]):
            def __init__(self, start: int, end: int):
                self.start = start
                self.end = end

            def create_iterator(self) -> Iterator[int]:
                return iter(range(self.start, self.end))
    """

    @abstractmethod
    def create_iterator(self) -> Iterator[T]:
        """Create and return an iterator over this collection."""
        ...

    def __iter__(self) -> Iterator[T]:
        return self.create_iterator()


class PeekableIterator[T]:
    """Iterator that supports peeking at the next element without consuming it.

    Example::

        it = PeekableIterator([1, 2, 3])
        assert it.peek() == 1
        assert next(it) == 1
        assert it.peek() == 2
    """

    _sentinel = object()

    def __init__(self, iterable: Iterable[T]) -> None:
        self._iterator = iter(iterable)
        self._peeked: T | object = self._sentinel

    def peek(self) -> T:
        """Return the next element without consuming it.

        Raises:
            StopIteration: If the iterator is exhausted.
        """
        if self._peeked is self._sentinel:
            self._peeked = next(self._iterator)
        return self._peeked  # type: ignore[return-value]

    def has_next(self) -> bool:
        """Check if there are more elements."""
        try:
            self.peek()
            return True
        except StopIteration:
            return False

    def __next__(self) -> T:
        if self._peeked is not self._sentinel:
            value = self._peeked
            self._peeked = self._sentinel
            return value  # type: ignore[return-value]
        return next(self._iterator)

    def __iter__(self) -> Self:
        return self


class FilterIterator[T]:
    """Iterator that yields only elements matching a predicate.

    Example::

        it = FilterIterator([1, 2, 3, 4, 5], lambda x: x % 2 == 0)
        assert list(it) == [2, 4]
    """

    def __init__(self, iterable: Iterable[T], predicate: Callable[[T], bool]) -> None:
        self._iterator = iter(iterable)
        self._predicate = predicate

    def __next__(self) -> T:
        while True:
            item = next(self._iterator)
            if self._predicate(item):
                return item

    def __iter__(self) -> Self:
        return self


class MappingIterator[T, U]:
    """Iterator that transforms elements using a mapping function.

    Example::

        it = MappingIterator([1, 2, 3], lambda x: x * 2)
        assert list(it) == [2, 4, 6]
    """

    def __init__(self, iterable: Iterable[T], mapper: Callable[[T], U]) -> None:
        self._iterator = iter(iterable)
        self._mapper = mapper

    def __next__(self) -> U:
        return self._mapper(next(self._iterator))

    def __iter__(self) -> Self:
        return self


class BatchIterator[T]:
    """Iterator that yields items in chunks of a given size.

    Example::

        it = BatchIterator([1, 2, 3, 4, 5], batch_size=2)
        assert list(it) == [[1, 2], [3, 4], [5]]
    """

    def __init__(self, iterable: Iterable[T], batch_size: int) -> None:
        if batch_size < 1:
            raise ValueError("batch_size must be at least 1")
        self._iterator = iter(iterable)
        self._batch_size = batch_size

    def __next__(self) -> list[T]:
        batch: list[T] = []
        try:
            for _ in range(self._batch_size):
                batch.append(next(self._iterator))
        except StopIteration:
            if batch:
                return batch
            raise
        return batch

    def __iter__(self) -> Self:
        return self


__all__ = [
    "IterableCollection",
    "PeekableIterator",
    "FilterIterator",
    "MappingIterator",
    "BatchIterator",
]
