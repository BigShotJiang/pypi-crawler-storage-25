"""Strategy pattern — Defines a family of interchangeable algorithms.

Accepts both Protocol-based strategy objects and plain callables.

See Also:
    https://refactoring.guru/design-patterns/strategy
"""

from collections.abc import Callable
from typing import Protocol, runtime_checkable


@runtime_checkable
class Strategy[T, R](Protocol):
    """Protocol for strategy objects.

    Any object with an ``execute(data: T) -> R`` method satisfies this protocol.
    """

    def execute(self, data: T) -> R: ...


class StrategyContext[T, R]:
    """Context that delegates work to a swappable strategy.

    Accepts either a ``Strategy`` protocol object or a plain callable ``(T) -> R``.

    Example::

        # With a callable
        ctx = StrategyContext[list[int], list[int]](sorted)
        result = ctx.execute([3, 1, 2])  # [1, 2, 3]

        # Swap strategy at runtime
        ctx.set_strategy(lambda x: list(reversed(x)))
        result = ctx.execute([3, 1, 2])  # [2, 1, 3]

        # With a Strategy object
        class BubbleSort:
            def execute(self, data: list[int]) -> list[int]:
                return sorted(data)

        ctx.set_strategy(BubbleSort())
    """

    def __init__(self, strategy: Strategy[T, R] | Callable[[T], R]) -> None:
        self._strategy = strategy

    @property
    def strategy(self) -> Strategy[T, R] | Callable[[T], R]:
        """Return the current strategy."""
        return self._strategy

    def set_strategy(self, strategy: Strategy[T, R] | Callable[[T], R]) -> None:
        """Replace the current strategy."""
        self._strategy = strategy

    def execute(self, data: T) -> R:
        """Execute the current strategy on the given data."""
        if isinstance(self._strategy, Strategy):
            return self._strategy.execute(data)
        return self._strategy(data)


__all__ = ["Strategy", "StrategyContext"]
