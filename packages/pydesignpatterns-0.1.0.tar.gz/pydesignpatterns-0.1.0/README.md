# pypatterns

All 23 GoF design patterns as reusable, Pythonic, type-safe implementations.

## Installation

```bash
pip install pypatterns
```

## Requirements

- Python 3.12+
- Zero dependencies

## Quick Start

```python
from pypatterns import singleton, Subject, Builder, registry_factory

# Singleton via decorator
@singleton
class Config:
    def __init__(self):
        self.debug = False

# Observer pattern
subject = Subject[str]()
subject.subscribe(lambda msg: print(f"Got: {msg}"))
subject.notify("hello")

# Factory registry
factory = registry_factory[str, Animal]()
factory.register("dog", lambda: Dog())
factory.register("cat", lambda: Cat())
animal = factory.create("dog")
```

## Patterns Included

### Creational
- Singleton, Factory Method, Abstract Factory, Builder, Prototype

### Structural
- Adapter, Bridge, Composite, Decorator, Facade, Flyweight, Proxy

### Behavioral
- Chain of Responsibility, Command, Iterator, Mediator, Memento, Observer, State, Strategy, Template Method, Visitor

## Reference

All patterns follow the catalog at [refactoring.guru/design-patterns](https://refactoring.guru/design-patterns).

## License

MIT
