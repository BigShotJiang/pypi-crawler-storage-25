
# FissionBox SDK

Install with pip
```
pip install fissionbox
```

Run the CLI as follows
```bash
python -m fissionbox.cli.main
```

Temporary local auth flow notes are documented in `docs/local-auth.md`.

For now, the CLI local-auth defaults are:

```text
FISSIONBOX_AUTH_HOST=http://localhost:4242
FISSIONBOX_PLATFORM_HOST=http://localhost:8888
```

Published CLI installs should use the hosted API for platform requests:

```text
FISSIONBOX_PLATFORM_HOST=https://api.beta.platform.fissionbox.ai
FISSIONBOX_HOST=https://api.beta.fissionbox.ai
```

The CLI stores only the auth token and default namespace in `~/.fissionbox/config.json`.
Host overrides are environment-only and are never persisted.

Document workflow commands
```bash
fissionbox auth login

fissionbox namespace use --namespace-id=ns-123

fissionbox document upload --path=./invoices
fissionbox document run --path=./invoice.pdf --schema-file=./schema.json
fissionbox document list
fissionbox document export-chunks --id=art-123 --output=./chunks.ndjson
```

Processed document runs now persist their converter responses server-side in platform, keyed by the saved document run ID. Follow-up platform operations can reuse that stored result instead of sending the full payload back through the client.

Service account tokens for automation
```bash
export FISSIONBOX_PLATFORM_HOST=https://api.beta.platform.fissionbox.ai
export FISSIONBOX_HOST=https://api.beta.fissionbox.ai
export FISSIONBOX_PLATFORM_USER_TOKEN=<user-access-token>
export FISSIONBOX_NAMESPACE_ID=ns-123

fissionbox account create-service-account --name=document-bot
fissionbox account list-service-accounts
fissionbox account issue-token --service-account-id=acc-123 --max-age=2592000
```

Clear the current auth token from your shell with:

```bash
eval "$(fissionbox auth logout --shell)"
```
