from argparse import ArgumentParser, Namespace
import json

from fissionbox.cli.utils.env import get_account_client


def register(parser: ArgumentParser) -> None:
    """Register commands for account and token management."""
    subparsers = parser.add_subparsers(dest="command", required=True)

    subparsers.add_parser("me", help="Show the current platform account")
    subparsers.add_parser("list-service-accounts", help="List available service accounts")

    create_service_account_parser = subparsers.add_parser("create-service-account", help="Create a service account")
    create_service_account_parser.add_argument("--name", type=str, required=True, help="Service account name")

    issue_token_parser = subparsers.add_parser("issue-token", help="Issue an authorized token for a service account")
    issue_token_parser.add_argument("--service-account-id", type=str, required=True, help="Service account ID")
    issue_token_parser.add_argument("--max-age", type=int, default=60 * 60 * 24 * 30, help="Token max age in seconds")

    list_tokens_parser = subparsers.add_parser("list-tokens", help="List authorized tokens for a service account")
    list_tokens_parser.add_argument("--service-account-id", type=str, required=True, help="Service account ID")

    revoke_token_parser = subparsers.add_parser("revoke-token", help="Revoke an authorized token")
    revoke_token_parser.add_argument("--service-account-id", type=str, required=True, help="Service account ID")
    revoke_token_parser.add_argument("--token-id", type=str, required=True, help="Token ID")


def main(args: Namespace) -> None:
    client = get_account_client()
    if args.command == "me":
        print(json.dumps(client.me(), indent=2))
        return

    if args.command == "list-service-accounts":
        print(json.dumps(client.list_service_accounts(), indent=2))
        return

    if args.command == "create-service-account":
        print(json.dumps(client.create_service_account(args.name), indent=2))
        return

    if args.command == "issue-token":
        print(json.dumps(client.issue_authorized_token(args.service_account_id, args.max_age), indent=2))
        return

    if args.command == "list-tokens":
        print(json.dumps(client.list_authorized_tokens(args.service_account_id), indent=2))
        return

    if args.command == "revoke-token":
        client.revoke_authorized_token(args.service_account_id, args.token_id)
        print(json.dumps({"revoked": args.token_id}, indent=2))
        return

    print(f"Unknown command: {args.command}")
