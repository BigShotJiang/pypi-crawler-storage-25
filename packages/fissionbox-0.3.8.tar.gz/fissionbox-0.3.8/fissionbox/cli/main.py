from argparse import ArgumentParser, Namespace
import json
import sys
from urllib.parse import urlparse

import requests

# Import all submodules to register their commands
from fissionbox.cli.dataset import module as dataset_module
from fissionbox.cli.account import module as account_module
from fissionbox.cli.auth import module as auth_module
from fissionbox.cli.document import module as document_module
from fissionbox.cli.namespace import module as namespace_module
from fissionbox.cli.sample import module as sample_module
from fissionbox.cli.reactor import module as reactor_module


def _format_http_error(error: requests.HTTPError) -> str:
    response = error.response
    request = response.request if response is not None else None
    method = request.method if request is not None else "HTTP"
    url = request.url if request is not None else None
    status_code = response.status_code if response is not None else "unknown"
    reason = response.reason if response is not None else "Request failed"

    details = ""
    if response is not None:
        content_type = response.headers.get("Content-Type", "")
        try:
            payload = response.json()
            if isinstance(payload, dict):
                details = str(
                    payload.get("message")
                    or payload.get("error")
                    or payload.get("detail")
                    or json.dumps(payload),
                )
            else:
                details = str(payload)
        except ValueError:
            text = response.text.strip()
            if "text/html" in content_type:
                details = "The server returned HTML instead of an API response. Check the configured host."
            elif text:
                details = text[:300]

    parts = [f"{method} request failed with {status_code} {reason}"]
    if url:
        parts.append(url)
    if details:
        parts.append(details)
    return ": ".join(parts)


def _format_connection_error(error: requests.ConnectionError) -> str:
    request = getattr(error, "request", None)
    url = getattr(request, "url", None)
    host = urlparse(url).netloc if url else "configured host"
    return f"Could not connect to {host}. Check the FISSIONBOX_* host settings and network/DNS connectivity."


def _run_namespace_command(module, args: Namespace) -> int:
    try:
        module.main(args)
        return 0
    except requests.HTTPError as error:
        print(_format_http_error(error), file=sys.stderr)
        return 1
    except requests.ConnectionError as error:
        print(_format_connection_error(error), file=sys.stderr)
        return 1
    except requests.Timeout:
        print("The request timed out. Try again or check the target service.", file=sys.stderr)
        return 1
    except (TimeoutError, ValueError) as error:
        print(str(error), file=sys.stderr)
        return 1


def main():
    parser = ArgumentParser(description="FissionBox CLI")
    subparsers = parser.add_subparsers(dest="namespace", required=True)
    namespace_modules = {
        "account": account_module,
        "auth": auth_module,
        "dataset": dataset_module,
        "document": document_module,
        "namespace": namespace_module,
        "sample": sample_module,
        "reactor": reactor_module,
    }
    for namespace_name, module in namespace_modules.items():
        subparser = subparsers.add_parser(namespace_name, help=module.__doc__)
        module.register(subparser)

    args = parser.parse_args()
    namespace_name = args.namespace
    raise SystemExit(_run_namespace_command(namespace_modules[namespace_name], args))
    

if __name__ == "__main__":
    main()
