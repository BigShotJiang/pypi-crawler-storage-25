from argparse import ArgumentParser, Namespace
from http.server import BaseHTTPRequestHandler, HTTPServer
import json
import os
import sys
import threading
import time
import webbrowser
from urllib.parse import urlencode, urlparse, parse_qs

from fissionbox.cli.utils.config_store import CliConfigStore, CONFIG_STORE
from fissionbox.cli.utils.env import CliRuntime, RUNTIME


SUCCESS_HTML = """
<html>
  <body style="font-family: sans-serif; padding: 2rem;">
    <h2>FissionBox CLI login complete</h2>
    <p>You can return to the terminal now.</p>
  </body>
</html>
"""


class CliLoginCallbackServer:
    def __init__(self):
        self.token = ""

        parent = self

        class CallbackHandler(BaseHTTPRequestHandler):
            def do_GET(self):
                parsed = urlparse(self.path)
                if parsed.path != "/callback":
                    self.send_response(404)
                    self.end_headers()
                    return
                params = parse_qs(parsed.query)
                parent.token = params.get("token", [""])[0]
                self.send_response(200)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.end_headers()
                self.wfile.write(SUCCESS_HTML.encode("utf-8"))

            def log_message(self, format, *args):
                return

        self._server = HTTPServer(("127.0.0.1", 0), CallbackHandler)

    @property
    def callback_url(self) -> str:
        return f"http://127.0.0.1:{self._server.server_port}/callback"

    def await_token(self, timeout_seconds: float) -> str:
        thread = threading.Thread(target=self._server.handle_request, daemon=True)
        thread.start()
        timeout_at = time.time() + timeout_seconds
        while time.time() < timeout_at and not self.token:
            time.sleep(0.2)
        self._server.server_close()
        return self.token


class AuthCommands:
    def __init__(self, runtime: CliRuntime, config_store: CliConfigStore):
        self.runtime = runtime
        self.config_store = config_store

    def shell_exports(self, token: str) -> str:
        return "\n".join(
            [
                f"export FISSIONBOX_AUTH_HOST={json.dumps(self.runtime.get_auth_host())}",
                f"export FISSIONBOX_PLATFORM_HOST={json.dumps(self.runtime.get_platform_host())}",
                f"export FISSIONBOX_HOST={json.dumps(self.runtime.get_fissionbox_host())}",
                f"export FISSIONBOX_PLATFORM_USER_TOKEN={json.dumps(token)}",
            ]
        )

    def shell_unsets(self) -> str:
        return "\n".join(
            [
                "unset FISSIONBOX_PLATFORM_USER_TOKEN",
                "unset FISSIONBOX_PLATFORM_API_KEY",
            ]
        )

    def login(self, *, shell: bool = False) -> None:
        auth_host = self.runtime.get_auth_host()
        platform_host = self.runtime.get_platform_host()
        callback_server = CliLoginCallbackServer()
        login_url = f"{auth_host.rstrip('/')}/auth/login?" + urlencode(
            {"returnTo": callback_server.callback_url}
        )

        print(
            f"Opening browser for login at {auth_host} ...",
            file=sys.stderr if shell else sys.stdout,
        )
        webbrowser.open(login_url)

        token = callback_server.await_token(timeout_seconds=180)
        if not token:
            raise TimeoutError("Login timed out before the CLI received a token.")

        self.config_store.update(platform_user_token=token)

        exports = self.shell_exports(token)
        if shell:
            print(exports)
            return

        print("Login successful, you are now logged in to the FissionBox CLI!")

    def status(self) -> None:
        config = self.config_store.load()
        connection = self.runtime.get_platform_connection()
        print(
            json.dumps(
                {
                    "auth_host": self.runtime.get_auth_host(),
                    "platform_host": self.runtime.get_platform_host(),
                    "fissionbox_host": self.runtime.get_fissionbox_host(),
                    "default_namespace_id": self.runtime.get_default_namespace_id()
                    or None,
                    "has_platform_api_key": bool(
                        os.getenv("FISSIONBOX_PLATFORM_API_KEY")
                        or config.get("platform_api_key")
                    ),
                    "has_platform_user_token": bool(
                        os.getenv("FISSIONBOX_PLATFORM_USER_TOKEN")
                        or config.get("platform_user_token")
                    ),
                    "config_path": str(self.config_store.path),
                    "auth_header": connection._auth_header_name,
                },
                indent=2,
            )
        )

    def logout(self, *, shell: bool = False) -> None:
        self.config_store.update(platform_user_token=None, platform_api_key=None)
        unsets = self.shell_unsets()
        if shell:
            print(unsets)
            return

        print("Logged out.")


AUTH_COMMANDS = AuthCommands(RUNTIME, CONFIG_STORE)


def register(parser: ArgumentParser) -> None:
    """Register commands for CLI authentication."""
    subparsers = parser.add_subparsers(dest="command", required=True)
    login_parser = subparsers.add_parser(
        "login", help="Log in through the web app and print shell exports"
    )
    login_parser.add_argument(
        "--shell", action="store_true", help="Print only shell exports for eval"
    )
    subparsers.add_parser("status", help="Show the current CLI auth status")
    logout_parser = subparsers.add_parser(
        "logout", help="Print shell commands to clear CLI auth variables"
    )
    logout_parser.add_argument(
        "--shell", action="store_true", help="Print only shell commands for eval"
    )


def main(args: Namespace) -> None:
    if args.command == "login":
        AUTH_COMMANDS.login(shell=getattr(args, "shell", False))
        return

    if args.command == "status":
        AUTH_COMMANDS.status()
        return

    if args.command == "logout":
        AUTH_COMMANDS.logout(shell=getattr(args, "shell", False))
        return

    print(f"Unknown command: {args.command}")
