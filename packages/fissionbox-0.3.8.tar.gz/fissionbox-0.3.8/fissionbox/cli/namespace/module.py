from argparse import ArgumentParser, Namespace
import json

from fissionbox.cli.utils.config_store import CliConfigStore, CONFIG_STORE
from fissionbox.cli.utils.env import CliRuntime, RUNTIME


class NamespaceCommands:
    def __init__(self, runtime: CliRuntime, config_store: CliConfigStore):
        self.runtime = runtime
        self.config_store = config_store

    def current(self, *, as_json: bool = False) -> None:
        namespace_id = self.runtime.get_default_namespace_id()
        payload = {
            "namespace_id": namespace_id or None,
            "config_path": str(self.config_store.path),
        }
        if as_json:
            print(json.dumps(payload, indent=2))
        elif namespace_id:
            print(namespace_id)
        else:
            print("No default namespace configured.")

    def use(self, namespace_id: str) -> None:
        self.config_store.update(default_namespace_id=namespace_id)
        print(f"Default namespace set to {namespace_id}.")

    def clear(self) -> None:
        self.config_store.update(default_namespace_id=None)
        print("Default namespace cleared.")


NAMESPACE_COMMANDS = NamespaceCommands(RUNTIME, CONFIG_STORE)


def register(parser: ArgumentParser) -> None:
    """Register commands for default namespace management."""
    subparsers = parser.add_subparsers(dest="command", required=True)

    current_parser = subparsers.add_parser("current", help="Show the current default namespace")
    current_parser.add_argument("--json", action="store_true", help="Print the result as JSON")

    use_parser = subparsers.add_parser("use", help="Set the current default namespace")
    use_parser.add_argument("--namespace-id", type=str, required=True, help="Workspace namespace ID")

    subparsers.add_parser("clear", help="Clear the current default namespace")


def main(args: Namespace) -> None:
    if args.command == "current":
        NAMESPACE_COMMANDS.current(as_json=getattr(args, "json", False))
        return

    if args.command == "use":
        NAMESPACE_COMMANDS.use(args.namespace_id)
        return

    if args.command == "clear":
        NAMESPACE_COMMANDS.clear()
        return

    print(f"Unknown command: {args.command}")
