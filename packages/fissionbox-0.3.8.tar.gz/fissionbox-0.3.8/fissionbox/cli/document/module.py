from argparse import ArgumentParser, Namespace
import json
import os

from fissionbox.cli.utils.env import get_document_client, resolve_namespace_id


def _print_json(payload) -> None:
    print(json.dumps(payload, indent=2))


def register(parser: ArgumentParser) -> None:
    """Register commands for the document namespace."""
    subparsers = parser.add_subparsers(dest="command", required=True)

    upload_parser = subparsers.add_parser("upload", help="Upload source document files")
    upload_parser.add_argument("--namespace-id", type=str, default=None, help="Workspace namespace ID")
    upload_parser.add_argument("--path", type=str, required=True, help="Path to a document file or folder")

    process_parser = subparsers.add_parser("process", help="Process an uploaded source document")
    process_parser.add_argument("--namespace-id", type=str, default=None, help="Workspace namespace ID")
    process_parser.add_argument("--source-path", type=str, required=True, help="Stored source asset path")
    process_parser.add_argument("--name", type=str, default=None, help="Saved document name")
    process_parser.add_argument("--schema-json", type=json.loads, default=None, help="Extraction schema as inline JSON")
    process_parser.add_argument("--schema-file", type=str, default=None, help="Path to extraction schema JSON file")
    process_parser.add_argument("--extract-diagrams", action="store_true", help="Extract diagrams when available")
    process_parser.add_argument("--extract-images", action="store_true", help="Extract images when available")
    process_parser.add_argument(
        "--response-detail",
        choices=["full", "extracted_only"],
        default="full",
        help="Response detail mode",
    )

    run_parser = subparsers.add_parser("run", help="Upload a local document and process it")
    run_parser.add_argument("--namespace-id", type=str, default=None, help="Workspace namespace ID")
    run_parser.add_argument("--path", type=str, required=True, help="Path to a local document file")
    run_parser.add_argument("--name", type=str, default=None, help="Saved document name")
    run_parser.add_argument("--schema-json", type=json.loads, default=None, help="Extraction schema as inline JSON")
    run_parser.add_argument("--schema-file", type=str, default=None, help="Path to extraction schema JSON file")
    run_parser.add_argument("--extract-diagrams", action="store_true", help="Extract diagrams when available")
    run_parser.add_argument("--extract-images", action="store_true", help="Extract images when available")
    run_parser.add_argument(
        "--response-detail",
        choices=["full", "extracted_only"],
        default="full",
        help="Response detail mode",
    )

    list_parser = subparsers.add_parser("list", help="List saved processed documents")
    list_parser.add_argument("--namespace-id", type=str, default=None, help="Workspace namespace ID")
    list_parser.add_argument("--page", type=int, default=0, help="Page index")
    list_parser.add_argument("--size", type=int, default=50, help="Page size")

    export_chunks_parser = subparsers.add_parser("export-chunks", help="Export saved chunks for a processed document")
    export_chunks_parser.add_argument("--namespace-id", type=str, default=None, help="Workspace namespace ID")
    export_chunks_parser.add_argument("--id", type=str, required=True, help="Saved document artifact ID")
    export_chunks_parser.add_argument("--output", type=str, required=True, help="Output file path")


def _resolve_schema(args: Namespace):
    if args.schema_json and args.schema_file:
        raise ValueError("Use either --schema-json or --schema-file, not both.")
    if args.schema_file:
        with open(args.schema_file, "r", encoding="utf-8") as handle:
            return json.load(handle)
    return args.schema_json


def _resolve_document_context(args: Namespace):
    namespace_id = resolve_namespace_id(getattr(args, "namespace_id", None))
    return namespace_id, get_document_client(namespace_id)


def _confirm_folder_upload(path: str) -> bool:
    yes = input(
        f"The path {path} is a directory. Do you want to upload all supported documents in this folder? (y/n): "
    )
    return yes.lower() == "y"


def _upload_documents(client, namespace_id: str, path: str):
    if os.path.isdir(path):
        if not _confirm_folder_upload(path):
            print("Upload cancelled.")
            return None
        return client.upload_folder(namespace_id, path)

    return {path: client.upload(namespace_id, path)}


def main(args: Namespace) -> None:
    if args.command == "upload":
        namespace_id, client = _resolve_document_context(args)
        response = _upload_documents(client, namespace_id, args.path)
        if response is None:
            return
        _print_json(response)
        return

    if args.command == "process":
        namespace_id, client = _resolve_document_context(args)
        response = client.process(
            namespace_id=namespace_id,
            source_path=args.source_path,
            name=args.name,
            extraction_schema=_resolve_schema(args),
            extract_diagrams=args.extract_diagrams,
            extract_images=args.extract_images,
            response_detail=args.response_detail,
        )
        _print_json(response)
        return

    if args.command == "run":
        namespace_id, client = _resolve_document_context(args)
        response = client.run(
            namespace_id=namespace_id,
            path=args.path,
            name=args.name,
            extraction_schema=_resolve_schema(args),
            extract_diagrams=args.extract_diagrams,
            extract_images=args.extract_images,
            response_detail=args.response_detail,
        )
        _print_json(response)
        return

    if args.command == "list":
        namespace_id, client = _resolve_document_context(args)
        response = client.list(namespace_id, page=args.page, size=args.size)
        _print_json(response)
        return

    if args.command == "export-chunks":
        namespace_id, client = _resolve_document_context(args)
        output = client.export_chunks(namespace_id, args.id, args.output)
        _print_json({"output": output})
        return

    print(f"Unknown command: {args.command}")
