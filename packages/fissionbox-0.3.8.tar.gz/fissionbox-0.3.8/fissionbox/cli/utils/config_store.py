import json
from pathlib import Path
from typing import Any


class CliConfigStore:
    def __init__(self, path: Path):
        self.path = path

    @property
    def directory(self) -> Path:
        return self.path.parent

    def load(self) -> dict[str, Any]:
        if not self.path.exists():
            return {}
        try:
            return json.loads(self.path.read_text(encoding="utf-8"))
        except Exception:
            return {}

    def save(self, data: dict[str, Any]) -> None:
        self.directory.mkdir(parents=True, exist_ok=True)
        self.path.write_text(json.dumps(data, indent=2), encoding="utf-8")

    def get(self, key: str, default: Any = "") -> Any:
        return self.load().get(key, default)

    def update(self, **updates: Any) -> dict[str, Any]:
        config = self.load()
        for key, value in updates.items():
            if value is None:
                config.pop(key, None)
            else:
                config[key] = value
        self.save(config)
        return config


CONFIG_PATH = Path.home() / ".fissionbox" / "config.json"
CONFIG_STORE = CliConfigStore(CONFIG_PATH)
