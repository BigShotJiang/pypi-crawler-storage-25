import json
import mimetypes
from pathlib import Path
from typing import Any, Dict, Optional

import requests
from tqdm import tqdm

from .connection import Connection


DOCUMENT_SOURCE_DIRECTORY = "documents/source"
ALLOWED_DOCUMENT_EXTENSIONS = {
    ".pdf",
    ".png",
    ".jpg",
    ".jpeg",
    ".docx",
}
NAMESPACE_HEADER = "X-FissionBox-Namespace-Id"


class DocumentClient:
    def __init__(self, connection: Connection):
        self._connection = connection

    def upload(self, namespace_id: str, path: str, directory: str = DOCUMENT_SOURCE_DIRECTORY) -> str:
        file_path = Path(path)
        if not file_path.exists() or not file_path.is_file():
            raise FileNotFoundError(f"The file at {path} does not exist.")
        content_type, _ = mimetypes.guess_type(str(file_path))
        if not content_type:
            content_type = "application/octet-stream"
        response = self._connection.request(
            "POST",
            "/documents/uploads",
            json={"name": file_path.name},
            headers=self._namespace_headers(namespace_id),
        )
        upload = response.json()
        with file_path.open("rb") as handle:
            upload_response = requests.put(
                upload["upload_url"],
                data=handle,
                headers={"Content-Type": content_type},
            )
        upload_response.raise_for_status()
        return upload["path"]

    def upload_folder(self, namespace_id: str, path: str, directory: str = DOCUMENT_SOURCE_DIRECTORY) -> Dict[str, str]:
        folder = Path(path)
        if not folder.is_dir():
            raise NotADirectoryError(f"The path {path} is not a directory.")
        uploaded: Dict[str, str] = {}
        files = [
            candidate
            for candidate in sorted(folder.rglob("*"))
            if candidate.is_file() and candidate.suffix.lower() in ALLOWED_DOCUMENT_EXTENSIONS
        ]
        for candidate in tqdm(files, desc="Uploading documents"):
            uploaded[str(candidate)] = self.upload(namespace_id, str(candidate), directory=directory)
        return uploaded

    def list(self, namespace_id: str, page: int = 0, size: int = 50) -> Dict[str, Any]:
        response = self._connection.request(
            "GET",
            "/documents",
            params={"page": page, "size": size},
            headers=self._namespace_headers(namespace_id),
        )
        return response.json()

    def get(self, namespace_id: str, document_id: str) -> Dict[str, Any]:
        response = self._connection.request(
            "GET",
            f"/documents/{document_id}",
            headers=self._namespace_headers(namespace_id),
        )
        return response.json()

    def export_chunks(self, namespace_id: str, document_id: str, output_path: str) -> str:
        response = self._connection.request(
            "GET",
            f"/documents/{document_id}/exports/chunks",
            headers=self._namespace_headers(namespace_id),
        )
        data = response.json()
        download = requests.get(data["download_url"])
        download.raise_for_status()
        output = Path(output_path)
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_bytes(download.content)
        return str(output)

    def run(
        self,
        namespace_id: str,
        path: str,
        name: Optional[str] = None,
        extraction_schema: Optional[Dict[str, Any]] = None,
        extract_diagrams: bool = False,
        extract_images: bool = False,
        response_detail: str = "full",
    ) -> Dict[str, Any]:
        source_path = self.upload(namespace_id, path)
        return self.process(
            namespace_id=namespace_id,
            source_path=source_path,
            name=name,
            extraction_schema=extraction_schema,
            extract_diagrams=extract_diagrams,
            extract_images=extract_images,
            response_detail=response_detail,
        )

    def process(
        self,
        namespace_id: str,
        source_path: str,
        name: Optional[str] = None,
        extraction_schema: Optional[Dict[str, Any]] = None,
        extract_diagrams: bool = False,
        extract_images: bool = False,
        response_detail: str = "full",
    ) -> Dict[str, Any]:
        response = self._connection.request(
            "POST",
            "/documents/process",
            json={
                "source_path": source_path,
                "name": name,
                "extraction_schema": extraction_schema,
                "extract_diagrams": extract_diagrams,
                "extract_images": extract_images,
                "response_detail": response_detail,
            },
            headers=self._namespace_headers(namespace_id),
        )
        return response.json()

    @staticmethod
    def _namespace_headers(namespace_id: str) -> Dict[str, str]:
        return {NAMESPACE_HEADER: namespace_id}
