from typing import Any, Dict, List

from .connection import Connection


class AccountClient:
    def __init__(self, connection: Connection):
        self._connection = connection

    def me(self) -> Dict[str, Any]:
        response = self._connection.request("GET", "/accounts/me")
        return response.json()

    def list_service_accounts(self) -> List[Dict[str, Any]]:
        response = self._connection.request("GET", "/accounts/me/service-accounts")
        return response.json()

    def create_service_account(self, account_name: str) -> Dict[str, Any]:
        response = self._connection.request(
            "POST",
            "/accounts/me/service-accounts",
            json={"accountName": account_name},
        )
        return response.json()

    def list_authorized_tokens(self, service_account_id: str) -> Dict[str, Any]:
        response = self._connection.request(
            "GET",
            f"/accounts/me/service-accounts/{service_account_id}/authorized-tokens",
        )
        return response.json()

    def issue_authorized_token(self, service_account_id: str, max_age: int) -> Dict[str, Any]:
        response = self._connection.request(
            "POST",
            f"/accounts/me/service-accounts/{service_account_id}/authorized-tokens",
            json={"maxAge": max_age},
        )
        return response.json()

    def revoke_authorized_token(self, service_account_id: str, token_id: str) -> None:
        self._connection.request(
            "DELETE",
            f"/accounts/me/service-accounts/{service_account_id}/authorized-tokens/{token_id}",
        )
