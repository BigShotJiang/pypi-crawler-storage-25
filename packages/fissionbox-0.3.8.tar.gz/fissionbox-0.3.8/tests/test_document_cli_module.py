import argparse
import importlib.util
import io
import json
import sys
import types
import unittest
from pathlib import Path
from unittest.mock import Mock, patch


MODULE_PATH = (
    Path(__file__).resolve().parents[1] / "fissionbox" / "cli" / "document" / "module.py"
)


def load_document_cli_module():
    env_module = types.ModuleType("fissionbox.cli.utils.env")
    env_module.get_document_client = lambda namespace_id: None
    env_module.resolve_namespace_id = lambda namespace_id: namespace_id

    cli_utils_package = types.ModuleType("fissionbox.cli.utils")
    cli_package = types.ModuleType("fissionbox.cli")
    fissionbox_package = types.ModuleType("fissionbox")

    previous_modules = {
        name: sys.modules.get(name)
        for name in [
            "fissionbox",
            "fissionbox.cli",
            "fissionbox.cli.utils",
            "fissionbox.cli.utils.env",
            "test_document_cli_module_runtime",
        ]
    }

    sys.modules["fissionbox"] = fissionbox_package
    sys.modules["fissionbox.cli"] = cli_package
    sys.modules["fissionbox.cli.utils"] = cli_utils_package
    sys.modules["fissionbox.cli.utils.env"] = env_module

    try:
        spec = importlib.util.spec_from_file_location(
            "test_document_cli_module_runtime",
            MODULE_PATH,
        )
        module = importlib.util.module_from_spec(spec)
        assert spec.loader is not None
        spec.loader.exec_module(module)
        return module
    finally:
        for name, previous in previous_modules.items():
            if previous is None:
                sys.modules.pop(name, None)
            else:
                sys.modules[name] = previous


class DocumentCliModuleTest(unittest.TestCase):
    def test_process_forwards_extract_images(self):
        module = load_document_cli_module()
        client = Mock()
        client.process.return_value = {"status": "queued"}
        args = argparse.Namespace(
            command="process",
            namespace_id="ns-123",
            source_path="documents/source/invoice.pdf",
            name=None,
            schema_json=None,
            schema_file=None,
            extract_diagrams=False,
            extract_images=True,
            response_detail="full",
        )

        with patch.object(module, "resolve_namespace_id", return_value="ns-123"), patch.object(
            module, "get_document_client", return_value=client
        ), patch("sys.stdout", new_callable=io.StringIO) as stdout:
            module.main(args)

        client.process.assert_called_once_with(
            namespace_id="ns-123",
            source_path="documents/source/invoice.pdf",
            name=None,
            extraction_schema=None,
            extract_diagrams=False,
            extract_images=True,
            response_detail="full",
        )
        self.assertEqual({"status": "queued"}, json.loads(stdout.getvalue()))


if __name__ == "__main__":
    unittest.main()
