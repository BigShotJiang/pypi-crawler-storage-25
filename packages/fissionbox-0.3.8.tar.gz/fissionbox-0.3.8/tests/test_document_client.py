import importlib.util
import sys
import types
import unittest
from pathlib import Path
from unittest.mock import Mock


MODULE_PATH = (
    Path(__file__).resolve().parents[1] / "fissionbox" / "core" / "client" / "document.py"
)


def load_document_client_class():
    connection_module = types.ModuleType("fissionbox.core.client.connection")
    requests_module = types.ModuleType("requests")
    tqdm_module = types.ModuleType("tqdm")

    class Connection:  # pragma: no cover - simple test stub
        pass

    connection_module.Connection = Connection
    requests_module.put = Mock()
    requests_module.get = Mock()
    tqdm_module.tqdm = lambda iterable, **kwargs: iterable
    client_package = types.ModuleType("fissionbox.core.client")
    core_package = types.ModuleType("fissionbox.core")
    fissionbox_package = types.ModuleType("fissionbox")

    previous_modules = {
        name: sys.modules.get(name)
        for name in [
            "fissionbox",
            "fissionbox.core",
            "fissionbox.core.client",
            "fissionbox.core.client.connection",
            "fissionbox.core.client.document",
            "requests",
            "tqdm",
            "test_document_client_runtime",
        ]
    }

    sys.modules["fissionbox"] = fissionbox_package
    sys.modules["fissionbox.core"] = core_package
    sys.modules["fissionbox.core.client"] = client_package
    sys.modules["fissionbox.core.client.connection"] = connection_module
    sys.modules["requests"] = requests_module
    sys.modules["tqdm"] = tqdm_module

    try:
        spec = importlib.util.spec_from_file_location(
            "fissionbox.core.client.document",
            MODULE_PATH,
        )
        module = importlib.util.module_from_spec(spec)
        assert spec.loader is not None
        spec.loader.exec_module(module)
        return module.DocumentClient
    finally:
        for name, previous in previous_modules.items():
            if previous is None:
                sys.modules.pop(name, None)
            else:
                sys.modules[name] = previous


class DocumentClientTest(unittest.TestCase):
    def test_process_forwards_extract_images(self):
        document_client_class = load_document_client_class()
        connection = Mock()
        response = Mock()
        response.json.return_value = {"ok": True}
        connection.request.return_value = response

        client = document_client_class(connection)
        result = client.process(
            namespace_id="ns-123",
            source_path="documents/source/invoice.pdf",
            extract_images=True,
        )

        self.assertEqual({"ok": True}, result)
        connection.request.assert_called_once_with(
            "POST",
            "/documents/process",
            json={
                "source_path": "documents/source/invoice.pdf",
                "name": None,
                "extraction_schema": None,
                "extract_diagrams": False,
                "extract_images": True,
                "response_detail": "full",
            },
            headers={"X-FissionBox-Namespace-Id": "ns-123"},
        )

    def test_run_forwards_extract_images_to_process(self):
        document_client_class = load_document_client_class()
        connection = Mock()
        client = document_client_class(connection)
        client.upload = Mock(return_value="documents/source/invoice.pdf")
        client.process = Mock(return_value={"status": "queued"})

        result = client.run(
            namespace_id="ns-123",
            path="/tmp/invoice.pdf",
            extract_images=True,
        )

        self.assertEqual({"status": "queued"}, result)
        client.upload.assert_called_once_with("ns-123", "/tmp/invoice.pdf")
        client.process.assert_called_once_with(
            namespace_id="ns-123",
            source_path="documents/source/invoice.pdf",
            name=None,
            extraction_schema=None,
            extract_diagrams=False,
            extract_images=True,
            response_detail="full",
        )


if __name__ == "__main__":
    unittest.main()
