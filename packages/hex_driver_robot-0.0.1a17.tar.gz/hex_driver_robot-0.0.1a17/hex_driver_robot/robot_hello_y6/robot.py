#!/usr/bin/env python3
# -*- coding:utf-8 -*-
################################################################
# Copyright 2026 Dong Zhaorui. All rights reserved.
# Author: Dong Zhaorui 847235539@qq.com
# Date  : 2026-03-24
################################################################

import time
import numpy as np
import multiprocessing as mp
from dataclasses import dataclass
from typing import Any, Optional

from hex_device import HexDeviceApi, Arm, Hands, set_log_level
from hex_util_runtime import HexRate, HexShmRingBuffer, ns_now, hex_ts_to_ns
from ..base import HexRobotBase, HexRobotBaseParams


@dataclass
class HexRobotHelloY6Params(HexRobotBaseParams):
    led_buffer_size: int = 10


class HexRobotHelloY6(HexRobotBase):

    def __init__(
            self,
            params: HexRobotHelloY6Params = HexRobotHelloY6Params(),
    ) -> None:
        HexRobotBase.__init__(self)
        self.__params = params
        self.__hex_api: Optional[HexDeviceApi] = None
        self.__arm: Optional[Arm] = None
        self.__grip: Optional[Hands] = None

        self.__dof_dict = {"arm": 6, "grip": 7}
        self.__ring_frame_dt = {
            "arm_motor": None,
            "grip_motor": None,
        }
        self.__ring_dict = {
            "arm_motor": None,
            "grip_motor": None,
        }
        self.__rgb_pipe = None
        self.init_vars()

    def get_dofs(self) -> dict[str, int]:
        return self.__dof_dict

    def set_grip_led_cmd(self, cmd_dict: dict[str, Any]) -> None:
        self.__rgb_pipe[1].send({
            "r": cmd_dict["r"],
            "g": cmd_dict["g"],
            "b": cmd_dict["b"],
        })

    def get_arm_motor(self, latest: bool = True) -> Optional[dict[str, Any]]:
        if self.__ring_dict["arm_motor"] is None:
            return None
        return self.__ring_dict["arm_motor"].read(latest=latest)

    def get_grip_motor(self, latest: bool = True) -> Optional[dict[str, Any]]:
        if self.__ring_dict["grip_motor"] is None:
            return None
        return self.__ring_dict["grip_motor"].read(latest=latest)

    def init_vars(self):
        self.__host = self.__params.host
        self.__port = self.__params.port
        self.__ctrl_rate = int(self.__params.ctrl_rate)
        self.__state_buffer_size = int(self.__params.state_buffer_size)
        self.__led_queue_max = int(self.__params.led_buffer_size)
        self.__sens_ts = self.__params.sens_ts

        # state buffer
        self.__ring_frame_dt["arm_motor"] = np.dtype([
            ("ts_ns", np.int64),
            ("pos", np.float64, (6, )),
            ("vel", np.float64, (6, )),
        ])
        self.__ring_dict["arm_motor"] = HexShmRingBuffer(
            capacity=self.__state_buffer_size,
            dtype=self.__ring_frame_dt["arm_motor"],
        )
        self.__ring_frame_dt["grip_motor"] = np.dtype([
            ("ts_ns", np.int64),
            ("pos", np.float64, (7, )),
        ])
        self.__ring_dict["grip_motor"] = HexShmRingBuffer(
            capacity=self.__state_buffer_size,
            dtype=self.__ring_frame_dt["grip_motor"],
        )

        # grip led buffer
        self.__rgb_pipe = mp.Pipe()

    def init_robot(self):
        set_log_level("WARNING")
        # open device
        self.__hex_api = HexDeviceApi(
            ws_url=f"ws://{self.__host}:{self.__port}",
            control_hz=self.__ctrl_rate,
        )

        # open arm
        while self.__hex_api.find_device_by_robot_type(26) is None:
            print("\033[33mArm not found\033[0m")
            time.sleep(1)
        self.__arm = self.__hex_api.find_device_by_robot_type(26)
        self.__arm.start()

        # open grip
        while self.__hex_api.find_optional_device_by_id(1) is None:
            print("\033[33mgrip not found\033[0m")
            time.sleep(1)
        self.__grip = self.__hex_api.find_optional_device_by_id(1)
        self.__grip.set_rgb_stripe_command(
            [255] * 6,
            [0] * 6,
            [0] * 6,
        )

        self._init_event.set()

    def deinit_robot(self):
        main = mp.current_process().name == "MainProcess"
        if main and self.is_working():
            self.stop()

        if self.__grip is not None:
            self.__grip.set_rgb_stripe_command(
                [255] * 6,
                [0] * 6,
                [0] * 6,
            )
        if self.__arm is not None:
            self.__arm.stop()
            self.__arm = None
        if self.__hex_api is not None:
            self.__hex_api.close()
            self.__hex_api = None
        self.__grip = None

        for key in self.__ring_dict.keys():
            if self.__ring_dict[key] is not None:
                self.__ring_dict[key].close()
                self.__ring_dict[key] = None

    def work_loop(self) -> None:
        state_buffer = {
            "arm_motor": np.empty(1, dtype=self.__ring_frame_dt["arm_motor"]),
            "grip_motor": np.empty(1,
                                   dtype=self.__ring_frame_dt["grip_motor"]),
        }
        rate = HexRate(2 * self.__ctrl_rate)
        while not self.stop_event.is_set():
            rate.sleep()
            self.__state_func(state_buffer)
            self.__led_func()

    def __state_func(self, state_buffer) -> None:
        self.__arm_state_func(state_buffer)
        self.__grip_state_func(state_buffer)

    def __arm_state_func(self, state_buffer) -> None:
        arm_state = self.__arm.get_simple_motor_status()
        if arm_state is None:
            return

        ts_ns = hex_ts_to_ns(arm_state["ts"]) if self.__sens_ts else ns_now()
        state_buffer["arm_motor"][0]["ts_ns"] = ts_ns
        state_buffer["arm_motor"][0]["pos"][:] = arm_state["pos"]
        state_buffer["arm_motor"][0]["vel"][:] = arm_state["vel"]
        self.__ring_dict["arm_motor"].write(state_buffer["arm_motor"])

    def __grip_state_func(self, state_buffer) -> None:
        grip_state = self.__grip.get_simple_motor_status()
        if grip_state is None:
            return

        ts_ns = hex_ts_to_ns(grip_state["ts"]) if self.__sens_ts else ns_now()
        state_buffer["grip_motor"][0]["ts_ns"] = ts_ns
        state_buffer["grip_motor"][0]["pos"][:] = grip_state["pos"]
        self.__ring_dict["grip_motor"].write(state_buffer["grip_motor"])

    def __led_func(self) -> None:
        grip_led_cmd = None
        while self.__rgb_pipe[0].poll():
            grip_led_cmd = self.__rgb_pipe[0].recv()
        if grip_led_cmd is not None:
            self.__grip.set_rgb_stripe_command(
                grip_led_cmd["r"].tolist(),
                grip_led_cmd["g"].tolist(),
                grip_led_cmd["b"].tolist(),
            )
