#!/usr/bin/env python3
# -*- coding:utf-8 -*-
################################################################
# Copyright 2026 Dong Zhaorui. All rights reserved.
# Author: Dong Zhaorui 847235539@qq.com
# Date  : 2026-03-26
################################################################

import time
import numpy as np
import multiprocessing as mp
from dataclasses import dataclass, field
from typing import Any, Optional

from hex_device import HexDeviceApi, Arm, Hands, set_log_level
from hex_device.motor_base import CommandType
from hex_util_runtime import HexRate, HexShmRingBuffer, ns_now, hex_ts_to_ns
from hex_util_robot import HexDynUtilY6, HexFricUtil, interp_joint
from hex_util_urdf import HEXARM_URDF_PATH_DICT
from ..base import HexRobotBase, HexRobotBaseParams


@dataclass
class HexRobotFireflyY6Params(HexRobotBaseParams):
    grip_type: str = "gp80"
    pose_end_in_flange: np.ndarray = field(default_factory=lambda: np.array(
        [0.187, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0]))


class HexRobotFireflyY6(HexRobotBase):

    def __init__(
            self,
            params: HexRobotFireflyY6Params = HexRobotFireflyY6Params(),
    ) -> None:
        HexRobotBase.__init__(self)
        self.__params = params
        self.__hex_api: Optional[HexDeviceApi] = None
        self.__arm: Optional[Arm] = None
        self.__grip: Optional[Hands] = None

        self.__dof_dict = {
            "arm": 6,
            "grip": 1 if self.__params.grip_type.startswith("gp80") else 0,
        }
        self.__ring_frame_dt = {
            "arm_motor": None,
            "arm_end": None,
            "grip_motor": None,
        }
        self.__ring_dict = {
            "arm_motor": None,
            "arm_end": None,
            "grip_motor": None,
        }
        self.__pipe_dict = {
            "arm_cmd": None,
            "grip_cmd": None,
        }
        self.__cur_cmd = {
            "arm_cmd": None,
            "grip_cmd": None,
        }
        self.__last_cmd_ts = {
            "arm_cmd": 0,
            "grip_cmd": 0,
        }
        grip_dof = self.__dof_dict["grip"]
        self.__cur_state = {
            "arm": {
                "pos": np.zeros(6),
                "vel": np.zeros(6),
                "tau_comp": np.zeros(6),
            },
            "grip": {
                "pos": np.zeros(grip_dof),
                "vel": np.zeros(grip_dof),
                "tau_comp": np.zeros(grip_dof),
            } if grip_dof > 0 else None,
        }
        self.__dyn_util = HexDynUtilY6(
            model_path=HEXARM_URDF_PATH_DICT[
                f"firefly_y6_{self.__params.grip_type}"],
            pose_end_in_flange=self.__params.pose_end_in_flange,
        )
        self.__arm_fric_util = HexFricUtil(
            fc=np.array([0.15, 0.2, 0.17, 0.2, 0.0, 0.0]),
            fv=np.array([0.0, 0.0, 0.0, 0.0, 0.0, 0.0]),
            fo=np.array([0.0, 0.0, 0.0, 0.0, 0.0, 0.0]),
            k=np.array([200.0, 200.0, 200.0, 200.0, 200.0, 200.0]),
        )
        self.__grip_fric_util = HexFricUtil(
            fc=np.array([0.05]),
            fv=np.array([0.0]),
            fo=np.array([0.0]),
            k=np.array([200.0]),
        ) if self.__params.grip_type.startswith("gp80") else None
        self.init_vars()

    def init_vars(self):
        self.__host = self.__params.host
        self.__port = self.__params.port
        self.__ctrl_rate = int(self.__params.ctrl_rate)
        self.__state_buffer_size = int(self.__params.state_buffer_size)
        self.__sens_ts = self.__params.sens_ts

        # arm state buffer
        self.__ring_frame_dt["arm_motor"] = np.dtype([
            ("ts_ns", np.int64),
            ("pos", np.float64, (6, )),
            ("vel", np.float64, (6, )),
            ("eff", np.float64, (6, )),
        ])
        self.__ring_dict["arm_motor"] = HexShmRingBuffer(
            capacity=self.__state_buffer_size,
            dtype=self.__ring_frame_dt["arm_motor"],
        )

        # arm end buffer
        self.__ring_frame_dt["arm_end"] = np.dtype([
            ("ts_ns", np.int64),
            ("pos", np.float64, (3, )),
            ("quat", np.float64, (4, )),
        ])
        self.__ring_dict["arm_end"] = HexShmRingBuffer(
            capacity=self.__state_buffer_size,
            dtype=self.__ring_frame_dt["arm_end"],
        )

        # grip state buffer
        grip_dof = self.__dof_dict["grip"]
        if grip_dof > 0:
            self.__ring_frame_dt["grip_motor"] = np.dtype([
                ("ts_ns", np.int64),
                ("pos", np.float64, (grip_dof, )),
                ("vel", np.float64, (grip_dof, )),
                ("eff", np.float64, (grip_dof, )),
            ])
            self.__ring_dict["grip_motor"] = HexShmRingBuffer(
                capacity=self.__state_buffer_size,
                dtype=self.__ring_frame_dt["grip_motor"],
            )

        # cmd pipe
        self.__pipe_dict["arm_cmd"] = mp.Pipe()
        self.__pipe_dict["grip_cmd"] = mp.Pipe()

    def init_robot(self):
        set_log_level("WARNING")
        # open device
        self.__hex_api = HexDeviceApi(
            ws_url=f"ws://{self.__host}:{self.__port}",
            control_hz=self.__ctrl_rate,
        )

        # open arm
        while self.__hex_api.find_device_by_robot_type(27) is None:
            print("\033[33mArm not found\033[0m")
            time.sleep(1)
        self.__arm = self.__hex_api.find_device_by_robot_type(27)
        self.__arm.start()

        # try to open grip
        if self.__dof_dict["grip"] > 0:
            self.__grip = self.__hex_api.find_optional_device_by_id(1)
            if self.__grip is None:
                print("\033[33mgrip not found\033[0m")

        self._init_event.set()

    def deinit_robot(self):
        main = mp.current_process().name == "MainProcess"
        if main and self.is_working():
            self.stop()

        if self.__arm is not None:
            self.__arm.stop()
            self.__arm = None
        if self.__hex_api is not None:
            self.__hex_api.close()
            self.__hex_api = None

        for key in self.__ring_dict.keys():
            if self.__ring_dict[key] is not None:
                self.__ring_dict[key].close()
                self.__ring_dict[key] = None

    def get_dofs(self) -> dict[str, int]:
        return self.__dof_dict

    def get_arm_motor(self, latest: bool = True) -> Optional[dict[str, Any]]:
        if self.__ring_dict["arm_motor"] is None:
            return None
        return self.__ring_dict["arm_motor"].read(latest=latest)

    def get_arm_end(self, latest: bool = True) -> Optional[dict[str, Any]]:
        if self.__ring_dict["arm_end"] is None:
            return None
        return self.__ring_dict["arm_end"].read(latest=latest)

    def get_grip_motor(self, latest: bool = True) -> Optional[dict[str, Any]]:
        if self.__ring_dict["grip_motor"] is None:
            return None
        return self.__ring_dict["grip_motor"].read(latest=latest)

    def set_arm_mit_cmd(self, cmd_dict: dict[str, Any]) -> None:
        self.__pipe_dict["arm_cmd"][1].send({
            "type":
            "mit",
            "ts_ns":
            cmd_dict.get("ts_ns", ns_now()),
            "q_tar":
            cmd_dict["q_tar"],
            "dq_tar":
            cmd_dict["dq_tar"],
            "tau":
            cmd_dict["tau"],
            "kp":
            cmd_dict["kp"],
            "kd":
            cmd_dict["kd"],
        })

    def set_arm_mit_comp_cmd(self, cmd_dict: dict[str, Any]) -> None:
        self.__pipe_dict["arm_cmd"][1].send({
            "type":
            "mit_comp",
            "ts_ns":
            cmd_dict.get("ts_ns", ns_now()),
            "q_tar":
            cmd_dict["q_tar"],
            "dq_tar":
            cmd_dict["dq_tar"],
            "tau":
            cmd_dict["tau"],
            "kp":
            cmd_dict["kp"],
            "kd":
            cmd_dict["kd"],
        })

    def set_arm_pos_cmd(self, cmd_dict: dict[str, Any]) -> None:
        self.__pipe_dict["arm_cmd"][1].send({
            "type":
            "pos",
            "ts_ns":
            cmd_dict.get("ts_ns", ns_now()),
            "q_tar":
            cmd_dict["q_tar"],
            "kp":
            cmd_dict.get("kp",
                         np.array([400.0, 400.0, 500.0, 200.0, 100.0, 100.0])),
            "kd":
            cmd_dict.get("kd", np.array([5.0, 5.0, 5.0, 5.0, 2.0, 2.0])),
            "err_limit":
            cmd_dict.get("err_limit", 0.03),
        })

    def set_arm_pose_cmd(self, cmd_dict: dict[str, Any]) -> None:
        self.__pipe_dict["arm_cmd"][1].send({
            "type":
            "pose",
            "ts_ns":
            cmd_dict.get("ts_ns", ns_now()),
            "pos":
            cmd_dict["pos"],
            "quat":
            cmd_dict.get("quat", np.array([1.0, 0.0, 0.0, 0.0])),
            "kp":
            cmd_dict.get("kp",
                         np.array([400.0, 400.0, 500.0, 200.0, 100.0, 100.0])),
            "kd":
            cmd_dict.get("kd", np.array([5.0, 5.0, 5.0, 5.0, 2.0, 2.0])),
            "err_limit":
            cmd_dict.get("err_limit", 0.03),
        })

    def set_grip_mit_cmd(self, cmd_dict: dict[str, Any]) -> None:
        self.__pipe_dict["grip_cmd"][1].send({
            "type":
            "mit",
            "ts_ns":
            cmd_dict.get("ts_ns", ns_now()),
            "q_tar":
            cmd_dict["q_tar"],
            "dq_tar":
            cmd_dict["dq_tar"],
            "tau":
            cmd_dict["tau"],
            "kp":
            cmd_dict["kp"],
            "kd":
            cmd_dict["kd"],
        })

    def set_grip_mit_comp_cmd(self, cmd_dict: dict[str, Any]) -> None:
        self.__pipe_dict["grip_cmd"][1].send({
            "type":
            "mit_comp",
            "ts_ns":
            cmd_dict.get("ts_ns", ns_now()),
            "q_tar":
            cmd_dict["q_tar"],
            "dq_tar":
            cmd_dict["dq_tar"],
            "tau":
            cmd_dict["tau"],
            "kp":
            cmd_dict["kp"],
            "kd":
            cmd_dict["kd"],
        })

    def set_grip_pos_cmd(self, cmd_dict: dict[str, Any]) -> None:
        self.__pipe_dict["grip_cmd"][1].send({
            "type":
            "pos",
            "ts_ns":
            cmd_dict.get("ts_ns", ns_now()),
            "q_tar":
            cmd_dict["q_tar"],
            "kp":
            cmd_dict.get("kp", np.array([10.0])),
            "kd":
            cmd_dict.get("kd", np.array([0.5])),
            "err_limit":
            cmd_dict.get("err_limit", 0.01),
        })

    def work_loop(self) -> None:
        state_buffer = {
            "arm_motor":
            np.empty(1, dtype=self.__ring_frame_dt["arm_motor"]),
            "arm_end":
            np.empty(1, dtype=self.__ring_frame_dt["arm_end"]),
            "grip_motor":
            np.empty(1, dtype=self.__ring_frame_dt["grip_motor"])
            if "grip_motor" in self.__ring_frame_dt else None,
        }
        rate = HexRate(2 * self.__ctrl_rate)
        while not self.stop_event.is_set():
            rate.sleep()
            self.__state_func(state_buffer)
            self.__cmd_func()

    def __state_func(self, state_buffer) -> None:
        self.__arm_state_func(state_buffer)
        if self.__grip is not None and self.__dof_dict["grip"] > 0:
            self.__grip_state_func(state_buffer)

    def __arm_state_func(self, state_buffer) -> None:
        arm_state = self.__arm.get_simple_motor_status()
        if arm_state is None:
            return

        ts_ns = hex_ts_to_ns(arm_state["ts"]) if self.__sens_ts else ns_now()
        state_buffer["arm_motor"][0]["ts_ns"] = ts_ns
        state_buffer["arm_motor"][0]["pos"][:] = arm_state["pos"]
        state_buffer["arm_motor"][0]["vel"][:] = arm_state["vel"]
        state_buffer["arm_motor"][0]["eff"][:] = arm_state["eff"]
        self.__ring_dict["arm_motor"].write(state_buffer["arm_motor"])

        arm_pos, arm_quat = self.__dyn_util.forward_kinematics(
            arm_state["pos"])[-1]
        state_buffer["arm_end"][0]["ts_ns"] = ts_ns
        state_buffer["arm_end"][0]["pos"][:] = arm_pos
        state_buffer["arm_end"][0]["quat"][:] = arm_quat
        self.__ring_dict["arm_end"].write(state_buffer["arm_end"])

        self.__cur_state["arm"]["pos"][:] = arm_state["pos"]
        self.__cur_state["arm"]["vel"][:] = arm_state["vel"]
        self.__cur_state["arm"]["tau_comp"][:] = self.__cal_arm_comp(
            arm_state["pos"], arm_state["vel"])

    def __grip_state_func(self, state_buffer) -> None:
        grip_state = self.__grip.get_simple_motor_status()
        if grip_state is None:
            return

        ts_ns = hex_ts_to_ns(grip_state["ts"]) if self.__sens_ts else ns_now()
        state_buffer["grip_motor"][0]["ts_ns"] = ts_ns
        state_buffer["grip_motor"][0]["pos"][:] = grip_state["pos"]
        state_buffer["grip_motor"][0]["vel"][:] = grip_state["vel"]
        state_buffer["grip_motor"][0]["eff"][:] = grip_state["eff"]
        self.__ring_dict["grip_motor"].write(state_buffer["grip_motor"])

        self.__cur_state["grip"]["pos"][:] = grip_state["pos"]
        self.__cur_state["grip"]["vel"][:] = grip_state["vel"]
        self.__cur_state["grip"]["tau_comp"][:] = self.__cal_grip_comp(
            grip_state["vel"])

    def __cmd_func(self) -> None:
        while self.__pipe_dict["arm_cmd"][0].poll():
            self.__cur_cmd["arm_cmd"] = self.__pipe_dict["arm_cmd"][0].recv()
        self.__arm_cmd_func()
        while self.__pipe_dict["grip_cmd"][0].poll():
            self.__cur_cmd["grip_cmd"] = self.__pipe_dict["grip_cmd"][0].recv()
        if self.__grip is not None and self.__dof_dict["grip"] > 0:
            self.__grip_cmd_func()

    def __arm_cmd_func(self) -> None:
        if self.__cur_cmd["arm_cmd"] is None:
            return

        if self.__cur_cmd["arm_cmd"]["ts_ns"] is None or self.__cur_cmd[
                "arm_cmd"]["ts_ns"] <= self.__last_cmd_ts["arm_cmd"]:
            return

        self.__last_cmd_ts["arm_cmd"] = self.__cur_cmd["arm_cmd"]["ts_ns"]
        cur_pos = self.__cur_state["arm"]["pos"]

        if self.__cur_cmd["arm_cmd"]["type"] == "mit":
            arm_cmd = self.__arm.construct_mit_command(
                self.__cur_cmd["arm_cmd"]["q_tar"],
                self.__cur_cmd["arm_cmd"]["dq_tar"],
                self.__cur_cmd["arm_cmd"]["tau"],
                self.__cur_cmd["arm_cmd"]["kp"],
                self.__cur_cmd["arm_cmd"]["kd"],
            )
            self.__arm.motor_command(CommandType.MIT, arm_cmd)
            return
        elif self.__cur_cmd["arm_cmd"]["type"] == "mit_comp":
            arm_cmd = self.__arm.construct_mit_command(
                self.__cur_cmd["arm_cmd"]["q_tar"],
                self.__cur_cmd["arm_cmd"]["dq_tar"],
                self.__cur_cmd["arm_cmd"]["tau"] +
                self.__cur_state["arm"]["tau_comp"],
                self.__cur_cmd["arm_cmd"]["kp"],
                self.__cur_cmd["arm_cmd"]["kd"],
            )
            self.__arm.motor_command(CommandType.MIT, arm_cmd)
            return
        elif self.__cur_cmd["arm_cmd"]["type"] == "pos":
            tar_pos = interp_joint(
                cur_pos,
                self.__cur_cmd["arm_cmd"]["q_tar"],
                err_limit=self.__cur_cmd["arm_cmd"]["err_limit"],
            )
            arm_cmd = self.__arm.construct_mit_command(
                tar_pos,
                np.zeros(6),
                self.__cur_state["arm"]["tau_comp"],
                self.__cur_cmd["arm_cmd"]["kp"],
                self.__cur_cmd["arm_cmd"]["kd"],
            )
            self.__arm.motor_command(CommandType.MIT, arm_cmd)
            return
        elif self.__cur_cmd["arm_cmd"]["type"] == "pose":
            tar_pos = self.__cur_cmd["arm_cmd"]["pos"]
            tar_quat = self.__cur_cmd["arm_cmd"]["quat"]
            success, tar_pos = self.__dyn_util.inverse_kinematics_analytic(
                (tar_pos, tar_quat),
                cur_pos,
            )
            if not success:
                print("Inverse kinematics failed")
                return
            tar_pos = interp_joint(
                cur_pos,
                tar_pos,
                err_limit=self.__cur_cmd["arm_cmd"]["err_limit"],
            )
            arm_cmd = self.__arm.construct_mit_command(
                tar_pos,
                np.zeros(6),
                self.__cur_state["arm"]["tau_comp"],
                self.__cur_cmd["arm_cmd"]["kp"],
                self.__cur_cmd["arm_cmd"]["kd"],
            )
            self.__arm.motor_command(CommandType.MIT, arm_cmd)
            return
        else:
            raise ValueError(
                f"Unknown arm command type: {self.__cur_cmd['arm_cmd']['type']}"
            )

    def __grip_cmd_func(self) -> None:
        if self.__cur_cmd["grip_cmd"] is None:
            return

        if self.__cur_cmd["grip_cmd"]["ts_ns"] is None or self.__cur_cmd[
                "grip_cmd"]["ts_ns"] <= self.__last_cmd_ts["grip_cmd"]:
            return

        self.__last_cmd_ts["grip_cmd"] = self.__cur_cmd["grip_cmd"]["ts_ns"]
        cur_pos = self.__cur_state["grip"]["pos"]

        if self.__cur_cmd["grip_cmd"]["type"] == "mit":
            grip_cmd = self.__grip.construct_mit_command(
                self.__cur_cmd["grip_cmd"]["q_tar"],
                self.__cur_cmd["grip_cmd"]["dq_tar"],
                self.__cur_cmd["grip_cmd"]["tau"],
                self.__cur_cmd["grip_cmd"]["kp"],
                self.__cur_cmd["grip_cmd"]["kd"],
            )
            self.__grip.motor_command(CommandType.MIT, grip_cmd)
            return
        elif self.__cur_cmd["grip_cmd"]["type"] == "mit_comp":
            grip_cmd = self.__grip.construct_mit_command(
                self.__cur_cmd["grip_cmd"]["q_tar"],
                self.__cur_cmd["grip_cmd"]["dq_tar"],
                self.__cur_cmd["grip_cmd"]["tau"] +
                self.__cur_state["grip"]["tau_comp"],
                self.__cur_cmd["grip_cmd"]["kp"],
                self.__cur_cmd["grip_cmd"]["kd"],
            )
            self.__grip.motor_command(CommandType.MIT, grip_cmd)
            return
        elif self.__cur_cmd["grip_cmd"]["type"] == "pos":
            tar_pos = interp_joint(
                cur_pos,
                self.__cur_cmd["grip_cmd"]["q_tar"],
                err_limit=self.__cur_cmd["grip_cmd"]["err_limit"],
            )
            grip_cmd = self.__grip.construct_mit_command(
                tar_pos,
                np.zeros(self.__dof_dict["grip"]),
                self.__cur_state["grip"]["tau_comp"],
                self.__cur_cmd["grip_cmd"]["kp"],
                self.__cur_cmd["grip_cmd"]["kd"],
            )
            self.__grip.motor_command(CommandType.MIT, grip_cmd)
            return
        else:
            raise ValueError(
                f"Unknown grip command type: {self.__cur_cmd['grip_cmd']['type']}"
            )

    def __cal_arm_comp(self, cur_q, cur_dq):
        tau_comp = self.__dyn_util.compensation(cur_q, cur_dq)
        tau_comp += self.__arm_fric_util(cur_dq)
        return tau_comp

    def __cal_grip_comp(self, cur_dq):
        tau_comp = self.__grip_fric_util(cur_dq)
        return tau_comp
