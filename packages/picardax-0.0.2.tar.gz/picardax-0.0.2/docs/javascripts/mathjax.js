window.MathJax = {
  tex: {
    inlineMath: [["\\(", "\\)"], ["$", "$"]],
    displayMath: [["\\[", "\\]"], ["$$", "$$"]],
    processEscapes: true,
    processEnvironments: true
  },
  options: {
    ignoreHtmlClass: ".*|",
    processHtmlClass: "arithmatex|jp-RenderedHTMLCommon|jp-RenderedMarkdown|md-content"
  }
};

document$.subscribe(() => {
  MathJax.typesetPromise()
})
