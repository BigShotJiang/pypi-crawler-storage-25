# Getting Started

<p align="center">
  <img src="imgs/logo.svg" alt="picardax logo" width="300">
</p>

`Picardax` is a library for time-implicit, differentiable PDE solvers in JAX. It
is a sister project to [Exponax](https://github.com/Ceyron/exponax) (which
provides *explicit* and exponential time steppers). Where Exponax sidesteps
nonlinear solves entirely, Picardax embraces them: it solves the implicit system
arising from theta-method (and similar) time discretizations using iterative
nonlinear solvers (Picard iteration, Newton's method) that themselves rely on
iterative linear solvers (CG, GMRES, BiCGStab).

## Installation

```bash
pip install picardax
```

Requires Python 3.10+ and JAX 0.4.13+. See the [JAX install guide](https://jax.readthedocs.io/en/latest/installation.html).


## License

MIT, see [here](https://github.com/Ceyron/picardax/blob/main/LICENSE)

---

> [fkoehler.site](https://fkoehler.site/) &nbsp;&middot;&nbsp;
> GitHub [@ceyron](https://github.com/ceyron) &nbsp;&middot;&nbsp;
> X [@felix_m_koehler](https://twitter.com/felix_m_koehler)
