import jax
import jax.numpy as jnp
import pytest

# Enable x64 globally so float64 tests work. This does not affect
# float32 tests — it just allows both precisions to be used.
jax.config.update("jax_enable_x64", True)


@pytest.fixture(params=[jnp.float32, jnp.float64], ids=["f32", "f64"])
def precision(request):
    """Yield the dtype; tests run once per precision."""
    return request.param


@pytest.fixture
def spd_system(precision):
    """A small 10x10 symmetric positive definite system."""
    key = jax.random.key(0)
    Q = jax.random.normal(key, (10, 10), dtype=precision)
    A = Q.T @ Q + 0.1 * jnp.eye(10, dtype=precision)
    b = jnp.ones(10, dtype=precision)
    x_true = jnp.linalg.solve(A, b)

    def lin_fun(x):
        return A @ x

    return lin_fun, b, x_true


@pytest.fixture
def general_system(precision):
    """A 10x10 non-symmetric but diagonally dominant system."""
    key = jax.random.key(42)
    Q = jax.random.normal(key, (10, 10), dtype=precision)
    A = Q + 5.0 * jnp.eye(10, dtype=precision)
    b = jnp.ones(10, dtype=precision)
    x_true = jnp.linalg.solve(A, b)

    def lin_fun(x):
        return A @ x

    return lin_fun, b, x_true


@pytest.fixture
def identity_system(precision):
    """Trivial system: A = I, so x = b."""

    def lin_fun(x):
        return x

    b = jnp.array([1.0, 2.0, 3.0, 4.0, 5.0], dtype=precision)
    x_true = b
    return lin_fun, b, x_true
