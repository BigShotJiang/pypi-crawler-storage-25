import equinox as eqx
import jax
import jax.numpy as jnp
import pytest

from picardax._linear_solver import CG, GMRES
from picardax._residuum import ThetaResiduum
from picardax._solver import Newton, Picard, Solver
from picardax.periodic._derivatives import CollocatedDerivatives
from picardax.periodic.rhs._burgers import Burgers
from picardax.periodic.rhs._diffusion import Diffusion

jax.config.update("jax_enable_x64", True)

DOMAIN_EXTENT = 2 * jnp.pi


def sin_1d(N, k=1):
    x = jnp.linspace(0, DOMAIN_EXTENT, N, endpoint=False)
    return jnp.sin(k * x)[None]


def make_diffusion_residuum(N=32, nu=0.01, dt=0.01, theta=0.5):
    derivatives = CollocatedDerivatives(1, N, DOMAIN_EXTENT)
    rhs = Diffusion(derivatives=derivatives, diffusivity=nu)
    return ThetaResiduum(rhs=rhs, theta=theta, dt=dt)


def make_burgers_residuum(N=32, nu=0.01, conv=1.0, dt=0.01, theta=0.5):
    derivatives = CollocatedDerivatives(1, N, DOMAIN_EXTENT)
    rhs = Burgers(derivatives=derivatives, diffusivity=nu, convection_scale=conv)
    return ThetaResiduum(rhs=rhs, theta=theta, dt=dt)


# ─── Abstract base class ───


class TestSolverBase:
    def test_is_abstract(self):
        with pytest.raises(TypeError):
            Solver(linear_solver=CG())


# ─── Picard solver ───


class TestPicard:
    def test_solves_linear_diffusion(self):
        residuum = make_diffusion_residuum()
        solver = Picard(linear_solver=CG())
        u0 = sin_1d(32)
        u1 = solver(residuum, u0)
        assert u1.shape == u0.shape
        assert not jnp.allclose(u1, u0)  # state should change

    def test_linear_pde_one_picard_iteration(self):
        """For linear PDE, Picard converges in exactly 1 iteration."""
        residuum = make_diffusion_residuum()
        solver = Picard(linear_solver=CG())
        u0 = sin_1d(32)
        n_iters = solver.diagnose(residuum, u0)
        assert n_iters == 1

    def test_nonlinear_pde_multiple_iterations(self):
        residuum = make_burgers_residuum(dt=0.1)
        solver = Picard(linear_solver=GMRES())
        u0 = sin_1d(32)
        n_iters = solver.diagnose(residuum, u0)
        assert n_iters > 1


# ─── Newton solver ───


class TestNewton:
    def test_solves_linear_diffusion(self):
        residuum = make_diffusion_residuum()
        solver = Newton(linear_solver=CG())
        u0 = sin_1d(32)
        u1 = solver(residuum, u0)
        assert u1.shape == u0.shape

    def test_matches_picard_on_linear_pde(self):
        """Newton and Picard should give identical results on linear PDEs."""
        residuum = make_diffusion_residuum()
        u0 = sin_1d(32)
        u_picard = Picard(linear_solver=CG())(residuum, u0)
        u_newton = Newton(linear_solver=CG())(residuum, u0)
        assert jnp.allclose(u_picard, u_newton, atol=1e-6)

    def test_solves_nonlinear_burgers(self):
        residuum = make_burgers_residuum(dt=0.01)
        solver = Newton(linear_solver=GMRES())
        u0 = sin_1d(32)
        u1 = solver(residuum, u0)
        assert u1.shape == u0.shape


# ─── Throw behavior ───


class TestThrowBehavior:
    def test_throw_true_converged_no_error(self):
        residuum = make_diffusion_residuum()
        solver = Picard(linear_solver=CG(), throw=True)
        u0 = sin_1d(32)
        u1 = solver(residuum, u0)
        assert u1.shape == u0.shape

    def test_throw_true_not_converged_raises(self):
        residuum = make_diffusion_residuum()
        solver = Picard(linear_solver=CG(), throw=True, maxiter=0, tol=1e-15)
        u0 = sin_1d(32)
        with pytest.raises(Exception, match="Nonlinear solver"):
            solver(residuum, u0)

    def test_throw_false_returns_result(self):
        residuum = make_diffusion_residuum()
        solver = Picard(linear_solver=CG(), throw=False, maxiter=0)
        u0 = sin_1d(32)
        u1 = solver(residuum, u0)
        assert u1.shape == u0.shape

    def test_throw_true_not_converged_raises_under_jit(self):
        residuum = make_diffusion_residuum()
        solver = Picard(linear_solver=CG(), throw=True, maxiter=0, tol=1e-15)
        u0 = sin_1d(32)

        @eqx.filter_jit
        def solve(u):
            return solver(residuum, u)

        with pytest.raises(eqx.EquinoxRuntimeError, match="Nonlinear solver"):
            solve(u0)

    def test_throw_false_not_converged_returns_under_jit(self):
        residuum = make_diffusion_residuum()
        solver = Picard(linear_solver=CG(), throw=False, maxiter=0)
        u0 = sin_1d(32)

        @eqx.filter_jit
        def solve(u):
            return solver(residuum, u)

        u1 = solve(u0)
        assert u1.shape == u0.shape


# ─── Diagnostics ───


class TestDiagnostics:
    def test_get_all_iterates_shape(self):
        residuum = make_diffusion_residuum()
        solver = Picard(linear_solver=CG(), maxiter=5)
        u0 = sin_1d(32)
        iterates = solver.get_all_iterates(residuum, u0)
        assert iterates.shape == (5, *u0.shape)

    def test_get_all_iterates_with_init(self):
        residuum = make_diffusion_residuum()
        solver = Picard(linear_solver=CG(), maxiter=5)
        u0 = sin_1d(32)
        iterates = solver.get_all_iterates(residuum, u0, include_init=True)
        assert iterates.shape == (6, *u0.shape)

    def test_get_error_iterates_shape(self):
        residuum = make_diffusion_residuum()
        solver = Picard(linear_solver=CG(), maxiter=5)
        u0 = sin_1d(32)
        errors = solver.get_error_iterates(residuum, u0)
        assert errors.shape == (5,)

    def test_error_iterates_decrease_for_linear(self):
        """For a linear PDE, error should drop to ~0 after first iteration."""
        residuum = make_diffusion_residuum()
        solver = Picard(linear_solver=CG(), maxiter=5)
        u0 = sin_1d(32)
        errors = solver.get_error_iterates(residuum, u0)
        # After first iteration, error should be very small
        assert errors[1] < 1e-3

    def test_diagnose_returns_int(self):
        residuum = make_diffusion_residuum()
        solver = Picard(linear_solver=CG())
        u0 = sin_1d(32)
        n = solver.diagnose(residuum, u0)
        assert n >= 1


# ─── JIT compatibility ───


class TestJITCompatibility:
    def test_picard_under_jit(self):
        residuum = make_diffusion_residuum()
        solver = Picard(linear_solver=CG())
        u0 = sin_1d(32)
        u_eager = solver(residuum, u0)

        @jax.jit
        def solve(u):
            return solver(residuum, u)

        u_jit = solve(u0)
        assert jnp.allclose(u_eager, u_jit)

    def test_newton_under_jit(self):
        residuum = make_diffusion_residuum()
        solver = Newton(linear_solver=CG())
        u0 = sin_1d(32)
        u_eager = solver(residuum, u0)

        @jax.jit
        def solve(u):
            return solver(residuum, u)

        u_jit = solve(u0)
        assert jnp.allclose(u_eager, u_jit)

    def test_solver_is_valid_pytree(self):
        solver = Picard(linear_solver=CG(), maxiter=50)
        leaves, treedef = jax.tree_util.tree_flatten(solver)
        solver_rt = jax.tree_util.tree_unflatten(treedef, leaves)
        assert solver_rt.maxiter == solver.maxiter
