"""Tests for differentiation through implicit solvers.

Organized by the plan's 5 groups:
  1. Correctness (per mode)
  2. Mode-specific properties
  3. Parameter gradients
  4. Initial guess interaction
  5. Composition and edge cases
"""

import equinox as eqx
import jax
import jax.numpy as jnp
import pytest

from picardax._linear_solver import CG, GMRES
from picardax._residuum import ThetaResiduum
from picardax._solver import Newton, Picard
from picardax._stepper import Stepper
from picardax.periodic._derivatives import CollocatedDerivatives
from picardax.periodic.rhs._burgers import Burgers as BurgersRHS
from picardax.periodic.rhs._diffusion import Diffusion as DiffusionRHS

jax.config.update("jax_enable_x64", True)

DOMAIN_EXTENT = 2 * jnp.pi
N = 32


def sin_1d(N=N, k=1):
    x = jnp.linspace(0, DOMAIN_EXTENT, N, endpoint=False)
    return jnp.sin(k * x)[None]


def make_diffusion_stepper(diff_mode="implicit", throw=False, **solver_kw):
    derivatives = CollocatedDerivatives(1, N, DOMAIN_EXTENT)
    rhs = DiffusionRHS(derivatives=derivatives, diffusivity=0.01)
    residuum = ThetaResiduum(rhs=rhs, theta=0.5, dt=0.01)
    solver = Picard(
        linear_solver=CG(tol=1e-10),
        maxiter=1,
        tol=1e-5,
        throw=throw,
        diff_mode=diff_mode,
        **solver_kw,
    )
    return Stepper(residuum=residuum, solver=solver)


def make_burgers_stepper(diff_mode="implicit", throw=False, **solver_kw):
    derivatives = CollocatedDerivatives(1, N, DOMAIN_EXTENT)
    rhs = BurgersRHS(derivatives=derivatives, diffusivity=0.01, convection_scale=1.0)
    residuum = ThetaResiduum(rhs=rhs, theta=0.5, dt=0.01)
    solver = Picard(
        linear_solver=GMRES(tol=1e-10),
        maxiter=100,
        tol=1e-5,
        throw=throw,
        diff_mode=diff_mode,
        **solver_kw,
    )
    return Stepper(residuum=residuum, solver=solver)


def scalar_loss(stepper, u):
    return jnp.sum(stepper(u) ** 2)


# ─── Group 1: Correctness (per mode) ───


class TestFiniteDiffValidation:
    """Test 1: Finite difference validation for VJP and/or JVP per mode."""

    @pytest.mark.parametrize(
        "diff_mode",
        [
            "implicit",
            "implicit_jvp",
            "bounded",
            "implicit_reduced",
            "implicit_reduced_jvp",
        ],
    )
    def test_grad_diffusion(self, diff_mode):
        stepper = make_diffusion_stepper(diff_mode=diff_mode)
        u0 = sin_1d()

        def loss(u):
            return scalar_loss(stepper, u)

        grad_ad = jax.grad(loss)(u0)

        # Finite difference
        eps = 1e-5
        grad_fd = jnp.zeros_like(u0)
        u0_flat = u0.flatten()
        for i in range(min(5, u0_flat.size)):  # Check first 5 elements
            e = jnp.zeros_like(u0_flat).at[i].set(eps)
            fp = loss(u0 + e.reshape(u0.shape))
            fm = loss(u0 - e.reshape(u0.shape))
            grad_fd = grad_fd.at[0, i].set((fp - fm) / (2 * eps))

        assert jnp.allclose(grad_ad[0, :5], grad_fd[0, :5], atol=1e-4, rtol=1e-3), (
            f"Mode {diff_mode}: AD grad doesn't match FD"
        )

    @pytest.mark.parametrize(
        "diff_mode",
        ["implicit", "implicit_jvp", "bounded"],
    )
    def test_grad_burgers(self, diff_mode):
        stepper = make_burgers_stepper(diff_mode=diff_mode)
        u0 = 0.1 * sin_1d()  # Small amplitude for easier convergence

        def loss(u):
            return scalar_loss(stepper, u)

        grad_ad = jax.grad(loss)(u0)

        eps = 1e-5
        grad_fd = jnp.zeros_like(u0)
        u0_flat = u0.flatten()
        for i in range(min(5, u0_flat.size)):
            e = jnp.zeros_like(u0_flat).at[i].set(eps)
            fp = loss(u0 + e.reshape(u0.shape))
            fm = loss(u0 - e.reshape(u0.shape))
            grad_fd = grad_fd.at[0, i].set((fp - fm) / (2 * eps))

        assert jnp.allclose(grad_ad[0, :5], grad_fd[0, :5], atol=1e-4, rtol=1e-3), (
            f"Mode {diff_mode}: AD grad doesn't match FD on Burgers"
        )


class TestCrossModeConsistency:
    """Test 2–4: Different modes produce the same gradient at convergence."""

    def test_implicit_modes_match_diffusion(self):
        """implicit, implicit_jvp, bounded, implicit_reduced, implicit_reduced_jvp
        all agree on linear PDE."""
        u0 = sin_1d()
        grads = {}
        for mode in [
            "implicit",
            "implicit_jvp",
            "bounded",
            "implicit_reduced",
            "implicit_reduced_jvp",
        ]:
            stepper = make_diffusion_stepper(diff_mode=mode)
            g = jax.grad(lambda u, s=stepper: scalar_loss(s, u))(u0)
            grads[mode] = g

        ref = grads["implicit"]
        for mode, g in grads.items():
            assert jnp.allclose(ref, g, atol=1e-6), f"Mode {mode} differs from implicit"

    def test_implicit_vs_implicit_jvp_burgers(self):
        """implicit and implicit_jvp give the same VJP on nonlinear PDE."""
        u0 = 0.1 * sin_1d()
        g1 = jax.grad(lambda u: scalar_loss(make_burgers_stepper("implicit"), u))(u0)
        g2 = jax.grad(lambda u: scalar_loss(make_burgers_stepper("implicit_jvp"), u))(
            u0
        )
        assert jnp.allclose(g1, g2, atol=1e-6)

    def test_jvp_explicit(self):
        """JVP works for implicit_jvp and bounded."""
        u0 = sin_1d()
        v = jnp.ones_like(u0)
        for mode in ["implicit_jvp", "bounded"]:
            stepper = make_diffusion_stepper(diff_mode=mode)
            primals, tangents = jax.jvp(stepper, (u0,), (v,))
            assert primals.shape == u0.shape
            assert tangents.shape == u0.shape
            assert jnp.all(jnp.isfinite(tangents))


# ─── Group 2: Mode-specific properties ───


class TestModeSpecificProperties:
    def test_linear_pde_reduced_matches_full(self):
        """Test 6: On linear PDE, implicit_reduced == implicit exactly."""
        u0 = sin_1d()
        g_full = jax.grad(lambda u: scalar_loss(make_diffusion_stepper("implicit"), u))(
            u0
        )
        g_reduced = jax.grad(
            lambda u: scalar_loss(make_diffusion_stepper("implicit_reduced"), u)
        )(u0)
        assert jnp.allclose(g_full, g_reduced, atol=1e-8)

    def test_nonlinear_pde_reduced_diverges_from_full(self):
        """Test 7: On nonlinear PDE, implicit_reduced != implicit."""
        u0 = 0.5 * sin_1d()  # Larger amplitude to trigger nonlinearity
        g_full = jax.grad(lambda u: scalar_loss(make_burgers_stepper("implicit"), u))(
            u0
        )
        g_reduced = jax.grad(
            lambda u: scalar_loss(make_burgers_stepper("implicit_reduced"), u)
        )(u0)
        # They should differ (not be identical)
        diff = jnp.max(jnp.abs(g_full - g_reduced))
        assert diff > 1e-6, (
            f"Expected divergence between full and reduced IFT on nonlinear PDE, "
            f"got max diff = {diff}"
        )

    def test_picard_vs_newton_implicit_diffusion(self):
        """Test 8: Picard and Newton give same gradient on linear PDE
        (IFT is solver-independent at convergence)."""
        u0 = sin_1d()

        # Picard
        stepper_picard = make_diffusion_stepper(diff_mode="implicit")
        g_picard = jax.grad(lambda u: scalar_loss(stepper_picard, u))(u0)

        # Newton
        derivatives = CollocatedDerivatives(1, N, DOMAIN_EXTENT)
        rhs = DiffusionRHS(derivatives=derivatives, diffusivity=0.01)
        residuum = ThetaResiduum(rhs=rhs, theta=0.5, dt=0.01)
        solver = Newton(linear_solver=CG(), maxiter=1, tol=1e-5, diff_mode="implicit")
        stepper_newton = Stepper(residuum=residuum, solver=solver)
        g_newton = jax.grad(lambda u: scalar_loss(stepper_newton, u))(u0)

        assert jnp.allclose(g_picard, g_newton, atol=1e-6)

    def test_detach_zero_gradient(self):
        """Test 9: detach mode gives zero gradient."""
        stepper = make_diffusion_stepper(diff_mode="detach")
        u0 = sin_1d()
        g = jax.grad(lambda u: scalar_loss(stepper, u))(u0)
        assert jnp.allclose(g, 0.0)

    def test_lax_jvp_works(self):
        """Test 11: lax mode supports JVP."""
        stepper = make_diffusion_stepper(diff_mode="lax")
        u0 = sin_1d()
        v = jnp.ones_like(u0)
        primals, tangents = jax.jvp(stepper, (u0,), (v,))
        assert jnp.all(jnp.isfinite(tangents))

    def test_checkpointed_vjp_works(self):
        """Test 10: checkpointed mode supports VJP."""
        stepper = make_diffusion_stepper(diff_mode="checkpointed")
        u0 = sin_1d()
        g = jax.grad(lambda u: scalar_loss(stepper, u))(u0)
        assert jnp.all(jnp.isfinite(g))
        assert not jnp.allclose(g, 0.0)

    def test_reduced_on_newton_raises(self):
        """Test 21: implicit_reduced on Newton raises ValueError."""
        with pytest.raises(ValueError, match="only supported by Picard"):
            derivatives = CollocatedDerivatives(1, N, DOMAIN_EXTENT)
            rhs = DiffusionRHS(derivatives=derivatives, diffusivity=0.01)
            residuum = ThetaResiduum(rhs=rhs, theta=0.5, dt=0.01)
            solver = Newton(linear_solver=CG(), diff_mode="implicit_reduced")
            solver(residuum, sin_1d())


# ─── Group 3: Parameter gradients ───


class TestParameterGradients:
    def test_grad_wrt_dt(self):
        """Test 12: Differentiate w.r.t. dt through the stepper."""
        derivatives = CollocatedDerivatives(1, N, DOMAIN_EXTENT)
        rhs = DiffusionRHS(derivatives=derivatives, diffusivity=0.01)
        u0 = sin_1d()

        def loss(dt):
            residuum = ThetaResiduum(rhs=rhs, theta=0.5, dt=dt)
            solver = Picard(
                linear_solver=CG(), maxiter=1, tol=1e-5, diff_mode="implicit"
            )
            stepper = Stepper(residuum=residuum, solver=solver)
            return jnp.sum(stepper(u0) ** 2)

        g = jax.grad(loss)(0.01)
        assert jnp.isfinite(g)
        assert g != 0.0

    def test_grad_wrt_diffusivity(self):
        """Test 12: Differentiate w.r.t. diffusivity."""
        derivatives = CollocatedDerivatives(1, N, DOMAIN_EXTENT)
        u0 = sin_1d()

        def loss(nu):
            rhs = DiffusionRHS(derivatives=derivatives, diffusivity=nu)
            residuum = ThetaResiduum(rhs=rhs, theta=0.5, dt=0.01)
            solver = Picard(
                linear_solver=CG(), maxiter=1, tol=1e-5, diff_mode="implicit"
            )
            stepper = Stepper(residuum=residuum, solver=solver)
            return jnp.sum(stepper(u0) ** 2)

        g = jax.grad(loss)(0.01)
        assert jnp.isfinite(g)
        assert g != 0.0

    def test_grad_neural_rhs(self):
        """Test 13: Gradient flows through to neural network weights in RHS."""
        from picardax._rhs import RHS

        class NeuralDiffusionRHS(RHS):
            derivatives: CollocatedDerivatives
            log_diffusivity: jnp.ndarray  # learnable parameter

            def linearized_operator(self, u, u_linearized):
                nu = jnp.exp(self.log_diffusivity)
                return nu * self.derivatives.laplacian(u)

        derivatives = CollocatedDerivatives(1, N, DOMAIN_EXTENT)
        rhs = NeuralDiffusionRHS(
            derivatives=derivatives,
            log_diffusivity=jnp.log(jnp.array(0.01)),
        )
        residuum = ThetaResiduum(rhs=rhs, theta=0.5, dt=0.01)
        solver = Picard(linear_solver=CG(), maxiter=1, tol=1e-5, diff_mode="implicit")
        stepper = Stepper(residuum=residuum, solver=solver)
        u0 = sin_1d()

        @eqx.filter_grad
        def grad_loss(stepper):
            return jnp.sum(stepper(u0) ** 2)

        grads = grad_loss(stepper)
        # Extract the gradient w.r.t. log_diffusivity
        g_log_nu = grads.residuum.rhs.log_diffusivity
        assert jnp.isfinite(g_log_nu)
        assert g_log_nu != 0.0


# ─── Group 4: Initial guess interaction ───


class TestInitialGuessInteraction:
    def test_ift_ignores_stop_gradient_setting(self):
        """Test 14: IFT modes give same gradient regardless of
        stop_gradient_on_initial_guess."""
        u0 = sin_1d()

        def make(stop_grad):
            derivatives = CollocatedDerivatives(1, N, DOMAIN_EXTENT)
            rhs = DiffusionRHS(derivatives=derivatives, diffusivity=0.01)
            residuum = ThetaResiduum(rhs=rhs, theta=0.5, dt=0.01)
            solver = Picard(
                linear_solver=CG(),
                maxiter=1,
                tol=1e-5,
                diff_mode="implicit",
                stop_gradient_on_initial_guess=stop_grad,
            )
            return Stepper(residuum=residuum, solver=solver)

        g_true = jax.grad(lambda u: scalar_loss(make(True), u))(u0)
        g_false = jax.grad(lambda u: scalar_loss(make(False), u))(u0)
        assert jnp.allclose(g_true, g_false, atol=1e-10)

    def test_iterpath_depends_on_stop_gradient(self):
        """Test 15: bounded mode gives different gradients when
        stop_gradient_on_initial_guess changes.

        Uses maxiter=1 so the initial guess directly affects the Picard
        linearization point, making the gradient sensitive to stop_gradient.
        """
        u0 = 0.5 * sin_1d()  # Larger amplitude for stronger nonlinearity

        def make(stop_grad):
            derivatives = CollocatedDerivatives(1, N, DOMAIN_EXTENT)
            rhs = BurgersRHS(
                derivatives=derivatives, diffusivity=0.01, convection_scale=1.0
            )
            residuum = ThetaResiduum(rhs=rhs, theta=0.5, dt=0.01)
            solver = Picard(
                linear_solver=GMRES(tol=1e-10),
                maxiter=1,  # Single iteration so initial guess path dominates
                tol=1e-15,
                throw=False,
                diff_mode="bounded",
                initial_from_prev=True,
                stop_gradient_on_initial_guess=stop_grad,
            )
            return Stepper(residuum=residuum, solver=solver)

        g_true = jax.grad(lambda u: scalar_loss(make(True), u))(u0)
        g_false = jax.grad(lambda u: scalar_loss(make(False), u))(u0)
        diff = jnp.max(jnp.abs(g_true - g_false))
        assert diff > 1e-10, f"Expected different gradients, got max diff = {diff}"


# ─── Group 5: Composition and edge cases ───


class TestComposition:
    @pytest.mark.parametrize(
        "diff_mode", ["implicit", "implicit_jvp", "bounded", "checkpointed"]
    )
    def test_multi_step_rollout(self, diff_mode):
        """Test 16: jax.grad through jax.lax.scan rollout."""
        stepper = make_diffusion_stepper(diff_mode=diff_mode)
        u0 = sin_1d()

        def rollout_loss(u):
            def step(carry, _):
                return stepper(carry), None

            u_final, _ = jax.lax.scan(step, u, None, length=3)
            return jnp.sum(u_final**2)

        g = jax.grad(rollout_loss)(u0)
        assert jnp.all(jnp.isfinite(g))
        assert not jnp.allclose(g, 0.0)

    def test_vmap_grad(self):
        """Test 17: vmap(grad(loss)) works."""
        stepper = make_diffusion_stepper(diff_mode="implicit")
        u0 = sin_1d()
        batch = jnp.stack([u0, 2 * u0, 0.5 * u0])  # (3, 1, N)

        @jax.vmap
        @jax.grad
        def batched_grad(u):
            return scalar_loss(stepper, u)

        grads = batched_grad(batch)
        assert grads.shape == batch.shape
        assert jnp.all(jnp.isfinite(grads))

    def test_non_convergence_finite_gradient(self):
        """Test 19: throw=False + implicit with small maxiter → finite gradient."""
        derivatives = CollocatedDerivatives(1, N, DOMAIN_EXTENT)
        rhs = BurgersRHS(
            derivatives=derivatives, diffusivity=0.01, convection_scale=1.0
        )
        residuum = ThetaResiduum(rhs=rhs, theta=0.5, dt=0.01)
        solver = Picard(
            linear_solver=GMRES(),
            maxiter=2,
            tol=1e-15,
            throw=False,
            diff_mode="implicit",
        )
        stepper = Stepper(residuum=residuum, solver=solver)
        u0 = 0.1 * sin_1d()

        g = jax.grad(lambda u: scalar_loss(stepper, u))(u0)
        assert jnp.all(jnp.isfinite(g))
