import equinox as eqx
import jax
import jax.numpy as jnp
import pytest

from picardax._linear_solver import (
    CG,
    GMRES,
    BiCGStab,
    LinearSolver,
)
from picardax._tree import tree_norm

ALL_SOLVERS = [CG, GMRES, BiCGStab]
ALL_SOLVER_IDS = ["CG", "GMRES", "BiCGStab"]


# ─── Base class tests ───


class TestLinearSolverBase:
    def test_is_abstract(self):
        with pytest.raises(TypeError):
            LinearSolver()

    def test_default_throw_is_true(self):
        solver = CG()
        assert solver.throw is True

    def test_residual_computation(self, identity_system):
        lin_fun, b, _ = identity_system
        solver = CG(throw=False)
        x = jnp.zeros_like(b)
        r = solver.residual(lin_fun, x, b)
        # r = Ax - b = 0 - b = -b
        assert jnp.allclose(r, -b)

    def test_residual_at_solution(self, spd_system):
        lin_fun, b, x_true = spd_system
        solver = CG(throw=False)
        r = solver.residual(lin_fun, x_true, b)
        assert tree_norm(r) < 1e-4

    def test_base_diagnostics_raise(self, identity_system):
        lin_fun, b, _ = identity_system
        solver = CG()
        # JAXIterativeLinearSolver overrides these, but without
        # unroll_hack they should raise NotImplementedError
        with pytest.raises(NotImplementedError):
            solver.get_all_iterates(lin_fun, b)
        with pytest.raises(NotImplementedError):
            solver.get_error_iterates(lin_fun, b)


# ─── Solver correctness tests ───


class TestSolverCorrectness:
    @pytest.mark.parametrize("SolverClass", ALL_SOLVERS, ids=ALL_SOLVER_IDS)
    def test_solves_identity_system(self, identity_system, SolverClass):
        lin_fun, b, x_true = identity_system
        solver = SolverClass(throw=False)
        x = solver(lin_fun, b)
        assert jnp.allclose(x, x_true, atol=1e-5)

    @pytest.mark.parametrize("SolverClass", ALL_SOLVERS, ids=ALL_SOLVER_IDS)
    def test_solves_spd_system(self, spd_system, SolverClass):
        lin_fun, b, x_true = spd_system
        solver = SolverClass(throw=False)
        x = solver(lin_fun, b)
        assert jnp.allclose(x, x_true, atol=1e-4)

    @pytest.mark.parametrize(
        "SolverClass", [GMRES, BiCGStab], ids=["GMRES", "BiCGStab"]
    )
    def test_solves_general_system(self, general_system, SolverClass):
        lin_fun, b, x_true = general_system
        solver = SolverClass(throw=False)
        x = solver(lin_fun, b)
        assert jnp.allclose(x, x_true, atol=1e-4)

    @pytest.mark.parametrize("SolverClass", ALL_SOLVERS, ids=ALL_SOLVER_IDS)
    def test_residual_within_tolerance(self, spd_system, SolverClass):
        lin_fun, b, _ = spd_system
        solver = SolverClass(throw=False, tol=1e-5)
        x = solver(lin_fun, b)
        r = solver.residual(lin_fun, x, b)
        rel_residual = tree_norm(r) / tree_norm(b)
        assert rel_residual < 1e-4

    @pytest.mark.parametrize("SolverClass", ALL_SOLVERS, ids=ALL_SOLVER_IDS)
    def test_single_element_system(self, precision, SolverClass):
        def lin_fun(x):
            return 3.0 * x

        b = jnp.array([6.0], dtype=precision)
        solver = SolverClass(throw=False)
        x = solver(lin_fun, b)
        assert jnp.allclose(x, jnp.array([2.0], dtype=precision), atol=1e-5)


# ─── Throw / convergence tests ───


class TestThrowBehavior:
    @pytest.mark.parametrize("SolverClass", ALL_SOLVERS, ids=ALL_SOLVER_IDS)
    def test_throw_true_converged_no_error(self, spd_system, SolverClass):
        lin_fun, b, _ = spd_system
        solver = SolverClass(throw=True)
        # Should not raise
        x = solver(lin_fun, b)
        assert x.shape == b.shape

    @pytest.mark.parametrize("SolverClass", ALL_SOLVERS, ids=ALL_SOLVER_IDS)
    def test_throw_true_not_converged_raises(self, spd_system, SolverClass):
        lin_fun, b, _ = spd_system
        solver = SolverClass(throw=True, maxiter=1, tol=1e-15)
        with pytest.raises(Exception, match="Linear solver"):
            solver(lin_fun, b)

    @pytest.mark.parametrize("SolverClass", ALL_SOLVERS, ids=ALL_SOLVER_IDS)
    def test_throw_true_not_converged_raises_under_jit(self, spd_system, SolverClass):
        lin_fun, b, _ = spd_system
        solver = SolverClass(throw=True, maxiter=1, tol=1e-15)

        @eqx.filter_jit
        def solve(b):
            return solver(lin_fun, b)

        with pytest.raises(eqx.EquinoxRuntimeError, match="Linear solver"):
            solve(b)

    @pytest.mark.parametrize("SolverClass", ALL_SOLVERS, ids=ALL_SOLVER_IDS)
    def test_throw_false_not_converged_returns_result(self, spd_system, SolverClass):
        lin_fun, b, _ = spd_system
        solver = SolverClass(throw=False, maxiter=1)
        x = solver(lin_fun, b)
        assert x.shape == b.shape
        assert x.dtype == b.dtype

    def test_convergence_uses_relative_tolerance(self, precision):
        """A system with large ||b|| should pass relative check even
        if absolute residual exceeds tol."""
        scale = jnp.array(1e6, dtype=precision)

        def lin_fun(x):
            return x

        b = scale * jnp.ones(5, dtype=precision)
        solver = CG(throw=True, tol=1e-5)
        # Identity system converges exactly, so this should pass
        x = solver(lin_fun, b)
        assert jnp.allclose(x, b)


# ─── Default parameter tests ───


class TestDefaultParameters:
    def test_jax_iterative_defaults(self):
        solver = CG()
        assert solver.tol == 1e-5
        assert solver.maxiter == 1000
        assert solver.unroll_hack is False
        assert solver.unroll_hack_chunk_size == 100
        assert solver.throw is True

    def test_custom_parameters(self):
        solver = CG(tol=1e-8, maxiter=500, throw=False)
        assert solver.tol == 1e-8
        assert solver.maxiter == 500
        assert solver.throw is False


# ─── Diagnostic tests ───


class TestDiagnosticsWithoutUnrollHack:
    @pytest.mark.parametrize("SolverClass", ALL_SOLVERS, ids=ALL_SOLVER_IDS)
    def test_get_all_iterates_raises(self, identity_system, SolverClass):
        lin_fun, b, _ = identity_system
        solver = SolverClass(unroll_hack=False)
        with pytest.raises(NotImplementedError):
            solver.get_all_iterates(lin_fun, b)

    @pytest.mark.parametrize("SolverClass", ALL_SOLVERS, ids=ALL_SOLVER_IDS)
    def test_get_error_iterates_raises(self, identity_system, SolverClass):
        lin_fun, b, _ = identity_system
        solver = SolverClass(unroll_hack=False)
        with pytest.raises(NotImplementedError):
            solver.get_error_iterates(lin_fun, b)

    @pytest.mark.parametrize("SolverClass", ALL_SOLVERS, ids=ALL_SOLVER_IDS)
    def test_diagnose_raises(self, identity_system, SolverClass):
        """diagnose calls get_error_iterates internally."""
        lin_fun, b, _ = identity_system
        solver = SolverClass(unroll_hack=False)
        with pytest.raises(NotImplementedError):
            solver.diagnose(lin_fun, b)


class TestDiagnosticsWithUnrollHack:
    @pytest.mark.parametrize("SolverClass", ALL_SOLVERS, ids=ALL_SOLVER_IDS)
    def test_get_all_iterates_shape_no_init(self, spd_system, SolverClass):
        lin_fun, b, _ = spd_system
        maxiter = 10
        solver = SolverClass(unroll_hack=True, maxiter=maxiter, throw=False)
        iterates = solver.get_all_iterates(lin_fun, b)
        assert iterates.shape == (maxiter, *b.shape)

    @pytest.mark.parametrize("SolverClass", ALL_SOLVERS, ids=ALL_SOLVER_IDS)
    def test_get_all_iterates_shape_with_init(self, spd_system, SolverClass):
        lin_fun, b, _ = spd_system
        maxiter = 10
        solver = SolverClass(unroll_hack=True, maxiter=maxiter, throw=False)
        iterates = solver.get_all_iterates(lin_fun, b, include_init=True)
        assert iterates.shape == (maxiter + 1, *b.shape)

    @pytest.mark.parametrize("SolverClass", ALL_SOLVERS, ids=ALL_SOLVER_IDS)
    def test_get_all_iterates_last_matches_call(self, spd_system, SolverClass):
        """The last iterate from unroll_hack should approximate __call__.

        We use a loose tolerance because jax.lax.map passes a traced
        (dynamic) maxiter to the solver, while __call__ uses a static
        Python int.  JAX solvers can compile differently for traced vs
        static loop bounds, producing small numerical differences —
        especially for less stable algorithms like BiCGStab in float32.
        """
        lin_fun, b, _ = spd_system
        maxiter = 15
        solver = SolverClass(unroll_hack=True, maxiter=maxiter, throw=False)
        iterates = solver.get_all_iterates(lin_fun, b)
        x_direct = solver(lin_fun, b)
        assert jnp.allclose(iterates[-1], x_direct, atol=1e-3)

    def test_get_all_iterates_convergence_trend(self, spd_system):
        lin_fun, b, x_true = spd_system
        solver = CG(unroll_hack=True, maxiter=20, throw=False)
        iterates = solver.get_all_iterates(lin_fun, b)
        errors = jnp.array([jnp.linalg.norm(it - x_true) for it in iterates])
        # Later iterates should generally have smaller error
        assert errors[-1] < errors[0]

    @pytest.mark.parametrize("SolverClass", ALL_SOLVERS, ids=ALL_SOLVER_IDS)
    def test_get_error_iterates_shape_no_init(self, spd_system, SolverClass):
        lin_fun, b, _ = spd_system
        maxiter = 10
        solver = SolverClass(unroll_hack=True, maxiter=maxiter, throw=False)
        errors = solver.get_error_iterates(lin_fun, b)
        assert errors.shape == (maxiter,)

    @pytest.mark.parametrize("SolverClass", ALL_SOLVERS, ids=ALL_SOLVER_IDS)
    def test_get_error_iterates_shape_with_init(self, spd_system, SolverClass):
        lin_fun, b, _ = spd_system
        maxiter = 10
        solver = SolverClass(unroll_hack=True, maxiter=maxiter, throw=False)
        errors = solver.get_error_iterates(lin_fun, b, include_init=True)
        assert errors.shape == (maxiter + 1,)

    @pytest.mark.parametrize("SolverClass", ALL_SOLVERS, ids=ALL_SOLVER_IDS)
    def test_get_error_iterates_are_scalars(self, spd_system, SolverClass):
        lin_fun, b, _ = spd_system
        solver = SolverClass(unroll_hack=True, maxiter=5, throw=False)
        errors = solver.get_error_iterates(lin_fun, b)
        assert errors.ndim == 1

    def test_get_error_iterates_match_manual(self, spd_system):
        """Error iterates should match manually computed relative
        residual norms from get_all_iterates."""
        lin_fun, b, _ = spd_system
        solver = CG(unroll_hack=True, maxiter=10, throw=False)
        iterates = solver.get_all_iterates(lin_fun, b)
        errors = solver.get_error_iterates(lin_fun, b)
        b_norm = tree_norm(b)
        for i in range(len(errors)):
            r = solver.residual(lin_fun, iterates[i], b)
            expected = tree_norm(r) / b_norm
            assert jnp.allclose(errors[i], expected, atol=1e-4)

    def test_get_error_iterates_decreasing(self, spd_system):
        lin_fun, b, _ = spd_system
        solver = CG(unroll_hack=True, maxiter=20, throw=False)
        errors = solver.get_error_iterates(lin_fun, b)
        # Last error should be much smaller than first
        assert errors[-1] < errors[0]

    @pytest.mark.parametrize("SolverClass", ALL_SOLVERS, ids=ALL_SOLVER_IDS)
    def test_diagnose_converged(self, spd_system, SolverClass):
        lin_fun, b, _ = spd_system
        solver = SolverClass(unroll_hack=True, maxiter=50, tol=1e-3, throw=False)
        n_iters = solver.diagnose(lin_fun, b)
        assert n_iters >= 0
        assert n_iters <= 50

    @pytest.mark.parametrize("SolverClass", ALL_SOLVERS, ids=ALL_SOLVER_IDS)
    def test_diagnose_not_converged_returns_minus_one(self, spd_system, SolverClass):
        lin_fun, b, _ = spd_system
        solver = SolverClass(unroll_hack=True, maxiter=1, tol=1e-15, throw=False)
        n_iters = solver.diagnose(lin_fun, b)
        assert n_iters == -1

    def test_diagnose_identity_system(self, identity_system):
        lin_fun, b, _ = identity_system
        solver = CG(unroll_hack=True, maxiter=5, tol=1e-5, throw=False)
        n_iters = solver.diagnose(lin_fun, b)
        # Identity system should converge very quickly
        assert 0 <= n_iters <= 2

    def test_chunk_size_does_not_affect_results(self, spd_system):
        lin_fun, b, _ = spd_system
        if b.dtype == jnp.float32:
            pytest.skip("f32 vectorisation reordering causes expected divergence")
        solver_small = CG(
            unroll_hack=True,
            maxiter=10,
            throw=False,
            unroll_hack_chunk_size=2,
        )
        solver_large = CG(
            unroll_hack=True,
            maxiter=10,
            throw=False,
            unroll_hack_chunk_size=10,
        )
        e1 = solver_small.get_error_iterates(lin_fun, b)
        e2 = solver_large.get_error_iterates(lin_fun, b)
        assert jnp.allclose(e1, e2)


# ─── JIT compatibility tests ───


class TestJITCompatibility:
    @pytest.mark.parametrize("SolverClass", ALL_SOLVERS, ids=ALL_SOLVER_IDS)
    def test_call_under_jit(self, spd_system, SolverClass):
        lin_fun, b, _ = spd_system
        solver = SolverClass(throw=False)
        x_eager = solver(lin_fun, b)

        @jax.jit
        def solve(b):
            return solver(lin_fun, b)

        x_jit = solve(b)
        assert jnp.allclose(x_eager, x_jit)

    @pytest.mark.parametrize("SolverClass", ALL_SOLVERS, ids=ALL_SOLVER_IDS)
    def test_solver_is_valid_pytree(self, SolverClass):
        solver = SolverClass(tol=1e-6, maxiter=100)
        leaves, treedef = jax.tree_util.tree_flatten(solver)
        solver_roundtrip = jax.tree_util.tree_unflatten(treedef, leaves)
        assert solver_roundtrip.tol == solver.tol
        assert solver_roundtrip.maxiter == solver.maxiter

    def test_diagnostics_under_jit(self, spd_system):
        lin_fun, b, _ = spd_system
        solver = CG(unroll_hack=True, maxiter=10, throw=False)

        @jax.jit
        def get_errors(b):
            return solver.get_error_iterates(lin_fun, b)

        errors = get_errors(b)
        assert errors.shape == (10,)


# ─── Edge cases ───


class TestEdgeCases:
    @pytest.mark.parametrize("SolverClass", ALL_SOLVERS, ids=ALL_SOLVER_IDS)
    def test_zero_rhs(self, precision, SolverClass):
        def lin_fun(x):
            return x

        b = jnp.zeros(5, dtype=precision)
        solver = SolverClass(throw=False)
        x = solver(lin_fun, b)
        assert jnp.allclose(x, jnp.zeros(5, dtype=precision))

    def test_very_large_tol(self, spd_system):
        """With huge tolerance, even maxiter=1 should 'converge'."""
        lin_fun, b, _ = spd_system
        solver = CG(throw=True, maxiter=1, tol=1e10)
        # Should not raise
        x = solver(lin_fun, b)
        assert x.shape == b.shape
