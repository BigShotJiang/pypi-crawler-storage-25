import jax
import jax.numpy as jnp
import pytest

from picardax.periodic._derivatives import CollocatedDerivatives

jax.config.update("jax_enable_x64", True)

# ─── Helpers ───


def make_grid(num_spatial_dims, num_points, domain_extent):
    """Return coordinate arrays for a periodic grid."""
    x1d = jnp.linspace(0, domain_extent, num_points, endpoint=False)
    if num_spatial_dims == 1:
        return (x1d,)
    elif num_spatial_dims == 2:
        return jnp.meshgrid(x1d, x1d, indexing="ij")
    elif num_spatial_dims == 3:
        return jnp.meshgrid(x1d, x1d, x1d, indexing="ij")


def sin_field(grids, k, domain_extent):
    """sin(2*pi*k*x / L) along each dim, summed. Shape: (1, *spatial)."""
    result = sum(jnp.sin(2 * jnp.pi * k * g / domain_extent) for g in grids)
    return result[None]  # add channel dim


def cos_field(grids, k, domain_extent):
    """cos(2*pi*k*x / L) along each dim, summed. Shape: (1, *spatial)."""
    result = sum(jnp.cos(2 * jnp.pi * k * g / domain_extent) for g in grids)
    return result[None]


# ─── Fixtures ───


@pytest.fixture(params=[1, 2], ids=["1D", "2D"])
def num_spatial_dims(request):
    return request.param


DOMAIN_EXTENT = 2 * jnp.pi
WAVENUMBER = 1


# ─── Basic derivative tests (analytical) ───


class TestDerivativeAnalytical:
    """d/dx sin(kx) = k cos(kx), Laplacian eigenvalue -k^2, etc."""

    def test_first_derivative_sin(self, num_spatial_dims):
        N = 64
        deriv = CollocatedDerivatives(num_spatial_dims, N, DOMAIN_EXTENT)
        grids = make_grid(num_spatial_dims, N, DOMAIN_EXTENT)
        u = sin_field(grids, WAVENUMBER, DOMAIN_EXTENT)

        # Test derivative along dim=0
        du = deriv.derivative(u, dim=0, derivative_order=1)
        k_eff = 2 * jnp.pi * WAVENUMBER / DOMAIN_EXTENT
        expected = k_eff * jnp.cos(k_eff * grids[0])[None]
        assert jnp.allclose(du, expected, atol=0.05)

    def test_laplacian_sin(self, num_spatial_dims):
        N = 64
        deriv = CollocatedDerivatives(num_spatial_dims, N, DOMAIN_EXTENT)
        grids = make_grid(num_spatial_dims, N, DOMAIN_EXTENT)
        u = sin_field(grids, WAVENUMBER, DOMAIN_EXTENT)

        lap = deriv.laplacian(u)
        k_eff = 2 * jnp.pi * WAVENUMBER / DOMAIN_EXTENT
        # Laplacian of sum_i sin(k*x_i) = -k^2 * sum_i sin(k*x_i)
        expected = -(k_eff**2) * u[0]
        assert jnp.allclose(lap, expected, atol=0.1)

    def test_double_laplacian_sin(self, num_spatial_dims):
        N = 64
        deriv = CollocatedDerivatives(num_spatial_dims, N, DOMAIN_EXTENT)
        grids = make_grid(num_spatial_dims, N, DOMAIN_EXTENT)
        u = sin_field(grids, WAVENUMBER, DOMAIN_EXTENT)

        dlap = deriv.double_laplacian(u)
        k_eff = 2 * jnp.pi * WAVENUMBER / DOMAIN_EXTENT
        # 4th derivative of sin(kx) = k^4 sin(kx), summed over dims
        expected = k_eff**4 * u[0]
        assert jnp.allclose(dlap, expected, atol=0.5)

    def test_derivative_of_constant_is_zero(self, num_spatial_dims):
        N = 32
        deriv = CollocatedDerivatives(num_spatial_dims, N, DOMAIN_EXTENT)
        u = jnp.ones((1,) + (N,) * num_spatial_dims)
        du = deriv.derivative(u, dim=0, derivative_order=1)
        assert jnp.allclose(du, 0.0, atol=1e-12)

    def test_laplacian_of_constant_is_zero(self, num_spatial_dims):
        N = 32
        deriv = CollocatedDerivatives(num_spatial_dims, N, DOMAIN_EXTENT)
        u = jnp.ones((1,) + (N,) * num_spatial_dims)
        lap = deriv.laplacian(u)
        assert jnp.allclose(lap, 0.0, atol=1e-12)


# ─── Gradient shape tests ───


class TestGradientShape:
    def test_gradient_shape_1d(self):
        N = 32
        deriv = CollocatedDerivatives(1, N, DOMAIN_EXTENT)
        u = jnp.ones((1, N))
        grad = deriv.gradient(u)
        # 1D: (C, D, N) = (1, 1, N)
        assert grad.shape == (1, 1, N)

    def test_gradient_shape_2d(self):
        N = 16
        deriv = CollocatedDerivatives(2, N, DOMAIN_EXTENT)
        u = jnp.ones((1, N, N))
        grad = deriv.gradient(u)
        # 2D: (C, D, N, N) = (1, 2, N, N)
        assert grad.shape == (1, 2, N, N)

    def test_gradient_shape_3d(self):
        N = 8
        deriv = CollocatedDerivatives(3, N, DOMAIN_EXTENT)
        u = jnp.ones((1, N, N, N))
        grad = deriv.gradient(u)
        # 3D: (C, D, N, N, N) = (1, 3, N, N, N)
        assert grad.shape == (1, 3, N, N, N)


# ─── Spatial convergence order ───


class TestSpatialConvergence:
    def test_first_derivative_convergence_centered_2nd(self):
        """Error decreases at O(h^2) for centered 2nd-order."""
        Ns = [32, 64, 128, 256]
        errors = []
        k_eff = 2 * jnp.pi * WAVENUMBER / DOMAIN_EXTENT
        for N in Ns:
            deriv = CollocatedDerivatives(1, N, DOMAIN_EXTENT)
            grids = make_grid(1, N, DOMAIN_EXTENT)
            u = sin_field(grids, WAVENUMBER, DOMAIN_EXTENT)
            du = deriv.derivative(u, dim=0, derivative_order=1)
            expected = k_eff * jnp.cos(k_eff * grids[0])[None]
            errors.append(float(jnp.max(jnp.abs(du - expected))))

        # Check convergence rate: error ratio should be ~4 for O(h^2)
        for i in range(len(errors) - 1):
            ratio = errors[i] / errors[i + 1]
            assert ratio > 3.5, f"Expected ~4x reduction, got {ratio:.2f}"

    def test_laplacian_convergence_centered_2nd(self):
        """Laplacian error decreases at O(h^2) for centered 2nd-order."""
        Ns = [32, 64, 128, 256]
        errors = []
        k_eff = 2 * jnp.pi * WAVENUMBER / DOMAIN_EXTENT
        for N in Ns:
            deriv = CollocatedDerivatives(1, N, DOMAIN_EXTENT)
            grids = make_grid(1, N, DOMAIN_EXTENT)
            u = sin_field(grids, WAVENUMBER, DOMAIN_EXTENT)
            lap = deriv.laplacian(u)
            expected = -(k_eff**2) * u[0]
            errors.append(float(jnp.max(jnp.abs(lap - expected))))

        for i in range(len(errors) - 1):
            ratio = errors[i] / errors[i + 1]
            assert ratio > 3.5, f"Expected ~4x reduction, got {ratio:.2f}"


# ─── Upwind scheme tests ───


class TestUpwind:
    def test_positive_wind_uses_backward_diff(self):
        """Constant positive wind should give backward difference."""
        N = 64
        deriv = CollocatedDerivatives(1, N, DOMAIN_EXTENT)
        grids = make_grid(1, N, DOMAIN_EXTENT)
        u = sin_field(grids, WAVENUMBER, DOMAIN_EXTENT)
        winds = jnp.ones((1, N))  # positive wind

        upwind = deriv.scaled_upwind_derivative(u, winds, zero_fixed=False)
        backward = deriv.derivative(
            u, dim=0, derivative_order=1, method="backward", method_order=1
        )
        assert jnp.allclose(upwind, backward, atol=1e-12)

    def test_negative_wind_uses_forward_diff(self):
        """Constant negative wind should give forward difference."""
        N = 64
        deriv = CollocatedDerivatives(1, N, DOMAIN_EXTENT)
        grids = make_grid(1, N, DOMAIN_EXTENT)
        u = sin_field(grids, WAVENUMBER, DOMAIN_EXTENT)
        winds = -jnp.ones((1, N))  # negative wind

        upwind = deriv.scaled_upwind_derivative(u, winds, zero_fixed=False)
        forward = -deriv.derivative(
            u, dim=0, derivative_order=1, method="forward", method_order=1
        )
        assert jnp.allclose(upwind, forward, atol=1e-12)

    def test_upwind_of_constant_is_zero(self):
        N = 32
        deriv = CollocatedDerivatives(1, N, DOMAIN_EXTENT)
        u = 5.0 * jnp.ones((1, N))
        winds = jnp.ones((1, N))
        result = deriv.scaled_upwind_derivative(u, winds)
        assert jnp.allclose(result, 0.0, atol=1e-12)


# ─── Wind splitting tests ───


class TestWindSplitting:
    def test_positive_wind_clips_negatives(self):
        N = 8
        deriv = CollocatedDerivatives(1, N, DOMAIN_EXTENT)
        winds = jnp.array([[-3.0, -1.0, 0.0, 1.0, 2.0, 3.0, -2.0, -1.0]])
        pos = deriv.get_positive_wind(winds, dim=0, zero_fixed=False)
        assert jnp.all(pos >= 0.0)

    def test_negative_wind_clips_positives(self):
        N = 8
        deriv = CollocatedDerivatives(1, N, DOMAIN_EXTENT)
        winds = jnp.array([[-3.0, -1.0, 0.0, 1.0, 2.0, 3.0, -2.0, -1.0]])
        neg = deriv.get_negative_wind(winds, dim=0, zero_fixed=False)
        assert jnp.all(neg <= 0.0)

    def test_all_positive_winds_pass_through(self):
        N = 4
        deriv = CollocatedDerivatives(1, N, DOMAIN_EXTENT)
        winds = jnp.array([[1.0, 2.0, 3.0, 4.0]])
        pos = deriv.get_positive_wind(winds, dim=0, zero_fixed=False)
        assert jnp.allclose(pos, winds)

    def test_all_negative_winds_pass_through(self):
        N = 4
        deriv = CollocatedDerivatives(1, N, DOMAIN_EXTENT)
        winds = jnp.array([[-1.0, -2.0, -3.0, -4.0]])
        neg = deriv.get_negative_wind(winds, dim=0, zero_fixed=False)
        assert jnp.allclose(neg, winds)


# ─── Neighbor / periodic wrapping ───


class TestGetNeighbor:
    def test_shift_wraps_periodically(self):
        N = 4
        deriv = CollocatedDerivatives(1, N, DOMAIN_EXTENT)
        u = jnp.array([[1.0, 2.0, 3.0, 4.0]])
        shifted = deriv.get_neighbor(u, dim=0, shift=1)
        expected = jnp.array([[2.0, 3.0, 4.0, 1.0]])
        assert jnp.allclose(shifted, expected)

    def test_shift_negative_wraps(self):
        N = 4
        deriv = CollocatedDerivatives(1, N, DOMAIN_EXTENT)
        u = jnp.array([[1.0, 2.0, 3.0, 4.0]])
        shifted = deriv.get_neighbor(u, dim=0, shift=-1)
        expected = jnp.array([[4.0, 1.0, 2.0, 3.0]])
        assert jnp.allclose(shifted, expected)

    def test_shift_zero_is_identity(self):
        N = 4
        deriv = CollocatedDerivatives(1, N, DOMAIN_EXTENT)
        u = jnp.array([[1.0, 2.0, 3.0, 4.0]])
        shifted = deriv.get_neighbor(u, dim=0, shift=0)
        assert jnp.allclose(shifted, u)


# ─── Gradient norm ───


class TestGradientNorm:
    def test_gradient_norm_positive(self, num_spatial_dims):
        N = 32
        deriv = CollocatedDerivatives(num_spatial_dims, N, DOMAIN_EXTENT)
        grids = make_grid(num_spatial_dims, N, DOMAIN_EXTENT)
        u = sin_field(grids, WAVENUMBER, DOMAIN_EXTENT)
        gn = deriv.gradient_norm(u)
        assert jnp.all(gn >= 0.0)

    def test_gradient_norm_of_constant_is_zero(self, num_spatial_dims):
        N = 32
        deriv = CollocatedDerivatives(num_spatial_dims, N, DOMAIN_EXTENT)
        u = jnp.ones((1,) + (N,) * num_spatial_dims)
        gn = deriv.gradient_norm(u)
        assert jnp.allclose(gn, 0.0, atol=1e-12)

    def test_gradient_norm_shape(self, num_spatial_dims):
        N = 16
        deriv = CollocatedDerivatives(num_spatial_dims, N, DOMAIN_EXTENT)
        u = jnp.ones((1,) + (N,) * num_spatial_dims)
        gn = deriv.gradient_norm(u)
        # Same shape as u (derivative axis summed out)
        assert gn.shape == u.shape


# ─── 2D double_laplacian correctness (biharmonic eigenvalue) ───


class TestDoubleLaplacian2D:
    def test_biharmonic_eigenvalue_product_mode(self):
        """For u = sin(kx)*sin(ky), Δ²u = (k²+k²)² u = 4k⁴ u.

        This validates that the biharmonic includes mixed cross-derivative
        terms (2·∂⁴u/∂x²∂y²). Without them, we'd get 2k⁴ instead of 4k⁴.
        """
        N = 64
        k_eff = 2 * jnp.pi * WAVENUMBER / DOMAIN_EXTENT
        deriv = CollocatedDerivatives(2, N, DOMAIN_EXTENT)
        x = jnp.linspace(0, DOMAIN_EXTENT, N, endpoint=False)
        X, Y = jnp.meshgrid(x, x, indexing="ij")
        u = (jnp.sin(k_eff * X) * jnp.sin(k_eff * Y))[None]  # (1, N, N)
        dlap = deriv.double_laplacian(u)
        # Biharmonic eigenvalue: (k^2 + k^2)^2 = 4*k^4
        expected = (k_eff**2 + k_eff**2) ** 2 * u
        assert jnp.allclose(dlap, expected, atol=0.5)
