import equinox as eqx
import jax
import jax.numpy as jnp
import pytest

from picardax.periodic.stepper import (
    Advection,
    Burgers,
    Diffusion,
    Dispersion,
    HyperDiffusion,
    KortewegDeVries,
    KuramotoSivashinsky,
)

jax.config.update("jax_enable_x64", True)

DOMAIN_EXTENT = 2 * jnp.pi


# ─── Helpers ───


def sin_1d(N, k=1):
    """sin(k*x) on [0, 2*pi), shape (1, N)."""
    x = jnp.linspace(0, DOMAIN_EXTENT, N, endpoint=False)
    return jnp.sin(k * x)[None]


def analytical_diffusion_1d(N, k, nu, dt):
    """Exact PDE solution after one step: exp(-k^2*nu*dt)*sin(kx)."""
    x = jnp.linspace(0, DOMAIN_EXTENT, N, endpoint=False)
    return (jnp.exp(-(k**2) * nu * dt) * jnp.sin(k * x))[None]


def semi_discrete_exact_1d(N, k, nu, T):
    """Exact semi-discrete solution for FD-discretized diffusion.

    Uses the FD eigenvalue lambda_h instead of -k^2, so comparing against
    this isolates the temporal error from spatial discretization error.
    """
    x = jnp.linspace(0, DOMAIN_EXTENT, N, endpoint=False)
    dx = DOMAIN_EXTENT / N
    lambda_h = -(4.0 / dx**2) * jnp.sin(jnp.pi * k / N) ** 2
    return (jnp.exp(nu * lambda_h * T) * jnp.sin(k * x))[None]


def run_n_steps(stepper, u0, n_steps):
    """Run stepper for n_steps using fori_loop (compiled)."""

    @jax.jit
    def _run(u0):
        def body(_, u):
            return stepper(u)

        return jax.lax.fori_loop(0, n_steps, body, u0)

    return _run(u0)


# ─── Diffusion: analytical solution ───


class TestDiffusionAnalytical:
    """One-step diffusion against the exact exponential decay."""

    @pytest.mark.parametrize("theta", [0.5, 1.0], ids=["CN", "IE"])
    def test_one_step_matches_analytical(self, theta):
        N, k, nu, dt = 64, 1, 0.01, 0.01
        stepper = Diffusion(1, DOMAIN_EXTENT, N, dt, diffusivity=nu, theta=theta)
        u0 = sin_1d(N, k)
        u1 = stepper(u0)
        expected = analytical_diffusion_1d(N, k, nu, dt)
        assert jnp.allclose(u1, expected, atol=1e-4)

    def test_multi_step_decays(self):
        N, k, nu, dt = 64, 1, 0.01, 0.01
        stepper = Diffusion(1, DOMAIN_EXTENT, N, dt, diffusivity=nu)
        u = sin_1d(N, k)
        amp_init = jnp.max(jnp.abs(u))
        for _ in range(10):
            u = stepper(u)
        amp_final = jnp.max(jnp.abs(u))
        assert amp_final < amp_init


# ─── Temporal convergence order ───


class TestTemporalConvergence:
    """Test temporal convergence using the semi-discrete exact solution.

    Comparing against the semi-discrete (FD eigenvalue) reference
    eliminates spatial discretization error, cleanly isolating the
    temporal error of the theta method.

    We use nu=10 so the temporal error is well above the linear solver
    tolerance floor (~1e-5).
    """

    def test_implicit_euler_is_first_order(self):
        """IE (theta=1): global error O(dt), ratio ~2 for halving dt."""
        N, k, nu, T = 64, 1, 10.0, 0.1
        u0 = sin_1d(N, k)
        u_ref = semi_discrete_exact_1d(N, k, nu, T)

        n_steps_list = [2, 4, 8]
        errors = []
        for n in n_steps_list:
            stepper = Diffusion(1, DOMAIN_EXTENT, N, T / n, diffusivity=nu, theta=1.0)
            u = run_n_steps(stepper, u0, n)
            errors.append(float(jnp.max(jnp.abs(u - u_ref))))

        for i in range(len(errors) - 1):
            ratio = errors[i] / errors[i + 1]
            assert ratio > 1.7, f"Expected ~2x reduction, got {ratio:.2f}"

    def test_crank_nicolson_is_second_order(self):
        """CN (theta=0.5): global error O(dt^2), ratio ~4 for halving dt."""
        N, k, nu, T = 64, 1, 10.0, 0.1
        u0 = sin_1d(N, k)
        u_ref = semi_discrete_exact_1d(N, k, nu, T)

        n_steps_list = [2, 4, 8]
        errors = []
        for n in n_steps_list:
            stepper = Diffusion(1, DOMAIN_EXTENT, N, T / n, diffusivity=nu, theta=0.5)
            u = run_n_steps(stepper, u0, n)
            errors.append(float(jnp.max(jnp.abs(u - u_ref))))

        for i in range(len(errors) - 1):
            ratio = errors[i] / errors[i + 1]
            assert ratio > 3.5, f"Expected ~4x reduction, got {ratio:.2f}"


# ─── Spatial convergence ───


class TestSpatialConvergence:
    def test_diffusion_spatial_convergence(self):
        """Fix tiny dt, vary N — check 2nd-order spatial convergence."""
        k, nu, dt = 1, 0.01, 1e-5  # tiny dt to isolate spatial error
        Ns = [16, 32, 64, 128]
        errors = []
        for N in Ns:
            stepper = Diffusion(1, DOMAIN_EXTENT, N, dt, diffusivity=nu, theta=0.5)
            u0 = sin_1d(N, k)
            u1 = stepper(u0)
            exact = analytical_diffusion_1d(N, k, nu, dt)
            errors.append(float(jnp.max(jnp.abs(u1 - exact))))

        for i in range(len(errors) - 1):
            ratio = errors[i] / errors[i + 1]
            assert ratio > 3.0, f"Expected ~4x reduction, got {ratio:.2f}"


# ─── Burgers with convection_scale=0 matches diffusion ───


class TestBurgersReducesToDiffusion:
    def test_zero_convection_matches_diffusion(self):
        N, k, nu, dt = 64, 1, 0.01, 0.01
        diff_stepper = Diffusion(1, DOMAIN_EXTENT, N, dt, diffusivity=nu)
        burg_stepper = Burgers(
            1, DOMAIN_EXTENT, N, dt, diffusivity=nu, convection_scale=0.0
        )
        u0 = sin_1d(N, k)
        u_diff = diff_stepper(u0)
        u_burg = burg_stepper(u0)
        assert jnp.allclose(u_diff, u_burg, atol=1e-6)


# ─── Picard iteration counts ───


class TestIterationCounts:
    def test_diffusion_converges_in_one_iteration(self):
        """Diffusion is linear — Picard should converge in 1 iteration."""
        N, nu, dt = 32, 0.01, 0.01
        stepper = Diffusion(1, DOMAIN_EXTENT, N, dt, diffusivity=nu)
        u0 = sin_1d(N)
        n_iters = stepper.diagnose(u0)
        assert n_iters == 1

    def test_burgers_needs_multiple_iterations(self):
        """Burgers is nonlinear — Picard should need >1 iteration."""
        N, nu, dt = 32, 0.01, 0.1
        stepper = Burgers(1, DOMAIN_EXTENT, N, dt, diffusivity=nu, convection_scale=1.0)
        u0 = sin_1d(N)
        n_iters = stepper.diagnose(u0)
        assert n_iters > 1


# ─── JIT compatibility ───


class TestJITCompatibility:
    def test_diffusion_under_jit(self):
        N, nu, dt = 32, 0.01, 0.01
        stepper = Diffusion(1, DOMAIN_EXTENT, N, dt, diffusivity=nu)
        u0 = sin_1d(N)

        @jax.jit
        def step(u):
            return stepper(u)

        u1_eager = stepper(u0)
        u1_jit = step(u0)
        assert jnp.allclose(u1_eager, u1_jit)

    def test_burgers_under_jit(self):
        N, nu, dt = 32, 0.01, 0.01
        stepper = Burgers(1, DOMAIN_EXTENT, N, dt, diffusivity=nu, convection_scale=1.0)
        u0 = sin_1d(N)

        @jax.jit
        def step(u):
            return stepper(u)

        u1_eager = stepper(u0)
        u1_jit = step(u0)
        assert jnp.allclose(u1_eager, u1_jit)

    def test_advection_under_jit(self):
        N, dt = 64, 0.01
        stepper = Advection(1, DOMAIN_EXTENT, N, dt, velocity=0.1)
        u0 = sin_1d(N)

        @jax.jit
        def step(u):
            return stepper(u)

        u1_eager = stepper(u0)
        u1_jit = step(u0)
        assert jnp.allclose(u1_eager, u1_jit)


# ─── Advection basic behavior ───


class TestAdvection:
    def test_advection_preserves_amplitude(self):
        """Pure advection should not change amplitude (no diffusion)."""
        N, dt = 128, 0.001
        stepper = Advection(1, DOMAIN_EXTENT, N, dt, velocity=1.0, theta=0.5)
        u0 = sin_1d(N)
        u = u0
        for _ in range(5):
            u = stepper(u)
        # Amplitude should be approximately preserved
        assert jnp.abs(jnp.max(jnp.abs(u)) - jnp.max(jnp.abs(u0))) < 0.01

    def test_advection_translates_signal(self):
        """After advection, the signal should have shifted."""
        N, dt = 128, 0.01
        stepper = Advection(1, DOMAIN_EXTENT, N, dt, velocity=1.0, theta=0.5)
        u0 = sin_1d(N)
        u = u0
        for _ in range(10):
            u = stepper(u)
        # Should not be identical to initial (it moved)
        assert not jnp.allclose(u, u0, atol=1e-3)


# ─── Throw behavior ───


class TestThrowBehavior:
    """Test throw/no-throw for linear and nonlinear solver convergence.

    Linsolve throw tests require ``eqx.filter_jit`` as the outermost
    compilation boundary, because ``eqx.error_if`` inside
    ``jax.lax.while_loop`` (used by the Picard solver) only raises a
    catchable ``EquinoxRuntimeError`` under ``filter_jit``. In eager
    mode or under plain ``jax.jit``, the error is logged to stderr but
    not raised.

    Picard throw tests work in eager mode because the ``eqx.error_if``
    call sits *after* the ``while_loop`` in ``Solver.__call__``.

    All linsolve tests use large diffusivity/dt so the linear system is
    far from identity and the solver cannot converge in 1 iteration.
    """

    # ── Diffusion (linear PDE — only linsolve throw) ──

    def test_diffusion_linsolve_throw_raises(self):
        N, dt = 32, 1.0
        stepper = Diffusion(
            1,
            DOMAIN_EXTENT,
            N,
            dt,
            diffusivity=10.0,
            linsolve_throw=True,
            linsolve_maxiter=1,
            linsolve_tol=1e-15,
        )
        u0 = sin_1d(N)

        @eqx.filter_jit
        def step(u):
            return stepper(u)

        with pytest.raises(eqx.EquinoxRuntimeError, match="Linear solver"):
            step(u0)

    def test_diffusion_linsolve_no_throw_returns(self):
        N, dt = 32, 1.0
        stepper = Diffusion(
            1,
            DOMAIN_EXTENT,
            N,
            dt,
            diffusivity=10.0,
            linsolve_throw=False,
            linsolve_maxiter=1,
            linsolve_tol=1e-15,
        )
        u0 = sin_1d(N)
        u1 = stepper(u0)
        assert u1.shape == u0.shape

    # ── Advection (linear PDE — only linsolve throw) ──

    def test_advection_linsolve_throw_raises(self):
        # N=128 ensures GMRES(restart=20) cannot converge in 1 outer iteration
        N, dt = 128, 1.0
        stepper = Advection(
            1,
            DOMAIN_EXTENT,
            N,
            dt,
            velocity=10.0,
            linsolve_throw=True,
            linsolve_maxiter=1,
            linsolve_tol=1e-15,
        )
        u0 = sin_1d(N)

        @eqx.filter_jit
        def step(u):
            return stepper(u)

        with pytest.raises(eqx.EquinoxRuntimeError, match="Linear solver"):
            step(u0)

    def test_advection_linsolve_no_throw_returns(self):
        N, dt = 128, 1.0
        stepper = Advection(
            1,
            DOMAIN_EXTENT,
            N,
            dt,
            velocity=10.0,
            linsolve_throw=False,
            linsolve_maxiter=1,
            linsolve_tol=1e-15,
        )
        u0 = sin_1d(N)
        u1 = stepper(u0)
        assert u1.shape == u0.shape

    # ── Burgers (nonlinear PDE — both picard and linsolve throw) ──

    def test_burgers_picard_throw_raises(self):
        N, dt = 32, 0.01
        stepper = Burgers(
            1,
            DOMAIN_EXTENT,
            N,
            dt,
            picard_throw=True,
            picard_maxiter=1,
            picard_tol=1e-15,
        )
        u0 = sin_1d(N)
        with pytest.raises(Exception, match="Nonlinear solver"):
            stepper(u0)

    def test_burgers_picard_no_throw_returns(self):
        N, dt = 32, 0.01
        stepper = Burgers(
            1,
            DOMAIN_EXTENT,
            N,
            dt,
            picard_throw=False,
            picard_maxiter=1,
            picard_tol=1e-15,
        )
        u0 = sin_1d(N)
        u1 = stepper(u0)
        assert u1.shape == u0.shape

    def test_burgers_linsolve_throw_raises(self):
        N, dt = 32, 1.0
        stepper = Burgers(
            1,
            DOMAIN_EXTENT,
            N,
            dt,
            diffusivity=10.0,
            linsolve_throw=True,
            linsolve_maxiter=1,
            linsolve_tol=1e-15,
            picard_throw=False,
        )
        u0 = sin_1d(N)

        @eqx.filter_jit
        def step(u):
            return stepper(u)

        with pytest.raises(eqx.EquinoxRuntimeError, match="Linear solver"):
            step(u0)

    def test_burgers_linsolve_no_throw_returns(self):
        N, dt = 32, 1.0
        stepper = Burgers(
            1,
            DOMAIN_EXTENT,
            N,
            dt,
            diffusivity=10.0,
            linsolve_throw=False,
            linsolve_maxiter=1,
            linsolve_tol=1e-15,
            picard_throw=False,
        )
        u0 = sin_1d(N)
        u1 = stepper(u0)
        assert u1.shape == u0.shape


# ─── HyperDiffusion ───


class TestHyperDiffusion:
    def test_smooths_high_frequency(self):
        """Hyper-diffusion should damp high-frequency modes faster than low."""
        N, dt = 64, 0.001
        stepper = HyperDiffusion(1, DOMAIN_EXTENT, N, dt, hyper_diffusivity=0.01)
        u0_low = sin_1d(N, k=1)
        u0_high = sin_1d(N, k=4)
        u1_low = stepper(u0_low)
        u1_high = stepper(u0_high)
        decay_low = float(jnp.max(jnp.abs(u1_low)) / jnp.max(jnp.abs(u0_low)))
        decay_high = float(jnp.max(jnp.abs(u1_high)) / jnp.max(jnp.abs(u0_high)))
        # k^4 scaling: mode k=4 decays much faster than k=1
        assert decay_high < decay_low

    def test_converges_in_one_iteration(self):
        """HyperDiffusion is linear — Picard converges in 1 iteration."""
        N, dt = 32, 0.01
        stepper = HyperDiffusion(1, DOMAIN_EXTENT, N, dt, hyper_diffusivity=0.01)
        u0 = sin_1d(N)
        n_iters = stepper.diagnose(u0)
        assert n_iters == 1

    def test_under_jit(self):
        N, dt = 32, 0.01
        stepper = HyperDiffusion(1, DOMAIN_EXTENT, N, dt, hyper_diffusivity=0.01)
        u0 = sin_1d(N)

        @jax.jit
        def step(u):
            return stepper(u)

        assert jnp.allclose(stepper(u0), step(u0))


# ─── Dispersion ───


class TestDispersion:
    def test_preserves_amplitude(self):
        """Dispersion is purely wave-like — amplitude should be ~preserved."""
        N, dt = 128, 0.001
        stepper = Dispersion(1, DOMAIN_EXTENT, N, dt, dispersivity=0.1, theta=0.5)
        u0 = sin_1d(N)
        u = u0
        for _ in range(5):
            u = stepper(u)
        ratio = float(jnp.max(jnp.abs(u)) / jnp.max(jnp.abs(u0)))
        assert 0.95 < ratio < 1.05

    def test_converges_in_one_iteration(self):
        """Dispersion is linear — Picard converges in 1 iteration."""
        N, dt = 32, 0.01
        stepper = Dispersion(1, DOMAIN_EXTENT, N, dt, dispersivity=0.01)
        u0 = sin_1d(N)
        n_iters = stepper.diagnose(u0)
        assert n_iters == 1

    def test_under_jit(self):
        N, dt = 32, 0.01
        stepper = Dispersion(1, DOMAIN_EXTENT, N, dt, dispersivity=0.01)
        u0 = sin_1d(N)

        @jax.jit
        def step(u):
            return stepper(u)

        assert jnp.allclose(stepper(u0), step(u0))


# ─── Korteweg-de Vries ───


class TestKortewegDeVries:
    def test_zero_convection_matches_dispersion(self):
        """KdV with convection_scale=0 should match pure dispersion."""
        N, dt = 64, 0.001
        disp_stepper = Dispersion(1, DOMAIN_EXTENT, N, dt, dispersivity=0.1)
        kdv_stepper = KortewegDeVries(
            1, DOMAIN_EXTENT, N, dt, convection_scale=0.0, dispersivity=0.1
        )
        u0 = sin_1d(N)
        u_disp = disp_stepper(u0)
        u_kdv = kdv_stepper(u0)
        assert jnp.allclose(u_disp, u_kdv, atol=1e-6)

    def test_needs_multiple_iterations(self):
        """KdV is nonlinear — Picard should need >1 iteration."""
        N, dt = 32, 0.1
        stepper = KortewegDeVries(
            1, DOMAIN_EXTENT, N, dt, convection_scale=1.0, dispersivity=1.0
        )
        u0 = sin_1d(N)
        n_iters = stepper.diagnose(u0)
        assert n_iters > 1

    def test_under_jit(self):
        N, dt = 32, 0.01
        stepper = KortewegDeVries(
            1, DOMAIN_EXTENT, N, dt, convection_scale=1.0, dispersivity=1.0
        )
        u0 = sin_1d(N)

        @jax.jit
        def step(u):
            return stepper(u)

        assert jnp.allclose(stepper(u0), step(u0))


# ─── Kuramoto-Sivashinsky ───


class TestKuramotoSivashinsky:
    def test_needs_multiple_iterations(self):
        """KS is nonlinear — Picard should need >1 iteration."""
        N, dt = 32, 0.1
        stepper = KuramotoSivashinsky(1, DOMAIN_EXTENT, N, dt, gradient_norm_scale=1.0)
        u0 = sin_1d(N)
        n_iters = stepper.diagnose(u0)
        assert n_iters > 1

    def test_under_jit(self):
        N, dt = 32, 0.01
        stepper = KuramotoSivashinsky(1, DOMAIN_EXTENT, N, dt, gradient_norm_scale=1.0)
        u0 = sin_1d(N)

        @jax.jit
        def step(u):
            return stepper(u)

        assert jnp.allclose(stepper(u0), step(u0))

    def test_gradient_through_solve(self):
        """jax.grad w.r.t. u0 runs without error and returns finite values."""
        N, dt = 32, 0.01
        stepper = KuramotoSivashinsky(
            1, DOMAIN_EXTENT, N, dt, gradient_norm_scale=1.0, diff_mode="implicit"
        )
        u0 = sin_1d(N)

        def loss(u):
            return jnp.sum(stepper(u) ** 2)

        grad = jax.grad(loss)(u0)
        assert grad.shape == u0.shape
        assert jnp.all(jnp.isfinite(grad))

    def test_zero_nonlinearity_matches_linear(self):
        """With gradient_norm_scale=0, KS reduces to diffusion + hyper-diffusion."""
        N, dt = 32, 0.01
        nu2 = -1.0  # second_order_scale (diffusion-like, but destabilizing)
        nu4 = -1.0  # fourth_order_scale (hyper-diffusion, stabilizing)
        ks_stepper = KuramotoSivashinsky(
            1,
            DOMAIN_EXTENT,
            N,
            dt,
            gradient_norm_scale=0.0,
            second_order_scale=nu2,
            fourth_order_scale=nu4,
        )
        # Build equivalent linear stepper: diffusion + hyper-diffusion
        u0 = sin_1d(N)
        u_ks = ks_stepper(u0)
        # The combined linear effect: we can't just add two steppers, but
        # with gradient_norm_scale=0 the KS stepper IS the linear stepper.
        # Compare against running KS with zero nonlinearity which should
        # converge in 1 Picard iteration (linear).
        n_iters = ks_stepper.diagnose(u0)
        assert n_iters == 1  # confirms linearity
        assert u_ks.shape == u0.shape
        assert jnp.all(jnp.isfinite(u_ks))


# ─── Multi-dimensional tests ───


class TestMultiDimensional:
    def test_2d_diffusion_one_step(self):
        """2D diffusion of sin(kx)*sin(ky) matches analytical decay."""
        N, k, nu, dt = 32, 1, 0.01, 0.01
        stepper = Diffusion(2, DOMAIN_EXTENT, N, dt, diffusivity=nu)
        x = jnp.linspace(0, DOMAIN_EXTENT, N, endpoint=False)
        X, Y = jnp.meshgrid(x, x, indexing="ij")
        u0 = (jnp.sin(k * X) * jnp.sin(k * Y))[None]  # (1, N, N)
        u1 = stepper(u0)
        # Analytical: exp(-(k^2 + k^2)*nu*dt) * sin(kx)*sin(ky)
        decay = jnp.exp(-(k**2 + k**2) * nu * dt)
        expected = decay * u0
        assert jnp.allclose(u1, expected, atol=1e-4)
