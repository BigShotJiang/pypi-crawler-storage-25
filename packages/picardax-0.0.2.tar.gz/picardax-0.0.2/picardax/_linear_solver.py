from abc import ABC, abstractmethod

import equinox as eqx
import jax
import jax.numpy as jnp

from picardax._tree import tree_norm, tree_sub


class LinearSolver(ABC, eqx.Module):
    """Abstract base class for linear solvers."""

    throw: bool = True

    @abstractmethod
    def __call__(self, lin_fun, b):
        """Solve the linear system A x = b, where lin_fun applies A.

        If throw=True and the solver does not converge, raises an error
        via equinox.error_if.
        """
        ...

    def residual(self, lin_fun, x, b):
        """Compute the residual r = A x - b."""
        return tree_sub(lin_fun(x), b)

    def diagnose(self, lin_fun, b) -> int:
        """Return the number of iterations needed to converge."""
        raise NotImplementedError

    def get_all_iterates(self, lin_fun, b, *, include_init=False):
        """Return all iterates as an array of shape (n_iter, *b.shape)."""
        raise NotImplementedError

    def get_error_iterates(self, lin_fun, b, *, include_init=False):
        """Return a scalar error metric (e.g. residual norm) at each iteration.

        More memory-efficient than get_all_iterates since only a scalar
        per iteration is stored, not the full state.

        """
        raise NotImplementedError


class JAXIterativeLinearSolver(LinearSolver, ABC):
    """Abstract base for JAX built-in iterative solvers.

    These solvers are opaque and cannot be unrolled, so per-iteration
    diagnostics (get_all_iterates, get_error_iterates) require
    ``unroll_hack=True``, which re-runs the solver with increasing
    maxiter caps via ``jax.lax.map``.

    """

    tol: float = 1e-5
    maxiter: int | None = 1000
    unroll_hack: bool = False
    """If True, enable per-iteration diagnostics by re-solving with
    increasing ``maxiter`` caps via ``jax.lax.map``. Expensive (reruns
    the full solve up to ``maxiter`` times) but the only way to extract
    iterates from opaque JAX solvers."""
    unroll_hack_chunk_size: int = 100
    """Batch size for ``jax.lax.map`` when ``unroll_hack=True``."""

    @abstractmethod
    def _solve(self, lin_fun, b, *, tol: float, maxiter: int | None):
        """Call the underlying JAX solver.

        Returns:
            A tuple (x, info) where info == 0 indicates convergence.
        """
        ...

    def __call__(self, lin_fun, b):
        x, _ = self._solve(lin_fun, b, tol=self.tol, maxiter=self.maxiter)

        if self.throw:
            r = self.residual(lin_fun, x, b)
            is_converged = tree_norm(r) <= self.tol * tree_norm(b)

            x = eqx.error_if(
                x,
                jnp.logical_not(is_converged),
                "Linear solver did not converge.",
            )

        return x

    def get_all_iterates(self, lin_fun, b, *, include_init=False):
        if not self.unroll_hack:
            raise NotImplementedError(
                "`get_all_iterates` is only supported when"
                " `unroll_hack` is True (costly, vmaps over"
                " the iterations)."
            )

        def get_iterate(i):
            x, _ = self._solve(lin_fun, b, tol=self.tol, maxiter=i)
            return x

        iteration_range = (
            jnp.arange(0, self.maxiter + 1)
            if include_init
            else jnp.arange(1, self.maxiter + 1)
        )

        iterates = jax.lax.map(
            get_iterate,
            iteration_range,
            batch_size=self.unroll_hack_chunk_size,
        )

        return iterates

    def get_error_iterates(self, lin_fun, b, *, include_init=False):
        if not self.unroll_hack:
            raise NotImplementedError(
                "`get_error_iterates` is only supported when"
                " `unroll_hack` is True (costly, vmaps over"
                " the iterations)."
            )

        def get_error(i):
            x, _ = self._solve(lin_fun, b, tol=self.tol, maxiter=i)
            r = self.residual(lin_fun, x, b)
            return tree_norm(r) / tree_norm(b)

        iteration_range = (
            jnp.arange(0, self.maxiter + 1)
            if include_init
            else jnp.arange(1, self.maxiter + 1)
        )

        error_iterates = jax.lax.map(
            get_error,
            iteration_range,
            batch_size=self.unroll_hack_chunk_size,
        )

        return error_iterates

    def diagnose(self, lin_fun, b):
        error_iterates = self.get_error_iterates(lin_fun, b, include_init=True)
        converged = error_iterates <= self.tol
        # Does not require +1 because we include the init
        return jnp.where(jnp.any(converged), jnp.argmax(converged), -1)


class CG(JAXIterativeLinearSolver):
    """Conjugate Gradient solver."""

    def _solve(self, lin_fun, b, *, tol: float, maxiter: int | None):
        return jax.scipy.sparse.linalg.cg(lin_fun, b, tol=tol, maxiter=maxiter)


class GMRES(JAXIterativeLinearSolver):
    """GMRES solver."""

    def _solve(self, lin_fun, b, *, tol: float, maxiter: int | None):
        return jax.scipy.sparse.linalg.gmres(lin_fun, b, tol=tol, maxiter=maxiter)


class BiCGStab(JAXIterativeLinearSolver):
    """BiCGStab solver."""

    def _solve(self, lin_fun, b, *, tol: float, maxiter: int | None):
        return jax.scipy.sparse.linalg.bicgstab(lin_fun, b, tol=tol, maxiter=maxiter)
