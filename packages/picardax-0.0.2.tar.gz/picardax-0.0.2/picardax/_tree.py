"""
Pytree utilities for linear algebra operations.

Based on helpers from
https://github.com/jax-ml/jax/blob/main/jax/_src/scipy/sparse/linalg.py
"""

import operator
from functools import partial

import jax
import jax.numpy as jnp

_vdot = partial(jnp.vdot, precision=jax.lax.Precision.HIGHEST)


def _vdot_real_part(x, y):
    """Vector dot-product guaranteed to have a real valued result despite
    possibly complex input. Thus neglects the real-imaginary cross-terms.
    The result is a real float.
    """
    result = _vdot(x.real, y.real)
    if jnp.iscomplexobj(x) or jnp.iscomplexobj(y):
        result += _vdot(x.imag, y.imag)
    return result


def tree_norm(x):
    xs = jax.tree.leaves(x)
    return jnp.sqrt(sum(map(_vdot_real_part, xs, xs)))


def tree_scalar_mul(scalar, tree):
    return jax.tree.map(partial(operator.mul, scalar), tree)


tree_add = partial(jax.tree.map, operator.add)
tree_sub = partial(jax.tree.map, operator.sub)
