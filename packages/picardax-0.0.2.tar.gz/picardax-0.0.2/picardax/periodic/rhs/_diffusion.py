from picardax._rhs import RHS
from picardax.periodic._derivatives import Derivatives


class Diffusion(RHS):
    """Diffusion operator: F(u) = diffusivity * laplacian(u)."""

    derivatives: Derivatives
    diffusivity: float

    def linearized_operator(self, u, u_linearized):
        return self.diffusivity * self.derivatives.laplacian(u)
