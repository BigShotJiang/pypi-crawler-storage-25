from picardax._rhs import RHS
from picardax.periodic._derivatives import Derivatives


class HyperDiffusion(RHS):
    """Hyper-diffusion: F(u) = -hyper_diffusivity * nabla^4 u.

    Linear PDE — u_linearized is unused.
    Positive hyper_diffusivity is smoothing (stabilizing).
    """

    derivatives: Derivatives
    hyper_diffusivity: float

    def linearized_operator(self, u, u_linearized):
        return -self.hyper_diffusivity * self.derivatives.double_laplacian(u)
