from ._advection import Advection
from ._burgers import Burgers
from ._diffusion import Diffusion
from ._dispersion import Dispersion
from ._hyper_diffusion import HyperDiffusion
from ._korteweg_de_vries import KortewegDeVries
from ._kuramoto_sivashinsky import KuramotoSivashinsky

__all__ = [
    "Advection",
    "Burgers",
    "Diffusion",
    "Dispersion",
    "HyperDiffusion",
    "KortewegDeVries",
    "KuramotoSivashinsky",
]
