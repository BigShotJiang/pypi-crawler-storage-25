from picardax._rhs import RHS
from picardax.periodic._derivatives import Derivatives


class Burgers(RHS):
    """Burgers equation: nonlinear convection + diffusion."""

    derivatives: Derivatives
    diffusivity: float
    convection_scale: float

    def linearized_operator(self, u, u_linearized):
        return -self.convection_scale * self.derivatives.scaled_upwind_derivative(
            u, winds=u_linearized
        ) + self.diffusivity * self.derivatives.laplacian(u)
