from picardax._rhs import RHS
from picardax.periodic._derivatives import Derivatives


class Dispersion(RHS):
    """Dispersion: F(u) = -dispersivity * sum_d(d^3 u / dx_d^3).

    Linear PDE — u_linearized is unused.
    Pure wave-like behavior with no damping.
    """

    derivatives: Derivatives
    dispersivity: float

    def linearized_operator(self, u, u_linearized):
        return -self.dispersivity * sum(
            self.derivatives.derivative(u, dim=d, derivative_order=3)
            for d in range(self.derivatives.num_spatial_dims)
        )
