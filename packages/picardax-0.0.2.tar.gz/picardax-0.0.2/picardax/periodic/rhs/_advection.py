import jax.numpy as jnp

from picardax._rhs import RHS
from picardax.periodic._derivatives import Derivatives


class Advection(RHS):
    """Advection with constant velocity: F(u) = -(v . nabla) u.

    Linear PDE — u_linearized is unused.
    """

    derivatives: Derivatives
    velocity: tuple[float, ...]

    def linearized_operator(self, u, u_linearized):
        winds = jnp.concatenate(
            [
                adv
                * jnp.ones(
                    (1,)
                    + (self.derivatives.num_points,) * self.derivatives.num_spatial_dims
                )
                for adv in self.velocity
            ]
        )
        return -self.derivatives.scaled_upwind_derivative(u, winds=winds)
