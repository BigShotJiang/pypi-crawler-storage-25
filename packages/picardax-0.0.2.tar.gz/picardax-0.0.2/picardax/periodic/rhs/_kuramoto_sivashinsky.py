import jax.numpy as jnp

from picardax._rhs import RHS
from picardax.periodic._derivatives import Derivatives


class KuramotoSivashinsky(RHS):
    """Kuramoto-Sivashinsky equation: squared gradient norm + diffusion +
    hyper-diffusion.

    F(u) = -scale * ||nabla u||^2 + second_order * laplacian(u)
           + fourth_order * biharmonic(u)

    Linearization: the squared gradient norm ||nabla u||^2 = sum_i (du/dx_i)^2
    is linearized by freezing one gradient factor at u_linearized, giving
    sum_i (du/dx_i)(du_lin/dx_i). This is analogous to how Burgers freezes one
    factor in the u * du/dx convection term.
    """

    derivatives: Derivatives
    gradient_norm_scale: float
    second_order_scale: float
    fourth_order_scale: float

    def linearized_operator(self, u, u_linearized):
        grad_u = self.derivatives.gradient(u, method="centered", method_order=2)
        grad_u_lin = self.derivatives.gradient(
            u_linearized, method="centered", method_order=2
        )
        # ||nabla u||^2 linearized: freeze one gradient at u_lin
        linearized_gradient_norm_sq = jnp.sum(
            grad_u_lin * grad_u,
            axis=self.derivatives._derivative_axis,
        )
        return (
            -self.gradient_norm_scale * linearized_gradient_norm_sq
            + self.second_order_scale * self.derivatives.laplacian(u)
            + self.fourth_order_scale * self.derivatives.double_laplacian(u)
        )
