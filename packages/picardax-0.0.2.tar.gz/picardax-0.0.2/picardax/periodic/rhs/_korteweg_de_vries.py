from picardax._rhs import RHS
from picardax.periodic._derivatives import Derivatives


class KortewegDeVries(RHS):
    """Korteweg-de Vries: nonlinear convection + dispersion.

    Standard form: u_t + convection_scale * u * u_x + dispersivity * u_xxx = 0
    """

    derivatives: Derivatives
    convection_scale: float
    dispersivity: float

    def linearized_operator(self, u, u_linearized):
        convection = -self.convection_scale * self.derivatives.scaled_upwind_derivative(
            u, winds=u_linearized
        )
        dispersion = -self.dispersivity * sum(
            self.derivatives.derivative(u, dim=d, derivative_order=3)
            for d in range(self.derivatives.num_spatial_dims)
        )
        return convection + dispersion
