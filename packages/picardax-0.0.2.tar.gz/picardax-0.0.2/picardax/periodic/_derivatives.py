from abc import ABC, abstractmethod

import equinox as eqx
import jax.numpy as jnp


class Derivatives(ABC, eqx.Module):
    """Optional abstract base class for grid-based finite difference derivatives.

    For grid-based FD submodules, this shared interface allows the same RHS
    implementations to work across different boundary conditions by swapping the
    Derivatives object.
    """

    @abstractmethod
    def derivative(self, u, dim, derivative_order, method, method_order):
        """Compute a finite difference derivative along a given dimension."""
        ...

    @abstractmethod
    def gradient(self, u):
        """Compute the gradient of u."""
        ...

    @abstractmethod
    def laplacian(self, u):
        """Compute the Laplacian of u."""
        ...


# Finite Difference stencils from
# https://en.wikipedia.org/wiki/Finite_difference_coefficient
#
# Indexing: stencils[method][derivative_order][approximation_order]
# Each entry is a list of (shift, weight) tuples.
STENCILS = {
    "forward": {
        1: {
            1: [(0, -1), (1, 1)],
            2: [(0, -3 / 2), (1, 2), (2, -1 / 2)],
            3: [(0, -11 / 6), (1, 3), (2, -3 / 2), (3, 1 / 3)],
        },
        3: {
            1: [(0, -1), (1, 3), (2, -3), (3, 1)],
        },
    },
    "backward": {
        1: {
            1: [(-1, -1), (0, 1)],
            2: [(-2, 1 / 2), (-1, -2), (0, 3 / 2)],
            3: [(-3, -1 / 3), (-2, 3 / 2), (-1, -3), (0, 11 / 6)],
        },
        3: {
            1: [(-3, -1), (-2, 3), (-1, -3), (0, 1)],
        },
    },
    "centered": {
        1: {
            2: [(-1, -1 / 2), (1, 1 / 2)],
        },
        2: {
            2: [(-1, 1), (0, -2), (1, 1)],
        },
        3: {
            2: [(-2, -1 / 2), (-1, 1), (1, -1), (2, 1 / 2)],
        },
        4: {
            2: [(-2, 1), (-1, -4), (0, 6), (1, -4), (2, 1)],
        },
    },
}


class CollocatedDerivatives(Derivatives):
    """Finite difference derivatives on a uniform collocated grid with periodic BCs."""

    num_spatial_dims: int
    num_points: int
    domain_extent: float
    dx: float

    def __init__(self, num_spatial_dims, num_points, domain_extent):
        self.num_spatial_dims = num_spatial_dims
        self.num_points = num_points
        self.domain_extent = domain_extent
        self.dx = domain_extent / num_points

    @property
    def _derivative_axis(self):
        return -(self.num_spatial_dims + 1)

    def get_neighbor(self, u, *, dim, shift):
        """Shift u along dim by shift grid points (periodic roll)."""
        if isinstance(dim, int):
            dim = (dim,)
        if isinstance(shift, int):
            shift = (shift,)
        axes = tuple(-self.num_spatial_dims + d for d in dim)
        rolls = tuple(-s for s in shift)
        return jnp.roll(u, rolls, axis=axes)

    def derivative(
        self,
        u,
        dim,
        derivative_order,
        method="centered",
        method_order=2,
    ):
        """Compute a finite difference derivative along a given dimension."""
        rolls_and_weights = STENCILS[method][derivative_order][method_order]
        return (
            sum(
                weight * self.get_neighbor(u, dim=dim, shift=shift)
                for shift, weight in rolls_and_weights
            )
            / self.dx**derivative_order
        )

    def gradient(
        self,
        u,
        *,
        derivative_order=1,
        method="centered",
        method_order=2,
    ):
        """Compute the gradient: stack of partial derivatives along a new axis."""
        return jnp.stack(
            [
                self.derivative(
                    u,
                    dim=dim,
                    derivative_order=derivative_order,
                    method=method,
                    method_order=method_order,
                )
                for dim in range(self.num_spatial_dims)
            ],
            axis=self._derivative_axis,
        )

    def laplacian(self, u, *, method="centered", method_order=2):
        """Sum of second-order partial derivatives."""
        return jnp.sum(
            self.gradient(
                u,
                derivative_order=2,
                method=method,
                method_order=method_order,
            ),
            axis=self._derivative_axis,
        )

    def double_laplacian(self, u, *, method="centered", method_order=2):
        """Biharmonic operator: Δ²u = Δ(Δu).

        Computes the Laplacian of the Laplacian, which includes mixed
        cross-derivative terms (e.g. 2·∂⁴u/∂x²∂y² in 2D).
        """
        return self.laplacian(
            self.laplacian(u, method=method, method_order=method_order),
            method=method,
            method_order=method_order,
        )

    def gradient_norm(self, u, *, method="centered", method_order=2):
        """L2 norm of the gradient: ||nabla u||_2. Nonlinear operation."""
        return jnp.linalg.norm(
            self.gradient(u, method=method, method_order=method_order),
            axis=self._derivative_axis,
        )

    def get_positive_wind(self, winds, *, dim, zero_fixed=True):
        """Keep only positive wind entries; zero the rest.

        With zero_fixed=True, averages with the left neighbor so that
        winds adjacent to non-zero regions are also non-zero. Critical
        for correct shock propagation in Burgers equation.
        """
        if zero_fixed:
            return jnp.maximum(
                (winds + self.get_neighbor(winds, dim=dim, shift=-1)) / 2,
                0.0,
            )
        return jnp.maximum(winds, 0.0)

    def get_negative_wind(self, winds, *, dim, zero_fixed=True):
        """Keep only negative wind entries; zero the rest.

        With zero_fixed=True, averages with the right neighbor so that
        winds adjacent to non-zero regions are also non-zero. Critical
        for correct shock propagation in Burgers equation.
        """
        if zero_fixed:
            return jnp.minimum(
                (winds + self.get_neighbor(winds, dim=dim, shift=1)) / 2,
                0.0,
            )
        return jnp.minimum(winds, 0.0)

    def scaled_upwind_derivative(self, u, winds, *, zero_fixed=True, method_order=1):
        """Compute (w . nabla) u using upwind finite differences.

        Splits winds into positive/negative parts and uses
        backward/forward differences respectively.
        """
        positive_winds = jnp.stack(
            [
                self.get_positive_wind(
                    winds[dim : dim + 1], dim=dim, zero_fixed=zero_fixed
                )
                for dim in range(self.num_spatial_dims)
            ],
            axis=self._derivative_axis,
        )
        negative_winds = jnp.stack(
            [
                self.get_negative_wind(
                    winds[dim : dim + 1], dim=dim, zero_fixed=zero_fixed
                )
                for dim in range(self.num_spatial_dims)
            ],
            axis=self._derivative_axis,
        )

        gradient_backward = self.gradient(
            u, method="backward", method_order=method_order
        )
        gradient_forward = self.gradient(u, method="forward", method_order=method_order)

        return jnp.sum(
            positive_winds * gradient_backward + negative_winds * gradient_forward,
            axis=self._derivative_axis,
        )
