from picardax._linear_solver import CG, LinearSolver
from picardax._residuum import ThetaResiduum
from picardax._solver import Picard
from picardax._stepper import Stepper
from picardax.periodic._derivatives import CollocatedDerivatives
from picardax.periodic.rhs._diffusion import Diffusion as DiffusionRHS


def Diffusion(
    num_spatial_dims: int,
    domain_extent: float,
    num_points: int,
    dt: float,
    *,
    diffusivity: float = 0.01,
    theta: float = 0.5,
    linsolve_maxiter: int | None = None,
    linsolve_tol: float = 1e-5,
    linsolve_throw: bool = True,
    diff_mode: str = "implicit",
    adjoint_linear_solver: LinearSolver | None = None,
) -> Stepper:
    """Convenience constructor for a periodic diffusion stepper.

    Uses CG because the implicit diffusion operator is symmetric positive
    definite.
    """
    derivatives = CollocatedDerivatives(num_spatial_dims, num_points, domain_extent)
    rhs = DiffusionRHS(derivatives=derivatives, diffusivity=diffusivity)
    residuum = ThetaResiduum(rhs=rhs, theta=theta, dt=dt)
    solver = Picard(
        linear_solver=CG(
            maxiter=linsolve_maxiter, tol=linsolve_tol, throw=linsolve_throw
        ),
        maxiter=1,
        tol=1e-5,
        diff_mode=diff_mode,
        adjoint_linear_solver=adjoint_linear_solver,
    )
    return Stepper(residuum=residuum, solver=solver)
