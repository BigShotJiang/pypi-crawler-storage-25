from picardax._linear_solver import CG, LinearSolver
from picardax._residuum import ThetaResiduum
from picardax._solver import Picard
from picardax._stepper import Stepper
from picardax.periodic._derivatives import CollocatedDerivatives
from picardax.periodic.rhs._hyper_diffusion import HyperDiffusion as HyperDiffusionRHS


def HyperDiffusion(
    num_spatial_dims: int,
    domain_extent: float,
    num_points: int,
    dt: float,
    *,
    hyper_diffusivity: float = 0.01,
    theta: float = 0.5,
    linsolve_maxiter: int | None = None,
    linsolve_tol: float = 1e-5,
    linsolve_throw: bool = True,
    diff_mode: str = "implicit",
    adjoint_linear_solver: LinearSolver | None = None,
) -> Stepper:
    """Convenience constructor for a periodic hyper-diffusion stepper."""
    derivatives = CollocatedDerivatives(num_spatial_dims, num_points, domain_extent)
    rhs = HyperDiffusionRHS(
        derivatives=derivatives, hyper_diffusivity=hyper_diffusivity
    )
    residuum = ThetaResiduum(rhs=rhs, theta=theta, dt=dt)
    solver = Picard(
        linear_solver=CG(
            maxiter=linsolve_maxiter, tol=linsolve_tol, throw=linsolve_throw
        ),
        maxiter=1,
        tol=1e-5,
        diff_mode=diff_mode,
        adjoint_linear_solver=adjoint_linear_solver,
    )
    return Stepper(residuum=residuum, solver=solver)
