from picardax._linear_solver import GMRES, LinearSolver
from picardax._residuum import ThetaResiduum
from picardax._solver import Picard
from picardax._stepper import Stepper
from picardax.periodic import rhs as periodic_rhs
from picardax.periodic._derivatives import CollocatedDerivatives


def Burgers(
    num_spatial_dims: int,
    domain_extent: float,
    num_points: int,
    dt: float,
    *,
    diffusivity: float = 0.01,
    convection_scale: float = 1.0,
    theta: float = 0.5,
    picard_maxiter: int = 100,
    picard_tol: float = 1e-5,
    picard_throw: bool = True,
    linsolve_maxiter: int | None = None,
    linsolve_tol: float = 1e-5,
    linsolve_throw: bool = True,
    diff_mode: str = "implicit",
    adjoint_linear_solver: LinearSolver | None = None,
) -> Stepper:
    """Convenience constructor for a periodic Burgers stepper.

    Uses GMRES because the linearized Burgers operator is non-symmetric
    due to the convection term.
    """
    derivatives = CollocatedDerivatives(num_spatial_dims, num_points, domain_extent)
    rhs = periodic_rhs.Burgers(
        derivatives=derivatives,
        diffusivity=diffusivity,
        convection_scale=convection_scale,
    )
    residuum = ThetaResiduum(rhs=rhs, theta=theta, dt=dt)
    solver = Picard(
        linear_solver=GMRES(
            maxiter=linsolve_maxiter, tol=linsolve_tol, throw=linsolve_throw
        ),
        maxiter=picard_maxiter,
        tol=picard_tol,
        throw=picard_throw,
        diff_mode=diff_mode,
        adjoint_linear_solver=adjoint_linear_solver,
    )
    return Stepper(residuum=residuum, solver=solver)
