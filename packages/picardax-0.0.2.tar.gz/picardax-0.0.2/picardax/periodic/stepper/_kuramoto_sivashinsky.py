from picardax._linear_solver import GMRES, LinearSolver
from picardax._residuum import ThetaResiduum
from picardax._solver import Picard
from picardax._stepper import Stepper
from picardax.periodic._derivatives import CollocatedDerivatives
from picardax.periodic.rhs._kuramoto_sivashinsky import (
    KuramotoSivashinsky as KuramotoSivashinskyRHS,
)


def KuramotoSivashinsky(
    num_spatial_dims: int,
    domain_extent: float,
    num_points: int,
    dt: float,
    *,
    gradient_norm_scale: float = 1.0,
    second_order_scale: float = -1.0,
    fourth_order_scale: float = -1.0,
    theta: float = 0.5,
    picard_maxiter: int = 100,
    picard_tol: float = 1e-5,
    picard_throw: bool = True,
    linsolve_maxiter: int | None = None,
    linsolve_tol: float = 1e-5,
    linsolve_throw: bool = True,
    diff_mode: str = "implicit",
    adjoint_linear_solver: LinearSolver | None = None,
) -> Stepper:
    """Convenience constructor for a periodic Kuramoto-Sivashinsky stepper.

    Uses GMRES because the KS operator is non-symmetric.
    """
    derivatives = CollocatedDerivatives(num_spatial_dims, num_points, domain_extent)
    rhs = KuramotoSivashinskyRHS(
        derivatives=derivatives,
        gradient_norm_scale=gradient_norm_scale,
        second_order_scale=second_order_scale,
        fourth_order_scale=fourth_order_scale,
    )
    residuum = ThetaResiduum(rhs=rhs, theta=theta, dt=dt)
    solver = Picard(
        linear_solver=GMRES(
            maxiter=linsolve_maxiter, tol=linsolve_tol, throw=linsolve_throw
        ),
        maxiter=picard_maxiter,
        tol=picard_tol,
        throw=picard_throw,
        diff_mode=diff_mode,
        adjoint_linear_solver=adjoint_linear_solver,
    )
    return Stepper(residuum=residuum, solver=solver)
