from importlib.metadata import version

from . import periodic
from ._linear_solver import CG, GMRES, BiCGStab, LinearSolver
from ._residuum import Residuum, ThetaResiduum
from ._rhs import RHS
from ._solver import DiffMode, Newton, Picard, Solver
from ._stepper import Stepper

__version__ = version("picardax")

__all__ = [
    "LinearSolver",
    "CG",
    "GMRES",
    "BiCGStab",
    "Residuum",
    "ThetaResiduum",
    "RHS",
    "Solver",
    "DiffMode",
    "Picard",
    "Newton",
    "Stepper",
    "periodic",
    "__version__",
]
