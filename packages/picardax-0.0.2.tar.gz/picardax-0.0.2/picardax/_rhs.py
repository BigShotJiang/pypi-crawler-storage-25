from abc import ABC, abstractmethod

import equinox as eqx


class RHS(ABC, eqx.Module):
    """Abstract base class for right-hand side operators F(u)."""

    @abstractmethod
    def linearized_operator(self, u, u_linearized):
        """Evaluate the (linearized) operator F_lin(u; u_linearized).

        For linear problems, u_linearized is ignored.
        For nonlinear problems, the nonlinear terms are linearized around
        u_linearized.
        """
        ...

    def __call__(self, u):
        """Evaluate the full (nonlinear) operator F(u)."""
        return self.linearized_operator(u, u)
