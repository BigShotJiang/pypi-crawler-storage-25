from abc import ABC, abstractmethod
from typing import Literal

import equinox as eqx
import equinox.internal as eqi
import jax
import jax.numpy as jnp

from picardax._linear_solver import LinearSolver
from picardax._residuum import Residuum
from picardax._tree import tree_norm

DiffMode = Literal[
    "implicit",
    "implicit_jvp",
    "implicit_reduced",
    "implicit_reduced_jvp",
    "lax",
    "checkpointed",
    "bounded",
    "detach",
]

_VALID_DIFF_MODES = (
    "implicit",
    "implicit_jvp",
    "implicit_reduced",
    "implicit_reduced_jvp",
    "lax",
    "checkpointed",
    "bounded",
    "detach",
)

_ITERPATH_MODES = ("lax", "checkpointed", "bounded")

_REDUCED_MODES = ("implicit_reduced", "implicit_reduced_jvp")


def _nothrow(solver: "LinearSolver") -> "LinearSolver":
    """Return a copy of a linear solver with throw=False."""
    return eqx.tree_at(lambda s: s.throw, solver, False)


class Solver(ABC, eqx.Module):
    """Abstract base class for iterative nonlinear solvers.

    Subclasses implement ``_step`` (a single iteration). All looping,
    differentiation, and diagnostic methods are derived from ``_step``
    on the base class.

    Attributes:
        linear_solver: The linear solver used inside each nonlinear
            iteration (e.g. ``CG``, ``GMRES``, ``BiCGStab``).
        maxiter: Maximum number of nonlinear iterations. For
            iteration-path modes (``"bounded"``, ``"checkpointed"``),
            this is also passed as ``max_steps`` to the equinox
            while loop.
        tol: Relative convergence tolerance (relative to the initial
            residual norm). The solver stops when
            ``‖R(u_k)‖ ≤ tol · ‖R(u_init)‖``. Note that this differs
            from the linear solver tolerance, which is relative to the
            RHS norm ``‖b‖``.
        throw: If ``True``, raise ``EquinoxRuntimeError`` when the
            solver does not converge within ``maxiter`` iterations.
            If ``False``, silently return the last iterate. Note that
            ``throw=True`` only raises a catchable exception when the
            outermost compilation boundary is ``eqx.filter_jit``.
        initial_from_prev: If ``True`` (default), use ``u_prev`` as
            the initial guess for the nonlinear iteration. If
            ``False``, start from zeros.
        stop_gradient_on_initial_guess: If ``True`` (default), apply
            ``jax.lax.stop_gradient`` to the initial guess before
            entering the iteration loop. Only affects iteration-path
            modes (``"lax"``, ``"checkpointed"``, ``"bounded"``)
            where the gradient flows through the loop body. Has no
            effect on IFT modes, which compute gradients from the
            converged fixed-point equation, not from the iteration
            path.
        diff_mode: Controls how gradients propagate through the solve.
            See below for details on each mode.
        adjoint_linear_solver: Optional separate linear solver for the
            adjoint/tangent system in IFT modes. If ``None`` (default),
            ``linear_solver`` is reused. Useful when a different
            tolerance or algorithm is desired for the backward pass
            (e.g. tighter tolerance for gradient accuracy, or GMRES
            instead of CG when the transposed operator is
            non-symmetric).

    Differentiation modes (``diff_mode``):

        **IFT group** — Implicit Function Theorem at convergence. These
        modes replace the native while-loop differentiation with a
        custom rule that solves a single linear system at the converged
        solution ``u*``. Memory is O(1) regardless of iteration count.
        Gradients are correct assuming convergence; they do not depend
        on the iteration path or the initial guess.

        ``"implicit"`` (default):
            Uses ``jax.custom_vjp``. The VJP (reverse-mode / ``jax.grad``)
            is computed explicitly by solving the adjoint system
            ``(∂R/∂u*)ᵀ λ = g`` using ``adjoint_linear_solver``.
            JVP (forward-mode / ``jax.jvp``) is derived automatically
            by JAX transposition. This is the recommended mode for
            most use cases (training, PDE-constrained optimization).

        ``"implicit_jvp"``:
            Uses ``jax.custom_jvp``. The JVP is computed explicitly
            by solving the tangent system ``(∂R/∂u*) u̇ = −ṘHS``
            using ``linear_solver``. VJP is derived by JAX
            transposition (via ``jax.lax.custom_linear_solve``).
            Prefer this when you need direct tangent propagation
            (e.g. forward-mode sensitivity analysis, computing
            Jacobian columns).

        ``"implicit_reduced"`` (**Picard only**):
            Like ``"implicit"``, but uses the Picard-assembled
            operator ``A(u*)`` instead of the full Jacobian
            ``∂R/∂u*``. The adjoint system becomes ``A(u*)ᵀ λ = g``.
            This is the classical **discrete adjoint** approach from
            CFD: transpose the assembled forward operator, don't
            autodiff through the nonlinear residual. Exact for linear
            PDEs (where ``∂A/∂u = 0``); approximate for nonlinear
            PDEs where it drops the ``∂A/∂u*`` Newton correction term.
            Raises ``ValueError`` on ``Newton``.

        ``"implicit_reduced_jvp"`` (**Picard only**):
            Like ``"implicit_jvp"``, but uses the Picard operator for
            the tangent system: ``A(u*) u̇ = ḃ − Ȧ·u*``. Same
            exactness properties as ``"implicit_reduced"``.
            Raises ``ValueError`` on ``Newton``.

        **Iteration-path group** — Differentiate through the loop body
        using ``equinox.internal.while_loop``. The gradient depends on
        the actual iteration trajectory, including the initial guess.

        ``"lax"``:
            Equivalent to ``jax.lax.while_loop``. Supports JVP
            (forward-mode) natively via tangent propagation through
            the loop. **Does not support VJP** (``jax.grad`` will
            error). Useful for forward-mode sensitivity or when no
            backward pass is needed.

        ``"checkpointed"``:
            Uses binomial checkpointing for O(√n) memory VJP.
            **Does not support JVP** (forward-mode will error).
            Good for memory-constrained backward-through-the-loop
            scenarios.

        ``"bounded"``:
            Supports both JVP and VJP by unrolling the loop up to
            ``maxiter`` in a base-16 recursive structure. Memory is
            O(n / base). Both AD modes work, but compilation time
            and memory grow with ``maxiter``. Suitable for moderate
            iteration counts where you want full flexibility.

        **No gradient:**

        ``"detach"``:
            Wraps the forward solve in ``jax.lax.stop_gradient``.
            Gradients are zero. Useful for "simulate then evaluate"
            workflows where the physics solve should not contribute
            to the loss gradient, or for debugging.
    """

    linear_solver: LinearSolver
    maxiter: int = 100
    tol: float = 1e-5
    throw: bool = True
    initial_from_prev: bool = True
    stop_gradient_on_initial_guess: bool = True
    diff_mode: DiffMode = "implicit"
    adjoint_linear_solver: LinearSolver | None = None

    @abstractmethod
    def _step(self, residuum: Residuum, u_current, u_prev):
        """Perform a single iteration."""
        ...

    def _resolve_lax(self, residuum: Residuum, u_init, u_prev):
        """Resolve using jax.lax.while_loop (no VJP support)."""
        init_norm = tree_norm(residuum.full_residual(u_init, u_prev))

        def body_fn(carry):
            u_current, i, has_converged = carry
            u_next = self._step(residuum, u_current, u_prev)
            residuum_norm = tree_norm(residuum.full_residual(u_next, u_prev))
            has_converged = residuum_norm <= self.tol * init_norm
            return (u_next, i + 1, has_converged)

        def cond_fn(carry):
            u_current, i, has_converged = carry
            return (i < self.maxiter) & (jnp.logical_not(has_converged))

        u_final, n_iters, converged = jax.lax.while_loop(
            cond_fn, body_fn, (u_init, 0, False)
        )
        return u_final, n_iters, converged

    def _resolve_eqi(self, residuum: Residuum, u_init, u_prev, *, kind):
        """Resolve using equinox.internal.while_loop with given kind."""
        init_norm = tree_norm(residuum.full_residual(u_init, u_prev))

        def body_fn(carry):
            u_current, i, has_converged = carry
            u_next = self._step(residuum, u_current, u_prev)
            residuum_norm = tree_norm(residuum.full_residual(u_next, u_prev))
            has_converged = residuum_norm <= self.tol * init_norm
            return (u_next, i + 1, has_converged)

        def cond_fn(carry):
            u_current, i, has_converged = carry
            return (i < self.maxiter) & (jnp.logical_not(has_converged))

        u_final, n_iters, converged = eqi.while_loop(
            cond_fn,
            body_fn,
            (u_init, 0, False),
            kind=kind,
            max_steps=self.maxiter,
        )
        return u_final, n_iters, converged

    def resolve(self, residuum: Residuum, u_init, u_prev):
        """Run the iteration loop via ``jax.lax.while_loop``.

        Public for diagnostics. Always uses ``_resolve_lax`` regardless of
        ``diff_mode``, since diagnostics do not need custom AD rules.
        """
        return self._resolve_lax(residuum, u_init, u_prev)

    def _solve_forward(self, residuum: Residuum, u_prev):
        """Forward solve: initial guess + iterate + throw check."""
        u_init = self.get_initial_guess(u_prev)
        u_final, n_iters, converged = self.resolve(residuum, u_init, u_prev)
        if self.throw:
            u_final = eqx.error_if(
                u_final,
                jnp.logical_not(converged),
                "Nonlinear solver did not converge.",
            )
        return u_final

    def _solve_iterpath(self, residuum: Residuum, u_prev):
        """Solve using equinox while_loop (iteration-path differentiation)."""
        u_init = self.get_initial_guess(u_prev)
        u_final, n_iters, converged = self._resolve_eqi(
            residuum, u_init, u_prev, kind=self.diff_mode
        )
        if self.throw:
            u_final = eqx.error_if(
                u_final,
                jnp.logical_not(converged),
                "Nonlinear solver did not converge.",
            )
        return u_final

    # ─── IFT: implicit (custom_vjp) ───

    def _solve_implicit(self, residuum: Residuum, u_prev):
        """Solve with custom_vjp implementing IFT adjoint."""
        # Partition differentiable arrays from static structure
        diff_args, static_args = eqx.partition((self, residuum), eqx.is_array)

        @jax.custom_vjp
        def solve(diff_args, u_prev):
            solver, residuum = eqx.combine(diff_args, static_args)
            return solver._solve_forward(residuum, u_prev)

        def solve_fwd(diff_args, u_prev):
            u_star = solve(diff_args, u_prev)
            return u_star, (diff_args, u_star, u_prev)

        def solve_bwd(res, g):
            diff_args, u_star, u_prev = res
            solver, residuum = eqx.combine(diff_args, static_args)

            # Full residual: R(u, u_prev) with all params
            # At convergence R(u*, u_prev) = 0
            # IFT: dR/du* · du*/dp = -dR/dp
            # Adjoint: (dR/du*)^T lambda = g => grad_p = -lambda^T dR/dp

            # Build the Jacobian-transpose-vector product for dR/du*
            def residual_of_u(u):
                return residuum.full_residual(u, u_prev)

            _, vjp_residual_u = jax.vjp(residual_of_u, u_star)

            def jac_T_vec(v):
                """(dR/du*)^T v"""
                return vjp_residual_u(v)[0]

            # Solve adjoint system: (dR/du*)^T lambda = g
            adj_solver = _nothrow(
                solver.adjoint_linear_solver
                if solver.adjoint_linear_solver is not None
                else solver.linear_solver
            )
            lambda_ = adj_solver(jac_T_vec, g)

            # Propagate through all parameters: grad = -lambda^T dR/d(params, u_prev)
            def residual_of_params(diff_args, u_prev):
                _, residuum_inner = eqx.combine(diff_args, static_args)
                return residuum_inner.full_residual(u_star, u_prev)

            _, vjp_params = jax.vjp(residual_of_params, diff_args, u_prev)
            g_diff_args, g_u_prev = vjp_params(-lambda_)

            return g_diff_args, g_u_prev

        solve.defvjp(solve_fwd, solve_bwd)
        return solve(diff_args, u_prev)

    # ─── IFT: implicit_jvp (custom_jvp) ───

    def _solve_implicit_jvp(self, residuum: Residuum, u_prev):
        """Solve with custom_jvp implementing IFT tangent solve."""
        diff_args, static_args = eqx.partition((self, residuum), eqx.is_array)

        @jax.custom_jvp
        def solve(diff_args, u_prev):
            solver, residuum = eqx.combine(diff_args, static_args)
            return solver._solve_forward(residuum, u_prev)

        @solve.defjvp
        def solve_jvp(primals, tangents):
            diff_args, u_prev = primals
            diff_args_dot, u_prev_dot = tangents

            u_star = solve(diff_args, u_prev)
            solver, residuum = eqx.combine(diff_args, static_args)

            # IFT tangent: (dR/du*) u_dot = -(dR/d_params dot + dR/du_prev u_prev_dot)
            def residual_of_params(diff_args, u_prev):
                _, residuum_inner = eqx.combine(diff_args, static_args)
                return residuum_inner.full_residual(u_star, u_prev)

            # Push tangents through R w.r.t. params and u_prev
            _, rhs_tangent = jax.jvp(
                residual_of_params,
                (diff_args, u_prev),
                (diff_args_dot, u_prev_dot),
            )

            # Jacobian-vector product for dR/du*
            def residual_of_u(u):
                return residuum.full_residual(u, u_prev)

            def jac_vec(v):
                """(dR/du*) v"""
                _, jvp_val = jax.jvp(residual_of_u, (u_star,), (v,))
                return jvp_val

            # Solve tangent system: (dR/du*) u_dot = -rhs_tangent
            # Use custom_linear_solve so JAX can transpose (for VJP)
            tangent_solver = _nothrow(solver.linear_solver)
            u_star_dot = jax.lax.custom_linear_solve(
                jac_vec,
                -rhs_tangent,
                solve=lambda mv, b: tangent_solver(mv, b),
                transpose_solve=lambda mv_T, g: tangent_solver(mv_T, g),
            )

            return u_star, u_star_dot

        return solve(diff_args, u_prev)

    # ─── Dispatch ───

    def __call__(self, residuum: Residuum, u_prev):
        """Solve for u_next given the residuum and u_prev.

        The ``diff_mode`` field controls how gradients propagate through the
        solve. See class docstring for available modes.
        """
        if self.diff_mode not in _VALID_DIFF_MODES:
            raise ValueError(f"Unknown diff_mode: {self.diff_mode!r}")

        if self.diff_mode in _REDUCED_MODES:
            raise ValueError(
                f"diff_mode={self.diff_mode!r} is only supported by Picard, "
                f"not {type(self).__name__}."
            )

        if self.diff_mode == "implicit":
            return self._solve_implicit(residuum, u_prev)
        elif self.diff_mode == "implicit_jvp":
            return self._solve_implicit_jvp(residuum, u_prev)
        elif self.diff_mode in _ITERPATH_MODES:
            return self._solve_iterpath(residuum, u_prev)
        else:  # detach
            return jax.lax.stop_gradient(self._solve_forward(residuum, u_prev))

    def get_initial_guess(self, u_prev):
        """Return the initial guess for u_next."""
        if self.initial_from_prev:
            if self.stop_gradient_on_initial_guess:
                return jax.lax.stop_gradient(u_prev)
            else:
                return u_prev
        else:
            return jax.tree.map(jnp.zeros_like, u_prev)

    # ─── Nonlinear solver diagnostics ───

    def diagnose(self, residuum: Residuum, u_prev) -> int:
        """Return the number of iterations needed to converge."""
        u_init = self.get_initial_guess(u_prev)
        _, n_iters, _ = self.resolve(residuum, u_init, u_prev)
        return n_iters

    def get_all_iterates(self, residuum: Residuum, u_prev, *, include_init=False):
        """Return all iterates as an array of shape (n_iter, *u.shape).

        Always runs for maxiter steps; iterates beyond convergence are not
        meaningful.
        """

        def scan_fn(u_current, _):
            u_next = self._step(residuum, u_current, u_prev)
            return u_next, u_next

        u_init = self.get_initial_guess(u_prev)
        _, iterates = jax.lax.scan(scan_fn, u_init, None, length=self.maxiter)
        if include_init:
            iterates = jax.tree.map(
                lambda its, init: jnp.concatenate([init[None], its], axis=0),
                iterates,
                u_init,
            )
        return iterates

    def get_error_iterates(self, residuum: Residuum, u_prev):
        """Return a scalar error metric at each iteration.

        More memory-efficient than get_all_iterates since only a scalar
        per iteration is stored (via scan), not the full state.

        Returns an array of shape (maxiter,).
        """
        u_init = self.get_initial_guess(u_prev)
        init_error = tree_norm(residuum.full_residual(u_init, u_prev))

        def scan_fn(u_current, _):
            u_next = self._step(residuum, u_current, u_prev)
            error = tree_norm(residuum.full_residual(u_next, u_prev)) / init_error
            return u_next, error

        _, errors = jax.lax.scan(scan_fn, u_init, None, length=self.maxiter)
        return errors

    # ─── Linear solver diagnostics (forwarded) ───

    def _assemble_linear_system(self, residuum: Residuum, u_current_iter, u_prev):
        """Assemble the linear system (lin_fun, rhs) at a nonlinear iterate.

        Subclasses override this to match their iteration scheme.
        """
        raise NotImplementedError

    def diagnose_linsolve(self, residuum: Residuum, u_current_iter, u_prev) -> int:
        """Return the number of linear solver iterations at one specific
        nonlinear iteration point.

        Not all linear solvers support this.
        """
        lin_fun, rhs = self._assemble_linear_system(residuum, u_current_iter, u_prev)
        return self.linear_solver.diagnose(lin_fun, rhs)

    def get_all_iterates_linsolve(
        self, residuum: Residuum, u_current_iter, u_prev, *, include_init=False
    ):
        """Return all linear solver iterates at one specific nonlinear
        iteration point.

        Not all linear solvers support this.
        """
        lin_fun, rhs = self._assemble_linear_system(residuum, u_current_iter, u_prev)
        return self.linear_solver.get_all_iterates(
            lin_fun, rhs, include_init=include_init
        )

    def get_error_iterates_linsolve(self, residuum: Residuum, u_current_iter, u_prev):
        """Return scalar error per linear solver iteration at one specific
        nonlinear iteration point.

        Not all linear solvers support this.
        """
        lin_fun, rhs = self._assemble_linear_system(residuum, u_current_iter, u_prev)
        return self.linear_solver.get_error_iterates(lin_fun, rhs)


class Picard(Solver):
    """Picard (fixed-point) iteration solver.

    Supports all diff_mode values including the Picard-specific
    ``"implicit_reduced"`` and ``"implicit_reduced_jvp"`` modes that use the
    assembled ``A(u*)x = b`` decomposition instead of the full Jacobian.
    """

    def _step(self, residuum: Residuum, u_current, u_prev):
        lin_fun, rhs = self._assemble_linear_system(residuum, u_current, u_prev)
        return self.linear_solver(lin_fun, rhs)

    def _assemble_linear_system(self, residuum, u_current_iter, u_prev):
        lin_fun = residuum.assemble_lin_fun(u_current_iter)
        rhs = residuum.assemble_rhs(u_prev)
        return lin_fun, rhs

    # ─── Picard-specific: implicit_reduced (custom_vjp) ───

    def _solve_implicit_reduced(self, residuum: Residuum, u_prev):
        """Reduced IFT via Picard A(u*)x=b decomposition (custom_vjp)."""
        diff_args, static_args = eqx.partition((self, residuum), eqx.is_array)

        @jax.custom_vjp
        def solve(diff_args, u_prev):
            solver, residuum = eqx.combine(diff_args, static_args)
            return solver._solve_forward(residuum, u_prev)

        def solve_fwd(diff_args, u_prev):
            u_star = solve(diff_args, u_prev)
            return u_star, (diff_args, u_star, u_prev)

        def solve_bwd(res, g):
            diff_args, u_star, u_prev = res
            solver, residuum = eqx.combine(diff_args, static_args)

            # 1. Adjoint solve: A(u*)^T lambda = g
            lin_fun = residuum.assemble_lin_fun(u_star)
            lin_fun_T = jax.linear_transpose(lin_fun, u_star)

            def lin_fun_T_flat(v):
                # linear_transpose returns a tuple of one element
                return lin_fun_T(v)[0]

            adj_solver = _nothrow(
                solver.adjoint_linear_solver
                if solver.adjoint_linear_solver is not None
                else solver.linear_solver
            )
            lambda_ = adj_solver(lin_fun_T_flat, g)

            # 2. Propagate through RHS assembly: lambda^T (db/d_params)
            def rhs_of_params(diff_args, u_prev):
                _, residuum_inner = eqx.combine(diff_args, static_args)
                return residuum_inner.assemble_rhs(u_prev)

            _, vjp_rhs = jax.vjp(rhs_of_params, diff_args, u_prev)
            g_from_rhs_diff, g_from_rhs_uprev = vjp_rhs(lambda_)

            # 3. Propagate through operator assembly: -lambda^T (dA/d_params . u*)
            def op_applied_of_params(diff_args):
                _, residuum_inner = eqx.combine(diff_args, static_args)
                lf = residuum_inner.assemble_lin_fun(u_star)
                return lf(u_star)

            _, vjp_op = jax.vjp(op_applied_of_params, diff_args)
            (g_from_A_diff,) = vjp_op(-lambda_)

            # 4. Combine
            g_diff_args = jax.tree.map(
                lambda a, b: a + b, g_from_rhs_diff, g_from_A_diff
            )
            g_u_prev = g_from_rhs_uprev

            return g_diff_args, g_u_prev

        solve.defvjp(solve_fwd, solve_bwd)
        return solve(diff_args, u_prev)

    # ─── Picard-specific: implicit_reduced_jvp (custom_jvp) ───

    def _solve_implicit_reduced_jvp(self, residuum: Residuum, u_prev):
        """Reduced IFT via Picard A(u*)x=b decomposition (custom_jvp)."""
        diff_args, static_args = eqx.partition((self, residuum), eqx.is_array)

        @jax.custom_jvp
        def solve(diff_args, u_prev):
            solver, residuum = eqx.combine(diff_args, static_args)
            return solver._solve_forward(residuum, u_prev)

        @solve.defjvp
        def solve_jvp(primals, tangents):
            diff_args, u_prev = primals
            diff_args_dot, u_prev_dot = tangents

            u_star = solve(diff_args, u_prev)
            solver, residuum = eqx.combine(diff_args, static_args)

            # 1. Push tangents through RHS assembly
            def rhs_of_params(diff_args, u_prev):
                _, residuum_inner = eqx.combine(diff_args, static_args)
                return residuum_inner.assemble_rhs(u_prev)

            _, b_dot = jax.jvp(
                rhs_of_params,
                (diff_args, u_prev),
                (diff_args_dot, u_prev_dot),
            )

            # 2. Push tangents through operator assembly at u*
            def op_applied_of_params(diff_args):
                _, residuum_inner = eqx.combine(diff_args, static_args)
                lf = residuum_inner.assemble_lin_fun(u_star)
                return lf(u_star)

            _, A_dot_u_star = jax.jvp(
                op_applied_of_params,
                (diff_args,),
                (diff_args_dot,),
            )

            # 3. Solve tangent system: A(u*) u_dot = b_dot - A_dot_u_star
            lin_fun = residuum.assemble_lin_fun(u_star)
            rhs_tangent = jax.tree.map(lambda a, b: a - b, b_dot, A_dot_u_star)
            tangent_solver = _nothrow(solver.linear_solver)
            u_star_dot = jax.lax.custom_linear_solve(
                lin_fun,
                rhs_tangent,
                solve=lambda mv, b: tangent_solver(mv, b),
                transpose_solve=lambda mv_T, g: tangent_solver(mv_T, g),
            )

            return u_star, u_star_dot

        return solve(diff_args, u_prev)

    # ─── Dispatch override ───

    def __call__(self, residuum: Residuum, u_prev):
        if self.diff_mode == "implicit_reduced":
            return self._solve_implicit_reduced(residuum, u_prev)
        elif self.diff_mode == "implicit_reduced_jvp":
            return self._solve_implicit_reduced_jvp(residuum, u_prev)
        else:
            return super().__call__(residuum, u_prev)


class Newton(Solver):
    """Newton-Raphson solver using autodiff Jacobian."""

    def _step(self, residuum: Residuum, u_current, u_prev):
        lin_fun, neg_residual = self._assemble_linear_system(
            residuum, u_current, u_prev
        )
        delta = self.linear_solver(lin_fun, neg_residual)
        return u_current + delta

    def _assemble_linear_system(self, residuum, u_current_iter, u_prev):
        residual, lin_fun = jax.linearize(
            lambda u: residuum.full_residual(u, u_prev=u_prev),
            u_current_iter,
        )
        return lin_fun, -residual
