from abc import ABC, abstractmethod

import equinox as eqx
import jax
import jax.numpy as jnp

from picardax._rhs import RHS


class Residuum(ABC, eqx.Module):
    """Abstract base class for time-discrete residuals."""

    rhs: RHS

    @abstractmethod
    def linearized_residual(self, u_next, u_prev, u_linearized):
        """Compute R(u_next, u_prev; u_lin). Zero at the solution."""
        ...

    def full_residual(self, u_next, u_prev):
        """Non-linearized residual R(u, u_prev; u) for Newton."""
        return self.linearized_residual(u_next, u_prev, u_next)

    def assemble_rhs(self, u_prev):
        """Extract constant vector b = -R(0, u_prev; 0)."""
        zero = jnp.zeros_like(u_prev)
        return -self.linearized_residual(zero, u_prev, zero)

    def assemble_lin_fun(self, u_linearized):
        """Return callable A(u_lin): u -> R(u, 0, u_lin)."""
        zero = jnp.zeros_like(u_linearized)
        return lambda u: self.linearized_residual(u, zero, u_linearized)

    def materialize_system_matrix(self, u_linearized):
        """Materialize A(u_lin) as a dense matrix.

        Warning: can be very large. Useful for inspecting sparsity patterns
        (e.g. via plt.spy).
        """
        lin_fun = self.assemble_lin_fun(u_linearized)
        return jax.jacfwd(lambda u: lin_fun(u.reshape(u_linearized.shape)).flatten())(
            jnp.zeros_like(u_linearized).flatten()
        )

    def materialize_rhs_assembly_matrix(self, u_prev):
        """Materialize the Jacobian of the RHS assembly.

        Constant if the method is fully implicit or the PDE is linear.
        """
        return jax.jacfwd(
            lambda u: self.assemble_rhs(u.reshape(u_prev.shape)).flatten()
        )(u_prev.flatten())


class ThetaResiduum(Residuum):
    """Theta method time discretization.

    theta=0: explicit Euler, theta=0.5: Crank-Nicolson, theta=1: implicit Euler.
    """

    theta: float
    dt: float

    def __check_init__(self):
        if not (0.0 <= self.theta <= 1.0):
            raise ValueError(f"theta must be in [0, 1], got {self.theta}")

    def linearized_residual(self, u_next, u_prev, u_linearized):
        F_next = self.rhs.linearized_operator(u_next, u_linearized)
        F_prev = self.rhs.linearized_operator(u_prev, u_prev)
        return (
            u_next
            - u_prev
            - self.dt * (self.theta * F_next + (1 - self.theta) * F_prev)
        )
