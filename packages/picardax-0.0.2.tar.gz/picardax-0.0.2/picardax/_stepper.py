import equinox as eqx

from picardax._residuum import Residuum
from picardax._solver import Solver


class Stepper(eqx.Module):
    """Thin orchestrator that composes a Residuum and a Solver."""

    residuum: Residuum
    solver: Solver

    def __call__(self, u):
        return self.solver(self.residuum, u)

    # ─── Nonlinear solver diagnostics ───

    def diagnose(self, u) -> int:
        """Return the number of nonlinear iterations needed to converge."""
        return self.solver.diagnose(self.residuum, u)

    def get_all_iterates(self, u, *, include_init=False):
        """Return all nonlinear iterates as an array."""
        return self.solver.get_all_iterates(self.residuum, u, include_init=include_init)

    def get_error_iterates(self, u):
        """Return scalar error per nonlinear iteration."""
        return self.solver.get_error_iterates(self.residuum, u)

    # ─── Linear solver diagnostics ───

    def diagnose_linsolve(self, u_current_iter, u_prev) -> int:
        """Return the number of linear solver iterations at a given
        nonlinear iteration point."""
        return self.solver.diagnose_linsolve(self.residuum, u_current_iter, u_prev)

    def get_all_iterates_linsolve(self, u_current_iter, u_prev, *, include_init=False):
        """Return all linear solver iterates at a given nonlinear iteration
        point."""
        return self.solver.get_all_iterates_linsolve(
            self.residuum, u_current_iter, u_prev, include_init=include_init
        )

    def get_error_iterates_linsolve(self, u_current_iter, u_prev):
        """Return scalar error per linear solver iteration at a given
        nonlinear iteration point."""
        return self.solver.get_error_iterates_linsolve(
            self.residuum, u_current_iter, u_prev
        )
