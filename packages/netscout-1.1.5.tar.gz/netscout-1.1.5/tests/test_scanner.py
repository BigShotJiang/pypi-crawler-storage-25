"""Tests for scanner — host result dataclass and OS guessing."""

import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from netscout.scanner import HostResult, PortInfo, guess_os_from_ttl, WELL_KNOWN_SERVICES


class TestGuessOsFromTtl:
    def test_linux(self): assert guess_os_from_ttl(64) == "Linux/Unix"
    def test_linux_decremented(self): assert guess_os_from_ttl(60) == "Linux/Unix"
    def test_windows(self): assert guess_os_from_ttl(128) == "Windows"
    def test_windows_decremented(self): assert guess_os_from_ttl(120) == "Windows"
    def test_cisco(self): assert guess_os_from_ttl(255) == "Cisco/Network OS"
    def test_network_device(self): assert guess_os_from_ttl(10) == "Network Device / Unknown"


class TestHostResult:
    def test_default_values(self):
        hr = HostResult(ip="1.2.3.4")
        assert hr.alive is False
        assert hr.open_ports == []
        assert hr.port_details == {}

    def test_with_ports(self):
        hr = HostResult(ip="1.2.3.4", alive=True, open_ports=[22, 80],
                        port_details={22: PortInfo(port=22, state="open", service="ssh")})
        assert 22 in hr.open_ports
        assert hr.port_details[22].service == "ssh"


class TestWellKnownServices:
    def test_common_ports(self):
        assert WELL_KNOWN_SERVICES[22] == "ssh"
        assert WELL_KNOWN_SERVICES[80] == "http"
        assert WELL_KNOWN_SERVICES[443] == "https"
        assert WELL_KNOWN_SERVICES[3389] == "ms-wbt-server"
