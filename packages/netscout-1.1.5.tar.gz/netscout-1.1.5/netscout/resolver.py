"""
DNS forward & reverse resolution with in-memory cache.

All lookups run in an asyncio thread-pool to avoid blocking the event loop.
Batch resolution fans out concurrently via asyncio.gather.
"""

from __future__ import annotations

import asyncio
import socket
from functools import lru_cache
from typing import Sequence

# ---------------------------------------------------------------------------
# Thread-safe in-process cache (keeps results across calls inside one run)
# ---------------------------------------------------------------------------

_reverse_cache: dict[str, str] = {}
_forward_cache: dict[str, str] = {}

# ---------------------------------------------------------------------------
# Low-level (sync, called inside executor)
# ---------------------------------------------------------------------------


def _reverse_lookup_sync(ip: str) -> str:
    """Blocking reverse DNS lookup. Returns hostname or empty string."""
    try:
        hostname, _, _ = socket.gethostbyaddr(ip)
        return hostname
    except (socket.herror, socket.gaierror, OSError):
        return ""


def _forward_lookup_sync(hostname: str) -> str:
    """Blocking forward DNS lookup. Returns IP or empty string."""
    try:
        return socket.gethostbyname(hostname)
    except (socket.gaierror, socket.herror, OSError):
        return ""


# ---------------------------------------------------------------------------
# Async wrappers
# ---------------------------------------------------------------------------


async def reverse_lookup(ip: str) -> str:
    """Non-blocking reverse DNS lookup with cache."""
    if ip in _reverse_cache:
        return _reverse_cache[ip]
    loop = asyncio.get_running_loop()
    result = await loop.run_in_executor(None, _reverse_lookup_sync, ip)
    _reverse_cache[ip] = result
    return result


async def forward_lookup(hostname: str) -> str:
    """Non-blocking forward DNS lookup with cache."""
    if hostname in _forward_cache:
        return _forward_cache[hostname]
    loop = asyncio.get_running_loop()
    result = await loop.run_in_executor(None, _forward_lookup_sync, hostname)
    _forward_cache[hostname] = result
    return result


# ---------------------------------------------------------------------------
# Batch operations
# ---------------------------------------------------------------------------


async def batch_reverse(ips: Sequence[str], concurrency: int = 150) -> dict[str, str]:
    """
    Resolve many IPs to hostnames concurrently.

    Returns dict mapping ip → hostname (empty string if unresolvable).
    """
    sem = asyncio.Semaphore(concurrency)

    async def _resolve(ip: str) -> tuple[str, str]:
        async with sem:
            hostname = await reverse_lookup(ip)
            return ip, hostname

    results = await asyncio.gather(*(_resolve(ip) for ip in ips))
    return dict(results)


async def batch_forward(
    hostnames: Sequence[str], concurrency: int = 150
) -> dict[str, str]:
    """
    Resolve many hostnames to IPs concurrently.

    Returns dict mapping hostname → ip (empty string if unresolvable).
    """
    sem = asyncio.Semaphore(concurrency)

    async def _resolve(h: str) -> tuple[str, str]:
        async with sem:
            ip = await forward_lookup(h)
            return h, ip

    results = await asyncio.gather(*(_resolve(h) for h in hostnames))
    return dict(results)


def clear_caches() -> None:
    """Flush DNS caches (useful in tests)."""
    _reverse_cache.clear()
    _forward_cache.clear()
