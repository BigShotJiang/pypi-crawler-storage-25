"""
Multi-CIDR input parsing, expansion, deduplication, and merging.

Handles:
  - CIDR notation: 10.10.10.0/24
  - Single IPs:   10.10.10.5
  - Ranges:       10.10.10.1-50  OR  10.10.10.1-10.10.10.254
  - Hostnames:    auto-resolved to IP
"""

from __future__ import annotations

import ipaddress
import re
import socket
from dataclasses import dataclass, field
from pathlib import Path
from typing import Sequence

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------
MAX_HOSTS_NO_FORCE = 65_536

# ---------------------------------------------------------------------------
# Dataclass for parsed input
# ---------------------------------------------------------------------------

@dataclass
class TargetSpec:
    """Represents a parsed target specification."""
    raw: str
    networks: list[ipaddress.IPv4Network] = field(default_factory=list)
    individual_ips: list[ipaddress.IPv4Address] = field(default_factory=list)
    resolved_hostname: str = ""
    error: str = ""


# ---------------------------------------------------------------------------
# Parsing helpers
# ---------------------------------------------------------------------------

_RANGE_SHORT_RE = re.compile(
    r"^(\d{1,3}\.\d{1,3}\.\d{1,3})\.(\d{1,3})-(\d{1,3})$"
)
_RANGE_FULL_RE = re.compile(
    r"^(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})-(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})$"
)


def _parse_single(raw: str) -> TargetSpec:
    """Parse a single target string into a TargetSpec."""
    spec = TargetSpec(raw=raw)
    text = raw.strip()
    if not text:
        spec.error = "empty input"
        return spec

    # 1) Try CIDR
    if "/" in text:
        try:
            net = ipaddress.IPv4Network(text, strict=False)
            spec.networks.append(net)
            return spec
        except (ipaddress.AddressValueError, ValueError) as exc:
            spec.error = str(exc)
            return spec

    # 2) Try short range: 10.10.10.1-50
    m = _RANGE_SHORT_RE.match(text)
    if m:
        prefix, start_s, end_s = m.group(1), int(m.group(2)), int(m.group(3))
        if start_s > end_s or end_s > 255:
            spec.error = f"invalid range {text}"
            return spec
        for octet in range(start_s, end_s + 1):
            spec.individual_ips.append(ipaddress.IPv4Address(f"{prefix}.{octet}"))
        return spec

    # 3) Try full range: 10.10.10.1-10.10.10.254
    m = _RANGE_FULL_RE.match(text)
    if m:
        try:
            start_ip = ipaddress.IPv4Address(m.group(1))
            end_ip = ipaddress.IPv4Address(m.group(2))
        except ipaddress.AddressValueError as exc:
            spec.error = str(exc)
            return spec
        if int(start_ip) > int(end_ip):
            spec.error = f"start > end in range {text}"
            return spec
        for ip_int in range(int(start_ip), int(end_ip) + 1):
            spec.individual_ips.append(ipaddress.IPv4Address(ip_int))
        return spec

    # 4) Try single IP
    try:
        addr = ipaddress.IPv4Address(text)
        spec.individual_ips.append(addr)
        return spec
    except ipaddress.AddressValueError:
        pass

    # 5) Try hostname resolution
    try:
        resolved = socket.gethostbyname(text)
        spec.individual_ips.append(ipaddress.IPv4Address(resolved))
        spec.resolved_hostname = text
        return spec
    except (socket.gaierror, socket.herror) as exc:
        spec.error = f"cannot resolve hostname '{text}': {exc}"
        return spec


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def parse_targets(raw_inputs: Sequence[str]) -> tuple[list[TargetSpec], list[str]]:
    """
    Parse a list of raw target strings.

    Returns (specs, errors) where *specs* is successfully parsed targets
    and *errors* is a list of human-readable error strings.
    """
    specs: list[TargetSpec] = []
    errors: list[str] = []
    for raw in raw_inputs:
        # Split on commas and whitespace for multi-target pasting
        tokens = re.split(r"[,\s]+", raw.strip())
        for tok in tokens:
            if not tok:
                continue
            spec = _parse_single(tok)
            if spec.error:
                errors.append(f"  ✗ {tok}: {spec.error}")
            else:
                specs.append(spec)
    return specs, errors


def load_targets_file(path: str | Path) -> list[str]:
    """Read one target per line from a file, stripping comments & blanks."""
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(f"targets file not found: {p}")
    lines: list[str] = []
    for line in p.read_text().splitlines():
        line = line.strip()
        if line and not line.startswith("#"):
            lines.append(line)
    return lines


def deduplicate_and_merge(
    specs: list[TargetSpec],
) -> tuple[list[ipaddress.IPv4Network], int]:
    """
    Collapse all parsed specs into a minimal set of non-overlapping networks.

    Returns (networks, total_hosts).
    """
    all_nets: list[ipaddress.IPv4Network] = []
    for spec in specs:
        all_nets.extend(spec.networks)
        for ip in spec.individual_ips:
            all_nets.append(ipaddress.IPv4Network(f"{ip}/32"))

    collapsed = list(ipaddress.collapse_addresses(all_nets))
    total = sum(net.num_addresses for net in collapsed)
    return collapsed, total


def expand_hosts(networks: list[ipaddress.IPv4Network]) -> list[ipaddress.IPv4Address]:
    """Expand collapsed networks into an ordered list of host addresses."""
    hosts: list[ipaddress.IPv4Address] = []
    for net in networks:
        if net.prefixlen == 32:
            hosts.append(net.network_address)
        else:
            hosts.extend(net.hosts())
    return hosts


def check_host_count(total: int, force: bool) -> bool:
    """
    Return True if scan should proceed.
    Raises SystemExit if total > MAX_HOSTS_NO_FORCE and --force not set.
    """
    if total > MAX_HOSTS_NO_FORCE and not force:
        raise SystemExit(
            f"[!] Target range contains {total:,} hosts (limit: {MAX_HOSTS_NO_FORCE:,}). "
            f"Use --force to proceed."
        )
    return True
