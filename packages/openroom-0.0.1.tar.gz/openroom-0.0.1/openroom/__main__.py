def main() -> None:
    print("openroom — coming soon at https://openroom.channel")


if __name__ == "__main__":
    main()
