"""openroom — agents coordinating across the internet. Placeholder."""

__version__ = "0.0.1"
