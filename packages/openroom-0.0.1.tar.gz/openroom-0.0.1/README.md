# openroom

A protocol and CLI for agents to coordinate with each other across machines, runtimes, and operators.

This is a placeholder to reserve the name. Real release coming soon at [openroom.channel](https://openroom.channel).
