"""Known MCP client config path registry.

Maps client names to their config file paths on macOS, Linux, and Windows.
Paths are annotated as verified (confirmed via official docs) or
unverified (extrapolated from naming conventions).
"""

from __future__ import annotations

import json
import os
import platform as _platform
import sys
from dataclasses import dataclass
from enum import Enum
from pathlib import Path


def _log(msg: str) -> None:
    print(f"[vloex-discovery] {msg}", file=sys.stderr, flush=True)


class ConfigFormat(str, Enum):
    """Config file format variants across MCP clients."""

    STANDARD = "standard"
    VSCODE = "vscode"
    ZED = "zed"
    CONTINUE_ARRAY = "continue"


@dataclass
class ClientConfig:
    """A known MCP client and its config path."""

    name: str
    config_path: str
    config_format: ConfigFormat
    verified: bool
    platform: str = "all"
    key_in_settings: str | None = None
    notes: str | None = None


@dataclass
class DiscoveredClient:
    """A discovered MCP client with its servers."""

    client_name: str
    config_path: Path
    config_format: ConfigFormat
    servers: dict[str, dict]
    verified: bool


# ---------------------------------------------------------------------------
# Registry — Top 20 clients
# ---------------------------------------------------------------------------

_KNOWN_CLIENTS: list[ClientConfig] = [
    # ── Verified (confirmed via official docs or testing) ────────
    ClientConfig(
        "Claude Code",
        "~/.claude/mcp.json",
        ConfigFormat.STANDARD,
        verified=True,
    ),
    ClientConfig(
        "Claude Code (managed)",
        "/Library/Application Support/ClaudeCode/managed-mcp.json",
        ConfigFormat.STANDARD,
        verified=True,
        platform="macos",
    ),
    ClientConfig(
        "Cursor",
        "~/.cursor/mcp.json",
        ConfigFormat.STANDARD,
        verified=True,
    ),
    ClientConfig(
        "Cursor (project)",
        ".cursor/mcp.json",
        ConfigFormat.STANDARD,
        verified=True,
        notes="project-level, relative to workspace root — skipped in Layer 1",
    ),
    ClientConfig(
        "VS Code",
        "~/Library/Application Support/Code/User/settings.json",
        ConfigFormat.VSCODE,
        verified=True,
        platform="macos",
        key_in_settings="mcp.servers",
    ),
    ClientConfig(
        "VS Code",
        "~/.config/Code/User/settings.json",
        ConfigFormat.VSCODE,
        verified=True,
        platform="linux",
        key_in_settings="mcp.servers",
    ),
    ClientConfig(
        "Windsurf",
        "~/.codeium/windsurf/mcp_config.json",
        ConfigFormat.STANDARD,
        verified=True,
        platform="macos",
    ),
    ClientConfig(
        "Cline",
        "~/Library/Application Support/Code/User/globalStorage/"
        "saoudrizwan.claude-dev/settings/cline_mcp_settings.json",
        ConfigFormat.STANDARD,
        verified=True,
        platform="macos",
    ),
    ClientConfig(
        "Continue",
        "~/.continue/config.json",
        ConfigFormat.CONTINUE_ARRAY,
        verified=True,
        key_in_settings="mcpServers",
    ),
    ClientConfig(
        "Zed",
        "~/.config/zed/settings.json",
        ConfigFormat.ZED,
        verified=True,
        key_in_settings="context_servers",
    ),
    ClientConfig(
        "JetBrains",
        "~/Library/Application Support/JetBrains/*/mcp.json",
        ConfigFormat.STANDARD,
        verified=True,
        platform="macos",
        notes="glob pattern — multiple IDE versions",
    ),
    # ── Unverified (extrapolated from naming conventions) ────────
    ClientConfig("Aider", "~/.aider/mcp.json", ConfigFormat.STANDARD, verified=False),
    ClientConfig(
        "Emacs (mcp.el)", "~/.emacs.d/mcp-servers.json", ConfigFormat.STANDARD, verified=False
    ),
    ClientConfig(
        "Neovim (mcphub)", "~/.config/nvim/mcphub.json", ConfigFormat.STANDARD, verified=False
    ),
    ClientConfig("Warp", "~/.warp/mcp.json", ConfigFormat.STANDARD, verified=False),
    ClientConfig("Amazon Q", "~/.aws/amazonq/mcp.json", ConfigFormat.STANDARD, verified=False),
    ClientConfig(
        "Sourcegraph Cody", "~/.sourcegraph/cody/mcp.json", ConfigFormat.STANDARD, verified=False
    ),
    ClientConfig("Genkit", "~/.genkit/mcp.json", ConfigFormat.STANDARD, verified=False),
    ClientConfig(
        "Cline",
        "~/.config/Code/User/globalStorage/saoudrizwan.claude-dev/settings/cline_mcp_settings.json",
        ConfigFormat.STANDARD,
        verified=False,
        platform="linux",
    ),
    ClientConfig(
        "Windsurf",
        "~/.codeium/windsurf/mcp_config.json",
        ConfigFormat.STANDARD,
        verified=False,
        platform="linux",
        notes="same path on Linux — unverified",
    ),
    # ── Emerging agents (unverified) ──────────────────────────
    ClientConfig(
        "Perplexity",
        "~/.perplexity/mcp.json",
        ConfigFormat.STANDARD,
        verified=False,
        notes="Perplexity AI assistant — config path unverified",
    ),
    ClientConfig(
        "Devin",
        "~/.devin/mcp.json",
        ConfigFormat.STANDARD,
        verified=False,
        notes="Devin AI coding agent — config path unverified",
    ),
    ClientConfig(
        "Roo Code",
        "~/Library/Application Support/Code/User/globalStorage/"
        "rooveterinaryinc.roo-cline/settings/mcp_settings.json",
        ConfigFormat.STANDARD,
        verified=False,
        platform="macos",
        notes="Roo Code (Cline fork) — config path extrapolated from Cline",
    ),
    ClientConfig(
        "Augment Code",
        "~/.augment/mcp.json",
        ConfigFormat.STANDARD,
        verified=False,
        notes="Augment Code AI assistant — config path unverified",
    ),
    ClientConfig(
        "GitHub Copilot (agent mode)",
        "~/Library/Application Support/Code/User/settings.json",
        ConfigFormat.VSCODE,
        verified=False,
        platform="macos",
        key_in_settings="github.copilot.chat.mcp.servers",
        notes="Copilot agent mode uses different settings key than VS Code MCP",
    ),
    # ── Windows entries ───────────────────────────────────────
    ClientConfig(
        "Claude Code",
        "~/.claude/mcp.json",
        ConfigFormat.STANDARD,
        verified=True,
        platform="windows",
        notes="Cross-platform path — same on Windows",
    ),
    ClientConfig(
        "Cursor",
        "~/.cursor/mcp.json",
        ConfigFormat.STANDARD,
        verified=True,
        platform="windows",
        notes="Cross-platform path — same on Windows",
    ),
    ClientConfig(
        "VS Code",
        "%APPDATA%/Code/User/settings.json",
        ConfigFormat.VSCODE,
        verified=True,
        platform="windows",
        key_in_settings="mcp.servers",
    ),
    ClientConfig(
        "Windsurf",
        "%APPDATA%/.codeium/windsurf/mcp_config.json",
        ConfigFormat.STANDARD,
        verified=False,
        platform="windows",
    ),
    ClientConfig(
        "Cline",
        "%APPDATA%/Code/User/globalStorage/saoudrizwan.claude-dev/settings/cline_mcp_settings.json",
        ConfigFormat.STANDARD,
        verified=True,
        platform="windows",
    ),
    ClientConfig(
        "Continue",
        "~/.continue/config.json",
        ConfigFormat.CONTINUE_ARRAY,
        verified=True,
        platform="windows",
        key_in_settings="mcpServers",
        notes="Cross-platform path — same on Windows",
    ),
    ClientConfig(
        "JetBrains",
        "%APPDATA%/JetBrains/*/mcp.json",
        ConfigFormat.STANDARD,
        verified=False,
        platform="windows",
        notes="glob pattern — multiple IDE versions",
    ),
]


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def _detect_platform() -> str:
    """Detect the current platform as 'macos', 'linux', or 'windows'."""
    system = _platform.system()
    if system == "Darwin":
        return "macos"
    elif system == "Windows":
        return "windows"
    return "linux"


def get_known_clients(platform: str | None = None) -> list[ClientConfig]:
    """Return known client configs for the given platform.

    Args:
        platform: "macos", "linux", "windows", or None (auto-detect).

    Returns:
        List of ClientConfig entries matching the platform.
    """
    plat = platform or _detect_platform()
    return [c for c in _KNOWN_CLIENTS if c.platform in ("all", plat)]


def _is_project_level(config: ClientConfig) -> bool:
    """Check if a config is project-level (relative path)."""
    return not config.config_path.startswith(("~", "/", "%"))


def _resolve_path(
    config: ClientConfig,
    config_dir_override: Path | None = None,
) -> list[Path]:
    """Resolve a config path template to actual filesystem path(s).

    Handles ~ expansion, %APPDATA% expansion, config_dir_override, and glob patterns.
    Returns a list because glob patterns can match multiple paths.
    """
    raw = config.config_path

    # Expand Windows environment variables (%APPDATA%, %LOCALAPPDATA%, etc.)
    # os.path.expandvars handles %VAR% on Windows and $VAR on Unix.
    # On Unix, %VAR% is not expanded by expandvars, so we do it manually.
    if "%" in raw:
        import re

        def _expand_percent_var(match: re.Match) -> str:
            var_name = match.group(1)
            return os.environ.get(var_name, match.group(0))

        raw = re.sub(r"%([^%]+)%", _expand_percent_var, raw)

    if config_dir_override and raw.startswith("~"):
        # Replace ~ with the override directory
        resolved = str(config_dir_override) + raw[1:]
    elif raw.startswith("~"):
        resolved = str(Path(raw).expanduser())
    else:
        resolved = raw

    path = Path(resolved)

    # Handle glob patterns (e.g., JetBrains */mcp.json)
    if "*" in resolved:
        # Walk up to find the first non-glob ancestor
        parts = Path(resolved).parts
        glob_start = 0
        for i, part in enumerate(parts):
            if "*" in part:
                glob_start = i
                break
        base = Path(*parts[:glob_start]) if glob_start > 0 else Path("/")
        glob_pattern = str(Path(*parts[glob_start:]))
        try:
            return sorted(base.glob(glob_pattern))
        except (OSError, PermissionError):
            return []

    return [path]


def discover_clients(
    config_dir_override: Path | None = None,
    platform: str | None = None,
) -> list[DiscoveredClient]:
    """Discover MCP clients by checking known config paths.

    Args:
        config_dir_override: If set, use this as the base directory instead of ~.
        platform: Override platform detection for testing.

    Returns:
        List of discovered clients with their server configs.
    """
    from vloex_mcp_proxy.discovery.config_parser import parse_config

    clients = get_known_clients(platform=platform)
    discovered: list[DiscoveredClient] = []

    for client in clients:
        # Skip project-level configs (need workspace root detection — M5)
        if _is_project_level(client):
            continue

        paths = _resolve_path(client, config_dir_override)

        for path in paths:
            if not path.exists():
                continue

            try:
                servers = parse_config(
                    path,
                    client.config_format,
                    key_in_settings=client.key_in_settings,
                )
            except (json.JSONDecodeError, ValueError) as exc:
                _log(f"Skipping {client.name} ({path}): {exc}")
                continue
            except PermissionError:
                _log(f"Skipping {client.name} ({path}): permission denied")
                continue

            if servers:
                discovered.append(
                    DiscoveredClient(
                        client_name=client.name,
                        config_path=path,
                        config_format=client.config_format,
                        servers=servers,
                        verified=client.verified,
                    )
                )

    return discovered
