"""MCP config rewriter — backup, rewrite, restore, competing proxy detection.

Rewrites MCP client config files to route server commands through
vloex-mcp-proxy. Creates .vloex-backup files before modifying.
Detects competing proxies (Harmonic, etc.) to prevent double-wrapping.
"""

from __future__ import annotations

import json
import os
import shutil
import sys
from dataclasses import dataclass, field
from pathlib import Path

from vloex_mcp_proxy.discovery.config_parser import parse_config, serialize_config
from vloex_mcp_proxy.discovery.config_paths import (
    ConfigFormat,
    DiscoveredClient,
    discover_clients,
)


def _log(msg: str) -> None:
    print(f"[vloex-discovery] {msg}", file=sys.stderr, flush=True)


# ---------------------------------------------------------------------------
# Data models
# ---------------------------------------------------------------------------


@dataclass
class RewriteResult:
    """Result of rewriting a single server entry."""

    server_name: str
    rewritten: bool
    skipped_reason: str | None = None


@dataclass
class DiscoverReport:
    """Summary of a discover operation."""

    clients_found: int
    total_servers: int
    details: list[str] = field(default_factory=list)


@dataclass
class RewriteReport:
    """Summary of a rewrite operation."""

    configs_rewritten: int = 0
    servers_rewritten: int = 0
    servers_skipped: int = 0
    backups_created: int = 0
    details: list[str] = field(default_factory=list)


@dataclass
class RestoreReport:
    """Summary of a restore operation."""

    configs_restored: int = 0
    details: list[str] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Competing proxy detection
# ---------------------------------------------------------------------------

COMPETING_PROXIES: list[str] = [
    "harmonic",
    "harmonic-mcp",
    "mcp-guardian",
]


def is_already_rewritten(server_config: dict) -> bool:
    """Check if a server is already routed through vloex-mcp-proxy.

    Returns True if the command is 'vloex-mcp-proxy' or ends with '/vloex-mcp-proxy'.
    """
    command = server_config.get("command", "")
    basename = command.rsplit("/", 1)[-1] if command else ""
    return basename == "vloex-mcp-proxy"


def is_competing_proxy(server_config: dict) -> str | None:
    """Check if a server is wrapped by a competing proxy.

    Returns the competing proxy name if detected, None otherwise.
    Checks both the command and args for known proxy binary names.
    """
    command = (server_config.get("command") or "").lower()
    command_base = command.rsplit("/", 1)[-1]

    for proxy in COMPETING_PROXIES:
        if proxy in command_base:
            return proxy

    args = server_config.get("args", [])
    for arg in args:
        arg_lower = str(arg).lower()
        for proxy in COMPETING_PROXIES:
            if proxy in arg_lower:
                return proxy

    return None


# ---------------------------------------------------------------------------
# Single server rewrite
# ---------------------------------------------------------------------------


def rewrite_server_entry(
    server_name: str,
    server_config: dict,
    proxy_command: str = "vloex-mcp-proxy",
) -> tuple[dict, RewriteResult]:
    """Rewrite a single server entry to route through the proxy.

    CRITICAL: Uses json.dumps(original_args) for --server-args (JSON array format).
    The CLI already supports JSON array parsing (cli.py:50-53).

    Args:
        server_name: The name of the server (used for --server-name).
        server_config: The original server config dict.
        proxy_command: Path to the proxy binary.

    Returns:
        Tuple of (new_config, RewriteResult).
    """
    if is_already_rewritten(server_config):
        return server_config, RewriteResult(
            server_name=server_name,
            rewritten=False,
            skipped_reason="already rewritten",
        )

    competing = is_competing_proxy(server_config)
    if competing:
        return server_config, RewriteResult(
            server_name=server_name,
            rewritten=False,
            skipped_reason=f"competing proxy ({competing})",
        )

    original_command = server_config.get("command", "")
    original_args = server_config.get("args", [])

    new_args = [
        "--server-command",
        original_command,
        "--server-args",
        json.dumps(original_args),
        "--server-name",
        server_name,
    ]

    new_config: dict = {
        "command": proxy_command,
        "args": new_args,
    }

    # Preserve env if present
    if "env" in server_config:
        new_config["env"] = server_config["env"]

    return new_config, RewriteResult(server_name=server_name, rewritten=True)


# ---------------------------------------------------------------------------
# Full config rewrite
# ---------------------------------------------------------------------------


def _backup_path(config_path: Path) -> Path:
    """Get the backup path for a config file."""
    return config_path.parent / f"{config_path.name}.vloex-backup"


def rewrite_config(
    config_path: Path,
    config_format: ConfigFormat,
    key_in_settings: str | None = None,
    proxy_command: str = "vloex-mcp-proxy",
    dry_run: bool = False,
) -> RewriteReport:
    """Rewrite all server entries in a config file.

    Steps:
    1. Read and parse the config file
    2. For each server: check if already rewritten or competing proxy
    3. Create .vloex-backup if any rewrites will happen
    4. Rewrite qualifying servers
    5. Write the modified config back
    6. Preserve file permissions
    """
    report = RewriteReport()
    report.details.append(f"  {config_path.name} ({config_path})")

    # Read original data for serialization (preserve non-MCP settings)
    text = config_path.read_text(encoding="utf-8")
    original_data = json.loads(text)

    servers = parse_config(config_path, config_format, key_in_settings=key_in_settings)
    if not servers:
        report.details.append("    (no servers found)")
        return report

    new_servers = {}
    any_rewritten = False

    for name, config in servers.items():
        new_config, result = rewrite_server_entry(name, config, proxy_command)
        new_servers[name] = new_config

        if result.rewritten:
            any_rewritten = True
            report.servers_rewritten += 1
            report.details.append(f"    \u2713 {name}  \u2192 rewritten")
        else:
            report.servers_skipped += 1
            report.details.append(f"    \u2298 {name}  \u2192 skipped ({result.skipped_reason})")

    if any_rewritten and not dry_run:
        # Create backup
        backup = _backup_path(config_path)
        stat_info = os.stat(config_path)
        shutil.copy2(config_path, backup)
        report.backups_created += 1
        report.details.append(f"    Backup: {backup}")

        # Write rewritten config
        serialized = serialize_config(
            new_servers,
            config_format,
            original_data=original_data,
            key_in_settings=key_in_settings,
        )
        config_path.write_text(serialized, encoding="utf-8")
        os.chmod(config_path, stat_info.st_mode)
        report.configs_rewritten += 1
    elif any_rewritten and dry_run:
        report.details.append("    (dry run — no changes written)")

    return report


# ---------------------------------------------------------------------------
# Restore
# ---------------------------------------------------------------------------


def restore_config(config_path: Path) -> bool:
    """Restore a config file from its .vloex-backup.

    Returns True if restored, False if no backup found.
    """
    backup = _backup_path(config_path)
    if not backup.exists():
        return False

    stat_info = os.stat(backup)
    shutil.copy2(backup, config_path)
    os.chmod(config_path, stat_info.st_mode)
    backup.unlink()
    return True


# ---------------------------------------------------------------------------
# High-level commands (called by CLI)
# ---------------------------------------------------------------------------


def discover_and_report(
    config_dir_override: Path | None = None,
    platform: str | None = None,
) -> DiscoverReport:
    """Discover all MCP clients and return a human-readable report."""
    discovered = discover_clients(config_dir_override=config_dir_override, platform=platform)

    total_servers = sum(len(d.servers) for d in discovered)
    details: list[str] = []

    if not discovered:
        details.append("No MCP clients found.")
        return DiscoverReport(clients_found=0, total_servers=0, details=details)

    details.append("Discovered MCP Clients:")
    details.append("")

    for client in discovered:
        verified = " (verified)" if client.verified else " (unverified)"
        details.append(f"  {client.client_name} ({client.config_path}){verified}")
        details.append("    Servers:")
        for name, config in client.servers.items():
            cmd = config.get("command", "?")
            args = " ".join(str(a) for a in config.get("args", []))
            details.append(f"      {name:20s} \u2192 {cmd} {args}".rstrip())
        details.append("")

    details.append(f"  Total: {len(discovered)} client(s), {total_servers} server(s)")

    return DiscoverReport(
        clients_found=len(discovered),
        total_servers=total_servers,
        details=details,
    )


def rewrite_all(
    config_dir_override: Path | None = None,
    platform: str | None = None,
    proxy_command: str = "vloex-mcp-proxy",
    dry_run: bool = False,
) -> RewriteReport:
    """Discover all MCP clients and rewrite their configs."""
    discovered = discover_clients(config_dir_override=config_dir_override, platform=platform)

    report = RewriteReport()

    if not discovered:
        report.details.append("No MCP clients found.")
        return report

    prefix = "Rewriting MCP configs..." if not dry_run else "Dry run — showing what would change..."
    report.details.append(prefix)
    report.details.append("")

    for client in discovered:
        try:
            sub = rewrite_config(
                config_path=client.config_path,
                config_format=client.config_format,
                key_in_settings=_key_for_client(client),
                proxy_command=proxy_command,
                dry_run=dry_run,
            )
            report.configs_rewritten += sub.configs_rewritten
            report.servers_rewritten += sub.servers_rewritten
            report.servers_skipped += sub.servers_skipped
            report.backups_created += sub.backups_created
            report.details.extend(sub.details)
            report.details.append("")
        except (json.JSONDecodeError, ValueError, PermissionError) as exc:
            report.details.append(f"  {client.client_name} ({client.config_path})")
            report.details.append(f"    Error: {exc}")
            report.details.append("")

    report.details.append(
        f"  Summary: {report.servers_rewritten} server(s) rewritten, "
        f"{report.servers_skipped} skipped, {report.backups_created} backup(s) created"
    )

    return report


def rewrite_single(
    config_path: Path,
    proxy_command: str = "vloex-mcp-proxy",
) -> RewriteReport:
    """Rewrite a single config file by path (used by daemon watcher).

    Discovers the config format by matching against known clients, then
    rewrites just that one file instead of scanning all clients.
    """
    config_path = config_path.resolve()
    discovered = discover_clients()

    for client in discovered:
        if client.config_path.resolve() == config_path:
            return rewrite_config(
                config_path=client.config_path,
                config_format=client.config_format,
                key_in_settings=_key_for_client(client),
                proxy_command=proxy_command,
            )

    # Config not found in known clients — return empty report
    report = RewriteReport()
    report.details.append(f"  {config_path} — not a known MCP client config")
    return report


def restore_all(
    config_dir_override: Path | None = None,
    platform: str | None = None,
) -> RestoreReport:
    """Restore all rewritten configs from backups.

    Uses two strategies to find restorable configs:
    1. Discover current configs (covers rewritten configs that are still parseable)
    2. Scan known config paths for orphaned .vloex-backup files (covers configs
       that were manually deleted or corrupted after rewriting)
    """
    from vloex_mcp_proxy.discovery.config_paths import _resolve_path, get_known_clients

    report = RestoreReport()
    report.details.append("Restoring MCP configs from backups...")
    report.details.append("")

    checked_paths: set[Path] = set()

    # Strategy 1: restore configs found via discovery
    discovered = discover_clients(config_dir_override=config_dir_override, platform=platform)
    for client in discovered:
        path = client.config_path
        if path in checked_paths:
            continue
        checked_paths.add(path)

        if restore_config(path):
            report.configs_restored += 1
            report.details.append(f"  \u2713 {path}  \u2192 restored from backup")

    # Strategy 2: scan known paths for orphaned .vloex-backup files
    # (handles case where config was deleted after rewrite)
    clients = get_known_clients(platform=platform)
    for client_cfg in clients:
        if client_cfg.config_path.startswith(("~", "/")):
            paths = _resolve_path(client_cfg, config_dir_override)
            for path in paths:
                if path in checked_paths:
                    continue
                checked_paths.add(path)

                backup = _backup_path(path)
                if backup.exists():
                    if restore_config(path):
                        report.configs_restored += 1
                        report.details.append(
                            f"  \u2713 {path}  \u2192 restored from orphaned backup"
                        )

    if report.configs_restored == 0:
        report.details.append("  No backups found to restore.")

    report.details.append("")
    report.details.append(f"  Summary: {report.configs_restored} config(s) restored")

    return report


def _key_for_client(client: DiscoveredClient) -> str | None:
    """Extract key_in_settings from a DiscoveredClient by looking up the registry."""
    from vloex_mcp_proxy.discovery.config_paths import get_known_clients

    for known in get_known_clients():
        if known.name == client.client_name and known.config_format == client.config_format:
            return known.key_in_settings
    return None
