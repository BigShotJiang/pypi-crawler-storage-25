"""Process discovery — scans running processes for known MCP servers and clients.

Uses psutil to iterate running processes and match against known
MCP server/client process names. Extracts CWDs from client processes
to discover workspace roots.
"""

from __future__ import annotations

import os
import shutil
import sys
from dataclasses import dataclass


def _log(msg: str) -> None:
    print(f"[vloex-process] {msg}", file=sys.stderr, flush=True)


# Known MCP client process name fragments
# Use specific patterns to avoid false positives (e.g. "code" matches too broadly)
_CLIENT_PROCESS_NAMES: frozenset[str] = frozenset(
    {
        "claude",
        "cursor",
        "code-",  # VS Code helper processes (code-server, code-insiders, etc.)
        "vscode",
        "electron",  # VS Code / Cursor run as Electron
        "windsurf",
        "zed",
        "cline",
        "continue",
    }
)

# Known MCP server process name fragments
_SERVER_PROCESS_NAMES: frozenset[str] = frozenset(
    {
        "mcp-server",
        "mcp_server",
        "modelcontextprotocol",
    }
)


@dataclass
class ProcessInfo:
    """Info about a discovered process."""

    pid: int
    name: str
    cmdline: list[str]
    cwd: str | None = None
    is_client: bool = False
    is_server: bool = False


def _try_import_psutil():
    """Import psutil, return None if not installed."""
    try:
        import psutil

        return psutil
    except ImportError:
        return None


def discover_processes() -> list[ProcessInfo]:
    """Scan running processes for known MCP servers and clients.

    Returns a list of ProcessInfo objects. Skips the current process.
    Catches AccessDenied, NoSuchProcess, ZombieProcess per-process.
    """
    psutil = _try_import_psutil()
    if psutil is None:
        _log("psutil not installed — process discovery unavailable")
        return []

    results: list[ProcessInfo] = []
    own_pid = os.getpid()

    for proc in psutil.process_iter(["pid", "name", "cmdline", "cwd"]):
        try:
            info = proc.info
            pid = info.get("pid", 0)
            if pid == own_pid:
                continue

            name = (info.get("name") or "").lower()
            cmdline = info.get("cmdline") or []
            cmdline_str = " ".join(cmdline).lower()
            cwd = info.get("cwd")

            is_client = any(cn in name or cn in cmdline_str for cn in _CLIENT_PROCESS_NAMES)
            is_server = any(sn in name or sn in cmdline_str for sn in _SERVER_PROCESS_NAMES)

            if is_client or is_server:
                results.append(
                    ProcessInfo(
                        pid=pid,
                        name=name,
                        cmdline=cmdline,
                        cwd=cwd,
                        is_client=is_client,
                        is_server=is_server,
                    )
                )
        except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
            continue
        except Exception:
            continue

    return results


def discover_workspace_roots() -> list[str]:
    """Extract unique CWDs from discovered client processes.

    These are likely workspace roots where MCP configs may be found.
    """
    processes = discover_processes()
    roots: set[str] = set()
    for p in processes:
        if p.is_client and p.cwd:
            roots.add(p.cwd)
    return sorted(roots)


def resolve_binary_path(command: str) -> str | None:
    """Resolve a server command to its binary path.

    Handles direct paths, npx/python wrappers, and PATH lookup.
    Returns the resolved absolute path, or None if not found.
    """
    # Direct absolute path
    if os.path.isabs(command) and os.path.isfile(command):
        return command

    # Try shutil.which for PATH lookup
    resolved = shutil.which(command)
    if resolved:
        return resolved

    # For wrapper commands like npx/python, the binary is the wrapper itself
    wrapper_prefixes = ("npx", "python", "python3", "node", "deno", "bun")
    parts = command.split()
    if parts and parts[0] in wrapper_prefixes:
        wrapper_path = shutil.which(parts[0])
        return wrapper_path

    return None
