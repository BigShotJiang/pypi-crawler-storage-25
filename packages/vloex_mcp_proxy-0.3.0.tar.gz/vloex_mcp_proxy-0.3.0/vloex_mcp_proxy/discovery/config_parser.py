"""Multi-format MCP config file parser.

Parses 5 config format variations:
- Standard: {"mcpServers": {"name": {...}}}
- VS Code:  {"mcp": {"servers": {...}}} or {"mcp.servers": {...}}
- Zed:      {"context_servers": {"name": {...}}}
- Continue: {"mcpServers": [{"name": "...", "command": "..."}]}
- JetBrains: same as Standard
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

from vloex_mcp_proxy.discovery.config_paths import ConfigFormat


def _log(msg: str) -> None:
    print(f"[vloex-discovery] {msg}", file=sys.stderr, flush=True)


def parse_config(
    path: Path,
    config_format: ConfigFormat,
    key_in_settings: str | None = None,
) -> dict[str, dict]:
    """Parse an MCP config file and return server entries.

    Args:
        path: Path to the config file.
        config_format: Which format parser to use.
        key_in_settings: For VS Code/Zed, the key within the settings JSON.

    Returns:
        Dict mapping server_name → server config dict.
        Each server config has at minimum: {"command": "...", "args": [...]}
        May also have: {"env": {...}}

    Raises:
        FileNotFoundError: if the file doesn't exist.
        json.JSONDecodeError: if the file is not valid JSON.
        ValueError: if the file doesn't match the expected format.
    """
    text = path.read_text(encoding="utf-8")
    data = json.loads(text)

    if not isinstance(data, dict):
        raise ValueError(f"Expected JSON object, got {type(data).__name__}")

    if config_format == ConfigFormat.STANDARD:
        return _parse_standard(data)
    elif config_format == ConfigFormat.VSCODE:
        return _parse_vscode(data, key_in_settings or "mcp.servers")
    elif config_format == ConfigFormat.ZED:
        return _parse_zed(data, key_in_settings or "context_servers")
    elif config_format == ConfigFormat.CONTINUE_ARRAY:
        return _parse_continue(data, key_in_settings or "mcpServers")
    else:
        raise ValueError(f"Unknown config format: {config_format}")


def _parse_standard(data: dict) -> dict[str, dict]:
    """Parse standard MCP format: {"mcpServers": {"name": {...}}}"""
    servers = data.get("mcpServers", {})
    if not isinstance(servers, dict):
        return {}
    return servers


def _parse_vscode(data: dict, key: str) -> dict[str, dict]:
    """Parse VS Code settings format.

    The key is dot-separated (e.g., "mcp.servers"):
    1. Try nested first: data["mcp"]["servers"]
    2. Fall back to flat: data["mcp.servers"]
    VS Code supports both conventions. Try nested first because it's the
    canonical format in newer VS Code versions.
    """
    parts = key.split(".")

    # Try nested: data["mcp"]["servers"]
    nested = data
    try:
        for part in parts:
            nested = nested[part]
        if isinstance(nested, dict):
            return nested
    except (KeyError, TypeError):
        pass

    # Fall back to flat: data["mcp.servers"]
    flat = data.get(key, {})
    if isinstance(flat, dict):
        return flat

    return {}


def _parse_zed(data: dict, key: str) -> dict[str, dict]:
    """Parse Zed settings format: {"context_servers": {"name": {...}}}"""
    servers = data.get(key, {})
    if not isinstance(servers, dict):
        return {}
    return servers


def _parse_continue(data: dict, key: str) -> dict[str, dict]:
    """Parse Continue array format.

    Continue uses: {"mcpServers": [{"name": "...", "command": "..."}]}
    Convert to standard dict format: {"name": {"command": "...", ...}}
    """
    servers_list = data.get(key, [])
    if not isinstance(servers_list, list):
        return {}

    result: dict[str, dict] = {}
    for entry in servers_list:
        if not isinstance(entry, dict):
            continue
        name = entry.get("name")
        if not name:
            continue
        # Copy all fields except "name" into the server config
        config = {k: v for k, v in entry.items() if k != "name"}
        result[name] = config

    return result


# ---------------------------------------------------------------------------
# Serialization
# ---------------------------------------------------------------------------


def serialize_config(
    servers: dict[str, dict],
    config_format: ConfigFormat,
    original_data: dict | None = None,
    key_in_settings: str | None = None,
) -> str:
    """Serialize server entries back to the appropriate config format.

    If original_data is provided, merge the servers into the original structure
    (preserving all other settings like editor preferences in VS Code settings.json).

    Args:
        servers: Dict mapping server_name → server config dict.
        config_format: Which format to serialize to.
        original_data: The complete original file data (to preserve non-MCP settings).
        key_in_settings: For VS Code/Zed, the key within the settings JSON.

    Returns:
        JSON string ready to write to file.
    """
    if config_format == ConfigFormat.STANDARD:
        return _serialize_standard(servers, original_data)
    elif config_format == ConfigFormat.VSCODE:
        return _serialize_vscode(servers, original_data, key_in_settings or "mcp.servers")
    elif config_format == ConfigFormat.ZED:
        return _serialize_zed(servers, original_data, key_in_settings or "context_servers")
    elif config_format == ConfigFormat.CONTINUE_ARRAY:
        return _serialize_continue(servers, original_data, key_in_settings or "mcpServers")
    else:
        raise ValueError(f"Unknown config format: {config_format}")


def _serialize_standard(servers: dict[str, dict], original_data: dict | None) -> str:
    """Serialize to standard MCP format."""
    data = dict(original_data) if original_data else {}
    data["mcpServers"] = servers
    return json.dumps(data, indent=2) + "\n"


def _serialize_vscode(
    servers: dict[str, dict],
    original_data: dict | None,
    key: str,
) -> str:
    """Serialize to VS Code settings format.

    Preserves all non-MCP settings. Detects whether the original used
    nested or flat key format and writes back in the same style.
    """
    data = dict(original_data) if original_data else {}
    parts = key.split(".")

    # Detect which format the original used
    uses_nested = False
    if original_data:
        try:
            nested = original_data
            for part in parts:
                nested = nested[part]
            uses_nested = True
        except (KeyError, TypeError):
            pass

    if uses_nested or not original_data:
        # Write nested: data["mcp"]["servers"] = {...}
        current = data
        for part in parts[:-1]:
            if part not in current or not isinstance(current[part], dict):
                current[part] = {}
            current = current[part]
        current[parts[-1]] = servers
        # Remove flat key if it exists
        if key in data:
            del data[key]
    else:
        # Write flat: data["mcp.servers"] = {...}
        data[key] = servers

    return json.dumps(data, indent=2) + "\n"


def _serialize_zed(
    servers: dict[str, dict],
    original_data: dict | None,
    key: str,
) -> str:
    """Serialize to Zed settings format. Preserves all non-MCP settings."""
    data = dict(original_data) if original_data else {}
    data[key] = servers
    return json.dumps(data, indent=2) + "\n"


def _serialize_continue(
    servers: dict[str, dict],
    original_data: dict | None,
    key: str,
) -> str:
    """Serialize to Continue array format.

    Convert dict format back to array: {"name": {...}} → [{"name": "name", ...}]
    """
    data = dict(original_data) if original_data else {}
    servers_list = []
    for name, config in servers.items():
        entry = {"name": name}
        entry.update(config)
        servers_list.append(entry)
    data[key] = servers_list
    return json.dumps(data, indent=2) + "\n"
