"""HTTP client for Vloex backend communication.

Wraps httpx.AsyncClient with methods for heartbeat, event sync,
and enrollment. All methods return None/False on error (never raise).
"""

from __future__ import annotations

import sys

import httpx


def _log(msg: str) -> None:
    print(f"[vloex-http] {msg}", file=sys.stderr, flush=True)


class VloexClient:
    """Async HTTP client for Vloex backend communication."""

    def __init__(self, backend_url: str, device_token: str | None = None) -> None:
        self._backend_url = backend_url.rstrip("/")
        self._device_token = device_token
        self._client: httpx.AsyncClient | None = None
        if (
            not backend_url.startswith("https://")
            and "localhost" not in backend_url
            and "127.0.0.1" not in backend_url
        ):
            _log("WARNING: Backend URL is not HTTPS — credentials may be transmitted in plaintext")

    async def init(self) -> None:
        """Create the httpx client."""
        self._client = httpx.AsyncClient(
            base_url=self._backend_url,
            timeout=httpx.Timeout(10.0, connect=5.0),
        )

    async def close(self) -> None:
        """Close the httpx client."""
        if self._client:
            await self._client.aclose()
            self._client = None

    def set_token(self, token: str) -> None:
        """Update the device token (after enrollment or refresh)."""
        self._device_token = token

    def _auth_headers(self) -> dict[str, str]:
        """Build Authorization header if token is available."""
        if self._device_token:
            return {"Authorization": f"Bearer {self._device_token}"}
        return {}

    async def heartbeat(self, device_id: str) -> dict | None:
        """Send heartbeat to backend. No auth required (public endpoint).

        Returns response dict (with mcp_config for MCP proxies), or None on error.
        """
        if not self._client:
            return None
        try:
            resp = await self._client.post(
                "/api/v1/devices/heartbeat",
                json={"device_id": device_id, "client_type": "mcp_proxy"},
            )
            if resp.status_code == 200:
                return resp.json()
            _log(f"Heartbeat failed: HTTP {resp.status_code}")
            return None
        except httpx.HTTPError as exc:
            _log(f"Heartbeat error: {exc}")
            return None

    async def send_events_batch(self, events: list[dict]) -> bool:
        """Send a batch of events to backend. Requires device token.

        Returns True if accepted (2xx), False otherwise.
        """
        if not self._client:
            return False
        try:
            resp = await self._client.post(
                "/api/v1/events/batch",
                json=events,
                headers=self._auth_headers(),
            )
            if resp.status_code == 401:
                _log("Event sync got 401 — device token expired or invalid")
                return False
            if 200 <= resp.status_code < 300:
                return True
            _log(f"Event sync failed: HTTP {resp.status_code}")
            return False
        except httpx.HTTPError as exc:
            _log(f"Event sync error: {exc}")
            return False

    async def enroll_code(
        self, code: str, device_id: str, user_email: str | None = None
    ) -> dict | None:
        """Enroll with a 6-digit code.

        POST /api/v1/devices/enroll/validate
        """
        if not self._client:
            return None
        try:
            body: dict = {"code": code, "used_by": device_id}
            if user_email:
                body["user_email"] = user_email
            resp = await self._client.post("/api/v1/devices/enroll/validate", json=body)
            return resp.json()
        except (httpx.HTTPError, ValueError) as exc:
            _log(f"Enrollment error: {exc}")
            return None

    async def enroll_token(
        self, token: str, device_id: str, user_email: str | None = None
    ) -> dict | None:
        """Enroll with an org enrollment token.

        POST /api/v1/devices/auto-enroll
        """
        if not self._client:
            return None
        try:
            body: dict = {"enrollment_token": token, "device_id": device_id}
            if user_email:
                body["user_email"] = user_email
            resp = await self._client.post("/api/v1/devices/auto-enroll", json=body)
            return resp.json()
        except (httpx.HTTPError, ValueError) as exc:
            _log(f"Token enrollment error: {exc}")
            return None

    async def sso_initiate(self, device_id: str) -> dict | None:
        """Initiate SSO enrollment (Device Authorization Grant).

        POST /api/v1/devices/enroll/sso/initiate
        Returns {device_code, user_code, verification_url, expires_in} or None on error.
        """
        if not self._client:
            return None
        try:
            resp = await self._client.post(
                "/api/v1/devices/enroll/sso/initiate",
                json={"device_id": device_id},
            )
            return resp.json()
        except (httpx.HTTPError, ValueError) as exc:
            _log(f"SSO initiate error: {exc}")
            return None

    async def sso_poll(self, device_code: str) -> dict | None:
        """Poll SSO enrollment status.

        GET /api/v1/devices/enroll/sso/poll?device_code=...
        Returns {status, device_token?} or None on error.
        """
        if not self._client:
            return None
        try:
            resp = await self._client.get(
                "/api/v1/devices/enroll/sso/poll",
                params={"device_code": device_code},
            )
            return resp.json()
        except (httpx.HTTPError, ValueError) as exc:
            _log(f"SSO poll error: {exc}")
            return None
