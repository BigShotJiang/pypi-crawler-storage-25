"""Background worker for periodic heartbeat to the Vloex backend.

Sends heartbeat, receives policy updates, caches config for offline fallback.
"""

from __future__ import annotations

import asyncio
import json
import sys
from collections.abc import Callable
from pathlib import Path

from vloex_mcp_proxy.backend.config import get_vloex_dir
from vloex_mcp_proxy.backend.http_client import VloexClient
from vloex_mcp_proxy.policy.engine import PolicyEngine


def _log(msg: str) -> None:
    print(f"[vloex-heartbeat] {msg}", file=sys.stderr, flush=True)


HEARTBEAT_CACHE_FILE = "heartbeat_cache.json"
DEFAULT_INTERVAL: float = 60.0
MIN_HEARTBEAT_INTERVAL: float = 10.0


class HeartbeatWorker:
    """Background worker that sends periodic heartbeats and updates policies."""

    def __init__(
        self,
        client: VloexClient,
        policy_engine: PolicyEngine,
        device_id: str,
        vloex_dir: Path | None = None,
    ) -> None:
        self._client = client
        self._policy_engine = policy_engine
        self._device_id = device_id
        self._vloex_dir = vloex_dir or get_vloex_dir()
        self._interval = DEFAULT_INTERVAL
        self._running = False
        self._user_department: str | None = None
        self._on_config_updated: Callable[[], None] | None = None

    @property
    def interval(self) -> float:
        """Current heartbeat interval in seconds."""
        return self._interval

    @property
    def user_department(self) -> str | None:
        """User department from last heartbeat response."""
        return self._user_department

    def set_on_config_updated(self, callback: Callable[[], None]) -> None:
        """Set callback invoked after each config apply."""
        self._on_config_updated = callback

    def load_cached_config(self) -> bool:
        """Load policies from cached heartbeat response (offline fallback).

        Returns True if cache was loaded, False if no cache or invalid.
        """
        cache_path = self._vloex_dir / HEARTBEAT_CACHE_FILE
        if not cache_path.exists():
            return False
        try:
            data = json.loads(cache_path.read_text())
            self._apply_config(data)
            _log("Loaded cached heartbeat config")
            return True
        except (json.JSONDecodeError, OSError) as exc:
            _log(f"Failed to load heartbeat cache: {exc}")
            return False

    def _save_cache(self, config: dict) -> None:
        """Save heartbeat config to cache file."""
        cache_path = self._vloex_dir / HEARTBEAT_CACHE_FILE
        try:
            cache_path.write_text(json.dumps(config))
            cache_path.chmod(0o600)
        except OSError as exc:
            _log(f"Failed to save heartbeat cache: {exc}")

    def _apply_config(self, config: dict) -> None:
        """Apply MCP config from heartbeat response.

        Extracts policies list and calls policy_engine.set_policies().
        Extracts McpConfig fields and calls policy_engine.set_config().
        Updates heartbeat interval if backend specifies one.
        """
        policies = config.get("policies", [])
        self._policy_engine.set_policies(policies)
        _log(f"Applied {len(policies)} policies from backend")

        # Extract McpConfig fields (server_allowlist, tool_blocklist, etc.)
        mcp_config_keys = {
            "server_allowlist",
            "server_blocklist",
            "tool_blocklist",
            "scan_arguments",
            "scan_results",
            "block_on_rug_pull",
            "block_sampling",
            "max_tool_result_size_bytes",
            "tool_call_timeout_seconds",
        }
        mcp_config_data = {k: v for k, v in config.items() if k in mcp_config_keys}
        if mcp_config_data:
            self._policy_engine.set_config(mcp_config_data)

        interval = config.get("heartbeat_interval_seconds")
        if interval and isinstance(interval, (int, float)) and interval >= MIN_HEARTBEAT_INTERVAL:
            self._interval = float(interval)

        # Extract user department for department-scoped policies
        dept = config.get("user_department")
        if isinstance(dept, str) and dept:
            self._user_department = dept
        elif dept is None:
            self._user_department = None

        # Notify listeners (e.g., interceptor) of config changes
        if self._on_config_updated is not None:
            try:
                self._on_config_updated()
            except Exception as exc:
                _log(f"Config update callback error: {exc}")

    async def run(self) -> None:
        """Main loop. Sends heartbeat, applies config, sleeps."""
        self._running = True
        _log("Heartbeat worker started")

        while self._running:
            try:
                resp = await self._client.heartbeat(self._device_id)
                if resp:
                    mcp_config = resp.get("mcp_config")
                    if mcp_config:
                        self._apply_config(mcp_config)
                        self._save_cache(mcp_config)
                else:
                    _log("Heartbeat failed — using cached/existing policies")

                await asyncio.sleep(self._interval)

            except asyncio.CancelledError:
                _log("Heartbeat worker cancelled")
                return
            except Exception as exc:
                _log(f"Heartbeat worker error: {exc}")
                await asyncio.sleep(self._interval)

        _log("Heartbeat worker stopped")

    def stop(self) -> None:
        """Signal the worker to stop."""
        self._running = False
