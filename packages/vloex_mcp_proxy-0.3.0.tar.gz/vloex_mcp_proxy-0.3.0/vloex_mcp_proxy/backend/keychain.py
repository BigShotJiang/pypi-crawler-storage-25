"""Keychain abstraction for secure credential storage.

Uses the ``keyring`` library when available (optional [security] extras).
Falls back to file-based storage at ~/.vloex/<key> with 0o600.
Auto-migrates from file to keychain when keychain becomes available.
"""

from __future__ import annotations

import sys
from pathlib import Path

_SERVICE_NAME = "com.vloex.mcp-proxy"
_DEVICE_TOKEN_KEY = "device_token"


def _log(msg: str) -> None:
    print(f"[vloex-keychain] {msg}", file=sys.stderr, flush=True)


def _keyring_available() -> bool:
    """Check if keyring library is available."""
    try:
        import keyring  # noqa: F401

        return True
    except ImportError:
        return False


def store_credential(key: str, value: str, vloex_dir: Path | None = None) -> bool:
    """Store a credential, trying keychain first, file fallback.

    Returns True if stored successfully.
    """
    if _keyring_available():
        try:
            import keyring

            keyring.set_password(_SERVICE_NAME, key, value)
            _log(f"Stored '{key}' in system keychain")
            # Remove file copy if it exists (migration)
            if vloex_dir:
                file_path = vloex_dir / key
                if file_path.exists():
                    file_path.unlink()
                    _log(f"Removed file copy after keychain migration: {file_path}")
            return True
        except Exception as exc:
            _log(f"Keychain store failed: {exc} — falling back to file")

    # File fallback
    if vloex_dir is None:
        _log("No vloex_dir for file fallback")
        return False

    file_path = vloex_dir / key
    try:
        vloex_dir.mkdir(parents=True, exist_ok=True)
        file_path.write_text(value)
        try:
            file_path.chmod(0o600)
        except OSError:
            if sys.platform == "win32":
                _log(
                    "Cannot set file permissions on Windows"
                    " — install [security] extras for keychain"
                )
        _log(f"Stored '{key}' in file: {file_path}")
        return True
    except OSError as exc:
        _log(f"File store failed: {exc}")
        return False


def load_credential(key: str, vloex_dir: Path | None = None) -> str | None:
    """Load a credential, trying keychain first, then file.

    If found in file but keychain is available, auto-migrates to keychain.
    """
    if _keyring_available():
        try:
            import keyring

            value = keyring.get_password(_SERVICE_NAME, key)
            if value is not None:
                return value
        except Exception as exc:
            _log(f"Keychain load failed: {exc}")

    # File fallback
    if vloex_dir is None:
        return None

    file_path = vloex_dir / key
    if not file_path.exists():
        return None

    try:
        value = file_path.read_text().strip()
        # Auto-migrate to keychain if available
        if value and _keyring_available():
            try:
                import keyring

                keyring.set_password(_SERVICE_NAME, key, value)
                file_path.unlink()
                _log(f"Migrated '{key}' from file to keychain")
            except Exception:
                pass  # Keep file copy if migration fails
        return value
    except OSError:
        return None


def delete_credential(key: str, vloex_dir: Path | None = None) -> bool:
    """Delete a credential from both keychain and file."""
    deleted = False

    if _keyring_available():
        try:
            import keyring

            keyring.delete_password(_SERVICE_NAME, key)
            deleted = True
        except Exception:
            pass

    if vloex_dir:
        file_path = vloex_dir / key
        if file_path.exists():
            try:
                file_path.unlink()
                deleted = True
            except OSError:
                pass

    return deleted
