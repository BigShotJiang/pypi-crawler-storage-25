"""Build AIEvent dicts from proxy interception data.

Maps MCP proxy fields (server_name, tool_name, arguments, detections)
to the backend AIEvent ingestion schema.
"""

from __future__ import annotations

import uuid
from datetime import datetime, timezone

from vloex_mcp_proxy.scanner.sensitive import Detection


def _truncate(text: str | None, max_len: int = 256) -> str | None:
    """Truncate text for local storage. Full content sent via HTTPS."""
    if text is None:
        return None
    if len(text) <= max_len:
        return text
    return text[:max_len] + "...[truncated]"


def build_event(
    server_name: str,
    method: str,
    tool_name: str | None,
    arguments_text: str | None,
    result_text: str | None,
    detections: list[Detection],
    policy_action: str,
    device_id: str,
    user_email: str | None = None,
    department: str | None = None,
    schema_violations: list[str] | None = None,
    sampling_abuse_patterns: list[str] | None = None,
) -> dict:
    """Build an AIEvent dict from proxy interception data.

    Maps MCP proxy fields to the backend AIEvent schema:
    - capture_method = "mcp"
    - provider_name = server_name (the MCP server name)
    - service = "mcp"
    - interaction_type = "tool_call"
    - prompt_text = arguments_text (tool call arguments)
    - response_text = result_text (tool call result)
    """
    event_id = str(uuid.uuid4())
    now = datetime.now(timezone.utc).isoformat()

    sensitive_data = [
        {
            "data_type": d.data_type.value,
            "confidence": d.confidence,
            "count": d.count,
        }
        for d in detections
    ]

    risk_score = min(len(detections) * 3.0, 10.0) if detections else 0.0

    return {
        "event_id": event_id,
        "timestamp": now,
        "capture_method": "mcp",
        "provider_name": server_name,
        "service": "mcp",
        "model": None,
        "account_type": "enterprise",
        "user_email": user_email,
        "department": department,
        "interaction_type": "tool_call",
        "prompt_text": _truncate(arguments_text),
        "response_text": _truncate(result_text),
        "prompt_token_count": None,
        "response_token_count": None,
        "has_file_upload": False,
        "source_url": None,
        "risk_score": risk_score,
        "policy_action": policy_action,
        "estimated_cost_usd": None,
        "sensitive_data": sensitive_data,
        "metadata": {
            "mcp_server_name": server_name,
            "mcp_tool_name": tool_name,
            "mcp_method": method,
            **({"schema_violations": schema_violations} if schema_violations else {}),
            **(
                {"sampling_abuse_patterns": sampling_abuse_patterns}
                if sampling_abuse_patterns
                else {}
            ),
        },
        "device_id": device_id,
    }


def build_rugpull_event(
    server_name: str,
    change_type: str,
    severity: str,
    tool_name: str | None,
    detail: str,
    device_id: str,
    user_email: str | None = None,
) -> dict:
    """Build an event dict for a rug-pull security alert.

    Maps rug-pull detection alerts to the backend AIEvent schema:
    - interaction_type = "security_alert"
    - risk_score derived from severity level
    - rugpull metadata included for backend alert engine
    """
    severity_scores = {"info": 1.0, "warning": 4.0, "high": 7.0, "critical": 10.0}

    return {
        "event_id": str(uuid.uuid4()),
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "capture_method": "mcp",
        "provider_name": server_name,
        "service": "mcp",
        "model": None,
        "account_type": "enterprise",
        "user_email": user_email,
        "department": None,
        "interaction_type": "security_alert",
        "prompt_text": None,
        "response_text": detail,
        "prompt_token_count": None,
        "response_token_count": None,
        "has_file_upload": False,
        "source_url": None,
        "risk_score": severity_scores.get(severity.lower(), 5.0),
        "policy_action": "warn",
        "estimated_cost_usd": None,
        "sensitive_data": [],
        "metadata": {
            "mcp_server_name": server_name,
            "mcp_tool_name": tool_name,
            "mcp_method": "tools/list",
            "rugpull_change_type": change_type,
            "rugpull_severity": severity,
        },
        "device_id": device_id,
    }
