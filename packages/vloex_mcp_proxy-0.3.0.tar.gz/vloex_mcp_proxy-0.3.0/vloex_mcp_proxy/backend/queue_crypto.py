"""AES-256-GCM encryption for event queue data.

Uses PBKDF2-HMAC-SHA256 to derive key from device token.
Graceful fallback: if cryptography not available, operations are no-ops.
"""

from __future__ import annotations

import base64
import hashlib
import os
import sys


def _log(msg: str) -> None:
    print(f"[vloex-crypto] {msg}", file=sys.stderr, flush=True)


def derive_key(device_token: str, salt: bytes | None = None) -> tuple[bytes, bytes]:
    """Derive a 32-byte AES key from a device token using PBKDF2.

    Returns (key, salt) tuple. If salt is None, generates a random one.
    """
    if salt is None:
        salt = os.urandom(16)
    key = hashlib.pbkdf2_hmac("sha256", device_token.encode(), salt, 600_000, dklen=32)
    return key, salt


def encrypt(plaintext: str, key: bytes) -> str | None:
    """Encrypt plaintext with AES-256-GCM.

    Returns base64-encoded string: nonce(12) + ciphertext + tag(16).
    Returns None if cryptography is not available.
    """
    try:
        from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    except ImportError:
        _log("cryptography not available — storing plaintext")
        return None

    nonce = os.urandom(12)
    aesgcm = AESGCM(key)
    ciphertext = aesgcm.encrypt(nonce, plaintext.encode(), None)
    # nonce + ciphertext (includes tag)
    raw = nonce + ciphertext
    return base64.b64encode(raw).decode()


def decrypt(encrypted: str, key: bytes) -> str | None:
    """Decrypt an AES-256-GCM encrypted string.

    Returns plaintext string, or None on failure.
    """
    try:
        from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    except ImportError:
        return None

    try:
        raw = base64.b64decode(encrypted)
        nonce = raw[:12]
        ciphertext = raw[12:]
        aesgcm = AESGCM(key)
        plaintext = aesgcm.decrypt(nonce, ciphertext, None)
        return plaintext.decode()
    except Exception:
        return None
