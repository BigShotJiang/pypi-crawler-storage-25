"""Durable SQLite queue for intercepted MCP events.

Events are queued locally and synced to the backend in batches.
Survives proxy restarts via SQLite persistence.
"""

from __future__ import annotations

import json
import os
import sys
import time

import aiosqlite

_SCHEMA = """
CREATE TABLE IF NOT EXISTS event_queue (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    event_json TEXT NOT NULL,
    created_at REAL NOT NULL,
    sync_status TEXT NOT NULL DEFAULT 'pending',
    retry_count INTEGER NOT NULL DEFAULT 0
)
"""

MAX_QUEUE_SIZE: int = 10_000


def _log(msg: str) -> None:
    print(f"[vloex-queue] {msg}", file=sys.stderr, flush=True)


class EventQueue:
    """Async SQLite-backed event queue."""

    def __init__(self, db_path: str, encryption_key: bytes | None = None) -> None:
        self._db_path = db_path
        self._db: aiosqlite.Connection | None = None
        self._encryption_key = encryption_key

    async def init(self) -> None:
        """Open the database and create the schema."""
        self._db = await aiosqlite.connect(self._db_path)
        try:
            os.chmod(self._db_path, 0o600)
        except OSError:
            pass  # Windows doesn't support chmod
        await self._db.execute("PRAGMA journal_mode = WAL")
        await self._db.execute(_SCHEMA)
        await self._db.commit()

    async def close(self) -> None:
        """Close the database connection."""
        if self._db:
            await self._db.close()
            self._db = None

    async def enqueue(self, event: dict) -> int:
        """Add an event to the queue.

        If queue exceeds MAX_QUEUE_SIZE, evicts oldest pending events.

        Returns the row ID of the inserted event.
        """
        if self._db is None:
            raise RuntimeError("EventQueue not initialized — call init() first")
        event_json = json.dumps(event)
        if self._encryption_key:
            from vloex_mcp_proxy.backend.queue_crypto import encrypt

            encrypted = encrypt(event_json, self._encryption_key)
            if encrypted is not None:
                event_json = encrypted
        now = time.time()
        cursor = await self._db.execute(
            "INSERT INTO event_queue (event_json, created_at) VALUES (?, ?)",
            (event_json, now),
        )
        row_id = cursor.lastrowid
        await self._db.commit()

        # Evict overflow
        count_cursor = await self._db.execute(
            "SELECT COUNT(*) FROM event_queue WHERE sync_status = 'pending'"
        )
        row = await count_cursor.fetchone()
        pending = row[0] if row else 0
        if pending > MAX_QUEUE_SIZE:
            overflow = pending - MAX_QUEUE_SIZE
            await self._db.execute(
                "DELETE FROM event_queue WHERE id IN ("
                "  SELECT id FROM event_queue WHERE sync_status = 'pending'"
                "  ORDER BY created_at ASC LIMIT ?"
                ")",
                (overflow,),
            )
            await self._db.commit()
            _log(f"Evicted {overflow} oldest pending events (overflow)")

        return row_id or 0

    async def dequeue_batch(self, batch_size: int = 50) -> list[tuple[int, dict]]:
        """Fetch a batch of pending events for sync.

        Marks them as 'syncing' atomically.
        """
        if self._db is None:
            raise RuntimeError("EventQueue not initialized — call init() first")
        cursor = await self._db.execute(
            "SELECT id, event_json FROM event_queue "
            "WHERE sync_status = 'pending' "
            "ORDER BY created_at ASC LIMIT ?",
            (batch_size,),
        )
        rows = await cursor.fetchall()
        if not rows:
            return []

        row_ids = [r[0] for r in rows]
        placeholders = ",".join("?" * len(row_ids))
        await self._db.execute(
            f"UPDATE event_queue SET sync_status = 'syncing' WHERE id IN ({placeholders})",
            row_ids,
        )
        await self._db.commit()

        result: list[tuple[int, dict]] = []
        for row_id, event_json in rows:
            # Try to decrypt (gracefully handles plaintext for pre-encryption events)
            if self._encryption_key:
                from vloex_mcp_proxy.backend.queue_crypto import decrypt

                decrypted = decrypt(event_json, self._encryption_key)
                if decrypted is not None:
                    event_json = decrypted
            try:
                event = json.loads(event_json)
            except json.JSONDecodeError:
                _log(f"Skipping corrupt event row {row_id}")
                continue
            result.append((row_id, event))

        return result

    async def mark_synced(self, row_ids: list[int]) -> None:
        """Delete successfully synced events from the queue."""
        if not row_ids:
            return
        if self._db is None:
            raise RuntimeError("EventQueue not initialized — call init() first")
        placeholders = ",".join("?" * len(row_ids))
        await self._db.execute(
            f"DELETE FROM event_queue WHERE id IN ({placeholders})",
            row_ids,
        )
        await self._db.commit()

    async def mark_failed(self, row_ids: list[int]) -> None:
        """Reset failed events back to 'pending', increment retry_count."""
        if not row_ids:
            return
        if self._db is None:
            raise RuntimeError("EventQueue not initialized — call init() first")
        placeholders = ",".join("?" * len(row_ids))
        await self._db.execute(
            f"UPDATE event_queue SET sync_status = 'pending', retry_count = retry_count + 1 "
            f"WHERE id IN ({placeholders})",
            row_ids,
        )
        await self._db.commit()

    async def pending_count(self) -> int:
        """Return the number of pending events."""
        if self._db is None:
            raise RuntimeError("EventQueue not initialized — call init() first")
        cursor = await self._db.execute(
            "SELECT COUNT(*) FROM event_queue WHERE sync_status = 'pending'"
        )
        row = await cursor.fetchone()
        return row[0] if row else 0
