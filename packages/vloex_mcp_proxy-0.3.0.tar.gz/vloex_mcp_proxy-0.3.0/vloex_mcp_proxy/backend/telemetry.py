"""Opt-in telemetry for proxy health monitoring.

NEVER enabled by default. Controlled by enterprise config or CLI flag.
Minimal data: device_id, version, event_type, timestamp, os, python_version.
For crashes: SHA-256 hash of traceback (NOT the traceback itself). No PII.
"""

from __future__ import annotations

import hashlib
import json
import platform
import sys
import time
import urllib.request
from typing import Any


def _log(msg: str) -> None:
    print(f"[vloex-telemetry] {msg}", file=sys.stderr, flush=True)


class TelemetryClient:
    """Opt-in telemetry client. No-op when disabled."""

    def __init__(
        self,
        endpoint: str = "",
        device_id: str = "",
        proxy_version: str = "",
        enabled: bool = False,
    ) -> None:
        self._endpoint = endpoint
        self._device_id = device_id
        self._proxy_version = proxy_version
        self._enabled = enabled
        self._queue: list[dict[str, Any]] = []

    @property
    def enabled(self) -> bool:
        return self._enabled

    def record_event(self, event_type: str, extra: dict[str, Any] | None = None) -> None:
        """Record a telemetry event. No-op if disabled."""
        if not self._enabled:
            return

        event: dict[str, Any] = {
            "event_type": event_type,
            "device_id": self._device_id,
            "proxy_version": self._proxy_version,
            "timestamp": time.time(),
            "os": platform.system(),
            "python_version": platform.python_version(),
        }
        if extra:
            # Sanitize: only allow known safe keys
            safe_keys = {
                "server_count",
                "config_count",
                "uptime_seconds",
                "event_count",
                "crash_hash",
            }
            for k, v in extra.items():
                if k in safe_keys:
                    event[k] = v

        self._queue.append(event)

    def record_crash(self, traceback_str: str) -> None:
        """Record a crash event with hashed traceback. No PII."""
        if not self._enabled:
            return

        # Hash the traceback -- privacy-preserving deduplication
        tb_hash = hashlib.sha256(traceback_str.encode()).hexdigest()[:16]
        self.record_event("crash", {"crash_hash": tb_hash})

    def flush(self) -> int:
        """Send queued events to the telemetry endpoint. Returns count sent."""
        if not self._enabled or not self._queue or not self._endpoint:
            return 0

        events = list(self._queue)
        self._queue.clear()

        try:
            payload = json.dumps({"events": events}).encode()
            req = urllib.request.Request(
                self._endpoint,
                data=payload,
                headers={"Content-Type": "application/json"},
                method="POST",
            )
            with urllib.request.urlopen(req, timeout=5) as resp:
                if resp.status < 300:
                    return len(events)
        except Exception as exc:
            _log(f"Telemetry flush failed: {exc}")

        return 0

    def has_pii(self, event: dict) -> bool:
        """Check if an event contains PII fields. Used for validation."""
        pii_fields = {"user_email", "user_name", "ip_address", "hostname", "traceback"}
        return bool(set(event.keys()) & pii_fields)
