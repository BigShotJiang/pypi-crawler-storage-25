"""Background worker that syncs queued events to the Vloex backend.

Dequeues batches from the EventQueue, sends via VloexClient,
and handles success/failure with exponential backoff.
"""

from __future__ import annotations

import asyncio
import sys

from vloex_mcp_proxy.backend.event_queue import EventQueue
from vloex_mcp_proxy.backend.http_client import VloexClient


def _log(msg: str) -> None:
    print(f"[vloex-sync] {msg}", file=sys.stderr, flush=True)


MIN_BACKOFF: float = 1.0
MAX_BACKOFF: float = 60.0
IDLE_SLEEP: float = 5.0


class SyncWorker:
    """Background worker that syncs queued events to the backend."""

    def __init__(self, queue: EventQueue, client: VloexClient) -> None:
        self._queue = queue
        self._client = client
        self._backoff = MIN_BACKOFF
        self._running = False

    async def run(self) -> None:
        """Main loop. Dequeues batches, sends to backend, handles success/failure."""
        self._running = True
        _log("Sync worker started")
        while self._running:
            try:
                batch = await self._queue.dequeue_batch()
                if not batch:
                    await asyncio.sleep(IDLE_SLEEP)
                    continue

                row_ids = [row_id for row_id, _event in batch]
                events = [event for _row_id, event in batch]

                ok = await self._client.send_events_batch(events)
                if ok:
                    await self._queue.mark_synced(row_ids)
                    self._backoff = MIN_BACKOFF
                    _log(f"Synced {len(events)} events")
                else:
                    await self._queue.mark_failed(row_ids)
                    _log(f"Sync failed, backoff {self._backoff:.0f}s")
                    await asyncio.sleep(self._backoff)
                    self._backoff = min(self._backoff * 2, MAX_BACKOFF)

            except asyncio.CancelledError:
                _log("Sync worker cancelled")
                return
            except Exception as exc:
                _log(f"Sync worker error: {exc}")
                await asyncio.sleep(self._backoff)
                self._backoff = min(self._backoff * 2, MAX_BACKOFF)

        _log("Sync worker stopped")

    def stop(self) -> None:
        """Signal the worker to stop after the current iteration."""
        self._running = False
