"""Configuration for Vloex backend integration.

Manages the ~/.vloex/ state directory: device ID persistence, device token
storage, and backend URL resolution.
"""

from __future__ import annotations

import os
import sys
import uuid
from pathlib import Path

VLOEX_DIR: Path = Path.home() / ".vloex"


def _log(msg: str) -> None:
    """Log to stderr (stdout is the MCP communication channel)."""
    print(f"[vloex-config] {msg}", file=sys.stderr, flush=True)


def get_vloex_dir(override: Path | None = None) -> Path:
    """Return the vloex state directory, creating it if needed."""
    d = override or VLOEX_DIR
    d.mkdir(parents=True, exist_ok=True)
    try:
        d.chmod(0o700)
    except OSError:
        pass  # Windows doesn't support chmod
    return d


def get_or_create_device_id(vloex_dir: Path | None = None) -> str:
    """Read device_id from ~/.vloex/device_id, or create one.

    The device_id is a UUID4 stored as a plain text file.
    Once created, it persists across sessions.
    """
    d = get_vloex_dir(vloex_dir)
    path = d / "device_id"
    if path.exists():
        stored = path.read_text().strip()
        if stored:
            return stored
    device_id = str(uuid.uuid4())
    path.write_text(device_id)
    try:
        path.chmod(0o600)
    except OSError:
        pass  # Windows doesn't support chmod
    _log(f"Created device_id: {device_id[:8]}...")
    return device_id


def get_device_token(vloex_dir: Path | None = None) -> str | None:
    """Load device token, trying keychain first, file fallback.

    Returns the token string, or None if not enrolled.
    """
    d = get_vloex_dir(vloex_dir)
    try:
        from vloex_mcp_proxy.backend.keychain import load_credential

        return load_credential("device_token", d)
    except ImportError:
        # Keychain module not available — direct file read
        path = d / "device_token"
        if not path.exists():
            return None
        token = path.read_text().strip()
        return token if token else None


def save_device_token(token: str, vloex_dir: Path | None = None) -> None:
    """Save device token, trying keychain first, file fallback.

    Sets file permissions to 0o600 (owner read/write only).
    """
    d = get_vloex_dir(vloex_dir)
    try:
        from vloex_mcp_proxy.backend.keychain import store_credential

        store_credential("device_token", token, d)
    except ImportError:
        # Keychain module not available — direct file write
        path = d / "device_token"
        path.write_text(token)
        try:
            path.chmod(0o600)
        except OSError:
            pass  # Windows doesn't support chmod


def clear_device_token(vloex_dir: Path | None = None) -> None:
    """Remove the device token from keychain and file (on 401 / re-enrollment)."""
    d = get_vloex_dir(vloex_dir)
    try:
        from vloex_mcp_proxy.backend.keychain import delete_credential

        delete_credential("device_token", d)
    except ImportError:
        # Keychain module not available — delete file directly
        path = d / "device_token"
        if path.exists():
            path.unlink()


def get_backend_url() -> str | None:
    """Read backend URL from env var, then enterprise config fallback.

    Priority:
    1. VLOEX_BACKEND_URL environment variable
    2. Enterprise config at /etc/vloex/config.json (MDM-deployed)

    Returns the URL string, or None if not set.
    """
    url = os.environ.get("VLOEX_BACKEND_URL") or None
    if url:
        return url

    try:
        from vloex_mcp_proxy.packaging.enterprise_config import load_enterprise_config

        enterprise = load_enterprise_config()
        return enterprise.backend_url or None
    except ImportError:
        return None


def get_enrollment_token_from_config() -> str | None:
    """Read enrollment token from enterprise config.

    Returns the token string, or None if not configured.
    Used by auto-enrollment during .pkg/.deb install.
    """
    try:
        from vloex_mcp_proxy.packaging.enterprise_config import load_enterprise_config

        enterprise = load_enterprise_config()
        return enterprise.enrollment_token or None
    except ImportError:
        return None


def get_user_email_from_token(token: str) -> str | None:
    """Decode the JWT (without verification) to extract user_email.

    Uses pyjwt with verify_signature=False because the proxy doesn't
    have the backend's JWT_SECRET. We just need to read claims.
    """
    try:
        import jwt

        claims = jwt.decode(token, options={"verify_signature": False}, algorithms=["HS256"])
        return claims.get("user_email") or claims.get("sub")
    except Exception:
        return None
