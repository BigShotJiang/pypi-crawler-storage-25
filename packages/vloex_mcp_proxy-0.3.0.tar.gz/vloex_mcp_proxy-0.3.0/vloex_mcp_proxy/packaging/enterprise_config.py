"""Enterprise configuration — MDM-deployed config at /etc/vloex/config.json.

IT admins deploy this file via Jamf/Intune/Ansible. The proxy reads it as a
fallback when no env vars or CLI flags are set. NEVER raises — returns defaults
on missing/invalid file.
"""

from __future__ import annotations

import json
import sys
from dataclasses import dataclass
from pathlib import Path


def _log(msg: str) -> None:
    print(f"[vloex-enterprise] {msg}", file=sys.stderr, flush=True)


@dataclass
class EnterpriseConfig:
    """Enterprise configuration deployed by MDM/IT admin."""

    backend_url: str = ""
    enrollment_token: str = ""
    auto_discover: bool = True
    auto_rewrite: bool = True
    log_level: str = "INFO"
    event_queue_max_size_mb: int = 50
    heartbeat_interval_seconds: int = 30
    telemetry_enabled: bool = False

    @property
    def is_configured(self) -> bool:
        """True when enrollment_token is non-empty (MDM deployed a real config)."""
        return bool(self.enrollment_token)


def get_enterprise_config_path() -> Path:
    """Return the platform-specific enterprise config path.

    darwin/linux → /etc/vloex/config.json
    win32       → C:/ProgramData/Vloex/config.json
    """
    if sys.platform == "win32":
        return Path("C:/ProgramData/Vloex/config.json")
    return Path("/etc/vloex/config.json")


def load_enterprise_config(path: Path | None = None) -> EnterpriseConfig:
    """Load enterprise config from disk. NEVER raises — returns defaults.

    Args:
        path: Override config path (for testing). Uses platform default if None.

    Returns:
        EnterpriseConfig with values from file, or defaults on any error.
    """
    config_path = path or get_enterprise_config_path()
    if not config_path.exists():
        return EnterpriseConfig()

    try:
        raw = config_path.read_text(encoding="utf-8")
    except PermissionError:
        _log(f"Permission denied reading {config_path}")
        return EnterpriseConfig()
    except OSError as exc:
        _log(f"Failed to read {config_path}: {exc}")
        return EnterpriseConfig()

    try:
        data = json.loads(raw)
    except (json.JSONDecodeError, ValueError):
        _log(f"Invalid JSON in {config_path}")
        return EnterpriseConfig()

    if not isinstance(data, dict):
        _log(f"Expected JSON object in {config_path}")
        return EnterpriseConfig()

    try:
        return EnterpriseConfig(
            backend_url=str(data.get("backend_url", "")),
            enrollment_token=str(data.get("enrollment_token", "")),
            auto_discover=bool(data.get("auto_discover", True)),
            auto_rewrite=bool(data.get("auto_rewrite", True)),
            log_level=str(data.get("log_level", "INFO")),
            event_queue_max_size_mb=max(1, int(data.get("event_queue_max_size_mb", 50))),
            heartbeat_interval_seconds=max(10, int(data.get("heartbeat_interval_seconds", 30))),
            telemetry_enabled=bool(data.get("telemetry_enabled", False)),
        )
    except (ValueError, TypeError):
        _log(f"Invalid field value in {config_path}")
        return EnterpriseConfig()
