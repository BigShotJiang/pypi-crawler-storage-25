# Security: server inventory + rug-pull detection
