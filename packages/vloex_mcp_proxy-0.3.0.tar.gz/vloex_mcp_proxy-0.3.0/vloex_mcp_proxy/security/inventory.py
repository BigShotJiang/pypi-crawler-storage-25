"""Server inventory — tracks MCP server tools and binary hashes for rug-pull detection.

Persists tool fingerprints and binary SHA-256 hashes to a JSON file.
ServerInventory.update_tools_list() compares the new tools/list response
against the stored snapshot and returns a list of InventoryChange objects.
"""

from __future__ import annotations

import hashlib
import json
import os
import sys
from dataclasses import asdict, dataclass, field
from enum import Enum
from pathlib import Path


def _log(msg: str) -> None:
    print(f"[vloex-inventory] {msg}", file=sys.stderr, flush=True)


class ChangeType(Enum):
    """Type of change detected in a server's tool inventory."""

    TOOL_ADDED = "tool_added"
    TOOL_REMOVED = "tool_removed"
    TOOL_DESCRIPTION_CHANGED = "tool_description_changed"
    TOOL_SCHEMA_CHANGED = "tool_schema_changed"
    BINARY_CHANGED = "binary_changed"


@dataclass
class ToolEntry:
    """Snapshot of a single tool's identity."""

    name: str
    description_hash: str  # SHA-256 of description text
    schema_hash: str  # SHA-256 of JSON-serialized inputSchema
    input_schema: dict = field(default_factory=dict)  # Raw inputSchema for validation


@dataclass
class ServerEntry:
    """Stored state for one MCP server."""

    tools: dict[str, ToolEntry] = field(default_factory=dict)  # name → ToolEntry
    binary_hash: str | None = None  # SHA-256 of the server binary


@dataclass
class InventoryChange:
    """A single detected change in server inventory."""

    server_name: str
    change_type: ChangeType
    tool_name: str | None = None  # None for binary changes
    detail: str = ""


def _sha256(text: str) -> str:
    """Deterministic SHA-256 hex digest of a string."""
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def _tool_entry_from_dict(tool: dict) -> ToolEntry:
    """Create a ToolEntry from a tools/list response item."""
    name = tool.get("name", "")
    description = tool.get("description", "")
    schema = tool.get("inputSchema", {})
    # Deterministic JSON serialization for schema hash
    schema_str = json.dumps(schema, sort_keys=True, separators=(",", ":"))
    return ToolEntry(
        name=name,
        description_hash=_sha256(description),
        schema_hash=_sha256(schema_str),
        input_schema=schema,
    )


class ServerInventory:
    """Tracks MCP server tools and binary hashes, persisted to a JSON file.

    Thread-safe for single-process use (no concurrent writes expected
    since each proxy instance has its own inventory path).
    """

    def __init__(self, path: Path) -> None:
        self._path = path
        # server_name → ServerEntry
        self._servers: dict[str, ServerEntry] = {}
        self._load()

    def _load(self) -> None:
        """Load inventory from disk. Silently starts empty if file missing/corrupt."""
        if not self._path.exists():
            return
        try:
            with open(self._path) as f:
                data = json.load(f)
            for server_name, server_data in data.items():
                tools = {}
                for tool_name, tool_data in server_data.get("tools", {}).items():
                    tools[tool_name] = ToolEntry(
                        name=tool_data["name"],
                        description_hash=tool_data["description_hash"],
                        schema_hash=tool_data["schema_hash"],
                        input_schema=tool_data.get("input_schema", {}),
                    )
                self._servers[server_name] = ServerEntry(
                    tools=tools,
                    binary_hash=server_data.get("binary_hash"),
                )
        except (json.JSONDecodeError, KeyError, TypeError):
            _log(f"Corrupt inventory file at {self._path}, starting fresh")
            self._servers = {}

    def _save(self) -> None:
        """Persist inventory to disk with restrictive permissions."""
        data = {}
        for server_name, entry in self._servers.items():
            tools = {}
            for tool_name, tool_entry in entry.tools.items():
                tools[tool_name] = asdict(tool_entry)
            data[server_name] = {
                "tools": tools,
                "binary_hash": entry.binary_hash,
            }

        # Atomic write: write to temp, rename
        tmp_path = self._path.with_suffix(".tmp")
        with open(tmp_path, "w") as f:
            json.dump(data, f, indent=2)
        try:
            os.chmod(str(tmp_path), 0o600)
        except OSError:
            pass  # Windows doesn't support chmod
        os.replace(str(tmp_path), str(self._path))

    def update_tools_list(self, server_name: str, tools: list[dict]) -> list[InventoryChange]:
        """Compare new tools/list response against stored snapshot.

        Returns a list of changes. Updates the stored snapshot.
        First call for a new server returns TOOL_ADDED for each tool.
        """
        new_entries = {t.name: t for t in (_tool_entry_from_dict(t) for t in tools)}
        changes: list[InventoryChange] = []

        if server_name not in self._servers:
            self._servers[server_name] = ServerEntry()

        old_tools = self._servers[server_name].tools

        # Check for added tools
        for name, new_entry in new_entries.items():
            if name not in old_tools:
                changes.append(
                    InventoryChange(
                        server_name=server_name,
                        change_type=ChangeType.TOOL_ADDED,
                        tool_name=name,
                        detail=f"New tool: {name}",
                    )
                )
            else:
                old_entry = old_tools[name]
                if new_entry.description_hash != old_entry.description_hash:
                    changes.append(
                        InventoryChange(
                            server_name=server_name,
                            change_type=ChangeType.TOOL_DESCRIPTION_CHANGED,
                            tool_name=name,
                            detail=f"Description changed for tool: {name}",
                        )
                    )
                if new_entry.schema_hash != old_entry.schema_hash:
                    changes.append(
                        InventoryChange(
                            server_name=server_name,
                            change_type=ChangeType.TOOL_SCHEMA_CHANGED,
                            tool_name=name,
                            detail=f"Input schema changed for tool: {name}",
                        )
                    )

        # Check for removed tools
        for name in old_tools:
            if name not in new_entries:
                changes.append(
                    InventoryChange(
                        server_name=server_name,
                        change_type=ChangeType.TOOL_REMOVED,
                        tool_name=name,
                        detail=f"Tool removed: {name}",
                    )
                )

        # Update stored snapshot — only write to disk if something changed
        self._servers[server_name].tools = new_entries
        if changes:
            self._save()
        return changes

    def update_binary_hash(self, server_name: str, binary_path: str) -> list[InventoryChange]:
        """Compute and compare SHA-256 of a server binary.

        Returns a list with one BINARY_CHANGED entry if the hash changed.
        """
        try:
            sha = hashlib.sha256()
            with open(binary_path, "rb") as f:
                while True:
                    chunk = f.read(8192)
                    if not chunk:
                        break
                    sha.update(chunk)
            new_hash = sha.hexdigest()
        except (OSError, PermissionError) as exc:
            _log(f"Cannot hash binary {binary_path}: {exc}")
            return []

        changes: list[InventoryChange] = []
        if server_name not in self._servers:
            self._servers[server_name] = ServerEntry()

        old_hash = self._servers[server_name].binary_hash
        if old_hash is not None and old_hash != new_hash:
            changes.append(
                InventoryChange(
                    server_name=server_name,
                    change_type=ChangeType.BINARY_CHANGED,
                    detail=f"Binary hash changed: {old_hash[:12]}... → {new_hash[:12]}...",
                )
            )

        self._servers[server_name].binary_hash = new_hash
        self._save()
        return changes

    def get_server(self, server_name: str) -> ServerEntry | None:
        """Get stored entry for a server, or None."""
        return self._servers.get(server_name)

    def get_tool_schema(self, server_name: str, tool_name: str) -> dict | None:
        """Get stored inputSchema for a tool, or None if not found."""
        server = self._servers.get(server_name)
        if server is None:
            return None
        tool = server.tools.get(tool_name)
        if tool is None:
            return None
        return tool.input_schema if tool.input_schema else None

    def get_all_servers(self) -> dict[str, ServerEntry]:
        """Get all stored server entries."""
        return dict(self._servers)

    def clear(self, server_name: str | None = None) -> None:
        """Clear inventory for one server or all servers."""
        if server_name:
            self._servers.pop(server_name, None)
        else:
            self._servers.clear()
        self._save()
