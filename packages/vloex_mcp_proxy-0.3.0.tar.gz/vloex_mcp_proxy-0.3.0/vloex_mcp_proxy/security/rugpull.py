"""Rug-pull detection — monitors MCP servers for unexpected tool/binary changes.

Wraps ServerInventory and maps changes to severity levels:
- INFO: New tool added (expected during server upgrades)
- WARNING: Tool removed (capability loss, possible attack vector)
- HIGH: Tool description changed (may alter AI agent behavior)
- CRITICAL: Server binary changed (possible supply-chain attack)

Schema-only changes are rated WARNING (may affect validation behavior).
"""

from __future__ import annotations

import sys
from dataclasses import dataclass
from enum import Enum

from vloex_mcp_proxy.security.inventory import (
    ChangeType,
    InventoryChange,
    ServerInventory,
)


def _log(msg: str) -> None:
    print(f"[vloex-rugpull] {msg}", file=sys.stderr, flush=True)


class Severity(Enum):
    """Severity of a rug-pull alert."""

    INFO = "info"
    WARNING = "warning"
    HIGH = "high"
    CRITICAL = "critical"


# Map change types to severity levels
_SEVERITY_MAP: dict[ChangeType, Severity] = {
    ChangeType.TOOL_ADDED: Severity.INFO,
    ChangeType.TOOL_REMOVED: Severity.WARNING,
    ChangeType.TOOL_SCHEMA_CHANGED: Severity.WARNING,
    ChangeType.TOOL_DESCRIPTION_CHANGED: Severity.HIGH,
    ChangeType.BINARY_CHANGED: Severity.CRITICAL,
}


@dataclass
class RugPullAlert:
    """Alert for a detected rug-pull change."""

    server_name: str
    severity: Severity
    change_type: ChangeType
    tool_name: str | None
    detail: str


class RugPullDetector:
    """Detects rug-pull attacks by monitoring tool and binary changes.

    Wraps a ServerInventory instance and translates InventoryChange
    objects into severity-rated RugPullAlert objects.
    """

    def __init__(self, inventory: ServerInventory) -> None:
        self._inventory = inventory

    def check_tools_list(self, server_name: str, tools: list[dict]) -> list[RugPullAlert]:
        """Check a tools/list response for rug-pull indicators.

        Always forwards the tools/list — rug-pull detection is informational only.
        Blocking tools/list would break client discovery.
        """
        changes = self._inventory.update_tools_list(server_name, tools)
        alerts = [self._change_to_alert(c) for c in changes]

        for alert in alerts:
            _log(
                f"[{alert.severity.value}] {alert.server_name}: "
                f"{alert.change_type.value} — {alert.detail}"
            )

        return alerts

    def check_binary(self, server_name: str, binary_path: str) -> list[RugPullAlert]:
        """Check a server binary for changes."""
        changes = self._inventory.update_binary_hash(server_name, binary_path)
        alerts = [self._change_to_alert(c) for c in changes]

        for alert in alerts:
            _log(
                f"[{alert.severity.value}] {alert.server_name}: "
                f"{alert.change_type.value} — {alert.detail}"
            )

        return alerts

    @staticmethod
    def _change_to_alert(change: InventoryChange) -> RugPullAlert:
        """Convert an InventoryChange to a RugPullAlert with severity."""
        severity = _SEVERITY_MAP.get(change.change_type, Severity.WARNING)
        return RugPullAlert(
            server_name=change.server_name,
            severity=severity,
            change_type=change.change_type,
            tool_name=change.tool_name,
            detail=change.detail,
        )
