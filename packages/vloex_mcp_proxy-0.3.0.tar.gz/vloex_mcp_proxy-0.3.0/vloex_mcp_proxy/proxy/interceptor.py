"""Message interceptor for MCP JSON-RPC methods.

Decides which messages to intercept, tracks request/response correlation
by message ID, scans for sensitive data, evaluates policy, and produces
InterceptResult indicating whether to forward, block, or modify.
"""

from __future__ import annotations

import json
import sys
import time
from collections import deque
from dataclasses import dataclass
from enum import Enum

from vloex_mcp_proxy.policy.actions import (
    execute_block,
    execute_redact,
    redact_tool_arguments,
    redact_tool_result,
)
from vloex_mcp_proxy.policy.engine import PolicyAction, PolicyEngine, PolicyResult
from vloex_mcp_proxy.proxy.jsonrpc import JsonRpcMessage, MessageType, make_error_response
from vloex_mcp_proxy.scanner.sensitive import Detection, scan_text


class Direction(Enum):
    """Direction of a message in the proxy pipeline."""

    CLIENT_TO_SERVER = "client_to_server"
    SERVER_TO_CLIENT = "server_to_client"


# Methods that the proxy intercepts
INTERCEPTED_METHODS: frozenset[str] = frozenset(
    {
        "initialize",
        "initialized",
        "tools/list",
        "tools/call",
        "sampling/createMessage",
        "resources/read",
        "prompts/get",
    }
)


@dataclass
class InterceptResult:
    """Result of intercepting a message."""

    message: JsonRpcMessage  # The (possibly modified) message
    should_forward: bool = True  # If False, do not forward (e.g., blocked)
    response_override: bytes | None = None  # If set, send this instead of forwarding
    intercepted: bool = False  # Whether this message was intercepted
    method: str | None = None  # The method that was intercepted (for logging)

    # M4: Event metadata for backend reporting
    tool_name: str | None = None
    arguments_text: str | None = None
    result_text: str | None = None
    detections: list[Detection] | None = None
    policy_action: str | None = None

    # M5a→backend: Rug-pull security alerts for event capture
    security_alerts: list[dict] | None = None

    # Schema validation: errors when tool arguments don't match declared inputSchema
    schema_violations: list[str] | None = None


def _log(msg: str) -> None:
    """Log to stderr (stdout is the MCP communication channel)."""
    print(f"[vloex-intercept] {msg}", file=sys.stderr, flush=True)


# Guard against unbounded growth if server drops responses
_MAX_PENDING_REQUESTS: int = 10_000
_PENDING_TTL_SECONDS: float = 300.0  # 5 minutes


class Interceptor:
    """Stateful interceptor that tracks request/response correlation,
    scans for sensitive data, and evaluates policies.
    """

    def __init__(
        self,
        server_name: str,
        policy_file: str | None = None,
        inventory: object | None = None,
    ) -> None:
        self._server_name = server_name
        # id → (method_name, monotonic_timestamp)
        self._pending_requests: dict[int | str, tuple[str, float]] = {}
        # Policy engine (instance-based, no module globals)
        self._policy_engine = PolicyEngine()
        # Department and user email for policy scope evaluation
        self._department: str | None = None
        self._user_email: str | None = None
        if policy_file:
            try:
                self._policy_engine.load_from_file(policy_file)
                _log(f"Loaded policy file: {policy_file}")
            except (FileNotFoundError, json.JSONDecodeError) as exc:
                _log(f"Failed to load policy file: {exc}")
                # Falls back to log-only mode (empty policy list)

        # P2: Protocol version negotiation
        self._client_protocol_version: str | None = None
        self._server_protocol_version: str | None = None

        # Sampling abuse heuristics: monotonic timestamps for rate detection
        self._sampling_timestamps: deque[float] = deque(maxlen=600)

        # M5a: Server inventory for rug-pull detection (optional)
        self._inventory = inventory
        self._rugpull_detector = None
        if inventory is not None:
            try:
                from vloex_mcp_proxy.security.rugpull import RugPullDetector

                self._rugpull_detector = RugPullDetector(inventory)
            except ImportError:
                _log("Security module not available — rug-pull detection disabled")

    @property
    def policy_engine(self) -> PolicyEngine:
        """Expose the policy engine for testing."""
        return self._policy_engine

    @property
    def department(self) -> str | None:
        """Current user department for policy scope evaluation."""
        return self._department

    def set_department(self, department: str | None) -> None:
        """Set the user department for department-scoped policy evaluation."""
        self._department = department

    def set_user_email(self, user_email: str | None) -> None:
        """Set the user email for user-scoped policy evaluation."""
        self._user_email = user_email

    def _evict_stale(self) -> None:
        """Remove pending requests older than TTL, then drop oldest if still over limit."""
        now = time.monotonic()
        stale = [
            k
            for k, (_method, ts) in self._pending_requests.items()
            if now - ts > _PENDING_TTL_SECONDS
        ]
        for k in stale:
            del self._pending_requests[k]
        while len(self._pending_requests) >= _MAX_PENDING_REQUESTS:
            oldest_key = next(iter(self._pending_requests))
            del self._pending_requests[oldest_key]

    # ------------------------------------------------------------------
    # Config enforcement helpers
    # ------------------------------------------------------------------

    def _check_server_access(self) -> InterceptResult | None:
        """Check server allowlist/blocklist. Returns block result or None if allowed."""
        cfg = self._policy_engine.config
        name_lower = self._server_name.lower()

        # Allowlist: if non-empty, server must be in it
        if cfg.server_allowlist:
            if name_lower not in [s.lower() for s in cfg.server_allowlist]:
                _log(f"[{self._server_name}] BLOCKED — not in server allowlist")
                return self._make_server_block("Server not in allowlist")

        # Blocklist: if non-empty, server must NOT be in it
        if cfg.server_blocklist:
            if name_lower in [s.lower() for s in cfg.server_blocklist]:
                _log(f"[{self._server_name}] BLOCKED — in server blocklist")
                return self._make_server_block("Server is blocklisted")

        return None

    def _make_server_block(self, reason: str) -> InterceptResult:
        """Create a block result for server-level access denial."""
        error_msg = make_error_response(
            None,
            -32001,
            f"Vloex: {reason}. Contact your IT admin.",
        )
        return InterceptResult(
            message=JsonRpcMessage(raw=b"", msg_type=MessageType.INVALID),
            should_forward=False,
            response_override=error_msg,
            intercepted=True,
            method="server_access_check",
            policy_action="block",
        )

    # ------------------------------------------------------------------
    # Scanning helpers
    # ------------------------------------------------------------------

    def _scan_text(self, text: str) -> list[Detection]:
        """Scan text for sensitive data, including custom patterns from policy."""
        custom = self._policy_engine.custom_patterns if self._policy_engine.has_policies else None
        return scan_text(text, custom_patterns=custom)

    def _evaluate_policy(
        self,
        tool_name: str,
        detections: list[Detection],
        sampling_abuse_detected: bool = False,
    ) -> PolicyResult:
        """Evaluate detections against policy engine."""
        return self._policy_engine.evaluate(
            tool_name=tool_name,
            server_name=self._server_name,
            detections=detections,
            sampling_abuse_detected=sampling_abuse_detected,
            user_email=self._user_email,
            department=self._department,
        )

    def _rebuild_message(
        self,
        msg: JsonRpcMessage,
        new_params: dict | None = None,
        new_result: object = None,
        use_result: bool = False,
    ) -> JsonRpcMessage:
        """Rebuild a JsonRpcMessage with modified params or result."""
        if new_params is not None:
            new_obj: dict = {
                "jsonrpc": "2.0",
                "method": msg.method,
                "params": new_params,
            }
            if msg.msg_id is not None:
                new_obj["id"] = msg.msg_id
            new_raw = json.dumps(new_obj, separators=(",", ":")).encode()
            return JsonRpcMessage(
                raw=new_raw,
                msg_type=msg.msg_type,
                method=msg.method,
                msg_id=msg.msg_id,
                params=new_params,
            )
        if use_result:
            new_obj = {
                "jsonrpc": "2.0",
                "result": new_result,
                "id": msg.msg_id,
            }
            new_raw = json.dumps(new_obj, separators=(",", ":")).encode()
            return JsonRpcMessage(
                raw=new_raw,
                msg_type=msg.msg_type,
                msg_id=msg.msg_id,
                result=new_result,
            )
        return msg

    # ------------------------------------------------------------------
    # Client → Server interception
    # ------------------------------------------------------------------

    def intercept_client_message(self, msg: JsonRpcMessage) -> InterceptResult:
        """Process a message from the client heading to the server."""
        if msg.msg_type == MessageType.INVALID:
            return InterceptResult(message=msg, should_forward=True, intercepted=False)

        # Server allowlist/blocklist check
        block_result = self._check_server_access()
        if block_result is not None:
            return block_result

        if msg.msg_type == MessageType.BATCH:
            return self._intercept_batch(msg, Direction.CLIENT_TO_SERVER)

        if msg.msg_type in (MessageType.REQUEST, MessageType.NOTIFICATION):
            method = msg.method
            if method and method in INTERCEPTED_METHODS:
                # Track request ID for response correlation
                if msg.msg_type == MessageType.REQUEST and msg.msg_id is not None:
                    if len(self._pending_requests) >= _MAX_PENDING_REQUESTS:
                        self._evict_stale()
                    self._pending_requests[msg.msg_id] = (method, time.monotonic())
                _log(f"[{self._server_name}] client->server {method} (id={msg.msg_id})")

                # ── P2: Extract client protocol version ────────
                if method == "initialize" and msg.params:
                    version = msg.params.get("protocolVersion")
                    if version:
                        self._client_protocol_version = str(version)
                        _log(f"[{self._server_name}] Client protocol version: {version}")

                # ── M2: Scan + policy for tools/call ────────────
                if method == "tools/call" and msg.params:
                    return self._scan_tools_call_request(msg)

                # ── M2: Scan + policy for sampling/createMessage ─
                if method == "sampling/createMessage" and msg.params:
                    return self._scan_sampling_request(msg)

                return InterceptResult(
                    message=msg,
                    should_forward=True,
                    intercepted=True,
                    method=method,
                )

        return InterceptResult(message=msg, should_forward=True, intercepted=False)

    def _scan_tools_call_request(self, msg: JsonRpcMessage) -> InterceptResult:
        """Scan tools/call arguments and apply policy (client→server)."""
        params = msg.params or {}
        tool_name = params.get("name", "")
        arguments = params.get("arguments", {})
        text_to_scan = json.dumps(arguments) if not isinstance(arguments, str) else arguments

        # Config: tool blocklist check
        cfg = self._policy_engine.config
        if cfg.tool_blocklist and tool_name.lower() in [t.lower() for t in cfg.tool_blocklist]:
            _log(f"[{self._server_name}] BLOCKED tool '{tool_name}' — in tool blocklist")
            block_result = PolicyResult(
                action=PolicyAction.BLOCK,
                policy_name="tool_blocklist",
                message=f"Tool '{tool_name}' is blocklisted. Contact your IT admin.",
            )
            return InterceptResult(
                message=msg,
                should_forward=False,
                response_override=execute_block(msg.msg_id, block_result),
                intercepted=True,
                method="tools/call",
                tool_name=tool_name,
                arguments_text=text_to_scan,
                policy_action="block",
            )

        # Schema validation: check arguments against stored inputSchema
        schema_violations: list[str] | None = None
        if self._inventory is not None:
            try:
                from vloex_mcp_proxy.security.schema_validator import validate_arguments

                schema = self._inventory.get_tool_schema(self._server_name, tool_name)
                if schema and arguments:
                    args_dict = (
                        arguments
                        if isinstance(arguments, dict)
                        else json.loads(arguments)
                        if isinstance(arguments, str)
                        else {}
                    )
                    validation = validate_arguments(args_dict, schema)
                    if not validation.valid:
                        schema_violations = validation.errors
                        _log(
                            f"[{self._server_name}] Schema violation for "
                            f"{tool_name}: {validation.errors}"
                        )
                        # Evaluate policy with schema_validation_failed flag
                        schema_policy = self._policy_engine.evaluate(
                            tool_name=tool_name,
                            server_name=self._server_name,
                            detections=[],
                            schema_validation_failed=True,
                        )
                        if schema_policy.action == PolicyAction.BLOCK:
                            _log(
                                f"[{self._server_name}] BLOCKED tools/call "
                                f"{tool_name} — schema validation failed"
                            )
                            return InterceptResult(
                                message=msg,
                                should_forward=False,
                                response_override=execute_block(msg.msg_id, schema_policy),
                                intercepted=True,
                                method="tools/call",
                                tool_name=tool_name,
                                arguments_text=text_to_scan,
                                policy_action="block",
                                schema_violations=schema_violations,
                            )
                        # Non-block (warn/log_only/allow) — forward with violations logged
            except ImportError:
                pass  # schema_validator not available
            except (json.JSONDecodeError, TypeError, AttributeError) as exc:
                _log(f"[{self._server_name}] Schema validation error for {tool_name}: {exc}")

        # Config: scan_arguments toggle
        if not cfg.scan_arguments:
            return InterceptResult(
                message=msg,
                should_forward=True,
                intercepted=True,
                method="tools/call",
                tool_name=tool_name,
                arguments_text=text_to_scan,
                policy_action="allow",
                schema_violations=schema_violations,
            )

        detections = self._scan_text(text_to_scan)
        policy_result = self._evaluate_policy(tool_name, detections)

        if policy_result.action == PolicyAction.BLOCK:
            _log(
                f"[{self._server_name}] BLOCKED tools/call {tool_name}: "
                f"{[d.data_type.value for d in detections]}"
            )
            return InterceptResult(
                message=msg,
                should_forward=False,
                response_override=execute_block(msg.msg_id, policy_result),
                intercepted=True,
                method="tools/call",
                tool_name=tool_name,
                arguments_text=text_to_scan,
                detections=detections,
                policy_action=policy_result.action.value,
                schema_violations=schema_violations,
            )

        if policy_result.action == PolicyAction.REDACT and detections:
            _log(
                f"[{self._server_name}] REDACTED tools/call {tool_name}: "
                f"{[d.data_type.value for d in detections]}"
            )
            new_params = redact_tool_arguments(params, detections)
            redacted_msg = self._rebuild_message(msg, new_params=new_params)
            return InterceptResult(
                message=redacted_msg,
                should_forward=True,
                intercepted=True,
                method="tools/call",
                tool_name=tool_name,
                arguments_text=text_to_scan,
                detections=detections,
                policy_action=policy_result.action.value,
                schema_violations=schema_violations,
            )

        if policy_result.action in (PolicyAction.WARN, PolicyAction.LOG_ONLY) and detections:
            _log(
                f"[{self._server_name}] WARN tools/call {tool_name}: "
                f"{[d.data_type.value for d in detections]}"
            )

        return InterceptResult(
            message=msg,
            should_forward=True,
            intercepted=True,
            method="tools/call",
            tool_name=tool_name,
            arguments_text=text_to_scan,
            detections=detections,
            policy_action=policy_result.action.value,
            schema_violations=schema_violations,
        )

    def _scan_sampling_request(self, msg: JsonRpcMessage) -> InterceptResult:
        """Scan sampling/createMessage params (client→server)."""
        # Config: block_sampling toggle — immediate block if enabled
        cfg = self._policy_engine.config
        if cfg.block_sampling:
            _log(f"[{self._server_name}] BLOCKED sampling — block_sampling enabled")
            block_result = PolicyResult(
                action=PolicyAction.BLOCK,
                policy_name="block_sampling",
                message="Sampling is disabled by policy. Contact your IT admin.",
            )
            return InterceptResult(
                message=msg,
                should_forward=False,
                response_override=execute_block(msg.msg_id, block_result),
                intercepted=True,
                method="sampling/createMessage",
                policy_action="block",
            )

        params = msg.params or {}
        # Extract text from messages list
        text_parts: list[str] = []
        messages = params.get("messages", [])
        for m in messages:
            content = m.get("content", "")
            if isinstance(content, dict):
                text_parts.append(content.get("text", ""))
            elif isinstance(content, str):
                text_parts.append(content)
        text_to_scan = " ".join(text_parts)

        # Sampling abuse heuristics — track timestamps and check patterns
        now = time.monotonic()
        self._sampling_timestamps.append(now)
        # Trim timestamps older than 120s to avoid unbounded growth
        cutoff = time.monotonic() - 120.0
        while self._sampling_timestamps and self._sampling_timestamps[0] <= cutoff:
            self._sampling_timestamps.popleft()

        sampling_security_alerts: list[dict] | None = None
        try:
            from vloex_mcp_proxy.security.sampling_heuristics import (
                check_sampling_abuse,
            )

            abuse_alerts = check_sampling_abuse(
                text_to_scan, self._sampling_timestamps, self._server_name
            )
            if abuse_alerts:
                sampling_security_alerts = [
                    {
                        "server_name": self._server_name,
                        "severity": a.severity,
                        "change_type": f"sampling_{a.pattern}",
                        "tool_name": None,
                        "detail": a.detail,
                    }
                    for a in abuse_alerts
                ]
                _log(
                    f"[{self._server_name}] Sampling abuse detected: "
                    f"{[a.pattern for a in abuse_alerts]}"
                )
        except ImportError:
            pass

        if not text_to_scan.strip():
            return InterceptResult(
                message=msg,
                should_forward=True,
                intercepted=True,
                method="sampling/createMessage",
                arguments_text="",
                security_alerts=sampling_security_alerts,
            )

        detections = self._scan_text(text_to_scan)
        policy_result = self._evaluate_policy(
            "sampling/createMessage",
            detections,
            sampling_abuse_detected=bool(sampling_security_alerts),
        )

        if policy_result.action == PolicyAction.BLOCK:
            _log(f"[{self._server_name}] BLOCKED sampling/createMessage")
            return InterceptResult(
                message=msg,
                should_forward=False,
                response_override=execute_block(msg.msg_id, policy_result),
                intercepted=True,
                method="sampling/createMessage",
                arguments_text=text_to_scan,
                detections=detections,
                policy_action=policy_result.action.value,
                security_alerts=sampling_security_alerts,
            )

        if policy_result.action == PolicyAction.REDACT and detections:
            _log(f"[{self._server_name}] REDACTED sampling/createMessage")
            # Redact text in each message's content
            new_messages = []
            for m in messages:
                content = m.get("content", "")
                if isinstance(content, dict) and "text" in content:
                    new_content = {**content, "text": execute_redact(content["text"], detections)}
                    new_messages.append({**m, "content": new_content})
                elif isinstance(content, str):
                    new_messages.append({**m, "content": execute_redact(content, detections)})
                else:
                    new_messages.append(m)
            new_params = {**params, "messages": new_messages}
            redacted_msg = self._rebuild_message(msg, new_params=new_params)
            return InterceptResult(
                message=redacted_msg,
                should_forward=True,
                intercepted=True,
                method="sampling/createMessage",
                arguments_text=text_to_scan,
                detections=detections,
                policy_action=policy_result.action.value,
                security_alerts=sampling_security_alerts,
            )

        if detections:
            _log(
                f"[{self._server_name}] WARN sampling/createMessage: "
                f"{[d.data_type.value for d in detections]}"
            )

        return InterceptResult(
            message=msg,
            should_forward=True,
            intercepted=True,
            method="sampling/createMessage",
            arguments_text=text_to_scan,
            detections=detections,
            policy_action=policy_result.action.value,
            security_alerts=sampling_security_alerts,
        )

    # ------------------------------------------------------------------
    # Server → Client interception
    # ------------------------------------------------------------------

    def intercept_server_message(self, msg: JsonRpcMessage) -> InterceptResult:
        """Process a message from the server heading to the client."""
        if msg.msg_type == MessageType.INVALID:
            return InterceptResult(message=msg, should_forward=True, intercepted=False)

        if msg.msg_type == MessageType.BATCH:
            return self._intercept_batch(msg, Direction.SERVER_TO_CLIENT)

        # Server-sent notifications
        if msg.msg_type == MessageType.NOTIFICATION:
            method = msg.method
            if method and method in INTERCEPTED_METHODS:
                _log(f"[{self._server_name}] server->client {method} (notification)")
                return InterceptResult(
                    message=msg,
                    should_forward=True,
                    intercepted=True,
                    method=method,
                )
            return InterceptResult(message=msg, should_forward=True, intercepted=False)

        # Response or error response — correlate with pending request
        if msg.msg_type in (MessageType.RESPONSE, MessageType.ERROR_RESPONSE):
            if msg.msg_id is not None and msg.msg_id in self._pending_requests:
                method, request_ts = self._pending_requests.pop(msg.msg_id)
                _log(
                    f"[{self._server_name}] server->client response for {method} (id={msg.msg_id})"
                )

                # ── P2: Extract server protocol version ───────
                if method == "initialize" and msg.result and isinstance(msg.result, dict):
                    version = msg.result.get("protocolVersion")
                    if version:
                        self._server_protocol_version = str(version)
                        _log(f"[{self._server_name}] Server protocol version: {version}")
                        if (
                            self._client_protocol_version
                            and self._server_protocol_version != self._client_protocol_version
                        ):
                            _log(
                                f"[{self._server_name}] WARNING: Protocol version mismatch! "
                                f"Client={self._client_protocol_version} "
                                f"Server={self._server_protocol_version}"
                            )

                # ── M5a: Rug-pull check on tools/list responses ──
                if method == "tools/list" and msg.msg_type == MessageType.RESPONSE:
                    alerts, should_block = self._check_tools_list_response(msg)
                    if alerts:
                        if should_block:
                            _log(
                                f"[{self._server_name}] BLOCKED tools/list — "
                                f"rug-pull detected (block_on_rug_pull enabled)"
                            )
                            error_msg = make_error_response(
                                msg.msg_id,
                                -32001,
                                "Vloex: Server tools changed unexpectedly (rug-pull detected). "
                                "Contact your IT admin.",
                            )
                            return InterceptResult(
                                message=msg,
                                should_forward=False,
                                response_override=error_msg,
                                intercepted=True,
                                method=method,
                                security_alerts=alerts,
                                policy_action="block",
                            )
                        return InterceptResult(
                            message=msg,
                            should_forward=True,
                            intercepted=True,
                            method=method,
                            security_alerts=alerts,
                        )

                # ── M2: Scan results for tools/call responses ───
                if method == "tools/call" and msg.msg_type == MessageType.RESPONSE:
                    return self._scan_tools_call_response(msg, method, request_ts=request_ts)

                # ── M2: Scan sampling/createMessage responses ────
                if method == "sampling/createMessage" and msg.msg_type == MessageType.RESPONSE:
                    return self._scan_sampling_response(msg, method)

                # ── M2: Scan resources/read responses ────────────
                if method == "resources/read" and msg.msg_type == MessageType.RESPONSE:
                    return self._scan_resources_read_response(msg, method)

                # ── M2: Scan prompts/get responses ────────────────
                if method == "prompts/get" and msg.msg_type == MessageType.RESPONSE:
                    return self._scan_prompts_get_response(msg, method)

                return InterceptResult(
                    message=msg,
                    should_forward=True,
                    intercepted=True,
                    method=method,
                )

        return InterceptResult(message=msg, should_forward=True, intercepted=False)

    def _check_tools_list_response(self, msg: JsonRpcMessage) -> tuple[list[dict], bool]:
        """Run rug-pull detection on tools/list response.

        Returns (alert_dicts, should_block). should_block is True only when
        block_on_rug_pull is enabled AND severity is HIGH or CRITICAL.
        """
        if self._rugpull_detector is None:
            return [], False
        result = msg.result
        if not isinstance(result, dict):
            return [], False
        tools = result.get("tools", [])
        if not isinstance(tools, list):
            return [], False
        try:
            alerts = self._rugpull_detector.check_tools_list(self._server_name, tools)
            if not alerts:
                return [], False
            alert_dicts = [
                {
                    "server_name": a.server_name,
                    "severity": a.severity.value
                    if hasattr(a.severity, "value")
                    else str(a.severity),
                    "change_type": a.change_type.value
                    if hasattr(a.change_type, "value")
                    else str(a.change_type),
                    "tool_name": a.tool_name,
                    "detail": a.detail,
                }
                for a in alerts
            ]
            # Config: block_on_rug_pull — block on HIGH or CRITICAL severity
            should_block = False
            cfg = self._policy_engine.config
            if cfg.block_on_rug_pull:
                high_sev = {"high", "critical"}
                should_block = any(a.get("severity", "").lower() in high_sev for a in alert_dicts)
            return alert_dicts, should_block
        except Exception:
            _log("Rug-pull check failed (non-fatal)")
            return [], False

    def _scan_tools_call_response(
        self, msg: JsonRpcMessage, method: str, request_ts: float = 0.0
    ) -> InterceptResult:
        """Scan tools/call result (server->client).  Never block -- only redact or warn."""
        if msg.result is None:
            return InterceptResult(
                message=msg, should_forward=True, intercepted=True, method=method
            )

        text_to_scan = json.dumps(msg.result) if not isinstance(msg.result, str) else msg.result

        # Config: tool_call_timeout_seconds — warn when response is slow
        cfg = self._policy_engine.config
        if request_ts > 0:
            elapsed = time.monotonic() - request_ts
            if elapsed > cfg.tool_call_timeout_seconds:
                _log(
                    f"[{self._server_name}] Tool call took {elapsed:.1f}s "
                    f"(timeout: {cfg.tool_call_timeout_seconds}s)"
                )
        if len(text_to_scan.encode("utf-8")) > cfg.max_tool_result_size_bytes:
            _log(
                f"[{self._server_name}] Tool result exceeds max size "
                f"({len(text_to_scan.encode('utf-8'))} > {cfg.max_tool_result_size_bytes})"
            )
            return InterceptResult(
                message=msg,
                should_forward=True,
                intercepted=True,
                method=method,
                result_text=text_to_scan[:256] + "...[oversized]",
                policy_action="warn",
            )

        # Config: scan_results toggle
        if not cfg.scan_results:
            return InterceptResult(
                message=msg,
                should_forward=True,
                intercepted=True,
                method=method,
                result_text=text_to_scan,
                policy_action="allow",
            )

        detections = self._scan_text(text_to_scan)

        if not detections:
            return InterceptResult(
                message=msg,
                should_forward=True,
                intercepted=True,
                method=method,
                result_text=text_to_scan,
            )

        policy_result = self._evaluate_policy("tools/call", detections)

        # Server responses are NEVER blocked -- the tool already executed.
        # Downgrade block to redact for responses.
        action = policy_result.action
        if action == PolicyAction.BLOCK:
            action = PolicyAction.REDACT

        if action == PolicyAction.REDACT:
            _log(
                f"[{self._server_name}] REDACTED tools/call response: "
                f"{[d.data_type.value for d in detections]}"
            )
            new_result = redact_tool_result(msg.result, detections)
            redacted_msg = self._rebuild_message(msg, new_result=new_result, use_result=True)
            return InterceptResult(
                message=redacted_msg,
                should_forward=True,
                intercepted=True,
                method=method,
                result_text=text_to_scan,
                detections=detections,
                policy_action=action.value,
            )

        if detections:
            _log(
                f"[{self._server_name}] WARN tools/call response: "
                f"{[d.data_type.value for d in detections]}"
            )

        return InterceptResult(
            message=msg,
            should_forward=True,
            intercepted=True,
            method=method,
            result_text=text_to_scan,
            detections=detections,
            policy_action=action.value,
        )

    def _scan_sampling_response(self, msg: JsonRpcMessage, method: str) -> InterceptResult:
        """Scan sampling/createMessage response (server→client).  Never block."""
        result = msg.result
        if not isinstance(result, dict):
            return InterceptResult(
                message=msg, should_forward=True, intercepted=True, method=method
            )

        content = result.get("content", {})
        text = ""
        if isinstance(content, dict):
            text = content.get("text", "")
        elif isinstance(content, str):
            text = content

        if not text:
            return InterceptResult(
                message=msg, should_forward=True, intercepted=True, method=method
            )

        detections = self._scan_text(text)
        if not detections:
            return InterceptResult(
                message=msg, should_forward=True, intercepted=True, method=method
            )

        policy_result = self._evaluate_policy("sampling/createMessage", detections)
        action = policy_result.action
        if action == PolicyAction.BLOCK:
            action = PolicyAction.REDACT

        if action == PolicyAction.REDACT:
            _log(f"[{self._server_name}] REDACTED sampling response")
            if isinstance(content, dict) and "text" in content:
                new_content = {**content, "text": execute_redact(content["text"], detections)}
            else:
                new_content = execute_redact(str(content), detections)
            new_result = {**result, "content": new_content}
            redacted_msg = self._rebuild_message(msg, new_result=new_result, use_result=True)
            return InterceptResult(
                message=redacted_msg, should_forward=True, intercepted=True, method=method
            )

        if detections:
            _log(
                f"[{self._server_name}] WARN sampling response: "
                f"{[d.data_type.value for d in detections]}"
            )

        return InterceptResult(message=msg, should_forward=True, intercepted=True, method=method)

    def _scan_resources_read_response(self, msg: JsonRpcMessage, method: str) -> InterceptResult:
        """Scan resources/read response (server→client).  Never block."""
        result = msg.result
        if not isinstance(result, dict):
            return InterceptResult(
                message=msg, should_forward=True, intercepted=True, method=method
            )

        contents = result.get("contents", [])
        if not isinstance(contents, list):
            return InterceptResult(
                message=msg, should_forward=True, intercepted=True, method=method
            )

        # Scan all text values in contents
        all_text = " ".join(
            item.get("text", "") for item in contents if isinstance(item, dict) and "text" in item
        )
        if not all_text.strip():
            return InterceptResult(
                message=msg, should_forward=True, intercepted=True, method=method
            )

        detections = self._scan_text(all_text)
        if not detections:
            return InterceptResult(
                message=msg, should_forward=True, intercepted=True, method=method
            )

        policy_result = self._evaluate_policy("resources/read", detections)
        action = policy_result.action
        if action == PolicyAction.BLOCK:
            action = PolicyAction.REDACT

        if action == PolicyAction.REDACT:
            _log(f"[{self._server_name}] REDACTED resources/read response")
            new_contents = []
            for item in contents:
                if isinstance(item, dict) and "text" in item:
                    new_contents.append({**item, "text": execute_redact(item["text"], detections)})
                else:
                    new_contents.append(item)
            new_result = {**result, "contents": new_contents}
            redacted_msg = self._rebuild_message(msg, new_result=new_result, use_result=True)
            return InterceptResult(
                message=redacted_msg, should_forward=True, intercepted=True, method=method
            )

        if detections:
            _log(
                f"[{self._server_name}] WARN resources/read response: "
                f"{[d.data_type.value for d in detections]}"
            )

        return InterceptResult(message=msg, should_forward=True, intercepted=True, method=method)

    def _scan_prompts_get_response(self, msg: JsonRpcMessage, method: str) -> InterceptResult:
        """Scan prompts/get response (server→client).  Never block."""
        result = msg.result
        if not isinstance(result, dict):
            return InterceptResult(
                message=msg, should_forward=True, intercepted=True, method=method
            )

        # prompts/get returns {messages: [{role, content: {type, text}}]}
        messages = result.get("messages", [])
        if not isinstance(messages, list):
            return InterceptResult(
                message=msg, should_forward=True, intercepted=True, method=method
            )

        text_parts: list[str] = []
        for m in messages:
            if not isinstance(m, dict):
                continue
            content = m.get("content", "")
            if isinstance(content, dict):
                text_parts.append(content.get("text", ""))
            elif isinstance(content, str):
                text_parts.append(content)
        text_to_scan = " ".join(text_parts)

        if not text_to_scan.strip():
            return InterceptResult(
                message=msg, should_forward=True, intercepted=True, method=method
            )

        detections = self._scan_text(text_to_scan)
        if not detections:
            return InterceptResult(
                message=msg, should_forward=True, intercepted=True, method=method
            )

        policy_result = self._evaluate_policy("prompts/get", detections)
        action = policy_result.action
        if action == PolicyAction.BLOCK:
            action = PolicyAction.REDACT

        if action == PolicyAction.REDACT:
            _log(f"[{self._server_name}] REDACTED prompts/get response")
            new_messages = []
            for m in messages:
                if not isinstance(m, dict):
                    new_messages.append(m)
                    continue
                content = m.get("content", "")
                if isinstance(content, dict) and "text" in content:
                    new_content = {**content, "text": execute_redact(content["text"], detections)}
                    new_messages.append({**m, "content": new_content})
                elif isinstance(content, str):
                    new_messages.append({**m, "content": execute_redact(content, detections)})
                else:
                    new_messages.append(m)
            new_result = {**result, "messages": new_messages}
            redacted_msg = self._rebuild_message(msg, new_result=new_result, use_result=True)
            return InterceptResult(
                message=redacted_msg, should_forward=True, intercepted=True, method=method
            )

        if detections:
            _log(
                f"[{self._server_name}] WARN prompts/get response: "
                f"{[d.data_type.value for d in detections]}"
            )

        return InterceptResult(message=msg, should_forward=True, intercepted=True, method=method)

    # ------------------------------------------------------------------
    # Batch handling
    # ------------------------------------------------------------------

    def _intercept_batch(self, msg: JsonRpcMessage, direction: Direction) -> InterceptResult:
        """Process a batch message by checking each sub-message.

        Applies per-sub-message block/redact results:
        - Blocked sub-messages are removed from the forwarded batch; their
          error overrides are collected and concatenated as separate responses.
        - Redacted sub-messages replace the original in the forwarded batch.
        - If ALL sub-messages are blocked, the entire batch is not forwarded.
        """
        any_intercepted = False
        intercepted_methods: list[str] = []
        forwarded_sub: list[JsonRpcMessage] = []
        override_responses: list[bytes] = []

        for sub_msg in msg.batch:
            if direction == Direction.CLIENT_TO_SERVER:
                result = self.intercept_client_message(sub_msg)
            else:
                result = self.intercept_server_message(sub_msg)

            if result.intercepted:
                any_intercepted = True
                if result.method:
                    intercepted_methods.append(result.method)

            if not result.should_forward:
                # Blocked — collect override response, do NOT forward this sub-message
                if result.response_override:
                    override_responses.append(result.response_override)
            else:
                # Forward the (possibly redacted) message
                forwarded_sub.append(result.message)

        # If all sub-messages were blocked, don't forward the batch at all
        if not forwarded_sub:
            combined_override = b"".join(override_responses) if override_responses else None
            return InterceptResult(
                message=msg,
                should_forward=False,
                response_override=combined_override,
                intercepted=any_intercepted,
                method=",".join(intercepted_methods) if intercepted_methods else None,
            )

        # Rebuild the batch with surviving sub-messages
        batch_list = [json.loads(sub.raw) for sub in forwarded_sub]
        new_raw = json.dumps(batch_list, separators=(",", ":")).encode()
        rebuilt = JsonRpcMessage(
            raw=new_raw,
            msg_type=MessageType.BATCH,
            batch=forwarded_sub,
        )

        # If some sub-messages were blocked, prepend their error responses
        combined_override = b"".join(override_responses) if override_responses else None

        return InterceptResult(
            message=rebuilt,
            should_forward=True,
            response_override=combined_override,
            intercepted=any_intercepted,
            method=",".join(intercepted_methods) if intercepted_methods else None,
        )
