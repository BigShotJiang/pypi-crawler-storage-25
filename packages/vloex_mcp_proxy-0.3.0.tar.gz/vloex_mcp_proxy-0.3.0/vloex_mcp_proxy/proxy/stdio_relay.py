"""Core stdio relay loop for the MCP proxy.

Reads newline-delimited JSON-RPC messages from one pipe, passes them
through the interceptor, and writes them to another pipe. Runs two
concurrent relay tasks (client->server and server->client).
"""

from __future__ import annotations

import asyncio
import os
import signal
import sys
from typing import Protocol

from vloex_mcp_proxy.proxy.child_process import (
    STREAM_BUFFER_LIMIT,
    shutdown_server,
    spawn_server,
)
from vloex_mcp_proxy.proxy.interceptor import Direction, Interceptor
from vloex_mcp_proxy.proxy.jsonrpc import make_error_response, parse_message

# Writes larger than this are offloaded to the thread pool to avoid blocking
# the event loop (MCP tool results can be multi-MB).
_LARGE_WRITE_THRESHOLD: int = 65_536


def _log(msg: str) -> None:
    """Log to stderr (stdout is the MCP communication channel)."""
    print(f"[vloex-proxy] {msg}", file=sys.stderr, flush=True)


class MessageWriter(Protocol):
    """Protocol for anything that can write bytes and drain."""

    def write(self, data: bytes) -> None:
        """Write data."""
        ...

    async def drain(self) -> None:
        """Flush buffered data."""
        ...


class RawStdoutWriter:
    """Writer adapter for raw stdout that bypasses asyncio pipe transport.

    This avoids the 'Pipe transport is only for pipes, sockets and
    character devices' error that occurs when stdout is redirected
    to a file or certain shell pipe configurations.

    Buffers data in write() and flushes in drain(). Large writes
    (>64KB) are offloaded to the thread pool to avoid blocking the
    event loop — MCP tool results can be multi-MB.
    """

    _MAX_BUF_SIZE: int = 32 * 1024 * 1024  # 32 MB guard

    def __init__(self, fd: int) -> None:
        self._fd = fd
        self._buf = bytearray()

    def write(self, data: bytes) -> None:
        """Buffer data for the next drain() call."""
        if len(self._buf) + len(data) > self._MAX_BUF_SIZE:
            raise OSError("Write buffer overflow — message too large")
        self._buf.extend(data)

    def _write_all(self, data: bytes) -> None:
        """Write all bytes to fd, handling partial writes."""
        mv = memoryview(data)
        written = 0
        while written < len(data):
            n = os.write(self._fd, mv[written:])
            written += n

    async def drain(self) -> None:
        """Flush buffered data. Large writes use the thread pool."""
        if not self._buf:
            return
        data = bytes(self._buf)
        self._buf.clear()
        if len(data) > _LARGE_WRITE_THRESHOLD:
            loop = asyncio.get_running_loop()
            await loop.run_in_executor(None, self._write_all, data)
        else:
            self._write_all(data)


async def relay_stream(
    reader: asyncio.StreamReader,
    writer: MessageWriter,
    interceptor: Interceptor,
    direction: Direction,
    label: str,
    on_intercept: object | None = None,
    response_writer: MessageWriter | None = None,
) -> None:
    """Relay messages from reader to writer, passing through the interceptor.

    Reads newline-delimited messages. Each line is one JSON-RPC message.
    Runs until EOF on reader or writer is closed.

    Args:
        reader: The source stream to read messages from.
        writer: The destination stream to write messages to. Must have
                write(bytes) and drain() methods.
        interceptor: The interceptor to process each message through.
        direction: Whether this is client->server or server->client.
        label: Human-readable label for logging (e.g., "client->server").
        on_intercept: Optional callback invoked for intercepted messages
                      (fire-and-forget for event capture).
        response_writer: Optional separate writer for block/override responses.
                         For client->server relay, this should be the client
                         writer so blocked responses go back to the client,
                         not to the server.
    """
    override_writer = response_writer or writer
    while True:
        try:
            line = await reader.readline()
        except (ConnectionResetError, BrokenPipeError):
            _log(f"{label}: connection lost")
            break

        # Empty bytes means EOF
        if not line:
            _log(f"{label}: EOF")
            break

        # Skip empty lines (some clients send \n between messages)
        stripped = line.strip()
        if not stripped:
            continue

        # Parse and intercept
        msg = parse_message(stripped)

        if direction == Direction.CLIENT_TO_SERVER:
            result = interceptor.intercept_client_message(msg)
        else:
            result = interceptor.intercept_server_message(msg)

        # M4: Event capture callback (fire-and-forget)
        if result.intercepted and on_intercept is not None:
            try:
                on_intercept(result, direction)
            except Exception:
                pass  # Never let event capture crash the relay

        # Check result.should_forward and result.response_override
        if not result.should_forward:
            if result.response_override is not None:
                try:
                    override_writer.write(result.response_override)
                    await override_writer.drain()
                except (ConnectionResetError, BrokenPipeError, OSError):
                    _log(f"{label}: writer broken pipe on override")
                    break
            continue

        # If batch had some blocked sub-messages, send their error responses first
        if result.response_override is not None:
            try:
                override_writer.write(result.response_override)
                await override_writer.drain()
            except (ConnectionResetError, BrokenPipeError, OSError):
                _log(f"{label}: writer broken pipe on partial override")
                break

        # Forward the message (possibly modified by interceptor redaction)
        out_msg = result.message
        data = out_msg.raw if out_msg.raw.endswith(b"\n") else out_msg.raw + b"\n"
        try:
            writer.write(data)
            await writer.drain()
        except (ConnectionResetError, BrokenPipeError, OSError):
            _log(f"{label}: writer broken pipe")
            break


async def run_proxy(
    server_command: str,
    server_args: list[str],
    server_name: str,
    server_env: dict[str, str] | None = None,
    policy_file: str | None = None,
    backend_url: str | None = None,
    inventory_path: str | None = None,
    telemetry: object | None = None,
) -> int:
    """Main proxy entry point.

    1. Spawn the MCP server child process
    2. Set up two relay tasks:
       - stdin (from MCP client) -> interceptor -> server stdin
       - server stdout -> interceptor -> stdout (to MCP client)
    3. Wait for either relay to complete (EOF or error)
    4. Shut down the server process
    5. Return exit code

    Args:
        server_command: Command to start the MCP server.
        server_args: Arguments for the server command.
        server_name: Human-readable name for logging.
        server_env: Optional environment variables for the server.

    Returns:
        0 on clean shutdown, 1 on error.
    """
    _log(f"Starting proxy for server '{server_name}'")

    # Spawn the MCP server
    try:
        managed = await spawn_server(server_command, server_args, env=server_env)
    except FileNotFoundError:
        _log(f"Server command not found: {server_command}")
        # Try to send error to client stdout
        try:
            error_msg = make_error_response(
                None, -32603, "Vloex: MCP server failed to start. Check server configuration."
            )
            sys.stdout.buffer.write(error_msg)
            sys.stdout.buffer.flush()
        except (BrokenPipeError, OSError):
            pass
        return 1
    except OSError as e:
        _log(f"Failed to start server: {e}")
        return 1

    # M5a: Server inventory for rug-pull detection
    inventory = None
    if inventory_path or backend_url:
        try:
            from pathlib import Path

            from vloex_mcp_proxy.security.inventory import ServerInventory

            inv_path = inventory_path
            if not inv_path and backend_url:
                from vloex_mcp_proxy.backend.config import get_vloex_dir

                inv_path = str(get_vloex_dir() / "server_inventory.json")
            if inv_path:
                inventory = ServerInventory(Path(inv_path))
                _log(f"Server inventory active: {inv_path}")
        except ImportError:
            _log("Security module not available — inventory disabled")
        except Exception as exc:
            _log(f"Inventory init failed: {exc}")

    interceptor = Interceptor(server_name, policy_file=policy_file, inventory=inventory)

    # ── M4: Backend integration (optional) ─────────────────────
    event_queue = None
    http_client = None
    backend_tasks: list[asyncio.Task] = []
    device_id: str | None = None
    user_email: str | None = None

    if backend_url:
        try:
            from vloex_mcp_proxy.backend.config import (
                get_device_token,
                get_or_create_device_id,
                get_user_email_from_token,
                get_vloex_dir,
            )
            from vloex_mcp_proxy.backend.event_queue import EventQueue
            from vloex_mcp_proxy.backend.heartbeat_worker import HeartbeatWorker
            from vloex_mcp_proxy.backend.http_client import VloexClient
            from vloex_mcp_proxy.backend.sync_worker import SyncWorker

            vloex_dir = get_vloex_dir()
            device_id = get_or_create_device_id(vloex_dir)
            device_token = get_device_token(vloex_dir)
            if device_token:
                user_email = get_user_email_from_token(device_token)

            event_queue = EventQueue(str(vloex_dir / "event_queue.db"))
            await event_queue.init()

            http_client = VloexClient(backend_url, device_token=device_token)
            await http_client.init()

            heartbeat_worker = HeartbeatWorker(
                client=http_client,
                policy_engine=interceptor.policy_engine,
                device_id=device_id,
                vloex_dir=vloex_dir,
            )
            heartbeat_worker.load_cached_config()

            # Wire user identity into interceptor for policy scope evaluation
            interceptor.set_user_email(user_email)
            if heartbeat_worker.user_department:
                interceptor.set_department(heartbeat_worker.user_department)

            # Sync department to interceptor after each heartbeat config update
            def _on_heartbeat_config_updated() -> None:
                interceptor.set_department(heartbeat_worker.user_department)

            heartbeat_worker.set_on_config_updated(_on_heartbeat_config_updated)

            sync_worker = SyncWorker(queue=event_queue, client=http_client)

            backend_tasks.append(asyncio.ensure_future(heartbeat_worker.run()))
            backend_tasks.append(asyncio.ensure_future(sync_worker.run()))

            _log(f"Backend integration active (device_id={device_id[:8]}...)")
        except ImportError:
            _log("Backend dependencies not installed — running in standalone mode")
        except Exception as exc:
            _log(f"Backend init failed: {exc} — running in standalone mode")

    # M4: Event capture callback for relay_stream
    def _capture_event(result, direction) -> None:
        """Queue intercepted events for backend sync (fire-and-forget)."""
        if event_queue is None or device_id is None:
            return

        # Handle rug-pull security alerts (before method filter)
        if result.security_alerts:
            try:
                from vloex_mcp_proxy.backend.event_builder import build_rugpull_event

                for alert in result.security_alerts:
                    event = build_rugpull_event(
                        server_name=alert["server_name"],
                        change_type=alert["change_type"],
                        severity=alert["severity"],
                        tool_name=alert.get("tool_name"),
                        detail=alert.get("detail", ""),
                        device_id=device_id,
                        user_email=user_email,
                    )
                    asyncio.get_running_loop().create_task(event_queue.enqueue(event))
            except Exception as exc:
                _log(f"Event capture failed (rugpull): {exc}")

        # Regular event capture: only tools/call and sampling/createMessage
        if result.method not in ("tools/call", "sampling/createMessage"):
            return
        if result.arguments_text is None and result.result_text is None:
            return
        try:
            from vloex_mcp_proxy.backend.event_builder import build_event

            event = build_event(
                server_name=server_name,
                method=result.method or "",
                tool_name=result.tool_name,
                arguments_text=result.arguments_text,
                result_text=result.result_text,
                detections=result.detections or [],
                policy_action=result.policy_action or "allow",
                device_id=device_id,
                user_email=user_email,
                department=interceptor.department,
            )
            asyncio.get_running_loop().create_task(event_queue.enqueue(event))
        except Exception as exc:
            _log(f"Event capture failed: {exc}")

    # Set up shutdown event for signal handling
    shutdown_event = asyncio.Event()

    loop = asyncio.get_running_loop()
    try:
        for sig in (signal.SIGTERM, signal.SIGINT):
            loop.add_signal_handler(sig, shutdown_event.set)
    except NotImplementedError:
        # Windows: asyncio signal handlers not supported, fall back to signal module.
        # Use call_soon_threadsafe since signal handlers may run on any thread.
        signal.signal(signal.SIGINT, lambda _s, _f: loop.call_soon_threadsafe(shutdown_event.set))

    # Set up stdin reader (asyncio stream from proxy's stdin)
    # Use 16 MB buffer to handle large MCP tool results (default is only 64 KB).
    client_reader = asyncio.StreamReader(limit=STREAM_BUFFER_LIMIT)
    protocol = asyncio.StreamReaderProtocol(client_reader)
    await loop.connect_read_pipe(lambda: protocol, sys.stdin.buffer)

    # Duplicate stdout fd THEN redirect sys.stdout to stderr — any accidental
    # print() or traceback goes to stderr, not the JSON-RPC stream.
    stdout_fd = os.dup(sys.stdout.buffer.fileno())
    sys.stdout = sys.stderr
    client_writer = RawStdoutWriter(stdout_fd)

    # Create relay tasks
    client_to_server = asyncio.ensure_future(
        relay_stream(
            reader=client_reader,
            writer=managed.stdin,
            interceptor=interceptor,
            direction=Direction.CLIENT_TO_SERVER,
            label="client->server",
            on_intercept=_capture_event,
            response_writer=client_writer,
        )
    )
    server_to_client = asyncio.ensure_future(
        relay_stream(
            reader=managed.stdout,
            writer=client_writer,
            interceptor=interceptor,
            direction=Direction.SERVER_TO_CLIENT,
            label="server->client",
            on_intercept=_capture_event,
        )
    )

    shutdown_task = asyncio.ensure_future(shutdown_event.wait())

    # Wait for any of: relay EOF, signal, or server exit
    done, pending = await asyncio.wait(
        [client_to_server, server_to_client, shutdown_task],
        return_when=asyncio.FIRST_COMPLETED,
    )

    _log("Relay ended, cleaning up...")

    # Track whether server stopped on its own (crash or unexpected exit)
    server_initiated_exit = (
        server_to_client in done and shutdown_task not in done and client_to_server not in done
    )

    # If client->server finished (client EOF) but server->client is still running,
    # close the server's stdin to signal EOF to the server. Then wait briefly for
    # the server to finish processing and send its output before shutting down.
    if client_to_server in done and server_to_client in pending:
        _log("Client EOF — closing server stdin and draining responses...")
        try:
            managed.stdin.close()
            await managed.stdin.wait_closed()
        except (OSError, BrokenPipeError):
            pass
        # Give the server a chance to flush its output
        try:
            await asyncio.wait_for(server_to_client, timeout=5.0)
        except (TimeoutError, asyncio.CancelledError):
            pass
        pending = pending - {server_to_client}

    # Cancel remaining pending tasks
    for task in pending:
        task.cancel()
        try:
            await task
        except asyncio.CancelledError:
            pass

    # Cancel backend tasks
    for task in backend_tasks:
        task.cancel()
        try:
            await task
        except asyncio.CancelledError:
            pass

    # Close backend resources
    if event_queue:
        await event_queue.close()
    if http_client:
        await http_client.close()

    # Shut down the server
    exit_code = await shutdown_server(managed, timeout=5.0)

    # Close the duplicated stdout fd
    try:
        os.close(stdout_fd)
    except OSError:
        pass

    _log(f"Proxy shut down (server exit code: {exit_code})")

    # Report crash to telemetry if available
    if telemetry is not None and server_initiated_exit and exit_code != 0:
        try:
            telemetry.record_crash(f"server_exit_code={exit_code}")
            telemetry.flush()
        except Exception:
            pass  # Never let telemetry crash the shutdown path

    # Propagate failure when the server crashed on its own (not signal/client EOF)
    if server_initiated_exit and exit_code != 0:
        return 1
    return 0
