"""Child process management for MCP server spawning.

Spawns the real MCP server as a child process, manages its lifecycle,
and provides clean shutdown with SIGTERM/SIGKILL fallback.
"""

from __future__ import annotations

import asyncio
import os
import signal
import sys
from dataclasses import dataclass

# 16 MB stream buffer limit — MCP tool results can exceed the default 64 KB.
STREAM_BUFFER_LIMIT: int = 16 * 1024 * 1024


@dataclass
class ManagedProcess:
    """A managed child process with stdin/stdout access."""

    process: asyncio.subprocess.Process
    stdin: asyncio.StreamWriter
    stdout: asyncio.StreamReader
    server_command: str
    server_args: list[str]


def _log(msg: str) -> None:
    """Log to stderr (stdout is the MCP communication channel)."""
    print(f"[vloex-proxy] {msg}", file=sys.stderr, flush=True)


async def spawn_server(
    command: str,
    args: list[str],
    env: dict[str, str] | None = None,
    stream_limit: int = STREAM_BUFFER_LIMIT,
) -> ManagedProcess:
    """Spawn an MCP server as a child process.

    The child's stdin and stdout are connected via PIPE for message relay.
    The child's stderr is passed through to the proxy's stderr so MCP server
    logs remain visible.

    Args:
        command: The server executable command (e.g., "npx", "python3").
        args: Arguments for the server command.
        env: Optional environment variables. If None, inherits current env.

    Raises:
        FileNotFoundError: if the command is not found.
        OSError: if the process cannot be started.
    """
    # If env is provided, merge with current env so PATH etc. are available
    process_env: dict[str, str] | None = None
    if env is not None:
        process_env = {**os.environ, **env}

    _log(f"Spawning server: {command} [{len(args)} args]")

    process = await asyncio.create_subprocess_exec(
        command,
        *args,
        stdin=asyncio.subprocess.PIPE,
        stdout=asyncio.subprocess.PIPE,
        stderr=None,  # Inherit proxy's stderr (pass-through)
        env=process_env,
        limit=stream_limit,
    )

    if process.stdin is None or process.stdout is None:
        raise OSError("Failed to connect to child process stdin/stdout pipes")

    _log(f"Server spawned (PID {process.pid})")

    return ManagedProcess(
        process=process,
        stdin=process.stdin,
        stdout=process.stdout,
        server_command=command,
        server_args=args,
    )


async def shutdown_server(managed: ManagedProcess, timeout: float = 5.0) -> int:
    """Gracefully shut down the server process.

    Sends SIGTERM first, waits up to `timeout` seconds, then sends SIGKILL
    if the process is still running.

    Args:
        managed: The managed process to shut down.
        timeout: Seconds to wait after SIGTERM before SIGKILL.

    Returns:
        The child process exit code.
    """
    process = managed.process

    if process.returncode is not None:
        _log(f"Server already exited (code {process.returncode})")
        return process.returncode

    _log("Shutting down server (SIGTERM)...")

    try:
        process.send_signal(signal.SIGTERM)
    except ProcessLookupError:
        # Process already exited between our check and signal
        return process.returncode if process.returncode is not None else -1

    try:
        await asyncio.wait_for(process.wait(), timeout=timeout)
    except TimeoutError:
        _log("Server did not exit after SIGTERM, sending SIGKILL...")
        try:
            process.kill()
        except ProcessLookupError:
            pass
        await process.wait()

    exit_code = process.returncode if process.returncode is not None else -1
    _log(f"Server exited (code {exit_code})")
    return exit_code


async def wait_for_exit(managed: ManagedProcess) -> int:
    """Wait for the child process to exit.

    Args:
        managed: The managed process to wait for.

    Returns:
        The child process exit code.
    """
    await managed.process.wait()
    return managed.process.returncode if managed.process.returncode is not None else -1
