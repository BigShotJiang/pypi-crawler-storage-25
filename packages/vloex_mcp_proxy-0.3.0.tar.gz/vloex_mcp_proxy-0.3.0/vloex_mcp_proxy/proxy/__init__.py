"""Proxy core — JSON-RPC relay, interception, and child process management."""
