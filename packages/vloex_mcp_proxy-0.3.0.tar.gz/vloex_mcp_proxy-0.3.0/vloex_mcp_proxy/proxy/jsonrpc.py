"""JSON-RPC 2.0 message parser and constructor.

Handles parsing, classification, and construction of JSON-RPC 2.0 messages
for the MCP stdio proxy. Never raises on parse failure — returns INVALID type
with raw bytes preserved for pass-through.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from enum import Enum
from typing import Any


class MessageType(Enum):
    """Classification of a JSON-RPC 2.0 message."""

    REQUEST = "request"
    NOTIFICATION = "notification"
    RESPONSE = "response"
    ERROR_RESPONSE = "error_response"
    BATCH = "batch"
    INVALID = "invalid"


@dataclass
class JsonRpcMessage:
    """A parsed JSON-RPC 2.0 message."""

    raw: bytes  # Original bytes (for pass-through)
    msg_type: MessageType
    method: str | None = None  # For requests/notifications
    msg_id: int | str | None = None  # For requests/responses
    params: dict[str, Any] | None = None
    result: Any = None  # For success responses
    error: dict[str, Any] | None = None  # For error responses
    batch: list[JsonRpcMessage] = field(default_factory=list)


MAX_MESSAGE_BYTES: int = 4 * 1024 * 1024  # 4 MB hard limit per message
MAX_BATCH_SIZE: int = 100  # Max sub-messages in a batch


def parse_message(data: bytes) -> JsonRpcMessage:
    """Parse raw bytes into a JsonRpcMessage.

    Never raises — returns INVALID type on parse failure, preserving
    the raw bytes for transparent pass-through.
    """
    if len(data) > MAX_MESSAGE_BYTES:
        return JsonRpcMessage(raw=data, msg_type=MessageType.INVALID)

    try:
        parsed = json.loads(data)
    except (json.JSONDecodeError, UnicodeDecodeError):
        return JsonRpcMessage(raw=data, msg_type=MessageType.INVALID)

    # Batch: top-level JSON array
    if isinstance(parsed, list):
        if len(parsed) > MAX_BATCH_SIZE:
            return JsonRpcMessage(raw=data, msg_type=MessageType.INVALID)
        sub_messages = []
        for item in parsed:
            # Each sub-message gets its OWN raw bytes (not the whole batch),
            # so M2 can reconstruct/redact individual items independently.
            sub_raw = json.dumps(item, separators=(",", ":")).encode()
            if not isinstance(item, dict):
                sub_messages.append(JsonRpcMessage(raw=sub_raw, msg_type=MessageType.INVALID))
                continue
            sub_msg = _classify_single(item, sub_raw)
            sub_messages.append(sub_msg)
        return JsonRpcMessage(raw=data, msg_type=MessageType.BATCH, batch=sub_messages)

    if not isinstance(parsed, dict):
        return JsonRpcMessage(raw=data, msg_type=MessageType.INVALID)

    return _classify_single(parsed, data)


def _classify_single(obj: dict[str, Any], raw: bytes) -> JsonRpcMessage:
    """Classify a single JSON-RPC object into the appropriate message type."""
    # Must be a dict with recognizable JSON-RPC fields
    has_method = "method" in obj
    has_id = "id" in obj
    has_result = "result" in obj
    has_error = "error" in obj

    if has_method and has_id:
        # Request: has method + id
        return JsonRpcMessage(
            raw=raw,
            msg_type=MessageType.REQUEST,
            method=obj.get("method"),
            msg_id=obj.get("id"),
            params=obj.get("params"),
        )

    if has_method and not has_id:
        # Notification: has method, no id
        return JsonRpcMessage(
            raw=raw,
            msg_type=MessageType.NOTIFICATION,
            method=obj.get("method"),
            params=obj.get("params"),
        )

    if has_error and has_id:
        # Error response: has error + id
        return JsonRpcMessage(
            raw=raw,
            msg_type=MessageType.ERROR_RESPONSE,
            msg_id=obj.get("id"),
            error=obj.get("error"),
        )

    if has_result and has_id:
        # Success response: has result + id
        return JsonRpcMessage(
            raw=raw,
            msg_type=MessageType.RESPONSE,
            msg_id=obj.get("id"),
            result=obj.get("result"),
        )

    # Valid JSON but not a recognizable JSON-RPC message
    return JsonRpcMessage(raw=raw, msg_type=MessageType.INVALID)


def make_error_response(msg_id: int | str | None, code: int, message: str) -> bytes:
    """Construct a JSON-RPC error response as bytes (newline-terminated).

    Args:
        msg_id: The request ID to associate the error with.
        code: JSON-RPC error code (e.g., -32600 for invalid request).
        message: Human-readable error description.

    Returns:
        Newline-terminated JSON bytes.
    """
    response = {
        "jsonrpc": "2.0",
        "error": {"code": code, "message": message},
        "id": msg_id,
    }
    return json.dumps(response, separators=(",", ":")).encode() + b"\n"


def make_success_response(msg_id: int | str | None, result: Any) -> bytes:
    """Construct a JSON-RPC success response as bytes (newline-terminated).

    Args:
        msg_id: The request ID to associate the response with.
        result: The result value.

    Returns:
        Newline-terminated JSON bytes.
    """
    response = {
        "jsonrpc": "2.0",
        "result": result,
        "id": msg_id,
    }
    return json.dumps(response, separators=(",", ":")).encode() + b"\n"
