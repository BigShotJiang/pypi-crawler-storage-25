"""CLI entry point for vloex-mcp-proxy.

Supports multiple modes:
- Proxy mode (default): stdio or HTTP relay for MCP tool call governance
- Discover mode: find MCP clients, rewrite configs, restore from backups
"""

from __future__ import annotations

import argparse
import asyncio
import json
import os
import sys
from pathlib import Path

from vloex_mcp_proxy import __version__


def main() -> None:
    """CLI entry point for vloex-mcp-proxy."""
    parser = argparse.ArgumentParser(
        prog="vloex-mcp-proxy",
        description="Vloex MCP Gateway — stdio proxy for MCP tool call governance",
    )
    parser.add_argument("--version", action="version", version=f"%(prog)s {__version__}")

    # Proxy mode args (on main parser for backward compat)
    # CRITICAL: required=False — validated inside _handle_proxy() instead,
    # so `vloex-mcp-proxy discover` works without --server-command.
    parser.add_argument(
        "--server-command",
        required=False,
        default=None,
        help="Command to start the real MCP server (e.g., 'npx')",
    )
    parser.add_argument(
        "--server-args",
        default="",
        help="Server command arguments: comma-separated (e.g., '-y,@mcp/server-filesystem,/tmp')"
        ' or JSON array (e.g., \'["-y","@mcp/server-filesystem","/tmp"]\')',
    )
    parser.add_argument(
        "--server-name",
        default=None,
        help="Human-readable name for the server (defaults to command basename)",
    )
    parser.add_argument(
        "--policy-file",
        default=None,
        help="Path to JSON policy file for scan + enforcement rules",
    )
    parser.add_argument(
        "--backend-url",
        default=None,
        help="Vloex backend URL for event sync and policy updates",
    )
    parser.add_argument(
        "--transport",
        choices=["stdio", "http"],
        default="stdio",
        help="Transport mode: stdio (default) or http (Streamable HTTP)",
    )
    parser.add_argument(
        "--remote-url",
        default=None,
        help="Remote MCP server URL (required when --transport http)",
    )
    parser.add_argument(
        "--port",
        type=int,
        default=0,
        help="Local port for HTTP transport (0 = dynamic, default: 0)",
    )

    # Discover subcommand
    subparsers = parser.add_subparsers(dest="command")
    discover_parser = subparsers.add_parser("discover", help="Discover MCP clients on this system")
    discover_parser.add_argument(
        "--rewrite",
        action="store_true",
        help="Rewrite configs to route through proxy",
    )
    discover_parser.add_argument(
        "--restore",
        action="store_true",
        help="Restore configs from backups",
    )
    discover_parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Show changes without writing",
    )
    discover_parser.add_argument(
        "--config-dir",
        type=str,
        default=None,
        help="Override base config directory (for testing)",
    )
    discover_parser.add_argument(
        "--proxy-command",
        type=str,
        default="vloex-mcp-proxy",
        help="Path to proxy binary",
    )

    # Enroll subcommand
    enroll_parser = subparsers.add_parser("enroll", help="Enroll this device with Vloex backend")
    enroll_parser.add_argument("--code", type=str, help="6-digit enrollment code")
    enroll_parser.add_argument("--token", type=str, help="Org enrollment token")
    enroll_parser.add_argument("--sso", action="store_true", help="Enroll via SSO (opens browser)")
    enroll_parser.add_argument("--backend-url", type=str, required=True, help="Vloex backend URL")
    enroll_parser.add_argument(
        "--user-email", type=str, default=None, help="User email for enrollment"
    )

    # Status subcommand
    subparsers.add_parser("status", help="Show enrollment and proxy status")

    # Daemon subcommand
    daemon_parser = subparsers.add_parser("daemon", help="Manage the Vloex daemon")
    daemon_sub = daemon_parser.add_subparsers(dest="daemon_action")
    daemon_start = daemon_sub.add_parser("start", help="Start the daemon")
    daemon_start.add_argument("--backend-url", type=str, default=None, help="Vloex backend URL")
    daemon_start.add_argument(
        "--foreground", action="store_true", default=True, help="Run in foreground (default)"
    )
    daemon_start.add_argument(
        "--run-as", default=None, help="Drop privileges to this user (default: no drop)"
    )
    daemon_sub.add_parser("stop", help="Stop the daemon")
    daemon_sub.add_parser("status", help="Show daemon status")

    # Uninstall subcommand
    uninstall_parser = subparsers.add_parser("uninstall", help="Remove Vloex proxy from system")
    uninstall_parser.add_argument(
        "--keep-data",
        action="store_true",
        help="Keep ~/.vloex/ data directory",
    )

    # Update subcommand
    update_parser = subparsers.add_parser("update", help="Check for and apply updates")
    update_parser.add_argument(
        "--check-only",
        action="store_true",
        help="Check for updates without applying",
    )

    args = parser.parse_args()

    if args.command == "discover":
        _handle_discover(args)
    elif args.command == "enroll":
        _handle_enroll(args)
    elif args.command == "status":
        _handle_status(args)
    elif args.command == "daemon":
        _handle_daemon(args)
    elif args.command == "uninstall":
        _handle_uninstall(args)
    elif args.command == "update":
        _handle_update(args)
    else:
        _handle_proxy(args)


def _handle_proxy(args: argparse.Namespace) -> None:
    """Handle proxy mode (stdio or HTTP transport)."""
    transport = getattr(args, "transport", "stdio")

    if transport == "http":
        _handle_http_proxy(args)
        return

    # stdio transport (existing M1+ behavior)
    from vloex_mcp_proxy.proxy.stdio_relay import run_proxy

    if not args.server_command:
        print("error: --server-command is required for stdio proxy mode", file=sys.stderr)
        sys.exit(2)

    # Parse server args: support JSON array format (from MCP configs) or comma-separated
    raw_args = args.server_args
    if raw_args and raw_args.startswith("["):
        try:
            parsed_args = json.loads(raw_args)
            server_args = [str(a) for a in parsed_args] if isinstance(parsed_args, list) else []
        except json.JSONDecodeError:
            server_args = [a for a in raw_args.split(",") if a]
    else:
        server_args = [a for a in raw_args.split(",") if a] if raw_args else []
    server_name = args.server_name or args.server_command.rsplit("/", 1)[-1]

    # M4: Backend URL from CLI arg or env var
    backend_url = args.backend_url or os.environ.get("VLOEX_BACKEND_URL")

    # Optional telemetry (opt-in only, wired in future milestone)
    _telemetry = None
    try:
        from vloex_mcp_proxy.backend.telemetry import TelemetryClient

        telemetry_enabled = False
        try:
            from vloex_mcp_proxy.packaging.enterprise_config import load_enterprise_config

            ec = load_enterprise_config()
            telemetry_enabled = ec.telemetry_enabled
        except ImportError:
            pass
        if telemetry_enabled:
            _telemetry = TelemetryClient(
                endpoint="",  # Backend endpoint -- not wired yet
                device_id="",
                proxy_version=__version__,
                enabled=True,
            )
    except ImportError:
        pass

    exit_code = asyncio.run(
        run_proxy(
            server_command=args.server_command,
            server_args=server_args,
            server_name=server_name,
            policy_file=args.policy_file,
            backend_url=backend_url,
            telemetry=_telemetry,
        )
    )
    sys.exit(exit_code)


def _handle_http_proxy(args: argparse.Namespace) -> None:
    """Handle HTTP transport proxy mode."""
    from vloex_mcp_proxy.proxy.http_relay import run_http_proxy

    remote_url = getattr(args, "remote_url", None)
    if not remote_url:
        print("error: --remote-url is required when --transport http", file=sys.stderr)
        sys.exit(2)

    server_name = args.server_name or remote_url
    port = getattr(args, "port", 0)

    # Backend URL from CLI arg or env var
    backend_url = args.backend_url or os.environ.get("VLOEX_BACKEND_URL")

    exit_code = asyncio.run(
        run_http_proxy(
            remote_url=remote_url,
            server_name=server_name,
            port=port,
            policy_file=args.policy_file,
            backend_url=backend_url,
        )
    )
    sys.exit(exit_code)


def _handle_discover(args: argparse.Namespace) -> None:
    """Handle discover subcommand."""
    from vloex_mcp_proxy.discovery.rewriter import (
        discover_and_report,
        restore_all,
        rewrite_all,
    )

    config_dir = Path(args.config_dir) if args.config_dir else None

    if args.restore:
        report = restore_all(config_dir_override=config_dir)
        for line in report.details:
            print(line)
        sys.exit(0)

    if args.rewrite:
        report = rewrite_all(
            config_dir_override=config_dir,
            proxy_command=args.proxy_command,
            dry_run=args.dry_run,
        )
        for line in report.details:
            print(line)
        sys.exit(0)

    # Default: just discover and report
    report = discover_and_report(config_dir_override=config_dir)
    for line in report.details:
        print(line)
    sys.exit(0)


def _handle_enroll(args: argparse.Namespace) -> None:
    """Handle enrollment with the Vloex backend."""
    if getattr(args, "sso", False):
        _handle_sso_enroll(args)
        return

    from vloex_mcp_proxy.backend.config import (
        get_or_create_device_id,
        save_device_token,
    )
    from vloex_mcp_proxy.backend.http_client import VloexClient

    if not args.code and not args.token:
        print("error: --code, --token, or --sso is required", file=sys.stderr)
        sys.exit(2)

    device_id = get_or_create_device_id()

    async def _enroll() -> None:
        client = VloexClient(args.backend_url)
        await client.init()
        try:
            if args.code:
                result = await client.enroll_code(args.code, device_id, args.user_email)
            else:
                result = await client.enroll_token(args.token, device_id, args.user_email)

            if result and "device_token" in result:
                save_device_token(result["device_token"])
                print(f"Enrolled successfully (device_id: {device_id[:8]}...)")
                print(f"Backend: {args.backend_url}")
            else:
                reason = result.get("reason", "unknown") if result else "no response"
                print(f"Enrollment failed: {reason}", file=sys.stderr)
                sys.exit(1)
        finally:
            await client.close()

    asyncio.run(_enroll())


def _handle_sso_enroll(args: argparse.Namespace) -> None:
    """Handle SSO enrollment via Device Authorization Grant pattern.

    1. POST to /enroll/sso/initiate to get device_code + user_code + verification_url
    2. Open browser to verification_url
    3. Poll /enroll/sso/poll every 2s until approved or timeout
    """
    import time
    import webbrowser

    from vloex_mcp_proxy.backend.config import (
        get_or_create_device_id,
        save_device_token,
    )
    from vloex_mcp_proxy.backend.http_client import VloexClient

    device_id = get_or_create_device_id()

    async def _sso_flow() -> int:
        client = VloexClient(args.backend_url)
        await client.init()
        try:
            # Step 1: Initiate
            result = await client.sso_initiate(device_id)
            if not result or "error" in result:
                error = result.get("error", "unknown") if result else "no response"
                print(f"Error: {error}", file=sys.stderr)
                return 1

            user_code = result["user_code"]
            verification_url = result["verification_url"]
            device_code = result["device_code"]
            expires_in = result.get("expires_in", 300)

            print(f"\nYour verification code: {user_code}")
            print("\nOpening browser to approve enrollment...")
            print(f"If browser doesn't open, visit: {verification_url}")

            webbrowser.open(verification_url)

            # Step 2: Poll
            start = time.monotonic()
            while time.monotonic() - start < expires_in:
                await asyncio.sleep(2)
                poll = await client.sso_poll(device_code)
                if not poll:
                    continue

                status = poll.get("status")
                if status == "approved":
                    device_token = poll.get("device_token")
                    if device_token:
                        save_device_token(device_token)
                        print("\nDevice enrolled successfully!")
                        print(f"Backend: {args.backend_url}")
                        return 0
                    print("\nApproved but no token received.", file=sys.stderr)
                    return 1
                elif status == "expired":
                    print("\nEnrollment expired. Please try again.", file=sys.stderr)
                    return 1
                elif status == "denied":
                    print("\nEnrollment denied.", file=sys.stderr)
                    return 1
                # else "pending" — keep polling

            print("\nEnrollment timed out. Please try again.", file=sys.stderr)
            return 1
        finally:
            await client.close()

    exit_code = asyncio.run(_sso_flow())
    sys.exit(exit_code)


def _handle_status(args: argparse.Namespace) -> None:
    """Show enrollment and proxy status."""
    from vloex_mcp_proxy.backend.config import (
        get_backend_url,
        get_device_token,
        get_or_create_device_id,
        get_user_email_from_token,
        get_vloex_dir,
    )

    vloex_dir = get_vloex_dir()
    device_id = get_or_create_device_id(vloex_dir)
    token = get_device_token(vloex_dir)
    backend_url = get_backend_url()

    print(f"Device ID:   {device_id}")
    print(f"State dir:   {vloex_dir}")
    print(f"Backend URL: {backend_url or '(not set — standalone mode)'}")
    print(f"Enrolled:    {'yes' if token else 'no'}")

    if token:
        email = get_user_email_from_token(token)
        print(f"User email:  {email or '(unknown)'}")

    queue_db = vloex_dir / "event_queue.db"
    if queue_db.exists():
        print(f"Event queue: {queue_db} (exists)")
    else:
        print("Event queue: (not created yet)")


def _handle_daemon(args: argparse.Namespace) -> None:
    """Handle daemon subcommand."""
    action = getattr(args, "daemon_action", None)

    if action == "start":
        try:
            from vloex_mcp_proxy.daemon.service import DaemonService
        except ImportError:
            print(
                "error: daemon deps not installed (pip install vloex-mcp-proxy[daemon])",
                file=sys.stderr,
            )
            sys.exit(1)

        backend_url = args.backend_url or os.environ.get("VLOEX_BACKEND_URL")
        run_as = getattr(args, "run_as", None)
        svc = DaemonService(backend_url=backend_url, run_as=run_as)
        asyncio.run(svc.run())

    elif action == "stop":
        try:
            from vloex_mcp_proxy.backend.config import get_vloex_dir
            from vloex_mcp_proxy.daemon.service import DaemonService

            vloex_dir = get_vloex_dir()
            svc = DaemonService(vloex_dir=vloex_dir)
            if svc.stop_external():
                print("Daemon stop signal sent")
            else:
                print("No running daemon found")
        except ImportError:
            print("error: daemon deps not installed", file=sys.stderr)
            sys.exit(1)

    elif action == "status":
        try:
            from vloex_mcp_proxy.backend.config import get_vloex_dir
            from vloex_mcp_proxy.daemon.service import DaemonService

            vloex_dir = get_vloex_dir()
            pid_file = vloex_dir / "daemon.pid"
            if DaemonService.is_running(pid_file):
                pid = DaemonService.read_pid(pid_file)
                print(f"Daemon running (pid={pid})")
            else:
                print("Daemon not running")
        except ImportError:
            print("Daemon not installed")

    else:
        print("usage: vloex-mcp-proxy daemon {start|stop|status}", file=sys.stderr)
        sys.exit(2)


def _handle_uninstall(args: argparse.Namespace) -> None:
    """Handle uninstall — restore configs, stop daemon, remove service, optionally remove data."""
    import shutil

    vloex_dir = Path.home() / ".vloex"

    # Step 1: Restore all configs from backups
    try:
        from vloex_mcp_proxy.discovery.rewriter import restore_all

        report = restore_all()
        for line in report.details:
            print(line)
    except Exception as exc:
        print(f"Config restore failed: {exc}", file=sys.stderr)

    # Step 2: Stop daemon if running
    try:
        from vloex_mcp_proxy.backend.config import get_vloex_dir
        from vloex_mcp_proxy.daemon.service import DaemonService

        vloex_dir = get_vloex_dir()
        svc = DaemonService(vloex_dir=vloex_dir)
        if svc.stop_external():
            print("Daemon stopped")
    except ImportError:
        pass
    except Exception:
        pass

    # Step 3: Remove OS-level daemon service (launchd/systemd)
    _remove_daemon()

    # Step 4: Warn about enterprise config (MDM would re-deploy it)
    import platform as _platform

    if _platform.system() == "Windows":
        enterprise_config = Path("C:/ProgramData/Vloex/config.json")
    else:
        enterprise_config = Path("/etc/vloex/config.json")
    if enterprise_config.exists():
        print(f"Note: Enterprise config at {enterprise_config} was not removed")
        print("  (MDM-managed — remove via your MDM console)")

    # Step 5: Remove ~/.vloex/ unless --keep-data
    if not args.keep_data:
        if vloex_dir.exists():
            shutil.rmtree(str(vloex_dir), ignore_errors=True)
            print(f"Removed {vloex_dir}")
        else:
            print(f"{vloex_dir} does not exist")
    else:
        print(f"Kept data directory: {vloex_dir}")

    print("To complete removal: pip uninstall vloex-mcp-proxy")
    print("Uninstall complete")


def _remove_daemon() -> None:
    """Remove OS-level daemon service (launchd/systemd/Task Scheduler)."""
    import platform
    import subprocess

    system = platform.system()

    if system == "Darwin":
        # macOS: unload and remove LaunchAgent/LaunchDaemon plists
        plist_locations = [
            Path.home() / "Library/LaunchAgents/com.vloex.mcp-gateway.plist",
            Path("/Library/LaunchDaemons/com.vloex.mcp-gateway.plist"),
        ]

        for plist in plist_locations:
            if plist.exists():
                # Bootout before removal
                if str(plist).startswith("/Library"):
                    subprocess.run(
                        ["launchctl", "bootout", "system/com.vloex.mcp-gateway"],
                        capture_output=True,
                    )
                else:
                    uid = os.getuid()
                    subprocess.run(
                        ["launchctl", "bootout", f"gui/{uid}/com.vloex.mcp-gateway"],
                        capture_output=True,
                    )
                try:
                    plist.unlink()
                    print(f"Removed {plist}")
                except PermissionError:
                    print(f"Cannot remove {plist} (permission denied)", file=sys.stderr)
                except OSError as exc:
                    print(f"Cannot remove {plist}: {exc}", file=sys.stderr)

    elif system == "Linux":
        unit_path = Path("/etc/systemd/system/vloex-mcp-gateway.service")
        if unit_path.exists():
            subprocess.run(
                ["systemctl", "stop", "vloex-mcp-gateway"],
                capture_output=True,
            )
            subprocess.run(
                ["systemctl", "disable", "vloex-mcp-gateway"],
                capture_output=True,
            )
            try:
                unit_path.unlink()
                print(f"Removed {unit_path}")
            except PermissionError:
                print(f"Cannot remove {unit_path} (permission denied)", file=sys.stderr)
            except OSError as exc:
                print(f"Cannot remove {unit_path}: {exc}", file=sys.stderr)
            subprocess.run(
                ["systemctl", "daemon-reload"],
                capture_output=True,
            )

    elif system == "Windows":
        # Remove Task Scheduler entry
        result = subprocess.run(
            ["schtasks", "/Delete", "/TN", "VloexMCPGateway", "/F"],
            capture_output=True,
        )
        if result.returncode == 0:
            print("Removed Task Scheduler entry: VloexMCPGateway")

        # Remove SC service (if installed as a Windows service)
        subprocess.run(
            ["sc.exe", "stop", "VloexMCPGateway"],
            capture_output=True,
        )
        result = subprocess.run(
            ["sc.exe", "delete", "VloexMCPGateway"],
            capture_output=True,
        )
        if result.returncode == 0:
            print("Removed Windows service: VloexMCPGateway")


def _handle_update(args: argparse.Namespace) -> None:
    """Handle update subcommand — check for and apply updates."""
    try:
        from vloex_mcp_proxy.daemon.updater import apply_update, check_for_update
    except ImportError:
        print("error: updater module not available", file=sys.stderr)
        sys.exit(1)

    if args.check_only:
        result = check_for_update()
        print(f"Current version: {result.current_version}")
        if result.error:
            print(f"Error: {result.error}", file=sys.stderr)
            sys.exit(1)
        print(f"Latest version:  {result.latest_version}")
        if result.update_available:
            print("Update available! Run: vloex-mcp-proxy update")
        else:
            print("Already up to date")
    else:
        print("Checking for updates...")
        result = apply_update()
        print(f"Current version: {result.current_version}")
        if result.error:
            print(f"Error: {result.error}", file=sys.stderr)
            if not result.updated:
                sys.exit(1)
        if result.updated:
            print(f"Updated to {result.latest_version}")
            print("Restart any running daemon or proxy instances to use the new version")
        elif not result.error:
            print("Already up to date")


if __name__ == "__main__":
    main()
