"""Optional Presidio NLP-based scanner for enhanced sensitive data detection.

Wraps Microsoft Presidio when available ([ml] extras). Falls back gracefully
when not installed -- regex scanner in sensitive.py handles detection alone.

Entity mapping: Presidio -> Vloex detection types:
  PERSON -> pii_name
  EMAIL_ADDRESS -> pii_email
  PHONE_NUMBER -> pii_phone
  CREDIT_CARD -> pii_credit_card
  US_SSN -> pii_ssn
  IP_ADDRESS -> pii_ip_address
  IBAN_CODE -> financial_iban
  MEDICAL_LICENSE -> phi_medical
  US_DRIVER_LICENSE -> pii_drivers_license
"""

from __future__ import annotations

import sys
from dataclasses import dataclass


def _log(msg: str) -> None:
    print(f"[vloex-presidio] {msg}", file=sys.stderr, flush=True)


# Presidio entity -> Vloex data_type mapping
_ENTITY_MAP: dict[str, str] = {
    "PERSON": "pii_name",
    "EMAIL_ADDRESS": "pii_email",
    "PHONE_NUMBER": "pii_phone",
    "CREDIT_CARD": "pii_credit_card",
    "US_SSN": "pii_ssn",
    "IP_ADDRESS": "pii_ip_address",
    "IBAN_CODE": "financial_iban",
    "MEDICAL_LICENSE": "phi_medical",
    "US_DRIVER_LICENSE": "pii_drivers_license",
}

# Minimum Presidio confidence to include
_MIN_CONFIDENCE: float = 0.5


@dataclass
class PresidioDetection:
    """A single detection from Presidio."""

    data_type: str  # Vloex data type (e.g., "pii_email")
    start: int
    end: int
    confidence: float


def _is_available() -> bool:
    """Check if Presidio analyzer is importable."""
    try:
        import presidio_analyzer  # noqa: F401

        return True
    except ImportError:
        return False


# Lazy-initialized analyzer (heavy -- loads spaCy models)
_analyzer = None
_init_attempted = False


def _get_analyzer():
    """Get or create the Presidio AnalyzerEngine (singleton)."""
    global _analyzer, _init_attempted
    if _init_attempted:
        return _analyzer
    _init_attempted = True

    try:
        from presidio_analyzer import AnalyzerEngine

        _analyzer = AnalyzerEngine()
        _log("Presidio analyzer initialized")
    except Exception as exc:
        _log(f"Presidio initialization failed: {exc}")
        _analyzer = None

    return _analyzer


def reset_analyzer() -> None:
    """Reset the lazy-initialized analyzer (for testing)."""
    global _analyzer, _init_attempted
    _analyzer = None
    _init_attempted = False


def scan_with_presidio(text: str) -> list[PresidioDetection]:
    """Scan text using Presidio NLP engine.

    Returns list of PresidioDetection. Returns empty list if Presidio
    is not available or initialization fails.
    """
    if not _is_available():
        return []

    analyzer = _get_analyzer()
    if analyzer is None:
        return []

    try:
        results = analyzer.analyze(text=text, language="en")
        detections: list[PresidioDetection] = []

        for result in results:
            if result.score < _MIN_CONFIDENCE:
                continue
            vloex_type = _ENTITY_MAP.get(result.entity_type)
            if vloex_type is None:
                continue

            detections.append(
                PresidioDetection(
                    data_type=vloex_type,
                    start=result.start,
                    end=result.end,
                    confidence=result.score,
                )
            )

        return detections
    except Exception as exc:
        _log(f"Presidio scan failed: {exc}")
        return []


def merge_detections(
    regex_detections: list,
    presidio_detections: list[PresidioDetection],
) -> list:
    """Merge Presidio results into regex detections (additive only).

    Rules:
    - If Presidio finds a type already detected by regex with higher confidence,
      upgrade the confidence.
    - If Presidio finds a new type not detected by regex, add it.
    - Never remove or downgrade regex detections.

    Args:
        regex_detections: List of Detection objects from sensitive.py
        presidio_detections: List of PresidioDetection from this module

    Returns:
        Updated list of Detection objects.
    """
    if not presidio_detections:
        return regex_detections

    # Build lookup of existing regex detections by data_type
    existing_types: dict[str, float] = {}  # data_type -> max confidence
    for det in regex_detections:
        dt = det.data_type.value if hasattr(det.data_type, "value") else str(det.data_type)
        existing_conf = existing_types.get(dt, 0.0)
        existing_types[dt] = max(existing_conf, det.confidence)

    # Import Detection from sensitive.py for creating new entries
    try:
        from vloex_mcp_proxy.scanner.sensitive import Detection, SensitiveDataType
    except ImportError:
        return regex_detections

    result = list(regex_detections)

    for pdet in presidio_detections:
        if pdet.data_type in existing_types:
            # Type already detected -- upgrade confidence if Presidio is higher
            if pdet.confidence > existing_types[pdet.data_type]:
                for det in result:
                    dt = (
                        det.data_type.value
                        if hasattr(det.data_type, "value")
                        else str(det.data_type)
                    )
                    if dt == pdet.data_type:
                        det.confidence = max(det.confidence, pdet.confidence)
                existing_types[pdet.data_type] = pdet.confidence
        else:
            # New type from Presidio -- add it
            try:
                data_type = SensitiveDataType(pdet.data_type)
            except ValueError:
                continue  # Unknown type, skip
            result.append(
                Detection(
                    data_type=data_type,
                    confidence=pdet.confidence,
                    count=1,
                )
            )
            existing_types[pdet.data_type] = pdet.confidence

    return result
