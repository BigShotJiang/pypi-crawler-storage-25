"""Sensitive data detection — regex scanner mirroring the backend.

Scans text for PII, PHI, credentials, and IP using the same 13 patterns
as packages/backend/app/services/sensitive_scanner.py.  Zero external
dependencies — stdlib only (re, concurrent.futures, dataclasses, enum).
"""

from __future__ import annotations

import concurrent.futures
import re
import sys
from dataclasses import dataclass
from enum import Enum

# ---------------------------------------------------------------------------
# Data model (stdlib only — no Pydantic)
# ---------------------------------------------------------------------------


class SensitiveDataType(str, Enum):
    """Types of sensitive data detected. Mirrors backend SensitiveDataType."""

    PII_SSN = "pii_ssn"
    PII_EMAIL = "pii_email"
    PII_PHONE = "pii_phone"
    PII_ADDRESS = "pii_address"
    PII_CREDIT_CARD = "pii_credit_card"
    PHI_MEDICAL = "phi_medical"
    PHI_ICD_CODE = "phi_icd_code"
    PHI_DRUG_NAME = "phi_drug_name"
    PHI_GENOMIC = "phi_genomic"
    PHI_MRN = "phi_mrn"
    CREDENTIALS_API_KEY = "credentials_api_key"
    CREDENTIALS_PASSWORD = "credentials_password"
    IP_SOURCE_CODE = "ip_source_code"
    IP_TRADE_SECRET = "ip_trade_secret"  # Used for custom patterns


@dataclass
class Detection:
    """A single sensitive data detection."""

    data_type: SensitiveDataType
    confidence: float  # 0.0-1.0
    count: int
    custom_label: str | None = None
    pattern: re.Pattern[str] | None = None  # Compiled regex for redaction


# ---------------------------------------------------------------------------
# Safe regex execution with timeout (ReDoS guard)
# ---------------------------------------------------------------------------

_REGEX_EXECUTOR = concurrent.futures.ThreadPoolExecutor(max_workers=2)


def _safe_findall(pattern: re.Pattern[str], text: str, timeout: float = 1.0) -> list[str]:
    """Run regex findall with a timeout to guard against ReDoS.

    Note: ThreadPoolExecutor .cancel() only prevents scheduling — it cannot
    terminate an already-running thread.  A truly pathological regex may
    continue consuming CPU until the thread completes.  This is an accepted
    limitation; Phase 1 will replace regex scanning with Presidio/SLM.
    """
    future = _REGEX_EXECUTOR.submit(pattern.findall, text)
    try:
        return future.result(timeout=timeout)
    except concurrent.futures.TimeoutError:
        future.cancel()
        return []


# ---------------------------------------------------------------------------
# Luhn check for credit card validation
# ---------------------------------------------------------------------------


def _luhn_check(number_str: str) -> bool:
    """Validate a number string using the Luhn algorithm.

    Strips spaces and dashes before checking.
    Returns True if the number passes the Luhn check.
    """
    digits = [int(d) for d in number_str if d.isdigit()]
    if len(digits) != 16:
        return False
    total = 0
    for i, d in enumerate(reversed(digits)):
        if i % 2 == 1:
            d *= 2
            if d > 9:
                d -= 9
        total += d
    return total % 10 == 0


# ---------------------------------------------------------------------------
# Pattern definitions — EXACT copies from backend sensitive_scanner.py
# ---------------------------------------------------------------------------

_PATTERN_DEFS: list[tuple[SensitiveDataType, re.Pattern[str], float]] = [
    # ── Exact structural matches (confidence 1.0) ────────────────
    (
        SensitiveDataType.PII_EMAIL,
        re.compile(r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b"),
        1.0,
    ),
    (
        SensitiveDataType.PII_SSN,
        re.compile(r"\b\d{3}[-\s]?\d{2}[-\s]?\d{4}\b"),
        1.0,
    ),
    (
        SensitiveDataType.CREDENTIALS_API_KEY,
        re.compile(
            r"\b(?:"
            r"sk-[A-Za-z0-9]{20,}"
            r"|sk-ant-[A-Za-z0-9\-]{20,}"
            r"|sk-proj-[A-Za-z0-9\-]{20,}"
            r"|sk_(?:live|test)_[A-Za-z0-9]{24,}"
            r"|gsk_[A-Za-z0-9]{20,}"
            r"|ghp_[A-Za-z0-9]{36,}"
            r"|AKIA[0-9A-Z]{16}"
            r"|AIzaSy[A-Za-z0-9_\-]{33}"
            r"|xox[bpras]-[A-Za-z0-9\-]{10,}"
            r"|eyJ[A-Za-z0-9_-]{10,}\.eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}"
            r")\b"
        ),
        1.0,
    ),
    # ── Credit card (validated with Luhn post-check) ─────────────
    (
        SensitiveDataType.PII_CREDIT_CARD,
        re.compile(r"\b\d{4}[\s-]?\d{4}[\s-]?\d{4}[\s-]?\d{4}\b"),
        0.7,  # Base confidence; bumped to 1.0 if Luhn passes
    ),
    # ── Heuristic matches (lower confidence) ─────────────────────
    (
        SensitiveDataType.PII_PHONE,
        re.compile(r"\b(?:\+1[-.\s]?)?(?:\(?\d{3}\)?[-.\s]?)\d{3}[-.\s]?\d{4}\b"),
        0.8,
    ),
    (
        SensitiveDataType.PII_ADDRESS,
        re.compile(
            r"\b\d{1,5}\s+[A-Z][a-z]+(?:\s+[A-Z][a-z]+)*\s+"
            r"(?:St|Street|Ave|Avenue|Blvd|Boulevard|Dr|Drive|Ln|Lane|Rd|Road|Way|Ct|Court|Pl|Place|Cir|Circle)\.?\b"
        ),
        0.7,
    ),
    (
        SensitiveDataType.PHI_MEDICAL,
        re.compile(
            r"\b(?:diagnosis|patient|medical record|prescription|treatment plan"
            r"|ICD-10|CPT code|HIPAA|protected health|health insurance)\b",
            re.IGNORECASE,
        ),
        0.8,
    ),
    # ── PHI: ICD-10 diagnosis codes (e.g. J45.20, E11.9, M54.5) ──
    (
        SensitiveDataType.PHI_ICD_CODE,
        re.compile(r"\b[A-TV-Z]\d{2}\.\d{1,2}\b"),
        0.7,
    ),
    # ── PHI: Common prescription drug names ───────────────────────
    (
        SensitiveDataType.PHI_DRUG_NAME,
        re.compile(
            r"\b(?:"
            r"metformin|lisinopril|atorvastatin|amlodipine|metoprolol"
            r"|omeprazole|losartan|albuterol|gabapentin|hydrochlorothiazide"
            r"|sertraline|fluoxetine|montelukast|escitalopram|duloxetine"
            r"|rosuvastatin|levothyroxine|pantoprazole|prednisone|tamsulosin"
            r"|amoxicillin|azithromycin|ciprofloxacin|doxycycline|cephalexin"
            r"|ibuprofen|acetaminophen|naproxen|oxycodone|tramadol"
            r"|insulin|warfarin|heparin|clopidogrel|apixaban"
            r"|trastuzumab|pembrolizumab|nivolumab|rituximab|bevacizumab"
            r"|ozempic|wegovy|semaglutide|tirzepatide|mounjaro"
            r")\b",
            re.IGNORECASE,
        ),
        0.7,
    ),
    # ── PHI: Genomic markers (gene names, rsIDs, variants) ────────
    (
        SensitiveDataType.PHI_GENOMIC,
        re.compile(
            r"\b(?:"
            r"BRCA[12]|TP53|EGFR|KRAS|BRAF|HER2|ALK|ROS1|MET|PIK3CA"
            r"|PTEN|RB1|APC|MLH1|MSH2|MSH6|PMS2|PALB2|CHEK2|ATM"
            r"|CDKN2A|CDH1|STK11|NF1|NF2|VHL|RET|KIT|PDGFRA|NTRK[123]"
            r"|APOE|MTHFR|CYP2D6|CYP2C19|CYP3A4|DPYD|TPMT|UGT1A1|SLCO1B1|HLA-B"
            r"|rs\d{3,}"
            r"|(?:c|p|g)\.\d+[A-Z]>[A-Z]"
            r")\b"
        ),
        0.9,
    ),
    # ── PHI: Medical record numbers ───────────────────────────────
    (
        SensitiveDataType.PHI_MRN,
        re.compile(
            r"\b(?:"
            r"MRN\s*[-:#]?\s*\d{6,10}"
            r"|MR#\d{6,10}"
            r"|medical\s+record\s+(?:number|no\.?|#)\s*:?\s*\d{6,10}"
            r")\b",
            re.IGNORECASE,
        ),
        0.9,
    ),
    (
        SensitiveDataType.CREDENTIALS_PASSWORD,
        re.compile(r"(?:password|passwd|pwd)\s*[:=]\s*\S+", re.IGNORECASE),
        0.9,
    ),
    (
        SensitiveDataType.IP_SOURCE_CODE,
        re.compile(
            r"(?:^|\n)\s*(?:"
            r"def\s+\w+"
            r"|class\s+\w+"
            r"|function\s+\w+"
            r"|const\s+\w+\s*=\s*(?:async\s+)?\("
            r"|import\s+(?:\{[^}]+\}\s+from|[a-zA-Z])"
            r")"
        ),
        0.8,
    ),
]


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


# Maximum length for custom regex patterns (guard against absurdly large patterns)
_MAX_CUSTOM_PATTERN_LENGTH: int = 500

# Regex that detects nested quantifiers — classic ReDoS trigger like (a+)+
_REDOS_DETECTOR = re.compile(r"\([^)]*[+*][^)]*\)[+*?]")

# Zero-width / invisible characters that can break pattern matching
_INVISIBLE_CHARS = re.compile("[\u200b\u200c\u200d\ufeff\u00ad\u200e\u200f]")


def _sanitize_text(text: str) -> str:
    """Strip zero-width / invisible characters before scanning."""
    return _INVISIBLE_CHARS.sub("", text)


def _validate_custom_regex(pattern_value: str) -> None:
    """Validate a custom regex pattern for safety.

    Raises ValueError if the pattern is too long or contains
    known ReDoS-prone constructs (nested quantifiers).
    """
    if len(pattern_value) > _MAX_CUSTOM_PATTERN_LENGTH:
        raise ValueError(
            f"Custom regex too long ({len(pattern_value)} > {_MAX_CUSTOM_PATTERN_LENGTH})"
        )
    if _REDOS_DETECTOR.search(pattern_value):
        raise ValueError(f"Custom regex has nested quantifiers (ReDoS risk): {pattern_value[:80]}")


def scan_text(text: str, custom_patterns: list[dict] | None = None) -> list[Detection]:
    """Scan text for sensitive data patterns.

    Args:
        text: The text to scan.
        custom_patterns: Optional org-specific patterns from policy file.
            Each dict has: pattern_type ("keyword"|"regex"),
            pattern_value, data_type_label, confidence

    Returns:
        List of Detection objects for each pattern that matched.
    """
    # Strip invisible/zero-width characters before scanning
    clean_text = _sanitize_text(text)
    detections: list[Detection] = []

    for data_type, pattern, base_confidence in _PATTERN_DEFS:
        matches = _safe_findall(pattern, clean_text)
        if not matches:
            continue

        confidence = base_confidence

        # Credit card: upgrade confidence if all matches pass Luhn
        if data_type == SensitiveDataType.PII_CREDIT_CARD:
            if all(_luhn_check(m) for m in matches):
                confidence = 1.0

        detections.append(
            Detection(
                data_type=data_type,
                confidence=confidence,
                count=len(matches),
                pattern=pattern,
            )
        )

    # Custom patterns (org-specific) — cap at 50 to bound scan time
    if custom_patterns:
        if len(custom_patterns) > 50:
            print(
                f"[vloex-scanner] Custom patterns capped at 50 (received {len(custom_patterns)})",
                file=sys.stderr,
                flush=True,
            )
            custom_patterns = custom_patterns[:50]
        for cp in custom_patterns:
            try:
                ptype = cp.get("pattern_type", "keyword")
                pvalue = cp.get("pattern_value", "")
                if not pvalue:
                    continue

                if ptype == "keyword":
                    compiled = re.compile(r"\b" + re.escape(pvalue) + r"\b", re.IGNORECASE)
                else:
                    # Validate custom regex for length and ReDoS safety
                    _validate_custom_regex(pvalue)
                    compiled = re.compile(pvalue)

                matches = _safe_findall(compiled, clean_text)
                if matches:
                    detections.append(
                        Detection(
                            data_type=SensitiveDataType.IP_TRADE_SECRET,
                            confidence=cp.get("confidence", 0.8),
                            count=len(matches),
                            custom_label=cp.get("data_type_label"),
                            pattern=compiled,
                        )
                    )
            except (re.error, ValueError) as exc:
                print(
                    f"[vloex-scanner] Rejected custom pattern: {str(exc)[:100]}",
                    file=sys.stderr,
                    flush=True,
                )
                continue

    # Optional Presidio NLP enhancement (additive only)
    try:
        from vloex_mcp_proxy.scanner.presidio_scanner import merge_detections, scan_with_presidio

        presidio_results = scan_with_presidio(clean_text)
        if presidio_results:
            detections = merge_detections(detections, presidio_results)
    except ImportError:
        pass  # Presidio not available -- regex-only mode

    return detections
