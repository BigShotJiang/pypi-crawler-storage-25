"""Local policy evaluator for MCP proxy.

Simplified version of backend policy_engine.py.  Reads policies from a
JSON file (M4 will switch to cached heartbeat response).  Instance-based
state — no module-level globals.
"""

from __future__ import annotations

import json
import sys
from dataclasses import dataclass, field
from enum import Enum

from vloex_mcp_proxy.scanner.sensitive import Detection


def _log(msg: str) -> None:
    """Log to stderr."""
    print(f"[vloex-policy] {msg}", file=sys.stderr, flush=True)


# ---------------------------------------------------------------------------
# Data model
# ---------------------------------------------------------------------------


class PolicyAction(str, Enum):
    """Policy enforcement actions. Mirrors backend PolicyAction."""

    ALLOW = "allow"
    LOG_ONLY = "log_only"
    INFORM = "inform"
    WARN = "warn"
    REDACT = "redact"
    BLOCK = "block"


# Strictness ranking — higher = stricter.  Strictest matching policy wins.
STRICTNESS: dict[str, int] = {
    "allow": 0,
    "log_only": 1,
    "inform": 2,
    "warn": 3,
    "redact": 4,
    "block": 5,
}


@dataclass
class PolicyResult:
    """Result of evaluating a tool call against policies."""

    action: PolicyAction
    policy_id: str | None = None
    policy_name: str | None = None
    message: str | None = None  # Human-readable reason (for LLM-as-coaching)
    detections: list[Detection] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Condition & scope matching (mirrors backend)
# ---------------------------------------------------------------------------


def _match_condition(condition: dict, event_data: dict) -> bool:
    """Evaluate a single condition against event data."""
    field_name = condition.get("field", "")
    operator = condition.get("operator", "")
    expected = condition.get("value")

    actual = event_data.get(field_name)

    if operator == "exists":
        return actual is not None and actual != "" and actual != []

    if operator == "equals":
        if isinstance(actual, str) and isinstance(expected, str):
            return actual.lower() == expected.lower()
        return actual == expected

    if operator == "not_equals":
        if isinstance(actual, str) and isinstance(expected, str):
            return actual.lower() != expected.lower()
        return actual != expected

    if operator == "contains":
        if isinstance(actual, str) and isinstance(expected, str):
            return expected.lower() in actual.lower()
        if isinstance(actual, list) and expected is not None:
            return expected in actual
        return False

    if operator == "not_contains":
        if isinstance(actual, str) and isinstance(expected, str):
            return expected.lower() not in actual.lower()
        if isinstance(actual, list) and expected is not None:
            return expected not in actual
        return True

    if operator == "in":
        if isinstance(expected, list):
            if isinstance(actual, str):
                return actual.lower() in [str(v).lower() for v in expected]
            return actual in expected
        return False

    if operator == "not_in":
        if isinstance(expected, list):
            if isinstance(actual, str):
                return actual.lower() not in [str(v).lower() for v in expected]
            return actual not in expected
        return True

    if operator == "greater_than":
        try:
            return float(actual) > float(expected)
        except (ValueError, TypeError):
            return False

    if operator == "less_than":
        try:
            return float(actual) < float(expected)
        except (ValueError, TypeError):
            return False

    return False


def _match_scope(scope: dict | None, event_data: dict) -> bool:
    """Check if event falls within the policy scope.  Empty scope = matches all."""
    if not scope:
        return True

    departments = scope.get("departments")
    if departments:
        event_dept = event_data.get("department", "")
        if not event_dept:
            return False
        if event_dept.lower() not in [d.lower() for d in departments]:
            return False

    server_names = scope.get("server_names") or scope.get("mcp_servers")
    if server_names:
        event_server = event_data.get("server_name", "")
        if not event_server:
            return False
        if event_server.lower() not in [s.lower() for s in server_names]:
            return False

    tool_names = scope.get("tool_names") or scope.get("mcp_tools")
    if tool_names:
        event_tool = event_data.get("tool_name", "")
        if not event_tool:
            return False
        if event_tool.lower() not in [t.lower() for t in tool_names]:
            return False

    user_emails = scope.get("user_emails")
    if user_emails:
        event_email = event_data.get("user_email", "")
        if not event_email:
            return False
        if event_email.lower() not in [e.lower() for e in user_emails]:
            return False

    return True


# ---------------------------------------------------------------------------
# PolicyEngine class (instance-based, NOT module-level globals)
# ---------------------------------------------------------------------------


@dataclass
class McpConfig:
    """Remote MCP proxy configuration from heartbeat.

    All fields have safe defaults — the proxy works without any backend config.
    """

    server_allowlist: list[str] = field(default_factory=list)  # Empty = allow all
    server_blocklist: list[str] = field(default_factory=list)  # Empty = block none
    tool_blocklist: list[str] = field(default_factory=list)  # Empty = block none
    scan_arguments: bool = True  # Current behavior preserved
    scan_results: bool = True  # Current behavior preserved
    block_on_rug_pull: bool = False  # Opt-in (new behavior)
    block_sampling: bool = False  # Opt-in (new behavior)
    max_tool_result_size_bytes: int = 10_485_760  # 10MB default
    tool_call_timeout_seconds: int = 30  # Warn when tool call exceeds this

    @classmethod
    def from_dict(cls, data: dict) -> McpConfig:
        """Create from heartbeat config dict. Invalid values use defaults."""
        defaults = cls()
        try:
            server_allowlist = data.get("server_allowlist", defaults.server_allowlist)
            if not isinstance(server_allowlist, list):
                server_allowlist = defaults.server_allowlist
            server_blocklist = data.get("server_blocklist", defaults.server_blocklist)
            if not isinstance(server_blocklist, list):
                server_blocklist = defaults.server_blocklist
            tool_blocklist = data.get("tool_blocklist", defaults.tool_blocklist)
            if not isinstance(tool_blocklist, list):
                tool_blocklist = defaults.tool_blocklist
            return cls(
                server_allowlist=server_allowlist,
                server_blocklist=server_blocklist,
                tool_blocklist=tool_blocklist,
                scan_arguments=bool(data.get("scan_arguments", defaults.scan_arguments)),
                scan_results=bool(data.get("scan_results", defaults.scan_results)),
                block_on_rug_pull=bool(data.get("block_on_rug_pull", defaults.block_on_rug_pull)),
                block_sampling=bool(data.get("block_sampling", defaults.block_sampling)),
                max_tool_result_size_bytes=int(
                    data.get("max_tool_result_size_bytes", defaults.max_tool_result_size_bytes)
                ),
                tool_call_timeout_seconds=int(
                    data.get(
                        "tool_call_timeout_seconds", defaults.tool_call_timeout_seconds
                    )
                ),
            )
        except (ValueError, TypeError):
            _log("Invalid McpConfig values — using defaults")
            return defaults


class PolicyEngine:
    """Local policy evaluator.  Reads policies from JSON file."""

    def __init__(self) -> None:
        self._policies: list[dict] = []
        self._custom_patterns: list[dict] = []
        self._mcp_config: McpConfig = McpConfig()

    _REQUIRED_POLICY_FIELDS: frozenset[str] = frozenset({"id", "action"})

    def _validate_policies(self, raw_policies: list) -> list[dict]:
        """Validate a list of policy dicts.

        Checks that each policy has required fields (id, action)
        and that action is a recognized PolicyAction value. Skips
        invalid policies with a warning.

        Returns the list of validated policies.
        """
        validated: list[dict] = []
        for policy in raw_policies:
            if not isinstance(policy, dict):
                _log(f"Skipping non-dict policy entry: {type(policy)}")
                continue
            missing = self._REQUIRED_POLICY_FIELDS - set(policy.keys())
            if missing:
                name = policy.get("name", "?")
                _log(f"Skipping policy missing required fields {missing}: {name}")
                continue
            action_str = policy.get("action", "")
            try:
                PolicyAction(action_str)
            except ValueError:
                name = policy.get("name", "?")
                _log(f"Skipping policy with invalid action '{action_str}': {name}")
                continue
            validated.append(policy)
        return validated

    def load_from_file(self, path: str) -> None:
        """Load policies and custom patterns from a JSON file.

        Validates that each policy has required fields (id, action)
        and that action is a recognized PolicyAction value. Skips
        invalid policies with a warning.

        Raises:
            FileNotFoundError: if the file doesn't exist.
            json.JSONDecodeError: if the file is invalid JSON.
        """
        with open(path) as f:
            data = json.load(f)

        raw_policies = data.get("policies", [])
        self._policies = self._validate_policies(raw_policies)
        self._custom_patterns = data.get("custom_patterns", [])
        _log(f"Loaded {len(self._policies)} policies from {path}")

    def set_policies(self, policies: list[dict]) -> None:
        """Set policies directly (from heartbeat or testing).

        Applies the same validation as load_from_file — invalid
        policies are skipped with a warning.
        """
        self._policies = self._validate_policies(list(policies))

    @property
    def custom_patterns(self) -> list[dict]:
        """Return loaded custom patterns (for the scanner)."""
        return self._custom_patterns

    @property
    def has_policies(self) -> bool:
        """Whether any policies are loaded."""
        return len(self._policies) > 0

    @property
    def config(self) -> McpConfig:
        """Return the current MCP proxy config."""
        return self._mcp_config

    def set_config(self, data: dict) -> None:
        """Update MCP config from heartbeat response dict."""
        self._mcp_config = McpConfig.from_dict(data)
        _log(
            f"McpConfig updated: allowlist={len(self._mcp_config.server_allowlist)}, "
            f"blocklist={len(self._mcp_config.server_blocklist)}, "
            f"block_sampling={self._mcp_config.block_sampling}"
        )

    def evaluate(
        self,
        tool_name: str,
        server_name: str,
        detections: list[Detection],
        user_email: str | None = None,
        department: str | None = None,
        schema_validation_failed: bool = False,
        sampling_abuse_detected: bool = False,
    ) -> PolicyResult:
        """Evaluate a tool call against loaded policies.

        Builds an event_data dict from the inputs, checks each enabled
        policy's conditions and scope, returns the strictest matching action.
        """
        if not self._policies:
            return PolicyResult(action=PolicyAction.ALLOW, detections=detections)

        # Build event data dict for condition matching
        sensitive_types = [d.data_type.value for d in detections]
        event_data: dict = {
            "tool_name": tool_name,
            "server_name": server_name,
            "sensitive_data": sensitive_types,  # alias for policy conditions
            "sensitive_data_types": sensitive_types,
            "has_sensitive_data": len(detections) > 0,
            "user_email": user_email,
            "department": department,
            "schema_validation_failed": schema_validation_failed,
            "sampling_abuse_detected": sampling_abuse_detected,
        }

        strictest_result: PolicyResult | None = None
        strictest_score = -1

        for policy in self._policies:
            # Skip disabled policies
            if not policy.get("enabled", True):
                continue

            # Skip simulation-mode policies (log only, don't enforce)
            mode = policy.get("mode", "enforced")
            if mode == "simulation":
                continue

            # Check scope
            scope = policy.get("scope")
            if not _match_scope(scope, event_data):
                continue

            # Check conditions — empty conditions never match (safety default)
            conditions = policy.get("conditions", [])
            if not conditions:
                continue

            match_all = policy.get("match_all", True)

            if match_all:
                matched = all(_match_condition(c, event_data) for c in conditions)
            else:
                matched = any(_match_condition(c, event_data) for c in conditions)

            if not matched:
                continue

            # Matched — collect and pick strictest
            action_str = policy.get("action", "allow")
            try:
                action = PolicyAction(action_str)
            except ValueError:
                _log(f"Invalid action '{action_str}' in policy '{policy.get('name')}', skipping")
                continue

            score = STRICTNESS.get(action.value, 0)
            if score > strictest_score:
                strictest_score = score
                policy_message = policy.get("message", "")
                contact = policy_message or "your IT admin"
                strictest_result = PolicyResult(
                    action=action,
                    policy_id=policy.get("id"),
                    policy_name=policy.get("name"),
                    message=f"Policy '{policy.get('name')}' triggered: {action.value}. {contact}",
                    detections=detections,
                )

        if strictest_result:
            return strictest_result

        return PolicyResult(action=PolicyAction.ALLOW, detections=detections)
