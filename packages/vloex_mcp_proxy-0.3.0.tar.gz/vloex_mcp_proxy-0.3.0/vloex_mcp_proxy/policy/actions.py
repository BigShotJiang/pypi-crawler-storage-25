"""Policy action handlers — block, redact, warn.

This is the LLM-as-coaching module.  Block error messages are read by
Claude Code / Cursor / Windsurf and communicated to the developer in chat.
They MUST be natural language, descriptive, and actionable.
"""

from __future__ import annotations

import copy
import re
from typing import Any

from vloex_mcp_proxy.policy.engine import PolicyResult
from vloex_mcp_proxy.proxy.jsonrpc import make_error_response
from vloex_mcp_proxy.scanner.sensitive import _PATTERN_DEFS, Detection, SensitiveDataType


def execute_block(
    msg_id: int | str | None,
    policy_result: PolicyResult,
) -> bytes:
    """Create a JSON-RPC error response for a BLOCK action.

    The error message is natural language prefixed with "Vloex:" so the
    AI agent knows the source.  Includes what was detected, which policy
    triggered, and who to contact.

    Returns:
        Newline-terminated JSON-RPC error bytes.
    """
    detected_types = ", ".join(d.data_type.value for d in policy_result.detections)
    policy_name = policy_result.policy_name or "unnamed policy"
    contact = _extract_contact(policy_result.message)

    message = (
        f"Vloex: Tool call blocked. Detected: {detected_types}. Policy: '{policy_name}'. {contact}"
    )

    return make_error_response(msg_id, -32600, message)


def _extract_contact(message: str | None) -> str:
    """Extract the contact instruction from a policy message, or default."""
    if not message:
        return "Contact your IT admin for exceptions."
    # The message from the policy engine includes the policy name prefix;
    # look for "Contact" part if present.
    for part in message.split(". "):
        if "contact" in part.lower():
            return part.rstrip(".") + "."
    # If no explicit contact, use the custom message as-is
    return message.split(". ")[-1].rstrip(".") + "."


# ---------------------------------------------------------------------------
# Redaction
# ---------------------------------------------------------------------------

# Build a lookup from SensitiveDataType → compiled regex for redaction.
# We reuse the exact same patterns from the scanner module.
_REDACTION_PATTERNS: dict[SensitiveDataType, re.Pattern[str]] = {
    dtype: pattern for dtype, pattern, _conf in _PATTERN_DEFS
}


def execute_redact(
    content: str,
    detections: list[Detection],
) -> str:
    """Redact detected sensitive data in content.

    For each detection, find the matching text and replace with [REDACTED:type].

    Example:
        Input:  "SSN is 123-45-6789 and email is john@test.com"
        Output: "SSN is [REDACTED:pii_ssn] and email is [REDACTED:pii_email]"

    Args:
        content: The text content to redact.
        detections: List of detections from the scanner.

    Returns:
        The content with sensitive data replaced.
    """
    result = content
    for detection in detections:
        pattern = _REDACTION_PATTERNS.get(detection.data_type)
        if pattern is None:
            # Custom pattern — use the compiled regex stored on the Detection
            pattern = detection.pattern
        if pattern is None:
            # No pattern available — cannot redact, skip
            continue
        label = detection.custom_label or detection.data_type.value
        replacement = f"[REDACTED:{label}]"
        result = pattern.sub(replacement, result)
    return result


def redact_tool_arguments(
    params: dict[str, Any],
    detections: list[Detection],
) -> dict[str, Any]:
    """Redact sensitive data in tools/call arguments.

    Walks the params dict, finds string values, applies redaction.
    Returns a NEW dict (does not mutate the original).
    """
    new_params = copy.deepcopy(params)
    arguments = new_params.get("arguments", {})
    if isinstance(arguments, dict):
        new_params["arguments"] = _redact_recursive(arguments, detections)
    elif isinstance(arguments, str):
        new_params["arguments"] = execute_redact(arguments, detections)
    return new_params


def redact_tool_result(
    result: Any,
    detections: list[Detection],
) -> Any:
    """Redact sensitive data in tools/call result.

    The result can be a dict, list, or string.  Walk recursively,
    redact strings, return new structure.
    """
    return _redact_recursive(result, detections)


def _redact_recursive(value: Any, detections: list[Detection]) -> Any:
    """Recursively walk a value, redacting strings."""
    if isinstance(value, str):
        return execute_redact(value, detections)
    if isinstance(value, dict):
        return {k: _redact_recursive(v, detections) for k, v in value.items()}
    if isinstance(value, list):
        return [_redact_recursive(item, detections) for item in value]
    return value
