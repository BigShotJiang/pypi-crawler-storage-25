"""Self-update checker for vloex-mcp-proxy.

Two strategies for version lookup:
1. `pip index versions` (subprocess, 30s timeout)
2. PyPI JSON API via urllib.request (stdlib, no deps)

Binary (PyInstaller) builds cannot self-update — prints download instruction.
"""

from __future__ import annotations

import json
import subprocess
import sys
from dataclasses import dataclass


@dataclass
class UpdateResult:
    """Result of an update check or apply."""

    current_version: str
    latest_version: str = ""
    update_available: bool = False
    updated: bool = False
    error: str = ""


def _parse_version_tuple(version: str) -> tuple[int, ...]:
    """Parse '0.3.0' → (0, 3, 0). Returns (0,) on invalid input."""
    try:
        return tuple(int(p) for p in version.split("."))
    except (ValueError, AttributeError):
        return (0,)


def _is_pyinstaller_binary() -> bool:
    """Check if running from a PyInstaller bundle."""
    return bool(getattr(sys, "frozen", False))


def _get_current_version() -> str:
    from vloex_mcp_proxy import __version__

    return __version__


def check_latest_version() -> str | None:
    """Check PyPI for the latest version of vloex-mcp-proxy.

    Strategy 1: pip index versions (subprocess)
    Strategy 2: PyPI JSON API (urllib.request, stdlib)

    Returns version string or None on failure.
    """
    # Strategy 1: pip index versions
    try:
        result = subprocess.run(
            [sys.executable, "-m", "pip", "index", "versions", "vloex-mcp-proxy"],
            capture_output=True,
            text=True,
            timeout=30,
        )
        if result.returncode == 0 and result.stdout:
            # Output format: "vloex-mcp-proxy (0.3.0)"
            for line in result.stdout.splitlines():
                if "vloex-mcp-proxy" in line and "(" in line:
                    version = line.split("(")[1].split(")")[0].strip()
                    if version:
                        return version
    except (subprocess.TimeoutExpired, FileNotFoundError, OSError):
        pass

    # Strategy 2: PyPI JSON API
    try:
        import urllib.request

        req = urllib.request.Request(
            "https://pypi.org/pypi/vloex-mcp-proxy/json",
            headers={"Accept": "application/json", "User-Agent": "vloex-mcp-proxy"},
        )
        with urllib.request.urlopen(req, timeout=15) as resp:
            data = json.loads(resp.read().decode("utf-8"))
            return data.get("info", {}).get("version")
    except Exception:
        return None


def check_for_update() -> UpdateResult:
    """Check if an update is available.

    Returns UpdateResult with update_available=True if a newer version exists.
    """
    current = _get_current_version()
    latest = check_latest_version()

    if latest is None:
        return UpdateResult(
            current_version=current,
            error="Failed to check for updates (no network or PyPI unavailable)",
        )

    current_tuple = _parse_version_tuple(current)
    latest_tuple = _parse_version_tuple(latest)

    return UpdateResult(
        current_version=current,
        latest_version=latest,
        update_available=latest_tuple > current_tuple,
    )


def apply_update() -> UpdateResult:
    """Apply the update via pip install --upgrade.

    PyInstaller binaries cannot self-update — returns error with download instruction.
    """
    current = _get_current_version()

    if _is_pyinstaller_binary():
        return UpdateResult(
            current_version=current,
            error="Binary builds cannot self-update. Download the latest release from "
            "https://github.com/vloex/vloex-mcp-proxy/releases",
        )

    # Check first
    result = check_for_update()
    if result.error:
        return result
    if not result.update_available:
        return UpdateResult(
            current_version=current,
            latest_version=result.latest_version,
            update_available=False,
            error="Already up to date",
        )

    # pip install --upgrade
    try:
        proc = subprocess.run(
            [sys.executable, "-m", "pip", "install", f"vloex-mcp-proxy=={result.latest_version}"],
            capture_output=True,
            text=True,
            timeout=120,
        )
        if proc.returncode == 0:
            return UpdateResult(
                current_version=current,
                latest_version=result.latest_version,
                update_available=True,
                updated=True,
            )
        return UpdateResult(
            current_version=current,
            latest_version=result.latest_version,
            update_available=True,
            error=f"pip install failed: {proc.stderr[:500]}",
        )
    except subprocess.TimeoutExpired:
        return UpdateResult(
            current_version=current,
            latest_version=result.latest_version,
            update_available=True,
            error="pip install timed out (120s)",
        )
    except Exception as exc:
        return UpdateResult(
            current_version=current,
            latest_version=result.latest_version,
            update_available=True,
            error=f"Update failed: {exc}",
        )
