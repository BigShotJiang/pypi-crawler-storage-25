"""Daemon service — orchestrates config watching, process monitoring, and backend sync.

Runs in the foreground (launchd/systemd handle actual daemonization).
PID file at ~/.vloex/daemon.pid tracks whether daemon is running.
"""

from __future__ import annotations

import asyncio
import os
import signal
import sys
from pathlib import Path


def _log(msg: str) -> None:
    print(f"[vloex-daemon] {msg}", file=sys.stderr, flush=True)


# Process monitor scan interval
_PROCESS_SCAN_INTERVAL: float = 60.0


class DaemonService:
    """Orchestrates config watching + process monitoring + heartbeat + sync.

    PID file lifecycle:
    - Written on start with current PID
    - Removed on stop/exit
    - is_running() validates PID file + process alive check
    """

    def __init__(
        self,
        vloex_dir: Path | None = None,
        backend_url: str | None = None,
        run_as: str | None = None,
    ) -> None:
        if vloex_dir is None:
            from vloex_mcp_proxy.backend.config import get_vloex_dir

            vloex_dir = get_vloex_dir()

        self._vloex_dir = vloex_dir
        self._backend_url = backend_url
        self._run_as_user = run_as
        self._pid_file = vloex_dir / "daemon.pid"
        self._shutdown = asyncio.Event()
        self._watcher = None

    @property
    def pid_file(self) -> Path:
        return self._pid_file

    def _write_pid(self) -> None:
        """Write current PID to file atomically using O_CREAT|O_EXCL to prevent races."""
        pid_bytes = str(os.getpid()).encode("utf-8")
        try:
            fd = os.open(str(self._pid_file), os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
            try:
                os.write(fd, pid_bytes)
            finally:
                os.close(fd)
        except FileExistsError:
            # PID file exists but is_running() returned False — stale file, overwrite
            self._pid_file.write_text(str(os.getpid()))
            try:
                self._pid_file.chmod(0o600)
            except OSError:
                pass

    def _remove_pid(self) -> None:
        """Remove PID file on exit."""
        try:
            self._pid_file.unlink(missing_ok=True)
        except OSError:
            pass

    @staticmethod
    def is_running(pid_file: Path) -> bool:
        """Check if daemon is running by verifying PID file + process alive."""
        if not pid_file.exists():
            return False
        try:
            pid = int(pid_file.read_text().strip())
            os.kill(pid, 0)  # Check if process exists (doesn't actually send signal)
            return True
        except (ValueError, ProcessLookupError, PermissionError, OSError):
            return False

    @staticmethod
    def read_pid(pid_file: Path) -> int | None:
        """Read PID from file, return None if invalid."""
        try:
            return int(pid_file.read_text().strip())
        except (ValueError, OSError):
            return None

    async def run(self) -> None:
        """Main daemon loop. Runs until SIGTERM/SIGINT."""
        if self.is_running(self._pid_file):
            existing_pid = self.read_pid(self._pid_file)
            _log(f"Daemon already running (pid={existing_pid})")
            return

        self._write_pid()
        _log(f"Daemon started (pid={os.getpid()})")

        # Drop privileges if running as root in daemon mode
        try:
            from vloex_mcp_proxy.daemon.privilege import drop_privileges

            if self._run_as_user:
                drop_privileges(self._run_as_user)
        except ImportError:
            pass

        # Set up signal handlers
        loop = asyncio.get_running_loop()
        try:
            for sig in (signal.SIGTERM, signal.SIGINT):
                loop.add_signal_handler(sig, self._shutdown.set)
        except NotImplementedError:
            signal.signal(
                signal.SIGINT, lambda _s, _f: loop.call_soon_threadsafe(self._shutdown.set)
            )

        try:
            # Start config watcher
            self._start_watcher()

            # Start backend workers if configured
            backend_tasks = await self._start_backend()

            # Process monitor loop
            monitor_task = asyncio.ensure_future(self._process_monitor_loop())

            # Wait for shutdown signal
            await self._shutdown.wait()
            _log("Shutdown signal received")

            # Cancel tasks
            monitor_task.cancel()
            for task in backend_tasks:
                task.cancel()
            for task in [monitor_task, *backend_tasks]:
                try:
                    await task
                except asyncio.CancelledError:
                    pass

        finally:
            self._stop()

    def _start_watcher(self) -> None:
        """Start the config file watcher."""
        try:
            from vloex_mcp_proxy.daemon.watcher import ConfigWatcher
            from vloex_mcp_proxy.discovery.config_paths import get_known_clients

            clients = get_known_clients()
            config_paths = [Path(c.config_path).expanduser() for c in clients]
            existing = [p for p in config_paths if p.exists()]

            if not existing:
                _log("No existing config files found to watch")
                return

            self._watcher = ConfigWatcher(existing, on_change=self._on_config_change)
            self._watcher.start()
        except ImportError as exc:
            _log(f"Config watcher deps missing: {exc}")
        except Exception as exc:
            _log(f"Config watcher failed to start: {exc}")

    def _on_config_change(self, path: Path) -> None:
        """Callback when a config file changes — rewrite only the changed file."""
        _log(f"Config change detected: {path}")
        try:
            from vloex_mcp_proxy.discovery.rewriter import rewrite_single

            report = rewrite_single(path)
            for line in report.details:
                _log(f"  {line}")
        except ImportError:
            # rewrite_single not available — fall back to rewrite_all
            try:
                from vloex_mcp_proxy.discovery.rewriter import rewrite_all

                report = rewrite_all()
                for line in report.details:
                    _log(f"  {line}")
            except Exception as exc:
                _log(f"Config rewrite failed: {exc}")
        except Exception as exc:
            _log(f"Config rewrite failed: {exc}")

    async def _start_backend(self) -> list[asyncio.Task]:
        """Start heartbeat + sync workers if backend_url is set."""
        if not self._backend_url:
            return []
        try:
            from vloex_mcp_proxy.backend.config import (
                get_device_token,
                get_or_create_device_id,
            )
            from vloex_mcp_proxy.backend.heartbeat_worker import HeartbeatWorker
            from vloex_mcp_proxy.backend.http_client import VloexClient
            from vloex_mcp_proxy.policy.engine import PolicyEngine

            device_id = get_or_create_device_id(self._vloex_dir)
            device_token = get_device_token(self._vloex_dir)

            client = VloexClient(self._backend_url, device_token=device_token)
            await client.init()

            policy_engine = PolicyEngine()
            heartbeat = HeartbeatWorker(
                client=client,
                policy_engine=policy_engine,
                device_id=device_id,
                vloex_dir=self._vloex_dir,
            )
            heartbeat.load_cached_config()

            tasks = [asyncio.ensure_future(heartbeat.run())]
            _log("Backend workers started")
            return tasks
        except ImportError:
            _log("Backend deps not installed — running without backend sync")
            return []
        except Exception as exc:
            _log(f"Backend init failed: {exc}")
            return []

    async def _process_monitor_loop(self) -> None:
        """Periodically scan for MCP server/client processes."""
        while not self._shutdown.is_set():
            try:
                from vloex_mcp_proxy.discovery.process import discover_processes

                processes = discover_processes()
                if processes:
                    servers = [p for p in processes if p.is_server]
                    clients = [p for p in processes if p.is_client]
                    _log(f"Process scan: {len(servers)} servers, {len(clients)} clients")
            except Exception:
                pass  # Non-fatal
            await asyncio.sleep(_PROCESS_SCAN_INTERVAL)

    def _stop(self) -> None:
        """Clean up on exit."""
        if self._watcher is not None:
            self._watcher.stop()
        self._remove_pid()
        _log("Daemon stopped")

    def stop_external(self) -> bool:
        """Stop a running daemon by sending SIGTERM.

        Returns True if signal was sent, False if no daemon running.
        """
        if not self.is_running(self._pid_file):
            return False
        pid = self.read_pid(self._pid_file)
        if pid is None:
            return False
        try:
            os.kill(pid, signal.SIGTERM)
            _log(f"Sent SIGTERM to daemon (pid={pid})")
            return True
        except (ProcessLookupError, PermissionError):
            # Process already gone — clean up stale PID
            self._remove_pid()
            return False
