"""Config watcher — monitors MCP client config files for changes.

Uses watchdog to watch parent directories of known config files.
Debounces rapid changes (editors save multiple times) and skips
configs that are already rewritten by the proxy.
"""

from __future__ import annotations

import sys
import threading
import time
from collections.abc import Callable
from pathlib import Path


def _log(msg: str) -> None:
    print(f"[vloex-watcher] {msg}", file=sys.stderr, flush=True)


# Debounce window — editors often write multiple times on save
_DEBOUNCE_SECONDS: float = 2.0


class ConfigWatcher:
    """Watches MCP client config files for changes.

    Uses watchdog Observer to watch parent directories (watchdog watches
    dirs, not individual files). Calls the on_change callback when a
    watched config file is modified, with debounce to handle rapid saves.
    """

    def __init__(
        self,
        config_paths: list[Path],
        on_change: Callable[[Path], None],
        debounce: float = _DEBOUNCE_SECONDS,
    ) -> None:
        self._config_paths = {p.resolve() for p in config_paths if p.exists()}
        self._on_change = on_change
        self._debounce = debounce
        self._observer = None
        self._last_event: dict[Path, float] = {}
        self._lock = threading.Lock()

    def start(self) -> None:
        """Start watching config file parent directories."""
        try:
            from watchdog.events import FileModifiedEvent, FileSystemEventHandler
            from watchdog.observers import Observer
        except ImportError:
            _log("watchdog not installed — config watching unavailable")
            return

        watcher = self

        class _Handler(FileSystemEventHandler):
            def on_modified(self, event):
                if event.is_directory:
                    return
                if not isinstance(event, FileModifiedEvent):
                    return
                path = Path(event.src_path).resolve()
                if path in watcher._config_paths:
                    watcher._handle_change(path)

        self._observer = Observer()
        handler = _Handler()

        # Watch unique parent directories
        watched_dirs: set[Path] = set()
        for config_path in self._config_paths:
            parent = config_path.parent
            if parent not in watched_dirs and parent.is_dir():
                self._observer.schedule(handler, str(parent), recursive=False)
                watched_dirs.add(parent)
                _log(f"Watching {parent}")

        if watched_dirs:
            self._observer.start()
            _log(f"Config watcher started ({len(watched_dirs)} directories)")
        else:
            _log("No config directories to watch")

    def _handle_change(self, path: Path) -> None:
        """Handle a config file change with debounce."""
        now = time.monotonic()
        with self._lock:
            last = self._last_event.get(path, 0.0)
            if now - last < self._debounce:
                return  # Debounced
            self._last_event[path] = now

        # Check if already rewritten (skip our own changes)
        try:
            import json

            from vloex_mcp_proxy.discovery.rewriter import is_already_rewritten

            with open(path) as f:
                config = json.load(f)

            # Check if any server in the config is already rewritten
            servers = config.get("mcpServers", {})
            all_rewritten = (
                all(is_already_rewritten(s) for s in servers.values()) if servers else False
            )
            if all_rewritten and servers:
                _log(f"Skipping {path.name} — already rewritten")
                return
        except Exception:
            pass  # If we can't check, proceed with callback

        _log(f"Config changed: {path}")
        try:
            self._on_change(path)
        except Exception as exc:
            _log(f"on_change callback failed: {exc}")

    def stop(self) -> None:
        """Stop watching."""
        if self._observer is not None:
            try:
                if self._observer.is_alive():
                    self._observer.stop()
                    self._observer.join(timeout=5.0)
            except RuntimeError:
                pass  # Thread never started
            self._observer = None
            _log("Config watcher stopped")

    @property
    def is_running(self) -> bool:
        """Check if the watcher is active."""
        return self._observer is not None and self._observer.is_alive()
