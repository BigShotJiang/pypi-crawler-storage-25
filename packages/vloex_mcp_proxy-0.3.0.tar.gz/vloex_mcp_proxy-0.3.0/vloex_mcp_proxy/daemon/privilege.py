"""Privilege dropping for daemon mode.

Drops from root to a service user after PID file creation.
No-op on Windows or when not running as root.
"""

from __future__ import annotations

import os
import sys


def _log(msg: str) -> None:
    print(f"[vloex-privilege] {msg}", file=sys.stderr, flush=True)


def drop_privileges(user: str = "_vloex") -> bool:
    """Drop from root to the specified service user.

    Returns True if privileges were dropped, False if skipped.
    No-op conditions: Windows, not root, user not found.
    """
    if sys.platform == "win32":
        _log("Privilege dropping not supported on Windows")
        return False

    if os.getuid() != 0:
        _log(f"Not running as root (uid={os.getuid()}) — skipping privilege drop")
        return False

    try:
        import pwd

        try:
            pw = pwd.getpwnam(user)
        except KeyError:
            _log(f"User '{user}' not found — skipping privilege drop")
            return False

        target_uid = pw.pw_uid
        target_gid = pw.pw_gid

        if os.getuid() == target_uid:
            _log(f"Already running as '{user}' — no change needed")
            return False

        # Clear supplementary groups first (prevents group-based privilege escalation)
        os.setgroups([])
        os.setgid(target_gid)
        os.initgroups(user, target_gid)
        os.setuid(target_uid)

        _log(f"Dropped privileges to '{user}' (uid={target_uid}, gid={target_gid})")
        return True
    except (ImportError, OSError) as exc:
        _log(f"Failed to drop privileges: {exc}")
        return False
