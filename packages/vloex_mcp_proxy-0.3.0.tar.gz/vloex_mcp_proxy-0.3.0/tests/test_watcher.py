"""Tests for config watcher — start/stop, change detection, debounce."""

import json
import time
from pathlib import Path
from unittest.mock import MagicMock

from vloex_mcp_proxy.daemon.watcher import ConfigWatcher


def _create_config(path: Path) -> Path:
    """Create a minimal MCP config file."""
    config = {
        "mcpServers": {
            "test-server": {
                "command": "npx",
                "args": ["-y", "@test/server"],
            }
        }
    }
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(config))
    return path


class TestConfigWatcher:
    def test_start_stop(self, tmp_path: Path):
        config_path = _create_config(tmp_path / "config.json")
        callback = MagicMock()
        watcher = ConfigWatcher([config_path], callback)
        watcher.start()
        try:
            # May not start if watchdog not installed — that's OK
            pass
        finally:
            watcher.stop()
        assert not watcher.is_running

    def test_stop_without_start(self, tmp_path: Path):
        """stop() should be safe to call without start()."""
        config_path = _create_config(tmp_path / "config.json")
        watcher = ConfigWatcher([config_path], MagicMock())
        watcher.stop()  # Should not raise

    def test_debounce_prevents_rapid_calls(self, tmp_path: Path):
        """_handle_change should debounce rapid calls."""
        config_path = _create_config(tmp_path / "config.json")
        callback = MagicMock()
        watcher = ConfigWatcher([config_path], callback, debounce=1.0)
        # Simulate two rapid changes
        watcher._handle_change(config_path.resolve())
        watcher._handle_change(config_path.resolve())
        # Only one call should have gone through
        assert callback.call_count == 1

    def test_debounce_allows_after_window(self, tmp_path: Path):
        """After debounce window, next change should fire."""
        config_path = _create_config(tmp_path / "config.json")
        callback = MagicMock()
        watcher = ConfigWatcher([config_path], callback, debounce=0.01)
        watcher._handle_change(config_path.resolve())
        time.sleep(0.02)  # Wait past debounce
        watcher._handle_change(config_path.resolve())
        assert callback.call_count == 2

    def test_nonexistent_path_ignored(self, tmp_path: Path):
        """Non-existent config paths should not crash."""
        callback = MagicMock()
        watcher = ConfigWatcher([tmp_path / "nonexistent.json"], callback)
        watcher.start()
        watcher.stop()
        # Should not crash

    def test_empty_config_list(self):
        """Empty config list should not crash."""
        callback = MagicMock()
        watcher = ConfigWatcher([], callback)
        watcher.start()
        watcher.stop()
