"""Tests for the Presidio scanner integration.

All tests mock presidio throughout -- never actually import presidio_analyzer.
"""

from __future__ import annotations

import sys
from dataclasses import dataclass
from types import ModuleType

from vloex_mcp_proxy.scanner.presidio_scanner import (
    _ENTITY_MAP,
    _MIN_CONFIDENCE,
    PresidioDetection,
    merge_detections,
    reset_analyzer,
    scan_with_presidio,
)
from vloex_mcp_proxy.scanner.sensitive import Detection, SensitiveDataType

# ── Availability tests ──────────────────────────────────────────────


class TestPresidioAvailability:
    def test_is_available_returns_false_when_not_installed(self) -> None:
        """_is_available() returns False when presidio is not installed."""
        from vloex_mcp_proxy.scanner.presidio_scanner import _is_available

        # presidio_analyzer is not installed in test env
        assert _is_available() is False

    def test_scan_returns_empty_when_not_available(self) -> None:
        """scan_with_presidio() returns empty list when presidio not installed."""
        result = scan_with_presidio("John Smith's SSN is 123-45-6789")
        assert result == []


# ── Mock Presidio tests ─────────────────────────────────────────────


@dataclass
class MockRecognizerResult:
    """Mock of presidio_analyzer.RecognizerResult."""

    entity_type: str
    start: int
    end: int
    score: float


class TestPresidioWithMock:
    """Tests that mock presidio_analyzer to verify entity mapping and filtering."""

    def setup_method(self) -> None:
        """Reset the lazy-initialized analyzer before each test."""
        reset_analyzer()

    def teardown_method(self) -> None:
        """Clean up after each test."""
        reset_analyzer()
        # Remove fake presidio module if present
        sys.modules.pop("presidio_analyzer", None)

    def _install_fake_presidio(self, results: list[MockRecognizerResult]) -> None:
        """Inject a fake presidio_analyzer module into sys.modules."""
        fake_module = ModuleType("presidio_analyzer")

        class FakeAnalyzerEngine:
            def analyze(self, text: str, language: str = "en") -> list:
                return results

        fake_module.AnalyzerEngine = FakeAnalyzerEngine  # type: ignore[attr-defined]
        sys.modules["presidio_analyzer"] = fake_module

    def test_entity_mapping_email(self) -> None:
        """Presidio EMAIL_ADDRESS maps to pii_email."""
        self._install_fake_presidio([MockRecognizerResult("EMAIL_ADDRESS", 0, 14, 0.95)])
        text = "alice@test.com"
        result = scan_with_presidio(text)
        assert len(result) == 1
        assert result[0].data_type == "pii_email"
        assert result[0].confidence == 0.95

    def test_entity_mapping_person(self) -> None:
        """Presidio PERSON maps to pii_name."""
        self._install_fake_presidio([MockRecognizerResult("PERSON", 0, 10, 0.85)])
        text = "John Smith"
        result = scan_with_presidio(text)
        assert len(result) == 1
        assert result[0].data_type == "pii_name"

    def test_entity_mapping_ssn(self) -> None:
        """Presidio US_SSN maps to pii_ssn."""
        self._install_fake_presidio([MockRecognizerResult("US_SSN", 0, 11, 1.0)])
        text = "123-45-6789"
        result = scan_with_presidio(text)
        assert len(result) == 1
        assert result[0].data_type == "pii_ssn"

    def test_entity_mapping_all_known_types(self) -> None:
        """All entity types in _ENTITY_MAP produce correct Vloex types."""
        for presidio_type, vloex_type in _ENTITY_MAP.items():
            reset_analyzer()
            sys.modules.pop("presidio_analyzer", None)
            self._install_fake_presidio([MockRecognizerResult(presidio_type, 0, 5, 0.9)])
            result = scan_with_presidio("test_")
            assert len(result) == 1, f"Failed for {presidio_type}"
            assert result[0].data_type == vloex_type, f"Mapping wrong for {presidio_type}"

    def test_confidence_filtering_below_threshold(self) -> None:
        """Results below _MIN_CONFIDENCE (0.5) are excluded."""
        self._install_fake_presidio([MockRecognizerResult("EMAIL_ADDRESS", 0, 14, 0.3)])
        result = scan_with_presidio("alice@test.com")
        assert len(result) == 0

    def test_confidence_filtering_at_threshold(self) -> None:
        """Results at exactly _MIN_CONFIDENCE are included."""
        self._install_fake_presidio([MockRecognizerResult("EMAIL_ADDRESS", 0, 14, _MIN_CONFIDENCE)])
        result = scan_with_presidio("alice@test.com")
        assert len(result) == 1

    def test_unmapped_entity_type_skipped(self) -> None:
        """Entity types not in _ENTITY_MAP are skipped."""
        self._install_fake_presidio([MockRecognizerResult("UNKNOWN_ENTITY", 0, 5, 0.9)])
        result = scan_with_presidio("hello")
        assert len(result) == 0

    def test_multiple_results(self) -> None:
        """Multiple Presidio results produce multiple PresidioDetections."""
        self._install_fake_presidio(
            [
                MockRecognizerResult("EMAIL_ADDRESS", 0, 14, 0.95),
                MockRecognizerResult("PHONE_NUMBER", 15, 27, 0.8),
            ]
        )
        text = "alice@test.com 555-123-4567"
        result = scan_with_presidio(text)
        assert len(result) == 2
        types = {r.data_type for r in result}
        assert "pii_email" in types
        assert "pii_phone" in types

    def test_analyzer_init_failure_returns_empty(self) -> None:
        """If AnalyzerEngine() raises, scan returns empty list."""
        fake_module = ModuleType("presidio_analyzer")

        class FailingAnalyzerEngine:
            def __init__(self) -> None:
                raise RuntimeError("spaCy model not found")

        fake_module.AnalyzerEngine = FailingAnalyzerEngine  # type: ignore[attr-defined]
        sys.modules["presidio_analyzer"] = fake_module

        result = scan_with_presidio("test text")
        assert result == []


# ── Merge detections tests ──────────────────────────────────────────


class TestMergeDetections:
    def test_empty_presidio_returns_regex_unchanged(self) -> None:
        """When Presidio has no results, regex detections are returned as-is."""
        regex_dets = [
            Detection(
                data_type=SensitiveDataType.PII_EMAIL,
                confidence=1.0,
                count=1,
            )
        ]
        result = merge_detections(regex_dets, [])
        assert len(result) == 1
        assert result[0].confidence == 1.0

    def test_presidio_upgrades_existing_confidence(self) -> None:
        """Presidio with higher confidence upgrades the regex detection."""
        regex_dets = [
            Detection(
                data_type=SensitiveDataType.PII_EMAIL,
                confidence=0.7,
                count=1,
            )
        ]
        presidio_dets = [
            PresidioDetection(
                data_type="pii_email",
                start=0,
                end=14,
                confidence=0.95,
            )
        ]
        result = merge_detections(regex_dets, presidio_dets)
        assert len(result) == 1
        assert result[0].confidence == 0.95

    def test_presidio_does_not_downgrade_confidence(self) -> None:
        """Presidio with lower confidence does not downgrade regex detection."""
        regex_dets = [
            Detection(
                data_type=SensitiveDataType.PII_EMAIL,
                confidence=1.0,
                count=1,
            )
        ]
        presidio_dets = [
            PresidioDetection(
                data_type="pii_email",
                start=0,
                end=14,
                confidence=0.6,
            )
        ]
        result = merge_detections(regex_dets, presidio_dets)
        assert len(result) == 1
        assert result[0].confidence == 1.0

    def test_presidio_adds_new_type(self) -> None:
        """Presidio adds a type not found by regex (e.g., pii_phone)."""
        regex_dets = [
            Detection(
                data_type=SensitiveDataType.PII_EMAIL,
                confidence=1.0,
                count=1,
            )
        ]
        presidio_dets = [
            PresidioDetection(
                data_type="pii_phone",
                start=0,
                end=12,
                confidence=0.85,
            )
        ]
        result = merge_detections(regex_dets, presidio_dets)
        assert len(result) == 2
        types = {d.data_type for d in result}
        assert SensitiveDataType.PII_EMAIL in types
        assert SensitiveDataType.PII_PHONE in types
        phone = next(d for d in result if d.data_type == SensitiveDataType.PII_PHONE)
        assert phone.confidence == 0.85
        assert phone.count == 1

    def test_presidio_unknown_type_skipped(self) -> None:
        """Presidio type not in SensitiveDataType enum is skipped."""
        regex_dets = [
            Detection(
                data_type=SensitiveDataType.PII_EMAIL,
                confidence=1.0,
                count=1,
            )
        ]
        presidio_dets = [
            PresidioDetection(
                data_type="pii_name",  # Not in SensitiveDataType
                start=0,
                end=10,
                confidence=0.85,
            )
        ]
        result = merge_detections(regex_dets, presidio_dets)
        # pii_name doesn't exist in SensitiveDataType, so it should be skipped
        assert len(result) == 1
        assert result[0].data_type == SensitiveDataType.PII_EMAIL

    def test_overlapping_detections_no_duplicate(self) -> None:
        """When regex and Presidio both find the same type, no duplicate entry."""
        regex_dets = [
            Detection(
                data_type=SensitiveDataType.PII_SSN,
                confidence=1.0,
                count=1,
            )
        ]
        presidio_dets = [
            PresidioDetection(
                data_type="pii_ssn",
                start=0,
                end=11,
                confidence=0.99,
            )
        ]
        result = merge_detections(regex_dets, presidio_dets)
        # Should NOT add a duplicate -- just upgrade confidence
        assert len(result) == 1
        assert result[0].data_type == SensitiveDataType.PII_SSN

    def test_multiple_presidio_detections(self) -> None:
        """Multiple Presidio results are merged correctly."""
        regex_dets = [
            Detection(
                data_type=SensitiveDataType.PII_EMAIL,
                confidence=0.8,
                count=1,
            )
        ]
        presidio_dets = [
            PresidioDetection(
                data_type="pii_email",
                start=0,
                end=7,
                confidence=0.95,
            ),
            PresidioDetection(
                data_type="pii_phone",
                start=10,
                end=18,
                confidence=0.7,
            ),
        ]
        result = merge_detections(regex_dets, presidio_dets)
        assert len(result) == 2
        email = next(d for d in result if d.data_type == SensitiveDataType.PII_EMAIL)
        assert email.confidence == 0.95  # upgraded
        phone = next(d for d in result if d.data_type == SensitiveDataType.PII_PHONE)
        assert phone.confidence == 0.7


# ── scan_text integration (Presidio not available) ──────────────────


class TestScanTextPresidioIntegration:
    def test_scan_text_works_without_presidio(self) -> None:
        """scan_text still works when Presidio is not installed."""
        from vloex_mcp_proxy.scanner.sensitive import scan_text

        detections = scan_text("john@company.com")
        types = [d.data_type for d in detections]
        assert SensitiveDataType.PII_EMAIL in types
