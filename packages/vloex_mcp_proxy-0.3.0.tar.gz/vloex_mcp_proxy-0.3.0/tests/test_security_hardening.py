"""Security hardening tests — covers all review findings."""

from __future__ import annotations

import json

from vloex_mcp_proxy.policy.actions import execute_redact
from vloex_mcp_proxy.policy.engine import PolicyAction, PolicyEngine
from vloex_mcp_proxy.proxy.interceptor import Interceptor
from vloex_mcp_proxy.proxy.jsonrpc import (
    MAX_BATCH_SIZE,
    MAX_MESSAGE_BYTES,
    MessageType,
    parse_message,
)
from vloex_mcp_proxy.scanner.sensitive import (
    Detection,
    SensitiveDataType,
    _validate_custom_regex,
    scan_text,
)

# ── Fix #1: JSON payload size limit ──────────────────────────────


def test_oversized_message_rejected() -> None:
    """Messages exceeding MAX_MESSAGE_BYTES are returned as INVALID."""
    data = b'{"jsonrpc":"2.0","method":"test","id":1}' + b"x" * MAX_MESSAGE_BYTES
    msg = parse_message(data)
    assert msg.msg_type == MessageType.INVALID


def test_oversized_batch_rejected() -> None:
    """Batch arrays exceeding MAX_BATCH_SIZE are returned as INVALID."""
    items = [{"jsonrpc": "2.0", "method": "test", "id": i} for i in range(MAX_BATCH_SIZE + 1)]
    data = json.dumps(items).encode()
    msg = parse_message(data)
    assert msg.msg_type == MessageType.INVALID


def test_normal_message_still_parses() -> None:
    """Messages under the size limit still parse correctly."""
    data = json.dumps({"jsonrpc": "2.0", "method": "tools/call", "id": 1}).encode()
    msg = parse_message(data)
    assert msg.msg_type == MessageType.REQUEST
    assert msg.method == "tools/call"


# ── Fix #5: Batch bypass — per-sub-message block/redact ──────────


def test_batch_block_removes_sub_message(block_ssn_policy_file: str) -> None:
    """Blocked sub-message in batch is removed; error override returned."""
    interceptor = Interceptor("test", policy_file=block_ssn_policy_file)
    batch = [
        {
            "jsonrpc": "2.0",
            "method": "tools/call",
            "params": {"name": "q", "arguments": {"sql": "SSN 123-45-6789"}},
            "id": 1,
        },
        {
            "jsonrpc": "2.0",
            "method": "tools/list",
            "id": 2,
        },
    ]
    data = json.dumps(batch).encode()
    msg = parse_message(data)
    result = interceptor.intercept_client_message(msg)

    # Batch should still forward (second message is clean)
    assert result.should_forward is True
    # But the blocked sub-message produces an error override
    assert result.response_override is not None
    assert b"Vloex" in result.response_override
    # The forwarded batch should only contain the clean message
    forwarded = json.loads(result.message.raw)
    assert isinstance(forwarded, list)
    assert len(forwarded) == 1
    assert forwarded[0]["method"] == "tools/list"


def test_batch_all_blocked(block_ssn_policy_file: str) -> None:
    """If all sub-messages are blocked, entire batch is not forwarded."""
    interceptor = Interceptor("test", policy_file=block_ssn_policy_file)
    batch = [
        {
            "jsonrpc": "2.0",
            "method": "tools/call",
            "params": {"name": "q", "arguments": {"sql": "SSN 123-45-6789"}},
            "id": 1,
        },
        {
            "jsonrpc": "2.0",
            "method": "tools/call",
            "params": {"name": "q2", "arguments": {"data": "SSN 999-88-7777"}},
            "id": 2,
        },
    ]
    data = json.dumps(batch).encode()
    msg = parse_message(data)
    result = interceptor.intercept_client_message(msg)

    assert result.should_forward is False
    assert result.response_override is not None


def test_batch_redact_applies_to_sub_messages(redact_email_policy_file: str) -> None:
    """Redacted sub-messages in batch have their content modified."""
    interceptor = Interceptor("test", policy_file=redact_email_policy_file)
    batch = [
        {
            "jsonrpc": "2.0",
            "method": "tools/call",
            "params": {"name": "q", "arguments": {"to": "a@b.com"}},
            "id": 1,
        },
    ]
    data = json.dumps(batch).encode()
    msg = parse_message(data)
    result = interceptor.intercept_client_message(msg)

    assert result.should_forward is True
    forwarded = json.loads(result.message.raw)
    assert "[REDACTED:pii_email]" in json.dumps(forwarded)
    assert "a@b.com" not in json.dumps(forwarded)


# ── Fix #6: Custom pattern redaction ─────────────────────────────


def test_custom_pattern_redaction_works() -> None:
    """Custom patterns are redacted (not silently skipped)."""
    custom = [
        {
            "pattern_type": "regex",
            "pattern_value": r"PROJ-\d{6}",
            "data_type_label": "project_ref",
            "confidence": 0.9,
        }
    ]
    detections = scan_text("Ref: PROJ-789012", custom_patterns=custom)
    custom_det = [d for d in detections if d.custom_label == "project_ref"]
    assert len(custom_det) == 1
    assert custom_det[0].pattern is not None

    # Now redact using the detection
    result = execute_redact("Ref: PROJ-789012", custom_det)
    assert "PROJ-789012" not in result
    assert "[REDACTED:project_ref]" in result


def test_builtin_detection_carries_pattern() -> None:
    """Built-in detections also carry their pattern for redaction."""
    detections = scan_text("SSN: 123-45-6789")
    ssn = next(d for d in detections if d.data_type == SensitiveDataType.PII_SSN)
    assert ssn.pattern is not None


# ── Fix #7: Custom regex validation ──────────────────────────────


def test_nested_quantifier_rejected() -> None:
    """Regex with nested quantifiers (ReDoS risk) is rejected."""
    custom = [
        {
            "pattern_type": "regex",
            "pattern_value": "(a+)+$",
            "data_type_label": "redos",
            "confidence": 0.9,
        }
    ]
    detections = scan_text("aaaa", custom_patterns=custom)
    redos_dets = [d for d in detections if d.custom_label == "redos"]
    assert redos_dets == []  # Rejected, not matched


def test_oversized_regex_rejected() -> None:
    """Custom regex exceeding length limit is rejected."""
    custom = [
        {
            "pattern_type": "regex",
            "pattern_value": "a" * 600,
            "data_type_label": "long",
            "confidence": 0.9,
        }
    ]
    detections = scan_text("a" * 600, custom_patterns=custom)
    long_dets = [d for d in detections if d.custom_label == "long"]
    assert long_dets == []


def test_validate_custom_regex_catches_redos() -> None:
    """_validate_custom_regex raises ValueError on nested quantifiers."""
    try:
        _validate_custom_regex("(a+)+$")
        raise AssertionError("Should have raised ValueError")
    except ValueError as e:
        assert "nested quantifiers" in str(e)


def test_safe_regex_passes_validation() -> None:
    """Normal regex passes validation."""
    _validate_custom_regex(r"PROJ-\d{6}")  # Should not raise


# ── Fix #8: prompts/get response scanning ────────────────────────


def test_prompts_get_response_redacted(redact_email_policy_file: str) -> None:
    """prompts/get response with email is redacted."""
    interceptor = Interceptor("test", policy_file=redact_email_policy_file)
    # Track request
    req_data = json.dumps(
        {"jsonrpc": "2.0", "method": "prompts/get", "params": {"name": "greet"}, "id": 60}
    ).encode()
    interceptor.intercept_client_message(parse_message(req_data))
    # Process response
    resp_data = json.dumps(
        {
            "jsonrpc": "2.0",
            "result": {
                "messages": [
                    {"role": "user", "content": {"type": "text", "text": "Email admin@corp.com"}}
                ]
            },
            "id": 60,
        }
    ).encode()
    result = interceptor.intercept_server_message(parse_message(resp_data))
    assert result.should_forward is True
    output = json.loads(result.message.raw)
    assert "admin@corp.com" not in json.dumps(output)
    assert "[REDACTED:pii_email]" in json.dumps(output)


# ── Fix #9: Policy schema validation ─────────────────────────────


def test_policy_missing_id_skipped(tmp_path) -> None:
    """Policy without required 'id' field is skipped at load time."""
    policy_file = tmp_path / "bad.json"
    policy_file.write_text(
        json.dumps(
            {
                "policies": [
                    {"name": "No ID", "action": "block", "conditions": []},
                    {
                        "id": "ok",
                        "name": "Valid",
                        "action": "warn",
                        "conditions": [
                            {"field": "has_sensitive_data", "operator": "equals", "value": True}
                        ],
                    },
                ]
            }
        )
    )
    engine = PolicyEngine()
    engine.load_from_file(str(policy_file))
    assert engine.has_policies is True
    # Only 1 valid policy loaded (the one with id)
    assert len(engine._policies) == 1


def test_policy_invalid_action_skipped(tmp_path) -> None:
    """Policy with invalid action value is skipped at load time."""
    policy_file = tmp_path / "bad_action.json"
    policy_file.write_text(
        json.dumps(
            {
                "policies": [
                    {"id": "p1", "name": "Bad", "action": "quarantine", "conditions": []},
                ]
            }
        )
    )
    engine = PolicyEngine()
    engine.load_from_file(str(policy_file))
    assert engine.has_policies is False


# ── Fix #10: Zero-width character bypass ──────────────────────────


def test_zero_width_chars_stripped_before_scan() -> None:
    """Zero-width characters inserted into SSN don't bypass scanning."""
    # U+200B (zero-width space) inserted between digits
    text = "SSN: 1\u200b2\u200b3-45-6789"
    detections = scan_text(text)
    types = [d.data_type for d in detections]
    assert SensitiveDataType.PII_SSN in types


def test_zero_width_chars_in_email() -> None:
    """Zero-width characters in email don't bypass scanning."""
    text = "john\u200b@test.com"
    detections = scan_text(text)
    types = [d.data_type for d in detections]
    assert SensitiveDataType.PII_EMAIL in types


# ── Fix #12: Float conversion crash ──────────────────────────────


def test_greater_than_non_numeric_no_crash() -> None:
    """Non-numeric values in greater_than operator don't crash."""
    engine = PolicyEngine()
    engine.set_policies(
        [
            {
                "id": "p1",
                "name": "test",
                "enabled": True,
                "mode": "enforced",
                "action": "block",
                "conditions": [{"field": "risk_score", "operator": "greater_than", "value": "abc"}],
            }
        ]
    )
    detections = [Detection(SensitiveDataType.PII_SSN, 1.0, 1)]
    result = engine.evaluate("test", "server", detections)
    # Should not crash, should not match
    assert result.action == PolicyAction.ALLOW


# ── Fix #13: Empty conditions ────────────────────────────────────


def test_empty_conditions_never_match() -> None:
    """Policy with empty conditions array never matches (safety default)."""
    engine = PolicyEngine()
    engine.set_policies(
        [
            {
                "id": "p1",
                "name": "Block Everything",
                "enabled": True,
                "mode": "enforced",
                "action": "block",
                "conditions": [],
            }
        ]
    )
    detections = [Detection(SensitiveDataType.PII_SSN, 1.0, 1)]
    result = engine.evaluate("test", "server", detections)
    # Empty conditions = no match = allow
    assert result.action == PolicyAction.ALLOW


# ── SEC-07: 10K rapid tool calls ──────────────────────────────────


def test_10k_rapid_tool_calls_no_crash() -> None:
    """SEC-07: 10K rapid tool calls don't crash or leak memory."""
    interceptor = Interceptor("stress-test")

    for i in range(10_000):
        msg_data = json.dumps(
            {
                "jsonrpc": "2.0",
                "method": "tools/call",
                "params": {"name": "read_file", "arguments": {"path": f"/tmp/file_{i}.txt"}},
                "id": i,
            }
        ).encode()
        msg = parse_message(msg_data)
        result = interceptor.intercept_client_message(msg)
        assert result.should_forward is True

    # Pending requests should be bounded by _MAX_PENDING_REQUESTS (10K)
    # Since we sent exactly 10K, eviction should have kicked in
    assert len(interceptor._pending_requests) <= 10_000


def test_10k_rapid_requests_with_responses() -> None:
    """SEC-07: 10K request/response cycles keep pending_requests bounded."""
    interceptor = Interceptor("stress-test")

    for i in range(10_000):
        # Send request
        req_data = json.dumps(
            {
                "jsonrpc": "2.0",
                "method": "tools/call",
                "params": {"name": "read_file", "arguments": {"path": f"/tmp/{i}"}},
                "id": i,
            }
        ).encode()
        interceptor.intercept_client_message(parse_message(req_data))

        # Send matching response
        resp_data = json.dumps(
            {
                "jsonrpc": "2.0",
                "result": {"content": [{"type": "text", "text": "ok"}]},
                "id": i,
            }
        ).encode()
        interceptor.intercept_server_message(parse_message(resp_data))

    # All responses consumed — pending should be empty
    assert len(interceptor._pending_requests) == 0


# ── SEC-08: 50MB tool result ──────────────────────────────────────


def test_50mb_message_rejected() -> None:
    """SEC-08: 50MB message is rejected as INVALID (exceeds 4MB limit)."""
    # Create a 50MB payload
    large_data = b'{"jsonrpc":"2.0","result":"' + b"x" * (50 * 1024 * 1024) + b'","id":1}'
    msg = parse_message(large_data)
    assert msg.msg_type == MessageType.INVALID


def test_message_at_limit_boundary() -> None:
    """Message just under MAX_MESSAGE_BYTES still parses correctly."""
    # Create a message just under 4MB — account for JSON overhead
    padding_size = MAX_MESSAGE_BYTES - 200
    payload = {"jsonrpc": "2.0", "method": "test", "id": 1, "params": {"data": "x" * padding_size}}
    data = json.dumps(payload).encode()
    msg = parse_message(data)
    # Either parses as REQUEST or INVALID (if over limit) — just shouldn't crash
    assert msg.msg_type in (MessageType.REQUEST, MessageType.INVALID)
