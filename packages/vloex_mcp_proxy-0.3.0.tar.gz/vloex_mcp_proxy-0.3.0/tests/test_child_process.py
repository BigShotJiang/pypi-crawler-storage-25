"""Tests for child process spawning and management."""

from __future__ import annotations

import sys

import pytest

from vloex_mcp_proxy.proxy.child_process import (
    shutdown_server,
    spawn_server,
    wait_for_exit,
)


async def test_spawn_echo_server() -> None:
    """Spawn cat as child, verify it starts and can receive input."""
    managed = await spawn_server("cat", [])
    assert managed.process.pid is not None
    assert managed.process.returncode is None  # Still running

    # Clean up
    managed.stdin.close()
    await managed.stdin.wait_closed()
    await shutdown_server(managed, timeout=2.0)


async def test_spawn_nonexistent_command() -> None:
    """Non-existent command raises FileNotFoundError."""
    with pytest.raises(FileNotFoundError):
        await spawn_server("nonexistent_command_that_does_not_exist_xyz", [])


async def test_shutdown_server() -> None:
    """Spawn + shutdown returns exit code, process terminated."""
    # Use a long-running process (cat blocks on stdin)
    managed = await spawn_server("cat", [])
    assert managed.process.returncode is None

    exit_code = await shutdown_server(managed, timeout=2.0)
    assert managed.process.returncode is not None
    # cat terminated by signal returns negative exit code on Unix
    assert isinstance(exit_code, int)


async def test_env_passthrough() -> None:
    """Spawn with custom env, child inherits it."""
    # Use 'env' command to print environment, check for our custom var
    managed = await spawn_server(
        sys.executable,
        ["-c", "import os; print(os.environ.get('VLOEX_TEST_VAR', 'NOT_SET'))"],
        env={"VLOEX_TEST_VAR": "hello_from_test"},
    )

    # Read child stdout
    output = await managed.stdout.read()
    exit_code = await wait_for_exit(managed)

    assert b"hello_from_test" in output
    assert exit_code == 0


async def test_wait_for_exit() -> None:
    """wait_for_exit returns the correct exit code."""
    managed = await spawn_server(
        sys.executable,
        ["-c", "import sys; sys.exit(42)"],
    )
    exit_code = await wait_for_exit(managed)
    assert exit_code == 42


async def test_shutdown_already_exited() -> None:
    """Shutting down an already-exited process returns its exit code."""
    managed = await spawn_server(
        sys.executable,
        ["-c", "import sys; sys.exit(0)"],
    )
    # Wait for it to finish
    await wait_for_exit(managed)

    # Now shut down again — should handle gracefully
    exit_code = await shutdown_server(managed, timeout=1.0)
    assert exit_code == 0
