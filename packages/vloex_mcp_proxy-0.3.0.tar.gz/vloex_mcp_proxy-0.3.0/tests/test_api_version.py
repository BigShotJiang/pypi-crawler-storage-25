"""Tests for API version negotiation in Interceptor (Item 12)."""

from __future__ import annotations

import json

from vloex_mcp_proxy.proxy.interceptor import Interceptor
from vloex_mcp_proxy.proxy.jsonrpc import JsonRpcMessage, MessageType


def _make_request(method: str, params: dict | None = None, msg_id: int = 1) -> JsonRpcMessage:
    """Create a JSON-RPC request message."""
    obj: dict = {"jsonrpc": "2.0", "method": method, "id": msg_id}
    if params is not None:
        obj["params"] = params
    raw = json.dumps(obj).encode()
    return JsonRpcMessage(
        raw=raw,
        msg_type=MessageType.REQUEST,
        method=method,
        msg_id=msg_id,
        params=params,
    )


def _make_response(result: dict | None = None, msg_id: int = 1) -> JsonRpcMessage:
    """Create a JSON-RPC response message."""
    obj: dict = {"jsonrpc": "2.0", "id": msg_id}
    if result is not None:
        obj["result"] = result
    raw = json.dumps(obj).encode()
    return JsonRpcMessage(
        raw=raw,
        msg_type=MessageType.RESPONSE,
        msg_id=msg_id,
        result=result,
    )


class TestProtocolVersionNegotiation:
    """Tests for initialize request/response version tracking."""

    def test_initialize_request_extracts_client_version(self) -> None:
        """initialize request extracts client protocolVersion."""
        interceptor = Interceptor(server_name="test-server")
        msg = _make_request("initialize", {"protocolVersion": "2024-11-05"})

        interceptor.intercept_client_message(msg)

        assert interceptor._client_protocol_version == "2024-11-05"

    def test_initialize_response_extracts_server_version(self) -> None:
        """initialize response extracts server protocolVersion."""
        interceptor = Interceptor(server_name="test-server")

        # First send the request to register in pending_requests
        req = _make_request("initialize", {"protocolVersion": "2024-11-05"}, msg_id=1)
        interceptor.intercept_client_message(req)

        # Then send the response
        resp = _make_response(
            {"protocolVersion": "2024-11-05", "capabilities": {}},
            msg_id=1,
        )
        interceptor.intercept_server_message(resp)

        assert interceptor._server_protocol_version == "2024-11-05"

    def test_version_mismatch_detection(self, capsys) -> None:
        """When client and server versions differ, a warning is logged."""
        interceptor = Interceptor(server_name="test-server")

        # Client sends version A
        req = _make_request("initialize", {"protocolVersion": "2024-11-05"}, msg_id=1)
        interceptor.intercept_client_message(req)

        # Server responds with version B
        resp = _make_response(
            {"protocolVersion": "2025-03-26", "capabilities": {}},
            msg_id=1,
        )
        interceptor.intercept_server_message(resp)

        captured = capsys.readouterr()
        assert "WARNING: Protocol version mismatch" in captured.err
        assert "Client=2024-11-05" in captured.err
        assert "Server=2025-03-26" in captured.err

    def test_matching_versions_no_warning(self, capsys) -> None:
        """When client and server versions match, no warning."""
        interceptor = Interceptor(server_name="test-server")

        req = _make_request("initialize", {"protocolVersion": "2024-11-05"}, msg_id=1)
        interceptor.intercept_client_message(req)

        resp = _make_response(
            {"protocolVersion": "2024-11-05", "capabilities": {}},
            msg_id=1,
        )
        interceptor.intercept_server_message(resp)

        captured = capsys.readouterr()
        assert "WARNING: Protocol version mismatch" not in captured.err

    def test_missing_protocol_version_no_crash(self) -> None:
        """Missing protocolVersion field does not crash."""
        interceptor = Interceptor(server_name="test-server")

        # Request without protocolVersion
        req = _make_request("initialize", {"capabilities": {}}, msg_id=1)
        result = interceptor.intercept_client_message(req)
        assert result.should_forward is True
        assert interceptor._client_protocol_version is None

        # Response without protocolVersion
        resp = _make_response({"capabilities": {}}, msg_id=1)
        result = interceptor.intercept_server_message(resp)
        assert result.should_forward is True
        assert interceptor._server_protocol_version is None

    def test_version_stored_as_string(self) -> None:
        """protocolVersion is always stored as str even if numeric."""
        interceptor = Interceptor(server_name="test-server")

        req = _make_request("initialize", {"protocolVersion": 42}, msg_id=1)
        interceptor.intercept_client_message(req)

        assert interceptor._client_protocol_version == "42"
        assert isinstance(interceptor._client_protocol_version, str)

    def test_initialize_still_forwards(self) -> None:
        """initialize messages are still forwarded after version extraction."""
        interceptor = Interceptor(server_name="test-server")

        req = _make_request("initialize", {"protocolVersion": "2024-11-05"}, msg_id=1)
        result = interceptor.intercept_client_message(req)

        assert result.should_forward is True
        assert result.intercepted is True
        assert result.method == "initialize"
