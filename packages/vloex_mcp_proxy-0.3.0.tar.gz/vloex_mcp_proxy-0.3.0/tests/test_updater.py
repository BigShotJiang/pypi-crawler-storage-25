"""Tests for the self-update checker."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

from vloex_mcp_proxy.daemon.updater import (
    UpdateResult,
    _is_pyinstaller_binary,
    _parse_version_tuple,
    apply_update,
    check_for_update,
    check_latest_version,
)


class TestVersionParsing:
    """Tests for version string parsing."""

    def test_simple_version(self) -> None:
        assert _parse_version_tuple("0.3.0") == (0, 3, 0)

    def test_larger_version(self) -> None:
        assert _parse_version_tuple("1.12.3") == (1, 12, 3)

    def test_invalid_version(self) -> None:
        assert _parse_version_tuple("invalid") == (0,)

    def test_empty_string(self) -> None:
        assert _parse_version_tuple("") == (0,)

    def test_none_input(self) -> None:
        assert _parse_version_tuple(None) == (0,)  # type: ignore[arg-type]


class TestPyInstallerDetection:
    """Tests for PyInstaller binary detection."""

    def test_not_frozen(self) -> None:
        assert _is_pyinstaller_binary() is False

    def test_frozen(self) -> None:
        with patch.object(__import__("sys"), "frozen", True, create=True):
            assert _is_pyinstaller_binary() is True


class TestCheckForUpdate:
    """Tests for check_for_update()."""

    @patch("vloex_mcp_proxy.daemon.updater.check_latest_version")
    @patch("vloex_mcp_proxy.daemon.updater._get_current_version", return_value="0.3.0")
    def test_update_available(self, _mock_ver: MagicMock, mock_latest: MagicMock) -> None:
        mock_latest.return_value = "0.4.0"
        result = check_for_update()
        assert result.current_version == "0.3.0"
        assert result.latest_version == "0.4.0"
        assert result.update_available is True
        assert result.error == ""

    @patch("vloex_mcp_proxy.daemon.updater.check_latest_version")
    @patch("vloex_mcp_proxy.daemon.updater._get_current_version", return_value="0.3.0")
    def test_no_update(self, _mock_ver: MagicMock, mock_latest: MagicMock) -> None:
        mock_latest.return_value = "0.3.0"
        result = check_for_update()
        assert result.current_version == "0.3.0"
        assert result.latest_version == "0.3.0"
        assert result.update_available is False

    @patch("vloex_mcp_proxy.daemon.updater.check_latest_version")
    @patch("vloex_mcp_proxy.daemon.updater._get_current_version", return_value="0.3.0")
    def test_network_failure(self, _mock_ver: MagicMock, mock_latest: MagicMock) -> None:
        mock_latest.return_value = None
        result = check_for_update()
        assert result.current_version == "0.3.0"
        assert "Failed" in result.error


class TestCheckLatestVersion:
    """Tests for check_latest_version() strategies."""

    @patch("subprocess.run")
    def test_pip_index_success(self, mock_run: MagicMock) -> None:
        mock_run.return_value = MagicMock(
            returncode=0,
            stdout="vloex-mcp-proxy (0.5.0)\n",
        )
        version = check_latest_version()
        assert version == "0.5.0"

    @patch("urllib.request.urlopen")
    @patch("subprocess.run")
    def test_pypi_json_fallback(self, mock_run: MagicMock, mock_urlopen: MagicMock) -> None:
        """If pip index fails, fall back to PyPI JSON API."""
        mock_run.side_effect = FileNotFoundError("pip not found")

        mock_response = MagicMock()
        mock_response.read.return_value = b'{"info": {"version": "0.6.0"}}'
        mock_response.__enter__ = lambda s: s
        mock_response.__exit__ = MagicMock(return_value=False)
        mock_urlopen.return_value = mock_response

        version = check_latest_version()
        assert version == "0.6.0"

    @patch("urllib.request.urlopen")
    @patch("subprocess.run")
    def test_both_strategies_fail(self, mock_run: MagicMock, mock_urlopen: MagicMock) -> None:
        mock_run.side_effect = FileNotFoundError()
        mock_urlopen.side_effect = Exception("network error")
        version = check_latest_version()
        assert version is None


class TestApplyUpdate:
    """Tests for apply_update()."""

    @patch("subprocess.run")
    @patch("vloex_mcp_proxy.daemon.updater.check_for_update")
    @patch("vloex_mcp_proxy.daemon.updater._is_pyinstaller_binary", return_value=False)
    @patch("vloex_mcp_proxy.daemon.updater._get_current_version", return_value="0.3.0")
    def test_pip_upgrade_success(
        self,
        _mock_ver: MagicMock,
        _mock_frozen: MagicMock,
        mock_check: MagicMock,
        mock_run: MagicMock,
    ) -> None:
        mock_check.return_value = UpdateResult(
            current_version="0.3.0",
            latest_version="0.4.0",
            update_available=True,
        )
        mock_run.return_value = MagicMock(returncode=0, stdout="", stderr="")
        result = apply_update()
        assert result.updated is True
        assert result.latest_version == "0.4.0"

    @patch("vloex_mcp_proxy.daemon.updater._is_pyinstaller_binary", return_value=True)
    @patch("vloex_mcp_proxy.daemon.updater._get_current_version", return_value="0.3.0")
    def test_standalone_no_self_update(self, _mock_ver: MagicMock, _mock_frozen: MagicMock) -> None:
        result = apply_update()
        assert result.updated is False
        assert "Binary builds cannot self-update" in result.error

    @patch("vloex_mcp_proxy.daemon.updater.check_for_update")
    @patch("vloex_mcp_proxy.daemon.updater._is_pyinstaller_binary", return_value=False)
    @patch("vloex_mcp_proxy.daemon.updater._get_current_version", return_value="0.3.0")
    def test_already_up_to_date(
        self,
        _mock_ver: MagicMock,
        _mock_frozen: MagicMock,
        mock_check: MagicMock,
    ) -> None:
        mock_check.return_value = UpdateResult(
            current_version="0.3.0",
            latest_version="0.3.0",
            update_available=False,
        )
        result = apply_update()
        assert result.updated is False
        assert "Already up to date" in result.error

    @patch("subprocess.run")
    @patch("vloex_mcp_proxy.daemon.updater.check_for_update")
    @patch("vloex_mcp_proxy.daemon.updater._is_pyinstaller_binary", return_value=False)
    @patch("vloex_mcp_proxy.daemon.updater._get_current_version", return_value="0.3.0")
    def test_pip_failure(
        self,
        _mock_ver: MagicMock,
        _mock_frozen: MagicMock,
        mock_check: MagicMock,
        mock_run: MagicMock,
    ) -> None:
        mock_check.return_value = UpdateResult(
            current_version="0.3.0",
            latest_version="0.4.0",
            update_available=True,
        )
        mock_run.return_value = MagicMock(returncode=1, stderr="Permission denied")
        result = apply_update()
        assert result.updated is False
        assert "pip install failed" in result.error

    @patch("subprocess.run")
    @patch("vloex_mcp_proxy.daemon.updater.check_for_update")
    @patch("vloex_mcp_proxy.daemon.updater._is_pyinstaller_binary", return_value=False)
    @patch("vloex_mcp_proxy.daemon.updater._get_current_version", return_value="0.3.0")
    def test_pip_timeout(
        self,
        _mock_ver: MagicMock,
        _mock_frozen: MagicMock,
        mock_check: MagicMock,
        mock_run: MagicMock,
    ) -> None:
        import subprocess

        mock_check.return_value = UpdateResult(
            current_version="0.3.0",
            latest_version="0.4.0",
            update_available=True,
        )
        mock_run.side_effect = subprocess.TimeoutExpired(cmd="pip", timeout=120)
        result = apply_update()
        assert result.updated is False
        assert "timed out" in result.error
