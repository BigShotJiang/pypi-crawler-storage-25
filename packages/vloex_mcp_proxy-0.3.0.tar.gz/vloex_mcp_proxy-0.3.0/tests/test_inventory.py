"""Tests for ServerInventory — tool tracking, change detection, persistence."""

from pathlib import Path

from vloex_mcp_proxy.security.inventory import (
    ChangeType,
    ServerInventory,
    _sha256,
    _tool_entry_from_dict,
)


def _make_tool(name: str, description: str = "A tool", schema: dict | None = None) -> dict:
    return {
        "name": name,
        "description": description,
        "inputSchema": schema or {"type": "object"},
    }


class TestSha256:
    def test_deterministic(self):
        assert _sha256("hello") == _sha256("hello")

    def test_different_inputs(self):
        assert _sha256("hello") != _sha256("world")


class TestToolEntryFromDict:
    def test_basic(self):
        tool = _make_tool("read_file", "Read a file")
        entry = _tool_entry_from_dict(tool)
        assert entry.name == "read_file"
        assert len(entry.description_hash) == 64
        assert len(entry.schema_hash) == 64

    def test_same_tool_same_hash(self):
        tool1 = _make_tool("foo", "desc", {"type": "string"})
        tool2 = _make_tool("foo", "desc", {"type": "string"})
        e1 = _tool_entry_from_dict(tool1)
        e2 = _tool_entry_from_dict(tool2)
        assert e1.description_hash == e2.description_hash
        assert e1.schema_hash == e2.schema_hash

    def test_different_description(self):
        e1 = _tool_entry_from_dict(_make_tool("foo", "desc A"))
        e2 = _tool_entry_from_dict(_make_tool("foo", "desc B"))
        assert e1.description_hash != e2.description_hash

    def test_schema_key_order_irrelevant(self):
        """JSON sort_keys=True ensures consistent hashing regardless of key order."""
        e1 = _tool_entry_from_dict(_make_tool("foo", "d", {"a": 1, "b": 2}))
        e2 = _tool_entry_from_dict(_make_tool("foo", "d", {"b": 2, "a": 1}))
        assert e1.schema_hash == e2.schema_hash


class TestServerInventory:
    def test_new_server_all_added(self, tmp_path: Path):
        inv = ServerInventory(tmp_path / "inv.json")
        tools = [_make_tool("read"), _make_tool("write")]
        changes = inv.update_tools_list("test-server", tools)
        assert len(changes) == 2
        assert all(c.change_type == ChangeType.TOOL_ADDED for c in changes)

    def test_no_change_on_same_tools(self, tmp_path: Path):
        inv = ServerInventory(tmp_path / "inv.json")
        tools = [_make_tool("read")]
        inv.update_tools_list("s", tools)
        changes = inv.update_tools_list("s", tools)
        assert changes == []

    def test_tool_removed(self, tmp_path: Path):
        inv = ServerInventory(tmp_path / "inv.json")
        inv.update_tools_list("s", [_make_tool("a"), _make_tool("b")])
        changes = inv.update_tools_list("s", [_make_tool("a")])
        assert len(changes) == 1
        assert changes[0].change_type == ChangeType.TOOL_REMOVED
        assert changes[0].tool_name == "b"

    def test_tool_description_changed(self, tmp_path: Path):
        inv = ServerInventory(tmp_path / "inv.json")
        inv.update_tools_list("s", [_make_tool("read", "Read a file")])
        changes = inv.update_tools_list("s", [_make_tool("read", "Read a file MODIFIED")])
        assert len(changes) == 1
        assert changes[0].change_type == ChangeType.TOOL_DESCRIPTION_CHANGED

    def test_tool_schema_changed(self, tmp_path: Path):
        inv = ServerInventory(tmp_path / "inv.json")
        inv.update_tools_list("s", [_make_tool("read", "d", {"type": "object"})])
        changes = inv.update_tools_list("s", [_make_tool("read", "d", {"type": "string"})])
        assert len(changes) == 1
        assert changes[0].change_type == ChangeType.TOOL_SCHEMA_CHANGED

    def test_multiple_changes(self, tmp_path: Path):
        inv = ServerInventory(tmp_path / "inv.json")
        inv.update_tools_list("s", [_make_tool("a", "old_desc"), _make_tool("b")])
        changes = inv.update_tools_list("s", [_make_tool("a", "new_desc"), _make_tool("c")])
        types = {c.change_type for c in changes}
        assert ChangeType.TOOL_DESCRIPTION_CHANGED in types  # a description changed
        assert ChangeType.TOOL_REMOVED in types  # b removed
        assert ChangeType.TOOL_ADDED in types  # c added

    def test_persistence_save_load(self, tmp_path: Path):
        path = tmp_path / "inv.json"
        inv1 = ServerInventory(path)
        inv1.update_tools_list("s", [_make_tool("read")])

        # Create new instance, should load from file
        inv2 = ServerInventory(path)
        changes = inv2.update_tools_list("s", [_make_tool("read")])
        assert changes == []  # No changes since same tools

    def test_persistence_file_permissions(self, tmp_path: Path):
        path = tmp_path / "inv.json"
        inv = ServerInventory(path)
        inv.update_tools_list("s", [_make_tool("read")])
        assert path.exists()
        # Check permissions (Unix only)
        import os
        import stat

        if hasattr(os, "chmod"):
            mode = stat.S_IMODE(path.stat().st_mode)
            assert mode == 0o600

    def test_corrupt_file_handled(self, tmp_path: Path):
        path = tmp_path / "inv.json"
        path.write_text("not valid json {{{")
        inv = ServerInventory(path)
        assert inv.get_all_servers() == {}

    def test_binary_hash_first_time(self, tmp_path: Path):
        inv = ServerInventory(tmp_path / "inv.json")
        binary = tmp_path / "server.bin"
        binary.write_bytes(b"binary content v1")
        changes = inv.update_binary_hash("s", str(binary))
        assert changes == []  # First time, no change to report

    def test_binary_hash_changed(self, tmp_path: Path):
        inv = ServerInventory(tmp_path / "inv.json")
        binary = tmp_path / "server.bin"
        binary.write_bytes(b"binary content v1")
        inv.update_binary_hash("s", str(binary))
        binary.write_bytes(b"binary content v2")
        changes = inv.update_binary_hash("s", str(binary))
        assert len(changes) == 1
        assert changes[0].change_type == ChangeType.BINARY_CHANGED

    def test_binary_hash_same(self, tmp_path: Path):
        inv = ServerInventory(tmp_path / "inv.json")
        binary = tmp_path / "server.bin"
        binary.write_bytes(b"same content")
        inv.update_binary_hash("s", str(binary))
        changes = inv.update_binary_hash("s", str(binary))
        assert changes == []

    def test_binary_missing_no_crash(self, tmp_path: Path):
        inv = ServerInventory(tmp_path / "inv.json")
        changes = inv.update_binary_hash("s", "/nonexistent/path")
        assert changes == []

    def test_clear_server(self, tmp_path: Path):
        inv = ServerInventory(tmp_path / "inv.json")
        inv.update_tools_list("s1", [_make_tool("a")])
        inv.update_tools_list("s2", [_make_tool("b")])
        inv.clear("s1")
        assert inv.get_server("s1") is None
        assert inv.get_server("s2") is not None

    def test_clear_all(self, tmp_path: Path):
        inv = ServerInventory(tmp_path / "inv.json")
        inv.update_tools_list("s1", [_make_tool("a")])
        inv.update_tools_list("s2", [_make_tool("b")])
        inv.clear()
        assert inv.get_all_servers() == {}

    def test_multiple_servers_independent(self, tmp_path: Path):
        inv = ServerInventory(tmp_path / "inv.json")
        inv.update_tools_list("s1", [_make_tool("read")])
        inv.update_tools_list("s2", [_make_tool("write")])
        # Changing s2 should not affect s1
        changes = inv.update_tools_list("s1", [_make_tool("read")])
        assert changes == []

    def test_empty_file_handled(self, tmp_path: Path):
        path = tmp_path / "inv.json"
        path.write_text("")
        inv = ServerInventory(path)
        assert inv.get_all_servers() == {}
