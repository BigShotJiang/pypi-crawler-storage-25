"""Tests for discovery/config_parser.py — multi-format config parsing."""

from __future__ import annotations

import json

import pytest

from vloex_mcp_proxy.discovery.config_parser import parse_config, serialize_config
from vloex_mcp_proxy.discovery.config_paths import ConfigFormat

# ---------------------------------------------------------------------------
# Standard format
# ---------------------------------------------------------------------------


class TestParseStandard:
    """Tests for standard MCP config format."""

    def test_parse_standard_format(self, tmp_path) -> None:
        """Standard config with 2 servers → parsed correctly."""
        config = {
            "mcpServers": {
                "filesystem": {
                    "command": "npx",
                    "args": ["-y", "@modelcontextprotocol/server-filesystem", "/Users"],
                },
                "github": {
                    "command": "npx",
                    "args": ["-y", "@modelcontextprotocol/server-github"],
                },
            }
        }
        path = tmp_path / "mcp.json"
        path.write_text(json.dumps(config))

        servers = parse_config(path, ConfigFormat.STANDARD)
        assert len(servers) == 2
        assert servers["filesystem"]["command"] == "npx"
        assert servers["github"]["command"] == "npx"

    def test_parse_standard_with_env(self, tmp_path) -> None:
        """Server entry with env field → preserved in parsed output."""
        config = {
            "mcpServers": {
                "github": {
                    "command": "npx",
                    "args": ["-y", "@modelcontextprotocol/server-github"],
                    "env": {"GITHUB_TOKEN": "ghp_fake123"},
                }
            }
        }
        path = tmp_path / "mcp.json"
        path.write_text(json.dumps(config))

        servers = parse_config(path, ConfigFormat.STANDARD)
        assert servers["github"]["env"]["GITHUB_TOKEN"] == "ghp_fake123"

    def test_parse_missing_key_returns_empty(self, tmp_path) -> None:
        """Config without mcpServers key → returns empty dict."""
        config = {"someOtherKey": "value"}
        path = tmp_path / "mcp.json"
        path.write_text(json.dumps(config))

        servers = parse_config(path, ConfigFormat.STANDARD)
        assert servers == {}

    def test_parse_empty_servers_returns_empty(self, tmp_path) -> None:
        """Empty mcpServers → returns empty dict."""
        config = {"mcpServers": {}}
        path = tmp_path / "mcp.json"
        path.write_text(json.dumps(config))

        servers = parse_config(path, ConfigFormat.STANDARD)
        assert servers == {}

    def test_parse_invalid_json_raises(self, tmp_path) -> None:
        """Malformed JSON → json.JSONDecodeError."""
        path = tmp_path / "mcp.json"
        path.write_text("{invalid json!!!}")

        with pytest.raises(json.JSONDecodeError):
            parse_config(path, ConfigFormat.STANDARD)


# ---------------------------------------------------------------------------
# VS Code format
# ---------------------------------------------------------------------------


class TestParseVSCode:
    """Tests for VS Code settings.json format."""

    def test_parse_vscode_nested_key(self, tmp_path) -> None:
        """Nested format: {"mcp": {"servers": {...}}} → parsed."""
        config = {
            "editor.fontSize": 14,
            "mcp": {
                "servers": {
                    "postgres": {
                        "command": "npx",
                        "args": ["-y", "@modelcontextprotocol/server-postgres"],
                    }
                }
            },
        }
        path = tmp_path / "settings.json"
        path.write_text(json.dumps(config))

        servers = parse_config(path, ConfigFormat.VSCODE, key_in_settings="mcp.servers")
        assert len(servers) == 1
        assert servers["postgres"]["command"] == "npx"

    def test_parse_vscode_flat_key(self, tmp_path) -> None:
        """Flat format: {"mcp.servers": {...}} → also parsed."""
        config = {
            "editor.fontSize": 14,
            "mcp.servers": {
                "postgres": {
                    "command": "npx",
                    "args": ["-y", "@modelcontextprotocol/server-postgres"],
                }
            },
        }
        path = tmp_path / "settings.json"
        path.write_text(json.dumps(config))

        servers = parse_config(path, ConfigFormat.VSCODE, key_in_settings="mcp.servers")
        assert len(servers) == 1
        assert servers["postgres"]["command"] == "npx"

    def test_parse_vscode_nested_preferred_over_flat(self, tmp_path) -> None:
        """When both nested and flat exist, nested wins."""
        config = {
            "mcp": {"servers": {"nested_server": {"command": "npx", "args": []}}},
            "mcp.servers": {"flat_server": {"command": "npx", "args": []}},
        }
        path = tmp_path / "settings.json"
        path.write_text(json.dumps(config))

        servers = parse_config(path, ConfigFormat.VSCODE, key_in_settings="mcp.servers")
        assert "nested_server" in servers
        assert "flat_server" not in servers

    def test_parse_vscode_no_mcp_key(self, tmp_path) -> None:
        """VS Code settings without MCP section → empty dict."""
        config = {"editor.fontSize": 14, "workbench.colorTheme": "Dark+"}
        path = tmp_path / "settings.json"
        path.write_text(json.dumps(config))

        servers = parse_config(path, ConfigFormat.VSCODE, key_in_settings="mcp.servers")
        assert servers == {}


# ---------------------------------------------------------------------------
# Zed format
# ---------------------------------------------------------------------------


class TestParseZed:
    """Tests for Zed settings format."""

    def test_parse_zed_format(self, tmp_path) -> None:
        """Zed config with context_servers → parsed correctly."""
        config = {
            "theme": "One Dark",
            "context_servers": {
                "filesystem": {
                    "command": "npx",
                    "args": ["-y", "@modelcontextprotocol/server-filesystem", "/tmp"],
                }
            },
            "vim_mode": True,
        }
        path = tmp_path / "settings.json"
        path.write_text(json.dumps(config))

        servers = parse_config(path, ConfigFormat.ZED, key_in_settings="context_servers")
        assert len(servers) == 1
        assert servers["filesystem"]["command"] == "npx"


# ---------------------------------------------------------------------------
# Continue array format
# ---------------------------------------------------------------------------


class TestParseContinue:
    """Tests for Continue array-format configs."""

    def test_parse_continue_array(self, tmp_path) -> None:
        """Array format → converted to dict format."""
        config = {
            "mcpServers": [
                {
                    "name": "filesystem",
                    "command": "npx",
                    "args": ["-y", "@modelcontextprotocol/server-filesystem", "/tmp"],
                },
                {
                    "name": "github",
                    "command": "npx",
                    "args": ["-y", "@modelcontextprotocol/server-github"],
                    "env": {"GITHUB_TOKEN": "ghp_fake"},
                },
            ]
        }
        path = tmp_path / "config.json"
        path.write_text(json.dumps(config))

        servers = parse_config(path, ConfigFormat.CONTINUE_ARRAY, key_in_settings="mcpServers")
        assert len(servers) == 2
        assert servers["filesystem"]["command"] == "npx"
        assert "name" not in servers["filesystem"]  # "name" extracted as key
        assert servers["github"]["env"]["GITHUB_TOKEN"] == "ghp_fake"

    def test_parse_continue_empty_array(self, tmp_path) -> None:
        """Empty array → empty dict."""
        config = {"mcpServers": []}
        path = tmp_path / "config.json"
        path.write_text(json.dumps(config))

        servers = parse_config(path, ConfigFormat.CONTINUE_ARRAY, key_in_settings="mcpServers")
        assert servers == {}

    def test_parse_continue_skips_nameless_entries(self, tmp_path) -> None:
        """Array entries without 'name' field → skipped."""
        config = {
            "mcpServers": [
                {"command": "npx", "args": []},  # no name
                {"name": "valid", "command": "npx", "args": []},
            ]
        }
        path = tmp_path / "config.json"
        path.write_text(json.dumps(config))

        servers = parse_config(path, ConfigFormat.CONTINUE_ARRAY, key_in_settings="mcpServers")
        assert len(servers) == 1
        assert "valid" in servers


# ---------------------------------------------------------------------------
# Serialization round-trips
# ---------------------------------------------------------------------------


class TestSerialize:
    """Tests for serialize_config() round-trip fidelity."""

    def test_serialize_standard_round_trip(self, tmp_path) -> None:
        """Parse → serialize → parse → same result."""
        config = {
            "mcpServers": {
                "fs": {"command": "npx", "args": ["-y", "fs-server"]},
            }
        }
        path = tmp_path / "mcp.json"
        path.write_text(json.dumps(config))

        servers = parse_config(path, ConfigFormat.STANDARD)
        serialized = serialize_config(servers, ConfigFormat.STANDARD)
        reparsed = json.loads(serialized)
        assert reparsed["mcpServers"] == servers

    def test_serialize_vscode_preserves_other_settings(self, tmp_path) -> None:
        """VS Code settings with editor prefs → only MCP section changed."""
        original = {
            "editor.fontSize": 14,
            "editor.tabSize": 2,
            "mcp": {
                "servers": {
                    "pg": {"command": "npx", "args": ["-y", "pg-server"]},
                }
            },
            "workbench.colorTheme": "One Dark Pro",
        }
        new_servers = {
            "pg": {"command": "vloex-mcp-proxy", "args": ["--server-command", "npx"]},
        }

        serialized = serialize_config(
            new_servers,
            ConfigFormat.VSCODE,
            original_data=original,
            key_in_settings="mcp.servers",
        )
        result = json.loads(serialized)

        # MCP section updated
        assert result["mcp"]["servers"]["pg"]["command"] == "vloex-mcp-proxy"
        # Other settings preserved
        assert result["editor.fontSize"] == 14
        assert result["editor.tabSize"] == 2
        assert result["workbench.colorTheme"] == "One Dark Pro"

    def test_serialize_vscode_flat_key_preserved(self, tmp_path) -> None:
        """VS Code with flat key format → serializes back to flat."""
        original = {
            "editor.fontSize": 14,
            "mcp.servers": {
                "pg": {"command": "npx", "args": []},
            },
        }
        new_servers = {"pg": {"command": "vloex-mcp-proxy", "args": []}}

        serialized = serialize_config(
            new_servers,
            ConfigFormat.VSCODE,
            original_data=original,
            key_in_settings="mcp.servers",
        )
        result = json.loads(serialized)
        assert "mcp.servers" in result
        assert result["mcp.servers"]["pg"]["command"] == "vloex-mcp-proxy"

    def test_serialize_zed_preserves_other_settings(self) -> None:
        """Zed settings → only context_servers changed, other prefs intact."""
        original = {"theme": "One Dark", "context_servers": {}, "vim_mode": True}
        new_servers = {"fs": {"command": "vloex-mcp-proxy", "args": []}}

        serialized = serialize_config(
            new_servers,
            ConfigFormat.ZED,
            original_data=original,
            key_in_settings="context_servers",
        )
        result = json.loads(serialized)
        assert result["context_servers"]["fs"]["command"] == "vloex-mcp-proxy"
        assert result["theme"] == "One Dark"
        assert result["vim_mode"] is True

    def test_serialize_continue_to_array(self) -> None:
        """Dict format → serialized back to Continue array format."""
        servers = {
            "fs": {"command": "npx", "args": ["-y", "fs-server"]},
            "gh": {"command": "npx", "args": ["-y", "gh-server"]},
        }

        serialized = serialize_config(servers, ConfigFormat.CONTINUE_ARRAY)
        result = json.loads(serialized)
        arr = result["mcpServers"]
        assert isinstance(arr, list)
        assert len(arr) == 2
        names = {entry["name"] for entry in arr}
        assert names == {"fs", "gh"}
        # Each entry has command + name
        for entry in arr:
            assert "command" in entry
            assert "name" in entry

    def test_serialize_standard_with_original_preserves_extra_keys(self) -> None:
        """Original data with extra keys → preserved after serialization."""
        original = {"mcpServers": {}, "customKey": "customValue"}
        new_servers = {"fs": {"command": "npx", "args": []}}

        serialized = serialize_config(new_servers, ConfigFormat.STANDARD, original_data=original)
        result = json.loads(serialized)
        assert result["customKey"] == "customValue"
        assert result["mcpServers"]["fs"]["command"] == "npx"
