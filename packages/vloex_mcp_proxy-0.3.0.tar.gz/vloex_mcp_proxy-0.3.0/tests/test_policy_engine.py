"""Tests for the local policy engine."""

from __future__ import annotations

import json

from vloex_mcp_proxy.policy.engine import PolicyAction, PolicyEngine
from vloex_mcp_proxy.scanner.sensitive import Detection, SensitiveDataType


def _make_detection(dtype: SensitiveDataType, confidence: float = 1.0) -> Detection:
    return Detection(data_type=dtype, confidence=confidence, count=1)


def test_no_policies_allows() -> None:
    """Empty policy list → ALLOW."""
    engine = PolicyEngine()
    result = engine.evaluate("tool", "server", [])
    assert result.action == PolicyAction.ALLOW


def test_block_on_ssn() -> None:
    """Policy blocks when pii_ssn detected."""
    engine = PolicyEngine()
    engine.set_policies(
        [
            {
                "id": "p1",
                "name": "Block SSN",
                "enabled": True,
                "mode": "enforced",
                "action": "block",
                "conditions": [
                    {"field": "sensitive_data_types", "operator": "contains", "value": "pii_ssn"}
                ],
            }
        ]
    )
    result = engine.evaluate("query", "postgres", [_make_detection(SensitiveDataType.PII_SSN)])
    assert result.action == PolicyAction.BLOCK
    assert result.policy_id == "p1"


def test_redact_on_email() -> None:
    """Policy redacts when pii_email detected."""
    engine = PolicyEngine()
    engine.set_policies(
        [
            {
                "id": "p2",
                "name": "Redact Email",
                "enabled": True,
                "mode": "enforced",
                "action": "redact",
                "conditions": [
                    {
                        "field": "sensitive_data_types",
                        "operator": "contains",
                        "value": "pii_email",
                    }
                ],
            }
        ]
    )
    result = engine.evaluate("query", "server", [_make_detection(SensitiveDataType.PII_EMAIL)])
    assert result.action == PolicyAction.REDACT


def test_warn_on_source_code() -> None:
    """Policy warns when ip_source_code detected."""
    engine = PolicyEngine()
    engine.set_policies(
        [
            {
                "id": "p3",
                "name": "Warn Source Code",
                "enabled": True,
                "mode": "enforced",
                "action": "warn",
                "conditions": [
                    {
                        "field": "sensitive_data_types",
                        "operator": "contains",
                        "value": "ip_source_code",
                    }
                ],
            }
        ]
    )
    result = engine.evaluate("tool", "server", [_make_detection(SensitiveDataType.IP_SOURCE_CODE)])
    assert result.action == PolicyAction.WARN


def test_block_server_name() -> None:
    """Policy blocks specific server by equals condition."""
    engine = PolicyEngine()
    engine.set_policies(
        [
            {
                "id": "p4",
                "name": "Block malicious server",
                "enabled": True,
                "mode": "enforced",
                "action": "block",
                "conditions": [
                    {"field": "server_name", "operator": "equals", "value": "malicious"}
                ],
            }
        ]
    )
    result = engine.evaluate("tool", "malicious", [])
    assert result.action == PolicyAction.BLOCK


def test_block_tool_name() -> None:
    """Policy blocks specific tool name."""
    engine = PolicyEngine()
    engine.set_policies(
        [
            {
                "id": "p5",
                "name": "Block execute_command",
                "enabled": True,
                "mode": "enforced",
                "action": "block",
                "conditions": [
                    {"field": "tool_name", "operator": "equals", "value": "execute_command"}
                ],
            }
        ]
    )
    result = engine.evaluate("execute_command", "server", [])
    assert result.action == PolicyAction.BLOCK


def test_scope_server_filter() -> None:
    """Policy scoped to 'postgres' does not match 'filesystem'."""
    engine = PolicyEngine()
    engine.set_policies(
        [
            {
                "id": "p6",
                "name": "Block PII in postgres",
                "enabled": True,
                "mode": "enforced",
                "action": "block",
                "conditions": [
                    {"field": "has_sensitive_data", "operator": "equals", "value": True}
                ],
                "scope": {"server_names": ["postgres"]},
            }
        ]
    )
    result = engine.evaluate("query", "filesystem", [_make_detection(SensitiveDataType.PII_SSN)])
    assert result.action == PolicyAction.ALLOW


def test_scope_department_filter() -> None:
    """Policy scoped to finance does not match engineering."""
    engine = PolicyEngine()
    engine.set_policies(
        [
            {
                "id": "p7",
                "name": "Block for finance",
                "enabled": True,
                "mode": "enforced",
                "action": "block",
                "conditions": [
                    {"field": "has_sensitive_data", "operator": "equals", "value": True}
                ],
                "scope": {"departments": ["finance"]},
            }
        ]
    )
    result = engine.evaluate(
        "query",
        "server",
        [_make_detection(SensitiveDataType.PII_SSN)],
        department="engineering",
    )
    assert result.action == PolicyAction.ALLOW


def test_strictest_wins() -> None:
    """When both warn and block match, block (strictest) wins."""
    engine = PolicyEngine()
    engine.set_policies(
        [
            {
                "id": "p8a",
                "name": "Warn on PII",
                "enabled": True,
                "mode": "enforced",
                "action": "warn",
                "conditions": [
                    {"field": "has_sensitive_data", "operator": "equals", "value": True}
                ],
            },
            {
                "id": "p8b",
                "name": "Block SSN",
                "enabled": True,
                "mode": "enforced",
                "action": "block",
                "conditions": [
                    {"field": "sensitive_data_types", "operator": "contains", "value": "pii_ssn"}
                ],
            },
        ]
    )
    result = engine.evaluate("tool", "server", [_make_detection(SensitiveDataType.PII_SSN)])
    assert result.action == PolicyAction.BLOCK
    assert result.policy_id == "p8b"


def test_disabled_policy_skipped() -> None:
    """Disabled policy does not match."""
    engine = PolicyEngine()
    engine.set_policies(
        [
            {
                "id": "p9",
                "name": "Block (disabled)",
                "enabled": False,
                "mode": "enforced",
                "action": "block",
                "conditions": [
                    {"field": "has_sensitive_data", "operator": "equals", "value": True}
                ],
            }
        ]
    )
    result = engine.evaluate("tool", "server", [_make_detection(SensitiveDataType.PII_SSN)])
    assert result.action == PolicyAction.ALLOW


def test_simulation_mode() -> None:
    """Simulation-mode policy is not enforced."""
    engine = PolicyEngine()
    engine.set_policies(
        [
            {
                "id": "p10",
                "name": "Block (simulation)",
                "enabled": True,
                "mode": "simulation",
                "action": "block",
                "conditions": [
                    {"field": "has_sensitive_data", "operator": "equals", "value": True}
                ],
            }
        ]
    )
    result = engine.evaluate("tool", "server", [_make_detection(SensitiveDataType.PII_SSN)])
    assert result.action == PolicyAction.ALLOW


def test_load_from_file(tmp_path) -> None:
    """Load policies from JSON file and evaluate."""
    policy_file = tmp_path / "test.json"
    policy_file.write_text(
        json.dumps(
            {
                "policies": [
                    {
                        "id": "file_p1",
                        "name": "Block SSN from file",
                        "enabled": True,
                        "mode": "enforced",
                        "action": "block",
                        "conditions": [
                            {
                                "field": "sensitive_data_types",
                                "operator": "contains",
                                "value": "pii_ssn",
                            }
                        ],
                        "message": "Contact security team.",
                    }
                ],
                "custom_patterns": [
                    {
                        "pattern_type": "regex",
                        "pattern_value": r"PROJ-\d{6}",
                        "data_type_label": "project_ref",
                        "confidence": 0.9,
                    }
                ],
            }
        )
    )
    engine = PolicyEngine()
    engine.load_from_file(str(policy_file))
    assert engine.has_policies
    assert len(engine.custom_patterns) == 1

    result = engine.evaluate("query", "db", [_make_detection(SensitiveDataType.PII_SSN)])
    assert result.action == PolicyAction.BLOCK
    assert result.policy_name == "Block SSN from file"


def test_policy_result_has_message() -> None:
    """PolicyResult includes policy name and contact info."""
    engine = PolicyEngine()
    engine.set_policies(
        [
            {
                "id": "pmsg",
                "name": "No PII in queries",
                "enabled": True,
                "mode": "enforced",
                "action": "block",
                "conditions": [
                    {"field": "sensitive_data_types", "operator": "contains", "value": "pii_ssn"}
                ],
                "message": "Contact IT admin for exceptions.",
            }
        ]
    )
    result = engine.evaluate("query", "db", [_make_detection(SensitiveDataType.PII_SSN)])
    assert result.action == PolicyAction.BLOCK
    assert "No PII in queries" in (result.message or "")
    assert "Contact IT admin" in (result.message or "")


def test_scope_server_matches() -> None:
    """Policy scoped to 'postgres' matches when server_name is 'postgres'."""
    engine = PolicyEngine()
    engine.set_policies(
        [
            {
                "id": "scope_match",
                "name": "Block PII in postgres",
                "enabled": True,
                "mode": "enforced",
                "action": "block",
                "conditions": [
                    {"field": "has_sensitive_data", "operator": "equals", "value": True}
                ],
                "scope": {"server_names": ["postgres"]},
            }
        ]
    )
    result = engine.evaluate("query", "postgres", [_make_detection(SensitiveDataType.PII_SSN)])
    assert result.action == PolicyAction.BLOCK


def test_contains_operator_on_list() -> None:
    """'contains' operator works on list fields."""
    engine = PolicyEngine()
    engine.set_policies(
        [
            {
                "id": "list_check",
                "name": "Block if email detected",
                "enabled": True,
                "mode": "enforced",
                "action": "block",
                "conditions": [
                    {
                        "field": "sensitive_data_types",
                        "operator": "contains",
                        "value": "pii_email",
                    }
                ],
            }
        ]
    )
    result = engine.evaluate(
        "tool",
        "server",
        [
            _make_detection(SensitiveDataType.PII_SSN),
            _make_detection(SensitiveDataType.PII_EMAIL),
        ],
    )
    assert result.action == PolicyAction.BLOCK
