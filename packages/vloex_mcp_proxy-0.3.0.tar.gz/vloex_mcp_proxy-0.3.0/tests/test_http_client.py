"""Tests for vloex_mcp_proxy.backend.http_client."""

from __future__ import annotations

import json

import httpx

from vloex_mcp_proxy.backend.http_client import VloexClient


def _mock_transport(handler):
    """Create async mock transport from sync handler."""
    return httpx.MockTransport(handler)


class TestHeartbeat:
    async def test_success(self):
        def handler(request: httpx.Request) -> httpx.Response:
            assert request.url.path == "/api/v1/devices/heartbeat"
            body = json.loads(request.content)
            assert body["client_type"] == "mcp_proxy"
            return httpx.Response(200, json={"status": "ok", "mcp_config": {"policies": []}})

        client = VloexClient("http://test")
        client._client = httpx.AsyncClient(
            transport=_mock_transport(handler), base_url="http://test"
        )
        result = await client.heartbeat("device-001")
        assert result is not None
        assert result["status"] == "ok"
        await client.close()

    async def test_failure(self):
        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(500, json={"error": "internal"})

        client = VloexClient("http://test")
        client._client = httpx.AsyncClient(
            transport=_mock_transport(handler), base_url="http://test"
        )
        result = await client.heartbeat("device-001")
        assert result is None
        await client.close()

    async def test_not_initialized(self):
        client = VloexClient("http://test")
        result = await client.heartbeat("device-001")
        assert result is None


class TestSendEventsBatch:
    async def test_success(self):
        def handler(request: httpx.Request) -> httpx.Response:
            assert request.url.path == "/api/v1/events/batch"
            return httpx.Response(200, json=[])

        client = VloexClient("http://test", device_token="test-jwt")
        client._client = httpx.AsyncClient(
            transport=_mock_transport(handler), base_url="http://test"
        )
        ok = await client.send_events_batch([{"event": "test"}])
        assert ok is True
        await client.close()

    async def test_401(self):
        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(401, json={"detail": "unauthorized"})

        client = VloexClient("http://test", device_token="expired-jwt")
        client._client = httpx.AsyncClient(
            transport=_mock_transport(handler), base_url="http://test"
        )
        ok = await client.send_events_batch([{"event": "test"}])
        assert ok is False
        await client.close()

    async def test_auth_header(self):
        def handler(request: httpx.Request) -> httpx.Response:
            assert request.headers["authorization"] == "Bearer my-token"
            return httpx.Response(200, json=[])

        client = VloexClient("http://test", device_token="my-token")
        client._client = httpx.AsyncClient(
            transport=_mock_transport(handler), base_url="http://test"
        )
        await client.send_events_batch([])
        await client.close()

    async def test_no_token(self):
        def handler(request: httpx.Request) -> httpx.Response:
            assert "authorization" not in request.headers
            return httpx.Response(200, json=[])

        client = VloexClient("http://test")
        client._client = httpx.AsyncClient(
            transport=_mock_transport(handler), base_url="http://test"
        )
        await client.send_events_batch([])
        await client.close()


class TestEnrollCode:
    async def test_success(self):
        def handler(request: httpx.Request) -> httpx.Response:
            assert request.url.path == "/api/v1/devices/enroll/validate"
            body = json.loads(request.content)
            assert body["code"] == "123456"
            assert body["used_by"] == "dev-001"
            return httpx.Response(200, json={"valid": True, "device_token": "jwt-xyz"})

        client = VloexClient("http://test")
        client._client = httpx.AsyncClient(
            transport=_mock_transport(handler), base_url="http://test"
        )
        result = await client.enroll_code("123456", "dev-001")
        assert result is not None
        assert result["device_token"] == "jwt-xyz"
        await client.close()

    async def test_invalid_code(self):
        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(400, json={"valid": False, "reason": "invalid_code"})

        client = VloexClient("http://test")
        client._client = httpx.AsyncClient(
            transport=_mock_transport(handler), base_url="http://test"
        )
        result = await client.enroll_code("000000", "dev-001")
        assert result is not None
        assert result["valid"] is False
        await client.close()


class TestEnrollToken:
    async def test_success(self):
        def handler(request: httpx.Request) -> httpx.Response:
            assert request.url.path == "/api/v1/devices/auto-enroll"
            body = json.loads(request.content)
            assert body["enrollment_token"] == "tok-abc"
            assert body["device_id"] == "dev-001"
            return httpx.Response(200, json={"valid": True, "device_token": "jwt-abc"})

        client = VloexClient("http://test")
        client._client = httpx.AsyncClient(
            transport=_mock_transport(handler), base_url="http://test"
        )
        result = await client.enroll_token("tok-abc", "dev-001")
        assert result is not None
        assert result["device_token"] == "jwt-abc"
        await client.close()


class TestNetworkError:
    async def test_heartbeat_connection_error(self):
        def handler(request: httpx.Request) -> httpx.Response:
            raise httpx.ConnectError("connection refused")

        client = VloexClient("http://test")
        client._client = httpx.AsyncClient(
            transport=_mock_transport(handler), base_url="http://test"
        )
        result = await client.heartbeat("dev-001")
        assert result is None
        await client.close()

    async def test_send_events_connection_error(self):
        def handler(request: httpx.Request) -> httpx.Response:
            raise httpx.ConnectError("connection refused")

        client = VloexClient("http://test")
        client._client = httpx.AsyncClient(
            transport=_mock_transport(handler), base_url="http://test"
        )
        ok = await client.send_events_batch([{"event": "test"}])
        assert ok is False
        await client.close()
