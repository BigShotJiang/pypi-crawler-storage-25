"""Tests for daemon service — PID lifecycle, stale PID, stop/cleanup."""

import os
from pathlib import Path

from vloex_mcp_proxy.daemon.service import DaemonService


class TestDaemonPIDLifecycle:
    def test_write_pid(self, tmp_path: Path):
        svc = DaemonService(vloex_dir=tmp_path)
        svc._write_pid()
        assert svc.pid_file.exists()
        assert int(svc.pid_file.read_text().strip()) == os.getpid()

    def test_remove_pid(self, tmp_path: Path):
        svc = DaemonService(vloex_dir=tmp_path)
        svc._write_pid()
        assert svc.pid_file.exists()
        svc._remove_pid()
        assert not svc.pid_file.exists()

    def test_remove_pid_idempotent(self, tmp_path: Path):
        svc = DaemonService(vloex_dir=tmp_path)
        svc._remove_pid()  # Should not raise even if file doesn't exist

    def test_is_running_no_pid_file(self, tmp_path: Path):
        svc = DaemonService(vloex_dir=tmp_path)
        assert not svc.is_running(svc.pid_file)

    def test_is_running_own_pid(self, tmp_path: Path):
        svc = DaemonService(vloex_dir=tmp_path)
        svc._write_pid()
        assert svc.is_running(svc.pid_file)

    def test_is_running_stale_pid(self, tmp_path: Path):
        """A PID that doesn't correspond to a running process should return False."""
        svc = DaemonService(vloex_dir=tmp_path)
        # Use a PID that's very unlikely to be running
        svc.pid_file.write_text("999999999")
        assert not svc.is_running(svc.pid_file)

    def test_is_running_invalid_pid(self, tmp_path: Path):
        svc = DaemonService(vloex_dir=tmp_path)
        svc.pid_file.write_text("not-a-number")
        assert not svc.is_running(svc.pid_file)

    def test_read_pid(self, tmp_path: Path):
        svc = DaemonService(vloex_dir=tmp_path)
        svc._write_pid()
        assert svc.read_pid(svc.pid_file) == os.getpid()

    def test_read_pid_invalid(self, tmp_path: Path):
        svc = DaemonService(vloex_dir=tmp_path)
        svc.pid_file.write_text("garbage")
        assert svc.read_pid(svc.pid_file) is None

    def test_stop_cleans_up(self, tmp_path: Path):
        svc = DaemonService(vloex_dir=tmp_path)
        svc._write_pid()
        svc._stop()
        assert not svc.pid_file.exists()

    def test_stop_external_no_daemon(self, tmp_path: Path):
        svc = DaemonService(vloex_dir=tmp_path)
        assert svc.stop_external() is False
