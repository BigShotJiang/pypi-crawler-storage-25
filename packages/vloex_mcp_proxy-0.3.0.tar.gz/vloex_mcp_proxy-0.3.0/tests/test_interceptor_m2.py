"""M2 interceptor tests — scanner + policy wired into intercept pipeline."""

from __future__ import annotations

import json

from vloex_mcp_proxy.proxy.interceptor import Interceptor
from vloex_mcp_proxy.proxy.jsonrpc import JsonRpcMessage, parse_message


def _make_request(method: str, params: dict, msg_id: int = 1) -> JsonRpcMessage:
    data = json.dumps({"jsonrpc": "2.0", "method": method, "params": params, "id": msg_id})
    return parse_message(data.encode())


def _make_response(result: object, msg_id: int = 1) -> JsonRpcMessage:
    data = json.dumps({"jsonrpc": "2.0", "result": result, "id": msg_id})
    return parse_message(data.encode())


# ── tools/call client→server ───────────────────────────────────────


def test_intercept_tools_call_block_ssn(block_ssn_policy_file: str) -> None:
    """tools/call with SSN + block policy → should_forward=False."""
    interceptor = Interceptor("test-server", policy_file=block_ssn_policy_file)
    msg = _make_request(
        "tools/call",
        {"name": "query_db", "arguments": {"sql": "SELECT * WHERE ssn='123-45-6789'"}},
    )
    result = interceptor.intercept_client_message(msg)
    assert result.should_forward is False
    assert result.response_override is not None
    parsed = json.loads(result.response_override)
    assert "Vloex" in parsed["error"]["message"]
    assert "pii_ssn" in parsed["error"]["message"]


def test_intercept_tools_call_redact_email(redact_email_policy_file: str) -> None:
    """tools/call with email + redact policy → should_forward=True, raw redacted."""
    interceptor = Interceptor("test-server", policy_file=redact_email_policy_file)
    msg = _make_request(
        "tools/call",
        {"name": "send_msg", "arguments": {"to": "john@test.com"}},
    )
    result = interceptor.intercept_client_message(msg)
    assert result.should_forward is True
    assert result.response_override is None
    # Check the redacted message
    output = json.loads(result.message.raw)
    assert "[REDACTED:pii_email]" in json.dumps(output)
    assert "john@test.com" not in json.dumps(output)


def test_intercept_tools_call_no_policy() -> None:
    """tools/call with SSN but no policy file → should_forward=True (log-only)."""
    interceptor = Interceptor("test-server")  # No policy file
    msg = _make_request(
        "tools/call",
        {"name": "query_db", "arguments": {"sql": "SELECT * WHERE ssn='123-45-6789'"}},
    )
    result = interceptor.intercept_client_message(msg)
    assert result.should_forward is True
    assert result.intercepted is True


def test_intercept_tools_call_clean() -> None:
    """tools/call with clean args → should_forward=True, no redaction."""
    interceptor = Interceptor("test-server")
    msg = _make_request(
        "tools/call",
        {"name": "read_file", "arguments": {"path": "/tmp/readme.txt"}},
    )
    result = interceptor.intercept_client_message(msg)
    assert result.should_forward is True
    assert result.intercepted is True
    # raw should be unchanged (no redaction needed)
    assert result.message.raw == msg.raw


# ── tools/call server→client responses ─────────────────────────────


def test_intercept_server_response_redact(redact_email_policy_file: str) -> None:
    """tools/call response with email + redact policy → result redacted."""
    interceptor = Interceptor("test-server", policy_file=redact_email_policy_file)
    # First track the request
    req = _make_request("tools/call", {"name": "query"}, msg_id=10)
    interceptor.intercept_client_message(req)
    # Then process the response
    resp = _make_response({"data": "Contact john@test.com for details"}, msg_id=10)
    result = interceptor.intercept_server_message(resp)
    assert result.should_forward is True
    output = json.loads(result.message.raw)
    assert "[REDACTED:pii_email]" in json.dumps(output)
    assert "john@test.com" not in json.dumps(output)


def test_intercept_server_response_never_blocks(block_ssn_policy_file: str) -> None:
    """tools/call response with SSN + block policy → NOT blocked, downgraded to redact."""
    interceptor = Interceptor("test-server", policy_file=block_ssn_policy_file)
    req = _make_request("tools/call", {"name": "query"}, msg_id=20)
    interceptor.intercept_client_message(req)
    resp = _make_response({"data": "SSN: 123-45-6789"}, msg_id=20)
    result = interceptor.intercept_server_message(resp)
    # Should NOT be blocked — server already executed
    assert result.should_forward is True
    assert result.response_override is None
    # Should be redacted instead
    output = json.loads(result.message.raw)
    assert "123-45-6789" not in json.dumps(output)
    assert "[REDACTED:pii_ssn]" in json.dumps(output)


# ── sampling/createMessage ──────────────────────────────────────────


def test_intercept_sampling_create_message_block(block_ssn_policy_file: str) -> None:
    """sampling/createMessage with SSN in params → blocked before server."""
    interceptor = Interceptor("test-server", policy_file=block_ssn_policy_file)
    msg = _make_request(
        "sampling/createMessage",
        {"messages": [{"role": "user", "content": {"type": "text", "text": "SSN is 123-45-6789"}}]},
    )
    result = interceptor.intercept_client_message(msg)
    assert result.should_forward is False
    assert result.response_override is not None
    parsed = json.loads(result.response_override)
    assert "Vloex" in parsed["error"]["message"]


def test_intercept_sampling_create_message_redact(redact_email_policy_file: str) -> None:
    """sampling/createMessage with email → content redacted."""
    interceptor = Interceptor("test-server", policy_file=redact_email_policy_file)
    msg = _make_request(
        "sampling/createMessage",
        {"messages": [{"role": "user", "content": {"type": "text", "text": "Email: a@b.com"}}]},
    )
    result = interceptor.intercept_client_message(msg)
    assert result.should_forward is True
    output = json.loads(result.message.raw)
    text_out = output["params"]["messages"][0]["content"]["text"]
    assert "[REDACTED:pii_email]" in text_out
    assert "a@b.com" not in text_out


def test_intercept_sampling_response_scan(redact_email_policy_file: str) -> None:
    """sampling/createMessage response content → scanned and redacted."""
    interceptor = Interceptor("test-server", policy_file=redact_email_policy_file)
    req = _make_request("sampling/createMessage", {"messages": []}, msg_id=30)
    interceptor.intercept_client_message(req)
    resp = _make_response(
        {"role": "assistant", "content": {"type": "text", "text": "Found: admin@corp.com"}},
        msg_id=30,
    )
    result = interceptor.intercept_server_message(resp)
    assert result.should_forward is True
    output = json.loads(result.message.raw)
    assert "admin@corp.com" not in json.dumps(output)
    assert "[REDACTED:pii_email]" in json.dumps(output)


# ── resources/read ──────────────────────────────────────────────────


def test_intercept_resources_read_response_redact(redact_email_policy_file: str) -> None:
    """resources/read response with email → redacted."""
    interceptor = Interceptor("test-server", policy_file=redact_email_policy_file)
    req = _make_request("resources/read", {"uri": "file:///etc/passwd"}, msg_id=40)
    interceptor.intercept_client_message(req)
    resp = _make_response(
        {"contents": [{"uri": "file:///etc/passwd", "text": "user: admin@corp.com"}]},
        msg_id=40,
    )
    result = interceptor.intercept_server_message(resp)
    assert result.should_forward is True
    output = json.loads(result.message.raw)
    text_out = output["result"]["contents"][0]["text"]
    assert "admin@corp.com" not in text_out
    assert "[REDACTED:pii_email]" in text_out


def test_intercept_resources_read_response_never_blocks(block_ssn_policy_file: str) -> None:
    """resources/read response with SSN + block policy → NOT blocked, redacted."""
    interceptor = Interceptor("test-server", policy_file=block_ssn_policy_file)
    req = _make_request("resources/read", {"uri": "file:///data"}, msg_id=50)
    interceptor.intercept_client_message(req)
    resp = _make_response(
        {"contents": [{"uri": "file:///data", "text": "SSN: 123-45-6789"}]},
        msg_id=50,
    )
    result = interceptor.intercept_server_message(resp)
    # Never blocked — read already happened
    assert result.should_forward is True
    assert result.response_override is None
    output = json.loads(result.message.raw)
    assert "123-45-6789" not in json.dumps(output)
    assert "[REDACTED:pii_ssn]" in json.dumps(output)


# ── Department-scoped policy evaluation ────────────────────────────


def test_interceptor_passes_department_to_evaluate(tmp_path) -> None:
    """set_department should cause policy engine to receive department in evaluate()."""
    # Policy that only blocks SSN for Engineering department
    policy = {
        "policies": [
            {
                "id": "dept_001",
                "name": "Block SSN for Engineering",
                "enabled": True,
                "mode": "enforced",
                "action": "block",
                "conditions": [
                    {"field": "sensitive_data_types", "operator": "contains", "value": "pii_ssn"}
                ],
                "scope": {"departments": ["Engineering"]},
            }
        ],
        "custom_patterns": [],
    }
    path = tmp_path / "dept_policy.json"
    path.write_text(json.dumps(policy))

    interceptor = Interceptor("test-server", policy_file=str(path))
    interceptor.set_department("Engineering")

    msg = _make_request(
        "tools/call",
        {"name": "query_db", "arguments": {"sql": "SSN is 123-45-6789"}},
    )
    result = interceptor.intercept_client_message(msg)
    # Engineering department matches → blocked
    assert result.should_forward is False
    assert result.policy_action == "block"


def test_interceptor_department_scope_no_match(tmp_path) -> None:
    """Department-scoped policy should not match when department differs."""
    policy = {
        "policies": [
            {
                "id": "dept_002",
                "name": "Block SSN for Engineering only",
                "enabled": True,
                "mode": "enforced",
                "action": "block",
                "conditions": [
                    {"field": "sensitive_data_types", "operator": "contains", "value": "pii_ssn"}
                ],
                "scope": {"departments": ["Engineering"]},
            }
        ],
        "custom_patterns": [],
    }
    path = tmp_path / "dept_policy2.json"
    path.write_text(json.dumps(policy))

    interceptor = Interceptor("test-server", policy_file=str(path))
    interceptor.set_department("Marketing")

    msg = _make_request(
        "tools/call",
        {"name": "query_db", "arguments": {"sql": "SSN is 123-45-6789"}},
    )
    result = interceptor.intercept_client_message(msg)
    # Marketing department does NOT match Engineering scope → allowed
    assert result.should_forward is True
    assert result.policy_action == "allow"
