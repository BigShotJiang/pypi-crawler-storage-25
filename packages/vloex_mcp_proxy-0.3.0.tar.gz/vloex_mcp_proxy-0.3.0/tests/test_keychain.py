"""Tests for keychain abstraction (Item 9).

All tests mock keyring — never import the real keyring library.
"""

from __future__ import annotations

import types
from unittest.mock import MagicMock, patch

from vloex_mcp_proxy.backend.keychain import (
    _SERVICE_NAME,
    delete_credential,
    load_credential,
    store_credential,
)


def _make_mock_keyring() -> types.ModuleType:
    """Create a mock keyring module with common methods."""
    mock = types.ModuleType("keyring")
    mock.set_password = MagicMock()
    mock.get_password = MagicMock(return_value=None)
    mock.delete_password = MagicMock()
    return mock


class TestStoreCredential:
    """Tests for store_credential()."""

    def test_stores_in_keychain_when_available(self) -> None:
        """With keyring available, stores via keyring.set_password."""
        mock_keyring = _make_mock_keyring()

        with patch.dict("sys.modules", {"keyring": mock_keyring}):
            result = store_credential("device_token", "jwt-abc-123")

        assert result is True
        mock_keyring.set_password.assert_called_once_with(
            _SERVICE_NAME, "device_token", "jwt-abc-123"
        )

    def test_falls_back_to_file_when_keyring_unavailable(self, tmp_path) -> None:
        """Without keyring, falls back to file storage."""
        with patch("vloex_mcp_proxy.backend.keychain._keyring_available", return_value=False):
            result = store_credential("device_token", "jwt-abc-123", vloex_dir=tmp_path)

        assert result is True
        token_file = tmp_path / "device_token"
        assert token_file.exists()
        assert token_file.read_text() == "jwt-abc-123"

    def test_removes_file_after_keychain_store(self, tmp_path) -> None:
        """After storing in keychain, removes existing file copy (migration)."""
        # Pre-create file
        token_file = tmp_path / "device_token"
        token_file.write_text("old-token")

        mock_keyring = _make_mock_keyring()
        with patch.dict("sys.modules", {"keyring": mock_keyring}):
            result = store_credential("device_token", "new-token", vloex_dir=tmp_path)

        assert result is True
        assert not token_file.exists()

    def test_file_fallback_returns_false_without_vloex_dir(self) -> None:
        """No vloex_dir and no keyring: returns False."""
        with patch("vloex_mcp_proxy.backend.keychain._keyring_available", return_value=False):
            result = store_credential("device_token", "jwt-abc")

        assert result is False

    def test_falls_back_to_file_on_keyring_exception(self, tmp_path) -> None:
        """Keyring raises exception: falls back to file."""
        mock_keyring = _make_mock_keyring()
        mock_keyring.set_password.side_effect = Exception("keychain locked")

        with patch.dict("sys.modules", {"keyring": mock_keyring}):
            result = store_credential("device_token", "jwt-abc", vloex_dir=tmp_path)

        assert result is True
        assert (tmp_path / "device_token").read_text() == "jwt-abc"


class TestLoadCredential:
    """Tests for load_credential()."""

    def test_loads_from_keychain_when_available(self) -> None:
        """With keyring available, loads via keyring.get_password."""
        mock_keyring = _make_mock_keyring()
        mock_keyring.get_password.return_value = "stored-jwt"

        with patch.dict("sys.modules", {"keyring": mock_keyring}):
            result = load_credential("device_token")

        assert result == "stored-jwt"
        mock_keyring.get_password.assert_called_once_with(_SERVICE_NAME, "device_token")

    def test_falls_back_to_file_when_keyring_empty(self, tmp_path) -> None:
        """Keyring returns None, file exists: reads from file."""
        token_file = tmp_path / "device_token"
        token_file.write_text("file-jwt")

        mock_keyring = _make_mock_keyring()
        mock_keyring.get_password.return_value = None

        with patch.dict("sys.modules", {"keyring": mock_keyring}):
            result = load_credential("device_token", vloex_dir=tmp_path)

        assert result == "file-jwt"

    def test_auto_migrates_from_file_to_keychain(self, tmp_path) -> None:
        """File exists + keyring available + keyring empty: migrates to keychain, deletes file."""
        token_file = tmp_path / "device_token"
        token_file.write_text("migrate-me")

        mock_keyring = _make_mock_keyring()
        mock_keyring.get_password.return_value = None  # Not in keychain yet

        with patch.dict("sys.modules", {"keyring": mock_keyring}):
            result = load_credential("device_token", vloex_dir=tmp_path)

        assert result == "migrate-me"
        mock_keyring.set_password.assert_called_once_with(
            _SERVICE_NAME, "device_token", "migrate-me"
        )
        assert not token_file.exists()

    def test_returns_none_when_nothing_available(self, tmp_path) -> None:
        """No keyring, no file: returns None."""
        with patch("vloex_mcp_proxy.backend.keychain._keyring_available", return_value=False):
            result = load_credential("device_token", vloex_dir=tmp_path)

        assert result is None

    def test_keyring_load_exception_falls_back_to_file(self, tmp_path) -> None:
        """Keyring raises exception: falls back to file."""
        token_file = tmp_path / "device_token"
        token_file.write_text("fallback-jwt")

        mock_keyring = _make_mock_keyring()
        mock_keyring.get_password.side_effect = Exception("keychain error")

        with patch.dict("sys.modules", {"keyring": mock_keyring}):
            result = load_credential("device_token", vloex_dir=tmp_path)

        assert result == "fallback-jwt"


class TestDeleteCredential:
    """Tests for delete_credential()."""

    def test_deletes_from_both_keychain_and_file(self, tmp_path) -> None:
        """Deletes from keychain and file when both exist."""
        token_file = tmp_path / "device_token"
        token_file.write_text("to-delete")

        mock_keyring = _make_mock_keyring()

        with patch.dict("sys.modules", {"keyring": mock_keyring}):
            result = delete_credential("device_token", vloex_dir=tmp_path)

        assert result is True
        mock_keyring.delete_password.assert_called_once_with(_SERVICE_NAME, "device_token")
        assert not token_file.exists()

    def test_returns_false_when_nothing_to_delete(self, tmp_path) -> None:
        """No keyring, no file: returns False."""
        with patch("vloex_mcp_proxy.backend.keychain._keyring_available", return_value=False):
            result = delete_credential("device_token", vloex_dir=tmp_path)

        assert result is False
