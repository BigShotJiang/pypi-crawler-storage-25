"""Tests for policy action handlers — block, redact, warn."""

from __future__ import annotations

import json

from vloex_mcp_proxy.policy.actions import (
    execute_block,
    execute_redact,
    redact_tool_arguments,
    redact_tool_result,
)
from vloex_mcp_proxy.policy.engine import PolicyAction, PolicyResult
from vloex_mcp_proxy.scanner.sensitive import Detection, SensitiveDataType


def _det(dtype: SensitiveDataType) -> Detection:
    return Detection(data_type=dtype, confidence=1.0, count=1)


# ── Block tests ────────────────────────────────────────────────────


def test_block_error_format() -> None:
    """Block returns valid JSON-RPC error with 'Vloex:' prefix."""
    result = PolicyResult(
        action=PolicyAction.BLOCK,
        policy_id="p1",
        policy_name="Test Policy",
        message="Policy 'Test Policy' triggered: block. Contact admin.",
        detections=[_det(SensitiveDataType.PII_SSN)],
    )
    raw = execute_block(42, result)
    assert raw.endswith(b"\n")
    parsed = json.loads(raw)
    assert parsed["jsonrpc"] == "2.0"
    assert parsed["id"] == 42
    assert parsed["error"]["code"] == -32600
    assert parsed["error"]["message"].startswith("Vloex:")


def test_block_error_includes_detection_types() -> None:
    """Block error message mentions 'pii_ssn'."""
    result = PolicyResult(
        action=PolicyAction.BLOCK,
        policy_id="p1",
        policy_name="Block SSN",
        detections=[_det(SensitiveDataType.PII_SSN)],
    )
    raw = execute_block(1, result)
    parsed = json.loads(raw)
    assert "pii_ssn" in parsed["error"]["message"]


def test_block_error_includes_policy_name() -> None:
    """Block error message mentions the policy name."""
    result = PolicyResult(
        action=PolicyAction.BLOCK,
        policy_id="p1",
        policy_name="No PII in queries",
        detections=[_det(SensitiveDataType.PII_SSN)],
    )
    raw = execute_block(1, result)
    parsed = json.loads(raw)
    assert "No PII in queries" in parsed["error"]["message"]


def test_block_error_includes_contact() -> None:
    """Block error message includes contact info."""
    result = PolicyResult(
        action=PolicyAction.BLOCK,
        policy_id="p1",
        policy_name="Policy",
        message="Policy 'Policy' triggered: block. Contact IT admin for exceptions.",
        detections=[_det(SensitiveDataType.PII_SSN)],
    )
    raw = execute_block(1, result)
    parsed = json.loads(raw)
    assert "Contact IT admin" in parsed["error"]["message"]


def test_block_error_is_natural_language() -> None:
    """Block error is readable by LLM — no stack traces, no code."""
    result = PolicyResult(
        action=PolicyAction.BLOCK,
        policy_id="p1",
        policy_name="Block SSN",
        detections=[_det(SensitiveDataType.PII_SSN)],
    )
    raw = execute_block(1, result)
    parsed = json.loads(raw)
    msg = parsed["error"]["message"]
    # Should NOT contain code-like patterns
    assert "Traceback" not in msg
    assert "Exception" not in msg
    assert "raise " not in msg
    # Should be readable
    assert "Vloex" in msg
    assert "blocked" in msg.lower()


def test_block_multiple_detection_types() -> None:
    """Block with multiple detections lists all types."""
    result = PolicyResult(
        action=PolicyAction.BLOCK,
        policy_id="p1",
        policy_name="Block PII",
        detections=[_det(SensitiveDataType.PII_SSN), _det(SensitiveDataType.PII_EMAIL)],
    )
    raw = execute_block(1, result)
    parsed = json.loads(raw)
    msg = parsed["error"]["message"]
    assert "pii_ssn" in msg
    assert "pii_email" in msg


# ── Redact tests ───────────────────────────────────────────────────


def test_redact_ssn() -> None:
    """SSN is replaced with [REDACTED:pii_ssn]."""
    result = execute_redact("SSN: 123-45-6789", [_det(SensitiveDataType.PII_SSN)])
    assert "[REDACTED:pii_ssn]" in result
    assert "123-45-6789" not in result


def test_redact_email() -> None:
    """Email is replaced with [REDACTED:pii_email]."""
    result = execute_redact("john@test.com", [_det(SensitiveDataType.PII_EMAIL)])
    assert "[REDACTED:pii_email]" in result
    assert "john@test.com" not in result


def test_redact_nested_dict() -> None:
    """Sensitive data in nested dict is redacted."""
    data = {"a": {"b": "SSN is 123-45-6789"}}
    result = redact_tool_result(data, [_det(SensitiveDataType.PII_SSN)])
    assert "[REDACTED:pii_ssn]" in result["a"]["b"]
    assert "123-45-6789" not in result["a"]["b"]


def test_redact_in_list() -> None:
    """Sensitive data in list is redacted."""
    data = ["SSN is 123-45-6789"]
    result = redact_tool_result(data, [_det(SensitiveDataType.PII_SSN)])
    assert "[REDACTED:pii_ssn]" in result[0]
    assert "123-45-6789" not in result[0]


def test_redact_tool_arguments() -> None:
    """tools/call params dict → arguments redacted, rest preserved."""
    params = {
        "name": "query_db",
        "arguments": {"sql": "SELECT * WHERE ssn='123-45-6789'"},
    }
    result = redact_tool_arguments(params, [_det(SensitiveDataType.PII_SSN)])
    assert result["name"] == "query_db"  # Preserved
    assert "[REDACTED:pii_ssn]" in result["arguments"]["sql"]
    assert "123-45-6789" not in result["arguments"]["sql"]


def test_redact_tool_result_dict() -> None:
    """tools/call result dict → content redacted."""
    result_data = {"content": [{"text": "Email: john@test.com"}]}
    result = redact_tool_result(result_data, [_det(SensitiveDataType.PII_EMAIL)])
    assert "[REDACTED:pii_email]" in result["content"][0]["text"]
    assert "john@test.com" not in result["content"][0]["text"]


def test_redact_does_not_mutate_original() -> None:
    """Original message unchanged after redaction."""
    original = {"sql": "SELECT * WHERE ssn='123-45-6789'"}
    params = {"name": "query", "arguments": original}
    _redacted = redact_tool_arguments(params, [_det(SensitiveDataType.PII_SSN)])
    # Original untouched
    assert "123-45-6789" in original["sql"]


def test_multiple_redactions() -> None:
    """Text with SSN + email → both redacted."""
    text = "SSN: 123-45-6789, email: a@b.com"
    result = execute_redact(
        text,
        [_det(SensitiveDataType.PII_SSN), _det(SensitiveDataType.PII_EMAIL)],
    )
    assert "[REDACTED:pii_ssn]" in result
    assert "[REDACTED:pii_email]" in result
    assert "123-45-6789" not in result
    assert "a@b.com" not in result
