"""Tests for the message interceptor."""

from __future__ import annotations

import json

from vloex_mcp_proxy.proxy.interceptor import (
    INTERCEPTED_METHODS,
    Interceptor,
)
from vloex_mcp_proxy.proxy.jsonrpc import MessageType, parse_message


def _make_request(method: str, msg_id: int | str, params: dict | None = None) -> bytes:
    """Helper to create a JSON-RPC request as bytes."""
    obj: dict = {"jsonrpc": "2.0", "method": method, "id": msg_id}
    if params is not None:
        obj["params"] = params
    return json.dumps(obj).encode() + b"\n"


def _make_response(msg_id: int | str, result: object = None) -> bytes:
    """Helper to create a JSON-RPC response as bytes."""
    return json.dumps({"jsonrpc": "2.0", "result": result, "id": msg_id}).encode() + b"\n"


def _make_notification(method: str) -> bytes:
    """Helper to create a JSON-RPC notification as bytes."""
    return json.dumps({"jsonrpc": "2.0", "method": method}).encode() + b"\n"


def test_intercept_tools_call() -> None:
    """tools/call request -> intercepted=True, should_forward=True."""
    interceptor = Interceptor("test-server")
    msg = parse_message(_make_request("tools/call", 1, {"name": "read_file"}))
    result = interceptor.intercept_client_message(msg)

    assert result.intercepted is True
    assert result.should_forward is True
    assert result.method == "tools/call"
    assert result.response_override is None


def test_intercept_tools_list() -> None:
    """tools/list request -> intercepted=True."""
    interceptor = Interceptor("test-server")
    msg = parse_message(_make_request("tools/list", 2))
    result = interceptor.intercept_client_message(msg)

    assert result.intercepted is True
    assert result.method == "tools/list"


def test_intercept_initialize() -> None:
    """initialize request -> intercepted=True."""
    interceptor = Interceptor("test-server")
    msg = parse_message(_make_request("initialize", 3))
    result = interceptor.intercept_client_message(msg)

    assert result.intercepted is True
    assert result.method == "initialize"


def test_passthrough_unknown_method() -> None:
    """Unknown method -> intercepted=False, should_forward=True."""
    interceptor = Interceptor("test-server")
    msg = parse_message(_make_request("some/unknown/method", 4))
    result = interceptor.intercept_client_message(msg)

    assert result.intercepted is False
    assert result.should_forward is True
    assert result.method is None


def test_correlation_request_response() -> None:
    """Send request id=42, then response id=42 -> response correlated to method."""
    interceptor = Interceptor("test-server")

    # Client sends tools/call with id=42
    request = parse_message(_make_request("tools/call", 42, {"name": "test"}))
    req_result = interceptor.intercept_client_message(request)
    assert req_result.intercepted is True

    # Server responds with id=42
    response = parse_message(_make_response(42, {"content": "test result"}))
    resp_result = interceptor.intercept_server_message(response)
    assert resp_result.intercepted is True
    assert resp_result.method == "tools/call"


def test_notification_not_tracked() -> None:
    """Notification (no id) -> not added to pending requests."""
    interceptor = Interceptor("test-server")

    # Send an initialized notification (intercepted method, but no id)
    notification = parse_message(_make_notification("initialized"))
    result = interceptor.intercept_client_message(notification)
    assert result.intercepted is True
    assert result.method == "initialized"

    # Verify _pending_requests is empty
    assert len(interceptor._pending_requests) == 0


def test_invalid_message_passthrough() -> None:
    """INVALID message -> should_forward=True, intercepted=False."""
    interceptor = Interceptor("test-server")
    msg = parse_message(b"this is not json\n")
    assert msg.msg_type == MessageType.INVALID

    result = interceptor.intercept_client_message(msg)
    assert result.intercepted is False
    assert result.should_forward is True


def test_batch_interception() -> None:
    """Batch with mixed methods -> each sub-message checked individually."""
    interceptor = Interceptor("test-server")

    batch_data = (
        json.dumps(
            [
                {"jsonrpc": "2.0", "method": "tools/list", "id": 1},
                {"jsonrpc": "2.0", "method": "some/other", "id": 2},
                {"jsonrpc": "2.0", "method": "tools/call", "params": {"name": "test"}, "id": 3},
            ]
        ).encode()
        + b"\n"
    )

    msg = parse_message(batch_data)
    assert msg.msg_type == MessageType.BATCH

    result = interceptor.intercept_client_message(msg)
    assert result.intercepted is True
    assert result.should_forward is True
    # Both intercepted methods should be in the comma-separated list
    assert "tools/list" in result.method
    assert "tools/call" in result.method


def test_response_correlation_removes_from_pending() -> None:
    """After correlating a response, the ID is removed from pending requests."""
    interceptor = Interceptor("test-server")

    # Track a request
    request = parse_message(_make_request("tools/call", 99))
    interceptor.intercept_client_message(request)
    assert 99 in interceptor._pending_requests

    # Correlate the response
    response = parse_message(_make_response(99, {}))
    interceptor.intercept_server_message(response)
    assert 99 not in interceptor._pending_requests


def test_uncorrelated_response_passthrough() -> None:
    """Response with unknown id -> not intercepted, passed through."""
    interceptor = Interceptor("test-server")

    response = parse_message(_make_response(999, {"data": "something"}))
    result = interceptor.intercept_server_message(response)
    assert result.intercepted is False
    assert result.should_forward is True


def test_all_intercepted_methods_recognized() -> None:
    """All methods in INTERCEPTED_METHODS are properly intercepted."""
    interceptor = Interceptor("test-server")

    for i, method in enumerate(sorted(INTERCEPTED_METHODS)):
        msg = parse_message(_make_request(method, i + 100))
        result = interceptor.intercept_client_message(msg)
        assert result.intercepted is True, f"Method {method} was not intercepted"
        assert result.method == method


def test_pending_requests_eviction() -> None:
    """Pending requests map evicts stale entries and respects max size."""
    from vloex_mcp_proxy.proxy.interceptor import _MAX_PENDING_REQUESTS

    interceptor = Interceptor("test-server")

    # Fill up to the max
    for i in range(_MAX_PENDING_REQUESTS):
        msg = parse_message(_make_request("tools/call", i))
        interceptor.intercept_client_message(msg)

    assert len(interceptor._pending_requests) == _MAX_PENDING_REQUESTS

    # Adding one more should trigger eviction (oldest gets dropped)
    msg = parse_message(_make_request("tools/call", _MAX_PENDING_REQUESTS + 1))
    interceptor.intercept_client_message(msg)
    assert len(interceptor._pending_requests) <= _MAX_PENDING_REQUESTS

    # The newest one should be present
    assert (_MAX_PENDING_REQUESTS + 1) in interceptor._pending_requests


def test_string_id_correlation() -> None:
    """Request/response correlation works with string IDs."""
    interceptor = Interceptor("test-server")

    request = parse_message(_make_request("tools/call", "req-abc-123"))
    interceptor.intercept_client_message(request)
    assert "req-abc-123" in interceptor._pending_requests

    response = parse_message(_make_response("req-abc-123", {"ok": True}))
    resp_result = interceptor.intercept_server_message(response)
    assert resp_result.intercepted is True
    assert resp_result.method == "tools/call"
