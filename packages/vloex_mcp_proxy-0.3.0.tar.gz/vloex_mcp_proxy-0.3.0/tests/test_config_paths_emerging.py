"""Tests for emerging agent config path entries (Item 10)."""

from __future__ import annotations

from vloex_mcp_proxy.discovery.config_paths import get_known_clients

# The 5 new emerging agent entries
_EMERGING_NAMES = {
    "Perplexity",
    "Devin",
    "Roo Code",
    "Augment Code",
    "GitHub Copilot (agent mode)",
}


def test_emerging_agents_returned_for_macos() -> None:
    """New entries with platform='all' or 'macos' returned for macOS."""
    clients = get_known_clients(platform="macos")
    names = {c.name for c in clients}
    # All-platform entries
    for name in ("Perplexity", "Devin", "Augment Code"):
        assert name in names, f"{name} not found in macos client list"
    # macOS-specific entries
    assert "Roo Code" in names
    assert "GitHub Copilot (agent mode)" in names


def test_emerging_agents_returned_for_linux() -> None:
    """New entries with platform='all' returned for Linux."""
    clients = get_known_clients(platform="linux")
    names = {c.name for c in clients}
    for name in ("Perplexity", "Devin", "Augment Code"):
        assert name in names, f"{name} not found in linux client list"


def test_emerging_agents_returned_for_windows() -> None:
    """New entries with platform='all' returned for Windows."""
    clients = get_known_clients(platform="windows")
    names = {c.name for c in clients}
    for name in ("Perplexity", "Devin", "Augment Code"):
        assert name in names, f"{name} not found in windows client list"


def test_macos_only_not_in_linux() -> None:
    """macOS-only entries should not appear on Linux."""
    clients = get_known_clients(platform="linux")
    names_plats = [(c.name, c.platform) for c in clients]
    # Roo Code and GitHub Copilot (agent mode) are macOS-only
    for name, plat in names_plats:
        if name == "Roo Code":
            assert plat in ("all", "linux"), "Roo Code shouldn't appear on linux"
        if name == "GitHub Copilot (agent mode)":
            assert plat in ("all", "linux"), "GitHub Copilot (agent mode) shouldn't appear on linux"

    linux_names = {c.name for c in clients}
    assert "Roo Code" not in linux_names
    assert "GitHub Copilot (agent mode)" not in linux_names


def test_no_duplicate_name_platform_pairs() -> None:
    """No duplicate (name, platform) pairs in the full registry."""
    # Check across all platforms
    for plat in ("macos", "linux", "windows"):
        clients = get_known_clients(platform=plat)
        pairs = [(c.name, c.platform) for c in clients]
        seen = set()
        for pair in pairs:
            assert pair not in seen, f"Duplicate (name, platform) pair: {pair} on {plat}"
            seen.add(pair)


def test_all_new_entries_unverified() -> None:
    """All emerging agent entries have verified=False."""
    all_clients = get_known_clients(platform="macos")
    all_clients += get_known_clients(platform="linux")
    all_clients += get_known_clients(platform="windows")

    for client in all_clients:
        if client.name in _EMERGING_NAMES:
            assert client.verified is False, (
                f"{client.name} (platform={client.platform}) should be unverified"
            )
