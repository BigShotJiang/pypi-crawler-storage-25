"""Tests for process discovery — list return, binary resolution."""

import os
import shutil

from vloex_mcp_proxy.discovery.process import (
    ProcessInfo,
    discover_processes,
    discover_workspace_roots,
    resolve_binary_path,
)


class TestDiscoverProcesses:
    def test_returns_list(self):
        """discover_processes() should return a list (possibly empty without psutil)."""
        result = discover_processes()
        assert isinstance(result, list)

    def test_excludes_own_process(self):
        """Should not include the current process."""
        result = discover_processes()
        own_pid = os.getpid()
        assert all(p.pid != own_pid for p in result)

    def test_process_info_fields(self):
        """ProcessInfo dataclass should have expected fields."""
        info = ProcessInfo(pid=1, name="test", cmdline=["test"], is_client=True)
        assert info.pid == 1
        assert info.is_client is True
        assert info.is_server is False
        assert info.cwd is None


class TestDiscoverWorkspaceRoots:
    def test_returns_sorted_list(self):
        """discover_workspace_roots() should return a sorted list."""
        result = discover_workspace_roots()
        assert isinstance(result, list)
        assert result == sorted(result)


class TestResolveBinaryPath:
    def test_resolves_known_command(self):
        """Should resolve 'python3' or 'python' to a path."""
        for cmd in ("python3", "python"):
            if shutil.which(cmd):
                result = resolve_binary_path(cmd)
                assert result is not None
                assert os.path.isabs(result)
                break

    def test_nonexistent_returns_none(self):
        result = resolve_binary_path("definitely-not-a-real-binary-xyz123")
        assert result is None

    def test_wrapper_prefix_resolution(self):
        """Should resolve wrapper commands like 'npx some-package'."""
        if shutil.which("python3"):
            result = resolve_binary_path("python3 -m some_module")
            assert result is not None

    def test_absolute_path_existing(self, tmp_path):
        """Should return absolute path if file exists."""
        binary = tmp_path / "server"
        binary.write_bytes(b"#!/bin/sh\necho hi")
        result = resolve_binary_path(str(binary))
        assert result == str(binary)

    def test_absolute_path_nonexistent(self):
        result = resolve_binary_path("/nonexistent/path/to/binary")
        assert result is None
