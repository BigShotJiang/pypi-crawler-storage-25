"""Tests for CLI argument parsing."""

from __future__ import annotations

import json
from unittest.mock import patch

import pytest

from vloex_mcp_proxy.cli import main


def test_version_flag() -> None:
    """--version prints version and exits."""
    with pytest.raises(SystemExit) as exc_info:
        with patch("sys.argv", ["vloex-mcp-proxy", "--version"]):
            main()
    assert exc_info.value.code == 0


def test_missing_server_command() -> None:
    """Missing --server-command exits with error."""
    with pytest.raises(SystemExit) as exc_info:
        with patch("sys.argv", ["vloex-mcp-proxy"]):
            main()
    assert exc_info.value.code == 2  # argparse exits with 2


def _parse_server_args(raw: str) -> list[str]:
    """Replicate the arg parsing logic from cli.py for testing."""
    if raw and raw.startswith("["):
        try:
            parsed_args = json.loads(raw)
            return [str(a) for a in parsed_args] if isinstance(parsed_args, list) else []
        except json.JSONDecodeError:
            return [a for a in raw.split(",") if a]
    return [a for a in raw.split(",") if a] if raw else []


def _get_server_name(command: str, explicit_name: str | None) -> str:
    """Replicate the server name defaulting logic from cli.py."""
    return explicit_name or command.rsplit("/", 1)[-1]


def test_comma_separated_args() -> None:
    """Comma-separated --server-args are split correctly."""
    result = _parse_server_args("-y,@mcp/server-filesystem,/tmp")
    assert result == ["-y", "@mcp/server-filesystem", "/tmp"]


def test_json_array_args() -> None:
    """JSON array --server-args are parsed correctly."""
    args_json = json.dumps(["-y", "@mcp/server-filesystem", "/tmp"])
    result = _parse_server_args(args_json)
    assert result == ["-y", "@mcp/server-filesystem", "/tmp"]


def test_json_array_with_commas() -> None:
    """JSON array args containing commas are preserved correctly."""
    args_json = json.dumps(["--config", "a,b,c", "/tmp"])
    result = _parse_server_args(args_json)
    assert result == ["--config", "a,b,c", "/tmp"]


def test_malformed_json_falls_back_to_comma_split() -> None:
    """Malformed JSON starting with [ falls back to comma split."""
    result = _parse_server_args("[broken,json")
    assert result == ["[broken", "json"]


def test_empty_args() -> None:
    """Empty --server-args produces empty list."""
    assert _parse_server_args("") == []


def test_single_arg() -> None:
    """Single arg without commas works."""
    assert _parse_server_args("server.js") == ["server.js"]


def test_server_name_defaults_to_command_basename() -> None:
    """--server-name defaults to basename of --server-command."""
    assert _get_server_name("/usr/local/bin/npx", None) == "npx"


def test_server_name_simple_command() -> None:
    """Simple command without path uses the command itself."""
    assert _get_server_name("npx", None) == "npx"


def test_server_name_explicit() -> None:
    """Explicit --server-name is used as-is."""
    assert _get_server_name("npx", "my-mcp-server") == "my-mcp-server"
