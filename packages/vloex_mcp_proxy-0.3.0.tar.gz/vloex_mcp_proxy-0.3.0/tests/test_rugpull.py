"""Tests for rug-pull detection — severity mapping, multi-change, binary changes."""

from pathlib import Path

from vloex_mcp_proxy.security.inventory import ChangeType, ServerInventory
from vloex_mcp_proxy.security.rugpull import RugPullDetector, Severity


def _make_tool(name: str, description: str = "A tool", schema: dict | None = None) -> dict:
    return {
        "name": name,
        "description": description,
        "inputSchema": schema or {"type": "object"},
    }


class TestRugPullDetector:
    def test_new_tool_info_severity(self, tmp_path: Path):
        inv = ServerInventory(tmp_path / "inv.json")
        det = RugPullDetector(inv)
        alerts = det.check_tools_list("s", [_make_tool("read")])
        assert len(alerts) == 1
        assert alerts[0].severity == Severity.INFO
        assert alerts[0].change_type == ChangeType.TOOL_ADDED

    def test_removed_tool_warning_severity(self, tmp_path: Path):
        inv = ServerInventory(tmp_path / "inv.json")
        det = RugPullDetector(inv)
        det.check_tools_list("s", [_make_tool("a"), _make_tool("b")])
        alerts = det.check_tools_list("s", [_make_tool("a")])
        removed = [a for a in alerts if a.change_type == ChangeType.TOOL_REMOVED]
        assert len(removed) == 1
        assert removed[0].severity == Severity.WARNING

    def test_description_changed_high_severity(self, tmp_path: Path):
        inv = ServerInventory(tmp_path / "inv.json")
        det = RugPullDetector(inv)
        det.check_tools_list("s", [_make_tool("read", "Read a file")])
        alerts = det.check_tools_list("s", [_make_tool("read", "Read a file MODIFIED")])
        assert len(alerts) == 1
        assert alerts[0].severity == Severity.HIGH
        assert alerts[0].change_type == ChangeType.TOOL_DESCRIPTION_CHANGED

    def test_binary_changed_critical_severity(self, tmp_path: Path):
        inv = ServerInventory(tmp_path / "inv.json")
        det = RugPullDetector(inv)
        binary = tmp_path / "server.bin"
        binary.write_bytes(b"v1")
        det.check_binary("s", str(binary))
        binary.write_bytes(b"v2")
        alerts = det.check_binary("s", str(binary))
        assert len(alerts) == 1
        assert alerts[0].severity == Severity.CRITICAL
        assert alerts[0].change_type == ChangeType.BINARY_CHANGED

    def test_schema_changed_warning_severity(self, tmp_path: Path):
        inv = ServerInventory(tmp_path / "inv.json")
        det = RugPullDetector(inv)
        det.check_tools_list("s", [_make_tool("r", "d", {"type": "object"})])
        alerts = det.check_tools_list("s", [_make_tool("r", "d", {"type": "string"})])
        assert len(alerts) == 1
        assert alerts[0].severity == Severity.WARNING
        assert alerts[0].change_type == ChangeType.TOOL_SCHEMA_CHANGED

    def test_no_change_no_alerts(self, tmp_path: Path):
        inv = ServerInventory(tmp_path / "inv.json")
        det = RugPullDetector(inv)
        tools = [_make_tool("read")]
        det.check_tools_list("s", tools)
        alerts = det.check_tools_list("s", tools)
        assert alerts == []

    def test_multi_change_multiple_alerts(self, tmp_path: Path):
        inv = ServerInventory(tmp_path / "inv.json")
        det = RugPullDetector(inv)
        det.check_tools_list("s", [_make_tool("a", "old"), _make_tool("b")])
        alerts = det.check_tools_list("s", [_make_tool("a", "new"), _make_tool("c")])
        # a: description changed, b: removed, c: added
        assert len(alerts) == 3
        types = {a.change_type for a in alerts}
        assert ChangeType.TOOL_DESCRIPTION_CHANGED in types
        assert ChangeType.TOOL_REMOVED in types
        assert ChangeType.TOOL_ADDED in types

    def test_schema_only_change(self, tmp_path: Path):
        """Schema change without description change should only produce schema alert."""
        inv = ServerInventory(tmp_path / "inv.json")
        det = RugPullDetector(inv)
        det.check_tools_list("s", [_make_tool("r", "same desc", {"type": "object"})])
        alerts = det.check_tools_list("s", [_make_tool("r", "same desc", {"type": "string"})])
        assert len(alerts) == 1
        assert alerts[0].change_type == ChangeType.TOOL_SCHEMA_CHANGED

    def test_alert_contains_server_name(self, tmp_path: Path):
        inv = ServerInventory(tmp_path / "inv.json")
        det = RugPullDetector(inv)
        alerts = det.check_tools_list("my-server", [_make_tool("t")])
        assert alerts[0].server_name == "my-server"

    def test_alert_contains_tool_name(self, tmp_path: Path):
        inv = ServerInventory(tmp_path / "inv.json")
        det = RugPullDetector(inv)
        alerts = det.check_tools_list("s", [_make_tool("special_tool")])
        assert alerts[0].tool_name == "special_tool"

    def test_binary_no_change(self, tmp_path: Path):
        inv = ServerInventory(tmp_path / "inv.json")
        det = RugPullDetector(inv)
        binary = tmp_path / "server.bin"
        binary.write_bytes(b"content")
        det.check_binary("s", str(binary))
        alerts = det.check_binary("s", str(binary))
        assert alerts == []
