"""Tests for enterprise configuration loading."""

from __future__ import annotations

import json
from pathlib import Path

from vloex_mcp_proxy.packaging.enterprise_config import (
    EnterpriseConfig,
    get_enterprise_config_path,
    load_enterprise_config,
)


class TestEnterpriseConfig:
    """Tests for the EnterpriseConfig dataclass."""

    def test_defaults(self) -> None:
        cfg = EnterpriseConfig()
        assert cfg.backend_url == ""
        assert cfg.enrollment_token == ""
        assert cfg.auto_discover is True
        assert cfg.auto_rewrite is True
        assert cfg.log_level == "INFO"
        assert cfg.event_queue_max_size_mb == 50
        assert cfg.heartbeat_interval_seconds == 30

    def test_is_configured_false_by_default(self) -> None:
        cfg = EnterpriseConfig()
        assert cfg.is_configured is False

    def test_is_configured_false_with_empty_token(self) -> None:
        cfg = EnterpriseConfig(enrollment_token="")
        assert cfg.is_configured is False

    def test_is_configured_true_with_token(self) -> None:
        cfg = EnterpriseConfig(enrollment_token="abc123")
        assert cfg.is_configured is True

    def test_full_config(self) -> None:
        cfg = EnterpriseConfig(
            backend_url="https://api.vloex.com",
            enrollment_token="tok_abc",
            auto_discover=False,
            auto_rewrite=False,
            log_level="DEBUG",
            event_queue_max_size_mb=100,
            heartbeat_interval_seconds=60,
        )
        assert cfg.backend_url == "https://api.vloex.com"
        assert cfg.enrollment_token == "tok_abc"
        assert cfg.auto_discover is False
        assert cfg.log_level == "DEBUG"
        assert cfg.event_queue_max_size_mb == 100
        assert cfg.heartbeat_interval_seconds == 60
        assert cfg.is_configured is True


class TestPlatformPaths:
    """Tests for platform-specific config paths."""

    def test_known_platforms(self) -> None:
        path = get_enterprise_config_path()
        assert path.name == "config.json"
        # On macOS/Linux, should be /etc/vloex/config.json
        # On Windows, C:/ProgramData/Vloex/config.json
        assert "vloex" in str(path).lower() or "Vloex" in str(path)

    def test_path_is_absolute(self) -> None:
        path = get_enterprise_config_path()
        assert path.is_absolute()


class TestLoadEnterprise:
    """Tests for loading enterprise config from disk."""

    def test_missing_file_returns_defaults(self, tmp_path: Path) -> None:
        cfg = load_enterprise_config(tmp_path / "nonexistent.json")
        assert cfg == EnterpriseConfig()

    def test_empty_json_returns_defaults(self, tmp_path: Path) -> None:
        config_file = tmp_path / "config.json"
        config_file.write_text("")
        cfg = load_enterprise_config(config_file)
        assert cfg == EnterpriseConfig()

    def test_invalid_json_returns_defaults(self, tmp_path: Path) -> None:
        config_file = tmp_path / "config.json"
        config_file.write_text("{not valid json")
        cfg = load_enterprise_config(config_file)
        assert cfg == EnterpriseConfig()

    def test_non_object_json_returns_defaults(self, tmp_path: Path) -> None:
        config_file = tmp_path / "config.json"
        config_file.write_text('"just a string"')
        cfg = load_enterprise_config(config_file)
        assert cfg == EnterpriseConfig()

    def test_full_config_from_file(self, tmp_path: Path) -> None:
        config_file = tmp_path / "config.json"
        config_file.write_text(
            json.dumps(
                {
                    "backend_url": "https://api.example.com",
                    "enrollment_token": "tok_123",
                    "auto_discover": False,
                    "auto_rewrite": False,
                    "log_level": "DEBUG",
                    "event_queue_max_size_mb": 200,
                    "heartbeat_interval_seconds": 120,
                }
            )
        )
        cfg = load_enterprise_config(config_file)
        assert cfg.backend_url == "https://api.example.com"
        assert cfg.enrollment_token == "tok_123"
        assert cfg.auto_discover is False
        assert cfg.auto_rewrite is False
        assert cfg.log_level == "DEBUG"
        assert cfg.event_queue_max_size_mb == 200
        assert cfg.heartbeat_interval_seconds == 120
        assert cfg.is_configured is True

    def test_partial_config_merges_with_defaults(self, tmp_path: Path) -> None:
        config_file = tmp_path / "config.json"
        config_file.write_text(json.dumps({"backend_url": "https://partial.example.com"}))
        cfg = load_enterprise_config(config_file)
        assert cfg.backend_url == "https://partial.example.com"
        assert cfg.enrollment_token == ""
        assert cfg.auto_discover is True
        assert cfg.heartbeat_interval_seconds == 30

    def test_extra_fields_ignored(self, tmp_path: Path) -> None:
        config_file = tmp_path / "config.json"
        config_file.write_text(
            json.dumps(
                {
                    "backend_url": "https://api.example.com",
                    "enrollment_token": "tok_x",
                    "unknown_field": "ignored",
                    "another_extra": 42,
                }
            )
        )
        cfg = load_enterprise_config(config_file)
        assert cfg.backend_url == "https://api.example.com"
        assert cfg.enrollment_token == "tok_x"
        assert not hasattr(cfg, "unknown_field")

    def test_custom_path_override(self, tmp_path: Path) -> None:
        custom = tmp_path / "custom" / "my-config.json"
        custom.parent.mkdir(parents=True)
        custom.write_text(json.dumps({"enrollment_token": "custom_tok"}))
        cfg = load_enterprise_config(custom)
        assert cfg.enrollment_token == "custom_tok"

    def test_string_coercion(self, tmp_path: Path) -> None:
        """Numeric backend_url gets coerced to string."""
        config_file = tmp_path / "config.json"
        config_file.write_text(json.dumps({"backend_url": 12345}))
        cfg = load_enterprise_config(config_file)
        assert cfg.backend_url == "12345"

    def test_bool_coercion(self, tmp_path: Path) -> None:
        """String 'false' is truthy in Python — bool() coercion means non-empty string → True."""
        config_file = tmp_path / "config.json"
        config_file.write_text(json.dumps({"auto_discover": 0}))
        cfg = load_enterprise_config(config_file)
        assert cfg.auto_discover is False

    def test_invalid_int_field_returns_defaults(self, tmp_path: Path) -> None:
        """Non-numeric string in int field returns defaults instead of raising."""
        config_file = tmp_path / "config.json"
        config_file.write_text(json.dumps({"event_queue_max_size_mb": "not-a-number"}))
        cfg = load_enterprise_config(config_file)
        assert cfg == EnterpriseConfig()

    def test_permission_error_returns_defaults(self, tmp_path: Path) -> None:
        """If we can't read the file, return defaults gracefully."""
        config_file = tmp_path / "config.json"
        config_file.write_text(json.dumps({"enrollment_token": "secret"}))
        config_file.chmod(0o000)
        try:
            cfg = load_enterprise_config(config_file)
            assert cfg == EnterpriseConfig()
        finally:
            config_file.chmod(0o644)
