"""Tests for event queue encryption (Item 4)."""

from __future__ import annotations

from unittest.mock import patch

import pytest

from vloex_mcp_proxy.backend.queue_crypto import decrypt, derive_key, encrypt


class TestDerivKey:
    """Tests for PBKDF2 key derivation."""

    def test_deterministic_with_same_salt(self) -> None:
        """Same token + salt always produces the same key."""
        salt = b"fixed-salt-12345"
        key1, s1 = derive_key("my-device-token", salt=salt)
        key2, s2 = derive_key("my-device-token", salt=salt)
        assert key1 == key2
        assert s1 == s2

    def test_different_keys_for_different_tokens(self) -> None:
        """Different tokens produce different keys with same salt."""
        salt = b"fixed-salt-12345"
        key1, _ = derive_key("token-alpha", salt=salt)
        key2, _ = derive_key("token-beta", salt=salt)
        assert key1 != key2

    def test_generates_random_salt_when_none(self) -> None:
        """When salt is None, generates a random 16-byte salt."""
        key1, salt1 = derive_key("my-device-token")
        key2, salt2 = derive_key("my-device-token")
        assert len(salt1) == 16
        assert len(salt2) == 16
        # Random salts should differ (extremely unlikely to collide)
        assert salt1 != salt2

    def test_key_is_32_bytes(self) -> None:
        """Derived key is always 32 bytes (AES-256)."""
        key, _ = derive_key("test-token")
        assert len(key) == 32


class TestEncryptDecrypt:
    """Tests for AES-256-GCM encrypt/decrypt."""

    def test_roundtrip(self) -> None:
        """Encrypt then decrypt recovers original plaintext."""
        key, _ = derive_key("test-token", salt=b"salt-for-testing")
        plaintext = '{"event": "test", "data": "sensitive-info"}'
        encrypted = encrypt(plaintext, key)
        assert encrypted is not None
        assert encrypted != plaintext
        decrypted = decrypt(encrypted, key)
        assert decrypted == plaintext

    def test_decrypt_returns_none_on_corrupt_data(self) -> None:
        """Corrupt ciphertext returns None instead of raising."""
        key, _ = derive_key("test-token", salt=b"salt-for-testing")
        result = decrypt("not-valid-base64!!", key)
        assert result is None

    def test_decrypt_returns_none_on_wrong_key(self) -> None:
        """Decrypting with wrong key returns None."""
        key1, _ = derive_key("token-1", salt=b"salt-for-testing")
        key2, _ = derive_key("token-2", salt=b"salt-for-testing")
        encrypted = encrypt("secret data", key1)
        assert encrypted is not None
        result = decrypt(encrypted, key2)
        assert result is None

    def test_encrypt_returns_none_when_cryptography_unavailable(self) -> None:
        """encrypt returns None when cryptography is not installed."""
        key, _ = derive_key("test-token", salt=b"salt-for-testing")
        with patch.dict(
            "sys.modules",
            {
                "cryptography": None,
                "cryptography.hazmat": None,
                "cryptography.hazmat.primitives": None,
                "cryptography.hazmat.primitives.ciphers": None,
                "cryptography.hazmat.primitives.ciphers.aead": None,
            },
        ):
            # Force re-import failure by patching builtins.__import__
            original_import = (
                __builtins__.__import__ if hasattr(__builtins__, "__import__") else __import__
            )

            def mock_import(name, *args, **kwargs):
                if "cryptography" in name:
                    raise ImportError("mocked")
                return original_import(name, *args, **kwargs)

            with patch("builtins.__import__", side_effect=mock_import):
                result = encrypt("test", key)
                assert result is None


class TestEventQueueEncryption:
    """Tests for EventQueue with encryption key."""

    @pytest.fixture
    def encryption_key(self) -> bytes:
        key, _ = derive_key("test-device-token", salt=b"test-salt-fixd!!")
        return key

    async def test_encrypted_roundtrip(self, tmp_path, encryption_key) -> None:
        """EventQueue with encryption key: enqueue/dequeue roundtrip."""
        from vloex_mcp_proxy.backend.event_queue import EventQueue

        db_path = str(tmp_path / "test_encrypted.db")
        queue = EventQueue(db_path, encryption_key=encryption_key)
        await queue.init()
        try:
            event = {"type": "tools/call", "tool": "read_file", "data": "sensitive"}
            await queue.enqueue(event)
            batch = await queue.dequeue_batch(10)
            assert len(batch) == 1
            row_id, dequeued = batch[0]
            assert dequeued == event
        finally:
            await queue.close()

    async def test_plaintext_without_encryption_key(self, tmp_path) -> None:
        """EventQueue without encryption key stores plaintext (existing behavior)."""
        from vloex_mcp_proxy.backend.event_queue import EventQueue

        db_path = str(tmp_path / "test_plain.db")
        queue = EventQueue(db_path)
        await queue.init()
        try:
            event = {"type": "test", "value": 42}
            await queue.enqueue(event)
            batch = await queue.dequeue_batch(10)
            assert len(batch) == 1
            _, dequeued = batch[0]
            assert dequeued == event
        finally:
            await queue.close()

    async def test_mixed_encrypted_and_plaintext(self, tmp_path, encryption_key) -> None:
        """Graceful migration: mixed encrypted and plaintext events in same queue."""
        import aiosqlite

        from vloex_mcp_proxy.backend.event_queue import EventQueue

        db_path = str(tmp_path / "test_mixed.db")

        # Step 1: Write a plaintext event (no encryption)
        queue_plain = EventQueue(db_path)
        await queue_plain.init()
        plaintext_event = {"type": "old_event", "plain": True}
        await queue_plain.enqueue(plaintext_event)
        # Mark it back to pending (dequeue_batch marks as syncing)
        await queue_plain.close()

        # Step 2: Write an encrypted event
        queue_enc = EventQueue(db_path, encryption_key=encryption_key)
        await queue_enc.init()
        encrypted_event = {"type": "new_event", "encrypted": True}
        await queue_enc.enqueue(encrypted_event)

        # Reset the first event back to pending for dequeue
        async with aiosqlite.connect(db_path) as db:
            await db.execute("UPDATE event_queue SET sync_status = 'pending'")
            await db.commit()

        # Step 3: Dequeue all — should handle both plaintext and encrypted
        batch = await queue_enc.dequeue_batch(10)
        assert len(batch) == 2

        events = [e for _, e in batch]
        assert plaintext_event in events
        assert encrypted_event in events

        await queue_enc.close()
