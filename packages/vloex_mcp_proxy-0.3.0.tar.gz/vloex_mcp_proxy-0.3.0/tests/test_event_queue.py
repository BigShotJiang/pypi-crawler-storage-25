"""Tests for vloex_mcp_proxy.backend.event_queue."""

from __future__ import annotations

import pytest

from vloex_mcp_proxy.backend.event_queue import MAX_QUEUE_SIZE, EventQueue


@pytest.fixture
async def queue(tmp_path):
    db_path = str(tmp_path / "test_queue.db")
    q = EventQueue(db_path)
    await q.init()
    yield q
    await q.close()


class TestEventQueue:
    async def test_enqueue_and_pending_count(self, queue):
        await queue.enqueue({"event": "one"})
        await queue.enqueue({"event": "two"})
        await queue.enqueue({"event": "three"})
        assert await queue.pending_count() == 3

    async def test_dequeue_batch(self, queue):
        for i in range(5):
            await queue.enqueue({"n": i})
        batch = await queue.dequeue_batch(3)
        assert len(batch) == 3
        # Items should be marked as syncing, not pending
        assert await queue.pending_count() == 2

    async def test_mark_synced_deletes(self, queue):
        await queue.enqueue({"event": "test"})
        batch = await queue.dequeue_batch()
        row_ids = [row_id for row_id, _event in batch]
        await queue.mark_synced(row_ids)
        assert await queue.pending_count() == 0

    async def test_mark_failed_retries(self, queue):
        await queue.enqueue({"event": "fail"})
        batch = await queue.dequeue_batch()
        row_ids = [row_id for row_id, _event in batch]
        await queue.mark_failed(row_ids)
        # Should be back to pending
        assert await queue.pending_count() == 1

    async def test_dequeue_empty(self, queue):
        batch = await queue.dequeue_batch()
        assert batch == []

    async def test_overflow_eviction(self, tmp_path):
        db_path = str(tmp_path / "overflow.db")
        q = EventQueue(db_path)
        await q.init()
        try:
            # Enqueue more than MAX_QUEUE_SIZE
            for i in range(MAX_QUEUE_SIZE + 10):
                await q.enqueue({"n": i})
            count = await q.pending_count()
            assert count <= MAX_QUEUE_SIZE
        finally:
            await q.close()

    async def test_close_and_reopen(self, tmp_path):
        db_path = str(tmp_path / "persist.db")
        q = EventQueue(db_path)
        await q.init()
        await q.enqueue({"event": "persisted"})
        await q.close()

        # Reopen
        q2 = EventQueue(db_path)
        await q2.init()
        assert await q2.pending_count() == 1
        await q2.close()

    async def test_dequeue_preserves_order(self, queue):
        for i in range(5):
            await queue.enqueue({"n": i})
        batch = await queue.dequeue_batch(5)
        events = [event for _row_id, event in batch]
        assert [e["n"] for e in events] == [0, 1, 2, 3, 4]

    async def test_mark_synced_empty_list(self, queue):
        # Should not raise
        await queue.mark_synced([])

    async def test_mark_failed_empty_list(self, queue):
        # Should not raise
        await queue.mark_failed([])
