"""Tests for CLI discover subcommand."""

from __future__ import annotations

import json
import subprocess
import sys


def _run_cli(*args: str, cwd: str | None = None) -> subprocess.CompletedProcess:
    """Run the CLI as a subprocess."""
    return subprocess.run(
        [sys.executable, "-m", "vloex_mcp_proxy.cli", *args],
        capture_output=True,
        text=True,
        cwd=cwd,
        timeout=10,
    )


class TestDiscoverCLI:
    """Tests for `vloex-mcp-proxy discover` subcommand."""

    def test_cli_discover_shows_clients(self, tmp_path) -> None:
        """discover --config-dir → lists found clients."""
        cursor_dir = tmp_path / ".cursor"
        cursor_dir.mkdir()
        config = {
            "mcpServers": {
                "filesystem": {
                    "command": "npx",
                    "args": ["-y", "@modelcontextprotocol/server-filesystem", "/tmp"],
                }
            }
        }
        (cursor_dir / "mcp.json").write_text(json.dumps(config))

        result = _run_cli("discover", "--config-dir", str(tmp_path))
        assert result.returncode == 0
        assert "Cursor" in result.stdout
        assert "filesystem" in result.stdout

    def test_cli_discover_rewrite(self, tmp_path) -> None:
        """discover --rewrite → configs rewritten."""
        cursor_dir = tmp_path / ".cursor"
        cursor_dir.mkdir()
        config = {"mcpServers": {"fs": {"command": "npx", "args": ["-y", "foo"]}}}
        (cursor_dir / "mcp.json").write_text(json.dumps(config))

        result = _run_cli("discover", "--rewrite", "--config-dir", str(tmp_path))
        assert result.returncode == 0
        assert "rewritten" in result.stdout

        # Verify the config was actually rewritten
        rewritten = json.loads((cursor_dir / "mcp.json").read_text())
        assert rewritten["mcpServers"]["fs"]["command"] == "vloex-mcp-proxy"

    def test_cli_discover_restore(self, tmp_path) -> None:
        """discover --restore → configs restored."""
        cursor_dir = tmp_path / ".cursor"
        cursor_dir.mkdir()
        config = {"mcpServers": {"fs": {"command": "npx", "args": ["-y", "foo"]}}}
        original_text = json.dumps(config, indent=2)
        (cursor_dir / "mcp.json").write_text(original_text)

        # Rewrite first
        _run_cli("discover", "--rewrite", "--config-dir", str(tmp_path))
        assert (cursor_dir / "mcp.json.vloex-backup").exists()

        # Restore
        result = _run_cli("discover", "--restore", "--config-dir", str(tmp_path))
        assert result.returncode == 0
        assert "restored" in result.stdout

    def test_cli_discover_dry_run(self, tmp_path) -> None:
        """discover --rewrite --dry-run → no changes."""
        cursor_dir = tmp_path / ".cursor"
        cursor_dir.mkdir()
        config = {"mcpServers": {"fs": {"command": "npx", "args": ["-y", "foo"]}}}
        original_text = json.dumps(config, indent=2)
        (cursor_dir / "mcp.json").write_text(original_text)

        result = _run_cli("discover", "--rewrite", "--dry-run", "--config-dir", str(tmp_path))
        assert result.returncode == 0
        assert "dry run" in result.stdout.lower()

        # File unchanged
        assert (cursor_dir / "mcp.json").read_text() == original_text
        assert not (cursor_dir / "mcp.json.vloex-backup").exists()

    def test_cli_discover_no_clients(self, tmp_path) -> None:
        """Empty config dir → 'No MCP clients found' message."""
        result = _run_cli("discover", "--config-dir", str(tmp_path))
        assert result.returncode == 0
        assert "No MCP clients found" in result.stdout

    def test_cli_proxy_mode_unchanged(self) -> None:
        """--server-command cat still works (M1 backward compat)."""
        result = subprocess.run(
            [
                sys.executable,
                "-m",
                "vloex_mcp_proxy.cli",
                "--server-command",
                "cat",
            ],
            input='{"jsonrpc":"2.0","method":"tools/list","id":1}\n',
            capture_output=True,
            text=True,
            timeout=5,
        )
        # cat echoes input back, proxy relays it
        assert result.returncode == 0
        output = result.stdout.strip()
        if output:
            msg = json.loads(output)
            assert msg["method"] == "tools/list"

    def test_cli_proxy_mode_requires_server_command(self) -> None:
        """Proxy mode without --server-command → error."""
        result = _run_cli()
        assert result.returncode == 2
        assert "server-command" in result.stderr.lower()

    def test_cli_discover_help(self) -> None:
        """discover --help shows options."""
        result = _run_cli("discover", "--help")
        assert result.returncode == 0
        assert "--rewrite" in result.stdout
        assert "--restore" in result.stdout
        assert "--dry-run" in result.stdout
        assert "--config-dir" in result.stdout
        assert "--proxy-command" in result.stdout
