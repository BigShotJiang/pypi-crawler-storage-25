"""Tests for the telemetry client."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path

from vloex_mcp_proxy.backend.telemetry import TelemetryClient

# ── Disabled by default ─────────────────────────────────────────────


class TestTelemetryDisabled:
    def test_disabled_by_default(self) -> None:
        """TelemetryClient is disabled by default."""
        client = TelemetryClient()
        assert client.enabled is False

    def test_record_event_noop_when_disabled(self) -> None:
        """record_event does nothing when disabled."""
        client = TelemetryClient(enabled=False)
        client.record_event("proxy_started")
        assert len(client._queue) == 0

    def test_record_crash_noop_when_disabled(self) -> None:
        """record_crash does nothing when disabled."""
        client = TelemetryClient(enabled=False)
        client.record_crash("Traceback: some error")
        assert len(client._queue) == 0

    def test_flush_noop_when_disabled(self) -> None:
        """flush returns 0 when disabled."""
        client = TelemetryClient(enabled=False)
        assert client.flush() == 0


# ── Enabled client ──────────────────────────────────────────────────


class TestTelemetryEnabled:
    def test_record_event_adds_to_queue(self) -> None:
        """Enabled client records events to the queue."""
        client = TelemetryClient(
            endpoint="http://example.com/telemetry",
            device_id="test-device-id",
            proxy_version="0.3.0",
            enabled=True,
        )
        client.record_event("proxy_started")
        assert len(client._queue) == 1
        event = client._queue[0]
        assert event["event_type"] == "proxy_started"
        assert event["device_id"] == "test-device-id"
        assert event["proxy_version"] == "0.3.0"
        assert "timestamp" in event
        assert "os" in event
        assert "python_version" in event

    def test_record_event_with_safe_extra(self) -> None:
        """Extra fields are included only if they're in the safe list."""
        client = TelemetryClient(enabled=True)
        client.record_event(
            "heartbeat",
            extra={
                "server_count": 3,
                "config_count": 5,
                "user_email": "secret@corp.com",  # Should be filtered
            },
        )
        event = client._queue[0]
        assert event["server_count"] == 3
        assert event["config_count"] == 5
        assert "user_email" not in event

    def test_multiple_events_queue(self) -> None:
        """Multiple events accumulate in the queue."""
        client = TelemetryClient(enabled=True)
        client.record_event("start")
        client.record_event("heartbeat")
        client.record_event("stop")
        assert len(client._queue) == 3


# ── Crash hash ──────────────────────────────────────────────────────


class TestCrashHash:
    def test_crash_hash_is_sha256_prefix(self) -> None:
        """crash_hash is a 16-char SHA-256 prefix, not the actual traceback."""
        client = TelemetryClient(enabled=True)
        traceback_str = (
            "Traceback (most recent call last):\n"
            '  File "cli.py", line 42, in main\n'
            "    raise ValueError('test')\n"
            "ValueError: test"
        )
        client.record_crash(traceback_str)

        assert len(client._queue) == 1
        event = client._queue[0]
        assert event["event_type"] == "crash"
        assert "crash_hash" in event

        # Verify it's a 16-char hex hash
        crash_hash = event["crash_hash"]
        assert len(crash_hash) == 16
        assert all(c in "0123456789abcdef" for c in crash_hash)

        # Verify it matches the expected SHA-256 prefix
        expected = hashlib.sha256(traceback_str.encode()).hexdigest()[:16]
        assert crash_hash == expected

    def test_crash_hash_not_actual_traceback(self) -> None:
        """The event does NOT contain the actual traceback text."""
        client = TelemetryClient(enabled=True)
        client.record_crash("Traceback: sensitive path /home/user/secret.py")
        event = client._queue[0]
        assert "sensitive" not in json.dumps(event)
        assert "secret.py" not in json.dumps(event)
        assert "/home/user" not in json.dumps(event)


# ── No PII validation ───────────────────────────────────────────────


class TestNoPII:
    def test_no_pii_in_standard_event(self) -> None:
        """Standard recorded events contain no PII fields."""
        client = TelemetryClient(
            device_id="d-123",
            proxy_version="0.3.0",
            enabled=True,
        )
        client.record_event("proxy_started")
        event = client._queue[0]
        assert not client.has_pii(event)

    def test_no_pii_in_crash_event(self) -> None:
        """Crash events contain no PII fields."""
        client = TelemetryClient(enabled=True)
        client.record_crash("Traceback: error")
        event = client._queue[0]
        assert not client.has_pii(event)

    def test_has_pii_detects_email(self) -> None:
        """has_pii detects user_email field."""
        client = TelemetryClient(enabled=True)
        event = {"event_type": "test", "user_email": "alice@corp.com"}
        assert client.has_pii(event) is True

    def test_has_pii_detects_hostname(self) -> None:
        """has_pii detects hostname field."""
        client = TelemetryClient(enabled=True)
        event = {"event_type": "test", "hostname": "alice-mbp.local"}
        assert client.has_pii(event) is True

    def test_has_pii_detects_traceback(self) -> None:
        """has_pii detects raw traceback field."""
        client = TelemetryClient(enabled=True)
        event = {"event_type": "test", "traceback": "Traceback: error"}
        assert client.has_pii(event) is True


# ── Enterprise config integration ───────────────────────────────────


class TestEnterpriseConfigTelemetry:
    def test_telemetry_enabled_field_default_false(self) -> None:
        """EnterpriseConfig.telemetry_enabled defaults to False."""
        from vloex_mcp_proxy.packaging.enterprise_config import EnterpriseConfig

        config = EnterpriseConfig()
        assert config.telemetry_enabled is False

    def test_telemetry_enabled_from_config_file(self, tmp_path: Path) -> None:
        """load_enterprise_config reads telemetry_enabled from file."""
        from vloex_mcp_proxy.packaging.enterprise_config import load_enterprise_config

        config_file = tmp_path / "config.json"
        config_file.write_text(json.dumps({"telemetry_enabled": True}))

        config = load_enterprise_config(path=config_file)
        assert config.telemetry_enabled is True

    def test_telemetry_disabled_in_config_file(self, tmp_path: Path) -> None:
        """telemetry_enabled=false in config file is read correctly."""
        from vloex_mcp_proxy.packaging.enterprise_config import load_enterprise_config

        config_file = tmp_path / "config.json"
        config_file.write_text(json.dumps({"telemetry_enabled": False}))

        config = load_enterprise_config(path=config_file)
        assert config.telemetry_enabled is False

    def test_missing_telemetry_field_defaults_false(self, tmp_path: Path) -> None:
        """Missing telemetry_enabled field defaults to False."""
        from vloex_mcp_proxy.packaging.enterprise_config import load_enterprise_config

        config_file = tmp_path / "config.json"
        config_file.write_text(json.dumps({"backend_url": "http://test.com"}))

        config = load_enterprise_config(path=config_file)
        assert config.telemetry_enabled is False


# ── Flush behavior ──────────────────────────────────────────────────


class TestFlush:
    def test_flush_returns_zero_without_endpoint(self) -> None:
        """flush returns 0 when endpoint is empty."""
        client = TelemetryClient(enabled=True, endpoint="")
        client.record_event("test")
        assert client.flush() == 0
        # Events should be cleared even on failed flush
        # Actually, re-check: events are cleared before send attempt
        # but if endpoint is empty, we return early
        assert len(client._queue) == 1  # Not cleared because early return

    def test_flush_returns_zero_empty_queue(self) -> None:
        """flush returns 0 when queue is empty."""
        client = TelemetryClient(enabled=True, endpoint="http://example.com/telemetry")
        assert client.flush() == 0
