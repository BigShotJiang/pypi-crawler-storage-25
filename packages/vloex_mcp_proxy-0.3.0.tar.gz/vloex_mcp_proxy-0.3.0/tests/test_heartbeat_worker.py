"""Tests for vloex_mcp_proxy.backend.heartbeat_worker."""

from __future__ import annotations

import asyncio
import json
from unittest.mock import AsyncMock

import pytest

from vloex_mcp_proxy.backend.heartbeat_worker import HeartbeatWorker
from vloex_mcp_proxy.policy.engine import PolicyEngine


@pytest.fixture
def policy_engine():
    return PolicyEngine()


@pytest.fixture
def mock_client():
    c = AsyncMock()
    c.heartbeat = AsyncMock(return_value=None)
    return c


class TestHeartbeatWorker:
    def test_load_cached_config(self, tmp_path, policy_engine, mock_client):
        cache = {
            "policies": [{"id": "p1", "action": "block", "conditions": [], "enabled": True}],
            "heartbeat_interval_seconds": 120,
        }
        (tmp_path / "heartbeat_cache.json").write_text(json.dumps(cache))

        worker = HeartbeatWorker(mock_client, policy_engine, "dev-001", vloex_dir=tmp_path)
        loaded = worker.load_cached_config()
        assert loaded is True
        assert policy_engine.has_policies is True
        assert worker.interval == 120.0

    def test_load_cached_config_no_file(self, tmp_path, policy_engine, mock_client):
        worker = HeartbeatWorker(mock_client, policy_engine, "dev-001", vloex_dir=tmp_path)
        loaded = worker.load_cached_config()
        assert loaded is False

    def test_load_cached_config_corrupt(self, tmp_path, policy_engine, mock_client):
        (tmp_path / "heartbeat_cache.json").write_text("not json{")
        worker = HeartbeatWorker(mock_client, policy_engine, "dev-001", vloex_dir=tmp_path)
        loaded = worker.load_cached_config()
        assert loaded is False

    async def test_heartbeat_updates_policies(self, tmp_path, policy_engine, mock_client):
        mock_client.heartbeat = AsyncMock(
            return_value={
                "status": "ok",
                "mcp_config": {
                    "policies": [{"id": "p1", "action": "warn", "conditions": [], "enabled": True}],
                    "heartbeat_interval_seconds": 30,
                },
            }
        )
        worker = HeartbeatWorker(mock_client, policy_engine, "dev-001", vloex_dir=tmp_path)

        async def _stop_after():
            await asyncio.sleep(0.1)
            worker.stop()

        asyncio.get_event_loop().create_task(_stop_after())
        await worker.run()

        assert policy_engine.has_policies is True
        assert worker.interval == 30.0

    async def test_heartbeat_saves_cache(self, tmp_path, policy_engine, mock_client):
        mock_client.heartbeat = AsyncMock(
            return_value={
                "status": "ok",
                "mcp_config": {
                    "policies": [{"id": "p1", "action": "block", "conditions": []}],
                },
            }
        )
        worker = HeartbeatWorker(mock_client, policy_engine, "dev-001", vloex_dir=tmp_path)

        async def _stop_after():
            await asyncio.sleep(0.1)
            worker.stop()

        asyncio.get_event_loop().create_task(_stop_after())
        await worker.run()

        cache_path = tmp_path / "heartbeat_cache.json"
        assert cache_path.exists()
        data = json.loads(cache_path.read_text())
        assert "policies" in data

    async def test_offline_fallback(self, tmp_path, policy_engine, mock_client):
        """Backend unreachable, but cached policies still work."""
        cache = {"policies": [{"id": "p1", "action": "block", "conditions": [], "enabled": True}]}
        (tmp_path / "heartbeat_cache.json").write_text(json.dumps(cache))

        mock_client.heartbeat = AsyncMock(return_value=None)
        worker = HeartbeatWorker(mock_client, policy_engine, "dev-001", vloex_dir=tmp_path)
        worker.load_cached_config()

        async def _stop_after():
            await asyncio.sleep(0.1)
            worker.stop()

        asyncio.get_event_loop().create_task(_stop_after())
        await worker.run()

        # Policies from cache should still be active
        assert policy_engine.has_policies is True

    async def test_heartbeat_stop(self, tmp_path, policy_engine, mock_client):
        worker = HeartbeatWorker(mock_client, policy_engine, "dev-001", vloex_dir=tmp_path)
        worker.stop()
        assert worker._running is False

    def test_apply_config_extracts_user_department(self, tmp_path, policy_engine, mock_client):
        """_apply_config should extract user_department from heartbeat config."""
        worker = HeartbeatWorker(mock_client, policy_engine, "dev-001", vloex_dir=tmp_path)
        assert worker.user_department is None

        worker._apply_config(
            {
                "policies": [],
                "user_department": "Engineering",
            }
        )
        assert worker.user_department == "Engineering"

    def test_apply_config_clears_department_when_none(self, tmp_path, policy_engine, mock_client):
        """_apply_config should clear department when backend returns None."""
        worker = HeartbeatWorker(mock_client, policy_engine, "dev-001", vloex_dir=tmp_path)
        worker._apply_config({"policies": [], "user_department": "Sales"})
        assert worker.user_department == "Sales"

        worker._apply_config({"policies": [], "user_department": None})
        assert worker.user_department is None

    def test_apply_config_calls_on_config_updated(self, tmp_path, policy_engine, mock_client):
        """_apply_config should invoke the on_config_updated callback."""
        worker = HeartbeatWorker(mock_client, policy_engine, "dev-001", vloex_dir=tmp_path)
        callback_called = []
        worker.set_on_config_updated(lambda: callback_called.append(True))

        worker._apply_config({"policies": [], "user_department": "Engineering"})
        assert len(callback_called) == 1
