"""Tests for discovery/rewriter.py — rewrite, backup, restore, competing proxy."""

from __future__ import annotations

import json
import os
import stat

from vloex_mcp_proxy.discovery.config_paths import ConfigFormat
from vloex_mcp_proxy.discovery.rewriter import (
    is_already_rewritten,
    is_competing_proxy,
    restore_all,
    restore_config,
    rewrite_config,
    rewrite_server_entry,
)

# ---------------------------------------------------------------------------
# is_already_rewritten / is_competing_proxy
# ---------------------------------------------------------------------------


class TestDetection:
    """Tests for already-rewritten and competing proxy detection."""

    def test_is_already_rewritten_command(self) -> None:
        """Command is 'vloex-mcp-proxy' → True."""
        assert is_already_rewritten({"command": "vloex-mcp-proxy", "args": []})

    def test_is_already_rewritten_full_path(self) -> None:
        """Command is full path ending in vloex-mcp-proxy → True."""
        assert is_already_rewritten({"command": "/usr/local/bin/vloex-mcp-proxy", "args": []})

    def test_is_not_rewritten(self) -> None:
        """Regular command → False."""
        assert not is_already_rewritten({"command": "npx", "args": ["-y", "foo"]})

    def test_is_competing_proxy_in_command(self) -> None:
        """Competing proxy name in command → detected."""
        result = is_competing_proxy({"command": "harmonic-mcp", "args": []})
        assert result is not None
        assert "harmonic" in result

    def test_is_competing_proxy_in_args(self) -> None:
        """Competing proxy name in args → detected."""
        result = is_competing_proxy({"command": "npx", "args": ["harmonic", "--wrap"]})
        assert result is not None

    def test_is_competing_proxy_case_insensitive(self) -> None:
        """Case-insensitive detection."""
        result = is_competing_proxy({"command": "Harmonic-MCP", "args": []})
        assert result is not None

    def test_no_competing_proxy(self) -> None:
        """Regular config → None."""
        result = is_competing_proxy({"command": "npx", "args": ["-y", "fs-server"]})
        assert result is None

    def test_is_competing_proxy_mcp_guardian(self) -> None:
        """mcp-guardian in command → detected."""
        result = is_competing_proxy({"command": "mcp-guardian", "args": ["--wrap", "npx"]})
        assert result == "mcp-guardian"


# ---------------------------------------------------------------------------
# rewrite_server_entry
# ---------------------------------------------------------------------------


class TestRewriteServerEntry:
    """Tests for single server entry rewriting."""

    def test_rewrite_single_server(self) -> None:
        """Standard server → rewritten with proxy wrapper."""
        config = {
            "command": "npx",
            "args": ["-y", "@modelcontextprotocol/server-filesystem", "/Users"],
        }
        new_config, result = rewrite_server_entry("filesystem", config)

        assert result.rewritten is True
        assert new_config["command"] == "vloex-mcp-proxy"
        assert "--server-command" in new_config["args"]
        assert "npx" in new_config["args"]
        assert "--server-name" in new_config["args"]
        assert "filesystem" in new_config["args"]

    def test_rewrite_uses_json_array_for_args(self) -> None:
        """Server args serialized as JSON array string (not comma-separated)."""
        config = {
            "command": "npx",
            "args": ["-y", "@modelcontextprotocol/server-filesystem", "/Users"],
        }
        new_config, _ = rewrite_server_entry("fs", config)

        args = new_config["args"]
        idx = args.index("--server-args")
        server_args_value = args[idx + 1]

        # Must be valid JSON array
        parsed = json.loads(server_args_value)
        assert isinstance(parsed, list)
        assert parsed == ["-y", "@modelcontextprotocol/server-filesystem", "/Users"]

    def test_rewrite_preserves_env(self) -> None:
        """Server with env → env preserved in rewritten config."""
        config = {
            "command": "npx",
            "args": ["-y", "gh-server"],
            "env": {"GITHUB_TOKEN": "ghp_fake123"},
        }
        new_config, result = rewrite_server_entry("github", config)

        assert result.rewritten is True
        assert new_config["env"]["GITHUB_TOKEN"] == "ghp_fake123"

    def test_rewrite_already_rewritten_skipped(self) -> None:
        """Already wrapped in vloex-mcp-proxy → skipped."""
        config = {
            "command": "vloex-mcp-proxy",
            "args": ["--server-command", "npx", "--server-name", "fs"],
        }
        new_config, result = rewrite_server_entry("fs", config)

        assert result.rewritten is False
        assert result.skipped_reason == "already rewritten"
        assert new_config is config  # unchanged

    def test_rewrite_competing_proxy_skipped(self) -> None:
        """Wrapped in harmonic → skipped."""
        config = {
            "command": "harmonic-mcp",
            "args": ["--wrap", "npx"],
        }
        new_config, result = rewrite_server_entry("fs", config)

        assert result.rewritten is False
        assert "competing proxy" in result.skipped_reason

    def test_rewrite_empty_args(self) -> None:
        """Server with no args → --server-args is empty JSON array."""
        config = {"command": "my-server"}
        new_config, result = rewrite_server_entry("srv", config)

        assert result.rewritten is True
        args = new_config["args"]
        idx = args.index("--server-args")
        assert json.loads(args[idx + 1]) == []

    def test_rewrite_custom_proxy_command(self) -> None:
        """Custom proxy_command → used instead of default."""
        config = {"command": "npx", "args": []}
        new_config, _ = rewrite_server_entry(
            "fs", config, proxy_command="/usr/local/bin/vloex-mcp-proxy"
        )
        assert new_config["command"] == "/usr/local/bin/vloex-mcp-proxy"


# ---------------------------------------------------------------------------
# rewrite_config (full file)
# ---------------------------------------------------------------------------


class TestRewriteConfig:
    """Tests for full config file rewriting."""

    def test_rewrite_creates_backup(self, tmp_path) -> None:
        """After rewrite → .vloex-backup exists with original content."""
        config = {"mcpServers": {"fs": {"command": "npx", "args": ["-y", "foo"]}}}
        path = tmp_path / "mcp.json"
        original_text = json.dumps(config, indent=2)
        path.write_text(original_text)

        rewrite_config(path, ConfigFormat.STANDARD)

        backup = tmp_path / "mcp.json.vloex-backup"
        assert backup.exists()
        assert json.loads(backup.read_text()) == config

    def test_rewrite_multiple_servers(self, tmp_path) -> None:
        """Config with 3 servers → all rewritten."""
        config = {
            "mcpServers": {
                "fs": {"command": "npx", "args": ["-y", "fs"]},
                "gh": {"command": "npx", "args": ["-y", "gh"]},
                "pg": {"command": "npx", "args": ["-y", "pg"]},
            }
        }
        path = tmp_path / "mcp.json"
        path.write_text(json.dumps(config))

        report = rewrite_config(path, ConfigFormat.STANDARD)
        assert report.servers_rewritten == 3
        assert report.servers_skipped == 0

        # Verify rewritten content
        rewritten = json.loads(path.read_text())
        for name in ("fs", "gh", "pg"):
            assert rewritten["mcpServers"][name]["command"] == "vloex-mcp-proxy"

    def test_rewrite_mixed_servers(self, tmp_path) -> None:
        """1 clean + 1 already rewritten + 1 competing → only clean one rewritten."""
        config = {
            "mcpServers": {
                "clean": {"command": "npx", "args": ["-y", "clean-server"]},
                "proxied": {
                    "command": "vloex-mcp-proxy",
                    "args": ["--server-command", "npx"],
                },
                "harmonic": {"command": "harmonic-mcp", "args": ["--wrap", "npx"]},
            }
        }
        path = tmp_path / "mcp.json"
        path.write_text(json.dumps(config))

        report = rewrite_config(path, ConfigFormat.STANDARD)
        assert report.servers_rewritten == 1
        assert report.servers_skipped == 2

    def test_rewrite_dry_run_no_changes(self, tmp_path) -> None:
        """dry_run=True → no file changes."""
        config = {"mcpServers": {"fs": {"command": "npx", "args": []}}}
        path = tmp_path / "mcp.json"
        original_text = json.dumps(config, indent=2)
        path.write_text(original_text)

        report = rewrite_config(path, ConfigFormat.STANDARD, dry_run=True)
        assert report.servers_rewritten == 1  # counted but not written

        # File unchanged
        assert path.read_text() == original_text
        # No backup created
        backup = tmp_path / "mcp.json.vloex-backup"
        assert not backup.exists()

    def test_rewrite_vscode_preserves_settings(self, tmp_path) -> None:
        """VS Code settings → only MCP section changed, editor prefs intact."""
        config = {
            "editor.fontSize": 14,
            "editor.tabSize": 2,
            "mcp": {
                "servers": {
                    "pg": {"command": "npx", "args": ["-y", "pg-server"]},
                }
            },
            "workbench.colorTheme": "One Dark Pro",
        }
        path = tmp_path / "settings.json"
        path.write_text(json.dumps(config))

        rewrite_config(path, ConfigFormat.VSCODE, key_in_settings="mcp.servers")

        result = json.loads(path.read_text())
        assert result["editor.fontSize"] == 14
        assert result["workbench.colorTheme"] == "One Dark Pro"
        assert result["mcp"]["servers"]["pg"]["command"] == "vloex-mcp-proxy"

    def test_rewrite_zed_preserves_settings(self, tmp_path) -> None:
        """Zed settings → only context_servers changed."""
        config = {
            "theme": "One Dark",
            "context_servers": {
                "fs": {"command": "npx", "args": ["-y", "fs-server"]},
            },
            "vim_mode": True,
        }
        path = tmp_path / "settings.json"
        path.write_text(json.dumps(config))

        rewrite_config(path, ConfigFormat.ZED, key_in_settings="context_servers")

        result = json.loads(path.read_text())
        assert result["theme"] == "One Dark"
        assert result["vim_mode"] is True
        assert result["context_servers"]["fs"]["command"] == "vloex-mcp-proxy"

    def test_rewrite_continue_array_format(self, tmp_path) -> None:
        """Continue config → rewritten in array format."""
        config = {
            "mcpServers": [
                {"name": "fs", "command": "npx", "args": ["-y", "fs-server"]},
            ]
        }
        path = tmp_path / "config.json"
        path.write_text(json.dumps(config))

        rewrite_config(path, ConfigFormat.CONTINUE_ARRAY, key_in_settings="mcpServers")

        result = json.loads(path.read_text())
        arr = result["mcpServers"]
        assert isinstance(arr, list)
        assert len(arr) == 1
        assert arr[0]["name"] == "fs"
        assert arr[0]["command"] == "vloex-mcp-proxy"

    def test_rewrite_preserves_file_permissions(self, tmp_path) -> None:
        """Config file with specific permissions → same after rewrite."""
        config = {"mcpServers": {"fs": {"command": "npx", "args": []}}}
        path = tmp_path / "mcp.json"
        path.write_text(json.dumps(config))

        # Set specific permissions (owner read+write only)
        os.chmod(path, stat.S_IRUSR | stat.S_IWUSR)
        original_mode = os.stat(path).st_mode

        rewrite_config(path, ConfigFormat.STANDARD)

        assert os.stat(path).st_mode == original_mode


# ---------------------------------------------------------------------------
# Restore
# ---------------------------------------------------------------------------


class TestRestore:
    """Tests for config restore from backups."""

    def test_restore_from_backup(self, tmp_path) -> None:
        """Rewrite → restore → file matches original."""
        config = {"mcpServers": {"fs": {"command": "npx", "args": ["-y", "foo"]}}}
        path = tmp_path / "mcp.json"
        original_text = json.dumps(config, indent=2)
        path.write_text(original_text)

        rewrite_config(path, ConfigFormat.STANDARD)
        # Verify it was rewritten
        rewritten = json.loads(path.read_text())
        assert rewritten["mcpServers"]["fs"]["command"] == "vloex-mcp-proxy"

        # Restore
        restored = restore_config(path)
        assert restored is True
        assert json.loads(path.read_text()) == config

        # Backup removed after restore
        backup = tmp_path / "mcp.json.vloex-backup"
        assert not backup.exists()

    def test_restore_no_backup(self, tmp_path) -> None:
        """No backup file → returns False, no crash."""
        path = tmp_path / "mcp.json"
        path.write_text(json.dumps({"mcpServers": {}}))

        result = restore_config(path)
        assert result is False

    def test_double_rewrite_skips(self, tmp_path) -> None:
        """Rewrite twice → second time all servers skipped (no double wrapping)."""
        config = {"mcpServers": {"fs": {"command": "npx", "args": ["-y", "foo"]}}}
        path = tmp_path / "mcp.json"
        path.write_text(json.dumps(config))

        report1 = rewrite_config(path, ConfigFormat.STANDARD)
        assert report1.servers_rewritten == 1

        report2 = rewrite_config(path, ConfigFormat.STANDARD)
        assert report2.servers_rewritten == 0
        assert report2.servers_skipped == 1

    def test_restore_all_orphaned_backup(self, tmp_path) -> None:
        """Orphaned .vloex-backup (config deleted after rewrite) → still restored."""
        # Create Cursor config dir structure
        cursor_dir = tmp_path / ".cursor"
        cursor_dir.mkdir()
        config = {"mcpServers": {"fs": {"command": "npx", "args": ["-y", "foo"]}}}
        config_path = cursor_dir / "mcp.json"
        config_path.write_text(json.dumps(config))

        # Rewrite to create backup
        rewrite_config(config_path, ConfigFormat.STANDARD)
        backup = cursor_dir / "mcp.json.vloex-backup"
        assert backup.exists()

        # Simulate orphaned backup: delete the rewritten config
        # but keep the backup (e.g., user manually deleted or corrupted config)
        config_path.unlink()
        assert not config_path.exists()
        assert backup.exists()

        # restore_all should find and restore from orphaned backup
        report = restore_all(config_dir_override=tmp_path, platform="macos")
        assert report.configs_restored == 1
        assert "orphaned" in "\n".join(report.details)
        assert config_path.exists()
        assert json.loads(config_path.read_text()) == config
