"""Tests for the sensitive data scanner."""

from __future__ import annotations

import time

from vloex_mcp_proxy.scanner.sensitive import (
    SensitiveDataType,
    _luhn_check,
    scan_text,
)

# ── Pattern detection tests (one per pattern) ──────────────────────


def test_detect_ssn() -> None:
    """SSN pattern detects XXX-XX-XXXX format."""
    detections = scan_text("SSN: 123-45-6789")
    types = [d.data_type for d in detections]
    assert SensitiveDataType.PII_SSN in types
    ssn = next(d for d in detections if d.data_type == SensitiveDataType.PII_SSN)
    assert ssn.confidence == 1.0


def test_detect_email() -> None:
    """Email pattern detects standard addresses."""
    detections = scan_text("john@company.com")
    types = [d.data_type for d in detections]
    assert SensitiveDataType.PII_EMAIL in types
    email = next(d for d in detections if d.data_type == SensitiveDataType.PII_EMAIL)
    assert email.confidence == 1.0


def test_detect_api_key_openai() -> None:
    """API key pattern detects OpenAI sk- keys."""
    detections = scan_text("sk-abc123def456ghi789jkl012mno")
    types = [d.data_type for d in detections]
    assert SensitiveDataType.CREDENTIALS_API_KEY in types


def test_detect_api_key_aws() -> None:
    """API key pattern detects AWS AKIA keys."""
    detections = scan_text("AKIAIOSFODNN7EXAMPLE")
    types = [d.data_type for d in detections]
    assert SensitiveDataType.CREDENTIALS_API_KEY in types


def test_detect_api_key_github() -> None:
    """API key pattern detects GitHub ghp_ tokens."""
    detections = scan_text("ghp_ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghij")
    types = [d.data_type for d in detections]
    assert SensitiveDataType.CREDENTIALS_API_KEY in types


def test_detect_credit_card_luhn_valid() -> None:
    """Credit card with Luhn-valid number gets confidence 1.0."""
    detections = scan_text("4532015112830366")
    types = [d.data_type for d in detections]
    assert SensitiveDataType.PII_CREDIT_CARD in types
    cc = next(d for d in detections if d.data_type == SensitiveDataType.PII_CREDIT_CARD)
    assert cc.confidence == 1.0


def test_detect_credit_card_luhn_invalid() -> None:
    """Credit card with Luhn-invalid number keeps base confidence 0.7."""
    detections = scan_text("1234-5678-9012-3456")
    types = [d.data_type for d in detections]
    assert SensitiveDataType.PII_CREDIT_CARD in types
    cc = next(d for d in detections if d.data_type == SensitiveDataType.PII_CREDIT_CARD)
    assert cc.confidence == 0.7


def test_detect_phone() -> None:
    """Phone pattern detects US phone numbers."""
    detections = scan_text("(555) 123-4567")
    types = [d.data_type for d in detections]
    assert SensitiveDataType.PII_PHONE in types
    phone = next(d for d in detections if d.data_type == SensitiveDataType.PII_PHONE)
    assert phone.confidence == 0.8


def test_detect_address() -> None:
    """Address pattern detects street addresses."""
    detections = scan_text("123 Main Street")
    types = [d.data_type for d in detections]
    assert SensitiveDataType.PII_ADDRESS in types
    addr = next(d for d in detections if d.data_type == SensitiveDataType.PII_ADDRESS)
    assert addr.confidence == 0.7


def test_detect_medical() -> None:
    """Medical pattern detects health terminology."""
    detections = scan_text("patient diagnosis ICD-10")
    types = [d.data_type for d in detections]
    assert SensitiveDataType.PHI_MEDICAL in types


def test_detect_icd_code() -> None:
    """ICD code pattern detects J45.20 format."""
    detections = scan_text("J45.20")
    types = [d.data_type for d in detections]
    assert SensitiveDataType.PHI_ICD_CODE in types


def test_detect_drug_name() -> None:
    """Drug name pattern detects prescription drugs."""
    detections = scan_text("prescribed metformin")
    types = [d.data_type for d in detections]
    assert SensitiveDataType.PHI_DRUG_NAME in types


def test_detect_password() -> None:
    """Password pattern detects password assignments."""
    detections = scan_text("password: hunter2")
    types = [d.data_type for d in detections]
    assert SensitiveDataType.CREDENTIALS_PASSWORD in types
    pwd = next(d for d in detections if d.data_type == SensitiveDataType.CREDENTIALS_PASSWORD)
    assert pwd.confidence == 0.9


def test_detect_genomic() -> None:
    """Genomic pattern detects gene names."""
    detections = scan_text("Patient has BRCA1 mutation")
    types = [d.data_type for d in detections]
    assert SensitiveDataType.PHI_GENOMIC in types


def test_detect_mrn() -> None:
    """MRN pattern detects medical record numbers."""
    detections = scan_text("MRN: 12345678")
    types = [d.data_type for d in detections]
    assert SensitiveDataType.PHI_MRN in types


def test_detect_source_code() -> None:
    """Source code pattern detects function definitions."""
    detections = scan_text("\ndef calculate_salary(employee):")
    types = [d.data_type for d in detections]
    assert SensitiveDataType.IP_SOURCE_CODE in types


# ── Edge case tests ────────────────────────────────────────────────


def test_no_detection_clean_text() -> None:
    """Clean text returns empty list."""
    detections = scan_text("Hello world, read file /tmp/test")
    # Filter out source code detection (import could false-positive)
    meaningful = [d for d in detections if d.data_type != SensitiveDataType.IP_SOURCE_CODE]
    assert meaningful == []


def test_multiple_detections() -> None:
    """Text with multiple sensitive types returns all."""
    detections = scan_text("SSN: 123-45-6789 email: a@b.com")
    types = {d.data_type for d in detections}
    assert SensitiveDataType.PII_SSN in types
    assert SensitiveDataType.PII_EMAIL in types


def test_empty_string() -> None:
    """Empty string returns no detections."""
    assert scan_text("") == []


def test_custom_pattern_keyword() -> None:
    """Custom keyword pattern matches with word boundaries."""
    custom = [
        {
            "pattern_type": "keyword",
            "pattern_value": "PROJ-123456",
            "data_type_label": "internal_project_id",
            "confidence": 0.9,
        }
    ]
    detections = scan_text("Contains PROJ-123456 here", custom_patterns=custom)
    custom_dets = [d for d in detections if d.data_type == SensitiveDataType.IP_TRADE_SECRET]
    assert len(custom_dets) == 1
    assert custom_dets[0].custom_label == "internal_project_id"
    assert custom_dets[0].confidence == 0.9


def test_custom_pattern_regex() -> None:
    r"""Custom regex pattern PROJ-\d{6} matches."""
    custom = [
        {
            "pattern_type": "regex",
            "pattern_value": r"PROJ-\d{6}",
            "data_type_label": "project_ref",
            "confidence": 0.85,
        }
    ]
    detections = scan_text("Ref: PROJ-789012", custom_patterns=custom)
    custom_dets = [d for d in detections if d.data_type == SensitiveDataType.IP_TRADE_SECRET]
    assert len(custom_dets) == 1
    assert custom_dets[0].custom_label == "project_ref"


def test_malformed_custom_pattern() -> None:
    """Bad regex in custom pattern is skipped gracefully."""
    custom = [
        {
            "pattern_type": "regex",
            "pattern_value": "[invalid",
            "data_type_label": "bad",
            "confidence": 0.5,
        }
    ]
    # Should not crash
    detections = scan_text("test text", custom_patterns=custom)
    custom_dets = [d for d in detections if d.custom_label == "bad"]
    assert custom_dets == []


def test_large_text_performance() -> None:
    """1MB string with no matches completes in < 2s."""
    text = "x" * 1_000_000
    start = time.monotonic()
    detections = scan_text(text)
    elapsed = time.monotonic() - start
    # Should be fast — no matches means early return per pattern
    assert elapsed < 2.0
    # No meaningful detections on uniform text
    meaningful = [d for d in detections if d.data_type != SensitiveDataType.IP_SOURCE_CODE]
    assert meaningful == []


def test_binary_content_safety() -> None:
    """Non-UTF8 bytes don't crash (scan_text takes str, caller handles encoding)."""
    # If caller accidentally decodes with errors='replace', we still don't crash
    text = "some \x00 data \ufffd here"
    detections = scan_text(text)
    # Should return without crash
    assert isinstance(detections, list)


# ── Luhn validation tests ─────────────────────────────────────────


def test_luhn_valid_visa() -> None:
    """Luhn check passes for valid Visa number."""
    assert _luhn_check("4532015112830366") is True


def test_luhn_invalid() -> None:
    """Luhn check fails for invalid number."""
    assert _luhn_check("1234567890123456") is False


def test_luhn_short_number() -> None:
    """Luhn check fails for non-16-digit number."""
    assert _luhn_check("12345") is False


def test_detection_count() -> None:
    """Multiple occurrences of same pattern are counted."""
    detections = scan_text("email: a@b.com and c@d.com")
    email = next(d for d in detections if d.data_type == SensitiveDataType.PII_EMAIL)
    assert email.count == 2
