"""Tests for privilege dropping (Item 5, SEC-10).

All tests use mocking — never actually call setuid/setgid.
"""

from __future__ import annotations

import types
from unittest.mock import MagicMock, patch

from vloex_mcp_proxy.daemon.privilege import drop_privileges


class TestDropPrivileges:
    """Tests for drop_privileges()."""

    def test_drops_when_root_and_user_exists(self) -> None:
        """Running as root with valid user: calls setgid + setuid, returns True."""
        mock_pw = MagicMock()
        mock_pw.pw_uid = 501
        mock_pw.pw_gid = 501

        mock_pwd = MagicMock()
        mock_pwd.getpwnam.return_value = mock_pw

        with (
            patch("vloex_mcp_proxy.daemon.privilege.sys") as mock_sys,
            patch("vloex_mcp_proxy.daemon.privilege.os") as mock_os,
            patch.dict("sys.modules", {"pwd": mock_pwd}),
        ):
            mock_sys.platform = "darwin"
            mock_sys.stderr = MagicMock()
            mock_os.getuid.return_value = 0

            result = drop_privileges("_vloex")

            assert result is True
            mock_os.setgroups.assert_called_once_with([])
            mock_os.setgid.assert_called_once_with(501)
            mock_os.initgroups.assert_called_once_with("_vloex", 501)
            mock_os.setuid.assert_called_once_with(501)

    def test_skips_when_not_root(self) -> None:
        """Non-root user: skip, return False, no setuid/setgid calls."""
        with (
            patch("vloex_mcp_proxy.daemon.privilege.sys") as mock_sys,
            patch("vloex_mcp_proxy.daemon.privilege.os") as mock_os,
        ):
            mock_sys.platform = "darwin"
            mock_sys.stderr = MagicMock()
            mock_os.getuid.return_value = 1000

            result = drop_privileges("_vloex")

            assert result is False
            mock_os.setgid.assert_not_called()
            mock_os.setuid.assert_not_called()

    def test_skips_on_windows(self) -> None:
        """Windows: skip, return False."""
        with patch("vloex_mcp_proxy.daemon.privilege.sys") as mock_sys:
            mock_sys.platform = "win32"
            mock_sys.stderr = MagicMock()

            result = drop_privileges("_vloex")

            assert result is False

    def test_skips_when_user_not_found(self) -> None:
        """User not found (KeyError): skip, return False."""
        mock_pwd = types.ModuleType("pwd")
        mock_pwd.getpwnam = MagicMock(side_effect=KeyError("_vloex"))

        with (
            patch("vloex_mcp_proxy.daemon.privilege.sys") as mock_sys,
            patch("vloex_mcp_proxy.daemon.privilege.os") as mock_os,
            patch.dict("sys.modules", {"pwd": mock_pwd}),
        ):
            mock_sys.platform = "darwin"
            mock_sys.stderr = MagicMock()
            mock_os.getuid.return_value = 0

            result = drop_privileges("_vloex")

            assert result is False
            mock_os.setgid.assert_not_called()
            mock_os.setuid.assert_not_called()

    def test_skips_when_already_correct_user(self) -> None:
        """Already running as target user: skip, return False."""
        mock_pw = MagicMock()
        mock_pw.pw_uid = 0  # Same as getuid()
        mock_pw.pw_gid = 0

        mock_pwd = MagicMock()
        mock_pwd.getpwnam.return_value = mock_pw

        with (
            patch("vloex_mcp_proxy.daemon.privilege.sys") as mock_sys,
            patch("vloex_mcp_proxy.daemon.privilege.os") as mock_os,
            patch.dict("sys.modules", {"pwd": mock_pwd}),
        ):
            mock_sys.platform = "darwin"
            mock_sys.stderr = MagicMock()
            mock_os.getuid.return_value = 0

            result = drop_privileges("root")

            assert result is False
            mock_os.setgid.assert_not_called()
            mock_os.setuid.assert_not_called()
