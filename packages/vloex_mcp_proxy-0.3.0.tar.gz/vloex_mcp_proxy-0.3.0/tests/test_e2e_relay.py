"""End-to-end tests for the MCP proxy relay.

These tests spawn a real child process and relay messages through the proxy
components, verifying full round-trip behavior.
"""

from __future__ import annotations

import asyncio
import json
import sys

from vloex_mcp_proxy.proxy.child_process import shutdown_server, spawn_server
from vloex_mcp_proxy.proxy.interceptor import Direction, Interceptor
from vloex_mcp_proxy.proxy.stdio_relay import relay_stream

# Echo server: reads lines from stdin, writes them to stdout
ECHO_SERVER_SCRIPT = """\
import sys
for line in sys.stdin:
    sys.stdout.write(line)
    sys.stdout.flush()
"""

# Crash server: exits immediately with code 1
CRASH_SERVER_SCRIPT = """\
import sys
sys.exit(1)
"""


class MockWriter:
    """A mock StreamWriter that captures written bytes."""

    def __init__(self) -> None:
        self.buffer = bytearray()

    def write(self, data: bytes) -> None:
        """Write data to buffer."""
        self.buffer.extend(data)

    async def drain(self) -> None:
        """No-op drain."""


async def test_e2e_echo_relay() -> None:
    """Proxy with Python echo script as server: send message, receive same back."""
    # Spawn echo server
    managed = await spawn_server(sys.executable, ["-c", ECHO_SERVER_SCRIPT])
    interceptor = Interceptor("echo-test")
    output_writer = MockWriter()

    # Create a reader with our test message
    input_reader = asyncio.StreamReader()
    msg = json.dumps({"jsonrpc": "2.0", "method": "tools/list", "id": 1}).encode() + b"\n"
    input_reader.feed_data(msg)
    input_reader.feed_eof()

    # Relay client->server
    await relay_stream(
        reader=input_reader,
        writer=managed.stdin,
        interceptor=interceptor,
        direction=Direction.CLIENT_TO_SERVER,
        label="test client->server",
    )

    # Close server stdin to signal EOF — server will write responses then exit
    managed.stdin.close()
    await managed.stdin.wait_closed()

    # Relay server->client (read the echo response)
    await relay_stream(
        reader=managed.stdout,
        writer=output_writer,
        interceptor=interceptor,
        direction=Direction.SERVER_TO_CLIENT,
        label="test server->client",
    )

    # Verify the message was echoed back
    output = bytes(output_writer.buffer)
    assert output.strip(), "No output received from echo server"
    parsed = json.loads(output.strip())
    assert parsed["method"] == "tools/list"
    assert parsed["id"] == 1

    await shutdown_server(managed, timeout=2.0)


async def test_e2e_multiple_messages() -> None:
    """Send 5 messages through echo server, all relayed correctly in order."""
    managed = await spawn_server(sys.executable, ["-c", ECHO_SERVER_SCRIPT])
    interceptor = Interceptor("echo-multi-test")
    output_writer = MockWriter()

    # Feed 5 messages
    input_reader = asyncio.StreamReader()
    sent_messages = []
    for i in range(5):
        msg = {"jsonrpc": "2.0", "method": f"test/method_{i}", "id": i + 1}
        sent_messages.append(msg)
        input_reader.feed_data(json.dumps(msg).encode() + b"\n")
    input_reader.feed_eof()

    # Relay client->server
    await relay_stream(
        reader=input_reader,
        writer=managed.stdin,
        interceptor=interceptor,
        direction=Direction.CLIENT_TO_SERVER,
        label="test client->server",
    )

    managed.stdin.close()
    await managed.stdin.wait_closed()

    # Relay server->client
    await relay_stream(
        reader=managed.stdout,
        writer=output_writer,
        interceptor=interceptor,
        direction=Direction.SERVER_TO_CLIENT,
        label="test server->client",
    )

    # Verify all 5 messages came back in order
    output_lines = [line for line in bytes(output_writer.buffer).split(b"\n") if line.strip()]
    assert len(output_lines) == 5, f"Expected 5 messages, got {len(output_lines)}"

    for i, line in enumerate(output_lines):
        parsed = json.loads(line)
        assert parsed["method"] == f"test/method_{i}"
        assert parsed["id"] == i + 1

    await shutdown_server(managed, timeout=2.0)


async def test_e2e_server_crash() -> None:
    """Server process exits immediately, proxy detects and shuts down cleanly."""
    managed = await spawn_server(sys.executable, ["-c", CRASH_SERVER_SCRIPT])
    interceptor = Interceptor("crash-test")
    output_writer = MockWriter()

    # Wait a moment for the server to exit
    await asyncio.sleep(0.1)

    # Relay server->client should detect EOF quickly
    await relay_stream(
        reader=managed.stdout,
        writer=output_writer,
        interceptor=interceptor,
        direction=Direction.SERVER_TO_CLIENT,
        label="test server->client",
    )

    # Server should have exited with code 1
    exit_code = await managed.process.wait()
    assert exit_code == 1

    # No output from crashed server
    assert len(output_writer.buffer) == 0


async def test_e2e_interceptor_tracks_through_relay() -> None:
    """Interceptor properly tracks requests through the full relay chain."""
    managed = await spawn_server(sys.executable, ["-c", ECHO_SERVER_SCRIPT])
    interceptor = Interceptor("tracking-test")
    output_writer = MockWriter()

    # Send a tools/call request
    input_reader = asyncio.StreamReader()
    request = {"jsonrpc": "2.0", "method": "tools/call", "params": {"name": "test"}, "id": 42}
    input_reader.feed_data(json.dumps(request).encode() + b"\n")
    input_reader.feed_eof()

    # Relay client->server (should track the request)
    await relay_stream(
        reader=input_reader,
        writer=managed.stdin,
        interceptor=interceptor,
        direction=Direction.CLIENT_TO_SERVER,
        label="test client->server",
    )

    # The echo server echoes the request back (treating it as a "response" from server)
    # Close stdin to get the response
    managed.stdin.close()
    await managed.stdin.wait_closed()

    # Since echo returns the same message (a request), the server->client relay
    # will see it as a request from the server, not a response
    # This is expected — echo doesn't convert requests to responses
    await relay_stream(
        reader=managed.stdout,
        writer=output_writer,
        interceptor=interceptor,
        direction=Direction.SERVER_TO_CLIENT,
        label="test server->client",
    )

    # Verify message was forwarded
    output = bytes(output_writer.buffer)
    assert output.strip()
    parsed = json.loads(output.strip())
    assert parsed["method"] == "tools/call"
    assert parsed["id"] == 42

    await shutdown_server(managed, timeout=2.0)


# ── M2 E2E tests ──────────────────────────────────────────────────


async def test_e2e_block_ssn_in_tool_call(block_ssn_policy_file: str) -> None:
    """Send tools/call with SSN through proxy with block policy.

    Client receives JSON-RPC error; server NEVER gets the message.
    """
    managed = await spawn_server(sys.executable, ["-c", ECHO_SERVER_SCRIPT])
    interceptor = Interceptor("block-test", policy_file=block_ssn_policy_file)
    output_writer = MockWriter()
    client_output = MockWriter()

    input_reader = asyncio.StreamReader()
    msg = (
        json.dumps(
            {
                "jsonrpc": "2.0",
                "method": "tools/call",
                "params": {
                    "name": "query_db",
                    "arguments": {"sql": "SELECT * FROM users WHERE ssn='123-45-6789'"},
                },
                "id": 1,
            }
        ).encode()
        + b"\n"
    )
    input_reader.feed_data(msg)
    input_reader.feed_eof()

    # Relay client->server with client_output as writer.
    # When blocked, the override is written to the writer (simulating client response).
    await relay_stream(
        reader=input_reader,
        writer=client_output,
        interceptor=interceptor,
        direction=Direction.CLIENT_TO_SERVER,
        label="test client->server",
    )

    # Client should receive JSON-RPC error
    output = bytes(client_output.buffer)
    assert output.strip(), "Block should produce error response"
    parsed = json.loads(output.strip())
    assert "error" in parsed
    assert "Vloex" in parsed["error"]["message"]
    assert "pii_ssn" in parsed["error"]["message"]

    # Server should NOT have received anything
    managed.stdin.close()
    await managed.stdin.wait_closed()

    await relay_stream(
        reader=managed.stdout,
        writer=output_writer,
        interceptor=interceptor,
        direction=Direction.SERVER_TO_CLIENT,
        label="test server->client",
    )
    assert len(output_writer.buffer) == 0

    await shutdown_server(managed, timeout=2.0)


async def test_e2e_redact_email_in_tool_call(redact_email_policy_file: str) -> None:
    """Send tools/call with email through proxy with redact policy.

    Server receives redacted arguments.
    """
    managed = await spawn_server(sys.executable, ["-c", ECHO_SERVER_SCRIPT])
    interceptor = Interceptor("redact-test", policy_file=redact_email_policy_file)
    output_writer = MockWriter()

    input_reader = asyncio.StreamReader()
    msg = (
        json.dumps(
            {
                "jsonrpc": "2.0",
                "method": "tools/call",
                "params": {
                    "name": "send_email",
                    "arguments": {"to": "john@test.com", "body": "Hello"},
                },
                "id": 1,
            }
        ).encode()
        + b"\n"
    )
    input_reader.feed_data(msg)
    input_reader.feed_eof()

    await relay_stream(
        reader=input_reader,
        writer=managed.stdin,
        interceptor=interceptor,
        direction=Direction.CLIENT_TO_SERVER,
        label="test client->server",
    )

    managed.stdin.close()
    await managed.stdin.wait_closed()

    await relay_stream(
        reader=managed.stdout,
        writer=output_writer,
        interceptor=interceptor,
        direction=Direction.SERVER_TO_CLIENT,
        label="test server->client",
    )

    output = bytes(output_writer.buffer)
    assert output.strip(), "No output received from echo server"
    parsed = json.loads(output.strip())
    raw_str = json.dumps(parsed)
    assert "john@test.com" not in raw_str
    assert "[REDACTED:pii_email]" in raw_str

    await shutdown_server(managed, timeout=2.0)


async def test_e2e_no_policy_passthrough() -> None:
    """Send tools/call with SSN but NO policy file → passes through unchanged."""
    managed = await spawn_server(sys.executable, ["-c", ECHO_SERVER_SCRIPT])
    interceptor = Interceptor("passthrough-test")
    output_writer = MockWriter()

    input_reader = asyncio.StreamReader()
    original_msg = {
        "jsonrpc": "2.0",
        "method": "tools/call",
        "params": {
            "name": "query_db",
            "arguments": {"sql": "SELECT * FROM users WHERE ssn='123-45-6789'"},
        },
        "id": 1,
    }
    msg = json.dumps(original_msg).encode() + b"\n"
    input_reader.feed_data(msg)
    input_reader.feed_eof()

    await relay_stream(
        reader=input_reader,
        writer=managed.stdin,
        interceptor=interceptor,
        direction=Direction.CLIENT_TO_SERVER,
        label="test client->server",
    )

    managed.stdin.close()
    await managed.stdin.wait_closed()

    await relay_stream(
        reader=managed.stdout,
        writer=output_writer,
        interceptor=interceptor,
        direction=Direction.SERVER_TO_CLIENT,
        label="test server->client",
    )

    output = bytes(output_writer.buffer)
    assert output.strip()
    parsed = json.loads(output.strip())
    assert "123-45-6789" in json.dumps(parsed)

    await shutdown_server(managed, timeout=2.0)
