"""Tests for the stdio relay loop."""

from __future__ import annotations

import asyncio
import json

from vloex_mcp_proxy.proxy.interceptor import Direction, Interceptor
from vloex_mcp_proxy.proxy.stdio_relay import relay_stream


class MockWriter:
    """A mock StreamWriter that captures written bytes."""

    def __init__(self) -> None:
        self.buffer = bytearray()

    def write(self, data: bytes) -> None:
        """Write data to buffer."""
        self.buffer.extend(data)

    async def drain(self) -> None:
        """No-op drain."""


async def test_relay_single_message() -> None:
    """One message relayed from reader to writer correctly."""
    reader = asyncio.StreamReader()
    writer = MockWriter()
    interceptor = Interceptor("test-server")

    msg = json.dumps({"jsonrpc": "2.0", "method": "tools/list", "id": 1}).encode() + b"\n"
    reader.feed_data(msg)
    reader.feed_eof()

    await relay_stream(reader, writer, interceptor, Direction.CLIENT_TO_SERVER, "test")

    # Verify the message was forwarded
    output = bytes(writer.buffer)
    parsed = json.loads(output.strip())
    assert parsed["method"] == "tools/list"
    assert parsed["id"] == 1


async def test_relay_preserves_order() -> None:
    """Multiple messages relayed in order."""
    reader = asyncio.StreamReader()
    writer = MockWriter()
    interceptor = Interceptor("test-server")

    messages = []
    for i in range(5):
        msg = {"jsonrpc": "2.0", "method": f"method_{i}", "id": i}
        messages.append(msg)
        reader.feed_data(json.dumps(msg).encode() + b"\n")
    reader.feed_eof()

    await relay_stream(reader, writer, interceptor, Direction.CLIENT_TO_SERVER, "test")

    # Parse all output lines
    output_lines = bytes(writer.buffer).strip().split(b"\n")
    assert len(output_lines) == 5

    for i, line in enumerate(output_lines):
        parsed = json.loads(line)
        assert parsed["method"] == f"method_{i}"
        assert parsed["id"] == i


async def test_relay_handles_eof() -> None:
    """Reader at EOF -> relay function returns cleanly."""
    reader = asyncio.StreamReader()
    writer = MockWriter()
    interceptor = Interceptor("test-server")

    # Immediately signal EOF
    reader.feed_eof()

    # This should return without error
    await relay_stream(reader, writer, interceptor, Direction.CLIENT_TO_SERVER, "test")

    # No data written
    assert len(writer.buffer) == 0


async def test_relay_skips_empty_lines() -> None:
    """Empty lines between messages are skipped."""
    reader = asyncio.StreamReader()
    writer = MockWriter()
    interceptor = Interceptor("test-server")

    msg = json.dumps({"jsonrpc": "2.0", "method": "tools/list", "id": 1}).encode()
    reader.feed_data(b"\n\n")
    reader.feed_data(msg + b"\n")
    reader.feed_data(b"\n")
    reader.feed_eof()

    await relay_stream(reader, writer, interceptor, Direction.CLIENT_TO_SERVER, "test")

    output_lines = [line for line in bytes(writer.buffer).split(b"\n") if line.strip()]
    assert len(output_lines) == 1
    parsed = json.loads(output_lines[0])
    assert parsed["method"] == "tools/list"


async def test_relay_large_message() -> None:
    """Messages larger than 64KB are relayed without crashing.

    The default asyncio StreamReader limit is 64KB. Our proxy uses 16MB.
    """
    from vloex_mcp_proxy.proxy.child_process import STREAM_BUFFER_LIMIT

    reader = asyncio.StreamReader(limit=STREAM_BUFFER_LIMIT)
    writer = MockWriter()
    interceptor = Interceptor("test-server")

    # Create a message with a ~100KB payload (well over default 64KB limit)
    big_content = "x" * 100_000
    msg = (
        json.dumps(
            {
                "jsonrpc": "2.0",
                "method": "tools/call",
                "params": {"content": big_content},
                "id": 1,
            }
        ).encode()
        + b"\n"
    )
    assert len(msg) > 65536, "Test message should exceed default StreamReader limit"

    reader.feed_data(msg)
    reader.feed_eof()

    await relay_stream(reader, writer, interceptor, Direction.CLIENT_TO_SERVER, "test")

    output = bytes(writer.buffer)
    parsed = json.loads(output.strip())
    assert parsed["params"]["content"] == big_content


async def test_relay_forwards_invalid_json() -> None:
    """Invalid JSON is forwarded as-is (pass-through for non-parseable messages)."""
    reader = asyncio.StreamReader()
    writer = MockWriter()
    interceptor = Interceptor("test-server")

    invalid_data = b"this is not json at all\n"
    reader.feed_data(invalid_data)
    reader.feed_eof()

    await relay_stream(reader, writer, interceptor, Direction.CLIENT_TO_SERVER, "test")

    output = bytes(writer.buffer)
    assert b"this is not json at all" in output
