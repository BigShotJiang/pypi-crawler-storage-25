"""Tests for vloex_mcp_proxy.backend.config."""

from __future__ import annotations

import stat
from unittest.mock import patch

import jwt
import pytest

from vloex_mcp_proxy.backend.config import (
    clear_device_token,
    get_backend_url,
    get_device_token,
    get_enrollment_token_from_config,
    get_or_create_device_id,
    get_user_email_from_token,
    get_vloex_dir,
    save_device_token,
)
from vloex_mcp_proxy.packaging.enterprise_config import EnterpriseConfig


@pytest.fixture(autouse=True)
def _disable_keyring():
    """Disable keyring for all backend config tests to ensure file-based isolation via tmp_path."""
    with patch("vloex_mcp_proxy.backend.keychain._keyring_available", return_value=False):
        yield


class TestVloexDir:
    def test_creates_dir(self, tmp_path):
        d = tmp_path / "vloex"
        result = get_vloex_dir(d)
        assert result == d
        assert d.exists()

    def test_existing_dir(self, tmp_path):
        d = tmp_path / "vloex"
        d.mkdir()
        result = get_vloex_dir(d)
        assert result == d


class TestDeviceId:
    def test_creates_device_id(self, tmp_path):
        device_id = get_or_create_device_id(tmp_path)
        assert len(device_id) == 36  # UUID format
        assert (tmp_path / "device_id").exists()

    def test_persists_device_id(self, tmp_path):
        first = get_or_create_device_id(tmp_path)
        second = get_or_create_device_id(tmp_path)
        assert first == second

    def test_handles_empty_file(self, tmp_path):
        (tmp_path / "device_id").write_text("")
        device_id = get_or_create_device_id(tmp_path)
        assert len(device_id) == 36


class TestDeviceToken:
    def test_save_and_get(self, tmp_path):
        save_device_token("jwt-token-here", tmp_path)
        assert get_device_token(tmp_path) == "jwt-token-here"

    def test_not_enrolled(self, tmp_path):
        assert get_device_token(tmp_path) is None

    def test_clear(self, tmp_path):
        save_device_token("jwt-token", tmp_path)
        clear_device_token(tmp_path)
        assert get_device_token(tmp_path) is None

    def test_clear_nonexistent(self, tmp_path):
        # Should not raise
        clear_device_token(tmp_path)

    def test_file_permissions(self, tmp_path):
        save_device_token("secret", tmp_path)
        path = tmp_path / "device_token"
        mode = path.stat().st_mode
        # Check owner read/write only (0o600)
        assert stat.S_IMODE(mode) == 0o600


class TestBackendUrl:
    def test_from_env(self, monkeypatch):
        monkeypatch.setenv("VLOEX_BACKEND_URL", "http://localhost:8000")
        assert get_backend_url() == "http://localhost:8000"

    @patch(
        "vloex_mcp_proxy.packaging.enterprise_config.load_enterprise_config",
        return_value=EnterpriseConfig(),
    )
    def test_not_set(self, _mock_enterprise, monkeypatch):
        monkeypatch.delenv("VLOEX_BACKEND_URL", raising=False)
        assert get_backend_url() is None

    @patch(
        "vloex_mcp_proxy.packaging.enterprise_config.load_enterprise_config",
        return_value=EnterpriseConfig(),
    )
    def test_empty_string(self, _mock_enterprise, monkeypatch):
        monkeypatch.setenv("VLOEX_BACKEND_URL", "")
        assert get_backend_url() is None

    @patch(
        "vloex_mcp_proxy.packaging.enterprise_config.load_enterprise_config",
        return_value=EnterpriseConfig(backend_url="https://mdm.example.com"),
    )
    def test_enterprise_config_fallback(self, _mock_enterprise, monkeypatch):
        monkeypatch.delenv("VLOEX_BACKEND_URL", raising=False)
        assert get_backend_url() == "https://mdm.example.com"

    @patch(
        "vloex_mcp_proxy.packaging.enterprise_config.load_enterprise_config",
        return_value=EnterpriseConfig(backend_url="https://mdm.example.com"),
    )
    def test_env_var_takes_priority_over_enterprise(self, _mock_enterprise, monkeypatch):
        monkeypatch.setenv("VLOEX_BACKEND_URL", "https://env.example.com")
        assert get_backend_url() == "https://env.example.com"


class TestEnrollmentTokenFromConfig:
    @patch(
        "vloex_mcp_proxy.packaging.enterprise_config.load_enterprise_config",
        return_value=EnterpriseConfig(enrollment_token="tok_abc"),
    )
    def test_returns_token(self, _mock):
        assert get_enrollment_token_from_config() == "tok_abc"

    @patch(
        "vloex_mcp_proxy.packaging.enterprise_config.load_enterprise_config",
        return_value=EnterpriseConfig(),
    )
    def test_returns_none_when_empty(self, _mock):
        assert get_enrollment_token_from_config() is None


class TestUserEmailFromToken:
    def test_extract_user_email(self):
        token = jwt.encode(
            {"sub": "test-device", "user_email": "alice@corp.com"},
            "secret",
            algorithm="HS256",
        )
        assert get_user_email_from_token(token) == "alice@corp.com"

    def test_fallback_to_sub(self):
        token = jwt.encode({"sub": "alice@corp.com"}, "secret", algorithm="HS256")
        assert get_user_email_from_token(token) == "alice@corp.com"

    def test_invalid_token(self):
        assert get_user_email_from_token("not-a-jwt") is None

    def test_empty_token(self):
        assert get_user_email_from_token("") is None
