"""Tests for CLI enroll and status subcommands."""

from __future__ import annotations

import subprocess
import sys


class TestCLIEnroll:
    def test_enroll_no_code_no_token(self):
        """enroll without --code or --token should fail."""
        result = subprocess.run(
            [
                sys.executable,
                "-m",
                "vloex_mcp_proxy.cli",
                "enroll",
                "--backend-url",
                "http://test",
            ],
            capture_output=True,
            text=True,
        )
        assert result.returncode == 2
        assert "code" in result.stderr.lower() or "token" in result.stderr.lower()

    def test_enroll_help(self):
        result = subprocess.run(
            [sys.executable, "-m", "vloex_mcp_proxy.cli", "enroll", "--help"],
            capture_output=True,
            text=True,
        )
        assert result.returncode == 0
        assert "--code" in result.stdout
        assert "--token" in result.stdout
        assert "--backend-url" in result.stdout


class TestCLIStatus:
    def test_status_runs(self):
        """status should run and show Device ID."""
        result = subprocess.run(
            [sys.executable, "-m", "vloex_mcp_proxy.cli", "status"],
            capture_output=True,
            text=True,
        )
        assert result.returncode == 0
        assert "Device ID:" in result.stdout

    def test_status_help(self):
        result = subprocess.run(
            [sys.executable, "-m", "vloex_mcp_proxy.cli", "status", "--help"],
            capture_output=True,
            text=True,
        )
        assert result.returncode == 0


class TestCLIBackendUrl:
    def test_proxy_backend_url_flag(self):
        """--backend-url should be accepted by the proxy."""
        result = subprocess.run(
            [sys.executable, "-m", "vloex_mcp_proxy.cli", "--help"],
            capture_output=True,
            text=True,
        )
        assert result.returncode == 0
        assert "--backend-url" in result.stdout
