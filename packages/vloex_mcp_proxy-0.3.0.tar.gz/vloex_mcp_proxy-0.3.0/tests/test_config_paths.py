"""Tests for discovery/config_paths.py — known client registry + discovery."""

from __future__ import annotations

import json

from vloex_mcp_proxy.discovery.config_paths import (
    ConfigFormat,
    DiscoveredClient,
    discover_clients,
    get_known_clients,
)

# ---------------------------------------------------------------------------
# Registry filtering
# ---------------------------------------------------------------------------


class TestGetKnownClients:
    """Tests for get_known_clients() platform filtering."""

    def test_macos_clients(self) -> None:
        """Returns macOS clients when platform='macos'."""
        clients = get_known_clients(platform="macos")
        assert len(clients) > 0
        for c in clients:
            assert c.platform in ("all", "macos")

    def test_linux_clients(self) -> None:
        """Returns Linux clients when platform='linux'."""
        clients = get_known_clients(platform="linux")
        assert len(clients) > 0
        for c in clients:
            assert c.platform in ("all", "linux")

    def test_all_platform_included(self) -> None:
        """Clients with platform='all' appear for both macOS and Linux."""
        macos = get_known_clients(platform="macos")
        linux = get_known_clients(platform="linux")
        all_names_macos = {c.name for c in macos if c.platform == "all"}
        all_names_linux = {c.name for c in linux if c.platform == "all"}
        assert all_names_macos == all_names_linux
        assert len(all_names_macos) > 0

    def test_verified_and_unverified_present(self) -> None:
        """Registry has both verified=True and verified=False entries."""
        clients = get_known_clients(platform="macos")
        has_verified = any(c.verified for c in clients)
        has_unverified = any(not c.verified for c in clients)
        assert has_verified, "Expected at least one verified client"
        assert has_unverified, "Expected at least one unverified client"

    def test_known_clients_have_required_fields(self) -> None:
        """Every client has name, config_path, config_format."""
        for c in get_known_clients(platform="macos"):
            assert c.name, "Client must have a name"
            assert c.config_path, "Client must have a config_path"
            assert isinstance(c.config_format, ConfigFormat)


# ---------------------------------------------------------------------------
# Discovery
# ---------------------------------------------------------------------------


class TestDiscoverClients:
    """Tests for discover_clients() filesystem discovery."""

    def test_discover_finds_existing_config(self, tmp_path) -> None:
        """Create a temp Cursor config → discover_clients() finds it."""
        cursor_dir = tmp_path / ".cursor"
        cursor_dir.mkdir()
        config = {"mcpServers": {"fs": {"command": "npx", "args": ["-y", "foo"]}}}
        (cursor_dir / "mcp.json").write_text(json.dumps(config))

        discovered = discover_clients(config_dir_override=tmp_path, platform="macos")
        cursor_results = [d for d in discovered if d.client_name == "Cursor"]
        assert len(cursor_results) == 1
        assert "fs" in cursor_results[0].servers

    def test_discover_ignores_missing_config(self, tmp_path) -> None:
        """Known path doesn't exist → skipped, no crash."""
        discovered = discover_clients(config_dir_override=tmp_path, platform="macos")
        # Most paths won't exist in tmp_path — should return empty or only found ones
        # No crash is the main assertion
        assert isinstance(discovered, list)

    def test_discover_with_config_dir_override(self, tmp_path) -> None:
        """Override base dir → discovers files in override dir."""
        claude_dir = tmp_path / ".claude"
        claude_dir.mkdir()
        config = {"mcpServers": {"pg": {"command": "npx", "args": ["-y", "pg-server"]}}}
        (claude_dir / "mcp.json").write_text(json.dumps(config))

        discovered = discover_clients(config_dir_override=tmp_path, platform="macos")
        claude_results = [d for d in discovered if d.client_name == "Claude Code"]
        assert len(claude_results) == 1
        assert "pg" in claude_results[0].servers

    def test_discover_empty_when_no_configs(self, tmp_path) -> None:
        """No config files exist → returns empty list."""
        discovered = discover_clients(config_dir_override=tmp_path, platform="macos")
        assert discovered == []

    def test_discover_skips_invalid_json(self, tmp_path) -> None:
        """Invalid JSON config → skipped with no crash."""
        cursor_dir = tmp_path / ".cursor"
        cursor_dir.mkdir()
        (cursor_dir / "mcp.json").write_text("{invalid json!!!}")

        discovered = discover_clients(config_dir_override=tmp_path, platform="macos")
        cursor_results = [d for d in discovered if d.client_name == "Cursor"]
        assert len(cursor_results) == 0

    def test_discover_skips_project_level_configs(self, tmp_path) -> None:
        """Project-level configs (relative paths) are skipped."""
        # Cursor (project) has path ".cursor/mcp.json" — relative, should be skipped
        cursor_dir = tmp_path / ".cursor"
        cursor_dir.mkdir()
        config = {"mcpServers": {"fs": {"command": "npx", "args": []}}}
        (cursor_dir / "mcp.json").write_text(json.dumps(config))

        discovered = discover_clients(config_dir_override=tmp_path, platform="macos")
        # Should find Cursor (global) but NOT Cursor (project)
        project_results = [d for d in discovered if d.client_name == "Cursor (project)"]
        assert len(project_results) == 0

    def test_discovered_client_has_correct_fields(self, tmp_path) -> None:
        """DiscoveredClient has all required fields populated."""
        cursor_dir = tmp_path / ".cursor"
        cursor_dir.mkdir()
        config = {"mcpServers": {"fs": {"command": "cat", "args": ["/tmp"]}}}
        (cursor_dir / "mcp.json").write_text(json.dumps(config))

        discovered = discover_clients(config_dir_override=tmp_path, platform="macos")
        assert len(discovered) >= 1

        d = discovered[0]
        assert isinstance(d, DiscoveredClient)
        assert d.client_name
        assert d.config_path.exists()
        assert isinstance(d.config_format, ConfigFormat)
        assert isinstance(d.servers, dict)
        assert isinstance(d.verified, bool)
