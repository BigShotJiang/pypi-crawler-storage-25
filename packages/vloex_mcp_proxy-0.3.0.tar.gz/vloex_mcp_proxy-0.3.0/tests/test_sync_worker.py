"""Tests for vloex_mcp_proxy.backend.sync_worker."""

from __future__ import annotations

import asyncio
from unittest.mock import AsyncMock

import pytest

from vloex_mcp_proxy.backend.sync_worker import MAX_BACKOFF, MIN_BACKOFF, SyncWorker


@pytest.fixture
def mock_queue():
    q = AsyncMock()
    q.dequeue_batch = AsyncMock(return_value=[])
    q.mark_synced = AsyncMock()
    q.mark_failed = AsyncMock()
    return q


@pytest.fixture
def mock_client():
    c = AsyncMock()
    c.send_events_batch = AsyncMock(return_value=True)
    return c


class TestSyncWorker:
    async def test_sync_success_resets_backoff(self, mock_queue, mock_client):
        mock_queue.dequeue_batch = AsyncMock(
            side_effect=[
                [(1, {"event": "test"})],
                [],  # empty -> triggers sleep -> we stop
            ]
        )
        worker = SyncWorker(mock_queue, mock_client)
        worker._backoff = 30.0  # Simulate previous failures

        async def _stop_after():
            await asyncio.sleep(0.1)
            worker.stop()

        asyncio.get_event_loop().create_task(_stop_after())
        await worker.run()

        mock_client.send_events_batch.assert_called_once()
        mock_queue.mark_synced.assert_called_once_with([1])
        assert worker._backoff == MIN_BACKOFF

    async def test_sync_failure_doubles_backoff(self, mock_queue, mock_client):
        mock_client.send_events_batch = AsyncMock(return_value=False)
        mock_queue.dequeue_batch = AsyncMock(side_effect=[[(1, {"event": "fail"})], []])
        worker = SyncWorker(mock_queue, mock_client)
        initial_backoff = worker._backoff

        async def _stop_after():
            await asyncio.sleep(0.2)
            worker.stop()

        asyncio.get_event_loop().create_task(_stop_after())
        await worker.run()

        mock_queue.mark_failed.assert_called_once_with([1])
        assert worker._backoff == initial_backoff * 2

    async def test_sync_backoff_cap(self, mock_queue, mock_client):
        worker = SyncWorker(mock_queue, mock_client)
        worker._backoff = MAX_BACKOFF
        # Simulate a failure scenario -- backoff should not exceed MAX
        mock_client.send_events_batch = AsyncMock(return_value=False)
        mock_queue.dequeue_batch = AsyncMock(side_effect=[[(1, {"event": "fail"})], []])

        async def _stop_after():
            await asyncio.sleep(0.2)
            worker.stop()

        asyncio.get_event_loop().create_task(_stop_after())
        await worker.run()

        assert worker._backoff <= MAX_BACKOFF

    async def test_sync_empty_queue_no_http_call(self, mock_queue, mock_client):
        mock_queue.dequeue_batch = AsyncMock(return_value=[])
        worker = SyncWorker(mock_queue, mock_client)

        async def _stop_after():
            await asyncio.sleep(0.1)
            worker.stop()

        asyncio.get_event_loop().create_task(_stop_after())
        await worker.run()

        mock_client.send_events_batch.assert_not_called()

    async def test_stop(self, mock_queue, mock_client):
        worker = SyncWorker(mock_queue, mock_client)
        worker.stop()
        # run() should exit immediately when _running is already False
        assert worker._running is False
