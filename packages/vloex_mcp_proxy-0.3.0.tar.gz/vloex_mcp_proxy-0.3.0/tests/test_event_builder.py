"""Tests for vloex_mcp_proxy.backend.event_builder."""

from __future__ import annotations

from vloex_mcp_proxy.backend.event_builder import build_event
from vloex_mcp_proxy.scanner.sensitive import Detection, SensitiveDataType


class TestBuildEvent:
    def test_basic_fields(self):
        event = build_event(
            server_name="filesystem",
            method="tools/call",
            tool_name="read_file",
            arguments_text='{"path": "/tmp/test.txt"}',
            result_text="file contents here",
            detections=[],
            policy_action="allow",
            device_id="dev-001",
        )
        assert event["capture_method"] == "mcp"
        assert event["provider_name"] == "filesystem"
        assert event["service"] == "mcp"
        assert event["interaction_type"] == "tool_call"
        assert event["device_id"] == "dev-001"
        assert event["prompt_text"] == '{"path": "/tmp/test.txt"}'
        assert event["response_text"] == "file contents here"

    def test_capture_method_always_mcp(self):
        event = build_event(
            server_name="github",
            method="tools/call",
            tool_name="create_issue",
            arguments_text="{}",
            result_text=None,
            detections=[],
            policy_action="allow",
            device_id="dev-001",
        )
        assert event["capture_method"] == "mcp"

    def test_with_detections(self):
        detections = [
            Detection(
                data_type=SensitiveDataType.PII_SSN,
                confidence=1.0,
                count=1,
            ),
            Detection(
                data_type=SensitiveDataType.PII_EMAIL,
                confidence=1.0,
                count=2,
            ),
        ]
        event = build_event(
            server_name="db-server",
            method="tools/call",
            tool_name="query",
            arguments_text="SELECT * WHERE ssn='123-45-6789'",
            result_text=None,
            detections=detections,
            policy_action="block",
            device_id="dev-001",
        )
        assert len(event["sensitive_data"]) == 2
        assert event["sensitive_data"][0]["data_type"] == "pii_ssn"
        assert event["risk_score"] == 6.0  # 2 detections * 3.0

    def test_metadata(self):
        event = build_event(
            server_name="filesystem",
            method="tools/call",
            tool_name="read_file",
            arguments_text=None,
            result_text=None,
            detections=[],
            policy_action="allow",
            device_id="dev-001",
        )
        assert event["metadata"]["mcp_server_name"] == "filesystem"
        assert event["metadata"]["mcp_tool_name"] == "read_file"
        assert event["metadata"]["mcp_method"] == "tools/call"

    def test_no_detections_zero_risk(self):
        event = build_event(
            server_name="test",
            method="tools/call",
            tool_name="test_tool",
            arguments_text="hello",
            result_text=None,
            detections=[],
            policy_action="allow",
            device_id="dev-001",
        )
        assert event["risk_score"] == 0.0
        assert event["sensitive_data"] == []

    def test_user_email_and_department(self):
        event = build_event(
            server_name="test",
            method="tools/call",
            tool_name="tool",
            arguments_text=None,
            result_text=None,
            detections=[],
            policy_action="allow",
            device_id="dev-001",
            user_email="alice@corp.com",
            department="Engineering",
        )
        assert event["user_email"] == "alice@corp.com"
        assert event["department"] == "Engineering"

    def test_event_id_is_uuid(self):
        event = build_event(
            server_name="test",
            method="tools/call",
            tool_name="tool",
            arguments_text=None,
            result_text=None,
            detections=[],
            policy_action="allow",
            device_id="dev-001",
        )
        assert len(event["event_id"]) == 36
        assert event["event_id"].count("-") == 4

    def test_risk_score_cap(self):
        """Risk score should be capped at 10.0."""
        detections = [
            Detection(data_type=SensitiveDataType.PII_SSN, confidence=1.0, count=1),
            Detection(data_type=SensitiveDataType.PII_EMAIL, confidence=1.0, count=1),
            Detection(data_type=SensitiveDataType.PII_PHONE, confidence=0.8, count=1),
            Detection(data_type=SensitiveDataType.CREDENTIALS_API_KEY, confidence=1.0, count=1),
        ]
        event = build_event(
            server_name="test",
            method="tools/call",
            tool_name="tool",
            arguments_text="data",
            result_text=None,
            detections=detections,
            policy_action="block",
            device_id="dev-001",
        )
        assert event["risk_score"] == 10.0  # 4 * 3.0 = 12.0, capped at 10.0
