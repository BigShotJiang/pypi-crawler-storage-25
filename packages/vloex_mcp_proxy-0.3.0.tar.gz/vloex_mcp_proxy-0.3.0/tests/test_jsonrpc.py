"""Tests for JSON-RPC 2.0 message parser and constructor."""

from __future__ import annotations

import json

from vloex_mcp_proxy.proxy.jsonrpc import (
    MessageType,
    make_error_response,
    make_success_response,
    parse_message,
)


def test_parse_valid_request(sample_request: bytes) -> None:
    """Parses request, extracts method, id, params."""
    msg = parse_message(sample_request)
    assert msg.msg_type == MessageType.REQUEST
    assert msg.method == "tools/call"
    assert msg.msg_id == 1
    assert msg.params is not None
    assert msg.params["name"] == "read_file"
    assert msg.params["arguments"]["path"] == "/tmp/test"


def test_parse_valid_notification(sample_notification: bytes) -> None:
    """Parses notification, method set, id is None."""
    msg = parse_message(sample_notification)
    assert msg.msg_type == MessageType.NOTIFICATION
    assert msg.method == "notifications/initialized"
    assert msg.msg_id is None


def test_parse_valid_response(sample_response: bytes) -> None:
    """Parses response, extracts result and id."""
    msg = parse_message(sample_response)
    assert msg.msg_type == MessageType.RESPONSE
    assert msg.msg_id == 1
    assert msg.result == {"tools": [{"name": "read_file"}]}


def test_parse_error_response(sample_error_response: bytes) -> None:
    """Parses error response, extracts error and id."""
    msg = parse_message(sample_error_response)
    assert msg.msg_type == MessageType.ERROR_RESPONSE
    assert msg.msg_id == 1
    assert msg.error is not None
    assert msg.error["code"] == -32600
    assert msg.error["message"] == "Invalid request"


def test_parse_batch(sample_batch: bytes) -> None:
    """Parses batch, returns list of sub-messages."""
    msg = parse_message(sample_batch)
    assert msg.msg_type == MessageType.BATCH
    assert len(msg.batch) == 2
    assert msg.batch[0].msg_type == MessageType.REQUEST
    assert msg.batch[0].method == "tools/list"
    assert msg.batch[0].msg_id == 1
    assert msg.batch[1].msg_type == MessageType.REQUEST
    assert msg.batch[1].method == "tools/list"
    assert msg.batch[1].msg_id == 2


def test_parse_invalid_json() -> None:
    """Invalid bytes -> INVALID type, raw preserved."""
    data = b"not valid json at all\n"
    msg = parse_message(data)
    assert msg.msg_type == MessageType.INVALID
    assert msg.raw == data


def test_parse_empty_object() -> None:
    """{} -> INVALID type (missing required fields)."""
    data = json.dumps({}).encode()
    msg = parse_message(data)
    assert msg.msg_type == MessageType.INVALID


def test_parse_preserves_raw_bytes(sample_request: bytes) -> None:
    """raw field contains exact original bytes."""
    msg = parse_message(sample_request)
    assert msg.raw == sample_request


def test_parse_string_id() -> None:
    """id: 'abc-123' -> msg_id is string, not int."""
    data = json.dumps(
        {
            "jsonrpc": "2.0",
            "method": "tools/list",
            "id": "abc-123",
        }
    ).encode()
    msg = parse_message(data)
    assert msg.msg_type == MessageType.REQUEST
    assert msg.msg_id == "abc-123"
    assert isinstance(msg.msg_id, str)


def test_parse_numeric_id() -> None:
    """id: 42 -> msg_id is int."""
    data = json.dumps(
        {
            "jsonrpc": "2.0",
            "method": "tools/call",
            "params": {"name": "test"},
            "id": 42,
        }
    ).encode()
    msg = parse_message(data)
    assert msg.msg_type == MessageType.REQUEST
    assert msg.msg_id == 42
    assert isinstance(msg.msg_id, int)


def test_make_error_response() -> None:
    """Constructs valid JSON-RPC error, newline-terminated."""
    result = make_error_response(1, -32600, "Invalid request")
    assert result.endswith(b"\n")
    parsed = json.loads(result)
    assert parsed["jsonrpc"] == "2.0"
    assert parsed["error"]["code"] == -32600
    assert parsed["error"]["message"] == "Invalid request"
    assert parsed["id"] == 1


def test_make_success_response() -> None:
    """Constructs valid JSON-RPC success, newline-terminated."""
    result = make_success_response(42, {"tools": [{"name": "read_file"}]})
    assert result.endswith(b"\n")
    parsed = json.loads(result)
    assert parsed["jsonrpc"] == "2.0"
    assert parsed["result"] == {"tools": [{"name": "read_file"}]}
    assert parsed["id"] == 42


def test_parse_response_with_null_result() -> None:
    """Response with result: null is valid."""
    data = json.dumps(
        {
            "jsonrpc": "2.0",
            "result": None,
            "id": 5,
        }
    ).encode()
    msg = parse_message(data)
    # result key exists but value is None — still has "result" key
    assert msg.msg_type == MessageType.RESPONSE
    assert msg.msg_id == 5
    assert msg.result is None


def test_batch_sub_messages_have_individual_raw() -> None:
    """Each sub-message in a batch has its own raw bytes, not the whole batch."""
    batch_data = json.dumps(
        [
            {"jsonrpc": "2.0", "method": "tools/list", "id": 1},
            {"jsonrpc": "2.0", "method": "tools/call", "id": 2},
        ]
    ).encode()
    msg = parse_message(batch_data)
    assert msg.msg_type == MessageType.BATCH

    # Each sub-message's raw should be its own serialized JSON, not the whole batch
    for sub_msg in msg.batch:
        parsed_sub = json.loads(sub_msg.raw)
        assert isinstance(parsed_sub, dict)  # NOT a list (the batch)
        assert "method" in parsed_sub

    # Verify they're different from each other
    assert msg.batch[0].raw != msg.batch[1].raw

    # Verify the top-level raw IS the whole batch
    assert msg.raw == batch_data


def test_batch_non_dict_items_are_invalid() -> None:
    """Non-dict items in a batch are classified as INVALID, not crash."""
    batch_data = json.dumps(
        [
            {"jsonrpc": "2.0", "method": "tools/list", "id": 1},
            "not a dict",
            42,
            None,
        ]
    ).encode()
    msg = parse_message(batch_data)
    assert msg.msg_type == MessageType.BATCH
    assert len(msg.batch) == 4
    assert msg.batch[0].msg_type == MessageType.REQUEST
    assert msg.batch[1].msg_type == MessageType.INVALID
    assert msg.batch[2].msg_type == MessageType.INVALID
    assert msg.batch[3].msg_type == MessageType.INVALID


def test_parse_notification_with_params() -> None:
    """Notification with params is parsed correctly."""
    data = json.dumps(
        {
            "jsonrpc": "2.0",
            "method": "notifications/progress",
            "params": {"token": "abc", "value": 50},
        }
    ).encode()
    msg = parse_message(data)
    assert msg.msg_type == MessageType.NOTIFICATION
    assert msg.method == "notifications/progress"
    assert msg.params == {"token": "abc", "value": 50}
    assert msg.msg_id is None
