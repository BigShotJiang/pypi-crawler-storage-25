from __future__ import annotations

from abc import abstractmethod
from collections.abc import Mapping
from enum import Enum
from typing import Any, Generic, Literal, Protocol, overload, runtime_checkable

from typing_extensions import TypedDict, TypeVar

from ..observable import Observable
from .base import Sensor, SensorCategory, SensorLike, SensorType
from .motion import Detection, VideoFrameData
from .spec import ModelSpec


class ClassifierProperty(str, Enum):
    """Properties for classifier sensors."""

    Detected = "detected"
    Detections = "detections"
    Labels = "labels"


class ClassifierDetection(Detection):
    """A classifier detection result with open attribute for classifier categories."""

    attribute: str  # type: ignore[misc]  # open for classifier (bird, delivery, etc.)
    subAttribute: str  # e.g., "woodpecker", "amazon"


class ClassifierSensorProperties(TypedDict):
    detected: bool
    detections: list[ClassifierDetection]
    labels: list[str]


class ClassifierPropertyChangeData(TypedDict):
    """Emitted on ClassifierSensorLike.onPropertyChanged."""

    property: str  # ClassifierProperty value
    value: bool | list[ClassifierDetection] | list[str]


TStorage = TypeVar("TStorage", bound=Mapping[str, Any], default=dict[str, Any])


@runtime_checkable
class ClassifierSensorLike(SensorLike, Protocol):
    """Read-only proxy interface for a classifier sensor."""

    @property
    def type(self) -> SensorType:
        return SensorType.Classifier

    @overload
    def getPropertyValue(self, property: Literal[ClassifierProperty.Detected]) -> bool | None: ...
    @overload
    def getPropertyValue(
        self, property: Literal[ClassifierProperty.Detections]
    ) -> list[ClassifierDetection] | None: ...
    @overload
    def getPropertyValue(self, property: Literal[ClassifierProperty.Labels]) -> list[str] | None: ...
    @overload
    def getPropertyValue(self, property: str) -> object | None: ...

    @property
    def onPropertyChanged(self) -> Observable[ClassifierPropertyChangeData]: ...


class ClassifierSensor(Sensor[ClassifierSensorProperties, TStorage, str], Generic[TStorage]):
    """General-purpose image classifier sensor. Setting detections auto-updates labels."""

    _requires_frames = False

    def __init__(self, name: str = "Classifier") -> None:
        super().__init__(name)
        self.props.detected = False
        self.props.detections = []
        self.props.labels = []

    @property
    def type(self) -> SensorType:
        return SensorType.Classifier

    @property
    def category(self) -> SensorCategory:
        return SensorCategory.Sensor

    @property
    def detected(self) -> bool:
        return self.props.detected  # type: ignore[no-any-return]

    @detected.setter
    def detected(self, value: bool) -> None:
        self.props.detected = value

    @property
    def detections(self) -> list[ClassifierDetection]:
        return self.props.detections  # type: ignore[no-any-return]

    @detections.setter
    def detections(self, value: list[ClassifierDetection]) -> None:
        self.props.detections = value
        labels = list({d["label"] for d in value})
        self.props.labels = labels

    @property
    def labels(self) -> list[str]:
        return self.props.labels  # type: ignore[no-any-return]

    @labels.setter
    def labels(self, value: list[str]) -> None:
        self.props.labels = value


class ClassifierResult(TypedDict):
    """Return type for ClassifierDetectorSensor.classify()."""

    detected: bool
    detections: list[ClassifierDetection]


class ClassifierDetectorSensor(ClassifierSensor[TStorage], Generic[TStorage]):
    """Classifier detector that receives video frames. Implement classify() to run classification models."""

    _requires_frames = True

    @property
    @abstractmethod
    def modelSpec(self) -> ModelSpec:
        """Declares expected input dimensions and output labels. The backend scales frames to match."""
        ...

    @abstractmethod
    async def classify(
        self, frame: VideoFrameData, triggerRegions: list[Detection] | None = None
    ) -> ClassifierResult:
        """Classify a video frame. Called by the backend at the configured interval."""
        ...
