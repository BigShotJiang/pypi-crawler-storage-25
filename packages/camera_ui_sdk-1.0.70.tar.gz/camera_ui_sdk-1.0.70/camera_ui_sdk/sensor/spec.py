from __future__ import annotations

from typing import Literal, NotRequired

from typing_extensions import TypedDict


class VideoInputSpec(TypedDict):
    """Expected video input dimensions and format for a detector model."""

    width: int
    height: int
    format: Literal["rgb", "nv12", "gray"]


class ObjectModelSpec(TypedDict):
    """Model spec for object detectors (input dimensions only, labels are dynamic)."""

    input: VideoInputSpec


class ModelSpec(TypedDict):
    """Model spec for detectors with fixed output labels (face, classifier, license plate)."""

    input: VideoInputSpec
    triggerLabels: list[str]
    embeddingModel: NotRequired[str]


class EmbeddingModels:
    ARCFACE_MOBILEFACENET_128 = "arcface-mobilefacenet-128"
    ARCFACE_R100_512 = "arcface-r100-512"
    FACENET_INCEPTION_128 = "facenet-inceptionresnetv1-128"
    FACENET_INCEPTION_512 = "facenet-inceptionresnetv1-512"
    ADAFACE_R100_512 = "adaface-r100-512"


class AudioInputSpec(TypedDict):
    """Expected audio input format for an audio detector model."""

    sampleRate: int
    channels: int
    format: Literal["pcm16", "float32"]
    samplesPerFrame: NotRequired[int]


class AudioModelSpec(TypedDict):
    """Model spec for audio detectors."""

    input: AudioInputSpec
