import os, jsonpickle
from http import HTTPMethod

from fmconsult.http.api import ApiBase
from fmconsult.utils.url import UrlUtil

class SoulMVSyncLinkApi(ApiBase):

  def __init__(self):
    try:
      self.api_tenant_id = os.environ['soulmv.synclink.api.tenant.id']
      self.api_user = os.environ['soulmv.synclink.api.user']

      self.base_url = 'https://mv-sync-link.use77seg.com.br/synclink-ehr-service'
      self.headers = {
        'X-Tenant-ID': self.api_tenant_id
      }

      self.__login()
    except:
      raise
  def __login(self):
    try:
      res = self.call_request(
        http_method = HTTPMethod.POST, 
        request_url = UrlUtil().make_url(self.base_url, ['auth','login']), 
        payload = {
          'user': self.api_user
        }
      )
      res = jsonpickle.decode(res)
      if res.get('status') == 200:
        self.token_type = res.get('data').get('token_type')
        self.access_token = res.get('data').get('access_token')
        self.refresh_token = res.get('data').get('refresh_token')
        self.headers['Authorization'] = f'{self.token_type} {self.access_token}'
      else:
        raise Exception(res.get('message'))
    except:
      raise