import logging, jsonpickle, json
from http import HTTPMethod

from fmconsult.utils.url import UrlUtil

from soulmv.synclink.api import SoulMVSyncLinkApi

class PatientRecordApi(SoulMVSyncLinkApi):
    def __init__(self):
        super().__init__()
        self.endpoint_url = UrlUtil().make_url(self.base_url, ['api', 'v1', 'PatientRecord'])

    def searchByCPF(self, cpf_number):
        try:
            self.endpoint_url = UrlUtil().make_url(self.base_url, ['search'])

            payload = { 'cpf': cpf_number }

            res = self.call_request(HTTPMethod.POST, self.endpoint_url, None, payload=payload)
            res = jsonpickle.decode(res)

            return res
        except:
            raise
    
    def searchByCNS(self, cns_number):
        try:
            self.endpoint_url = UrlUtil().make_url(self.base_url, ['search'])

            payload = { 'cns': cns_number }

            res = self.call_request(HTTPMethod.POST, self.endpoint_url, None, payload=payload)
            res = jsonpickle.decode(res)
            
            return res
        except:
            raise