"""snakeoil-web test harness — pytest plugin and reporting."""
