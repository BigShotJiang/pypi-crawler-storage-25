"""snakeoil-web CLI — project initialisation."""

import os
import subprocess
import sys


README = '''\
# snakeoil-web

## Dependencies

- Python 3.8+
- A supported browser installed on your machine (Chrome, Firefox, Safari, or Edge)

Everything else — Playwright, pytest, pytest-html — is installed automatically by `snakeoil init`.

---

## Install

```bash
pip install snakeoil-web
```

---

## Quick start

```bash
pip install snakeoil-web
snakeoil init
pytest web-tests/
```

---

## What `snakeoil init` creates

```
your-project/
├── snakeoil.web.config.py   ← configure URL, browser, headless mode
├── pytest.ini               ← pytest settings
└── web-tests/
    ├── test_english.py      ← English instruction style tests
    └── test_pythonic.py     ← Pythonic API style tests
```

After running your tests:
```
your-project/
└── report.html              ← test report (open in browser)
```

---

## Configuration

Edit `snakeoil.web.config.py` in your project root:

```python
# URL of the site under test
URL = "https://yourapp.com"

# Browser to use: chrome | firefox | safari | edge
# chrome  — Google Chrome (must be installed)
# firefox — Mozilla Firefox (must be installed)
# safari  — Safari via WebKit (macOS only)
# edge    — Microsoft Edge (must be installed)
BROWSER = "chrome"

# Run browser without a visible window (True for CI, False for local debugging)
HEADLESS = False

# Launch browser maximized (ignored when HEADLESS = True)
MAXIMIZED = True

# Maximum time in milliseconds to wait for elements and page loads
TIMEOUT = 10_000

# Directory where report.html is saved after each test run
RESULT_DIR = "."
```

---

## Two ways to write tests

**English:**
```python
def test_login(agent):
    agent.run([
        \'type "harish@example.com" into "Email"\',
        \'type "secret123" into "Password"\',
        \'click "Sign in"\',
        \'verify text "Dashboard" is present\',
    ])
```

**Pythonic:**
```python
def test_login(agent):
    (agent
        .type("harish@example.com", into="Email")
        .type("secret123", into="Password")
        .click("Sign in")
        .verify_text("Dashboard")
    )
```

---

## Supported instructions

### Actions
| Instruction | Example |
|---|---|
| Type into a field | `type "value" into "Field Label"` |
| Click an element | `click "Button Text"` |
| Click by position | `click "Add to cart" below "Product Name"` |
| Click near element | `click "Edit" near "John Smith"` |
| Click nth element | `click second "Add to cart"` |
| Select a dropdown | `select "Option" from "dropdown_name"` |
| Hover over element | `hover "element"` |
| Press a key | `press Enter` |
| Navigate to URL | `navigate "https://yourapp.com/page"` |

### Verification
| Instruction | Example |
|---|---|
| Verify text is present | `verify text "Welcome" is present` |
| Verify element is present | `verify "Submit" is present` |
| Verify element is visible | `verify "Submit" is visible` |
| Verify text next to element | `verify text next to "Balance" is "$100.00"` |
| Verify text below element | `verify text below "Total" is "$29.99"` |

### Extraction
| Instruction | Example |
|---|---|
| Extract from element | `extract text from "element_class"` |
| Extract nth | `extract text from first "item name"` |
| Extract next to element | `extract text next to "Balance"` |
| Extract near element | `extract text near "Balance"` |
| Extract below element | `extract text below "Label"` |
| Extract above element | `extract text above "Label"` |
| Capture into variable | `{{price}} = extract text next to "Total"` |

---

## Spatial targeting

Supported directions: `next to`, `below`, `above`, `left of`, `right of`, `near`

```python
agent.click("Add to cart", below="Sauce Labs Backpack")
agent.run(\'extract text next to "Balance"\')
```

---

## Extracting values

```python
price = agent.run(\'extract text next to "Total"\')
assert price == "$29.99"

agent.run(\'{{balance}} = extract text next to "Balance"\')
balance = agent.get("balance")

price = agent.extract_text(next_to="Total")
```

---

## Running tests

```bash
pytest web-tests/
pytest web-tests/test_english.py::test_login
open report.html
```

---

## Supported browsers

| Config value | Browser |
|---|---|
| `chrome` | Google Chrome |
| `firefox` | Mozilla Firefox |
| `safari` | Safari (macOS only) |
| `edge` | Microsoft Edge |

---

[PyPI](https://pypi.org/project/snakeoil-web/)
'''


PYTEST_INI = '''\
[pytest]
python_files = test_*.py
'''


CONFIG = '''\
"""
snakeoil.web.config.py — configure your web test settings here.
"""

# URL of the site under test
URL = "https://www.saucedemo.com"

# Browser to use: chrome | firefox | safari | edge
# chrome  — Google Chrome (must be installed)
# firefox — Mozilla Firefox (must be installed)
# safari  — Safari via WebKit (macOS only)
# edge    — Microsoft Edge (must be installed)
BROWSER = "chrome"

# Run browser without a visible window (True for CI, False for local debugging)
HEADLESS = False

# Launch browser maximized (ignored when HEADLESS = True)
MAXIMIZED = True

# Maximum time in milliseconds to wait for elements and page loads
TIMEOUT = 10_000

# Directory where report.html is saved after each test run
RESULT_DIR = "test_report"

# Capture a screenshot when a step fails and embed it in the report
SCREENSHOTS_ON_FAILURE = False
'''



ENGLISH_TEST = '''\
"""
test_english.py — English instruction API example using pytest.

Each test_ function is an isolated test with its own browser session.
Use f-strings to embed Python variables inside instructions.
"""

# Test data
username = "standard_user"
password = "secret_sauce"


def test_login(agent):
    # "Loin" is deliberately misspelled to demonstrate how a failure looks in the report
    agent.run([
        f\'type "{username}" into "Username"\',   # type into field identified by placeholder label
        f\'type "{password}" into "Password"\',   # type into password field
        \'click "Loin"\',                          # deliberately misspelled — will fail
        \'verify text "Products" is present\',     # assert we landed on the products page
    ])


def test_product_checkout(agent):
    agent.run([
        f\'type "{username}" into "Username"\',
        f\'type "{password}" into "Password"\',
        \'click "Login"\',
        \'select "Price (low to high)" from "product_sort_container"\',  # select dropdown option by class
        \'verify text "Sauce Labs Onesie" is present\',                  # assert cheapest item is first
    ])

    price = agent.run(\'extract text next to "Add to cart"\')  # spatial extract — price is left of button
    print(f"Cheapest product price: {price}")
    assert price, "No price extracted"

    agent.run([
        \'click "Add to cart" below "Sauce Labs Onesie"\',  # spatial click — button is below product name
        \'verify "Remove" is present\',                      # assert button changed to Remove
        \'hover "shopping_cart_link"\',                      # hover over cart icon by class
        \'click "shopping_cart_link"\',                      # click cart icon by class name
        \'verify text "Your Cart" is present\',              # assert we landed on cart page
    ])

    cart_item = agent.run(\'extract text from first "inventory item name"\')  # extract first cart item name
    print(f"Cart item: {cart_item}")
    assert cart_item == "Sauce Labs Onesie", f"Expected Sauce Labs Onesie in cart, got: {cart_item}"

    agent.run([\'click "Checkout"\'])

    agent.run([
        \'type "Andromeda" into "First Name"\',
        \'type "Galaxy" into "Last Name"\',
        \'type "3000" into "Zip/Postal Code"\',
        \'click "Continue"\',
    ])

    total_amount = agent.run(\'extract text next to "Total:"\')
    print(f"Total amount: {total_amount}")

    agent.run([
        \'click "Finish"\',
        \'verify text "Thank you for your order!" is present\',
    ])
'''


PYTHONIC_TEST = '''\
"""
test_pythonic.py — Pythonic API example using pytest.

Each test_ function is an isolated test with its own browser session.
IDE autocomplete guides you through every method.
"""

# Test data
username = "standard_user"
password = "secret_sauce"


def test_login(agent):
    (agent
        .type(username, into="Username")   # type into field identified by placeholder label
        .type(password, into="Password")   # type into password field
        .click("Login")                    # click login button by text
        .verify_text("Products")           # assert we landed on the products page
    )


def test_product_checkout(agent):
    (agent
        .type(username, into="Username")
        .type(password, into="Password")
        .click("Login")
        .select("Price (low to high)", from_="product_sort_container")  # select dropdown option by class
        .verify_text("Sauce Labs Onesie")                               # assert cheapest item is first
    )

    price = agent.extract_text(next_to="Add to cart")  # spatial extract — price is left of button
    print(f"Cheapest product price: {price}")
    assert price, "No price extracted"

    (agent
        .click("Add to cart", below="Sauce Labs Onesie")  # spatial click — button is below product name
        .verify_present("Remove")                          # assert button changed to Remove
        .hover("shopping_cart_link")                       # hover over cart icon by class
        .click("shopping_cart_link")                       # click cart icon by class name
        .verify_text("Your Cart")                          # assert we landed on cart page
    )

    cart_item = agent.extract_text("inventory item name")  # extract first cart item name
    print(f"Cart item: {cart_item}")
    assert cart_item == "Sauce Labs Onesie", f"Expected Sauce Labs Onesie in cart, got: {cart_item}"

    agent.click("Checkout")

    (agent
        .type("Andromeda", into="First Name")
        .type("Galaxy", into="Last Name")
        .type("3000", into="Zip/Postal Code")
        .click("Continue")
    )

    total_amount = agent.extract_text(next_to="Total:")
    print(f"Total amount: {total_amount}")

    agent.click("Finish")
    agent.verify_text("Thank you for your order!")
'''


def init():
    """Create project structure for snakeoil-web."""
    cwd       = os.getcwd()
    web_tests = os.path.join(cwd, "web-tests")

    os.makedirs(web_tests, exist_ok=True)

    files = {
        os.path.join(cwd, "README.md"):                README,
        os.path.join(cwd, "pytest.ini"):               PYTEST_INI,
        os.path.join(cwd, "snakeoil.web.config.py"):   CONFIG,
        os.path.join(web_tests, "test_english.py"):    ENGLISH_TEST,
        os.path.join(web_tests, "test_pythonic.py"):   PYTHONIC_TEST,
    }

    created = []
    skipped = []

    for path, content in files.items():
        if os.path.exists(path):
            skipped.append(path)
        else:
            with open(path, "w") as f:
                f.write(content)
            created.append(path)

    # Install dependencies
    print("\nInstalling dependencies...")
    for pkg in ["pytest", "pytest-html"]:
        try:
            subprocess.run([sys.executable, "-m", "pip", "install", pkg],
                           check=True, capture_output=True)
        except subprocess.CalledProcessError:
            print(f"Warning: could not install {pkg}. Run 'pip install {pkg}' manually.")

    print("\nInstalling browser binaries...")
    try:
        subprocess.run(
            [sys.executable, "-m", "playwright", "install", "chromium"],
            check=True
        )
        print("Browsers installed.")
    except subprocess.CalledProcessError:
        print("Warning: could not install browsers. Run 'playwright install' manually.")

    print("\nsnakeoil-web project initialised.\n")

    if created:
        print("Created:")
        for f in created:
            print(f"  {f}")

    if skipped:
        print("\nSkipped (already exist):")
        for f in skipped:
            print(f"  {f}")

    print("""
Next steps:
  1. Edit snakeoil.web.config.py — set your URL, browser and options
  2. Run your tests:   pytest web-tests/
  3. View report:      open report.html
""")


def main():
    if len(sys.argv) < 2 or sys.argv[1] != "init":
        print("Usage: snakeoil init")
        sys.exit(1)
    init()


if __name__ == "__main__":
    main()
