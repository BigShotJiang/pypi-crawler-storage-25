"""Tests for OpenAI Agents SDK Raindrop integration."""
import logging
import warnings
from datetime import datetime, timezone
from unittest.mock import MagicMock, patch, call

from raindrop_openai_agents.wrapper import (
    RaindropOpenAIAgents,
    RaindropTracingProcessor,
    create_raindrop_openai_agents,
    _safe_str,
    _compute_duration_ms,
    _extract_finish_reason,
    _extract_finish_reason_from_generation,
    _extract_extended_tokens,
)


def _make_trace(trace_id="trace-1", name="agent_run"):
    trace = MagicMock()
    trace.trace_id = trace_id
    trace.name = name
    return trace


def _make_span(trace_id="trace-1", span_id="span-1", span_type="generation", **kwargs):
    data = MagicMock()
    data.type = span_type
    data.name = kwargs.get("name")
    data.model = kwargs.get("model")
    data.input = kwargs.get("input")
    data.output = kwargs.get("output")
    data.error = kwargs.get("error")

    usage = kwargs.get("usage")
    if usage:
        data.usage = MagicMock()
        data.usage.input_tokens = usage.get("input_tokens")
        data.usage.output_tokens = usage.get("output_tokens")
        # Extended token details
        if "input_tokens_details" in usage:
            data.usage.input_tokens_details = MagicMock()
            data.usage.input_tokens_details.cached_tokens = usage["input_tokens_details"].get("cached_tokens")
            data.usage.prompt_tokens_details = None
            data.usage.completion_tokens_details = None
        else:
            data.usage.input_tokens_details = None
        if "output_tokens_details" in usage:
            data.usage.output_tokens_details = MagicMock()
            data.usage.output_tokens_details.reasoning_tokens = usage["output_tokens_details"].get("reasoning_tokens")
            data.usage.prompt_tokens_details = None
            data.usage.completion_tokens_details = None
        else:
            data.usage.output_tokens_details = None
        if "prompt_tokens_details" in usage:
            data.usage.prompt_tokens_details = MagicMock()
            data.usage.prompt_tokens_details.cached_tokens = usage["prompt_tokens_details"].get("cached_tokens")
            if not hasattr(data.usage, "input_tokens_details") or data.usage.input_tokens_details is None:
                data.usage.input_tokens_details = None
        elif not hasattr(data.usage, "prompt_tokens_details"):
            data.usage.prompt_tokens_details = None
        if "completion_tokens_details" in usage:
            data.usage.completion_tokens_details = MagicMock()
            data.usage.completion_tokens_details.reasoning_tokens = usage["completion_tokens_details"].get("reasoning_tokens")
            if not hasattr(data.usage, "output_tokens_details") or data.usage.output_tokens_details is None:
                data.usage.output_tokens_details = None
        elif not hasattr(data.usage, "completion_tokens_details"):
            data.usage.completion_tokens_details = None
    else:
        data.usage = None

    span = MagicMock()
    span.trace_id = trace_id
    span.span_id = span_id
    span.span_data = data
    span.started_at = kwargs.get("started_at")
    span.ended_at = kwargs.get("ended_at")
    span.error = kwargs.get("span_error")
    return span


def _make_function_span(
    trace_id="trace-1",
    span_id="span-fn",
    name="get_weather",
    input_val='{"city": "Paris"}',
    output_val='{"temp": 22}',
    started_at=None,
    ended_at=None,
    span_error=None,
):
    """Create a function/tool span matching OpenAI Agents SDK FunctionSpanData."""
    data = MagicMock()
    data.type = "function"
    data.name = name
    data.input = input_val
    data.output = output_val

    span = MagicMock()
    span.trace_id = trace_id
    span.span_id = span_id
    span.span_data = data
    span.started_at = started_at
    span.ended_at = ended_at
    span.error = span_error
    return span


def _make_interaction_mock():
    """Create a mock Interaction object."""
    interaction = MagicMock()
    interaction.id = "evt-mock-123"
    return interaction


class TestSafeStr:
    def test_string_passthrough(self):
        assert _safe_str("hello") == "hello"

    def test_none(self):
        assert _safe_str(None) is None

    def test_dict(self):
        result = _safe_str({"key": "val"})
        assert "key" in result

    def test_non_serializable(self):
        assert _safe_str(object()) is not None

    def test_pydantic_model(self):
        model = MagicMock()
        model.model_dump_json = MagicMock(return_value='{"a": 1}')
        assert _safe_str(model) == '{"a": 1}'


class TestComputeDurationMs:
    """Tests for _compute_duration_ms helper."""

    def test_valid_iso_timestamps(self):
        span = MagicMock()
        span.started_at = "2024-01-01T00:00:00+00:00"
        span.ended_at = "2024-01-01T00:00:01.500+00:00"
        result = _compute_duration_ms(span)
        assert result == 1500.0

    def test_naive_timestamps_treated_as_utc(self):
        span = MagicMock()
        span.started_at = "2024-01-01T00:00:00"
        span.ended_at = "2024-01-01T00:00:00.250"
        result = _compute_duration_ms(span)
        assert result == 250.0

    def test_missing_started_at(self):
        span = MagicMock()
        span.started_at = None
        span.ended_at = "2024-01-01T00:00:01+00:00"
        assert _compute_duration_ms(span) is None

    def test_missing_ended_at(self):
        span = MagicMock()
        span.started_at = "2024-01-01T00:00:00+00:00"
        span.ended_at = None
        assert _compute_duration_ms(span) is None

    def test_zero_duration(self):
        span = MagicMock()
        span.started_at = "2024-01-01T12:00:00+00:00"
        span.ended_at = "2024-01-01T12:00:00+00:00"
        assert _compute_duration_ms(span) == 0.0

    def test_negative_duration_clamped_to_zero(self):
        span = MagicMock()
        span.started_at = "2024-01-01T00:00:01+00:00"
        span.ended_at = "2024-01-01T00:00:00+00:00"
        assert _compute_duration_ms(span) == 0.0

    def test_invalid_timestamp_returns_none(self):
        span = MagicMock()
        span.started_at = "not-a-timestamp"
        span.ended_at = "also-not-a-timestamp"
        assert _compute_duration_ms(span) is None

    def test_no_attributes_returns_none(self):
        span = object()
        assert _compute_duration_ms(span) is None

    def test_z_suffix_timestamps_python310_compat(self):
        """Timestamps ending with 'Z' should work on Python 3.10+."""
        span = MagicMock()
        span.started_at = "2024-01-01T00:00:00Z"
        span.ended_at = "2024-01-01T00:00:02Z"
        result = _compute_duration_ms(span)
        assert result == 2000.0


class TestExtractFinishReason:
    """Tests for _extract_finish_reason helper."""

    def test_response_status(self):
        response = MagicMock()
        response.status = "completed"
        response.output = []
        assert _extract_finish_reason(response) == "completed"

    def test_output_item_finish_reason(self):
        response = MagicMock()
        response.status = None
        item = MagicMock()
        item.finish_reason = "stop"
        item.status = None
        response.output = [item]
        assert _extract_finish_reason(response) == "stop"

    def test_output_item_status(self):
        response = MagicMock()
        response.status = None
        item = MagicMock()
        item.finish_reason = None
        item.status = "completed"
        response.output = [item]
        assert _extract_finish_reason(response) == "completed"

    def test_no_finish_reason(self):
        response = MagicMock()
        response.status = None
        response.output = None
        assert _extract_finish_reason(response) is None

    def test_none_response(self):
        assert _extract_finish_reason(None) is None


class TestExtractFinishReasonFromGeneration:
    """Tests for _extract_finish_reason_from_generation helper."""

    def test_direct_finish_reason(self):
        output = MagicMock()
        output.finish_reason = "stop"
        output.choices = None
        assert _extract_finish_reason_from_generation(output) == "stop"

    def test_choices_finish_reason(self):
        output = MagicMock()
        output.finish_reason = None
        choice = MagicMock()
        choice.finish_reason = "length"
        output.choices = [choice]
        assert _extract_finish_reason_from_generation(output) == "length"

    def test_dict_choices(self):
        output = {"choices": [{"finish_reason": "stop", "index": 0}]}
        assert _extract_finish_reason_from_generation(output) == "stop"

    def test_none_output(self):
        assert _extract_finish_reason_from_generation(None) is None

    def test_no_choices(self):
        output = MagicMock()
        output.finish_reason = None
        output.choices = None
        assert _extract_finish_reason_from_generation(output) is None


class TestExtractExtendedTokens:
    """Tests for _extract_extended_tokens helper."""

    def test_response_api_format(self):
        """Test OpenAI Responses API: input_tokens_details / output_tokens_details."""
        usage = MagicMock()
        usage.input_tokens_details = MagicMock()
        usage.input_tokens_details.cached_tokens = 100
        usage.output_tokens_details = MagicMock()
        usage.output_tokens_details.reasoning_tokens = 50
        usage.prompt_tokens_details = None
        usage.completion_tokens_details = None

        props: dict = {}
        _extract_extended_tokens(usage, props)
        assert props["ai.usage.cached_tokens"] == 100
        assert props["ai.usage.thoughts_tokens"] == 50

    def test_chat_completions_format(self):
        """Test Chat Completions: prompt_tokens_details / completion_tokens_details."""
        usage = MagicMock()
        usage.input_tokens_details = None
        usage.output_tokens_details = None
        usage.prompt_tokens_details = MagicMock()
        usage.prompt_tokens_details.cached_tokens = 200
        usage.completion_tokens_details = MagicMock()
        usage.completion_tokens_details.reasoning_tokens = 75

        props: dict = {}
        _extract_extended_tokens(usage, props)
        assert props["ai.usage.cached_tokens"] == 200
        assert props["ai.usage.thoughts_tokens"] == 75

    def test_dict_format(self):
        """Test dict-style usage data."""
        usage = {
            "prompt_tokens_details": {"cached_tokens": 300},
            "completion_tokens_details": {"reasoning_tokens": 25},
        }
        props: dict = {}
        _extract_extended_tokens(usage, props)
        assert props["ai.usage.cached_tokens"] == 300
        assert props["ai.usage.thoughts_tokens"] == 25

    def test_no_extended_tokens(self):
        usage = MagicMock()
        usage.input_tokens_details = None
        usage.output_tokens_details = None
        usage.prompt_tokens_details = None
        usage.completion_tokens_details = None
        props: dict = {}
        _extract_extended_tokens(usage, props)
        assert "ai.usage.cached_tokens" not in props
        assert "ai.usage.thoughts_tokens" not in props

    def test_partial_extended_tokens(self):
        """Only cached_tokens present, no reasoning."""
        usage = MagicMock()
        usage.input_tokens_details = MagicMock()
        usage.input_tokens_details.cached_tokens = 42
        usage.output_tokens_details = None
        usage.prompt_tokens_details = None
        usage.completion_tokens_details = None
        props: dict = {}
        _extract_extended_tokens(usage, props)
        assert props["ai.usage.cached_tokens"] == 42
        assert "ai.usage.thoughts_tokens" not in props


class TestProcessor:
    def test_generation_span_tracked(self):
        with patch("raindrop_openai_agents.wrapper.raindrop") as mock_rd:
            mock_interaction = _make_interaction_mock()
            mock_rd.begin.return_value = mock_interaction

            p = RaindropTracingProcessor(user_id="test-user")

            p.on_trace_start(_make_trace("t1"))
            p.on_span_start(_make_span("t1", "s1", "generation",
                model="gpt-4o", input=[{"role": "user", "content": "Hi"}]))
            p.on_span_end(_make_span("t1", "s1", "generation",
                model="gpt-4o", input=[{"role": "user", "content": "Hi"}],
                output=[{"role": "assistant", "content": "Hello!"}],
                usage={"input_tokens": 10, "output_tokens": 5}))
            p.on_trace_end(_make_trace("t1"))

            # Interaction API should be used
            mock_rd.begin.assert_called_once()
            mock_interaction.finish.assert_called_once()
            finish_kwargs = mock_interaction.finish.call_args
            assert "Hello" in str(finish_kwargs)

    def test_response_span_tracked(self):
        """Test the real OpenAI Agents SDK span format (type=response)."""
        with patch("raindrop_openai_agents.wrapper.raindrop") as mock_rd:
            mock_interaction = _make_interaction_mock()
            mock_rd.begin.return_value = mock_interaction

            p = RaindropTracingProcessor(user_id="test-user")

            response_data = MagicMock()
            response_data.type = "response"
            response_data.input = [{"role": "user", "content": "Hello"}]
            response_data.error = None

            response_obj = MagicMock()
            response_obj.model = "gpt-4o-mini-2024-07-18"
            response_obj.status = "completed"
            content_block = MagicMock()
            content_block.text = "Paris."
            output_msg = MagicMock()
            output_msg.content = [content_block]
            output_msg.finish_reason = None
            output_msg.status = None
            response_obj.output = [output_msg]
            usage = MagicMock()
            usage.input_tokens = 8
            usage.output_tokens = 2
            usage.input_tokens_details = None
            usage.output_tokens_details = None
            usage.prompt_tokens_details = None
            usage.completion_tokens_details = None
            response_obj.usage = usage
            response_data.response = response_obj

            span = MagicMock()
            span.trace_id = "t-resp"
            span.span_id = "s-resp"
            span.span_data = response_data

            p.on_trace_start(_make_trace("t-resp"))
            p.on_span_end(span)
            p.on_trace_end(_make_trace("t-resp"))

            mock_rd.begin.assert_called_once()
            mock_interaction.set_input.assert_called_once()
            mock_interaction.set_properties.assert_called()
            props = mock_interaction.set_properties.call_args[0][0]
            assert props["ai.usage.prompt_tokens"] == 8
            assert props["ai.usage.completion_tokens"] == 2
            assert props["ai.finish_reason"] == "completed"

    def test_non_generation_span_does_not_emit_properties(self):
        with patch("raindrop_openai_agents.wrapper.raindrop") as mock_rd:
            mock_interaction = _make_interaction_mock()
            mock_rd.begin.return_value = mock_interaction

            p = RaindropTracingProcessor(user_id="test-user")

            p.on_trace_start(_make_trace("t2"))
            # A custom span type that is not generation/response/function
            custom_span = MagicMock()
            custom_span.trace_id = "t2"
            custom_span.span_id = "s2"
            custom_data = MagicMock()
            custom_data.type = "custom"
            custom_span.span_data = custom_data
            p.on_span_start(custom_span)
            p.on_span_end(custom_span)
            p.on_trace_end(_make_trace("t2"))

            mock_interaction.finish.assert_called_once()
            # No properties set since no generation/response data
            mock_interaction.set_properties.assert_not_called()

    def test_convo_id_forwarded(self):
        with patch("raindrop_openai_agents.wrapper.raindrop") as mock_rd:
            mock_interaction = _make_interaction_mock()
            mock_rd.begin.return_value = mock_interaction

            p = RaindropTracingProcessor(user_id="test-user", convo_id="convo-abc")

            p.on_trace_start(_make_trace("t3"))
            p.on_trace_end(_make_trace("t3"))

            begin_kwargs = mock_rd.begin.call_args.kwargs
            assert begin_kwargs["convo_id"] == "convo-abc"

    def test_trace_name_forwarded(self):
        with patch("raindrop_openai_agents.wrapper.raindrop") as mock_rd:
            mock_interaction = _make_interaction_mock()
            mock_rd.begin.return_value = mock_interaction

            p = RaindropTracingProcessor(user_id="test-user")

            p.on_trace_start(_make_trace("t4", name="my_workflow"))
            p.on_trace_end(_make_trace("t4", name="my_workflow"))

            begin_kwargs = mock_rd.begin.call_args.kwargs
            assert begin_kwargs["event"] == "my_workflow"

    def test_multiple_traces_no_leak(self):
        with patch("raindrop_openai_agents.wrapper.raindrop") as mock_rd:
            mock_rd.begin.side_effect = lambda **kw: _make_interaction_mock()

            p = RaindropTracingProcessor(user_id="test-user")

            for i in range(5):
                p.on_trace_start(_make_trace(f"t-{i}"))
                p.on_span_start(_make_span(f"t-{i}", f"s-{i}", "generation", model="gpt-4o"))
                p.on_span_end(_make_span(f"t-{i}", f"s-{i}", "generation",
                    model="gpt-4o", output=[{"content": f"Response {i}"}]))
                p.on_trace_end(_make_trace(f"t-{i}"))

            assert mock_rd.begin.call_count == 5
            assert len(p._trace_event_ids) == 0
            assert len(p._pending_data) == 0
            assert len(p._interactions) == 0

    def test_error_in_finish_does_not_propagate(self):
        with patch("raindrop_openai_agents.wrapper.raindrop") as mock_rd:
            mock_interaction = _make_interaction_mock()
            mock_interaction.finish.side_effect = RuntimeError("telemetry broke")
            mock_rd.begin.return_value = mock_interaction

            p = RaindropTracingProcessor(user_id="test-user")

            p.on_trace_start(_make_trace("t5"))
            p.on_trace_end(_make_trace("t5"))
            # No exception raised

    def test_span_without_trace_is_ignored(self):
        with patch("raindrop_openai_agents.wrapper.raindrop") as mock_rd:
            p = RaindropTracingProcessor(user_id="test-user")

            p.on_span_start(_make_span("unknown-trace", "s1", "generation"))
            p.on_span_end(_make_span("unknown-trace", "s1", "generation"))
            # No crash, no event emitted

    def test_shutdown_clears_state(self):
        with patch("raindrop_openai_agents.wrapper.raindrop") as mock_rd:
            mock_rd.begin.return_value = _make_interaction_mock()
            p = RaindropTracingProcessor(user_id="test-user")
            p.on_trace_start(_make_trace("t6"))
            assert len(p._trace_event_ids) == 1
            assert len(p._interactions) == 1

            p.shutdown()
            assert len(p._trace_event_ids) == 0
            assert len(p._pending_data) == 0
            assert len(p._interactions) == 0

    def test_user_id_defaults_to_unknown(self):
        with patch("raindrop_openai_agents.wrapper.raindrop") as mock_rd:
            mock_rd.begin.return_value = _make_interaction_mock()
            p = RaindropTracingProcessor()

            p.on_trace_start(_make_trace("t-default"))
            p.on_trace_end(_make_trace("t-default"))

            begin_kwargs = mock_rd.begin.call_args.kwargs
            assert begin_kwargs["user_id"] == "unknown"

    def test_error_captured_in_response_span(self):
        """Error type and message should appear in properties."""
        with patch("raindrop_openai_agents.wrapper.raindrop") as mock_rd:
            mock_interaction = _make_interaction_mock()
            mock_rd.begin.return_value = mock_interaction

            p = RaindropTracingProcessor(user_id="test-user")

            response_data = MagicMock()
            response_data.type = "response"
            response_data.input = "Hello"
            response_data.response = None
            response_data.error = ValueError("something went wrong")

            span = MagicMock()
            span.trace_id = "t-err"
            span.span_id = "s-err"
            span.span_data = response_data

            p.on_trace_start(_make_trace("t-err"))
            p.on_span_end(span)
            p.on_trace_end(_make_trace("t-err"))

            mock_interaction.set_properties.assert_called()
            props = mock_interaction.set_properties.call_args[0][0]
            assert props["error.type"] == "ValueError"
            assert "something went wrong" in props["error.message"]

    def test_error_captured_in_generation_span(self):
        """Error type and message should appear in generation span properties."""
        with patch("raindrop_openai_agents.wrapper.raindrop") as mock_rd:
            mock_interaction = _make_interaction_mock()
            mock_rd.begin.return_value = mock_interaction

            p = RaindropTracingProcessor(user_id="test-user")

            p.on_trace_start(_make_trace("t-gerr"))
            p.on_span_end(_make_span(
                "t-gerr", "s-gerr", "generation",
                model="gpt-4o",
                error=RuntimeError("model failed"),
            ))
            p.on_trace_end(_make_trace("t-gerr"))

            mock_interaction.set_properties.assert_called()
            props = mock_interaction.set_properties.call_args[0][0]
            assert props["error.type"] == "RuntimeError"
            assert "model failed" in props["error.message"]

    def test_string_error_captured(self):
        """String errors should be captured with type 'Error'."""
        with patch("raindrop_openai_agents.wrapper.raindrop") as mock_rd:
            mock_interaction = _make_interaction_mock()
            mock_rd.begin.return_value = mock_interaction

            p = RaindropTracingProcessor(user_id="test-user")

            response_data = MagicMock()
            response_data.type = "response"
            response_data.input = "Hello"
            response_data.response = None
            response_data.error = "rate limit exceeded"

            span = MagicMock()
            span.trace_id = "t-serr"
            span.span_id = "s-serr"
            span.span_data = response_data

            p.on_trace_start(_make_trace("t-serr"))
            p.on_span_end(span)
            p.on_trace_end(_make_trace("t-serr"))

            mock_interaction.set_properties.assert_called()
            props = mock_interaction.set_properties.call_args[0][0]
            assert props["error.type"] == "Error"
            assert props["error.message"] == "rate limit exceeded"

    def test_fallback_to_track_ai_when_interaction_fails(self):
        """When raindrop.begin() fails, on_trace_end should fall back to track_ai."""
        with patch("raindrop_openai_agents.wrapper.raindrop") as mock_rd:
            mock_rd.begin.side_effect = RuntimeError("begin failed")

            p = RaindropTracingProcessor(user_id="test-user")
            p.on_trace_start(_make_trace("t-fallback"))
            p.on_span_end(_make_span("t-fallback", "s1", "generation",
                model="gpt-4o",
                input=[{"role": "user", "content": "Hi"}],
                output="Hello!",
                usage={"input_tokens": 5, "output_tokens": 3}))
            p.on_trace_end(_make_trace("t-fallback"))

            # Should fall back to track_ai
            mock_rd.track_ai.assert_called_once()
            kwargs = mock_rd.track_ai.call_args.kwargs
            assert kwargs["user_id"] == "test-user"
            assert kwargs["model"] == "gpt-4o"


class TestFunctionSpanTracking:
    """Tests for tool/function span tracking via interaction.track_tool()."""

    def test_function_span_calls_track_tool(self):
        """Function spans should create tool spans via interaction.track_tool()."""
        with patch("raindrop_openai_agents.wrapper.raindrop") as mock_rd:
            mock_interaction = _make_interaction_mock()
            mock_rd.begin.return_value = mock_interaction

            p = RaindropTracingProcessor(user_id="test-user")

            p.on_trace_start(_make_trace("t-fn"))
            fn_span = _make_function_span(
                trace_id="t-fn",
                name="get_weather",
                input_val='{"city": "Paris"}',
                output_val='{"temp": 22}',
                started_at="2024-01-01T00:00:00+00:00",
                ended_at="2024-01-01T00:00:00.150+00:00",
            )
            p.on_span_end(fn_span)
            p.on_trace_end(_make_trace("t-fn"))

            mock_interaction.track_tool.assert_called_once()
            tool_kwargs = mock_interaction.track_tool.call_args.kwargs
            assert tool_kwargs["name"] == "get_weather"
            assert tool_kwargs["input"] == '{"city": "Paris"}'
            assert tool_kwargs["output"] == '{"temp": 22}'
            assert tool_kwargs["duration_ms"] == 150.0
            assert tool_kwargs["error"] is None

    def test_function_span_with_error(self):
        """Function spans with errors should pass error to track_tool."""
        with patch("raindrop_openai_agents.wrapper.raindrop") as mock_rd:
            mock_interaction = _make_interaction_mock()
            mock_rd.begin.return_value = mock_interaction

            p = RaindropTracingProcessor(user_id="test-user")

            p.on_trace_start(_make_trace("t-fn-err"))

            span_error = MagicMock()
            span_error.message = "Tool execution failed"

            fn_span = _make_function_span(
                trace_id="t-fn-err",
                name="search_db",
                input_val="query",
                output_val=None,
                started_at="2024-01-01T00:00:00+00:00",
                ended_at="2024-01-01T00:00:01+00:00",
                span_error=span_error,
            )
            p.on_span_end(fn_span)

            mock_interaction.track_tool.assert_called_once()
            tool_kwargs = mock_interaction.track_tool.call_args.kwargs
            assert tool_kwargs["name"] == "search_db"
            assert tool_kwargs["error"] == "Tool execution failed"
            assert tool_kwargs["duration_ms"] == 1000.0

    def test_function_span_without_timing(self):
        """Function spans without timing info should pass duration_ms=None."""
        with patch("raindrop_openai_agents.wrapper.raindrop") as mock_rd:
            mock_interaction = _make_interaction_mock()
            mock_rd.begin.return_value = mock_interaction

            p = RaindropTracingProcessor(user_id="test-user")
            p.on_trace_start(_make_trace("t-fn-notiming"))

            fn_span = _make_function_span(
                trace_id="t-fn-notiming",
                name="calc",
                started_at=None,
                ended_at=None,
            )
            p.on_span_end(fn_span)

            tool_kwargs = mock_interaction.track_tool.call_args.kwargs
            assert tool_kwargs["duration_ms"] is None

    def test_multiple_function_spans(self):
        """Multiple tool calls in one trace should each get a track_tool call."""
        with patch("raindrop_openai_agents.wrapper.raindrop") as mock_rd:
            mock_interaction = _make_interaction_mock()
            mock_rd.begin.return_value = mock_interaction

            p = RaindropTracingProcessor(user_id="test-user")
            p.on_trace_start(_make_trace("t-multi-fn"))

            for i, tool_name in enumerate(["get_weather", "search_web", "calculate"]):
                fn_span = _make_function_span(
                    trace_id="t-multi-fn",
                    span_id=f"s-fn-{i}",
                    name=tool_name,
                    input_val=f"input-{i}",
                    output_val=f"output-{i}",
                )
                p.on_span_end(fn_span)

            assert mock_interaction.track_tool.call_count == 3
            tool_names = [c.kwargs["name"] for c in mock_interaction.track_tool.call_args_list]
            assert tool_names == ["get_weather", "search_web", "calculate"]

    def test_function_span_without_interaction_is_skipped(self):
        """If interaction wasn't created, function spans should be silently skipped."""
        with patch("raindrop_openai_agents.wrapper.raindrop") as mock_rd:
            mock_rd.begin.side_effect = RuntimeError("begin failed")

            p = RaindropTracingProcessor(user_id="test-user")
            p.on_trace_start(_make_trace("t-no-int"))

            fn_span = _make_function_span(trace_id="t-no-int")
            p.on_span_end(fn_span)
            # No crash, track_tool not called since no interaction

    def test_function_span_track_tool_exception_caught(self):
        """Exceptions from track_tool should be caught and logged."""
        with patch("raindrop_openai_agents.wrapper.raindrop") as mock_rd:
            mock_interaction = _make_interaction_mock()
            mock_interaction.track_tool.side_effect = RuntimeError("track_tool broke")
            mock_rd.begin.return_value = mock_interaction

            p = RaindropTracingProcessor(user_id="test-user")
            p.on_trace_start(_make_trace("t-fn-exc"))

            fn_span = _make_function_span(trace_id="t-fn-exc")
            # Should not raise
            p.on_span_end(fn_span)

    def test_function_span_with_none_name(self):
        """Function span with no name should default to 'unknown'."""
        with patch("raindrop_openai_agents.wrapper.raindrop") as mock_rd:
            mock_interaction = _make_interaction_mock()
            mock_rd.begin.return_value = mock_interaction

            p = RaindropTracingProcessor(user_id="test-user")
            p.on_trace_start(_make_trace("t-fn-noname"))

            fn_span = _make_function_span(trace_id="t-fn-noname", name=None)
            p.on_span_end(fn_span)

            tool_kwargs = mock_interaction.track_tool.call_args.kwargs
            assert tool_kwargs["name"] == "unknown"

    def test_function_span_with_string_error(self):
        """String errors on function spans should be passed through directly."""
        with patch("raindrop_openai_agents.wrapper.raindrop") as mock_rd:
            mock_interaction = _make_interaction_mock()
            mock_rd.begin.return_value = mock_interaction

            p = RaindropTracingProcessor(user_id="test-user")
            p.on_trace_start(_make_trace("t-fn-serr"))

            fn_span = _make_function_span(
                trace_id="t-fn-serr",
                name="lookup",
                span_error="connection timeout",
            )
            p.on_span_end(fn_span)

            tool_kwargs = mock_interaction.track_tool.call_args.kwargs
            assert tool_kwargs["error"] == "connection timeout"

    def test_function_span_with_exception_error(self):
        """BaseException errors on function spans should use str()."""
        with patch("raindrop_openai_agents.wrapper.raindrop") as mock_rd:
            mock_interaction = _make_interaction_mock()
            mock_rd.begin.return_value = mock_interaction

            p = RaindropTracingProcessor(user_id="test-user")
            p.on_trace_start(_make_trace("t-fn-exc-err"))

            fn_span = _make_function_span(
                trace_id="t-fn-exc-err",
                name="fetch_data",
                span_error=ValueError("invalid input"),
            )
            p.on_span_end(fn_span)

            tool_kwargs = mock_interaction.track_tool.call_args.kwargs
            assert tool_kwargs["error"] == "invalid input"

    def test_function_span_with_arbitrary_error_object(self):
        """Arbitrary error objects without .message should use str()."""
        with patch("raindrop_openai_agents.wrapper.raindrop") as mock_rd:
            mock_interaction = _make_interaction_mock()
            mock_rd.begin.return_value = mock_interaction

            p = RaindropTracingProcessor(user_id="test-user")
            p.on_trace_start(_make_trace("t-fn-arb-err"))

            class CustomError:
                def __str__(self):
                    return "custom error occurred"

            fn_span = _make_function_span(
                trace_id="t-fn-arb-err",
                name="process",
                span_error=CustomError(),
            )
            p.on_span_end(fn_span)

            tool_kwargs = mock_interaction.track_tool.call_args.kwargs
            assert tool_kwargs["error"] == "custom error occurred"


class TestFinishReasonCapture:
    """Tests for finish_reason extraction in processor spans."""

    def test_response_span_finish_reason_from_status(self):
        """finish_reason from response.status should be captured in properties."""
        with patch("raindrop_openai_agents.wrapper.raindrop") as mock_rd:
            mock_interaction = _make_interaction_mock()
            mock_rd.begin.return_value = mock_interaction

            p = RaindropTracingProcessor(user_id="test-user")

            response_data = MagicMock()
            response_data.type = "response"
            response_data.input = "Hello"
            response_data.error = None
            response_obj = MagicMock()
            response_obj.model = "gpt-4o"
            response_obj.status = "completed"
            response_obj.output = []
            response_obj.usage = None
            response_data.response = response_obj

            span = MagicMock()
            span.trace_id = "t-fr"
            span.span_id = "s-fr"
            span.span_data = response_data

            p.on_trace_start(_make_trace("t-fr"))
            p.on_span_end(span)
            p.on_trace_end(_make_trace("t-fr"))

            mock_interaction.set_properties.assert_called()
            props = mock_interaction.set_properties.call_args[0][0]
            assert props["ai.finish_reason"] == "completed"


class TestExtendedTokensCapture:
    """Tests for extended token categories in processor spans."""

    def test_response_span_extended_tokens(self):
        """Extended tokens from response usage should appear in properties."""
        with patch("raindrop_openai_agents.wrapper.raindrop") as mock_rd:
            mock_interaction = _make_interaction_mock()
            mock_rd.begin.return_value = mock_interaction

            p = RaindropTracingProcessor(user_id="test-user")

            response_data = MagicMock()
            response_data.type = "response"
            response_data.input = "Hello"
            response_data.error = None
            response_obj = MagicMock()
            response_obj.model = "gpt-4o"
            response_obj.status = None
            response_obj.output = []

            usage = MagicMock()
            usage.input_tokens = 100
            usage.output_tokens = 50
            usage.input_tokens_details = MagicMock()
            usage.input_tokens_details.cached_tokens = 80
            usage.output_tokens_details = MagicMock()
            usage.output_tokens_details.reasoning_tokens = 30
            usage.prompt_tokens_details = None
            usage.completion_tokens_details = None
            response_obj.usage = usage
            response_data.response = response_obj

            span = MagicMock()
            span.trace_id = "t-ext"
            span.span_id = "s-ext"
            span.span_data = response_data

            p.on_trace_start(_make_trace("t-ext"))
            p.on_span_end(span)
            p.on_trace_end(_make_trace("t-ext"))

            mock_interaction.set_properties.assert_called()
            props = mock_interaction.set_properties.call_args[0][0]
            assert props["ai.usage.cached_tokens"] == 80
            assert props["ai.usage.thoughts_tokens"] == 30
            assert props["ai.usage.prompt_tokens"] == 100
            assert props["ai.usage.completion_tokens"] == 50

    def test_generation_span_extended_tokens(self):
        """Extended tokens from generation usage should appear in properties."""
        with patch("raindrop_openai_agents.wrapper.raindrop") as mock_rd:
            mock_interaction = _make_interaction_mock()
            mock_rd.begin.return_value = mock_interaction

            p = RaindropTracingProcessor(user_id="test-user")
            p.on_trace_start(_make_trace("t-gext"))

            span = _make_span("t-gext", "s-gext", "generation",
                model="o1",
                input="Hello",
                output="Reasoning...",
                usage={
                    "input_tokens": 200,
                    "output_tokens": 100,
                    "prompt_tokens_details": {"cached_tokens": 150},
                    "completion_tokens_details": {"reasoning_tokens": 60},
                })
            p.on_span_end(span)
            p.on_trace_end(_make_trace("t-gext"))

            mock_interaction.set_properties.assert_called()
            props = mock_interaction.set_properties.call_args[0][0]
            assert props["ai.usage.cached_tokens"] == 150
            assert props["ai.usage.thoughts_tokens"] == 60


class TestTracingFlags:
    """Tests for tracing_enabled and bypass_otel_for_tools flags."""

    @patch("raindrop_openai_agents.wrapper.raindrop")
    def test_init_passes_tracing_flags(self, mock_rd):
        with patch("raindrop_openai_agents.wrapper.RaindropOpenAIAgents._register_processor"):
            RaindropOpenAIAgents(api_key="rk_test", user_id="u1")
            mock_rd.init.assert_called_once_with(
                api_key="rk_test",
                tracing_enabled=True,
                bypass_otel_for_tools=True,
            )

    @patch("raindrop_openai_agents.wrapper.raindrop")
    def test_custom_tracing_flags(self, mock_rd):
        """Custom tracing_enabled and bypass_otel_for_tools values are passed through."""
        with patch("raindrop_openai_agents.wrapper.RaindropOpenAIAgents._register_processor"):
            RaindropOpenAIAgents(
                api_key="rk_test",
                tracing_enabled=False,
                bypass_otel_for_tools=False,
            )
            mock_rd.init.assert_called_once_with(
                api_key="rk_test",
                tracing_enabled=False,
                bypass_otel_for_tools=False,
            )

    @patch("raindrop_openai_agents.wrapper.raindrop")
    def test_empty_api_key_passes_empty_string(self, mock_rd):
        """When api_key is None, raindrop.init receives empty string."""
        with patch("raindrop_openai_agents.wrapper.RaindropOpenAIAgents._register_processor"):
            with warnings.catch_warnings():
                warnings.simplefilter("ignore")
                RaindropOpenAIAgents(api_key=None)
            mock_rd.init.assert_called_once_with(
                api_key="",
                tracing_enabled=True,
                bypass_otel_for_tools=True,
            )


class TestRaindropOpenAIAgents:
    """Tests for the top-level RaindropOpenAIAgents class."""

    @patch("raindrop_openai_agents.wrapper.raindrop")
    def test_init_calls_raindrop_init(self, mock_rd):
        with patch("raindrop_openai_agents.wrapper.RaindropOpenAIAgents._register_processor"):
            RaindropOpenAIAgents(api_key="rk_test", user_id="u1")
            mock_rd.init.assert_called_once_with(
                api_key="rk_test",
                tracing_enabled=True,
                bypass_otel_for_tools=True,
            )

    @patch("raindrop_openai_agents.wrapper.raindrop")
    def test_processor_property(self, mock_rd):
        with patch("raindrop_openai_agents.wrapper.RaindropOpenAIAgents._register_processor"):
            r = RaindropOpenAIAgents(api_key="rk_test", user_id="u1")
            assert isinstance(r.processor, RaindropTracingProcessor)

    @patch("raindrop_openai_agents.wrapper.raindrop")
    def test_flush_delegates_to_raindrop(self, mock_rd):
        with patch("raindrop_openai_agents.wrapper.RaindropOpenAIAgents._register_processor"):
            r = RaindropOpenAIAgents(api_key="rk_test")
            r.flush()
            mock_rd.flush.assert_called_once()

    @patch("raindrop_openai_agents.wrapper.raindrop")
    def test_shutdown_delegates(self, mock_rd):
        with patch("raindrop_openai_agents.wrapper.RaindropOpenAIAgents._register_processor"):
            mock_rd.begin.return_value = _make_interaction_mock()
            r = RaindropOpenAIAgents(api_key="rk_test")
            r.processor.on_trace_start(_make_trace("t-shut"))
            assert len(r.processor._trace_event_ids) == 1
            assert len(r.processor._interactions) == 1
            r.shutdown()
            assert len(r.processor._trace_event_ids) == 0
            assert len(r.processor._pending_data) == 0
            assert len(r.processor._interactions) == 0
            mock_rd.shutdown.assert_called_once()

    @patch("raindrop_openai_agents.wrapper.raindrop")
    def test_identify_delegates(self, mock_rd):
        with patch("raindrop_openai_agents.wrapper.RaindropOpenAIAgents._register_processor"):
            r = RaindropOpenAIAgents(api_key="rk_test")
            r.identify("user-42", traits={"plan": "pro"})
            mock_rd.identify.assert_called_once_with(
                user_id="user-42", traits={"plan": "pro"}
            )

    @patch("raindrop_openai_agents.wrapper.raindrop")
    def test_identify_empty_traits(self, mock_rd):
        with patch("raindrop_openai_agents.wrapper.RaindropOpenAIAgents._register_processor"):
            r = RaindropOpenAIAgents(api_key="rk_test")
            r.identify("user-42")
            mock_rd.identify.assert_called_once_with(
                user_id="user-42", traits={}
            )

    @patch("raindrop_openai_agents.wrapper.raindrop")
    def test_track_signal_delegates(self, mock_rd):
        with patch("raindrop_openai_agents.wrapper.RaindropOpenAIAgents._register_processor"):
            r = RaindropOpenAIAgents(api_key="rk_test")
            r.track_signal("evt_abc", "thumbs_up", properties={"score": 1})
            mock_rd.track_signal.assert_called_once_with(
                event_id="evt_abc",
                name="thumbs_up",
                signal_type="default",
                timestamp=None,
                properties={"score": 1},
                attachment_id=None,
                comment=None,
                after=None,
                sentiment=None,
            )

    @patch("raindrop_openai_agents.wrapper.raindrop")
    def test_track_signal_with_sentiment(self, mock_rd):
        with patch("raindrop_openai_agents.wrapper.RaindropOpenAIAgents._register_processor"):
            r = RaindropOpenAIAgents(api_key="rk_test")
            r.track_signal("evt_abc", "thumbs_down", sentiment="NEGATIVE", comment="Bad answer")
            mock_rd.track_signal.assert_called_once_with(
                event_id="evt_abc",
                name="thumbs_down",
                signal_type="default",
                timestamp=None,
                properties=None,
                attachment_id=None,
                comment="Bad answer",
                after=None,
                sentiment="NEGATIVE",
            )

    @patch("raindrop_openai_agents.wrapper.raindrop")
    def test_track_signal_full_params(self, mock_rd):
        """All track_signal params should be forwarded to raindrop.track_signal."""
        with patch("raindrop_openai_agents.wrapper.RaindropOpenAIAgents._register_processor"):
            r = RaindropOpenAIAgents(api_key="rk_test")
            r.track_signal(
                "evt_abc",
                "edit_applied",
                "edit",
                timestamp="2026-01-01T00:00:00Z",
                properties={"key": "val"},
                attachment_id="att-1",
                comment="Edited output",
                after="new text",
                sentiment="POSITIVE",
            )
            mock_rd.track_signal.assert_called_once_with(
                event_id="evt_abc",
                name="edit_applied",
                signal_type="edit",
                timestamp="2026-01-01T00:00:00Z",
                properties={"key": "val"},
                attachment_id="att-1",
                comment="Edited output",
                after="new text",
                sentiment="POSITIVE",
            )

    @patch("raindrop_openai_agents.wrapper.raindrop")
    def test_empty_api_key_warns(self, mock_rd):
        """Empty api_key should emit a warnings.warn, not logger.warning."""
        with patch("raindrop_openai_agents.wrapper.RaindropOpenAIAgents._register_processor"):
            with warnings.catch_warnings(record=True) as w:
                warnings.simplefilter("always")
                RaindropOpenAIAgents(api_key="")
            assert len(w) >= 1
            assert "api_key not provided" in str(w[0].message)

    @patch("raindrop_openai_agents.wrapper.raindrop")
    def test_none_api_key_warns(self, mock_rd):
        """None api_key should also emit a warning."""
        with patch("raindrop_openai_agents.wrapper.RaindropOpenAIAgents._register_processor"):
            with warnings.catch_warnings(record=True) as w:
                warnings.simplefilter("always")
                RaindropOpenAIAgents()
            assert len(w) >= 1
            assert "api_key not provided" in str(w[0].message)

    @patch("raindrop_openai_agents.wrapper.raindrop")
    def test_user_id_defaults_to_unknown(self, mock_rd):
        with patch("raindrop_openai_agents.wrapper.RaindropOpenAIAgents._register_processor"):
            r = RaindropOpenAIAgents(api_key="rk_test")
            assert r._user_id == "unknown"
            assert r.processor._user_id == "unknown"

    @patch("raindrop_openai_agents.wrapper.raindrop")
    def test_processor_works_end_to_end(self, mock_rd):
        with patch("raindrop_openai_agents.wrapper.RaindropOpenAIAgents._register_processor"):
            mock_interaction = _make_interaction_mock()
            mock_rd.begin.return_value = mock_interaction

            r = RaindropOpenAIAgents(api_key="rk_test", user_id="u1")
            p = r.processor

            p.on_trace_start(_make_trace("tf1"))
            p.on_trace_end(_make_trace("tf1"))

            mock_rd.begin.assert_called_once()
            mock_interaction.finish.assert_called_once()

    @patch("raindrop_openai_agents.wrapper.raindrop")
    def test_debug_flag_sets_logger_level(self, mock_rd):
        """Verify that debug=True sets the module logger to DEBUG level."""
        with patch("raindrop_openai_agents.wrapper.RaindropOpenAIAgents._register_processor"):
            import raindrop_openai_agents.wrapper as mod
            original_level = mod.logger.level
            try:
                RaindropOpenAIAgents(api_key="rk_test", debug=True)
                assert mod.logger.level == logging.DEBUG
            finally:
                mod.logger.setLevel(original_level)


class TestFactory:
    def test_factory_returns_instance(self):
        with patch("raindrop_openai_agents.wrapper.raindrop") as mock_rd:
            with patch("raindrop_openai_agents.wrapper.RaindropOpenAIAgents._register_processor"):
                result = create_raindrop_openai_agents(api_key="rk_test", user_id="user-1")

                assert isinstance(result, RaindropOpenAIAgents)
                assert isinstance(result.processor, RaindropTracingProcessor)
                mock_rd.init.assert_called_once_with(
                    api_key="rk_test",
                    tracing_enabled=True,
                    bypass_otel_for_tools=True,
                )

    def test_factory_processor_works(self):
        with patch("raindrop_openai_agents.wrapper.raindrop") as mock_rd:
            with patch("raindrop_openai_agents.wrapper.RaindropOpenAIAgents._register_processor"):
                mock_rd.begin.return_value = _make_interaction_mock()
                result = create_raindrop_openai_agents(api_key="rk_test", user_id="user-1")
                processor = result.processor

                processor.on_trace_start(_make_trace("tf1"))
                processor.on_trace_end(_make_trace("tf1"))

                mock_rd.begin.assert_called_once()

    def test_factory_with_convo_id(self):
        with patch("raindrop_openai_agents.wrapper.raindrop") as mock_rd:
            with patch("raindrop_openai_agents.wrapper.RaindropOpenAIAgents._register_processor"):
                mock_rd.begin.return_value = _make_interaction_mock()
                result = create_raindrop_openai_agents(api_key="rk_test", user_id="u1", convo_id="c1")
                processor = result.processor

                processor.on_trace_start(_make_trace("tf2"))
                processor.on_trace_end(_make_trace("tf2"))

                begin_kwargs = mock_rd.begin.call_args.kwargs
                assert begin_kwargs["convo_id"] == "c1"

    def test_factory_with_debug(self):
        with patch("raindrop_openai_agents.wrapper.raindrop"):
            with patch("raindrop_openai_agents.wrapper.RaindropOpenAIAgents._register_processor"):
                result = create_raindrop_openai_agents(api_key="rk_test", debug=True)
                assert isinstance(result, RaindropOpenAIAgents)

    def test_factory_with_tracing_flags(self):
        """Factory should forward tracing_enabled and bypass_otel_for_tools."""
        with patch("raindrop_openai_agents.wrapper.raindrop") as mock_rd:
            with patch("raindrop_openai_agents.wrapper.RaindropOpenAIAgents._register_processor"):
                create_raindrop_openai_agents(
                    api_key="rk_test",
                    tracing_enabled=False,
                    bypass_otel_for_tools=False,
                )
                mock_rd.init.assert_called_once_with(
                    api_key="rk_test",
                    tracing_enabled=False,
                    bypass_otel_for_tools=False,
                )


class TestDoubleWrapGuard:
    """Test that registering the processor twice is prevented and reuses the same processor."""

    @patch("raindrop_openai_agents.wrapper.raindrop")
    def test_double_wrap_guard(self, mock_rd):
        import raindrop_openai_agents.wrapper as mod
        # Reset the markers for this test
        original_marker = getattr(mod, "_raindrop_openai_agents_wrapped", False)
        original_proc = getattr(mod, "_raindrop_openai_agents_processor", None)
        setattr(mod, "_raindrop_openai_agents_wrapped", False)
        setattr(mod, "_raindrop_openai_agents_processor", None)

        try:
            with patch("agents.tracing.add_trace_processor") as mock_add:
                r1 = RaindropOpenAIAgents(api_key="rk_test")
                r2 = RaindropOpenAIAgents(api_key="rk_test")
                # Should only be called once due to double-wrap guard
                assert mock_add.call_count == 1
        except ImportError:
            # agents SDK not installed — guard logic still works
            pass
        finally:
            setattr(mod, "_raindrop_openai_agents_wrapped", original_marker)
            setattr(mod, "_raindrop_openai_agents_processor", original_proc)

    @patch("raindrop_openai_agents.wrapper.raindrop")
    def test_second_instance_reuses_registered_processor(self, mock_rd):
        """Second instantiation should reuse the registered processor, not create an orphan."""
        import raindrop_openai_agents.wrapper as mod
        original_marker = getattr(mod, "_raindrop_openai_agents_wrapped", False)
        original_proc = getattr(mod, "_raindrop_openai_agents_processor", None)
        setattr(mod, "_raindrop_openai_agents_wrapped", False)
        setattr(mod, "_raindrop_openai_agents_processor", None)

        try:
            with patch("agents.tracing.add_trace_processor"):
                r1 = RaindropOpenAIAgents(api_key="rk_test", user_id="user-A")
                first_processor = r1.processor

                r2 = RaindropOpenAIAgents(api_key="rk_test", user_id="user-B")
                second_processor = r2.processor

                # Both instances should reference the same processor object
                assert first_processor is second_processor
                # The processor should have the updated user_id from the second instance
                assert second_processor._user_id == "user-B"
        except ImportError:
            pass
        finally:
            setattr(mod, "_raindrop_openai_agents_wrapped", original_marker)
            setattr(mod, "_raindrop_openai_agents_processor", original_proc)

    @patch("raindrop_openai_agents.wrapper.raindrop")
    def test_shutdown_and_recreate_reuses_processor(self, mock_rd):
        """After shutdown + re-create, the new instance should reuse the registered processor."""
        import raindrop_openai_agents.wrapper as mod
        original_marker = getattr(mod, "_raindrop_openai_agents_wrapped", False)
        original_proc = getattr(mod, "_raindrop_openai_agents_processor", None)
        setattr(mod, "_raindrop_openai_agents_wrapped", False)
        setattr(mod, "_raindrop_openai_agents_processor", None)

        try:
            with patch("agents.tracing.add_trace_processor"):
                mock_rd.begin.return_value = _make_interaction_mock()

                r1 = RaindropOpenAIAgents(api_key="rk_1", user_id="user-A")
                first_processor = r1.processor
                r1.shutdown()

                # Re-create with different config
                r2 = RaindropOpenAIAgents(api_key="rk_2", user_id="user-B", convo_id="c2")
                # Should reuse the same processor, not create an orphan
                assert r2.processor is first_processor
                assert r2.processor._user_id == "user-B"
                assert r2.processor._convo_id == "c2"

                # Processor should still work (state was cleared by shutdown, but it's reregistered)
                r2.processor.on_trace_start(_make_trace("t-reuse"))
                mock_rd.begin.assert_called()
                assert len(r2.processor._trace_event_ids) == 1
        except ImportError:
            pass
        finally:
            setattr(mod, "_raindrop_openai_agents_wrapped", original_marker)
            setattr(mod, "_raindrop_openai_agents_processor", original_proc)


class TestImports:
    """Test that the public API is importable from __init__."""

    def test_class_importable(self):
        from raindrop_openai_agents import RaindropOpenAIAgents
        assert RaindropOpenAIAgents is not None

    def test_processor_importable(self):
        from raindrop_openai_agents import RaindropTracingProcessor
        assert RaindropTracingProcessor is not None

    def test_factory_importable(self):
        from raindrop_openai_agents import create_raindrop_openai_agents
        assert create_raindrop_openai_agents is not None

    def test_version(self):
        from raindrop_openai_agents import __version__
        assert __version__ == "0.0.3"


class TestInteractionLifecycle:
    """Tests for the full interaction lifecycle with tool spans."""

    def test_full_agent_run_with_tools(self):
        """End-to-end: trace with function + response spans using Interaction API."""
        with patch("raindrop_openai_agents.wrapper.raindrop") as mock_rd:
            mock_interaction = _make_interaction_mock()
            mock_rd.begin.return_value = mock_interaction

            p = RaindropTracingProcessor(user_id="user-1", convo_id="convo-1")

            # Start trace
            p.on_trace_start(_make_trace("t-e2e", name="weather_agent"))

            # Tool span: get_weather
            fn_span = _make_function_span(
                trace_id="t-e2e",
                name="get_weather",
                input_val='{"city": "London"}',
                output_val='{"temp": 15, "condition": "cloudy"}',
                started_at="2024-06-15T10:00:00.000+00:00",
                ended_at="2024-06-15T10:00:00.350+00:00",
            )
            p.on_span_end(fn_span)

            # Response span with usage
            response_data = MagicMock()
            response_data.type = "response"
            response_data.input = [{"role": "user", "content": "What's the weather in London?"}]
            response_data.error = None
            response_obj = MagicMock()
            response_obj.model = "gpt-4o"
            response_obj.status = "completed"
            content_block = MagicMock()
            content_block.text = "It's 15°C and cloudy in London."
            output_msg = MagicMock()
            output_msg.content = [content_block]
            output_msg.finish_reason = None
            output_msg.status = None
            response_obj.output = [output_msg]
            usage_obj = MagicMock()
            usage_obj.input_tokens = 50
            usage_obj.output_tokens = 20
            usage_obj.input_tokens_details = MagicMock()
            usage_obj.input_tokens_details.cached_tokens = 30
            usage_obj.output_tokens_details = None
            usage_obj.prompt_tokens_details = None
            usage_obj.completion_tokens_details = None
            response_obj.usage = usage_obj
            response_data.response = response_obj

            resp_span = MagicMock()
            resp_span.trace_id = "t-e2e"
            resp_span.span_id = "s-resp"
            resp_span.span_data = response_data
            p.on_span_end(resp_span)

            # End trace
            p.on_trace_end(_make_trace("t-e2e", name="weather_agent"))

            # Verify interaction was created correctly
            begin_kwargs = mock_rd.begin.call_args.kwargs
            assert begin_kwargs["user_id"] == "user-1"
            assert begin_kwargs["event"] == "weather_agent"
            assert begin_kwargs["convo_id"] == "convo-1"

            # Verify tool was tracked
            mock_interaction.track_tool.assert_called_once()
            tool_kwargs = mock_interaction.track_tool.call_args.kwargs
            assert tool_kwargs["name"] == "get_weather"
            assert tool_kwargs["duration_ms"] == 350.0

            # Verify input was set
            mock_interaction.set_input.assert_called_once()

            # Verify model was set via _track_ai_partial
            mock_rd._track_ai_partial.assert_called_once()

            # Verify properties were set
            mock_interaction.set_properties.assert_called()
            props = mock_interaction.set_properties.call_args[0][0]
            assert props["ai.usage.prompt_tokens"] == 50
            assert props["ai.usage.completion_tokens"] == 20
            assert props["ai.usage.cached_tokens"] == 30
            assert props["ai.finish_reason"] == "completed"

            # Verify interaction was finished with output
            mock_interaction.finish.assert_called_once()
            finish_kwargs = mock_interaction.finish.call_args.kwargs
            assert "15°C" in finish_kwargs["output"]

            # Verify no leftover state
            assert len(p._trace_event_ids) == 0
            assert len(p._pending_data) == 0
            assert len(p._interactions) == 0

    def test_interaction_model_tracking_via_partial(self):
        """Model should be tracked via _track_ai_partial when interaction is used."""
        with patch("raindrop_openai_agents.wrapper.raindrop") as mock_rd:
            mock_interaction = _make_interaction_mock()
            mock_rd.begin.return_value = mock_interaction

            p = RaindropTracingProcessor(user_id="test-user")
            p.on_trace_start(_make_trace("t-model"))
            p.on_span_end(_make_span("t-model", "s1", "generation",
                model="gpt-4o-2024-08-06",
                input="Hi",
                output="Hello"))
            p.on_trace_end(_make_trace("t-model"))

            mock_rd._track_ai_partial.assert_called_once()
            # PartialTrackAIEvent was called with ai_data={"model": "gpt-4o-2024-08-06"}
            partial_kwargs = mock_rd.PartialTrackAIEvent.call_args.kwargs
            assert partial_kwargs["ai_data"] == {"model": "gpt-4o-2024-08-06"}

    def test_model_fallback_to_properties_when_partial_fails(self):
        """Model should be included in properties when _track_ai_partial fails."""
        with patch("raindrop_openai_agents.wrapper.raindrop") as mock_rd:
            mock_interaction = _make_interaction_mock()
            mock_rd.begin.return_value = mock_interaction
            mock_rd._track_ai_partial.side_effect = AttributeError("no such method")

            p = RaindropTracingProcessor(user_id="test-user")
            p.on_trace_start(_make_trace("t-model-fb"))
            p.on_span_end(_make_span("t-model-fb", "s1", "generation",
                model="gpt-4o",
                input="Hi",
                output="Hello",
                usage={"input_tokens": 10, "output_tokens": 5}))
            p.on_trace_end(_make_trace("t-model-fb"))

            # _track_ai_partial failed, so model should appear in properties
            mock_interaction.set_properties.assert_called()
            props = mock_interaction.set_properties.call_args[0][0]
            assert props["ai.model"] == "gpt-4o"
            # Other properties should still be present
            assert props["ai.usage.prompt_tokens"] == 10


class TestGetItemBackwardCompat:
    """Tests for __getitem__ dict-style backward compatibility."""

    @patch("raindrop_openai_agents.wrapper.raindrop")
    def test_getitem_flush(self, mock_rd):
        """raindrop['flush'] should return the flush method with a DeprecationWarning."""
        with patch("raindrop_openai_agents.wrapper.RaindropOpenAIAgents._register_processor"):
            r = RaindropOpenAIAgents(api_key="rk_test")
            with warnings.catch_warnings(record=True) as w:
                warnings.simplefilter("always")
                flush_fn = r["flush"]
            assert callable(flush_fn)
            assert len(w) == 1
            assert issubclass(w[0].category, DeprecationWarning)
            assert "flush" in str(w[0].message)

    @patch("raindrop_openai_agents.wrapper.raindrop")
    def test_getitem_shutdown(self, mock_rd):
        """raindrop['shutdown'] should return the shutdown method with a DeprecationWarning."""
        with patch("raindrop_openai_agents.wrapper.RaindropOpenAIAgents._register_processor"):
            r = RaindropOpenAIAgents(api_key="rk_test")
            with warnings.catch_warnings(record=True) as w:
                warnings.simplefilter("always")
                shutdown_fn = r["shutdown"]
            assert callable(shutdown_fn)
            assert issubclass(w[0].category, DeprecationWarning)

    @patch("raindrop_openai_agents.wrapper.raindrop")
    def test_getitem_unknown_key_raises(self, mock_rd):
        """Unknown keys should raise KeyError."""
        with patch("raindrop_openai_agents.wrapper.RaindropOpenAIAgents._register_processor"):
            r = RaindropOpenAIAgents(api_key="rk_test")
            import pytest
            with pytest.raises(KeyError):
                r["nonexistent"]
