"""End-to-end tests for raindrop-openai-agents.

These tests make REAL API calls to OpenAI and the Raindrop backend.
They are skipped in CI where the required environment variables are
not available.

Required env vars:
    RAINDROP_WRITE_KEY (or RAINDROP_API_KEY) — Raindrop write key
    OPENAI_API_KEY                           — OpenAI API key
    RAINDROP_DASHBOARD_TOKEN                 — Bearer token for dashboard TRPC API
    RAINDROP_BACKEND_URL (optional)          — defaults to https://backend.raindrop.ai

Run locally:
    cd packages/openai-agents-python
    source .venv/bin/activate
    export RAINDROP_WRITE_KEY=your-write-key
    export OPENAI_API_KEY=sk-...
    export RAINDROP_DASHBOARD_TOKEN=eyJ...
    python -m pytest tests/test_e2e.py -v -s
"""

from __future__ import annotations

import json
import os
import time
import urllib.parse
import uuid

import pytest
import requests

WRITE_KEY = os.getenv("RAINDROP_WRITE_KEY") or os.getenv("RAINDROP_API_KEY")
OPENAI_KEY = os.getenv("OPENAI_API_KEY")
DASHBOARD_TOKEN = os.getenv("RAINDROP_DASHBOARD_TOKEN")
BACKEND_URL = os.getenv("RAINDROP_BACKEND_URL", "https://backend.raindrop.ai")

skip_unless_e2e = pytest.mark.skipif(
    not all([WRITE_KEY, OPENAI_KEY, DASHBOARD_TOKEN]),
    reason="RAINDROP_WRITE_KEY, OPENAI_API_KEY, and RAINDROP_DASHBOARD_TOKEN required",
)

RUN_ID = uuid.uuid4().hex[:10]
MODEL = "gpt-4o-mini"


# ======================================================================
# Dashboard TRPC query helpers
# ======================================================================


def _query_dashboard(limit: int = 50) -> list[dict]:
    """Fetch recent events from the dashboard TRPC API."""
    input_obj = {"json": {"limit": limit, "orderBy": {"field": "timestamp", "direction": "desc"}}}
    encoded = urllib.parse.quote(json.dumps(input_obj))
    resp = requests.get(
        f"{BACKEND_URL}/api/trpc/events.list?input={encoded}",
        headers={"Authorization": f"Bearer {DASHBOARD_TOKEN}"},
        timeout=20,
    )
    resp.raise_for_status()
    data = resp.json()
    return data.get("result", {}).get("data", [])


def poll_events(
    user_id: str,
    min_count: int = 1,
    timeout: int = 120,
    interval: int = 5,
) -> list[dict]:
    """Poll the dashboard TRPC API until *min_count* events for *user_id* appear."""
    deadline = time.time() + timeout
    matched: list[dict] = []
    while time.time() < deadline:
        all_events = _query_dashboard()
        matched = [e for e in all_events if e.get("userId") == user_id]
        if len(matched) >= min_count:
            return matched
        time.sleep(interval)
    raise TimeoutError(
        f"Expected >= {min_count} events for userId={user_id}, "
        f"got {len(matched)} after {timeout}s"
    )


# ======================================================================
# Helpers
# ======================================================================


def _make_user(suffix: str) -> str:
    return f"e2e_oai_{RUN_ID}_{suffix}"


def _make_convo(suffix: str) -> str:
    return f"e2e_convo_{RUN_ID}_{suffix}"


# ======================================================================
# E2E Tests
# ======================================================================


@skip_unless_e2e
class TestBasicAgentRun:
    """Basic Agent.run() → verify full event shape in dashboard."""

    def test_event_shape(self):
        from agents import Agent, Runner

        from raindrop_openai_agents import RaindropOpenAIAgents

        user_id = _make_user("basic")
        convo_id = _make_convo("basic")
        raindrop = RaindropOpenAIAgents(
            api_key=WRITE_KEY,
            user_id=user_id,
            convo_id=convo_id,
        )

        agent = Agent(
            name="E2E-Basic",
            model=MODEL,
            instructions="Reply with exactly: Hello, world!",
        )
        result = Runner.run_sync(agent, "Say hello")
        assert result.final_output is not None

        raindrop.flush()
        raindrop.shutdown()

        events = poll_events(user_id)
        assert len(events) >= 1, f"Expected at least 1 event for userId={user_id}"
        ev = events[0]

        assert ev["userId"] == user_id

        ai = ev.get("aiData") or {}
        assert ai.get("input"), "aiData.input should be captured"
        assert ai.get("output"), "aiData.output should be captured"
        assert ai.get("convoId") == convo_id, (
            f"aiData.convoId should be {convo_id}, got {ai.get('convoId')}"
        )

        assert "isPending" not in ev or not ev["isPending"], "Event should be finalized"


@skip_unless_e2e
class TestModelTracking:
    """Model name should be captured in aiData."""

    def test_model_in_event(self):
        from agents import Agent, Runner

        from raindrop_openai_agents import RaindropOpenAIAgents

        user_id = _make_user("model")
        raindrop = RaindropOpenAIAgents(api_key=WRITE_KEY, user_id=user_id)

        agent = Agent(name="E2E-Model", model=MODEL, instructions="Reply briefly.")
        Runner.run_sync(agent, "What is 2+2?")

        raindrop.flush()
        raindrop.shutdown()

        events = poll_events(user_id)
        ai = events[0].get("aiData") or {}
        model = ai.get("model") or ""
        assert "gpt" in model.lower(), f"Expected model containing 'gpt', got: {model}"


@skip_unless_e2e
class TestTokenUsage:
    """Token usage should be captured in properties with exact keys."""

    def test_tokens_present(self):
        from agents import Agent, Runner

        from raindrop_openai_agents import RaindropOpenAIAgents

        user_id = _make_user("tokens")
        raindrop = RaindropOpenAIAgents(api_key=WRITE_KEY, user_id=user_id)

        agent = Agent(name="E2E-Tokens", model=MODEL, instructions="Reply briefly.")
        Runner.run_sync(agent, "What is the capital of France?")

        raindrop.flush()
        raindrop.shutdown()

        events = poll_events(user_id)
        props = events[0].get("properties") or {}

        prompt_tokens = props.get("ai.usage.prompt_tokens")
        completion_tokens = props.get("ai.usage.completion_tokens")

        assert prompt_tokens is not None and int(prompt_tokens) > 0, (
            f"ai.usage.prompt_tokens should be > 0, got {prompt_tokens}"
        )
        assert completion_tokens is not None and int(completion_tokens) > 0, (
            f"ai.usage.completion_tokens should be > 0, got {completion_tokens}"
        )


@skip_unless_e2e
class TestFinishReason:
    """finish_reason should be captured in properties."""

    def test_finish_reason_present(self):
        from agents import Agent, Runner

        from raindrop_openai_agents import RaindropOpenAIAgents

        user_id = _make_user("finreason")
        raindrop = RaindropOpenAIAgents(api_key=WRITE_KEY, user_id=user_id)

        agent = Agent(name="E2E-FinReason", model=MODEL, instructions="Reply with one word.")
        Runner.run_sync(agent, "Say yes")

        raindrop.flush()
        raindrop.shutdown()

        events = poll_events(user_id)
        props = events[0].get("properties") or {}
        finish_reason = props.get("ai.finish_reason")
        assert finish_reason is not None, (
            f"ai.finish_reason should be present, got props: {list(props.keys())}"
        )
        assert finish_reason in ("completed", "stop"), (
            f"Expected 'completed' or 'stop', got: {finish_reason}"
        )


@skip_unless_e2e
class TestToolCallTracking:
    """Agent with a tool → verify tool spans are captured."""

    def test_tool_name_and_output_tracked(self):
        from agents import Agent, Runner, function_tool

        from raindrop_openai_agents import RaindropOpenAIAgents

        @function_tool
        def get_weather(city: str) -> str:
            """Get the weather for a city."""
            return f"Sunny, 22°C in {city}"

        user_id = _make_user("tool")
        raindrop = RaindropOpenAIAgents(api_key=WRITE_KEY, user_id=user_id)

        agent = Agent(
            name="E2E-Tool",
            model=MODEL,
            instructions="Always use the get_weather tool to answer weather questions.",
            tools=[get_weather],
        )
        result = Runner.run_sync(agent, "What's the weather in Paris?")
        assert result.final_output is not None

        raindrop.flush()
        raindrop.shutdown()

        events = poll_events(user_id)
        assert len(events) >= 1
        ev = events[0]

        ai = ev.get("aiData") or {}
        assert ai.get("output"), "Should have output text"

        tool_call_names = ev.get("toolCallNames") or []
        tool_calls = ev.get("toolCalls") or []

        has_tool_evidence = (
            "get_weather" in str(tool_call_names)
            or "get_weather" in str(tool_calls)
            or "get_weather" in str(ev.get("properties", {}))
        )
        assert has_tool_evidence, (
            f"Expected tool call 'get_weather' to appear somewhere in the event. "
            f"toolCallNames={tool_call_names}, toolCalls length={len(tool_calls)}, "
            f"props keys={list((ev.get('properties') or {}).keys())}"
        )


@skip_unless_e2e
class TestMultipleRunsNoLeak:
    """Multiple sequential runs produce distinct events with no cross-contamination."""

    def test_three_runs_distinct_events(self):
        from agents import Agent, Runner

        from raindrop_openai_agents import RaindropOpenAIAgents

        user_id = _make_user("multi")
        raindrop = RaindropOpenAIAgents(api_key=WRITE_KEY, user_id=user_id)

        agent = Agent(
            name="E2E-Multi",
            model=MODEL,
            instructions="Reply with exactly the city name you are asked about, nothing else.",
        )

        cities = ["Tokyo", "London", "Cairo"]
        for city in cities:
            Runner.run_sync(agent, f"What city is this: {city}?")

        raindrop.flush()
        raindrop.shutdown()

        events = poll_events(user_id, min_count=3, timeout=180)
        assert len(events) >= 3, f"Expected >= 3 events, got {len(events)}"

        unique_outputs = set()
        for ev in events:
            out = (ev.get("aiData") or {}).get("output", "")
            if out:
                unique_outputs.add(out)
        assert len(unique_outputs) >= 2, (
            f"Expected >= 2 distinct outputs (proving no cross-contamination), "
            f"got {len(unique_outputs)}: {unique_outputs}"
        )


@skip_unless_e2e
class TestConvoIdGrouping:
    """Events with same convo_id are grouped together."""

    def test_shared_convo_id(self):
        from agents import Agent, Runner

        from raindrop_openai_agents import RaindropOpenAIAgents

        user_id = _make_user("convo")
        convo_id = _make_convo("shared")

        raindrop = RaindropOpenAIAgents(
            api_key=WRITE_KEY,
            user_id=user_id,
            convo_id=convo_id,
        )

        agent = Agent(name="E2E-Convo", model=MODEL, instructions="Reply briefly.")
        Runner.run_sync(agent, "First message")
        Runner.run_sync(agent, "Second message")

        raindrop.flush()
        raindrop.shutdown()

        events = poll_events(user_id, min_count=2, timeout=120)
        assert len(events) >= 2

        for ev in events:
            ev_convo = (ev.get("aiData") or {}).get("convoId")
            assert ev_convo == convo_id, (
                f"Expected aiData.convoId={convo_id}, got {ev_convo}"
            )


@skip_unless_e2e
class TestFactoryFunction:
    """Factory function API works the same as class-based."""

    def test_factory_produces_events(self):
        from agents import Agent, Runner

        from raindrop_openai_agents import create_raindrop_openai_agents

        user_id = _make_user("factory")
        convo_id = _make_convo("factory")
        raindrop = create_raindrop_openai_agents(
            api_key=WRITE_KEY,
            user_id=user_id,
            convo_id=convo_id,
        )

        agent = Agent(name="E2E-Factory", model=MODEL, instructions="Reply briefly.")
        Runner.run_sync(agent, "Hello from factory")

        raindrop.flush()
        raindrop.shutdown()

        events = poll_events(user_id)
        assert len(events) >= 1
        ev = events[0]
        assert ev["userId"] == user_id
        ai = ev.get("aiData") or {}
        assert ai.get("output"), "Should have output"
        assert ai.get("convoId") == convo_id


@skip_unless_e2e
class TestMultiToolAgent:
    """Agent with multiple tools → verify both tool names appear."""

    def test_two_tools_both_tracked(self):
        from agents import Agent, Runner, function_tool

        from raindrop_openai_agents import RaindropOpenAIAgents

        @function_tool
        def get_weather(city: str) -> str:
            """Get the current weather for a city."""
            return f"Sunny, 22°C in {city}"

        @function_tool
        def get_population(city: str) -> str:
            """Get the population of a city."""
            return f"{city} has approximately 2.1 million people"

        user_id = _make_user("2tools")
        raindrop = RaindropOpenAIAgents(api_key=WRITE_KEY, user_id=user_id)

        agent = Agent(
            name="E2E-MultiTool",
            model=MODEL,
            instructions=(
                "You have two tools: get_weather and get_population. "
                "When asked about a city, call BOTH tools, then give a brief answer."
            ),
            tools=[get_weather, get_population],
        )
        Runner.run_sync(agent, "Tell me about Paris — weather and population.")

        raindrop.flush()
        raindrop.shutdown()

        events = poll_events(user_id)
        ev = events[0]

        tool_evidence = json.dumps(ev.get("toolCalls", [])) + json.dumps(ev.get("toolCallNames", []))
        props_str = json.dumps(ev.get("properties", {}))
        combined = tool_evidence + props_str

        assert "get_weather" in combined, (
            f"Expected 'get_weather' in tool data. "
            f"toolCallNames={ev.get('toolCallNames')}, toolCalls count={len(ev.get('toolCalls', []))}"
        )
        assert "get_population" in combined, (
            f"Expected 'get_population' in tool data. "
            f"toolCallNames={ev.get('toolCallNames')}, toolCalls count={len(ev.get('toolCalls', []))}"
        )


@skip_unless_e2e
class TestEventNameIsTraceName:
    """The event name should reflect the agent/trace name."""

    def test_event_name(self):
        from agents import Agent, Runner

        from raindrop_openai_agents import RaindropOpenAIAgents

        user_id = _make_user("evname")
        raindrop = RaindropOpenAIAgents(api_key=WRITE_KEY, user_id=user_id)

        agent = Agent(name="My-Custom-Agent", model=MODEL, instructions="Reply briefly.")
        Runner.run_sync(agent, "Hi")

        raindrop.flush()
        raindrop.shutdown()

        events = poll_events(user_id)
        ev = events[0]
        event_name = ev.get("name", "")
        assert event_name, f"Event name should be set, got empty. Keys: {list(ev.keys())}"


@skip_unless_e2e
class TestDictCompatBackwardCompat:
    """Legacy dict-access pattern still works end-to-end."""

    def test_dict_style_flush_and_shutdown(self):
        import warnings

        from agents import Agent, Runner

        from raindrop_openai_agents import create_raindrop_openai_agents

        user_id = _make_user("compat")
        raindrop = create_raindrop_openai_agents(api_key=WRITE_KEY, user_id=user_id)

        agent = Agent(name="E2E-Compat", model=MODEL, instructions="Reply briefly.")
        Runner.run_sync(agent, "Test backward compat")

        with warnings.catch_warnings():
            warnings.simplefilter("ignore", DeprecationWarning)
            raindrop["flush"]()
            raindrop["shutdown"]()

        events = poll_events(user_id)
        assert len(events) >= 1, "Dict-style flush should still deliver events"
