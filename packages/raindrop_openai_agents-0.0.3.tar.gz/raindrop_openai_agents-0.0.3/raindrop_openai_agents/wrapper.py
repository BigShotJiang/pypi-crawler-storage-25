"""
OpenAI Agents SDK TracingProcessor for Raindrop observability.

Implements the TracingProcessor interface to capture agent runs, LLM
generations, tool calls, and handoffs, shipping them to Raindrop.

Usage:
    from raindrop_openai_agents import RaindropOpenAIAgents

    raindrop = RaindropOpenAIAgents(api_key="your-write-key")
    # Processor is auto-registered globally

    from agents import Agent, Runner
    agent = Agent(name="Assistant", model="gpt-4o")
    result = Runner.run_sync(agent, "Hello!")
    raindrop.flush()
"""

from __future__ import annotations

import json
import logging
import uuid
import warnings
from datetime import datetime, timezone
from typing import TYPE_CHECKING, Any, Dict, List, Literal, Optional, Union

import raindrop.analytics as raindrop

if TYPE_CHECKING:
    from agents.tracing import Span, Trace

logger = logging.getLogger(__name__)

_WRAPPED_MARKER = "_raindrop_openai_agents_wrapped"
_REGISTERED_PROCESSOR = "_raindrop_openai_agents_processor"


class RaindropOpenAIAgents:
    """Top-level entry point for Raindrop + OpenAI Agents SDK integration.

    Initialises the Raindrop analytics backend and registers a
    :class:`RaindropTracingProcessor` with the OpenAI Agents global trace
    provider so that all agent runs are automatically captured.

    Args:
        api_key: Raindrop API key.  When ``None`` or empty, a warning is
            emitted and telemetry shipping is disabled, which is useful
            during local development.
        user_id: Default user identifier attached to every event.  Falls
            back to ``"unknown"`` when not supplied.
        convo_id: Optional conversation identifier used to group related
            events together.
        tracing_enabled: Whether to enable OTEL-based tracing in the
            Raindrop SDK.  Defaults to ``True``.
        bypass_otel_for_tools: When ``True`` (default), bypass OTEL
            instrumentation for tool calls.
        debug: When ``True``, sets the module logger to ``DEBUG`` level for
            verbose diagnostics.
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        user_id: Optional[str] = None,
        convo_id: Optional[str] = None,
        tracing_enabled: bool = True,
        bypass_otel_for_tools: bool = True,
        debug: bool = False,
    ) -> None:
        if debug:
            logger.setLevel(logging.DEBUG)

        if not api_key:
            warnings.warn(
                "[raindrop-openai-agents] api_key not provided; telemetry shipping is disabled",
                stacklevel=2,
            )

        raindrop.init(
            api_key=api_key or "",
            tracing_enabled=tracing_enabled,
            bypass_otel_for_tools=bypass_otel_for_tools,
        )

        self._user_id = user_id or "unknown"
        self._convo_id = convo_id
        self._processor = self._get_or_create_processor()

        self._register_processor()

    def _get_or_create_processor(self) -> RaindropTracingProcessor:
        """Return the already-registered processor or create a new one.

        When a processor was previously registered with the OpenAI Agents
        SDK, that same instance is reused and its ``_user_id`` /
        ``_convo_id`` are updated to match the current constructor args.
        This prevents orphaned processors after ``shutdown()`` + re-create.
        """
        import sys

        existing: Optional[RaindropTracingProcessor] = getattr(
            sys.modules[__name__], _REGISTERED_PROCESSOR, None
        )
        if existing is not None:
            logger.debug(
                "Reusing already-registered processor — updating user_id/convo_id"
            )
            existing._user_id = self._user_id
            existing._convo_id = self._convo_id
            return existing

        return RaindropTracingProcessor(
            user_id=self._user_id,
            convo_id=self._convo_id,
        )

    def _register_processor(self) -> None:
        """Register the tracing processor with the OpenAI Agents SDK.

        Uses a module-level marker to prevent double-registration when
        ``RaindropOpenAIAgents`` is instantiated more than once.  The
        processor instance is also stored at the module level so that
        subsequent instances can reuse it (see :meth:`_get_or_create_processor`).
        """
        import sys

        if getattr(sys.modules[__name__], _WRAPPED_MARKER, False):
            logger.debug("Processor already registered — skipping double-wrap")
            return

        try:
            from agents.tracing import add_trace_processor

            add_trace_processor(self._processor)
            setattr(sys.modules[__name__], _WRAPPED_MARKER, True)
            setattr(sys.modules[__name__], _REGISTERED_PROCESSOR, self._processor)
        except Exception:
            logger.debug(
                "Failed to register tracing processor with OpenAI Agents SDK",
                exc_info=True,
            )

    # -- backward compatibility -----------------------------------------------

    def __getitem__(self, key: str) -> Any:
        """Support dict-style access for backwards compatibility.

        .. deprecated::
            Use attribute access instead.
        """
        _COMPAT_MAP = {"processor": "processor", "flush": "flush", "shutdown": "shutdown"}
        if key in _COMPAT_MAP:
            warnings.warn(
                f'raindrop["{key}"] is deprecated \u2014 use raindrop.{key} instead',
                DeprecationWarning,
                stacklevel=2,
            )
            return getattr(self, key)
        raise KeyError(key)

    # -- public properties ---------------------------------------------------

    @property
    def processor(self) -> RaindropTracingProcessor:
        """Return the underlying :class:`RaindropTracingProcessor` instance.

        Use this when you need to register the processor manually instead
        of relying on auto-registration::

            from agents.tracing import add_trace_processor
            add_trace_processor(raindrop.processor)
        """
        return self._processor

    # -- public methods ------------------------------------------------------

    def flush(self) -> None:
        """Flush any buffered events to the Raindrop backend."""
        try:
            raindrop.flush()
        except Exception:
            logger.debug("Failed to flush events", exc_info=True)

    def shutdown(self) -> None:
        """Flush remaining events and release resources.

        .. note::

            The processor registration is permanent for the lifetime of the
            process because the OpenAI Agents SDK has no
            ``remove_trace_processor`` API.  Creating a new
            ``RaindropOpenAIAgents`` instance after shutdown will reuse the
            already-registered processor (updating its ``user_id`` and
            ``convo_id`` to match the new constructor arguments).
        """
        try:
            self._processor.shutdown()
        except Exception:
            logger.debug("Failed to shutdown processor", exc_info=True)
        try:
            raindrop.shutdown()
        except Exception:
            logger.debug("Failed to shutdown raindrop", exc_info=True)

    def identify(
        self,
        user_id: str,
        traits: Optional[Dict[str, Union[str, int, bool, float]]] = None,
    ) -> None:
        """Identify a user with optional traits.

        Args:
            user_id: The user identifier.
            traits: Optional dictionary of user traits.
        """
        try:
            raindrop.identify(user_id=user_id, traits=traits or {})
        except Exception:
            logger.debug("Failed to identify user", exc_info=True)

    def track_signal(
        self,
        event_id: str,
        name: str,
        signal_type: Literal["default", "feedback", "edit"] = "default",
        *,
        timestamp: Optional[str] = None,
        properties: Optional[Dict[str, object]] = None,
        attachment_id: Optional[str] = None,
        comment: Optional[str] = None,
        after: Optional[str] = None,
        sentiment: Optional[Literal["POSITIVE", "NEGATIVE"]] = None,
    ) -> None:
        """Track a signal event.

        Args:
            event_id: The event ID to associate the signal with.
            name: Signal name.
            signal_type: One of "default", "feedback", or "edit".
            timestamp: Optional ISO-8601 timestamp string.
            properties: Optional extra properties dict.
            attachment_id: Optional attachment identifier.
            comment: Optional comment text.
            after: Optional "after" value for edit signals.
            sentiment: Optional sentiment ("POSITIVE" or "NEGATIVE").
        """
        try:
            raindrop.track_signal(
                event_id=event_id,
                name=name,
                signal_type=signal_type,
                timestamp=timestamp,
                properties=properties,
                attachment_id=attachment_id,
                comment=comment,
                after=after,
                sentiment=sentiment,
            )
        except Exception:
            logger.debug("Failed to track signal", exc_info=True)


def create_raindrop_openai_agents(
    api_key: Optional[str] = None,
    user_id: Optional[str] = None,
    convo_id: Optional[str] = None,
    tracing_enabled: bool = True,
    bypass_otel_for_tools: bool = True,
    debug: bool = False,
) -> RaindropOpenAIAgents:
    """Create a Raindrop-instrumented OpenAI Agents SDK processor.

    This is a convenience factory that returns a :class:`RaindropOpenAIAgents`
    instance.  The processor is automatically registered with the global trace
    provider.

    Args:
        api_key: Raindrop API key.
        user_id: Associate all events with this user.
        convo_id: Conversation ID to group related events.
        tracing_enabled: Whether to enable OTEL-based tracing.
        bypass_otel_for_tools: When True, bypass OTEL for tool calls.
        debug: Enable verbose debug logging.

    Returns:
        A :class:`RaindropOpenAIAgents` instance.
    """
    try:
        return RaindropOpenAIAgents(
            api_key=api_key,
            user_id=user_id,
            convo_id=convo_id,
            tracing_enabled=tracing_enabled,
            bypass_otel_for_tools=bypass_otel_for_tools,
            debug=debug,
        )
    except Exception:
        logger.debug("Failed to create RaindropOpenAIAgents", exc_info=True)
        inst = RaindropOpenAIAgents.__new__(RaindropOpenAIAgents)
        inst._user_id = user_id or "unknown"
        inst._convo_id = convo_id
        inst._processor = RaindropTracingProcessor.__new__(
            RaindropTracingProcessor
        )
        inst._processor._user_id = user_id or "unknown"
        inst._processor._convo_id = convo_id
        inst._processor._trace_event_ids = {}
        inst._processor._pending_data = {}
        inst._processor._interactions = {}
        return inst


class RaindropTracingProcessor:
    """TracingProcessor implementation that ships events to Raindrop.

    This class implements the ``TracingProcessor`` interface defined by the
    OpenAI Agents SDK.  It is used internally by :class:`RaindropOpenAIAgents`
    and can also be registered manually via
    ``agents.tracing.add_trace_processor``.
    """

    def __init__(
        self,
        user_id: Optional[str] = None,
        convo_id: Optional[str] = None,
    ) -> None:
        self._user_id = user_id or "unknown"
        self._convo_id = convo_id
        self._trace_event_ids: Dict[str, str] = {}
        self._pending_data: Dict[str, Dict[str, object]] = {}
        self._interactions: Dict[str, object] = {}

    # -- TracingProcessor interface ------------------------------------------

    def on_trace_start(self, trace: Trace) -> None:
        """Called by the SDK when a new trace begins."""
        try:
            trace_id = getattr(trace, "trace_id", None)
            if not trace_id:
                return
            event_id = str(uuid.uuid4())
            self._trace_event_ids[trace_id] = event_id

            try:
                interaction = raindrop.begin(
                    user_id=self._user_id,
                    event=getattr(trace, "name", "agent_run") or "agent_run",
                    event_id=event_id,
                    convo_id=self._convo_id,
                )
                self._interactions[trace_id] = interaction
            except Exception:
                logger.debug("Failed to create interaction", exc_info=True)
        except Exception:
            logger.debug("Error in on_trace_start", exc_info=True)

    def on_trace_end(self, trace: Trace) -> None:
        """Called by the SDK when a trace finishes."""
        try:
            trace_id = getattr(trace, "trace_id", None)
            if not trace_id:
                return
            event_id = self._trace_event_ids.pop(trace_id, None)
            pending = self._pending_data.pop(trace_id, {})
            interaction = self._interactions.pop(trace_id, None)

            if interaction is not None:
                # Set input on the interaction
                input_val = pending.get("input")
                if input_val is not None:
                    try:
                        interaction.set_input(str(input_val))
                    except Exception:
                        logger.debug(
                            "Failed to set interaction input", exc_info=True
                        )

                # Set model via _track_ai_partial (preferred), with fallback
                # to properties so the model is never silently lost.
                model = pending.get("model")
                model_tracked = False
                if model and event_id:
                    try:
                        raindrop._track_ai_partial(
                            raindrop.PartialTrackAIEvent(
                                event_id=event_id,
                                ai_data={"model": model},
                            )
                        )
                        model_tracked = True
                    except Exception:
                        logger.debug(
                            "Failed to track model via _track_ai_partial",
                            exc_info=True,
                        )

                # Set properties on the interaction
                props = pending.get("properties")
                # Include model in properties as fallback when
                # _track_ai_partial is unavailable or failed.
                if model and not model_tracked:
                    props = dict(props) if props else {}
                    props["ai.model"] = model
                if props:
                    try:
                        interaction.set_properties(props)
                    except Exception:
                        logger.debug(
                            "Failed to set interaction properties",
                            exc_info=True,
                        )

                # Finish the interaction with output
                try:
                    interaction.finish(output=pending.get("output"))
                except Exception:
                    logger.debug(
                        "Failed to finish interaction", exc_info=True
                    )
            elif event_id:
                # Fallback to track_ai if interaction creation failed
                raindrop.track_ai(
                    user_id=self._user_id,
                    event=getattr(trace, "name", "agent_run") or "agent_run",
                    event_id=event_id,
                    input=pending.get("input"),
                    output=pending.get("output"),
                    model=pending.get("model"),
                    properties=pending.get("properties") or None,
                    convo_id=self._convo_id,
                )
        except Exception:
            logger.debug("Error in on_trace_end", exc_info=True)

    def on_span_start(self, span: Span) -> None:
        """Called by the SDK when a new span begins inside a trace."""
        try:
            trace_id = getattr(span, "trace_id", None)
            if not trace_id or trace_id not in self._trace_event_ids:
                return
        except Exception:
            logger.debug("Error in on_span_start", exc_info=True)

    def on_span_end(self, span: Span) -> None:
        """Called by the SDK when a span finishes."""
        try:
            trace_id = getattr(span, "trace_id", None)
            if not trace_id or trace_id not in self._trace_event_ids:
                return

            data = getattr(span, "span_data", None)
            if not data:
                return

            span_type = getattr(data, "type", None)

            if span_type == "response":
                self._extract_response_span(trace_id, data)
            elif span_type == "generation":
                self._extract_generation_span(trace_id, data)
            elif span_type == "function":
                self._extract_function_span(trace_id, span, data)
        except Exception:
            logger.debug("Error in on_span_end", exc_info=True)

    # -- span data extraction ------------------------------------------------

    def _extract_response_span(self, trace_id: str, data: object) -> None:
        """Extract data from a ``response`` span (OpenAI Agents SDK format).

        In multi-response traces (e.g. multi-agent handoffs), later responses
        overwrite earlier ones.  Only the last response's data survives.  This
        is a known limitation — the TypeScript SDK preserves all via individual
        spans.
        """
        pending = self._pending_data.setdefault(trace_id, {})

        input_val = getattr(data, "input", None) or getattr(data, "_input", None)
        if input_val is not None:
            pending["input"] = _format_messages(input_val)

        response = getattr(data, "response", None) or getattr(data, "_response", None)

        # Capture error information if present
        error = getattr(data, "error", None)
        if error is not None:
            _record_error(pending, error)

        if response is None:
            return

        model: Optional[str] = getattr(response, "model", None)
        if model:
            pending["model"] = model

        output_parts = getattr(response, "output", None)
        if output_parts:
            texts: List[str] = []
            for part in output_parts:
                content = getattr(part, "content", None)
                if content:
                    for block in content:
                        text: Optional[str] = getattr(block, "text", None)
                        if text:
                            texts.append(text)
            if texts:
                pending["output"] = "\n".join(texts)

        # Extract finish_reason from the response status or output items
        finish_reason = _extract_finish_reason(response)
        if finish_reason:
            props: Dict[str, object] = dict(pending.get("properties", {}))  # type: ignore[arg-type]
            props["ai.finish_reason"] = finish_reason
            pending["properties"] = props

        usage = getattr(response, "usage", None)
        if usage:
            props = dict(pending.get("properties", {}))  # type: ignore[arg-type]
            input_tokens: Optional[int] = getattr(usage, "input_tokens", None)
            output_tokens: Optional[int] = getattr(usage, "output_tokens", None)
            if input_tokens is not None:
                props["ai.usage.prompt_tokens"] = input_tokens
            if output_tokens is not None:
                props["ai.usage.completion_tokens"] = output_tokens

            # Extended token categories (OpenAI response format)
            _extract_extended_tokens(usage, props)

            if props:
                pending["properties"] = props

    def _extract_generation_span(self, trace_id: str, data: object) -> None:
        """Extract data from a ``generation`` span (generic/older format)."""
        pending = self._pending_data.setdefault(trace_id, {})

        input_val = getattr(data, "input", None)
        if input_val is not None:
            pending["input"] = _format_messages(input_val)

        output_val = getattr(data, "output", None)
        if output_val is not None:
            pending["output"] = _safe_str(output_val)

        model: Optional[str] = getattr(data, "model", None)
        if model:
            pending["model"] = model

        # Capture error information if present
        error = getattr(data, "error", None)
        if error is not None:
            _record_error(pending, error)

        # Extract finish_reason from generation output (Chat Completions format)
        finish_reason = _extract_finish_reason_from_generation(output_val)
        if finish_reason:
            props: Dict[str, object] = dict(pending.get("properties", {}))  # type: ignore[arg-type]
            props["ai.finish_reason"] = finish_reason
            pending["properties"] = props

        usage = getattr(data, "usage", None)
        if usage:
            props = dict(pending.get("properties", {}))  # type: ignore[arg-type]
            input_tokens: Optional[int] = getattr(usage, "input_tokens", None)
            if input_tokens is None and isinstance(usage, dict):
                input_tokens = usage.get("input_tokens")
            output_tokens: Optional[int] = getattr(usage, "output_tokens", None)
            if output_tokens is None and isinstance(usage, dict):
                output_tokens = usage.get("output_tokens")
            if input_tokens is not None:
                props["ai.usage.prompt_tokens"] = input_tokens
            if output_tokens is not None:
                props["ai.usage.completion_tokens"] = output_tokens

            # Extended token categories (Chat Completions format)
            _extract_extended_tokens(usage, props)

            if props:
                pending["properties"] = props

    def _extract_function_span(
        self, trace_id: str, span: Span, data: object
    ) -> None:
        """Extract data from a ``function`` span and track as a tool call.

        Uses the Interaction API to create individual tool spans with
        name, input, output, duration, and error information.
        """
        interaction = self._interactions.get(trace_id)
        if interaction is None:
            return

        tool_name = getattr(data, "name", None) or "unknown"
        tool_input = _safe_str(getattr(data, "input", None))
        tool_output = _safe_str(getattr(data, "output", None))

        duration_ms = _compute_duration_ms(span)

        error: Optional[str] = None
        span_error = getattr(span, "error", None)
        if span_error is not None:
            if isinstance(span_error, str):
                error = span_error
            elif isinstance(span_error, BaseException):
                error = str(span_error)
            else:
                error_message = getattr(span_error, "message", None)
                if error_message:
                    error = str(error_message)
                else:
                    error = str(span_error)

        try:
            interaction.track_tool(
                name=tool_name,
                input=tool_input,
                output=tool_output,
                duration_ms=duration_ms,
                error=error,
            )
        except Exception:
            logger.debug("Failed to track tool span", exc_info=True)

    # -- lifecycle -----------------------------------------------------------

    def shutdown(self) -> None:
        """Clear internal state.  Does not flush the Raindrop backend."""
        self._trace_event_ids.clear()
        self._pending_data.clear()
        self._interactions.clear()

    def force_flush(self) -> None:
        """No-op required by the TracingProcessor interface."""


# ---------------------------------------------------------------------------
# Private helpers
# ---------------------------------------------------------------------------


def _compute_duration_ms(span: object) -> Optional[float]:
    """Compute span duration in milliseconds from ISO timestamps.

    The OpenAI Agents SDK stores ``started_at`` and ``ended_at`` as ISO-8601
    strings on each :class:`SpanImpl`.

    Args:
        span: The span object with optional ``started_at``/``ended_at`` attrs.

    Returns:
        Duration in milliseconds, or ``None`` if timestamps are unavailable.
    """
    try:
        started_at = getattr(span, "started_at", None)
        ended_at = getattr(span, "ended_at", None)
        if started_at is None or ended_at is None:
            return None

        start_dt = datetime.fromisoformat(started_at.replace("Z", "+00:00"))
        end_dt = datetime.fromisoformat(ended_at.replace("Z", "+00:00"))

        # Ensure timezone-aware comparison
        if start_dt.tzinfo is None:
            start_dt = start_dt.replace(tzinfo=timezone.utc)
        if end_dt.tzinfo is None:
            end_dt = end_dt.replace(tzinfo=timezone.utc)

        delta = end_dt - start_dt
        return max(delta.total_seconds() * 1000.0, 0.0)
    except Exception:
        logger.debug("Failed to compute span duration", exc_info=True)
        return None


def _extract_finish_reason(response: object) -> Optional[str]:
    """Extract finish_reason from an OpenAI Response object.

    Checks the response-level ``status`` field and individual output items
    for ``status`` or ``finish_reason`` attributes.

    Args:
        response: The OpenAI Response object from a response span.

    Returns:
        The finish reason string, or ``None`` if not found.
    """
    try:
        # OpenAI Responses API: response.status ("completed", "failed", etc.)
        status = getattr(response, "status", None)
        if status and isinstance(status, str):
            return status

        # Check output items for finish_reason (Chat Completions compat)
        output = getattr(response, "output", None)
        if output and isinstance(output, list):
            for item in output:
                fr = getattr(item, "finish_reason", None)
                if fr:
                    return str(fr)
                item_status = getattr(item, "status", None)
                if item_status and isinstance(item_status, str):
                    return item_status
    except Exception:
        logger.debug("Failed to extract finish_reason", exc_info=True)
    return None


def _extract_finish_reason_from_generation(output: object) -> Optional[str]:
    """Extract finish_reason from generation span output data.

    Handles Chat Completions format where the output may contain
    ``choices`` with ``finish_reason`` fields.

    Args:
        output: The output value from a generation span.

    Returns:
        The finish reason string, or ``None`` if not found.
    """
    try:
        if output is None:
            return None

        # Direct finish_reason attribute
        fr = getattr(output, "finish_reason", None)
        if fr:
            return str(fr)

        # Chat Completions format: choices[0].finish_reason
        choices = getattr(output, "choices", None)
        if choices and isinstance(choices, list) and len(choices) > 0:
            choice_fr = getattr(choices[0], "finish_reason", None)
            if choice_fr:
                return str(choice_fr)
            # Dict-style choices
            if isinstance(choices[0], dict):
                choice_fr = choices[0].get("finish_reason")
                if choice_fr:
                    return str(choice_fr)

        # Dict-style output with choices
        if isinstance(output, dict):
            choices = output.get("choices")
            if choices and isinstance(choices, list) and len(choices) > 0:
                if isinstance(choices[0], dict):
                    choice_fr = choices[0].get("finish_reason")
                    if choice_fr:
                        return str(choice_fr)
    except Exception:
        logger.debug("Failed to extract finish_reason from generation", exc_info=True)
    return None


def _extract_extended_tokens(usage: object, props: Dict[str, object]) -> None:
    """Extract extended token categories from usage data.

    Looks for cached tokens and reasoning/thoughts tokens in both
    the OpenAI Responses API format and the Chat Completions format.

    Args:
        usage: The usage object from a response or generation span.
        props: The mutable properties dictionary to update.
    """
    try:
        # OpenAI Responses API format:
        #   usage.input_tokens_details.cached_tokens
        #   usage.output_tokens_details.reasoning_tokens
        input_details = getattr(usage, "input_tokens_details", None)
        if input_details is not None:
            cached = getattr(input_details, "cached_tokens", None)
            if cached is not None:
                props["ai.usage.cached_tokens"] = cached

        output_details = getattr(usage, "output_tokens_details", None)
        if output_details is not None:
            reasoning = getattr(output_details, "reasoning_tokens", None)
            if reasoning is not None:
                props["ai.usage.thoughts_tokens"] = reasoning

        # Chat Completions format:
        #   usage.prompt_tokens_details.cached_tokens
        #   usage.completion_tokens_details.reasoning_tokens
        prompt_details = getattr(usage, "prompt_tokens_details", None)
        if prompt_details is not None:
            cached = getattr(prompt_details, "cached_tokens", None)
            if cached is not None:
                props["ai.usage.cached_tokens"] = cached

        completion_details = getattr(usage, "completion_tokens_details", None)
        if completion_details is not None:
            reasoning = getattr(completion_details, "reasoning_tokens", None)
            if reasoning is not None:
                props["ai.usage.thoughts_tokens"] = reasoning

        # Dict-style usage (fallback)
        if isinstance(usage, dict):
            pd = usage.get("prompt_tokens_details")
            if isinstance(pd, dict):
                cached = pd.get("cached_tokens")
                if cached is not None:
                    props["ai.usage.cached_tokens"] = cached
            cd = usage.get("completion_tokens_details")
            if isinstance(cd, dict):
                reasoning = cd.get("reasoning_tokens")
                if reasoning is not None:
                    props["ai.usage.thoughts_tokens"] = reasoning
    except Exception:
        logger.debug("Failed to extract extended tokens", exc_info=True)


def _record_error(pending: Dict[str, object], error: object) -> None:
    """Capture error type and message into the pending properties dict.

    Args:
        pending: The mutable pending-data dictionary for the current trace.
        error: The error value from the span data — may be an Exception, a
            string, or an arbitrary object.
    """
    props: Dict[str, object] = dict(pending.get("properties", {}))  # type: ignore[arg-type]
    if isinstance(error, BaseException):
        props["error.type"] = type(error).__name__
        props["error.message"] = str(error)
    elif isinstance(error, str):
        props["error.type"] = "Error"
        props["error.message"] = error
    else:
        props["error.type"] = type(error).__name__
        props["error.message"] = _safe_str(error) or str(error)
    pending["properties"] = props


def _format_messages(input_val: object) -> Optional[str]:
    """Extract text content from user messages (no role prefix).

    Handles plain strings, lists of message dicts, and arbitrary objects.

    Args:
        input_val: The raw input value from the span data.

    Returns:
        The extracted user message text, or ``None`` if nothing useful
        could be extracted.
    """
    if isinstance(input_val, str):
        return input_val
    if not isinstance(input_val, list):
        return _safe_str(input_val)
    try:
        user_texts: List[str] = []
        all_texts: List[str] = []
        for msg in input_val:
            if isinstance(msg, str):
                all_texts.append(msg)
            elif isinstance(msg, dict):
                content = msg.get("content", "")
                text = content if isinstance(content, str) else (_safe_str(content) or "")
                if text:
                    all_texts.append(text)
                    if msg.get("role") == "user":
                        user_texts.append(text)
            else:
                all_texts.append(str(msg))
        last_text = user_texts[-1] if user_texts else (all_texts[-1] if all_texts else None)
        return last_text or _safe_str(input_val)
    except Exception:
        logger.debug("Error formatting messages", exc_info=True)
        return _safe_str(input_val)


def _safe_str(value: object) -> Optional[str]:
    """Convert a value to a JSON string safely.

    Handles ``None``, plain strings, Pydantic models (via ``model_dump_json``),
    and arbitrary objects (via ``json.dumps`` with a ``str`` default).

    Args:
        value: Any value to serialise.

    Returns:
        A string representation, or ``None`` if the input is ``None``.
    """
    if value is None:
        return None
    if isinstance(value, str):
        return value
    try:
        if hasattr(value, "model_dump_json"):
            return value.model_dump_json()  # type: ignore[union-attr]
        return json.dumps(value, default=str)
    except Exception:
        return str(value)
