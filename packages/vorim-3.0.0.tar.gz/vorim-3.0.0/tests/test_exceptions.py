"""Tests for VorimError."""

from __future__ import annotations

import pytest

from vorim import VorimError


class TestVorimError:
    def test_basic(self):
        err = VorimError(status=404, code="AGENT_NOT_FOUND", message="Not found")
        assert err.status == 404
        assert err.code == "AGENT_NOT_FOUND"
        assert err.message == "Not found"
        assert err.details is None
        assert str(err) == "Not found"

    def test_with_details(self):
        err = VorimError(
            status=400,
            code="VALIDATION_ERROR",
            message="Invalid input",
            details={"field": "name"},
        )
        assert err.details == {"field": "name"}

    def test_repr(self):
        err = VorimError(status=500, code="INTERNAL", message="Server error")
        assert "VorimError" in repr(err)
        assert "500" in repr(err)
        assert "INTERNAL" in repr(err)

    def test_is_exception(self):
        err = VorimError(status=401, code="UNAUTHORIZED", message="Bad token")
        with pytest.raises(VorimError):
            raise err
