"""Shared fixtures for Vorim Python SDK tests."""

from __future__ import annotations

from typing import Any

import httpx
import pytest
import respx

AGENT_DATA: dict[str, Any] = {
    "id": "uuid-123",
    "agent_id": "agid_acme_a1b2c3d4",
    "org_id": "org-1",
    "owner_user_id": "user-1",
    "name": "test-agent",
    "status": "active",
    "public_key": "ed25519-pub-key",
    "key_fingerprint": "fp:abc123",
    "trust_score": 85.0,
    "capabilities": ["search"],
    "metadata": {},
    "created_at": "2026-01-01T00:00:00Z",
    "updated_at": "2026-01-01T00:00:00Z",
    "description": "Test agent",
}

REGISTRATION_DATA: dict[str, Any] = {
    "data": {
        "agent": AGENT_DATA,
        "private_key": "ed25519-private-key",
        "public_key": "ed25519-pub-key",
        "key_fingerprint": "fp:abc123",
    }
}

PERMISSION_CHECK_ALLOWED: dict[str, Any] = {
    "data": {
        "allowed": True,
        "scope": "agent:execute",
        "agent_id": "agid_acme_a1b2c3d4",
    }
}

PERMISSION_CHECK_DENIED: dict[str, Any] = {
    "data": {
        "allowed": False,
        "scope": "agent:execute",
        "agent_id": "agid_acme_a1b2c3d4",
        "reason": "Scope not granted",
    }
}

AUDIT_RESPONSE: dict[str, Any] = {
    "data": {"ingested": 1}
}

TRUST_RECORD_DATA: dict[str, Any] = {
    "data": {
        "agent_id": "agid_acme_a1b2c3d4",
        "owner": {"org_name": "Acme", "verified": True},
        "trust_score": 85.0,
        "status": "active",
        "created_at": "2026-01-01T00:00:00Z",
        "active_scopes": ["agent:read", "agent:execute"],
        "key_fingerprint": "fp:abc123",
        "revocation_status": False,
        "last_active": "2026-03-17T12:00:00Z",
    }
}

AGENT_ID = "agid_acme_a1b2c3d4"
API_KEY = "agid_sk_test_abc123"
BASE_URL = "https://api.vorim.ai"
