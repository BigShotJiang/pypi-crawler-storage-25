"""Tests for Vorim type definitions."""

from __future__ import annotations

from dataclasses import asdict

from vorim.types import (
    Agent,
    AgentRegistrationInput,
    AuditEventInput,
    GrantPermissionOptions,
    PermissionCheckResult,
    RateLimit,
    TrustRecord,
)


class TestAgent:
    def test_required_fields(self):
        agent = Agent(
            id="1",
            agent_id="agid_test",
            org_id="org-1",
            owner_user_id="user-1",
            name="test",
            status="active",
            public_key="key",
            key_fingerprint="fp",
            trust_score=90.0,
            capabilities=["search"],
            metadata={},
            created_at="2026-01-01",
            updated_at="2026-01-01",
        )
        assert agent.agent_id == "agid_test"
        assert agent.description is None
        assert agent.expires_at is None

    def test_optional_fields(self):
        agent = Agent(
            id="1",
            agent_id="agid_test",
            org_id="org-1",
            owner_user_id="user-1",
            name="test",
            status="revoked",
            public_key="key",
            key_fingerprint="fp",
            trust_score=0.0,
            capabilities=[],
            metadata={"env": "prod"},
            created_at="2026-01-01",
            updated_at="2026-01-01",
            description="A revoked agent",
            revoked_at="2026-03-01",
            revoked_by="admin",
        )
        assert agent.revoked_at == "2026-03-01"
        assert agent.metadata == {"env": "prod"}


class TestAuditEventInput:
    def test_minimal(self):
        event = AuditEventInput(
            agent_id="agid_test",
            event_type="tool_call",
            action="search",
            result="success",
        )
        d = asdict(event)
        assert d["agent_id"] == "agid_test"
        assert d["resource"] is None

    def test_full(self):
        event = AuditEventInput(
            agent_id="agid_test",
            event_type="api_request",
            action="fetch_data",
            result="error",
            resource="/api/data",
            input_hash="sha256:abc",
            output_hash="sha256:def",
            permission="agent:read",
            latency_ms=150,
            error_code="TIMEOUT",
            signature="ed25519:sig",
            metadata={"retry": 2},
        )
        assert event.error_code == "TIMEOUT"
        assert event.metadata == {"retry": 2}


class TestRateLimit:
    def test_asdict(self):
        rl = RateLimit(max=100, window="1h")
        d = asdict(rl)
        assert d == {"max": 100, "window": "1h"}


class TestGrantPermissionOptions:
    def test_defaults(self):
        opts = GrantPermissionOptions()
        assert opts.valid_until is None
        assert opts.rate_limit is None


class TestPermissionCheckResult:
    def test_allowed(self):
        result = PermissionCheckResult(
            allowed=True, scope="agent:execute", agent_id="agid_test"
        )
        assert result.allowed is True
        assert result.reason is None

    def test_denied_with_reason(self):
        result = PermissionCheckResult(
            allowed=False,
            scope="agent:write",
            agent_id="agid_test",
            reason="Scope not granted",
        )
        assert result.reason == "Scope not granted"


class TestTrustRecord:
    def test_creation(self):
        record = TrustRecord(
            agent_id="agid_test",
            owner={"org_name": "Acme", "verified": True},
            trust_score=92.5,
            status="active",
            created_at="2026-01-01",
            active_scopes=["agent:read"],
            key_fingerprint="fp:abc",
            revocation_status=False,
        )
        assert record.last_active is None
        assert record.trust_score == 92.5


class TestAgentRegistrationInput:
    def test_creation(self):
        inp = AgentRegistrationInput(
            name="test", capabilities=["search"], scopes=["agent:read"]
        )
        assert inp.description is None
