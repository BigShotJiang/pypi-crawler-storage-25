"""Vorim SDK — Type definitions.

Mirrors the TypeScript SDK types for full API compatibility.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Literal

# ── Agent ─────────────────────────────────────────────────────────────────

AgentStatus = Literal["pending", "active", "suspended", "revoked", "expired"]

PermissionScope = Literal[
    "agent:read",
    "agent:write",
    "agent:execute",
    "agent:transact",
    "agent:communicate",
    "agent:delegate",
    "agent:elevate",
]

AuditEventType = Literal[
    "tool_call",
    "api_request",
    "message_sent",
    "permission_change",
    "status_change",
    "key_rotation",
    "login",
    "export",
]

AuditResult = Literal["success", "denied", "error"]


@dataclass
class Agent:
    id: str
    agent_id: str
    org_id: str
    owner_user_id: str
    name: str
    status: AgentStatus
    key_fingerprint: str
    trust_score: float
    capabilities: list[str]
    metadata: dict[str, Any]
    created_at: str
    updated_at: str
    description: str | None = None
    expires_at: str | None = None
    revoked_at: str | None = None
    revoked_by: str | None = None


@dataclass
class AgentRegistrationInput:
    name: str
    capabilities: list[str]
    scopes: list[PermissionScope]
    description: str | None = None


@dataclass
class AgentRegistrationResult:
    agent: Agent
    private_key: str
    public_key: str
    key_fingerprint: str


@dataclass
class PermissionCheckResult:
    allowed: bool
    scope: PermissionScope
    agent_id: str
    reason: str | None = None
    remaining_quota: int | None = None


@dataclass
class AuditEventInput:
    agent_id: str
    event_type: AuditEventType
    action: str
    result: AuditResult
    resource: str | None = None
    input_hash: str | None = None
    output_hash: str | None = None
    permission: PermissionScope | None = None
    latency_ms: int | None = None
    error_code: str | None = None
    signature: str | None = None
    metadata: dict[str, Any] | None = None


@dataclass
class TrustRecord:
    agent_id: str
    owner: dict[str, Any]
    trust_score: float
    status: AgentStatus
    created_at: str
    active_scopes: list[PermissionScope]
    key_fingerprint: str
    revocation_status: bool
    last_active: str | None = None


@dataclass
class RateLimit:
    max: int
    window: str  # '1h' | '1d' | '1m'


@dataclass
class GrantPermissionOptions:
    valid_until: str | None = None
    rate_limit: RateLimit | None = None
