"""Vorim SDK — Exception classes."""

from __future__ import annotations

from typing import Any


class VorimError(Exception):
    """Raised when the Vorim API returns a non-2xx response.

    Attributes:
        status: HTTP status code.
        code: Error code from the API (e.g. ``AGENT_NOT_FOUND``).
        message: Human-readable error message.
        details: Optional additional context from the API.
    """

    def __init__(
        self,
        status: int,
        code: str,
        message: str,
        details: dict[str, Any] | None = None,
    ) -> None:
        super().__init__(message)
        self.status = status
        self.code = code
        self.details = details

    def __repr__(self) -> str:
        return f"VorimError(status={self.status}, code={self.code!r}, message={self.message!r})"

    @property
    def message(self) -> str:
        return str(self.args[0])
