"""Vorim — The identity and trust layer for AI agents.

Usage::

    from vorim import Vorim, AsyncVorim, VorimError

    vorim = Vorim(api_key="agid_sk_live_...")
    result = vorim.register(
        name="my-agent",
        capabilities=["search"],
        scopes=["agent:read", "agent:execute"],
    )
"""

from .client import AsyncVorim, Vorim
from .exceptions import VorimError
from .types import (
    Agent,
    AgentRegistrationInput,
    AgentRegistrationResult,
    AgentStatus,
    AuditEventInput,
    AuditEventType,
    AuditResult,
    GrantPermissionOptions,
    PermissionCheckResult,
    PermissionScope,
    RateLimit,
    TrustRecord,
)

__all__ = [
    "Vorim",
    "AsyncVorim",
    "VorimError",
    "Agent",
    "AgentRegistrationInput",
    "AgentRegistrationResult",
    "AgentStatus",
    "AuditEventInput",
    "AuditEventType",
    "AuditResult",
    "GrantPermissionOptions",
    "PermissionCheckResult",
    "PermissionScope",
    "RateLimit",
    "TrustRecord",
]

__version__ = "2.3.0"
