"""Vorim SDK — Framework integrations.

Available integrations:

- ``vorim.integrations.langchain`` — LangChain / LangGraph
- ``vorim.integrations.crewai`` — CrewAI (crew registration, task audit, delegation)
- ``vorim.integrations.openai_agents`` — OpenAI Agents SDK (tool registry, agent loop)

Each integration is imported lazily to avoid pulling in peer dependencies
unless the specific integration is used.
"""
