# vorim

Official Python SDK for [Vorim AI](https://vorim.ai) — the identity, permissions, and audit layer for AI agents.

Vorim AI provides cryptographic agent identities (Ed25519), fine-grained permissions (7 scopes), immutable audit trails, and trust scoring (0-100) for production AI agent deployments. EU AI Act compliant out of the box.

[![PyPI](https://img.shields.io/pypi/v/vorim)](https://pypi.org/project/vorim/)
[![Python](https://img.shields.io/pypi/pyversions/vorim)](https://pypi.org/project/vorim/)
[![License](https://img.shields.io/pypi/l/vorim)](https://github.com/Kzino/vorim-protocol/blob/main/LICENSE)

> **[vorim.ai](https://vorim.ai)** — Create a free account and get your API key in 30 seconds.
> **[Documentation](https://vorim.ai/docs)** — Full API reference, framework integrations, and examples.
> **[Quick Start](https://vorim.ai/quickstart)** — Set up in under 5 minutes.

## Install

```bash
pip install vorim
```

With framework integrations:

```bash
pip install vorim[langchain]    # LangChain / LangGraph
pip install vorim[crewai]       # CrewAI
pip install vorim[openai]       # OpenAI Agents SDK
pip install vorim[all]          # All integrations
```

Requires Python 3.10+.

## Quick Start

```python
from vorim import Vorim

vorim = Vorim(api_key="agid_sk_live_...")

# Register an agent (returns Ed25519 keypair, private key shown once)
result = vorim.register(
    name="invoice-processor",
    capabilities=["read_documents", "extract_data"],
    scopes=["agent:read", "agent:execute"],
)
print(result.agent.agent_id)    # agid_acme_a1b2c3d4
print(result.agent.trust_score) # 50

# Check permissions (<5ms via Redis)
check = vorim.check(result.agent.agent_id, "agent:execute")

if check.allowed:
    # Emit audit event
    vorim.emit(
        agent_id=result.agent.agent_id,
        event_type="tool_call",
        action="process_invoice",
        resource="INV-2026-0042",
        result="success",
        latency_ms=142,
    )

# Verify any agent's trust (public, no auth required)
trust = vorim.verify(result.agent.agent_id)
print(f"Trust score: {trust.trust_score}/100")
```

## Async Client

```python
from vorim import AsyncVorim

async with AsyncVorim(api_key="agid_sk_live_...") as vorim:
    result = await vorim.register(
        name="my-agent",
        capabilities=["search"],
        scopes=["agent:read"],
    )

    trust = await vorim.verify(result.agent.agent_id)
    print(f"Trust score: {trust.trust_score}/100")
```

## API Reference

### `Vorim(api_key, base_url?, timeout?)`

| Method | Description |
|--------|-------------|
| `register(name, capabilities, scopes)` | Register an agent with Ed25519 keypair |
| `check(agent_id, scope)` | Check if agent has permission (sub-5ms) |
| `emit(agent_id, event_type, action, ...)` | Emit an audit event |
| `emit_batch(events)` | Emit up to 1,000 audit events |
| `verify(agent_id)` | Verify agent identity and trust score (public) |
| `get_agent(agent_id)` | Get agent details |
| `list_agents(status?, page?, per_page?)` | List agents with filtering |
| `revoke(agent_id)` | Permanently revoke an agent |
| `grant(agent_id, scope, valid_until?, rate_limit?)` | Grant a permission scope |
| `sign(payload, private_key_pem)` | Sign payload with Ed25519 key |

`AsyncVorim` has the same interface with `await` on all methods.

### Permission Scopes

| Scope | Description |
|-------|-------------|
| `agent:read` | Read data on behalf of owner |
| `agent:write` | Write or modify data |
| `agent:execute` | Trigger actions or tool calls |
| `agent:transact` | Financial or contractual actions |
| `agent:communicate` | Send messages or emails |
| `agent:delegate` | Sub-delegate to other agents |
| `agent:elevate` | Request permission elevation |

## Framework Integrations

### LangChain / LangGraph

```python
from vorim import Vorim
from vorim.integrations.langchain import vorim_tool, VorimCallbackHandler

vorim = Vorim(api_key="agid_sk_live_...")

@vorim_tool(vorim, agent_id="agid_acme_...", permission="agent:execute")
def search(query: str) -> str:
    """Search documents."""
    return f"Results for {query}"

# search() is now a standard LangChain tool with built-in permission checks + audit
```

### CrewAI

```python
from vorim import Vorim
from vorim.integrations.crewai import register_crew

vorim = Vorim(api_key="agid_sk_live_...")

crew = register_crew(vorim, {
    "crew_name": "content-pipeline",
    "members": [
        {
            "role": "researcher",
            "name": "crew-researcher",
            "capabilities": ["web_search"],
            "scopes": ["agent:read", "agent:execute"],
        },
    ],
})
```

### OpenAI Function Calling

```python
from openai import OpenAI
from vorim import Vorim
from vorim.integrations.openai_agents import VorimToolRegistry

vorim = Vorim(api_key="agid_sk_live_...")
client = OpenAI()

registry = VorimToolRegistry(vorim=vorim, agent_id="agid_acme_...")
registry.add(
    name="search",
    description="Search documents",
    parameters={"type": "object", "properties": {"query": {"type": "string"}}},
    execute=lambda args: f"Results for {args['query']}",
)

response = client.chat.completions.create(
    model="gpt-4o",
    messages=[{"role": "user", "content": "Search for AI papers"}],
    tools=registry.to_openai_tools(),
)

# Permission checked + audited automatically
tool_messages = registry.execute_tool_calls(
    response.choices[0].message.tool_calls or []
)
```

## Resources

- [Full Documentation](https://vorim.ai/docs)
- [Protocol Specification](https://github.com/Kzino/vorim-protocol)
- [TypeScript SDK (@vorim/sdk)](https://www.npmjs.com/package/@vorim/sdk)

## License

MIT
