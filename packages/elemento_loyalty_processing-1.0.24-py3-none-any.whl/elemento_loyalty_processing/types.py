from datetime import date, datetime
from decimal import Decimal
from enum import Enum, auto
from typing import Any, NewType, TypedDict

from elemento_customers.types import Customer, CustomerId
from msgspec import Struct

DATE_MAXVALUE = date.fromisoformat("3000-01-01")

TransactionExtId = NewType("TransactionExtId", str)
TransactionId = NewType("TransactionId", int)
EventTypeId = NewType("EventTypeId", str)
ListId = NewType("ListId", int)
StoreId = NewType("StoreId", int)
OfferId = NewType("OfferId", int)
LifetimeId = NewType("LifetimeId", str)
GroupId = NewType("GroupId", int)
ConditionId = NewType("ConditionId", int)
ActionId = NewType("ActionId", int)
Points = NewType("Points", int)
Position = NewType("Position", int)


class OfferEventType(Enum):
    PointsAdd = "PointsAdd"
    PointsUse = "PointsUse"
    Purchase = "Purchase"
    Return = "Return"
    Birthday = "Birthday"
    RegistrationDone = "RegistrationDone"
    Discount = "Discount"
    PointsAddLimit = "PointsAddLimit"
    ExternalPointsAdd = "ExternalPointsAdd"


class ItemListType(Enum):
    STORE = "STORE"
    PRODUCT = "PRODUCT"
    TERMINAL = "TERMINAL"


class ItemList(Struct):
    type: ItemListType
    id: ListId
    items: list[str]


class BalanceStatus(Enum):
    FUTURE = "FUTURE"
    HOLD = "HOLD"
    ACTIVE = "ACTIVE"


class Balance(Struct):
    customer_id: CustomerId
    active_from: date
    active_to: date
    status: BalanceStatus
    amount: int
    transaction_id: TransactionId | None = None


class TransactionType(Enum):
    ORDER = "ORDER"
    SCRIPT = "SCRIPT"


class _PointTypeData(TypedDict, total=False):
    func: str
    value: Any
    time_unit: str


class PointType(Struct):
    updated: datetime
    id: LifetimeId
    label: str
    activation: _PointTypeData
    expiration: _PointTypeData


class BalanceAction(Enum):
    BEGIN = "BEGIN"
    DISCOUNT = "DISCOUNT"
    SUB = "SUB"
    ADD = "ADD"


BALANCE_ACTION_EVENTS = {
    BalanceAction.BEGIN: [],
    BalanceAction.DISCOUNT: [OfferEventType.Discount, OfferEventType.PointsUse],
    BalanceAction.SUB: [OfferEventType.PointsUse],
    BalanceAction.ADD: [OfferEventType.PointsAdd, OfferEventType.PointsAddLimit],
}


class AppliedOffer(Struct):
    offer_id: int | None
    offer_name: str
    points_sub: Points
    points_sub_max: Points
    points_add: Points
    discount: Decimal
    active_from: date
    active_to: date
    promo_id: str | None = None


class PersonalOffer(Struct):
    id: str
    type: str
    discount_percent: int = 0
    cashback_percent: int = 0


class Item(Struct):
    pos: Position
    product_id: str
    quantity: int
    total: Decimal
    price: Decimal
    initial_total: Decimal | None = None
    cashback: Points = 0
    discount: Decimal = Decimal("0.00")
    initial_discount: Decimal = None
    points_add: Points = 0
    points_sub: Points = 0
    points_sub_max: Points = 0
    params: dict[str, Any] = {}
    offers_add: list[AppliedOffer] = []
    offers_sub: list[AppliedOffer] = []
    offers_discount: list[AppliedOffer] = []
    personal: list[PersonalOffer] = []

    def __post_init__(self):
        if self.initial_total is None:
            self.initial_total = self.total
        if self.initial_discount is None:
            self.initial_discount = self.discount


class RefundItem(TypedDict):
    pos: int
    quantity: int


class Cart(Struct):
    items: list[Item]
    total: Decimal = Decimal(0)
    initial_total: Decimal = Decimal(0)
    discount: Decimal = Decimal(0)
    points_add: Points = Points(0)
    points_sub: Points = Points(0)
    points_sub_max: Points = Points(0)
    points_available: Points = Points(0)
    cashier_message: str = ""
    customer_message: str = ""
    offers_add: list[AppliedOffer] = []
    personal: list[PersonalOffer] = []


class StoredTransaction(Struct):
    id: TransactionId
    created: datetime
    customer_id: CustomerId
    total: int
    type: TransactionType
    balance: list[int]
    quantity: list[int]
    ext_id: TransactionExtId
    source: str
    active: bool = True


class Transaction(Struct):
    ext_id: TransactionExtId | None
    id: TransactionId
    source: str
    store_id: StoreId
    customer: Customer.Fields | None = None
    timestamp: datetime = None
    cart: Cart = None
    confirmed: bool = False
    payment_type: str | None = None
    actions: list[BalanceAction] = []
    order_id: str | None = None

    def set_current_action(self, action: BalanceAction, /) -> None:
        if action is BalanceAction.BEGIN:
            self.init_discount()
            self.init_point_sub()
            self.init_point_add()
        elif action is BalanceAction.DISCOUNT:
            self.init_discount()
        elif action is BalanceAction.SUB:
            self.init_point_sub()
        elif action is BalanceAction.ADD:
            self.init_point_add()
        else:
            raise ValueError(f"Unknown state: {action}")

        self.actions.append(action)

    def init_discount(self) -> None:
        initial_total = Decimal(0)

        for item in self.cart.items:
            item.discount = Decimal(0)
            item.total = item.initial_total
            initial_total += item.initial_total
            item.offers_discount.clear()

        self.cart.total = initial_total
        self.cart.initial_total = initial_total
        self.cart.discount = Decimal(0)

    def init_point_sub(self) -> None:
        total = Decimal(0)
        discount = Decimal(0)

        for item in self.cart.items:
            item.points_sub = Points(0)
            item.points_sub_max = Points(0)
            item.total = item.initial_total - item.discount
            total += item.total
            discount += item.discount
            item.offers_sub.clear()

        self.cart.total = total
        self.cart.discount = discount
        self.cart.points_sub = Points(0)
        self.cart.points_sub_max = Points(0)

    def init_point_add(self) -> None:

        for item in self.cart.items:
            item.points_add = Points(0)
            item.offers_add.clear()

        self.cart.points_add = Points(0)
        self.cart.offers_add.clear()


class PurchaseStats(Struct):
    total: Decimal = Decimal(0)
    points_day: Points = Points(0)
    purchases_day: int = 0
    points_week: Points = Points(0)
    purchases_week: int = 0
    points_month: Points = Points(0)
    purchases_month: int = 0


class LogRecordType(Enum):
    EVENT = "E"
    OFFER = "O"
    GROUP = "G"
    COND = "C"
    ACTION = "A"
    ITEM_DISCOUNT = "d"
    ITEM_SUB = "s"
    ITEM_ADD = "a"
    ITEM_LIMIT = "l"


class LogState(Enum):
    BEGIN = "B"
    OK = "O"
    FAIL = "F"
    END = "E"
    ERROR = "R"


class LogCart(Struct, omit_defaults=True):
    total: int
    initial_total: int
    points_add: int = 0
    points_sub: int = 0
    points_sub_max: int = 0
    discount: int = 0


class LogRecord(Struct, omit_defaults=True):
    id: str
    type: LogRecordType
    state: LogState = LogState.OK
    points_add: int | None = None
    points_add_limit: int | None = None
    limit_type: str | None = None
    points_sub: int | None = None
    points_sub_max: int | None = None
    discount: int | None = None
    pos: list[int] | None = None
    timestamp: int | None = None
    error_msg: str | None = None
    cart: LogCart | None = None
