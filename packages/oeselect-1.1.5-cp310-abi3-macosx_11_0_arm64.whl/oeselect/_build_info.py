# Auto-generated build information - do not edit
OPENEYE_BUILD_VERSION = "2025.2.1"
OPENEYE_LIBRARY_TYPE = "SHARED"
OPENEYE_EXPECTED_LIBS = ["liboechem-4.3.0.1.dylib", "liboesystem-4.3.0.1.dylib", "liboeplatform-4.3.0.1.dylib", "liboemath-2.9.1.1.dylib", "libzstd.1.dylib", "liboegraphsim-2.7.0.1.dylib", "liboemedchem-1.2.5.1.dylib", "liboebio-4.3.0.1.dylib", "liboegrid-4.3.0.1.dylib", "liboefizzchem-1.2.5.dylib"]
