"""
OESelect - PyMOL-style selection language for OpenEye Toolkits

This package provides a fast C++ implementation of a PyMOL-compatible
selection language for use with OpenEye molecular modeling tools.

Install with: ``pip install oeselect``

Example usage::

    from openeye import oechem
    from oeselect import OESelect, select, count, parse

    # Create a molecule
    mol = oechem.OEGraphMol()
    oechem.OESmilesToMol(mol, "CC(=O)OC1=CC=CC=C1C(=O)O")

    # Select atoms -- returns list of atom indices
    indices = select(mol, "name CA")

    # Count atoms matching a selection
    num_carbons = count(mol, "elem C")

    # Use OESelect as a predicate with OpenEye functions
    pred = OESelect(mol, "protein and chain A")
    for atom in mol.GetAtoms(pred):
        print(atom.GetName())

    # Parse and validate a selection string
    sele = parse("protein and chain A")
    print(sele.ToCanonical())

Supported selection keywords:

Atom properties:
    - name <pattern>: Atom name (supports wildcards * and ?)
    - resn <name>: Residue name (ALA, GLY, etc.)
    - resi <number>: Residue number (supports ranges like 1-10 and comparisons like > 50)
    - chain <id>: Chain identifier
    - elem <symbol>: Element symbol (C, N, O, etc.)
    - index <number>: Atom index (supports ranges and comparisons)
    - id / serial <number>: Atom serial number (supports ranges and comparisons)
    - alt <char>: Alternate location identifier
    - b / bfactor <number>: B-factor (supports float ranges and comparisons)
    - frag / fragment <number>: Fragment number (supports ranges and comparisons)

Component types:
    - protein: Protein atoms
    - ligand: Small molecule ligand atoms
    - water: Water molecules
    - solvent: Solvent molecules (water + common solvents)
    - organic: Small organic molecules
    - backbone / bb: Protein backbone atoms (N, CA, C, O)
    - sidechain / sc: Protein sidechain atoms
    - metal / metals: Metal ions

Atom types:
    - heavy: Non-hydrogen atoms
    - hydrogen / h: Hydrogen atoms
    - polar_hydrogen / polarh: Polar hydrogens
    - nonpolar_hydrogen / apolarh: Non-polar hydrogens

Secondary structure:
    - helix: Alpha helix atoms
    - sheet: Beta sheet atoms
    - turn: Turn atoms
    - loop: Loop/coil atoms

Distance-based:
    - <selection> around <radius>: Atoms within radius of selection, excluding reference
    - <selection> expand <radius>: Atoms within radius of selection, including reference
    - <selection> beyond <radius>: Atoms outside radius of selection

Expansion:
    - byres <selection>: Expand to complete residues
    - bychain <selection>: Expand to complete chains

Logical operators:
    - and / &: Logical AND
    - or / |: Logical OR
    - not / !: Logical NOT
    - xor / ^: Logical XOR

Special:
    - all: All atoms
    - none: No atoms
    - (parentheses): Grouping

Multi-value syntax:
    - name CA+CB+N: Equivalent to name CA or name CB or name N

Hierarchical macro syntax:
    - //chain/resi/name: e.g., //A/100/CA
"""

import os
import re
import warnings

# Version info
__version__ = "1.1.5"
__version_info__ = (1, 1, 5)


def _ensure_library_compat():
    """Create compatibility symlinks when OpenEye library versions differ from build time.

    When oeselect is built with shared OpenEye libraries, the compiled extension
    records the exact versioned library filenames (e.g., liboechem-4.3.0.1.dylib).
    If the user upgrades openeye-toolkits, these filenames change (e.g., to
    liboechem-4.3.0.2.dylib) and the dynamic linker fails to load the extension.

    This function detects version mismatches and creates symlinks from the expected
    (build-time) library names to the actual (runtime) library files in the oeselect
    package directory, which is on the extension's rpath (@loader_path / $ORIGIN).
    """
    try:
        from . import _build_info
    except ImportError:
        return False

    if getattr(_build_info, 'OPENEYE_LIBRARY_TYPE', 'STATIC') != 'SHARED':
        return False

    expected_libs = getattr(_build_info, 'OPENEYE_EXPECTED_LIBS', [])
    if not expected_libs:
        return False

    try:
        from openeye import libs
        oe_lib_dir = libs.FindOpenEyeDLLSDirectory()
    except (ImportError, Exception):
        return False

    if not os.path.isdir(oe_lib_dir):
        return False

    pkg_dir = os.path.dirname(__file__)
    created_any = False

    for expected_name in expected_libs:
        # Check if the expected library exists in the OpenEye lib directory
        if os.path.exists(os.path.join(oe_lib_dir, expected_name)):
            continue

        # Check for an existing symlink in our package directory
        symlink_path = os.path.join(pkg_dir, expected_name)
        if os.path.islink(symlink_path):
            if os.path.exists(symlink_path):
                continue  # Valid symlink already exists
            # Stale symlink (target was removed/upgraded) - remove it
            try:
                os.unlink(symlink_path)
            except OSError:
                continue
        elif os.path.exists(symlink_path):
            continue  # Regular file exists

        # Extract the base library name (e.g., "liboechem" from "liboechem-4.3.0.1.dylib")
        # Handles both dash-versioned (liboechem-4.3.0.1.dylib) and
        # dot-versioned (libzstd.1.dylib) naming conventions
        match = re.match(r'(lib\w+?)(-[\d.]+)?(\.[\d.]*\w+)$', expected_name)
        if not match:
            continue
        base_name = match.group(1)

        # Find the actual library with a potentially different version
        actual_path = None
        for f in os.listdir(oe_lib_dir):
            if f.startswith(base_name + '-') or f.startswith(base_name + '.'):
                actual_path = os.path.join(oe_lib_dir, f)
                break

        if actual_path:
            symlink_path = os.path.join(pkg_dir, expected_name)
            try:
                os.symlink(actual_path, symlink_path)
                created_any = True
            except OSError:
                pass

    return created_any


def _preload_shared_libs():
    """Preload OpenEye shared libraries so the C extension can find them.

    On Linux, the extension's RUNPATH (set at build time) normally handles
    dependency resolution, but preloading ensures libraries are available
    even if RUNPATH is stripped (e.g. by certain packaging tools).
    On macOS, @rpath references may not resolve without preloading.

    Only the libraries recorded in ``OPENEYE_EXPECTED_LIBS`` are loaded,
    and they are loaded with ``RTLD_GLOBAL`` so that cross-module C++
    symbol references resolve correctly. Loading the entire OpenEye
    library directory (which can contain 70+ unrelated shared objects)
    would pollute the global symbol namespace and cause segfaults in
    unrelated C extensions such as ``_sqlite3``.
    """
    import ctypes
    import sys
    if sys.platform not in ('linux', 'darwin'):
        return

    try:
        from . import _build_info
    except ImportError:
        return

    if getattr(_build_info, 'OPENEYE_LIBRARY_TYPE', 'STATIC') != 'SHARED':
        return

    expected_libs = getattr(_build_info, 'OPENEYE_EXPECTED_LIBS', [])
    if not expected_libs:
        return

    try:
        from openeye import libs
        oe_lib_dir = libs.FindOpenEyeDLLSDirectory()
    except (ImportError, Exception):
        return

    if not os.path.isdir(oe_lib_dir):
        return

    pkg_dir = os.path.dirname(__file__)
    for lib_name in expected_libs:
        oe_path = os.path.join(oe_lib_dir, lib_name)
        local_path = os.path.join(pkg_dir, lib_name)
        path = oe_path if os.path.exists(oe_path) else local_path
        if os.path.exists(path) or os.path.islink(path):
            try:
                ctypes.CDLL(path, mode=ctypes.RTLD_GLOBAL)
            except OSError:
                pass


def _preload_bundled_libs():
    """Preload libraries bundled by auditwheel from the .libs directory.

    auditwheel repair bundles non-manylinux dependencies (e.g. libraries
    from FetchContent or system packages) into a ``<package>.libs/``
    directory next to the package. The bundled copies have hashed filenames
    and must be loaded before the C extension to satisfy its DT_NEEDED
    entries.

    Libraries may have inter-dependencies, so we do multiple passes
    until no new libraries can be loaded. Libraries are loaded without
    ``RTLD_GLOBAL`` to avoid polluting the global symbol namespace.
    """
    import sys
    if sys.platform != 'linux':
        return

    import ctypes
    pkg_name = __name__
    pkg_dir = os.path.dirname(os.path.abspath(__file__))
    site_dir = os.path.dirname(pkg_dir)
    for libs_name in (f'{pkg_name}.libs', f'.{pkg_name}.libs'):
        libs_dir = os.path.join(site_dir, libs_name)
        if not os.path.isdir(libs_dir):
            continue
        remaining = [
            os.path.join(libs_dir, f)
            for f in sorted(os.listdir(libs_dir))
            if '.so' in f
        ]
        while remaining:
            failed = []
            for lib_path in remaining:
                try:
                    ctypes.CDLL(lib_path)
                except OSError:
                    failed.append(lib_path)
            if len(failed) == len(remaining):
                break
            remaining = failed


def _check_openeye_version():
    """Check that the OpenEye version matches what was used at build time."""
    try:
        from . import _build_info
    except ImportError:
        # Build info not available (development install)
        return

    # Only check if using shared/dynamic linking
    if getattr(_build_info, 'OPENEYE_LIBRARY_TYPE', 'STATIC') != 'SHARED':
        return

    build_version = getattr(_build_info, 'OPENEYE_BUILD_VERSION', None)
    if not build_version:
        return

    try:
        from openeye import oechem
        # Get runtime toolkit version using the official API
        runtime_version = oechem.OEToolkitsGetRelease()
        if runtime_version and build_version:
            # Compare major.minor.patch versions (e.g., "2025.2.1")
            build_parts = build_version.split('.')[:3]
            runtime_parts = runtime_version.split('.')[:3]
            if build_parts != runtime_parts:
                warnings.warn(
                    f"OpenEye version mismatch: oeselect was built with OpenEye Toolkits {build_version} "
                    f"but runtime has OpenEye Toolkits {runtime_version}. "
                    f"This may cause compatibility issues. Please ensure openeye-toolkits "
                    f"matches the version used to build oeselect.",
                    RuntimeWarning
                )
    except ImportError:
        warnings.warn(
            "openeye-toolkits package not found. "
            "This wheel requires openeye-toolkits to be installed. "
            "Install with: pip install openeye-toolkits",
            ImportWarning
        )


# Create compatibility symlinks before loading the C extension
_ensure_library_compat()

# Preload OpenEye shared libraries (needed on Linux where RUNPATH may not
# include the OpenEye library directory after auditwheel repair)
_preload_shared_libs()

# Preload auditwheel-bundled libraries from .libs directory
_preload_bundled_libs()

# Check OpenEye version on import
_check_openeye_version()

from .oeselect import (
    OESelection,
    OESelect as _CppOESelect,
    Selector,
    OEResidueSelector as _CppOEResidueSelector,
    OEHasResidueName as _CppOEHasResidueName,
    OEHasAtomNameAdvanced as _CppOEHasAtomNameAdvanced,
    EvaluateSelection,
    CountSelection,
    parse_selector_set,
    mol_to_selector_set,
    str_selector_set,
    get_selector_string,
    select,
    count,
    parse,
    selector_set,
)


try:
    from openeye import oechem as _oechem
    _OEUnaryAtomPred = _oechem.OEUnaryAtomPred
except ImportError:
    _OEUnaryAtomPred = object
    _oechem = None


class OESelect(_OEUnaryAtomPred):
    """Molecule-bound selection predicate compatible with OpenEye's predicate interface.

    Wraps the C++ OESelect evaluator and implements the OpenEye OEUnaryAtomPred
    protocol, allowing use with ``mol.GetAtoms(pred)`` and ``oechem.OECount(mol, pred)``.

    :param mol: An OpenEye OEMolBase object.
    :param sele: PyMOL-style selection string or OESelection object.

    Example::

        from openeye import oechem
        from oeselect import OESelect

        mol = oechem.OEGraphMol()
        oechem.OEReadMolecule(oechem.oemolistream("protein.pdb"), mol)

        pred = OESelect(mol, "protein and chain A")

        # Use with OpenEye atom iteration
        for atom in mol.GetAtoms(pred):
            print(atom.GetName())

        # Use with OpenEye counting
        num = oechem.OECount(mol, pred)
    """

    def __init__(self, mol, sele=None):
        _OEUnaryAtomPred.__init__(self)
        self._mol = mol
        if sele is None:
            self._cpp_select = _CppOESelect(mol, "all")
        elif isinstance(sele, str):
            self._cpp_select = _CppOESelect(mol, sele)
        elif isinstance(sele, OESelection):
            self._cpp_select = _CppOESelect(mol, sele)
        else:
            self._cpp_select = _CppOESelect(mol, str(sele))

    def __call__(self, atom):
        """Test if an atom matches the selection.

        :param atom: An OpenEye OEAtomBase object.
        :returns: True if the atom matches.
        """
        return self._cpp_select(atom)

    def __iter__(self):
        """Iterate over atoms matching the selection.

        :returns: Iterator of matching OEAtomBase objects.
        """
        return iter(self._mol.GetAtoms(self))

    def CreateCopy(self):
        """Create a copy for OpenEye compatibility."""
        copy = OESelect(self._mol, self._cpp_select.GetSelection())
        return copy.__disown__()

    @property
    def sele(self):
        """Access the underlying OESelection object."""
        return self._cpp_select.GetSelection()

    def __repr__(self):
        return f"OESelect('{self._cpp_select.GetSelection().ToCanonical()}')"


class OEResidueSelector(_OEUnaryAtomPred):
    """Predicate matching atoms by residue selector strings.

    Compatible with OpenEye's predicate interface for use with
    ``mol.GetAtoms(pred)`` and ``oechem.OECount(mol, pred)``.

    :param selector_str: Comma/semicolon/newline-separated selector strings
        in "NAME:NUMBER:ICODE:CHAIN" format.

    Example::

        sel = OEResidueSelector("ALA:123: :A,GLY:124: :A")
        for atom in mol.GetAtoms(sel):
            print(atom.GetName())
    """

    def __init__(self, selector_str):
        _OEUnaryAtomPred.__init__(self)
        if isinstance(selector_str, str):
            self._cpp_selector = _CppOEResidueSelector(selector_str)
        else:
            self._cpp_selector = _CppOEResidueSelector(selector_str)

    def __call__(self, atom):
        """Test if an atom belongs to one of the specified residues.

        :param atom: An OpenEye OEAtomBase object.
        :returns: True if the atom's residue matches.
        """
        return self._cpp_selector(atom)

    def CreateCopy(self):
        """Create a copy for OpenEye compatibility."""
        copy = OEResidueSelector.__new__(OEResidueSelector)
        _OEUnaryAtomPred.__init__(copy)
        copy._cpp_selector = _CppOEResidueSelector(self._cpp_selector)
        return copy.__disown__()


class OEHasResidueName(_OEUnaryAtomPred):
    """Match atoms by residue name with optional case/whitespace control.

    :param residue_name: The residue name to match.
    :param case_sensitive: If True, comparison is case-sensitive (default: False).
    :param whitespace: If True, whitespace is preserved (default: False).

    Example::

        pred = OEHasResidueName("ala")  # Matches "ALA", " ALA", etc.
    """

    def __init__(self, residue_name: str, case_sensitive: bool = False,
                 whitespace: bool = False):
        _OEUnaryAtomPred.__init__(self)
        self._cpp_pred = _CppOEHasResidueName(residue_name, case_sensitive, whitespace)
        self._residue_name = residue_name
        self._case_sensitive = case_sensitive
        self._whitespace = whitespace

    def __call__(self, atom):
        return self._cpp_pred(atom)

    def CreateCopy(self):
        copy = OEHasResidueName(self._residue_name, self._case_sensitive, self._whitespace)
        return copy.__disown__()


class OEHasAtomNameAdvanced(_OEUnaryAtomPred):
    """Match atoms by name with optional case/whitespace control.

    :param atom_name: The atom name to match.
    :param case_sensitive: If True, comparison is case-sensitive (default: False).
    :param whitespace: If True, whitespace is preserved (default: False).

    Example::

        pred = OEHasAtomNameAdvanced("ca")  # Matches "CA", " CA", etc.
    """

    def __init__(self, atom_name: str, case_sensitive: bool = False,
                 whitespace: bool = False):
        _OEUnaryAtomPred.__init__(self)
        self._cpp_pred = _CppOEHasAtomNameAdvanced(atom_name, case_sensitive, whitespace)
        self._atom_name = atom_name
        self._case_sensitive = case_sensitive
        self._whitespace = whitespace

    def __call__(self, atom):
        return self._cpp_pred(atom)

    def CreateCopy(self):
        copy = OEHasAtomNameAdvanced(self._atom_name, self._case_sensitive, self._whitespace)
        return copy.__disown__()

# Import PredicateType enum values
from .oeselect import (
    PredicateType_AND,
    PredicateType_OR,
    PredicateType_NOT,
    PredicateType_XOR,
    PredicateType_NAME,
    PredicateType_RESN,
    PredicateType_RESI,
    PredicateType_CHAIN,
    PredicateType_ELEM,
    PredicateType_INDEX,
    PredicateType_ID,
    PredicateType_ALT,
    PredicateType_B_FACTOR,
    PredicateType_FRAGMENT,
    PredicateType_SECONDARY_STRUCTURE,
    PredicateType_PROTEIN,
    PredicateType_LIGAND,
    PredicateType_WATER,
    PredicateType_SOLVENT,
    PredicateType_ORGANIC,
    PredicateType_BACKBONE,
    PredicateType_METAL,
    PredicateType_HEAVY,
    PredicateType_HYDROGEN,
    PredicateType_POLAR_HYDROGEN,
    PredicateType_NONPOLAR_HYDROGEN,
    PredicateType_BY_RES,
    PredicateType_BY_CHAIN,
    PredicateType_AROUND,
    PredicateType_EXPAND,
    PredicateType_BEYOND,
    PredicateType_HELIX,
    PredicateType_SHEET,
    PredicateType_TURN,
    PredicateType_LOOP,
    PredicateType_TRUE,
    PredicateType_FALSE,
)

# Create a namespace for PredicateType enum
class PredicateType:
    """Enum-like class for predicate types."""
    And = PredicateType_AND
    Or = PredicateType_OR
    Not = PredicateType_NOT
    XOr = PredicateType_XOR
    Name = PredicateType_NAME
    Resn = PredicateType_RESN
    Resi = PredicateType_RESI
    Chain = PredicateType_CHAIN
    Elem = PredicateType_ELEM
    Index = PredicateType_INDEX
    Id = PredicateType_ID
    Alt = PredicateType_ALT
    BFactor = PredicateType_B_FACTOR
    Fragment = PredicateType_FRAGMENT
    SecondaryStructure = PredicateType_SECONDARY_STRUCTURE
    Protein = PredicateType_PROTEIN
    Ligand = PredicateType_LIGAND
    Water = PredicateType_WATER
    Solvent = PredicateType_SOLVENT
    Organic = PredicateType_ORGANIC
    Backbone = PredicateType_BACKBONE
    Metal = PredicateType_METAL
    Heavy = PredicateType_HEAVY
    Hydrogen = PredicateType_HYDROGEN
    PolarHydrogen = PredicateType_POLAR_HYDROGEN
    NonpolarHydrogen = PredicateType_NONPOLAR_HYDROGEN
    ByRes = PredicateType_BY_RES
    ByChain = PredicateType_BY_CHAIN
    Around = PredicateType_AROUND
    Expand = PredicateType_EXPAND
    Beyond = PredicateType_BEYOND
    Helix = PredicateType_HELIX
    Sheet = PredicateType_SHEET
    Turn = PredicateType_TURN
    Loop = PredicateType_LOOP
    True_ = PredicateType_TRUE
    False_ = PredicateType_FALSE

__all__ = [
    "__version__",
    "__version_info__",
    "OESelection",
    "OESelect",
    "Selector",
    "OEResidueSelector",
    "OEHasResidueName",
    "OEHasAtomNameAdvanced",
    "PredicateType",
    "EvaluateSelection",
    "CountSelection",
    "select",
    "count",
    "parse",
    "str_selector_set",
    "selector_set",
    "mol_to_selector_set",
    "get_selector_string",
]
