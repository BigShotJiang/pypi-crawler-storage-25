#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "OESelect::oeselect" for configuration "Release"
set_property(TARGET OESelect::oeselect APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(OESelect::oeselect PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/liboeselect.a"
  )

list(APPEND _cmake_import_check_targets OESelect::oeselect )
list(APPEND _cmake_import_check_files_for_OESelect::oeselect "${_IMPORT_PREFIX}/lib/liboeselect.a" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
