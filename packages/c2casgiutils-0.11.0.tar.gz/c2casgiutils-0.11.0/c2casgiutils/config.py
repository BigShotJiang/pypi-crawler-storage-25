import logging
import os
from pathlib import Path
from typing import Annotated, Literal, cast

from pydantic import BaseModel, Field, field_validator, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

_LOGGER = logging.getLogger(__name__)


class Redis(BaseModel):
    """Redis configuration."""

    url: Annotated[
        str | None,
        Field(
            description="Redis connection URL",
        ),
    ] = None
    options: Annotated[
        str | None,
        Field(description="Redis connection options, e.g. 'socket_timeout=5,ssl=True'."),
    ] = None
    sentinels: Annotated[
        str | None,
        Field(
            description="Redis Sentinels",
        ),
    ] = None
    servicename: Annotated[
        str | None,
        Field(
            description="Redis service name for Sentinel",
        ),
    ] = None
    db: Annotated[int, Field(description="Redis database number")] = 0
    broadcast_prefix: Annotated[
        str,
        Field(
            description="Redis prefix for broadcast channels",
        ),
    ] = "broadcast_api_"


class Prometheus(BaseModel):
    """Prometheus configuration."""

    prefix: Annotated[
        str,
        Field(
            description="Prefix for Prometheus metrics",
        ),
    ] = "c2casgiutils_"
    port: Annotated[int, Field(description="Port for Prometheus metrics")] = 9000


class Sentry(BaseModel):
    """
    Sentry configuration.

    See also: https://docs.sentry.io/platforms/python/configuration/options/#core-options
    """

    dsn: Annotated[str | None, Field(description="Sentry DSN")] = None
    debug: Annotated[bool, Field(description="Enable Sentry debug mode")] = False
    release: Annotated[str | None, Field(description="Sentry release version")] = None
    environment: Annotated[str, Field(description="Sentry environment")] = "production"
    dist: Annotated[str | None, Field(description="Sentry distribution")] = None
    sample_rate: Annotated[float, Field(description="Sample rate for error events")] = 1.0
    ignore_errors: Annotated[list[str], Field(description="List of exception class names to ignore")] = []
    max_breadcrumbs: Annotated[int, Field(description="Maximum number of breadcrumbs to capture")] = 100
    attach_stacktrace: Annotated[bool, Field(description="Attach stack trace to all messages")] = False
    send_default_pii: Annotated[bool | None, Field(description="Send default PII")] = None
    event_scrubber: Annotated[str | None, Field(description="Event scrubber for sensitive information")] = (
        None
    )
    include_source_context: Annotated[bool, Field(description="Include source context in events")] = True
    include_local_variables: Annotated[bool, Field(description="Include local variables in events")] = True
    add_full_stack: Annotated[bool, Field(description="Add full stack trace to events")] = False
    max_stack_frames: Annotated[int, Field(description="Maximum number of stack frames to capture")] = 100
    server_name: Annotated[str | None, Field(description="Server name for Sentry events")] = None
    project_root: Annotated[str, Field(description="Root directory of the project")] = str(Path.cwd())
    in_app_include: Annotated[
        list[str],
        Field(description="List of module prefixes that are in the app"),
    ] = []
    in_app_exclude: Annotated[
        list[str],
        Field(description="List of module prefixes that are not in the app"),
    ] = []
    max_request_body_size: Annotated[str, Field(description="Maximum request body size to capture")] = (
        "medium"
    )
    max_value_length: Annotated[int, Field(description="Maximum length of values in event payloads")] = 1024
    ca_certs: Annotated[str | None, Field(description="Path to alternative CA bundle file in PEM format")] = (
        None
    )
    send_client_reports: Annotated[bool, Field(description="Send client reports to Sentry")] = True
    tags: Annotated[
        dict[str, str],
        Field(
            description=(
                "Default tags for Sentry events, loaded from environment variables with prefix "
                "`C2C__SENTRY__TAG_` to set tags. The tag name will be the part after the prefix, "
                "converted to lowercase. For example, `C2C__SENTRY__TAG_SERVICE=my-service` will set a tag "
                "named `service` (lowercase) with value `my-service`."
            ),
        ),
    ] = {}

    @model_validator(mode="after")
    def build_sentry_tags(self) -> "Sentry":
        """Build the tags dictionary from environment variables."""
        # Get all environment variables that start with "C2C__SENTRY__TAG_"
        prefix = "C2C__SENTRY__TAG_"
        self.tags = {
            key[len(prefix) :].lower(): value for key, value in os.environ.items() if key.startswith(prefix)
        }
        return self


class AuthGitHub(BaseModel):
    """GitHub Authentication settings."""

    repository: Annotated[
        str | None,
        Field(description="GitHub repository for authentication"),
    ] = None
    access_type: Annotated[str, Field(description="GitHub access type")] = "pull"
    authorize_url: Annotated[
        str,
        Field(description="GitHub OAuth authorization URL"),
    ] = "https://github.com/login/oauth/authorize"
    token_url: Annotated[
        str,
        Field(description="GitHub OAuth token URL"),
    ] = "https://github.com/login/oauth/access_token"  # noqa: S105
    user_url: Annotated[str, Field(description="GitHub user API URL")] = "https://api.github.com/user"
    repo_url: Annotated[
        str,
        Field(description="GitHub repository API URL"),
    ] = "https://api.github.com/repos"
    client_id: Annotated[str | None, Field(description="GitHub OAuth client ID")] = None
    client_secret: Annotated[str | None, Field(description="GitHub OAuth client secret")] = None
    scope: Annotated[str, Field(description="GitHub OAuth scope")] = "repo"
    proxy_url: Annotated[str | None, Field(description="GitHub proxy URL")] = None
    state_cookie: Annotated[str, Field(description="GitHub state cookie name")] = "c2c-state"
    state_cookie_age: Annotated[
        int,
        Field(description="GitHub state cookie age in seconds (default: 10 minutes)"),
    ] = 10 * 60  # 10 minutes


class AuthJWTCookie(BaseModel):
    """JWT cookie settings."""

    name: Annotated[str, Field(description="Authentication cookie name")] = "c2c-jwt-auth"
    age: Annotated[
        int,
        Field(description="Authentication cookie age in seconds (default: 7 days)"),
    ] = 7 * 24 * 3600  # 7 days
    same_site: Annotated[
        Literal["lax", "strict", "none"],
        Field(
            description=(
                "SameSite attribute for the JWT cookies (state and auth token). "
                "Defaults to 'lax' to support OAuth and other redirect-based login flows that rely "
                "on the cookie being sent on top-level navigation from external sites. "
                "Use 'strict' for stronger CSRF protection when such flows are not required."
            ),
        ),
    ] = "lax"
    secure: Annotated[
        bool,
        Field(
            description="Whether the JWT cookie should be secure",
        ),
    ] = True
    path: Annotated[
        str | None,
        Field(
            description="Path for the JWT cookie (default: the c2c index path)",
        ),
    ] = None

    @field_validator("same_site", mode="before")
    @classmethod
    def normalize_same_site(cls, value: str | None) -> Literal["lax", "strict", "none"]:
        """Normalize same_site values like `Lax` to lowercase."""
        if value is None:
            message = "C2C__AUTH__JWT__COOKIE__SAME_SITE environment variable should be defined"
            raise ValueError(message)
        result = value.lower()
        if result in {"lax", "strict", "none"}:
            return cast("Literal['lax', 'strict', 'none']", result)
        message = f"Invalid C2C__AUTH__JWT__COOKIE__SAME_SITE environment variable value: {value}"
        raise ValueError(message)


class AuthJWT(BaseModel):
    """JWT Authentication settings used to store the cookies."""

    secret: Annotated[str | None, Field(description="JWT secret key")] = None
    algorithm: Annotated[str, Field(description="JWT algorithm (default: HS256)")] = "HS256"
    cookie: Annotated[AuthJWTCookie, Field(description="JWT cookie settings")] = AuthJWTCookie()


class AuthTest(BaseModel):
    """Test Authentication settings."""

    username: Annotated[str | None, Field(description="Test username")] = None


class Auth(BaseModel):
    """C2C Authentication settings."""

    # GitHub authentication settings
    jwt: Annotated[AuthJWT, Field(description="JWT authentication settings")] = AuthJWT()

    # Trivial auth (not secure)
    secret: Annotated[
        str | None,
        Field(description="Secret key for trivial authentication (not secure)"),
    ] = None

    # GitHub Authentication settings
    github: Annotated[
        AuthGitHub,
        Field(description="GitHub authentication settings"),
    ] = AuthGitHub()

    test: Annotated[
        AuthTest,
        Field(description="Test authentication settings"),
    ] = AuthTest()


class SettingsToolsLogging(BaseModel):
    """C2C Tools logging settings."""

    redis_prefix: Annotated[
        str,
        Field(
            description="Redis prefix for logging settings",
        ),
    ] = "c2c_logging_level_"
    application_module: Annotated[
        str,
        Field(
            description="Application module name for logging",
        ),
    ] = "c2casgiutils"


class SettingsTools(BaseModel):
    """C2C Tools settings."""

    logging: Annotated[
        SettingsToolsLogging,
        Field(
            description="Settings for logging tools",
        ),
    ] = SettingsToolsLogging()


class ProxyHeaders(BaseModel):
    """Proxy headers handling settings."""

    type: Annotated[
        Literal["none", "x-forwarded", "forwarded"],
        Field(
            description=(
                "Proxy headers mode: 'none' disables host/proto rewriting, "
                "'x-forwarded' trusts X-Forwarded-* headers, 'forwarded' trusts RFC7239 Forwarded header"
            ),
        ),
    ] = "none"
    trusted_hosts: Annotated[
        list[str] | str,
        Field(
            description=(
                "Trusted proxy client hosts/networks. Accepts comma-separated string or list "
                "(e.g. '127.0.0.1,10.0.0.0/8' or '*')."
            ),
        ),
    ] = ["127.0.0.1"]

    @field_validator("trusted_hosts", mode="before")
    @classmethod
    def normalize_trusted_hosts(cls, value: list[str] | str | None) -> list[str]:
        """Normalize trusted_hosts from env values to a list."""
        if value is None:
            return ["127.0.0.1"]
        if isinstance(value, list):
            return [v.strip() for v in value if v.strip()]
        return [v.strip() for v in value.split(",") if v.strip()]


class Settings(BaseSettings, extra="ignore"):
    """Application settings."""

    redis: Annotated[
        Redis,
        Field(
            description="Redis configuration settings",
        ),
    ] = Redis()
    prometheus: Annotated[
        Prometheus,
        Field(
            description="Prometheus configuration settings",
        ),
    ] = Prometheus()
    sentry: Annotated[
        Sentry,
        Field(
            description="Sentry configuration settings",
        ),
    ] = Sentry()
    auth: Annotated[
        Auth,
        Field(description="Authentication settings"),
    ] = Auth()
    tools: Annotated[
        SettingsTools,
        Field(description="Tools settings"),
    ] = SettingsTools()
    proxy_headers: Annotated[
        ProxyHeaders,
        Field(description="Proxy headers handling settings"),
    ] = ProxyHeaders()
    http: Annotated[
        bool,
        Field(
            description="The application is running in HTTP mode to be used for development only (default: False)",
        ),
    ] = False
    route_prefix: Annotated[
        str, Field(description="Route prefix for the application, should start and end with a '/'")
    ] = "/"

    model_config = SettingsConfigDict(env_prefix="C2C__", env_nested_delimiter="__")

    @model_validator(mode="after")
    def validate_route_prefix(self) -> "Settings":
        """Ensure route_prefix has leading and trailing slashes."""
        prefix = (self.route_prefix or "").strip()
        if not prefix:
            prefix = "/"
        if not prefix.startswith("/"):
            prefix = f"/{prefix}"
        if not prefix.endswith("/"):
            prefix = f"{prefix}/"
        if prefix != self.route_prefix:
            _LOGGER.info("Normalized route prefix to '%s'", prefix)
        self.route_prefix = prefix
        return self


settings = Settings()
