import re
from abc import ABC
from typing import Any, Dict, Optional, Tuple

from fastapi import HTTPException

from src.api.schemas import UserSchema
from src.api.tools.resource import ResourceName, check_shared_app
from src.api.tools.ssh import run_command


def parse_env_vars(text: str) -> Dict:
    result = {}
    lines = text.strip().splitlines()

    for line in lines:
        if line.startswith("=====>"):
            continue

        match = re.match(r"^(.+?):\s+(.*)$", line)

        if match:
            key = match.group(1).strip()
            value = match.group(2).strip()
            result[key] = value

    return result


class ConfigService(ABC):

    @staticmethod
    async def list_config(
        session_user: UserSchema, app_name: str, shared_by: Optional[str] = None
    ) -> Tuple[bool, Any]:
        session_user = await check_shared_app(session_user, app_name, shared_by)

        app_name = ResourceName(session_user, app_name).for_system()

        if app_name not in session_user.apps:
            raise HTTPException(
                status_code=404,
                detail="App does not exist",
            )
        success, message = await run_command(f"config:show {app_name}")

        return success, parse_env_vars(message)

    @staticmethod
    async def get_config(
        session_user: UserSchema,
        app_name: str,
        key: str,
        shared_by: Optional[str] = None,
    ) -> Tuple[bool, Any]:
        session_user = await check_shared_app(session_user, app_name, shared_by)

        app_name = ResourceName(session_user, app_name).for_system()

        if app_name not in session_user.apps:
            raise HTTPException(
                status_code=404,
                detail="App does not exist",
            )
        return await run_command(f"config:get {app_name} {key}")

    @staticmethod
    async def set_config(
        session_user: UserSchema,
        app_name: str,
        key: str,
        value: str,
        shared_by: Optional[str] = None,
    ) -> Tuple[bool, Any]:
        session_user = await check_shared_app(session_user, app_name, shared_by)

        app_name = ResourceName(session_user, app_name).for_system()

        if app_name not in session_user.apps:
            raise HTTPException(
                status_code=404,
                detail="App does not exist",
            )
        allowed = "abcdefghijklmnopqrstuvwxyz0123456789_"

        key = "".join([(c if c.lower() in allowed else "_") for c in key])

        return await run_command(f"config:set --no-restart {app_name} {key}='{value}'")

    @staticmethod
    async def unset_config(
        session_user: UserSchema,
        app_name: str,
        key: str,
        shared_by: Optional[str] = None,
    ) -> Tuple[bool, Any]:
        session_user = await check_shared_app(session_user, app_name, shared_by)

        app_name = ResourceName(session_user, app_name).for_system()

        if app_name not in session_user.apps:
            raise HTTPException(
                status_code=404,
                detail="App does not exist",
            )
        return await run_command(f"config:unset --no-restart {app_name} {key}")
