import logging
from datetime import datetime
from pathlib import Path

from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.triggers.interval import IntervalTrigger
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from src.api.middlewares import UserSessionMiddleware
from src.api.models import AsyncSessionLocal
from src.api.routers import get_router
from src.api.services import AppService, DatabaseService, NetworkService
from src.config import Config

APP_ROOT = Path(__file__).parent

scheduler = AsyncIOScheduler()


def get_app() -> FastAPI:
    """
    Get FastAPI application.

    This is the main constructor of the application.
    """
    logging.basicConfig(level=Config.API_LOG_LEVEL.upper())

    _app = FastAPI(
        title="Dokku API",
        default_response_class=JSONResponse,
        version=Config.API_VERSION_NUMBER,
    )

    _app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )
    _app.add_middleware(UserSessionMiddleware)

    _app.include_router(get_router(_app))

    async def sync_apps_job():
        async with AsyncSessionLocal() as db_session:
            await AppService.sync_dokku_with_api_database(db_session)

    async def sync_databases_job():
        async with AsyncSessionLocal() as db_session:
            await DatabaseService.sync_dokku_with_api_database(db_session)

    async def sync_networks_job():
        async with AsyncSessionLocal() as db_session:
            await NetworkService.sync_dokku_with_api_database(db_session)

    @_app.on_event("startup")
    async def startup():
        scheduler.start()
        scheduler.add_job(
            sync_apps_job,
            trigger=IntervalTrigger(hours=1),
            id="sync_dokku_with_app_database",
            replace_existing=True,
            next_run_time=datetime.now(),
            max_instances=1,
            coalesce=True,
        )
        scheduler.add_job(
            sync_databases_job,
            trigger=IntervalTrigger(hours=1),
            id="sync_dokku_with_service_database",
            replace_existing=True,
            next_run_time=datetime.now(),
            max_instances=1,
            coalesce=True,
        )
        scheduler.add_job(
            sync_networks_job,
            trigger=IntervalTrigger(minutes=10),
            id="sync_dokku_with_network_database",
            replace_existing=True,
            next_run_time=datetime.now(),
            max_instances=1,
            coalesce=True,
        )

    return _app
