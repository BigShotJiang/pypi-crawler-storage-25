import re
import typing as t
from datetime import UTC, datetime
from pathlib import Path

from loguru import logger

from dreadnode.agents.tools import Tool, tool


def _slugify(value: str) -> str:
    slug = re.sub(r"[^a-zA-Z0-9._-]+", "-", value.strip().lower())
    slug = slug.strip("._-")
    return slug or "report"


def _resolve_filename(
    *,
    title: str | None,
    filename: str | None,
    format: t.Literal["markdown", "text"],
) -> str:
    candidate = Path(filename).name if filename else _slugify(title or "report")
    if not Path(candidate).suffix:
        suffix = ".md" if format == "markdown" else ".txt"
        candidate = f"{candidate}{suffix}"
    return candidate


def create_report_tool(*, base_dir: Path | None = None) -> "Tool[..., str]":
    """Create a report tool bound to a specific base directory."""
    report_root = base_dir or Path.cwd()

    @tool(name="report", catch=True)
    def report(
        content: t.Annotated[
            str,
            "Markdown or plain-text report content to persist for later reference.",
        ],
        *,
        title: t.Annotated[
            str | None,
            "Optional human-readable title used for logging and default filename generation.",
        ] = None,
        filename: t.Annotated[
            str | None,
            "Optional filename under .dreadnode/reports/. Path components are ignored.",
        ] = None,
        format: t.Annotated[
            t.Literal["markdown", "text"],
            "Output format hint for the saved report artifact.",
        ] = "markdown",
    ) -> str:
        """
        Persist a named report artifact for the current run or session.

        Use this when you have produced a deliverable worth saving outside the normal
        assistant reply, such as a findings report, migration summary, or plan.
        The tool writes the report under `.dreadnode/reports/` and logs it to the
        current Dreadnode run when tracing is active.
        """
        from dreadnode import log_output
        from dreadnode.core.types import Markdown, Text

        body = content.strip()
        if not body:
            raise ValueError("Report content must not be empty.")

        reports_dir = report_root / ".dreadnode" / "reports"
        reports_dir.mkdir(parents=True, exist_ok=True)

        resolved_name = _resolve_filename(title=title, filename=filename, format=format)
        path = reports_dir / resolved_name
        if path.exists():
            stem = path.stem
            timestamp = datetime.now(UTC).strftime("%Y%m%d-%H%M%S")
            path = path.with_name(f"{stem}-{timestamp}{path.suffix}")

        path.write_text(content, encoding="utf-8")

        relative_path = str(path.relative_to(report_root))
        renderable = Markdown(content) if format == "markdown" else Text(content, format="text")
        log_output(
            "report",
            renderable,
            label=title or path.name,
            attributes={"path": relative_path, "format": format},
        )
        logger.info("Saved report artifact to {}", path)
        return f"Saved {format} report to {relative_path}"

    return report


report = create_report_tool()
