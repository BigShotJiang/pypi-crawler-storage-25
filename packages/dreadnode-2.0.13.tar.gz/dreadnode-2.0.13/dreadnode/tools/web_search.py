"""Web search tool for searching the web via DuckDuckGo or Google."""

import typing as t

import httpx
from loguru import logger

from dreadnode.agents.tools import tool


@tool(catch=True)
async def web_search(
    query: t.Annotated[str, "Search query"],
    *,
    num_results: t.Annotated[int, "Number of results to return"] = 5,
    search_engine: t.Annotated[str, "Search engine: 'duckduckgo' or 'google'"] = "duckduckgo",
) -> str:
    """
    Search the web and return results.

    Returns a list of search results with titles, URLs, and snippets.

    ## Note
    - DuckDuckGo is the default (no API key required)
    - Google requires GOOGLE_API_KEY and GOOGLE_CSE_ID environment variables

    ## Examples

    Basic search:
    ```
    web_search("python asyncio tutorial")
    ```

    More results:
    ```
    web_search("fastapi authentication", num_results=10)
    ```

    Args:
        query: The search query.
        num_results: Number of results to return (max 10).
        search_engine: Which search engine to use.

    Returns:
        Formatted search results.
    """
    num_results = min(num_results, 10)

    logger.info(f"Searching: {query}")

    if search_engine == "duckduckgo":
        return await _search_duckduckgo(query, num_results)
    if search_engine == "google":
        return await _search_google(query, num_results)
    raise ValueError(f"Unknown search engine: {search_engine}")


async def _search_duckduckgo(query: str, num_results: int) -> str:
    """Search using DuckDuckGo HTML (no API key needed)."""
    try:
        from duckduckgo_search import DDGS

        with DDGS() as ddgs:
            results = list(ddgs.text(query, max_results=num_results))

        if not results:
            return f"No results found for: {query}"

        output = f"## Search Results for: {query}\n\n"

        for i, r in enumerate(results, 1):
            title = r.get("title", "No title")
            url = r.get("href", r.get("link", ""))
            snippet = r.get("body", r.get("snippet", ""))

            output += f"### {i}. {title}\n"
            output += f"**URL:** {url}\n"
            output += f"{snippet}\n\n"
    except ImportError:
        # Fallback: use DuckDuckGo Lite HTML scraping
        return await _search_duckduckgo_lite(query, num_results)
    else:
        return output


async def _search_duckduckgo_lite(query: str, num_results: int) -> str:
    """Fallback DuckDuckGo search via HTML scraping."""
    async with httpx.AsyncClient(timeout=30) as client:
        response = await client.get(
            "https://lite.duckduckgo.com/lite/",
            params={"q": query},
            headers={"User-Agent": "Mozilla/5.0"},
        )
        response.raise_for_status()

        # Basic parsing
        try:
            from bs4 import BeautifulSoup

            soup = BeautifulSoup(response.text, "html.parser")
            results = []

            for link in soup.select("a.result-link")[:num_results]:
                title = link.get_text(strip=True)
                url = link.get("href", "")
                snippet_elem = link.find_next("td", class_="result-snippet")
                snippet = snippet_elem.get_text(strip=True) if snippet_elem else ""

                results.append({"title": title, "url": url, "snippet": snippet})

            if not results:
                return f"No results found for: {query}"

            output = f"## Search Results for: {query}\n\n"
            for i, r in enumerate(results, 1):
                output += f"### {i}. {r['title']}\n"
                output += f"**URL:** {r['url']}\n"
                output += f"{r['snippet']}\n\n"
        except ImportError:
            return (
                "Search requires 'duckduckgo-search' or 'beautifulsoup4' package.\n"
                "Install with: pip install duckduckgo-search"
            )
        else:
            return output


async def _search_google(query: str, num_results: int) -> str:
    """Search using Google Custom Search API."""
    import os

    api_key = os.environ.get("GOOGLE_API_KEY")
    cse_id = os.environ.get("GOOGLE_CSE_ID")

    if not api_key or not cse_id:
        return (
            "Google search requires GOOGLE_API_KEY and GOOGLE_CSE_ID environment variables.\n"
            "Falling back to DuckDuckGo..."
        )

    async with httpx.AsyncClient(timeout=30) as client:
        response = await client.get(
            "https://www.googleapis.com/customsearch/v1",
            params={
                "key": api_key,
                "cx": cse_id,
                "q": query,
                "num": num_results,
            },
        )
        response.raise_for_status()
        data = response.json()

    items = data.get("items", [])

    if not items:
        return f"No results found for: {query}"

    output = f"## Search Results for: {query}\n\n"

    for i, item in enumerate(items, 1):
        title = item.get("title", "No title")
        url = item.get("link", "")
        snippet = item.get("snippet", "")

        output += f"### {i}. {title}\n"
        output += f"**URL:** {url}\n"
        output += f"{snippet}\n\n"

    return output
