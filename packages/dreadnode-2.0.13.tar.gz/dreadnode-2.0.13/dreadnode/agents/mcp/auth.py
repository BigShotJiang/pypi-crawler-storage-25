"""
MCP OAuth authentication support.

Provides file-based token storage and helpers for building OAuth providers
using the MCP SDK's built-in OAuthClientProvider.
"""

import asyncio
import json
import os
import typing as t
from collections.abc import Awaitable, Callable
from pathlib import Path

from loguru import logger

if t.TYPE_CHECKING:
    from mcp.client.auth.oauth2 import OAuthClientProvider, TokenStorage
    from mcp.shared.auth import OAuthClientInformationFull, OAuthToken

from dreadnode.agents.mcp.config import OAuthConfig

DEFAULT_AUTH_PATH = Path.home() / ".dreadnode" / "mcp-auth.json"


class FileTokenStorage:
    """Persist OAuth tokens to disk, keyed by server URL.

    File format (at ~/.dreadnode/mcp-auth.json, mode 0o600):
    {
      "https://api.example.com/mcp": {
        "tokens": { ... },
        "client_info": { ... }
      }
    }
    """

    def __init__(self, server_url: str, path: Path | None = None) -> None:
        self._server_url = server_url
        self._path = path or DEFAULT_AUTH_PATH

    def _read_store(self) -> dict[str, t.Any]:
        if not self._path.exists():
            return {}
        try:
            return json.loads(self._path.read_text())
        except (json.JSONDecodeError, OSError):
            logger.warning("Corrupt MCP auth file at {}, starting fresh", self._path)
            return {}

    def _write_store(self, store: dict[str, t.Any]) -> None:
        self._path.parent.mkdir(parents=True, exist_ok=True)
        fd = os.open(self._path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        with os.fdopen(fd, "w") as f:
            json.dump(store, f, indent=2)

    def _get_entry(self) -> dict[str, t.Any]:
        return self._read_store().get(self._server_url, {})

    def _set_entry(self, entry: dict[str, t.Any]) -> None:
        store = self._read_store()
        store[self._server_url] = entry
        self._write_store(store)

    async def get_tokens(self) -> "OAuthToken | None":
        from mcp.shared.auth import OAuthToken

        entry = await asyncio.to_thread(self._get_entry)
        data = entry.get("tokens")
        if data is None:
            return None
        try:
            return OAuthToken.model_validate(data)
        except Exception:
            logger.warning("Invalid stored tokens for {}", self._server_url)
            return None

    async def set_tokens(self, tokens: "OAuthToken") -> None:
        def _update() -> None:
            entry = self._get_entry()
            entry["tokens"] = tokens.model_dump(mode="json", exclude_none=True)
            self._set_entry(entry)

        await asyncio.to_thread(_update)

    async def get_client_info(self) -> "OAuthClientInformationFull | None":
        from mcp.shared.auth import OAuthClientInformationFull

        entry = await asyncio.to_thread(self._get_entry)
        data = entry.get("client_info")
        if data is None:
            return None
        try:
            return OAuthClientInformationFull.model_validate(data)
        except Exception:
            logger.warning("Invalid stored client info for {}", self._server_url)
            return None

    async def set_client_info(self, client_info: "OAuthClientInformationFull") -> None:
        def _update() -> None:
            entry = self._get_entry()
            entry["client_info"] = client_info.model_dump(mode="json", exclude_none=True)
            self._set_entry(entry)

        await asyncio.to_thread(_update)


async def _default_redirect_handler(url: str) -> None:
    logger.info("MCP OAuth: Visit this URL to authorize:\n  {}", url)


def create_oauth_provider(
    server_url: str,
    config: OAuthConfig | None = None,
    storage: "TokenStorage | None" = None,
    redirect_handler: Callable[[str], Awaitable[None]] | None = None,
    callback_handler: Callable[[], Awaitable[tuple[str, str | None]]] | None = None,
) -> "OAuthClientProvider":
    """Build an OAuthClientProvider from our config types.

    Args:
        server_url: The MCP server URL.
        config: OAuth configuration. Uses defaults if None.
        storage: Token storage. Defaults to FileTokenStorage.
        redirect_handler: Called with auth URL. Defaults to logging the URL.
        callback_handler: Called to get (code, state). None by default
            (Layer 3/TUI provides this for interactive flows).
    """
    from mcp.client.auth.oauth2 import OAuthClientProvider
    from mcp.shared.auth import OAuthClientMetadata

    config = config or OAuthConfig()

    client_metadata = OAuthClientMetadata(
        redirect_uris=None,
        client_name=config.client_name,
        scope=config.scope,
    )

    if storage is None:
        storage = FileTokenStorage(server_url)

    return OAuthClientProvider(
        server_url=server_url,
        client_metadata=client_metadata,
        storage=storage,
        redirect_handler=redirect_handler or _default_redirect_handler,
        callback_handler=callback_handler,
    )
