"""Runtime client with server lifecycle management.

Extends :class:`RuntimeClient` with the ability to start, stop, and
restart the runtime server — either in-process via ASGI or as a
managed subprocess. Also provides transport introspection methods
used by the TUI connection manager.
"""

import asyncio
import contextlib
import os
import shlex
import subprocess
import tempfile
import time
import typing as t
from pathlib import Path

import httpx
from loguru import logger

from dreadnode.app.client import models
from dreadnode.app.client.runtime_client import (
    DEFAULT_RUNTIME_HOST,
    DEFAULT_RUNTIME_PORT,
    DEFAULT_RUNTIME_URL,
    RuntimeClient,
)
from dreadnode.app.client.transports import StreamingASGITransport

DEFAULT_START_TIMEOUT_S = 20.0

if t.TYPE_CHECKING:
    from dreadnode.app.config import Profile


class ManagedRuntimeClient(RuntimeClient):
    """Runtime client that can start and manage the server process.

    Use this when the client is responsible for ensuring the server
    is running — the TUI, ``dn --print``, and similar launchers.
    Workers and standalone scripts that connect to an already-running
    server should use :class:`RuntimeClient` directly.
    """

    def __init__(
        self,
        server_url: str | None = None,
        auto_start: bool = True,
        transport: httpx.AsyncBaseTransport | None = None,
        capability_dirs: list[str] | None = None,
        enabled_capabilities: list[str] | None = None,
        capability_flag_overrides: list[str] | None = None,
        system_prompt_append: str | None = None,
        auth_token: str | None = None,
    ) -> None:
        super().__init__(
            server_url=server_url or DEFAULT_RUNTIME_URL,
            auth_token=auth_token,
            transport=transport,
        )
        self.auto_start = auto_start
        self._in_process = auto_start and transport is None and server_url is None
        self._owned_process: subprocess.Popen[t.Any] | None = None
        self._owned_log_file: t.Any = None
        self._platform_server: str | None = None
        self._platform_api_key: str | None = None
        self._platform_organization: str | None = None
        self._platform_workspace: str | None = None
        self._platform_project: str | None = None
        # CLI overrides threaded to initialize_app()
        self._capability_dirs = capability_dirs
        self._enabled_capabilities = enabled_capabilities
        self._capability_flag_overrides = capability_flag_overrides
        self._system_prompt_append = system_prompt_append
        self._lifecycle_ctx: t.Any = None
        # Serialize concurrent start() callers so the slow in-process boot
        # (capability scan + MCP start + litellm warmup) runs once. The
        # event lets passive consumers (e.g. the TUI notify subscriber)
        # wait for the runtime to come up instead of racing start() and
        # kicking off a second boot with empty credentials.
        self._start_lock = asyncio.Lock()
        self._started_event = asyncio.Event()

    # ── Platform profile ──────────────────────────────────────────

    def set_platform_profile(self, profile: "Profile") -> None:
        """Store the active platform profile for local server startup."""
        self._platform_server = profile.url
        self._platform_api_key = profile.api_key
        self._platform_organization = profile.default_organization
        self._platform_workspace = profile.default_workspace
        self._platform_project = profile.default_project

    def clear_platform_profile(self) -> None:
        """Clear any stored platform profile for local-only runtime startup."""
        self._platform_server = None
        self._platform_api_key = None
        self._platform_organization = None
        self._platform_workspace = None
        self._platform_project = None

    # ── Session creation (with platform project default) ──────────

    async def create_session(
        self,
        *,
        capability: str | None = None,
        agent: str | None = None,
        model: str | None = None,
        session_id: str | None = None,
        project: str | None = None,
        generate_params_extra: dict[str, t.Any] | None = None,
        policy: str | dict[str, t.Any] | None = None,
    ) -> models.SessionInfo:
        """Create a session, defaulting project from the platform profile."""
        resolved_project = project or self._platform_project
        return await super().create_session(
            capability=capability,
            agent=agent,
            model=model,
            session_id=session_id,
            project=resolved_project,
            generate_params_extra=generate_params_extra,
            policy=policy,
        )

    # ── Server lifecycle ──────────────────────────────────────────

    async def start(self) -> None:
        """Ensure the target server is reachable, auto-starting if needed."""
        if self._started:
            return

        async with self._start_lock:
            if self._started:
                return

            if self._in_process:
                logger.info("Server start | mode=in-process | url={}", self.server_url)
                await self._start_in_process()
                self._mark_started()
                return

            if await self._is_healthy():
                logger.info("Server start | mode=external | url={}", self.server_url)
                self._mark_started()
                return

            if not self.auto_start:
                logger.error("Server unreachable | url={} | auto_start=false", self.server_url)
                raise RuntimeError(
                    "Could not connect to Dreadnode runtime server at "
                    f"{self.server_url}. The --server flag overrides the local runtime "
                    "endpoint, not the platform API. Omit --server to auto-start the local "
                    "runtime, and use /login --server <url> to set the platform API."
                )

            logger.info("Server start | mode=spawned | url={}", self.server_url)
            self._spawn_local_server()
            await self._wait_until_healthy()
            self._mark_started()

    async def wait_until_started(self) -> None:
        """Block until ``start()`` has successfully brought the server up."""
        await self._started_event.wait()

    def _mark_started(self) -> None:
        self._started = True
        self._started_event.set()

    def _mark_stopped(self) -> None:
        self._started = False
        self._started_event.clear()

    async def close(self) -> None:
        """Close resources and shut down any managed server."""
        logger.info("Closing runtime client")

        # Exit in-process lifecycle before closing the transport
        # (the httpx client owns the ASGI transport whose loop hosts it).
        if self._in_process and self._lifecycle_ctx is not None:
            transport = self._http_client._transport
            if (
                isinstance(transport, StreamingASGITransport)
                and transport.server_loop is not None
                and transport.server_loop.is_running()
            ):
                server_loop = transport.require_server_loop()
                future = asyncio.run_coroutine_threadsafe(
                    self._lifecycle_ctx.__aexit__(None, None, None),
                    server_loop,
                )
                await asyncio.to_thread(future.result)
            else:
                await self._lifecycle_ctx.__aexit__(None, None, None)
            self._lifecycle_ctx = None

        await super().close()

        if self._in_process:
            from dreadnode.app.server.app import reset_app_state

            reset_app_state()
            logger.debug("In-process server state reset")
            return

        if self._owned_process is not None and self._owned_process.poll() is None:
            logger.info("Terminating spawned server | pid={}", self._owned_process.pid)
            self._owned_process.terminate()
            with contextlib.suppress(subprocess.TimeoutExpired):
                self._owned_process.wait(timeout=5)
            if self._owned_process.poll() is None:
                logger.warning(
                    "Server did not terminate gracefully, killing | pid={}", self._owned_process.pid
                )
                self._owned_process.kill()
                with contextlib.suppress(subprocess.TimeoutExpired):
                    self._owned_process.wait(timeout=2)

        if self._owned_log_file is not None:
            log_name = self._owned_log_file.name
            self._owned_log_file.close()
            with contextlib.suppress(OSError):
                Path(log_name).unlink()

    async def restart(self) -> None:
        """Restart the server so it picks up fresh platform context."""
        logger.info("Restarting runtime server | in_process={}", self._in_process)
        interactive = self._interactive_transport
        self._interactive_transport = None
        if interactive is not None:
            await interactive.close()
        if self._in_process:
            await self._http_client.aclose()

            from dreadnode.app.server.app import reset_app_state

            reset_app_state()

            self._mark_stopped()
            await self._start_in_process()
            self._mark_started()
            return

        await self.close()
        self._owned_process = None
        self._owned_log_file = None
        self._mark_stopped()
        self._http_client = httpx.AsyncClient(
            base_url=self.server_url,
            timeout=None,  # noqa: S113 - long-lived local runtime client intentionally disables global timeout
            headers=self._build_auth_headers(),
        )
        await self.start()

    # ── Transport introspection (TUI connection manager) ──────────

    async def probe_interactive_transport(self) -> bool:
        """Check remote liveness through the persistent interactive websocket."""
        transport = self._interactive_transport
        if transport is None:
            return False
        await transport.ping()
        return True

    def latest_session_snapshot(self, session_id: str) -> dict[str, t.Any] | None:
        """Return the last interactive session snapshot seen for a session."""
        transport = self._interactive_transport
        if transport is None:
            return None
        return transport.latest_session_snapshot(session_id)

    def latest_session_resync_required(self, session_id: str) -> dict[str, t.Any] | None:
        """Return the last replay-miss payload seen for a session."""
        transport = self._interactive_transport
        if transport is None:
            return None
        return transport.latest_resync_required(session_id)

    def desired_session_subscriptions(self) -> set[str]:
        """Return the sessions the client intends to keep subscribed."""
        transport = self._interactive_transport
        if transport is None:
            return set()
        return transport.desired_session_ids()

    def subscribed_session_subscriptions(self) -> set[str]:
        """Return the sessions currently subscribed on the websocket."""
        transport = self._interactive_transport
        if transport is None:
            return set()
        return transport.subscribed_session_ids()

    # ── Private server management ─────────────────────────────────

    async def _start_in_process(self) -> None:
        """Initialize the FastAPI app in-process and connect via ASGI transport."""
        logger.info("Starting in-process runtime server")
        from dreadnode.app.server.app import app as server_app
        from dreadnode.app.server.app import initialize_app, server_lifecycle

        await asyncio.to_thread(
            initialize_app,
            server=self._platform_server,
            api_key=self._platform_api_key,
            organization=self._platform_organization,
            workspace=self._platform_workspace,
            project=self._platform_project,
            capability_dirs=self._capability_dirs,
            enabled_capabilities=self._enabled_capabilities,
            capability_flag_overrides=self._capability_flag_overrides,
            system_prompt_append=self._system_prompt_append,
        )

        # Create the transport first — it owns a dedicated server event loop.
        transport = StreamingASGITransport(app=server_app)

        # In-process mode skips FastAPI lifespan events, so we enter the
        # shared server_lifecycle context manually on the transport's server
        # loop.  This ensures MCP client tasks, the reload endpoint, and
        # shutdown all share the same event loop — avoiding cross-loop errors.
        self._lifecycle_ctx = server_lifecycle()
        server_loop = transport.require_server_loop()
        future = asyncio.run_coroutine_threadsafe(self._lifecycle_ctx.__aenter__(), server_loop)
        await asyncio.to_thread(future.result)

        self._http_client = httpx.AsyncClient(
            transport=transport,
            base_url=self.server_url,
            timeout=None,  # noqa: S113 - in-process transport should not enforce request timeouts
            headers=self._build_auth_headers(),
        )

    def _spawn_local_server(self) -> None:
        """Spawn the agent server as a subprocess."""
        command = [
            "uv",
            "run",
            "dreadnode",
            "serve",
            "--host",
            DEFAULT_RUNTIME_HOST,
            "--port",
            str(DEFAULT_RUNTIME_PORT),
        ]
        if self._platform_server:
            command.extend(["--platform-server", shlex.quote(self._platform_server)])
        if self._platform_api_key:
            command.extend(["--api-key", shlex.quote(self._platform_api_key)])
        if self._platform_organization:
            command.extend(["--organization", shlex.quote(self._platform_organization)])
        if self._platform_workspace:
            command.extend(["--workspace", shlex.quote(self._platform_workspace)])
        if self._platform_project:
            command.extend(["--project", shlex.quote(self._platform_project)])

        self._owned_log_file = tempfile.NamedTemporaryFile(  # noqa: SIM115 - manually owned across subprocess lifecycle
            mode="w+",
            encoding="utf-8",
            prefix="dreadnode-tui-server-",
            suffix=".log",
            delete=False,
        )
        self._owned_process = subprocess.Popen(  # noqa: S603 - command is assembled from fixed local runtime arguments
            command,
            stdout=self._owned_log_file,
            stderr=subprocess.STDOUT,
            env=os.environ.copy(),
        )
        logger.info(
            "Spawned local server | pid={} | cmd={} | log={}",
            self._owned_process.pid,
            " ".join(command),
            self._owned_log_file.name,
        )

    async def _wait_until_healthy(self, timeout_s: float = DEFAULT_START_TIMEOUT_S) -> None:
        deadline = time.monotonic() + timeout_s
        attempts = 0
        start_time = time.monotonic()
        while time.monotonic() < deadline:
            attempts += 1
            if self._owned_process is not None and self._owned_process.poll() is not None:
                logger.error(
                    "Spawned server exited early | exit_code={} | attempts={}",
                    self._owned_process.returncode,
                    attempts,
                )
                log_tail = self._read_log_tail()
                details = f"\n\n{log_tail}" if log_tail else ""
                raise RuntimeError(
                    f"Local Dreadnode server exited with status {self._owned_process.returncode}.{details}"
                )
            if await self._is_healthy():
                elapsed = time.monotonic() - start_time
                logger.info("Server healthy | attempts={} | elapsed={:.1f}s", attempts, elapsed)
                return
            await asyncio.sleep(0.1)

        elapsed = time.monotonic() - start_time
        logger.error(
            "Server health timeout | url={} | attempts={} | elapsed={:.1f}s",
            self.server_url,
            attempts,
            elapsed,
        )
        log_tail = self._read_log_tail()
        details = f"\n\n{log_tail}" if log_tail else ""
        raise RuntimeError(
            f"Timed out waiting for local Dreadnode server at {self.server_url}.{details}"
        )

    def _read_log_tail(self, max_chars: int = 4000) -> str:
        if self._owned_log_file is None:
            return ""
        with contextlib.suppress(OSError):
            return Path(self._owned_log_file.name).read_text(encoding="utf-8")[-max_chars:].strip()
        return ""
