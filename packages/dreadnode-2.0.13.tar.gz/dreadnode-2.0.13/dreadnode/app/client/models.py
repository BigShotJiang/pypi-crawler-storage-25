import typing as t
from dataclasses import dataclass, field


@dataclass(slots=True)
class CapabilityAgentInfo:
    """Agent metadata returned by the runtime API."""

    name: str
    description: str
    model: str
    capability: str

    @classmethod
    def from_dict(cls, data: dict[str, t.Any]) -> "CapabilityAgentInfo":
        return cls(
            name=str(data.get("name", "")),
            description=str(data.get("description", "")),
            model=str(data.get("model", "inherit")),
            capability=str(data.get("capability", "")),
        )


@dataclass(slots=True)
class CapabilityInfo:
    """Capability metadata returned by the runtime API."""

    name: str
    display_name: str
    canonical_name: str | None = None
    local_path: str | None = None
    entry_agent: str | None = None
    skills_paths: list[str] = field(default_factory=list)
    agents: list[CapabilityAgentInfo] = field(default_factory=list)
    source: str | None = None
    provenance: str | None = None
    version: str | None = None
    description: str | None = None
    author: dict[str, t.Any] | None = None
    license: str | None = None
    origin: dict[str, t.Any] | None = None
    enabled: bool = True
    binding_id: str | None = None
    components: list[dict[str, t.Any]] = field(default_factory=list)
    update_available: str | None = None
    dependencies: dict[str, t.Any] | None = None
    checks: list[dict[str, t.Any]] | None = None
    flags: list[dict[str, t.Any]] = field(default_factory=list)

    @classmethod
    def from_dict(cls, data: dict[str, t.Any]) -> "CapabilityInfo":
        return cls(
            name=str(data.get("name", "")),
            display_name=str(data.get("display_name") or data.get("name", "")),
            canonical_name=(
                str(data["canonical_name"]) if data.get("canonical_name") is not None else None
            ),
            local_path=(str(data["local_path"]) if data.get("local_path") is not None else None),
            entry_agent=str(data["entry_agent"]) if data.get("entry_agent") else None,
            skills_paths=[str(path) for path in data.get("skills_paths", [])],
            agents=[
                CapabilityAgentInfo.from_dict(item)
                for item in data.get("agents", [])
                if isinstance(item, dict)
            ],
            source=data.get("source"),
            provenance=(str(data["provenance"]) if data.get("provenance") is not None else None),
            version=data.get("version"),
            description=str(data["description"]) if data.get("description") is not None else None,
            author=data.get("author") if isinstance(data.get("author"), dict) else None,
            license=str(data["license"]) if data.get("license") is not None else None,
            origin=data.get("origin") if isinstance(data.get("origin"), dict) else None,
            enabled=data.get("enabled", True),
            binding_id=data.get("binding_id"),
            components=data.get("components", []),
            update_available=data.get("update_available"),
            dependencies=data.get("dependencies"),
            checks=data.get("checks"),
            flags=[item for item in data.get("flags", []) if isinstance(item, dict)],
        )


@dataclass(slots=True)
class SkillInfo:
    """Skill metadata from the server."""

    name: str
    description: str

    @staticmethod
    def from_dict(data: dict[str, t.Any]) -> "SkillInfo":
        return SkillInfo(name=str(data["name"]), description=str(data.get("description", "")))


@dataclass(slots=True)
class ToolInfo:
    """Tool metadata from the runtime ``/api/tools`` endpoint.

    ``capability`` is the source group the runtime reports: ``built-in``
    for the default toolset, ``mcp`` for MCP-server tools, ``session``
    for session-scoped helpers like ``load_skill``/``spawn_agent``, or
    a loaded capability name for capability-provided tools.

    ``parameters_schema`` is the tool's JSON Schema (if available) —
    used by :mod:`dreadnode.app.tui.tool_format` to derive the key
    argument for a compact label.
    """

    name: str
    description: str = ""
    capability: str = ""
    parameters_schema: dict[str, t.Any] | None = None

    @staticmethod
    def from_dict(data: dict[str, t.Any]) -> "ToolInfo":
        schema = data.get("parameters_schema")
        return ToolInfo(
            name=str(data.get("name", "")),
            description=str(data.get("description", "") or ""),
            capability=str(data.get("capability", "") or ""),
            parameters_schema=schema if isinstance(schema, dict) else None,
        )


@dataclass(slots=True)
class RuntimeInfo:
    """Summary of the connected server runtime."""

    status: str
    version: str
    runtime_id: str | None = None
    host_type: str = "local"
    working_dir: str = ""
    default_capability: str | None = None
    capabilities: list[CapabilityInfo] = field(default_factory=list)

    @classmethod
    def from_dict(cls, data: dict[str, t.Any]) -> "RuntimeInfo":
        return cls(
            status=str(data.get("status", "unknown")),
            version=str(data.get("version", "unknown")),
            runtime_id=(str(data["runtime_id"]) if data.get("runtime_id") else None),
            host_type=str(data.get("host_type", "local")),
            working_dir=str(data.get("working_dir", "")),
            default_capability=(
                str(data["default_capability"]) if data.get("default_capability") else None
            ),
            capabilities=[
                CapabilityInfo.from_dict(item)
                for item in data.get("capabilities", [])
                if isinstance(item, dict)
            ],
        )


@dataclass(slots=True)
class SessionInfo:
    """Server-side session metadata."""

    session_id: str
    project: str | None
    created_at: str
    updated_at: str | None = None
    message_count: int = 0
    session_dir: str | None = None
    capability: str | None = None
    agent: str | None = None
    title: str | None = None
    preview: str | None = None
    policy_name: str = "interactive"
    policy_is_autonomous: bool = False
    policy_display_label: str = ""

    @classmethod
    def from_dict(cls, data: dict[str, t.Any]) -> "SessionInfo":
        return cls(
            session_id=str(data.get("session_id", "")),
            project=str(data["project"]) if data.get("project") else None,
            created_at=str(data.get("created_at", "")),
            updated_at=str(data["updated_at"]) if data.get("updated_at") else None,
            message_count=int(data.get("message_count", 0)),
            session_dir=str(data["session_dir"]) if data.get("session_dir") else None,
            capability=str(data["capability"]) if data.get("capability") else None,
            agent=str(data["agent"]) if data.get("agent") else None,
            title=str(data["title"]) if data.get("title") else None,
            preview=str(data["preview"]) if data.get("preview") else None,
            policy_name=str(data.get("policy_name", "interactive")),
            policy_is_autonomous=bool(data.get("policy_is_autonomous", False)),
            policy_display_label=str(data.get("policy_display_label", "") or ""),
        )
