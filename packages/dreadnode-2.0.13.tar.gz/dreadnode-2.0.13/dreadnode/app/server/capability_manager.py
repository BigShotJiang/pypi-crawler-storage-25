import asyncio
import os
import time
import typing as t
from dataclasses import dataclass, field
from pathlib import Path

from loguru import logger

from dreadnode.app.api.models import (
    CapabilityAgentInfo,
    CapabilityInfo,
    ComponentStatusInfo,
    FlagInfo,
    RuntimeInfoResponse,
)

if t.TYPE_CHECKING:
    from dreadnode.app.server.worker_manager import WorkerLifecycleManager
    from dreadnode.capabilities.capability import Capability
    from dreadnode.capabilities.types import AgentDef


def _tool_name(tool: t.Any) -> str:
    """Get the name of a tool object."""
    return getattr(tool, "name", "")


@dataclass(slots=True)
class CapabilityRegistry:
    """Registry of capabilities available to the local server."""

    capabilities: dict[str, "Capability"] = field(default_factory=dict)
    disabled_local: dict[str, "Capability"] = field(default_factory=dict)
    default_capability_name: str | None = None
    mcp_manager: "MCPLifecycleManager | None" = None
    worker_manager: "WorkerLifecycleManager | None" = None
    runtime_bindings: list[dict[str, t.Any]] = field(default_factory=list)
    load_failures: list[dict[str, t.Any]] = field(default_factory=list)
    local_capability_records: dict[str, dict[str, t.Any]] = field(default_factory=dict)
    update_info: dict[str, str] = field(default_factory=dict)
    _skills_cache: list[t.Any] | None = field(default=None, init=False, repr=False)

    def get(self, name: str | None) -> "Capability | None":
        if not name:
            return None
        return self.capabilities.get(name)

    def default(self) -> "Capability | None":
        if self.default_capability_name:
            return self.capabilities.get(self.default_capability_name)
        if self.capabilities:
            return next(iter(self.capabilities.values()))
        return None

    def resolve(
        self,
        *,
        capability_name: str | None = None,
        agent_name: str | None = None,
    ) -> tuple[str | None, "Capability | None", "AgentDef | None"]:
        """Resolve a capability + agent pair for a new session."""
        if capability_name:
            capability = self.get(capability_name)
            if capability is None:
                raise ValueError(f"Unknown capability: {capability_name}")

            if agent_name:
                agent_def = next(
                    (agent for agent in capability.agents if agent.name == agent_name), None
                )
                if agent_def is None:
                    raise ValueError(
                        f"Agent '{agent_name}' is not defined in capability '{capability_name}'"
                    )
                return capability_name, capability, agent_def

            agent_def = capability.agents[0] if capability.agents else None
            return capability_name, capability, agent_def

        if agent_name:
            matches = [
                (loaded_capability_name, capability, agent_def)
                for loaded_capability_name, capability in self.capabilities.items()
                for agent_def in capability.agents
                if agent_def.name == agent_name
            ]
            if len(matches) == 1:
                return matches[0]
            if len(matches) > 1:
                matched_capabilities = ", ".join(
                    sorted(capability_name for capability_name, _, _ in matches)
                )
                raise ValueError(
                    f"Agent '{agent_name}' is defined in multiple capabilities: "
                    f"{matched_capabilities}. Choose a capability explicitly."
                )
            logger.warning(
                "Requested agent '{}' was not found in loaded capabilities; "
                "falling back to the default capability",
                agent_name,
            )

        capability = self.default()
        if capability is None:
            return None, None, None
        capability_name = self.default_capability_name
        if capability_name is None and self.capabilities:
            capability_name = next(iter(self.capabilities))
        agent_def = capability.agents[0] if capability.agents else None
        return capability_name, capability, agent_def

    def all_tools(self) -> list[t.Any]:
        """All tools from all capabilities + MCP servers, deduped by name."""
        seen: set[str] = set()
        tools: list[t.Any] = []
        for cap in self.capabilities.values():
            for tool in cap.tools:
                name = _tool_name(tool)
                if name and name not in seen:
                    tools.append(tool)
                    seen.add(name)
                elif name in seen:
                    logger.debug(
                        "Tool '{}' already registered, skipping duplicate",
                        name,
                    )
        if self.mcp_manager:
            for tool in self.mcp_manager.all_tools():
                name = _tool_name(tool)
                if name and name not in seen:
                    tools.append(tool)
                    seen.add(name)
                elif name in seen:
                    logger.debug("Tool '{}' already registered (MCP), skipping", name)
        return tools

    def all_hooks(self) -> list[t.Any]:
        """All hooks contributed by loaded capabilities, in registration order.

        Hooks are session-global middleware — unlike tools, they aren't
        filtered by per-agent rules. A capability that ships a
        ``@hook(GenerationStep)`` participates in every turn as long as
        the capability is loaded.
        """
        hooks: list[t.Any] = []
        for cap in self.capabilities.values():
            cap_hooks = getattr(cap, "hooks", None) or []
            hooks.extend(cap_hooks)
        return hooks

    def register_capability_policies(self) -> list[str]:
        """Register all policy classes contributed by loaded capabilities.

        Walks every capability's ``.policies`` list and inserts each
        class into the global :data:`session_policy._REGISTRY` via
        :func:`register_policy`. Idempotent: re-registering a
        capability's policies is a no-op unless the class object
        itself changed.

        Returns the list of registered policy names for telemetry
        and CLI ``/policies`` listing. Called at end of
        capability-load so policies become available before the
        first session is created.
        """
        from dreadnode.app.server.session_policy import register_policy

        registered: list[str] = []
        for cap in self.capabilities.values():
            cap_policies = getattr(cap, "policies", None) or []
            for policy_cls in cap_policies:
                try:
                    register_policy(policy_cls)
                    name = getattr(policy_cls, "name", None)
                    if isinstance(name, str) and name:
                        registered.append(name)
                except ValueError as exc:
                    logger.warning(
                        "Capability '{}' policy {} rejected: {}",
                        getattr(cap, "name", "?"),
                        getattr(policy_cls, "__name__", repr(policy_cls)),
                        exc,
                    )
        return registered

    def all_skills(self) -> list[t.Any]:
        """Discover skills from all capabilities' skills_paths, deduped by name."""
        if self._skills_cache is not None:
            return self._skills_cache

        from dreadnode.agents.skills import Skill, discover_skills

        skill_map: dict[str, tuple[str, Skill]] = {}
        for cap_name, cap in self.capabilities.items():
            for skills_path in cap.skills_paths or []:
                for skill in discover_skills(skills_path):
                    if skill.name in skill_map:
                        prev_cap_name, _ = skill_map[skill.name]
                        if prev_cap_name != cap_name:
                            logger.warning(
                                "Skill '{}' from '{}' overrides same-named skill from '{}'",
                                skill.name,
                                cap_name,
                                prev_cap_name,
                            )
                            prev_cap = self.capabilities.get(prev_cap_name)
                            if prev_cap is not None:
                                health = getattr(prev_cap, "component_health", None)
                                if health is not None:
                                    detail = f"Overridden by same-named skill from '{cap_name}'"
                                    for entry in health:
                                        if (
                                            isinstance(entry, dict)
                                            and entry.get("kind") == "skill"
                                            and entry.get("name") == skill.name
                                        ):
                                            entry["status"] = "degraded"
                                            entry["detail"] = detail
                                            break
                                    else:
                                        health.append(
                                            {
                                                "kind": "skill",
                                                "name": skill.name,
                                                "status": "degraded",
                                                "error": None,
                                                "detail": detail,
                                            }
                                        )
                    skill_map[skill.name] = (cap_name, skill)

        self._skills_cache = [skill for _, skill in skill_map.values()]
        return self._skills_cache

    def find_agent(self, agent_name: str) -> tuple[str, t.Any, "AgentDef"] | None:
        """Find an agent by name across all capabilities."""
        for cap_name, cap in self.capabilities.items():
            for agent_def in cap.agents:
                if agent_def.name == agent_name:
                    return (cap_name, cap, agent_def)
        return None

    def to_runtime_info(self, *, working_dir: Path) -> RuntimeInfoResponse:
        """Serialize registry state for CLI/runtime introspection."""
        from dreadnode.capabilities.sync import bare_capability_name

        def _provenance_for(
            *, bare_name: str, source: str
        ) -> t.Literal["local", "org", "public"] | None:
            if source == "runtime":
                return None
            record = self.local_capability_records.get(bare_name, {})
            persisted = record.get("source")
            if persisted == "org":
                return "org"
            if persisted == "public":
                return "public"
            return "local"

        def _display_identity(
            *,
            bare_name: str,
            source: str,
            binding: dict[str, t.Any] | None = None,
        ) -> tuple[str, str | None]:
            canonical_name = None
            if binding is not None:
                binding_name = binding.get("capability_name")
                if isinstance(binding_name, str) and binding_name.strip():
                    canonical_name = binding_name
            if canonical_name is not None:
                return canonical_name, canonical_name
            if source in {"local", "package"}:
                record = self.local_capability_records.get(bare_name, {})
                artifact_identity = record.get("artifact_identity")
                if isinstance(artifact_identity, str) and artifact_identity.strip():
                    return bare_name, artifact_identity
                return bare_name, None
            return f"{source}/{bare_name}", None

        def _capability_metadata(
            capability: t.Any,
        ) -> tuple[str | None, dict[str, t.Any] | None, str | None, dict[str, t.Any] | None]:
            contract = getattr(capability, "contract", None)
            description = getattr(capability, "description", None)
            if description is None and contract is not None:
                description = getattr(contract, "description", None)

            author = getattr(capability, "author", None)
            if author is None and contract is not None:
                author = getattr(contract, "author", None)

            license_name = getattr(capability, "license", None)
            if license_name is None and contract is not None:
                license_name = getattr(contract, "license", None)

            origin = getattr(capability, "origin", None)
            if origin is None and contract is not None:
                repository = getattr(contract, "repository", None)
                if isinstance(repository, str) and repository.strip():
                    origin = {"type": "repository", "url": repository}

            return description, author, license_name, origin

        def _local_path(value: t.Any) -> str | None:
            if value is None:
                return None
            raw_path = getattr(value, "path", value)
            if not isinstance(raw_path, (str, Path)):
                return None
            return str(Path(raw_path))

        capabilities_out: list[CapabilityInfo] = []
        binding_by_bare: dict[str, dict[str, t.Any]] = {}
        for binding in self.runtime_bindings:
            bare = bare_capability_name(binding.get("capability_name", ""))
            binding_by_bare[bare] = binding

        for name, capability in self.capabilities.items():
            source = getattr(capability, "source", "local")
            version = getattr(capability, "version", None)
            health = getattr(capability, "component_health", [])
            binding = binding_by_bare.pop(name, None)
            binding_id = binding.get("id") if binding else None
            display_name, canonical_name = _display_identity(
                bare_name=name,
                source=source,
                binding=binding,
            )
            cap_update = self.update_info.get(canonical_name) if canonical_name else None
            description, author, license_name, origin = _capability_metadata(capability)

            capabilities_out.append(
                CapabilityInfo(
                    name=name,
                    display_name=display_name,
                    canonical_name=canonical_name,
                    local_path=_local_path(capability),
                    source=source,
                    provenance=_provenance_for(bare_name=name, source=source),
                    version=version,
                    description=description,
                    author=author,
                    license=license_name,
                    origin=origin,
                    enabled=True,
                    binding_id=binding_id,
                    update_available=cap_update,
                    flags=[
                        FlagInfo(
                            name=f.name,
                            description=f.description,
                            default=f.default,
                            effective=f.effective,
                            source=f.source,
                        )
                        for f in getattr(capability, "resolved_flags", [])
                    ],
                    components=[ComponentStatusInfo(**entry) for entry in health],
                    dependencies=(
                        {
                            "python": _cap_deps.python,
                            "packages": _cap_deps.packages,
                            "scripts": _cap_deps.scripts,
                        }
                        if (
                            (_cap_deps := getattr(capability, "dependencies", None))
                            and (_cap_deps.python or _cap_deps.packages or _cap_deps.scripts)
                        )
                        else None
                    ),
                    checks=(
                        [{"name": c.name, "command": c.command} for c in _cap_checks]
                        if (_cap_checks := getattr(capability, "checks", None))
                        else None
                    ),
                    entry_agent=None,
                    skills_paths=[
                        str(p)
                        for p in (
                            capability.skills_paths
                            or ([] if capability.skills_path is None else [capability.skills_path])
                        )
                    ],
                    agents=[
                        CapabilityAgentInfo(
                            name=a.name,
                            description=a.description,
                            model=a.model,
                            capability=name,
                        )
                        for a in capability.agents
                    ],
                )
            )

        for bare, binding in binding_by_bare.items():
            if not binding.get("enabled", True):
                display_name, canonical_name = _display_identity(
                    bare_name=bare,
                    source="runtime",
                    binding=binding,
                )
                cap_update = self.update_info.get(canonical_name) if canonical_name else None
                capabilities_out.append(
                    CapabilityInfo(
                        name=bare,
                        display_name=display_name,
                        canonical_name=canonical_name,
                        local_path=None,
                        source="runtime",
                        provenance=None,
                        version=binding.get("version"),
                        enabled=False,
                        binding_id=binding.get("id"),
                        update_available=cap_update,
                        components=[],
                    )
                )

        for name, capability in self.disabled_local.items():
            source = getattr(capability, "source", "local")
            version = getattr(capability, "version", None)
            display_name, canonical_name = _display_identity(
                bare_name=name,
                source=source,
                binding=None,
            )
            cap_update = self.update_info.get(canonical_name) if canonical_name else None
            description, author, license_name, origin = _capability_metadata(capability)
            capabilities_out.append(
                CapabilityInfo(
                    name=name,
                    display_name=display_name,
                    canonical_name=canonical_name,
                    local_path=_local_path(capability),
                    source=source,
                    provenance=_provenance_for(bare_name=name, source=source),
                    version=version,
                    description=description,
                    author=author,
                    license=license_name,
                    origin=origin,
                    enabled=False,
                    update_available=cap_update,
                    components=[],
                )
            )

        for failure in self.load_failures:
            name = failure.get("name", "unknown")
            display_name, canonical_name = _display_identity(
                bare_name=name,
                source="local",
                binding=None,
            )
            cap_update = self.update_info.get(canonical_name) if canonical_name else None
            capabilities_out.append(
                CapabilityInfo(
                    name=name,
                    display_name=display_name,
                    canonical_name=canonical_name,
                    local_path=_local_path(failure.get("path")),
                    source="local",
                    provenance=_provenance_for(bare_name=name, source="local"),
                    enabled=True,
                    update_available=cap_update,
                    components=[
                        ComponentStatusInfo(
                            kind="capability",
                            name=name,
                            status="error",
                            error=failure.get("error"),
                            detail="Check capability.yaml format and directory structure",
                        )
                    ],
                )
            )

        runtime_id = os.environ.get("DREADNODE_RUNTIME_ID", "").strip() or None
        host = "sandbox" if runtime_id else "local"
        from dreadnode.version import VERSION

        return RuntimeInfoResponse(
            runtime_id=runtime_id,
            host_type=host,
            version=VERSION,
            working_dir=str(working_dir),
            default_capability=self.default_capability_name,
            capabilities=capabilities_out,
        )


@dataclass
class MCPLifecycleManager:
    """Manages MCP server connections for all capabilities."""

    _clients: dict[str, tuple[t.Any, t.Any]] = field(default_factory=dict)
    _registry: t.Any = field(default=None)

    async def start(self, registry: CapabilityRegistry) -> None:
        """Connect to all MCP servers from all capabilities (CAP-MCP-007: best-effort)."""
        from dreadnode.agents.mcp.client import MCPClient
        from dreadnode.agents.mcp.config import StdioServerConfig
        from dreadnode.capabilities.flags import evaluate_when

        self._registry = registry
        started_at = time.perf_counter()
        connected_count = 0
        failed_count = 0
        gated_count = 0

        async def _start_server(cap: t.Any, server_def: t.Any, flag_env: dict[str, str]) -> None:
            nonlocal connected_count, failed_count

            cap_health = getattr(cap, "component_health", None)
            qualified = f"{cap.name}:{server_def.name}"
            server_started_at = time.perf_counter()
            try:
                config = server_def.to_server_config()
                # CAP-FLAG-020: inject CAPABILITY_FLAG__* env vars into subprocess
                if isinstance(config, StdioServerConfig) and flag_env:
                    config.env = {**(config.env or {}), **flag_env}
                client = MCPClient.from_config(config)
                await client.connect()
                self._clients[qualified] = (server_def, client)
                logger.info("MCP server connected: {}", qualified)
                logger.debug(
                    "MCP start | server={} | status=connected | elapsed_ms={}",
                    qualified,
                    round((time.perf_counter() - server_started_at) * 1000),
                )
                connected_count += 1
                if cap_health is not None:
                    for entry in cap_health:
                        if (
                            entry.get("kind") == "mcp_server"
                            and entry.get("name") == server_def.name
                        ):
                            entry["qualified_name"] = qualified
                            entry["capability"] = cap.name
                            entry["transport"] = server_def.transport
                            entry["tool_count"] = len(client.tools)
                            break
            except Exception as exc:
                logger.opt(exception=True).warning(
                    "MCP server '{}' failed to start — skipping",
                    qualified,
                )
                logger.debug(
                    "MCP start | server={} | status=failed | elapsed_ms={} | error={}",
                    qualified,
                    round((time.perf_counter() - server_started_at) * 1000),
                    exc,
                )
                failed_count += 1
                self._clients[qualified] = (server_def, None)
                # CAP-FLAG-015: distinguish enabled-failed from generic error
                status = "enabled_failed" if server_def.when else "error"
                if cap_health is not None:
                    for entry in cap_health:
                        if (
                            entry.get("kind") == "mcp_server"
                            and entry.get("name") == server_def.name
                        ):
                            entry["status"] = status
                            entry["error"] = str(exc)
                            entry["detail"] = (
                                "Check server command/URL and authentication credentials"
                            )
                            entry["qualified_name"] = qualified
                            entry["capability"] = cap.name
                            entry["transport"] = server_def.transport
                            entry["tool_count"] = 0
                            break

        async with asyncio.TaskGroup() as tg:
            for cap in registry.capabilities.values():
                resolved = cap.resolved_flags
                flag_env = cap.flag_env_vars()
                for server_def in cap.mcp_server_defs:
                    # CAP-FLAG-014: evaluate when: predicate before starting
                    if not evaluate_when(server_def.when, resolved):
                        gated_count += 1
                        qualified = f"{cap.name}:{server_def.name}"
                        logger.debug("MCP server gated off: {}", qualified)
                        self._clients[qualified] = (server_def, None)
                        cap_health = getattr(cap, "component_health", None)
                        if cap_health is not None:
                            for entry in cap_health:
                                if (
                                    entry.get("kind") == "mcp_server"
                                    and entry.get("name") == server_def.name
                                ):
                                    entry["status"] = "gated_off"
                                    entry["qualified_name"] = qualified
                                    entry["capability"] = cap.name
                                    entry["transport"] = server_def.transport
                                    entry["tool_count"] = 0
                                    when_names = ", ".join(server_def.when or [])
                                    entry["detail"] = f"Requires flag: {when_names}"
                                    entry["when"] = list(server_def.when or [])
                                    break
                        continue
                    tg.create_task(_start_server(cap, server_def, flag_env))

        logger.info(
            "MCP start complete | connected={} | failed={} | gated_off={} | total_ms={}",
            connected_count,
            failed_count,
            gated_count,
            round((time.perf_counter() - started_at) * 1000),
        )

    async def stop(self) -> None:
        """Disconnect all MCP servers."""
        started_at = time.perf_counter()
        disconnect_targets = [
            (name, client)
            for name, (_server_def, client) in self._clients.items()
            if client is not None
        ]
        async with asyncio.TaskGroup() as tg:
            for name, client in disconnect_targets:
                tg.create_task(self._disconnect_client(name, client))
        logger.info(
            "MCP stop complete | disconnected={} | total_ms={}",
            len(disconnect_targets),
            round((time.perf_counter() - started_at) * 1000),
        )
        self._clients.clear()

    async def _disconnect_client(self, name: str, client: t.Any) -> None:
        """Disconnect one MCP client without interrupting the rest."""
        started_at = time.perf_counter()
        try:
            await client.disconnect()
            logger.debug(
                "MCP stop | server={} | status=disconnected | elapsed_ms={}",
                name,
                round((time.perf_counter() - started_at) * 1000),
            )
        except Exception:
            logger.opt(exception=True).warning("Error disconnecting MCP server '{}'", name)
            logger.debug(
                "MCP stop | server={} | status=error | elapsed_ms={}",
                name,
                round((time.perf_counter() - started_at) * 1000),
            )

    def all_tools(self) -> list[t.Any]:
        """Collect tools from all connected MCP servers."""
        tools: list[t.Any] = []
        for _server_def, client in self._clients.values():
            if client is not None:
                tools.extend(client.tools)
        return tools

    def get_server_detail(self, capability: str, server_name: str) -> dict[str, t.Any] | None:
        """Return full detail dict for an MCP server, or None if not found."""
        qualified = f"{capability}:{server_name}"
        entry = self._clients.get(qualified)
        if entry is None:
            return None

        server_def, client = entry

        if client is not None:
            status_val = (
                client.status.value if hasattr(client.status, "value") else str(client.status)
            )
            error_val = getattr(client, "_error", None)
            tools = []
            for tool in client.tools:
                tool_info: dict[str, t.Any] = {
                    "name": tool.name,
                    "description": getattr(tool, "description", ""),
                }
                params = getattr(tool, "parameters_schema", None) or getattr(
                    tool, "parameters", None
                )
                if params:
                    tool_info["input_schema"] = params
                tools.append(tool_info)
        else:
            status_val = "disconnected"
            error_val = "Server failed to connect"
            tools = []

        return {
            "name": server_def.name,
            "qualified_name": qualified,
            "capability": capability,
            "status": status_val,
            "error": error_val,
            "transport": server_def.transport,
            "command": server_def.command,
            "args": list(server_def.args),
            "url": server_def.url,
            "tool_count": len(tools),
            "tools": tools,
        }

    async def reconnect_server(self, capability: str, server_name: str) -> dict[str, t.Any] | None:
        """Disconnect and reconnect an MCP server."""
        from dreadnode.agents.mcp.client import MCPClient
        from dreadnode.agents.mcp.config import StdioServerConfig
        from dreadnode.capabilities.flags import evaluate_when

        qualified = f"{capability}:{server_name}"
        entry = self._clients.get(qualified)
        if entry is None:
            return None

        server_def, client = entry

        # CAP-FLAG-014: re-evaluate when: predicate before reconnecting
        if self._registry is not None:
            cap = self._registry.capabilities.get(capability)
            if cap is not None and not evaluate_when(server_def.when, cap.resolved_flags):
                self._update_component_health(capability, server_def.name, "gated_off", None, 0)
                detail = self.get_server_detail(capability, server_name) or {}
                detail["gated_off"] = True
                detail["when"] = list(server_def.when or [])
                return detail

        if client is not None:
            try:
                await client.disconnect()
            except Exception:
                logger.debug(
                    "Error during disconnect of '{}' — proceeding with reconnect", qualified
                )

        new_client: t.Any = None
        try:
            config = server_def.to_server_config()
            # CAP-FLAG-020: inject flag env vars on reconnect too
            if self._registry is not None and isinstance(config, StdioServerConfig):
                cap = self._registry.capabilities.get(capability)
                if cap is not None:
                    flag_env = cap.flag_env_vars()
                    if flag_env:
                        config.env = {**(config.env or {}), **flag_env}
            new_client = MCPClient.from_config(config)
            await new_client.connect()
            self._clients[qualified] = (server_def, new_client)
            self._update_component_health(
                capability, server_def.name, "ok", None, len(new_client.tools)
            )
        except Exception as exc:
            logger.warning("Reconnect failed for '{}': {}", qualified, exc)
            self._clients[qualified] = (server_def, None)
            self._update_component_health(capability, server_def.name, "error", str(exc), 0)

        return self.get_server_detail(capability, server_name)

    def _update_component_health(
        self, capability: str, server_name: str, status: str, error: str | None, tool_count: int
    ) -> None:
        """Update the component_health entry for an MCP server in the registry."""
        if self._registry is None:
            return
        cap = self._registry.capabilities.get(capability)
        if cap is None:
            return
        for entry in getattr(cap, "component_health", []):
            if entry.get("kind") == "mcp_server" and entry.get("name") == server_name:
                entry["status"] = status
                entry["error"] = error
                entry["tool_count"] = tool_count
                break
