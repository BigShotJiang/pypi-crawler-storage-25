"""Per-session behavioral policy — how a session answers human prompts and
continuation decisions.

The substrate (``SessionRuntime``, ``SessionTurnCoordinator``,
``EventBus``) is frontend-agnostic: it streams events and runs
turns without caring whether a human is at a terminal, a supervisor is
watching multiple sessions, or a script is orchestrating agents
programmatically. The policy is where mode-specific behavior lives:

- ``handle_human_prompt`` — when a tool invokes ``ask_user()``, what
  answers? (Interactive: the human at the terminal. Headless: auto-deny.
  Delegated: another agent.)
- ``extra_hooks`` — session-level continuation hooks layered on top of
  whatever the loaded capabilities contribute. Interactive policies
  return ``[]``; headless/supervised policies return budget or
  max-step hooks that emit ``Finish`` reactions.

Two shipped implementations:

- :class:`InteractiveSessionPolicy` — today's TUI behavior. Registers
  the prompt, publishes to both the per-turn stream and the session
  broker, awaits the client's response.
- :class:`HeadlessSessionPolicy` — autonomous mode. Auto-denies
  ``ask_user()`` (no transport publishes, the tool resolves
  instantly). Attaches a step-counter hook that ends the turn past a
  configurable cap.

Policies are resolved by name from :data:`POLICY_REGISTRY` via
:func:`resolve_policy` so clients can request a mode via a simple
string or ``{"name": ..., ...params}`` dict without importing Python
classes across process boundaries.
"""

import typing as t
from dataclasses import dataclass

from loguru import logger

from dreadnode.agents.events import AgentStep
from dreadnode.agents.reactions import Finish
from dreadnode.core.hook import Hook

if t.TYPE_CHECKING:
    import asyncio

    from dreadnode.app.api.models import HumanInputResponse, HumanPrompt

EventPayload = dict[str, t.Any]

RegisterHumanPrompt = t.Callable[["HumanPrompt"], "asyncio.Future[HumanInputResponse]"]
EmitTurnEvent = t.Callable[[EventPayload], t.Awaitable[None]]
PublishBrokerRawEvent = t.Callable[[str, EventPayload], t.Awaitable[None]]


@dataclass(frozen=True, slots=True)
class HumanPromptContext:
    """Per-turn plumbing handed to ``SessionPolicy.handle_human_prompt``.

    A policy may need to register the prompt (so a client response can
    later resolve it), publish the ``userinputrequired`` event to the
    per-turn SSE stream, and/or publish it to the session broker. The
    runtime provides these as callables so the policy stays decoupled
    from ``SessionRuntime`` internals.
    """

    turn_id: str
    register: RegisterHumanPrompt
    emit_turn_event: EmitTurnEvent
    publish_broker_raw_event: PublishBrokerRawEvent


class PolicyValidationError(ValueError):
    """Raised when a policy's ``validate()`` method returns non-empty issues.

    Distinct subclass of ``ValueError`` so FastAPI handlers can map
    validation failures to HTTP 400 without conflating with other
    ``ValueError``-raising paths (session_id collisions → 409,
    unknown capability → 409, etc.). The ``issues`` attribute holds
    the list of human-readable strings the policy returned, in case
    a caller wants to render them individually instead of the joined
    message.
    """

    def __init__(self, policy_name: str, issues: list[str]) -> None:
        self.policy_name = policy_name
        self.issues = list(issues)
        joined = "; ".join(issues)
        super().__init__(f"policy {policy_name!r} failed validation: {joined}")


@t.runtime_checkable
class SessionPolicy(t.Protocol):
    """How a session responds to human prompts and continuation signals.

    Implementations expose three class-level metadata fields that
    frontends read to render status UI without hardcoding policy
    names:

    - ``name`` — registry key (``"interactive"``, ``"headless"``, …).
      Required. Must be unique across registered policies.
    - ``is_autonomous`` — whether the session is running without
      meaningful human input. The TUI uses this to tag session labels
      and gate the "background task" summary notifications.
    - ``display_label`` — short string shown in status bars when
      ``is_autonomous`` is true (``"auto"``, ``"strict"``, …).
      Defaults to ``name`` if omitted.
    """

    name: t.ClassVar[str]
    is_autonomous: t.ClassVar[bool]
    display_label: t.ClassVar[str]

    async def handle_human_prompt(
        self,
        prompt: "HumanPrompt",
        *,
        ctx: HumanPromptContext,
    ) -> "HumanInputResponse":
        """Called when an agent tool invokes ``ask_user()``."""
        ...

    def extra_hooks(self) -> list[Hook]:
        """Hooks appended to the agent at turn start.

        Composed on top of hooks contributed by loaded capabilities —
        policy hooks own *session control* (budget, termination,
        user-interrupt polling), capability hooks own domain logic
        (scorers, validators).
        """
        ...

    def validate(
        self,
        *,
        available_tools: list[str],
        available_hooks: list[Hook],
    ) -> list[str]:
        """Return a list of issue strings describing missing dependencies.

        Called at session create (``POST /api/sessions``) and at every
        mid-session policy swap (``POST /api/sessions/{id}/policy``).
        Policies use this to enforce their dependencies: required
        tools from a companion capability, required hooks, denied
        tool names that must not be present.

        Empty list means the policy is ready to run in this context.
        A non-empty list raises ``PolicyValidationError`` at the
        enforcement site, which maps to HTTP 400 at the API layer.

        Runtime introspection: ``CapabilityRegistry`` is process-global,
        so ``available_tools`` and ``available_hooks`` reflect the
        whole registry at activation time, not a per-session subset.
        A session bound to a specific capability still sees every
        loaded capability's tools here — the ``capability`` arg to
        ``create_session`` is a selector, not a scope filter.

        Implementations that have no dependencies should return
        ``[]``. The two shipped built-ins do so — only capability-
        shipped or specialization policies need a non-trivial
        implementation.
        """
        ...


class InteractiveSessionPolicy:
    """Default policy matching today's TUI behavior exactly.

    Human prompts are registered with the session's prompt registry and
    published to both transports: the per-turn stream (for ``stream_chat``
    consumers) and the session broker (for ``/api/ws`` subscribers). The
    future returned by ``register`` is awaited until a client sends a
    ``human_input_response``.

    Missing either publish path would hang clients on that transport —
    see the regression fixed in ``test_server_human_input.py``.
    """

    name: t.ClassVar[str] = "interactive"
    is_autonomous: t.ClassVar[bool] = False
    display_label: t.ClassVar[str] = ""

    async def handle_human_prompt(
        self,
        prompt: "HumanPrompt",
        *,
        ctx: HumanPromptContext,
    ) -> "HumanInputResponse":
        future = ctx.register(prompt)
        event: EventPayload = {
            "type": "userinputrequired",
            "data": prompt.model_dump(),
        }
        await ctx.emit_turn_event(event)
        await ctx.publish_broker_raw_event(ctx.turn_id, event)
        return await future

    def extra_hooks(self) -> list[Hook]:
        return []

    def validate(
        self,
        *,
        available_tools: list[str],
        available_hooks: list[Hook],
    ) -> list[str]:
        del available_tools, available_hooks
        return []


def _make_max_steps_hook(max_steps: int) -> Hook:
    """Create a ``@hook(AgentStep)`` that finishes the turn past ``max_steps``.

    Step counting lives in the hook's closure: ``AgentStep`` events
    fire at every react-cycle boundary, so by the time we've seen
    ``max_steps`` of them the agent has gone through ``max_steps``
    LLM → tool → LLM iterations. Returning ``Finish`` short-circuits
    the remainder of the turn and surfaces a ``reason`` that the TUI
    can display in its status badge.
    """
    count = 0

    async def _stop_on_max_steps(_event: AgentStep) -> Finish | None:
        nonlocal count
        count += 1
        if count >= max_steps:
            return Finish(reason=f"max_steps={max_steps} reached")
        return None

    return Hook(_stop_on_max_steps, AgentStep)


class HeadlessSessionPolicy:
    """Autonomous mode policy — no human available, bounded execution.

    ``handle_human_prompt`` returns an immediate ``deny`` response
    without touching any transport. The tool site's ``ask_user()``
    resolves instantly and the agent handles the deny like any other
    user refusal — typically by emitting its best guess or aborting
    the current subtask.

    ``extra_hooks`` returns a step-counter hook that emits
    ``Finish(reason="max_steps=N reached")`` once the turn has run
    ``max_steps`` react cycles. This is the continuation-policy
    escape hatch for runaway agents — no matter what the agent
    thinks it's doing, it stops when the hook fires.
    """

    name: t.ClassVar[str] = "headless"
    is_autonomous: t.ClassVar[bool] = True
    display_label: t.ClassVar[str] = "auto"

    def __init__(self, *, max_steps: int = 30) -> None:
        if max_steps <= 0:
            raise ValueError(f"max_steps must be positive, got {max_steps}")
        self.max_steps = max_steps

    async def handle_human_prompt(
        self,
        prompt: "HumanPrompt",
        *,
        ctx: HumanPromptContext,  # noqa: ARG002 — part of the protocol, unused here
    ) -> "HumanInputResponse":
        from dreadnode.app.api.models import HumanInputResponse

        return HumanInputResponse(
            request_id=prompt.request_id,
            action="deny",
            text="autonomous mode: no human available",
        )

    def extra_hooks(self) -> list[Hook]:
        return [_make_max_steps_hook(self.max_steps)]

    def validate(
        self,
        *,
        available_tools: list[str],
        available_hooks: list[Hook],
    ) -> list[str]:
        del available_tools, available_hooks
        return []


_PolicySpec = str | dict[str, t.Any] | None

_REGISTRY: dict[str, type[SessionPolicy]] = {
    "interactive": InteractiveSessionPolicy,
    "headless": HeadlessSessionPolicy,
}


def register_policy(
    cls: type[SessionPolicy],
    *,
    name: str | None = None,
    replace: bool = False,
) -> type[SessionPolicy]:
    """Register a policy class into the global registry.

    The registry key defaults to ``cls.name``; pass ``name`` to
    override. Re-registering an existing name is a no-op unless
    ``replace=True`` — capability authors loading a policy twice
    shouldn't get a confusing error, but intentional overrides
    should be explicit.

    Returns the class unchanged so this function can be used as a
    decorator:

    .. code-block:: python

        @register_policy
        class StrictPolicy:
            name = "strict"
            is_autonomous = True
            display_label = "strict"
            ...

    Capabilities ship policies by placing files under ``policies/``
    with top-level classes decorated like above — the capability
    loader picks them up and routes them through this function.
    """
    key = name or getattr(cls, "name", None)
    if not key:
        raise ValueError(f"policy {cls.__name__} must define ``name`` class attribute")
    existing = _REGISTRY.get(key)
    if existing is not None and existing is not cls and not replace:
        logger.debug("Policy {} already registered, skipping re-register", key)
        return cls
    _REGISTRY[key] = cls
    return cls


def registered_policy_names() -> list[str]:
    """Return sorted list of policy names currently in the registry."""
    return sorted(_REGISTRY)


def get_policy_class(name: str) -> type[SessionPolicy] | None:
    """Look up a registered policy class by name."""
    return _REGISTRY.get(name)


def validate_policy_or_raise(
    policy: SessionPolicy,
    *,
    available_tools: list[str],
    available_hooks: list[Hook],
) -> None:
    """Run ``policy.validate()`` and raise ``PolicyValidationError`` on issues.

    Shared helper for the two API call sites
    (``POST /api/sessions`` and ``POST /api/sessions/{id}/policy``)
    so the resolve → validate → use pattern stays consistent. A
    policy returning a non-empty issue list is turned into a
    ``PolicyValidationError`` carrying the policy name and the
    issues; FastAPI handlers map the exception to HTTP 400.

    Intentionally a module-level function, not a method on
    ``SessionPolicy``, because the issue-to-exception conversion
    is an *enforcement* concern — policies own the "are we
    valid?" question, the runtime owns the "what do we do about
    invalid?" question.
    """
    issues = policy.validate(
        available_tools=available_tools,
        available_hooks=available_hooks,
    )
    if issues:
        raise PolicyValidationError(
            getattr(policy, "name", "unknown"),
            issues,
        )


def collect_registry_view(
    registry: t.Any,
) -> tuple[list[str], list[Hook]]:
    """Collect the process-global tool/hook view for policy validation.

    Returns ``(available_tools, available_hooks)`` where
    ``available_tools`` is the list of tool names from
    ``registry.all_tools()`` (empty names filtered), and
    ``available_hooks`` is the list of capability-contributed hooks
    from ``registry.all_hooks()``. Both lists are empty when the
    registry is ``None`` (test contexts that don't load any
    capabilities).

    Captures the introspection pattern the call sites share so
    future validate() callers can reuse it without hand-rolling
    the tool-name extraction.
    """
    if registry is None:
        return [], []
    tools: list[str] = []
    for tool in registry.all_tools():
        name = getattr(tool, "name", "")
        if name:
            tools.append(name)
    hooks = list(registry.all_hooks())
    return tools, hooks


def resolve_policy(spec: _PolicySpec) -> SessionPolicy:
    """Resolve a policy spec from the API into a policy instance.

    ``spec`` may be:
      - ``None`` or the string ``"interactive"`` → default interactive policy
      - a string matching a registered name → policy with default params
      - a dict ``{"name": ..., **params}`` → policy with keyword params

    Unknown names raise ``ValueError`` so mis-typed policy names in a
    request payload fail loudly at session-create time instead of
    silently falling back to interactive.
    """
    if spec is None:
        return InteractiveSessionPolicy()
    if isinstance(spec, str):
        name, params = spec, {}
    else:
        name = spec.get("name", "interactive")
        params = {k: v for k, v in spec.items() if k != "name"}
    cls = _REGISTRY.get(name)
    if cls is None:
        available = ", ".join(sorted(_REGISTRY))
        raise ValueError(f"unknown session policy {name!r}; known: {available}")
    return cls(**params)
