"""Runtime env var resolution with deprecation warnings for legacy names.

Centralizes reads of the ``DREADNODE_RUNTIME_*`` family so legacy aliases (which
collided with the platform ``DREADNODE_SERVER`` var or lived under the narrow
``SANDBOX_`` prefix) can be honored during the deprecation window without
duplicating warning bookkeeping at every call site.
"""

import os
import threading
import typing as t
import warnings

from loguru import logger

__all__ = [
    "read_env_with_deprecation",
]

_ALREADY_WARNED: set[str] = set()
# Guard the check-then-add on ``_ALREADY_WARNED`` so concurrent threads
# racing on startup (SDK + TUI + worker manager) still produce exactly one
# warning per legacy name.
_WARN_LOCK = threading.Lock()


@t.overload
def read_env_with_deprecation(canonical: str, legacy: str) -> str | None: ...


@t.overload
def read_env_with_deprecation(canonical: str, legacy: str, default: str) -> str: ...


def read_env_with_deprecation(
    canonical: str,
    legacy: str,
    default: str | None = None,
) -> str | None:
    """Return the value of ``canonical`` if set, else ``legacy`` (warning once), else ``default``.

    The ``DeprecationWarning`` fires at most once per legacy name per process,
    so repeated reads during startup don't flood logs. The mirrored
    ``logger.warning`` ensures the message is visible even when warnings are
    filtered out of the user's environment.
    """
    canonical_value = os.environ.get(canonical)
    if canonical_value is not None:
        return canonical_value

    legacy_value = os.environ.get(legacy)
    if legacy_value is not None:
        with _WARN_LOCK:
            should_warn = legacy not in _ALREADY_WARNED
            if should_warn:
                _ALREADY_WARNED.add(legacy)
        if should_warn:
            msg = (
                f"{legacy} is deprecated and will be removed in a future release. "
                f"Use {canonical} instead."
            )
            warnings.warn(msg, DeprecationWarning, stacklevel=2)
            logger.warning(msg)
        return legacy_value

    return default
