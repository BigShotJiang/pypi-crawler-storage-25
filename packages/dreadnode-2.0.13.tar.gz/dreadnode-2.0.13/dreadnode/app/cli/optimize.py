"""Optimize subcommands for the cyclopts CLI."""

import json
import typing as t

import cyclopts

from dreadnode.app.cli.args import PlatformScopeArgs
from dreadnode.app.cli.shared import (
    ArtifactRef,
    _render,
    _render_artifacts,
    _render_list,
    _render_logs,
    _status_color,
    _wait_for_job,
)
from dreadnode.app.model_catalog import resolve_model

RewardRecipeChoice = t.Literal[
    "contains_v1",
    "exact_match_v1",
    "row_reward_v1",
    "trajectory_imitation_v1",
]

OptimizationStatus = t.Literal[
    "queued",
    "running",
    "completed",
    "failed",
    "cancelled",
]

OptimizationBackend = t.Literal["gepa"]

TargetKind = t.Literal["capability_agent"]

cli = cyclopts.App(name="optimize", help="Optimize agents with jobs.")


# ---------------------------------------------------------------------------
# Local helpers
# ---------------------------------------------------------------------------


def _summarize_optimization_job(p: dict[str, t.Any]) -> str:
    job_id = p.get("id", "unknown")
    status = p.get("status", "unknown")
    name = p.get("name") or f"{p.get('backend')}/{p.get('target_kind')}"
    color = _status_color(status)
    return f"[dim]{job_id}[/dim] [{color}]{status}[/{color}] [cyan]{name}[/cyan]"


def _wait_for_optimization_job(
    client: t.Any,
    *,
    org: str,
    workspace: str,
    job_id: str,
    poll_interval_sec: float,
    timeout_sec: float | None,
) -> t.Any:
    return _wait_for_job(
        lambda: client.get_optimization_job(org, workspace, job_id),
        job_id=job_id,
        label="optimization",
        poll_interval_sec=poll_interval_sec,
        timeout_sec=timeout_sec,
    )


# ---------------------------------------------------------------------------
# submit (default command — runs when `dn optimize` has no subcommand)
# ---------------------------------------------------------------------------


@cli.command(name="submit")
def submit(
    *,
    model: t.Annotated[str, cyclopts.Parameter(help="Model identifier")],
    capability: t.Annotated[
        str,
        cyclopts.Parameter(help="Capability ref in NAME@VERSION form"),
    ],
    dataset: t.Annotated[
        str,
        cyclopts.Parameter(help="Training dataset ref in NAME@VERSION form"),
    ],
    reward_recipe: t.Annotated[
        RewardRecipeChoice,
        cyclopts.Parameter(
            help="Hosted reward recipe name",
        ),
    ],
    val_dataset: t.Annotated[
        str | None,
        cyclopts.Parameter(
            help="Optional validation dataset ref in NAME@VERSION form",
        ),
    ] = None,
    reward_params: t.Annotated[
        str | None, cyclopts.Parameter(help="Reward recipe parameters as JSON")
    ] = None,
    agent_name: t.Annotated[
        str | None,
        cyclopts.Parameter(
            help="Optional agent name when the capability exports multiple agents",
        ),
    ] = None,
    objective: t.Annotated[
        str | None,
        cyclopts.Parameter(help="Optional natural-language optimization objective"),
    ] = None,
    name: t.Annotated[
        str | None,
        cyclopts.Parameter(help="Optional optimization job name"),
    ] = None,
    run_ref: t.Annotated[str | None, cyclopts.Parameter(help="Run reference for tracking")] = None,
    tag: t.Annotated[
        list[str] | None,
        cyclopts.Parameter(negative_iterable=(), help="Tag for the job (repeatable)"),
    ] = None,
    seed: t.Annotated[
        int | None, cyclopts.Parameter(help="Random seed for reproducibility")
    ] = None,
    max_metric_calls: t.Annotated[
        int | None, cyclopts.Parameter(help="Maximum metric evaluation calls")
    ] = None,
    max_trials: t.Annotated[
        int | None, cyclopts.Parameter(help="Maximum optimization trials before stopping")
    ] = None,
    max_trials_without_improvement: t.Annotated[
        int | None,
        cyclopts.Parameter(
            help="Stop after this many finished trials without improving the best score"
        ),
    ] = None,
    max_runtime_sec: t.Annotated[
        int | None,
        cyclopts.Parameter(help="Maximum hosted runtime seconds before the job is timed out"),
    ] = None,
    reflection_lm: t.Annotated[
        str | None, cyclopts.Parameter(help="Language model for reflection steps")
    ] = None,
    max_reflection_examples: t.Annotated[
        int | None, cyclopts.Parameter(help="Maximum examples for reflection")
    ] = None,
    max_side_info_chars: t.Annotated[
        int | None, cyclopts.Parameter(help="Maximum characters of side information")
    ] = None,
    track_best_outputs: t.Annotated[
        bool,
        cyclopts.Parameter(negative=()),
    ] = False,
    display_progress_bar: t.Annotated[
        bool,
        cyclopts.Parameter(negative=()),
    ] = False,
    capture_traces: t.Annotated[
        bool,
        cyclopts.Parameter(negative="--no-capture-traces"),
    ] = True,
    include_outputs: t.Annotated[
        bool,
        cyclopts.Parameter(negative="--no-include-outputs"),
    ] = True,
    include_errors: t.Annotated[
        bool,
        cyclopts.Parameter(negative="--no-include-errors"),
    ] = True,
    wait: t.Annotated[bool, cyclopts.Parameter(negative=())] = False,
    poll_interval_sec: t.Annotated[
        float,
        cyclopts.Parameter(
            validator=cyclopts.validators.Number(gt=0), help="Polling interval in seconds"
        ),
    ] = 5.0,
    timeout_sec: t.Annotated[
        float | None, cyclopts.Parameter(help="Timeout in seconds for waiting")
    ] = None,
    as_json: t.Annotated[bool, cyclopts.Parameter(name="--json", negative=())] = False,
    platform: PlatformScopeArgs = PlatformScopeArgs(),
) -> None:
    """Submit a hosted optimization job."""
    from dreadnode.app.api.models import (
        CapabilityRef,
        CreateGEPAOptimizationJobRequest,
        DatasetRef,
        OptimizationJobConfig,
        RewardRecipe,
    )

    api, profile = platform.connect()

    capability_ref = ArtifactRef.parse_versioned(capability, profile.org_key)
    dataset_ref = ArtifactRef.parse_versioned(dataset, profile.org_key)

    val_dataset_ref: DatasetRef | None = None
    if val_dataset:
        val_ref = ArtifactRef.parse_versioned(val_dataset, profile.org_key)
        val_dataset_ref = DatasetRef(name=val_ref.name, version=val_ref.version)

    parsed_reward_params: dict[str, t.Any] = {}
    if reward_params:
        try:
            raw_params = json.loads(reward_params)
        except json.JSONDecodeError as exc:
            raise ValueError("--reward-params must be valid JSON") from exc
        if not isinstance(raw_params, dict):
            raise ValueError("--reward-params must decode to a JSON object")
        parsed_reward_params = raw_params

    config_kwargs: dict[str, t.Any] = {
        "capture_traces": capture_traces,
        "include_outputs": include_outputs,
        "include_errors": include_errors,
    }
    if seed is not None:
        config_kwargs["seed"] = seed
    if max_metric_calls is not None:
        config_kwargs["max_metric_calls"] = max_metric_calls
    if max_trials is not None:
        config_kwargs["max_trials"] = max_trials
    if max_trials_without_improvement is not None:
        config_kwargs["max_trials_without_improvement"] = max_trials_without_improvement
    if max_runtime_sec is not None:
        config_kwargs["max_runtime_sec"] = max_runtime_sec
    if reflection_lm is not None:
        config_kwargs["reflection_lm"] = reflection_lm
    if max_reflection_examples is not None:
        config_kwargs["max_reflection_examples"] = max_reflection_examples
    if max_side_info_chars is not None:
        config_kwargs["max_side_info_chars"] = max_side_info_chars
    if track_best_outputs:
        config_kwargs["track_best_outputs"] = True
    if display_progress_bar:
        config_kwargs["display_progress_bar"] = True

    request = CreateGEPAOptimizationJobRequest(
        name=name,
        model=resolve_model(model),
        project=profile.project_key,
        run_ref=run_ref,
        capability_ref=CapabilityRef(
            name=capability_ref.name,
            version=capability_ref.version,
        ),
        agent_name=agent_name,
        dataset_ref=DatasetRef(name=dataset_ref.name, version=dataset_ref.version),
        val_dataset_ref=val_dataset_ref,
        reward_recipe=RewardRecipe(
            name=reward_recipe,
            params=parsed_reward_params,
        ),
        components=["instructions"],
        objective=objective,
        config=OptimizationJobConfig(**config_kwargs),
        tags=list(tag or []),
    )
    job = api.create_optimization_job(profile.org_key, profile.workspace_key, request)
    if wait:
        job = _wait_for_optimization_job(
            api,
            org=profile.org_key,
            workspace=profile.workspace_key,
            job_id=job.id,
            poll_interval_sec=poll_interval_sec,
            timeout_sec=timeout_sec,
        )
    _render(job, as_json=as_json, summary=_summarize_optimization_job)
    if wait and job.status != "completed":
        raise RuntimeError(job.error or f"Optimization job {job.id} ended with status {job.status}")


# ---------------------------------------------------------------------------
# list
# ---------------------------------------------------------------------------


@cli.command(name="list")
def list_(
    *,
    page: t.Annotated[int, cyclopts.Parameter(validator=cyclopts.validators.Number(gte=1))] = 1,
    page_size: t.Annotated[
        int,
        cyclopts.Parameter(validator=cyclopts.validators.Number(gte=1)),
    ] = 20,
    status: OptimizationStatus | None = None,
    backend: OptimizationBackend | None = None,
    target_kind: TargetKind | None = None,
    as_json: t.Annotated[bool, cyclopts.Parameter(name="--json", negative=())] = False,
    platform: PlatformScopeArgs = PlatformScopeArgs(),
) -> None:
    """List hosted optimization jobs."""
    api, profile = platform.connect()
    jobs = api.list_optimization_jobs(
        profile.org_key,
        profile.workspace_key,
        page=page,
        page_size=page_size,
        status=status,
        backend=backend,
        target_kind=target_kind,
        project=profile.project_key,
    )
    _render_list(
        jobs,
        as_json=as_json,
        summary=_summarize_optimization_job,
        empty_msg="No optimization jobs found",
    )


# ---------------------------------------------------------------------------
# get
# ---------------------------------------------------------------------------


@cli.command()
def get(
    job_id: str,
    *,
    as_json: t.Annotated[bool, cyclopts.Parameter(name="--json", negative=())] = False,
    platform: PlatformScopeArgs = PlatformScopeArgs(),
) -> None:
    """Get a hosted optimization job."""
    api, profile = platform.connect()
    job = api.get_optimization_job(profile.org_key, profile.workspace_key, job_id)
    _render(job, as_json=as_json, summary=_summarize_optimization_job)


# ---------------------------------------------------------------------------
# wait
# ---------------------------------------------------------------------------


@cli.command()
def wait(
    job_id: str,
    *,
    poll_interval_sec: t.Annotated[
        float,
        cyclopts.Parameter(
            validator=cyclopts.validators.Number(gt=0), help="Polling interval in seconds"
        ),
    ] = 5.0,
    timeout_sec: t.Annotated[
        float | None, cyclopts.Parameter(help="Timeout in seconds for waiting")
    ] = None,
    as_json: t.Annotated[bool, cyclopts.Parameter(name="--json", negative=())] = False,
    platform: PlatformScopeArgs = PlatformScopeArgs(),
) -> None:
    """Wait for a hosted optimization job to reach a terminal state."""
    api, profile = platform.connect()
    job = _wait_for_optimization_job(
        api,
        org=profile.org_key,
        workspace=profile.workspace_key,
        job_id=job_id,
        poll_interval_sec=poll_interval_sec,
        timeout_sec=timeout_sec,
    )
    _render(job, as_json=as_json, summary=_summarize_optimization_job)
    if job.status != "completed":
        raise RuntimeError(job.error or f"Optimization job {job.id} ended with status {job.status}")


# ---------------------------------------------------------------------------
# logs
# ---------------------------------------------------------------------------


@cli.command()
def logs(
    job_id: str,
    *,
    as_json: t.Annotated[bool, cyclopts.Parameter(name="--json", negative=())] = False,
    platform: PlatformScopeArgs = PlatformScopeArgs(),
) -> None:
    """Show hosted optimization logs."""
    api, profile = platform.connect()
    log_data = api.list_optimization_job_logs(profile.org_key, profile.workspace_key, job_id)
    _render_logs(log_data, as_json=as_json)


# ---------------------------------------------------------------------------
# artifacts
# ---------------------------------------------------------------------------


@cli.command()
def artifacts(
    job_id: str,
    *,
    as_json: t.Annotated[bool, cyclopts.Parameter(name="--json", negative=())] = False,
    platform: PlatformScopeArgs = PlatformScopeArgs(),
) -> None:
    """Show hosted optimization artifacts."""
    api, profile = platform.connect()
    artifact_data = api.get_optimization_job_artifacts(
        profile.org_key, profile.workspace_key, job_id
    )
    _render_artifacts(artifact_data, as_json=as_json)


# ---------------------------------------------------------------------------
# cancel
# ---------------------------------------------------------------------------


@cli.command()
def cancel(
    job_id: str,
    *,
    as_json: t.Annotated[bool, cyclopts.Parameter(name="--json", negative=())] = False,
    platform: PlatformScopeArgs = PlatformScopeArgs(),
) -> None:
    """Cancel a hosted optimization job."""
    api, profile = platform.connect()
    job = api.cancel_optimization_job(profile.org_key, profile.workspace_key, job_id)
    _render(job, as_json=as_json, summary=_summarize_optimization_job)


# ---------------------------------------------------------------------------
# retry
# ---------------------------------------------------------------------------


@cli.command()
def retry(
    job_id: str,
    *,
    as_json: t.Annotated[bool, cyclopts.Parameter(name="--json", negative=())] = False,
    platform: PlatformScopeArgs = PlatformScopeArgs(),
) -> None:
    """Retry a terminal hosted optimization job."""
    api, profile = platform.connect()
    job = api.retry_optimization_job(profile.org_key, profile.workspace_key, job_id)
    _render(job, as_json=as_json, summary=_summarize_optimization_job)
