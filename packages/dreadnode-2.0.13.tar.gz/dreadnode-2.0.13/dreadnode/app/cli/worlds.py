"""Worlds subcommands for the cyclopts CLI."""

import typing as t

import cyclopts

from dreadnode.app.cli.args import PlatformScopeArgs
from dreadnode.app.cli.shared import (
    _print_json,
    _render,
    _render_list,
    _status_color,
    _wait_for_job,
)
from dreadnode.app.model_catalog import resolve_model

cli = cyclopts.App(name="worlds", help="Work with simulated network environments.")


# ---------------------------------------------------------------------------
# Local helpers
# ---------------------------------------------------------------------------


def _summarize_job(p: dict[str, t.Any]) -> str:
    job_id = p.get("id", "unknown")
    status = p.get("status", "unknown")
    kind = p.get("kind", "unknown")
    resource_type = p.get("resource_type") or "resource"
    color = _status_color(status)
    return f"[dim]{job_id}[/dim] [{color}]{status}[/{color}] [cyan]{kind}[/cyan] [dim]{resource_type}[/dim]"


def _summarize_manifest(p: dict[str, t.Any]) -> str:
    manifest_id = p.get("id", "unknown")
    preset = p.get("preset") or "custom"
    name = p.get("name") or "unnamed-manifest"
    return f"[dim]{manifest_id}[/dim] [magenta]{preset}[/magenta] [cyan]{name}[/cyan]"


def _summarize_trajectory(p: dict[str, t.Any]) -> str:
    traj_id = p.get("id", "unknown")
    success = p.get("success")
    success_text = "success" if success else "pending" if success is None else "failed"
    goal = p.get("goal", "unknown")
    color = _status_color(success_text)
    return f"[dim]{traj_id}[/dim] [{color}]{success_text}[/{color}] [cyan]{goal}[/cyan]"


ManifestPreset = t.Literal["small", "medium", "large", "enterprise"]
TrajectoryStrategy = t.Literal["random", "greedy", "recon-first", "smart-random"]
TrajectoryMode = t.Literal["kali", "c2", "agent"]
JobKind = t.Literal["manifest_generation", "trajectory_generation"]
JobStatus = t.Literal["queued", "running", "completed", "failed", "cancelled"]


# ---------------------------------------------------------------------------
# manifest-create
# ---------------------------------------------------------------------------


@cli.command(name="manifest-create")
def manifest_create(
    *,
    name: t.Annotated[str | None, cyclopts.Parameter(help="Manifest name")] = None,
    project_id: t.Annotated[str | None, cyclopts.Parameter(help="Project ID to associate")] = None,
    preset: ManifestPreset | None = None,
    seed: t.Annotated[
        int | None, cyclopts.Parameter(help="Random seed for reproducibility")
    ] = None,
    num_users: t.Annotated[
        int | None, cyclopts.Parameter(help="Number of users to generate")
    ] = None,
    num_hosts: t.Annotated[
        int | None, cyclopts.Parameter(help="Number of hosts to generate")
    ] = None,
    domain: t.Annotated[
        list[str] | None, cyclopts.Parameter(negative_iterable=(), help="Domain name (repeatable)")
    ] = None,
    as_json: t.Annotated[bool, cyclopts.Parameter(name="--json", negative=())] = False,
    platform: PlatformScopeArgs = PlatformScopeArgs(),
) -> None:
    """Create a new world manifest."""
    api, profile = platform.connect()
    payload = api.create_world_manifest(
        profile.org_key,
        profile.workspace_key,
        name=name,
        project_id=project_id,
        preset=preset,
        seed=seed,
        num_users=num_users,
        num_hosts=num_hosts,
        domains=list(domain or []) or None,
    )
    _render(payload, as_json=as_json, summary=_summarize_job)


# ---------------------------------------------------------------------------
# manifest-list
# ---------------------------------------------------------------------------


@cli.command(name="manifest-list")
def manifest_list(
    *,
    project_id: t.Annotated[str | None, cyclopts.Parameter(help="Project ID filter")] = None,
    created_by: t.Annotated[str | None, cyclopts.Parameter(help="Filter by creator")] = None,
    page: int = 1,
    page_size: t.Annotated[
        int, cyclopts.Parameter(validator=cyclopts.validators.Number(gte=1))
    ] = 20,
    as_json: t.Annotated[bool, cyclopts.Parameter(name="--json", negative=())] = False,
    platform: PlatformScopeArgs = PlatformScopeArgs(),
) -> None:
    """List world manifests."""
    api, profile = platform.connect()
    payload = api.list_world_manifests(
        profile.org_key,
        profile.workspace_key,
        project_id=project_id,
        created_by=created_by,
        page=page,
        page_size=page_size,
    )
    _render_list(
        payload, as_json=as_json, summary=_summarize_manifest, empty_msg="No manifests found"
    )


# ---------------------------------------------------------------------------
# manifest-get
# ---------------------------------------------------------------------------


@cli.command(name="manifest-get")
def manifest_get(
    manifest_id: str,
    *,
    as_json: t.Annotated[bool, cyclopts.Parameter(name="--json", negative=())] = False,
    platform: PlatformScopeArgs = PlatformScopeArgs(),
) -> None:
    """Get a world manifest by ID."""
    api, profile = platform.connect()
    payload = api.get_world_manifest(profile.org_key, profile.workspace_key, manifest_id)
    _render(payload, as_json=as_json, summary=_summarize_manifest)


# ---------------------------------------------------------------------------
# graph-nodes
# ---------------------------------------------------------------------------


@cli.command(name="graph-nodes")
def graph_nodes(
    manifest_id: str,
    *,
    limit: int = 1000,
    offset: int = 0,
    platform: PlatformScopeArgs = PlatformScopeArgs(),
) -> None:
    """Get graph nodes for a world manifest."""
    api, profile = platform.connect()
    payload = api.get_world_manifest_graph_nodes(
        profile.org_key,
        profile.workspace_key,
        manifest_id,
        limit=limit,
        offset=offset,
    )
    _print_json(payload)


# ---------------------------------------------------------------------------
# graph-edges
# ---------------------------------------------------------------------------


@cli.command(name="graph-edges")
def graph_edges(
    manifest_id: str,
    *,
    limit: int = 5000,
    offset: int = 0,
    platform: PlatformScopeArgs = PlatformScopeArgs(),
) -> None:
    """Get graph edges for a world manifest."""
    api, profile = platform.connect()
    payload = api.get_world_manifest_graph_edges(
        profile.org_key,
        profile.workspace_key,
        manifest_id,
        limit=limit,
        offset=offset,
    )
    _print_json(payload)


# ---------------------------------------------------------------------------
# subgraph
# ---------------------------------------------------------------------------


@cli.command()
def subgraph(
    manifest_id: str,
    center: str,
    *,
    depth: int = 2,
    platform: PlatformScopeArgs = PlatformScopeArgs(),
) -> None:
    """Get a subgraph centered on a node."""
    api, profile = platform.connect()
    payload = api.get_world_manifest_subgraph(
        profile.org_key,
        profile.workspace_key,
        manifest_id,
        center=center,
        depth=depth,
    )
    _print_json(payload)


# ---------------------------------------------------------------------------
# principals
# ---------------------------------------------------------------------------


@cli.command()
def principals(
    manifest_id: str,
    *,
    query: t.Annotated[str | None, cyclopts.Parameter(help="Search query")] = None,
    principal_type: t.Annotated[
        str | None, cyclopts.Parameter(help="Filter by principal type")
    ] = None,
    page: int = 1,
    page_size: t.Annotated[
        int, cyclopts.Parameter(validator=cyclopts.validators.Number(gte=1))
    ] = 20,
    platform: PlatformScopeArgs = PlatformScopeArgs(),
) -> None:
    """Search principals in a world manifest."""
    api, profile = platform.connect()
    payload = api.search_world_manifest_principals(
        profile.org_key,
        profile.workspace_key,
        manifest_id,
        query=query,
        principal_type=principal_type,
        page=page,
        page_size=page_size,
    )
    _print_json(payload)


# ---------------------------------------------------------------------------
# principal
# ---------------------------------------------------------------------------


@cli.command()
def principal(
    manifest_id: str,
    principal_id: str,
    *,
    platform: PlatformScopeArgs = PlatformScopeArgs(),
) -> None:
    """Get a principal by ID."""
    api, profile = platform.connect()
    payload = api.get_world_manifest_principal(
        profile.org_key,
        profile.workspace_key,
        manifest_id,
        principal_id,
    )
    _print_json(payload)


# ---------------------------------------------------------------------------
# principal-details
# ---------------------------------------------------------------------------


@cli.command(name="principal-details")
def principal_details(
    manifest_id: str,
    principal_id: str,
    *,
    platform: PlatformScopeArgs = PlatformScopeArgs(),
) -> None:
    """Get detailed info for a principal."""
    api, profile = platform.connect()
    payload = api.get_world_manifest_principal_details(
        profile.org_key,
        profile.workspace_key,
        manifest_id,
        principal_id,
    )
    _print_json(payload)


# ---------------------------------------------------------------------------
# host
# ---------------------------------------------------------------------------


@cli.command()
def host(
    manifest_id: str,
    host_id: str,
    *,
    platform: PlatformScopeArgs = PlatformScopeArgs(),
) -> None:
    """Get a host by ID."""
    api, profile = platform.connect()
    payload = api.get_world_manifest_host(
        profile.org_key,
        profile.workspace_key,
        manifest_id,
        host_id,
    )
    _print_json(payload)


# ---------------------------------------------------------------------------
# host-details
# ---------------------------------------------------------------------------


@cli.command(name="host-details")
def host_details(
    manifest_id: str,
    host_id: str,
    *,
    platform: PlatformScopeArgs = PlatformScopeArgs(),
) -> None:
    """Get detailed info for a host."""
    api, profile = platform.connect()
    payload = api.get_world_manifest_host_details(
        profile.org_key,
        profile.workspace_key,
        manifest_id,
        host_id,
    )
    _print_json(payload)


# ---------------------------------------------------------------------------
# commands
# ---------------------------------------------------------------------------


@cli.command()
def commands(
    manifest_id: str,
    *,
    platform: PlatformScopeArgs = PlatformScopeArgs(),
) -> None:
    """List commands for a world manifest."""
    api, profile = platform.connect()
    payload = api.list_world_manifest_commands(profile.org_key, profile.workspace_key, manifest_id)
    _print_json(payload)


# ---------------------------------------------------------------------------
# manifest-trajectories
# ---------------------------------------------------------------------------


@cli.command(name="manifest-trajectories")
def manifest_trajectories(
    manifest_id: str,
    *,
    page: int = 1,
    page_size: t.Annotated[
        int, cyclopts.Parameter(validator=cyclopts.validators.Number(gte=1))
    ] = 20,
    as_json: t.Annotated[bool, cyclopts.Parameter(name="--json", negative=())] = False,
    platform: PlatformScopeArgs = PlatformScopeArgs(),
) -> None:
    """List trajectories for a world manifest."""
    api, profile = platform.connect()
    payload = api.list_world_manifest_trajectories(
        profile.org_key,
        profile.workspace_key,
        manifest_id,
        page=page,
        page_size=page_size,
    )
    _render_list(
        payload, as_json=as_json, summary=_summarize_trajectory, empty_msg="No trajectories found"
    )


# ---------------------------------------------------------------------------
# trajectory-create
# ---------------------------------------------------------------------------


@cli.command(name="trajectory-create")
def trajectory_create(
    *,
    manifest_id: str,
    name: t.Annotated[str | None, cyclopts.Parameter(help="Trajectory name")] = None,
    project_id: t.Annotated[str | None, cyclopts.Parameter(help="Project ID to associate")] = None,
    goal: t.Annotated[str, cyclopts.Parameter(help="Target goal for trajectory")] = "Domain Admins",
    count: t.Annotated[int, cyclopts.Parameter(help="Number of trajectories to generate")] = 1,
    strategy: TrajectoryStrategy = "random",
    max_steps: t.Annotated[int, cyclopts.Parameter(help="Maximum steps per trajectory")] = 100,
    seed: t.Annotated[int, cyclopts.Parameter(help="Random seed for reproducibility")] = 42,
    threads: t.Annotated[int, cyclopts.Parameter(help="Number of parallel threads")] = 1,
    only_successful: t.Annotated[
        bool,
        cyclopts.Parameter(negative=()),
    ] = False,
    mode: TrajectoryMode = "kali",
    runtime_id: t.Annotated[str | None, cyclopts.Parameter(help="Runtime environment ID")] = None,
    capability_name: t.Annotated[str | None, cyclopts.Parameter(help="Capability to use")] = None,
    agent_name: t.Annotated[
        str | None, cyclopts.Parameter(help="Agent name within capability")
    ] = None,
    agent_model: t.Annotated[str | None, cyclopts.Parameter(help="Model for the agent")] = None,
    as_json: t.Annotated[bool, cyclopts.Parameter(name="--json", negative=())] = False,
    platform: PlatformScopeArgs = PlatformScopeArgs(),
) -> None:
    """Create a new world trajectory."""
    api, profile = platform.connect()
    payload = api.create_world_trajectory(
        profile.org_key,
        profile.workspace_key,
        manifest_id=manifest_id,
        name=name,
        project_id=project_id,
        goal=goal,
        count=count,
        strategy=strategy,
        max_steps=max_steps,
        seed=seed,
        threads=threads,
        only_successful=only_successful,
        mode=mode,
        runtime_id=runtime_id,
        capability_name=capability_name,
        agent_name=agent_name,
        agent_model=resolve_model(agent_model) if agent_model else None,
    )
    _render(payload, as_json=as_json, summary=_summarize_job)


# ---------------------------------------------------------------------------
# trajectory-list
# ---------------------------------------------------------------------------


@cli.command(name="trajectory-list")
def trajectory_list(
    *,
    manifest_id: t.Annotated[str | None, cyclopts.Parameter(help="Filter by manifest ID")] = None,
    project_id: t.Annotated[str | None, cyclopts.Parameter(help="Project ID filter")] = None,
    created_by: t.Annotated[str | None, cyclopts.Parameter(help="Filter by creator")] = None,
    page: int = 1,
    page_size: t.Annotated[
        int, cyclopts.Parameter(validator=cyclopts.validators.Number(gte=1))
    ] = 20,
    as_json: t.Annotated[bool, cyclopts.Parameter(name="--json", negative=())] = False,
    platform: PlatformScopeArgs = PlatformScopeArgs(),
) -> None:
    """List world trajectories."""
    api, profile = platform.connect()
    payload = api.list_world_trajectories(
        profile.org_key,
        profile.workspace_key,
        manifest_id=manifest_id,
        project_id=project_id,
        created_by=created_by,
        page=page,
        page_size=page_size,
    )
    _render_list(
        payload, as_json=as_json, summary=_summarize_trajectory, empty_msg="No trajectories found"
    )


# ---------------------------------------------------------------------------
# trajectory-get
# ---------------------------------------------------------------------------


@cli.command(name="trajectory-get")
def trajectory_get(
    trajectory_id: str,
    *,
    as_json: t.Annotated[bool, cyclopts.Parameter(name="--json", negative=())] = False,
    platform: PlatformScopeArgs = PlatformScopeArgs(),
) -> None:
    """Get a world trajectory by ID."""
    api, profile = platform.connect()
    payload = api.get_world_trajectory(profile.org_key, profile.workspace_key, trajectory_id)
    _render(payload, as_json=as_json, summary=_summarize_trajectory)


# ---------------------------------------------------------------------------
# job-list
# ---------------------------------------------------------------------------


@cli.command(name="job-list")
def job_list(
    *,
    project_id: t.Annotated[str | None, cyclopts.Parameter(help="Project ID filter")] = None,
    created_by: t.Annotated[str | None, cyclopts.Parameter(help="Filter by creator")] = None,
    kind: JobKind | None = None,
    status: JobStatus | None = None,
    page: int = 1,
    page_size: t.Annotated[
        int, cyclopts.Parameter(validator=cyclopts.validators.Number(gte=1))
    ] = 20,
    as_json: t.Annotated[bool, cyclopts.Parameter(name="--json", negative=())] = False,
    platform: PlatformScopeArgs = PlatformScopeArgs(),
) -> None:
    """List world jobs."""
    api, profile = platform.connect()
    payload = api.list_world_jobs(
        profile.org_key,
        profile.workspace_key,
        project_id=project_id,
        created_by=created_by,
        kind=kind,
        status=status,
        page=page,
        page_size=page_size,
    )
    _render_list(payload, as_json=as_json, summary=_summarize_job, empty_msg="No jobs found")


# ---------------------------------------------------------------------------
# job-get
# ---------------------------------------------------------------------------


@cli.command(name="job-get")
def job_get(
    job_id: str,
    *,
    as_json: t.Annotated[bool, cyclopts.Parameter(name="--json", negative=())] = False,
    platform: PlatformScopeArgs = PlatformScopeArgs(),
) -> None:
    """Get a world job by ID."""
    api, profile = platform.connect()
    payload = api.get_world_job(profile.org_key, profile.workspace_key, job_id)
    _render(payload, as_json=as_json, summary=_summarize_job)


# ---------------------------------------------------------------------------
# job-wait
# ---------------------------------------------------------------------------


@cli.command(name="job-wait")
def job_wait(
    job_id: str,
    *,
    poll_interval_sec: t.Annotated[
        float,
        cyclopts.Parameter(
            validator=cyclopts.validators.Number(gt=0), help="Polling interval in seconds"
        ),
    ] = 5.0,
    timeout_sec: t.Annotated[
        float | None, cyclopts.Parameter(help="Timeout in seconds for waiting")
    ] = None,
    as_json: t.Annotated[bool, cyclopts.Parameter(name="--json", negative=())] = False,
    platform: PlatformScopeArgs = PlatformScopeArgs(),
) -> None:
    """Wait for a world job to complete."""
    api, profile = platform.connect()
    payload = _wait_for_job(
        lambda: api.get_world_job(profile.org_key, profile.workspace_key, job_id),
        job_id=job_id,
        label="world",
        poll_interval_sec=poll_interval_sec,
        timeout_sec=timeout_sec,
    )
    _render(payload, as_json=as_json, summary=_summarize_job)
    if payload.get("status") != "completed":
        raise RuntimeError(
            payload.get("error") or f"World job {job_id} ended with status {payload.get('status')}"
        )


# ---------------------------------------------------------------------------
# job-cancel
# ---------------------------------------------------------------------------


@cli.command(name="job-cancel")
def job_cancel(
    job_id: str,
    *,
    as_json: t.Annotated[bool, cyclopts.Parameter(name="--json", negative=())] = False,
    platform: PlatformScopeArgs = PlatformScopeArgs(),
) -> None:
    """Cancel a world job."""
    api, profile = platform.connect()
    payload = api.cancel_world_job(profile.org_key, profile.workspace_key, job_id)
    _render(payload, as_json=as_json, summary=_summarize_job)
