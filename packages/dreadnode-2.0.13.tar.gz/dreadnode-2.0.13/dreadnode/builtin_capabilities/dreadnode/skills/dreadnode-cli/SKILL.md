---
name: dreadnode-cli
description: Use when the user wants exact dreadnode or dn CLI commands, needs a workflow mapped to sdk/app/cli command groups, wants intent routed to the right CLI or capability surface, wants the TUI equivalent of a CLI workflow, or needs current shipped CLI boundaries kept straight.
---

# Dreadnode CLI

Use this skill when the user wants exact `dn` or `dreadnode` commands, or when the boundary between
CLI command groups matters. It may also help when the user wants the nearest TUI command or screen
for a CLI workflow.

## When to Use

- The user asks for exact `dn` or `dreadnode` commands
- The user wants to know which CLI group owns a workflow
- The user wants to know which Dreadnode workflow or surface fits an intent
- The user is mixing up CLI groups or local versus hosted CLI workflows
- The user asks for the TUI equivalent of a CLI workflow
- The user asks how to iterate on a local capability versus run a hosted optimization job

## When Not to Use

- The request is purely about capability content, not how to operate the SDK
- The answer does not depend on command shape or CLI workflow boundary
- The user wants platform internals rather than operator-facing workflows

## Operating Rules

- Prefer workflow-shaped commands, not raw API operations
- Prefer the actual SDK command groups in `packages/sdk/dreadnode/app/cli/`
- Choose the owning surface before giving syntax
- If a feature is planned but not shipped, say that directly
- When exact syntax matters, prefer `dreadnode --help` or `dreadnode <group> --help`
- Keep the CLI group boundary explicit
- If the user asks for TUI help, give the CLI answer first and then the nearest TUI equivalent

## CLI Surface Map

### CLI

The SDK CLI has two halves:

- app and local runtime: bare `dn`, `dn --print`, `dn serve`, `dn login`, `dn whoami`
- platform and registry control plane: the top-level groups under `packages/sdk/dreadnode/app/cli/`

Top-level groups live in:

- `packages/sdk/dreadnode/app/cli/main.py`
- `packages/sdk/dreadnode/app/cli/capability.py`
- `packages/sdk/dreadnode/app/cli/dataset.py`
- `packages/sdk/dreadnode/app/cli/task.py`
- `packages/sdk/dreadnode/app/cli/evaluation.py`
- `packages/sdk/dreadnode/app/cli/optimize.py`
- `packages/sdk/dreadnode/app/cli/runtime.py`
- `packages/sdk/dreadnode/app/cli/model.py`
- `packages/sdk/dreadnode/app/cli/sandbox.py`
- `packages/sdk/dreadnode/app/cli/train.py`
- `packages/sdk/dreadnode/app/cli/worlds.py`
- `packages/sdk/dreadnode/app/cli/airt.py`

## Command Selection

Read `references/command-groups.md` when you need the full shipped CLI inventory, a quick map from user intent to the right CLI group or Dreadnode surface, or a reminder of which subcommands each group exposes.

Read `references/tui-crosswalk.md` only when the user explicitly wants the TUI path.

Common rules:

- "I want to talk to an agent right now" -> bare `dn` or `dn --print`
- "I need to log in or confirm which profile/workspace/project I am using" -> `dn login` or `dn whoami`
- domain-specific work like web app pentesting, AI red teaming, or specialized operations -> search for relevant capabilities first, then route to the next workflow
- local capability iteration: use `dn capability ...`
- local datasets: use `dn dataset ...`
- task environments and challenge flows: use `dn task ...`
- evaluation runs and inspection: use `dn evaluation ...`
- hosted optimization control plane: use `dn optimize ...`
- hosted fine-tuning jobs: use `dn train ...`
- local runtime management: use `dn runtime ...`

## Important Distinctions

- `dn capability improve` is local and stack-aware
- `dn optimize submit` is hosted and instruction-only today
- planned runtime self-improvement should not be described as shipped until the command exists
- TUI flows are a convenience layer; the CLI remains the source of exact command syntax

## Coverage Rule

- Treat the built-in CLI skill as covering the full shipped CLI surface, not just a few common groups
- If the user asks about a Dreadnode CLI workflow, map it to a real shipped top-level command or subcommand before answering
- When a request mentions a verb like compare, wait, logs, artifacts, export, alias, metrics, transcript, or retry, check the owning group instead of assuming from memory

## Intent Heuristics

- If the user asks to run a repeatable benchmark, regression, or scored run, route to `dn evaluation ...`
- If the user asks to inspect a past run, route to `dn evaluation get`, `list-samples`, `get-sample`, or `get-transcript`
- If the user asks to do domain work like "run a web-app pentest", start with capability discovery rather than assuming `evaluation` or `airt`
- If the user asks to publish or inspect reusable building blocks, route to `capability`, `dataset`, `model`, or `task`
- If the user asks for hosted fine-tuning, route to `dn train ...`
- If the user asks for hosted optimization of a published capability, route to `dn optimize ...`
- If the user asks about runtime records, use `dn runtime ...`; if they ask about backing compute, use `dn sandbox ...`

## Answering Pattern

1. Identify which CLI workflow the user is asking for.
2. Map the request to the owning CLI group.
3. Give the exact command when possible.
4. If the user asked for TUI help, add the closest slash command or screen after the CLI answer.
5. If the workflow is only planned, say that directly instead of implying the command exists.
