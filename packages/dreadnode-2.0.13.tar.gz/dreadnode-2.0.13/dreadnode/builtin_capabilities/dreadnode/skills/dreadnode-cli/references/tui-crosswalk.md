# Dreadnode CLI to TUI Crosswalk

Use this file only when the user explicitly wants the TUI path as well as, or instead of, the
exact CLI command.

The CLI remains the source of exact syntax. The TUI is a convenience surface.

## Common mappings

- `dn capability ...` -> `/capabilities` screen for browsing and managing capabilities
- `dn dataset ...` -> no single equivalent command group; datasets are usually handled through
  evaluation and workflow screens rather than a dedicated TUI dataset command
- `dn task ...` -> `/environments` for browsing environments and tasks
- `dn evaluation ...` -> `/evaluations`
- `dn optimize ...` -> no direct equivalent for full hosted control-plane submission; explain the
  CLI path directly
- `dn runtime ...` -> `/runtimes`
- `dn model ...` -> `/models`
- session switching and routing -> `/sessions`, `/agents`, `/agent name`, or `@agent-name`

## Practical rule

When the user asks "how do I do this in the TUI?":

1. Give the exact CLI owner first if command precision matters.
2. Then name the nearest slash command or screen.
3. If no solid TUI equivalent exists, say so directly instead of guessing.
