# Dreadnode CLI Command Groups

Use this file when you need a quick map from operator intent to the owning SDK CLI module or Dreadnode surface.

## First split: app versus control plane

- bare `dn` / `dreadnode` -> launch the app, resume a session, or run one-shot `--print` mode
- `dn login` / `dn whoami` -> authenticate and inspect saved platform context
- `dn serve` -> host a local runtime server
- `dn something ...` -> usually a platform or registry workflow owned by a specific CLI group

## Top-level groups

- `main`: app launch, one-shot print mode, login, whoami, and local runtime hosting
- `capability`: local capability scaffolding, validation, install, sync, info, and local improvement
- `dataset`: local and remote dataset workflows
- `task`: task and environment execution workflows
- `evaluation`: evaluation runs, inspection, and results
- `optimize`: hosted optimization control-plane commands
- `runtime`: hosted runtime record inspection
- `model`: model inspection and local model workflows
- `sandbox`: sandbox inspection and management
- `train`: hosted SFT and RL training jobs
- `worlds`: world definitions and related workflows
- `airt`: AIRT workflows

## Practical routing

- "I want to talk to an agent right now" -> bare `dn` or `dn --print`
- "I need to log in" -> `login`
- "Who am I / which profile or project am I using?" -> `whoami`
- "I need a local runtime server for the TUI or clients" -> `serve`
- "I need to find the right agent or toolkit for a domain workflow" -> `capability`
- "I am still editing a capability locally" -> `capability`
- "I want to run a web-app pentest or other domain-specific workflow" -> search for relevant capabilities first with `dn capability list --search ... --include-public`, then install or inspect the right one before choosing the next workflow
- "I need a published hosted optimization job" -> `optimize`
- "I need to run or inspect an evaluation" -> `evaluation`
- "I need to inspect runtime records in the platform" -> `runtime`
- "I need to inspect backing compute, logs, or usage" -> `sandbox`
- "I need hosted fine-tuning" -> `train`
- "I need AI red teaming workflows" -> `airt`
- "I need simulated network manifests or trajectories" -> `worlds`
- "I need reusable data for training, optimization, or evaluation" -> `dataset`
- "I need reusable model artifacts, aliases, or metrics" -> `model`
- "I need task environments with instructions and verification" -> `task`
- "I need the exact top-level CLI layout" -> `main.py` plus the relevant group file
- "I need exact `dn` syntax, not TUI slash commands" -> stay within these CLI groups

## Decision rules that avoid common mistakes

- Repeatable benchmark or regression -> `evaluation`, not `runtime`
- Domain-specific work like web app pentesting -> capability discovery first, not `evaluation` by default
- Interactive live work after capability selection -> bare `dn` / TUI, not necessarily a control-plane command
- Hosted runtime record inspection -> `runtime`
- Local runtime hosting -> `serve`
- Backing compute inspection -> `sandbox`
- Local capability iteration -> `capability improve`
- Hosted optimization of a published capability -> `optimize submit`

## Shipped command inventory

Use this inventory when the user asks about specific CLI functionality. If a request sounds like one
of these verbs, route to the owning group instead of guessing.

### `main`

- bare `dn` / `dreadnode` -> launch the TUI
- `dn --print` -> run one-shot print mode against the runtime
- `dn login` -> authenticate and save a profile
- `dn whoami` -> inspect current identity and scope
- `dn serve` -> host a local runtime server

### `capability`

- `dn capability init` -> scaffold a new local capability
- `dn capability install` -> activate a local or registry capability for local use
- `dn capability push` -> upload one capability version
- `dn capability publish` -> make a capability visible
- `dn capability unpublish` -> remove public visibility
- `dn capability list` -> search available capabilities
- `dn capability info` -> inspect one capability and its versions
- `dn capability pull` -> download a capability without activating it
- `dn capability delete` -> remove a published capability version
- `dn capability sync` -> bulk-publish capabilities from a tree
- `dn capability improve` -> run local capability improvement
- `dn capability validate` -> validate a local capability bundle

### `dataset`

- `dn dataset inspect` -> inspect a local dataset before upload
- `dn dataset push` -> upload one dataset version
- `dn dataset publish` -> make a dataset visible
- `dn dataset unpublish` -> remove public visibility
- `dn dataset list` -> search datasets
- `dn dataset info` -> inspect one dataset and its versions
- `dn dataset delete` -> remove a published dataset version
- `dn dataset pull` -> download dataset content

### `task`

- `dn task init` -> scaffold a new task environment
- `dn task push` -> upload one task version
- `dn task publish` -> make a task visible
- `dn task unpublish` -> remove public visibility
- `dn task list` -> search tasks
- `dn task info` -> inspect one task and its instructions
- `dn task pull` -> download a task locally
- `dn task delete` -> remove a published task version
- `dn task sync` -> bulk-publish tasks from a tree
- `dn task validate` -> validate a local task bundle and optional build flow

### `evaluation`

- `dn evaluation create` -> launch an evaluation
- `dn evaluation list` -> list evaluations
- `dn evaluation get` -> inspect one evaluation
- `dn evaluation list-samples` -> list samples in an evaluation
- `dn evaluation get-sample` -> inspect one sample in detail
- `dn evaluation get-transcript` -> fetch the full agent transcript for a sample
- `dn evaluation wait` -> block until an evaluation finishes
- `dn evaluation cancel` -> cancel a running evaluation
- `dn evaluation retry` -> retry failed or errored samples
- `dn evaluation export` -> export evaluation results
- `dn evaluation compare` -> compare evaluations

### `optimize`

- `dn optimize submit` -> start a hosted optimization job
- `dn optimize list` -> list optimization jobs
- `dn optimize get` -> inspect one optimization job
- `dn optimize wait` -> block until a job finishes
- `dn optimize logs` -> read optimization logs
- `dn optimize artifacts` -> inspect optimization artifacts
- `dn optimize cancel` -> cancel a running job
- `dn optimize retry` -> retry a failed optimization job

### `runtime`

- `dn runtime list` -> list hosted runtime records
- `dn runtime get` -> inspect one hosted runtime record

### `model`

- `dn model inspect` -> inspect a local model bundle
- `dn model push` -> upload one model version
- `dn model publish` -> make a model visible
- `dn model unpublish` -> remove public visibility
- `dn model list` -> search models
- `dn model info` -> inspect one model and its versions
- `dn model compare` -> compare two model versions
- `dn model alias` -> attach or move an alias
- `dn model metrics` -> attach metrics to a model version
- `dn model delete` -> remove a published model version
- `dn model pull` -> download a model locally

### `sandbox`

- `dn sandbox list` -> list sandboxes
- `dn sandbox get` -> inspect one sandbox
- `dn sandbox logs` -> fetch sandbox logs
- `dn sandbox usage` -> inspect sandbox resource usage
- `dn sandbox delete` -> stop and remove a sandbox

### `train`

- `dn train sft` -> start a hosted supervised fine-tuning job
- `dn train rl` -> start a hosted RL training job
- `dn train list` -> list training jobs
- `dn train get` -> inspect one training job
- `dn train wait` -> block until a training job finishes
- `dn train logs` -> fetch training logs
- `dn train artifacts` -> inspect training artifacts
- `dn train cancel` -> cancel a running training job

### `worlds`

- `dn worlds manifest-create` -> create a world manifest
- `dn worlds manifest-list` -> list manifests
- `dn worlds manifest-get` -> inspect one manifest
- `dn worlds graph-nodes` -> inspect graph nodes
- `dn worlds graph-edges` -> inspect graph edges
- `dn worlds subgraph` -> inspect a filtered graph slice
- `dn worlds principals` -> search principals
- `dn worlds principal` -> inspect one principal
- `dn worlds principal-details` -> inspect detailed principal metadata
- `dn worlds host` -> inspect one host
- `dn worlds host-details` -> inspect detailed host metadata
- `dn worlds commands` -> inspect available command history or command surfaces
- `dn worlds manifest-trajectories` -> list trajectories for a manifest
- `dn worlds trajectory-create` -> create trajectories
- `dn worlds trajectory-list` -> list trajectories
- `dn worlds trajectory-get` -> inspect one trajectory
- `dn worlds job-list` -> list Worlds jobs
- `dn worlds job-get` -> inspect one Worlds job
- `dn worlds job-wait` -> block until a Worlds job finishes
- `dn worlds job-cancel` -> cancel a Worlds job

### `airt`

- `dn airt create` -> create an assessment record
- `dn airt list` -> list assessments
- `dn airt get` -> inspect one assessment
- `dn airt update` -> update assessment metadata or status
- `dn airt delete` -> delete an assessment record
- `dn airt sandbox` -> inspect the assessment sandbox
- `dn airt reports` -> list reports for an assessment
- `dn airt report` -> inspect one report
- `dn airt analytics` -> inspect assessment analytics
- `dn airt traces` -> inspect related traces
- `dn airt attacks` -> inspect attack records
- `dn airt trials` -> inspect attack trials
- `dn airt project-summary` -> summarize project-level AIRT state
- `dn airt findings` -> inspect findings
- `dn airt generate-project-report` -> generate a project-level report
- `dn airt run` -> run a direct AIRT attack workflow from the CLI
- `dn airt run-suite` -> run a suite of AIRT workflows
- `dn airt list-attacks` -> list available attack types
- `dn airt list-transforms` -> list available transforms
- `dn airt list-goal-categories` -> list supported goal categories

## Known current boundary

- `dn capability improve` exists for local capability-owned iteration
- `dn runtime improve` is design work, not a shipped command unless the SDK adds it later
