# Capability Improvement Spec

This document defines a stack-aware self-improvement loop for Dreadnode capabilities.

It combines two ideas:

- the capability-authoring guidance in `SKILL.md`: prefer simple components, improve skills before tools, and test against real prompts
- the outer-loop discipline from `autoagent`: establish a baseline, mutate a bounded surface, benchmark, keep or discard, and prefer simpler systems when results are equal

## Why this needs a spec

A capability is not the whole agent.

At runtime, Dreadnode builds an agent from multiple layers:

1. core runtime system prompt
2. optional capability agent prompt override
3. capability `system-prompt.md`
4. inherent default tools
5. capability tools, MCP servers, and delegation links
6. native SDK skills plus capability skills

The current hosted optimization path only mutates agent `instructions`. That is useful, but it cannot improve the other surfaces that often matter more: skill descriptions, skill bodies, tool rules, or orchestration.

## Product split

The design should expose two distinct workflows.

### `dreadnode capability improve`

Use when the goal is to improve one published capability while holding the runtime constant.

This command should mutate capability-owned surfaces only:

- agent definition prompts
- capability `system-prompt.md`
- skill descriptions
- skill bodies
- agent tool rules
- delegation links
- MCP configuration
- capability-local tool configuration

It should pin:

- runtime version
- default toolset
- native SDK skills
- target model

### `dreadnode runtime improve`

Use when the goal is to improve the shared default agent that capabilities sit on top of.

The long-term target for this workflow should be a bundled SDK capability named `dreadnode`, not a
purely hardcoded default prompt. Read `runtime-default-capability.md` for the migration plan and
the fallback semantics for `default`.

This command should mutate runtime-owned surfaces only:

- core runtime prompt
- default tools
- native SDK skills

It should pin:

- a benchmark suite containing multiple representative capabilities
- a fixed evaluation dataset set per capability
- the current capability versions under test

### `--scope full-stack`

Support this only as an advanced mode.

Without clear ownership boundaries, full-stack search can produce misleading wins by compensating for one bad layer with another.

## Improvement loop

Every improver should follow the same outer loop.

1. Establish a baseline on train and holdout datasets.
2. Inspect failures and select one bounded mutation surface.
3. Produce a candidate.
4. Re-run train and holdout.
5. Keep the candidate only if it improves the target metric and does not regress the guardrails.
6. Record the result in an experiment ledger.
7. Repeat until budget or stop conditions are reached.

This is intentionally conservative. The goal is reliable compounding improvement, not flashy one-off prompt edits.

The same control-loop ideas appear in `autoagent`'s `program.md`: baseline first, one general
improvement, strict keep or discard rules, and equal-performance preference for simpler systems.

## Mutation order

Prefer the cheapest, highest-leverage surfaces first.

1. skill `description`
2. skill body in `SKILL.md`
3. agent definition prompt
4. capability `system-prompt.md`
5. tool rules
6. delegation and orchestration
7. MCP configuration
8. custom tool code

Why this order:

- skill routing errors often explain why a good capability underperforms
- skill body changes are cheaper and easier to validate than code changes
- prompt and tool-rule changes are still cheap relative to tool rewrites
- custom tools should be the last resort because they add maintenance cost

## Keep and discard policy

A candidate should be kept only when all of these are true:

- train score improves by the configured threshold
- holdout score does not regress past the configured tolerance
- required guardrail metrics remain green
- the candidate stays within allowed mutation scope

Tie-break rules:

- equal score prefers the simpler candidate
- prompt-only beats prompt-plus-code when outcomes are equivalent
- fewer changed files beats more changed files when outcomes are equivalent

## Candidate model

A stack-aware candidate should not be represented as one flat `instructions` string.

It should be represented as named components with ownership and provenance.

Suggested component keys:

- `core_prompt`
- `agent_prompt`
- `capability_prompt`
- `skill_descriptions`
- `skill_bodies`
- `tool_rules`
- `delegation_links`
- `mcp_config`
- `tool_config`

Each component should carry:

- ownership: `runtime` or `capability`
- source path
- optional selector inside the file
- current content
- mutability flag

## Adapter requirements

The current adapter is instruction-only. A stack-aware adapter should replace that flattening with component-aware seed and apply behavior.

### Proposed adapter shape

`StackAwareCapabilityAdapter`

Responsibilities:

- load the capability and runtime stack using the same assembly path as normal execution
- expose seed candidates as structured components instead of one string
- apply a structured candidate back onto a temporary capability workspace
- rebuild the effective agent after each mutation
- evaluate the rebuilt agent on datasets and scorers
- emit reflective data per component so the optimizer can reason about what changed

### Seed behavior

Seed candidates should capture the current state of each allowed component.

For example:

```python
{
    "agent_prompt": "...",
    "capability_prompt": "...",
    "skill_descriptions": {
        "recon": "Use when ..."
    },
    "skill_bodies": {
        "recon": "# Recon ..."
    },
}
```

### Apply behavior

Apply should:

1. clone the capability into a temporary workspace
2. rewrite only the candidate-owned components
3. validate the capability
4. recreate the agent through the normal runtime assembly path
5. evaluate it

This keeps optimization honest. It ensures the evaluated candidate is something that could actually be shipped.

## Control file

The improver needs a human-edited control file similar in spirit to `program.md` in `autoagent`.

Suggested file: `improvement.yaml`

Fields:

- target capability ref
- optional agent name
- scope: `capability`, `runtime`, or `full-stack`
- allowed mutation surfaces
- train dataset ref
- holdout dataset ref
- target model
- optimization budget
- stop conditions
- keep and discard thresholds
- publish policy

This file makes the improvement loop reproducible and reviewable.

## Ledgers and artifacts

Every run should write an experiment ledger.

Minimum fields:

- baseline stack hash
- candidate stack hash
- changed components
- train metrics
- holdout metrics
- keep or discard decision
- rationale

Artifacts should include:

- a patch or file diff
- reflective notes from the optimizer
- the rebuilt candidate capability bundle

## Evaluation policy

Capability and runtime improvement need different evaluation policies.

### Capability improvement

- optimize against one capability
- pin the runtime
- use one train dataset and one holdout dataset
- allow fast iteration on skill and prompt surfaces

### Runtime improvement

- optimize the shared runtime only
- benchmark across a suite of capabilities
- require non-regression across the suite
- keep the mutation budget lower per run because blast radius is higher

## Safety rules

The improver should reject candidates that:

- modify files outside the allowed ownership scope
- change both runtime and capability surfaces in non-full-stack mode
- remove validation-critical files
- introduce new dependencies without explicit approval
- improve train score while violating holdout or guardrail thresholds

## CLI shape

The first concrete CLI should look like this:

```bash
dreadnode capability improve my-capability@1.2.3 \
  --agent assistant \
  --dataset train-prompts@1.0.0 \
  --holdout-dataset holdout-prompts@1.0.0 \
  --model openai/gpt-4o-mini \
  --scope capability \
  --surfaces skill_descriptions,skill_bodies,agent_prompt,capability_prompt \
  --max-trials 20
```

And for runtime:

```bash
dreadnode runtime improve \
  --suite core-runtime-v1 \
  --model openai/gpt-4o-mini \
  --scope runtime \
  --surfaces core_prompt,default_tools,native_skills \
  --max-trials 10
```

These commands are workflow-shaped, not CRUD-shaped. They describe what the user is trying to accomplish.

## Implementation order

Build this in phases.

### Phase 1

- keep hosted optimization as instruction-only
- add local stack-aware capability improvement using a temporary workspace
- support skill descriptions, skill bodies, agent prompt, and capability prompt
- write experiment ledger output

### Phase 2

- add tool rules and delegation links
- add holdout-aware keep and discard policy
- add promotion output that can be published as a new capability version

### Phase 3

- add runtime improvement
- add broad benchmark suites
- allow full-stack mode behind an explicit advanced flag

## Non-goals for the first version

- arbitrary code synthesis across the whole capability tree
- automatic dependency installation
- automatic publishing without an explicit promotion step
- hidden cross-layer mutations that the user did not allow

## Practical rule

The improver should behave like a careful engineer:

- baseline first
- one bounded change at a time
- holdout before keep
- simpler wins ties
- publish only validated improvements
