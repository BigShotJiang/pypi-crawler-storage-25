# Capability Components Reference

A capability can include any combination of these components. Start with just a skill — add others only when you've proven the need.

For full documentation, see the extensibility guides in the platform docs (`packages/docs/src/content/docs/extensibility/`).

## Skills

**When to use:** Almost always. Skills are the primary way to give an agent domain expertise.

**Format:** A directory containing `SKILL.md` with YAML frontmatter (`name`, `description` required) and a markdown body. Supporting files (scripts, references, assets) go alongside.

**How they work:** Skill metadata (name + description) is always in the agent's context. The full body loads on demand when the agent decides the skill is relevant. This is progressive disclosure — cheap metadata for routing, full content only when needed.

**Key guidance:** See Step 4 of the main skill for writing effective skills.

## Agent Definitions

**When to use:** When the default agent behavior isn't right and you need:
- A different behavioral posture (e.g., cautious auditor vs. aggressive red teamer)
- Tool access restrictions (allow/deny specific tools by pattern)
- A specific model rather than the session default
- Named delegation targets for multi-agent workflows

Most capabilities don't need custom agent definitions.

**Format:** Markdown files in `agents/` with YAML frontmatter + system prompt body.

Key frontmatter fields:
- `name` — identifier (lowercase, hyphens)
- `description` — when to use this agent
- `model` — `"inherit"` (default) or a specific model ID
- `tools` — dict of fnmatch patterns to true/false for allow/deny

The markdown body becomes the agent's system prompt.

**Gotcha:** Tool rules use fnmatch patterns (`scan-*` matches `scan-http`, `scan-dns`). An empty system prompt triggers a validation warning.

## MCP Servers

**When to use:** When the capability needs to connect to external services (APIs, databases, hosted tools) or when an existing MCP server provides the functionality you need.

**Format:** Defined inline in `capability.yaml` under `mcp.servers`, or in a `.mcp.json` file.

Two transport types:
- **stdio** — local process (specify `command` + `args`). Best for custom servers or npm-packaged MCP servers.
- **streamable-http** — remote endpoint (specify `url` + optional `headers`). Best for hosted services.

```yaml
# In capability.yaml
mcp:
  servers:
    my-server:
      command: "uv"
      args: ["run", "path/to/server.py"]
      init_timeout: 30
```

**Gotcha:** Environment variables in MCP configs use `${VAR}` or `${VAR:-default}` syntax. They're resolved at connect time, not load time. Setting `mcp: {}` explicitly disables MCP; omitting it enables auto-discovery of `.mcp.json`.

## Python Tools (Toolsets)

**When to use:** When the agent needs programmatic access to something that doesn't have a good CLI or MCP server — custom HTTP APIs, stateful protocols, domain-specific analysis.

**Format:** Python files in `tools/` using the `@tool` decorator (standalone functions) or `Toolset` classes with `@tool_method`.

```python
from dreadnode.agents.tools import Toolset, tool_method

class MyTools(Toolset):
    @tool_method(name="my_tool", catch=True)
    async def my_tool(self, query: str) -> str:
        """Tool description from docstring."""
        return f"Result for {query}"
```

**Lazy initialization pattern** — for tools that need async resources (HTTP clients, database connections). The capability loader auto-instantiates Toolsets but doesn't call `__aenter__`, so you must initialize lazily:

```python
from pydantic import PrivateAttr
import httpx

class HttpTools(Toolset):
    _client: httpx.AsyncClient | None = PrivateAttr(default=None)

    def _ensure_client(self) -> httpx.AsyncClient:
        if self._client is None:
            self._client = httpx.AsyncClient(timeout=30)
        return self._client

    @tool_method(name="fetch", catch=True)
    async def fetch(self, url: str) -> str:
        client = self._ensure_client()
        resp = await client.get(url)
        return resp.text
```

**Gotcha:** Toolsets must have a parameterless constructor (they're auto-instantiated). Use `PrivateAttr` for internal state. Tool output over 30KB is auto-offloaded to disk.

## Manifest (capability.yaml)

The manifest declares what the capability contains. Required fields: `schema` (always 1), `name`, `version` (semver), `description`.

Optional fields:
- `agents`, `tools`, `skills` — paths to components. Omit for auto-discovery from conventional directories. Set to `[]` to disable a component type.
- `mcp` — MCP server definitions (see above)
- `dependencies` — sandbox requirements: `python` (versions), `packages` (OS packages), `scripts` (setup scripts)
- `checks` — pre-flight health checks: `name` + `command` (shell command, exit 0 = pass)
- `author`, `license`, `repository`, `keywords` — metadata

Run `dn capability validate` to check your manifest against all validation rules.
