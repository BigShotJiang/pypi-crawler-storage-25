---
name: creating-capabilities
description: Use when asked to create a new capability, improve an existing capability, build skills or tools for the Dreadnode platform, or when the user says "build me a capability for X".
---

# Creating Capabilities

A capability packages domain expertise — skills, tools, agent definitions, MCP servers — so that agents can apply it on demand.

## Before You Start

Ask the user what they need the capability to do. One or two questions — enough to identify:

1. **The domain** — what problem space? (security research, compliance review, data pipeline, etc.)
2. **The kind of work** — is this research with uncertain outcomes, wrapping an existing tool, or automating a known process? This determines how much user input you'll need and how the skill should be structured (see Step 4).

## Step 1: Research the Space

The most common mistake is jumping straight to scaffolding. Capabilities that wrap existing tools well are more robust and maintainable than ones that reimplement functionality from scratch — and users already have muscle memory for established CLIs.

Before building anything, survey what already exists:

- **CLI tools** — search package managers for established tools in the domain
- **MCP servers** — check registries and GitHub for MCP server implementations
- **Libraries** — look for Python/JS libraries that solve the core problem
- **AI tooling** — search for existing skills, plugins, or agent capabilities in the space
- **Community knowledge** — HackTricks, awesome-lists, tool comparison posts

Use web search. Check multiple sources. The goal is to understand what's already solved so you don't reimplement it.

**What you're looking for:**
- Tools the agent can drive via bash (no wrapper needed)
- Libraries or MCP servers worth referencing in the capability
- Gaps where custom tooling actually adds value
- Established methodologies the skill should encode

## Step 2: Decide What to Build

Most capable capabilities are simpler than you'd expect. Start from the simplest architecture that works — you can always add complexity later when you've proven you need it, but you can't easily remove it.

```
Can the agent do this with bash + existing CLI tools?
  YES → Write a skill teaching the methodology. Done.
  NO  → Is there an existing MCP server or library?
    YES → Reference it in the manifest. Write a skill for workflow.
    NO  → Now write custom tools. Prefer MCP over Python Toolset.
         Only then consider whether a custom agent definition adds value.
```

**Why this ordering matters:**

- **Skills over tools** — a skill teaching methodology is more adaptable than a custom tool. When a CLI changes flags or adds features, the agent picks it up from `--help`. A hardcoded tool wrapper needs code changes.
- **MCP over Python Toolset** — models are more familiar with MCP patterns, and MCP servers are reusable across platforms. Python Toolsets are framework-specific and have quirks (e.g., the lazy initialization pattern for async resources).
- **Agent definitions are rarely needed** — the default agent + a good skill handles most cases. Agent definitions add value only when you need a fundamentally different behavioral posture, tool filtering, a different model, or delegation targets for multi-agent workflows.

When your decision tree leads you to MCP servers, Python tools, or agent definitions, see `capability-components.md` for format details, examples, and gotchas for each component type.

## Step 3: Scaffold and Set Up the Dev Loop

Use `dn capability init` to scaffold a new capability directory. Use `--with-skills` if you plan to include skills (you almost always should). Run `dn capability --help` for the full set of options.

The scaffold creates a capability directory in your current working directory with a manifest, a starter agent, and optionally a starter skill. After scaffolding:

1. Run `dn capability validate` against the directory to confirm it's valid
2. Look at installed capabilities for reference: `ls ~/.dreadnode/capabilities/`
3. Read a well-structured capability's files to understand the patterns

Review the scaffold and remove anything that doesn't serve the capability. An agent definition that just says "You are a helpful assistant" duplicates the default — delete it. An empty `tools/` directory suggests tooling you haven't proven you need — delete it.

**Set up live development** by installing the capability locally with `dn capability install`. When given a local path, this creates a symlink in `~/.dreadnode/capabilities/` pointing at your working directory. Edits are live — no reinstall needed between changes.

For a quick one-off test without installing, you can use the `--capabilities-dir` flag when launching the agent to point at a directory containing your capability (see Step 5).

## Step 4: Write the Skill

Skills are the primary delivery mechanism. They're what make a capability useful — without a good skill, even great tools go unused because the agent doesn't know when or how to apply them.

### What makes a skill effective

**Teach methodology, not mechanics.** The agent has bash and `--help` for reference docs. The skill's value is knowing *what to reach for and in what order*. If information exists in a file the agent can read or a command it can run, point to it instead of duplicating it in the skill.

**Explain why, not just what.** Instead of rigid MUSTs, explain the reasoning. "Check oldest image tags first because credentials from before secret management maturity may still be unrotated" is more effective than "ALWAYS check old tags first" — it lets the agent adapt when the reasoning doesn't apply.

**Match structure to the kind of work:**

| Kind of work | Skill structure | Agent freedom |
|--------------|-----------------|---------------|
| Domain research (security assessments, threat modeling) | Hypotheses and approaches, each with "how to test" and "when to abandon" | High — agent forms theories, pivots on findings |
| Tool integration (wrapping Semgrep, Nmap, a database CLI) | Workflow patterns, common invocations, output interpretation | Medium — agent follows patterns, adapts to context |
| Process automation (report generation, NDA review) | Step-by-step recipes, validation gates, output templates | Low — agent follows the recipe |

Many capabilities are hybrids — a security tool integration has tool-integration mechanics but domain-research strategy. The skill should reflect both layers.

**Interview when goals are ambiguous.** For domain-research capabilities, the skill should instruct the agent to clarify the objective before starting work. Not a long interview — one or two questions that determine which approaches to prioritize.

### Writing good descriptions

The `description` in YAML frontmatter is how the agent decides whether to load the skill. It should describe *when to use* the skill — trigger conditions only, not what the skill does or how it works. Agents tend to undertrigger, so be specific and slightly pushy about when the skill applies.

**Weak descriptions:**
- `"Helps with security testing"` — too vague, won't trigger on specific requests
- `"A guide for analyzing Docker registries and finding vulnerabilities in container images"` — summarizes what the skill does, not when to use it

**Strong descriptions:**
- `"Use when performing container registry security research, analyzing Docker images for leaked secrets, or mapping build infrastructure through image metadata"` — specific trigger conditions, includes scenarios a user would describe
- `"Use when asked to run red team assessments against LLMs, test model safety guardrails, or evaluate prompt injection resistance"` — concrete, action-oriented, covers multiple entry points

Keep descriptions under 200 characters when possible — every installed skill's metadata contributes to a shared token budget. Front-load the most important trigger keywords.

### Supporting files

Skills can bundle reference data, scripts, and templates alongside SKILL.md:

- **Reference files** — for depth the agent reaches for selectively. In your skill instructions, tell the agent what each file contains and when to read it. Don't put content here that the agent needs on every invocation — that belongs in the skill body.
- **Scripts** — for operations that should produce the same output every time (validation, formatting, data transformation). Scripts are more reliable than asking the agent to do deterministic work, save tokens, and work consistently across models. They can be executed without being read into context.

## Step 5: Test, Iterate, and Publish

This is where most of the value comes from. A skill you haven't tested against real prompts is a guess about what will work.

**The development loop:**

1. Validate the capability structure with `dn capability validate`
2. Launch the agent with your capability enabled — use `--print` with `--prompt` for headless testing, or launch the TUI for interactive testing. If you installed via symlink in Step 3, use `--capability` by name. Otherwise, use `--capabilities-dir` to point at the parent directory.
3. Edits to the skill are live (symlink install) — just re-run with a new prompt.

**What to test:**
- Run 2-3 realistic prompts — the kind of thing a real user would actually say, not abstract test inputs
- For domain-research capabilities, try different goals against the same target — the agent should behave differently based on the goal
- Read the transcripts, not just the outputs — the intermediate steps reveal whether the skill is making the agent waste time or skip important things

**How to iterate:**
- **Remove things** — if the agent doesn't use a section, cut it. Shorter skills are better skills.
- **Sharpen guidance** — if the agent went off-track, the skill wasn't clear enough at that decision point. Add a sentence explaining *why*, not a paragraph of rules.
- **Bundle repeated work** — if every test run independently produces the same helper script, bundle that script in the skill's `scripts/` directory. Write it once so every future invocation doesn't reinvent it.
- **Simplify the architecture** — if you wrote custom tools but the agent keeps falling back to bash, the tools aren't pulling their weight. Remove them.

Complexity should decrease over iterations, not increase. If your skill is getting longer with each round, you're likely adding patches instead of fixing root causes.

**When you're confident the capability works**, publish it to your organization's registry with `dn capability push`. Run `dn capability --help` for options around visibility, versioning, and CI sync.

To prove it works at scale, the platform provides a full evaluation pipeline: create tasks (challenge environments with verification), run evaluations (the capability against tasks), and optionally run optimization (automated iteration on the capability using reward signals). Use `dn task --help`, `dn evaluation --help`, and `dn optimize --help` to explore these. Start with manual testing — graduate to formal evaluation once the core skill is solid.

The current hosted optimization path is intentionally narrow: it optimizes agent `instructions` only. If the user is asking about broader self-improvement across skill descriptions, skill bodies, capability prompts, or runtime layers, read `capability-improvement.md` for the stack-aware design.

If the user is specifically asking how to replace the hardcoded default agent with a bundled SDK
capability, expose `@dreadnode`, or keep `default` only as a fallback label when no agent is
resolvable, read `runtime-default-capability.md`.

## Common Pitfalls

**Building before researching.** The best capabilities compose existing tools, not replace them. If `skopeo`, `nmap`, or `semgrep` already do the job, teach the agent to use them well — don't reimplement them in Python.

**Checklist skills for research problems.** Domain research needs hypotheses and approaches ("here are the classes of things to look for and how to test each one"), not Phase 1 → Phase 2 → Phase 3. A checklist produces the same behavior regardless of the user's goal. Hypotheses let the agent prioritize based on what the user actually wants.

**Duplicating reference docs.** If it's in `--help` or a file the agent can read, don't copy it into the skill. The skill's job is knowing what to reach for, not containing the reference material itself. Duplicated content drifts out of sync and wastes tokens.

**Over-engineering on the first pass.** Writing a Python Toolset, an MCP server, an agent definition, and three skills before testing anything is building a cathedral when you need a tent. Start with just a skill. Prove you need each additional component before adding it.

**Vague skill descriptions.** See "Writing good descriptions" above. The description is the single most important factor in whether a skill gets used — invest time in getting it right.
