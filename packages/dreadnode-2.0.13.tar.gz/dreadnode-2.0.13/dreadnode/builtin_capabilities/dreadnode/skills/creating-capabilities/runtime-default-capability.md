# Built-In `dreadnode` Capability Plan

This document defines the migration from a partly hardcoded default agent to a bundled SDK
capability named `dreadnode`.

It extends the stack-aware improvement design in `capability-improvement.md` and adds one
important UX rule:

- `default` is a fallback state meaning "no explicit agent selected"
- `dreadnode` is the real built-in core capability and agent

## Why this migration is worth doing

Today the runtime has most of the pieces needed for a real built-in default capability:

- the TUI already routes `@agent-name`
- the runtime registry already supports a real `default_capability_name`
- tool policy is already capability-owned through `AgentDef.tools`
- native SDK skills already exist outside any user capability

The part that is still too hardcoded is the core default-agent behavior:

- the core prompt lives in code
- the TUI injects a synthetic `default` agent row
- the most important default behavior is not versioned as a capability asset

That makes self-improvement harder than it needs to be. It also makes the user model messier than it
needs to be.

## Target model

The target runtime model is:

- `dreadnode` is a bundled SDK capability
- `dreadnode` has a primary agent also named `dreadnode`
- the runtime registry sets `default_capability_name = "dreadnode"`
- bare chat means "use the runtime default capability"
- `@dreadnode` explicitly routes one prompt to the built-in core agent
- `default` is not a real agent or capability name

### When `default` should appear

`default` should appear only when there is no resolvable explicit agent to show.

Examples:

- the bundled `dreadnode` capability failed to load
- the runtime is in a degraded or pre-load state
- a session has no explicit agent and the UI wants to show a safe placeholder before runtime info is
  available

Examples where `default` should **not** appear:

- the bundled `dreadnode` capability loaded successfully
- the runtime already knows the default capability agent name
- mention completion and agent picker UIs

So `default` stays as a fallback label, not a user-facing routing target when `dreadnode` exists.

## Ownership split

The clean design is still hybrid:

- host-owned runtime shell
- bundled built-in `dreadnode` capability

### Move into the bundled capability

- the primary default agent prompt
- capability-level system prompt text
- default agent tool rules
- core behavior skills that are really stable policy

### Keep in host code

- dynamic platform context injection
- CLI and slash-command introspection
- server-wired tools such as subagent routing and pooled skill tools
- default tool implementations themselves
- session persistence and runtime-info plumbing

This keeps the runtime honest. The code owns infrastructure; the built-in capability owns behavior.

## UX rules

### Bare chat

When the user sends a message without `@agent-name`, the runtime should resolve the registry default.

If the bundled `dreadnode` capability loaded, that means the message goes to `dreadnode`.

### Explicit `@dreadnode`

This is the user-facing way to say:

- use the built-in core agent on purpose
- do not rely on fallback resolution
- treat the core runtime capability like any other routable agent

### Legacy `default`

Legacy `"default"` values should be accepted only as compatibility input.

Rules:

- normalize `"default"` to `None` on read
- do not write `"default"` for new sessions
- do not show `"default"` in agent picker or mention UI once `dreadnode` is available

## Why this helps self-improvement

`autoagent`'s strongest lesson is that a harness improves best when:

- the editable surface is explicit
- the fixed boundary is explicit
- baseline comes first
- one general improvement is tested at a time
- keep and discard rules are strict

That maps much better onto a real built-in capability than onto scattered hardcoded strings.

For Dreadnode, the fixed boundary becomes:

- runtime shell code
- default tool implementations
- session and registry infrastructure

The editable runtime surface becomes:

- `dreadnode/agents/dreadnode.md`
- `dreadnode/system-prompt.md`
- built-in `dreadnode` skills
- selected policy files that are intentionally bundled with the capability

This is the right target for `dreadnode runtime improve`.

## Why add a native CLI skill too

The Hermes autonomous-agent skills are a useful reminder that some behavior should be packaged as a
skill, not baked into one giant prompt.

For the Dreadnode SDK, one missing native skill is a CLI boundary skill:

- when the user wants exact `dn` commands
- when the owning CLI group matters
- when the agent should answer with workflow-shaped CLI guidance instead of fuzzy prose

That should live as a native SDK skill, not inside the built-in `dreadnode` capability. It is part
of the host shell's operator affordances.

## Bundled capability shape

Suggested asset tree:

```text
dreadnode/
  builtin_capabilities/
    dreadnode/
      capability.yaml
      system-prompt.md
      agents/
        dreadnode.md
      skills/
        ...
```

Key properties:

- bundled with the SDK wheel
- loaded automatically by the runtime
- reserved name: local user capabilities should not silently shadow it

## Migration phases

### Phase 1: Bundle the capability

- add a packaged `dreadnode` capability directory inside the SDK
- add loader helpers for bundled capabilities
- add runtime tests proving it loads

### Phase 2: Make it the real runtime default

- auto-load the bundled capability during registry construction
- set `default_capability_name = "dreadnode"`
- keep current code-path fallback only if bundled capability load fails

### Phase 3: Remove user-facing synthetic default

- stop injecting synthetic `default` rows into agent picker data
- stop offering `@default` in mention completion
- keep `default` only as a placeholder label in failure or pre-load states

### Phase 4: Migrate prompt text

- move stable core behavior out of the hardcoded prompt and into the bundled capability
- keep dynamic prompt appendices in code
- reduce the code-owned core prompt to runtime-shell concerns only

### Phase 5: Runtime improvement

- point `dreadnode runtime improve` at the bundled `dreadnode` capability
- benchmark across multiple representative capabilities
- use the same outer-loop rules as capability improvement

## Session and API rules

New behavior:

- no explicit override: `agent=None`, `capability=None`
- explicit `@dreadnode`: `agent="dreadnode"`, `capability="dreadnode"`

Compatibility behavior:

- incoming `"default"` is normalized to no override
- restored `"default"` session state is normalized on hydrate
- new writes should never emit `"default"`

## TUI rules

### Agent picker

If `dreadnode` is loaded:

- show `dreadnode`
- do not show `default`

If no agent is available yet:

- show a `default` fallback entry so the UI still has a safe state label

### Context bar and session list

Display order:

1. explicit agent name
2. resolved default capability agent name
3. `default` only when nothing else can be resolved

## Improvement policy

The runtime improver should use the same conservative outer loop defined in
`capability-improvement.md`:

1. baseline first
2. one bounded change at a time
3. broad runtime suite, not one capability
4. holdout non-regression
5. simpler wins ties

This is the main reason to do the migration. Once the built-in runtime behavior is a capability, it
becomes inspectable, versionable, and optimizable with the same discipline as user capabilities.

## Practical rule

Do not think of this as "renaming default to dreadnode."

Think of it as:

- making the core runtime behavior real
- keeping `default` as a minimal fallback state only
- moving editable behavior into capability assets
- leaving infrastructure in code
