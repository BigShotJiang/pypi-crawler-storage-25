---
name: dreadnode-runtime-reference
description: "Reference for the bundled Dreadnode runtime: default capability behavior, key directories, capability layout, platform hierarchy, and practical help paths."
---
## Runtime Model

The SDK runtime has two layers:

- Host-owned runtime shell: dynamic platform context, built-in tools, and runtime wiring
- Bundled default capability: the internal `dreadnode` capability that provides the normal default agent behavior

When the bundled capability loads successfully, bare chat uses the `dreadnode` capability through the normal capability registry path. The string `default` is only a compatibility or degraded fallback label, not the primary runtime agent.

## Key Directories

- `~/.dreadnode/` — user configuration and local data
  - `~/.dreadnode/config.yaml` — platform profiles and authentication
  - `~/.dreadnode/capabilities/` — locally installed capabilities
  - `~/.dreadnode/cache/` — cached data and sessions
- `.dreadnode/` in the project root — project-local configuration
  - `.dreadnode/capabilities/` — project-scoped capabilities

## Capability Layout

A capability directory typically contains:

- `capability.yaml` — manifest with name, version, description
- `agents/` — agent definitions as markdown files with YAML frontmatter
- `tools/` — Python tool implementations
- `skills/` — `SKILL.md` workflow definitions
- `system-prompt.md` — optional capability-level prompt overlay

Capabilities can come from:

- bundled SDK assets
- local project or user capability directories
- platform/runtime sync

## Platform Hierarchy

The Dreadnode platform organizes work as:

- Organizations
- Workspaces
- Projects

Projects hold related traces, evaluations, and other artifacts inside a workspace.

## Default Runtime Behavior

The normal SDK default capability is the bundled `dreadnode` capability.

Update locations:

- main default-agent behavior:
  `packages/sdk/dreadnode/builtin_capabilities/dreadnode/agents/dreadnode.md`
- capability-wide overlay:
  `packages/sdk/dreadnode/builtin_capabilities/dreadnode/system-prompt.md`
- host-owned runtime shell and dynamic context:
  `packages/sdk/dreadnode/app/server/prompt.py`
- runtime assembly and default-capability wiring:
  `packages/sdk/dreadnode/app/server/app.py`

Use that split when explaining or editing the system:

- change behavior in the bundled capability
- change dynamic runtime context in the host prompt code
- change routing or binding behavior in the server runtime

## Getting Help

If the user asks about Dreadnode behavior and you are unsure:

1. Run `dreadnode --help` or `dreadnode <command> --help` for exact CLI usage.
2. Inspect capability manifests and agent markdown in capability directories.
3. Use the official docs at `https://docs.dreadnode.io` for product documentation.
