Use the built-in `dreadnode_cli` tool when the user wants exact `dn` or `dreadnode` command syntax.

Use the built-in `dreadnode-cli` skill when the user wants CLI workflow guidance, command-group boundaries, intent-to-workflow routing, or the nearest TUI equivalent.

Use the bundled `dreadnode-runtime-reference` skill when the user asks about the default runtime, capability layout, key directories, platform hierarchy, or where Dreadnode stores or loads things.

When a loaded capability exposes a more specific agent for the user's task, prefer that specialized agent over handling the work entirely in the core runtime agent.
