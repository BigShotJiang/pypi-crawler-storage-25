"""AI Red Team (AIRT) module.

Pre-configured attack functions that combine Samplers with Study for easy use.
For more control, use samplers directly from `dreadnode.samplers`.

LLM jailbreak attacks:
- prompt_attack: Beam search prompt refinement
- goat_attack: GOAT pattern with graph neighborhood search
- tap_attack: Tree of Attacks pattern
- crescendo_attack: Multi-turn progressive escalation attack
- pair_attack: PAIR iterative refinement attack
- rainbow_attack: Rainbow Teaming quality-diversity attack
- gptfuzzer_attack: GPTFuzzer mutation-based fuzzing attack
- autodan_turbo_attack: AutoDAN-Turbo lifelong strategy learning attack
- renellm_attack: ReNeLLM prompt rewriting and scenario nesting attack
- beast_attack: BEAST gradient-free beam search suffix attack
- drattack: DrAttack prompt decomposition and reconstruction attack
- deep_inception_attack: DeepInception nested scene hypnosis attack

Image adversarial attacks:
- simba_attack: Simple Black-box Attack
- nes_attack: Natural Evolution Strategies
- zoo_attack: Zeroth-Order Optimization
- hopskipjump_attack: HopSkipJump decision-based attack

Multimodal attacks:
- multimodal_attack: Transform-based multimodal probing (vision, audio, text)
"""

from dreadnode.airt.assessment import Assessment
from dreadnode.airt.autodan_turbo import autodan_turbo_attack
from dreadnode.airt.beast import beast_attack
from dreadnode.airt.crescendo import crescendo_attack
from dreadnode.airt.deep_inception import deep_inception_attack
from dreadnode.airt.drattack import drattack
from dreadnode.airt.goat import goat_attack
from dreadnode.airt.gptfuzzer import gptfuzzer_attack
from dreadnode.airt.image import (
    hopskipjump_attack,
    nes_attack,
    simba_attack,
    zoo_attack,
)
from dreadnode.airt.multimodal import multimodal_attack
from dreadnode.airt.pair import pair_attack
from dreadnode.airt.prompt import prompt_attack
from dreadnode.airt.rainbow import rainbow_attack
from dreadnode.airt.renellm import renellm_attack
from dreadnode.airt.tap import tap_attack

__all__ = [
    "Assessment",
    "autodan_turbo_attack",
    "beast_attack",
    "crescendo_attack",
    "deep_inception_attack",
    "drattack",
    "goat_attack",
    "gptfuzzer_attack",
    "hopskipjump_attack",
    "multimodal_attack",
    "nes_attack",
    "pair_attack",
    "prompt_attack",
    "rainbow_attack",
    "renellm_attack",
    "simba_attack",
    "tap_attack",
    "zoo_attack",
]
