"""Image adversarial attack wrappers.

Convenience functions that combine image samplers with Study for easy use.
For more control, use the samplers directly from `dreadnode.samplers`.
"""

from __future__ import annotations

import typing as t

from dreadnode.optimization import Study
from dreadnode.samplers import (
    HopSkipJumpSampler,
    NESSampler,
    SimBASampler,
    ZOOSampler,
)

if t.TYPE_CHECKING:
    from dreadnode.core.scorer import ScorersLike
    from dreadnode.core.types import Image
    from dreadnode.scorers.image import Norm


def simba_attack(
    original: Image,
    objective: ScorersLike[Image],
    *,
    theta: float = 0.1,
    num_masks: int = 500,
    norm: Norm = "l2",
    max_iterations: int = 10_000,
    seed: int | None = None,
) -> Study[Image]:
    """
    Create a SimBA (Simple Black-box Attack) study.

    Iteratively perturbs the image using random noise masks and retains
    perturbations that improve the adversarial objective.

    See: https://arxiv.org/abs/1805.12317

    Args:
        original: The original image to perturb.
        objective: Scorer(s) to evaluate adversarial success.
        theta: Perturbation step size.
        num_masks: Number of random masks to pre-generate.
        norm: Distance metric ('l2', 'l1', or 'linf').
        max_iterations: Maximum attack iterations.
        seed: Random seed for reproducibility.

    Returns:
        A configured Study instance.

    Example:
        ```python
        from dreadnode.airt import simba_attack
        from dreadnode.scorers import target_class

        study = simba_attack(
            original=my_image,
            objective=target_class(model, target_label=5),
            max_iterations=1000,
        )
        result = await study.run()
        ```
    """
    sampler = SimBASampler(
        original,
        theta=theta,
        num_masks=num_masks,
        norm=norm,
        max_iterations=max_iterations,
        seed=seed,
    )

    return Study(
        sampler=sampler,
        objective=objective,
        direction="maximize",
        n_iterations=max_iterations,
        max_trials=max_iterations,
        tags=["airt"],
    )


def nes_attack(
    original: Image,
    objective: ScorersLike[Image],
    *,
    learning_rate: float = 0.01,
    num_samples: int = 64,
    sigma: float = 0.001,
    max_iterations: int = 100,
    seed: int | None = None,
) -> Study[Image]:
    """
    Create a NES (Natural Evolution Strategies) attack study.

    Estimates gradients by probing with random perturbations and uses
    Adam optimizer for updates.

    Args:
        original: The original image to perturb.
        objective: Scorer(s) to evaluate adversarial success.
        learning_rate: Adam optimizer learning rate.
        num_samples: Number of samples for gradient estimation.
        sigma: Noise scale for gradient estimation.
        max_iterations: Maximum attack iterations.
        seed: Random seed for reproducibility.

    Returns:
        A configured Study instance.

    Example:
        ```python
        from dreadnode.airt import nes_attack
        from dreadnode.scorers import target_class

        study = nes_attack(
            original=my_image,
            objective=target_class(model, target_label=5),
            max_iterations=100,
        )
        result = await study.run()
        ```
    """
    sampler = NESSampler(
        original,
        learning_rate=learning_rate,
        num_samples=num_samples,
        sigma=sigma,
        max_iterations=max_iterations,
        seed=seed,
    )

    return Study(
        sampler=sampler,
        objective=objective,
        direction="maximize",
        n_iterations=max_iterations,
        max_trials=max_iterations,
        tags=["airt"],
    )


def zoo_attack(
    original: Image,
    objective: ScorersLike[Image],
    *,
    learning_rate: float = 0.01,
    num_samples: int = 128,
    epsilon: float = 0.01,
    max_iterations: int = 1000,
    seed: int | None = None,
) -> Study[Image]:
    """
    Create a ZOO (Zeroth-Order Optimization) attack study.

    Uses coordinate-wise gradient estimation with Adam optimizer.

    See: https://arxiv.org/abs/1708.03999

    Args:
        original: The original image to perturb.
        objective: Scorer(s) to evaluate adversarial success.
        learning_rate: Adam optimizer learning rate.
        num_samples: Number of coordinates to sample per iteration.
        epsilon: Step size for finite difference gradient estimation.
        max_iterations: Maximum attack iterations.
        seed: Random seed for reproducibility.

    Returns:
        A configured Study instance.

    Example:
        ```python
        from dreadnode.airt import zoo_attack
        from dreadnode.scorers import target_class

        study = zoo_attack(
            original=my_image,
            objective=target_class(model, target_label=5),
            max_iterations=500,
        )
        result = await study.run()
        ```
    """
    sampler = ZOOSampler(
        original,
        learning_rate=learning_rate,
        num_samples=num_samples,
        epsilon=epsilon,
        max_iterations=max_iterations,
        seed=seed,
    )

    return Study(
        sampler=sampler,
        objective=objective,
        direction="maximize",
        n_iterations=max_iterations,
        max_trials=max_iterations,
        tags=["airt"],
    )


def hopskipjump_attack(
    source: Image,
    objective: ScorersLike[Image],
    *,
    adversarial: Image | None = None,
    adversarial_threshold: float = 0.0,
    norm: Norm = "l2",
    theta: float = 0.01,
    max_iterations: int = 1000,
    seed: int | None = None,
) -> Study[Image]:
    """
    Create a HopSkipJump attack study.

    A decision-based attack that uses binary search to find the decision
    boundary and gradient estimation to minimize the perturbation distance.

    See: https://arxiv.org/abs/1904.02144

    Args:
        source: The original, unperturbed image.
        objective: Scorer(s) to evaluate adversarial success.
        adversarial: Optional initial adversarial example.
        adversarial_threshold: Score threshold for adversarial classification.
        norm: Distance metric ('l2', 'l1', or 'linf').
        theta: Relative size of perturbation for gradient estimation.
        max_iterations: Maximum attack iterations.
        seed: Random seed for reproducibility.

    Returns:
        A configured Study instance.

    Example:
        ```python
        from dreadnode.airt import hopskipjump_attack
        from dreadnode.scorers import target_class

        study = hopskipjump_attack(
            source=my_image,
            objective=target_class(model, target_label=5),
            max_iterations=100,
        )
        result = await study.run()
        ```
    """
    sampler = HopSkipJumpSampler(
        source,
        adversarial=adversarial,
        adversarial_threshold=adversarial_threshold,
        norm=norm,
        theta=theta,
        max_iterations=max_iterations,
        seed=seed,
    )

    return Study(
        sampler=sampler,
        objective=objective,
        direction="maximize",
        n_iterations=max_iterations,
        max_trials=max_iterations,
        tags=["airt"],
    )
