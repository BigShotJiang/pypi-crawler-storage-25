"""Tinker-based reinforcement learning runtimes.

This module provides a small hosted-training-oriented RL runtime surface for
Tinker. Async training is organized around rollout groups:

- ``one_step_off_async`` keeps a single future rollout group in flight, which
  bounds policy staleness to one training step.
- ``fully_async`` widens the same pipeline to multiple queued rollout groups,
  allowing bounded off-policy training with explicit staleness control.
"""

from __future__ import annotations

import os
from collections import deque
from concurrent.futures import Future, ThreadPoolExecutor
from dataclasses import dataclass, field
from typing import Any, Literal, Protocol

TinkerRLExecutionMode = Literal["sync", "one_step_off_async", "fully_async"]


@dataclass
class TinkerRLConfig:
    """Configuration for Tinker-based RL training."""

    base_model: str = "meta-llama/Llama-3.1-8B-Instruct"
    algorithm: Literal["importance_sampling", "ppo"] = "importance_sampling"
    lora_rank: int = 16
    steps: int = 1
    num_rollouts: int = 8
    batch_size: int = 8
    learning_rate: float = 1e-4
    weight_sync_interval: int = 1
    checkpoint_interval: int = 1
    max_new_tokens: int = 128
    temperature: float = 0.0
    stop: list[str] = field(default_factory=list)
    execution_mode: TinkerRLExecutionMode = "sync"
    max_steps_off_policy: int = 1

    def __post_init__(self) -> None:
        """Validate RL configuration."""
        if self.algorithm not in {"importance_sampling", "ppo"}:
            raise ValueError("algorithm must be importance_sampling or ppo")
        if self.execution_mode not in {"sync", "one_step_off_async", "fully_async"}:
            raise ValueError(
                "execution_mode must be sync, one_step_off_async, or fully_async"
            )
        if self.lora_rank <= 0:
            raise ValueError("lora_rank must be positive")
        if self.steps <= 0:
            raise ValueError("steps must be positive")
        if self.num_rollouts <= 0:
            raise ValueError("num_rollouts must be positive")
        if self.batch_size <= 0:
            raise ValueError("batch_size must be positive")
        if self.learning_rate <= 0:
            raise ValueError("learning_rate must be positive")
        if self.weight_sync_interval <= 0:
            raise ValueError("weight_sync_interval must be positive")
        if self.checkpoint_interval <= 0:
            raise ValueError("checkpoint_interval must be positive")
        if self.max_new_tokens <= 0:
            raise ValueError("max_new_tokens must be positive")
        if self.temperature < 0:
            raise ValueError("temperature must be non-negative")
        if self.max_steps_off_policy <= 0:
            raise ValueError("max_steps_off_policy must be positive")
        if (
            self.execution_mode == "one_step_off_async"
            and self.max_steps_off_policy != 1
        ):
            raise ValueError(
                "one_step_off_async currently supports max_steps_off_policy=1 only"
            )


@dataclass
class TinkerRLRolloutGroup:
    """One generated group of RL rollouts ready for training."""

    generation_step: int
    model_version: int
    scheduled_at_training_step: int
    datums: list[Any]
    rewards: list[float]

    @property
    def num_rollouts(self) -> int:
        """Number of rollouts represented by the group."""
        return len(self.rewards)


@dataclass
class TinkerRLTrainingResult:
    """Summary returned by the Tinker RL runtime."""

    metrics: dict[str, int | float]
    checkpoints: list[str]


class RolloutGroupGenerator(Protocol):
    """Callable that generates one rollout group for RL training."""

    def __call__(
        self,
        *,
        sampling_client: Any,
        tokenizer: Any,
        generation_step: int,
        model_version: int,
        scheduled_at_training_step: int,
    ) -> TinkerRLRolloutGroup: ...


def train_tinker_rl(
    *,
    tinker: Any,
    config: TinkerRLConfig,
    job_id: str,
    generate_group: RolloutGroupGenerator,
) -> TinkerRLTrainingResult:
    """Train a Tinker RL job using the configured execution mode."""

    service_client = tinker.ServiceClient(base_url=os.environ.get("TINKER_BASE_URL"))
    training_client = service_client.create_lora_training_client(
        base_model=config.base_model,
        rank=config.lora_rank,
    )
    tokenizer = training_client.get_tokenizer()
    adam_params = tinker.AdamParams(
        learning_rate=config.learning_rate,
        beta1=0.9,
        beta2=0.95,
        eps=1e-8,
    )
    if config.execution_mode in {"one_step_off_async", "fully_async"}:
        return _train_async_pipeline(
            training_client=training_client,
            tokenizer=tokenizer,
            adam_params=adam_params,
            config=config,
            job_id=job_id,
            generate_group=generate_group,
        )
    return _train_sync(
        training_client=training_client,
        tokenizer=tokenizer,
        adam_params=adam_params,
        config=config,
        job_id=job_id,
        generate_group=generate_group,
    )


def _train_sync(
    *,
    training_client: Any,
    tokenizer: Any,
    adam_params: Any,
    config: TinkerRLConfig,
    job_id: str,
    generate_group: RolloutGroupGenerator,
) -> TinkerRLTrainingResult:
    """Run synchronous RL training."""

    checkpoint_paths: list[str] = []
    reward_history: list[float] = []
    model_version = 0
    last_synced_model_version = 0
    weight_sync_count = 0
    sampling_client: Any | None = None

    for step in range(1, config.steps + 1):
        if sampling_client is None or (step - 1) % config.weight_sync_interval == 0:
            model_version += 1
            sampling_client = training_client.save_weights_and_get_sampling_client(
                name=f"training-job-{job_id}-step-{step}"
            )
            last_synced_model_version = model_version
            weight_sync_count += 1

        group = generate_group(
            sampling_client=sampling_client,
            tokenizer=tokenizer,
            generation_step=step,
            model_version=model_version,
            scheduled_at_training_step=step - 1,
        )
        _require_datums(group)
        training_client.forward_backward(group.datums, loss_fn=config.algorithm).result()
        training_client.optim_step(adam_params).result()

        reward_history.extend(group.rewards)
        if step % config.checkpoint_interval == 0:
            checkpoint = training_client.save_weights_for_sampler(
                f"training-job-{job_id}-step-{step}"
            ).result()
            checkpoint_paths.append(checkpoint.path)

    if not checkpoint_paths:
        checkpoint = training_client.save_weights_for_sampler(
            f"training-job-{job_id}-final"
        ).result()
        checkpoint_paths.append(checkpoint.path)

    return TinkerRLTrainingResult(
        metrics=_build_training_metrics(
            reward_history=reward_history,
            steps=config.steps,
            generation_step=config.steps,
            training_step=config.steps,
            model_version=model_version,
            last_synced_model_version=last_synced_model_version,
            weight_sync_count=weight_sync_count,
            max_staleness_observed=0,
        ),
        checkpoints=checkpoint_paths,
    )


def _train_async_pipeline(
    *,
    training_client: Any,
    tokenizer: Any,
    adam_params: Any,
    config: TinkerRLConfig,
    job_id: str,
    generate_group: RolloutGroupGenerator,
) -> TinkerRLTrainingResult:
    """Run bounded async RL training over queued rollout groups."""

    checkpoint_paths: list[str] = []
    reward_history: list[float] = []
    training_step = 0
    generation_step = 0
    model_version = 1
    last_synced_model_version = model_version
    weight_sync_count = 1
    max_staleness_observed = 0

    sampling_client = training_client.save_weights_and_get_sampling_client(
        name=f"training-job-{job_id}-step-1"
    )
    current_group = generate_group(
        sampling_client=sampling_client,
        tokenizer=tokenizer,
        generation_step=1,
        model_version=model_version,
        scheduled_at_training_step=0,
    )
    generation_step = 1
    next_generation_step = 2
    pending_groups: deque[Future[TinkerRLRolloutGroup]] = deque()
    max_pending_generation_groups = 0

    with ThreadPoolExecutor(max_workers=max(1, config.max_steps_off_policy)) as executor:
        for step in range(1, config.steps + 1):
            while (
                next_generation_step <= config.steps
                and len(pending_groups) < config.max_steps_off_policy
            ):
                pending_groups.append(
                    executor.submit(
                        generate_group,
                        sampling_client=sampling_client,
                        tokenizer=tokenizer,
                        generation_step=next_generation_step,
                        model_version=model_version,
                        scheduled_at_training_step=step,
                    )
                )
                generation_step = max(generation_step, next_generation_step)
                next_generation_step += 1
                max_pending_generation_groups = max(
                    max_pending_generation_groups,
                    len(pending_groups),
                )

            _require_datums(current_group)
            forward_backward_future = training_client.forward_backward(
                current_group.datums,
                loss_fn=config.algorithm,
            )
            optim_step_future = training_client.optim_step(adam_params)
            forward_backward_future.result()
            optim_step_future.result()

            training_step = step
            reward_history.extend(current_group.rewards)
            staleness = step - current_group.scheduled_at_training_step
            max_staleness_observed = max(max_staleness_observed, staleness)

            if step % config.checkpoint_interval == 0:
                checkpoint = training_client.save_weights_for_sampler(
                    f"training-job-{job_id}-step-{step}"
                ).result()
                checkpoint_paths.append(checkpoint.path)

            if not pending_groups:
                continue

            next_group = pending_groups.popleft().result()
            if step % config.weight_sync_interval == 0:
                model_version += 1
                sampling_client = training_client.save_weights_and_get_sampling_client(
                    name=f"training-job-{job_id}-step-{step + 1}"
                )
                last_synced_model_version = model_version
                weight_sync_count += 1
            current_group = next_group

    if not checkpoint_paths:
        checkpoint = training_client.save_weights_for_sampler(
            f"training-job-{job_id}-final"
        ).result()
        checkpoint_paths.append(checkpoint.path)

    return TinkerRLTrainingResult(
        metrics=_build_training_metrics(
            reward_history=reward_history,
            steps=config.steps,
            generation_step=generation_step,
            training_step=training_step,
            model_version=model_version,
            last_synced_model_version=last_synced_model_version,
            weight_sync_count=weight_sync_count,
            max_staleness_observed=max_staleness_observed,
            max_pending_generation_groups=max_pending_generation_groups,
        ),
        checkpoints=checkpoint_paths,
    )


def _require_datums(group: TinkerRLRolloutGroup) -> None:
    """Ensure a generated rollout group contains trainable datums."""

    if group.datums:
        return
    raise RuntimeError("No RL rollouts were generated for training")


def _build_training_metrics(
    *,
    reward_history: list[float],
    steps: int,
    generation_step: int,
    training_step: int,
    model_version: int,
    last_synced_model_version: int,
    weight_sync_count: int,
    max_staleness_observed: int,
    max_pending_generation_groups: int = 0,
) -> dict[str, int | float]:
    """Return hosted-job-friendly RL metrics."""

    reward_mean = (
        float(sum(reward_history) / len(reward_history)) if reward_history else 0.0
    )
    reward_max = float(max(reward_history)) if reward_history else 0.0
    reward_min = float(min(reward_history)) if reward_history else 0.0
    return {
        "train/steps": steps,
        "train/num_rollouts": len(reward_history),
        "train/reward_mean": reward_mean,
        "train/reward_max": reward_max,
        "train/reward_min": reward_min,
        "async/generation_step": generation_step,
        "async/training_step": training_step,
        "async/model_version": model_version,
        "async/last_synced_model_version": last_synced_model_version,
        "async/weight_sync_count": weight_sync_count,
        "async/max_staleness_observed": max_staleness_observed,
        "async/max_pending_generation_groups": max_pending_generation_groups,
    }


__all__ = [
    "RolloutGroupGenerator",
    "TinkerRLConfig",
    "TinkerRLExecutionMode",
    "TinkerRLRolloutGroup",
    "TinkerRLTrainingResult",
    "train_tinker_rl",
]
