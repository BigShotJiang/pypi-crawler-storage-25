import typing as t
from abc import ABC, abstractmethod

T = t.TypeVar("T")


class Environment(ABC):
    """
    Base class for agent execution environments.

    An environment manages the lifecycle of an external system
    (container, kernel, API connection, etc.).

    Example:
        env = DockerEnvironment(image="python:3.11")
        agent = Agent(name="runner", tools=[bash_tool])
        result = await env.run(agent.run("Run the tests"))
    """

    @abstractmethod
    async def setup(self) -> dict[str, t.Any]:
        """
        Initialize the environment.

        Returns:
            Context dict with environment state (e.g., container ID, paths).
        """
        ...

    @abstractmethod
    async def teardown(self) -> None:
        """Clean up the environment."""
        ...

    async def reset(self) -> dict[str, t.Any]:
        """Reset for a new attempt. Default: teardown + setup."""
        await self.teardown()
        return await self.setup()

    async def get_state(self) -> dict[str, t.Any]:
        """Get current state (for debugging/logging)."""
        return {}

    async def __aenter__(self) -> "Environment":
        await self.setup()
        return self

    async def __aexit__(self, *args: object) -> None:
        await self.teardown()

    async def run(self, coro: t.Awaitable[T]) -> T:
        """
        Run a coroutine within this environment.

        Sets up the environment, awaits the coroutine, and tears down afterward.

        Args:
            coro: The coroutine to run (e.g., agent.run("goal")).

        Returns:
            The coroutine's result.
        """
        try:
            await self.setup()
            return await coro
        finally:
            await self.teardown()
