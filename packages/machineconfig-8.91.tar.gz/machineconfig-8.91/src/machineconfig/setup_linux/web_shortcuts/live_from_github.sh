#!/bin/bash

# @ https://bit.ly/cfglg

. <( curl -sSL "https://raw.githubusercontent.com/thisismygitrepo/machineconfig/main/src/machineconfig/setup_linux/uv.sh")
. <( curl -sSL "https://raw.githubusercontent.com/thisismygitrepo/machineconfig/main/src/machineconfig/scripts/linux/wrap_mcfg")

alias mcfg='$HOME/.local/bin/uvx --python 3.14 --from "git+https://github.com/thisismygitrepo/machineconfig" mcfg'

alias d='wrap_in_shell_script mcfg devops'
alias c='wrap_in_shell_script mcfg cloud'
alias a='wrap_in_shell_script mcfg agents'
alias fx='wrap_in_shell_script mcfg cloud ftpx'
alias f='wrap_in_shell_script mcfg fire'
alias rr='wrap_in_shell_script mcfg croshell'
alias u='wrap_in_shell_script mcfg utils'
alias t='wrap_in_shell_script mcfg terminal'
seek() { "$HOME/.local/bin/uvx" --python 3.14 --from "git+https://github.com/thisismygitrepo/machineconfig" seek "$@"; }
alias s='wrap_in_shell_script seek'

alias devops='mcfg devops'
alias cloud='mcfg cloud'
alias agents='mcfg agents'
alias ftpx='mcfg cloud ftpx'
alias fire='mcfg fire'
alias croshell='mcfg croshell'
alias utils='mcfg utils'
alias terminal='mcfg terminal'


echo "mcfg command aliases are now defined in this shell session."
