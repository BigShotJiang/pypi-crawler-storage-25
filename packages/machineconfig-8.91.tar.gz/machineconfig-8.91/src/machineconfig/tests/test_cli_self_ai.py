from pathlib import Path
import subprocess

import pytest
from typer.testing import CliRunner

from machineconfig.scripts.python.helpers.helpers_agents.fire_agents_helper_types import DEFAULT_SEAPRATOR
from machineconfig.scripts.python.helpers.helpers_devops import cli_self
from machineconfig.scripts.python.helpers.helpers_devops.cli_self_ai import app as cli_self_ai_app
from machineconfig.scripts.python.helpers.helpers_devops.cli_self_ai import update_installer as update_installer_module
from machineconfig.scripts.python.helpers.helpers_devops.cli_self_ai import update_test as update_test_module


def _init_git_repo(repo_root: Path) -> None:
    subprocess.run(
        ["git", "init", "-q"],
        cwd=repo_root,
        check=True,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )


def test_self_help_shows_ai_only_for_developers(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    runner = CliRunner()
    home_root = tmp_path.joinpath("home", "alex")
    monkeypatch.setattr(cli_self.Path, "home", lambda: home_root)

    result_without_repo = runner.invoke(cli_self.get_app(), ["--help"])

    assert result_without_repo.exit_code == 0
    assert "Developer AI workflows" not in result_without_repo.stdout

    repo_root = home_root.joinpath("code", "machineconfig")
    repo_root.mkdir(parents=True, exist_ok=True)
    repo_root.joinpath("pyproject.toml").write_text("[project]\nname = 'machineconfig'\n", encoding="utf-8")

    result_with_repo = runner.invoke(cli_self.get_app(), ["a", "--help"])

    assert result_with_repo.exit_code == 0
    assert "update-installer" in result_with_repo.stdout
    assert "update-test" in result_with_repo.stdout


def test_update_installer_uses_embedded_defaults(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    home_root = tmp_path.joinpath("home", "alex")
    repo_root = home_root.joinpath("code", "machineconfig")
    repo_root.mkdir(parents=True, exist_ok=True)
    repo_root.joinpath("pyproject.toml").write_text("[project]\nname = 'machineconfig'\n", encoding="utf-8")

    captured: dict[str, object] = {}

    def fake_agents_create_impl(**kwargs: object) -> None:
        captured.update(kwargs)

    monkeypatch.setattr(update_installer_module.Path, "home", lambda: home_root)
    monkeypatch.setattr(update_installer_module, "agents_create_impl", fake_agents_create_impl)

    update_installer_module.update_installer()

    job_name = "updateInstallerData"
    agents_dir = repo_root.joinpath(".ai", "agents", job_name)

    assert captured["agent"] == "codex"
    assert captured["host"] == "local"
    assert captured["context"] is None
    assert captured["context_path"] == str(repo_root.joinpath("src", "machineconfig", "jobs", "installer", "installer_data.json"))
    assert captured["separator"] == "    },\n    {"
    assert captured["agent_load"] == 10
    assert captured["prompt"] == update_installer_module.UPDATE_INSTALLER_PROMPT
    assert captured["prompt_path"] is None
    assert captured["prompt_name"] is None
    assert captured["job_name"] == job_name
    assert captured["output_path"] == str(agents_dir.joinpath("layout.json"))
    assert captured["agents_dir"] == str(agents_dir)
    assert captured["interactive"] is False


def test_update_installer_allows_overriding_default_sources_and_agent(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    home_root = tmp_path.joinpath("home", "alex")
    repo_root = home_root.joinpath("code", "machineconfig")
    repo_root.mkdir(parents=True, exist_ok=True)
    repo_root.joinpath("pyproject.toml").write_text("[project]\nname = 'machineconfig'\n", encoding="utf-8")

    captured: dict[str, object] = {}

    def fake_agents_create_impl(**kwargs: object) -> None:
        captured.update(kwargs)

    monkeypatch.setattr(update_installer_module.Path, "home", lambda: home_root)
    monkeypatch.setattr(update_installer_module, "agents_create_impl", fake_agents_create_impl)

    update_installer_module.update_installer(agent="gemini", context="context body", prompt="prompt body", job_name="customJob")

    custom_agents_dir = repo_root.joinpath(".ai", "agents", "customJob")

    assert captured["agent"] == "gemini"
    assert captured["context"] == "context body"
    assert captured["context_path"] is None
    assert captured["prompt"] == "prompt body"
    assert captured["prompt_path"] is None
    assert captured["job_name"] == "customJob"
    assert captured["agents_dir"] == str(custom_agents_dir)
    assert captured["output_path"] == str(custom_agents_dir.joinpath("layout.json"))


def test_update_test_uses_generated_repo_context(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    home_root = tmp_path.joinpath("home", "alex")
    repo_root = home_root.joinpath("code", "machineconfig")
    repo_root.mkdir(parents=True, exist_ok=True)
    repo_root.joinpath("pyproject.toml").write_text("[project]\nname = 'machineconfig'\n", encoding="utf-8")
    repo_root.joinpath(".gitignore").write_text("ignored.py\nignored_dir/\n", encoding="utf-8")
    repo_root.joinpath("pkg", "alpha.py").parent.mkdir(parents=True, exist_ok=True)
    repo_root.joinpath("pkg", "alpha.py").write_text("alpha = 1\n", encoding="utf-8")
    repo_root.joinpath("src", "keep.py").parent.mkdir(parents=True, exist_ok=True)
    repo_root.joinpath("src", "keep.py").write_text("keep = 1\n", encoding="utf-8")
    repo_root.joinpath("tests", "skip.py").parent.mkdir(parents=True, exist_ok=True)
    repo_root.joinpath("tests", "skip.py").write_text("skip = True\n", encoding="utf-8")
    repo_root.joinpath("src", "machineconfig", "tests", "skip_nested.py").parent.mkdir(parents=True, exist_ok=True)
    repo_root.joinpath("src", "machineconfig", "tests", "skip_nested.py").write_text("skip_nested = True\n", encoding="utf-8")
    repo_root.joinpath(".ai", "skip.py").parent.mkdir(parents=True, exist_ok=True)
    repo_root.joinpath(".ai", "skip.py").write_text("skip_ai = True\n", encoding="utf-8")
    repo_root.joinpath(".venv", "skip.py").parent.mkdir(parents=True, exist_ok=True)
    repo_root.joinpath(".venv", "skip.py").write_text("skip_venv = True\n", encoding="utf-8")
    repo_root.joinpath("ignored.py").write_text("ignored = True\n", encoding="utf-8")
    repo_root.joinpath("ignored_dir", "skip.py").parent.mkdir(parents=True, exist_ok=True)
    repo_root.joinpath("ignored_dir", "skip.py").write_text("ignored_dir = True\n", encoding="utf-8")
    _init_git_repo(repo_root)

    captured: dict[str, object] = {}

    def fake_agents_create_impl(**kwargs: object) -> None:
        captured.update(kwargs)

    monkeypatch.setattr(update_test_module.Path, "home", lambda: home_root)
    monkeypatch.setattr(update_test_module, "agents_create_impl", fake_agents_create_impl)

    update_test_module.update_test()

    job_name = "updateTests"
    agents_dir = repo_root.joinpath(".ai", "agents", job_name)
    context_path = agents_dir.joinpath("context.md")
    context_content = context_path.read_text(encoding="utf-8")

    assert captured["agent"] == "codex"
    assert captured["host"] == "local"
    assert captured["context"] == context_content
    assert captured["context_path"] is None
    assert captured["separator"] == DEFAULT_SEAPRATOR
    assert captured["agent_load"] == 10
    assert captured["prompt"] == update_test_module.UPDATE_TEST_PROMPT
    assert captured["prompt_path"] is None
    assert captured["prompt_name"] is None
    assert captured["job_name"] == job_name
    assert captured["output_path"] == str(agents_dir.joinpath("layout.json"))
    assert captured["agents_dir"] == str(agents_dir)
    assert captured["interactive"] is False
    expected_context_entries = ["pkg/alpha.py", "src/keep.py"]
    assert context_content == DEFAULT_SEAPRATOR.join(expected_context_entries)
    assert "alpha = 1" not in context_content
    assert "keep = 1" not in context_content
    assert "tests/skip.py" not in context_content
    assert "src/machineconfig/tests/skip_nested.py" not in context_content
    assert ".ai/skip.py" not in context_content
    assert ".venv/skip.py" not in context_content
    assert "ignored.py" not in context_content
    assert "ignored_dir/skip.py" not in context_content


def test_update_test_help_hides_generated_context_controls() -> None:
    runner = CliRunner()

    result = runner.invoke(cli_self_ai_app.get_app(), ["update-test", "--help"])

    assert result.exit_code == 0
    assert "Create an agents layout for writing tests from repo Python sources." in result.stdout
    assert "Context as a direct string" not in result.stdout
    assert "Context file or folder path" not in result.stdout
    assert "Separator for context" not in result.stdout
    assert ".ai/todo" not in result.stdout
