"""
This script Takes away all config files from the computer, place them in one directory
`dotfiles`, and create symlinks to those files from thier original locations.

"""

from machineconfig.utils.links import ActionType, OperationRecord, OperationResult
from rich.console import Console
from rich.panel import Panel
from rich.pretty import Pretty
from rich.text import Text
from rich.table import Table

from machineconfig.utils.path_extended import PathExtended
from machineconfig.utils.links import symlink_map, copy_map
from machineconfig.profile.create_links_export import DIRECTION_STRICT, ON_CONFLICT_STRICT
from machineconfig.profile.dotfiles_mapper import (
    LIBRARY_MAPPER_PATH,
    USER_MAPPER_PATH,
    MapperDocument,
    OsField,
    OsName,
    VALID_OS_VALUES,
    load_dotfiles_mapper,
)
from machineconfig.utils.source_of_truth import CONFIG_ROOT

import platform
import subprocess
import io
from typing import Any, TypedDict, Literal, TypeAlias


system = platform.system()  # Linux or Windows
ERROR_LIST: list[Any] = []  # append to this after every exception captured.
SYSTEM = system.lower()

console = Console()

REPO_ALIASES = {
    "l": "library",
    "i": "user",
}
ON_CONFLICT_UP_COPY_MAP: dict[ON_CONFLICT_STRICT, ON_CONFLICT_STRICT] = {
    "throw-error": "throw-error",
    "overwrite-self-managed": "overwrite-default-path",
    "backup-self-managed": "backup-default-path",
    "overwrite-default-path": "overwrite-self-managed",
    "backup-default-path": "backup-self-managed",
}


def _normalize_os_name(value: str) -> OsName:
    token = value.strip().lower()
    if token not in VALID_OS_VALUES:
        expected_values = ", ".join(sorted(VALID_OS_VALUES))
        raise ValueError(f"Unsupported operating system: {value!r}. Expected one of: {expected_values}.")
    return token


def _normalize_repo_name(value: str) -> str:
    return REPO_ALIASES.get(value.strip().lower(), value.strip().lower())


def _parse_os_field(os_field: OsField) -> set[OsName]:
    return set(os_field)


def _resolve_self_managed_path(path_value: str) -> PathExtended:
    return PathExtended(path_value.replace("CONFIG_ROOT", CONFIG_ROOT.as_posix())).expanduser().absolute()


def _is_public_self_managed_path(path_value: str) -> bool:
    config_root = PathExtended(CONFIG_ROOT).expanduser().absolute()
    resolved_path = _resolve_self_managed_path(path_value)
    return resolved_path == config_root or resolved_path.is_relative_to(config_root)


class ConfigMapper(TypedDict):
    file_name: str
    config_file_default_path: str
    config_file_self_managed_path: str
    contents: bool | None
    copy: bool | None
    os: OsField
class MapperFileData(TypedDict):
    public: dict[str, list[ConfigMapper]]
    private: dict[str, list[ConfigMapper]]

RepoLoose: TypeAlias = Literal["user", "library", "all"]


def read_mapper(repo: RepoLoose) -> MapperFileData:
    repo_key = _normalize_repo_name(repo)
    match repo_key:
        case "user":
            mapper_path = USER_MAPPER_PATH
        case "library":
            mapper_path = LIBRARY_MAPPER_PATH
        case "all":
            # Merge both mappers
            if not USER_MAPPER_PATH.exists():
                user_mapper: MapperFileData = {"public": {}, "private": {}}
            else:
                user_mapper = read_mapper(repo="user")
            library_mapper = read_mapper(repo="library")
            merged_public: dict[str, list[ConfigMapper]] = {**library_mapper["public"], **user_mapper["public"]}
            merged_private: dict[str, list[ConfigMapper]] = {**library_mapper["private"], **user_mapper["private"]}
            return {"public": merged_public, "private": merged_private}
        case _:
            raise ValueError(f"Unsupported repo value: {repo}")
    mapper_data: MapperDocument = load_dotfiles_mapper(mapper_path)
    public: dict[str, list[ConfigMapper]] = {}
    private: dict[str, list[ConfigMapper]] = {}
    normalized_system = _normalize_os_name(SYSTEM)
    for program_key, program_map in mapper_data.items():
        for file_name, file_base in program_map.items():
            os_values = _parse_os_field(file_base["os"])
            if normalized_system not in os_values:
                continue
            file_map: ConfigMapper = {
                "file_name": file_name,
                "config_file_default_path": file_base["original"],
                "config_file_self_managed_path": file_base["self_managed"],
                "contents": file_base.get("contents"),
                "copy": file_base.get("copy"),
                "os": file_base["os"],
            }
            if _is_public_self_managed_path(file_map["config_file_self_managed_path"]):
                if program_key not in public:
                    public[program_key] = []
                public[program_key].append(file_map)
            else:
                if program_key not in private:
                    private[program_key] = []
                private[program_key].append(file_map)
    return {"public": public, "private": private}


def _resolve_mapper_paths(a_mapper: ConfigMapper) -> tuple[PathExtended, PathExtended]:
    config_file_default_path = PathExtended(a_mapper["config_file_default_path"]).expanduser().absolute()
    config_file_self_managed_path = _resolve_self_managed_path(a_mapper["config_file_self_managed_path"])
    return config_file_default_path, config_file_self_managed_path


def _get_source_label(direction: DIRECTION_STRICT) -> Literal["default", "self-managed"]:
    if direction == "up":
        return "default"
    return "self-managed"


def _iter_operation_paths(
    config_file_default_path: PathExtended,
    config_file_self_managed_path: PathExtended,
    contents: bool,
    direction: DIRECTION_STRICT,
) -> list[tuple[PathExtended, PathExtended]]:
    source_root = config_file_default_path if direction == "up" else config_file_self_managed_path
    source_label = _get_source_label(direction)
    if not source_root.exists():
        raise FileNotFoundError(f"{direction} sync requires existing {source_label} path: {source_root}")
    if not contents:
        return [(config_file_default_path, config_file_self_managed_path)]
    if not source_root.is_dir():
        raise NotADirectoryError(f"{direction} sync expects a directory for contents mapper: {source_root}")
    source_children = sorted(source_root.glob("*"), key=lambda path: path.name)
    return [
        (
            config_file_default_path.joinpath(source_child.name),
            config_file_self_managed_path.joinpath(source_child.name),
        )
        for source_child in source_children
    ]


def _run_directional_operation(
    config_file_default_path: PathExtended,
    config_file_self_managed_path: PathExtended,
    on_conflict: ON_CONFLICT_STRICT,
    method: Literal["symlink", "copy"],
    direction: DIRECTION_STRICT,
) -> OperationResult:
    if method == "copy" and direction == "up":
        return copy_map(
            config_file_default_path=config_file_self_managed_path,
            config_file_self_managed_path=config_file_default_path,
            on_conflict=ON_CONFLICT_UP_COPY_MAP[on_conflict],
        )
    if method == "copy":
        return copy_map(
            config_file_default_path=config_file_default_path,
            config_file_self_managed_path=config_file_self_managed_path,
            on_conflict=on_conflict,
        )
    return symlink_map(
        config_file_default_path=config_file_default_path,
        config_file_self_managed_path=config_file_self_managed_path,
        on_conflict=on_conflict,
    )


def _append_operation_record(
    operation_records: list[OperationRecord],
    *,
    program_name: str,
    file_key: str,
    config_file_default_path: PathExtended,
    config_file_self_managed_path: PathExtended,
    operation: str,
    action: ActionType,
    details: str,
    status: str,
) -> None:
    operation_records.append(
        {
            "program": program_name,
            "file_key": file_key,
            "defaultPath": str(config_file_default_path),
            "selfManaged": str(config_file_self_managed_path),
            "operation": operation,
            "action": action,
            "details": details,
            "status": status,
        }
    )


def apply_mapper(
    mapper_data: dict[str, list[ConfigMapper]],
    on_conflict: ON_CONFLICT_STRICT,
    method: Literal["symlink", "copy"],
    direction: DIRECTION_STRICT,
) -> None:
    operation_records: list[OperationRecord] = []
    print(f"Working with {len(mapper_data)} programs from mapper data.")
    if len(mapper_data) == 1:
        print(mapper_data)
    import os
    if os.name == "nt":
        import ctypes
        try:
            windll = getattr(ctypes, "windll", None)
            is_admin = bool(windll.shell32.IsUserAnAdmin()) if windll is not None else False
        except Exception:
            is_admin = False
        total_length = sum(len(item) for item in mapper_data.values())
        if not is_admin and method == "symlink" and total_length > 5:
            warning_body = "\n".join([
                "[bold yellow]Administrator privileges required[/]",
                "Run the terminal as admin and try again to avoid repeated elevation prompts.",
            ])
            console.print(
                Panel.fit(
                    warning_body,
                    title="⚠️ Permission Needed",
                    border_style="yellow",
                    padding=(1, 2),
                )
            )
            raise RuntimeError("Run terminal as admin and try again, otherwise, there will be too many popups for admin requests and no chance to terminate the program.")
    for program_name, program_files in mapper_data.items():
        console.rule(f"🔄 Processing [bold]{program_name}[/] ({direction})", style="cyan")
        for a_mapper in program_files:
            config_file_default_path, config_file_self_managed_path = _resolve_mapper_paths(a_mapper)
            use_copy = method == "copy" or a_mapper.get("copy", False)
            resolved_method: Literal["symlink", "copy"] = "copy" if use_copy else "symlink"
            operation_type = f"{direction}_{resolved_method}"
            if a_mapper.get("contents"):
                operation_type = f"{operation_type}_contents"
            try:
                operation_paths = _iter_operation_paths(
                    config_file_default_path=config_file_default_path,
                    config_file_self_managed_path=config_file_self_managed_path,
                    contents=bool(a_mapper.get("contents")),
                    direction=direction,
                )
            except Exception as ex:
                console.print(f"❌ [red]Config error[/red]: {program_name} | {a_mapper['file_name']} | {ex}")
                _append_operation_record(
                    operation_records,
                    program_name=program_name,
                    file_key=a_mapper["file_name"],
                    config_file_default_path=config_file_default_path,
                    config_file_self_managed_path=config_file_self_managed_path,
                    operation=operation_type,
                    action="error",
                    details=f"Failed to prepare {operation_type}: {str(ex)}",
                    status=f"error: {str(ex)}",
                )
                continue
            for config_file_default_path_item, config_file_self_managed_path_item in operation_paths:
                try:
                    result = _run_directional_operation(
                        config_file_default_path=config_file_default_path_item,
                        config_file_self_managed_path=config_file_self_managed_path_item,
                        on_conflict=on_conflict,
                        method=resolved_method,
                        direction=direction,
                    )
                    _append_operation_record(
                        operation_records,
                        program_name=program_name,
                        file_key=a_mapper["file_name"],
                        config_file_default_path=config_file_default_path_item,
                        config_file_self_managed_path=config_file_self_managed_path_item,
                        operation=operation_type,
                        action=result["action"],
                        details=result["details"],
                        status="success",
                    )
                except ValueError as ex:
                    if "resolve to the same location" in str(ex):
                        _append_operation_record(
                            operation_records,
                            program_name=program_name,
                            file_key=a_mapper["file_name"],
                            config_file_default_path=config_file_default_path_item,
                            config_file_self_managed_path=config_file_self_managed_path_item,
                            operation=operation_type,
                            action="already_linked",
                            details="defaultPath and selfManaged resolve to same location - already correctly configured",
                            status="success",
                        )
                    else:
                        raise
                except Exception as ex:
                    console.print(f"❌ [red]Config error[/red]: {program_name} | {a_mapper['file_name']} | {ex}")
                    _append_operation_record(
                        operation_records,
                        program_name=program_name,
                        file_key=a_mapper["file_name"],
                        config_file_default_path=config_file_default_path_item,
                        config_file_self_managed_path=config_file_self_managed_path_item,
                        operation=operation_type,
                        action="error",
                        details=f"Failed to create {operation_type}: {str(ex)}",
                        status=f"error: {str(ex)}",
                    )

            if program_name == "ssh" and system == "Linux":  # permissions of ~/dotfiles/.ssh should be adjusted
                try:
                    console.print("\n[bold]🔒 Setting secure permissions for SSH files...[/bold]")
                    subprocess.run("chmod 700 $HOME/.ssh/", shell=True, check=True)
                    subprocess.run("chmod 700 $HOME/dotfiles/creds/.ssh/", shell=True, check=True)
                    subprocess.run("chmod 600 $HOME/dotfiles/creds/.ssh/*", shell=True, check=True)
                    subprocess.run("chmod 600 $HOME/.ssh/*", shell=True, check=True)
                    console.print("[green]✅ SSH permissions set successfully[/green]")
                except Exception as e:
                    ERROR_LIST.append(e)
                    console.print(f"❌ [red]Error setting SSH permissions[/red]: {e}")

    # Display operation summary table
    if operation_records:
        table = Table(title="🔗 Dotfile Sync Summary", show_header=True, header_style="bold magenta")
        table.add_column("Program", style="cyan", no_wrap=True)
        table.add_column("File Key", style="blue", no_wrap=True)
        table.add_column("Default Path", style="green")
        table.add_column("Self Managed", style="yellow")
        table.add_column("Operation", style="magenta", no_wrap=True)
        table.add_column("Action", style="red", no_wrap=True)
        table.add_column("Details", style="white")
        table.add_column("Status", style="red", no_wrap=True)
        
        for record in operation_records:
            status_style = "green" if record["status"] == "success" else "red"
            action_style = "green" if record["action"] != "error" else "red"
            table.add_row(
                record["program"],
                record["file_key"],
                record["defaultPath"],
                record["selfManaged"],
                record["operation"],
                f"[{action_style}]{record['action']}[/{action_style}]",
                record["details"],
                f"[{status_style}]{record['status']}[/{status_style}]"
            )
        
        console.print("\n")
        console.print(table)
        
        # Export operation records to CSV
        import csv
        from datetime import datetime

        csv_dir = PathExtended(CONFIG_ROOT).joinpath("symlink_operations")
        csv_dir.mkdir(parents=True, exist_ok=True)
        
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        csv_filename = f"symlink_operations_{timestamp}.csv"
        csv_path = csv_dir.joinpath(csv_filename)
        
        fieldnames = ["program", "file_key", "defaultPath", "selfManaged", "operation", "action", "details", "status"]
        csv_buffer = io.StringIO(newline="")
        writer = csv.DictWriter(csv_buffer, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(operation_records)
        csv_path.write_text(csv_buffer.getvalue(), encoding="utf-8")

        console.print(f"\n[bold green]📊 Operations exported to CSV:[/bold green] [cyan]{csv_path}[/cyan]")

    if len(ERROR_LIST) > 0:
        console.print(
            Panel(
                Pretty(ERROR_LIST),
                title="❗ Errors Encountered During Processing",
                border_style="red",
                padding=(1, 2),
            )
        )
    else:
        console.print(
            Panel.fit(
                Text("✅ Dotfile sync completed successfully!", justify="center"),
                title="Dotfile Sync Complete",
                border_style="green",
            )
        )


if __name__ == "__main__":
    pass
