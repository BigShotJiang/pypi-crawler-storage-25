#
# Copyright (c) 2025-2026, Humanlike AI
#
# SPDX-License-Identifier: Apache-2.0
#

"""Humanlike video service for real-time avatar generation.

Connects to a Humanlike GPU orchestrator via WebSocket, streams TTS audio,
and receives lip-synced video frames with expression control.

Orchestrator WS protocol:
  1. Client sends JSON config:
     {"model": "humanlike-homo", "image": "<base64>", "seed": 42,
      "prompt": "warm, friendly, subtly smiling"}
  2. Server responds: {"status": "ready", "fps": 25, "chunk_samples": N}
  3. Client streams binary PCM int16 LE 16 kHz mono chunks
  4. Server streams binary: [4-byte frame_idx LE uint32][JPEG bytes]
  5. Client sends empty bytes to signal end of stream
"""

import asyncio
import base64
import io
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

import numpy as np
from loguru import logger

from pipecat.frames.frames import (
    CancelFrame,
    EndFrame,
    Frame,
    OutputImageRawFrame,
    StartFrame,
    TTSAudioRawFrame,
    TTSStartedFrame,
    TTSStoppedFrame,
    UserStartedSpeakingFrame,
)
from pipecat.processors.frame_processor import FrameDirection
from pipecat.services.ai_service import AIService
from pipecat.services.settings import ServiceSettings

try:
    import websockets
except ModuleNotFoundError as e:
    logger.error(f"Exception: {e}")
    logger.error(
        "In order to use Humanlike, you need to `pip install pipecat-ai-humanlike`."
    )
    raise Exception(f"Missing module: {e}")

try:
    from PIL import Image
except ModuleNotFoundError as e:
    logger.error(f"Exception: {e}")
    logger.error(
        "In order to use Humanlike, you need to `pip install pipecat-ai-humanlike`."
    )
    raise Exception(f"Missing module: {e}")

TARGET_SR = 16000


def _resample(samples: np.ndarray, src_sr: int, dst_sr: int) -> np.ndarray:
    if src_sr == dst_sr:
        return samples
    try:
        import soxr

        return soxr.resample(samples, src_sr, dst_sr).astype(np.float32)
    except ImportError:
        ratio = dst_sr / src_sr
        n_out = int(len(samples) * ratio)
        indices = np.linspace(0, len(samples) - 1, n_out)
        return np.interp(indices, np.arange(len(samples)), samples).astype(np.float32)


@dataclass
class HumanlikeVideoSettings(ServiceSettings):
    """Settings for the Humanlike video service."""

    pass


class HumanlikeVideoService(AIService):
    """Humanlike video service for real-time avatar generation.

    Connects to a Humanlike GPU orchestrator via WebSocket, streams TTS
    audio and produces synchronized lip-synced video output with
    expression control via natural-language prompts.

    Pipeline position: after TTS, before transport output.

    Audio frames pass through so the user hears them; video frames are
    generated in the background and pushed downstream.
    """

    Settings = HumanlikeVideoSettings
    _settings: Settings

    def __init__(
        self,
        *,
        ws_url: str = "ws://127.0.0.1:8000/ws/stream",
        image: str | bytes = "./face.png",
        avatar_model: str = "humanlike-homo",
        prompt: str = "warm, friendly, subtly smiling",
        seed: int = 42,
        video_width: int = 512,
        video_height: int = 512,
        settings: Optional[Settings] = None,
        **kwargs,
    ):
        """Initialize the Humanlike video service.

        Args:
            ws_url: WebSocket URL of the avatar orchestrator.
            image: Path to a face image, or raw image bytes (PNG/JPEG).
            avatar_model: Model identifier, e.g. "humanlike-homo".
            prompt: Natural-language expression prompt that guides facial
                behaviour, e.g. "expressive, warm smile, occasional nods".
                Can be updated at runtime via update_prompt().
            seed: Random seed for reproducible generation.
            video_width: Output video width (should match orchestrator).
            video_height: Output video height (should match orchestrator).
            settings: Service settings.
            **kwargs: Additional arguments passed to AIService.
        """
        default_settings = ServiceSettings(model=avatar_model)
        if settings is not None:
            default_settings.apply_update(settings)
        super().__init__(settings=default_settings, **kwargs)

        self._ws_url = ws_url
        self._image = image
        self._avatar_model = avatar_model
        self._prompt = prompt
        self._seed = seed
        self._video_size = (video_width, video_height)

        self._ws: websockets.WebSocketClientProtocol | None = None
        self._chunk_samples: int = 0
        self._fps: float = 25.0
        self._audio_buf = np.array([], dtype=np.float32)
        self._connected = False
        self._recv_task: asyncio.Task | None = None
        self._idle_task: asyncio.Task | None = None
        self._idle_frame: OutputImageRawFrame | None = None
        self._generating = False
        self._speaking = False

    def _load_image(self) -> bytes:
        if isinstance(self._image, bytes):
            return self._image
        return Path(self._image).expanduser().read_bytes()

    async def start(self, frame: StartFrame):
        await super().start(frame)
        await self._start_connection()

    async def stop(self, frame: EndFrame):
        await super().stop(frame)
        await self._stop_connection()

    async def cancel(self, frame: CancelFrame):
        await super().cancel(frame)
        await self._stop_connection()

    async def _start_connection(self):
        """Open WS, send config, wait for ready, start recv loop."""
        try:
            image_bytes = self._load_image()
            image_b64 = base64.b64encode(image_bytes).decode()

            self._ws = await websockets.connect(
                self._ws_url,
                max_size=10 * 1024 * 1024,
                ping_interval=None,
                ping_timeout=None,
                close_timeout=120,
            )

            config = {
                "model": self._avatar_model,
                "image": image_b64,
                "seed": self._seed,
                "prompt": self._prompt,
            }
            await self._ws.send(
                __import__("json").dumps(config)
            )
            logger.info(
                f"Humanlike: sent config model={self._avatar_model} "
                f"prompt={self._prompt[:60]!r}"
            )

            while True:
                raw = await self._ws.recv()
                if isinstance(raw, str):
                    import json

                    msg = json.loads(raw)
                    if msg.get("status") == "ready":
                        self._fps = float(msg.get("fps", 25))
                        self._chunk_samples = int(msg.get("chunk_samples", 0))
                        self._connected = True
                        logger.info(
                            f"Humanlike orchestrator ready: "
                            f"fps={self._fps:.0f} chunk_samples={self._chunk_samples}"
                        )
                        break
                    if "error" in msg:
                        raise RuntimeError(f"Orchestrator error: {msg['error']}")

            self._recv_task = self.create_task(self._recv_loop())

            img = Image.open(io.BytesIO(image_bytes)).convert("RGB").resize(
                self._video_size
            )
            self._idle_frame = OutputImageRawFrame(
                image=img.tobytes(),
                size=self._video_size,
                format="RGB",
            )
            self._idle_task = self.create_task(self._idle_loop())
        except Exception as e:
            await self.push_error(
                error_msg=f"Humanlike connection failed: {e}", exception=e
            )

    async def _idle_loop(self):
        """Push the reference image at fps until the first GPU frame arrives."""
        interval = 1.0 / self._fps
        while not self._generating and self._idle_frame is not None:
            await self.push_frame(self._idle_frame, FrameDirection.DOWNSTREAM)
            await asyncio.sleep(interval)

    async def _recv_loop(self):
        """Receive JPEG frames from orchestrator, decode, push downstream."""
        try:
            assert self._ws is not None
            async for message in self._ws:
                if not isinstance(message, bytes) or len(message) < 4:
                    continue
                jpeg_data = message[4:]
                try:
                    img = Image.open(io.BytesIO(jpeg_data)).convert("RGB")
                    img = img.resize(self._video_size)
                    if not self._generating:
                        self._generating = True
                        self._idle_frame = None
                    frame = OutputImageRawFrame(
                        image=img.tobytes(),
                        size=self._video_size,
                        format="RGB",
                    )
                    await self.push_frame(frame, FrameDirection.DOWNSTREAM)
                except Exception as e:
                    logger.warning(f"Humanlike: failed to decode frame: {e}")
        except websockets.ConnectionClosed:
            logger.info("Humanlike orchestrator WS closed")
        except Exception as e:
            logger.exception(f"Humanlike recv loop error: {e}")

    async def process_frame(self, frame: Frame, direction: FrameDirection):
        await super().process_frame(frame, direction)

        if isinstance(frame, TTSAudioRawFrame) and self._connected:
            pcm = np.frombuffer(frame.audio, dtype=np.int16).astype(np.float32) / 32768.0
            if frame.num_channels > 1:
                pcm = pcm.reshape(-1, frame.num_channels).mean(axis=1)
            pcm = _resample(pcm, frame.sample_rate, TARGET_SR)
            self._audio_buf = np.concatenate([self._audio_buf, pcm])

            while self._chunk_samples > 0 and len(self._audio_buf) >= self._chunk_samples:
                chunk = self._audio_buf[: self._chunk_samples]
                self._audio_buf = self._audio_buf[self._chunk_samples :]
                await self._send_chunk(chunk)

        elif isinstance(frame, TTSStoppedFrame):
            await self._flush_audio()

        elif isinstance(frame, UserStartedSpeakingFrame):
            self._audio_buf = np.array([], dtype=np.float32)

        await self.push_frame(frame, direction)

    async def update_prompt(self, prompt: str) -> None:
        """Update the expression prompt mid-session."""
        self._prompt = prompt
        if self._ws is not None:
            try:
                import json

                await self._ws.send(json.dumps({"update_prompt": prompt}))
                logger.info(f"Humanlike: expression prompt updated: {prompt[:60]!r}")
            except Exception as e:
                logger.warning(f"Humanlike: failed to send prompt update: {e}")

    async def _send_chunk(self, chunk: np.ndarray) -> None:
        if self._ws is None:
            return
        pcm_int16 = (np.clip(chunk, -1.0, 1.0) * 32767).astype(np.int16)
        await self._ws.send(pcm_int16.tobytes())

    async def _flush_audio(self) -> None:
        if self._chunk_samples > 0 and len(self._audio_buf) > 0:
            chunk = self._audio_buf
            self._audio_buf = np.array([], dtype=np.float32)
            if len(chunk) < self._chunk_samples:
                chunk = np.pad(chunk, (0, self._chunk_samples - len(chunk)))
            await self._send_chunk(chunk)
        if self._ws is not None:
            try:
                await self._ws.send(b"")
            except Exception:
                pass

    async def _stop_connection(self):
        self._connected = False
        if self._idle_task is not None:
            await self.cancel_task(self._idle_task)
            self._idle_task = None
        if self._recv_task is not None:
            await self.cancel_task(self._recv_task)
            self._recv_task = None
        if self._ws is not None:
            try:
                await self._ws.close()
            except Exception:
                pass
            self._ws = None
