"""
Data models for dbt-cloud-run-runner.
"""

from dataclasses import dataclass
from enum import Enum
from typing import Optional
from datetime import datetime

# Keys set by the runner via `DbtCloudRunSetup.to_env_vars()`. User-provided env must not use these names.
DBT_CLOUD_RUN_BUILTIN_ENV_KEYS = frozenset(
    {
        "DBT_PROJECT_URL",
        "PROFILE_YML",
        "CREDENTIALS_URL",
        "OUTPUT_URL",
        "LOGS_URL",
        "DBT_DOCS_SELECTOR",
        "EXTRA_ENV_VARS",
    }
)


class ExecutionState(Enum):
    """State of a Cloud Run job execution."""

    UNKNOWN = "UNKNOWN"
    PENDING = "PENDING"
    RUNNING = "RUNNING"
    SUCCEEDED = "SUCCEEDED"
    FAILED = "FAILED"
    CANCELLED = "CANCELLED"


@dataclass
class DbtCloudRunSetup:
    """
    Configuration for a dbt Cloud Run execution.

    Contains the GCS blob paths and signed URLs needed to run dbt.
    """

    # GCS blob paths (gs://bucket/path format)
    profiles_yml_blob: str
    dbt_project_blob: str
    credentials_blob: str
    output_blob: str
    logs_blob: str

    # Pre-signed URLs for the Docker container
    profiles_yml_url: str
    dbt_project_url: str
    credentials_url: str
    output_url: str
    logs_url: str

    # Docker image to use
    image: str

    # Extra env vars for the dbt container (must not overlap `DBT_CLOUD_RUN_BUILTIN_ENV_KEYS`)
    extra_env: Optional[dict[str, str]] = None

    # Optional selector for dbt docs generate command (--selector argument)
    docs_generate_selector: Optional[str] = None

    def to_env_vars(self) -> dict[str, str]:
        """Return built-in environment variables for the Cloud Run job."""
        env_vars = {
            "DBT_PROJECT_URL": self.dbt_project_url,
            "PROFILE_YML": self.profiles_yml_url,
            "CREDENTIALS_URL": self.credentials_url,
            "OUTPUT_URL": self.output_url,
            "LOGS_URL": self.logs_url,
        }
        if self.docs_generate_selector:
            env_vars["DBT_DOCS_SELECTOR"] = self.docs_generate_selector
        if self.extra_env:
            env_vars["EXTRA_ENV_VARS"] = ",".join(self.extra_env.keys())
        return env_vars

    def env_vars_for_cloud_run(self) -> dict[str, str]:
        """Full env for the job: user extras plus built-ins (built-ins take precedence)."""
        return {**(self.extra_env or {}), **self.to_env_vars()}


@dataclass
class ExecutionStatus:
    """
    Status of a Cloud Run job execution.
    """

    execution_id: str
    state: ExecutionState
    create_time: Optional[datetime] = None
    start_time: Optional[datetime] = None
    completion_time: Optional[datetime] = None
    error_message: Optional[str] = None

    @property
    def is_terminal(self) -> bool:
        """Return True if the execution has reached a terminal state."""
        return self.state in (
            ExecutionState.SUCCEEDED,
            ExecutionState.FAILED,
            ExecutionState.CANCELLED,
        )

    @property
    def is_successful(self) -> bool:
        """Return True if the execution completed successfully."""
        return self.state == ExecutionState.SUCCEEDED
