pub mod canonical;
pub mod delegation;
pub mod error;
pub mod identity;
pub mod policy;
pub mod policy_eval;
pub mod policy_load;
pub mod receipt;
pub mod sign;
pub mod sign_delegation;
pub mod trust;
pub mod verify;
pub mod verify_delegation;

#[cfg(not(target_arch = "wasm32"))]
pub mod keystore;

#[cfg(not(target_arch = "wasm32"))]
pub mod audit;

pub use delegation::{
    validate_scope_narrowing, Authorization, DelegationIdentity, DelegationToken, Scope,
};
pub use error::SignetError;
pub use identity::generate_keypair;
pub use policy::{compute_policy_hash, Policy, PolicyAttestation, PolicyEvalResult, RuleAction};
pub use policy_eval::{evaluate_policy, RateLimitState};
pub use policy_load::{parse_policy_json, parse_policy_yaml, validate_policy};

#[cfg(not(target_arch = "wasm32"))]
pub use policy_load::load_policy;
pub use receipt::{
    Action, BilateralReceipt, CompoundReceipt, Receipt, Response, ServerInfo, Signer,
};
pub use sign::{sign, sign_bilateral, sign_compound, sign_with_expiration, sign_with_policy};
pub use sign_delegation::{sign_authorized, sign_delegation};
pub use trust::{
    parse_trust_bundle_json, parse_trust_bundle_yaml, validate_trust_bundle, TrustBundle,
    TrustKeyEntry, TrustKeyStatus,
};
pub use verify::{
    verify, verify_allow_expired, verify_any, verify_bilateral, verify_bilateral_detailed,
    verify_bilateral_with_options, verify_bilateral_with_options_detailed, verify_compound,
    BilateralVerifyOptions, BilateralVerifyOutcome, InMemoryNonceChecker, NonceChecker,
};
pub use verify_delegation::{
    verify_authorized, verify_chain as verify_delegation_chain, verify_delegation,
    AuthorizedVerifyOptions,
};

#[cfg(not(target_arch = "wasm32"))]
pub use identity::fs_ops::{
    default_signet_dir, export_public_key, generate_and_save, list_keys, load_key_info,
    load_signing_key, load_verifying_key, validate_key_name, KeyInfo,
};
#[cfg(not(target_arch = "wasm32"))]
pub use trust::{load_trust_bundle, save_trust_bundle};

#[cfg(test)]
pub(crate) mod test_helpers {
    use crate::receipt::Action;
    use serde_json::json;

    pub fn test_action() -> Action {
        Action {
            tool: "github_create_issue".to_string(),
            params: json!({"title": "fix bug", "body": "details"}),
            params_hash: String::new(),
            target: "mcp://github.local".to_string(),
            transport: "stdio".to_string(),
            session: None,
            call_id: None,
            response_hash: None,
            trace_id: None,
            parent_receipt_id: None,
        }
    }
}
