"""Type stubs for signet_auth._signet (PyO3 extension module)."""

from __future__ import annotations

from datetime import datetime
from typing import Any

__version__: str

# ─── Exceptions ───────────────────────────────────────────────────────────────

class SignetError(Exception): ...
class InvalidKeyError(SignetError): ...
class SignatureMismatchError(SignetError): ...
class InvalidReceiptError(SignetError): ...
class CanonicalizeError(SignetError): ...
class SerializeError(SignetError): ...
class KeyNotFoundError(SignetError): ...
class KeyExistsError(SignetError): ...
class InvalidNameError(SignetError): ...
class DecryptionError(SignetError): ...
class CorruptedFileError(SignetError): ...
class CorruptedRecordError(SignetError): ...
class SignetIOError(SignetError): ...
class UnsupportedFormatError(SignetError): ...
class ScopeViolationError(SignetError): ...
class ChainError(SignetError): ...
class DelegationExpiredError(SignetError): ...
class UnauthorizedError(SignetError): ...

# ─── Types ────────────────────────────────────────────────────────────────────

class Action:
    def __init__(
        self,
        tool: str,
        params: Any | None = None,
        target: str = "",
        transport: str = "stdio",
        session: str | None = None,
        call_id: str | None = None,
        response_hash: str | None = None,
    ) -> None: ...
    @classmethod
    def hash_only(
        cls,
        tool: str,
        params_hash: str,
        *,
        target: str = "",
        transport: str = "stdio",
        session: str | None = None,
        call_id: str | None = None,
        response_hash: str | None = None,
    ) -> Action: ...
    @property
    def tool(self) -> str: ...
    @property
    def params(self) -> Any | None: ...
    @property
    def params_hash(self) -> str: ...
    @property
    def target(self) -> str: ...
    @property
    def transport(self) -> str: ...
    @property
    def session(self) -> str | None: ...
    @property
    def call_id(self) -> str | None: ...
    @property
    def response_hash(self) -> str | None: ...

class Signer:
    @property
    def pubkey(self) -> str: ...
    @property
    def name(self) -> str: ...
    @property
    def owner(self) -> str: ...

class Receipt:
    @property
    def v(self) -> int: ...
    @property
    def id(self) -> str: ...
    @property
    def action(self) -> Action: ...
    @property
    def signer(self) -> Signer: ...
    @property
    def ts(self) -> str: ...
    @property
    def nonce(self) -> str: ...
    @property
    def sig(self) -> str: ...
    def to_json(self) -> str: ...
    @staticmethod
    def from_json(json_str: str) -> Receipt: ...

class KeyPair:
    secret_key: str
    public_key: str
    def __repr__(self) -> str: ...

class KeyInfo:
    name: str
    owner: str | None
    pubkey: str
    created_at: str

class AuditRecord:
    @property
    def receipt(self) -> Receipt: ...
    @property
    def prev_hash(self) -> str: ...
    @property
    def record_hash(self) -> str: ...

class ChainBreak:
    file: str
    line: int
    expected_hash: str
    actual_hash: str

class ChainStatus:
    total_records: int
    valid: bool
    @property
    def break_point(self) -> ChainBreak | None: ...

class VerifyFailure:
    file: str | None
    line: int | None
    receipt_id: str
    reason: str

class VerifyWarning:
    file: str | None
    line: int | None
    receipt_id: str
    reason: str

class VerifyResult:
    total: int
    valid: int
    @property
    def warnings(self) -> list[VerifyWarning]: ...
    @property
    def failures(self) -> list[VerifyFailure]: ...

class Response:
    @property
    def content_hash(self) -> str: ...

class CompoundReceipt:
    @property
    def v(self) -> int: ...
    @property
    def id(self) -> str: ...
    @property
    def action(self) -> Action: ...
    @property
    def response(self) -> Response: ...
    @property
    def signer(self) -> Signer: ...
    @property
    def ts_request(self) -> str: ...
    @property
    def ts_response(self) -> str: ...
    @property
    def nonce(self) -> str: ...
    @property
    def sig(self) -> str: ...
    def to_json(self) -> str: ...
    @staticmethod
    def from_json(json_str: str) -> CompoundReceipt: ...

class ServerInfo:
    @property
    def pubkey(self) -> str: ...
    @property
    def name(self) -> str: ...

class BilateralReceipt:
    @property
    def v(self) -> int: ...
    @property
    def id(self) -> str: ...
    @property
    def agent_receipt(self) -> Receipt: ...
    @property
    def response(self) -> Response: ...
    @property
    def server(self) -> ServerInfo: ...
    @property
    def ts_response(self) -> str: ...
    @property
    def nonce(self) -> str: ...
    @property
    def sig(self) -> str: ...
    @property
    def extensions(self) -> Any | None: ...
    def to_json(self) -> str: ...
    @staticmethod
    def from_json(json_str: str) -> BilateralReceipt: ...

# ─── Core functions ───────────────────────────────────────────────────────────

def generate_keypair() -> KeyPair: ...
def sign(
    secret_key: str,
    action: Action,
    signer_name: str,
    signer_owner: str | None = None,
) -> Receipt: ...
def verify(receipt: Receipt, public_key: str) -> bool: ...
def sign_compound(
    secret_key: str,
    action: Action,
    response_content: Any,
    signer_name: str,
    signer_owner: str | None = None,
    ts_request: str | None = None,
    ts_response: str | None = None,
) -> CompoundReceipt: ...
def verify_any(receipt_json: str, public_key: str) -> bool: ...
def sign_bilateral(
    server_key: str,
    agent_receipt: Receipt,
    response_content: Any,
    server_name: str,
    ts_response: str | None = None,
) -> BilateralReceipt: ...
def verify_bilateral(receipt: BilateralReceipt, server_public_key: str) -> bool: ...
def verify_bilateral_with_options(
    receipt: BilateralReceipt,
    server_public_key: str,
    expected_session: str | None = None,
    expected_call_id: str | None = None,
    check_nonce: bool = False,
    max_time_window_secs: int = 300,
    trusted_agent_public_key: str | None = None,
) -> bool: ...
def verify_bilateral_detailed(
    receipt: BilateralReceipt,
    server_public_key: str,
    expected_session: str | None = None,
    expected_call_id: str | None = None,
    check_nonce: bool = False,
    max_time_window_secs: int = 300,
    trusted_agent_public_key: str | None = None,
) -> str: ...

# ─── Delegation functions ────────────────────────────────────────────────────

def sign_delegation(
    delegator_key_b64: str,
    delegator_name: str,
    delegate_pubkey_b64: str,
    delegate_name: str,
    scope_json: str,
    parent_scope_json: str | None = None,
) -> str: ...
def verify_delegation(token_json: str) -> bool: ...
def sign_authorized(
    key_b64: str,
    action_json: str,
    signer_name: str,
    chain_json: str,
) -> str: ...
def verify_authorized(
    receipt_json: str,
    trusted_roots_b64: list[str],
    clock_skew_secs: int = 60,
) -> str: ...

# ─── Expiration functions ─────────────────────────────────────────────────────

def sign_with_expiration(
    secret_key: str,
    action: Action,
    signer_name: str,
    signer_owner: str,
    expires_at: str,
) -> Receipt: ...
def verify_allow_expired(receipt: Receipt, public_key: str) -> bool: ...

# ─── Policy functions ─────────────────────────────────────────────────────────

def parse_policy_yaml(yaml: str) -> str: ...
def parse_policy_json(json_str: str) -> str: ...
def evaluate_policy(
    action_json: str,
    agent_name: str,
    policy_json: str,
) -> str: ...
def sign_with_policy(
    key_b64: str,
    action_json: str,
    signer_name: str,
    signer_owner: str,
    policy_json: str,
) -> tuple[str, str]: ...
def compute_policy_hash(policy_json: str) -> str: ...

# ─── Identity functions ───────────────────────────────────────────────────────

def validate_key_name(name: str) -> None: ...
def default_signet_dir() -> str: ...
def generate_and_save(
    dir: str,
    name: str,
    owner: str | None = None,
    passphrase: str | None = None,
) -> KeyInfo: ...
def load_signing_key(
    dir: str,
    name: str,
    passphrase: str | None = None,
) -> str: ...
def load_verifying_key(dir: str, name: str) -> str: ...
def load_key_info(dir: str, name: str) -> KeyInfo: ...
def list_keys(dir: str) -> list[KeyInfo]: ...
def export_public_key(dir: str, name: str) -> dict[str, Any]: ...

# ─── Audit functions ──────────────────────────────────────────────────────────

def audit_append(dir: str, receipt: Receipt) -> AuditRecord: ...
def audit_query(
    dir: str,
    *,
    since: str | datetime | None = None,
    tool: str | None = None,
    signer: str | None = None,
    limit: int | None = None,
) -> list[AuditRecord]: ...
def audit_verify_chain(dir: str) -> ChainStatus: ...
def audit_verify_signatures(
    dir: str,
    *,
    since: str | datetime | None = None,
    tool: str | None = None,
    signer: str | None = None,
    limit: int | None = None,
    trusted_agent_keys: list[str] | None = None,
    trusted_server_keys: list[str] | None = None,
) -> VerifyResult: ...
