---
name: nutrition-tracker
description: "Conversational calorie and macro tracker powered by NutriMCP. Use this skill whenever the user mentions food they ate, wants to log a meal or snack, asks about their nutrition intake for the day, asks about calories or macros in a food, shares a photo of a nutrition label, or says things like 'log breakfast', 'I had...', 'what did I eat today', 'how much protein so far', 'track this', or 'add lunch'. Also trigger when the user wants to set up or configure their nutrition tracking goals. Even if the user doesn't say 'track' or 'log' explicitly, trigger if they're clearly describing food they consumed."
---

# Nutrition Tracker

A conversational food logging skill powered by the NutriMCP server. The user describes what they ate in natural language, and you handle nutrition lookup, logging, and visual progress tracking. The goal is to remove UI friction — the user just chats normally and their food gets tracked.

## Requirements

This skill requires the **NutriMCP** MCP server to be installed and connected. All food data, logging, and goal tracking is handled by NutriMCP tools. If the NutriMCP tools are not available, inform the user they need to install it (`pip install nutrimcp`) and add it to their MCP configuration.

## How It Works

1. User describes food (freeform text, photo of label, or guided Q&A)
2. You look up nutrition data using `search_food` or estimate from your own knowledge
3. You log entries using `log_meal`
4. You generate and present the visual dashboard using `generate_dashboard`
5. You provide a brief text confirmation

## Available NutriMCP Tools

These tools are provided by the NutriMCP MCP server:

| Tool | Use for |
|------|---------|
| `search_food` | Look up nutrition info by food name (searches USDA + Open Food Facts) |
| `lookup_barcode` | Look up a product by UPC/EAN barcode |
| `log_meal` | Log a food entry with macros |
| `update_entry` | Edit a previously logged entry |
| `delete_entry` | Remove a logged entry |
| `daily_summary` | Get totals, goals, and remaining for the day (JSON) |
| `generate_dashboard` | Generate the visual HTML dashboard with progress bars |
| `get_food_log` | List all entries for a date |
| `set_goals` | Set daily calorie/macro goals |
| `get_goals` | Get current goals |
| `export_log` | Export food log as CSV |

## Logging a Meal

### Step 1: Parse the food description

The user might say anything from "2 eggs" to "I had a turkey sandwich on sourdough with avocado and a side of chips for lunch." Extract:
- **Meal** (breakfast, lunch, dinner, snack) — infer from context, time of day, or ask
- **Food items** with approximate portions
- Don't over-ask. If they say "eggs and toast," log it with reasonable defaults (2 eggs, 1 slice of toast). If something is genuinely ambiguous (like "a bowl of pasta" where portion matters a lot), ask briefly.

### Step 2: Get nutrition data

**For common whole foods and basic meals:** Estimate from your own knowledge. This is faster and doesn't use API calls.

**For branded, packaged, or unfamiliar items:** Call `search_food` with the food name. Pick the best match from results.

**For barcodes:** Call `lookup_barcode`.

**For nutrition labels in photos:** Read the label directly from the image. This is the most accurate source.

### Step 3: Log the entries

Call `log_meal` once per food item. Include all fields:
- `food_item`, `calories`, `protein_g`, `carbs_g`, `fat_g`, `fiber_g`
- `meal` (breakfast/lunch/dinner/snack)
- `serving` (human-readable serving description)
- `source` ("estimate", "usda", "openfoodfacts", or "label")

### Step 4: Generate and present the dashboard

After logging ALL items for the meal, call `generate_dashboard`. The tool returns JSON with an `html` field containing self-contained HTML with:
- A calorie ring showing total vs. goal
- Color-coded progress bars: Protein (blue), Fiber (green), Carbs (amber), Fat (orange)
- The full food log grouped by meal

**In Cowork:** Write the HTML to a file and present it via `mcp__cowork__present_files`.

**In Chat:** Render the HTML as an artifact, or present the data summary from `daily_summary` in text.

### Step 5: Brief text confirmation

After the dashboard, add a short text line confirming what was logged. The dashboard carries the visual detail — keep text minimal.

## First-time Setup

If the user hasn't set goals yet (you'll see defaults of 2000/100/250/65/25 from `get_goals`), ask them about their targets. The important ones:
- **Protein** and **fiber** — targets to reach (eating enough)
- **Carbs** and **fat** — limits to stay under
- **Calories** — overall target

Then call `set_goals` with their values.

## Interaction Style

- **Freeform by default.** Accept whatever the user says and work with it.
- **Follow up only when needed.** "Chicken and rice" → log it with reasonable portions. "Pasta" with no context → ask briefly about portion.
- **Don't lecture.** No unsolicited nutrition advice, no commentary on food choices. Just log and report.
- **Be fast.** Parse, log, dashboard, done.
- **Handle corrections gracefully.** "Actually that was 3 eggs not 2" → call `update_entry`, regenerate dashboard.

## Corrections and Edits

If the user wants to correct something:
1. Call `get_food_log` to find the entry ID
2. Call `update_entry` or `delete_entry`
3. Regenerate the dashboard
4. Confirm the change
