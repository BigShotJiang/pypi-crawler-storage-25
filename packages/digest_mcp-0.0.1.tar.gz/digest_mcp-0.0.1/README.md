# Digest

**Local-first nutrition tracking that runs inside Claude.** You log food by chatting. Your data lives in a SQLite file on your machine — no account, no cloud, no signup. A color-coded dashboard shows five numbers at a glance: calories, protein, fiber, carbs, fat. Protein and fiber are targets. Carbs and fat are limits. That's the whole product.

> **Note:** This is a pre-alpha release (`0.0.1`) reserving the package name while development continues. The core functionality works, but features are still being added. Watch the repo for the 0.1.0 release.

## What Digest does

- **Search foods** across USDA FoodData Central (380K+) and Open Food Facts (4M+ branded products)
- **Barcode lookup** (UPC/EAN)
- **Log meals** via natural conversation — calories, protein, carbs, fat, fiber
- **Track goals** as targets (protein, fiber) or limits (carbs, fat)
- **Visual dashboard** — color-coded progress bars with a calorie ring, updates in place
- **Edit and delete** entries with natural language
- **CSV export** so your data is never locked in

## What Digest doesn't do, by design

- No meal plans or recipe suggestions
- No grocery lists
- No social feed, streaks, or gamification
- No coaching, nudges, or "helpful" reminders
- No account, login, or cloud sync
- No ads, ever

**Label photos work.** Snap a picture of any nutrition facts panel, paste it into chat, and Claude reads the numbers and logs them. No special tool needed.

## Data location

All data lives in `~/.digest/digest.db` — a single SQLite file. Delete it and it's gone. Export to CSV anytime. Query it directly with `sqlite3` if you want.

## Install

```bash
pip install digest-mcp
```

## Configure (Claude Desktop)

Add to `~/Library/Application Support/Claude/claude_desktop_config.json`:

```json
{
  "mcpServers": {
    "digest": {
      "command": "digest-mcp",
      "env": {
        "USDA_API_KEY": "DEMO_KEY"
      }
    }
  }
}
```

The `DEMO_KEY` works for light personal use (~30 requests/hour). For higher limits, get a free key at [fdc.nal.usda.gov/api-key-signup](https://fdc.nal.usda.gov/api-key-signup).

Restart Claude Desktop, and Digest's tools become available in any chat.

## License

MIT. Do whatever you want with it.

## Author

Mya — mya@twobitcircus.org
