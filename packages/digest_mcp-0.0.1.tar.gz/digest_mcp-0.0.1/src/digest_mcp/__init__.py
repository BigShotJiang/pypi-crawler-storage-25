"""Digest - Nutrition tracking MCP server."""
__version__ = "0.0.1"
