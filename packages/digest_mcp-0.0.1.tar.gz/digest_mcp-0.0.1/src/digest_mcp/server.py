"""Digest — Nutrition tracking MCP server.

Provides food search (USDA + Open Food Facts), meal logging,
daily summaries with goal tracking, barcode lookup, and CSV export.
"""

import os
import json
from datetime import datetime, date
from pathlib import Path
from typing import Optional

from fastmcp import FastMCP
from digest_mcp import db, apis, dashboard


LIVE_DASHBOARD_PATH = Path.home() / ".digest" / "dashboard.html"


def _write_live_dashboard(log_date: str = "") -> None:
    """Regenerate the live dashboard HTML file. Silent on error."""
    try:
        conn = _get_conn()
        d = log_date or date.today().isoformat()
        entries = db.get_entries(conn, d)
        totals = db.get_daily_totals(conn, d)
        goals = db.get_goals(conn)

        meals = {}
        for e in entries:
            m = e["meal"]
            meals.setdefault(m, []).append({
                "food": e["food_item"],
                "serving": e["serving"],
                "calories": e["calories"],
                "protein_g": e["protein_g"],
                "carbs_g": e["carbs_g"],
                "fat_g": e["fat_g"],
                "fiber_g": e["fiber_g"],
            })

        html_content = dashboard.generate_dashboard_html(d, meals, totals, goals, auto_refresh=True)
        LIVE_DASHBOARD_PATH.parent.mkdir(parents=True, exist_ok=True)
        LIVE_DASHBOARD_PATH.write_text(html_content, encoding="utf-8")
    except Exception:
        # Never let dashboard writes break a log call
        pass


# ── Server init ──

mcp = FastMCP(
    name="Digest",
    instructions="""You are a nutrition tracking assistant. When the user describes food,
    use search_food to find matches, then log_meal to record entries.
    After logging, call daily_summary to show progress toward goals.
    Be concise — confirm what was logged and show the daily totals.
    Don't lecture about food choices. Just log and report.""",
)

_conn = None

def _get_conn():
    global _conn
    if _conn is None:
        db_path = os.environ.get("DIGEST_DB_PATH")
        _conn = db.get_db(db_path and __import__("pathlib").Path(db_path) or None)
    return _conn

def _usda_key():
    return os.environ.get("USDA_API_KEY", "DEMO_KEY")


# ── Food Search Tools ──

@mcp.tool()
async def search_food(query: str, max_results: int = 8) -> str:
    """Search for foods by name across USDA FoodData Central and Open Food Facts.

    Use this when the user mentions a food and you need nutrition data.
    Returns a list of matching foods with calories, protein, carbs, fat, and fiber.

    Args:
        query: Food name or description (e.g., "chicken breast", "Cheerios", "Big Mac")
        max_results: Maximum number of results to return (default 8)
    """
    results = await apis.search_food(query, api_key=_usda_key(), max_results=max_results)

    if not results:
        return json.dumps({"status": "no_results", "message": f"No foods found for '{query}'. Try a different search term."})

    # Format results for readability
    formatted = []
    for i, r in enumerate(results):
        formatted.append({
            "index": i + 1,
            "name": r["name"],
            "brand": r["brand"] or None,
            "serving": r["serving"],
            "calories": r["calories"],
            "protein_g": r["protein_g"],
            "carbs_g": r["carbs_g"],
            "fat_g": r["fat_g"],
            "fiber_g": r["fiber_g"],
            "source": r["source"],
            "source_id": r["source_id"],
        })

    return json.dumps({"status": "ok", "count": len(formatted), "results": formatted}, indent=2)


@mcp.tool()
async def lookup_barcode(barcode: str) -> str:
    """Look up a food product by its barcode (UPC/EAN).

    Use this when the user provides a barcode number or scans a product.

    Args:
        barcode: The product barcode (UPC or EAN number)
    """
    result = await apis.lookup_barcode(barcode)

    if not result:
        return json.dumps({"status": "not_found", "message": f"No product found for barcode {barcode}."})

    return json.dumps({"status": "ok", "product": result}, indent=2)


# ── Meal Logging Tools ──

@mcp.tool()
def log_meal(
    food_item: str,
    calories: float,
    protein_g: float,
    carbs_g: float,
    fat_g: float,
    meal: str = "other",
    serving: str = "1 serving",
    fiber_g: float = 0,
    source: str = "estimate",
    source_id: str = "",
    log_date: str = "",
    log_time: str = "",
) -> str:
    """Log a food entry to the nutrition tracker.

    Call this after looking up nutrition data for a food the user ate.
    You can log multiple items in sequence for a single meal.

    Args:
        food_item: Name of the food (e.g., "scrambled eggs")
        calories: Total calories for the serving
        protein_g: Grams of protein
        carbs_g: Grams of carbohydrates
        fat_g: Grams of fat
        meal: Meal type — breakfast, lunch, dinner, or snack (default: other)
        serving: Serving description (e.g., "2 large", "1 cup", "6 oz")
        fiber_g: Grams of fiber (default 0)
        source: Data source — "usda", "openfoodfacts", "estimate", or "label" (default: estimate)
        source_id: ID from the source database, if applicable
        log_date: Date in YYYY-MM-DD format (default: today)
        log_time: Time in HH:MM format (default: now)
    """
    conn = _get_conn()
    d = log_date or date.today().isoformat()
    t = log_time or datetime.now().strftime("%H:%M")

    entry_id = db.log_entry(
        conn, d, t, meal, food_item, serving,
        calories, protein_g, carbs_g, fat_g, fiber_g,
        source, source_id or None,
    )

    _write_live_dashboard(d)

    return json.dumps({
        "status": "logged",
        "entry_id": entry_id,
        "summary": f"{food_item} ({serving}) — {calories} cal, {protein_g}p/{carbs_g}c/{fat_g}f/{fiber_g}fi",
        "meal": meal,
        "date": d,
    })


@mcp.tool()
def update_entry(
    entry_id: int,
    food_item: str = "",
    serving: str = "",
    calories: float = None,
    protein_g: float = None,
    carbs_g: float = None,
    fat_g: float = None,
    fiber_g: float = None,
    meal: str = "",
) -> str:
    """Update a previously logged food entry.

    Use this when the user wants to correct something they logged.
    Only the fields you provide will be updated; others stay the same.

    Args:
        entry_id: The ID of the entry to update (from log_meal or get_food_log)
        food_item: New food name (optional)
        serving: New serving description (optional)
        calories: New calorie value (optional)
        protein_g: New protein value (optional)
        carbs_g: New carbs value (optional)
        fat_g: New fat value (optional)
        fiber_g: New fiber value (optional)
        meal: New meal type (optional)
    """
    conn = _get_conn()
    kwargs = {}
    if food_item: kwargs["food_item"] = food_item
    if serving: kwargs["serving"] = serving
    if calories is not None: kwargs["calories"] = calories
    if protein_g is not None: kwargs["protein_g"] = protein_g
    if carbs_g is not None: kwargs["carbs_g"] = carbs_g
    if fat_g is not None: kwargs["fat_g"] = fat_g
    if fiber_g is not None: kwargs["fiber_g"] = fiber_g
    if meal: kwargs["meal"] = meal

    success = db.update_entry(conn, entry_id, **kwargs)

    if success:
        _write_live_dashboard()
        return json.dumps({"status": "updated", "entry_id": entry_id, "fields_changed": list(kwargs.keys())})
    return json.dumps({"status": "error", "message": f"Entry {entry_id} not found or no valid fields to update."})


@mcp.tool()
def delete_entry(entry_id: int) -> str:
    """Delete a logged food entry.

    Args:
        entry_id: The ID of the entry to delete
    """
    conn = _get_conn()
    success = db.delete_entry(conn, entry_id)

    if success:
        _write_live_dashboard()
        return json.dumps({"status": "deleted", "entry_id": entry_id})
    return json.dumps({"status": "error", "message": f"Entry {entry_id} not found."})


# ── Summary & Reporting Tools ──

@mcp.tool()
def daily_summary(log_date: str = "") -> str:
    """Get a complete daily nutrition summary with goal progress.

    Shows all logged foods grouped by meal, daily totals, and
    remaining amounts for each goal. Call this after logging meals
    or when the user asks about their day.

    Args:
        log_date: Date in YYYY-MM-DD format (default: today)
    """
    conn = _get_conn()
    d = log_date or date.today().isoformat()
    entries = db.get_entries(conn, d)
    totals = db.get_daily_totals(conn, d)
    goals = db.get_goals(conn)

    # Group by meal
    meals = {}
    for e in entries:
        m = e["meal"]
        if m not in meals:
            meals[m] = []
        meals[m].append({
            "id": e["id"],
            "food": e["food_item"],
            "serving": e["serving"],
            "calories": e["calories"],
            "protein_g": e["protein_g"],
            "carbs_g": e["carbs_g"],
            "fat_g": e["fat_g"],
            "fiber_g": e["fiber_g"],
            "source": e["source"],
        })

    # Calculate remaining
    remaining = {
        "calories": round(goals["calories"] - totals["calories"], 1),
        "protein_g": round(goals["protein_g"] - totals["protein_g"], 1),
        "carbs_g": round(goals["carbs_g"] - totals["carbs_g"], 1),
        "fat_g": round(goals["fat_g"] - totals["fat_g"], 1),
        "fiber_g": round(goals["fiber_g"] - totals["fiber_g"], 1),
    }

    # Progress percentages
    progress = {}
    for key in goals:
        if goals[key] > 0:
            progress[key] = round((totals.get(key, 0) / goals[key]) * 100, 1)
        else:
            progress[key] = 0

    return json.dumps({
        "date": d,
        "meals": meals,
        "totals": {k: round(v, 1) for k, v in totals.items()},
        "goals": goals,
        "remaining": remaining,
        "progress_pct": progress,
    }, indent=2)


@mcp.tool()
def get_food_log(log_date: str = "", meal: str = "") -> str:
    """Get the raw food log entries for a date.

    Args:
        log_date: Date in YYYY-MM-DD format (default: today)
        meal: Filter by meal type — breakfast, lunch, dinner, snack (optional)
    """
    conn = _get_conn()
    d = log_date or date.today().isoformat()
    entries = db.get_entries(conn, d, meal=meal or None)

    return json.dumps({
        "date": d,
        "meal_filter": meal or "all",
        "count": len(entries),
        "entries": [
            {
                "id": e["id"],
                "time": e["time"],
                "meal": e["meal"],
                "food": e["food_item"],
                "serving": e["serving"],
                "calories": e["calories"],
                "protein_g": e["protein_g"],
                "carbs_g": e["carbs_g"],
                "fat_g": e["fat_g"],
                "fiber_g": e["fiber_g"],
                "source": e["source"],
            }
            for e in entries
        ],
    }, indent=2)


# ── Goal Management Tools ──

@mcp.tool()
def set_goals(
    calories: float = None,
    protein_g: float = None,
    carbs_g: float = None,
    fat_g: float = None,
    fiber_g: float = None,
) -> str:
    """Set daily nutrition goals.

    Only the goals you provide will be updated. Others stay the same.

    Args:
        calories: Daily calorie target
        protein_g: Daily protein target in grams
        carbs_g: Daily carb limit in grams
        fat_g: Daily fat limit in grams
        fiber_g: Daily fiber target in grams
    """
    conn = _get_conn()
    kwargs = {}
    if calories is not None: kwargs["calories"] = calories
    if protein_g is not None: kwargs["protein_g"] = protein_g
    if carbs_g is not None: kwargs["carbs_g"] = carbs_g
    if fat_g is not None: kwargs["fat_g"] = fat_g
    if fiber_g is not None: kwargs["fiber_g"] = fiber_g

    updated = db.set_goals(conn, **kwargs)
    _write_live_dashboard()
    return json.dumps({"status": "goals_updated", "goals": updated})


@mcp.tool()
def get_goals() -> str:
    """Get current daily nutrition goals."""
    conn = _get_conn()
    goals = db.get_goals(conn)
    return json.dumps({"goals": goals})


# ── Dashboard Tool ──

@mcp.tool()
def generate_dashboard(log_date: str = "") -> str:
    """Generate an HTML dashboard with visual progress bars for daily nutrition goals.

    Returns self-contained HTML showing a calorie ring, color-coded macro progress
    bars (protein=blue, fiber=green, carbs=amber, fat=orange), and the full food log.
    The AI assistant should present this HTML to the user as a visual artifact or file.

    Call this after logging meals or when the user asks for a visual summary.

    Args:
        log_date: Date in YYYY-MM-DD format (default: today)
    """
    conn = _get_conn()
    d = log_date or date.today().isoformat()
    entries = db.get_entries(conn, d)
    totals = db.get_daily_totals(conn, d)
    goals = db.get_goals(conn)

    # Group by meal
    meals = {}
    for e in entries:
        m = e["meal"]
        if m not in meals:
            meals[m] = []
        meals[m].append({
            "food": e["food_item"],
            "serving": e["serving"],
            "calories": e["calories"],
            "protein_g": e["protein_g"],
            "carbs_g": e["carbs_g"],
            "fat_g": e["fat_g"],
            "fiber_g": e["fiber_g"],
        })

    html_content = dashboard.generate_dashboard_html(d, meals, totals, goals)

    return json.dumps({
        "status": "ok",
        "date": d,
        "html": html_content,
        "totals": {k: round(v, 1) for k, v in totals.items()},
    })


# ── Live Dashboard Tool ──

@mcp.tool()
def start_live_dashboard(log_date: str = "") -> str:
    """Write the live auto-refreshing dashboard to disk and return its file path.

    The file is at ~/.digest/dashboard.html and auto-refreshes every 3 seconds.
    It is rewritten automatically whenever meals are logged, updated, deleted,
    or goals are changed. Open the returned file:// URL in a browser tab and
    keep it visible alongside the chat for always-current nutrition progress.

    Args:
        log_date: Date in YYYY-MM-DD format (default: today)
    """
    _write_live_dashboard(log_date)
    return json.dumps({
        "status": "ok",
        "path": str(LIVE_DASHBOARD_PATH),
        "url": f"file://{LIVE_DASHBOARD_PATH}",
        "note": "Open the url in a browser tab. It will auto-refresh as you log food.",
    })


# ── Export Tool ──

@mcp.tool()
def export_log(log_date: str = "") -> str:
    """Export the food log as CSV data.

    Args:
        log_date: Export only this date (YYYY-MM-DD). Leave empty for all dates.
    """
    conn = _get_conn()
    csv_data = db.export_csv(conn, date_str=log_date or None)
    return json.dumps({
        "status": "ok",
        "format": "csv",
        "date_filter": log_date or "all",
        "csv_data": csv_data,
    })
