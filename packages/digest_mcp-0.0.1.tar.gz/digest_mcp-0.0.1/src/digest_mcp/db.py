"""SQLite database for food logging and goal tracking."""

import sqlite3
import json
from pathlib import Path
from datetime import datetime, date
from typing import Optional


DEFAULT_DB_PATH = Path.home() / ".digest" / "digest.db"

DEFAULT_GOALS = {
    "calories": 2000,
    "protein_g": 100,
    "carbs_g": 250,
    "fat_g": 65,
    "fiber_g": 25,
}


def get_db(db_path: Optional[Path] = None) -> sqlite3.Connection:
    """Get a database connection, creating tables if needed."""
    path = db_path or DEFAULT_DB_PATH
    path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(path), check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    _create_tables(conn)
    return conn


def _create_tables(conn: sqlite3.Connection):
    conn.executescript("""
        CREATE TABLE IF NOT EXISTS food_log (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            date TEXT NOT NULL,
            time TEXT NOT NULL,
            meal TEXT NOT NULL,
            food_item TEXT NOT NULL,
            serving TEXT NOT NULL DEFAULT '1 serving',
            calories REAL NOT NULL DEFAULT 0,
            protein_g REAL NOT NULL DEFAULT 0,
            carbs_g REAL NOT NULL DEFAULT 0,
            fat_g REAL NOT NULL DEFAULT 0,
            fiber_g REAL NOT NULL DEFAULT 0,
            source TEXT NOT NULL DEFAULT 'estimate',
            source_id TEXT,
            created_at TEXT NOT NULL DEFAULT (datetime('now')),
            updated_at TEXT NOT NULL DEFAULT (datetime('now'))
        );

        CREATE INDEX IF NOT EXISTS idx_food_log_date ON food_log(date);
        CREATE INDEX IF NOT EXISTS idx_food_log_meal ON food_log(date, meal);

        CREATE TABLE IF NOT EXISTS goals (
            id INTEGER PRIMARY KEY CHECK (id = 1),
            calories REAL NOT NULL DEFAULT 2000,
            protein_g REAL NOT NULL DEFAULT 100,
            carbs_g REAL NOT NULL DEFAULT 250,
            fat_g REAL NOT NULL DEFAULT 65,
            fiber_g REAL NOT NULL DEFAULT 25,
            updated_at TEXT NOT NULL DEFAULT (datetime('now'))
        );
    """)
    conn.commit()


# ── Food Log Operations ──

def log_entry(
    conn: sqlite3.Connection,
    date_str: str,
    time_str: str,
    meal: str,
    food_item: str,
    serving: str,
    calories: float,
    protein_g: float,
    carbs_g: float,
    fat_g: float,
    fiber_g: float = 0,
    source: str = "estimate",
    source_id: Optional[str] = None,
) -> int:
    """Log a food entry. Returns the entry ID."""
    cursor = conn.execute(
        """INSERT INTO food_log
           (date, time, meal, food_item, serving, calories, protein_g, carbs_g, fat_g, fiber_g, source, source_id)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
        (date_str, time_str, meal.lower(), food_item, serving,
         round(calories, 1), round(protein_g, 1), round(carbs_g, 1),
         round(fat_g, 1), round(fiber_g, 1), source, source_id),
    )
    conn.commit()
    return cursor.lastrowid


def get_entries(conn: sqlite3.Connection, date_str: str, meal: Optional[str] = None) -> list[dict]:
    """Get all entries for a date, optionally filtered by meal."""
    if meal:
        rows = conn.execute(
            "SELECT * FROM food_log WHERE date = ? AND meal = ? ORDER BY time, id",
            (date_str, meal.lower()),
        ).fetchall()
    else:
        rows = conn.execute(
            "SELECT * FROM food_log WHERE date = ? ORDER BY time, id",
            (date_str,),
        ).fetchall()
    return [dict(r) for r in rows]


def update_entry(conn: sqlite3.Connection, entry_id: int, **kwargs) -> bool:
    """Update specific fields of an entry by ID."""
    allowed = {"meal", "food_item", "serving", "calories", "protein_g",
               "carbs_g", "fat_g", "fiber_g", "source", "time"}
    updates = {k: v for k, v in kwargs.items() if k in allowed and v is not None}
    if not updates:
        return False
    updates["updated_at"] = datetime.now().isoformat()
    set_clause = ", ".join(f"{k} = ?" for k in updates)
    values = list(updates.values()) + [entry_id]
    conn.execute(f"UPDATE food_log SET {set_clause} WHERE id = ?", values)
    conn.commit()
    return True


def delete_entry(conn: sqlite3.Connection, entry_id: int) -> bool:
    """Delete an entry by ID."""
    cursor = conn.execute("DELETE FROM food_log WHERE id = ?", (entry_id,))
    conn.commit()
    return cursor.rowcount > 0


def get_daily_totals(conn: sqlite3.Connection, date_str: str) -> dict:
    """Get summed nutrition totals for a date."""
    row = conn.execute(
        """SELECT
            COALESCE(SUM(calories), 0) as calories,
            COALESCE(SUM(protein_g), 0) as protein_g,
            COALESCE(SUM(carbs_g), 0) as carbs_g,
            COALESCE(SUM(fat_g), 0) as fat_g,
            COALESCE(SUM(fiber_g), 0) as fiber_g,
            COUNT(*) as entry_count
           FROM food_log WHERE date = ?""",
        (date_str,),
    ).fetchone()
    return dict(row)


# ── Goal Operations ──

def get_goals(conn: sqlite3.Connection) -> dict:
    """Get current daily goals. Returns defaults if none set."""
    row = conn.execute("SELECT * FROM goals WHERE id = 1").fetchone()
    if row:
        return {k: row[k] for k in ["calories", "protein_g", "carbs_g", "fat_g", "fiber_g"]}
    return DEFAULT_GOALS.copy()


def set_goals(conn: sqlite3.Connection, **kwargs) -> dict:
    """Set daily goals. Only updates provided fields."""
    current = get_goals(conn)
    current.update({k: v for k, v in kwargs.items() if k in current and v is not None})
    conn.execute(
        """INSERT INTO goals (id, calories, protein_g, carbs_g, fat_g, fiber_g, updated_at)
           VALUES (1, ?, ?, ?, ?, ?, datetime('now'))
           ON CONFLICT(id) DO UPDATE SET
             calories=excluded.calories, protein_g=excluded.protein_g,
             carbs_g=excluded.carbs_g, fat_g=excluded.fat_g,
             fiber_g=excluded.fiber_g, updated_at=excluded.updated_at""",
        (current["calories"], current["protein_g"], current["carbs_g"],
         current["fat_g"], current["fiber_g"]),
    )
    conn.commit()
    return current


# ── Export ──

def export_csv(conn: sqlite3.Connection, date_str: Optional[str] = None) -> str:
    """Export food log as CSV string. Optionally filter by date."""
    import csv
    import io

    if date_str:
        rows = conn.execute(
            "SELECT date, time, meal, food_item, serving, calories, protein_g, carbs_g, fat_g, fiber_g, source FROM food_log WHERE date = ? ORDER BY date, time, id",
            (date_str,),
        ).fetchall()
    else:
        rows = conn.execute(
            "SELECT date, time, meal, food_item, serving, calories, protein_g, carbs_g, fat_g, fiber_g, source FROM food_log ORDER BY date, time, id"
        ).fetchall()

    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["date", "time", "meal", "food_item", "serving", "calories", "protein_g", "carbs_g", "fat_g", "fiber_g", "source"])
    for row in rows:
        writer.writerow(list(row))
    return output.getvalue()
