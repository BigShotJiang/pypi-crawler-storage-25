"""Entry point for running Digest MCP server."""
from digest_mcp.server import mcp

mcp.run()
