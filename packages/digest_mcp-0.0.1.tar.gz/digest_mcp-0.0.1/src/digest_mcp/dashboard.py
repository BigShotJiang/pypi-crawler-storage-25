"""HTML dashboard generator for daily nutrition progress."""

import html as html_lib


def generate_dashboard_html(date_str: str, meals: dict, totals: dict, goals: dict, auto_refresh: bool = False) -> str:
    """Generate a self-contained HTML dashboard with progress bars.

    Args:
        date_str: Date string (YYYY-MM-DD)
        meals: Dict of meal_name -> list of entry dicts
        totals: Dict with calories, protein_g, carbs_g, fat_g, fiber_g totals
        goals: Dict with calorie/macro goals
        auto_refresh: If True, include a meta refresh tag (for live dashboard file)
    """
    refresh_tag = '<meta http-equiv="refresh" content="3">' if auto_refresh else ''
    # Build meal log HTML
    meal_html = ""
    for meal_name in ["breakfast", "lunch", "dinner", "snack", "other"]:
        if meal_name not in meals:
            continue
        meal_html += f'<div class="meal-group"><h3>{html_lib.escape(meal_name.capitalize())}</h3>'
        for e in meals[meal_name]:
            cal = float(e.get("calories", 0))
            p = float(e.get("protein_g", 0))
            c = float(e.get("carbs_g", 0))
            f = float(e.get("fat_g", 0))
            fi = float(e.get("fiber_g", 0))
            item = html_lib.escape(str(e.get("food", e.get("food_item", ""))))
            serving = html_lib.escape(str(e.get("serving", "")))
            meal_html += (
                f'<div class="food-entry">'
                f'<span class="food-name">{item}</span>'
                f'<span class="food-serving">{serving}</span>'
                f'<span class="food-macros">{cal:.0f} cal &middot; {p:.0f}p {c:.0f}c {f:.0f}f {fi:.0f}fi</span>'
                f'</div>'
            )
        meal_html += '</div>'

    if not meal_html:
        meal_html = '<p class="empty-state">No entries yet today.</p>'

    # Nutrient bar configs: (key, label, goal_val, direction, unit, color_id)
    nutrients = [
        ("protein_g",  "Protein", goals.get("protein_g", 100), "target", "g",   "protein"),
        ("fiber_g",    "Fiber",   goals.get("fiber_g", 25),    "target", "g",   "fiber"),
        ("carbs_g",    "Carbs",   goals.get("carbs_g", 250),   "limit",  "g",   "carbs"),
        ("fat_g",      "Fat",     goals.get("fat_g", 65),      "limit",  "g",   "fat"),
    ]

    bars_html = ""
    for key, label, goal_val, direction, unit, color_id in nutrients:
        current = float(totals.get(key, 0))
        pct = (current / goal_val * 100) if goal_val > 0 else 0
        pct_clamped = min(pct, 100)
        remaining = goal_val - current

        if remaining > 0:
            remaining_text = f"{remaining:.0f}{unit} remaining"
        elif remaining == 0:
            remaining_text = "Goal met"
        else:
            remaining_text = f"{abs(remaining):.0f}{unit} over"

        over_class = ""
        if direction == "limit" and pct > 100:
            over_class = " over"
        elif direction == "limit" and pct >= 85:
            over_class = " approaching"

        direction_icon = "&#x25B2;" if direction == "target" else "&#x25BC;"
        direction_label = "target" if direction == "target" else "limit"

        bars_html += f'''
        <div class="nutrient-row {color_id}{over_class}">
            <div class="nutrient-header">
                <div class="nutrient-label">
                    <span class="nutrient-dot {color_id}"></span>
                    <span class="nutrient-name">{label}</span>
                    <span class="nutrient-direction {direction_label}">{direction_icon} {direction_label}</span>
                </div>
                <div class="nutrient-values">
                    <span class="nutrient-current">{current:.0f}</span>
                    <span class="nutrient-separator">/</span>
                    <span class="nutrient-goal">{goal_val:.0f}{unit}</span>
                </div>
            </div>
            <div class="bar-track {color_id}">
                <div class="bar-fill {color_id}" style="width: {pct_clamped}%"></div>
            </div>
            <div class="nutrient-remaining">{remaining_text}</div>
        </div>
        '''

    cal_current = float(totals.get("calories", 0))
    cal_goal = float(goals.get("calories", 2000))
    calorie_ring = _generate_calorie_ring(cal_current, cal_goal)

    return f'''<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
{refresh_tag}
<title>Nutrition — {date_str}</title>
<style>
    * {{ margin: 0; padding: 0; box-sizing: border-box; }}

    body {{
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
        background: #ffffff;
        color: #1f2328;
        padding: 24px;
        max-width: 520px;
        margin: 0 auto;
    }}

    .header {{
        display: flex;
        justify-content: space-between;
        align-items: baseline;
        margin-bottom: 28px;
        padding-bottom: 16px;
        border-bottom: 1px solid #d8dee4;
    }}
    .header h1 {{ font-size: 20px; font-weight: 600; color: #1f2328; }}
    .header .date {{ font-size: 14px; color: #656d76; }}

    /* ── Nutrient color system ── */
    .nutrient-dot.protein {{ background: #0969da; }}
    .bar-track.protein {{ background: #ddf4ff; border-color: #b6d9f7; }}
    .bar-fill.protein {{ background: #0969da; }}
    .nutrient-row.protein .nutrient-remaining {{ color: #0969da; }}

    .nutrient-dot.fiber {{ background: #1a7f37; }}
    .bar-track.fiber {{ background: #dafbe1; border-color: #aceebb; }}
    .bar-fill.fiber {{ background: #1a7f37; }}
    .nutrient-row.fiber .nutrient-remaining {{ color: #1a7f37; }}

    .nutrient-dot.carbs {{ background: #9a6700; }}
    .bar-track.carbs {{ background: #fff8c5; border-color: #ecd479; }}
    .bar-fill.carbs {{ background: #bf8700; }}
    .nutrient-row.carbs .nutrient-remaining {{ color: #9a6700; }}

    .nutrient-dot.fat {{ background: #bc4c00; }}
    .bar-track.fat {{ background: #fff1e5; border-color: #ffd8b5; }}
    .bar-fill.fat {{ background: #bc4c00; }}
    .nutrient-row.fat .nutrient-remaining {{ color: #bc4c00; }}

    /* Over-limit states */
    .nutrient-row.approaching .nutrient-remaining {{ font-weight: 600; }}
    .nutrient-row.over .bar-fill {{ background: #cf222e !important; }}
    .nutrient-row.over .bar-track {{ background: #ffebe9 !important; border-color: #ffc1ba !important; }}
    .nutrient-row.over .nutrient-remaining {{ color: #cf222e !important; font-weight: 600; }}
    .nutrient-row.over .nutrient-current {{ color: #cf222e; }}

    /* ── Progress bars ── */
    .nutrient-row {{ margin-bottom: 20px; }}
    .nutrient-header {{
        display: flex; justify-content: space-between;
        align-items: baseline; margin-bottom: 6px;
    }}
    .nutrient-label {{ display: flex; align-items: center; gap: 8px; }}
    .nutrient-dot {{ width: 10px; height: 10px; border-radius: 50%; flex-shrink: 0; }}
    .nutrient-name {{ font-size: 15px; font-weight: 500; color: #1f2328; }}
    .nutrient-direction {{
        font-size: 10px; padding: 1px 6px; border-radius: 10px;
        font-weight: 500; text-transform: uppercase; letter-spacing: 0.5px;
    }}
    .nutrient-direction.target {{ background: #ddf4ff; color: #0969da; }}
    .nutrient-direction.limit {{ background: #fff8c5; color: #9a6700; }}
    .nutrient-values {{ font-size: 15px; font-variant-numeric: tabular-nums; }}
    .nutrient-current {{ font-weight: 600; color: #1f2328; }}
    .nutrient-separator {{ color: #afb8c1; margin: 0 2px; }}
    .nutrient-goal {{ color: #656d76; }}

    .bar-track {{
        height: 10px; border-radius: 5px; overflow: hidden;
        position: relative; border: 1px solid #d8dee4;
    }}
    .bar-fill {{
        height: 100%; border-radius: 5px;
        transition: width 0.4s ease;
    }}
    .nutrient-remaining {{ font-size: 12px; margin-top: 4px; font-weight: 500; }}

    /* ── Calorie ring ── */
    .calorie-ring {{ display: flex; justify-content: center; margin-bottom: 28px; }}
    .ring-container {{ position: relative; width: 140px; height: 140px; }}
    .ring-container svg {{ transform: rotate(-90deg); }}
    .ring-bg {{ fill: none; stroke: #eaeef2; stroke-width: 10; }}
    .ring-fill {{
        fill: none; stroke-width: 10; stroke-linecap: round;
        transition: stroke-dashoffset 0.6s ease;
    }}
    .ring-text {{
        position: absolute; top: 50%; left: 50%;
        transform: translate(-50%, -50%); text-align: center;
    }}
    .ring-current {{ font-size: 28px; font-weight: 700; color: #1f2328; line-height: 1; display: block; }}
    .ring-label {{ font-size: 11px; color: #656d76; margin-top: 2px; display: block; }}

    /* ── Meal log ── */
    .meals-section {{
        margin-top: 32px; padding-top: 24px;
        border-top: 1px solid #d8dee4;
    }}
    .meals-section > h2 {{
        font-size: 14px; font-weight: 500; color: #656d76;
        text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 16px;
    }}
    .meal-group {{ margin-bottom: 16px; }}
    .meal-group h3 {{ font-size: 13px; font-weight: 600; color: #656d76; margin-bottom: 6px; }}
    .food-entry {{
        display: flex; gap: 8px; align-items: baseline;
        padding: 4px 0; font-size: 13px;
    }}
    .food-name {{ color: #1f2328; font-weight: 500; flex-shrink: 0; }}
    .food-serving {{ color: #656d76; flex-shrink: 0; }}
    .food-macros {{
        color: #656d76; margin-left: auto;
        font-variant-numeric: tabular-nums; white-space: nowrap;
    }}
    .empty-state {{ color: #afb8c1; font-style: italic; font-size: 14px; }}
</style>
</head>
<body>
    <div class="header">
        <h1>Nutrition</h1>
        <span class="date">{date_str}</span>
    </div>

    {calorie_ring}

    {bars_html}

    <div class="meals-section">
        <h2>Food Log</h2>
        {meal_html}
    </div>
</body>
</html>'''


def _generate_calorie_ring(current: float, goal: float) -> str:
    pct = min(current / goal, 1.2) if goal > 0 else 0
    radius = 58
    circumference = 2 * 3.14159 * radius
    offset = circumference * (1 - min(pct, 1.0))

    if pct > 1.0:
        color = "#cf222e"
    elif pct >= 0.75:
        color = "#6639ba"
    elif pct >= 0.4:
        color = "#8b7ec8"
    else:
        color = "#c5cdd5"

    remaining = goal - current
    sub_label = f"{remaining:.0f} remaining" if remaining > 0 else f"{abs(remaining):.0f} over"

    return f'''
    <div class="calorie-ring">
        <div class="ring-container">
            <svg width="140" height="140">
                <circle class="ring-bg" cx="70" cy="70" r="{radius}"/>
                <circle class="ring-fill" cx="70" cy="70" r="{radius}"
                    stroke="{color}"
                    stroke-dasharray="{circumference}"
                    stroke-dashoffset="{offset}"/>
            </svg>
            <div class="ring-text">
                <span class="ring-current">{current:.0f}</span>
                <span class="ring-label">{sub_label}</span>
            </div>
        </div>
    </div>'''
