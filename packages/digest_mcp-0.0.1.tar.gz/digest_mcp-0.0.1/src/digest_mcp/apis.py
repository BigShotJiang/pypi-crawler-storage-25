"""Food data API integrations — USDA FoodData Central + Open Food Facts."""

import httpx
from typing import Optional


USDA_BASE = "https://api.nal.usda.gov/fdc/v1"
OFF_BASE = "https://world.openfoodfacts.net/api/v2"
USER_AGENT = "Digest/0.0.1 (nutrition-tracking-mcp; mya@twobitcircus.org)"


# ── Unified result format ──

def _normalize_nutrient(nutrients: list[dict], nutrient_id: int, fallback_name: str = "") -> float:
    """Extract a nutrient value from USDA nutrient list by ID."""
    for n in nutrients:
        if n.get("nutrientId") == nutrient_id or n.get("nutrientNumber") == str(nutrient_id):
            return round(float(n.get("value", 0)), 1)
    return 0.0


def _usda_to_standard(item: dict) -> dict:
    """Convert a USDA food item to our standard format."""
    nutrients = item.get("foodNutrients", [])

    # USDA nutrient IDs: 1008=Energy(kcal), 1003=Protein, 1005=Carbs, 1004=Fat, 1079=Fiber
    return {
        "name": item.get("description", "Unknown"),
        "brand": item.get("brandName") or item.get("brandOwner", ""),
        "source": "usda",
        "source_id": str(item.get("fdcId", "")),
        "serving": f"{item.get('servingSize', 100)}{item.get('servingSizeUnit', 'g')}",
        "calories": _normalize_nutrient(nutrients, 1008),
        "protein_g": _normalize_nutrient(nutrients, 1003),
        "carbs_g": _normalize_nutrient(nutrients, 1005),
        "fat_g": _normalize_nutrient(nutrients, 1004),
        "fiber_g": _normalize_nutrient(nutrients, 1079),
        "data_type": item.get("dataType", ""),
    }


def _off_to_standard(product: dict) -> dict:
    """Convert an Open Food Facts product to our standard format."""
    n = product.get("nutriments", {})
    serving = product.get("serving_size", "")
    if not serving:
        serving = f"{product.get('product_quantity', '100')}g"

    return {
        "name": product.get("product_name") or product.get("product_name_en", "Unknown"),
        "brand": product.get("brands", ""),
        "source": "openfoodfacts",
        "source_id": product.get("code", ""),
        "serving": serving,
        "calories": round(float(n.get("energy-kcal_serving", n.get("energy-kcal_100g", 0))), 1),
        "protein_g": round(float(n.get("proteins_serving", n.get("proteins_100g", 0))), 1),
        "carbs_g": round(float(n.get("carbohydrates_serving", n.get("carbohydrates_100g", 0))), 1),
        "fat_g": round(float(n.get("fat_serving", n.get("fat_100g", 0))), 1),
        "fiber_g": round(float(n.get("fiber_serving", n.get("fiber_100g", 0))), 1),
        "data_type": "Branded",
    }


# ── USDA FoodData Central ──

async def search_usda(
    query: str,
    api_key: str = "DEMO_KEY",
    page_size: int = 5,
    data_type: Optional[list[str]] = None,
) -> list[dict]:
    """Search USDA FoodData Central. Returns standardized results."""
    params = {
        "query": query,
        "api_key": api_key,
        "pageSize": page_size,
    }
    if data_type:
        params["dataType"] = ",".join(data_type)

    async with httpx.AsyncClient(timeout=15) as client:
        resp = await client.get(f"{USDA_BASE}/foods/search", params=params)
        resp.raise_for_status()
        data = resp.json()

    foods = data.get("foods", [])
    return [_usda_to_standard(f) for f in foods]


async def get_usda_food(fdc_id: str, api_key: str = "DEMO_KEY") -> Optional[dict]:
    """Get a specific food by USDA FDC ID."""
    async with httpx.AsyncClient(timeout=15) as client:
        resp = await client.get(
            f"{USDA_BASE}/food/{fdc_id}",
            params={"api_key": api_key},
        )
        if resp.status_code == 404:
            return None
        resp.raise_for_status()
        return _usda_to_standard(resp.json())


# ── Open Food Facts ──

async def search_off(query: str, page_size: int = 5) -> list[dict]:
    """Search Open Food Facts. Returns standardized results."""
    headers = {"User-Agent": USER_AGENT}
    params = {
        "search_terms": query,
        "search_simple": 1,
        "action": "process",
        "json": 1,
        "page_size": page_size,
    }

    try:
        async with httpx.AsyncClient(timeout=15) as client:
            resp = await client.get(
                "https://world.openfoodfacts.org/cgi/search.pl",
                params=params,
                headers=headers,
            )
            resp.raise_for_status()
            data = resp.json()
    except (httpx.HTTPStatusError, httpx.ConnectError, httpx.TimeoutException):
        return []  # Degrade gracefully — USDA results still available

    products = data.get("products", [])
    results = []
    for p in products:
        try:
            results.append(_off_to_standard(p))
        except (KeyError, ValueError, TypeError):
            continue
    return results


async def lookup_barcode(barcode: str) -> Optional[dict]:
    """Look up a product by barcode via Open Food Facts."""
    headers = {"User-Agent": USER_AGENT}
    try:
        async with httpx.AsyncClient(timeout=15) as client:
            resp = await client.get(
                f"{OFF_BASE}/product/{barcode}",
                headers=headers,
            )
            if resp.status_code == 404:
                return None
            resp.raise_for_status()
            data = resp.json()
    except (httpx.HTTPStatusError, httpx.ConnectError, httpx.TimeoutException):
        return None

    if data.get("status") != 1:
        return None

    return _off_to_standard(data.get("product", {}))


# ── Combined search ──

async def search_food(query: str, api_key: str = "DEMO_KEY", max_results: int = 8) -> list[dict]:
    """Search both USDA and Open Food Facts, deduplicated and ranked."""
    import asyncio

    half = max(max_results // 2, 3)
    usda_task = search_usda(query, api_key=api_key, page_size=half)
    off_task = search_off(query, page_size=half)

    usda_results, off_results = await asyncio.gather(
        usda_task, off_task, return_exceptions=True
    )

    results = []
    if isinstance(usda_results, list):
        results.extend(usda_results)
    if isinstance(off_results, list):
        results.extend(off_results)

    # Deduplicate by name similarity (simple)
    seen_names = set()
    deduped = []
    for r in results:
        name_key = r["name"].lower().strip()
        if name_key not in seen_names:
            seen_names.add(name_key)
            deduped.append(r)

    return deduped[:max_results]
