"""Diagnostics utilities for dynestyx."""
