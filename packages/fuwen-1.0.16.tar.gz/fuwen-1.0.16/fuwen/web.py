from vnpy.event import EventEngine
from vnpy.trader.engine import MainEngine
import argparse

# 尝试导入 web 框架
web_framework = None
try:
    from flask import Flask, jsonify
    web_framework = "flask"
except ImportError:
    try:
        from fastapi import FastAPI
        from fastapi.responses import JSONResponse
        web_framework = "fastapi"
    except ImportError:
        pass


def create_flask_app(main_engine, event_engine):
    """创建 Flask 应用"""
    app = Flask(__name__)
    
    @app.route("/api/strategies", methods=["GET"])
    def get_strategies():
        cta_engine = main_engine.get_engine("cta")
        strategies = cta_engine.strategies
        return jsonify([{"name": name, "status": strategy.status} for name, strategy in strategies.items()])
    
    @app.route("/api/data", methods=["GET"])
    def get_data():
        return jsonify({"message": "数据接口"})
    
    return app


def create_fastapi_app(main_engine, event_engine):
    """创建 FastAPI 应用"""
    app = FastAPI()
    
    @app.get("/api/strategies")
    def get_strategies():
        cta_engine = main_engine.get_engine("cta")
        strategies = cta_engine.strategies
        return [{"name": name, "status": strategy.status} for name, strategy in strategies.items()]
    
    @app.get("/api/data")
    def get_data():
        return {"message": "数据接口"}
    
    return app


def main():
    """启动 Web 服务"""
    parser = argparse.ArgumentParser(description="Fuwen Web 服务")
    parser.add_argument("--host", type=str, default="0.0.0.0", help="主机地址")
    parser.add_argument("--port", type=int, default=8000, help="端口号")
    
    args = parser.parse_args()
    
    event_engine = EventEngine()
    main_engine = MainEngine(event_engine)
    
    # 加载应用

    
    event_engine.start()
    
    # 创建 web 应用
    if web_framework == "flask":
        app = create_flask_app(main_engine, event_engine)
        app.run(host=args.host, port=args.port, debug=True)
    elif web_framework == "fastapi":
        app = create_fastapi_app(main_engine, event_engine)
        import uvicorn
        uvicorn.run(app, host=args.host, port=args.port)
    else:
        print("请安装 Flask 或 FastAPI 来运行 Web 服务")
    
    # 关闭引擎
    main_engine.close()
    event_engine.stop()


if __name__ == "__main__":
    main()