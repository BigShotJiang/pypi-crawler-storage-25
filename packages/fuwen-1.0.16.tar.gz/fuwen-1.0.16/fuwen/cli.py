import argparse
from vnpy.event import EventEngine
from vnpy.trader.engine import MainEngine


def main():
    """启动命令行工具"""
    parser = argparse.ArgumentParser(description="Fuwen CLI 工具")
    parser.add_argument("--mode", type=str, default="backtest", choices=["backtest", "run", "help"], 
                        help="运行模式: backtest (回测), run (实盘), help (帮助)")
    parser.add_argument("--strategy", type=str, default="", help="策略名称")
    parser.add_argument("--symbol", type=str, default="", help="交易标的")
    parser.add_argument("--start", type=str, default="", help="回测开始日期，格式：YYYYMMDD")
    parser.add_argument("--end", type=str, default="", help="回测结束日期，格式：YYYYMMDD")
    
    args = parser.parse_args()
    
    if args.mode == "help":
        parser.print_help()
        return
    
    event_engine = EventEngine()
    main_engine = MainEngine(event_engine)
    
    if args.mode == "backtest":
        main_engine.add_app(CtaBacktesterApp)
        print(f"启动回测模式，策略: {args.strategy}, 标的: {args.symbol}, 时间范围: {args.start} to {args.end}")
        # 这里可以添加具体的回测逻辑
    elif args.mode == "run":
        main_engine.add_app(CtaStrategyApp)
        print(f"启动实盘模式，策略: {args.strategy}")
        # 这里可以添加具体的实盘运行逻辑
    
    event_engine.start()
    
    try:
        input("按回车键退出...")
    except KeyboardInterrupt:
        pass
    finally:
        main_engine.close()
        event_engine.stop()


if __name__ == "__main__":
    main()