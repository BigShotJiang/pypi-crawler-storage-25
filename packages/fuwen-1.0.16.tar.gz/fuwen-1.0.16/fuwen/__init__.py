__version__ = "1.0.0"

from . import gui
from . import cli
from . import web
from . import main


def version():
    return __version__


def helloworld(name="None"):
    if name:
        res_msg = (f"Hello {name}!")
    else:
        res_msg = "Hello World!"
    return res_msg


def hello(name=None):
    return helloworld(name)


def hi(name=None):
    return helloworld(name)


if __name__ == '__main__':
    print(f"fuwen version: {version()}")
