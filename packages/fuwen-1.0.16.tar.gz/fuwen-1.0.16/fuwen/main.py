import argparse
from . import gui
from . import cli
from . import web


def main():
    """Fuwen 主入口"""
    parser = argparse.ArgumentParser(description="Fuwen 交易框架主入口")
    
    subparsers = parser.add_subparsers(dest="command", help="子命令")
    
    # GUI 子命令
    gui_parser = subparsers.add_parser("gui", help="启动 GUI 界面")
    gui_parser.add_argument("action", nargs="?", default="start", choices=["start"], help="操作：start (启动)")
    
    # CLI 子命令
    cli_parser = subparsers.add_parser("cli", help="启动命令行工具")
    cli_parser.add_argument("action", nargs="?", default="start", choices=["start"], help="操作：start (启动)")
    cli_parser.add_argument("--mode", type=str, default="backtest", choices=["backtest", "run"], 
                         help="运行模式: backtest (回测), run (实盘)")
    cli_parser.add_argument("--strategy", type=str, default="", help="策略名称")
    cli_parser.add_argument("--symbol", type=str, default="", help="交易标的")
    cli_parser.add_argument("--start", type=str, default="", help="回测开始日期，格式：YYYYMMDD")
    cli_parser.add_argument("--end", type=str, default="", help="回测结束日期，格式：YYYYMMDD")
    
    # Web 子命令
    web_parser = subparsers.add_parser("web", help="启动 Web 服务")
    web_parser.add_argument("action", nargs="?", default="start", choices=["start"], help="操作：start (启动)")
    web_parser.add_argument("--host", type=str, default="0.0.0.0", help="主机地址")
    web_parser.add_argument("--port", type=int, default=8000, help="端口号")
    
    args = parser.parse_args()
    
    if args.command == "gui":
        print("启动 GUI 界面...")
        gui.main()
    elif args.command == "cli":
        print(f"启动命令行工具，模式: {args.mode}")
        # 传递参数给 cli.main()
        import sys
        sys.argv = ["fuwen-cli"]
        if args.mode:
            sys.argv.extend(["--mode", args.mode])
        if args.strategy:
            sys.argv.extend(["--strategy", args.strategy])
        if args.symbol:
            sys.argv.extend(["--symbol", args.symbol])
        if args.start:
            sys.argv.extend(["--start", args.start])
        if args.end:
            sys.argv.extend(["--end", args.end])
        cli.main()
    elif args.command == "web":
        print(f"启动 Web 服务，地址: {args.host}:{args.port}")
        # 传递参数给 web.main()
        import sys
        sys.argv = ["fuwen-web"]
        if args.host:
            sys.argv.extend(["--host", args.host])
        if args.port:
            sys.argv.extend(["--port", str(args.port)])
        web.main()
    else:
        parser.print_help()


if __name__ == "__main__":
    main()