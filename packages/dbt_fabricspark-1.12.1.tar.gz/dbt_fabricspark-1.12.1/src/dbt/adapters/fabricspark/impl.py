import os
import re
from concurrent.futures import Future
from dataclasses import dataclass
from typing import (
    TYPE_CHECKING,
    Any,
    Callable,
    Dict,
    FrozenSet,
    Iterable,
    List,
    Optional,
    Set,
    Tuple,
    Union,
)

from typing_extensions import TypeAlias

if TYPE_CHECKING:
    # Indirectly imported via agate_helper, which is lazy loaded further downfile.
    # Used by mypy for earlier type hints.
    import agate

from dbt_common.clients.agate_helper import DEFAULT_TYPE_TESTER
from dbt_common.contracts.constraints import ConstraintType
from dbt_common.exceptions import CompilationError, DbtRuntimeError
from dbt_common.utils import AttrDict, executor

from dbt.adapters.base import AdapterConfig, BaseRelation, available
from dbt.adapters.base.impl import ConstraintSupport, catch_as_completed
from dbt.adapters.base.relation import InformationSchema
from dbt.adapters.contracts.relation import RelationConfig, RelationType
from dbt.adapters.events.logging import AdapterLogger
from dbt.adapters.fabricspark import FabricSparkColumn, FabricSparkConnectionManager, mlv_api
from dbt.adapters.fabricspark.relation import FabricSparkRelation
from dbt.adapters.sql import SQLAdapter

logger = AdapterLogger("fabricspark")

GET_COLUMNS_IN_RELATION_RAW_MACRO_NAME = "get_columns_in_relation_raw"
LIST_SCHEMAS_MACRO_NAME = "list_schemas"
LIST_RELATIONS_MACRO_NAME = "list_relations_without_caching"
LIST_RELATIONS_SHOW_TABLES_MACRO_NAME = "list_relations_show_tables_without_caching"
DESCRIBE_TABLE_EXTENDED_MACRO_NAME = "describe_table_extended_without_caching"

KEY_TABLE_OWNER = "Owner"
KEY_TABLE_STATISTICS = "Statistics"

TABLE_OR_VIEW_NOT_FOUND_MESSAGES = (
    "[TABLE_OR_VIEW_NOT_FOUND]",
    "Table or view not found",
    "NoSuchTableException",
)


@dataclass
class FabricSparkConfig(AdapterConfig):
    file_format: str = "parquet"
    location_root: Optional[str] = None
    partition_by: Optional[Union[List[str], str]] = None
    clustered_by: Optional[Union[List[str], str]] = None
    buckets: Optional[int] = None
    options: Optional[Dict[str, str]] = None
    merge_update_columns: Optional[str] = None
    # Cross-workspace 4-part naming. When set on a model's
    # ``{{ config() }}``, the rendered relation becomes
    # ``\`workspace_name\`.\`database\`.\`schema\`.identifier`` — enabling
    # cross-workspace reads (``SELECT``) and writes (``CREATE TABLE AS
    # SELECT``) against schema-enabled lakehouses in another Fabric workspace.
    # Allowed only when the target *write* lakehouse is schema-enabled; the
    # macro layer raises a parse-time error otherwise. The target schema is
    # auto-created via the standard ``fabricspark__create_schema`` flow, which
    # Fabric Livy supports cross-workspace via 3-part
    # ``CREATE DATABASE IF NOT EXISTS \`WS2\`.\`lh\`.\`schema\``` DDL.
    workspace_name: Optional[str] = None


class FabricSparkAdapter(SQLAdapter):
    COLUMN_NAMES = (
        "table_database",
        "table_schema",
        "table_name",
        "table_type",
        "table_comment",
        "table_owner",
        "column_name",
        "column_index",
        "column_type",
        "column_comment",
        "stats:bytes:label",
        "stats:bytes:value",
        "stats:bytes:description",
        "stats:bytes:include",
        "stats:rows:label",
        "stats:rows:value",
        "stats:rows:description",
        "stats:rows:include",
    )
    INFORMATION_COLUMNS_REGEX = re.compile(r"^ \|-- (.*): (.*) \(nullable = (.*)\b", re.MULTILINE)
    INFORMATION_OWNER_REGEX = re.compile(r"^Owner: (.*)$", re.MULTILINE)
    INFORMATION_STATISTICS_REGEX = re.compile(r"^Statistics: (.*)$", re.MULTILINE)

    CONSTRAINT_SUPPORT = {
        ConstraintType.check: ConstraintSupport.NOT_ENFORCED,
        ConstraintType.not_null: ConstraintSupport.NOT_ENFORCED,
        ConstraintType.unique: ConstraintSupport.NOT_ENFORCED,
        ConstraintType.primary_key: ConstraintSupport.NOT_ENFORCED,
        ConstraintType.foreign_key: ConstraintSupport.NOT_ENFORCED,
    }

    Relation: TypeAlias = FabricSparkRelation
    RelationInfo = Tuple[str, str, str]
    Column: TypeAlias = FabricSparkColumn
    ConnectionManager: TypeAlias = FabricSparkConnectionManager
    AdapterSpecificConfigs: TypeAlias = FabricSparkConfig

    @available
    def is_lakehouse_schemas_enabled(self) -> bool:
        """Expose lakehouse_schemas_enabled to macros via adapter.

        Uses the class-level flag on FabricSparkRelation which is set during
        connection open. This avoids requiring a thread connection, which
        may not exist during manifest parsing when generate_schema_name
        is called.

        Note: This returns False during manifest parsing (before connection.open).
        The generate_schema_name macro uses a parse-time fallback by comparing
        target.schema != target.lakehouse to infer schema-enabled mode.
        """
        return FabricSparkRelation._schemas_enabled

    @available
    def validate_workspace_name_supported(
        self,
        workspace_name: Optional[str],
        target_database: Optional[str] = None,
        target_schema: Optional[str] = None,
        target_lakehouse: Optional[str] = None,
    ) -> None:
        """Parse-time guard for cross-workspace 4-part naming.

        Raises ``DbtRuntimeError`` when ``workspace_name`` is set but the
        session-bound lakehouse is non-schema-enabled. Fabric Livy only
        supports 4-part naming against schema-enabled lakehouses, and that
        constraint applies symmetrically to both cross-workspace reads
        (``SELECT``) and cross-workspace writes (``CREATE TABLE AS SELECT``).

        Parameters
        ----------
        workspace_name : Optional[str]
            The model's ``workspace_name`` config value (may be None / empty).
        target_database : Optional[str]
            The lakehouse the model writes to (post-resolution by
            ``generate_database_name``). Currently informational.
        target_schema : Optional[str]
            The model's resolved schema (post ``generate_schema_name``).
        target_lakehouse : Optional[str]
            The profile's ``lakehouse`` value (``target.lakehouse``).
        """
        if not workspace_name:
            return

        if FabricSparkRelation._schemas_enabled:
            return

        if target_schema and target_lakehouse and target_schema != target_lakehouse:
            return

        raise DbtRuntimeError(
            "config.workspace_name=" + repr(workspace_name) + " requires a "
            "schema-enabled lakehouse for the model's write target. Fabric "
            "Livy only supports 4-part naming against schema-enabled "
            "lakehouses. Either:\n"
            "  1. Use a schema-enabled lakehouse and set `schema` to a value "
            "different from `lakehouse` in profiles.yml (e.g. schema: dbo); or\n"
            "  2. Remove `workspace_name` from this model's config; or\n"
            "  3. Use a OneLake shortcut to bring the cross-workspace data "
            "into the current workspace.\n"
            "See README → 'Cross-Workspace 4-Part Naming' for details."
        )

    @available
    def is_local_mode(self) -> bool:
        """Expose local mode flag to macros via adapter.

        Falls back to False if no connection is available (e.g. during parsing).
        """
        try:
            conn = self.connections.get_thread_connection()
            return conn.credentials.is_local_mode
        except Exception:
            return False

    @available
    def mlv_run_on_demand(self, lakehouse_id: Optional[str] = None) -> Dict[str, Any]:
        """Trigger an on-demand MLV lineage refresh via the Fabric REST API.

        Exposed to macros as ``adapter.mlv_run_on_demand()``.
        Raises ``MLVApiError`` (a ``DbtRuntimeError``) on failure, which
        causes the model to fail.
        """
        conn = self.connections.get_thread_connection()
        return mlv_api.run_on_demand_refresh(conn.credentials, lakehouse_id)

    @available
    def mlv_create_or_update_schedule(
        self, schedule_config: Dict[str, Any], lakehouse_id: Optional[str] = None
    ) -> Dict[str, Any]:
        """Create or update an MLV refresh schedule via the Fabric REST API.

        Exposed to macros as ``adapter.mlv_create_or_update_schedule(schedule_config)``.
        Raises ``MLVApiError`` (a ``DbtRuntimeError``) on failure, which
        causes the model to fail.
        """
        conn = self.connections.get_thread_connection()
        return mlv_api.create_or_update_schedule(conn.credentials, schedule_config, lakehouse_id)

    @available
    def mlv_resolve_lakehouse_id(self, lakehouse_name: str) -> str:
        """Resolve a lakehouse name to its ID within the workspace.

        Exposed to macros as ``adapter.mlv_resolve_lakehouse_id(lakehouse_name)``.
        Uses the Fabric REST API with caching to avoid repeated calls.
        Raises ``MLVApiError`` if the lakehouse is not found.
        """
        conn = self.connections.get_thread_connection()
        return mlv_api.resolve_lakehouse_id(conn.credentials, lakehouse_name)

    @available
    def mlv_validate_prerequisites(self) -> None:
        """Validate runtime prerequisites for Materialized Lake View models.

        Reads the cached result from ``check_mlv_prerequisites()`` which
        ran at connection open time. If prerequisites are not met, raises
        ``DbtRuntimeError`` immediately — no SQL is executed first.
        """
        error = FabricSparkConnectionManager.mlv_prereq_error
        if error:
            raise DbtRuntimeError(error)

    @available
    def mlv_validate_delta_sources(self, upstream_relations: List[Dict[str, Any]]) -> None:
        """Validate that all upstream source tables are Delta format.

        Parameters
        ----------
        upstream_relations : list of dict
            Each dict has keys ``database``, ``schema``, ``identifier`` for an
            upstream table.

        Raises ``DbtRuntimeError`` if any source is not a Delta table.
        """
        non_delta = []
        for rel_info in upstream_relations:
            try:
                relation = self.Relation.create(
                    database=rel_info.get("database"),
                    schema=rel_info.get("schema"),
                    identifier=rel_info["identifier"],
                    type=RelationType.Table,
                )
                # Use list_relations to find the relation with metadata
                relations = self.list_relations_without_caching(
                    self.Relation.create(
                        database=rel_info.get("database"),
                        schema=rel_info.get("schema"),
                        identifier=None,
                        type=RelationType.Table,
                    )
                )
                found = False
                for r in relations:
                    if r.identifier == rel_info["identifier"]:
                        if hasattr(r, "is_delta") and not r.is_delta:
                            non_delta.append(str(relation))
                        found = True
                        break
                if not found:
                    logger.warning(
                        f"Could not verify Delta format for {relation} — table not found. "
                        "Proceeding, but MLV creation may fail if the table is not Delta."
                    )
            except Exception as e:
                logger.warning(f"Could not verify Delta format for {rel_info}: {e}")

        if non_delta:
            raise DbtRuntimeError(
                "Materialized Lake Views require all source tables to be Delta format. "
                f"The following tables are NOT Delta: {', '.join(non_delta)}"
            )

    @classmethod
    def date_function(cls) -> str:
        return "current_timestamp()"

    @classmethod
    def convert_text_type(cls, agate_table: "agate.Table", col_idx: int) -> str:
        return "string"

    @classmethod
    def convert_number_type(cls, agate_table: "agate.Table", col_idx: int) -> str:
        import agate

        decimals = agate_table.aggregate(agate.MaxPrecision(col_idx))
        return "double" if decimals else "bigint"

    @classmethod
    def convert_integer_type(cls, agate_table: "agate.Table", col_idx: int) -> str:
        return "bigint"

    @classmethod
    def convert_date_type(cls, agate_table: "agate.Table", col_idx: int) -> str:
        return "date"

    @classmethod
    def convert_time_type(cls, agate_table: "agate.Table", col_idx: int) -> str:
        return "time"

    @classmethod
    def convert_datetime_type(cls, agate_table: "agate.Table", col_idx: int) -> str:
        return "timestamp"

    def quote(self, identifier: str) -> str:
        return "`{}`".format(identifier)

    def _get_relation_information(self, row: "agate.Row") -> RelationInfo:
        """relation info was fetched with SHOW TABLES EXTENDED"""
        try:
            _schema, name, is_temporary, information = row
        except ValueError:
            raise DbtRuntimeError(
                f'Invalid value from "show tables extended ...", got {len(row)} values, expected 4'
            )

        # ``show table extended`` returns session-scoped temporary views alongside
        # real relations. When multiple xdist workers share a single Livy session
        # (tests are sharded across N sessions by worker index), temp views
        # created by one worker's test leak into every other worker's listing
        # for the same session. Surface them as a sentinel that the caller
        # filters out; otherwise ``docs generate`` and other catalog lookups try
        # to describe relations that don't exist in the requested schema.
        if is_temporary:
            return None  # type: ignore[return-value]

        return _schema, name, information

    def _get_relation_information_using_describe(self, row: "agate.Row") -> RelationInfo:
        """Relation info fetched using SHOW TABLES and an auxiliary DESCRIBE statement"""
        try:
            _schema, name, is_temporary = row
        except ValueError:
            raise DbtRuntimeError(
                f'Invalid value from "show tables ...", got {len(row)} values, expected 3'
            )

        # Skip session-scoped temp views — see _get_relation_information.
        if is_temporary:
            return None  # type: ignore[return-value]

        table_name = f"{_schema}.{name}"
        try:
            table_results = self.execute_macro(
                DESCRIBE_TABLE_EXTENDED_MACRO_NAME, kwargs={"table_name": table_name}
            )
        except DbtRuntimeError as e:
            logger.debug(f"Error while retrieving information about {table_name}: {e.msg}")
            table_results = AttrDict()

        information = ""
        for info_row in table_results:
            info_type, info_value, _ = info_row
            if not info_type.startswith("#"):
                information += f"{info_type}: {info_value}\n"

        return _schema, name, information

    def _build_spark_relation_list(
        self,
        row_list: "agate.Table",
        relation_info_func: Callable[["agate.Row"], RelationInfo],
        schema_relation: Optional[BaseRelation] = None,
    ) -> List[BaseRelation]:
        """Aggregate relations with format metadata included."""
        relations = []
        for row in row_list:
            info = relation_info_func(row)
            if info is None:
                # Session-scoped temp views (see _get_relation_information) — skip.
                continue
            _schema, name, information = info

            rel_type: RelationType = (
                RelationType.MaterializedView
                if "Type: MATERIALIZED_LAKE_VIEW" in information
                else RelationType.MaterializedView
                if "Type: MATERIALIZED_VIEW" in information
                else RelationType.View
                if "Type: VIEW" in information
                else RelationType.Table
            )
            is_delta: bool = "Provider: delta" in information
            # Use database/schema from the input relation when available.
            # Schema-enabled lakehouses return a multi-part backtick-quoted
            # namespace that doesn't match the cache key.
            # Workspace propagates from the input relation when set so that
            # cross-workspace listings render 4-part consistently.
            relation: BaseRelation = self.Relation.create(
                database=schema_relation.database if schema_relation else None,
                schema=schema_relation.schema if schema_relation else _schema,
                identifier=name,
                type=rel_type,
                information=information,
                is_delta=is_delta,
                workspace=getattr(schema_relation, "workspace", None) if schema_relation else None,
                _skip_prefix=True,
            )
            # In no_schema mode, filter to only relations matching the active
            # identifier prefix - which presents a similar API as schema.
            active_prefix = self.Relation._identifier_prefix
            if (
                active_prefix
                and relation.identifier
                and not relation.identifier.startswith(active_prefix)
            ):
                continue
            relations.append(relation)

        return relations

    def list_relations_without_caching(self, schema_relation: BaseRelation) -> List[BaseRelation]:
        """Distinct Spark compute engines may not support the same SQL featureset. Thus, we must
        try different methods to fetch relation information."""

        # In no_schema mode, use a prefix-specific LIKE pattern so Spark only
        # returns tables belonging to that prefix.
        prefix = self.Relation._identifier_prefix
        if prefix:
            schema_clause = schema_relation.schema
            if schema_relation.include_policy.database and schema_relation.database:
                schema_clause = f"{schema_relation.database}.{schema_clause}"
            # When the relation carries a workspace prefix (cross-workspace
            # listing), prepend it as a backtick-quoted segment so Spark
            # routes the SHOW TABLE EXTENDED to the correct workspace
            # catalog, e.g. workspaces with spaces / mixed case.
            ws = getattr(schema_relation, "workspace", None)
            if ws:
                schema_clause = f"`{ws}`.{schema_clause}"
            sql = f"show table extended in {schema_clause} like '{prefix}*'"
            try:
                _, result = self.execute(sql, auto_begin=False, fetch=True)
                return self._build_spark_relation_list(
                    row_list=result,
                    relation_info_func=self._get_relation_information,
                    schema_relation=schema_relation,
                )
            except DbtRuntimeError as e:
                errmsg = getattr(e, "msg", "")
                if (
                    f"Database '{schema_relation}' not found" in errmsg
                    or "[SCHEMA_NOT_FOUND]" in errmsg
                ):
                    return []
                logger.debug(
                    f"Error while retrieving information about {schema_relation}: {errmsg}"
                )
                return []

        kwargs = {"schema_relation": schema_relation}

        try:
            # Default compute engine behavior: show tables extended
            show_table_extended_rows = self.execute_macro(LIST_RELATIONS_MACRO_NAME, kwargs=kwargs)
            return self._build_spark_relation_list(
                row_list=show_table_extended_rows,
                relation_info_func=self._get_relation_information,
                schema_relation=schema_relation,
            )
        except DbtRuntimeError as e:
            errmsg = getattr(e, "msg", "")
            if (
                f"Database '{schema_relation}' not found" in errmsg
                or "[SCHEMA_NOT_FOUND]" in errmsg
            ):
                return []
            # Iceberg compute engine behavior: show table
            elif "SHOW TABLE EXTENDED is not supported for v2 tables" in errmsg:
                # this happens with spark-iceberg with v2 iceberg tables
                # https://issues.apache.org/jira/browse/SPARK-33393
                try:
                    # Iceberg behavior: 3-row result of relations obtained
                    show_table_rows = self.execute_macro(
                        LIST_RELATIONS_SHOW_TABLES_MACRO_NAME, kwargs=kwargs
                    )
                    return self._build_spark_relation_list(
                        row_list=show_table_rows,
                        relation_info_func=self._get_relation_information_using_describe,
                        schema_relation=schema_relation,
                    )
                except DbtRuntimeError as e:
                    description = "Error while retrieving information about"
                    logger.debug(f"{description} {schema_relation}: {e.msg}")
                    return []
            else:
                logger.debug(
                    f"Error while retrieving information about {schema_relation}: {errmsg}"
                )
                return []

    def get_relation(self, database: str, schema: str, identifier: str) -> Optional[BaseRelation]:
        if not self.Relation.get_default_include_policy().database:
            database = None  # type: ignore

        # Apply identifier prefix for cache lookup in no_schema mode.
        # Macros pass the model alias (un-prefixed) but the cache stores
        # relations with their physical (prefixed) identifiers.
        prefix = self.Relation._identifier_prefix
        if prefix and identifier and not identifier.startswith(prefix):
            identifier = f"{prefix}{identifier}"

        return super().get_relation(database, schema, identifier)

    def parse_describe_extended(
        self, relation: BaseRelation, raw_rows: AttrDict
    ) -> List[FabricSparkColumn]:
        # Convert the Row to a dict
        dict_rows = [dict(zip(row._keys, row._values)) for row in raw_rows]
        # Find the separator between the rows and the metadata provided
        # by the DESCRIBE TABLE EXTENDED statement
        pos = self.find_table_information_separator(dict_rows)

        # Remove rows that start with a hash, they are comments
        rows = [row for row in raw_rows[0:pos] if not row["col_name"].startswith("#")]
        metadata = {col["col_name"]: col["data_type"] for col in raw_rows[pos + 1 :]}

        raw_table_stats = metadata.get(KEY_TABLE_STATISTICS)
        table_stats = FabricSparkColumn.convert_table_stats(raw_table_stats)
        return [
            FabricSparkColumn(
                table_database=None,
                table_schema=relation.schema,
                table_name=relation.name,
                table_type=relation.type,
                table_owner=str(metadata.get(KEY_TABLE_OWNER)),
                table_stats=table_stats,
                column=column["col_name"],
                column_index=idx,
                dtype=column["data_type"],
            )
            for idx, column in enumerate(rows)
        ]

    @staticmethod
    def find_table_information_separator(rows: List[dict]) -> int:
        pos = 0
        for row in rows:
            if not row["col_name"] or row["col_name"].startswith("#"):
                break
            pos += 1
        return pos

    def get_columns_in_relation(self, relation: BaseRelation) -> List[FabricSparkColumn]:
        columns = []
        # Retry once on transient errors — Fabric Livy sessions can
        # occasionally return errors under concurrent load.
        for attempt in range(2):
            try:
                rows: AttrDict = self.execute_macro(
                    GET_COLUMNS_IN_RELATION_RAW_MACRO_NAME, kwargs={"relation": relation}
                )
                columns = self.parse_describe_extended(relation, rows)
                break
            except DbtRuntimeError as e:
                # spark would throw error when table doesn't exist, where other
                # CDW would just return and empty list, normalizing the behavior here
                errmsg = getattr(e, "msg", "")
                found_msgs = (msg in errmsg for msg in TABLE_OR_VIEW_NOT_FOUND_MESSAGES)
                if any(found_msgs):
                    break
                if attempt == 0:
                    import time as _time

                    logger.debug(f"Retrying get_columns_in_relation for {relation}: {errmsg}")
                    _time.sleep(2)
                    continue
                raise e
        return columns

    def parse_columns_from_information(self, relation: BaseRelation) -> List[FabricSparkColumn]:
        if hasattr(relation, "information"):
            information = relation.information or ""
        else:
            information = ""
        owner_match = re.findall(self.INFORMATION_OWNER_REGEX, information)
        owner = owner_match[0] if owner_match else None
        matches = re.finditer(self.INFORMATION_COLUMNS_REGEX, information)
        columns = []
        stats_match = re.findall(self.INFORMATION_STATISTICS_REGEX, information)
        raw_table_stats = stats_match[0] if stats_match else None
        table_stats = FabricSparkColumn.convert_table_stats(raw_table_stats)
        for match_num, match in enumerate(matches):
            column_name, column_type, nullable = match.groups()
            column = FabricSparkColumn(
                table_database=None,
                table_schema=relation.schema,
                table_name=relation.table,
                table_type=relation.type,
                column_index=match_num,
                table_owner=owner,
                column=column_name,
                dtype=column_type,
                table_stats=table_stats,
            )
            columns.append(column)
        return columns

    def _get_columns_for_catalog(self, relation: BaseRelation) -> Iterable[Dict[str, Any]]:
        ws = getattr(relation, "workspace", None)
        if ws:
            ws_q = f"`{ws}`"
            db_q = f"`{relation.database}`" if relation.database else None
            schema_q = f"`{relation.schema}`" if relation.schema else None
            parts = [ws_q]
            if db_q:
                parts.append(db_q)
            if schema_q:
                parts.append(schema_q)
            parts.append(relation.identifier)
            table_name = ".".join(parts)
        elif relation.database:
            table_name = f"{relation.database}.{relation.schema}.{relation.identifier}"
        else:
            table_name = f"{relation.schema}.{relation.identifier}"
        raw_rows = None
        try:
            raw_rows = self.execute_macro(
                DESCRIBE_TABLE_EXTENDED_MACRO_NAME, kwargs={"table_name": table_name}
            )
        except DbtRuntimeError as e:
            logger.debug(f"Error while retrieving information about {table_name}: {e.msg}")
            raise e

        # Not using parsing to extract schema and other properties using describe table extended command
        columns = self.parse_describe_extended(relation, raw_rows)

        # In no_schema mode, strip the identifier prefix from table_name
        # so dbt-core can match catalog rows to manifest nodes.  Manifest
        # nodes use node.alias (un-prefixed model name) as the key, while
        # the physical relation identifier carries the prefix.
        prefix = self.Relation._identifier_prefix

        for column in columns:
            # convert SparkColumns into catalog dicts
            as_dict = column.to_column_dict()
            as_dict["column_name"] = as_dict.pop("column", None)
            as_dict["column_type"] = as_dict.pop("dtype")
            # Must match the database value from generate_database_name (target.lakehouse)
            # so dbt-core can join catalog rows to manifest nodes via CatalogKey.
            as_dict["table_database"] = relation.database or self.config.credentials.lakehouse
            if prefix and as_dict.get("table_name", "").startswith(prefix):
                as_dict["table_name"] = as_dict["table_name"][len(prefix) :]
            yield as_dict

    def get_filtered_catalog(
        self,
        relation_configs,
        used_schemas,
        relations=None,
    ):
        """Override to bypass relation-level filtering in no_schema mode.

        When ``_identifier_prefix`` is active, ``_get_columns_for_catalog``
        strips the prefix from ``table_name`` so dbt-core can match catalog
        rows to manifest nodes (which use the un-prefixed model alias).
        However, the base implementation's relation-map filter uses prefixed
        identifiers from ``Relation.create_from`` — causing a mismatch.

        Bypassing the per-relation filter is safe because
        ``list_relations_without_caching`` already filters by prefix, so the
        catalog only contains the current test class's tables.
        """
        if self.Relation._identifier_prefix:
            return self.get_catalog(relation_configs, used_schemas)
        return super().get_filtered_catalog(relation_configs, used_schemas, relations)

    def get_catalog(
        self,
        relation_configs: Iterable[RelationConfig],
        used_schemas: FrozenSet[Tuple[str, str]],
    ) -> Tuple["agate.Table", List[Exception]]:
        schema_map = self._get_catalog_schemas(relation_configs)

        with executor(self.config) as tpe:
            futures: List[Future["agate.Table"]] = []
            for info, schemas in schema_map.items():
                for schema in schemas:
                    futures.append(
                        tpe.submit_connected(
                            self,
                            schema,
                            self._get_one_catalog,
                            info,
                            [schema],
                            relation_configs,
                        )
                    )
            catalogs, exceptions = catch_as_completed(futures)
        return catalogs, exceptions

    def _get_one_catalog(
        self,
        information_schema: InformationSchema,
        schemas: Set[str],
        used_schemas: FrozenSet[Tuple[str, str]],
    ) -> "agate.Table":
        if len(schemas) != 1:
            raise CompilationError(
                f"Expected only one schema in spark _get_one_catalog, found {schemas}"
            )

        database = information_schema.database
        if not self.Relation.get_default_include_policy().database:
            database = None
        logger.debug(f"database name is {database}")
        schema = list(schemas)[0]

        columns: List[Dict[str, Any]] = []
        for relation in self.list_relations(database, schema):
            logger.debug("Getting table schema for relation {}", str(relation))
            columns_to_add = self._get_columns_for_catalog(relation)
            columns.extend(columns_to_add)
        import agate

        return agate.Table.from_object(columns, column_types=DEFAULT_TYPE_TESTER)

    def check_schema_exists(self, database: str, schema: str) -> bool:
        results = self.execute_macro(LIST_SCHEMAS_MACRO_NAME, kwargs={"database": database})

        exists = True if schema in [row[0] for row in results] else False
        return exists

    def get_rows_different_sql(
        self,
        relation_a: BaseRelation,
        relation_b: BaseRelation,
        column_names: Optional[List[str]] = None,
        except_operator: str = "EXCEPT",
    ) -> str:
        """Generate SQL for a query that returns a single row with two
        columns: the number of rows that are different between the two
        relations and the number of mismatched rows.
        """
        # This method only really exists for test reasons.
        names: List[str]
        if column_names is None:
            columns = self.get_columns_in_relation(relation_a)
            names = sorted((self.quote(c.name) for c in columns))
        else:
            names = sorted((self.quote(n) for n in column_names))
        columns_csv = ", ".join(names)

        sql = COLUMNS_EQUAL_SQL.format(
            columns=columns_csv,
            relation_a=str(relation_a),
            relation_b=str(relation_b),
        )

        return sql

    def run_sql_for_tests(self, sql, fetch, conn):
        cursor = conn.handle.cursor()
        try:
            cursor.execute(sql)
            if fetch == "one":
                if hasattr(cursor, "fetchone"):
                    return cursor.fetchone()
                else:
                    return cursor.fetchall()[0]
            elif fetch == "all":
                return cursor.fetchall()
            else:
                return
        except BaseException as e:
            print(sql)
            print(e)
            raise
        finally:
            conn.transaction_open = False

    def standardize_grants_dict(self, grants_table: "agate.Table") -> dict:
        grants_dict: Dict[str, List[str]] = {}
        for row in grants_table:
            grantee = row["Principal"]
            privilege = row["ActionType"]
            object_type = row["ObjectType"]

            # we only want to consider grants on this object
            # (view or table both appear as 'TABLE')
            # and we don't want to consider the OWN privilege
            if object_type == "TABLE" and privilege != "OWN":
                if privilege in grants_dict.keys():
                    grants_dict[privilege].append(grantee)
                else:
                    grants_dict.update({privilege: [grantee]})
        return grants_dict

    def debug_query(self) -> None:
        """Override for DebugTask method"""
        if os.environ.get("FABRIC_SKIP_DEBUG_QUERY"):
            return
        self.execute("select 1 as id")

    @classmethod
    def _get_adapter_specific_run_info(cls, config: RelationConfig) -> Dict[str, Any]:
        table_format: Optional[str] = None
        # Full table_format support within this adapter is coming. Until then, for telemetry,
        # we're relying on table_formats_within_file_formats - a subset of file_format values
        table_formats_within_file_formats = ["delta"]

        if (
            config
            and hasattr(config, "_extra")
            and (file_format := config._extra.get("file_format"))
        ):
            if file_format in table_formats_within_file_formats:
                table_format = file_format

        return {
            "adapter_type": "fabricspark",
            "table_format": table_format,
        }


# spark does something interesting with joins when both tables have the same
# static values for the join condition and complains that the join condition is
# "trivial". Which is true, though it seems like an unreasonable cause for
# failure! It also doesn't like the `from foo, bar` syntax as opposed to
# `from foo cross join bar`.
COLUMNS_EQUAL_SQL = """
with diff_count as (
    SELECT
        1 as id,
        COUNT(*) as num_missing FROM (
            (SELECT {columns} FROM {relation_a} EXCEPT
             SELECT {columns} FROM {relation_b})
             UNION ALL
            (SELECT {columns} FROM {relation_b} EXCEPT
             SELECT {columns} FROM {relation_a})
        ) as a
), table_a as (
    SELECT COUNT(*) as num_rows FROM {relation_a}
), table_b as (
    SELECT COUNT(*) as num_rows FROM {relation_b}
), row_count_diff as (
    select
        1 as id,
        table_a.num_rows - table_b.num_rows as difference
    from table_a
    cross join table_b
)
select
    INT(row_count_diff.difference) as row_count_difference,
    INT(diff_count.num_missing) as num_mismatched
from row_count_diff
cross join diff_count
""".strip()
