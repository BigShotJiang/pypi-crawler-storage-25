import unittest
from multiprocessing import get_context
from unittest import mock

from agate import Row

import dbt.flags as flags
from dbt.adapters.contracts.relation import RelationType
from dbt.adapters.fabricspark import FabricSparkAdapter, FabricSparkRelation

from .utils import config_from_parts_or_dicts


class TestSparkAdapter(unittest.TestCase):
    def setUp(self):
        flags.STRICT_MODE = False
        self.mp_context = get_context("spawn")

        self.project_cfg = {
            "name": "X",
            "version": "0.1",
            "profile": "test",
            "project-root": "/tmp/dbt/does-not-exist",
            "quoting": {
                "identifier": False,
                "schema": False,
            },
            "config-version": 2,
        }

    def _get_target_livy(self, project):
        return config_from_parts_or_dicts(
            project,
            {
                "outputs": {
                    "test": {
                        "type": "fabricspark",
                        "method": "livy",
                        "authentication": "CLI",
                        "lakehouse": "dbtsparktest",
                        "workspaceid": "1de8390c-9aca-4790-bee8-72049109c0f4",
                        "lakehouseid": "8c5bc260-bc3a-4898-9ada-01e433d461ba",
                        "connect_retries": 0,
                        "connect_timeout": 10,
                        "threads": 1,
                        "endpoint": "https://dailyapi.fabric.microsoft.com/v1",
                        "spark_config": {"name": "test-session"},
                    }
                },
                "target": "test",
            },
        )

    def _get_target_livy_local(self, project):
        """Get config for local Livy mode."""
        return config_from_parts_or_dicts(
            project,
            {
                "outputs": {
                    "test": {
                        "type": "fabricspark",
                        "method": "livy",
                        "livy_mode": "local",
                        "livy_url": "http://localhost:8998",
                        "connect_retries": 0,
                        "connect_timeout": 10,
                        "threads": 1,
                        "spark_config": {"name": "test-session"},
                    }
                },
                "target": "test",
            },
        )

    @unittest.skip("Requires Azure CLI authentication - integration test")
    def test_livy_connection(self):
        config = self._get_target_livy(self.project_cfg)
        adapter = FabricSparkAdapter(config, self.mp_context)

        def fabric_spark_livy_connect(configuration):
            self.assertEqual(configuration.method, "livy")
            self.assertEqual(configuration.type, "fabricspark")

        # with mock.patch.object(hive, 'connect', new=hive_http_connect):
        with mock.patch(
            "dbt.adapters.fabricspark.livysession.LivySessionConnectionWrapper",
            new=fabric_spark_livy_connect,
        ):
            connection = adapter.acquire_connection("dummy")
            connection.handle  # trigger lazy-load

            self.assertEqual(connection.state, "open")
            self.assertIsNotNone(connection.handle)
            self.assertEqual(connection.credentials.authentication, "CLI")
            self.assertEqual(connection.credentials.database, "dbtsparktest")

    def test_local_livy_credentials(self):
        """Test that local Livy mode credentials are properly set up."""
        config = self._get_target_livy_local(self.project_cfg)
        FabricSparkAdapter(config, self.mp_context)

        # Get credentials from config
        creds = config.credentials
        self.assertEqual(creds.livy_mode, "local")
        self.assertTrue(creds.is_local_mode)
        self.assertEqual(creds.lakehouse_endpoint, "http://localhost:8998")
        self.assertIsNone(creds.workspaceid)
        self.assertIsNone(creds.lakehouseid)

    def test_fabric_livy_credentials(self):
        """Test that Fabric Livy mode credentials are properly set up."""
        config = self._get_target_livy(self.project_cfg)

        creds = config.credentials
        self.assertEqual(creds.livy_mode, "fabric")
        self.assertFalse(creds.is_local_mode)
        self.assertIn("workspaces", creds.lakehouse_endpoint)
        self.assertIsNotNone(creds.workspaceid)
        self.assertIsNotNone(creds.lakehouseid)

    def test_parse_relation(self):
        self.maxDiff = None
        rel_type = FabricSparkRelation.get_relation_type.Table

        relation = FabricSparkRelation.create(
            schema="default_schema", identifier="mytable", type=rel_type
        )
        assert relation.database is None

        # Mimics the output of Spark with a DESCRIBE TABLE EXTENDED
        plain_rows = [
            ("col1", "decimal(22,0)"),
            (
                "col2",
                "string",
            ),
            ("dt", "date"),
            ("struct_col", "struct<struct_inner_col:string>"),
            ("# Partition Information", "data_type"),
            ("# col_name", "data_type"),
            ("dt", "date"),
            (None, None),
            ("# Detailed Table Information", None),
            ("Database", None),
            ("Owner", "root"),
            ("Created Time", "Wed Feb 04 18:15:00 UTC 1815"),
            ("Last Access", "Wed May 20 19:25:00 UTC 1925"),
            ("Type", "MANAGED"),
            ("Provider", "delta"),
            ("Location", "/mnt/vo"),
            ("Serde Library", "org.apache.hadoop.hive.serde2.lazy.LazySimpleSerDe"),
            ("InputFormat", "org.apache.hadoop.mapred.SequenceFileInputFormat"),
            ("OutputFormat", "org.apache.hadoop.hive.ql.io.HiveSequenceFileOutputFormat"),
            ("Partition Provider", "Catalog"),
        ]

        input_cols = [Row(keys=["col_name", "data_type"], values=r) for r in plain_rows]

        config = self._get_target_livy(self.project_cfg)
        rows = FabricSparkAdapter(config, self.mp_context).parse_describe_extended(
            relation, input_cols
        )
        self.assertEqual(len(rows), 4)
        self.assertEqual(
            rows[0].to_column_dict(omit_none=False),
            {
                "table_database": None,
                "table_schema": relation.schema,
                "table_name": relation.name,
                "table_type": rel_type,
                "table_owner": "root",
                "column": "col1",
                "column_index": 0,
                "dtype": "decimal(22,0)",
                "numeric_scale": None,
                "numeric_precision": None,
                "char_size": None,
            },
        )

        self.assertEqual(
            rows[1].to_column_dict(omit_none=False),
            {
                "table_database": None,
                "table_schema": relation.schema,
                "table_name": relation.name,
                "table_type": rel_type,
                "table_owner": "root",
                "column": "col2",
                "column_index": 1,
                "dtype": "string",
                "numeric_scale": None,
                "numeric_precision": None,
                "char_size": None,
            },
        )

        self.assertEqual(
            rows[2].to_column_dict(omit_none=False),
            {
                "table_database": None,
                "table_schema": relation.schema,
                "table_name": relation.name,
                "table_type": rel_type,
                "table_owner": "root",
                "column": "dt",
                "column_index": 2,
                "dtype": "date",
                "numeric_scale": None,
                "numeric_precision": None,
                "char_size": None,
            },
        )

        self.assertEqual(
            rows[3].to_column_dict(omit_none=False),
            {
                "table_database": None,
                "table_schema": relation.schema,
                "table_name": relation.name,
                "table_type": rel_type,
                "table_owner": "root",
                "column": "struct_col",
                "column_index": 3,
                "dtype": "struct<struct_inner_col:string>",
                "numeric_scale": None,
                "numeric_precision": None,
                "char_size": None,
            },
        )

    def test_parse_relation_with_integer_owner(self):
        self.maxDiff = None
        rel_type = FabricSparkRelation.get_relation_type.Table

        relation = FabricSparkRelation.create(
            schema="default_schema", identifier="mytable", type=rel_type
        )
        assert relation.database is None

        # Mimics the output of Spark with a DESCRIBE TABLE EXTENDED
        plain_rows = [
            ("col1", "decimal(22,0)"),
            ("# Detailed Table Information", None),
            ("Owner", 1234),
        ]

        input_cols = [Row(keys=["col_name", "data_type"], values=r) for r in plain_rows]

        config = self._get_target_livy(self.project_cfg)
        rows = FabricSparkAdapter(config, self.mp_context).parse_describe_extended(
            relation, input_cols
        )

        self.assertEqual(rows[0].to_column_dict().get("table_owner"), "1234")

    def test_parse_relation_with_statistics(self):
        self.maxDiff = None
        rel_type = FabricSparkRelation.get_relation_type.Table

        relation = FabricSparkRelation.create(
            schema="default_schema", identifier="mytable", type=rel_type
        )
        assert relation.database is None

        # Mimics the output of Spark with a DESCRIBE TABLE EXTENDED
        plain_rows = [
            ("col1", "decimal(22,0)"),
            ("# Partition Information", "data_type"),
            (None, None),
            ("# Detailed Table Information", None),
            ("Database", None),
            ("Owner", "root"),
            ("Created Time", "Wed Feb 04 18:15:00 UTC 1815"),
            ("Last Access", "Wed May 20 19:25:00 UTC 1925"),
            ("Statistics", "1109049927 bytes, 14093476 rows"),
            ("Type", "MANAGED"),
            ("Provider", "delta"),
            ("Location", "/mnt/vo"),
            ("Serde Library", "org.apache.hadoop.hive.serde2.lazy.LazySimpleSerDe"),
            ("InputFormat", "org.apache.hadoop.mapred.SequenceFileInputFormat"),
            ("OutputFormat", "org.apache.hadoop.hive.ql.io.HiveSequenceFileOutputFormat"),
            ("Partition Provider", "Catalog"),
        ]

        input_cols = [Row(keys=["col_name", "data_type"], values=r) for r in plain_rows]

        config = self._get_target_livy(self.project_cfg)
        rows = FabricSparkAdapter(config, self.mp_context).parse_describe_extended(
            relation, input_cols
        )
        self.assertEqual(len(rows), 1)
        self.assertEqual(
            rows[0].to_column_dict(omit_none=False),
            {
                "table_database": None,
                "table_schema": relation.schema,
                "table_name": relation.name,
                "table_type": rel_type,
                "table_owner": "root",
                "column": "col1",
                "column_index": 0,
                "dtype": "decimal(22,0)",
                "numeric_scale": None,
                "numeric_precision": None,
                "char_size": None,
                "stats:bytes:description": "",
                "stats:bytes:include": True,
                "stats:bytes:label": "bytes",
                "stats:bytes:value": 1109049927,
                "stats:rows:description": "",
                "stats:rows:include": True,
                "stats:rows:label": "rows",
                "stats:rows:value": 14093476,
            },
        )

    def test_relation_with_database(self):
        config = self._get_target_livy(self.project_cfg)
        adapter = FabricSparkAdapter(config, self.mp_context)
        # fine - database excluded from rendering by include_policy
        adapter.Relation.create(schema="different", identifier="table")
        # also fine now - database is excluded from rendering
        adapter.Relation.create(database="something", schema="different", identifier="table")

    def test_relation_two_part_mode(self):
        """Test that non-schema mode uses two-part naming (schema.identifier)."""
        FabricSparkRelation._schemas_enabled = False
        try:
            rel = FabricSparkRelation.create(
                database="my_lakehouse", schema="my_lakehouse", identifier="my_table"
            )
            # include_policy.database should be False
            assert rel.include_policy.database is False
            assert rel.include_policy.schema is True
            # Renders as `lakehouse_name`.identifier (two-part; the lakehouse name occupies the
            # schema position and is backtick-quoted to preserve its original casing)
            assert str(rel) == "`my_lakehouse`.my_table"
        finally:
            FabricSparkRelation._schemas_enabled = False

    def test_relation_three_part_mode(self):
        """Test that schema-enabled mode uses three-part naming (database.schema.identifier)."""
        FabricSparkRelation._schemas_enabled = True
        try:
            rel = FabricSparkRelation.create(
                database="my_lakehouse", schema="dbo", identifier="my_table"
            )
            # include_policy.database should be True
            assert rel.include_policy.database is True
            assert rel.include_policy.schema is True
            # Renders as `database`.`schema`.identifier (three-part, both quoted)
            assert str(rel) == "`my_lakehouse`.`dbo`.my_table"
        finally:
            FabricSparkRelation._schemas_enabled = False

    def test_relation_mode_isolation(self):
        """Test that changing the ClassVar affects new relations, not existing ones."""
        FabricSparkRelation._schemas_enabled = False
        try:
            rel_two = FabricSparkRelation.create(database="lh", schema="lh", identifier="t1")
            FabricSparkRelation._schemas_enabled = True
            rel_three = FabricSparkRelation.create(database="lh", schema="dbo", identifier="t2")
            # Existing relation retains its original policy
            assert str(rel_two) == "`lh`.t1"
            # New relation uses updated policy (both database and schema quoted)
            assert str(rel_three) == "`lh`.`dbo`.t2"
        finally:
            FabricSparkRelation._schemas_enabled = False

    def test_mixed_case_database_no_approximate_match_error(self):
        """Regression test for ApproximateMatchError when lakehouse name uses mixed case.

        When the Fabric lakehouse displayName contains uppercase characters
        (e.g. 'DBTTest'), the relation cache stores relations with the
        case-preserved database name from the catalog.  Before the fix,
        FabricSparkQuotePolicy.database was False, which caused
        _make_match_kwargs to lowercase the search term ('dbttest'), while
        the cached relation kept the original casing ('DBTTest').  This
        mismatch triggered ApproximateMatchError on every rerun.

        The fix sets FabricSparkQuotePolicy.database to True so dbt
        preserves the original casing through the cache-lookup path.
        """
        FabricSparkRelation._schemas_enabled = True
        try:
            # Simulate a cached relation returned by Fabric's catalog with
            # case-preserved lakehouse name (as list_relations_without_caching
            # populates it).
            cached_relation = FabricSparkRelation.create(
                database="DBTTest",
                schema="dbo",
                identifier="my_first_model",
                type=FabricSparkRelation.get_relation_type.Table,
            )

            # Verify that the quote policy defaults database to True
            assert cached_relation.quote_policy.database is True

            # The search term that dbt passes through _make_match_kwargs.
            # With quoting.database=True, the database name is NOT lowercased,
            # so it stays as "DBTTest" and matches exactly.
            assert cached_relation.matches(
                database="DBTTest", schema="dbo", identifier="my_first_model"
            )

            # Also verify that mixed-case database renders correctly
            # with backtick quoting (harmless in Spark SQL).
            assert str(cached_relation) == "`DBTTest`.`dbo`.my_first_model"
        finally:
            FabricSparkRelation._schemas_enabled = False

    def test_mixed_case_database_lowered_raises_approximate_match(self):
        """Verify that searching with a lowered database name vs. mixed-case
        cached relation correctly raises ApproximateMatchError, confirming
        the root cause described in the issue."""
        from dbt_common.exceptions import CompilationError

        FabricSparkRelation._schemas_enabled = True
        try:
            cached_relation = FabricSparkRelation.create(
                database="DBTTest",
                schema="dbo",
                identifier="my_first_model",
                type=FabricSparkRelation.get_relation_type.Table,
            )
            # Searching with the lowered form should raise ApproximateMatchError
            # (which is a CompilationError subclass) since 'dbttest' != 'DBTTest'.
            with self.assertRaises(CompilationError):
                cached_relation.matches(
                    database="dbttest", schema="dbo", identifier="my_first_model"
                )
        finally:
            FabricSparkRelation._schemas_enabled = False

    def test_mixed_case_schema_no_approximate_match_error(self):
        """Regression test: mixed-case schema names must not trigger ApproximateMatchError.

        When a lakehouse has schemas enabled and the schema name contains
        uppercase characters (e.g. 'Operations'), FabricSparkQuotePolicy.schema
        must be True so that dbt's _make_match_kwargs does NOT lowercase the
        search term — otherwise 'operations' would fail to match 'Operations'
        in the relation cache and trigger ApproximateMatchError.
        """
        FabricSparkRelation._schemas_enabled = True
        try:
            cached_relation = FabricSparkRelation.create(
                database="my_lakehouse",
                schema="Operations",
                identifier="my_table",
                type=FabricSparkRelation.get_relation_type.Table,
            )

            assert cached_relation.quote_policy.schema is True
            assert cached_relation.matches(
                database="my_lakehouse", schema="Operations", identifier="my_table"
            )
            assert str(cached_relation) == "`my_lakehouse`.`Operations`.my_table"
        finally:
            FabricSparkRelation._schemas_enabled = False

    def test_mixed_case_schema_no_schema_mode_no_approximate_match_error(self):
        """Regression test: mixed-case lakehouse name used as schema in no-schema mode.

        In no-schema mode the schema field is set to the lakehouse name
        (e.g. 'Demo_Bronze').  With FabricSparkQuotePolicy.schema
        previously False, dbt would lowercase this to 'demo_bronze'
        in _make_match_kwargs, while the catalog returned the original casing,
        causing ApproximateMatchError.  The fix sets schema to True.
        """
        FabricSparkRelation._schemas_enabled = False
        try:
            lakehouse_name = "Demo_Bronze"
            cached_relation = FabricSparkRelation.create(
                database=lakehouse_name,
                schema=lakehouse_name,
                identifier="my_table",
                type=FabricSparkRelation.get_relation_type.Table,
            )

            assert cached_relation.quote_policy.schema is True
            assert cached_relation.matches(schema=lakehouse_name, identifier="my_table")
            assert str(cached_relation) == f"`{lakehouse_name}`.my_table"
        finally:
            FabricSparkRelation._schemas_enabled = False

    # -------------------------------------------------------------------- #
    # Cross-workspace 4-part naming                                        #
    # -------------------------------------------------------------------- #

    def test_relation_four_part_mode(self):
        """Setting `workspace` on a relation renders 4-part SQL.

        Each segment is independently backtick-quoted so Spark/Livy parses
        it as four distinct identifiers (per Fabric docs for cross-workspace
        access against schema-enabled lakehouses).
        """
        FabricSparkRelation._schemas_enabled = True
        try:
            rel = FabricSparkRelation.create(
                database="silver_lh",
                schema="dbo",
                identifier="orders",
                workspace="prod_ws",
            )
            assert rel.workspace == "prod_ws"
            assert str(rel) == "`prod_ws`.`silver_lh`.`dbo`.orders"
        finally:
            FabricSparkRelation._schemas_enabled = False

    def test_relation_workspace_none_preserves_three_part(self):
        """Relations without workspace render unchanged 3-part SQL (no regression)."""
        FabricSparkRelation._schemas_enabled = True
        try:
            rel = FabricSparkRelation.create(
                database="silver_lh", schema="dbo", identifier="orders", workspace=None
            )
            assert rel.workspace is None
            assert str(rel) == "`silver_lh`.`dbo`.orders"
        finally:
            FabricSparkRelation._schemas_enabled = False

    def test_relation_workspace_mixed_case_preserved(self):
        """Workspace names like 'dbt Fabric Spark 1' (spaces, mixed case) are preserved."""
        FabricSparkRelation._schemas_enabled = True
        try:
            rel = FabricSparkRelation.create(
                database="silver_lh",
                schema="dbo",
                identifier="orders",
                workspace="dbt Fabric Spark 1",
            )
            # Mixed-case + space-bearing workspace round-trips through the cache
            # match path (workspace is a render decoration, not a matching field).
            assert rel.matches(database="silver_lh", schema="dbo", identifier="orders")
            assert str(rel) == "`dbt Fabric Spark 1`.`silver_lh`.`dbo`.orders"
        finally:
            FabricSparkRelation._schemas_enabled = False

    def test_relation_workspace_temp_view_excludes_prefix(self):
        """Temp views (.include(database=False, schema=False)) drop the workspace prefix.

        Temp views are session-scoped — emitting a 4-part name would cause
        Spark to complain about cross-namespace temporary views.  The render
        gating on ``include_policy.database`` ensures workspace is only emitted
        when the database segment is also included.
        """
        FabricSparkRelation._schemas_enabled = True
        try:
            rel = FabricSparkRelation.create(
                database="silver_lh",
                schema="dbo",
                identifier="my_temp",
                workspace="prod_ws",
            )
            temp = rel.include(database=False, schema=False)
            # Workspace remains on the dataclass (preserved through incorporate)
            # but is not rendered when database is excluded.
            assert temp.workspace == "prod_ws"
            assert str(temp) == "my_temp"
        finally:
            FabricSparkRelation._schemas_enabled = False

    def test_relation_workspace_incorporate_preserves_field(self):
        """``incorporate`` round-trips the workspace field via to_dict/from_dict."""
        FabricSparkRelation._schemas_enabled = True
        try:
            rel = FabricSparkRelation.create(
                database="silver_lh",
                schema="dbo",
                identifier="orders",
                workspace="prod_ws",
            )
            renamed = rel.incorporate(path={"identifier": "orders_renamed"})
            assert renamed.workspace == "prod_ws"
            assert str(renamed) == "`prod_ws`.`silver_lh`.`dbo`.orders_renamed"
        finally:
            FabricSparkRelation._schemas_enabled = False

    def test_validate_workspace_name_supported_runtime_schema_enabled(self):
        """When the runtime flag says schema-enabled, workspace_name is allowed."""
        config = self._get_target_livy(self.project_cfg)
        adapter = FabricSparkAdapter(config, self.mp_context)
        FabricSparkRelation._schemas_enabled = True
        try:
            # Should not raise
            adapter.validate_workspace_name_supported(
                "prod_ws",
                target_database="silver_lh",
                target_schema="dbo",
                target_lakehouse="bronze_lh",
            )
        finally:
            FabricSparkRelation._schemas_enabled = False

    def test_validate_workspace_name_supported_parse_time_schema_enabled(self):
        """Parse-time heuristic: schema != lakehouse implies schema-enabled, allowed."""
        config = self._get_target_livy(self.project_cfg)
        adapter = FabricSparkAdapter(config, self.mp_context)
        FabricSparkRelation._schemas_enabled = False  # runtime not yet set
        try:
            # schema=dbo != lakehouse=bronze_lh → parse-time inference says schema-enabled
            adapter.validate_workspace_name_supported(
                "prod_ws",
                target_database="silver_lh",
                target_schema="dbo",
                target_lakehouse="bronze_lh",
            )
        finally:
            FabricSparkRelation._schemas_enabled = False

    def test_validate_workspace_name_supported_no_op_when_unset(self):
        """When workspace_name is None or empty, validation is a no-op."""
        config = self._get_target_livy(self.project_cfg)
        adapter = FabricSparkAdapter(config, self.mp_context)
        FabricSparkRelation._schemas_enabled = False
        try:
            adapter.validate_workspace_name_supported(
                None, target_schema="lh", target_lakehouse="lh"
            )
            adapter.validate_workspace_name_supported(
                "", target_schema="lh", target_lakehouse="lh"
            )
        finally:
            FabricSparkRelation._schemas_enabled = False

    def test_validate_workspace_name_supported_blocks_no_schema_mode(self):
        """workspace_name on a non-schema-enabled lakehouse raises a clear error."""
        from dbt_common.exceptions import DbtRuntimeError

        config = self._get_target_livy(self.project_cfg)
        adapter = FabricSparkAdapter(config, self.mp_context)
        FabricSparkRelation._schemas_enabled = False
        try:
            with self.assertRaises(DbtRuntimeError) as ctx:
                adapter.validate_workspace_name_supported(
                    "prod_ws",
                    target_database="my_lh",
                    target_schema="my_lh",  # schema == lakehouse → not schema-enabled
                    target_lakehouse="my_lh",
                )
            msg = str(ctx.exception)
            assert "workspace_name" in msg
            assert "schema-enabled" in msg
            assert "Cross-Workspace" in msg or "OneLake shortcut" in msg
        finally:
            FabricSparkRelation._schemas_enabled = False

    def test_workspace_name_registered_on_adapter_config(self):
        """workspace_name is a first-class FabricSparkConfig key."""
        from dataclasses import fields

        from dbt.adapters.fabricspark.impl import FabricSparkConfig

        field_names = {f.name for f in fields(FabricSparkConfig)}
        assert "workspace_name" in field_names, (
            "workspace_name must be registered on FabricSparkConfig so model "
            "config() values flow through node.config rather than being silently ignored."
        )

    def test_profile_with_schema(self):
        """Test that schema is accepted as user input and database is derived from lakehouse."""
        profile = {
            "outputs": {
                "test": {
                    "type": "fabricspark",
                    "method": "livy",
                    "authentication": "CLI",
                    "schema": "custom_schema",
                    "lakehouse": "dbtsparktest",
                    "workspaceid": "1de8390c-9aca-4790-bee8-72049109c0f4",
                    "lakehouseid": "8c5bc260-bc3a-4898-9ada-01e433d461ba",
                    "connect_retries": 0,
                    "connect_timeout": 10,
                    "threads": 1,
                    "endpoint": "https://dailyapi.fabric.microsoft.com/v1",
                    "spark_config": {"name": "test-session"},
                }
            },
            "target": "test",
        }
        config = config_from_parts_or_dicts(self.project_cfg, profile)
        # schema is user input
        assert config.credentials.schema == "custom_schema"
        # database is always derived from lakehouse name
        assert config.credentials.database == "dbtsparktest"

    def test_parse_columns_from_information_with_table_type_and_delta_provider(self):
        self.maxDiff = None
        rel_type = FabricSparkRelation.get_relation_type.Table

        # Mimics the output of Spark in the information column
        information = (
            "Database: default_schema\n"
            "Table: mytable\n"
            "Owner: root\n"
            "Created Time: Wed Feb 04 18:15:00 UTC 1815\n"
            "Last Access: Wed May 20 19:25:00 UTC 1925\n"
            "Created By: Spark 3.0.1\n"
            "Type: MANAGED\n"
            "Provider: delta\n"
            "Statistics: 123456789 bytes\n"
            "Location: /mnt/vo\n"
            "Serde Library: org.apache.hadoop.hive.serde2.lazy.LazySimpleSerDe\n"
            "InputFormat: org.apache.hadoop.mapred.SequenceFileInputFormat\n"
            "OutputFormat: org.apache.hadoop.hive.ql.io.HiveSequenceFileOutputFormat\n"
            "Partition Provider: Catalog\n"
            "Partition Columns: [`dt`]\n"
            "Schema: root\n"
            " |-- col1: decimal(22,0) (nullable = true)\n"
            " |-- col2: string (nullable = true)\n"
            " |-- dt: date (nullable = true)\n"
            " |-- struct_col: struct (nullable = true)\n"
            " |    |-- struct_inner_col: string (nullable = true)\n"
        )
        relation = FabricSparkRelation.create(
            schema="default_schema", identifier="mytable", type=rel_type, information=information
        )

        config = self._get_target_livy(self.project_cfg)
        columns = FabricSparkAdapter(config, self.mp_context).parse_columns_from_information(
            relation
        )
        self.assertEqual(len(columns), 4)
        self.assertEqual(
            columns[0].to_column_dict(omit_none=False),
            {
                "table_database": None,
                "table_schema": relation.schema,
                "table_name": relation.name,
                "table_type": rel_type,
                "table_owner": "root",
                "column": "col1",
                "column_index": 0,
                "dtype": "decimal(22,0)",
                "numeric_scale": None,
                "numeric_precision": None,
                "char_size": None,
                "stats:bytes:description": "",
                "stats:bytes:include": True,
                "stats:bytes:label": "bytes",
                "stats:bytes:value": 123456789,
            },
        )

        self.assertEqual(
            columns[3].to_column_dict(omit_none=False),
            {
                "table_database": None,
                "table_schema": relation.schema,
                "table_name": relation.name,
                "table_type": rel_type,
                "table_owner": "root",
                "column": "struct_col",
                "column_index": 3,
                "dtype": "struct",
                "numeric_scale": None,
                "numeric_precision": None,
                "char_size": None,
                "stats:bytes:description": "",
                "stats:bytes:include": True,
                "stats:bytes:label": "bytes",
                "stats:bytes:value": 123456789,
            },
        )

    def test_parse_columns_from_information_with_view_type(self):
        self.maxDiff = None
        rel_type = FabricSparkRelation.get_relation_type.View
        information = (
            "Database: default_schema\n"
            "Table: myview\n"
            "Owner: root\n"
            "Created Time: Wed Feb 04 18:15:00 UTC 1815\n"
            "Last Access: UNKNOWN\n"
            "Created By: Spark 3.0.1\n"
            "Type: VIEW\n"
            "View Text: WITH base (\n"
            "    SELECT * FROM source_table\n"
            ")\n"
            "SELECT col1, col2, dt FROM base\n"
            "View Original Text: WITH base (\n"
            "    SELECT * FROM source_table\n"
            ")\n"
            "SELECT col1, col2, dt FROM base\n"
            "View Catalog and Namespace: spark_catalog.default\n"
            "View Query Output Columns: [col1, col2, dt]\n"
            "Table Properties: [view.query.out.col.1=col1, view.query.out.col.2=col2, "
            "transient_lastDdlTime=1618324324, view.query.out.col.3=dt, "
            "view.catalogAndNamespace.part.0=spark_catalog, "
            "view.catalogAndNamespace.part.1=default]\n"
            "Serde Library: org.apache.hadoop.hive.serde2.lazy.LazySimpleSerDe\n"
            "InputFormat: org.apache.hadoop.mapred.SequenceFileInputFormat\n"
            "OutputFormat: org.apache.hadoop.hive.ql.io.HiveSequenceFileOutputFormat\n"
            "Storage Properties: [serialization.format=1]\n"
            "Schema: root\n"
            " |-- col1: decimal(22,0) (nullable = true)\n"
            " |-- col2: string (nullable = true)\n"
            " |-- dt: date (nullable = true)\n"
            " |-- struct_col: struct (nullable = true)\n"
            " |    |-- struct_inner_col: string (nullable = true)\n"
        )
        relation = FabricSparkRelation.create(
            schema="default_schema", identifier="myview", type=rel_type, information=information
        )

        config = self._get_target_livy(self.project_cfg)
        columns = FabricSparkAdapter(config, self.mp_context).parse_columns_from_information(
            relation
        )
        self.assertEqual(len(columns), 4)
        self.assertEqual(
            columns[1].to_column_dict(omit_none=False),
            {
                "table_database": None,
                "table_schema": relation.schema,
                "table_name": relation.name,
                "table_type": rel_type,
                "table_owner": "root",
                "column": "col2",
                "column_index": 1,
                "dtype": "string",
                "numeric_scale": None,
                "numeric_precision": None,
                "char_size": None,
            },
        )

        self.assertEqual(
            columns[3].to_column_dict(omit_none=False),
            {
                "table_database": None,
                "table_schema": relation.schema,
                "table_name": relation.name,
                "table_type": rel_type,
                "table_owner": "root",
                "column": "struct_col",
                "column_index": 3,
                "dtype": "struct",
                "numeric_scale": None,
                "numeric_precision": None,
                "char_size": None,
            },
        )

    def test_parse_columns_from_information_with_table_type_and_parquet_provider(self):
        self.maxDiff = None
        rel_type = FabricSparkRelation.get_relation_type.Table

        information = (
            "Database: default_schema\n"
            "Table: mytable\n"
            "Owner: root\n"
            "Created Time: Wed Feb 04 18:15:00 UTC 1815\n"
            "Last Access: Wed May 20 19:25:00 UTC 1925\n"
            "Created By: Spark 3.0.1\n"
            "Type: MANAGED\n"
            "Provider: parquet\n"
            "Statistics: 1234567890 bytes, 12345678 rows\n"
            "Location: /mnt/vo\n"
            "Serde Library: org.apache.hadoop.hive.ql.io.parquet.serde.ParquetHiveSerDe\n"
            "InputFormat: org.apache.hadoop.hive.ql.io.parquet.MapredParquetInputFormat\n"
            "OutputFormat: org.apache.hadoop.hive.ql.io.parquet.MapredParquetOutputFormat\n"
            "Schema: root\n"
            " |-- col1: decimal(22,0) (nullable = true)\n"
            " |-- col2: string (nullable = true)\n"
            " |-- dt: date (nullable = true)\n"
            " |-- struct_col: struct (nullable = true)\n"
            " |    |-- struct_inner_col: string (nullable = true)\n"
        )
        relation = FabricSparkRelation.create(
            schema="default_schema", identifier="mytable", type=rel_type, information=information
        )

        config = self._get_target_livy(self.project_cfg)
        columns = FabricSparkAdapter(config, self.mp_context).parse_columns_from_information(
            relation
        )
        self.assertEqual(len(columns), 4)

        self.assertEqual(
            columns[2].to_column_dict(omit_none=False),
            {
                "table_database": None,
                "table_schema": relation.schema,
                "table_name": relation.name,
                "table_type": rel_type,
                "table_owner": "root",
                "column": "dt",
                "column_index": 2,
                "dtype": "date",
                "numeric_scale": None,
                "numeric_precision": None,
                "char_size": None,
                "stats:bytes:description": "",
                "stats:bytes:include": True,
                "stats:bytes:label": "bytes",
                "stats:bytes:value": 1234567890,
                "stats:rows:description": "",
                "stats:rows:include": True,
                "stats:rows:label": "rows",
                "stats:rows:value": 12345678,
            },
        )

        self.assertEqual(
            columns[3].to_column_dict(omit_none=False),
            {
                "table_database": None,
                "table_schema": relation.schema,
                "table_name": relation.name,
                "table_type": rel_type,
                "table_owner": "root",
                "column": "struct_col",
                "column_index": 3,
                "dtype": "struct",
                "numeric_scale": None,
                "numeric_precision": None,
                "char_size": None,
                "stats:bytes:description": "",
                "stats:bytes:include": True,
                "stats:bytes:label": "bytes",
                "stats:bytes:value": 1234567890,
                "stats:rows:description": "",
                "stats:rows:include": True,
                "stats:rows:label": "rows",
                "stats:rows:value": 12345678,
            },
        )

    def test_build_spark_relation_list_materialized_lake_view(self):
        """MATERIALIZED_LAKE_VIEW from Fabric should be classified as MaterializedView."""
        config = self._get_target_livy(self.project_cfg)
        adapter = FabricSparkAdapter(config, self.mp_context)

        schema_relation = FabricSparkRelation.create(
            database="mydb", schema="dbo", identifier="dummy"
        )

        def fake_info(row):
            return row

        rows = [
            ("dbo", "mlv_table", "Type: MATERIALIZED_LAKE_VIEW\nProvider: delta\n"),
            ("dbo", "mv_table", "Type: MATERIALIZED_VIEW\nProvider: delta\n"),
            ("dbo", "view_table", "Type: VIEW\nProvider: delta\n"),
            ("dbo", "regular_table", "Type: MANAGED\nProvider: delta\n"),
        ]

        relations = adapter._build_spark_relation_list(
            row_list=rows,
            relation_info_func=fake_info,
            schema_relation=schema_relation,
        )

        self.assertEqual(len(relations), 4)
        self.assertEqual(relations[0].type, RelationType.MaterializedView)
        self.assertEqual(relations[1].type, RelationType.MaterializedView)
        self.assertEqual(relations[2].type, RelationType.View)
        self.assertEqual(relations[3].type, RelationType.Table)
