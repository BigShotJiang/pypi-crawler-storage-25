from setuptools import setup, find_packages

setup(
    name="synglue",
    version="0.1.0",
    description="Python client for SynGlue",
    author="Saveena Solanki",
    author_email="saveenas@iiitd.ac.in",
    packages=find_packages(where="src"),
    package_dir={"": "src"},
    install_requires=["requests"],
)
