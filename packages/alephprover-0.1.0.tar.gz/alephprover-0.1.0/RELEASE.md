# Release Process

The version is derived automatically from git tags via [`hatch-vcs`](https://github.com/ofek/hatch-vcs) — there is no version field in `pyproject.toml`.

## Prerequisites

- Push access to `logiq-ai/alephprover`
- The GitHub repository has a `pypi` environment configured with [trusted publishing](https://docs.pypi.org/trusted-publishers/)

## Steps

1. Go to [Releases → Draft a new release](https://github.com/logiq-ai/alephprover/releases/new)
2. Enter a new tag (e.g. `v0.1.0`) — GitHub will create it on publish
3. Click **Generate release notes** for an auto-generated changelog
4. Click **Publish release**

This creates the `v*` tag, which triggers the [publish workflow](.github/workflows/publish.yml) to build and publish to PyPI via trusted publishing.

### Verify

```bash
pip install alephprover==0.1.0
```

### Alternative: CLI

```bash
git tag v0.1.0
git push origin v0.1.0
```

## Dry Run

To test the build without publishing, trigger the workflow manually:

```bash
gh workflow run publish.yml --field dry_run=true
```

## Versioning

This project follows [Semantic Versioning](https://semver.org/):

- **Patch** (0.0.x) — bug fixes
- **Minor** (0.x.0) — new features, backward-compatible
- **Major** (x.0.0) — breaking changes