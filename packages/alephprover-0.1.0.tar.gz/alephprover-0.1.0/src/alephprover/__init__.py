"""Aleph Prover CLI — submit Lean proof requests from your terminal."""

__version__ = "0.0.1"
