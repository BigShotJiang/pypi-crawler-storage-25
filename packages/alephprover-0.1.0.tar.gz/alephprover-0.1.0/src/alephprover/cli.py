"""Aleph Prover CLI — submit Lean proof requests and apply results."""

from __future__ import annotations

import importlib.resources
import os
import subprocess
import sys
import tempfile
import time
import zipfile
from pathlib import Path

import click
import httpx

DEFAULT_API_URL = "https://alephprover.logicalintelligence.com"
POLL_INTERVAL = 15  # seconds
POLL_TIMEOUT = 60 * 60  # 60 minutes

# Project config files needed for building — searched project-wide
CONFIG_GLOBS = ("lakefile.lean", "lakefile.toml", "lean-toolchain", "lake-manifest.json")


def find_project_root(start: Path) -> Path:
    """Walk up from start to find directory containing lakefile.lean or lakefile.toml."""
    current = start.resolve()
    if current.is_file():
        current = current.parent
    while current != current.parent:
        if (current / "lakefile.lean").exists() or (current / "lakefile.toml").exists():
            return current
        current = current.parent
    click.echo(
        "Error: Could not find a Lean project root (lakefile.lean or lakefile.toml).\n"
        "Make sure you are inside a Lean project directory.",
        err=True,
    )
    sys.exit(1)


def validate_api_key() -> str:
    """Check PROVER_API_KEY env var."""
    key = os.environ.get("PROVER_API_KEY", "")
    if not key:
        click.echo(
            "Error: PROVER_API_KEY is not set.\n"
            "\n"
            "To set up:\n"
            "  1. Get an API key from https://alephprover.logicalintelligence.com/account\n"
            '  2. export PROVER_API_KEY="sk-aleph-..."',
            err=True,
        )
        sys.exit(1)
    if not key.startswith("sk-aleph-"):
        click.echo(
            'Error: PROVER_API_KEY must start with "sk-aleph-".\n'
            "Check your API key at https://alephprover.logicalintelligence.com/account",
            err=True,
        )
        sys.exit(1)
    return key


def get_api_url() -> str:
    return os.environ.get("PROVER_API_URL", DEFAULT_API_URL).rstrip("/")


def get_lean_src_paths(project_root: Path) -> list[str] | None:
    """Query Lake for source directories. Returns None if Lake is unavailable."""
    try:
        result = subprocess.run(
            ["lake", "env", "printenv", "LEAN_SRC_PATH"],
            capture_output=True,
            text=True,
            cwd=project_root,
            timeout=30,
        )
        if result.returncode == 0 and result.stdout.strip():
            return [p for p in result.stdout.strip().split(":") if p]
    except (FileNotFoundError, subprocess.TimeoutExpired):
        pass
    return None


def _git_ls_files(root: Path) -> set[str] | None:
    """Return all tracked + untracked-not-ignored files using git, or None if unavailable."""
    try:
        # Tracked files (root + submodules)
        tracked = subprocess.run(
            ["git", "ls-files", "--cached", "--recurse-submodules"],
            cwd=root, capture_output=True, text=True, timeout=30,
        )
        if tracked.returncode != 0:
            return None

        # Untracked-not-ignored (root only)
        untracked = subprocess.run(
            ["git", "ls-files", "--others", "--exclude-standard"],
            cwd=root, capture_output=True, text=True, timeout=30,
        )

        result = set(tracked.stdout.splitlines())
        if untracked.returncode == 0:
            result.update(untracked.stdout.splitlines())

        # Untracked files in submodules
        submodules = subprocess.run(
            ["git", "submodule", "--quiet", "foreach", "echo $displaypath"],
            cwd=root, capture_output=True, text=True, timeout=30,
        )
        if submodules.returncode == 0:
            for sm_path in submodules.stdout.splitlines():
                sm_dir = root / sm_path
                if not sm_dir.is_dir():
                    continue
                sm_untracked = subprocess.run(
                    ["git", "ls-files", "--others", "--exclude-standard"],
                    cwd=sm_dir, capture_output=True, text=True, timeout=30,
                )
                if sm_untracked.returncode == 0:
                    for f in sm_untracked.stdout.splitlines():
                        result.add(f"{sm_path}/{f}")

        return result
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return None


def zip_project(project_root: Path, verbose: bool = False, all_files: bool = False) -> Path:
    """Create a ZIP archive with only the files needed for building.

    Uses Lake to discover source directories when available. Falls back to
    including all .lean files outside .lake/.
    """
    # Collect files to archive
    files: list[Path] = []

    if all_files:
        git_files = _git_ls_files(project_root)

        if git_files is not None:
            click.echo("Warning: --all-files includes all project files (respecting .gitignore). Archive may be large.", err=True)
            for rel in sorted(git_files):
                if ".lake" in rel.split("/"):
                    continue
                p = project_root / rel
                if p.is_file():
                    files.append(p)
        else:
            click.echo("Warning: --all-files includes ALL project files. git not available, .gitignore is NOT respected. Archive may contain sensitive data.", err=True)
            for p in sorted(project_root.rglob("*")):
                if not p.is_file():
                    continue
                rel = p.relative_to(project_root).as_posix()
                if ".git" in rel.split("/") or ".lake" in rel.split("/"):
                    continue
                files.append(p)
    else:
        resolved_root = project_root.resolve()

        # Config files: always search project-wide
        for glob in CONFIG_GLOBS:
            for p in sorted(project_root.rglob(glob)):
                rel = p.relative_to(resolved_root).as_posix()
                if not rel.startswith(".lake/") and not rel.startswith("lake-packages/"):
                    files.append(p)

        # .lean files: use Lake source paths when available, else fallback
        src_paths = get_lean_src_paths(project_root)

        if src_paths is not None:
            click.echo(f"Lake source paths: {', '.join(src_paths) or '.'}")
            if src_paths:
                for src in src_paths:
                    src_dir = (project_root / src).resolve()
                    if not src_dir.is_dir():
                        continue
                    if not src_dir.is_relative_to(resolved_root):
                        continue
                    rel_dir = src_dir.relative_to(resolved_root).as_posix()
                    if rel_dir.startswith(".lake") or rel_dir.startswith("lake-packages"):
                        continue
                    for p in sorted(src_dir.rglob("*.lean")):
                        rel = p.relative_to(resolved_root).as_posix()
                        if not rel.startswith(".lake/") and not rel.startswith("lake-packages/"):
                            files.append(p)
            else:
                # Empty LEAN_SRC_PATH means project root is the source dir
                for p in sorted(project_root.rglob("*.lean")):
                    rel = p.relative_to(resolved_root).as_posix()
                    if not rel.startswith(".lake/") and not rel.startswith("lake-packages/"):
                        files.append(p)
        else:
            click.echo("Lake not available, including all .lean files")
            for p in sorted(project_root.rglob("*.lean")):
                rel = p.relative_to(resolved_root).as_posix()
                if not rel.startswith(".lake/") and not rel.startswith("lake-packages/"):
                    files.append(p)

    # Deduplicate while preserving order
    seen: set[Path] = set()
    unique_files: list[Path] = []
    for f in files:
        if f not in seen:
            seen.add(f)
            unique_files.append(f)

    # Create archive
    tmp = tempfile.NamedTemporaryFile(suffix=".zip", prefix="alephprover-", delete=False)
    tmp.close()
    zip_path = Path(tmp.name)

    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
        for path in unique_files:
            rel = path.relative_to(project_root).as_posix()
            if verbose:
                click.echo(f"  {rel}")
            zf.write(path, rel)

    size_mb = zip_path.stat().st_size / (1024 * 1024)
    click.echo(f"Archived {len(unique_files)} files ({size_mb:.1f} MB)")
    return zip_path


def submit(
    api_url: str,
    api_key: str,
    zip_path: Path,
    file_path: str,
    theorem_name: str,
    hints: str | None,
    time_budget: int | None,
    cost_budget: float | None,
) -> str:
    """Submit the archive and return the request ID."""
    data: dict[str, str] = {
        "file_path": file_path,
        "theorem_name": theorem_name,
    }
    if hints:
        data["hints"] = hints
    if time_budget is not None:
        data["time_budget_minutes"] = str(time_budget)
    if cost_budget is not None:
        data["cost_budget_usd"] = str(cost_budget)

    with open(zip_path, "rb") as f:
        files = {"archive": ("project.zip", f, "application/zip")}
        response = httpx.post(
            f"{api_url}/api/v1/requests/upload",
            headers={"Authorization": f"Bearer {api_key}"},
            data=data,
            files=files,
            timeout=120.0,
        )

    if response.status_code != 201:
        click.echo(f"Error: Upload failed (HTTP {response.status_code})", err=True)
        try:
            click.echo(response.json(), err=True)
        except Exception:
            click.echo(response.text, err=True)
        sys.exit(1)

    request_id = response.json()["id"]
    return request_id


def poll_status(api_url: str, api_key: str, request_id: str) -> str:
    """Poll until terminal status. Returns final status."""
    headers = {"Authorization": f"Bearer {api_key}"}
    start = time.time()
    last_stage = None

    while time.time() - start < POLL_TIMEOUT:
        try:
            response = httpx.get(
                f"{api_url}/api/v1/requests/{request_id}",
                headers=headers,
                timeout=30.0,
            )
            response.raise_for_status()
        except httpx.HTTPError as e:
            click.echo(f"Warning: Poll request failed ({e}), retrying...", err=True)
            time.sleep(POLL_INTERVAL)
            continue

        data = response.json()
        status = data["status"]
        stage = data.get("stage")

        if stage and stage != last_stage:
            click.echo(f"  Stage: {stage}")
            last_stage = stage

        if status in ("completed", "failed", "cancelled"):
            return status

        time.sleep(POLL_INTERVAL)

    click.echo(
        f"Timeout: polling exceeded {POLL_TIMEOUT // 60} minutes.\n"
        f"Check status at: {api_url}/requests/{request_id}",
        err=True,
    )
    sys.exit(1)


def download_diff(api_url: str, api_key: str, request_id: str) -> Path | None:
    """Download the diff patch. Returns path or None on failure."""
    response = httpx.get(
        f"{api_url}/api/v1/requests/{request_id}/diff",
        headers={"Authorization": f"Bearer {api_key}"},
        timeout=60.0,
    )
    if response.status_code != 200:
        return None

    patch_path = Path(tempfile.mktemp(suffix=".patch", prefix=f"proof-{request_id[:8]}-"))
    patch_path.write_bytes(response.content)
    return patch_path


def apply_patch(patch_path: Path, project_root: Path) -> bool:
    """Apply patch with git apply. Returns True on success."""
    result = subprocess.run(
        ["git", "apply", str(patch_path)],
        capture_output=True,
        text=True,
        cwd=project_root,
    )
    if result.returncode == 0:
        return True

    # Try --3way fallback
    click.echo("Standard apply failed, trying --3way...")
    result = subprocess.run(
        ["git", "apply", "--3way", str(patch_path)],
        capture_output=True,
        text=True,
        cwd=project_root,
    )
    return result.returncode == 0


@click.group()
@click.version_option(package_name="alephprover")
def main():
    """Aleph Prover CLI — submit Lean proof requests."""


@main.command()
@click.argument("file_path")
@click.argument("theorem_name")
@click.option("--hints", default=None, help="Hints for the prover")
@click.option("--time-budget", default=None, type=int, help="Time budget in minutes (default: server-side 900)")
@click.option("--cost-budget", default=None, type=float, help="Cost budget in USD (default: server-side 50)")
@click.option("-v", "--verbose", is_flag=True, help="List files included in the archive")
@click.option("--all-files", is_flag=True, help="Archive all project files (excludes .git, .lake, and .gitignore patterns)")
def prove(
    file_path: str,
    theorem_name: str,
    hints: str | None,
    time_budget: int | None,
    cost_budget: float | None,
    verbose: bool,
    all_files: bool,
):
    """Submit a Lean theorem for proving.

    FILE_PATH is the path to the Lean file (relative to project root).
    THEOREM_NAME is the name of the theorem to prove.
    """
    api_key = validate_api_key()
    api_url = get_api_url()

    # Find project root
    if Path(file_path).is_absolute():
        start = Path(file_path)
    else:
        start = Path.cwd()
    project_root = find_project_root(start)
    click.echo(f"Project root: {project_root}")

    # Resolve file_path relative to project root
    abs_file = (project_root / file_path) if not Path(file_path).is_absolute() else Path(file_path)
    if not abs_file.exists():
        click.echo(f"Error: File not found: {abs_file}", err=True)
        sys.exit(1)
    rel_file = abs_file.relative_to(project_root).as_posix()

    # Zip
    click.echo("Zipping project...")
    zip_path = zip_project(project_root, verbose=verbose, all_files=all_files)

    try:
        # Submit
        click.echo("Submitting proof request...")
        request_id = submit(api_url, api_key, zip_path, rel_file, theorem_name, hints, time_budget, cost_budget)
        click.echo(f"Request ID: {request_id}")
        click.echo(f"View at: {api_url}/requests/{request_id}")

        # Poll
        click.echo("Waiting for proof...")
        status = poll_status(api_url, api_key, request_id)

        if status != "completed":
            click.echo(f"Proof request {status}.", err=True)
            click.echo(f"Details: {api_url}/requests/{request_id}", err=True)
            sys.exit(1)

        click.echo("Proof completed!")

        # Download diff
        click.echo("Downloading diff...")
        patch_path = download_diff(api_url, api_key, request_id)

        if patch_path is None:
            click.echo(
                "Could not download diff. Check results at:\n"
                f"  {api_url}/requests/{request_id}",
                err=True,
            )
            sys.exit(1)

        # Apply
        click.echo("Applying patch...")
        if apply_patch(patch_path, project_root):
            click.echo("Proof applied successfully!")
            # Show what changed
            result = subprocess.run(["git", "diff", "--stat"], capture_output=True, text=True, cwd=project_root)
            if result.stdout:
                click.echo(result.stdout)
            # Cleanup patch
            patch_path.unlink(missing_ok=True)
        else:
            click.echo(
                f"Could not apply patch automatically.\n"
                f"Patch saved to: {patch_path}\n"
                f"Apply manually with: git apply {patch_path}",
                err=True,
            )
            sys.exit(1)
    finally:
        # Cleanup zip
        Path(zip_path).unlink(missing_ok=True)


@main.command("install-skill")
@click.option("--global", "global_", is_flag=True, help="Install to ~/.claude/commands/ instead of project")
def install_skill(global_: bool):
    """Install the /prove skill for Claude Code."""
    if global_:
        target = Path.home() / ".claude" / "commands" / "prove.md"
    else:
        target = Path.cwd() / ".claude" / "commands" / "prove.md"

    source = importlib.resources.files("alephprover") / "prove.md"
    content = source.read_text(encoding="utf-8")

    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(content, encoding="utf-8")
    click.echo(f"Installed /prove skill to {target}")
