# GLM Client 详细使用指南

## 目录

1. [安装与配置](#安装与配置)
2. [文本生成](#文本生成)
3. [视觉理解](#视觉理解)
4. [图像生成](#图像生成)
5. [语音合成](#语音合成)
6. [视频生成](#视频生成)
7. [文本嵌入](#文本嵌入)
8. [语音识别](#语音识别)
9. [高级用法](#高级用法)
10. [免费模型基准测试](#免费模型基准测试)

---

## 安装与配置

### 安装方式

```bash
# 从 PyPI 安装（推荐）
pip install glm-client

# 使用 UV 安装
uv pip install glm-client

# 从源码安装
git clone https://github.com/fengrui/GLM-API.git
cd GLM-API
uv sync
```

### API Key 配置

获取 API Key：访问 [https://open.bigmodel.cn/](https://open.bigmodel.cn/) 注册并创建。

**方法一：环境变量**

```bash
# Linux/macOS
export ZAI_API_KEY="your_api_key_here"

# Windows PowerShell
$env:ZAI_API_KEY="your_api_key_here"

# Windows CMD
set ZAI_API_KEY=your_api_key_here
```

**方法二：.env 文件**

在项目根目录创建 `.env` 文件：

```
ZAI_API_KEY=your_api_key_here
```

> 兼容旧版环境变量名 `ZHIPUAI_API_KEY`。

---

## 文本生成

### 可用模型

| 模型 | 价格 | 上下文 | 说明 |
|------|------|--------|------|
| `glm-4-flash` | **永久免费** | 128K | 推荐默认使用 |
| `glm-4.7-flash` | **永久免费** | 200K | 免费额度频率限制较严 |
| `glm-5.1` | 付费 | 32K+ | 最新旗舰模型 |
| `glm-4.7` | 付费 | 200K | 支持思考模式 |
| `glm-4.5-air` | 付费 | 128K | 高性价比 |

### 基础用法

```python
from glm_client import GLMClient, chat_completion

client = GLMClient()

# 非流式响应
response = chat_completion(
    "请用三句话介绍人工智能",
    client=client,
    stream=False,
)
print(response)

# 流式响应
for chunk in chat_completion(
    "请用三句话介绍人工智能",
    client=client,
    stream=True,
):
    print(chunk, end="")
```

### 自定义参数

```python
response = chat_completion(
    "写一首关于春天的诗",
    client=client,
    model="glm-5.1",          # 指定模型
    temperature=0.9,           # 创造性更高
    max_tokens=500,            # 限制输出长度
    top_p=0.95,                # 核采样
    system="你是一位诗人",      # 系统消息
    stream=False,
)
```

### 多轮对话

```python
history = [
    {"role": "user", "content": "我叫小明，今年25岁"},
    {"role": "assistant", "content": "你好小明！"},
    {"role": "user", "content": "我喜欢打篮球"},
    {"role": "assistant", "content": "篮球是一项很棒的运动！"},
]

response = chat_completion(
    "我之前说我叫什么名字？",
    client=client,
    history=history,
    stream=False,
)
```

### 思考模式

```python
# 需要支持思考的模型（如 glm-4.7）
response = chat_completion(
    "解方程 x^2 + 2x - 3 = 0",
    client=client,
    model="glm-4.7",
    thinking=True,
    stream=False,
)
```

### 联网搜索

```python
response = chat_completion(
    "今天的科技新闻有哪些？",
    client=client,
    web_search=True,
    stream=False,
)
```

---

## 视觉理解

### 可用模型

| 模型 | 价格 | 说明 |
|------|------|------|
| `glm-4v-flash` | **永久免费** | 推荐默认使用（OCR 基准测试满分） |
| `glm-4.6v` | 付费 | 更强视觉能力 |
| `glm-5v-turbo` | 付费 | 最新多模态模型 |

### 基础用法

```python
from glm_client import vision_completion

# 分析本地图片
result = vision_completion(
    "描述这张图片的内容",
    "photo.jpg",
    client=client,
)
print(result)

# 分析网络图片
result = vision_completion(
    "图片中有什么？",
    "https://example.com/image.jpg",
    client=client,
)
```

### 多图比较

```python
from glm_client import compare_images

result = compare_images(
    "比较这两张图片的异同",
    ["image1.jpg", "image2.jpg"],
    client=client,
)
```

---

## 图像生成

### 可用模型

| 模型 | 价格 | 说明 |
|------|------|------|
| `cogview-3-flash` | 付费（低） | 默认，快速生成 |
| `cogview-3-plus` | 付费 | 更高质量 |
| `cogview-4` | 付费 | 最新模型 |

### 基础用法

```python
from glm_client import generate_image, generate_and_save

# 生成图像（返回 URL 列表）
urls = generate_image(
    "一只穿着宇航服的猫在月球上",
    client=client,
    size="1024x1024",
)
for url in urls:
    print(url)

# 生成并保存到文件
paths = generate_and_save(
    "日落下的海滩",
    client=client,
    output="output/",
    size="1152x864",
    n=2,  # 生成 2 张
)
```

### 可用尺寸

`1024x1024`、`768x1344`、`864x1152`、`1152x864`、`1344x768`

---

## 语音合成

### 可用音色

| 音色 ID | 名称 | 性别 | 说明 |
|---------|------|------|------|
| `female` | 彤彤 | 女 | 默认女声 |
| `chen` | 小陈 | 男 | 男声音色 |
| `cuicui` | 锤锤 | 女 | 活泼女声 |
| `jam` | jam | 男 | 英文男声 |
| `kazi` | kazi | 男 | 英文男声 |
| `douji` | douji | 男 | 英文男声 |
| `luodo` | luodo | 女 | 英文女声 |

### 基础用法

```python
from glm_client import text_to_speech

# 默认参数
path = text_to_speech("你好，世界！", client=client)

# 自定义音色和格式
path = text_to_speech(
    "这是一段测试语音",
    client=client,
    voice="chen",
    response_format="mp3",
    speed=1.2,
    volume=1.0,
)
```

### Word 文档转语音

```python
from glm_client import word_to_speech

path = word_to_speech(
    "document.docx",
    client=client,
    voice="female",
    output="output.docx_audio.wav",
)
```

---

## 视频生成

### 可用模型

| 模型 | 价格 | 说明 |
|------|------|------|
| `cogvideox-2` | 付费（低） | 默认 |
| `cogvideox-3` | 付费 | 更高质量 |

### 基础用法

```python
from glm_client import generate_video, generate_and_save_video

# 文本生成视频
url = generate_video(
    "一只猫在草地上追逐蝴蝶",
    client=client,
    quality="quality",  # quality 或 speed
    with_audio=True,
)

# 图生视频
url = generate_video(
    "让画面中的人物动起来",
    client=client,
    image_url="https://example.com/photo.jpg",
)

# 生成并保存
path = generate_and_save_video(
    "日落海滩场景",
    client=client,
    output="sunset.mp4",
    fps=30,
)
```

---

## 文本嵌入

### 基础用法

```python
from glm_client import create_embedding, create_embeddings_batch, compute_similarity

# 单文本嵌入
vector = create_embedding("人工智能", client=client)
print(f"向量维度: {len(vector)}")

# 批量嵌入
vectors = create_embeddings_batch(
    ["人工智能", "机器学习", "深度学习"],
    client=client,
)

# 计算相似度
score = compute_similarity("人工智能", "机器学习", client=client)
print(f"相似度: {score:.4f}")
```

---

## 语音识别

### 基础用法

```python
from glm_client import transcribe_audio

# 本地文件识别
text = transcribe_audio("recording.wav", client=client)
print(text)

# 指定语言
text = transcribe_audio(
    "english_audio.mp3",
    client=client,
    language="en",
)
```

---

## 高级用法

### 自定义客户端配置

```python
from glm_client import GLMClient
from glm_client.config import GLMConfig

config = GLMConfig(
    api_key="your_key",
    timeout=300,      # 超时秒数
    max_retries=5,    # 最大重试次数
    retry_delay=2.0,  # 重试间隔
)

client = GLMClient(config=config)
```

### 上下文管理器

```python
with GLMClient() as client:
    response = chat_completion("你好", client=client, stream=False)
```

---

## 免费模型基准测试

运行基准测试脚本：

```bash
uv run python scripts/benchmark_summarize_ocr.py
```

测试结果将保存到 `docs/benchmark_summarize_ocr.md`。

详细基准测试结果请参考 [benchmark_summarize_ocr.md](benchmark_summarize_ocr.md)。
