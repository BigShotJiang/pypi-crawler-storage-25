#!/usr/bin/env bash
# glm-client 发布脚本
# 用法：
#   ./scripts/release.sh              # 构建 + 检查（不发布）
#   ./scripts/release.sh --test       # 发布到 TestPyPI
#   ./scripts/release.sh --pypi       # 发布到正式 PyPI
#   ./scripts/release.sh --pypi -y    # 跳过确认直接发布
set -euo pipefail

# ── 颜色 ──────────────────────────────────────────────
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
BOLD='\033[1m'
NC='\033[0m'

info()  { echo -e "${CYAN}[INFO]${NC} $*"; }
ok()    { echo -e "${GREEN}[OK]${NC} $*"; }
warn()  { echo -e "${YELLOW}[WARN]${NC} $*"; }
err()   { echo -e "${RED}[ERROR]${NC} $*"; }

# ── 解析参数 ───────────────────────────────────────────
TARGET="build"   # build | test | pypi
SKIP_CONFIRM=false

for arg in "$@"; do
    case "$arg" in
        --test)  TARGET="test" ;;
        --pypi)  TARGET="pypi" ;;
        -y)      SKIP_CONFIRM=true ;;
        -h|--help)
            echo "用法: $0 [--test|--pypi] [-y]"
            echo ""
            echo "  (无参数)    仅构建并检查包"
            echo "  --test      发布到 TestPyPI"
            echo "  --pypi      发布到正式 PyPI"
            echo "  -y          跳过发布确认"
            exit 0
            ;;
        *)
            err "未知参数: $arg"
            exit 1
            ;;
    esac
done

cd "$(git rev-parse --show-toplevel)"

# ── 1. 前置检查 ────────────────────────────────────────
info "检查环境..."

# 检查 git 工作区是否干净
if ! git diff --quiet || ! git diff --cached --quiet; then
    err "工作区有未提交的修改，请先 commit 或 stash。"
    git status --short
    exit 1
fi
ok "工作区干净"

# 检查是否在 main 分支
BRANCH=$(git branch --show-current)
if [[ "$BRANCH" != "main" ]]; then
    warn "当前分支: $BRANCH（非 main）"
    if [[ "$TARGET" == "pypi" ]]; then
        err "正式发布必须在 main 分支上执行"
        exit 1
    fi
fi

# 检查工具是否安装
for cmd in python twine; do
    if ! command -v "$cmd" &>/dev/null; then
        err "缺少 $cmd，请先安装：pip install build twine"
        exit 1
    fi
done

# 确认 python 能找到 build 模块
if ! python -c "import build" &>/dev/null; then
    err "缺少 build 模块，请先安装：pip install build"
    exit 1
fi

# ── 2. 读取版本号 ──────────────────────────────────────
VERSION=$(python -c "
import re
with open('pyproject.toml') as f:
    m = re.search(r'version\s*=\s*\"([^\"]+)\"', f.read())
    print(m.group(1))
")

INIT_VERSION=$(python -c "
import re
with open('src/glm_client/__init__.py') as f:
    m = re.search(r'__version__\s*=\s*\"([^\"]+)\"', f.read())
    print(m.group(1))
")

if [[ "$VERSION" != "$INIT_VERSION" ]]; then
    err "版本号不一致: pyproject.toml=$VERSION, __init__.py=$INIT_VERSION"
    exit 1
fi

echo ""
echo -e "${BOLD}═══════════════════════════════════════${NC}"
echo -e "${BOLD}  glm-client v${VERSION}${NC}"
echo -e "${BOLD}═══════════════════════════════════════${NC}"
echo ""

# ── 3. 清理 + 构建 ────────────────────────────────────
info "清理旧构建产物..."
rm -rf dist/ build/ *.egg-info src/*.egg-info

info "构建包..."
python -m build

echo ""
ok "构建完成，产物："
ls -lh dist/

# ── 4. 检查包 ──────────────────────────────────────────
info "检查包..."
twine check dist/* 2>&1 | tail -1

# 列出包内容摘要
FILE_COUNT=$(tar -tzf "dist/glm-client-${VERSION}.tar.gz" | grep "\.py$" | wc -l | tr -d ' ')
info "包内 .py 文件数: $FILE_COUNT"

# ── 5. 发布 ────────────────────────────────────────────
if [[ "$TARGET" == "build" ]]; then
    echo ""
    ok "构建完成（未发布）。使用 --test 或 --pypi 发布。"
    exit 0
fi

echo ""
if [[ "$TARGET" == "pypi" ]]; then
    echo -e "${RED}${BOLD}即将发布到正式 PyPI！${NC}"
    echo -e "${RED}版本号 $VERSION 一旦发布即不可覆盖。${NC}"
fi

if [[ "$SKIP_CONFIRM" != "true" ]]; then
    echo ""
    read -rp "$(echo -e ${BOLD}"确认发布到 $TARGET？[y/N] "${NC})" confirm
    if [[ "$confirm" != "y" && "$confirm" != "Y" ]]; then
        info "已取消"
        exit 0
    fi
fi

echo ""
if [[ "$TARGET" == "test" ]]; then
    info "发布到 TestPyPI..."
    twine upload --repository testpypi dist/*
    echo ""
    ok "已发布到 TestPyPI: https://test.pypi.org/project/glm-client/${VERSION}/"
    info "验证安装: pip install --index-url https://test.pypi.org/simple/ glm-client==${VERSION}"
else
    info "发布到 PyPI..."
    twine upload dist/*
    echo ""
    ok "已发布到 PyPI: https://pypi.org/project/glm-client/${VERSION}/"
    info "安装: pip install glm-client==${VERSION}"
fi

echo ""
ok "完成！"
