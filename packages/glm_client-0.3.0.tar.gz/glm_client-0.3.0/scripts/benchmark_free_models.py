"""免费模型全面基准测试脚本（精简版）。

覆盖智谱AI所有免费模型的多维度评测：
- 文本模型(4个)：速度、推理、指令遵循、上下文理解、代码生成
- 视觉模型(3个)：OCR 中文长文本、OCR 中英混排、OCR 结构化文本
- 图像生成(1个)：质量评估
- 视频生成(1个)：质量评估

用法: uv run python scripts/benchmark_free_models.py
"""

import base64
import io
import json
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from dotenv import load_dotenv

load_dotenv()

from glm_client import GLMClient, GLMConfig, chat_completion, vision_completion, generate_image
from glm_client.models.video import generate_video

# ============================================================
# 配置
# ============================================================

TEXT_MODELS = ["glm-4.7-flash", "glm-4-flash-250414", "glm-z1-flash", "glm-4-flash"]
VISION_MODELS = ["glm-4.6v-flash", "glm-4v-flash", "glm-4.1v-thinking-flash"]
IMAGE_MODEL = "cogview-3-flash"
VIDEO_MODEL = "cogvideox-flash"

# 每个 API 调用后的等待时间（秒），用于避免频率限制
# 严格控制并发量为 1，所有调用均为顺序执行
API_DELAY = 2.0

TEXT_WEIGHTS = {
    "speed": 0.10,
    "reasoning": 0.30,
    "instruction_following": 0.20,
    "context_understanding": 0.20,
    "code_generation": 0.20,
}

VISION_WEIGHTS = {
    "ocr_chinese_text": 0.34,
    "ocr_mixed_cn_en": 0.33,
    "ocr_structured": 0.33,
}

# ============================================================
# 文本测试用例（精简版，每个维度 2-3 题）
# ============================================================

SPEED_PROMPT = "请用三句话介绍人工智能的发展历史。"

REASONING_PROMPTS = [
    {
        "prompt": "一个房间里有3个开关，分别控制隔壁房间的3盏灯。你只能进隔壁房间一次。如何确定每个开关控制哪盏灯？",
        "check": lambda r: "热" in r or "温度" in r or "摸" in r or "烫" in r,
        "key": "灯泡温度逻辑",
    },
    {
        "prompt": "计算：(15 × 8 + 120) ÷ 6 - 25 = ? 请给出计算过程和最终答案。",
        "check": lambda r: "25" in r,
        "key": "算术计算",
    },
    {
        "prompt": "所有的猫都会飞。加菲是一只猫。根据以上前提，加菲会飞吗？请分析这个三段论推理的正确性。",
        "check": lambda r: any(w in r for w in ["前提", "假", "错误", "不成立", "不正确", "不真", "前提不"]),
        "key": "逻辑分析",
    },
]

INSTRUCTION_PROMPTS = [
    {
        "prompt": "用JSON格式输出两个城市的基本信息，包含name和population字段。",
        "check": lambda r: "{" in r and "}" in r and "name" in r and "population" in r,
        "key": "JSON格式",
    },
    {
        "prompt": "只回答'是'或'否'，不要任何解释：地球是太阳系中最大的行星吗？",
        "check": lambda r: r.strip().startswith(("否", "不是", "No", "no")),
        "key": "Yes/No",
    },
    {
        "prompt": "列出恰好5个学习编程的理由，每条用数字编号。",
        "check": lambda r: sum(1 for i in range(1, 6) if str(i) in r) >= 4,
        "key": "5条编号",
    },
]

CONTEXT_PROMPTS = [
    {"role": "user", "content": "我叫小明，今年25岁，我在北京工作。"},
    {"role": "assistant", "content": "你好小明！很高兴认识你。"},
    {"role": "user", "content": "我的爱好是打篮球和看电影。"},
    {"role": "assistant", "content": "打篮球和看电影都是很棒的爱好！"},
    {"role": "user", "content": "我最近在学Python编程，已经学了3个月了。"},
    {"role": "assistant", "content": "学Python是个很好的选择！"},
    {"role": "user", "content": "请总结一下我前面提到的所有个人信息。"},
]

CODE_GENERATION_PROMPTS = [
    ("用Python实现快速排序算法，包含测试用例。", "python"),
    ("写一个SQL查询：从订单表中找出每个客户消费总额超过1000元的记录。", "sql"),
]

# ============================================================
# 视觉测试用例（OCR 专项）
# ============================================================

# macOS 系统中文字体
ZH_FONT_PATH = "/System/Library/Fonts/STHeiti Medium.ttc"

# 测试文档内容定义
CHINESE_LONG_TEXT = {
    "title": "中文长文本",
    "content": (
        "深度学习是机器学习的一个重要分支，它通过构建多层神经网络来模拟人脑的信息处理方式。"
        "近年来，深度学习在计算机视觉、自然语言处理和语音识别等领域取得了突破性进展。"
        "卷积神经网络（CNN）在图像分类任务中表现出色，能够自动提取图像中的空间特征。"
        "循环神经网络（RNN）及其变体LSTM和GRU则特别适合处理序列数据，如文本和语音。"
        "Transformer架构的出现彻底改变了自然语言处理领域的格局，BERT和GPT等模型不断刷新各项任务的成绩。"
        "生成对抗网络（GAN）通过对抗训练的方式生成高质量的图像、音频和视频内容。"
        "强化学习与深度学习的结合使得智能体能够在复杂环境中做出最优决策，"
        "例如AlphaGo就是利用深度强化学习在围棋领域超越了人类顶尖棋手。"
        "联邦学习是一种分布式机器学习方法，它允许多个参与者在不共享原始数据的情况下共同训练模型，"
        "有效保护了用户隐私，同时在医疗健康和金融服务等领域展现了巨大的应用潜力。"
    ),
    "keywords": [
        "深度学习", "机器学习", "神经网络", "计算机视觉", "自然语言处理",
        "语音识别", "卷积神经网络", "CNN", "图像分类", "空间特征",
        "循环神经网络", "RNN", "LSTM", "GRU", "序列数据",
        "Transformer", "BERT", "GPT", "生成对抗网络", "GAN",
        "对抗训练", "强化学习", "AlphaGo", "围棋", "联邦学习",
        "分布式", "隐私", "医疗健康", "金融服务", "应用潜力",
    ],
}

MIXED_CN_EN_TEXT = {
    "title": "中英混排",
    "content": (
        "基于Transformer的多模态融合方法研究\n"
        "A Study on Transformer-based Multimodal Fusion Methods\n"
        "Abstract: Multimodal fusion aims to integrate information from different data sources "
        "such as text, image, and audio to improve downstream task performance. "
        "This paper proposes a novel cross-attention mechanism that achieves state-of-the-art results "
        "on multiple benchmark datasets. "
        "Our experimental results demonstrate significant improvements in both accuracy and efficiency.\n"
        "关键词：多模态融合；Transformer；交叉注意力；深度学习；特征对齐"
    ),
    "keywords": [
        "Transformer", "多模态融合", "Abstract", "Multimodal",
        "fusion", "integrate", "information", "data sources",
        "image", "audio", "downstream", "performance",
        "cross-attention", "mechanism", "state-of-the-art",
        "benchmark", "datasets", "accuracy", "efficiency",
        "关键词", "交叉注意力", "深度学习", "特征对齐", "融合方法",
    ],
}

STRUCTURED_TEXT = {
    "title": "结构化文本",
    "content": (
        "第二章 相关工作综述\n"
        "2.1 注意力机制的发展\n"
        "注意力机制最早由Bahdanau等人在机器翻译任务中提出，它允许模型动态地关注输入序列的不同部分。"
        "随后Vaswani等人提出了自注意力机制，将注意力计算简化为Query、Key和Value三个矩阵的运算。"
        "这一创新使得模型能够并行处理所有位置的信息，大幅提升了训练效率。\n"
        "2.2 预训练语言模型\n"
        "BERT通过掩码语言模型和下一句预测两个预训练任务，学习到了丰富的双向上下文表示。"
        "GPT系列则采用自回归的方式，在生成任务上展现了强大的能力。"
        "T5模型将所有NLP任务统一为文本到文本的格式，简化了模型设计和使用流程。\n"
        "2.3 多模态学习方法\n"
        "CLIP模型通过对比学习将图像和文本映射到共享的语义空间，实现了零样本图像分类。"
        "ViLBERT和LXMERT等模型则在视觉问答和图像描述等任务上取得了优异的表现。"
    ),
    "keywords": [
        "第二章", "相关工作", "2.1", "注意力机制", "Bahdanau",
        "机器翻译", "输入序列", "Vaswani", "自注意力", "Query",
        "Key", "Value", "矩阵", "并行处理", "训练效率",
        "2.2", "预训练", "语言模型", "BERT", "掩码",
        "双向", "上下文", "GPT", "自回归", "T5",
        "NLP", "2.3", "多模态", "CLIP", "对比学习",
        "语义空间", "零样本", "ViLBERT", "LXMERT", "视觉问答",
    ],
}


def _render_text_image(text: str, width: int = 800, font_size: int = 22) -> str:
    """将文本渲染为白色背景图片，返回 base64 编码。"""
    from PIL import Image, ImageDraw, ImageFont

    font = ImageFont.truetype(ZH_FONT_PATH, font_size)
    # 先测量文本布局
    img_tmp = Image.new("RGB", (width, 100), "white")
    draw_tmp = ImageDraw.Draw(img_tmp)
    margin = 40
    line_spacing = 8
    # 逐段排版
    paragraphs = text.split("\n")
    lines = []
    for para in paragraphs:
        if not para.strip():
            lines.append("")
            continue
        bbox = draw_tmp.textbbox((0, 0), para, font=font)
        text_w = bbox[2] - bbox[0]
        if text_w <= width - 2 * margin:
            lines.append(para)
        else:
            # 手动换行
            line = ""
            for ch in para:
                test = line + ch
                bbox = draw_tmp.textbbox((0, 0), test, font=font)
                if bbox[2] - bbox[0] > width - 2 * margin:
                    lines.append(line)
                    line = ch
                else:
                    line = test
            if line:
                lines.append(line)

    # 计算高度
    line_h = font_size + line_spacing
    height = 2 * margin + len(lines) * line_h + 40
    height = max(height, 200)

    img = Image.new("RGB", (width, height), "white")
    draw = ImageDraw.Draw(img)
    y = margin
    for line in lines:
        if line:
            draw.text((margin, y), line, fill="black", font=font)
        y += line_h

    buf = io.BytesIO()
    img.save(buf, format="PNG")
    return base64.b64encode(buf.getvalue()).decode("utf-8")


def generate_document_images():
    """生成 3 类 OCR 测试文档图片，返回 {key: (image_base64, keywords, title)}。"""
    images = {}
    for key, doc in [
        ("ocr_chinese_text", CHINESE_LONG_TEXT),
        ("ocr_mixed_cn_en", MIXED_CN_EN_TEXT),
        ("ocr_structured", STRUCTURED_TEXT),
    ]:
        b64 = _render_text_image(doc["content"])
        images[key] = (b64, doc["keywords"], doc["title"])
    return images


def run_ocr_test(client, model, doc_images: dict):
    """对单个模型运行 OCR 测试。"""
    results = {}

    for idx, (key, (img_b64, keywords, title)) in enumerate(doc_images.items(), 1):
        print(f"  [{idx}/3] {title}...", end="", flush=True)
        try:
            # 使用 data URI 传入 base64 图片
            data_uri = f"data:image/png;base64,{img_b64}"
            resp = api_call(
                lambda: vision_completion(
                    prompt="请仔细识别并提取这张图片中的所有文字内容，按原文顺序输出，不要添加任何解释。",
                    image=data_uri,
                    client=client,
                    model=model,
                )
            )
            # 计算关键词命中率
            hits = [kw for kw in keywords if kw in resp]
            hit_rate = len(hits) / len(keywords) if keywords else 0
            score = round(hit_rate * 10, 1)

            results[key] = {
                "score": score,
                "keywords_total": len(keywords),
                "keywords_hit": len(hits),
                "preview": resp[:200],
            }
            print(f" {score}")
        except Exception as e:
            print(f" 失败: {e}")
            results[key] = {"score": 0, "error": str(e)}

    return results


# ============================================================
# 图像/视频生成测试用例
# ============================================================

IMAGE_GEN_PROMPTS = [
    "一只可爱的橘猫坐在窗台上，阳光洒进来，温馨治愈的风格",
    "赛博朋克风格的中国古代建筑，霓虹灯光，雨夜",
]

VIDEO_GEN_PROMPTS = [
    "一只金毛犬在海边奔跑，海浪拍打沙滩，阳光明媚",
]


# ============================================================
# 工具函数
# ============================================================

def api_call(func, *args, **kwargs):
    """统一 API 调用包装，带延迟和简单重试。严格控制顺序执行，不并行。"""
    t0 = time.time()
    try:
        result = func(*args, **kwargs)
        elapsed = time.time() - t0
        print(f"    ({elapsed:.1f}s)", end="", flush=True)
        time.sleep(API_DELAY)
        return result
    except Exception as e:
        elapsed = time.time() - t0
        print(f"    ({elapsed:.1f}s) WARN: {e}")
        time.sleep(3)
        t1 = time.time()
        try:
            result = func(*args, **kwargs)
            elapsed2 = time.time() - t1
            print(f"    (重试 {elapsed2:.1f}s)", end="", flush=True)
            time.sleep(API_DELAY)
            return result
        except Exception as e2:
            elapsed2 = time.time() - t1
            print(f"    (重试 {elapsed2:.1f}s) ERROR: {e2}")
            raise


# ============================================================
# 文本基准测试
# ============================================================

def run_speed_test(client, model):
    """速度测试（2次取中位数）。"""
    times = []
    for i in range(2):
        start = time.time()
        try:
            api_call(
                lambda: chat_completion(prompt=SPEED_PROMPT, client=client, model=model, stream=False)
            )
            times.append(time.time() - start)
        except Exception:
            times.append(float("inf"))

    times.sort()
    median = times[0]
    score = max(0, min(10, 10 * (15 - median) / 14))
    return {"median_seconds": round(median, 2), "score": round(score, 1)}


def run_reasoning_test(client, model):
    """推理与数学测试。"""
    results = []
    for item in REASONING_PROMPTS:
        try:
            resp = api_call(
                lambda p=item["prompt"]: chat_completion(prompt=p, client=client, model=model, stream=False)
            )
            passed = item["check"](resp)
            results.append({"key": item["key"], "passed": passed, "preview": resp[:150]})
        except Exception as e:
            results.append({"key": item["key"], "passed": False, "error": str(e)})

    score = sum(1 for r in results if r["passed"]) / max(len(results), 1) * 10
    return {"results": results, "score": round(score, 1)}


def run_instruction_test(client, model):
    """指令遵循测试。"""
    results = []
    for item in INSTRUCTION_PROMPTS:
        try:
            resp = api_call(
                lambda p=item["prompt"]: chat_completion(prompt=p, client=client, model=model, stream=False)
            )
            passed = item["check"](resp)
            results.append({"key": item["key"], "passed": passed, "preview": resp[:100]})
        except Exception as e:
            results.append({"key": item["key"], "passed": False, "error": str(e)})

    score = sum(1 for r in results if r["passed"]) / max(len(results), 1) * 10
    return {"results": results, "score": round(score, 1)}


def run_context_test(client, model):
    """上下文理解测试。"""
    try:
        resp = api_call(
            lambda: chat_completion(
                prompt="请回答上面的问题。",
                client=client,
                model=model,
                stream=False,
                history=CONTEXT_PROMPTS[:-1],
            )
        )
        checks = {
            "名字": "小明" in resp,
            "年龄": "25" in resp,
            "城市": "北京" in resp,
            "爱好": "篮球" in resp or "电影" in resp,
            "编程": "python" in resp.lower() or "编程" in resp,
        }
        score = sum(checks.values()) / len(checks) * 10
        return {"checks": checks, "score": round(score, 1), "preview": resp[:200]}
    except Exception as e:
        return {"score": 0, "error": str(e)}


def run_code_test(client, model):
    """代码生成测试。"""
    results = []
    for prompt, lang in CODE_GENERATION_PROMPTS:
        try:
            resp = api_call(
                lambda p=prompt: chat_completion(prompt=p, client=client, model=model, stream=False)
            )
            has_block = "```" in resp
            has_lang = lang in resp.lower() or "def " in resp or "SELECT" in resp.upper()
            results.append({
                "prompt": prompt[:30],
                "has_code_block": has_block,
                "has_lang": has_lang,
            })
        except Exception as e:
            results.append({"prompt": prompt[:30], "error": str(e)})

    scores = []
    for r in results:
        if "error" in r:
            scores.append(0)
        elif r["has_code_block"] and r["has_lang"]:
            scores.append(10)
        elif r["has_code_block"]:
            scores.append(7)
        elif r["has_lang"]:
            scores.append(5)
        else:
            scores.append(2)

    return {"results": results, "score": round(sum(scores) / max(len(scores), 1), 1)}


# ============================================================
# 视觉基准测试
# ============================================================

def run_vision_benchmark(client, model, doc_images: dict):
    """运行视觉模型 OCR 测试。"""
    return run_ocr_test(client, model, doc_images)


# ============================================================
# 图像/视频生成测试
# ============================================================

def run_image_gen_test(client):
    """图像生成质量测试。"""
    results = []
    for prompt in IMAGE_GEN_PROMPTS:
        print(f"  生成: {prompt[:25]}...")
        try:
            start = time.time()
            urls = generate_image(prompt=prompt, client=client, model=IMAGE_MODEL, size="1024x1024")
            elapsed = time.time() - start
            results.append({
                "prompt": prompt[:35],
                "url": urls[0] if urls else "",
                "elapsed": round(elapsed, 2),
                "success": bool(urls),
            })
            time.sleep(API_DELAY)
        except Exception as e:
            results.append({"prompt": prompt[:35], "error": str(e), "success": False})

    success = sum(1 for r in results if r.get("success"))
    return {
        "model": IMAGE_MODEL,
        "results": results,
        "success_rate": f"{success}/{len(results)}",
    }


def run_video_gen_test(client):
    """视频生成质量测试。"""
    results = []
    for prompt in VIDEO_GEN_PROMPTS:
        print(f"  生成: {prompt[:25]}...")
        try:
            start = time.time()
            url = generate_video(prompt=prompt, client=client, model=VIDEO_MODEL, size="1280x720")
            elapsed = time.time() - start
            results.append({
                "prompt": prompt[:35],
                "url": url,
                "elapsed": round(elapsed, 2),
                "success": True,
            })
        except Exception as e:
            results.append({"prompt": prompt[:35], "error": str(e), "success": False})

    success = sum(1 for r in results if r.get("success"))
    return {
        "model": VIDEO_MODEL,
        "results": results,
        "success_rate": f"{success}/{len(results)}",
    }


# ============================================================
# 报告生成
# ============================================================

def generate_report(text_results, vision_results, image_results, video_results):
    """生成 Markdown 报告。"""
    now = time.strftime("%Y-%m-%d %H:%M:%S")
    lines = [
        "# GLM 免费模型全面基准测试报告\n",
        f"测试时间: {now}",
        f"API_DELAY: {API_DELAY}s\n",
    ]

    # ---- 文本模型 ----
    lines.append("## 一、文本模型基准测试\n")
    lines.append(f"测试模型: {', '.join(f'`{m}`' for m in TEXT_MODELS)}\n")
    lines.append("### 测试维度\n")
    lines.append("| 维度 | 权重 | 说明 |")
    lines.append("|------|------|------|")
    lines.append("| 响应速度 | 10% | 中位数延迟（≤1s满分，≥15s零分） |")
    lines.append("| 推理与数学 | 30% | 3个推理/数学题，关键答案验证 |")
    lines.append("| 指令遵循 | 20% | 3个约束指令，格式/内容检查 |")
    lines.append("| 上下文理解 | 20% | 多轮对话信息召回（5个信息点） |")
    lines.append("| 代码生成 | 20% | Python/SQL代码块检测 |")
    lines.append("")

    # 汇总表
    lines.append("### 评分汇总\n")
    lines.append("| 模型 | 速度 | 推理 | 指令 | 上下文 | 代码 | **总分** |")
    lines.append("|------|------|------|------|--------|------|---------|")
    for model, data in text_results.items():
        cols = [
            str(data["speed"]["score"]),
            str(data["reasoning"]["score"]),
            str(data["instruction_following"]["score"]),
            str(data["context_understanding"]["score"]),
            str(data["code_generation"]["score"]),
            f"**{data['total_score']}**",
        ]
        lines.append(f"| `{model}` | {' | '.join(cols)} |")
    lines.append("")

    # 详细结果
    lines.append("### 详细结果\n")
    for model, data in text_results.items():
        lines.append(f"#### `{model}` (总分: {data['total_score']})\n")

        lines.append(f"- **速度**: 中位数 {data['speed']['median_seconds']}s")

        lines.append(f"- **推理**: {data['reasoning']['score']}/10")
        for r in data["reasoning"]["results"]:
            mark = "PASS" if r["passed"] else "FAIL"
            lines.append(f"  - [{mark}] {r['key']}")

        lines.append(f"- **指令遵循**: {data['instruction_following']['score']}/10")
        for r in data["instruction_following"]["results"]:
            mark = "PASS" if r["passed"] else "FAIL"
            lines.append(f"  - [{mark}] {r['key']}: {r.get('preview', '')[:60]}")

        lines.append(f"- **上下文理解**: {data['context_understanding']['score']}/10")
        if "checks" in data["context_understanding"]:
            for k, v in data["context_understanding"]["checks"].items():
                mark = "PASS" if v else "FAIL"
                lines.append(f"  - [{mark}] {k}")

        lines.append(f"- **代码生成**: {data['code_generation']['score']}/10")
        for r in data["code_generation"]["results"]:
            bc = "Y" if r.get("has_code_block") else "N"
            bl = "Y" if r.get("has_lang") else "N"
            lines.append(f"  - [代码块:{bc} 语言:{bl}] {r.get('prompt', '')[:30]}")

        lines.append("")

    # 排名
    ranked = sorted(text_results.items(), key=lambda x: x[1]["total_score"], reverse=True)
    lines.append("### 文本模型排名\n")
    for i, (model, data) in enumerate(ranked, 1):
        medal = {1: "🥇", 2: "🥈", 3: "🥉"}.get(i, f"{i}.")
        lines.append(f"{medal} `{model}` — 总分 {data['total_score']}/10")
    lines.append("")

    # 各维度最佳
    lines.append("### 各维度最优\n")
    dim_names = {
        "speed": "响应速度",
        "reasoning": "推理与数学",
        "instruction_following": "指令遵循",
        "context_understanding": "上下文理解",
        "code_generation": "代码生成",
    }
    for dim, name in dim_names.items():
        best = max(text_results.items(), key=lambda x: x[1][dim]["score"])
        lines.append(f"- **{name}**: `{best[0]}` ({best[1][dim]['score']}/10)")
    lines.append("")

    # ---- 视觉模型 ----
    lines.append("## 二、视觉模型 OCR 基准测试\n")
    lines.append(f"测试模型: {', '.join(f'`{m}`' for m in VISION_MODELS)}\n")
    lines.append("### 测试说明\n")
    lines.append("使用 Pillow 生成包含已知文本的文档图片，对比模型 OCR 识别结果与原文的关键词命中率。")
    lines.append("测试场景：扫描版文档/论文的中文长文本识别。\n")

    lines.append("### 评分汇总\n")
    lines.append("| 模型 | 中文长文本 | 中英混排 | 结构化文本 | **总分** |")
    lines.append("|------|----------|---------|----------|---------|")
    for model, data in vision_results.items():
        cols = [
            str(data["ocr_chinese_text"]["score"]),
            str(data["ocr_mixed_cn_en"]["score"]),
            str(data["ocr_structured"]["score"]),
            f"**{data['total_score']}**",
        ]
        lines.append(f"| `{model}` | {' | '.join(cols)} |")
    lines.append("")

    # 详细结果
    lines.append("### 详细结果\n")
    dim_labels = {
        "ocr_chinese_text": "中文长文本",
        "ocr_mixed_cn_en": "中英混排",
        "ocr_structured": "结构化文本",
    }
    for model, data in vision_results.items():
        lines.append(f"#### `{model}` (总分: {data['total_score']})\n")
        for dim, label in dim_labels.items():
            d = data[dim]
            if "error" in d:
                lines.append(f"- **{label}**: 失败 — {d['error']}")
            else:
                lines.append(f"- **{label}**: {d['score']}/10 (关键词命中 {d['keywords_hit']}/{d['keywords_total']})")
        lines.append("")

    ranked_v = sorted(vision_results.items(), key=lambda x: x[1]["total_score"], reverse=True)
    lines.append("### 视觉模型排名\n")
    for i, (model, data) in enumerate(ranked_v, 1):
        medal = {1: "🥇", 2: "🥈", 3: "🥉"}.get(i, f"{i}.")
        lines.append(f"{medal} `{model}` — 总分 {data['total_score']}/10")
    lines.append("")

    # ---- 图像生成 ----
    lines.append("## 三、图像生成测试 (CogView-3-Flash)\n")
    for r in image_results.get("results", []):
        if r.get("success"):
            lines.append(f"- \"{r['prompt']}...\" — {r['elapsed']}s — [查看]({r['url']})")
        else:
            lines.append(f"- \"{r['prompt']}...\" — 失败: {r.get('error', '')}")
    lines.append(f"\n成功率: {image_results.get('success_rate', 'N/A')}\n")

    # ---- 视频生成 ----
    lines.append("## 四、视频生成测试 (CogVideoX-Flash)\n")
    for r in video_results.get("results", []):
        if r.get("success"):
            lines.append(f"- \"{r['prompt']}...\" — {r['elapsed']}s — [查看]({r['url']})")
        else:
            lines.append(f"- \"{r['prompt']}...\" — 失败: {r.get('error', '')}")
    lines.append(f"\n成功率: {video_results.get('success_rate', 'N/A')}\n")

    # ---- 总结 ----
    lines.append("## 五、总结\n")
    lines.append(f"**最佳文本模型**: `{ranked[0][0]}` (总分 {ranked[0][1]['total_score']})")
    lines.append(f"**最佳视觉模型**: `{ranked_v[0][0]}` (总分 {ranked_v[0][1]['total_score']})\n")

    lines.append("---")
    lines.append("")
    lines.append("*本报告由 `scripts/benchmark_free_models.py` 自动生成。*")

    return "\n".join(lines)


# ============================================================
# 主流程
# ============================================================

def main():
    print("=" * 60)
    print("GLM 免费模型基准测试（精简版）")
    print(f"API_DELAY = {API_DELAY}s")
    print("=" * 60)

    config = GLMConfig.from_env()
    config.max_retries = 1  # SDK 层最多重试 1 次
    config.timeout = 60     # SDK 超时 60 秒
    client = GLMClient(config=config)

    # ---- 文本模型 ----
    print("\n[第一部分] 文本模型基准测试")
    text_results = {}
    text_tests = [
        ("速度", "speed", run_speed_test),
        ("推理", "reasoning", run_reasoning_test),
        ("指令", "instruction_following", run_instruction_test),
        ("上下文", "context_understanding", run_context_test),
        ("代码", "code_generation", run_code_test),
    ]

    for model in TEXT_MODELS:
        print(f"\n--- {model} ---")
        data = {}
        for idx, (name, key, func) in enumerate(text_tests, 1):
            print(f"  [{idx}/{len(text_tests)}] {name}...", end="", flush=True)
            try:
                data[key] = func(client, model)
                print(f" {data[key]['score']}")
            except Exception as e:
                print(f" 失败: {e}")
                data[key] = {"score": 0, "error": str(e)}

        total = sum(data[dim]["score"] * TEXT_WEIGHTS[dim] for dim in TEXT_WEIGHTS)
        data["total_score"] = round(total, 2)
        print(f"  >> 总分: {data['total_score']}")
        text_results[model] = data

    # ---- 视觉模型 ----
    print(f"\n[第二部分] 视觉模型 OCR 基准测试")
    print("  生成测试文档图片...")
    doc_images = generate_document_images()
    print(f"  已生成 {len(doc_images)} 张测试图片")
    vision_results = {}
    for model in VISION_MODELS:
        print(f"\n--- {model} ---")
        data = run_vision_benchmark(client, model, doc_images)
        total = sum(data[dim]["score"] * VISION_WEIGHTS[dim] for dim in VISION_WEIGHTS)
        data["total_score"] = round(total, 2)
        print(f"  >> 总分: {data['total_score']}")
        vision_results[model] = data

    # ---- 图像生成 ----
    print(f"\n[第三部分] 图像生成测试")
    image_results = run_image_gen_test(client)

    # ---- 视频生成 ----
    print(f"\n[第四部分] 视频生成测试")
    video_results = run_video_gen_test(client)

    # ---- 生成报告 ----
    report = generate_report(text_results, vision_results, image_results, video_results)

    report_path = Path(__file__).parent.parent / "docs" / "benchmark_free_models.md"
    report_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.write_text(report, encoding="utf-8")
    print(f"\n报告已保存到: {report_path}")

    raw = {
        "text": text_results,
        "vision": vision_results,
        "image": image_results,
        "video": video_results,
    }
    data_path = report_path.with_suffix(".json")
    data_path.write_text(json.dumps(raw, indent=2, ensure_ascii=False, default=str), encoding="utf-8")
    print(f"原始数据: {data_path}")


if __name__ == "__main__":
    main()
