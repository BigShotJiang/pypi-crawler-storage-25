"""文本总结 & OCR 多轮综合基准测试。

聚焦评测三个维度：
- 质量 (40%)：文本总结结构化质量 + OCR 关键词命中
- 速度 (30%)：平均响应时间
- 稳定性 (30%)：成功率，含重试惩罚

每个模型进行 3 轮测试，综合评分 = 质量×40% + 速度×30% + 稳定性×30%

用法: uv run python scripts/benchmark_summarize_ocr.py
"""

import base64
import io
import json
import sys
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from dotenv import load_dotenv

load_dotenv()

from glm_client import GLMClient, GLMConfig, summarize, vision_completion
from glm_client.models.summarize import DocumentSummary

# ============================================================
# 配置
# ============================================================

TEXT_MODELS = ["glm-4-flash-250414", "glm-z1-flash", "glm-4-flash", "glm-4.7-flash"]
VISION_MODELS = ["glm-4.6v-flash", "glm-4v-flash", "glm-4.1v-thinking-flash"]

API_DELAY = 5.0  # 摘要文本较长，需要更大延迟避免频率限制
NUM_ROUNDS = 3  # 每个模型测试轮数
MODEL_COOLDOWN = 10.0  # 模型间冷却时间
SECTION_COOLDOWN = 30.0  # 文本/OCR 两部分之间冷却时间


# ============================================================
# 结构化调用结果
# ============================================================


@dataclass
class CallResult:
    """单次 API 调用的结构化结果。"""

    success: bool
    response: object | None = None  # DocumentSummary 或 str
    elapsed: float = 0.0
    retries: int = 0  # 0=首次成功, 1=重试1次成功, ...
    error: str | None = None


# ============================================================
# 摘要测试用例
# ============================================================

SUMMARIZE_TEST_CASES = [
    {
        "name": "技术文档",
        "content": (
            "智谱AI技术白皮书（节选）\n\n"
            "第一章 GLM 大模型架构\n"
            "GLM（General Language Model）是一种基于自回归空白填充的预训练语言模型架构。"
            "与传统的 BERT 或 GPT 不同，GLM 统一了自然语言理解和自然语言生成两个任务。"
            "其核心创新在于将文本分为两部分：一部分作为上下文（Part A），另一部分作为生成目标（Part B）。"
            "模型通过随机遮盖连续的文本片段，然后学习在上下文中恢复这些片段，"
            "从而同时获得了双向编码和单向解码的能力。\n\n"
            "第二章 多模态扩展\n"
            "智谱AI在 GLM 架构基础上，进一步开发了多模态模型。"
            "GLM-4V 系列支持图像理解、OCR 识别、图表分析等视觉任务。"
            "通过将图像编码为视觉 token 序列，与文本 token 一起输入 Transformer 架构进行处理。"
            "CogView 系列则专注于文生图能力，使用扩散模型生成高质量图像。"
            "CogVideo 系列实现了文本到视频的生成，在短视频创作领域表现优异。\n\n"
            "第三章 应用场景\n"
            "GLM 系列模型已广泛应用于智能客服、文档分析、代码生成、学术研究等领域。"
            "在企业场景中，GLM 可以自动化处理合同审核、报告生成、数据提取等任务，"
            "大幅提升工作效率。在教育领域，GLM 可以作为智能助教，帮助学生理解复杂概念。"
            "在科研领域，GLM 可以辅助论文写作、文献综述和实验设计。\n\n"
            "第四章 性能与优化\n"
            "智谱AI在模型推理效率上做了大量优化工作。"
            "通过量化技术（INT4/INT8），模型可以在保持精度的同时将推理速度提升 2-4 倍。"
            "Flash Attention 技术将注意力计算复杂度从 O(n²) 降低到 O(n)。"
            "vLLM 推理框架配合 PagedAttention 技术，实现了高效的 KV 缓存管理，"
            "使得大批量推理的吞吐量提升了 3-5 倍。"
        ),
        "expected_title_keywords": ["智谱", "GLM", "技术", "白皮书"],
        "expected_doc_type": "报告",
        "expected_keywords_any": ["GLM", "多模态", "预训练", "模型", "应用"],
        "expected_parties": ["智谱"],
        "check_summary_quality": lambda s: len(s) >= 30 and len(s) <= 500,
    },
    {
        "name": "商业合同",
        "content": (
            "技术服务合同\n\n"
            "合同编号：GLM-2025-SVC-001\n"
            "签订日期：2025年3月15日\n"
            "签订地点：北京市海淀区\n\n"
            "甲方：北京智能科技有限公司\n"
            "地址：北京市海淀区中关村大街1号\n"
            "法定代表人：张三\n\n"
            "乙方：上海数据服务有限公司\n"
            "地址：上海市浦东新区世纪大道100号\n"
            "法定代表人：李四\n\n"
            "第一条 服务内容\n"
            "乙方为甲方提供以下技术服务：\n"
            "1. GLM 大模型 API 接口服务，包括文本生成、对话补全、文档摘要功能\n"
            "2. 技术支持服务，包含工作日 9:00-18:00 的在线技术支持\n"
            "3. 定期模型版本更新与性能优化\n\n"
            "第二条 服务费用\n"
            "1. API 调用费用：按实际用量计费，单价为 0.01 元/千 token\n"
            "2. 技术支持服务费：每月人民币 50,000 元（伍万元整）\n"
            "3. 合同总金额预估为人民币 120 万元/年\n\n"
            "第三条 合同期限\n"
            "本合同自 2025年4月1日 起生效，至 2026年3月31日 止，有效期一年。\n\n"
            "第四条 违约责任\n"
            "任何一方违反本合同约定的，应向守约方支付合同总金额 10% 的违约金。\n"
            "如违约金不足以弥补守约方损失的，违约方还应赔偿差额部分。\n\n"
            "第五条 争议解决\n"
            "因本合同引起的争议，双方应协商解决；协商不成的，提交北京仲裁委员会仲裁。"
        ),
        "expected_title_keywords": ["技术", "服务", "合同"],
        "expected_doc_type": "合同",
        "expected_keywords_any": ["技术服务", "API", "费用", "违约"],
        "expected_parties": ["智能科技", "数据服务", "张三", "李四"],
        "check_summary_quality": lambda s: len(s) >= 30 and len(s) <= 500,
    },
    {
        "name": "学术论文",
        "content": (
            "基于注意力机制的多模态情感分析方法研究\n\n"
            "摘要：本文提出了一种基于多头注意力机制的多模态情感分析框架 MSA-Former。"
            "该框架融合文本、语音和视觉三种模态信息，通过跨模态注意力模块捕获模态间的交互特征。"
            "在 CMU-MOSI 和 CMU-MOSEI 两个公开基准数据集上的实验结果表明，"
            "MSA-Former 在七分类准确率和 F1 分数上均优于现有的最优方法。"
            "消融实验证明跨模态注意力模块对最终性能有显著贡献。\n\n"
            "关键词：多模态情感分析；注意力机制；跨模态融合；Transformer\n\n"
            "1. 引言\n"
            "情感分析是自然语言处理领域的重要研究方向，旨在从文本中识别和提取主观情感信息。"
            "然而，人类在表达情感时往往同时使用语言、声音和面部表情等多种方式。"
            "因此，多模态情感分析（Multimodal Sentiment Analysis, MSA）应运而生，"
            "它综合分析来自不同模态的信息以更准确地判断情感极性和强度。\n\n"
            "2. 相关工作\n"
            "早期的多模态情感分析方法主要采用特征拼接或注意力加权等简单融合策略。"
            "Tsai 等人提出的 MulT 模型使用跨模态 Transformer 实现了模态间的直接交互。"
            "Hazarika 等人通过模态间和模态内的图神经网络建模模态关系。"
            "然而，这些方法在处理模态间语义对齐和时序同步方面仍有不足。\n\n"
            "3. 方法\n"
            "3.1 整体架构\n"
            "MSA-Former 由三个单模态编码器和一个跨模态融合模块组成。"
            "文本编码器基于 BERT-base，语音编码器使用 wav2vec 2.0，视觉编码器采用 ViT-B/16。"
            "跨模态融合模块包含三层跨模态注意力层，每层使用 8 个注意力头。\n\n"
            "3.2 跨模态注意力模块\n"
            "跨模态注意力模块接收来自两个不同模态的特征序列，"
            "使用一个模态的特征作为 Query，另一个模态的特征作为 Key 和 Value，"
            "计算跨模态注意力权重，实现信息在不同模态间的选择性传递。\n\n"
            "4. 实验\n"
            "4.1 数据集\n"
            "我们在两个公开数据集上进行了实验：\n"
            "- CMU-MOSI：包含 2,199 个视频片段，标注了情感强度分数（-3 到 +3）\n"
            "- CMU-MOSEI：包含 23,454 个视频片段，是目前最大的多模态情感分析数据集\n\n"
            "4.2 主要结果\n"
            "MSA-Former 在 CMU-MOSI 上的七分类准确率达到 42.8%，比之前的最佳结果提高了 1.5%。"
            "在 CMU-MOSEI 上的七分类准确率达到 52.3%，F1 分数达到 52.1%。\n\n"
            "5. 结论\n"
            "本文提出的 MSA-Former 框架通过跨模态注意力机制有效融合了多模态信息，"
            "在公开基准数据集上取得了最优性能。未来工作将探索更高效的多模态融合策略。"
        ),
        "expected_title_keywords": ["情感", "分析", "多模态", "注意力"],
        "expected_doc_type": "论文",
        "expected_keywords_any": ["情感分析", "多模态", "注意力", "Transformer", "跨模态"],
        "expected_parties": [],
        "check_summary_quality": lambda s: len(s) >= 30 and len(s) <= 500,
    },
]

# ============================================================
# OCR 测试用例（图片渲染）
# ============================================================

ZH_FONT_PATH = "/System/Library/Fonts/STHeiti Medium.ttc"

CHINESE_LONG_TEXT = {
    "title": "中文长文本",
    "content": (
        "深度学习是机器学习的一个重要分支，它通过构建多层神经网络来模拟人脑的信息处理方式。"
        "近年来，深度学习在计算机视觉、自然语言处理和语音识别等领域取得了突破性进展。"
        "卷积神经网络（CNN）在图像分类任务中表现出色，能够自动提取图像中的空间特征。"
        "循环神经网络（RNN）及其变体LSTM和GRU则特别适合处理序列数据，如文本和语音。"
        "Transformer架构的出现彻底改变了自然语言处理领域的格局，BERT和GPT等模型不断刷新各项任务的成绩。"
        "生成对抗网络（GAN）通过对抗训练的方式生成高质量的图像、音频和视频内容。"
        "强化学习与深度学习的结合使得智能体能够在复杂环境中做出最优决策，"
        "例如AlphaGo就是利用深度强化学习在围棋领域超越了人类顶尖棋手。"
        "联邦学习是一种分布式机器学习方法，它允许多个参与者在不共享原始数据的情况下共同训练模型，"
        "有效保护了用户隐私，同时在医疗健康和金融服务等领域展现了巨大的应用潜力。"
    ),
    "keywords": [
        "深度学习", "机器学习", "神经网络", "计算机视觉", "自然语言处理",
        "语音识别", "卷积神经网络", "CNN", "图像分类", "空间特征",
        "循环神经网络", "RNN", "LSTM", "GRU", "序列数据",
        "Transformer", "BERT", "GPT", "生成对抗网络", "GAN",
        "对抗训练", "强化学习", "AlphaGo", "围棋", "联邦学习",
        "分布式", "隐私", "医疗健康", "金融服务", "应用潜力",
    ],
}

MIXED_CN_EN_TEXT = {
    "title": "中英混排",
    "content": (
        "基于Transformer的多模态融合方法研究\n"
        "A Study on Transformer-based Multimodal Fusion Methods\n"
        "Abstract: Multimodal fusion aims to integrate information from different data sources "
        "such as text, image, and audio to improve downstream task performance. "
        "This paper proposes a novel cross-attention mechanism that achieves state-of-the-art results "
        "on multiple benchmark datasets. "
        "Our experimental results demonstrate significant improvements in both accuracy and efficiency.\n"
        "关键词：多模态融合；Transformer；交叉注意力；深度学习；特征对齐"
    ),
    "keywords": [
        "Transformer", "多模态融合", "Abstract", "Multimodal",
        "fusion", "integrate", "information", "data sources",
        "image", "audio", "downstream", "performance",
        "cross-attention", "mechanism", "state-of-the-art",
        "benchmark", "datasets", "accuracy", "efficiency",
        "关键词", "交叉注意力", "深度学习", "特征对齐", "融合方法",
    ],
}

STRUCTURED_TEXT = {
    "title": "结构化文本",
    "content": (
        "第二章 相关工作综述\n"
        "2.1 注意力机制的发展\n"
        "注意力机制最早由Bahdanau等人在机器翻译任务中提出，它允许模型动态地关注输入序列的不同部分。"
        "随后Vaswani等人提出了自注意力机制，将注意力计算简化为Query、Key和Value三个矩阵的运算。"
        "这一创新使得模型能够并行处理所有位置的信息，大幅提升了训练效率。\n"
        "2.2 预训练语言模型\n"
        "BERT通过掩码语言模型和下一句预测两个预训练任务，学习到了丰富的双向上下文表示。"
        "GPT系列则采用自回归的方式，在生成任务上展现了强大的能力。"
        "T5模型将所有NLP任务统一为文本到文本的格式，简化了模型设计和使用流程。\n"
        "2.3 多模态学习方法\n"
        "CLIP模型通过对比学习将图像和文本映射到共享的语义空间，实现了零样本图像分类。"
        "ViLBERT和LXMERT等模型则在视觉问答和图像描述等任务上取得了优异的表现。"
    ),
    "keywords": [
        "第二章", "相关工作", "2.1", "注意力机制", "Bahdanau",
        "机器翻译", "输入序列", "Vaswani", "自注意力", "Query",
        "Key", "Value", "矩阵", "并行处理", "训练效率",
        "2.2", "预训练", "语言模型", "BERT", "掩码",
        "双向", "上下文", "GPT", "自回归", "T5",
        "NLP", "2.3", "多模态", "CLIP", "对比学习",
        "语义空间", "零样本", "ViLBERT", "LXMERT", "视觉问答",
    ],
}


# ============================================================
# 工具函数
# ============================================================

MAX_RETRIES = 2  # 最多重试次数


def api_call(func, *args, **kwargs) -> CallResult:
    """统一 API 调用包装，带延迟和重试，返回结构化结果。"""
    for attempt in range(MAX_RETRIES + 1):
        t0 = time.time()
        try:
            result = func(*args, **kwargs)
            elapsed = time.time() - t0
            label = f"({elapsed:.1f}s)" if attempt == 0 else f"(重试{attempt} {elapsed:.1f}s)"
            print(f"    {label}", end="", flush=True)
            time.sleep(API_DELAY)
            return CallResult(success=True, response=result, elapsed=elapsed, retries=attempt)
        except Exception as e:
            elapsed = time.time() - t0
            if attempt < MAX_RETRIES:
                wait = 8 * (attempt + 1)
                print(f"    ({elapsed:.1f}s) WARN: {e}, 等待{wait}s重试...")
                time.sleep(wait)
            else:
                print(f"    ({elapsed:.1f}s) ERROR: {e}")
                return CallResult(success=False, elapsed=elapsed, retries=attempt, error=str(e))

    # 不应到达此处
    return CallResult(success=False, error="未知错误")


def _render_text_image(text: str, width: int = 800, font_size: int = 22) -> str:
    """将文本渲染为白色背景图片，返回 base64 编码。"""
    from PIL import Image, ImageDraw, ImageFont

    font = ImageFont.truetype(ZH_FONT_PATH, font_size)
    img_tmp = Image.new("RGB", (width, 100), "white")
    draw_tmp = ImageDraw.Draw(img_tmp)
    margin = 40
    line_spacing = 8

    paragraphs = text.split("\n")
    lines = []
    for para in paragraphs:
        if not para.strip():
            lines.append("")
            continue
        bbox = draw_tmp.textbbox((0, 0), para, font=font)
        text_w = bbox[2] - bbox[0]
        if text_w <= width - 2 * margin:
            lines.append(para)
        else:
            line = ""
            for ch in para:
                test = line + ch
                bbox = draw_tmp.textbbox((0, 0), test, font=font)
                if bbox[2] - bbox[0] > width - 2 * margin:
                    lines.append(line)
                    line = ch
                else:
                    line = test
            if line:
                lines.append(line)

    line_h = font_size + line_spacing
    height = 2 * margin + len(lines) * line_h + 40
    height = max(height, 200)

    img = Image.new("RGB", (width, height), "white")
    draw = ImageDraw.Draw(img)
    y = margin
    for line in lines:
        if line:
            draw.text((margin, y), line, fill="black", font=font)
        y += line_h

    buf = io.BytesIO()
    img.save(buf, format="PNG")
    return base64.b64encode(buf.getvalue()).decode("utf-8")


def generate_document_images():
    """生成 3 类 OCR 测试文档图片，保存为临时文件。"""
    import tempfile

    images = {}
    for key, doc in [
        ("ocr_chinese_text", CHINESE_LONG_TEXT),
        ("ocr_mixed_cn_en", MIXED_CN_EN_TEXT),
        ("ocr_structured", STRUCTURED_TEXT),
    ]:
        b64 = _render_text_image(doc["content"])
        # 保存为临时 PNG 文件
        tmp = tempfile.NamedTemporaryFile(suffix=".png", delete=False)
        tmp.write(base64.b64decode(b64))
        tmp.close()
        images[key] = (tmp.name, doc["keywords"], doc["title"])
    return images


# ============================================================
# 评分函数
# ============================================================

def score_summarize(summary: DocumentSummary, tc: dict) -> tuple[float, dict]:
    """评估单次文本总结质量，返回 (分数, 详情)。"""
    score_items = {}

    # 1. 标题关键词命中 (2分)
    title_hits = [kw for kw in tc["expected_title_keywords"] if kw in summary.title]
    title_score = min(len(title_hits) / max(len(tc["expected_title_keywords"]), 1), 1.0) * 2
    score_items["title"] = {"score": round(title_score, 1), "hits": title_hits}

    # 2. 文档类型准确 (2分)
    type_score = 2.0 if tc["expected_doc_type"] in summary.document_type else 0
    score_items["type"] = {"score": type_score, "actual": summary.document_type}

    # 3. 关键词覆盖 (2分)
    all_kw_text = " ".join(summary.keywords)
    kw_hits = [kw for kw in tc["expected_keywords_any"] if kw in all_kw_text]
    kw_score = min(len(kw_hits) / max(len(tc["expected_keywords_any"]), 1), 1.0) * 2
    score_items["keywords"] = {"score": round(kw_score, 1), "hits": kw_hits}

    # 4. 摘要质量（长度合理）(2分)
    quality_score = 2.0 if tc["check_summary_quality"](summary.summary) else 0
    score_items["quality"] = {"score": quality_score, "length": len(summary.summary)}

    # 5. JSON 解析成功 (2分)
    json_score = 2.0 if summary.title and summary.summary else 0
    score_items["json_valid"] = {"score": json_score}

    total = sum(v["score"] for v in score_items.values())
    return round(total, 1), score_items


def score_ocr(response: str, keywords: list[str]) -> tuple[float, dict]:
    """评估单次 OCR 质量，返回 (分数, 详情)。"""
    hits = [kw for kw in keywords if kw in response]
    hit_rate = len(hits) / len(keywords) if keywords else 0
    score = round(hit_rate * 10, 1)
    return score, {"score": score, "keywords_total": len(keywords), "keywords_hit": len(hits)}


def calc_speed_score(response_times: list[float]) -> float:
    """计算速度分 (满分 10)。"""
    if not response_times:
        return 0.0
    avg = sum(response_times) / len(response_times)
    return round(min(10, max(0, 10 * (30 - avg) / 27)), 1)


def calc_stability_stats(total_calls: int, success_count: int,
                         retry_success_count: int, fail_count: int) -> dict:
    """计算稳定性分 (满分 10)。"""
    success_rate = success_count / total_calls * 10 if total_calls > 0 else 0
    retry_penalty = retry_success_count * 1  # 每次重试成功扣 1 分
    fail_penalty = fail_count * 3  # 每次失败扣 3 分
    stability = max(0, success_rate - retry_penalty - fail_penalty)
    return {
        "success_rate": round(success_rate, 1),
        "retry_penalty": retry_penalty,
        "fail_penalty": fail_penalty,
        "stability_score": round(stability, 1),
    }


# ============================================================
# 文本总结基准测试（多轮）
# ============================================================

def run_summarize_benchmark(client, model, test_cases, num_rounds=NUM_ROUNDS):
    """对单个文本模型运行多轮摘要能力测试。"""
    all_results = []  # 每轮每用例的结果
    quality_scores = []
    response_times = []
    success_count = 0
    retry_success_count = 0
    fail_count = 0

    for round_idx in range(1, num_rounds + 1):
        print(f"\n  第 {round_idx}/{num_rounds} 轮:")
        round_results = []

        for tc in test_cases:
            print(f"    {tc['name']}...", end="", flush=True)
            cr = api_call(
                lambda c=tc["content"]: summarize(c, client=client, model=model)
            )

            if cr.success:
                if cr.retries == 0:
                    success_count += 1
                else:
                    retry_success_count += 1
                response_times.append(cr.elapsed)

                tc_score, details = score_summarize(cr.response, tc)
                quality_scores.append(tc_score)

                round_results.append({
                    "name": tc["name"],
                    "score": tc_score,
                    "details": details,
                    "elapsed": round(cr.elapsed, 1),
                    "retries": cr.retries,
                    "preview": {
                        "title": cr.response.title[:50],
                        "doc_type": cr.response.document_type,
                        "summary": cr.response.summary[:100],
                        "keywords": cr.response.keywords[:5],
                    },
                })
                print(f" {tc_score}/10")
            else:
                fail_count += 1
                round_results.append({
                    "name": tc["name"],
                    "score": 0,
                    "error": cr.error,
                    "elapsed": round(cr.elapsed, 1),
                    "retries": cr.retries,
                })
                print(f" 失败: {cr.error}")

        all_results.append({"round": round_idx, "results": round_results})

    # 统计
    total_calls = num_rounds * len(test_cases)
    avg_quality = round(sum(quality_scores) / max(len(quality_scores), 1), 1) if quality_scores else 0
    speed_score = calc_speed_score(response_times)
    stability_info = calc_stability_stats(total_calls, success_count, retry_success_count, fail_count)

    return {
        "rounds": all_results,
        "stats": {
            "total_calls": total_calls,
            "success_count": success_count,
            "retry_success_count": retry_success_count,
            "fail_count": fail_count,
            "quality_scores": quality_scores,
            "avg_quality": avg_quality,
            "response_times": [round(t, 1) for t in response_times],
            "avg_response_time": round(sum(response_times) / max(len(response_times), 1), 1) if response_times else None,
            "speed_score": speed_score,
            **stability_info,
        },
    }


# ============================================================
# OCR 基准测试（多轮）
# ============================================================

def run_ocr_benchmark(client, model, doc_images, num_rounds=NUM_ROUNDS):
    """对单个视觉模型运行多轮 OCR 测试。"""
    all_results = []
    quality_scores = []
    response_times = []
    success_count = 0
    retry_success_count = 0
    fail_count = 0

    ocr_prompt = (
        "请仔细识别并完整提取这张图片中的所有文字内容。"
        "要求：\n1. 保持原始排版格式\n2. 准确输出识别到的文字，不要遗漏\n"
        "3. 如果有表格，使用 Markdown 表格格式输出\n4. 只输出识别到的文字"
    )

    dim_labels = {
        "ocr_chinese_text": "中文长文本",
        "ocr_mixed_cn_en": "中英混排",
        "ocr_structured": "结构化文本",
    }

    for round_idx in range(1, num_rounds + 1):
        print(f"\n  第 {round_idx}/{num_rounds} 轮:")
        round_results = {}

        for idx, (key, (img_path, keywords, title)) in enumerate(doc_images.items(), 1):
            label = dim_labels.get(key, title)
            print(f"    [{idx}/3] {label}...", end="", flush=True)
            import base64 as _b64

            with open(img_path, "rb") as f:
                img_b64 = _b64.b64encode(f.read()).decode()
            data_uri = f"data:image/png;base64,{img_b64}"

            cr = api_call(
                lambda: vision_completion(
                    prompt=ocr_prompt,
                    image=data_uri,
                    client=client,
                    model=model,
                )
            )

            if cr.success:
                if cr.retries == 0:
                    success_count += 1
                else:
                    retry_success_count += 1
                response_times.append(cr.elapsed)

                tc_score, details = score_ocr(cr.response, keywords)
                quality_scores.append(tc_score)

                round_results[key] = {
                    **details,
                    "elapsed": round(cr.elapsed, 1),
                    "retries": cr.retries,
                    "preview": cr.response[:200],
                }
                print(f" {tc_score}")
            else:
                fail_count += 1
                round_results[key] = {"score": 0, "error": cr.error, "elapsed": round(cr.elapsed, 1), "retries": cr.retries}
                print(f" 失败: {cr.error}")

        all_results.append({"round": round_idx, "results": round_results})

    # 统计
    total_calls = num_rounds * len(doc_images)
    avg_quality = round(sum(quality_scores) / max(len(quality_scores), 1), 1) if quality_scores else 0
    speed_score = calc_speed_score(response_times)
    stability_info = calc_stability_stats(total_calls, success_count, retry_success_count, fail_count)

    return {
        "rounds": all_results,
        "stats": {
            "total_calls": total_calls,
            "success_count": success_count,
            "retry_success_count": retry_success_count,
            "fail_count": fail_count,
            "quality_scores": quality_scores,
            "avg_quality": avg_quality,
            "response_times": [round(t, 1) for t in response_times],
            "avg_response_time": round(sum(response_times) / max(len(response_times), 1), 1) if response_times else None,
            "speed_score": speed_score,
            **stability_info,
        },
    }


# ============================================================
# 报告生成
# ============================================================

def generate_report(summarize_results: dict, ocr_results: dict) -> str:
    """生成 Markdown 报告，含三维度评分和综合排名。"""
    now = time.strftime("%Y-%m-%d %H:%M:%S")
    lines = [
        "# 文本总结 & OCR 多轮综合基准测试报告\n",
        f"测试时间: {now}",
        f"测试轮数: 每模型 {NUM_ROUNDS} 轮",
        f"API_DELAY: {API_DELAY}s",
        f"评分公式: 综合 = 质量×40% + 速度×30% + 稳定性×30%\n",
    ]

    # ---- 辅助：计算综合分 ----
    def composite(stats):
        q = stats["avg_quality"]
        s = stats["speed_score"]
        st = stats["stability_score"]
        return round(q * 0.4 + s * 0.3 + st * 0.3, 1)

    # ========================================
    # 一、文本总结
    # ========================================
    lines.append("## 一、文本总结能力测试\n")
    lines.append(f"测试模型: {', '.join(f'`{m}`' for m in TEXT_MODELS)}")
    lines.append(f"每轮测试: {len(SUMMARIZE_TEST_CASES)} 个用例 × {NUM_ROUNDS} 轮 = {len(SUMMARIZE_TEST_CASES) * NUM_ROUNDS} 次调用\n")

    # 综合评分表
    lines.append("### 综合评分表\n")
    lines.append("| 模型 | 质量(40%) | 速度(30%) | 稳定性(30%) | **综合** |")
    lines.append("|------|----------|----------|------------|---------|")
    sum_ranked = sorted(summarize_results.items(), key=lambda x: composite(x[1]["stats"]), reverse=True)
    for model, data in sum_ranked:
        s = data["stats"]
        c = composite(s)
        lines.append(f"| `{model}` | {s['avg_quality']} | {s['speed_score']} | {s['stability_score']} | **{c}** |")
    lines.append("")

    # 评分维度说明
    lines.append("<details><summary>评分维度说明</summary>\n")
    lines.append("- **质量分**: 标题关键词(2) + 文档类型(2) + 关键词覆盖(2) + 摘要质量(2) + JSON结构(2) = 满分10")
    lines.append("- **速度分**: `max(0, 10×(30-平均秒数)/27)`，≤3s=10分，≥30s=0分")
    lines.append("- **稳定性分**: `max(0, 成功率×10 - 重试次数×1 - 失败次数×3)`\n")
    lines.append("</details>\n")

    # 每轮详细结果
    lines.append("### 按轮次详细结果\n")
    for model, data in summarize_results.items():
        s = data["stats"]
        lines.append(f"#### `{model}`\n")
        lines.append(f"- 成功: {s['success_count']} / {s['total_calls']}，重试成功: {s['retry_success_count']}，失败: {s['fail_count']}")
        if s["avg_response_time"] is not None:
            lines.append(f"- 平均响应: {s['avg_response_time']}s")
        lines.append("")

        for round_data in data["rounds"]:
            lines.append(f"**第 {round_data['round']} 轮:**\n")
            for r in round_data["results"]:
                if "error" in r:
                    lines.append(f"- **{r['name']}**: 失败 — {r['error']}")
                else:
                    lines.append(f"- **{r['name']}**: {r['score']}/10 ({r['elapsed']}s)")
                    d = r["details"]
                    lines.append(f"  - 标题: {r['preview']['title']} (命中: {d['title']['hits']})")
                    lines.append(f"  - 类型: {r['preview']['doc_type']}")
                    lines.append(f"  - 关键词: {r['preview']['keywords']}")
                    lines.append(f"  - 摘要({d['quality'].get('length', '?')}字): {r['preview']['summary']}...")
            lines.append("")

    # 文本排名
    lines.append("### 文本总结综合排名\n")
    for i, (model, data) in enumerate(sum_ranked, 1):
        s = data["stats"]
        c = composite(s)
        medal = {1: "🥇", 2: "🥈", 3: "🥉"}.get(i, f"{i}.")
        lines.append(f"{medal} `{model}` — 综合 {c} (质量{s['avg_quality']} 速度{s['speed_score']} 稳定性{s['stability_score']})")
    lines.append("")

    # ========================================
    # 二、OCR
    # ========================================
    lines.append("## 二、OCR 文字识别能力测试\n")
    lines.append(f"测试模型: {', '.join(f'`{m}`' for m in VISION_MODELS)}")
    lines.append(f"每轮测试: 3 个场景 × {NUM_ROUNDS} 轮 = {3 * NUM_ROUNDS} 次调用\n")

    dim_labels = {
        "ocr_chinese_text": "中文长文本",
        "ocr_mixed_cn_en": "中英混排",
        "ocr_structured": "结构化文本",
    }

    # 综合评分表
    lines.append("### 综合评分表\n")
    lines.append("| 模型 | 质量(40%) | 速度(30%) | 稳定性(30%) | **综合** |")
    lines.append("|------|----------|----------|------------|---------|")
    ocr_ranked = sorted(ocr_results.items(), key=lambda x: composite(x[1]["stats"]), reverse=True)
    for model, data in ocr_ranked:
        s = data["stats"]
        c = composite(s)
        lines.append(f"| `{model}` | {s['avg_quality']} | {s['speed_score']} | {s['stability_score']} | **{c}** |")
    lines.append("")

    # 按轮次详细结果
    lines.append("### 按轮次详细结果\n")
    for model, data in ocr_results.items():
        s = data["stats"]
        lines.append(f"#### `{model}`\n")
        lines.append(f"- 成功: {s['success_count']} / {s['total_calls']}，重试成功: {s['retry_success_count']}，失败: {s['fail_count']}")
        if s["avg_response_time"] is not None:
            lines.append(f"- 平均响应: {s['avg_response_time']}s")
        lines.append("")

        for round_data in data["rounds"]:
            lines.append(f"**第 {round_data['round']} 轮:**\n")
            for key, d in round_data["results"].items():
                label = dim_labels.get(key, key)
                if "error" in d:
                    lines.append(f"- **{label}**: 失败 — {d['error']}")
                else:
                    lines.append(f"- **{label}**: {d['score']}/10 (关键词 {d['keywords_hit']}/{d['keywords_total']}, {d['elapsed']}s)")
            lines.append("")

    # OCR 排名
    lines.append("### OCR 综合排名\n")
    for i, (model, data) in enumerate(ocr_ranked, 1):
        s = data["stats"]
        c = composite(s)
        medal = {1: "🥇", 2: "🥈", 3: "🥉"}.get(i, f"{i}.")
        lines.append(f"{medal} `{model}` — 综合 {c} (质量{s['avg_quality']} 速度{s['speed_score']} 稳定性{s['stability_score']})")
    lines.append("")

    # ---- 总结 ----
    lines.append("## 三、总结\n")
    best_text = sum_ranked[0]
    best_ocr = ocr_ranked[0]
    lines.append(f"**最佳文本总结模型**: `{best_text[0]}` (综合 {composite(best_text[1]['stats'])})")
    lines.append(f"**最佳 OCR 模型**: `{best_ocr[0]}` (综合 {composite(best_ocr[1]['stats'])})\n")

    lines.append("---")
    lines.append("")
    lines.append("*本报告由 `scripts/benchmark_summarize_ocr.py` 自动生成。*")

    return "\n".join(lines)


# ============================================================
# 主流程
# ============================================================

def main():
    print("=" * 60)
    print("文本总结 & OCR 多轮综合基准测试")
    print(f"每模型 {NUM_ROUNDS} 轮 | 评分: 质量×40% + 速度×30% + 稳定性×30%")
    print(f"API_DELAY = {API_DELAY}s")
    print("=" * 60)

    config = GLMConfig.from_env()
    config.max_retries = 0  # 禁用 SDK 内部重试，由脚本自行控制
    config.timeout = 120
    client = GLMClient(config=config)

    # ---- 文本总结 ----
    print("\n[第一部分] 文本总结能力测试")
    summarize_results = {}
    for model in TEXT_MODELS:
        print(f"\n=== {model} ===")
        if model != TEXT_MODELS[0]:
            print(f"  等待模型冷却({MODEL_COOLDOWN:.0f}s)...", end="", flush=True)
            time.sleep(MODEL_COOLDOWN)
            print(" ok")
        data = run_summarize_benchmark(client, model, SUMMARIZE_TEST_CASES)
        s = data["stats"]
        print(f"  >> 质量: {s['avg_quality']} 速度: {s['speed_score']} 稳定性: {s['stability_score']}")
        summarize_results[model] = data

    # ---- OCR ----
    print(f"\n[第二部分] OCR 文字识别能力测试")
    print(f"  等待两部分冷却({SECTION_COOLDOWN:.0f}s)...", end="", flush=True)
    time.sleep(SECTION_COOLDOWN)
    print(" ok")
    print("  生成测试文档图片...")
    doc_images = generate_document_images()
    print(f"  已生成 {len(doc_images)} 张测试图片")

    ocr_results = {}
    for model in VISION_MODELS:
        print(f"\n=== {model} ===")
        if model != VISION_MODELS[0]:
            print(f"  等待模型冷却({MODEL_COOLDOWN:.0f}s)...", end="", flush=True)
            time.sleep(MODEL_COOLDOWN)
            print(" ok")
        data = run_ocr_benchmark(client, model, doc_images)
        s = data["stats"]
        print(f"  >> 质量: {s['avg_quality']} 速度: {s['speed_score']} 稳定性: {s['stability_score']}")
        ocr_results[model] = data

    # 清理临时图片文件
    for key, (path, _, _) in doc_images.items():
        try:
            Path(path).unlink()
        except Exception:
            pass

    # ---- 生成报告 ----
    report = generate_report(summarize_results, ocr_results)

    report_path = Path(__file__).parent.parent / "docs" / "benchmark_summarize_ocr.md"
    report_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.write_text(report, encoding="utf-8")
    print(f"\n报告已保存到: {report_path}")

    # 序列化原始数据（CallResult / dataclass 需转 dict）
    raw = {
        "summarize": summarize_results,
        "ocr": ocr_results,
    }
    data_path = report_path.with_suffix(".json")
    data_path.write_text(json.dumps(raw, indent=2, ensure_ascii=False, default=str), encoding="utf-8")
    print(f"原始数据: {data_path}")


if __name__ == "__main__":
    main()
