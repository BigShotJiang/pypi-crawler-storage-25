"""免费模型基准测试脚本。

针对 GLM 免费文本模型进行多维度评测，生成评分报告。
用法: uv run python scripts/benchmark_models.py
"""

import json
import os
import sys
import time
from pathlib import Path

# 添加项目根目录到路径
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from dotenv import load_dotenv
load_dotenv()

from glm_client import GLMClient, chat_completion

# 测试的免费文本模型
TEST_MODELS = ["glm-4.7-flash", "glm-4-flash"]

# 每个测试运行次数（取中位数）
RUN_COUNT = 3

# 测试维度权重
WEIGHTS = {
    "speed": 0.20,
    "chinese_quality": 0.25,
    "code_generation": 0.20,
    "context_understanding": 0.15,
    "instruction_following": 0.20,
}

# ============================================================
# 测试用例
# ============================================================

SPEED_PROMPT = "请用三句话介绍人工智能的发展历史。"

CHINESE_QUALITY_PROMPTS = [
    "请写一首关于春天的七言绝句。",
    "请解释相对论的核心概念，用通俗易懂的语言。",
    "请总结《三国演义》的主要故事情节，不超过200字。",
    "请写一段关于人工智能伦理的议论文，300字左右。",
    "请用比喻的方式解释什么是量子纠缠。",
]

CODE_GENERATION_PROMPTS = [
    "用Python实现快速排序算法，包含测试用例。",
    "写一个JavaScript函数，实现数组的去重，要求使用Set。",
]

CONTEXT_PROMPTS = [
    {"role": "user", "content": "我叫小明，今年25岁，我在北京工作。"},
    {"role": "assistant", "content": "你好小明！很高兴认识你。你在北京工作，那是个很棒的城市。有什么我可以帮助你的吗？"},
    {"role": "user", "content": "我的爱好是打篮球和看电影。"},
    {"role": "assistant", "content": "打篮球和看电影都是很棒的爱好！打篮球可以锻炼身体，看电影可以放松心情。你最喜欢看什么类型的电影呢？"},
    {"role": "user", "content": "请总结一下我前面提到的个人信息，包括我的名字、年龄、工作和爱好。"},
]

INSTRUCTION_PROMPTS = [
    ("用恰好50个字回答：什么是机器学习？", "length_50"),
    ("列出恰好5个学习编程的理由。", "count_5"),
    ("用JSON格式输出两个城市的基本信息，包含name和population字段。", "json_format"),
    ("只回答是或否：地球是太阳系中最大的行星吗？", "yes_no"),
    ("用三个要点总结以下内容，每个要点不超过20字：人工智能是计算机科学的一个分支，它试图理解智能的实质，并生产出一种新的能以人类智能相似的方式做出反应的智能机器。", "three_points"),
]


def run_speed_test(client: GLMClient, model: str) -> dict:
    """测试响应速度。"""
    times = []

    for i in range(RUN_COUNT):
        start = time.time()
        try:
            response = chat_completion(
                prompt=SPEED_PROMPT,
                client=client,
                model=model,
                stream=False,
            )
            elapsed = time.time() - start
            times.append(elapsed)
        except Exception as e:
            print(f"  速度测试第 {i+1} 次失败: {e}")
            times.append(float("inf"))

    times.sort()
    median_time = times[len(times) // 2]

    return {
        "times": times,
        "median_seconds": round(median_time, 2),
        "score": max(0, min(10, 10 - median_time)),  # 越快越好，10秒内满分
    }


def run_chinese_quality_test(client: GLMClient, model: str) -> dict:
    """测试中文质量。"""
    results = []

    for prompt in CHINESE_QUALITY_PROMPTS:
        try:
            response = chat_completion(
                prompt=prompt,
                client=client,
                model=model,
                stream=False,
            )
            results.append({
                "prompt": prompt[:30],
                "response_length": len(response),
                "response_preview": response[:100],
            })
        except Exception as e:
            results.append({"prompt": prompt[:30], "error": str(e)})

    return {
        "results": results,
        "note": "质量需要人工评分，此处仅记录响应信息",
        "score": 7.0,  # 默认分数，实际需人工评定
    }


def run_code_generation_test(client: GLMClient, model: str) -> dict:
    """测试代码生成能力。"""
    results = []

    for prompt in CODE_GENERATION_PROMPTS:
        try:
            response = chat_completion(
                prompt=prompt,
                client=client,
                model=model,
                stream=False,
            )
            has_code_block = "```" in response or "def " in response or "function " in response
            results.append({
                "prompt": prompt[:30],
                "has_code": has_code_block,
                "response_length": len(response),
            })
        except Exception as e:
            results.append({"prompt": prompt[:30], "error": str(e)})

    code_score = sum(1 for r in results if r.get("has_code")) / max(len(results), 1) * 10
    return {
        "results": results,
        "score": round(code_score, 1),
    }


def run_context_test(client: GLMClient, model: str) -> dict:
    """测试上下文理解。"""
    try:
        response = chat_completion(
            prompt="请回答上面的问题。",
            client=client,
            model=model,
            stream=False,
            history=CONTEXT_PROMPTS[:-1],
        )

        # 检查是否包含关键信息
        checks = {
            "名字(小明)": "小明" in response,
            "年龄(25)": "25" in response,
            "地点(北京)": "北京" in response,
            "爱好(篮球/电影)": "篮球" in response or "电影" in response,
        }

        accuracy = sum(checks.values()) / len(checks) * 10
        return {
            "response_preview": response[:200],
            "checks": checks,
            "score": round(accuracy, 1),
        }
    except Exception as e:
        return {"error": str(e), "score": 0}


def run_instruction_test(client: GLMClient, model: str) -> dict:
    """测试指令遵循。"""
    results = []

    for prompt, check_type in INSTRUCTION_PROMPTS:
        try:
            response = chat_completion(
                prompt=prompt,
                client=client,
                model=model,
                stream=False,
            )

            passed = False
            if check_type == "length_50":
                # 宽容检查：30-70字之间算通过
                char_count = len(response.replace(" ", "").replace("\n", ""))
                passed = 30 <= char_count <= 70
            elif check_type == "count_5":
                passed = response.count("\n") >= 4 or response.count(".") >= 5 or response.count("、") >= 4
            elif check_type == "json_format":
                passed = "{" in response and "}" in response and ("name" in response or "population" in response)
            elif check_type == "yes_no":
                lower = response.lower().strip()
                passed = lower.startswith("是") or lower.startswith("否") or lower.startswith("yes") or lower.startswith("no")
            elif check_type == "three_points":
                passed = response.count("\n") >= 2 or response.count("1") >= 1

            results.append({
                "type": check_type,
                "passed": passed,
                "response_preview": response[:80],
            })
        except Exception as e:
            results.append({"type": check_type, "error": str(e), "passed": False})

    pass_rate = sum(1 for r in results if r.get("passed")) / max(len(results), 1) * 10
    return {
        "results": results,
        "score": round(pass_rate, 1),
    }


def run_benchmark() -> dict:
    """运行完整基准测试。"""
    client = GLMClient()
    all_results = {}

    for model in TEST_MODELS:
        print(f"\n{'='*60}")
        print(f"测试模型: {model}")
        print(f"{'='*60}")

        model_results = {}

        print("\n[1/5] 速度测试...")
        model_results["speed"] = run_speed_test(client, model)
        print(f"  中位数耗时: {model_results['speed']['median_seconds']}s")

        print("[2/5] 中文质量测试...")
        model_results["chinese_quality"] = run_chinese_quality_test(client, model)

        print("[3/5] 代码生成测试...")
        model_results["code_generation"] = run_code_generation_test(client, model)
        print(f"  代码生成评分: {model_results['code_generation']['score']}")

        print("[4/5] 上下文理解测试...")
        model_results["context_understanding"] = run_context_test(client, model)
        print(f"  引用准确率: {model_results['context_understanding']['score']}")

        print("[5/5] 指令遵循测试...")
        model_results["instruction_following"] = run_instruction_test(client, model)
        print(f"  指令遵循率: {model_results['instruction_following']['score']}")

        # 计算加权总分
        total_score = sum(
            model_results[dim]["score"] * WEIGHTS[dim]
            for dim in WEIGHTS
        )
        model_results["total_score"] = round(total_score, 2)
        print(f"\n  总分: {model_results['total_score']}/10")

        all_results[model] = model_results

    return all_results


def generate_report(results: dict) -> str:
    """生成 Markdown 格式的报告。"""
    lines = [
        "# GLM 免费模型基准测试报告\n",
        f"测试时间: {time.strftime('%Y-%m-%d %H:%M:%S')}\n",
        "## 测试模型\n",
    ]
    for model in results:
        lines.append(f"- `{model}`")
    lines.append("")

    lines.append("## 测试维度与权重\n")
    lines.append("| 维度 | 权重 | 说明 |")
    lines.append("|------|------|------|")
    lines.append("| 响应速度 | 20% | 中位数响应时间 |")
    lines.append("| 中文质量 | 25% | 多样化中文生成质量（需人工评分） |")
    lines.append("| 代码生成 | 20% | 代码正确性和完整性 |")
    lines.append("| 上下文理解 | 15% | 多轮对话引用准确性 |")
    lines.append("| 指令遵循 | 20% | 约束条件遵守率 |")
    lines.append("")

    # 评分汇总表
    lines.append("## 评分汇总\n")
    lines.append("| 模型 | 速度 | 中文质量 | 代码生成 | 上下文理解 | 指令遵循 | **总分** |")
    lines.append("|------|------|---------|---------|-----------|---------|---------|")

    for model, data in results.items():
        scores = [
            str(data["speed"]["score"]),
            str(data["chinese_quality"]["score"]),
            str(data["code_generation"]["score"]),
            str(data["context_understanding"]["score"]),
            str(data["instruction_following"]["score"]),
            f"**{data['total_score']}**",
        ]
        lines.append(f"| `{model}` | {' | '.join(scores)} |")

    lines.append("")

    # 详细结果
    lines.append("## 详细结果\n")

    for model, data in results.items():
        lines.append(f"### {model}\n")

        # 速度
        speed = data["speed"]
        lines.append(f"**响应速度**: 中位数 {speed['median_seconds']}s")
        lines.append(f"- 各次耗时: {', '.join(f'{t:.2f}s' for t in speed['times'] if t != float('inf'))}")
        lines.append("")

        # 代码生成
        code = data["code_generation"]
        lines.append(f"**代码生成**: {code['score']}/10")
        for r in code["results"]:
            status = "✓" if r.get("has_code") else "✗"
            lines.append(f"- {status} {r.get('prompt', '')[:30]}")
        lines.append("")

        # 上下文理解
        ctx = data["context_understanding"]
        lines.append(f"**上下文理解**: {ctx['score']}/10")
        if "checks" in ctx:
            for key, val in ctx["checks"].items():
                status = "✓" if val else "✗"
                lines.append(f"- {status} {key}")
        lines.append("")

        # 指令遵循
        inst = data["instruction_following"]
        lines.append(f"**指令遵循**: {inst['score']}/10")
        for r in inst["results"]:
            status = "✓" if r.get("passed") else "✗"
            lines.append(f"- {status} {r['type']}: {r.get('response_preview', '')[:50]}")
        lines.append("")

    # 推荐结论
    lines.append("## 推荐\n")

    # 按总分排序
    ranked = sorted(results.items(), key=lambda x: x[1]["total_score"], reverse=True)
    best = ranked[0]
    lines.append(f"**默认推荐模型**: `{best[0]}`（总分 {best[1]['total_score']}）\n")

    for i, (model, data) in enumerate(ranked):
        lines.append(f"{i+1}. `{model}` — 总分 {data['total_score']}/10")

    lines.append("")
    lines.append("---")
    lines.append("")
    lines.append("*本报告由 `scripts/benchmark_models.py` 自动生成。*")

    return "\n".join(lines)


def main():
    print("GLM 免费模型基准测试")
    print("=" * 60)

    results = run_benchmark()
    report = generate_report(results)

    # 保存报告
    report_path = Path(__file__).parent.parent / "docs" / "benchmark_results.md"
    report_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.write_text(report, encoding="utf-8")

    print(f"\n报告已保存到: {report_path}")

    # 同时保存原始数据
    data_path = report_path.with_suffix(".json")
    # 移除不可序列化的数据
    clean_results = json.loads(json.dumps(results, default=str))
    data_path.write_text(json.dumps(clean_results, indent=2, ensure_ascii=False), encoding="utf-8")


if __name__ == "__main__":
    main()
