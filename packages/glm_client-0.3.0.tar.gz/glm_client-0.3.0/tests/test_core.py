"""GLM Client 核心功能测试。"""

import os
from pathlib import Path
from unittest.mock import Mock, MagicMock, patch

import pytest
from pytest_mock import MockerFixture

# 在导入客户端之前设置测试 API Key
os.environ["ZAI_API_KEY"] = "test_api_key_123456789"
os.environ["ZHIPUAI_API_KEY"] = "test_api_key_123456789"


@pytest.fixture
def mock_client():
    """创建 mock GLM 客户端。"""
    from glm_client.client import GLMClient
    return GLMClient()


@pytest.fixture
def mock_chat_response():
    """创建 mock 聊天响应。"""
    mock_response = Mock()
    mock_choice = Mock()
    mock_message = Mock()
    mock_message.content = "你好！这是一个测试响应。"
    mock_choice.message = mock_message
    mock_response.choices = [mock_choice]
    return mock_response


@pytest.fixture
def mock_stream_chunks():
    """创建 mock 流式响应块。"""
    chunks = ["你好", "！", "这是", "一个", "测试", "响应", "。"]
    mock_chunks = []
    for text in chunks:
        chunk = Mock()
        delta = Mock()
        delta.content = text
        choice = Mock()
        choice.delta = delta
        chunk.choices = [choice]
        mock_chunks.append(chunk)
    return mock_chunks


@pytest.fixture
def mock_image_response():
    """创建 mock 图像生成响应。"""
    mock_response = Mock()
    mock_data = Mock()
    mock_data.url = "https://example.com/generated_image.png"
    mock_response.data = [mock_data]
    return mock_response


@pytest.fixture
def mock_embedding_response():
    """创建 mock 嵌入响应。"""
    mock_response = Mock()
    mock_data = Mock()
    mock_data.embedding = [0.1, 0.2, 0.3, 0.4, 0.5]
    mock_data.index = 0
    mock_response.data = [mock_data]
    return mock_response


@pytest.fixture
def mock_video_response():
    """创建 mock 视频生成响应。"""
    mock_response = Mock()
    mock_response.id = "test_task_id"
    mock_result = Mock()
    mock_result.url = "https://example.com/video.mp4"
    mock_response.video_result = [mock_result]
    return mock_response


@pytest.fixture
def mock_asr_response():
    """创建 mock ASR 响应。"""
    mock_response = Mock()
    mock_response.text = "这是识别出的文本。"
    return mock_response


class TestGLMClient:
    """测试 GLMClient 核心功能。"""

    def test_client_initialization(self, mock_client):
        """测试客户端初始化。"""
        assert mock_client.config.api_key == "test_api_key_123456789"
        assert mock_client._client is None

    def test_sdk_name(self, mock_client):
        """测试 SDK 名称可用。"""
        from glm_client.client import _SDK_NAME
        assert _SDK_NAME in ("zai-sdk", "zhipuai")

    def test_client_property_creates_sdk_client(self, mock_client, mocker):
        """测试访问 client 属性创建 SDK 客户端。"""
        from glm_client.client import _SDKClient
        mock_sdk = mocker.patch("glm_client.client._SDKClient")
        mock_instance = Mock()
        mock_sdk.return_value = mock_instance

        _ = mock_client.client

        mock_sdk.assert_called_once_with(api_key="test_api_key_123456789")
        assert mock_client._client == mock_instance

    def test_video_generation_method(self, mock_client, mocker):
        """测试视频生成方法。"""
        mock_response = Mock()
        mocker.patch.object(mock_client, "_make_request_with_retry", return_value=mock_response)

        result = mock_client.video_generation(model="cogvideox-2", prompt="test")
        assert result == mock_response

    def test_create_embedding_method(self, mock_client, mocker):
        """测试嵌入方法。"""
        mock_response = Mock()
        mocker.patch.object(mock_client, "_make_request_with_retry", return_value=mock_response)

        result = mock_client.create_embedding(model="embedding-3", input=["test"])
        assert result == mock_response

    def test_audio_transcription_method(self, mock_client, mocker):
        """测试 ASR 方法。"""
        mock_response = Mock()
        mocker.patch.object(mock_client, "_make_request_with_retry", return_value=mock_response)

        result = mock_client.audio_transcription(model="glm-asr", file="test.wav")
        assert result == mock_response

    def test_context_manager(self):
        """测试上下文管理器。"""
        from glm_client.client import GLMClient

        with GLMClient() as client:
            assert client.config.api_key == "test_api_key_123456789"
        assert client._client is None


class TestTextGeneration:
    """测试文本生成功能。"""

    def test_create_messages(self):
        """测试消息创建。"""
        from glm_client.models.text import create_messages

        messages = create_messages("你好")
        assert len(messages) == 1
        assert messages[0]["role"] == "user"

        messages = create_messages("你好", system="你是一个助手")
        assert len(messages) == 2
        assert messages[0]["role"] == "system"

        history = [{"role": "user", "content": "你好"}, {"role": "assistant", "content": "你好！"}]
        messages = create_messages("今天天气怎样？", history=history)
        assert len(messages) == 3

    def test_chat_completion_non_streaming(self, mock_client, mock_chat_response, mocker):
        """测试非流式聊天补全。"""
        from glm_client.models.text import chat_completion

        mocker.patch.object(mock_client, "_make_request_with_retry", return_value=mock_chat_response)

        response = chat_completion("你好", client=mock_client, stream=False)
        assert response == "你好！这是一个测试响应。"

    def test_chat_completion_streaming(self, mock_client, mock_stream_chunks, mocker):
        """测试流式聊天补全。"""
        from glm_client.models.text import chat_completion

        mocker.patch.object(mock_client, "_make_request_with_retry", return_value=iter(mock_stream_chunks))

        response = chat_completion("你好", client=mock_client, stream=True)
        result = "".join(response)
        assert result == "你好！这是一个测试响应。"

    def test_chat_completion_with_thinking(self, mock_client, mock_chat_response, mocker):
        """测试思考模式参数。"""
        from glm_client.models.text import chat_completion

        mocker.patch.object(mock_client, "_make_request_with_retry", return_value=mock_chat_response)

        chat_completion("解方程", client=mock_client, stream=False, thinking=True)
        call_args = mock_client._make_request_with_retry.call_args
        assert call_args is not None

    def test_chat_completion_with_web_search(self, mock_client, mock_chat_response, mocker):
        """测试联网搜索参数。"""
        from glm_client.models.text import chat_completion

        mocker.patch.object(mock_client, "_make_request_with_retry", return_value=mock_chat_response)

        chat_completion("最新新闻", client=mock_client, stream=False, web_search=True)
        call_args = mock_client._make_request_with_retry.call_args
        assert call_args is not None


class TestVision:
    """测试视觉理解功能。"""

    def test_create_vision_messages_with_url(self):
        """测试 URL 图片消息创建。"""
        from glm_client.models.vision import create_vision_messages

        messages = create_vision_messages(
            prompt="这是什么？",
            image="https://example.com/image.jpg",
        )

        assert len(messages) == 1
        assert messages[0]["role"] == "user"
        assert isinstance(messages[0]["content"], list)

    def test_create_vision_messages_with_system(self):
        """测试带系统消息的视觉消息创建。"""
        from glm_client.models.vision import create_vision_messages

        messages = create_vision_messages(
            prompt="描述图片",
            image="https://example.com/image.jpg",
            system="你是图片分析专家",
        )

        assert len(messages) == 2
        assert messages[0]["role"] == "system"


class TestImageGeneration:
    """测试图像生成功能。"""

    def test_generate_image(self, mock_client, mock_image_response, mocker):
        """测试图像生成。"""
        from glm_client.models.image import generate_image

        mocker.patch.object(mock_client, "_make_request_with_retry", return_value=mock_image_response)

        urls = generate_image("一只猫", client=mock_client)
        assert len(urls) == 1
        assert urls[0] == "https://example.com/generated_image.png"


class TestVideoGeneration:
    """测试视频生成功能。"""

    def test_generate_video(self, mock_client, mock_video_response, mocker):
        """测试视频生成。"""
        from glm_client.models.video import generate_video

        mocker.patch.object(mock_client, "video_generation", return_value=mock_video_response)

        url = generate_video("一只猫在玩球", client=mock_client)
        assert url == "https://example.com/video.mp4"

    def test_check_video_status(self, mock_client, mock_video_response, mocker):
        """测试视频状态查询。"""
        from glm_client.models.video import check_video_status

        mocker.patch.object(mock_client, "retrieve_video_result", return_value=mock_video_response)

        status = check_video_status("test_task_id", client=mock_client)
        assert status["status"] == "completed"


class TestEmbedding:
    """测试文本嵌入功能。"""

    def test_create_embedding(self, mock_client, mock_embedding_response, mocker):
        """测试单文本嵌入。"""
        from glm_client.models.embedding import create_embedding

        mocker.patch.object(mock_client, "create_embedding", return_value=mock_embedding_response)

        vector = create_embedding("人工智能", client=mock_client)
        assert len(vector) == 5

    def test_compute_similarity(self, mock_client, mocker):
        """测试相似度计算。"""
        from glm_client.models.embedding import _cosine_similarity

        # 相同向量
        assert _cosine_similarity([1.0, 0.0], [1.0, 0.0]) == 1.0
        # 正交向量
        assert abs(_cosine_similarity([1.0, 0.0], [0.0, 1.0])) < 0.001
        # 零向量
        assert _cosine_similarity([0.0, 0.0], [1.0, 0.0]) == 0.0


class TestASR:
    """测试语音识别功能。"""

    def test_transcribe_audio_file_not_found(self, mock_client):
        """测试文件不存在时的错误。"""
        from glm_client.models.asr import transcribe_audio

        with pytest.raises(FileNotFoundError):
            transcribe_audio("nonexistent.wav", client=mock_client)


class TestConfig:
    """测试配置功能。"""

    def test_get_api_key(self):
        """测试获取 API Key。"""
        from glm_client.config import get_api_key
        assert get_api_key() == "test_api_key_123456789"

    def test_get_api_key_missing(self):
        """测试 API Key 缺失。"""
        from glm_client.config import get_api_key

        original_zai = os.environ.pop("ZAI_API_KEY", None)
        original_zhipu = os.environ.pop("ZHIPUAI_API_KEY", None)

        try:
            with pytest.raises(ValueError, match="未设置 API Key"):
                get_api_key()
        finally:
            if original_zai:
                os.environ["ZAI_API_KEY"] = original_zai
            if original_zhipu:
                os.environ["ZHIPUAI_API_KEY"] = original_zhipu

    def test_validate_model(self):
        """测试模型验证。"""
        from glm_client.config import validate_model

        assert validate_model("glm-4.7-flash", "text") is True
        assert validate_model("glm-4-flash", "text") is True
        assert validate_model("unknown-model", "text") is False
        assert validate_model("glm-4.6v-flash", "vision") is True
        assert validate_model("cogview-3-flash", "image") is True
        assert validate_model("cogvideox-2", "video") is True
        assert validate_model("embedding-3", "embedding") is True
        assert validate_model("glm-asr", "asr") is True

    def test_is_free_model(self):
        """测试免费模型判断。"""
        from glm_client.config import is_free_model

        assert is_free_model("glm-4.7-flash", "text") is True
        assert is_free_model("glm-4-flash", "text") is True
        assert is_free_model("glm-5.1", "text") is False
        assert is_free_model("glm-4.6v-flash", "vision") is True

    def test_default_models(self):
        """测试默认模型配置。"""
        from glm_client.config import DEFAULT_MODELS

        assert "text" in DEFAULT_MODELS
        assert "vision" in DEFAULT_MODELS
        assert "image" in DEFAULT_MODELS
        assert "tts" in DEFAULT_MODELS
        assert "video" in DEFAULT_MODELS
        assert "embedding" in DEFAULT_MODELS
        assert "asr" in DEFAULT_MODELS

    def test_free_models_dict(self):
        """测试免费模型字典。"""
        from glm_client.config import FREE_MODELS

        assert "glm-4.7-flash" in FREE_MODELS["text"]
        assert "glm-4.6v-flash" in FREE_MODELS["vision"]


class TestHelpers:
    """测试辅助函数。"""

    def test_truncate_text(self):
        """测试文本截断。"""
        from glm_client.utils.helpers import truncate_text

        text = "a" * 150
        result = truncate_text(text, max_length=100)
        assert len(result) == 100

        short_text = "short"
        result = truncate_text(short_text, max_length=100)
        assert result == "short"

    def test_get_safe_filename(self):
        """测试安全文件名生成。"""
        from glm_client.utils.helpers import get_safe_filename

        filename = get_safe_filename("Test: Image/1", "png")
        assert "Test_Image1" in filename
        assert filename.endswith(".png")

    def test_validate_image_url(self):
        """测试图片 URL 验证。"""
        from glm_client.utils.helpers import validate_image_url

        assert validate_image_url("https://example.com/image.jpg") is True
        assert validate_image_url("http://example.com/image.png") is True
        assert validate_image_url("not-a-url") is False
        assert validate_image_url("https://example.com/doc.pdf") is False


class TestPublicAPI:
    """测试公开 API 导出。"""

    def test_all_exports(self):
        """测试所有公开 API 可导入。"""
        import glm_client

        assert glm_client.__version__ == "0.2.0"
        assert len(glm_client.__all__) >= 20

        for name in glm_client.__all__:
            assert hasattr(glm_client, name), f"导出项 {name} 不存在"

    def test_core_imports(self):
        """测试核心导入。"""
        from glm_client import (
            GLMClient, GLMConfig,
            GLMClientError, AuthenticationError, RateLimitError,
            chat_completion, create_messages,
            vision_completion, compare_images,
            generate_image, generate_and_save,
            text_to_speech, word_to_speech,
            generate_video, generate_and_save_video,
            create_embedding, compute_similarity,
            transcribe_audio,
        )

        assert GLMClient is not None
        assert GLMConfig is not None


@pytest.mark.integration
class TestIntegration:
    """集成测试（需要真实 API Key）。"""

    @pytest.mark.skipif(
        not os.environ.get("ZAI_API_KEY") or os.environ.get("ZAI_API_KEY") == "test_api_key_123456789",
        reason="需要真实 API Key"
    )
    def test_real_text_generation(self):
        """测试真实文本生成。"""
        from glm_client.client import GLMClient
        from glm_client.models.text import chat_completion

        client = GLMClient()
        response = chat_completion(
            "请说'你好世界'",
            client=client,
            stream=False,
            temperature=0.1,
        )

        assert isinstance(response, str)
        assert len(response) > 0
