"""Tests for GLM client."""
