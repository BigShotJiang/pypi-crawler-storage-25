# 项目规则

## 语言

- 撰写文档、Git commit message、代码注释时，请使用中文
- 代码中的变量名、函数名、类名等标识符保持英文

## 代码提交规范

- 参考<https://www.conventionalcommits.org/zh-hans/v1.0.0/>
