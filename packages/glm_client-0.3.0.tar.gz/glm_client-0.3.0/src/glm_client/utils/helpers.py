"""Helper functions for GLM client."""

import base64
from pathlib import Path
from typing import Union, Optional

from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn, DownloadColumn, TimeRemainingColumn
from rich.filesize import decimal

console = Console()


def encode_image_to_base64(image_path: Union[str, Path]) -> str:
    """Encode an image file to base64.

    Args:
        image_path: Path to the image file.

    Returns:
        Base64 encoded string of the image.

    Raises:
        FileNotFoundError: If the image file doesn't exist.
        ValueError: If the file is not a valid image.
    """
    path = Path(image_path)
    if not path.exists():
        raise FileNotFoundError(f"Image file not found: {image_path}")

    # Check if it's an image file
    valid_extensions = {".jpg", ".jpeg", ".png", ".gif", ".webp", ".bmp"}
    if path.suffix.lower() not in valid_extensions:
        raise ValueError(
            f"Invalid image format: {path.suffix}. "
            f"Supported formats: {', '.join(valid_extensions)}"
        )

    with open(path, "rb") as f:
        image_data = f.read()

    return base64.b64encode(image_data).decode("utf-8")


def validate_image_url(url: str) -> bool:
    """Validate if a string is a valid image URL.

    Args:
        url: The URL to validate.

    Returns:
        True if the URL appears to be valid, False otherwise.
    """
    if not url.startswith(("http://", "https://")):
        return False

    # Check for common image extensions in URL
    image_extensions = (".jpg", ".jpeg", ".png", ".gif", ".webp", ".bmp")
    return url.lower().endswith(image_extensions) or "image" in url.lower()


def download_file(
    url: str,
    output_path: Union[str, Path],
    show_progress: bool = True,
) -> Path:
    """Download a file from URL with progress bar.

    Args:
        url: The URL to download from.
        output_path: Where to save the downloaded file.
        show_progress: Whether to show a progress bar.

    Returns:
        Path to the downloaded file.
    """
    import httpx

    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    if show_progress:
        with httpx.stream("GET", url, timeout=60.0, follow_redirects=True) as response:
            response.raise_for_status()
            total_size = int(response.headers.get("content-length", 0))

            with Progress(
                SpinnerColumn(),
                TextColumn("[progress.description]{task.description}"),
                BarColumn(),
                DownloadColumn(),
                TimeRemainingColumn(),
                console=console,
            ) as progress:
                task = progress.add_task(
                    f"[cyan]Downloading {output_path.name}",
                    total=total_size,
                )

                with open(output_path, "wb") as f:
                    for chunk in response.iter_bytes(chunk_size=8192):
                        f.write(chunk)
                        progress.update(task, advance=len(chunk))
    else:
        response = httpx.get(url, timeout=60.0, follow_redirects=True)
        response.raise_for_status()
        with open(output_path, "wb") as f:
            f.write(response.content)

    return output_path


def extract_text_from_file(file_path: Union[str, Path]) -> str:
    """Extract text content from various file types.

    Supported file types:
    - Plain text files (.txt, .md, etc.)
    - Word documents (.docx)
    - PDF files (.pdf)

    Args:
        file_path: Path to the file.

    Returns:
        Extracted text content.

    Raises:
        FileNotFoundError: If the file doesn't exist.
        ValueError: If the file type is not supported.
    """
    path = Path(file_path)

    if not path.exists():
        raise FileNotFoundError(f"File not found: {file_path}")

    # Get file extension
    ext = path.suffix.lower()

    # Plain text files
    if ext in {".txt", ".md", ".text", ""}:
        with open(path, "r", encoding="utf-8") as f:
            return f.read()

    # Word documents (.docx)
    if ext == ".docx":
        try:
            from docx import Document
            doc = Document(path)
            text = "\n".join([para.text for para in doc.paragraphs])
            return text
        except ImportError:
            raise ValueError(
                "python-docx package is required for Word documents. "
                "Install it with: uv add python-docx"
            )
        except Exception as e:
            raise ValueError(f"Failed to read Word document: {e}")

    # PDF files (.pdf)
    if ext == ".pdf":
        try:
            import PyPDF2
            reader = PyPDF2.PdfReader(path)
            text = ""
            for page in reader.pages:
                text += page.extract_text()
            return text
        except ImportError:
            raise ValueError(
                "PyPDF2 package is required for PDF files. "
                "Install it with: uv add PyPDF2"
            )
        except Exception as e:
            raise ValueError(f"Failed to read PDF document: {e}")

    raise ValueError(
        f"Unsupported file type: {ext}. "
        f"Supported types: .txt, .md, .docx, .pdf"
    )


def get_file_character_count(file_path: Union[str, Path]) -> int:
    """Get the character count of a text file.

    Args:
        file_path: Path to the file.

    Returns:
        Number of characters in the file.
    """
    text = extract_text_from_file(file_path)
    return len(text)


def truncate_text(text: str, max_length: int = 100) -> str:
    """Truncate text to a maximum length.

    Args:
        text: The text to truncate.
        max_length: Maximum length.

    Returns:
        Truncated text with ellipsis if needed.
    """
    if len(text) <= max_length:
        return text
    return text[: max_length - 3] + "..."


def format_timestamp() -> str:
    """Get current timestamp as a string.

    Returns:
        Formatted timestamp string.
    """
    from datetime import datetime

    return datetime.now().strftime("%Y%m%d_%H%M%S")


def get_safe_filename(prompt: str, extension: str = "") -> str:
    """Convert a prompt to a safe filename.

    Args:
        prompt: The prompt to convert.
        extension: Optional file extension.

    Returns:
        Safe filename string.
    """
    import re

    # Remove or replace unsafe characters
    safe = re.sub(r'[<>:"/\\|?*]', "", prompt)
    # Replace whitespace with underscores
    safe = re.sub(r"\s+", "_", safe)
    # Limit length
    safe = safe[:50]
    # Add extension if provided
    if extension and not extension.startswith("."):
        extension = "." + extension
    return safe + extension


def print_markdown(text: str) -> None:
    """Print markdown formatted text.

    Args:
        text: The markdown text to print.
    """
    from rich.markdown import Markdown

    md = Markdown(text)
    console.print(md)


def print_error(message: str) -> None:
    """Print an error message.

    Args:
        message: The error message to print.
    """
    console.print(f"[red]Error: {message}[/red]")


def print_warning(message: str) -> None:
    """Print a warning message.

    Args:
        message: The warning message to print.
    """
    console.print(f"[yellow]Warning: {message}[/yellow]")


def print_success(message: str) -> None:
    """Print a success message.

    Args:
        message: The success message to print.
    """
    console.print(f"[green]Success: {message}[/green]")


def print_info(message: str) -> None:
    """Print an info message.

    Args:
        message: The info message to print.
    """
    console.print(f"[blue]Info: {message}[/blue]")


def confirm_action(message: str, default: bool = False) -> bool:
    """Ask for user confirmation.

    Args:
        message: The confirmation message.
        default: Default value if user just presses Enter.

    Returns:
        True if user confirms, False otherwise.
    """
    from rich.prompt import Confirm

    return Confirm.ask(message, default=default)
