"""GLM Client - 智谱AI GLM 大模型 Python 客户端库。"""

__version__ = "0.3.0"

# 核心类
from .client import GLMClient, GLMClientError, AuthenticationError, RateLimitError
from .config import GLMConfig

# 文本生成
from .models.text import chat_completion, create_messages, stream_to_console

# 视觉理解
from .models.vision import vision_completion, create_vision_messages, compare_images

# OCR 文字识别
from .models.ocr import ocr, ocr_batch

# 文档摘要
from .models.summarize import summarize, summarize_file, DocumentSummary

# 图像生成
from .models.image import generate_image, generate_and_save

# 语音合成
from .models.audio import text_to_speech, word_to_speech, list_voices

# 视频生成
from .models.video import generate_video, generate_and_save_video

# 文本嵌入
from .models.embedding import create_embedding, create_embeddings_batch, compute_similarity

# 语音识别
from .models.asr import transcribe_audio

__all__ = [
    # 核心
    "GLMClient",
    "GLMConfig",
    "GLMClientError",
    "AuthenticationError",
    "RateLimitError",
    # 文本
    "chat_completion",
    "create_messages",
    "stream_to_console",
    # 视觉
    "vision_completion",
    "create_vision_messages",
    "compare_images",
    # OCR
    "ocr",
    "ocr_batch",
    # 文档摘要
    "summarize",
    "summarize_file",
    "DocumentSummary",
    # 图像
    "generate_image",
    "generate_and_save",
    # 语音合成
    "text_to_speech",
    "word_to_speech",
    "list_voices",
    # 视频
    "generate_video",
    "generate_and_save_video",
    # 嵌入
    "create_embedding",
    "create_embeddings_batch",
    "compute_similarity",
    # 语音识别
    "transcribe_audio",
]
