"""GLM Client 命令行界面。"""

from pathlib import Path
from typing import Optional, List

import typer
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.prompt import Prompt

from . import __version__
from .client import GLMClient, GLMClientError, AuthenticationError, RateLimitError
from .config import (
    get_api_key,
    AVAILABLE_TEXT_MODELS,
    AVAILABLE_VISION_MODELS,
    AVAILABLE_IMAGE_MODELS,
    AVAILABLE_VIDEO_MODELS,
    AVAILABLE_EMBEDDING_MODELS,
    AVAILABLE_ASR_MODELS,
    TTS_VOICES,
    DEFAULT_TTS_VOICE,
    DEFAULT_TTS_FORMAT,
    DEFAULT_TTS_SPEED,
    DEFAULT_TTS_VOLUME,
    DEFAULT_MODELS,
    IMAGE_SIZES,
    DEFAULT_IMAGE_SIZE,
    VIDEO_SIZES,
    FREE_MODELS,
)
from .models.text import chat_completion, stream_to_console
from .models.vision import vision_completion
from .models.image import generate_and_save
from .models.audio import text_to_speech, list_voices, word_to_speech
from .models.video import generate_and_save_video
from .models.embedding import create_embedding as _create_embedding, compute_similarity as _compute_similarity
from .models.asr import transcribe_audio as _transcribe_audio
from .utils.helpers import (
    print_markdown,
    print_error,
    print_warning,
    print_success,
    print_info,
)

app = typer.Typer(
    name="glm-client",
    help="GLM (智谱AI) 大模型 API 客户端",
    add_completion=False,
)
console = Console()


def version_callback(value: bool) -> None:
    if value:
        console.print(f"glm-client version {__version__}")
        raise typer.Exit()


@app.callback()
def main(
    version: bool = typer.Option(
        False,
        "--version",
        "-v",
        callback=version_callback,
        help="显示版本号",
    ),
) -> None:
    """GLM Client - 智谱AI GLM 大模型客户端。"""
    pass


@app.command()
def chat(
    prompt: Optional[str] = typer.Argument(
        None,
        help="发送给模型的提示词（省略则进入交互模式）",
    ),
    model: str = typer.Option(
        DEFAULT_MODELS["text"],
        "--model",
        "-m",
        help="使用的模型",
    ),
    system: Optional[str] = typer.Option(
        None,
        "--system",
        "-s",
        help="系统消息",
    ),
    temperature: float = typer.Option(
        0.7,
        "--temperature",
        "-t",
        min=0.0,
        max=2.0,
        help="采样温度 (0-2)",
    ),
    max_tokens: Optional[int] = typer.Option(
        None,
        "--max-tokens",
        help="最大生成 token 数",
    ),
    stream: bool = typer.Option(
        True,
        "--stream/--no-stream",
        help="启用/禁用流式响应",
    ),
    interactive: bool = typer.Option(
        False,
        "--interactive",
        "-i",
        help="启动交互模式",
    ),
    thinking: bool = typer.Option(
        False,
        "--thinking",
        help="启用思考模式（需支持思考的模型如 glm-4.7）",
    ),
    web_search: bool = typer.Option(
        False,
        "--web-search",
        help="启用联网搜索",
    ),
) -> None:
    """文本生成。

    示例:
        glm-client chat "你好，介绍一下你自己"
        glm-client chat "解释量子计算" --temperature 0.5 --no-stream
        glm-client chat --interactive
        glm-client chat "最新新闻" --web-search
    """
    try:
        client = GLMClient()

        if interactive or prompt is None:
            _interactive_chat(client, model, system, temperature, max_tokens, stream)
            return

        console.print(f"[cyan]使用模型: {model}[/cyan]")
        console.print(f"[dim]提示词: {prompt[:100]}{'...' if len(prompt) > 100 else ''}[/dim]\n")

        response = chat_completion(
            prompt=prompt,
            client=client,
            model=model,
            system=system,
            temperature=temperature,
            max_tokens=max_tokens,
            stream=stream,
            thinking=thinking,
            web_search=web_search,
        )

        if stream:
            full_response = stream_to_console(response)
        else:
            full_response = response
            console.print(full_response)

        console.print()

    except AuthenticationError as e:
        console.print(f"[red]认证错误: {e}[/red]")
        console.print("[yellow]请设置 ZAI_API_KEY 或 ZHIPUAI_API_KEY 环境变量。[/yellow]")
        raise typer.Exit(code=1)
    except RateLimitError as e:
        console.print(f"[red]频率限制: {e}[/red]")
        raise typer.Exit(code=1)
    except GLMClientError as e:
        console.print(f"[red]错误: {e}[/red]")
        raise typer.Exit(code=1)
    except Exception as e:
        console.print(f"[red]未知错误: {e}[/red]")
        raise typer.Exit(code=1)


def _interactive_chat(
    client: GLMClient,
    model: str,
    system: Optional[str],
    temperature: float,
    max_tokens: Optional[int],
    stream: bool,
) -> None:
    """交互式聊天。"""
    console.print(Panel.fit(
        f"[bold cyan]GLM 交互式聊天[/bold cyan]\n\n"
        f"模型: {model}\n"
        f"温度: {temperature}\n\n"
        f"[dim]输入消息后按回车发送[/dim]\n"
        f"[dim]输入 quit/exit 或 Ctrl+C 退出[/dim]\n"
        f"[dim]输入 clear 清空对话历史[/dim]\n"
        f"[dim]输入 system <消息> 设置系统消息[/dim]",
        title="交互模式",
        border_style="cyan",
    ))

    conversation_history: List[dict] = []

    while True:
        try:
            user_input = Prompt.ask(
                "\n[bold cyan]你[/bold cyan]",
                default="",
                show_default=False,
            )

            if not user_input.strip():
                continue

            if user_input.lower() in ("quit", "exit", "q"):
                console.print("[yellow]再见！[/yellow]")
                break

            if user_input.lower() == "clear":
                conversation_history.clear()
                console.print("[green]对话历史已清空。[/green]")
                continue

            if user_input.lower().startswith("system "):
                system = user_input[7:].strip()
                console.print(f"[green]系统消息已设置: {system}[/green]")
                continue

            conversation_history.append({"role": "user", "content": user_input})

            console.print("[bold cyan]助手[/bold cyan]", end=" ")

            response_gen = chat_completion(
                prompt=user_input,
                client=client,
                model=model,
                system=system,
                history=conversation_history[:-1],
                temperature=temperature,
                max_tokens=max_tokens,
                stream=stream,
            )

            if stream:
                full_response = stream_to_console(response_gen)
            else:
                full_response = response_gen
                console.print(full_response)

            conversation_history.append({"role": "assistant", "content": full_response})

        except KeyboardInterrupt:
            console.print("\n\n[yellow]输入 quit/exit/q 退出。[/yellow]")
        except EOFError:
            console.print("\n\n[yellow]再见！[/yellow]")
            break


@app.command()
def vision(
    prompt: str = typer.Argument(
        ...,
        help="对图像的问题或指令",
    ),
    image: Optional[Path] = typer.Option(
        None,
        "--image",
        "-i",
        help="本地图片路径",
        exists=True,
    ),
    image_url: Optional[str] = typer.Option(
        None,
        "--image-url",
        help="图片 URL",
    ),
    model: str = typer.Option(
        DEFAULT_MODELS["vision"],
        "--model",
        "-m",
        help="视觉模型",
    ),
    system: Optional[str] = typer.Option(
        None,
        "--system",
        "-s",
        help="系统消息",
    ),
    temperature: float = typer.Option(
        0.7,
        "--temperature",
        "-t",
        min=0.0,
        max=2.0,
        help="采样温度 (0-2)",
    ),
) -> None:
    """图像分析。

    示例:
        glm-client vision "描述这张图片" --image photo.jpg
        glm-client vision "图片中有什么？" --image-url "https://example.com/image.jpg"
    """
    if not image and not image_url:
        console.print("[red]错误: 必须指定 --image 或 --image-url。[/red]")
        raise typer.Exit(code=1)

    try:
        client = GLMClient()
        image_source = str(image_url) if image_url else image

        console.print(f"[cyan]使用模型: {model}[/cyan]")
        console.print(f"[dim]图像: {image_source}[/dim]")
        console.print(f"[dim]提示词: {prompt}[/dim]\n")

        response = vision_completion(
            prompt=prompt,
            image=image_source,
            client=client,
            model=model,
            system=system,
            temperature=temperature,
        )

        console.print(response)
        console.print()

    except AuthenticationError as e:
        console.print(f"[red]认证错误: {e}[/red]")
        raise typer.Exit(code=1)
    except GLMClientError as e:
        console.print(f"[red]错误: {e}[/red]")
        raise typer.Exit(code=1)
    except Exception as e:
        console.print(f"[red]未知错误: {e}[/red]")
        raise typer.Exit(code=1)


@app.command()
def image(
    prompt: str = typer.Argument(
        ...,
        help="图像描述",
    ),
    output: Optional[Path] = typer.Option(
        None,
        "--output",
        "-o",
        help="输出文件路径",
    ),
    model: str = typer.Option(
        DEFAULT_MODELS["image"],
        "--model",
        "-m",
        help="图像生成模型",
    ),
    size: str = typer.Option(
        DEFAULT_IMAGE_SIZE,
        "--size",
        "-s",
        help="图像尺寸 (如 1024x1024, 768x1344)",
    ),
    n: int = typer.Option(
        1,
        "--count",
        "-n",
        min=1,
        max=4,
        help="生成图像数量",
    ),
) -> None:
    """图像生成。

    示例:
        glm-client image "一只坐在桌子上的猫"
        glm-client image "山上的日落" --output sunset.png
        glm-client image "未来城市" --size 768x1344 --count 2
    """
    try:
        client = GLMClient()

        console.print(f"[cyan]使用模型: {model}[/cyan]")
        console.print(f"[dim]提示词: {prompt}[/dim]")
        console.print(f"[dim]尺寸: {size} | 数量: {n}[/dim]\n")

        size = size.replace("-", "x")

        saved_paths = generate_and_save(
            prompt=prompt,
            client=client,
            output=output,
            model=model,
            size=size,
            n=n,
            show_progress=True,
        )

        console.print(f"\n[green]成功生成 {len(saved_paths)} 张图像！[/green]")

    except AuthenticationError as e:
        console.print(f"[red]认证错误: {e}[/red]")
        raise typer.Exit(code=1)
    except GLMClientError as e:
        console.print(f"[red]错误: {e}[/red]")
        raise typer.Exit(code=1)
    except Exception as e:
        console.print(f"[red]未知错误: {e}[/red]")
        raise typer.Exit(code=1)


@app.command()
def video(
    prompt: str = typer.Argument(
        ...,
        help="视频描述提示词",
    ),
    output: Optional[Path] = typer.Option(
        None,
        "--output",
        "-o",
        help="输出视频文件路径",
    ),
    model: str = typer.Option(
        DEFAULT_MODELS["video"],
        "--model",
        "-m",
        help="视频生成模型",
    ),
    image_url: Optional[str] = typer.Option(
        None,
        "--image-url",
        "-i",
        help="参考图片 URL（图生视频）",
    ),
    quality: str = typer.Option(
        "quality",
        "--quality",
        "-q",
        help="输出模式: quality（质量优先）或 speed（速度优先）",
    ),
    size: str = typer.Option(
        "1920x1080",
        "--size",
        "-s",
        help="视频分辨率",
    ),
    fps: int = typer.Option(
        30,
        "--fps",
        help="帧率 (30 或 60)",
    ),
    no_audio: bool = typer.Option(
        False,
        "--no-audio",
        help="不包含音频",
    ),
) -> None:
    """视频生成。

    示例:
        glm-client video "一只猫在玩球"
        glm-client video "日落海滩" --output sunset.mp4
        glm-client video "让画面动起来" --image-url https://example.com/image.jpg
    """
    try:
        client = GLMClient()

        console.print(f"[cyan]使用模型: {model}[/cyan]")
        console.print(f"[dim]提示词: {prompt}[/dim]")
        console.print(f"[dim]尺寸: {size} | FPS: {fps}[/dim]\n")

        output_path = generate_and_save_video(
            prompt=prompt,
            client=client,
            output=output,
            model=model,
            image_url=image_url,
            quality=quality,
            with_audio=not no_audio,
            size=size,
            fps=fps,
        )

        console.print(f"\n[green]视频已保存: {output_path}[/green]")

    except AuthenticationError as e:
        console.print(f"[red]认证错误: {e}[/red]")
        raise typer.Exit(code=1)
    except GLMClientError as e:
        console.print(f"[red]错误: {e}[/red]")
        raise typer.Exit(code=1)
    except Exception as e:
        console.print(f"[red]未知错误: {e}[/red]")
        raise typer.Exit(code=1)


@app.command()
def embed(
    text: str = typer.Argument(
        ...,
        help="要生成嵌入的文本",
    ),
    model: str = typer.Option(
        DEFAULT_MODELS["embedding"],
        "--model",
        "-m",
        help="嵌入模型",
    ),
    compare: Optional[str] = typer.Option(
        None,
        "--compare",
        "-c",
        help="与另一段文本比较相似度",
    ),
) -> None:
    """文本嵌入。

    示例:
        glm-client embed "人工智能"
        glm-client embed "机器学习" --compare "深度学习"
    """
    try:
        client = GLMClient()

        if compare:
            console.print(f"[cyan]计算文本相似度...[/cyan]")
            console.print(f"[dim]文本A: {text[:50]}...[/dim]")
            console.print(f"[dim]文本B: {compare[:50]}...[/dim]\n")

            similarity = _compute_similarity(text, compare, client, model)
            console.print(f"[green]余弦相似度: {similarity:.4f}[/green]")
        else:
            console.print(f"[cyan]使用模型: {model}[/cyan]")
            console.print(f"[dim]文本: {text[:50]}...[/dim]\n")

            embedding = _create_embedding(text, client, model)
            console.print(f"[green]嵌入维度: {len(embedding)}[/green]")
            console.print(f"[dim]前5个值: {embedding[:5]}[/dim]")

    except AuthenticationError as e:
        console.print(f"[red]认证错误: {e}[/red]")
        raise typer.Exit(code=1)
    except GLMClientError as e:
        console.print(f"[red]错误: {e}[/red]")
        raise typer.Exit(code=1)
    except Exception as e:
        console.print(f"[red]未知错误: {e}[/red]")
        raise typer.Exit(code=1)


@app.command()
def asr(
    file: Path = typer.Option(
        ...,
        "--file",
        "-f",
        help="音频文件路径",
        exists=True,
    ),
    model: str = typer.Option(
        DEFAULT_MODELS["asr"],
        "--model",
        "-m",
        help="语音识别模型",
    ),
    language: Optional[str] = typer.Option(
        None,
        "--language",
        "-l",
        help="语言提示 (如 zh, en)",
    ),
) -> None:
    """语音识别（音频转文字）。

    示例:
        glm-client asr --file audio.wav
        glm-client asr -f recording.mp3 --language zh
    """
    try:
        client = GLMClient()

        console.print(f"[cyan]使用模型: {model}[/cyan]")
        console.print(f"[dim]音频文件: {file}[/dim]\n")

        result = _transcribe_audio(
            audio_path=str(file),
            client=client,
            model=model,
            language=language,
        )

        console.print(f"[green]识别结果:[/green]")
        console.print(result)

    except AuthenticationError as e:
        console.print(f"[red]认证错误: {e}[/red]")
        raise typer.Exit(code=1)
    except GLMClientError as e:
        console.print(f"[red]错误: {e}[/red]")
        raise typer.Exit(code=1)
    except Exception as e:
        console.print(f"[red]未知错误: {e}[/red]")
        raise typer.Exit(code=1)


@app.command()
def tts(
    text: Optional[str] = typer.Argument(
        None,
        help="要转换为语音的文本",
    ),
    file: Optional[Path] = typer.Option(
        None,
        "--file",
        "-F",
        help="从文件读取文本",
        exists=True,
    ),
    word: Optional[Path] = typer.Option(
        None,
        "--word",
        "-w",
        help="从 Word 文档读取文本 (.docx)",
        exists=True,
    ),
    output: Optional[Path] = typer.Option(
        None,
        "--output",
        "-o",
        help="输出音频文件路径",
    ),
    voice: str = typer.Option(
        DEFAULT_TTS_VOICE,
        "--voice",
        "-v",
        help=f"语音音色。可选: {', '.join(TTS_VOICES)}",
    ),
    format: str = typer.Option(
        DEFAULT_TTS_FORMAT,
        "--format",
        "-f",
        help="音频格式 (wav, pcm, mp3)",
    ),
    speed: float = typer.Option(
        DEFAULT_TTS_SPEED,
        "--speed",
        "-s",
        min=0.5,
        max=2.0,
        help="语速 (0.5-2.0)",
    ),
    volume: float = typer.Option(
        DEFAULT_TTS_VOLUME,
        "--volume",
        "-V",
        min=0.5,
        max=2.0,
        help="音量 (0.5-2.0)",
    ),
) -> None:
    """文本转语音。

    示例:
        glm-client tts "你好，世界！"
        glm-client tts --file speech.txt
        glm-client tts --word document.docx --output audio.mp3
    """
    try:
        client = GLMClient()

        if word:
            console.print(f"[cyan]处理 Word 文档: {word}[/cyan]")
            console.print(f"[dim]音色: {voice} | 格式: {format} | 语速: {speed} | 音量: {volume}[/dim]\n")

            output_path = word_to_speech(
                word_path=word,
                client=client,
                voice=voice,
                output=output,
                response_format=format,
                speed=speed,
                volume=volume,
            )

            console.print(f"[green]音频已保存: {output_path}[/green]")
            return

        if file:
            with open(file, 'r', encoding='utf-8') as f:
                text_content = f.read()
            console.print(f"[dim]从 {file} 读取 {len(text_content)} 个字符[/dim]")
        elif text:
            text_content = text
        else:
            console.print("[dim]从标准输入读取...[/dim]")
            import sys
            text_content = sys.stdin.read()
            if text_content.endswith('\n'):
                text_content = text_content[:-1]

        if not text_content or not text_content.strip():
            console.print("[red]错误: 未提供文本。请使用 --file、--word 或直接输入文本。[/red]")
            raise typer.Exit(code=1)

        console.print(f"[cyan]使用音色: {voice}[/cyan]")
        console.print(f"[dim]格式: {format} | 语速: {speed} | 音量: {volume}[/dim]")
        console.print(f"[dim]文本: {text_content[:100]}{'...' if len(text_content) > 100 else ''}[/dim]\n")

        output_path = text_to_speech(
            text=text_content,
            client=client,
            voice=voice,
            output=output,
            response_format=format,
            speed=speed,
            volume=volume,
        )

        console.print(f"[green]音频已保存: {output_path}[/green]")

    except AuthenticationError as e:
        console.print(f"[red]认证错误: {e}[/red]")
        raise typer.Exit(code=1)
    except GLMClientError as e:
        console.print(f"[red]错误: {e}[/red]")
        raise typer.Exit(code=1)
    except Exception as e:
        console.print(f"[red]未知错误: {e}[/red]")
        raise typer.Exit(code=1)


@app.command()
def config(
    list_models: bool = typer.Option(
        False,
        "--list-models",
        help="列出所有可用模型",
    ),
    api_key: Optional[str] = typer.Option(
        None,
        "--api-key",
        help="查看 API Key 配置说明",
    ),
) -> None:
    """查看或设置配置。

    示例:
        glm-client config --list-models
        glm-client config --api-key
    """
    if api_key is not None:
        console.print(Panel.fit(
            "[bold yellow]API Key 配置[/bold yellow]\n\n"
            "设置 API Key 的方法：\n\n"
            "1. [cyan]环境变量:[/cyan]\n"
            "   export ZAI_API_KEY='your_key_here'\n\n"
            "2. [cyan].env 文件:[/cyan]\n"
            "   在项目目录创建 .env 文件：\n"
            "   ZAI_API_KEY=your_key_here\n\n"
            "3. [cyan]Windows PowerShell:[/cyan]\n"
            "   $env:ZAI_API_KEY='your_key_here'\n\n"
            "获取 API Key: https://open.bigmodel.cn/",
            title="配置帮助",
        ))
        return

    if list_models:
        _list_all_models()
        return

    _show_current_config()


def _list_all_models() -> None:
    """列出所有可用模型。"""
    console.print("\n[bold]可用模型[/bold]\n")

    model_categories = [
        ("文本生成模型", AVAILABLE_TEXT_MODELS, "text"),
        ("视觉理解模型", AVAILABLE_VISION_MODELS, "vision"),
        ("图像生成模型", AVAILABLE_IMAGE_MODELS, "image"),
        ("视频生成模型", AVAILABLE_VIDEO_MODELS, "video"),
        ("文本嵌入模型", AVAILABLE_EMBEDDING_MODELS, "embedding"),
        ("语音识别模型", AVAILABLE_ASR_MODELS, "asr"),
    ]

    for category_name, models, model_type in model_categories:
        console.print(f"[cyan]{category_name}:[/cyan]")
        free_set = set(FREE_MODELS.get(model_type, []))
        for model in models:
            tags = []
            if model == DEFAULT_MODELS.get(model_type):
                tags.append("默认")
            if model in free_set:
                tags.append("免费")
            tag_str = f" ({', '.join(tags)})" if tags else ""
            console.print(f"  - {model}{tag_str}")
        console.print()

    # TTS
    console.print("[cyan]TTS 音色:[/cyan]")
    for voice in TTS_VOICES:
        default = " (默认)" if voice == DEFAULT_TTS_VOICE else ""
        console.print(f"  - {voice}{default}")

    # 图像尺寸
    console.print(f"\n[cyan]图像尺寸:[/cyan]")
    console.print(f"  - {', '.join(IMAGE_SIZES)}")

    console.print()


def _show_current_config() -> None:
    """显示当前配置。"""
    console.print("\n[bold]当前配置[/bold]\n")

    table = Table(show_header=False, box=None)
    table.add_column("设置", style="cyan")
    table.add_column("值", style="yellow")

    try:
        api_key = get_api_key()
        table.add_row("API Key", "********")
    except ValueError:
        table.add_row("API Key", "[red]未设置[/red]")

    from .client import _SDK_NAME
    table.add_row("SDK", _SDK_NAME)
    table.add_row("默认文本模型", DEFAULT_MODELS["text"])
    table.add_row("默认视觉模型", DEFAULT_MODELS["vision"])
    table.add_row("默认图像模型", DEFAULT_MODELS["image"])
    table.add_row("默认视频模型", DEFAULT_MODELS["video"])
    table.add_row("默认嵌入模型", DEFAULT_MODELS["embedding"])
    table.add_row("默认TTS音色", DEFAULT_TTS_VOICE)

    console.print(table)
    console.print("\n[yellow]提示: 使用 --list-models 查看所有可用模型[/yellow]")
    console.print("[yellow]提示: 使用 --api-key 查看 API Key 配置方法[/yellow]\n")


if __name__ == "__main__":
    app()
