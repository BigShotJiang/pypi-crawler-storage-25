"""文档摘要模块。

基于 GLM-4.7-Flash 文本模型，对文档内容生成结构化摘要，
输出统一的 JSON 格式，适用于文件管理、搜索和分类场景。

可接收纯文本内容，也可直接传入文件（自动调用 OCR 识别后再摘要）。

基础用法::

    from glm_client import GLMClient, summarize

    client = GLMClient()

    # 从纯文本生成摘要
    result = summarize("合同全文内容...", client=client)

    # 直接传入文件（自动 OCR + 摘要）
    result = summarize_file("contract.pdf", client=client)

    print(result["title"])      # "XX公司技术服务合同"
    print(result["summary"])    # 200 字摘要
    print(result["keywords"])   # ["技术服务", "合同", ...]
"""

import json
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Union, Optional, List, Dict, Any

from rich.console import Console

from ..client import GLMClient, GLMClientError

console = Console()

# 结构化摘要的 system prompt
_SUMMARY_SYSTEM_PROMPT = (
    "你是一个专业的文档分析助手。你的任务是分析文档内容，"
    "生成一份结构化的摘要信息，用于文件管理和搜索系统。"
)

# 要求模型输出的 JSON schema 描述
_SUMMARY_USER_PROMPT_TEMPLATE = (
    "请分析以下文档内容，生成一份结构化摘要。"
    "严格按以下 JSON 格式输出，不要输出任何其他内容：\n\n"
    "```json\n"
    "{{\n"
    '  "title": "文档标题（如无法确定则提取关键主题作为标题）",\n'
    '  "document_type": "文件类型（从以下选择：合同/协议/方案/报告/通知/简历/发票/收据/证书/规章制度/会议纪要/邮件/论文/说明书/其他）",\n'
    '  "category": "业务分类（如：人事/财务/法务/技术/市场/行政/通用，可多选逗号分隔）",\n'
    '  "summary": "200字以内的核心内容摘要",\n'
    '  "keywords": ["关键词1", "关键词2", "关键词3", "关键词4", "关键词5"],\n'
    '  "key_info": {{\n'
    '    "dates": ["文档中提到的重要日期"],\n'
    '    "parties": ["涉及的机构、公司或个人名称"],\n'
    '    "amounts": ["涉及的金额或数量（如有）"],\n'
    '    "locations": ["涉及的地点（如有）"]\n'
    "  }},\n"
    '  "language": "文档的主要语言（zh/en/ja/ko/other）",\n'
    '  "confidence": "识别置信度（high/medium/low）"\n'
    "}}\n"
    "```\n\n"
    "文档内容：\n{content}"
)


@dataclass
class DocumentSummary:
    """结构化文档摘要。

    Attributes:
        title: 文档标题。
        document_type: 文件类型（合同/方案/报告等）。
        category: 业务分类。
        summary: 核心内容摘要（200 字以内）。
        keywords: 关键词列表。
        key_info: 关键信息（日期、参与方、金额、地点）。
        language: 主要语言。
        confidence: 置信度（high/medium/low）。
    """

    title: str
    document_type: str
    category: str
    summary: str
    keywords: List[str]
    key_info: Dict[str, List[str]]
    language: str
    confidence: str

    def to_dict(self) -> Dict[str, Any]:
        """转换为字典。"""
        return asdict(self)

    def to_json(self, ensure_ascii: bool = False, indent: int = 2) -> str:
        """转换为 JSON 字符串。"""
        return json.dumps(self.to_dict(), ensure_ascii=ensure_ascii, indent=indent)


def _parse_summary_response(raw: str) -> DocumentSummary:
    """解析模型返回的 JSON 为 DocumentSummary。

    容错处理：尝试从返回文本中提取 JSON 块。
    """
    text = raw.strip()

    # 尝试提取 ```json ... ``` 包裹的内容
    if "```json" in text:
        start = text.index("```json") + len("```json")
        end = text.index("```", start)
        text = text[start:end].strip()
    elif "```" in text:
        start = text.index("```") + len("```")
        end = text.index("```", start)
        text = text[start:end].strip()

    try:
        data = json.loads(text)
    except json.JSONDecodeError as e:
        raise ValueError(f"无法解析摘要 JSON: {e}\n原始响应: {raw[:200]}") from e

    return DocumentSummary(
        title=data.get("title", ""),
        document_type=data.get("document_type", "其他"),
        category=data.get("category", "通用"),
        summary=data.get("summary", ""),
        keywords=data.get("keywords", []),
        key_info=data.get("key_info", {}),
        language=data.get("language", "zh"),
        confidence=data.get("confidence", "medium"),
    )


def summarize(
    content: str,
    client: GLMClient,
    model: str = "glm-4-flash",
    max_tokens: int = 2048,
    temperature: float = 0.3,
) -> DocumentSummary:
    """对文本内容生成结构化摘要。

    使用最强免费文本模型 glm-4-flash，输出统一格式的摘要信息，
    包含标题、类型、分类、摘要、关键词、关键信息等字段，
    适合直接存入数据库用于文件管理和搜索。

    Args:
        content: 文档文本内容。
        client: GLMClient 实例。
        model: 文本模型名称，默认 ``glm-4-flash``（免费）。
        max_tokens: 最大输出 token 数。
        temperature: 采样温度，默认 0.3（偏低以获得稳定输出）。

    Returns:
        :class:`DocumentSummary` 结构化摘要对象，可 ``.to_dict()`` 或 ``.to_json()`` 导出。

    Raises:
        GLMClientError: API 请求失败。
        ValueError: 模型返回内容无法解析。

    Examples::

        from glm_client import GLMClient, summarize

        client = GLMClient()

        text = "甲方：XX科技有限公司 ...（合同全文）"
        result = summarize(text, client=client)

        print(result.title)           # "XX科技技术服务合同"
        print(result.document_type)   # "合同"
        print(result.summary)         # 核心摘要
        print(result.keywords)        # ["技术服务", ...]
        print(result.key_info)        # {"dates": [...], "parties": [...], ...}

        # 导出为 dict / JSON
        result.to_dict()
        result.to_json()
    """
    user_prompt = _SUMMARY_USER_PROMPT_TEMPLATE.format(content=content)

    messages = [
        {"role": "system", "content": _SUMMARY_SYSTEM_PROMPT},
        {"role": "user", "content": user_prompt},
    ]

    params = {
        "model": model,
        "messages": messages,
        "temperature": temperature,
        "max_tokens": max_tokens,
        "stream": False,
    }

    try:
        response = client.chat_completion(**params)
    except Exception as e:
        raise GLMClientError(f"摘要生成失败: {e}") from e

    if not response.choices or len(response.choices) == 0:
        raise GLMClientError("摘要生成失败：模型返回为空")

    raw = response.choices[0].message.content
    return _parse_summary_response(raw)


def summarize_file(
    source: Union[str, Path],
    client: GLMClient,
    ocr_model: str = "glm-4v-flash",
    text_model: str = "glm-4-flash",
    ocr_dpi: int = 200,
    max_tokens: int = 4096,
    verbose: bool = False,
) -> DocumentSummary:
    """对文件先 OCR 识别再生成结构化摘要。

    等价于 ``summarize(ocr(source, ...), client)`` 的快捷方式。
    支持图片和 PDF 文件（本地路径或 URL）。

    Args:
        source: 文件路径或 URL（图片/PDF）。
        client: GLMClient 实例。
        ocr_model: OCR 视觉模型名称。
        text_model: 摘要文本模型名称。
        ocr_dpi: PDF 渲染分辨率。
        max_tokens: OCR 和摘要的最大输出 token 数。
        verbose: 是否显示处理进度。

    Returns:
        :class:`DocumentSummary` 结构化摘要对象。

    Raises:
        FileNotFoundError: 文件不存在。
        ImportError: PDF 需要 pymupdf。
        GLMClientError: API 请求失败。

    Examples::

        from glm_client import GLMClient, summarize_file

        client = GLMClient()

        result = summarize_file("contract.pdf", client=client)
        print(result.title)
        print(result.to_json())
    """
    from .ocr import ocr as _ocr

    if verbose:
        console.print(f"[cyan]第一步：OCR 识别 {source}[/cyan]")

    text = ocr(
        source=source,
        client=client,
        model=ocr_model,
        max_tokens=max_tokens,
        dpi=ocr_dpi,
        verbose=verbose,
    )

    if not text.strip():
        raise GLMClientError(f"OCR 识别结果为空: {source}")

    if verbose:
        console.print(f"[cyan]第二步：生成结构化摘要[/cyan]")

    return summarize(
        content=text,
        client=client,
        model=text_model,
        max_tokens=max_tokens,
    )
