"""视频生成模块。"""

import time
from pathlib import Path
from typing import Optional, Union

from rich.console import Console

from ..client import GLMClient, GLMClientError
from ..config import (
    get_default_model,
    AVAILABLE_VIDEO_MODELS,
    VIDEO_SIZES,
    VIDEO_FPS_OPTIONS,
    get_output_dir,
)
from ..utils.helpers import download_file, format_timestamp, get_safe_filename

console = Console()

# 视频生成轮询间隔（秒）
POLL_INTERVAL = 10
# 最大等待时间（秒）
MAX_WAIT_TIME = 300


def generate_video(
    prompt: str,
    client: GLMClient,
    model: Optional[str] = None,
    image_url: Optional[str] = None,
    quality: str = "quality",
    with_audio: bool = True,
    size: str = "1920x1080",
    fps: int = 30,
) -> str:
    """生成视频并等待完成，返回视频 URL。

    Args:
        prompt: 视频描述提示词。
        client: GLM 客户端实例。
        model: 模型名称。
        image_url: 可选的参考图片 URL（图生视频）。
        quality: 输出模式，"quality" 质量优先，"speed" 速度优先。
        with_audio: 是否包含音频。
        size: 视频分辨率。
        fps: 帧率。

    Returns:
        视频文件 URL。

    Raises:
        GLMClientError: 视频生成失败或超时。
    """
    model = model or get_default_model("video")

    if model not in AVAILABLE_VIDEO_MODELS:
        console.print(f"[yellow]警告: 模型 '{model}' 不在已知列表中，仍将尝试。[/yellow]")

    try:
        params = {
            "model": model,
            "prompt": prompt,
            "quality": quality,
            "with_audio": with_audio,
            "size": size,
            "fps": fps,
        }
        if image_url:
            params["image_url"] = image_url

        response = client.video_generation(**params)

        # 如果响应直接包含视频结果
        if hasattr(response, "video_result") and response.video_result:
            results = response.video_result
            if results and len(results) > 0:
                return results[0].url if hasattr(results[0], "url") else str(results[0])

        # 如果是异步任务，需要轮询
        task_id = response.id
        if not task_id:
            raise GLMClientError("视频生成任务未返回任务 ID")

        console.print(f"[cyan]视频生成任务已创建: {task_id}[/cyan]")
        return _poll_video_result(task_id, client)

    except GLMClientError:
        raise
    except Exception as e:
        raise GLMClientError(f"视频生成失败: {e}") from e


def _poll_video_result(
    task_id: str,
    client: GLMClient,
    poll_interval: int = POLL_INTERVAL,
    max_wait: int = MAX_WAIT_TIME,
) -> str:
    """轮询视频生成结果。

    Args:
        task_id: 异步任务 ID。
        client: GLM 客户端实例。
        poll_interval: 轮询间隔秒数。
        max_wait: 最大等待秒数。

    Returns:
        视频文件 URL。
    """
    elapsed = 0

    while elapsed < max_wait:
        time.sleep(poll_interval)
        elapsed += poll_interval

        try:
            result = client.retrieve_video_result(task_id)

            if hasattr(result, "video_result") and result.video_result:
                results = result.video_result
                if results and len(results) > 0:
                    video_url = results[0].url if hasattr(results[0], "url") else str(results[0])
                    console.print("[green]视频生成完成！[/green]")
                    return video_url

            console.print(f"[dim]等待中... ({elapsed}s/{max_wait}s)[/dim]")

        except Exception as e:
            console.print(f"[yellow]查询状态失败: {e}[/yellow]")

    raise GLMClientError(f"视频生成超时（{max_wait}s）")


def check_video_status(task_id: str, client: GLMClient) -> dict:
    """查询视频生成任务状态。

    Args:
        task_id: 任务 ID。
        client: GLM 客户端实例。

    Returns:
        任务状态信息字典。
    """
    try:
        result = client.retrieve_video_result(task_id)
        info = {"task_id": task_id}

        if hasattr(result, "video_result") and result.video_result:
            results = result.video_result
            if results and len(results) > 0:
                info["status"] = "completed"
                info["url"] = results[0].url if hasattr(results[0], "url") else str(results[0])
            else:
                info["status"] = "processing"
        else:
            info["status"] = "processing"

        return info

    except Exception as e:
        return {"task_id": task_id, "status": "error", "error": str(e)}


def generate_and_save_video(
    prompt: str,
    client: GLMClient,
    output: Optional[Union[str, Path]] = None,
    model: Optional[str] = None,
    **kwargs,
) -> Path:
    """生成视频并保存到文件。

    Args:
        prompt: 视频描述提示词。
        client: GLM 客户端实例。
        output: 输出文件路径。
        model: 模型名称。
        **kwargs: 其他视频生成参数。

    Returns:
        保存的视频文件路径。
    """
    console.print(f"[cyan]正在生成视频...[/cyan]")

    video_url = generate_video(prompt, client, model=model, **kwargs)

    if not output:
        output_dir = get_output_dir()
        safe_name = get_safe_filename(prompt)
        timestamp = format_timestamp()
        output = output_dir / f"{safe_name}_{timestamp}.mp4"
    else:
        output = Path(output)
        output.parent.mkdir(parents=True, exist_ok=True)

    downloaded = download_file(video_url, output)
    console.print(f"[green]视频已保存: {downloaded}[/green]")
    return downloaded
