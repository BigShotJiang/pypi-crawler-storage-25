"""语音识别（ASR）模块。"""

import base64
from pathlib import Path
from typing import Optional

from rich.console import Console

from ..client import GLMClient, GLMClientError
from ..config import get_default_model, AVAILABLE_ASR_MODELS

console = Console()


def transcribe_audio(
    audio_path: str,
    client: GLMClient,
    model: Optional[str] = None,
    language: Optional[str] = None,
) -> str:
    """将本地音频文件转换为文字。

    Args:
        audio_path: 音频文件路径。
        client: GLM 客户端实例。
        model: ASR 模型名称。
        language: 可选的语言提示（如 "zh"、"en"）。

    Returns:
        识别出的文本。

    Raises:
        GLMClientError: 识别失败。
        FileNotFoundError: 音频文件不存在。
    """
    path = Path(audio_path)
    if not path.exists():
        raise FileNotFoundError(f"音频文件不存在: {audio_path}")

    model = model or get_default_model("asr")

    try:
        # 读取音频文件并编码为 base64
        audio_data = path.read_bytes()
        audio_base64 = base64.b64encode(audio_data).decode("utf-8")

        # 根据文件扩展名推断格式
        suffix = path.suffix.lower().lstrip(".")
        mime_map = {
            "wav": "audio/wav",
            "mp3": "audio/mpeg",
            "mp4": "audio/mp4",
            "m4a": "audio/mp4",
            "flac": "audio/flac",
            "ogg": "audio/ogg",
            "webm": "audio/webm",
        }
        mime_type = mime_map.get(suffix, "audio/wav")

        file_url = f"data:{mime_type};base64,{audio_base64}"

        params = {
            "model": model,
            "file": file_url,
        }
        if language:
            params["language"] = language

        response = client.audio_transcription(**params)

        if hasattr(response, "text"):
            return response.text
        elif isinstance(response, dict):
            return response.get("text", str(response))
        else:
            return str(response)

    except GLMClientError:
        raise
    except Exception as e:
        raise GLMClientError(f"语音识别失败: {e}") from e


def transcribe_audio_url(
    audio_url: str,
    client: GLMClient,
    model: Optional[str] = None,
    language: Optional[str] = None,
) -> str:
    """将远程音频 URL 转换为文字。

    Args:
        audio_url: 音频文件 URL。
        client: GLM 客户端实例。
        model: ASR 模型名称。
        language: 可选的语言提示。

    Returns:
        识别出的文本。
    """
    model = model or get_default_model("asr")

    try:
        params = {
            "model": model,
            "file": audio_url,
        }
        if language:
            params["language"] = language

        response = client.audio_transcription(**params)

        if hasattr(response, "text"):
            return response.text
        elif isinstance(response, dict):
            return response.get("text", str(response))
        else:
            return str(response)

    except GLMClientError:
        raise
    except Exception as e:
        raise GLMClientError(f"语音识别失败: {e}") from e
