"""文本嵌入模块。"""

import math
from typing import List, Optional

from rich.console import Console

from ..client import GLMClient, GLMClientError
from ..config import get_default_model, AVAILABLE_EMBEDDING_MODELS

console = Console()


def create_embedding(
    text: str,
    client: GLMClient,
    model: Optional[str] = None,
) -> List[float]:
    """生成单个文本的嵌入向量。

    Args:
        text: 输入文本。
        client: GLM 客户端实例。
        model: 嵌入模型名称。

    Returns:
        嵌入向量（浮点数列表）。
    """
    model = model or get_default_model("embedding")

    try:
        response = client.create_embedding(
            model=model,
            input=[text],
        )

        if not response.data or len(response.data) == 0:
            raise GLMClientError("嵌入结果为空")

        return response.data[0].embedding

    except GLMClientError:
        raise
    except Exception as e:
        raise GLMClientError(f"嵌入生成失败: {e}") from e


def create_embeddings_batch(
    texts: List[str],
    client: GLMClient,
    model: Optional[str] = None,
) -> List[List[float]]:
    """批量生成文本嵌入向量。

    Args:
        texts: 输入文本列表。
        client: GLM 客户端实例。
        model: 嵌入模型名称。

    Returns:
        嵌入向量列表。
    """
    model = model or get_default_model("embedding")

    try:
        response = client.create_embedding(
            model=model,
            input=texts,
        )

        if not response.data:
            raise GLMClientError("嵌入结果为空")

        # 按 index 排序确保顺序一致
        sorted_data = sorted(response.data, key=lambda x: x.index)
        return [item.embedding for item in sorted_data]

    except GLMClientError:
        raise
    except Exception as e:
        raise GLMClientError(f"批量嵌入生成失败: {e}") from e


def compute_similarity(
    text_a: str,
    text_b: str,
    client: GLMClient,
    model: Optional[str] = None,
) -> float:
    """计算两段文本的余弦相似度。

    Args:
        text_a: 第一段文本。
        text_b: 第二段文本。
        client: GLM 客户端实例。
        model: 嵌入模型名称。

    Returns:
        余弦相似度（-1 到 1 之间的浮点数）。
    """
    embeddings = create_embeddings_batch([text_a, text_b], client, model)
    return _cosine_similarity(embeddings[0], embeddings[1])


def _cosine_similarity(a: List[float], b: List[float]) -> float:
    """计算两个向量的余弦相似度。"""
    dot_product = sum(x * y for x, y in zip(a, b))
    norm_a = math.sqrt(sum(x * x for x in a))
    norm_b = math.sqrt(sum(x * x for x in b))

    if norm_a == 0 or norm_b == 0:
        return 0.0

    return dot_product / (norm_a * norm_b)
