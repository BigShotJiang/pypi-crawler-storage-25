"""OCR 文字识别模块。

基于 GLM-4V-Flash 视觉模型，提供图片和 PDF 文件的文字识别能力。

支持的输入类型：
  - 本地图片文件（jpg/jpeg/png/gif/webp/bmp）
  - 图片 URL（http/https）
  - 本地 PDF 文件
  - PDF URL（自动下载后识别）

基础用法::

    from glm_client import GLMClient, ocr

    client = GLMClient()
    text = ocr("invoice.jpg", client=client)
    text = ocr("document.pdf", client=client)
    text = ocr("https://example.com/image.png", client=client)
"""

import base64
import tempfile
from pathlib import Path
from typing import Union, Optional, List

from rich.console import Console

from ..client import GLMClient, GLMClientError
from ..utils.helpers import encode_image_to_base64, validate_image_url, download_file

console = Console()

# 默认 OCR 识别 prompt
_DEFAULT_OCR_PROMPT = (
    "请仔细识别并完整提取这张图片中的所有文字内容。"
    "要求：\n"
    "1. 保持原始排版格式（段落、缩进、列表等）\n"
    "2. 准确输出识别到的文字，不要遗漏\n"
    "3. 如果有表格，使用 Markdown 表格格式输出\n"
    "4. 只输出识别到的文字，不要添加额外解释"
)

# 图片格式白名单
_IMAGE_EXTENSIONS = {".jpg", ".jpeg", ".png", ".gif", ".webp", ".bmp"}


def _is_pdf(source: str) -> bool:
    """判断输入源是否为 PDF 文件。"""
    return source.lower().endswith(".pdf")


def _is_url(source: str) -> bool:
    """判断输入源是否为 URL。"""
    return source.startswith(("http://", "https://"))


def _get_image_mime_type(path: str) -> str:
    """根据文件扩展名返回 MIME 类型。"""
    ext = Path(path).suffix.lower()
    mime_map = {
        ".jpg": "image/jpeg",
        ".jpeg": "image/jpeg",
        ".png": "image/png",
        ".gif": "image/gif",
        ".webp": "image/webp",
        ".bmp": "image/bmp",
    }
    return mime_map.get(ext, "image/jpeg")


def _convert_pdf_to_images(
    pdf_path: Union[str, Path],
    dpi: int = 200,
) -> List[tuple]:
    """将 PDF 文件的每一页转换为 PNG 图片字节。

    Args:
        pdf_path: PDF 文件路径。
        dpi: 渲染分辨率，默认 200。

    Returns:
        列表，每项为 (page_number, png_bytes) 元组。

    Raises:
        ImportError: 未安装 pymupdf。
        ValueError: PDF 文件无法读取。
    """
    try:
        import pymupdf
    except ImportError:
        raise ImportError(
            "PDF 文件识别需要 pymupdf 库。"
            "请运行：pip install pymupdf"
        )

    path = Path(pdf_path)
    if not path.exists():
        raise FileNotFoundError(f"PDF 文件不存在: {pdf_path}")

    try:
        doc = pymupdf.open(str(path))
    except Exception as e:
        raise ValueError(f"无法打开 PDF 文件: {e}") from e

    pages = []
    try:
        for page_num in range(len(doc)):
            page = doc[page_num]
            pix = page.get_pixmap(dpi=dpi)
            image_bytes = pix.tobytes("png")
            pages.append((page_num + 1, image_bytes))
    finally:
        doc.close()

    return pages


def _ocr_image_source(
    source: Union[str, Path],
    client: GLMClient,
    model: str,
    prompt: str,
    max_tokens: int,
    temperature: float,
) -> str:
    """对单张图片执行 OCR。

    支持本地文件路径、图片 URL 和 data URI。
    """
    source_str = str(source)

    # 构建 content
    content = [
        {"type": "text", "text": prompt},
    ]

    if _is_url(source_str):
        # 图片 URL 直接传入
        content.append({
            "type": "image_url",
            "image_url": {"url": source_str},
        })
    elif source_str.startswith("data:image/"):
        # data URI 直接传入
        content.append({
            "type": "image_url",
            "image_url": {"url": source_str},
        })
    else:
        # 本地图片文件 -> base64
        mime_type = _get_image_mime_type(source_str)
        b64 = encode_image_to_base64(source_str)
        content.append({
            "type": "image_url",
            "image_url": {"url": f"data:{mime_type};base64,{b64}"},
        })

    messages = [{"role": "user", "content": content}]

    params = {
        "model": model,
        "messages": messages,
        "temperature": temperature,
        "stream": False,
    }
    if max_tokens:
        params["max_tokens"] = max_tokens

    response = client.chat_completion(**params)

    if response.choices and len(response.choices) > 0:
        return response.choices[0].message.content

    return ""


def ocr(
    source: Union[str, Path],
    client: GLMClient,
    model: str = "glm-4v-flash",
    prompt: Optional[str] = None,
    max_tokens: int = 4096,
    temperature: float = 0.1,
    dpi: int = 200,
    page_separator: str = "\n\n--- 第 {page} 页 ---\n\n",
    verbose: bool = False,
) -> str:
    """识别图片或 PDF 文件中的文字。

    自动检测输入类型并选择合适的处理方式：
    - 图片文件/URL：直接发送到视觉模型进行 OCR
    - PDF 文件/URL：将每页渲染为图片后逐页 OCR

    Args:
        source: 输入源，支持以下类型：
            - 本地图片路径：``"photo.jpg"``
            - 本地 PDF 路径：``"document.pdf"``
            - 图片 URL：``"https://example.com/img.png"``
            - PDF URL：``"https://example.com/doc.pdf"``
        client: GLMClient 实例。
        model: 视觉模型名称，默认 ``glm-4v-flash``（免费）。
        prompt: 自定义 OCR 提示词。默认为通用 OCR prompt。
        max_tokens: 最大输出 token 数，默认 4096。
        temperature: 采样温度，默认 0.1（低温度保证识别准确性）。
        dpi: PDF 渲染分辨率（仅 PDF 有效），默认 200。
        page_separator: PDF 多页分隔符模板，``{page}`` 会被替换为页码。
            设为空字符串可去除分隔符。
        verbose: 是否显示处理进度。

    Returns:
        识别到的文字内容。PDF 文件会合并所有页面的结果。

    Raises:
        FileNotFoundError: 文件不存在。
        ImportError: PDF 处理需要 pymupdf。
        GLMClientError: API 请求失败。

    Examples::

        from glm_client import GLMClient, ocr

        client = GLMClient()

        # 识别本地图片
        text = ocr("invoice.jpg", client=client)

        # 识别 PDF 文件
        text = ocr("contract.pdf", client=client)

        # 识别网络图片
        text = ocr("https://example.com/screenshot.png", client=client)
    """
    source_str = str(source)
    effective_prompt = prompt or _DEFAULT_OCR_PROMPT

    # ---- PDF 处理 ----
    if _is_pdf(source_str):
        pdf_path = source_str

        # 远程 PDF：先下载到临时文件
        if _is_url(source_str):
            if verbose:
                console.print(f"[cyan]下载 PDF: {source_str}[/cyan]")
            with tempfile.NamedTemporaryFile(suffix=".pdf", delete=False) as tmp:
                pdf_path = str(download_file(source_str, tmp.name, show_progress=verbose))

        # 转换 PDF 每页为图片
        pages = _convert_pdf_to_images(pdf_path, dpi=dpi)

        if not pages:
            return ""

        if verbose:
            console.print(f"[cyan]共 {len(pages)} 页，开始逐页识别...[/cyan]")

        results = []
        for page_num, image_bytes in pages:
            if verbose:
                console.print(f"[cyan]  识别第 {page_num}/{len(pages)} 页...[/cyan]")

            # 将 PNG 字节编码为 data URI
            b64 = base64.b64encode(image_bytes).decode("utf-8")
            data_uri = f"data:image/png;base64,{b64}"

            text = _ocr_image_source(
                source=data_uri,
                client=client,
                model=model,
                prompt=effective_prompt,
                max_tokens=max_tokens,
                temperature=temperature,
            )

            if page_separator and len(pages) > 1:
                results.append(page_separator.format(page=page_num) + text)
            else:
                results.append(text)

        return "".join(results)

    # ---- 图片处理 ----
    return _ocr_image_source(
        source=source_str,
        client=client,
        model=model,
        prompt=effective_prompt,
        max_tokens=max_tokens,
        temperature=temperature,
    )


def ocr_batch(
    sources: List[Union[str, Path]],
    client: GLMClient,
    model: str = "glm-4v-flash",
    prompt: Optional[str] = None,
    max_tokens: int = 4096,
    temperature: float = 0.1,
    verbose: bool = False,
) -> List[str]:
    """批量识别多个图片或 PDF 文件。

    Args:
        sources: 输入源列表，每个元素支持的类型与 :func:`ocr` 相同。
        client: GLMClient 实例。
        model: 视觉模型名称。
        prompt: 自定义 OCR 提示词。
        max_tokens: 最大输出 token 数。
        temperature: 采样温度。
        verbose: 是否显示处理进度。

    Returns:
        识别结果列表，与输入列表一一对应。识别失败的项返回空字符串。

    Examples::

        from glm_client import GLMClient, ocr_batch

        client = GLMClient()
        results = ocr_batch(
            ["page1.jpg", "page2.jpg", "page3.jpg"],
            client=client,
        )
        for path, text in zip(["page1.jpg", "page2.jpg", "page3.jpg"], results):
            print(f"--- {path} ---")
            print(text)
    """
    results = []

    for i, source in enumerate(sources):
        if verbose:
            console.print(f"[cyan]处理文件 {i + 1}/{len(sources)}: {source}[/cyan]")

        try:
            text = ocr(
                source=source,
                client=client,
                model=model,
                prompt=prompt,
                max_tokens=max_tokens,
                temperature=temperature,
                verbose=verbose,
            )
            results.append(text)
        except GLMClientError as e:
            console.print(f"[red]识别失败 ({source}): {e}[/red]")
            results.append("")
        except (FileNotFoundError, ImportError, ValueError) as e:
            console.print(f"[red]文件错误 ({source}): {e}[/red]")
            results.append("")

    return results
