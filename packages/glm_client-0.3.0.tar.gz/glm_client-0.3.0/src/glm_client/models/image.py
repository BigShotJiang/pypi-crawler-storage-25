"""图像生成模块。"""

from pathlib import Path
from typing import Union, Optional, List

from rich.console import Console

from ..client import GLMClient, GLMClientError
from ..config import get_default_model, AVAILABLE_IMAGE_MODELS, DEFAULT_IMAGE_SIZE, IMAGE_SIZES, get_output_dir
from ..utils.helpers import download_file, format_timestamp, get_safe_filename

console = Console()


def generate_image(
    prompt: str,
    client: GLMClient,
    model: Optional[str] = None,
    size: str = DEFAULT_IMAGE_SIZE,
    n: int = 1,
) -> List[str]:
    """Generate images using GLM image model.

    Args:
        prompt: Description of the image to generate.
        client: GLM client instance.
        model: Model name to use. Defaults to cogview-3-flash.
        size: Image size (e.g., "1024x1024", "768x1344").
        n: Number of images to generate.

    Returns:
        List of image URLs.

    Raises:
        GLMClientError: If the API request fails.
        ValueError: If size or n is invalid.
    """
    model = model or get_default_model("image")

    if model not in AVAILABLE_IMAGE_MODELS:
        console.print(f"[yellow]Warning: Model '{model}' is not in the known list. Attempting anyway.[/yellow]")

    if size not in IMAGE_SIZES:
        raise ValueError(
            f"Invalid size: {size}. "
            f"Available sizes: {', '.join(IMAGE_SIZES)}"
        )

    if n < 1 or n > 4:
        raise ValueError("Number of images (n) must be between 1 and 4")

    try:
        response = client.image_generation(
            model=model,
            prompt=prompt,
            size=size,
        )

        if not response.data:
            raise GLMClientError("No images returned from API")

        urls = [item.url for item in response.data[:n]]
        return urls

    except Exception as e:
        raise GLMClientError(f"Image generation failed: {e}") from e


def download_generated_images(
    urls: List[str],
    output_dir: Optional[Union[str, Path]] = None,
    prompt: Optional[str] = None,
    show_progress: bool = True,
) -> List[Path]:
    """Download generated images from URLs.

    Args:
        urls: List of image URLs to download.
        output_dir: Directory to save images. Defaults to "output/".
        prompt: Original prompt for filename generation.
        show_progress: Whether to show download progress.

    Returns:
        List of downloaded file paths.
    """
    output_dir = Path(output_dir) if output_dir else get_output_dir()
    output_dir.mkdir(parents=True, exist_ok=True)

    downloaded_paths = []

    for i, url in enumerate(urls):
        # Generate filename
        if prompt:
            base_name = get_safe_filename(prompt)
            filename = f"{base_name}_{i + 1}.png"
        else:
            timestamp = format_timestamp()
            filename = f"generated_{timestamp}_{i + 1}.png"

        output_path = output_dir / filename

        try:
            downloaded_path = download_file(url, output_path, show_progress=show_progress)
            downloaded_paths.append(downloaded_path)
            console.print(f"[green]Saved: {downloaded_path}[/green]")

        except Exception as e:
            console.print(f"[red]Failed to download image {i + 1}: {e}[/red]")

    return downloaded_paths


def generate_and_save(
    prompt: str,
    client: GLMClient,
    output: Optional[Union[str, Path]] = None,
    model: Optional[str] = None,
    size: str = DEFAULT_IMAGE_SIZE,
    n: int = 1,
    show_progress: bool = True,
) -> List[Path]:
    """Generate images and save them to disk.

    Args:
        prompt: Description of the image to generate.
        client: GLM client instance.
        output: Output file or directory path.
                If a file path with extension, saves to that file (only for n=1).
                If a directory path, saves to that directory.
                If None, saves to "output/" directory.
        model: Model name to use.
        size: Image size.
        n: Number of images to generate.
        show_progress: Whether to show download progress.

    Returns:
        List of saved image file paths.
    """
    console.print(f"[cyan]Generating {n} image(s)...[/cyan]")

    urls = generate_image(prompt, client, model, size, n)

    # Determine output location
    if output:
        output_path = Path(output)
        if output_path.suffix:
            # It's a file path
            if n > 1:
                console.print("[yellow]Warning: Multiple images requested, output will be a directory.[/yellow]")
                output_dir = output_path.parent
            else:
                output_dir = output_path.parent
                # For single image, use the exact filename
                downloaded = download_file(urls[0], output_path, show_progress=show_progress)
                console.print(f"[green]Saved: {downloaded}[/green]")
                return [downloaded]
        else:
            # It's a directory path
            output_dir = output_path
    else:
        output_dir = None

    return download_generated_images(urls, output_dir, prompt, show_progress)


def get_image_info(url: str) -> dict:
    """Get information about an image from URL.

    Args:
        url: Image URL.

    Returns:
        Dictionary with image information (dimensions, format, etc.).
    """
    import httpx
    from io import BytesIO
    from PIL import Image

    try:
        response = httpx.get(url, timeout=30.0, follow_redirects=True)
        response.raise_for_status()

        img = Image.open(BytesIO(response.content))

        return {
            "format": img.format,
            "mode": img.mode,
            "size": img.size,
            "width": img.width,
            "height": img.height,
        }

    except Exception as e:
        console.print(f"[yellow]Warning: Could not get image info: {e}[/yellow]")
        return {}
