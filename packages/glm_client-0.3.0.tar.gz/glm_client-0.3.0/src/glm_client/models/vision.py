"""视觉理解模块。"""

from pathlib import Path
from typing import Union, List, Optional, Dict

from rich.console import Console

from ..client import GLMClient, GLMClientError
from ..config import get_default_model, AVAILABLE_VISION_MODELS
from ..utils.helpers import encode_image_to_base64, validate_image_url

console = Console()


def create_vision_messages(
    prompt: str,
    image: Union[str, Path],
    system: Optional[str] = None,
) -> List[Dict]:
    """Create messages list for vision understanding.

    Args:
        prompt: Text prompt/question about the image.
        image: Path to image file or image URL.
        system: Optional system message.

    Returns:
        List of message dictionaries with image content.

    Raises:
        FileNotFoundError: If image file doesn't exist.
        ValueError: If image format is invalid.
    """
    image_path = str(image)
    is_url = validate_image_url(image_path)
    is_data_uri = image_path.startswith("data:image/")

    # Build content array
    content = [
        {"type": "text", "text": prompt},
    ]

    if is_url or is_data_uri:
        # Use image URL or data URI directly
        content.append({
            "type": "image_url",
            "image_url": {"url": image_path}
        })
    else:
        # Encode local image to base64
        try:
            base64_image = encode_image_to_base64(image_path)
            content.append({
                "type": "image_url",
                "image_url": {"url": f"data:image/jpeg;base64,{base64_image}"}
            })
        except (FileNotFoundError, ValueError) as e:
            raise e

    # Build messages list
    messages = []

    if system:
        messages.append({"role": "system", "content": system})

    messages.append({
        "role": "user",
        "content": content
    })

    return messages


def vision_completion(
    prompt: str,
    image: Union[str, Path],
    client: GLMClient,
    model: Optional[str] = None,
    system: Optional[str] = None,
    temperature: float = 0.7,
    max_tokens: Optional[int] = None,
) -> str:
    """Analyze an image using GLM vision model.

    Args:
        prompt: Question or instruction for the image analysis.
        image: Path to image file or image URL.
        client: GLM client instance.
        model: Model name to use. Defaults to glm-4v-flash.
        system: Optional system message.
        temperature: Sampling temperature (0-2).
        max_tokens: Maximum tokens to generate.

    Returns:
        Vision analysis response text.

    Raises:
        GLMClientError: If the API request fails.
        FileNotFoundError: If image file doesn't exist.
        ValueError: If image format is invalid.
    """
    model = model or get_default_model("vision")

    if model not in AVAILABLE_VISION_MODELS:
        console.print(f"[yellow]Warning: Model '{model}' is not in the known list. Attempting anyway.[/yellow]")

    try:
        messages = create_vision_messages(prompt, image, system)

        params = {
            "model": model,
            "messages": messages,
            "temperature": temperature,
            "stream": False,  # Vision doesn't support streaming
        }

        if max_tokens is not None:
            params["max_tokens"] = max_tokens

        response = client.chat_completion(**params)

        if response.choices and len(response.choices) > 0:
            return response.choices[0].message.content

        return ""

    except (FileNotFoundError, ValueError):
        raise
    except Exception as e:
        raise GLMClientError(f"Vision completion failed: {e}") from e


def batch_vision_analysis(
    prompts: List[str],
    image: Union[str, Path],
    client: GLMClient,
    model: Optional[str] = None,
    system: Optional[str] = None,
) -> List[str]:
    """Analyze an image with multiple prompts.

    Args:
        prompts: List of questions/prompts for the image.
        image: Path to image file or image URL.
        client: GLM client instance.
        model: Model name to use.
        system: Optional system message.

    Returns:
        List of vision analysis responses.
    """
    results = []

    for i, prompt in enumerate(prompts):
        console.print(f"[cyan]Processing prompt {i + 1}/{len(prompts)}...[/cyan]")

        try:
            response = vision_completion(
                prompt=prompt,
                image=image,
                client=client,
                model=model,
                system=system,
            )
            results.append(response)

        except GLMClientError as e:
            console.print(f"[red]Error processing prompt '{prompt}': {e}[/red]")
            results.append("")

    return results


def compare_images(
    prompt: str,
    images: List[Union[str, Path]],
    client: GLMClient,
    model: Optional[str] = None,
) -> str:
    """Compare multiple images using vision model.

    Args:
        prompt: Question asking to compare the images.
        images: List of image paths or URLs.
        client: GLM client instance.
        model: Model name to use.

    Returns:
        Comparison response.

    Raises:
        GLMClientError: If the API request fails.
    """
    model = model or get_default_model("vision")

    # Build content with multiple images
    content = [{"type": "text", "text": prompt}]

    for image in images:
        image_path = str(image)
        is_url = validate_image_url(image_path)

        if is_url:
            content.append({
                "type": "image_url",
                "image_url": {"url": image_path}
            })
        else:
            base64_image = encode_image_to_base64(image_path)
            content.append({
                "type": "image_url",
                "image_url": {"url": f"data:image/jpeg;base64,{base64_image}"}
            })

    messages = [{
        "role": "user",
        "content": content
    }]

    try:
        response = client.chat_completion(
            model=model,
            messages=messages,
            stream=False,
        )

        if response.choices and len(response.choices) > 0:
            return response.choices[0].message.content

        return ""

    except Exception as e:
        raise GLMClientError(f"Image comparison failed: {e}") from e
