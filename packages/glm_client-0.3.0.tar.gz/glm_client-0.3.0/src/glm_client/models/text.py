"""文本生成模块。"""

from typing import Any, Dict, Generator, List, Optional, Union

from rich.console import Console
from rich.text import Text

from ..client import GLMClient, GLMClientError
from ..config import get_default_model, AVAILABLE_TEXT_MODELS

console = Console()


def create_messages(
    prompt: str,
    system: Optional[str] = None,
    history: Optional[List[Dict[str, str]]] = None,
) -> List[Dict[str, str]]:
    """Create messages list for chat completion.

    Args:
        prompt: User prompt.
        system: Optional system message.
        history: Optional conversation history.

    Returns:
        List of message dictionaries.
    """
    messages = []

    # Add system message if provided
    if system:
        messages.append({"role": "system", "content": system})

    # Add conversation history if provided
    if history:
        messages.extend(history)

    # Add current user prompt
    messages.append({"role": "user", "content": prompt})

    return messages


def chat_completion(
    prompt: str,
    client: GLMClient,
    model: Optional[str] = None,
    system: Optional[str] = None,
    history: Optional[List[Dict[str, str]]] = None,
    stream: bool = True,
    temperature: float = 0.7,
    max_tokens: Optional[int] = None,
    top_p: float = 0.9,
    thinking: bool = False,
    web_search: bool = False,
    tools: Optional[List[Dict[str, Any]]] = None,
) -> Union[str, Generator[str, None, None]]:
    """生成聊天补全。

    Args:
        prompt: 用户提示词。
        client: GLM 客户端实例。
        model: 模型名称。默认 glm-4.7-flash。
        system: 可选系统消息。
        history: 可选对话历史。
        stream: 是否流式响应。
        temperature: 采样温度 (0-2)。
        max_tokens: 最大生成 token 数。
        top_p: 核采样参数 (0-1)。
        thinking: 是否启用思考模式（需要支持思考的模型如 glm-4.7）。
        web_search: 是否启用联网搜索。
        tools: 可选的工具列表（函数调用）。

    Returns:
        stream=True 时返回生成器，否则返回完整文本。
    """
    model = model or get_default_model("text")

    if model not in AVAILABLE_TEXT_MODELS:
        console.print(f"[yellow]Warning: Model '{model}' is not in the known list. Attempting anyway.[/yellow]")

    messages = create_messages(prompt, system, history)

    params = {
        "model": model,
        "messages": messages,
        "temperature": temperature,
        "top_p": top_p,
        "stream": stream,
    }

    if max_tokens is not None:
        params["max_tokens"] = max_tokens

    if thinking:
        params["thinking"] = {"type": "enabled"}

    if web_search:
        params.setdefault("tools", [])
        params["tools"].append({
            "type": "web_search",
            "web_search": {"search_result": True},
        })

    if tools:
        params.setdefault("tools", [])
        params["tools"].extend(tools)

    if stream:
        return _stream_response(client, params)
    else:
        return _get_complete_response(client, params)


def _stream_response(
    client: GLMClient,
    params: Dict,
) -> Generator[str, None, None]:
    """流式聊天补全响应。"""
    try:
        response = client.chat_completion(**params)

        for chunk in response:
            if chunk.choices and len(chunk.choices) > 0:
                delta = chunk.choices[0].delta
                if hasattr(delta, "content") and delta.content:
                    yield delta.content

    except Exception as e:
        raise GLMClientError(f"流式响应失败: {e}") from e


def stream_thinking_response(
    client: GLMClient,
    params: Dict,
) -> Generator[Dict[str, str], None, None]:
    """流式思考模式响应，同时输出思考过程和最终回答。

    Yields:
        包含 "type"（thinking/content）和 "text" 的字典。
    """
    try:
        response = client.chat_completion(**params)

        for chunk in response:
            if chunk.choices and len(chunk.choices) > 0:
                delta = chunk.choices[0].delta
                if hasattr(delta, "reasoning_content") and delta.reasoning_content:
                    yield {"type": "thinking", "text": delta.reasoning_content}
                if hasattr(delta, "content") and delta.content:
                    yield {"type": "content", "text": delta.content}

    except Exception as e:
        raise GLMClientError(f"流式思考响应失败: {e}") from e


def _get_complete_response(
    client: GLMClient,
    params: Dict,
) -> str:
    """获取完整聊天补全响应（非流式）。"""
    params["stream"] = False

    try:
        response = client.chat_completion(**params)

        if response.choices and len(response.choices) > 0:
            return response.choices[0].message.content

        return ""

    except Exception as e:
        raise GLMClientError(f"聊天补全失败: {e}") from e


def print_streaming_response(generator: Generator[str, None, None]) -> str:
    """将流式响应打印到控制台。"""
    full_response = ""
    live = Text()

    with console.screen() as screen:
        for chunk in generator:
            full_response += chunk
            live.append(chunk)
            screen.update(live)

    # Print final response with proper formatting
    console.print()

    return full_response


def stream_to_console(generator: Generator[str, None, None]) -> str:
    """实时流式输出到控制台。"""
    full_response = ""

    for chunk in generator:
        full_response += chunk
        console.print(chunk, end="")

    console.print()  # New line after completion

    return full_response


def get_response_text(response: Union[str, Generator]) -> str:
    """从字符串或生成器获取完整响应文本。"""
    if isinstance(response, str):
        return response

    # It's a generator, consume it
    return "".join(response)
