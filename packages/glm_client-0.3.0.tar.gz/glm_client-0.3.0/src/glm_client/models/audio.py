"""Audio/Text-to-Speech module for GLM API.

Uses the GLM-TTS model via ZhipuAI API.

References:
- https://docs.bigmodel.cn/cn/guide/models/sound-and-video/glm-tts
"""

import os
import tempfile
from pathlib import Path
from typing import Union, Optional, List

import httpx
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn, TaskProgressColumn

from ..client import GLMClient, GLMClientError
from ..config import (
    get_output_dir,
    DEFAULT_TTS_VOICE,
    DEFAULT_TTS_FORMAT,
    DEFAULT_TTS_SPEED,
    DEFAULT_TTS_VOLUME,
    TTS_VOICES,
)

console = Console()


# TTS API endpoint
TTS_API_URL = "https://open.bigmodel.cn/api/paas/v4/audio/speech"


def text_to_speech(
    text: str,
    client: GLMClient,
    voice: str = DEFAULT_TTS_VOICE,
    output: Optional[Union[str, Path]] = None,
    response_format: str = DEFAULT_TTS_FORMAT,
    speed: float = DEFAULT_TTS_SPEED,
    volume: float = DEFAULT_TTS_VOLUME,
) -> Path:
    """Convert text to speech using GLM-TTS.

    Args:
        text: Text to convert to speech.
        client: GLM client instance.
        voice: Voice to use (female, chen, cuicui, jam, kazi, douji, luodo).
        output: Output file path. If None, uses default naming.
        response_format: Audio format (mp3, wav, pcm).
        speed: Speech speed multiplier (0.5 - 2.0, default 1.0).
        volume: Volume multiplier (0.5 - 2.0, default 1.0).

    Returns:
        Path to the generated audio file.

    Raises:
        GLMClientError: If TTS generation fails.
        ValueError: If voice is not supported.
    """
    # Try SDK method first
    try:
        return _tts_with_sdk(text, client, voice, output, response_format, speed, volume)
    except AttributeError as e:
        # SDK method not available, fall back to direct HTTP request
        console.print(f"[yellow]SDK method failed: {e}. Using direct HTTP request.[/yellow]")
        return _tts_with_http(text, client.config.api_key, voice, output, response_format, speed, volume)


def _tts_with_sdk(
    text: str,
    client: GLMClient,
    voice: str,
    output: Optional[Union[str, Path]] = None,
    response_format: str = DEFAULT_TTS_FORMAT,
    speed: float = DEFAULT_TTS_SPEED,
    volume: float = DEFAULT_TTS_VOLUME,
) -> Path:
    """Use SDK method for TTS.

    Note: The current SDK version only supports wav and pcm formats.
    encode_format must be "base64" according to the official documentation.

    Args:
        text: Text to convert.
        client: GLM client.
        voice: Voice to use.
        output: Output file path.
        response_format: Audio format (wav or pcm).
        speed: Speech speed multiplier (ignored in SDK mode).
        volume: Volume multiplier (ignored in SDK mode).

    Returns:
        Path to generated audio file.

    Raises:
        GLMClientError: If TTS generation fails.
    """
    try:
        # Get the ZhipuAI client instance
        zhipuai_client = client.client

        # SDK only supports wav and pcm formats
        if response_format == "mp3":
            console.print("[yellow]Note: SDK does not support mp3 format. Falling back to wav format.[/yellow]")
            response_format = "wav"

        # Based on official docs, encode_format should be "base64"
        # This applies to both streaming and non-streaming calls
        encode_format = "base64"

        # Call the audio.speech method
        response = zhipuai_client.audio.speech(
            model="glm-tts",
            input=text,
            voice=voice,
            response_format=response_format,
            encode_format=encode_format,
        )

        output_path = _get_output_path(output, text, response_format)
        output_path.parent.mkdir(parents=True, exist_ok=True)

        # The response might be base64 encoded when using encode_format="base64"
        # Check if response.content is text (JSON) or binary
        content = response.content

        # If the response is text (JSON with base64 content), decode it
        if isinstance(content, bytes) and content.startswith(b'{'):
            import json
            import base64
            data = json.loads(content.decode('utf-8'))
            if 'data' in data or 'content' in data or 'choices' in data:
                # Extract base64 audio data from response
                if 'choices' in data and len(data['choices']) > 0:
                    audio_base64 = data['choices'][0].get('delta', {}).get('content', '')
                elif 'content' in data:
                    audio_base64 = data['content']
                elif 'data' in data:
                    audio_base64 = data['data']
                else:
                    raise GLMClientError(f"Unexpected response format: {data}")

                audio_bytes = base64.b64decode(audio_base64)
                with open(output_path, "wb") as f:
                    f.write(audio_bytes)

                console.print(f"[green]Audio saved: {output_path} ({len(audio_bytes)} bytes)[/green]")
                return output_path
        else:
            # Direct binary content
            with open(output_path, "wb") as f:
                f.write(content)

            console.print(f"[green]Audio saved: {output_path} ({len(content)} bytes)[/green]")
            return output_path

    except Exception as e:
        raise GLMClientError(f"TTS generation failed: {e}") from e


def _tts_with_http(
    text: str,
    api_key: str,
    voice: str,
    output: Optional[Union[str, Path]] = None,
    response_format: str = DEFAULT_TTS_FORMAT,
    speed: float = DEFAULT_TTS_SPEED,
    volume: float = DEFAULT_TTS_VOLUME,
) -> Path:
    """Use direct HTTP request for TTS.

    Args:
        text: Text to convert.
        api_key: ZhipuAI API key.
        voice: Voice to use.
        output: Output file path.
        response_format: Audio format.
        speed: Speech speed multiplier.
        volume: Volume multiplier.

    Returns:
        Path to generated audio file.

    Raises:
        GLMClientError: If TTS generation fails.
    """
    output_path = _get_output_path(output, text, response_format)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    try:
        with httpx.Client(timeout=120.0) as http_client:
            response = http_client.post(
                TTS_API_URL,
                headers={
                    "Authorization": f"Bearer {api_key}",
                    "Content-Type": "application/json",
                },
                json={
                    "model": "glm-tts",
                    "input": text,
                    "voice": voice,
                    "response_format": response_format,
                    "speed": speed,
                    "volume": volume,
                },
            )

            # Check response status
            if response.status_code == 401:
                raise GLMClientError("Authentication failed. Check your API key.")
            elif response.status_code == 429:
                raise GLMClientError("Rate limit exceeded. Please try again later.")
            elif response.status_code == 400:
                error_detail = response.text
                raise GLMClientError(f"Bad request: {error_detail}")

            response.raise_for_status()

            # Check if response contains audio content
            content_type = response.headers.get("content-type", "")
            if "audio" not in content_type.lower() and len(response.content) < 100:
                # Response is too small to be audio, might be an error message
                raise GLMClientError(f"Invalid response: {response.text}")

            # Save audio content
            with open(output_path, "wb") as f:
                f.write(response.content)

            console.print(f"[green]Audio saved: {output_path} ({len(response.content)} bytes)[/green]")
            return output_path

    except GLMClientError:
        raise
    except httpx.HTTPStatusError as e:
        raise GLMClientError(f"TTS request failed: {e.response.status_code} - {e.response.text}") from e
    except Exception as e:
        raise GLMClientError(f"TTS generation failed: {e}") from e


def _get_output_path(
    output: Optional[Union[str, Path]],
    text: str,
    response_format: str = DEFAULT_TTS_FORMAT
) -> Path:
    """Get the output file path for TTS audio.

    Args:
        output: Specified output path or None.
        text: Input text for default filename generation.
        response_format: Audio format for file extension.

    Returns:
        Path to output file.
    """
    if output:
        return Path(output)

    # Generate default filename
    output_dir = get_output_dir()
    from ..utils.helpers import format_timestamp, get_safe_filename

    safe_text = get_safe_filename(text[:30])
    timestamp = format_timestamp()
    filename = f"{safe_text}_{timestamp}.{response_format}"

    return output_dir / filename


def list_voices() -> list:
    """List available TTS voices.

    Returns:
        List of voice names.
    """
    return TTS_VOICES.copy()


def get_voice_info(voice: str) -> dict:
    """Get information about a TTS voice.

    Args:
        voice: Voice name.

    Returns:
        Dictionary with voice information.
    """
    # GLM-TTS voice information (based on official docs)
    voice_info = {
        "female": {"name": "彤彤", "gender": "女声", "description": "默认女声音色"},
        "chen": {"name": "小陈", "gender": "男声", "description": "男声音色"},
        "cuicui": {"name": "锤锤", "gender": "女声", "description": "活泼女声"},
        "jam": {"name": "jam", "gender": "男声", "description": "英文男声"},
        "kazi": {"name": "kazi", "gender": "男声", "description": "英文男声"},
        "douji": {"name": "douji", "gender": "男声", "description": "英文男声"},
        "luodo": {"name": "luodo", "gender": "女声", "description": "英文女声"},
    }

    return voice_info.get(voice, {"name": voice, "description": "Unknown or custom voice"})


# Constants for Word document processing
MAX_TTS_LENGTH = 4000  # Maximum characters per TTS request (safe limit)
CHUNK_OVERLAP = 100  # Overlap between chunks to maintain continuity


def extract_text_from_word(word_path: Union[str, Path]) -> str:
    """Extract text content from a Word document.

    Args:
        word_path: Path to the Word document (.docx).

    Returns:
        Extracted text content.

    Raises:
        GLMClientError: If document reading fails.
    """
    try:
        from docx import Document

        doc_path = Path(word_path)
        if not doc_path.exists():
            raise GLMClientError(f"File not found: {word_path}")

        if doc_path.suffix.lower() not in ('.docx', '.doc'):
            raise GLMClientError(f"Unsupported file format: {doc_path.suffix}. Please use .docx files.")

        doc = Document(doc_path)

        # Extract text from paragraphs
        text_parts = []
        for paragraph in doc.paragraphs:
            if paragraph.text.strip():
                text_parts.append(paragraph.text)

        # Extract text from tables
        for table in doc.tables:
            for row in table.rows:
                for cell in row.cells:
                    if cell.text.strip():
                        text_parts.append(cell.text)

        full_text = '\n\n'.join(text_parts)

        if not full_text.strip():
            raise GLMClientError(f"No text content found in document: {word_path}")

        console.print(f"[dim]Extracted {len(full_text)} characters from Word document[/dim]")
        return full_text

    except ImportError:
        raise GLMClientError("python-docx is required to read Word documents. Install it with: pip install python-docx")
    except Exception as e:
        raise GLMClientError(f"Failed to read Word document: {e}") from e


def split_text_for_tts(text: str, max_length: int = MAX_TTS_LENGTH) -> List[str]:
    """Split text into chunks suitable for TTS processing.

    Args:
        text: Input text to split.
        max_length: Maximum length per chunk.

    Returns:
        List of text chunks.
    """
    if len(text) <= max_length:
        return [text]

    chunks = []
    current_chunk = ""
    sentences = text.replace('\n\n', '\n').split('\n')

    for sentence in sentences:
        sentence = sentence.strip()
        if not sentence:
            continue

        # If a single sentence is too long, split by punctuation
        if len(sentence) > max_length:
            # Split long sentence by punctuation
            parts = []
            current = ""
            for char in sentence:
                current += char
                if char in '。！？.!?,，？!':
                    if len(current) > 0:
                        parts.append(current.strip())
                        current = ""
            if current:
                parts.append(current.strip())

            for part in parts:
                if len(part) > max_length:
                    # Force split very long parts
                    for i in range(0, len(part), max_length - CHUNK_OVERLAP):
                        chunk_part = part[i:i + max_length]
                        if i > 0 and len(chunk_part) > CHUNK_OVERLAP:
                            chunks.append(current_chunk)
                            current_chunk = chunk_part
                        else:
                            if current_chunk:
                                current_chunk += " " + chunk_part
                            else:
                                current_chunk = chunk_part
                else:
                    if len(current_chunk) + len(part) + 1 > max_length:
                        if current_chunk:
                            chunks.append(current_chunk)
                        current_chunk = part
                    else:
                        if current_chunk:
                            current_chunk += " " + part
                        else:
                            current_chunk = part
        else:
            if len(current_chunk) + len(sentence) + 2 > max_length:
                if current_chunk:
                    chunks.append(current_chunk)
                current_chunk = sentence
            else:
                if current_chunk:
                    current_chunk += "\n\n" + sentence
                else:
                    current_chunk = sentence

    if current_chunk:
        chunks.append(current_chunk)

    return chunks


def merge_audio_files(audio_files: List[Path], output_path: Path) -> Path:
    """Merge multiple audio files into a single file.

    Args:
        audio_files: List of audio file paths to merge.
        output_path: Output file path for merged audio.

    Returns:
        Path to the merged audio file.

    Raises:
        GLMClientError: If merging fails.
    """
    if not audio_files:
        raise GLMClientError("No audio files to merge")

    if len(audio_files) == 1:
        # No merging needed
        import shutil
        shutil.copy(audio_files[0], output_path)
        return output_path

    try:
        from pydub import AudioSegment

        # Determine file format from extension
        format_name = output_path.suffix[1:].lower()

        # Load and concatenate all audio files
        console.print(f"[dim]Merging {len(audio_files)} audio segments...[/dim]")

        combined = AudioSegment.empty()
        for i, audio_file in enumerate(audio_files):
            console.print(f"[dim]  Processing segment {i + 1}/{len(audio_files)}...[/dim]")
            audio = AudioSegment.from_file(audio_file)
            # Add a small pause between segments (100ms of silence)
            if i > 0:
                silence = AudioSegment.silent(duration=100)
                combined += silence
            combined += audio

        # Export the merged audio
        combined.export(str(output_path), format=format_name)

        console.print(f"[green]Merged audio saved: {output_path}[/green]")
        return output_path

    except ImportError:
        # Fallback: use ffmpeg directly if available
        console.print("[yellow]pydub not available, trying ffmpeg...[/yellow]")
        return _merge_with_ffmpeg(audio_files, output_path)
    except Exception as e:
        raise GLMClientError(f"Failed to merge audio files: {e}") from e


def _merge_with_ffmpeg(audio_files: List[Path], output_path: Path) -> Path:
    """Merge audio files using ffmpeg command line.

    Args:
        audio_files: List of audio file paths.
        output_path: Output file path.

    Returns:
        Path to merged audio file.

    Raises:
        GLMClientError: If ffmpeg is not available or merging fails.
    """
    import subprocess
    import shutil

    # Check if ffmpeg is available
    if not shutil.which("ffmpeg"):
        raise GLMClientError(
            "pydub and ffmpeg are required to merge multiple audio files. "
            "Install them with: pip install pydub and install ffmpeg from https://ffmpeg.org/"
        )

    try:
        # Create a file list for ffmpeg concat demuxer
        list_file = tempfile.NamedTemporaryFile(mode='w', suffix='.txt', delete=False)
        try:
            for audio_file in audio_files:
                # Use absolute paths and escape special characters
                abs_path = str(audio_file.resolve()).replace('\\', '/')
                list_file.write(f"file '{abs_path}'\n")
            list_file.close()

            # Run ffmpeg concat command
            subprocess.run(
                [
                    "ffmpeg", "-y", "-f", "concat", "-safe", "0",
                    "-i", list_file.name,
                    "-c", "copy",
                    str(output_path)
                ],
                check=True,
                capture_output=True
            )

            console.print(f"[green]Merged audio saved: {output_path}[/green]")
            return output_path
        finally:
            os.unlink(list_file.name)

    except subprocess.CalledProcessError as e:
        raise GLMClientError(f"ffmpeg failed: {e.stderr.decode() if e.stderr else str(e)}") from e
    except Exception as e:
        raise GLMClientError(f"Failed to merge audio with ffmpeg: {e}") from e


def word_to_speech(
    word_path: Union[str, Path],
    client: GLMClient,
    voice: str = DEFAULT_TTS_VOICE,
    output: Optional[Union[str, Path]] = None,
    response_format: str = DEFAULT_TTS_FORMAT,
    speed: float = DEFAULT_TTS_SPEED,
    volume: float = DEFAULT_TTS_VOLUME,
) -> Path:
    """Convert a Word document to speech.

    Extracts text from the Word document, splits it into chunks if needed,
    generates audio for each chunk, and merges them into a single file.

    Args:
        word_path: Path to the Word document (.docx).
        client: GLM client instance.
        voice: Voice to use.
        output: Output file path.
        response_format: Audio format.
        speed: Speech speed multiplier.
        volume: Volume multiplier.

    Returns:
        Path to the generated audio file.

    Raises:
        GLMClientError: If conversion fails.
    """
    console.print(f"[cyan]Processing Word document: {word_path}[/cyan]")

    # Step 1: Extract text from Word document
    text = extract_text_from_word(word_path)

    # Step 2: Split text into chunks
    chunks = split_text_for_tts(text)
    console.print(f"[dim]Text split into {len(chunks)} chunk(s) for processing[/dim]\n")

    if len(chunks) == 1:
        # Single chunk, use standard TTS
        console.print("[dim]Processing single chunk...[/dim]")
        return text_to_speech(
            text=chunks[0],
            client=client,
            voice=voice,
            output=output,
            response_format=response_format,
            speed=speed,
            volume=volume,
        )

    # Step 3: Process each chunk with progress bar
    output_path = _get_output_path(output, Path(word_path).stem, response_format)
    temp_dir = Path(tempfile.gettempdir()) / "glm_tts"
    temp_dir.mkdir(exist_ok=True)
    audio_files = []

    try:
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            BarColumn(),
            TaskProgressColumn(),
            console=console
        ) as progress:
            task = progress.add_task(
                "[cyan]Generating audio chunks...",
                total=len(chunks)
            )

            for i, chunk in enumerate(chunks):
                progress.update(task, description=f"[cyan]Processing chunk {i + 1}/{len(chunks)}...")

                # Generate audio for this chunk
                chunk_output = temp_dir / f"chunk_{i:04d}.{response_format}"

                _tts_with_http(
                    text=chunk,
                    api_key=client.config.api_key,
                    voice=voice,
                    output=chunk_output,
                    response_format=response_format,
                    speed=speed,
                    volume=volume,
                )

                audio_files.append(chunk_output)
                progress.update(task, advance=1)

        # Step 4: Merge all audio files
        console.print()
        output_path = merge_audio_files(audio_files, output_path)

        return output_path

    finally:
        # Clean up temporary files
        for audio_file in audio_files:
            try:
                audio_file.unlink()
            except Exception:
                pass
