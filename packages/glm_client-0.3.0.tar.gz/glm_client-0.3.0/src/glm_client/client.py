"""GLM API 客户端封装。"""

import time
from typing import Any, Optional, Union

import httpx
from rich.console import Console

# 优先使用新版 zai-sdk，回退到旧版 zhipuai SDK
try:
    from zai import ZhipuAiClient as _SDKClient
    _SDK_NAME = "zai-sdk"
except ImportError:
    try:
        from zhipuai import ZhipuAI as _SDKClient
        _SDK_NAME = "zhipuai"
    except ImportError:
        raise ImportError(
            "请安装 zai-sdk 或 zhipuai 包：pip install zai-sdk"
        )

from .config import GLMConfig, get_config

console = Console()


class GLMClientError(Exception):
    """Base exception for GLM client errors."""

    pass


class AuthenticationError(GLMClientError):
    """Raised when API authentication fails."""

    pass


class RateLimitError(GLMClientError):
    """Raised when rate limit is exceeded."""

    pass


class GLMClient:
    """智谱AI GLM 客户端封装，支持重试和错误处理。"""

    def __init__(self, config: Optional[GLMConfig] = None):
        self.config = config or get_config()
        self._client: Optional[Any] = None
        self._http_client: Optional[httpx.Client] = None

    @property
    def client(self):
        """获取或创建 SDK 客户端实例。"""
        if self._client is None:
            try:
                self._client = _SDKClient(
                    api_key=self.config.api_key,
                    timeout=self.config.timeout,
                    max_retries=self.config.max_retries,
                )
            except Exception as e:
                raise GLMClientError(f"初始化 SDK 客户端失败: {e}") from e
        return self._client

    @property
    def sdk_name(self) -> str:
        """当前使用的 SDK 名称。"""
        return _SDK_NAME

    @property
    def http_client(self) -> httpx.Client:
        """Get or create the HTTP client for direct API requests."""
        if self._http_client is None:
            self._http_client = httpx.Client(
                timeout=self.config.timeout,
                base_url=self.config.base_url,
            )
        return self._http_client

    def _make_request_with_retry(
        self,
        func,
        *args,
        max_retries: Optional[int] = None,
        **kwargs,
    ):
        """带重试机制的 API 请求。"""
        max_retries = max_retries if max_retries is not None else self.config.max_retries
        retry_delay = self.config.retry_delay
        last_error = None

        for attempt in range(max_retries + 1):
            try:
                return func(*args, **kwargs)
            except Exception as e:
                last_error = e
                error_str = str(e).lower()

                # Check for authentication errors
                if "unauthorized" in error_str or "authentication" in error_str or "invalid api key" in error_str:
                    raise AuthenticationError(
                        "认证失败，请检查 ZAI_API_KEY 或 ZHIPUAI_API_KEY 环境变量。"
                    ) from e

                # Check for rate limit errors
                if "rate limit" in error_str or "429" in error_str:
                    if attempt < max_retries:
                        # Exponential backoff for rate limit
                        wait_time = retry_delay * (2 ** attempt)
                        console.print(
                            f"[yellow]Rate limit reached. Waiting {wait_time:.1f}s before retry...[/yellow]"
                        )
                        time.sleep(wait_time)
                        continue
                    raise RateLimitError("请求频率超限，请稍后重试。") from e

                # For other errors, don't retry on the last attempt
                if attempt >= max_retries:
                    break

                # Wait before retrying
                wait_time = retry_delay * (2 ** attempt)
                console.print(
                    f"[yellow]Request failed (attempt {attempt + 1}/{max_retries + 1}). "
                    f"Retrying in {wait_time:.1f}s...[/yellow]"
                )
                console.print(f"[dim]Error: {e}[/dim]")
                time.sleep(wait_time)

        raise GLMClientError(f"请求在 {max_retries + 1} 次尝试后失败: {last_error}") from last_error

    def chat_completion(self, **kwargs):
        """创建聊天补全请求。"""
        return self._make_request_with_retry(
            self.client.chat.completions.create,
            **kwargs,
        )

    def image_generation(self, **kwargs):
        """生成图像。"""
        return self._make_request_with_retry(
            self.client.images.generations,
            **kwargs,
        )

    def video_generation(self, **kwargs):
        """生成视频。"""
        return self._make_request_with_retry(
            self.client.videos.generations,
            **kwargs,
        )

    def retrieve_video_result(self, task_id: str):
        """查询视频生成结果。"""
        return self._make_request_with_retry(
            self.client.videos.retrieve_videos_result,
            id=task_id,
        )

    def create_embedding(self, **kwargs):
        """创建文本嵌入。"""
        return self._make_request_with_retry(
            self.client.embeddings.create,
            **kwargs,
        )

    def audio_transcription(self, **kwargs):
        """语音转文字。"""
        return self._make_request_with_retry(
            self.client.audio.transcriptions.create,
            **kwargs,
        )

    def close(self):
        """关闭客户端连接。"""
        if self._client is not None:
            self._client = None
        if self._http_client is not None:
            self._http_client.close()
            self._http_client = None

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()
