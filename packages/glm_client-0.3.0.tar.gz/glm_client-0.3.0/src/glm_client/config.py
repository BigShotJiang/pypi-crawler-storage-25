"""GLM 客户端配置模块。"""

import os
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List

from dotenv import load_dotenv

load_dotenv()


@dataclass
class GLMConfig:
    """GLM API 客户端配置。"""

    api_key: str
    base_url: str = "https://open.bigmodel.cn/api/paas/v4/"
    timeout: int = 120
    max_retries: int = 3
    retry_delay: float = 1.0

    @classmethod
    def from_env(cls) -> "GLMConfig":
        """从环境变量创建配置。"""
        api_key = os.getenv("ZAI_API_KEY", "") or os.getenv("ZHIPUAI_API_KEY", "")
        if not api_key:
            raise ValueError(
                "未设置 API Key。请设置 ZAI_API_KEY 或 ZHIPUAI_API_KEY 环境变量，"
                "或创建 .env 文件。"
            )
        return cls(api_key=api_key)


# 默认模型
DEFAULT_MODELS = {
    "text": "glm-4-flash",
    "vision": "glm-4v-flash",
    "image": "cogview-3-flash",
    "tts": "glm-tts",
    "video": "cogvideox-2",
    "embedding": "embedding-3",
    "asr": "glm-asr",
}

# 可用模型列表
AVAILABLE_TEXT_MODELS = [
    "glm-5.1",
    "glm-5-turbo",
    "glm-5",
    "glm-4.7",
    "glm-4.7-flash",
    "glm-4.7-flashx",
    "glm-4.5-air",
    "glm-4-flash-250414",
    "glm-4-flash",
    "glm-4-plus",
    "glm-4-air",
    "glm-4",
    "glm-z1-flash",
]

AVAILABLE_VISION_MODELS = [
    "glm-5v-turbo",
    "glm-4.6v",
    "glm-4.6v-flash",
    "glm-4.6v-flashx",
    "glm-4.5v",
    "glm-4v-flash",
    "glm-4v-plus",
    "glm-4.1v-thinking-flash",
]

AVAILABLE_IMAGE_MODELS = [
    "cogview-4",
    "cogview-3-flash",
    "cogview-3-plus",
    "cogview-3",
]

AVAILABLE_VIDEO_MODELS = [
    "cogvideox-3",
    "cogvideox-2",
    "cogvideox-flash",
]

AVAILABLE_EMBEDDING_MODELS = [
    "embedding-3",
]

AVAILABLE_ASR_MODELS = [
    "glm-asr",
]

# 永久免费模型
FREE_MODELS: Dict[str, List[str]] = {
    "text": ["glm-4.7-flash", "glm-4-flash-250414", "glm-z1-flash", "glm-4-flash"],
    "vision": ["glm-4.6v-flash", "glm-4v-flash", "glm-4.1v-thinking-flash"],
    "image": ["cogview-3-flash"],
    "tts": [],
    "video": ["cogvideox-flash"],
    "embedding": [],
    "asr": [],
}

# TTS 相关配置
TTS_VOICES = ["female", "chen", "cuicui", "jam", "kazi", "douji", "luodo"]
DEFAULT_TTS_VOICE = "female"
DEFAULT_TTS_FORMAT = "wav"
TTS_FORMATS = ["wav", "pcm", "mp3"]
DEFAULT_TTS_SPEED = 1.0
DEFAULT_TTS_VOLUME = 1.0

# 图像生成参数
DEFAULT_IMAGE_SIZE = "1152x864"
IMAGE_SIZES = ["1024x1024", "768x1344", "864x1152", "1152x864", "1344x768"]

# 视频生成参数
VIDEO_SIZES = ["1920x1080", "1080x1920", "1280x720", "720x1280"]
VIDEO_FPS_OPTIONS = [30, 60]


def get_api_key() -> str:
    """从环境变量获取 API Key。"""
    api_key = os.getenv("ZAI_API_KEY", "") or os.getenv("ZHIPUAI_API_KEY", "")
    if not api_key:
        raise ValueError(
            "未设置 API Key。请设置 ZAI_API_KEY 或 ZHIPUAI_API_KEY 环境变量。"
        )
    return api_key


def get_config() -> GLMConfig:
    """获取 GLM 配置。"""
    return GLMConfig.from_env()


def validate_model(model: str, model_type: str) -> bool:
    """验证模型名称是否可用。"""
    model_lists = {
        "text": AVAILABLE_TEXT_MODELS,
        "vision": AVAILABLE_VISION_MODELS,
        "image": AVAILABLE_IMAGE_MODELS,
        "tts": ["glm-tts"],
        "video": AVAILABLE_VIDEO_MODELS,
        "embedding": AVAILABLE_EMBEDDING_MODELS,
        "asr": AVAILABLE_ASR_MODELS,
    }
    return model in model_lists.get(model_type, [])


def get_default_model(model_type: str) -> str:
    """获取指定类型的默认模型。"""
    return DEFAULT_MODELS.get(model_type, DEFAULT_MODELS["text"])


def is_free_model(model: str, model_type: str) -> bool:
    """检查模型是否为永久免费。"""
    return model in FREE_MODELS.get(model_type, [])


def get_output_dir() -> Path:
    """获取或创建输出目录。"""
    output_dir = Path("output")
    output_dir.mkdir(exist_ok=True)
    return output_dir
