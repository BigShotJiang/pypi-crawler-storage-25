# 更新日志

## v0.3.0 (2026-04-24)

### 新增
- OCR 文字识别模块（`models/ocr.py`），支持图片/PDF 文字提取，本地文件和 URL，批量识别
- 文档摘要模块（`models/summarize.py`），结构化 JSON 输出（标题、类型、关键词、摘要、关键信息）
- `summarize_file()` 支持 OCR + 摘要一步到位
- 多轮综合基准测试脚本，新增质量/速度/稳定性三维度评分体系
- CLI 新增 `config --list-models` 展示全部可用模型

### 变更
- 默认文本模型更新为 `glm-4-flash`（综合评分最优）
- 默认视觉模型更新为 `glm-4v-flash`（OCR 质量满分、速度最快）

## v0.2.0 (2026-04-20)

### 新增
- 迁移到新版 `zai-sdk`（官方推荐 SDK），兼容旧版 `zhipuai`
- 视频生成模块（`models/video.py`），支持文本生成视频和图片生成视频
- 文本嵌入模块（`models/embedding.py`），支持向量生成和相似度计算
- 语音识别模块（`models/asr`），支持本地和远程音频转文字
- CLI 新增 `video`、`embed`、`asr` 命令
- 文本生成支持思考模式（`thinking`）和联网搜索（`web_search`）
- 完善公开 API 导出（`__init__.py` 导出 22 个符号）
- 免费模型基准测试脚本（`scripts/benchmark_models.py`）
- MIT License 文件
- 中文使用指南和详细文档

### 变更
- 默认依赖从 `zhipuai>=2.0.0` 更改为 `zai-sdk>=0.0.3`
- 环境变量优先使用 `ZAI_API_KEY`，回退兼容 `ZHIPUAI_API_KEY`
- 扩展模型列表，新增 GLM-5 系列、视频、嵌入、ASR 模型
- CLI 帮助信息和输出改为中文

## v0.1.0 (2025-01-01)

### 初始版本
- 文本生成（chat）with 流式/非流式支持
- 视觉理解（vision）支持本地图片和 URL
- 图像生成（image）支持多种尺寸
- 文本转语音（tts）支持多种音色和 Word 文档转换
- CLI 交互模式
- 重试机制和错误处理
