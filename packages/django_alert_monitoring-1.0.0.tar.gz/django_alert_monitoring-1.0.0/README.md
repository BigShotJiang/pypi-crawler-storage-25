# Django Alert & Monitoring

A comprehensive Django package for monitoring system health, API performance, and sending automated alerts via email when issues occur.

## Features

- **API Error Monitoring**: Automatically detect and alert on API errors (4xx, 5xx status codes)
- **System Health Monitoring**: Monitor CPU, memory, disk usage with configurable thresholds
- **Redis Monitoring**: Track Redis connection health and performance
- **Log Monitoring**: Parse and analyze Django application logs for errors and warnings
- **Email Alerts**: Send configurable email notifications to administrators
- **Prometheus Integration**: Export metrics for external monitoring systems
- **Celery Integration**: Background task monitoring and health checks
- **Web Dashboard**: Built-in web interface for viewing alerts and system metrics

## Installation

```bash
pip install django-alert-monitoring
```

Or install from source:

```bash
git clone https://github.com/yourusername/django-alert-monitoring.git
cd django-alert-monitoring
pip install -e .
```

## Quick Start

1. Add to your Django `INSTALLED_APPS`:

```python
INSTALLED_APPS = [
    # ... other apps
    'alert_monitoring',
]
```

2. Add the middleware to monitor API requests:

```python
MIDDLEWARE = [
    # ... other middleware
    'alert_monitoring.middleware.APIMonitoringMiddleware',
]
```

3. Configure email settings for alerts:

```python
# settings.py
EMAIL_BACKEND = 'django.core.mail.backends.smtp.EmailBackend'
EMAIL_HOST = 'smtp.gmail.com'
EMAIL_PORT = 587
EMAIL_USE_TLS = True
EMAIL_HOST_USER = 'your-email@gmail.com'
EMAIL_HOST_PASSWORD = 'your-app-password'

# Alert monitoring settings
ALERT_MONITORING = {
    'ADMIN_EMAILS': ['admin@example.com', 'dev@example.com'],
    'EMAIL_SUBJECT_PREFIX': '[ALERT] ',
    'API_ERROR_THRESHOLD': 10,  # Alert if more than 10 errors in 5 minutes
    'SYSTEM_THRESHOLDS': {
        'CPU_WARNING': 80,
        'CPU_CRITICAL': 95,
        'MEMORY_WARNING': 85,
        'MEMORY_CRITICAL': 95,
        'DISK_WARNING': 90,
        'DISK_CRITICAL': 98,
    },
    'REDIS_CHECK_INTERVAL': 60,  # seconds
    'LOG_CHECK_INTERVAL': 300,  # seconds
}
```

4. Run migrations:

```bash
python manage.py migrate
```

5. Start the monitoring tasks:

```bash
python manage.py start_monitoring
```

## Usage

### API Monitoring

The middleware automatically monitors all API requests and creates alerts for:
- 4xx client errors
- 5xx server errors
- Slow response times (>5 seconds)

### System Monitoring

Monitor system resources with automatic alerts:
- High CPU usage
- High memory usage
- Low disk space

### Redis Monitoring

Track Redis connection health and performance metrics.

### Log Monitoring

Parse Django logs for:
- ERROR level messages
- WARNING level messages
- Custom patterns

### Email Alerts

Receive email notifications when:
- API errors exceed threshold
- System resources are critical
- Redis connection fails
- Log errors are detected

## Web Dashboard

Access the monitoring dashboard at `/monitoring/` to view:
- Current system health
- Recent alerts
- System metrics history
- Alert statistics

## Management Commands

- `start_monitoring`: Start all monitoring tasks
- `check_health`: Run manual health check
- `clear_old_alerts`: Remove alerts older than specified days

## API Endpoints

- `GET /monitoring/health/`: Basic health check
- `GET /monitoring/health/detailed/`: Detailed system health
- `GET /monitoring/metrics/`: Prometheus metrics
- `GET /monitoring/alerts/`: View alerts (requires authentication)

## Configuration

Full configuration options:

```python
ALERT_MONITORING = {
    'ADMIN_EMAILS': ['admin@example.com'],
    'EMAIL_SUBJECT_PREFIX': '[ALERT] ',
    'API_ERROR_THRESHOLD': 10,
    'API_ERROR_WINDOW': 300,  # 5 minutes
    'SYSTEM_THRESHOLDS': {
        'CPU_WARNING': 80,
        'CPU_CRITICAL': 95,
        'MEMORY_WARNING': 85,
        'MEMORY_CRITICAL': 95,
        'DISK_WARNING': 90,
        'DISK_CRITICAL': 98,
    },
    'REDIS_CHECK_INTERVAL': 60,
    'LOG_CHECK_INTERVAL': 300,
    'LOG_FILE_PATH': '/path/to/django.log',
    'LOG_ERROR_PATTERNS': [
        r'ERROR',
        r'CRITICAL',
        r'Exception',
    ],
    'ENABLE_PROMETHEUS': True,
    'PROMETHEUS_PORT': 8001,
}
```

## Dependencies

- Django >= 3.2
- psutil >= 5.8.0
- redis >= 4.0.0
- celery >= 5.0.0
- prometheus-client >= 0.16.0

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests
5. Submit a pull request

## License

MIT License - see LICENSE file for details