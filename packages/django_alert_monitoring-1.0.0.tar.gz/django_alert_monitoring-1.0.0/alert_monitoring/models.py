from django.db import models
from django.utils import timezone
from django.conf import settings


class AlertHistory(models.Model):
    """Store alert history for tracking and analysis"""

    SEVERITY_CHOICES = [
        ('Info', 'Info'),
        ('Warning', 'Warning'),
        ('Critical', 'Critical'),
    ]

    ALERT_TYPES = [
        ('api_error', 'API Error'),
        ('system_resource', 'System Resource'),
        ('redis_connection', 'Redis Connection'),
        ('log_error', 'Log Error'),
        ('custom', 'Custom'),
    ]

    alert_name = models.CharField(max_length=255)
    alert_type = models.CharField(max_length=20, choices=ALERT_TYPES, default='custom')
    severity = models.CharField(max_length=20, choices=SEVERITY_CHOICES, default='Info')
    message = models.TextField()
    triggered_at = models.DateTimeField(auto_now_add=True)
    resolved_at = models.DateTimeField(null=True, blank=True)
    resolved_by = models.CharField(max_length=100, blank=True)
    metadata = models.JSONField(default=dict, blank=True)  # Store additional context

    # Email notification tracking
    email_sent = models.BooleanField(default=False)
    email_sent_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ['-triggered_at']
        indexes = [
            models.Index(fields=['alert_type', 'severity']),
            models.Index(fields=['triggered_at']),
            models.Index(fields=['resolved_at']),
        ]

    def __str__(self):
        return f"{self.alert_name} - {self.severity}"

    def resolve(self, resolved_by='system'):
        """Mark alert as resolved"""
        self.resolved_at = timezone.now()
        self.resolved_by = resolved_by
        self.save()

    def is_active(self):
        """Check if alert is still active"""
        return self.resolved_at is None

    @property
    def duration(self):
        """Get alert duration in seconds"""
        if self.resolved_at:
            return (self.resolved_at - self.triggered_at).total_seconds()
        return (timezone.now() - self.triggered_at).total_seconds()


class SystemMetrics(models.Model):
    """Store historical system metrics for trending and analysis"""

    timestamp = models.DateTimeField(auto_now_add=True)
    cpu_usage = models.FloatField(help_text='CPU usage percentage')
    memory_usage = models.FloatField(help_text='Memory usage percentage')
    disk_usage = models.FloatField(help_text='Disk usage percentage')

    # Optional additional metrics
    network_connections = models.IntegerField(default=0, help_text='Active network connections')
    load_average = models.FloatField(null=True, blank=True, help_text='System load average')

    class Meta:
        ordering = ['-timestamp']
        indexes = [
            models.Index(fields=['timestamp']),
        ]

    def __str__(self):
        return f"Metrics at {self.timestamp}"

    @property
    def is_critical(self):
        """Check if any metric is in critical range"""
        from .utils import get_system_thresholds
        thresholds = get_system_thresholds()

        return (
            self.cpu_usage >= thresholds['CPU_CRITICAL'] or
            self.memory_usage >= thresholds['MEMORY_CRITICAL'] or
            self.disk_usage >= thresholds['DISK_CRITICAL']
        )


class APIMetrics(models.Model):
    """Store API performance metrics"""

    timestamp = models.DateTimeField(auto_now_add=True)
    endpoint = models.CharField(max_length=500)
    method = models.CharField(max_length=10)
    status_code = models.IntegerField()
    response_time = models.FloatField(help_text='Response time in seconds')
    request_size = models.IntegerField(default=0, help_text='Request size in bytes')
    response_size = models.IntegerField(default=0, help_text='Response size in bytes')

    # Error tracking
    is_error = models.BooleanField(default=False)
    error_message = models.TextField(blank=True)

    class Meta:
        ordering = ['-timestamp']
        indexes = [
            models.Index(fields=['endpoint', 'status_code']),
            models.Index(fields=['timestamp']),
            models.Index(fields=['is_error']),
        ]

    def __str__(self):
        return f"{self.method} {self.endpoint} - {self.status_code}"


class LogEntry(models.Model):
    """Store parsed log entries for monitoring"""

    LEVEL_CHOICES = [
        ('DEBUG', 'Debug'),
        ('INFO', 'Info'),
        ('WARNING', 'Warning'),
        ('ERROR', 'Error'),
        ('CRITICAL', 'Critical'),
    ]

    timestamp = models.DateTimeField()
    level = models.CharField(max_length=10, choices=LEVEL_CHOICES)
    message = models.TextField()
    logger_name = models.CharField(max_length=255)
    module = models.CharField(max_length=255, blank=True)
    function = models.CharField(max_length=255, blank=True)
    line_number = models.IntegerField(null=True, blank=True)
    exception = models.TextField(blank=True)

    # Alert tracking
    alert_created = models.BooleanField(default=False)

    class Meta:
        ordering = ['-timestamp']
        indexes = [
            models.Index(fields=['level', 'timestamp']),
            models.Index(fields=['alert_created']),
        ]

    def __str__(self):
        return f"{self.level} - {self.message[:50]}"


class RedisMetrics(models.Model):
    """Store Redis performance metrics"""

    timestamp = models.DateTimeField(auto_now_add=True)
    connected_clients = models.IntegerField(default=0)
    used_memory = models.BigIntegerField(default=0, help_text='Used memory in bytes')
    total_connections_received = models.BigIntegerField(default=0)
    total_commands_processed = models.BigIntegerField(default=0)
    instantaneous_ops_per_sec = models.IntegerField(default=0)
    keyspace_hits = models.BigIntegerField(default=0)
    keyspace_misses = models.BigIntegerField(default=0)

    # Connection status
    is_connected = models.BooleanField(default=True)

    class Meta:
        ordering = ['-timestamp']

    def __str__(self):
        return f"Redis metrics at {self.timestamp}"

    @property
    def hit_ratio(self):
        """Calculate cache hit ratio"""
        total = self.keyspace_hits + self.keyspace_misses
        return (self.keyspace_hits / total * 100) if total > 0 else 0


class AlertRule(models.Model):
    """Configurable alert rules"""

    RULE_TYPES = [
        ('threshold', 'Threshold'),
        ('pattern', 'Pattern Match'),
        ('frequency', 'Frequency'),
    ]

    name = models.CharField(max_length=255, unique=True)
    rule_type = models.CharField(max_length=20, choices=RULE_TYPES)
    metric = models.CharField(max_length=100)  # e.g., 'cpu_usage', 'api_errors'
    condition = models.CharField(max_length=50)  # e.g., '>', '<', '==', 'contains'
    threshold = models.FloatField()
    severity = models.CharField(max_length=20, choices=AlertHistory.SEVERITY_CHOICES)
    enabled = models.BooleanField(default=True)
    cooldown_minutes = models.IntegerField(default=60)  # Prevent alert spam

    # Last alert timestamp for cooldown
    last_alert_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ['name']

    def __str__(self):
        return f"{self.name} ({self.metric} {self.condition} {self.threshold})"

    def should_trigger(self, value):
        """Check if the rule should trigger an alert"""
        if not self.enabled:
            return False

        # Check cooldown
        if self.last_alert_at:
            cooldown_end = self.last_alert_at + timezone.timedelta(minutes=self.cooldown_minutes)
            if timezone.now() < cooldown_end:
                return False

        # Evaluate condition
        if self.condition == '>':
            return value > self.threshold
        elif self.condition == '<':
            return value < self.threshold
        elif self.condition == '>=':
            return value >= self.threshold
        elif self.condition == '<=':
            return value <= self.threshold
        elif self.condition == '==':
            return value == self.threshold
        elif self.condition == '!=':
            return value != self.threshold

        return False