import redis
import psutil
import logging
from celery import shared_task
from django.conf import settings
from django.core.mail import send_mail
from django.db import connection
from django.utils import timezone
from prometheus_client import Gauge
from .models import SystemMetrics, AlertHistory, RedisMetrics, LogEntry
from .utils import (
    get_system_thresholds, check_log_for_errors, get_log_file_path,
    format_alert_message, get_admin_emails, get_email_subject_prefix,
    should_send_email_alert, get_redis_check_interval, get_log_check_interval
)

# Prometheus metrics
CELERY_WORKERS_ACTIVE = Gauge('celery_workers_active', 'Number of active Celery workers')
CELERY_TASKS_ACTIVE = Gauge('celery_tasks_active', 'Number of active Celery tasks')
SYSTEM_CPU_USAGE = Gauge('system_cpu_usage_percent', 'System CPU usage percentage')
SYSTEM_MEMORY_USAGE = Gauge('system_memory_usage_percent', 'System memory usage percentage')
SYSTEM_DISK_USAGE = Gauge('system_disk_usage_percent', 'System disk usage percentage')
REDIS_CONNECTED_CLIENTS = Gauge('redis_connected_clients', 'Number of Redis connected clients')
REDIS_MEMORY_USAGE = Gauge('redis_memory_usage_bytes', 'Redis memory usage in bytes')

logger = logging.getLogger(__name__)


@shared_task
def monitor_celery_workers():
    """Monitor Celery workers and tasks"""
    try:
        from config.celery import app

        # Get active workers
        inspect = app.control.inspect()
        active_workers = len(inspect.active() or {})
        CELERY_WORKERS_ACTIVE.set(active_workers)

        # Get active tasks count
        active_tasks = sum(len(tasks) for tasks in (inspect.active() or {}).values())
        CELERY_TASKS_ACTIVE.set(active_tasks)

        return {
            'workers': active_workers,
            'tasks': active_tasks,
            'status': 'success'
        }
    except Exception as e:
        logger.error(f"Celery monitoring error: {e}")
        return {'status': 'error', 'message': str(e)}


@shared_task
def check_system_health():
    """Monitor system health and create alerts if needed"""
    try:
        # Get system metrics
        cpu_percent = psutil.cpu_percent(interval=1)
        memory = psutil.virtual_memory()
        disk = psutil.disk_usage('/')
        load_avg = psutil.getloadavg() if hasattr(psutil, 'getloadavg') else None

        # Update Prometheus metrics
        SYSTEM_CPU_USAGE.set(cpu_percent)
        SYSTEM_MEMORY_USAGE.set(memory.percent)
        SYSTEM_DISK_USAGE.set(disk.percent)

        # Store in database
        metrics = SystemMetrics.objects.create(
            cpu_usage=cpu_percent,
            memory_usage=memory.percent,
            disk_usage=disk.percent,
            network_connections=len(psutil.net_connections()),
            load_average=load_avg[0] if load_avg else None,
        )

        # Check thresholds and create alerts
        thresholds = get_system_thresholds()
        alerts_created = []

        # CPU alerts
        if cpu_percent >= thresholds['CPU_CRITICAL']:
            alert = AlertHistory.objects.create(
                alert_name='Critical CPU Usage',
                alert_type='system_resource',
                severity='Critical',
                message=f'System CPU usage is {cpu_percent:.1f}% (threshold: {thresholds["CPU_CRITICAL"]}%)',
                metadata={'cpu_usage': cpu_percent, 'threshold': thresholds['CPU_CRITICAL']}
            )
            alerts_created.append(alert)
        elif cpu_percent >= thresholds['CPU_WARNING']:
            alert = AlertHistory.objects.create(
                alert_name='High CPU Usage',
                alert_type='system_resource',
                severity='Warning',
                message=f'System CPU usage is {cpu_percent:.1f}% (threshold: {thresholds["CPU_WARNING"]}%)',
                metadata={'cpu_usage': cpu_percent, 'threshold': thresholds['CPU_WARNING']}
            )
            alerts_created.append(alert)

        # Memory alerts
        if memory.percent >= thresholds['MEMORY_CRITICAL']:
            alert = AlertHistory.objects.create(
                alert_name='Critical Memory Usage',
                alert_type='system_resource',
                severity='Critical',
                message=f'System memory usage is {memory.percent:.1f}% (threshold: {thresholds["MEMORY_CRITICAL"]}%)',
                metadata={'memory_usage': memory.percent, 'threshold': thresholds['MEMORY_CRITICAL']}
            )
            alerts_created.append(alert)
        elif memory.percent >= thresholds['MEMORY_WARNING']:
            alert = AlertHistory.objects.create(
                alert_name='High Memory Usage',
                alert_type='system_resource',
                severity='Warning',
                message=f'System memory usage is {memory.percent:.1f}% (threshold: {thresholds["MEMORY_WARNING"]}%)',
                metadata={'memory_usage': memory.percent, 'threshold': thresholds['MEMORY_WARNING']}
            )
            alerts_created.append(alert)

        # Disk alerts
        if disk.percent >= thresholds['DISK_CRITICAL']:
            alert = AlertHistory.objects.create(
                alert_name='Critical Disk Usage',
                alert_type='system_resource',
                severity='Critical',
                message=f'System disk usage is {disk.percent:.1f}% (threshold: {thresholds["DISK_CRITICAL"]}%)',
                metadata={'disk_usage': disk.percent, 'threshold': thresholds['DISK_CRITICAL']}
            )
            alerts_created.append(alert)
        elif disk.percent >= thresholds['DISK_WARNING']:
            alert = AlertHistory.objects.create(
                alert_name='Low Disk Space',
                alert_type='system_resource',
                severity='Warning',
                message=f'System disk usage is {disk.percent:.1f}% (threshold: {thresholds["DISK_WARNING"]}%)',
                metadata={'disk_usage': disk.percent, 'threshold': thresholds['DISK_WARNING']}
            )
            alerts_created.append(alert)

        # Send email alerts
        if should_send_email_alert():
            for alert in alerts_created:
                send_email_alert.delay(alert.id)

        return {
            'status': 'success',
            'cpu': cpu_percent,
            'memory': memory.percent,
            'disk': disk.percent,
            'alerts_created': len(alerts_created)
        }
    except Exception as e:
        logger.error(f"System health check error: {e}")
        return {'status': 'error', 'message': str(e)}


@shared_task
def monitor_redis():
    """Monitor Redis connection and performance"""
    try:
        redis_url = getattr(settings, 'CELERY_BROKER_URL', None) or getattr(settings, 'REDIS_URL', None)
        if not redis_url:
            return {'status': 'error', 'message': 'No Redis URL configured'}

        r = redis.Redis.from_url(redis_url)

        # Test connection
        r.ping()

        # Get Redis info
        info = r.info()

        # Store metrics
        metrics = RedisMetrics.objects.create(
            connected_clients=info.get('connected_clients', 0),
            used_memory=info.get('used_memory', 0),
            total_connections_received=info.get('total_connections_received', 0),
            total_commands_processed=info.get('total_commands_processed', 0),
            instantaneous_ops_per_sec=info.get('instantaneous_ops_per_sec', 0),
            keyspace_hits=info.get('keyspace_hits', 0),
            keyspace_misses=info.get('keyspace_misses', 0),
            is_connected=True,
        )

        # Update Prometheus metrics
        REDIS_CONNECTED_CLIENTS.set(metrics.connected_clients)
        REDIS_MEMORY_USAGE.set(metrics.used_memory)

        # Check for issues
        alerts_created = []

        if metrics.connected_clients > 1000:  # Arbitrary threshold
            alert = AlertHistory.objects.create(
                alert_name='High Redis Connections',
                alert_type='redis_connection',
                severity='Warning',
                message=f'Redis has {metrics.connected_clients} connected clients',
                metadata={'connected_clients': metrics.connected_clients}
            )
            alerts_created.append(alert)

        # Send email alerts
        if should_send_email_alert():
            for alert in alerts_created:
                send_email_alert.delay(alert.id)

        return {
            'status': 'success',
            'connected_clients': metrics.connected_clients,
            'used_memory': metrics.used_memory,
            'alerts_created': len(alerts_created)
        }
    except redis.ConnectionError:
        # Redis connection failed
        RedisMetrics.objects.create(is_connected=False)

        alert = AlertHistory.objects.create(
            alert_name='Redis Connection Failed',
            alert_type='redis_connection',
            severity='Critical',
            message='Unable to connect to Redis server',
            metadata={'error': 'Connection failed'}
        )

        if should_send_email_alert():
            send_email_alert.delay(alert.id)

        return {'status': 'error', 'message': 'Redis connection failed'}
    except Exception as e:
        logger.error(f"Redis monitoring error: {e}")
        return {'status': 'error', 'message': str(e)}


@shared_task
def monitor_logs():
    """Monitor log files for errors and create alerts"""
    try:
        log_file = get_log_file_path()
        errors = check_log_for_errors(log_file)

        alerts_created = []

        for error in errors:
            # Check if we already created an alert for this error
            existing = LogEntry.objects.filter(
                timestamp=error['timestamp'],
                message=error['message'],
                alert_created=True
            ).exists()

            if not existing:
                # Create log entry
                log_entry = LogEntry.objects.create(
                    timestamp=error['timestamp'],
                    level=error['level'],
                    message=error['message'],
                    logger_name=error.get('module', 'unknown'),
                    alert_created=True,
                )

                # Create alert
                alert = AlertHistory.objects.create(
                    alert_name=f'Log Error: {error["level"]}',
                    alert_type='log_error',
                    severity='Critical' if error['level'] in ['ERROR', 'CRITICAL'] else 'Warning',
                    message=f'{error["level"]} in {error.get("module", "unknown")}: {error["message"][:200]}...',
                    metadata={
                        'level': error['level'],
                        'module': error.get('module'),
                        'raw_message': error['message'],
                        'log_entry_id': log_entry.id,
                    }
                )
                alerts_created.append(alert)

        # Send email alerts
        if should_send_email_alert():
            for alert in alerts_created:
                send_email_alert.delay(alert.id)

        return {
            'status': 'success',
            'errors_found': len(errors),
            'alerts_created': len(alerts_created)
        }
    except Exception as e:
        logger.error(f"Log monitoring error: {e}")
        return {'status': 'error', 'message': str(e)}


@shared_task
def send_email_alert(alert_id):
    """Send email notification for an alert"""
    try:
        alert = AlertHistory.objects.get(id=alert_id)
        admin_emails = get_admin_emails()

        if not admin_emails:
            return {'status': 'error', 'message': 'No admin emails configured'}

        subject = f"{get_email_subject_prefix()}{alert.alert_name}"
        message = format_alert_message(
            alert.alert_name,
            alert.severity,
            alert.message,
            alert.metadata
        )

        send_mail(
            subject=subject,
            message=message,
            from_email=getattr(settings, 'DEFAULT_FROM_EMAIL', 'alerts@django.local'),
            recipient_list=admin_emails,
            fail_silently=True,
        )

        # Mark email as sent
        alert.email_sent = True
        alert.email_sent_at = timezone.now()
        alert.save()

        return {'status': 'success', 'alert_id': alert_id}
    except AlertHistory.DoesNotExist:
        return {'status': 'error', 'message': f'Alert {alert_id} not found'}
    except Exception as e:
        logger.error(f"Failed to send email alert {alert_id}: {e}")
        return {'status': 'error', 'message': str(e)}


@shared_task
def cleanup_old_data(days=30):
    """Clean up old monitoring data"""
    try:
        cutoff_date = timezone.now() - timezone.timedelta(days=days)

        # Clean up old metrics (keep last 90 days)
        old_metrics = SystemMetrics.objects.filter(timestamp__lt=cutoff_date).delete()
        old_api_metrics = APIMetrics.objects.filter(timestamp__lt=cutoff_date).delete()
        old_redis_metrics = RedisMetrics.objects.filter(timestamp__lt=cutoff_date).delete()

        # Clean up old log entries (keep last 30 days)
        old_logs = LogEntry.objects.filter(timestamp__lt=cutoff_date).delete()

        # Clean up resolved alerts older than 90 days
        old_alerts = AlertHistory.objects.filter(
            resolved_at__lt=cutoff_date - timezone.timedelta(days=60)
        ).delete()

        return {
            'status': 'success',
            'metrics_deleted': old_metrics[0] if old_metrics else 0,
            'api_metrics_deleted': old_api_metrics[0] if old_api_metrics else 0,
            'redis_metrics_deleted': old_redis_metrics[0] if old_redis_metrics else 0,
            'logs_deleted': old_logs[0] if old_logs else 0,
            'alerts_deleted': old_alerts[0] if old_alerts else 0,
        }
    except Exception as e:
        logger.error(f"Cleanup task error: {e}")
        return {'status': 'error', 'message': str(e)}


@shared_task
def generate_test_alerts(count=5):
    """Generate test alerts for demo purposes"""
    try:
        alert_names = [
            'High CPU Usage',
            'High Memory Usage',
            'Disk Space Low',
            'Database Connection Failed',
            'Redis Connection Failed',
            'API Response Time High',
            'Failed Background Jobs',
            'Worker Stopped'
        ]

        severities = ['Critical', 'Warning', 'Info']
        messages = {
            'Critical': 'Critical threshold exceeded',
            'Warning': 'Warning threshold exceeded',
            'Info': 'Informational alert'
        }

        created_count = 0
        for i in range(count):
            alert_name = alert_names[i % len(alert_names)]
            severity = severities[i % len(severities)]

            AlertHistory.objects.create(
                alert_name=alert_name,
                alert_type='custom',
                severity=severity,
                message=f"{messages[severity]} for {alert_name}",
                triggered_at=timezone.now()
            )
            created_count += 1

        return {
            'status': 'success',
            'message': f'{created_count} test alerts created',
            'count': created_count
        }
    except Exception as e:
        return {'status': 'error', 'message': str(e)}