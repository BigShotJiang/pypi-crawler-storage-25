/**
 * Alert & Monitoring JavaScript utilities
 */

(function($) {
    'use strict';

    // CSRF token setup for AJAX requests
    function getCookie(name) {
        let cookieValue = null;
        if (document.cookie && document.cookie !== '') {
            const cookies = document.cookie.split(';');
            for (let i = 0; i < cookies.length; i++) {
                const cookie = cookies[i].trim();
                if (cookie.substring(0, name.length + 1) === (name + '=')) {
                    cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                    break;
                }
            }
        }
        return cookieValue;
    }

    const csrftoken = getCookie('csrftoken');

    // Setup AJAX with CSRF token
    $.ajaxSetup({
        beforeSend: function(xhr, settings) {
            if (!(/^http:.*/.test(settings.url) || /^https:.*/.test(settings.url))) {
                xhr.setRequestHeader("X-CSRFToken", csrftoken);
            }
        }
    });

    // Alert & Monitoring namespace
    window.AlertMonitoring = {

        // Show loading spinner on button
        showLoading: function(button) {
            const originalText = $(button).html();
            $(button).data('original-text', originalText);
            $(button).html('<span class="loading-spinner"></span> Loading...');
            $(button).prop('disabled', true);
        },

        // Hide loading spinner on button
        hideLoading: function(button) {
            const originalText = $(button).data('original-text');
            $(button).html(originalText);
            $(button).prop('disabled', false);
        },

        // Show success message
        showSuccess: function(message) {
            this.showMessage(message, 'success');
        },

        // Show error message
        showError: function(message) {
            this.showMessage(message, 'danger');
        },

        // Show message using Bootstrap alert
        showMessage: function(message, type) {
            const alertHtml = `
                <div class="alert alert-${type} alert-dismissible fade show" role="alert">
                    ${message}
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            `;

            // Remove existing alerts
            $('.alert').remove();

            // Add new alert at the top of the page
            $('body').prepend(alertHtml);

            // Auto-dismiss after 5 seconds
            setTimeout(function() {
                $('.alert').fadeOut();
            }, 5000);
        },

        // Generate test alerts
        generateAlerts: function(count) {
            count = count || 5;

            if (!confirm(`Generate ${count} test alerts?`)) {
                return;
            }

            const button = event.target;
            this.showLoading(button);

            $.post('{% url "alert_monitoring:generate_alerts_action" %}', {
                count: count
            })
            .done(function(data) {
                if (data.status === 'success') {
                    AlertMonitoring.showSuccess(data.message);
                    setTimeout(function() {
                        location.reload();
                    }, 1000);
                } else {
                    AlertMonitoring.showError(data.message);
                }
            })
            .fail(function(xhr) {
                AlertMonitoring.showError('Failed to generate alerts: ' + xhr.responseText);
            })
            .always(function() {
                AlertMonitoring.hideLoading(button);
            });
        },

        // Run health check
        runHealthCheck: function() {
            const button = event.target;
            this.showLoading(button);

            $.post('{% url "alert_monitoring:run_health_check_action" %}')
            .done(function(data) {
                if (data.status === 'success') {
                    AlertMonitoring.showSuccess('Health check completed successfully!');
                    setTimeout(function() {
                        location.reload();
                    }, 1000);
                } else {
                    AlertMonitoring.showError(data.message);
                }
            })
            .fail(function(xhr) {
                AlertMonitoring.showError('Health check failed: ' + xhr.responseText);
            })
            .always(function() {
                AlertMonitoring.hideLoading(button);
            });
        },

        // Run Redis check
        runRedisCheck: function() {
            const button = event.target;
            this.showLoading(button);

            $.post('{% url "alert_monitoring:run_redis_check_action" %}')
            .done(function(data) {
                if (data.status === 'success') {
                    AlertMonitoring.showSuccess('Redis check completed successfully!');
                    setTimeout(function() {
                        location.reload();
                    }, 1000);
                } else {
                    AlertMonitoring.showError(data.message);
                }
            })
            .fail(function(xhr) {
                AlertMonitoring.showError('Redis check failed: ' + xhr.responseText);
            })
            .always(function() {
                AlertMonitoring.hideLoading(button);
            });
        },

        // Run log check
        runLogCheck: function() {
            const button = event.target;
            this.showLoading(button);

            $.post('{% url "alert_monitoring:run_log_check_action" %}')
            .done(function(data) {
                if (data.status === 'success') {
                    AlertMonitoring.showSuccess('Log check completed successfully!');
                    setTimeout(function() {
                        location.reload();
                    }, 1000);
                } else {
                    AlertMonitoring.showError(data.message);
                }
            })
            .fail(function(xhr) {
                AlertMonitoring.showError('Log check failed: ' + xhr.responseText);
            })
            .always(function() {
                AlertMonitoring.hideLoading(button);
            });
        },

        // Resolve alert
        resolveAlert: function(alertId) {
            if (!confirm('Mark this alert as resolved?')) {
                return;
            }

            $.post('{% url "alert_monitoring:resolve_alert_action" %}', {
                alert_id: alertId
            })
            .done(function(data) {
                if (data.status === 'success') {
                    AlertMonitoring.showSuccess(data.message);
                    setTimeout(function() {
                        location.reload();
                    }, 1000);
                } else {
                    AlertMonitoring.showError(data.message);
                }
            })
            .fail(function(xhr) {
                AlertMonitoring.showError('Failed to resolve alert: ' + xhr.responseText);
            });
        },

        // Initialize auto-refresh
        initAutoRefresh: function(intervalSeconds) {
            intervalSeconds = intervalSeconds || 30;

            setInterval(function() {
                // Only refresh if page is visible
                if (!document.hidden) {
                    location.reload();
                }
            }, intervalSeconds * 1000);
        },

        // Format timestamp for display
        formatTimestamp: function(timestamp) {
            const date = new Date(timestamp);
            return date.toLocaleString();
        },

        // Format bytes for display
        formatBytes: function(bytes) {
            if (bytes === 0) return '0 Bytes';
            const k = 1024;
            const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
            const i = Math.floor(Math.log(bytes) / Math.log(k));
            return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
        }
    };

})(jQuery);