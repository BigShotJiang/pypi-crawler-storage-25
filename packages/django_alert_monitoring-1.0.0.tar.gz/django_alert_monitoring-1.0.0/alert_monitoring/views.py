import json
from django.http import JsonResponse, HttpResponse
from django.views.decorators.http import require_GET, require_POST
from django.views.decorators.csrf import csrf_exempt
from django.shortcuts import render, get_object_or_404
from django.db.models import Q, Count
from django.utils import timezone
from prometheus_client import generate_latest, CONTENT_TYPE_LATEST
import psutil
import redis
from django.conf import settings
from django.db import connection
from datetime import timedelta
from .models import AlertHistory, SystemMetrics, APIMetrics, RedisMetrics, LogEntry
from .tasks import generate_test_alerts, check_system_health, monitor_redis, monitor_logs

@require_GET
def dashboard(request):
    """Main monitoring dashboard"""
    try:
        # Get system metrics
        cpu_percent = psutil.cpu_percent(interval=1)
        memory = psutil.virtual_memory()
        disk = psutil.disk_usage('/')

        # Get latest metrics from DB
        latest_metric = SystemMetrics.objects.order_by('-timestamp').first()
        system_metrics = {
            'cpu_usage': latest_metric.cpu_usage if latest_metric else cpu_percent,
            'memory_usage': latest_metric.memory_usage if latest_metric else memory.percent,
            'disk_usage': latest_metric.disk_usage if latest_metric else disk.percent,
        }

        # Check services
        health_status = get_health_status()

        # Get recent alerts (last 24 hours)
        recent_alerts = AlertHistory.objects.filter(
            triggered_at__gte=timezone.now() - timedelta(hours=24)
        ).order_by('-triggered_at')[:10]

        # Get alert statistics
        alert_stats = AlertHistory.objects.filter(
            triggered_at__gte=timezone.now() - timedelta(hours=24)
        ).aggregate(
            total=Count('id'),
            critical=Count('id', filter=Q(severity='Critical')),
            warning=Count('id', filter=Q(severity='Warning')),
            info=Count('id', filter=Q(severity='Info')),
        )

        context = {
            'system_metrics': system_metrics,
            'health_status': health_status,
            'recent_alerts': recent_alerts,
            'alert_stats': alert_stats,
            'last_update': timezone.now().strftime('%Y-%m-%d %H:%M:%S'),
        }

        return render(request, 'alert_monitoring/dashboard.html', context)
    except Exception as e:
        return render(request, 'alert_monitoring/dashboard.html', {'error': str(e)})


@require_GET
def alerts_view(request):
    """Alerts management view"""
    try:
        # Get filter parameters
        status = request.GET.get('status', 'all')  # all, active, resolved
        severity = request.GET.get('severity', 'all')  # all, Critical, Warning, Info
        alert_type = request.GET.get('type', 'all')  # all, api_error, system_resource, etc.

        # Build queryset
        alerts = AlertHistory.objects.all()

        if status == 'active':
            alerts = alerts.filter(resolved_at__isnull=True)
        elif status == 'resolved':
            alerts = alerts.filter(resolved_at__isnull=False)

        if severity != 'all':
            alerts = alerts.filter(severity=severity)

        if alert_type != 'all':
            alerts = alerts.filter(alert_type=alert_type)

        alerts = alerts.order_by('-triggered_at')

        # Get statistics
        total_alerts = alerts.count()
        active_alerts = alerts.filter(resolved_at__isnull=True)
        resolved_alerts = alerts.filter(resolved_at__isnull=False)

        stats = {
            'total': total_alerts,
            'active': active_alerts.count(),
            'resolved': resolved_alerts.count(),
            'critical': alerts.filter(severity='Critical').count(),
            'warning': alerts.filter(severity='Warning').count(),
            'info': alerts.filter(severity='Info').count(),
        }

        context = {
            'alerts': alerts[:100],  # Limit for performance
            'stats': stats,
            'filters': {
                'status': status,
                'severity': severity,
                'type': alert_type,
            }
        }

        return render(request, 'alert_monitoring/alerts.html', context)
    except Exception as e:
        return render(request, 'alert_monitoring/alerts.html', {'error': str(e)})


@require_GET
def system_metrics_view(request):
    """System metrics view with detailed information"""
    try:
        # Get current system metrics
        cpu_percent = psutil.cpu_percent(interval=1)
        memory = psutil.virtual_memory()
        disk = psutil.disk_usage('/')

        # Get historical data (last 24 hours)
        yesterday = timezone.now() - timedelta(hours=24)
        metrics_history = SystemMetrics.objects.filter(
            timestamp__gte=yesterday
        ).order_by('timestamp')

        # Prepare chart data
        chart_data = {
            'timestamps': [m.timestamp.strftime('%H:%M') for m in metrics_history],
            'cpu': [m.cpu_usage for m in metrics_history],
            'memory': [m.memory_usage for m in metrics_history],
            'disk': [m.disk_usage for m in metrics_history],
        }

        # Get latest Redis metrics
        latest_redis = RedisMetrics.objects.order_by('-timestamp').first()
        redis_info = None
        if latest_redis:
            redis_info = {
                'connected_clients': latest_redis.connected_clients,
                'used_memory': latest_redis.used_memory,
                'hit_ratio': latest_redis.hit_ratio,
                'is_connected': latest_redis.is_connected,
            }

        context = {
            'current_metrics': {
                'cpu_usage': cpu_percent,
                'memory_usage': memory.percent,
                'disk_usage': disk.percent,
                'network_connections': len(psutil.net_connections()),
            },
            'chart_data': json.dumps(chart_data),
            'redis_info': redis_info,
            'last_update': timezone.now().strftime('%Y-%m-%d %H:%M:%S'),
        }

        return render(request, 'alert_monitoring/system_metrics.html', context)
    except Exception as e:
        return render(request, 'alert_monitoring/system_metrics.html', {'error': str(e)})


@require_GET
def api_metrics_view(request):
    """API performance metrics view"""
    try:
        # Get API metrics summary
        yesterday = timezone.now() - timedelta(hours=24)

        # Response time statistics
        response_times = APIMetrics.objects.filter(
            timestamp__gte=yesterday
        ).values('endpoint').annotate(
            avg_response_time=Count('response_time'),
            error_count=Count('id', filter=Q(is_error=True)),
            total_requests=Count('id'),
        ).order_by('-total_requests')[:20]

        # Error rate by endpoint
        error_rates = []
        for stat in response_times:
            error_rate = (stat['error_count'] / stat['total_requests'] * 100) if stat['total_requests'] > 0 else 0
            error_rates.append({
                'endpoint': stat['endpoint'],
                'error_rate': error_rate,
                'total_requests': stat['total_requests'],
                'errors': stat['error_count'],
            })

        # Recent API errors
        recent_errors = APIMetrics.objects.filter(
            timestamp__gte=yesterday,
            is_error=True
        ).order_by('-timestamp')[:50]

        context = {
            'error_rates': error_rates,
            'recent_errors': recent_errors,
            'total_requests': APIMetrics.objects.filter(timestamp__gte=yesterday).count(),
            'total_errors': APIMetrics.objects.filter(timestamp__gte=yesterday, is_error=True).count(),
        }

        return render(request, 'alert_monitoring/api_metrics.html', context)
    except Exception as e:
        return render(request, 'alert_monitoring/api_metrics.html', {'error': str(e)})


@require_GET
def logs_view(request):
    """Log monitoring view"""
    try:
        # Get recent log entries
        recent_logs = LogEntry.objects.order_by('-timestamp')[:100]

        # Get log statistics
        yesterday = timezone.now() - timedelta(hours=24)
        log_stats = LogEntry.objects.filter(
            timestamp__gte=yesterday
        ).values('level').annotate(
            count=Count('id')
        ).order_by('-count')

        stats_dict = {stat['level']: stat['count'] for stat in log_stats}

        context = {
            'recent_logs': recent_logs,
            'log_stats': stats_dict,
            'total_logs': LogEntry.objects.filter(timestamp__gte=yesterday).count(),
        }

        return render(request, 'alert_monitoring/logs.html', context)
    except Exception as e:
        return render(request, 'alert_monitoring/logs.html', {'error': str(e)})


@require_GET
def health_check(request):
    """Basic health check endpoint"""
    health_status = get_health_status()
    status_code = 200 if all(health_status.values()) else 503

    return JsonResponse({
        'status': 'healthy' if status_code == 200 else 'unhealthy',
        **health_status
    }, status=status_code)


@require_GET
def detailed_health_check(request):
    """Detailed health check with system metrics"""
    try:
        health_status = get_health_status()

        # Get current metrics
        cpu_percent = psutil.cpu_percent(interval=1)
        memory = psutil.virtual_memory()
        disk = psutil.disk_usage('/')

        return JsonResponse({
            'status': 'healthy' if all(health_status.values()) else 'unhealthy',
            **health_status,
            'cpu_usage': f'{cpu_percent}%',
            'memory_usage': f'{memory.percent}%',
            'disk_usage': f'{disk.percent}%',
            'timestamp': timezone.now().isoformat(),
        })
    except Exception as e:
        return JsonResponse({'status': 'unhealthy', 'error': str(e)}, status=500)


@require_GET
def metrics(request):
    """Prometheus metrics endpoint"""
    return HttpResponse(generate_latest(), content_type=CONTENT_TYPE_LATEST)


# Action endpoints for generating test data

@require_POST
@csrf_exempt
def generate_alerts_action(request):
    """Endpoint to generate test alerts"""
    try:
        count = int(request.POST.get('count', 5))
        count = min(count, 50)  # Limit to 50 max

        # Execute synchronously for immediate response
        result = generate_test_alerts.apply(args=[count])

        return JsonResponse({
            'status': 'success',
            'message': f'Generated {result.get("count", 0)} test alerts',
            'data': result
        })
    except Exception as e:
        return JsonResponse({
            'status': 'error',
            'message': str(e)
        }, status=400)


@require_POST
@csrf_exempt
def run_health_check_action(request):
    """Endpoint to run manual health check"""
    try:
        result = check_system_health.apply()
        return JsonResponse({
            'status': 'success',
            'message': 'Health check completed',
            'data': result
        })
    except Exception as e:
        return JsonResponse({
            'status': 'error',
            'message': str(e)
        }, status=400)


@require_POST
@csrf_exempt
def run_redis_check_action(request):
    """Endpoint to run manual Redis check"""
    try:
        result = monitor_redis.apply()
        return JsonResponse({
            'status': 'success',
            'message': 'Redis check completed',
            'data': result
        })
    except Exception as e:
        return JsonResponse({
            'status': 'error',
            'message': str(e)
        }, status=400)


@require_POST
@csrf_exempt
def run_log_check_action(request):
    """Endpoint to run manual log check"""
    try:
        result = monitor_logs.apply()
        return JsonResponse({
            'status': 'success',
            'message': 'Log check completed',
            'data': result
        })
    except Exception as e:
        return JsonResponse({
            'status': 'error',
            'message': str(e)
        }, status=400)


@require_POST
@csrf_exempt
def resolve_alert_action(request):
    """Endpoint to resolve an alert"""
    try:
        alert_id = request.POST.get('alert_id')
        if not alert_id:
            return JsonResponse({
                'status': 'error',
                'message': 'Alert ID is required'
            }, status=400)

        alert = get_object_or_404(AlertHistory, id=alert_id)
        alert.resolve()

        return JsonResponse({
            'status': 'success',
            'message': f'Alert "{alert.alert_name}" resolved'
        })
    except Exception as e:
        return JsonResponse({
            'status': 'error',
            'message': str(e)
        }, status=400)


def get_health_status():
    """Get health status of all services"""
    health_status = {}

    # Check database
    try:
        with connection.cursor() as cursor:
            cursor.execute("SELECT 1")
        health_status['database'] = True
    except:
        health_status['database'] = False

    # Check Redis
    try:
        redis_url = getattr(settings, 'CELERY_BROKER_URL', None) or getattr(settings, 'REDIS_URL', None)
        if redis_url:
            r = redis.Redis.from_url(redis_url)
            r.ping()
            health_status['redis'] = True
        else:
            health_status['redis'] = None  # Not configured
    except:
        health_status['redis'] = False

    # Check Celery (simplified check)
    try:
        from config.celery import app
        inspect = app.control.inspect()
        workers = inspect.active()
        health_status['celery'] = len(workers or {}) > 0
    except:
        health_status['celery'] = False

    return health_status