"""
Django Alert & Monitoring Package

Provides comprehensive monitoring and alerting capabilities for Django applications.
"""

__version__ = '1.0.0'
__author__ = 'Your Name'
__email__ = 'your.email@example.com'

default_app_config = 'alert_monitoring.apps.AlertMonitoringConfig'