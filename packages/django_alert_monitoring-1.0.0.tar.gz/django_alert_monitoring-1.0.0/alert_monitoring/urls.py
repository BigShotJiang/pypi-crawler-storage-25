from django.urls import path
from . import views

app_name = 'alert_monitoring'

urlpatterns = [
    # Dashboard
    path('', views.dashboard, name='dashboard'),
    path('dashboard/', views.dashboard, name='dashboard'),

    # Monitoring views
    path('alerts/', views.alerts_view, name='alerts'),
    path('system-metrics/', views.system_metrics_view, name='system_metrics'),
    path('api-metrics/', views.api_metrics_view, name='api_metrics'),
    path('logs/', views.logs_view, name='logs'),

    # API endpoints
    path('api/health/', views.health_check, name='health_check'),
    path('api/health/detailed/', views.detailed_health_check, name='detailed_health_check'),
    path('api/metrics/', views.metrics, name='metrics'),

    # Action endpoints
    path('api/actions/generate-alerts/', views.generate_alerts_action, name='generate_alerts_action'),
    path('api/actions/health-check/', views.run_health_check_action, name='run_health_check_action'),
    path('api/actions/redis-check/', views.run_redis_check_action, name='run_redis_check_action'),
    path('api/actions/log-check/', views.run_log_check_action, name='run_log_check_action'),
    path('api/actions/resolve-alert/', views.resolve_alert_action, name='resolve_alert_action'),
]