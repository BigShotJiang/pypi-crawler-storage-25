"""
Signals for alert monitoring
"""

from django.db.models.signals import post_save
from django.dispatch import receiver
from .models import AlertHistory
from .tasks import send_email_alert


@receiver(post_save, sender=AlertHistory)
def alert_created_handler(sender, instance, created, **kwargs):
    """
    Handle alert creation - send email if configured
    """
    if created and not instance.email_sent:
        # Send email asynchronously
        send_email_alert.delay(instance.id)