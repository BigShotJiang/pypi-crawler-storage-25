from django.core.management.base import BaseCommand
from alert_monitoring.tasks import cleanup_old_data


class Command(BaseCommand):
    help = 'Clear old monitoring data and resolved alerts'

    def add_arguments(self, parser):
        parser.add_argument(
            '--days',
            type=int,
            default=30,
            help='Keep data for this many days (default: 30)',
        )
        parser.add_argument(
            '--dry-run',
            action='store_true',
            help='Show what would be deleted without actually deleting',
        )

    def handle(self, *args, **options):
        days = options['days']
        dry_run = options['dry_run']

        if dry_run:
            self.stdout.write(f'Dry run: Would clean up data older than {days} days')
        else:
            self.stdout.write(f'Cleaning up data older than {days} days...')

        result = cleanup_old_data.apply(args=[days])

        if result.get('status') == 'success':
            if dry_run:
                self.stdout.write('Data that would be deleted:')
            else:
                self.stdout.write('Successfully cleaned up:')

            self.stdout.write(f'  - System metrics: {result.get("metrics_deleted", 0)}')
            self.stdout.write(f'  - API metrics: {result.get("api_metrics_deleted", 0)}')
            self.stdout.write(f'  - Redis metrics: {result.get("redis_metrics_deleted", 0)}')
            self.stdout.write(f'  - Log entries: {result.get("logs_deleted", 0)}')
            self.stdout.write(f'  - Resolved alerts: {result.get("alerts_deleted", 0)}')
        else:
            self.stdout.write(
                self.style.ERROR(f'Cleanup failed: {result.get("message")}')
            )