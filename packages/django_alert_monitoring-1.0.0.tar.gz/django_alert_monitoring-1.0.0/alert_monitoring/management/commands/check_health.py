from django.core.management.base import BaseCommand
from alert_monitoring.tasks import check_system_health, monitor_redis, monitor_logs


class Command(BaseCommand):
    help = 'Run manual health check on all systems'

    def handle(self, *args, **options):
        self.stdout.write('Running system health check...')

        # Run system health check
        result = check_system_health.apply()
        if result.get('status') == 'success':
            self.stdout.write(
                self.style.SUCCESS(
                    f'✓ System Health: CPU {result.get("cpu")}%, '
                    f'Memory {result.get("memory")}%, Disk {result.get("disk")}%'
                )
            )
            if result.get('alerts_created', 0) > 0:
                self.stdout.write(
                    self.style.WARNING(f'⚠️  {result.get("alerts_created")} alerts created')
                )
        else:
            self.stdout.write(
                self.style.ERROR(f'✗ System Health Check Failed: {result.get("message")}')
            )

        # Run Redis check
        result = monitor_redis.apply()
        if result.get('status') == 'success':
            self.stdout.write(
                self.style.SUCCESS(
                    f'✓ Redis: {result.get("connected_clients")} clients, '
                    f'{result.get("used_memory")} bytes memory'
                )
            )
        else:
            self.stdout.write(
                self.style.ERROR(f'✗ Redis Check Failed: {result.get("message")}')
            )

        # Run log check
        result = monitor_logs.apply()
        if result.get('status') == 'success':
            errors_found = result.get('errors_found', 0)
            alerts_created = result.get('alerts_created', 0)
            if errors_found > 0:
                self.stdout.write(
                    self.style.WARNING(f'⚠️  Log Check: {errors_found} errors found, {alerts_created} alerts created')
                )
            else:
                self.stdout.write(self.style.SUCCESS('✓ Log Check: No errors found'))
        else:
            self.stdout.write(
                self.style.ERROR(f'✗ Log Check Failed: {result.get("message")}')
            )

        self.stdout.write(self.style.SUCCESS('Health check completed'))