from django.core.management.base import BaseCommand
from alert_monitoring.tasks import (
    check_system_health, monitor_redis, monitor_logs,
    monitor_celery_workers, cleanup_old_data
)


class Command(BaseCommand):
    help = 'Start all monitoring tasks'

    def add_arguments(self, parser):
        parser.add_argument(
            '--interval',
            type=int,
            default=60,
            help='Monitoring interval in seconds (default: 60)',
        )

    def handle(self, *args, **options):
        from django_celery_beat.models import PeriodicTask, IntervalSchedule
        from django.utils import timezone

        interval_seconds = options['interval']

        # Create or get interval schedule
        schedule, created = IntervalSchedule.objects.get_or_create(
            every=interval_seconds,
            period=IntervalSchedule.SECONDS,
        )

        # System health monitoring
        PeriodicTask.objects.get_or_create(
            name='System Health Check',
            task='alert_monitoring.tasks.check_system_health',
            interval=schedule,
            defaults={
                'enabled': True,
                'start_time': timezone.now(),
            }
        )

        # Redis monitoring
        PeriodicTask.objects.get_or_create(
            name='Redis Monitoring',
            task='alert_monitoring.tasks.monitor_redis',
            interval=schedule,
            defaults={
                'enabled': True,
                'start_time': timezone.now(),
            }
        )

        # Log monitoring
        PeriodicTask.objects.get_or_create(
            name='Log Monitoring',
            task='alert_monitoring.tasks.monitor_logs',
            interval=schedule,
            defaults={
                'enabled': True,
                'start_time': timezone.now(),
            }
        )

        # Celery monitoring
        PeriodicTask.objects.get_or_create(
            name='Celery Worker Monitoring',
            task='alert_monitoring.tasks.monitor_celery_workers',
            interval=schedule,
            defaults={
                'enabled': True,
                'start_time': timezone.now(),
            }
        )

        # Cleanup old data (daily)
        daily_schedule, _ = IntervalSchedule.objects.get_or_create(
            every=1,
            period=IntervalSchedule.DAYS,
        )
        PeriodicTask.objects.get_or_create(
            name='Cleanup Old Data',
            task='alert_monitoring.tasks.cleanup_old_data',
            interval=daily_schedule,
            defaults={
                'enabled': True,
                'start_time': timezone.now(),
            }
        )

        self.stdout.write(
            self.style.SUCCESS(
                f'Successfully scheduled monitoring tasks with {interval_seconds}s interval'
            )
        )