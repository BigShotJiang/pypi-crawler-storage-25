import os
import re
import logging
from django.conf import settings
from django.core.cache import cache
from django.utils import timezone

logger = logging.getLogger(__name__)


def get_alert_monitoring_config():
    """Get alert monitoring configuration from Django settings"""
    return getattr(settings, 'ALERT_MONITORING', {})


def get_admin_emails():
    """Get list of admin emails for alerts"""
    config = get_alert_monitoring_config()
    return config.get('ADMIN_EMAILS', [])


def get_email_subject_prefix():
    """Get email subject prefix"""
    config = get_alert_monitoring_config()
    return config.get('EMAIL_SUBJECT_PREFIX', '[ALERT] ')


def get_api_error_threshold():
    """Get API error threshold"""
    config = get_alert_monitoring_config()
    return config.get('API_ERROR_THRESHOLD', 10)


def get_api_error_window():
    """Get API error monitoring window in seconds"""
    config = get_alert_monitoring_config()
    return config.get('API_ERROR_WINDOW', 300)  # 5 minutes


def get_system_thresholds():
    """Get system resource thresholds"""
    config = get_alert_monitoring_config()
    return config.get('SYSTEM_THRESHOLDS', {
        'CPU_WARNING': 80,
        'CPU_CRITICAL': 95,
        'MEMORY_WARNING': 85,
        'MEMORY_CRITICAL': 95,
        'DISK_WARNING': 90,
        'DISK_CRITICAL': 98,
    })


def get_redis_check_interval():
    """Get Redis check interval in seconds"""
    config = get_alert_monitoring_config()
    return config.get('REDIS_CHECK_INTERVAL', 60)


def get_log_check_interval():
    """Get log check interval in seconds"""
    config = get_alert_monitoring_config()
    return config.get('LOG_CHECK_INTERVAL', 300)


def get_log_file_path():
    """Get log file path for monitoring"""
    config = get_alert_monitoring_config()
    return config.get('LOG_FILE_PATH', '/var/log/django/django.log')


def get_log_error_patterns():
    """Get log error patterns to monitor"""
    config = get_alert_monitoring_config()
    return config.get('LOG_ERROR_PATTERNS', [
        r'ERROR',
        r'CRITICAL',
        r'Exception',
        r'Traceback',
    ])


def should_send_email_alert():
    """Check if email alerts should be sent"""
    config = get_alert_monitoring_config()
    return config.get('ENABLE_EMAIL_ALERTS', True)


def should_enable_prometheus():
    """Check if Prometheus metrics should be enabled"""
    config = get_alert_monitoring_config()
    return config.get('ENABLE_PROMETHEUS', True)


def get_prometheus_port():
    """Get Prometheus metrics export port"""
    config = get_alert_monitoring_config()
    return config.get('PROMETHEUS_PORT', 8001)


def parse_log_line(line):
    """Parse a log line and extract structured information"""
    # Common Django log format: [timestamp] level module message
    pattern = r'\[(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}(?:,\d{3})?)\]\s+(\w+)\s+(\w+)\s+(.+)'
    match = re.match(pattern, line.strip())

    if match:
        timestamp_str, level, module, message = match.groups()
        try:
            # Parse timestamp
            if ',' in timestamp_str:
                timestamp = timezone.datetime.strptime(timestamp_str, '%Y-%m-%d %H:%M:%S,%f')
            else:
                timestamp = timezone.datetime.strptime(timestamp_str, '%Y-%m-%d %H:%M:%S')
            timestamp = timezone.make_aware(timestamp)

            return {
                'timestamp': timestamp,
                'level': level,
                'module': module,
                'message': message,
                'raw_line': line,
            }
        except ValueError:
            pass

    # Fallback: try to extract basic info
    return {
        'timestamp': timezone.now(),
        'level': 'UNKNOWN',
        'module': 'unknown',
        'message': line.strip(),
        'raw_line': line,
    }


def check_log_for_errors(log_file_path=None):
    """Check log file for error patterns"""
    if log_file_path is None:
        log_file_path = get_log_file_path()

    if not os.path.exists(log_file_path):
        return []

    errors = []
    patterns = get_log_error_patterns()

    try:
        with open(log_file_path, 'r', encoding='utf-8', errors='ignore') as f:
            # Read last 1000 lines for efficiency
            lines = f.readlines()[-1000:]

        for line in lines:
            line = line.strip()
            if not line:
                continue

            parsed = parse_log_line(line)

            # Check if line matches error patterns
            for pattern in patterns:
                if re.search(pattern, line, re.IGNORECASE):
                    errors.append(parsed)
                    break

    except Exception as e:
        logger.error(f"Failed to check log file {log_file_path}: {e}")

    return errors


def get_cache_key(prefix, *args):
    """Generate cache key"""
    return f"alert_monitoring:{prefix}:{':'.join(str(arg) for arg in args)}"


def set_cache_with_expiry(key, value, expiry_seconds=300):
    """Set cache with expiry"""
    cache.set(key, value, expiry_seconds)


def get_cache_value(key):
    """Get cache value"""
    return cache.get(key)


def clear_cache_pattern(pattern):
    """Clear cache keys matching pattern"""
    # Note: This is a simple implementation. In production, you might want
    # to use a more sophisticated cache clearing mechanism
    pass


def format_alert_message(alert_name, severity, message, metadata=None):
    """Format alert message for notifications"""
    formatted = f"""
🚨 {severity.upper()} ALERT 🚨

Alert: {alert_name}
Time: {timezone.now().strftime('%Y-%m-%d %H:%M:%S')}
Message: {message}
"""

    if metadata:
        formatted += f"\nDetails:\n"
        for key, value in metadata.items():
            formatted += f"- {key}: {value}\n"

    return formatted.strip()


def send_test_email():
    """Send a test email to verify email configuration"""
    from django.core.mail import send_mail

    admin_emails = get_admin_emails()
    if not admin_emails:
        return False, "No admin emails configured"

    try:
        send_mail(
            subject=f"{get_email_subject_prefix()}Test Alert",
            message="This is a test alert from Django Alert & Monitoring package.",
            from_email=getattr(settings, 'DEFAULT_FROM_EMAIL', 'alerts@django.local'),
            recipient_list=admin_emails,
            fail_silently=False,
        )
        return True, "Test email sent successfully"
    except Exception as e:
        return False, f"Failed to send test email: {e}"