# Generated migration for alert_monitoring app

from django.db import migrations, models
import django.utils.timezone


class Migration(migrations.Migration):

    initial = True

    dependencies = [
    ]

    operations = [
        migrations.CreateModel(
            name='AlertHistory',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('alert_name', models.CharField(max_length=255)),
                ('alert_type', models.CharField(choices=[('api_error', 'API Error'), ('system_resource', 'System Resource'), ('redis_connection', 'Redis Connection'), ('log_error', 'Log Error'), ('custom', 'Custom')], default='custom', max_length=20)),
                ('severity', models.CharField(choices=[('Info', 'Info'), ('Warning', 'Warning'), ('Critical', 'Critical')], default='Info', max_length=20)),
                ('message', models.TextField()),
                ('triggered_at', models.DateTimeField(auto_now_add=True)),
                ('resolved_at', models.DateTimeField(blank=True, null=True)),
                ('resolved_by', models.CharField(blank=True, max_length=100)),
                ('metadata', models.JSONField(blank=True, default=dict)),
                ('email_sent', models.BooleanField(default=False)),
                ('email_sent_at', models.DateTimeField(blank=True, null=True)),
            ],
            options={
                'ordering': ['-triggered_at'],
            },
        ),
        migrations.CreateModel(
            name='AlertRule',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('name', models.CharField(max_length=255, unique=True)),
                ('rule_type', models.CharField(choices=[('threshold', 'Threshold'), ('pattern', 'Pattern Match'), ('frequency', 'Frequency')], max_length=20)),
                ('metric', models.CharField(max_length=100)),
                ('condition', models.CharField(max_length=50)),
                ('threshold', models.FloatField()),
                ('severity', models.CharField(choices=[('Info', 'Info'), ('Warning', 'Warning'), ('Critical', 'Critical')], default='Info', max_length=20)),
                ('enabled', models.BooleanField(default=True)),
                ('cooldown_minutes', models.IntegerField(default=60)),
                ('last_alert_at', models.DateTimeField(blank=True, null=True)),
            ],
            options={
                'ordering': ['name'],
            },
        ),
        migrations.CreateModel(
            name='APIMetrics',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('timestamp', models.DateTimeField(auto_now_add=True)),
                ('endpoint', models.CharField(max_length=500)),
                ('method', models.CharField(max_length=10)),
                ('status_code', models.IntegerField()),
                ('response_time', models.FloatField(help_text='Response time in seconds')),
                ('request_size', models.IntegerField(default=0, help_text='Request size in bytes')),
                ('response_size', models.IntegerField(default=0, help_text='Response size in bytes')),
                ('is_error', models.BooleanField(default=False)),
                ('error_message', models.TextField(blank=True)),
            ],
            options={
                'ordering': ['-timestamp'],
            },
        ),
        migrations.CreateModel(
            name='LogEntry',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('timestamp', models.DateTimeField()),
                ('level', models.CharField(choices=[('DEBUG', 'Debug'), ('INFO', 'Info'), ('WARNING', 'Warning'), ('ERROR', 'Error'), ('CRITICAL', 'Critical')], max_length=10)),
                ('message', models.TextField()),
                ('logger_name', models.CharField(max_length=255)),
                ('module', models.CharField(blank=True, max_length=255)),
                ('function', models.CharField(blank=True, max_length=255)),
                ('line_number', models.IntegerField(blank=True, null=True)),
                ('exception', models.TextField(blank=True)),
                ('alert_created', models.BooleanField(default=False)),
            ],
            options={
                'ordering': ['-timestamp'],
            },
        ),
        migrations.CreateModel(
            name='RedisMetrics',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('timestamp', models.DateTimeField(auto_now_add=True)),
                ('connected_clients', models.IntegerField(default=0)),
                ('used_memory', models.BigIntegerField(default=0, help_text='Used memory in bytes')),
                ('total_connections_received', models.BigIntegerField(default=0)),
                ('total_commands_processed', models.BigIntegerField(default=0)),
                ('instantaneous_ops_per_sec', models.IntegerField(default=0)),
                ('keyspace_hits', models.BigIntegerField(default=0)),
                ('keyspace_misses', models.BigIntegerField(default=0)),
                ('is_connected', models.BooleanField(default=True)),
            ],
            options={
                'ordering': ['-timestamp'],
            },
        ),
        migrations.CreateModel(
            name='SystemMetrics',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('timestamp', models.DateTimeField(auto_now_add=True)),
                ('cpu_usage', models.FloatField(help_text='CPU usage percentage')),
                ('memory_usage', models.FloatField(help_text='Memory usage percentage')),
                ('disk_usage', models.FloatField(help_text='Disk usage percentage')),
                ('network_connections', models.IntegerField(default=0, help_text='Active network connections')),
                ('load_average', models.FloatField(blank=True, help_text='System load average', null=True)),
            ],
            options={
                'ordering': ['-timestamp'],
            },
        ),
        migrations.AddIndex(
            model_name='alerthistory',
            index=models.Index(fields=['alert_type', 'severity'], name='alert_monito_alert_t_8b9c8a_idx'),
        ),
        migrations.AddIndex(
            model_name='alerthistory',
            index=models.Index(fields=['triggered_at'], name='alert_monito_trigger_ea7b8c_idx'),
        ),
        migrations.AddIndex(
            model_name='alerthistory',
            index=models.Index(fields=['resolved_at'], name='alert_monito_resolve_4b8c9d_idx'),
        ),
        migrations.AddIndex(
            model_name='apimetrics',
            index=models.Index(fields=['endpoint', 'status_code'], name='alert_monito_endpoin_4f7c8a_idx'),
        ),
        migrations.AddIndex(
            model_name='apimetrics',
            index=models.Index(fields=['timestamp'], name='alert_monito_timesta_5b8c9d_idx'),
        ),
        migrations.AddIndex(
            model_name='apimetrics',
            index=models.Index(fields=['is_error'], name='alert_monito_is_erro_6c9d0e_idx'),
        ),
        migrations.AddIndex(
            model_name='logentry',
            index=models.Index(fields=['level', 'timestamp'], name='alert_monito_level_t_7d0e1f_idx'),
        ),
        migrations.AddIndex(
            model_name='logentry',
            index=models.Index(fields=['alert_created'], name='alert_monito_alert_c_8e1f2g_idx'),
        ),
        migrations.AddIndex(
            model_name='systemmetrics',
            index=models.Index(fields=['timestamp'], name='alert_monito_timesta_9f2g3h_idx'),
        ),
    ]