from django.apps import AppConfig


class AlertMonitoringConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'alert_monitoring'
    verbose_name = 'Alert & Monitoring'

    def ready(self):
        # Import signals to register them
        from . import signals