import time
import logging
from django.conf import settings
from django.core.mail import send_mail
from django.utils import timezone
from prometheus_client import Counter, Histogram, Gauge
from .models import APIMetrics, AlertHistory
from .utils import should_send_email_alert, get_api_error_threshold

# Prometheus metrics
REQUEST_COUNT = Counter('django_http_requests_total', 'Total HTTP requests', ['method', 'endpoint', 'status'])
REQUEST_LATENCY = Histogram('django_http_request_duration_seconds', 'HTTP request duration', ['method', 'endpoint'])
ACTIVE_REQUESTS = Gauge('django_http_active_requests', 'Active HTTP requests')
API_ERRORS = Counter('django_api_errors_total', 'Total API errors', ['method', 'endpoint', 'status'])

logger = logging.getLogger(__name__)


class APIMonitoringMiddleware:
    """
    Middleware to monitor API requests and send alerts on errors
    """

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        ACTIVE_REQUESTS.inc()
        start_time = time.time()

        response = self.get_response(request)

        duration = time.time() - start_time
        ACTIVE_REQUESTS.dec()

        # Record metrics
        REQUEST_COUNT.labels(
            method=request.method,
            endpoint=request.path,
            status=response.status_code
        ).inc()

        REQUEST_LATENCY.labels(
            method=request.method,
            endpoint=request.path
        ).observe(duration)

        # Check for API errors
        is_error = response.status_code >= 400
        if is_error:
            API_ERRORS.labels(
                method=request.method,
                endpoint=request.path,
                status=response.status_code
            ).inc()

        # Store API metrics
        try:
            APIMetrics.objects.create(
                endpoint=request.path,
                method=request.method,
                status_code=response.status_code,
                response_time=duration,
                is_error=is_error,
            )
        except Exception as e:
            logger.error(f"Failed to store API metrics: {e}")

        # Check for alert conditions
        if is_error:
            self._check_api_error_alerts(request, response, duration)

        return response

    def _check_api_error_alerts(self, request, response, duration):
        """Check if we should create alerts for API errors"""
        try:
            # Check error frequency in the last 5 minutes
            five_minutes_ago = timezone.now() - timezone.timedelta(minutes=5)
            recent_errors = APIMetrics.objects.filter(
                endpoint=request.path,
                is_error=True,
                timestamp__gte=five_minutes_ago
            ).count()

            threshold = get_api_error_threshold()
            if recent_errors >= threshold:
                # Create alert
                alert = AlertHistory.objects.create(
                    alert_name=f'High API Error Rate: {request.path}',
                    alert_type='api_error',
                    severity='Critical' if response.status_code >= 500 else 'Warning',
                    message=f'API endpoint {request.path} has {recent_errors} errors in the last 5 minutes '
                           f'(threshold: {threshold}). Last error: {response.status_code} - {duration:.2f}s',
                    metadata={
                        'endpoint': request.path,
                        'method': request.method,
                        'status_code': response.status_code,
                        'response_time': duration,
                        'error_count': recent_errors,
                        'threshold': threshold,
                    }
                )

                # Send email alert if configured
                if should_send_email_alert():
                    self._send_email_alert(alert)

        except Exception as e:
            logger.error(f"Failed to check API error alerts: {e}")

    def _send_email_alert(self, alert):
        """Send email notification for alert"""
        try:
            from .utils import get_admin_emails, get_email_subject_prefix

            admin_emails = get_admin_emails()
            if not admin_emails:
                return

            subject = f"{get_email_subject_prefix()}{alert.alert_name}"
            message = f"""
Alert Details:
- Name: {alert.alert_name}
- Type: {alert.alert_type}
- Severity: {alert.severity}
- Time: {alert.triggered_at}
- Message: {alert.message}

Metadata: {alert.metadata}

This is an automated alert from Django Alert & Monitoring.
"""

            send_mail(
                subject=subject,
                message=message,
                from_email=getattr(settings, 'DEFAULT_FROM_EMAIL', 'alerts@django.local'),
                recipient_list=admin_emails,
                fail_silently=True,
            )

            # Mark email as sent
            alert.email_sent = True
            alert.email_sent_at = timezone.now()
            alert.save()

        except Exception as e:
            logger.error(f"Failed to send email alert: {e}")


class LogMonitoringMiddleware:
    """
    Middleware to capture and monitor application logs
    """

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        # Add custom logging for requests
        logger.info(f"Request: {request.method} {request.path} from {request.META.get('REMOTE_ADDR')}")

        response = self.get_response(request)

        # Log response
        if response.status_code >= 400:
            logger.warning(f"Error response: {response.status_code} for {request.method} {request.path}")

        return response