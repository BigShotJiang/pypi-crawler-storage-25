"""
Tests for django-alert-monitoring package
"""

import json
from django.test import TestCase
from django.urls import reverse
from django.contrib.auth.models import User
from alert_monitoring.models import AlertHistory, SystemMetrics, APIMetrics


class AlertMonitoringTestCase(TestCase):

    def setUp(self):
        self.user = User.objects.create_user(
            username='testuser',
            password='testpass123'
        )

    def test_dashboard_view(self):
        """Test dashboard view loads correctly"""
        self.client.login(username='testuser', password='testpass123')
        response = self.client.get(reverse('alert_monitoring:dashboard'))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'Alert & Monitoring Dashboard')

    def test_health_check_endpoint(self):
        """Test health check API endpoint"""
        response = self.client.get(reverse('alert_monitoring:health_check'))
        self.assertEqual(response.status_code, 200)
        data = json.loads(response.content)
        self.assertIn('status', data)

    def test_generate_test_alerts(self):
        """Test generating test alerts"""
        self.client.login(username='testuser', password='testpass123')

        # Count alerts before
        before_count = AlertHistory.objects.count()

        # Generate alerts
        response = self.client.post(
            reverse('alert_monitoring:generate_alerts_action'),
            {'count': 3}
        )
        self.assertEqual(response.status_code, 200)

        # Check alerts were created
        after_count = AlertHistory.objects.count()
        self.assertEqual(after_count, before_count + 3)

    def test_alert_model(self):
        """Test AlertHistory model"""
        alert = AlertHistory.objects.create(
            alert_name='Test Alert',
            severity='Warning',
            message='This is a test alert'
        )

        self.assertEqual(str(alert), 'Test Alert - Warning')
        self.assertFalse(alert.is_active())

        # Test resolution
        alert.resolve('testuser')
        self.assertTrue(alert.resolved_at is not None)
        self.assertEqual(alert.resolved_by, 'testuser')

    def test_system_metrics_model(self):
        """Test SystemMetrics model"""
        metrics = SystemMetrics.objects.create(
            cpu_usage=45.5,
            memory_usage=67.8,
            disk_usage=23.4
        )

        self.assertEqual(str(metrics), f"Metrics at {metrics.timestamp}")
        self.assertFalse(metrics.is_critical)

        # Test critical metrics
        critical_metrics = SystemMetrics.objects.create(
            cpu_usage=95.5,
            memory_usage=96.8,
            disk_usage=97.4
        )
        self.assertTrue(critical_metrics.is_critical)

    def test_api_metrics_model(self):
        """Test APIMetrics model"""
        api_metric = APIMetrics.objects.create(
            endpoint='/api/test/',
            method='GET',
            status_code=200,
            response_time=0.145,
            is_error=False
        )

        self.assertEqual(str(api_metric), 'GET /api/test/ - 200')
        self.assertFalse(api_metric.is_error)

        # Test error metric
        error_metric = APIMetrics.objects.create(
            endpoint='/api/error/',
            method='POST',
            status_code=500,
            response_time=2.5,
            is_error=True,
            error_message='Internal Server Error'
        )
        self.assertTrue(error_metric.is_error)