#!/usr/bin/env python3
"""
Pathfinder User Onboarding Script

Two-step onboarding:
  1. POST /api/auth/UserInvitation       -> creates user in org
  2. POST /api/auth/siteaccess/{siteId}/user/{userId} -> grants site + product access

Usage:
    python pf_onboard.py --token <JWT> --email user@example.com
    python pf_onboard.py --token <JWT> --emails emails.txt
    python pf_onboard.py --token <JWT> --emails emails.txt --products entitle pra
    python pf_onboard.py --token <JWT> --emails emails.txt --cancel

Lookups (no email required):
    python pf_onboard.py --token <JWT> --info
    python pf_onboard.py --token <JWT> --list-users

Auth:
    --token is a browser JWT from app.beyondtrust.io (access cookie, ~5 min TTL).
    Use an admin/org-level token (scope=admin, aud=orgId) for full access.
    Grab from DevTools > Application > Cookies > access.

Finding your org info:
    While logged into Pathfinder, call GET https://app.beyondtrust.io/api/platform/currentSite
    The response includes your site_id (GUID), site name, and available products.

Examples:
    # Set your token as a variable (grab from DevTools > Application > Cookies > access)
    export PF_TOKEN="eyJhbG..."

    # Check your site info and available products
    python pf_onboard.py --token $PF_TOKEN --info

    # List existing users in the org
    python pf_onboard.py --token $PF_TOKEN --list-users

    # Onboard a single user with default product (entitle)
    python pf_onboard.py --token $PF_TOKEN --email user@example.com

    # Onboard with multiple products
    python pf_onboard.py --token $PF_TOKEN --email user@example.com --products entitle pra

    # Bulk onboard from a file
    python pf_onboard.py --token $PF_TOKEN --emails emails.txt --products entitle pra

    # Preview without making API calls
    python pf_onboard.py --token $PF_TOKEN --emails emails.txt --dry-run

    # Grant site access to an existing user (skip invitation)
    python pf_onboard.py --token $PF_TOKEN --email user@example.com --grant-only --products pra

    # Cancel a pending invitation
    python pf_onboard.py --token $PF_TOKEN --email user@example.com --cancel

Notes:
    - UserInvitation returns userId needed for site access grant
    - If user already exists (409), you can still grant site access with --grant-only
    - Product IDs are lowercase: entitle, pra, psc, epmwm, epml, rs, insights
"""
import argparse
import json
import sys
import requests

BASE_URL = "https://app.beyondtrust.io/api/auth"
PLATFORM_URL = "https://app.beyondtrust.io/api/platform"
DEFAULT_SITE_ID = "c882e07c-753b-4fcd-a1e6-7d39defec5ae"
DEFAULT_SITE_NAME = "Production - Americas"
DEFAULT_RESIDENCY = "US"
DEFAULT_PRODUCTS = ["entitle"]


def verify_token(token):
    resp = requests.get(f"{BASE_URL}/UserInfo", cookies={"access": token})
    if resp.status_code != 200:
        return None
    return resp.json()


def invite_user(token, email, first_name, last_name, products, site_id, site_name, residency):
    """Step 1: Create user invitation."""
    body = {
        "Email": email,
        "FirstName": first_name,
        "LastName": last_name,
        "ProductMetaData": [
            {"Name": p.upper(), "SiteId": site_id, "SiteName": site_name}
            for p in products
        ],
        "SiteMetaData": [
            {"SiteId": site_id, "Residency": residency, "Name": site_name}
        ],
    }
    resp = requests.post(
        f"{BASE_URL}/UserInvitation",
        headers={"Content-Type": "application/json"},
        cookies={"access": token},
        data=json.dumps(body),
    )
    return resp.status_code, resp.json() if resp.headers.get("content-type", "").startswith("application/json") else resp.text


def grant_site_access(token, site_id, user_id, products):
    """Step 2: Grant site access + products."""
    resp = requests.post(
        f"{BASE_URL}/siteaccess/{site_id}/user/{user_id}",
        headers={"Content-Type": "application/json"},
        cookies={"access": token},
        data=json.dumps(products),
    )
    return resp.status_code, resp.json() if resp.headers.get("content-type", "").startswith("application/json") else resp.text


def cancel_invitation(token, email):
    resp = requests.post(
        f"{BASE_URL}/UserInvitation/Cancel",
        headers={"Content-Type": "application/json"},
        cookies={"access": token},
        data=json.dumps({"Email": email}),
    )
    return resp.status_code, resp.text


def find_user_id(token, email):
    """Look up userId from the users list (for --grant-only mode)."""
    resp = requests.get(f"{BASE_URL}/Users", cookies={"access": token})
    if resp.status_code != 200:
        return None
    for user in resp.json():
        if user.get("email", "").lower() == email.lower():
            return user["id"]
    return None



def get_site_info(token):
    """Fetch current site info: site ID, name, residency, products."""
    resp = requests.get(f"{PLATFORM_URL}/currentSite", cookies={"access": token})
    if resp.status_code != 200:
        return None
    return resp.json()


def list_users(token):
    """Fetch all users in the org."""
    resp = requests.get(f"{BASE_URL}/Users", cookies={"access": token})
    if resp.status_code != 200:
        return None
    return resp.json()


def main():
    epilog = """
examples:
  # Set your token as a variable (grab from DevTools > Application > Cookies > access)
  export PF_TOKEN="eyJhbG..."

  # Check your site info and available products
  python pf_onboard.py --token $PF_TOKEN --info

  # List existing users in the org
  python pf_onboard.py --token $PF_TOKEN --list-users

  # Onboard a single user with default product (entitle)
  python pf_onboard.py --token $PF_TOKEN --email user@example.com

  # Onboard with multiple products
  python pf_onboard.py --token $PF_TOKEN --email user@example.com --products entitle pra

  # Bulk onboard from a file
  python pf_onboard.py --token $PF_TOKEN --emails emails.txt --products entitle pra

  # Preview without making API calls
  python pf_onboard.py --token $PF_TOKEN --emails emails.txt --dry-run

  # Grant site access to an existing user (skip invitation)
  python pf_onboard.py --token $PF_TOKEN --email user@example.com --grant-only --products pra

  # Cancel a pending invitation
  python pf_onboard.py --token $PF_TOKEN --email user@example.com --cancel

finding your org info:
  While logged into Pathfinder, call GET https://app.beyondtrust.io/api/platform/currentSite
  The response includes your site_id (GUID), site name, and available products.
"""
    parser = argparse.ArgumentParser(
        description="Onboard users to BeyondTrust Pathfinder",
        epilog=epilog,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument("--token", required=True, help="Browser JWT (access cookie)")

    emails_group = parser.add_mutually_exclusive_group()
    emails_group.add_argument("--email", help="Single email to onboard")
    emails_group.add_argument("--emails", help="File with emails (one per line)")

    parser.add_argument("--info", action="store_true",
                        help="Show site info, available products, and exit")
    parser.add_argument("--list-users", action="store_true",
                        help="List all users in the org and exit")

    parser.add_argument("--first", default="dont", help="First name (default: dont)")
    parser.add_argument("--last", default="care", help="Last name (default: care)")
    parser.add_argument("--products", nargs="+", default=DEFAULT_PRODUCTS,
                        help="Products (lowercase): entitle pra psc epmwm epml rs insights")
    parser.add_argument("--site-id", default=DEFAULT_SITE_ID)
    parser.add_argument("--site-name", default=DEFAULT_SITE_NAME)
    parser.add_argument("--residency", default=DEFAULT_RESIDENCY)
    parser.add_argument("--cancel", action="store_true", help="Cancel invitations")
    parser.add_argument("--grant-only", action="store_true",
                        help="Skip invitation, just grant site access (user must exist)")
    parser.add_argument("--dry-run", action="store_true", help="Preview without API calls")

    args = parser.parse_args()
    products = [p.lower() for p in args.products]

    if not args.dry_run:
        print("Verifying token... ", end="", flush=True)
        user_info = verify_token(args.token)
        if not user_info:
            print("FAILED - token expired or invalid")
            sys.exit(1)
        print(f"OK ({user_info['email']}, {user_info['role']})")

    # Lookup modes (no email required)
    if args.info:
        print("Fetching site info... ", end="", flush=True)
        site = get_site_info(args.token)
        if not site:
            print("FAILED")
            sys.exit(1)
        print("OK\n")
        print(f"  Site ID:    {site.get('id', 'N/A')}")
        print(f"  Site Name:  {site.get('name', 'N/A')}")
        print(f"  Residency:  {site.get('residency', 'N/A')}")
        products_list = site.get("products", [])
        if products_list:
            print(f"  Products:   {', '.join(p.get('name', p.get('id', '?')).lower() for p in products_list)}")
        else:
            print(f"  Products:   (none found)")
        print(f"\nUse these values with --site-id, --site-name, and --products")
        sys.exit(0)

    if args.list_users:
        print("Fetching users... ", end="", flush=True)
        users = list_users(args.token)
        if users is None:
            print("FAILED")
            sys.exit(1)
        print(f"OK ({len(users)} users)\n")
        for u in users:
            status = u.get("status", "")
            email = u.get("email", "N/A")
            uid = u.get("id", "N/A")
            role = u.get("role", "")
            print(f"  {email:<40} {uid}  {role}  {status}")
        sys.exit(0)

    if not args.email and not args.emails:
        parser.error("--email or --emails is required (unless using --info or --list-users)")

    if args.email:
        emails = [args.email]
    else:
        with open(args.emails) as f:
            emails = [l.strip() for l in f if l.strip() and not l.startswith("#")]

    if args.cancel:
        action = "Cancelling"
    elif args.grant_only:
        action = "Granting access for"
    else:
        action = "Onboarding"
    print(f"\n{action} {len(emails)} user(s)")
    if not args.cancel:
        print(f"  Products: {', '.join(products)}")
        print(f"  Site: {args.site_name} ({args.site_id})")
    print()

    ok = skip = fail = 0
    for email in emails:
        if args.dry_run:
            print(f"  [DRY RUN] {email}")
            ok += 1
            continue

        if args.cancel:
            status, _ = cancel_invitation(args.token, email)
            if status == 200:
                print(f"  OK   {email} (cancelled)")
                ok += 1
            elif status == 401:
                print(f"  FAIL {email} (token expired)")
                fail += 1
                break
            else:
                print(f"  FAIL {email} ({status})")
                fail += 1
            continue

        # Step 1: Invite (or find existing user)
        user_id = None
        if args.grant_only:
            print(f"  Looking up {email}... ", end="", flush=True)
            user_id = find_user_id(args.token, email)
            if not user_id:
                print("NOT FOUND")
                fail += 1
                continue
            print(f"found {user_id}")
        else:
            status, data = invite_user(
                args.token, email, args.first, args.last,
                products, args.site_id, args.site_name, args.residency,
            )
            if status == 200:
                user_id = data.get("userId")
                print(f"  Invited {email} (userId: {user_id})")
            elif status == 409:
                print(f"  {email} already active, looking up userId... ", end="", flush=True)
                user_id = find_user_id(args.token, email)
                if user_id:
                    print(f"found {user_id}")
                else:
                    print("NOT FOUND")
                    skip += 1
                    continue
            elif status == 401:
                print(f"  FAIL {email} (token expired)")
                fail += 1
                break
            else:
                print(f"  FAIL {email} invite ({status}: {data})")
                fail += 1
                continue

        # Step 2: Grant site + product access
        status, data = grant_site_access(args.token, args.site_id, user_id, products)
        if status == 200:
            granted = data.get("productIds", products) if isinstance(data, dict) else products
            print(f"  Granted {email} -> {', '.join(granted)}")
            ok += 1
        elif status == 401:
            print(f"  FAIL grant for {email} (token expired)")
            fail += 1
            break
        else:
            print(f"  FAIL grant for {email} ({status}: {data})")
            fail += 1

    print(f"\nDone: {ok} ok, {skip} skipped, {fail} failed")


if __name__ == "__main__":
    main()
