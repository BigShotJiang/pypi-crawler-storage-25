---
name: entitle
description: Entitle commands for JIT access, bundles, workflows, and permissions. Use when working with access requests, approval workflows, or managing user entitlements.
---

# Entitle Commands (`bt entitle`)

## Two API tokens — read vs. write-on-behalf-of-user

Entitle issues two distinct kinds of bearer token. The CLI uses both:

| Token | Config field | Env var | Used for |
|---|---|---|---|
| **Org / admin** | `entitle.api_key` | `BT_ENTITLE_API_KEY` | All read-only commands (`list`, `get`) and admin writes (revoke, delete) |
| **User-context** | `entitle.user_api_key` | `BT_ENTITLE_USER_API_KEY` | On-behalf-of-a-user writes — currently `bt entitle requests create` |

The org/admin token **cannot** create access requests because requests are
made *as* a person, not on behalf of the org. If only the admin token is
configured, `bt entitle requests create` exits early with a panel explaining
how to add a user token.

```yaml
# ~/.bt-cli/config.yaml
profiles:
  default:
    entitle:
      api_url: https://api.us.entitle.io
      api_key: <ORG_TOKEN>           # broad read access
      user_api_key: <USER_TOKEN>     # personal token, for `requests create`
```

The user token is generated from `app.entitle.io` → user profile → API tokens
→ **Create user token** (different page from the org token).

## IMPORTANT: Destructive Operations

**ALWAYS confirm with the user before:**
- `bt entitle resources delete` - Deletes resource from integration
- `bt entitle bundles delete` - Deletes access bundle
- `bt entitle permissions revoke` - Revokes active permission

List affected resources first, then ask for explicit confirmation.

## Performance Tips

**ALWAYS use server-side filters** - never download all data and filter locally.

```bash
# ✓ FAST - Server-side filtering
bt entitle permissions list --resource <resource_id>
bt entitle permissions list --user <user_id>
bt entitle permissions list --integration <integration_id>

# ✗ SLOW - Downloads ALL 23k+ permissions, filters locally
bt entitle permissions list | jq 'select(...)'
bt entitle permissions list -o json | grep "something"
```

**Available filters for permissions list:**

| Flag | Purpose |
|------|---------|
| `--resource -r` | Filter by resource ID |
| `--user -u` | Filter by user ID |
| `--integration -i` | Filter by integration ID |

**Dataset size warning:** Entitle can have 20,000+ permissions. Unfiltered queries will be very slow.

**Workflow - Check standing access for a resource:**
```bash
# 1. Find resource ID
bt entitle resources list --integration <integration_id> | grep -i "admin"

# 2. Query permissions with resource filter (fast)
bt entitle permissions list --resource <resource_id> -o json | jq -r '.[] | "\(.actor.name) | \(.actor.email)"'
```

## Integrations & Resources

```bash
# List integrations (connected apps)
bt entitle integrations list
bt entitle integrations get <integration_id>

# List resources in an integration
bt entitle resources list --integration <integration_id>
bt entitle resources get <resource_id>

# Virtual integration resources (use integration ID from `bt entitle integrations list`)
bt entitle resources create-virtual \
    --name "Customer-05 (Bing7)" \
    --integration <virtual_integration_id> \
    --source-role-id <role_id> \
    --role-name "Start Session"
bt entitle resources delete <resource_id>
```

## Bundles

Access bundles group multiple roles across integrations.

```bash
bt entitle bundles list
bt entitle bundles get <bundle_id>
bt entitle bundles create \
    --name "Dev AWS Access" \
    --description "Development AWS console access" \
    --workflow <workflow_id> \
    --role <role_id> \
    --duration 3600
bt entitle bundles delete <bundle_id>
```

## Workflows

```bash
bt entitle workflows list
bt entitle workflows get <workflow_id>
```

**Available Workflows:**
| Name | Type | Use Case |
|------|------|----------|
| Auto Approve | Automatic | Requests <= 12 hours |
| Low sensitivity | Simple | Single approver |
| Medium Sensitivity | Standard | Standard approval |
| Production access | Multi-step | Duration-based tiers |

## Users & Permissions

```bash
# Users
bt entitle users list
bt entitle users get <user_id>

# Active permissions
bt entitle permissions list
bt entitle permissions list --user <user_id>
bt entitle permissions revoke <permission_id>

# Accounts
bt entitle accounts list --integration <integration_id>
```

## Roles & Policies

```bash
bt entitle roles list
bt entitle roles list --resource <resource_id>
bt entitle roles get <role_id>

bt entitle policies list
bt entitle policies get <policy_id>
```

## Common Workflows

### Add PRA Jump Group to Entitle

**Important:** PRA integration sync is **asynchronous** (runs hourly). After creating a new PRA jump group, either:
- Wait up to 1 hour for auto-sync
- Or manually trigger sync in Entitle UI: Integrations → PRA → Sync Now

```bash
# 1. Find your PRA integration ID
bt entitle integrations list | grep -i pra

# 2. Trigger PRA sync in Entitle UI (or wait for hourly sync)

# 3. Find the new PRA resource
bt entitle resources list --integration <pra_integration_id>

# 4. Get "Start Sessions Only" role ID
bt entitle roles list --resource <pra_resource_id>

# 5. Add to virtual integration (find ID with `bt entitle integrations list`)
bt entitle resources create-virtual \
    --name "Customer-05" \
    --integration <virtual_integration_id> \
    --source-role-id <role_id> \
    --role-name "Start Session"
```

### Check User Access

```bash
bt entitle permissions list --user "user@example.com" -o json
```

## Discover IDs

```bash
# Find integration IDs
bt entitle integrations list

# Find workflow IDs
bt entitle workflows list

# Find resource IDs within an integration
bt entitle resources list --integration <integration_id>

# Find role IDs for a resource
bt entitle roles list --resource <resource_id>
```

## Integrations Available

- Cloud10 (Virtual Application)
- NexusDyn - Azure
- Customer Access (Virtual)
- Privileged Remote Access (PRA)
- AWS - SandBox Account
- Nexusdyn - Postgres ERP Database
- NexusDyn - EntraID

## Supported Applications (75+)

**Cloud:** AWS, Azure, GCP, Oracle OCI
**Identity:** Okta, Entra ID, OneLogin, JumpCloud
**DevOps:** GitHub, GitLab, Jenkins, Terraform Cloud
**Databases:** Postgres, MySQL, MSSQL, MongoDB, Snowflake
**Kubernetes:** EKS, AKS, GKE, Rancher
**BeyondTrust:** Password Safe, PRA, Remote Support

## API Notes

- Base path: `/public/v1`
- Pagination: `page`/`perPage`
- Response: `{"result": [...], "pagination": {...}}`
- All IDs are UUIDs (strings)
- Bearer token auth
