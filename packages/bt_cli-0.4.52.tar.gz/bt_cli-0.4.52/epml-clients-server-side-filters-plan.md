# Plan: Server-side filters + pagination on `bt epml clients list`

## Goal

Today `bt epml clients list` fetches the **entire** license-client inventory in one shot and filters client-side. The EPMLC API at `GET /api/epml/license/clients` supports server-side pagination, sorting, date-windowing, and pattern matching (per the [reference](https://docs.beyondtrust.com/epm-l/reference/epmlgetlicenseclients)). We don't expose any of that. On a tenant with thousands of clients it's slow and unnecessarily heavy.

This plan adds the missing flags, keeps current behavior working, and tightens the listing for large tenants.

## Current vs server

| Server query param | Type | Today's CLI | Notes |
|---|---|---|---|
| `limit` | int | ❌ missing | server-side page size |
| `offset` | int | ❌ missing | server-side page offset |
| `older` | int (epoch) | ❌ missing | last-updated **before** |
| `newer` | int (epoch) | ❌ missing | last-updated **since** |
| `order` | enum (`uuid`/`fqdn`/`addr`/`lastupdated`/`retired`) | ❌ missing | sort field |
| `direction` | enum (`asc`/`desc`) | ❌ missing | sort direction |
| `fqdn` | string (wildcard) | ⚠️ client-side substring | server-side wildcard match |
| `addr` | string (wildcard) | ❌ missing | server-side wildcard match |
| `exclude_retired` | bool | ⚠️ client-side filter (`--include-retired` flips) | server-side equivalent |
| `--component` | n/a | ✓ client-side only | NOT in server API; keep local |

Source method: `EPMLClient.list_license_clients(host_id)` at `src/bt_cli/epml/client/base.py:237`.
CLI command: `list_clients` at `src/bt_cli/epml/commands/clients.py:56`.

## Proposed CLI surface

```
bt epml clients list [OPTIONS]

  --host, -H              PMUL host id (uses host-scoped path)
  --component, -c         License bucket filter (CLIENT-SIDE; server doesn't have this)
                          {RBPClnts, PBULPolClnts, FIMClnts, SudoPolClnts}
  --fqdn TEXT             FQDN wildcard (server-side; supports * and ?)
  --addr TEXT             Address wildcard (server-side; supports * and ?)
  --include-retired       Include retired clients (default: hidden via server's
                          exclude_retired=true; flag flips it to false)
  --since TEXT            Only clients updated since this time
                          (accepts ISO-8601, "1h", "7d", or epoch)
  --before TEXT           Only clients updated before this time (same formats)
  --order [uuid|fqdn|addr|lastupdated|retired]
                          Sort field (default: fqdn)
  --direction [asc|desc]  Sort direction (default: asc)
  --limit, -n INTEGER     Page size (default: 200; max: server-defined)
  --all                   Iterate all pages until exhausted (overrides --limit
                          for the per-call value but pages internally)
  --output, -o            table | json
```

### Flag-naming notes

- `--since` / `--before` are friendlier than `--newer` / `--older`. Accept ISO-8601, relative durations (`1h`, `7d`, `30m`), and raw epoch ints. Convert to epoch before the API call.
- `--addr` mirrors the API param name verbatim (server already speaks wildcards there).
- `--component` stays as a **client-side** filter with a warning in `--help` since the server doesn't support it.
- Drop the current `--fqdn` substring behavior in favor of the server's wildcard matcher. If the user passes a plain string like `web-01`, transparently wrap in `*web-01*` so the substring UX is preserved. Document the auto-wrap behavior.
- Default to `--exclude-retired=true` (matches today's UX where retired clients are hidden unless `--include-retired` is passed). Done via flipping the server param.

## Implementation steps

### 1. Extend `EPMLClient.list_license_clients`

```python
def list_license_clients(
    self,
    host_id: Optional[int] = None,
    *,
    limit: Optional[int] = None,
    offset: Optional[int] = None,
    older: Optional[int] = None,    # epoch
    newer: Optional[int] = None,    # epoch
    order: Optional[str] = None,    # uuid|fqdn|addr|lastupdated|retired
    direction: Optional[str] = None,  # asc|desc
    fqdn: Optional[str] = None,
    addr: Optional[str] = None,
    exclude_retired: Optional[bool] = None,
) -> Dict[str, Any]:
    """GET license clients with full server-side filter set."""
    params: Dict[str, Any] = {}
    for k, v in (
        ("limit", limit), ("offset", offset),
        ("older", older), ("newer", newer),
        ("order", order), ("direction", direction),
        ("fqdn", fqdn), ("addr", addr),
        ("exclude_retired", exclude_retired),
    ):
        if v is not None:
            params[k] = v
    if host_id is not None:
        return self.get(f"/api/pbul/{host_id}/licenseinfo/clients", params=params or None)
    return self.get("/api/epml/license/clients", params=params or None)
```

Backwards-compatible: existing call sites pass no kwargs.

### 2. Add a paginating helper for `--all`

```python
def iter_license_clients(
    self,
    page_size: int = 200,
    **filters,
) -> Iterator[Dict[str, Any]]:
    """Yield every matching client across as many pages as needed."""
    offset = 0
    while True:
        page = self.list_license_clients(limit=page_size, offset=offset, **filters)
        rows = (page.get("Data") or page.get("data") or []) if isinstance(page, dict) else []
        if not rows:
            return
        yield from rows
        if len(rows) < page_size:
            return
        offset += page_size
```

### 3. Update the CLI command

In `src/bt_cli/epml/commands/clients.py`:
- Add the new typer options.
- Parse `--since`/`--before` to epoch using a small helper (accept `1h`/`7d`/`30m` patterns + ISO-8601 + raw integer).
- Auto-wrap plain `--fqdn` values in `*` if no glob char present (preserves substring UX).
- Branch on `--all`: paginate via `iter_license_clients`, otherwise single page.
- Keep `--component` as a post-filter (server doesn't support it). Document this in the option help text.

### 4. Time-spec parser

Small new helper in `core/timeparse.py` (or co-located if there's no shared util module):

```python
def parse_time_to_epoch(s: str) -> int:
    """Accept '1h', '7d', '30m', ISO-8601, or raw epoch int. Return UTC epoch."""
    ...
```

Used by both `--since` and `--before`. Tests cover each input form.

### 5. Output formatting

No change needed — `_flatten_user`-style helpers already handle the row shape. Only thing to verify: when paginating with `--all`, table rendering streams or buffers? For now buffer (dataset typically <10k rows; rich.Table handles fine). Document the trade-off.

### 6. Tests

In `tests/epml/test_clients.py` (or wherever the existing client tests live):

- `test_list_license_clients_passes_server_params` — respx-mock, assert query string carries all the params we set
- `test_list_license_clients_no_params_unchanged` — backwards compat: no kwargs → no `params` arg → same URL as today
- `test_iter_license_clients_paginates` — three pages of 200 + a partial; verify offset progression and termination
- `test_iter_license_clients_terminates_on_short_page`
- `test_clients_list_command_auto_wraps_fqdn_substring` — `--fqdn web-01` becomes `*web-01*`; `--fqdn '*web*'` is passed through
- `test_clients_list_command_since_relative` — `--since 1h` parses correctly
- `test_clients_list_command_since_iso` — ISO-8601 form
- `test_clients_list_component_is_post_filter` — server returns 100 rows; `--component RBPClnts` filters client-side
- `test_parse_time_to_epoch_accepts_*` — unit tests for the helper

### 7. Skill + docs

Update `src/bt_cli/data/skills/epml/SKILL.md`:
- The "License clients" section already exists. Replace with the new flag set.
- Add a one-liner about `--all` and the auto-wrap fqdn behavior.

Update `src/bt_cli/data/CLAUDE.md` if it has a clients line.

Update `btcli/CLAUDE.md`'s API quirks table — add a note that EPML clients endpoint supports server-side pagination and sorting.

## Backwards compatibility

- `--component`, `--fqdn`, `--include-retired`, `--host`, `--output` all keep their current meaning.
- `--fqdn`'s substring semantics preserved via the auto-wrap.
- Default sort changes from "whatever the server returned" to `fqdn asc` — small cosmetic change; document it.

## Edge cases

- **Empty Data array on a non-zero `Total`** — server bug or a filter that removed everything; treat as "end of pages" in `iter_license_clients`.
- **Server caps `limit`** — if the server returns fewer rows than asked, that's normal pagination, not necessarily end-of-data. The "fewer than page_size → done" heuristic is good enough today but could need revisiting.
- **`--all` with `--limit`** — `--limit` becomes the per-call page size; `--all` toggles iteration. Document.
- **Wildcard escape** — server interprets `*` and `?`. If a user has a literal `*` in an fqdn (unlikely but possible), no escape syntax exists. Note in help text.

## Verification

```bash
# Single page, default
bt epml clients list

# Server-side fqdn wildcard
bt epml clients list --fqdn 'web-*'

# Server-side address wildcard
bt epml clients list --addr '10.0.0.*'

# Recent activity
bt epml clients list --since 1h
bt epml clients list --since 2026-05-01T00:00:00Z

# Sorted
bt epml clients list --order lastupdated --direction desc --limit 20

# Full sweep
bt epml clients list --all -o json | jq '.Data | length'
```

## Out of scope

- `bt epml clients retire` flag additions (separate endpoint; can mirror later if needed).
- Changing the `host-scoped` URL behavior (`/api/pbul/{hostid}/licenseinfo/clients`) — current logic keeps it.
- Streaming output for `--all` (buffer for now).
