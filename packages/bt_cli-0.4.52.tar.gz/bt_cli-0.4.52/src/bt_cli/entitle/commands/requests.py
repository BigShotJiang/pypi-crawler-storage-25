"""Access request commands for Entitle.

Hybrid UX: pass --bundle or --role + --duration + --justification for a fully
non-interactive run, or omit any of those to drop into a filter-then-pick menu.

Auth note
---------
Entitle issues two kinds of API tokens:

* **Org / admin** token — used for read-only listings (the default for
  `bt entitle ...`).
* **User-context** token — required for any operation made *on behalf of*
  a real user. `bt entitle requests create` is one of those, so it always
  uses the user token (`config.user_api_key` /
  `BT_ENTITLE_USER_API_KEY`). If that token is missing the command bails
  out with a friendly explanation rather than silently submitting under the
  wrong identity.
"""

from typing import Any, Optional

import httpx
import typer
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

from ..client.base import EntitleClient, MissingUserTokenError, get_client, has_user_token
from ...core.output import console, print_json, print_success, print_api_error
from ...core.prompts import prompt_choice, prompt_filtered_pick

app = typer.Typer(no_args_is_help=True, help="Manage access requests")


# Curated 30-min-aligned duration menu (seconds)
DURATION_BLOCKS_SEC: list[int] = [
    1800,    # 30m
    3600,    # 1h
    5400,    # 1h30m
    7200,    # 2h
    10800,   # 3h
    14400,   # 4h
    28800,   # 8h
    43200,   # 12h
    86400,   # 1d
    172800,  # 2d
    259200,  # 3d
    604800,  # 7d
]


def _fmt_duration(secs: int) -> str:
    """Render a seconds value as a compact human label (e.g. 1h30m, 2d)."""
    if secs <= 0:
        return f"{secs}s"
    days, rem = divmod(secs, 86400)
    hours, rem = divmod(rem, 3600)
    mins = rem // 60
    parts: list[str] = []
    if days:
        parts.append(f"{days}d")
    if hours:
        parts.append(f"{hours}h")
    if mins:
        parts.append(f"{mins}m")
    return "".join(parts) or f"{secs}s"


def _pick_target_interactive(client: EntitleClient) -> tuple[str, str, str]:
    """Walk the user through choosing a bundle or a role.

    Returns (target_type, target_id, human_label).
    """
    target_type = prompt_choice(
        "Target type",
        [
            ("role", "A single role on a resource (drill down: integration → resource → role)"),
            ("bundle", "An access bundle (a curated group of roles)"),
        ],
        default="role",
    )

    if target_type == "bundle":
        bundles = client.list_bundles()
        chosen = prompt_filtered_pick(
            bundles,
            lambda b: f"{b.get('name', '?')}  [dim]{b.get('id', '')}[/dim]",
            title="Pick a bundle",
        )
        return "bundle", chosen["id"], chosen.get("name") or chosen["id"]

    integrations = client.list_integrations()
    integration = prompt_filtered_pick(
        integrations,
        lambda x: f"{x.get('name', '?')}  [dim]({(x.get('application') or {}).get('name', '-')})[/dim]",
        title="Pick an integration",
    )
    resources = client.list_resources(integration_id=integration["id"])
    resource = prompt_filtered_pick(
        resources,
        lambda x: x.get("name", "?"),
        title="Pick a resource",
    )
    roles = client.list_roles(resource_id=resource["id"])
    role = prompt_filtered_pick(
        roles,
        lambda x: x.get("name", "?"),
        title="Pick a role",
    )
    label = f"{integration.get('name', '?')} / {resource.get('name', '?')} / {role.get('name', '?')}"
    return "role", role["id"], label


def _pick_duration_interactive(
    client: EntitleClient, target_type: str, target_id: str
) -> int:
    """Show a duration menu. For bundles with allowedDurations, restrict to those."""
    options: list[int] = []

    if target_type == "bundle":
        try:
            response = client.get_bundle(target_id)
            bundle = response.get("result", response)
            allowed = bundle.get("allowedDurations") or []
            options = [int(d) for d in allowed if int(d) > 0]
        except Exception:
            # If the lookup fails for any reason, fall back to curated blocks
            options = []

    if not options:
        options = list(DURATION_BLOCKS_SEC)

    options.sort()
    chosen = prompt_filtered_pick(
        options,
        lambda secs: f"{_fmt_duration(secs)}  [dim]({secs}s)[/dim]",
        title="Pick a duration",
    )
    return chosen


def _prompt_justification() -> str:
    while True:
        text = typer.prompt("Justification (business reason)").strip()
        if 1 <= len(text) <= 2048:
            return text
        console.print("[red]Justification must be 1..2048 characters[/red]")


def _abort_missing_user_token() -> None:
    """Render a friendly panel explaining how to add a user-context token."""
    body = Text.from_markup(
        "[bold]No user-context token configured.[/bold]\n\n"
        "Creating an access request is an [italic]on-behalf-of-a-user[/italic] "
        "action and requires a personal Entitle token, not the org/admin "
        "token used for listings.\n\n"
        "[bold]Add one:[/bold]\n\n"
        "  • [cyan]Env var[/cyan]\n"
        "      [dim]export[/dim] BT_ENTITLE_USER_API_KEY=eyJhb...\n"
        "  • [cyan]~/.bt-cli/config.yaml[/cyan]\n"
        "      [dim]profiles:\n"
        "        default:\n"
        "          entitle:\n"
        "            user_api_key:[/dim] eyJhb...\n\n"
        "Get the token from [link]https://app.entitle.io[/link] → "
        "your profile → API tokens → [bold]Create user token[/bold]. "
        "(Org/admin tokens are issued from a different page and won't work "
        "here.)"
    )
    console.print(Panel(body, title="[red]Cannot create access request[/red]", border_style="red"))


def _summary_panel(target_type: str, target_label: str, target_id: str,
                   duration: int, justification: str) -> Panel:
    table = Table.grid(padding=(0, 2))
    table.add_column(style="dim", justify="right")
    table.add_column()
    table.add_row("Target type", target_type)
    table.add_row("Target", target_label)
    table.add_row("Target ID", f"[dim]{target_id}[/dim]")
    table.add_row("Duration", f"{_fmt_duration(duration)}  [dim]({duration}s)[/dim]")
    table.add_row("Justification", justification)
    return Panel(table, title="[bold]Access Request Summary[/bold]", border_style="cyan")


@app.command("create")
def create_access_request(
    bundle: Optional[str] = typer.Option(None, "--bundle", "-b", help="Bundle ID to request"),
    role: Optional[str] = typer.Option(None, "--role", "-r", help="Role ID to request"),
    duration: Optional[int] = typer.Option(
        None,
        "--duration",
        "-d",
        help="Access duration in seconds (interactive picker uses 30-min blocks)",
    ),
    justification: Optional[str] = typer.Option(
        None, "--justification", "-j", help="Business justification (1..2048 chars)"
    ),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip the pre-submit confirmation"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table, json"),
) -> None:
    """Create a new access request (uses the user-context token).

    Pass --bundle OR --role plus --duration and --justification for
    non-interactive use. Omit any of them to drop into a filter-then-pick menu.

    Authentication: this command always uses `BT_ENTITLE_USER_API_KEY` /
    `entitle.user_api_key`, NOT the org/admin token. If that token is not
    configured, the command exits before contacting the API.
    """
    if bundle and role:
        console.print("[red]Pass either --bundle or --role, not both[/red]")
        raise typer.Exit(1)

    if not has_user_token():
        _abort_missing_user_token()
        raise typer.Exit(2)

    # Read-only target/duration discovery uses the admin/org token (broad read
    # access). The actual create POST uses the user-context token.
    try:
        with get_client(user_token=False) as reader:
            if bundle:
                target_type, target_id, target_label = "bundle", bundle, bundle
            elif role:
                target_type, target_id, target_label = "role", role, role
            else:
                console.rule("[bold cyan]Pick what to request[/bold cyan]")
                target_type, target_id, target_label = _pick_target_interactive(reader)

            if duration is None:
                console.rule("[bold cyan]Pick a duration[/bold cyan]")
                duration = _pick_duration_interactive(reader, target_type, target_id)
            elif duration < 1:
                console.print("[red]--duration must be >= 1 second[/red]")
                raise typer.Exit(1)

        if justification is None:
            console.rule("[bold cyan]Justification[/bold cyan]")
            justification = _prompt_justification()
        else:
            if not (1 <= len(justification) <= 2048):
                console.print("[red]--justification must be 1..2048 characters[/red]")
                raise typer.Exit(1)

        # Pre-submit panel
        console.print()
        console.print(_summary_panel(target_type, target_label, target_id, duration, justification))
        console.print(
            "[dim]Submitting under the [bold]user-context[/bold] Entitle token "
            "(BT_ENTITLE_USER_API_KEY).[/dim]"
        )

        if not yes:
            typer.confirm("Submit this request?", default=True, abort=True)

        with get_client(user_token=True) as writer:
            result = writer.create_access_request(
                target_type=target_type,
                target_id=target_id,
                duration=duration,
                justification=justification,
            )

        request_id = (
            (result.get("result") or {}).get("id")
            if isinstance(result, dict) and "result" in result
            else (result.get("id") if isinstance(result, dict) else None)
        )

        if output == "json":
            print_json(result)
            return

        success_table = Table.grid(padding=(0, 2))
        success_table.add_column(style="dim", justify="right")
        success_table.add_column()
        if request_id:
            success_table.add_row("Request ID", f"[bold]{request_id}[/bold]")
        success_table.add_row("Target", target_label)
        success_table.add_row("Duration", _fmt_duration(duration))
        if request_id:
            success_table.add_row(
                "Follow up", f"[cyan]bt entitle requests get {request_id}[/cyan]"
            )
        console.print(Panel(success_table, title="[green]Submitted[/green]", border_style="green"))

    except MissingUserTokenError as e:
        console.print(f"[red]{e}[/red]")
        raise typer.Exit(2)
    except typer.Abort:
        console.print("[yellow]Aborted — nothing submitted.[/yellow]")
        raise typer.Exit(1)
    except httpx.HTTPStatusError as e:
        print_api_error(e, "create access request")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "create access request")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "create access request")
        raise typer.Exit(1)


@app.command("get")
def get_access_request(
    request_id: str = typer.Argument(..., help="Access request ID"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table, json"),
) -> None:
    """Get an access request by ID."""
    try:
        with get_client() as client:
            response = client.get_access_request(request_id)

        data: Any = response.get("result", response) if isinstance(response, dict) else response

        if output == "json":
            print_json(response)
            return

        from rich.panel import Panel

        if not isinstance(data, dict):
            print_json(response)
            return

        # Build a friendly summary line for each target. Role targets join in via
        # `roles[]` (with nested resource + integration); bundle targets via
        # `bundles[]`. Fall back to whatever's inside `targets[]` itself.
        target_lines: list[str] = []
        roles_by_id = {r.get("id"): r for r in (data.get("roles") or []) if r.get("id")}
        bundles_by_id = {b.get("id"): b for b in (data.get("bundles") or []) if b.get("id")}
        for t in (data.get("targets") or []):
            t_type = t.get("type") or "?"
            inner = t.get(t_type) or {}
            inner_id = inner.get("id")
            if t_type == "role" and inner_id in roles_by_id:
                role = roles_by_id[inner_id]
                resource = role.get("resource") or {}
                integration = resource.get("integration") or {}
                target_lines.append(
                    f"role: {role.get('name', '?')} on {resource.get('name', '?')} ({integration.get('name', '?')})"
                )
            elif t_type == "bundle" and inner_id in bundles_by_id:
                target_lines.append(f"bundle: {bundles_by_id[inner_id].get('name', '?')}")
            else:
                target_lines.append(f"{t_type}: {inner.get('name') or inner_id or '?'}")
        targets_str = "\n           ".join(target_lines) if target_lines else "-"

        user = data.get("user") or data.get("behalfOf") or {}
        requester = user.get("email") or user.get("id") or "-"
        number = data.get("number")
        id_line = f"{data.get('id', '-')}" + (f"  [dim](#{number})[/dim]" if number else "")

        body = (
            f"[dim]ID:[/dim] {id_line}\n"
            f"[dim]Status:[/dim] {data.get('status', '-')}\n"
            f"[dim]Requester:[/dim] {requester}\n"
            f"[dim]Duration:[/dim] {_fmt_duration(int(data.get('duration', 0))) if data.get('duration') else '-'}\n"
            f"[dim]Targets:[/dim] {targets_str}\n"
            f"[dim]Justification:[/dim] {data.get('justification', '-')}"
        )
        console.print(Panel(body, title="Access Request"))
    except httpx.HTTPStatusError as e:
        print_api_error(e, "get access request")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "get access request")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "get access request")
        raise typer.Exit(1)
