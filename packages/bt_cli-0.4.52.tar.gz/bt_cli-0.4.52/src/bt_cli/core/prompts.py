"""Reusable interactive prompts for CLI commands."""

import re
from typing import Any, Callable, Optional, TypeVar

import typer
from rich.console import Console

_ANSI_ESCAPE = re.compile(r"\x1b(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])")

console = Console()

T = TypeVar("T")
D = TypeVar("D")


def _clean_str(raw: Any) -> str:
    """Strip ANSI escape sequences from a prompted string value."""
    return _ANSI_ESCAPE.sub("", raw).strip()


def prompt_if_missing(
    value: Optional[T],
    prompt_text: str,
    value_type: type = str,
) -> T:
    """Prompt for a value if it's missing.

    Args:
        value: Current value (may be None)
        prompt_text: Text to show in prompt
        value_type: Type for typer.prompt (str, int, float)

    Returns:
        The value (either original or prompted)
    """
    if value is None or value == "":
        raw = typer.prompt(prompt_text, type=value_type)
        if value_type is str:
            return _clean_str(raw)  # type: ignore[return-value]
        return raw
    return value


def prompt_from_list(
    items: list[dict[str, Any]],
    prompt_text: str,
    id_key: str,
    name_key: str,
    title: str,
    value_type: type = int,
) -> Any:
    """Show a list of items and prompt for selection.

    Args:
        items: List of dicts to display
        prompt_text: Prompt text (e.g., "Workgroup ID")
        id_key: Key for the ID field in each dict
        name_key: Key for the display name field
        title: Title to show above list
        value_type: Type of the ID (int or str)

    Returns:
        The selected ID
    """
    console.print(f"\n[bold]{title}:[/bold]")
    for item in items:
        item_id = item.get(id_key, "")
        item_name = item.get(name_key, "Unknown")
        console.print(f"  {item_id}: {item_name}")
    raw = typer.prompt(prompt_text, type=value_type)
    if value_type is str:
        return _clean_str(raw)  # type: ignore[return-value]
    return raw


def prompt_choice(
    prompt_text: str,
    choices: list[tuple[str, str]],
    default: Optional[str] = None,
) -> str:
    """Prompt for a choice from a list of options.

    Args:
        prompt_text: Text to show
        choices: List of (value, description) tuples
        default: Default value

    Returns:
        The selected value
    """
    console.print(f"\n[bold]{prompt_text}:[/bold]")
    for value, desc in choices:
        marker = " (default)" if value == default else ""
        console.print(f"  {value}: {desc}{marker}")

    result = typer.prompt("Choice", default=default or choices[0][0])
    valid_values = [v for v, _ in choices]
    while result not in valid_values:
        console.print(f"[red]Invalid choice. Options: {', '.join(valid_values)}[/red]")
        result = typer.prompt("Choice", default=default or choices[0][0])
    return result


def prompt_filtered_pick(
    items: list[D],
    label_fn: Callable[[D], str],
    *,
    title: str = "Select",
    page_size: int = 20,
) -> D:
    """Paginated filter-then-pick selector.

    User actions at the prompt:
      - a number (1..N) picks the item shown on the current page
      - any other text filters the list by case-insensitive substring of the label
      - 'n' / 'p' moves to next / previous page
      - empty input cancels (raises typer.Abort)

    Args:
        items: Source list to choose from
        label_fn: Maps an item to the label shown in the list (also used for filtering)
        title: Heading shown above the list
        page_size: Items per page

    Returns:
        The chosen item from `items`.
    """
    if not items:
        console.print(f"[yellow]No {title.lower()} available[/yellow]")
        raise typer.Abort()

    visible = list(items)
    page = 0
    while True:
        total_pages = max(1, (len(visible) + page_size - 1) // page_size)
        page = max(0, min(page, total_pages - 1))
        start = page * page_size
        chunk = visible[start : start + page_size]

        match_count = len(visible)
        suffix = f" — page {page + 1}/{total_pages}" if total_pages > 1 else ""
        console.print(f"\n[bold]{title}[/bold] ({match_count} match{'es' if match_count != 1 else ''}{suffix}):")
        for i, item in enumerate(chunk, start=1):
            console.print(f"  {i}. {label_fn(item)}")
        console.print(
            "[dim]Type a number to pick, text to filter, n/p for next/prev page, blank to cancel[/dim]"
        )

        ans = typer.prompt(">", default="", show_default=False).strip()
        if ans == "":
            raise typer.Abort()
        low = ans.lower()
        if low == "n":
            if page + 1 < total_pages:
                page += 1
            else:
                console.print("[yellow]Already on last page[/yellow]")
            continue
        if low == "p":
            if page > 0:
                page -= 1
            else:
                console.print("[yellow]Already on first page[/yellow]")
            continue
        if ans.isdigit():
            idx = int(ans) - 1
            if 0 <= idx < len(chunk):
                return chunk[idx]
            console.print(f"[red]Invalid number — must be 1..{len(chunk)}[/red]")
            continue
        # Filter against the full source list, not the previously filtered view
        needle = low
        filtered = [it for it in items if needle in label_fn(it).lower()]
        if not filtered:
            console.print("[yellow]No matches — keeping previous list[/yellow]")
            continue
        visible = filtered
        page = 0
