"""Multi-product configuration management for BeyondTrust CLI."""

import os
import re
from dataclasses import dataclass, field
from typing import Any, Optional

from dotenv import load_dotenv

from .config_file import get_layered_config, get_secret_from_keyring


@dataclass
class ProductConfig:
    """Base configuration shared by all products."""

    api_url: str
    verify_ssl: bool = True
    timeout: float = 30.0


@dataclass
class PWSConfig(ProductConfig):
    """Password Safe configuration.

    Supports two authentication methods:
    - API Key: Uses PS-Auth header format
    - OAuth: Uses client_credentials grant flow
    """

    api_key: Optional[str] = None
    client_id: Optional[str] = None
    client_secret: Optional[str] = None
    run_as: Optional[str] = None
    api_version: str = "3.1"

    @property
    def auth_method(self) -> str:
        """Determine which auth method to use."""
        if self.api_key:
            return "api_key"
        if self.client_id and self.client_secret:
            return "oauth"
        raise ValueError("PWS requires either API key or OAuth credentials")

    def validate(self) -> None:
        """Validate configuration."""
        if not self.api_url:
            raise ValueError("BT_PWS_API_URL is required")
        if not self.api_key and not (self.client_id and self.client_secret):
            raise ValueError(
                "PWS requires either BT_PWS_API_KEY or both BT_PWS_CLIENT_ID and BT_PWS_CLIENT_SECRET"
            )


@dataclass
class EntitleConfig(ProductConfig):
    """Entitle configuration.

    Uses simple Bearer token authentication.
    """

    api_key: str = ""
    # Optional separate token issued for a real user (not the org/admin token).
    # Required for write operations performed *on behalf of* a user, like
    # `bt entitle requests create`. Not required for read-only admin work.
    user_api_key: str = ""

    def validate(self) -> None:
        """Validate configuration."""
        if not self.api_key:
            raise ValueError("BT_ENTITLE_API_KEY is required")
        if not self.api_url:
            raise ValueError("BT_ENTITLE_API_URL is required")


@dataclass
class PRAConfig(ProductConfig):
    """Privileged Remote Access configuration.

    Uses OAuth 2.0 client credentials authentication.
    API base path: /api/config/v1
    """

    client_id: str = ""
    client_secret: str = ""

    def validate(self) -> None:
        """Validate configuration."""
        if not self.api_url:
            raise ValueError("BT_PRA_API_URL is required")
        if not self.client_id or not self.client_secret:
            raise ValueError(
                "PRA requires both BT_PRA_CLIENT_ID and BT_PRA_CLIENT_SECRET"
            )


@dataclass
class EPMWConfig(ProductConfig):
    """EPM Windows configuration.

    Uses OAuth 2.0 client credentials authentication.
    API base path: /management-api/v3
    Token endpoint: /oauth/token
    """

    client_id: str = ""
    client_secret: str = ""

    def validate(self) -> None:
        """Validate configuration."""
        if not self.api_url:
            raise ValueError("BT_EPM_API_URL is required")
        if not self.client_id or not self.client_secret:
            raise ValueError(
                "EPMW requires both BT_EPM_CLIENT_ID and BT_EPM_CLIENT_SECRET"
            )


@dataclass
class SecretsConfig(ProductConfig):
    """BeyondTrust Secrets API configuration.

    Uses Personal Access Token (PAT) bearer authentication against the
    BeyondTrust public API gateway. URLs are composed as:

        {api_url}/site/{site_id}/secrets/<path>

    The `api_version` is sent as the `bt-secrets-api-version` header on
    every request. The live API version differs from the public doc page
    (which lists 2026-01-02 — that gets rejected); the default below is
    what the server currently accepts.
    """

    site_id: str = ""
    pat: str = ""
    api_version: str = "2026-04-28"

    def validate(self) -> None:
        """Validate configuration."""
        if not self.api_url:
            raise ValueError("BT_SECRETS_API_URL is required")
        if not self.site_id:
            raise ValueError("BT_SECRETS_SITE_ID is required")
        if not self.pat:
            raise ValueError("BT_SECRETS_PAT is required")


@dataclass
class EPMLConfig(ProductConfig):
    """EPM Linux configuration.

    Uses Personal Access Token (PAT) bearer authentication against the
    BeyondTrust public API gateway. URLs are composed as:

        {api_url}/site/{site_id}/epm/linux/{spec-path-minus-/api/}

    The OpenAPI spec lists paths with a `/api/` prefix and an empty
    `servers` block — the gateway requires the site/product prefix that
    isn't in the spec.
    """

    site_id: str = ""
    pat: str = ""
    default_host_id: int = 100

    def validate(self) -> None:
        """Validate configuration."""
        if not self.api_url:
            raise ValueError("BT_EPML_API_URL is required")
        if not self.site_id:
            raise ValueError("BT_EPML_SITE_ID is required")
        if not self.pat:
            raise ValueError("BT_EPML_PAT is required")


def _get_bool(value: Optional[str], default: bool = True) -> bool:
    """Parse boolean from environment variable."""
    if value is None:
        return default
    return value.lower() not in ("false", "0", "no", "off")


def _get_float(value: Optional[str], default: float, min_val: float = 0.1, max_val: float = 600.0) -> float:
    """Parse float from environment variable with range validation.

    Args:
        value: String value to parse
        default: Default if None or invalid
        min_val: Minimum allowed value (default 0.1 seconds)
        max_val: Maximum allowed value (default 600 seconds / 10 minutes)

    Returns:
        Float value within valid range, or default if invalid
    """
    if value is None:
        return default
    try:
        result = float(value)
        # Validate range - use default if out of bounds
        if result < min_val or result > max_val:
            return default
        return result
    except ValueError:
        return default


def _resolve_value(value: Any) -> Any:
    """Resolve keyring references in config values.

    If value is a string starting with 'keyring://', fetch from keyring.
    """
    if isinstance(value, str) and value.startswith("keyring://"):
        # Format: keyring://service/key
        parts = value[len("keyring://"):].split("/", 1)
        if len(parts) == 2:
            service, key = parts
            resolved = get_secret_from_keyring(service, key)
            if resolved:
                return resolved
        # Return None if keyring lookup fails
        return None
    return value


_ANSI_CSI = re.compile(r"\x1b\[[0-?]*[ -/]*[@-~]")


def _strip_controls(value: Any) -> Any:
    """Remove ANSI escape sequences and bare control bytes from a config string.

    Why: interactive prompts and copy-paste from terminals occasionally
    capture ANSI escape sequences (cursor-arrow keystrokes are the usual
    culprit) into values that end up in URLs or HTTP headers. httpx and
    most HTTP libraries refuse to send a URL containing non-printables and
    surface a confusing "Invalid non-printable ASCII character" error
    instead of the real config problem.

    We strip the *whole* CSI sequence (ESC + ``[`` + params + final byte)
    before the lone-control pass — otherwise the visible tail bytes like
    ``[C`` and ``[D`` survive as ASCII garbage glued onto an otherwise
    valid UUID, producing a clean URL that 404s instead of one the user
    can see is wrong.
    """
    if isinstance(value, str):
        cleaned = _ANSI_CSI.sub("", value)
        return "".join(c for c in cleaned if c >= " " and c != "\x7f")
    return value


def _to_bool(value: Any) -> bool:
    """Convert value to boolean."""
    if isinstance(value, bool):
        return value
    if isinstance(value, str):
        return value.lower() not in ("false", "0", "no", "off", "")
    return bool(value)


def _to_float(value: Any, default: float = 30.0, min_val: float = 0.1, max_val: float = 600.0) -> float:
    """Convert value to float with range validation.

    Args:
        value: Value to convert
        default: Default if None or invalid
        min_val: Minimum allowed value (default 0.1 seconds)
        max_val: Maximum allowed value (default 600 seconds / 10 minutes)

    Returns:
        Float value within valid range, or default if invalid
    """
    if value is None:
        return default
    try:
        result = float(value)
        # Validate range - use default if out of bounds
        if result < min_val or result > max_val:
            return default
        return result
    except (ValueError, TypeError):
        return default


def _get_profile() -> Optional[str]:
    """Get the active profile from CLI or environment."""
    # Try to get from CLI module
    try:
        from ..cli import get_active_profile
        profile = get_active_profile()
        if profile:
            return profile
    except ImportError:
        pass

    # Fall back to environment variable
    return os.getenv("BT_PROFILE")


def load_pws_config(env_file: Optional[str] = None, profile: Optional[str] = None) -> PWSConfig:
    """Load Password Safe configuration.

    Configuration sources (in order of precedence):
        1. Environment variables
        2. Config file (~/.bt-cli/config.yaml)

    Environment variables:
        BT_PWS_API_URL        - API endpoint URL (required)
        BT_PWS_API_KEY        - API key for PS-Auth authentication
        BT_PWS_CLIENT_ID      - OAuth client ID
        BT_PWS_CLIENT_SECRET  - OAuth client secret
        BT_PWS_VERIFY_SSL     - SSL verification (default: true)
        BT_PWS_TIMEOUT        - Request timeout in seconds (default: 30)
        BT_PWS_RUN_AS         - Username for impersonation
        BT_PWS_API_VERSION    - API version (default: 3.1)
    """
    if env_file:
        load_dotenv(env_file)
    else:
        load_dotenv()

    # Get layered config (file + env vars)
    profile = profile or _get_profile()
    layered = get_layered_config("pws", profile)

    # Resolve any keyring references
    for key in ["api_key", "client_secret"]:
        if key in layered:
            layered[key] = _resolve_value(layered[key])

    config = PWSConfig(
        api_url=layered.get("api_url") or os.getenv("BT_PWS_API_URL", ""),
        api_key=layered.get("api_key") or os.getenv("BT_PWS_API_KEY"),
        client_id=layered.get("client_id") or os.getenv("BT_PWS_CLIENT_ID"),
        client_secret=layered.get("client_secret") or os.getenv("BT_PWS_CLIENT_SECRET"),
        verify_ssl=_to_bool(layered.get("verify_ssl")) if "verify_ssl" in layered else _get_bool(os.getenv("BT_PWS_VERIFY_SSL")),
        timeout=_to_float(layered.get("timeout")) if "timeout" in layered else _get_float(os.getenv("BT_PWS_TIMEOUT"), 30.0),
        run_as=layered.get("run_as") or os.getenv("BT_PWS_RUN_AS"),
        api_version=layered.get("api_version") or os.getenv("BT_PWS_API_VERSION", "3.1"),
    )
    config.validate()
    return config


def load_entitle_config(env_file: Optional[str] = None, profile: Optional[str] = None) -> EntitleConfig:
    """Load Entitle configuration.

    Configuration sources (in order of precedence):
        1. Environment variables
        2. Config file (~/.bt-cli/config.yaml)

    Environment variables:
        BT_ENTITLE_API_URL      - API endpoint URL (default: https://api.us.entitle.io)
        BT_ENTITLE_API_KEY      - Org/admin Bearer token (required for read ops)
        BT_ENTITLE_USER_API_KEY - User-context Bearer token (optional; required
                                  for `bt entitle requests create` since access
                                  requests are made on behalf of a real user)
        BT_ENTITLE_VERIFY_SSL   - SSL verification (default: true)
        BT_ENTITLE_TIMEOUT      - Request timeout in seconds (default: 30)
    """
    if env_file:
        load_dotenv(env_file)
    else:
        load_dotenv()

    # Get layered config (file + env vars)
    profile = profile or _get_profile()
    layered = get_layered_config("entitle", profile)

    # Resolve any keyring references
    if "api_key" in layered:
        layered["api_key"] = _resolve_value(layered["api_key"])
    if "user_api_key" in layered:
        layered["user_api_key"] = _resolve_value(layered["user_api_key"])

    config = EntitleConfig(
        api_url=layered.get("api_url") or os.getenv("BT_ENTITLE_API_URL", "https://api.us.entitle.io"),
        api_key=layered.get("api_key") or os.getenv("BT_ENTITLE_API_KEY", ""),
        user_api_key=layered.get("user_api_key") or os.getenv("BT_ENTITLE_USER_API_KEY", ""),
        verify_ssl=_to_bool(layered.get("verify_ssl")) if "verify_ssl" in layered else _get_bool(os.getenv("BT_ENTITLE_VERIFY_SSL")),
        timeout=_to_float(layered.get("timeout")) if "timeout" in layered else _get_float(os.getenv("BT_ENTITLE_TIMEOUT"), 30.0),
    )
    config.validate()
    return config


def load_pra_config(env_file: Optional[str] = None, profile: Optional[str] = None) -> PRAConfig:
    """Load PRA configuration.

    Configuration sources (in order of precedence):
        1. Environment variables
        2. Config file (~/.bt-cli/config.yaml)

    Environment variables:
        BT_PRA_API_URL        - API endpoint URL (required, e.g., https://host.beyondtrustcloud.com)
        BT_PRA_CLIENT_ID      - OAuth client ID (required)
        BT_PRA_CLIENT_SECRET  - OAuth client secret (required)
        BT_PRA_VERIFY_SSL     - SSL verification (default: true)
        BT_PRA_TIMEOUT        - Request timeout in seconds (default: 30)
    """
    if env_file:
        load_dotenv(env_file)
    else:
        load_dotenv()

    # Get layered config (file + env vars)
    profile = profile or _get_profile()
    layered = get_layered_config("pra", profile)

    # Resolve any keyring references
    if "client_secret" in layered:
        layered["client_secret"] = _resolve_value(layered["client_secret"])

    config = PRAConfig(
        api_url=layered.get("api_url") or os.getenv("BT_PRA_API_URL", ""),
        client_id=layered.get("client_id") or os.getenv("BT_PRA_CLIENT_ID", ""),
        client_secret=layered.get("client_secret") or os.getenv("BT_PRA_CLIENT_SECRET", ""),
        verify_ssl=_to_bool(layered.get("verify_ssl")) if "verify_ssl" in layered else _get_bool(os.getenv("BT_PRA_VERIFY_SSL")),
        timeout=_to_float(layered.get("timeout")) if "timeout" in layered else _get_float(os.getenv("BT_PRA_TIMEOUT"), 30.0),
    )
    config.validate()
    return config


def load_epmw_config(env_file: Optional[str] = None, profile: Optional[str] = None) -> EPMWConfig:
    """Load EPM Windows configuration.

    Configuration sources (in order of precedence):
        1. Environment variables
        2. Config file (~/.bt-cli/config.yaml)

    Environment variables:
        BT_EPM_API_URL        - API endpoint URL (required, e.g., https://host-services.epm.bt3ng.com)
        BT_EPM_CLIENT_ID      - OAuth client ID (required)
        BT_EPM_CLIENT_SECRET  - OAuth client secret (required)
        BT_EPM_VERIFY_SSL     - SSL verification (default: true)
        BT_EPM_TIMEOUT        - Request timeout in seconds (default: 30)
    """
    if env_file:
        load_dotenv(env_file)
    else:
        load_dotenv()

    # Get layered config (file + env vars)
    profile = profile or _get_profile()
    layered = get_layered_config("epmw", profile)

    # Resolve any keyring references
    if "client_secret" in layered:
        layered["client_secret"] = _resolve_value(layered["client_secret"])

    config = EPMWConfig(
        api_url=layered.get("api_url") or os.getenv("BT_EPM_API_URL", ""),
        client_id=layered.get("client_id") or os.getenv("BT_EPM_CLIENT_ID", ""),
        client_secret=layered.get("client_secret") or os.getenv("BT_EPM_CLIENT_SECRET", ""),
        verify_ssl=_to_bool(layered.get("verify_ssl")) if "verify_ssl" in layered else _get_bool(os.getenv("BT_EPM_VERIFY_SSL")),
        timeout=_to_float(layered.get("timeout")) if "timeout" in layered else _get_float(os.getenv("BT_EPM_TIMEOUT"), 30.0),
    )
    config.validate()
    return config


def load_epml_config(env_file: Optional[str] = None, profile: Optional[str] = None) -> EPMLConfig:
    """Load EPM Linux configuration.

    Configuration sources (in order of precedence):
        1. Environment variables
        2. Config file (~/.bt-cli/config.yaml)

    Environment variables:
        BT_EPML_API_URL       - Gateway URL (default: https://api.beyondtrust.io)
        BT_EPML_SITE_ID       - Site UUID (required)
        BT_EPML_PAT           - Personal Access Token (required)
        BT_EPML_DEFAULT_HOST  - Default PMUL host id for host-scoped ops (default: 100)
        BT_EPML_VERIFY_SSL    - SSL verification (default: true)
        BT_EPML_TIMEOUT       - Request timeout in seconds (default: 30)
    """
    if env_file:
        load_dotenv(env_file)
    else:
        load_dotenv()

    profile = profile or _get_profile()
    layered = get_layered_config("epml", profile)

    if "pat" in layered:
        layered["pat"] = _resolve_value(layered["pat"])

    raw_host = layered.get("default_host_id") if "default_host_id" in layered else os.getenv("BT_EPML_DEFAULT_HOST")
    try:
        default_host = int(raw_host) if raw_host is not None else 100
    except (TypeError, ValueError):
        default_host = 100

    config = EPMLConfig(
        api_url=layered.get("api_url") or os.getenv("BT_EPML_API_URL", "https://api.beyondtrust.io"),
        site_id=layered.get("site_id") or os.getenv("BT_EPML_SITE_ID", ""),
        pat=layered.get("pat") or os.getenv("BT_EPML_PAT", ""),
        default_host_id=default_host,
        verify_ssl=_to_bool(layered.get("verify_ssl")) if "verify_ssl" in layered else _get_bool(os.getenv("BT_EPML_VERIFY_SSL")),
        timeout=_to_float(layered.get("timeout")) if "timeout" in layered else _get_float(os.getenv("BT_EPML_TIMEOUT"), 30.0),
    )
    config.validate()
    return config


def load_secrets_config(env_file: Optional[str] = None, profile: Optional[str] = None) -> SecretsConfig:
    """Load BeyondTrust Secrets API configuration.

    Configuration sources (in order of precedence):
        1. Environment variables
        2. Config file (~/.bt-cli/config.yaml)

    Environment variables:
        BT_SECRETS_API_URL      - Gateway URL (default: https://api.beyondtrust.io)
        BT_SECRETS_SITE_ID      - Site UUID (required)
        BT_SECRETS_PAT          - Personal Access Token (required)
        BT_SECRETS_API_VERSION  - API version header (default: 2026-04-28)
        BT_SECRETS_VERIFY_SSL   - SSL verification (default: true)
        BT_SECRETS_TIMEOUT      - Request timeout in seconds (default: 30)
    """
    if env_file:
        load_dotenv(env_file)
    else:
        load_dotenv()

    profile = profile or _get_profile()
    layered = get_layered_config("secrets", profile)

    if "pat" in layered:
        layered["pat"] = _resolve_value(layered["pat"])

    # Strip ANSI/C0 control bytes from values that flow into URLs and
    # headers — arrow keys captured at a `bt configure` prompt have been
    # observed to leave ESC sequences in site_id, breaking every request
    # with a misleading "non-printable ASCII" error from httpx.
    config = SecretsConfig(
        api_url=_strip_controls(layered.get("api_url") or os.getenv("BT_SECRETS_API_URL", "https://api.beyondtrust.io")),
        site_id=_strip_controls(layered.get("site_id") or os.getenv("BT_SECRETS_SITE_ID", "")),
        pat=_strip_controls(layered.get("pat") or os.getenv("BT_SECRETS_PAT", "")),
        api_version=_strip_controls(layered.get("api_version") or os.getenv("BT_SECRETS_API_VERSION", "2026-04-28")),
        verify_ssl=_to_bool(layered.get("verify_ssl")) if "verify_ssl" in layered else _get_bool(os.getenv("BT_SECRETS_VERIFY_SSL")),
        timeout=_to_float(layered.get("timeout")) if "timeout" in layered else _get_float(os.getenv("BT_SECRETS_TIMEOUT"), 30.0),
    )
    config.validate()
    return config


def load_config(product: str, env_file: Optional[str] = None) -> ProductConfig:
    """Load configuration for a specific product.

    Args:
        product: Product name ('pws', 'entitle', 'pra', 'epmw', 'epml', 'secrets')
        env_file: Optional path to .env file

    Returns:
        Product-specific configuration object

    Raises:
        ValueError: If product is unknown or configuration is invalid
    """
    loaders = {
        "pws": load_pws_config,
        "entitle": load_entitle_config,
        "pra": load_pra_config,
        "epmw": load_epmw_config,
        "epml": load_epml_config,
        "secrets": load_secrets_config,
    }

    loader = loaders.get(product.lower())
    if not loader:
        raise ValueError(f"Unknown product: {product}. Available: {list(loaders.keys())}")

    return loader(env_file)
