"""EPM Linux license clients — the installed-agent inventory.

Different from `bt epml hosts`: that lists PMUL *policy servers* (synthesized
from /pbul/features). This lists every client (endpoint) where the EPM-L
agent is installed and reporting in for licensing.

Endpoints:
  GET  /api/epml/license/clients                 (global)
  GET  /api/pbul/{hostid}/licenseinfo/clients    (host-scoped, same data)
  PUT  /api/epml/licenseinfo/clients/retire      (frees license seats)
  PUT  /api/pbul/{hostid}/licenseinfo/clients/retire
"""

from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

import httpx
import typer

from bt_cli.core.output import (
    OutputFormat,
    print_api_error,
    print_json,
    print_table,
    print_warning,
)

app = typer.Typer(no_args_is_help=True, help="License clients (installed EPM-L agents)")


def _fmt_epoch(ts: Any) -> str:
    """Format a unix-epoch int to an ISO-ish UTC string. 0/None → ''."""
    if not ts:
        return ""
    try:
        return datetime.fromtimestamp(int(ts), tz=timezone.utc).strftime("%Y-%m-%d %H:%M")
    except (TypeError, ValueError):
        return str(ts)


def _primary_ip(client: Dict[str, Any]) -> str:
    """Pick the first IP from the addresses list (server returns multiple)."""
    addrs = client.get("addresses") or []
    if isinstance(addrs, list) and addrs and isinstance(addrs[0], dict):
        return addrs[0].get("addr", "") or ""
    return ""


def _components(client: Dict[str, Any]) -> str:
    """Comma-joined license-bucket attrs from the stats array (e.g. RBPClnts)."""
    stats = client.get("stats") or []
    return ",".join(s.get("attr", "") for s in stats if isinstance(s, dict) and s.get("attr"))


@app.command("list")
def list_clients(
    host: Optional[int] = typer.Option(
        None, "--host", "-H",
        help="PMUL host id (uses host-scoped path); default uses /epml/license/clients",
    ),
    component: Optional[str] = typer.Option(
        None, "--component", "-c",
        help="Filter by license bucket: RBPClnts, PBULPolClnts, FIMClnts, SudoPolClnts",
    ),
    fqdn_filter: Optional[str] = typer.Option(
        None, "--fqdn", help="Substring match on FQDN (case-insensitive)",
    ),
    include_retired: bool = typer.Option(
        False, "--include-retired", help="Include retired clients (default: hide)",
    ),
    output: OutputFormat = typer.Option(OutputFormat.TABLE, "--output", "-o"),
):
    """List all clients with the EPM-L agent installed."""
    from bt_cli.epml.client import get_client

    try:
        with get_client() as c:
            data = c.list_license_clients(host_id=host) or {}
    except httpx.HTTPStatusError as e:
        print_api_error(e, "list license clients")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "list license clients")
        raise typer.Exit(1)

    rows: List[Dict[str, Any]] = list(data.get("Data", []))

    if not include_retired:
        rows = [r for r in rows if not r.get("retired")]

    if component:
        rows = [r for r in rows if any(s.get("attr") == component for s in (r.get("stats") or []))]

    if fqdn_filter:
        needle = fqdn_filter.lower()
        rows = [r for r in rows if needle in (r.get("fqdn") or "").lower()]

    if output == OutputFormat.JSON:
        print_json({"Total": len(rows), "Data": rows})
        return

    view = [
        {
            "fqdn": r.get("fqdn"),
            "uuid": r.get("uuid"),
            "ip": _primary_ip(r),
            "last_seen": _fmt_epoch(r.get("lastupdated")),
            "retired": _fmt_epoch(r.get("retired")) or "-",
            "components": _components(r),
        }
        for r in rows
    ]
    title = f"License clients ({len(rows)} of {data.get('Total', len(rows))})"
    print_table(view, [
        ("FQDN", "fqdn"),
        ("UUID", "uuid"),
        ("IP", "ip"),
        ("Last seen", "last_seen"),
        ("Retired", "retired"),
        ("Components", "components"),
    ], title=title)


@app.command("retire")
def retire_clients(
    uuids: Optional[str] = typer.Option(
        None, "--uuid", "-u",
        help="Comma-separated client UUIDs to retire",
    ),
    fqdns: Optional[str] = typer.Option(
        None, "--fqdn", "-f",
        help="Comma-separated FQDNs to retire (resolved to UUIDs via list)",
    ),
    host: Optional[int] = typer.Option(
        None, "--host", "-H", help="Use host-scoped retire path",
    ),
    confirm: bool = typer.Option(
        False, "--confirm", help="Required — retiring frees a license seat",
    ),
):
    """Retire one or more license clients (frees their license seats)."""
    from bt_cli.epml.client import get_client

    if not uuids and not fqdns:
        typer.echo("Provide --uuid and/or --fqdn", err=True)
        raise typer.Exit(2)

    targets: List[Dict[str, str]] = []
    if uuids:
        targets.extend({"uuid": u.strip()} for u in uuids.split(",") if u.strip())

    try:
        with get_client() as c:
            if fqdns:
                wanted = {f.strip().lower() for f in fqdns.split(",") if f.strip()}
                inventory = (c.list_license_clients(host_id=host) or {}).get("Data", [])
                by_fqdn = {(r.get("fqdn") or "").lower(): r for r in inventory}
                missing = []
                for fq in wanted:
                    rec = by_fqdn.get(fq)
                    if not rec:
                        missing.append(fq)
                        continue
                    targets.append({"uuid": rec.get("uuid", ""), "fqdn": rec.get("fqdn", "")})
                if missing:
                    typer.echo(f"FQDN not found: {', '.join(missing)}", err=True)
                    raise typer.Exit(1)

            if not targets:
                typer.echo("No clients matched", err=True)
                raise typer.Exit(1)

            if not confirm:
                print_warning(
                    f"Would retire {len(targets)} client(s). Re-run with --confirm to apply."
                )
                for t in targets:
                    typer.echo(f"  - {t.get('fqdn') or '<unknown fqdn>'}  {t['uuid']}")
                raise typer.Exit(0)

            result = c.retire_license_clients(targets, host_id=host)
        print_json(result if result is not None else {"retired": [t["uuid"] for t in targets]})
    except httpx.HTTPStatusError as e:
        print_api_error(e, "retire license clients")
        raise typer.Exit(1)
    except typer.Exit:
        raise
    except Exception as e:
        print_api_error(e, "retire license clients")
        raise typer.Exit(1)
