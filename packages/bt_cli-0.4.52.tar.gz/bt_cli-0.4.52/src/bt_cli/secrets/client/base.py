"""BeyondTrust Secrets API client (PAT bearer + version header, retry on 429/5xx)."""

import logging
import time
from typing import Any, Dict, List, Optional, Tuple
from urllib.parse import quote as _urlquote

import httpx

from bt_cli.core.client import _warn_ssl_disabled
from bt_cli.core.config import SecretsConfig, load_secrets_config
from bt_cli.core.rest_debug import get_event_hooks

logger = logging.getLogger(__name__)


# Deltas vs the static doc page (live as of 2026-05-14):
#   * Version header value is "2026-04-28" — the doc claims 2026-01-02 which
#     the server rejects. The server also rejects any earlier dated header,
#     so a stale default surfaces as "API version not found" rather than a
#     working-but-old response.
#   * The dynamic-secret path is "/dynamic" not "/dynamic-secrets".
#   * POST /dynamic/{name}/generate returns 201, not 200.
#   * /leases/revoke is scope-gated; the lab PAT returns 403. Surface that
#     distinctly so callers can act on it rather than treating it as generic
#     failure.

_RETRY_STATUS: Tuple[int, ...] = (429, 500, 502, 503, 504)


def split_path(full_path: str) -> Tuple[str, str]:
    """Split a full path into ``(folder, name)``.

    The Secrets API addresses every item as a name relative to a folder, but
    humans think in single paths like ``lab/aws/cloudwatch-readonly``. This
    helper splits the last segment off as the name, returning the leading
    folder (without trailing slash). A bare name (no slash) yields an empty
    folder.

        split_path("lab/aws/cloudwatch-readonly")  -> ("lab/aws", "cloudwatch-readonly")
        split_path("/lab/aws/foo")                 -> ("lab/aws", "foo")
        split_path("foo")                           -> ("", "foo")
    """
    cleaned = full_path.strip().strip("/")
    if "/" not in cleaned:
        return ("", cleaned)
    folder, _, name = cleaned.rpartition("/")
    return (folder, name)


class SecretsClient:
    """Client for the BeyondTrust Secrets API.

    URL composition:

        {api_url}/site/{site_id}/secrets/<spec-path>

    Auth: ``Authorization: Bearer <pat>`` plus the version header
    ``bt-secrets-api-version: <api_version>`` on every request.

    Retry policy: transient 5xx and 429 are retried once. When the response
    carries ``x-ratelimit-reset`` we sleep for that many seconds before the
    retry; otherwise a 1-second pause. Other 4xx errors are deterministic and
    surfaced immediately — we don't want to mask a 401/404 with retries.

    The PAT is never logged or echoed; error sanitization happens through the
    shared ``bt_cli.core.errors`` module.
    """

    def __init__(self, config: SecretsConfig):
        self.config = config
        self.base_url = config.api_url.rstrip("/")
        self.site_id = config.site_id
        self.api_version = config.api_version
        self._base = f"{self.base_url}/site/{self.site_id}/secrets"

        if not config.verify_ssl:
            _warn_ssl_disabled()

        self._client = httpx.Client(
            verify=config.verify_ssl,
            timeout=config.timeout,
            event_hooks=get_event_hooks(),
        )

    # ---- lifecycle ------------------------------------------------------

    def close(self) -> None:
        self._client.close()

    def __enter__(self) -> "SecretsClient":
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()

    # ---- low-level ------------------------------------------------------

    @staticmethod
    def _q(value: Any) -> str:
        """URL-quote a path segment. Names can contain @ ~ * ^ % which the
        API allows but which must still be encoded inside a URL path."""
        return _urlquote(str(value), safe="")

    def _url(self, spec_path: str) -> str:
        if not spec_path.startswith("/"):
            spec_path = "/" + spec_path
        return f"{self._base}{spec_path}"

    def _headers(self) -> Dict[str, str]:
        return {
            "Authorization": f"Bearer {self.config.pat}",
            "Accept": "application/json",
            "Content-Type": "application/json",
            "bt-secrets-api-version": self.api_version,
        }

    def _request(
        self,
        method: str,
        spec_path: str,
        *,
        params: Optional[Dict[str, Any]] = None,
        json: Any = None,
    ) -> httpx.Response:
        url = self._url(spec_path)
        try:
            r = self._client.request(method, url, headers=self._headers(), params=params, json=json)
            r.raise_for_status()
            return r
        except httpx.HTTPStatusError as e:
            if e.response.status_code not in _RETRY_STATUS:
                raise
            reset = e.response.headers.get("x-ratelimit-reset")
            try:
                pause = float(reset) if reset else 1.0
            except (TypeError, ValueError):
                pause = 1.0
            # Clamp so a bogus header can't park the CLI forever.
            pause = max(0.0, min(pause, 30.0))
            time.sleep(pause)
            r = self._client.request(method, url, headers=self._headers(), params=params, json=json)
            r.raise_for_status()
            return r

    @staticmethod
    def _json_or_none(r: httpx.Response) -> Any:
        if r.status_code == 204 or not r.content:
            return None
        try:
            return r.json()
        except ValueError:
            return r.text

    def get(self, spec_path: str, params: Optional[Dict[str, Any]] = None) -> Any:
        return self._json_or_none(self._request("GET", spec_path, params=params))

    def post(
        self,
        spec_path: str,
        json: Any = None,
        params: Optional[Dict[str, Any]] = None,
    ) -> Any:
        return self._json_or_none(self._request("POST", spec_path, params=params, json=json))

    def put(
        self,
        spec_path: str,
        json: Any = None,
        params: Optional[Dict[str, Any]] = None,
    ) -> Any:
        return self._json_or_none(self._request("PUT", spec_path, params=params, json=json))

    def patch(
        self,
        spec_path: str,
        json: Any = None,
        params: Optional[Dict[str, Any]] = None,
    ) -> Any:
        return self._json_or_none(self._request("PATCH", spec_path, params=params, json=json))

    def delete(self, spec_path: str, params: Optional[Dict[str, Any]] = None) -> Any:
        return self._json_or_none(self._request("DELETE", spec_path, params=params))

    # ---- Folders --------------------------------------------------------

    def list_folders(
        self,
        path: Optional[str] = None,
        recursive: bool = False,
        deleted_only: bool = False,
    ) -> List[Dict[str, Any]]:
        params: Dict[str, Any] = {}
        if path:
            params["path"] = path
        if recursive:
            params["recursive"] = "true"
        if deleted_only:
            params["deletedOnly"] = "true"
        body = self.get("/folders", params=params or None) or {}
        if isinstance(body, list):
            return body
        return body.get("data") or []

    def get_folder_metadata(self, name: str, folder: Optional[str] = None) -> Dict[str, Any]:
        params = {"folder": folder} if folder else None
        return self.get(f"/folders/{self._q(name)}/metadata", params=params) or {}

    def create_folder(self, name: str, folder: Optional[str] = None) -> Dict[str, Any]:
        params = {"folder": folder} if folder else None
        return self.post(f"/folders/{self._q(name)}", params=params) or {}

    def delete_folder(
        self,
        name: str,
        folder: Optional[str] = None,
        permanent: bool = False,
        recursive: bool = False,
    ) -> None:
        params: Dict[str, Any] = {}
        if folder:
            params["folder"] = folder
        if permanent:
            params["permanent"] = "true"
        if recursive:
            params["recursive"] = "true"
        self.delete(f"/folders/{self._q(name)}", params=params or None)

    # ---- Static secrets -------------------------------------------------

    def list_static(
        self,
        path: Optional[str] = None,
        recursive: bool = False,
        versions: bool = False,
        deleted_only: bool = False,
    ) -> List[Dict[str, Any]]:
        params: Dict[str, Any] = {}
        if path:
            params["path"] = path
        if recursive:
            params["recursive"] = "true"
        if versions:
            params["versions"] = "true"
        if deleted_only:
            params["deletedOnly"] = "true"
        body = self.get("/static", params=params or None) or {}
        if isinstance(body, list):
            return body
        return body.get("data") or []

    def get_static(
        self,
        name: str,
        folder: Optional[str] = None,
        version: Optional[int] = None,
        versions: bool = False,
    ) -> Dict[str, Any]:
        params: Dict[str, Any] = {}
        if folder:
            params["folder"] = folder
        if version is not None:
            params["version"] = version
        if versions:
            params["versions"] = "true"
        return self.get(f"/static/{self._q(name)}", params=params or None) or {}

    def create_static(self, name: str, secret: Dict[str, Any], folder: Optional[str] = None) -> Dict[str, Any]:
        params = {"folder": folder} if folder else None
        return self.post(f"/static/{self._q(name)}", json={"secret": secret}, params=params) or {}

    def update_static(self, name: str, secret: Dict[str, Any], folder: Optional[str] = None) -> None:
        params = {"folder": folder} if folder else None
        self.patch(f"/static/{self._q(name)}", json={"secret": secret}, params=params)

    def delete_static(
        self,
        name: str,
        folder: Optional[str] = None,
        permanent: bool = False,
    ) -> None:
        params: Dict[str, Any] = {}
        if folder:
            params["folder"] = folder
        if permanent:
            params["permanent"] = "true"
        self.delete(f"/static/{self._q(name)}", params=params or None)

    # ---- Dynamic secrets ------------------------------------------------
    #
    # Live API uses /dynamic, NOT /dynamic-secrets. The static doc page is
    # out of date.

    def list_dynamic(
        self,
        path: Optional[str] = None,
        recursive: bool = False,
        deleted_only: bool = False,
    ) -> List[Dict[str, Any]]:
        params: Dict[str, Any] = {}
        if path:
            params["path"] = path
        if recursive:
            params["recursive"] = "true"
        if deleted_only:
            params["deletedOnly"] = "true"
        body = self.get("/dynamic", params=params or None) or {}
        if isinstance(body, list):
            return body
        return body.get("data") or []

    def get_dynamic(self, name: str, folder: Optional[str] = None) -> Dict[str, Any]:
        params = {"folder": folder} if folder else None
        return self.get(f"/dynamic/{self._q(name)}", params=params) or {}

    def create_dynamic(self, name: str, config: Dict[str, Any], folder: Optional[str] = None) -> Dict[str, Any]:
        params = {"folder": folder} if folder else None
        return self.post(f"/dynamic/{self._q(name)}", json=config, params=params) or {}

    def update_dynamic(self, name: str, config: Dict[str, Any], folder: Optional[str] = None) -> None:
        params = {"folder": folder} if folder else None
        self.patch(f"/dynamic/{self._q(name)}", json=config, params=params)

    def delete_dynamic(
        self,
        name: str,
        folder: Optional[str] = None,
        permanent: bool = False,
    ) -> None:
        params: Dict[str, Any] = {}
        if folder:
            params["folder"] = folder
        if permanent:
            params["permanent"] = "true"
        self.delete(f"/dynamic/{self._q(name)}", params=params or None)

    def generate_dynamic(self, name: str, folder: Optional[str] = None) -> Dict[str, Any]:
        """POST /dynamic/{name}/generate — mint a fresh lease.

        Returns the full envelope (``{"secret": {...}}``); callers usually
        want ``.get("secret", {})``. The server returns 201 on success.
        """
        params = {"folder": folder} if folder else None
        return self.post(f"/dynamic/{self._q(name)}/generate", params=params) or {}

    # ---- Leases ---------------------------------------------------------

    def list_leases(self, name: str, folder: Optional[str] = None) -> List[Dict[str, Any]]:
        params = {"folder": folder} if folder else None
        body = self.get(f"/leases/{self._q(name)}", params=params) or {}
        if isinstance(body, list):
            return body
        return body.get("data") or []

    def get_lease(self, lease_id: str) -> Dict[str, Any]:
        return self.get(f"/leases/id/{self._q(lease_id)}") or {}

    def revoke_lease(self, lease_id: str) -> None:
        """GET /leases/revoke?id=<lease-id>.

        Scope-gated: the default lab PAT returns 403. Caller decides how to
        surface that — typically by catching ``httpx.HTTPStatusError`` and
        checking ``response.status_code == 403``.
        """
        self.get("/leases/revoke", params={"id": lease_id})

    # ---- Integrations ---------------------------------------------------

    def list_integrations(self, type_: Optional[str] = None) -> List[Dict[str, Any]]:
        params = {"type": type_} if type_ else None
        body = self.get("/integrations", params=params) or {}
        if isinstance(body, list):
            return body
        return body.get("data") or []

    def get_integration(self, name: str) -> Dict[str, Any]:
        return self.get(f"/integrations/{self._q(name)}") or {}

    def create_integration(self, name: str, config: Dict[str, Any]) -> Dict[str, Any]:
        return self.post(f"/integrations/{self._q(name)}", json=config) or {}

    def update_integration(self, name: str, config: Dict[str, Any]) -> Dict[str, Any]:
        """PUT — full replacement."""
        return self.put(f"/integrations/{self._q(name)}", json=config) or {}

    def patch_integration(self, name: str, config: Dict[str, Any]) -> Dict[str, Any]:
        """PATCH — partial update."""
        return self.patch(f"/integrations/{self._q(name)}", json=config) or {}

    def delete_integration(self, name: str) -> None:
        self.delete(f"/integrations/{self._q(name)}")

    # ---- Smoke ----------------------------------------------------------

    def smoke(self) -> None:
        """Verify PAT + site combination by listing the root folders.

        ``GET /folders`` is the lightest endpoint that exercises both site
        scoping and the version header.
        """
        self.get("/folders")


def get_client() -> SecretsClient:
    """Get a Secrets client from environment / config-file config."""
    return SecretsClient(load_secrets_config())
