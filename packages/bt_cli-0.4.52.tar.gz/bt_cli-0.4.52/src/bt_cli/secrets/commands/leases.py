"""Secrets API lease commands."""

import httpx
import typer

from bt_cli.core.output import (
    OutputFormat,
    print_api_error,
    print_error,
    print_json,
    print_success,
    print_table,
    print_warning,
)
from bt_cli.secrets.client import split_path

app = typer.Typer(no_args_is_help=True, help="Active leases for dynamic secrets")


def _lease_row(item: dict) -> dict:
    return {
        "leaseId": item.get("leaseId") or item.get("id"),
        "name": item.get("name"),
        "issuedAt": item.get("issuedAt") or item.get("createdAt"),
        "expiration": item.get("expiration") or item.get("expiresAt"),
        "externalEntityId": item.get("externalEntityId"),
    }


@app.command("list")
def list_leases(
    full_path: str = typer.Argument(..., help="Full dynamic-secret path"),
    output: OutputFormat = typer.Option(OutputFormat.TABLE, "--output", "-o", help="Output format"),
) -> None:
    """List active leases for a dynamic-secret config."""
    from bt_cli.secrets.client import get_client

    folder, name = split_path(full_path)
    if not name:
        typer.echo("Path must include a name", err=True)
        raise typer.Exit(2)

    try:
        with get_client() as client:
            data = client.list_leases(name, folder=folder or None)

        if output == OutputFormat.JSON:
            print_json(data)
        else:
            print_table(
                [_lease_row(r) for r in data],
                [
                    ("Lease ID", "leaseId"),
                    ("Name", "name"),
                    ("Issued", "issuedAt"),
                    ("Expires", "expiration"),
                    ("External Entity", "externalEntityId"),
                ],
                title=f"Leases — {full_path}",
            )
    except httpx.HTTPStatusError as e:
        print_api_error(e, "list leases")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "list leases")
        raise typer.Exit(1)


@app.command("get")
def get_lease(
    lease_id: str = typer.Argument(..., help="Lease UUID"),
    output: OutputFormat = typer.Option(OutputFormat.JSON, "--output", "-o", help="Output format"),
) -> None:
    """Get a lease by ID. Returns rich detail incl. externalEntityId."""
    from bt_cli.secrets.client import get_client

    try:
        with get_client() as client:
            data = client.get_lease(lease_id)

        if output == OutputFormat.JSON:
            print_json(data)
        else:
            for k, v in (data or {}).items():
                typer.echo(f"{k}: {v}")
    except httpx.HTTPStatusError as e:
        print_api_error(e, "get lease")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "get lease")
        raise typer.Exit(1)


@app.command("revoke")
def revoke_lease(
    lease_id: str = typer.Argument(..., help="Lease UUID to revoke"),
) -> None:
    """Revoke a lease (scope-gated).

    The /leases/revoke endpoint exists but is gated by a scope most PATs
    don't carry — a 403 here typically means "your PAT can't do this," not
    "the lease doesn't exist." TTL-based revocation still happens
    regardless; the lease will expire on its own.
    """
    from bt_cli.secrets.client import get_client

    try:
        with get_client() as client:
            client.revoke_lease(lease_id)
        print_success(f"Revoked lease {lease_id}")
    except httpx.HTTPStatusError as e:
        if e.response.status_code == 403:
            print_warning(
                f"403 Forbidden — your PAT lacks the revoke scope. "
                f"Lease {lease_id} will still expire at its TTL."
            )
            raise typer.Exit(3)
        print_api_error(e, "revoke lease")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "revoke lease")
        raise typer.Exit(1)
