"""Secrets API authentication / connectivity commands."""

import os

import httpx
import typer

from bt_cli.core.output import print_api_error, print_error, print_success, print_warning

app = typer.Typer(no_args_is_help=True, help="Authentication and connection testing")


@app.command()
def test() -> None:
    """Test the Secrets API connection by listing root folders.

    Distinct error meanings:
      * 401 — PAT is invalid or revoked.
      * 403 — PAT works but lacks scope for the Secrets API on this site.
      * 404 — site_id is wrong; the gateway returns a generic not-found.
    """
    from bt_cli.secrets.client import get_client

    try:
        with get_client() as client:
            client.smoke()
            print_success(f"Connected to Secrets API at site {client.site_id}")
            print_success(f"API version: {client.api_version}")
    except ValueError as e:
        print_error(f"Configuration error: {e}")
        raise typer.Exit(1)
    except httpx.HTTPStatusError as e:
        code = e.response.status_code
        if code == 401:
            print_error("401 Unauthorized — PAT is invalid or revoked")
        elif code == 403:
            print_error("403 Forbidden — PAT lacks Secrets API scope on this site")
        elif code == 404:
            print_error("404 Not Found — check BT_SECRETS_SITE_ID")
        print_api_error(e, "test connection")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "test connection")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "test connection")
        raise typer.Exit(1)


@app.command()
def status() -> None:
    """Show Secrets API configuration status (env-var view)."""
    api_url = os.getenv("BT_SECRETS_API_URL", "https://api.beyondtrust.io")
    site_id = os.getenv("BT_SECRETS_SITE_ID", "")
    pat = os.getenv("BT_SECRETS_PAT", "")
    api_version = os.getenv("BT_SECRETS_API_VERSION", "2026-04-28")

    typer.echo("Secrets API Configuration:")
    typer.echo(f"  Gateway URL:  {api_url}")
    typer.echo(f"  Site ID:      {site_id or '(not set)'}")
    typer.echo(f"  PAT:          {pat[:12] + '...' if pat else '(not set)'}")
    typer.echo(f"  API version:  {api_version}")

    if not site_id:
        print_warning("BT_SECRETS_SITE_ID is not set")
    if not pat:
        print_warning("BT_SECRETS_PAT is not set")
