"""BeyondTrust Secrets API commands."""

import typer

from .auth import app as auth_app
from .dynamic import app as dynamic_app
from .folders import app as folders_app
from .integrations import app as integrations_app
from .leases import app as leases_app
from .static import app as static_app

app = typer.Typer(
    name="secrets",
    help="BeyondTrust Secrets API (folders, static, dynamic, leases, integrations)",
    no_args_is_help=True,
)

app.add_typer(auth_app, name="auth")
app.add_typer(folders_app, name="folders")
app.add_typer(static_app, name="static")
app.add_typer(dynamic_app, name="dynamic")
app.add_typer(leases_app, name="leases")
app.add_typer(integrations_app, name="integrations")
