"""Secrets API static-secret commands."""

import json
from typing import Optional

import httpx
import typer

from bt_cli.core.output import (
    OutputFormat,
    confirm_action,
    print_api_error,
    print_error,
    print_json,
    print_success,
    print_table,
)
from bt_cli.secrets.client import split_path
from bt_cli.secrets.commands._hints import empty_hint

app = typer.Typer(no_args_is_help=True, help="Static (key/value, versioned) secrets")


def _static_row(item: dict) -> dict:
    meta = item.get("metadata") or {}
    return {
        "path": item.get("path"),
        "type": item.get("type"),
        "version": meta.get("version"),
        "id": meta.get("id"),
        "createdAt": meta.get("createdAt"),
    }


@app.command("list")
def list_static(
    path: Optional[str] = typer.Option(None, "--path", "-p", help="Path prefix to filter (server-side)"),
    recursive: bool = typer.Option(
        True, "--recursive/--shallow", "-r/-S",
        help="Recurse into subfolders (default). Use --shallow / -S for direct children only.",
    ),
    versions: bool = typer.Option(False, "--versions", help="Include version history"),
    deleted_only: bool = typer.Option(False, "--deleted-only", help="Only list soft-deleted secrets"),
    output: OutputFormat = typer.Option(OutputFormat.TABLE, "--output", "-o", help="Output format"),
) -> None:
    """List static secrets. Recursive by default — pass --shallow for direct children only."""
    from bt_cli.secrets.client import get_client

    try:
        with get_client() as client:
            data = client.list_static(
                path=path, recursive=recursive, versions=versions, deleted_only=deleted_only,
            )

        if output == OutputFormat.JSON:
            print_json(data)
        elif not data:
            empty_hint(path, recursive, "static secrets")
        else:
            print_table(
                [_static_row(r) for r in data],
                [
                    ("Path", "path"),
                    ("Type", "type"),
                    ("Version", "version"),
                    ("ID", "id"),
                    ("Created", "createdAt"),
                ],
                title="Static Secrets",
            )
    except httpx.HTTPStatusError as e:
        print_api_error(e, "list static secrets")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "list static secrets")
        raise typer.Exit(1)


@app.command("get")
def get_static(
    full_path: str = typer.Argument(..., help="Full secret path, e.g. lab/aws/db-password"),
    version: Optional[int] = typer.Option(None, "--version", "-v", help="Specific version to read"),
    versions: bool = typer.Option(False, "--versions", help="Include all version metadata"),
    output: OutputFormat = typer.Option(OutputFormat.JSON, "--output", "-o", help="Output format"),
) -> None:
    """Get a static secret value.

    Default output is JSON since values may contain structure.
    """
    from bt_cli.secrets.client import get_client

    folder, name = split_path(full_path)
    if not name:
        typer.echo("Secret path must include a name", err=True)
        raise typer.Exit(2)

    try:
        with get_client() as client:
            secret = client.get_static(name, folder=folder or None, version=version, versions=versions)

        if output == OutputFormat.JSON:
            print_json(secret)
        else:
            for k, v in (secret.get("secret") or {}).items():
                typer.echo(f"{k}={v}")
    except httpx.HTTPStatusError as e:
        print_api_error(e, "get static secret")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "get static secret")
        raise typer.Exit(1)


@app.command("create")
def create_static(
    full_path: str = typer.Argument(..., help="Full secret path, e.g. lab/db/creds"),
    data: Optional[str] = typer.Option(
        None, "--data", "-d",
        help="JSON object with the secret payload (e.g. '{\"password\":\"hunter2\"}')",
    ),
    data_file: Optional[str] = typer.Option(
        None, "--data-file", help="Path to a JSON file with the secret payload",
    ),
    output: OutputFormat = typer.Option(OutputFormat.JSON, "--output", "-o", help="Output format"),
) -> None:
    """Create a static secret. Pass the payload as inline JSON or via a file."""
    from bt_cli.secrets.client import get_client

    if not data and not data_file:
        print_error("Provide --data '<json>' or --data-file <path>")
        raise typer.Exit(2)
    if data and data_file:
        print_error("Provide either --data or --data-file, not both")
        raise typer.Exit(2)

    raw = data
    if data_file:
        try:
            with open(data_file, "r") as f:
                raw = f.read()
        except OSError as e:
            print_error(f"Cannot read --data-file: {e}")
            raise typer.Exit(2)

    try:
        payload = json.loads(raw)
    except json.JSONDecodeError as e:
        print_error(f"Invalid JSON: {e}")
        raise typer.Exit(2)
    if not isinstance(payload, dict):
        print_error("Secret payload must be a JSON object")
        raise typer.Exit(2)

    folder, name = split_path(full_path)
    if not name:
        typer.echo("Secret path must include a name", err=True)
        raise typer.Exit(2)

    try:
        with get_client() as client:
            result = client.create_static(name, secret=payload, folder=folder or None)

        if output == OutputFormat.JSON:
            print_json(result)
        else:
            print_success(f"Created secret {full_path}")
    except httpx.HTTPStatusError as e:
        print_api_error(e, "create static secret")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "create static secret")
        raise typer.Exit(1)


@app.command("update")
def update_static(
    full_path: str = typer.Argument(..., help="Full secret path"),
    data: Optional[str] = typer.Option(None, "--data", "-d", help="JSON payload (replaces value, bumps version)"),
    data_file: Optional[str] = typer.Option(None, "--data-file", help="Path to JSON file with payload"),
) -> None:
    """Update a static secret. Creates a new version on success (204 from server)."""
    from bt_cli.secrets.client import get_client

    if not data and not data_file:
        print_error("Provide --data '<json>' or --data-file <path>")
        raise typer.Exit(2)
    if data and data_file:
        print_error("Provide either --data or --data-file, not both")
        raise typer.Exit(2)

    raw = data
    if data_file:
        try:
            with open(data_file, "r") as f:
                raw = f.read()
        except OSError as e:
            print_error(f"Cannot read --data-file: {e}")
            raise typer.Exit(2)

    try:
        payload = json.loads(raw)
    except json.JSONDecodeError as e:
        print_error(f"Invalid JSON: {e}")
        raise typer.Exit(2)
    if not isinstance(payload, dict):
        print_error("Secret payload must be a JSON object")
        raise typer.Exit(2)

    folder, name = split_path(full_path)
    if not name:
        typer.echo("Secret path must include a name", err=True)
        raise typer.Exit(2)

    try:
        with get_client() as client:
            client.update_static(name, secret=payload, folder=folder or None)
        print_success(f"Updated secret {full_path}")
    except httpx.HTTPStatusError as e:
        print_api_error(e, "update static secret")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "update static secret")
        raise typer.Exit(1)


@app.command("delete")
def delete_static(
    full_path: str = typer.Argument(..., help="Full secret path to delete"),
    permanent: bool = typer.Option(False, "--permanent", help="Skip soft-delete and remove permanently"),
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation"),
) -> None:
    """Delete a static secret."""
    from bt_cli.secrets.client import get_client

    folder, name = split_path(full_path)
    if not name:
        typer.echo("Secret path must include a name", err=True)
        raise typer.Exit(2)

    if not force:
        msg = f"Delete secret '{full_path}'"
        if permanent:
            msg += " (PERMANENT)"
        if not confirm_action(msg + "?"):
            typer.echo("Cancelled")
            raise typer.Exit(0)

    try:
        with get_client() as client:
            client.delete_static(name, folder=folder or None, permanent=permanent)
        print_success(f"Deleted secret {full_path}")
    except httpx.HTTPStatusError as e:
        print_api_error(e, "delete static secret")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "delete static secret")
        raise typer.Exit(1)
