"""Secrets API folder commands."""

from typing import Optional

import httpx
import typer

from bt_cli.core.output import (
    OutputFormat,
    confirm_action,
    print_api_error,
    print_json,
    print_success,
    print_table,
)
from bt_cli.secrets.client import split_path
from bt_cli.secrets.commands._hints import empty_hint

app = typer.Typer(no_args_is_help=True, help="Folders for organizing secrets")


def _folder_row(item: dict) -> dict:
    meta = item.get("metadata") or {}
    return {
        "path": item.get("path"),
        "id": meta.get("id"),
        "createdAt": meta.get("createdAt"),
    }


@app.command("list")
def list_folders(
    path: Optional[str] = typer.Option(None, "--path", "-p", help="Path prefix to filter folders"),
    recursive: bool = typer.Option(
        True, "--recursive/--shallow", "-r/-S",
        help="Recurse into subfolders (default). Use --shallow / -S for direct children only.",
    ),
    deleted_only: bool = typer.Option(False, "--deleted-only", help="Only list soft-deleted folders"),
    output: OutputFormat = typer.Option(OutputFormat.TABLE, "--output", "-o", help="Output format"),
) -> None:
    """List folders. Recursive by default — pass --shallow for direct children only."""
    from bt_cli.secrets.client import get_client

    try:
        with get_client() as client:
            data = client.list_folders(path=path, recursive=recursive, deleted_only=deleted_only)

        if output == OutputFormat.JSON:
            print_json(data)
        elif not data:
            empty_hint(path, recursive, "folders")
        else:
            print_table(
                [_folder_row(r) for r in data],
                [("Path", "path"), ("ID", "id"), ("Created", "createdAt")],
                title="Folders",
            )
    except httpx.HTTPStatusError as e:
        print_api_error(e, "list folders")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "list folders")
        raise typer.Exit(1)


@app.command("get")
def get_folder(
    full_path: str = typer.Argument(..., help="Full folder path, e.g. lab/aws"),
    output: OutputFormat = typer.Option(OutputFormat.JSON, "--output", "-o", help="Output format"),
) -> None:
    """Get folder metadata by full path."""
    from bt_cli.secrets.client import get_client

    folder, name = split_path(full_path)
    if not name:
        typer.echo("Folder path must include a name", err=True)
        raise typer.Exit(2)

    try:
        with get_client() as client:
            meta = client.get_folder_metadata(name, folder=folder or None)

        if output == OutputFormat.JSON:
            print_json(meta)
        else:
            for k, v in (meta or {}).items():
                typer.echo(f"{k}: {v}")
    except httpx.HTTPStatusError as e:
        print_api_error(e, "get folder")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "get folder")
        raise typer.Exit(1)


@app.command("create")
def create_folder(
    full_path: str = typer.Argument(..., help="Full folder path to create, e.g. lab/aws/staging"),
    output: OutputFormat = typer.Option(OutputFormat.JSON, "--output", "-o", help="Output format"),
) -> None:
    """Create a folder at the given path."""
    from bt_cli.secrets.client import get_client

    folder, name = split_path(full_path)
    if not name:
        typer.echo("Folder path must include a name", err=True)
        raise typer.Exit(2)

    try:
        with get_client() as client:
            result = client.create_folder(name, folder=folder or None)

        if output == OutputFormat.JSON:
            print_json(result)
        else:
            print_success(f"Created folder /{folder + '/' if folder else ''}{name}")
    except httpx.HTTPStatusError as e:
        print_api_error(e, "create folder")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "create folder")
        raise typer.Exit(1)


@app.command("delete")
def delete_folder(
    full_path: str = typer.Argument(..., help="Full folder path to delete"),
    recursive: bool = typer.Option(False, "--recursive", "-r", help="Delete folder and all contents"),
    permanent: bool = typer.Option(False, "--permanent", help="Skip soft-delete and remove permanently"),
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation"),
) -> None:
    """Delete a folder. Use --recursive to remove non-empty folders."""
    from bt_cli.secrets.client import get_client

    folder, name = split_path(full_path)
    if not name:
        typer.echo("Folder path must include a name", err=True)
        raise typer.Exit(2)

    if not force:
        msg = f"Delete folder '{full_path}'"
        if recursive:
            msg += " AND ALL CONTENTS"
        if permanent:
            msg += " (PERMANENT)"
        if not confirm_action(msg + "?"):
            typer.echo("Cancelled")
            raise typer.Exit(0)

    try:
        with get_client() as client:
            client.delete_folder(name, folder=folder or None, permanent=permanent, recursive=recursive)
        print_success(f"Deleted folder {full_path}")
    except httpx.HTTPStatusError as e:
        print_api_error(e, "delete folder")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "delete folder")
        raise typer.Exit(1)
