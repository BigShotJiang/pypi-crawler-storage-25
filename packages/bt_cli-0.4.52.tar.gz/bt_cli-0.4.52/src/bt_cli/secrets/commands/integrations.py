"""Secrets API integration commands (external systems like AWS)."""

import json
from typing import Optional

import httpx
import typer

from bt_cli.core.output import (
    OutputFormat,
    confirm_action,
    print_api_error,
    print_error,
    print_json,
    print_success,
    print_table,
)

app = typer.Typer(no_args_is_help=True, help="External-system integrations (AWS, ...)")


def _integration_row(item: dict) -> dict:
    return {
        "name": item.get("name"),
        "type": item.get("type"),
        "id": item.get("id") or (item.get("metadata") or {}).get("id"),
        "createdAt": item.get("createdAt") or (item.get("metadata") or {}).get("createdAt"),
    }


@app.command("list")
def list_integrations(
    type_: Optional[str] = typer.Option(None, "--type", "-t", help="Filter by integration type (e.g. aws)"),
    output: OutputFormat = typer.Option(OutputFormat.TABLE, "--output", "-o", help="Output format"),
) -> None:
    """List integrations (server-side filter by --type)."""
    from bt_cli.secrets.client import get_client

    try:
        with get_client() as client:
            data = client.list_integrations(type_=type_)

        if output == OutputFormat.JSON:
            print_json(data)
        else:
            print_table(
                [_integration_row(r) for r in data],
                [("Name", "name"), ("Type", "type"), ("ID", "id"), ("Created", "createdAt")],
                title="Integrations",
            )
    except httpx.HTTPStatusError as e:
        print_api_error(e, "list integrations")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "list integrations")
        raise typer.Exit(1)


@app.command("get")
def get_integration(
    name: str = typer.Argument(..., help="Integration name"),
    output: OutputFormat = typer.Option(OutputFormat.JSON, "--output", "-o", help="Output format"),
) -> None:
    """Get an integration by name."""
    from bt_cli.secrets.client import get_client

    try:
        with get_client() as client:
            data = client.get_integration(name)

        if output == OutputFormat.JSON:
            print_json(data)
        else:
            for k, v in (data or {}).items():
                typer.echo(f"{k}: {v}")
    except httpx.HTTPStatusError as e:
        print_api_error(e, "get integration")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "get integration")
        raise typer.Exit(1)


def _load_payload(data: Optional[str], data_file: Optional[str]) -> dict:
    if not data and not data_file:
        print_error("Provide --data '<json>' or --data-file <path>")
        raise typer.Exit(2)
    if data and data_file:
        print_error("Provide either --data or --data-file, not both")
        raise typer.Exit(2)

    raw = data
    if data_file:
        try:
            with open(data_file, "r") as f:
                raw = f.read()
        except OSError as e:
            print_error(f"Cannot read --data-file: {e}")
            raise typer.Exit(2)

    try:
        payload = json.loads(raw)
    except json.JSONDecodeError as e:
        print_error(f"Invalid JSON: {e}")
        raise typer.Exit(2)
    if not isinstance(payload, dict):
        print_error("Integration config must be a JSON object")
        raise typer.Exit(2)
    return payload


@app.command("create")
def create_integration(
    name: str = typer.Argument(..., help="Integration name"),
    data: Optional[str] = typer.Option(None, "--data", "-d", help="JSON config"),
    data_file: Optional[str] = typer.Option(None, "--data-file", help="Path to JSON file with config"),
    output: OutputFormat = typer.Option(OutputFormat.JSON, "--output", "-o", help="Output format"),
) -> None:
    """Create an integration.

    Example AWS body:

        {"type":"aws","roleArn":"arn:aws:iam::123:role/MyRole","externalId":"ext-123"}
    """
    from bt_cli.secrets.client import get_client

    payload = _load_payload(data, data_file)

    try:
        with get_client() as client:
            result = client.create_integration(name, config=payload)

        if output == OutputFormat.JSON:
            print_json(result)
        else:
            print_success(f"Created integration {name}")
    except httpx.HTTPStatusError as e:
        print_api_error(e, "create integration")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "create integration")
        raise typer.Exit(1)


@app.command("update")
def update_integration(
    name: str = typer.Argument(..., help="Integration name"),
    data: Optional[str] = typer.Option(None, "--data", "-d", help="JSON config"),
    data_file: Optional[str] = typer.Option(None, "--data-file", help="Path to JSON file with config"),
    partial: bool = typer.Option(
        False, "--partial",
        help="Use PATCH (partial update) instead of PUT (full replacement)",
    ),
    output: OutputFormat = typer.Option(OutputFormat.JSON, "--output", "-o", help="Output format"),
) -> None:
    """Update an integration. Defaults to PUT (full replace); use --partial for PATCH."""
    from bt_cli.secrets.client import get_client

    payload = _load_payload(data, data_file)

    try:
        with get_client() as client:
            if partial:
                result = client.patch_integration(name, config=payload)
            else:
                result = client.update_integration(name, config=payload)

        if output == OutputFormat.JSON:
            print_json(result)
        else:
            print_success(f"Updated integration {name}")
    except httpx.HTTPStatusError as e:
        print_api_error(e, "update integration")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "update integration")
        raise typer.Exit(1)


@app.command("delete")
def delete_integration(
    name: str = typer.Argument(..., help="Integration name"),
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation"),
) -> None:
    """Delete an integration."""
    from bt_cli.secrets.client import get_client

    if not force and not confirm_action(f"Delete integration '{name}'?"):
        typer.echo("Cancelled")
        raise typer.Exit(0)

    try:
        with get_client() as client:
            client.delete_integration(name)
        print_success(f"Deleted integration {name}")
    except httpx.HTTPStatusError as e:
        print_api_error(e, "delete integration")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "delete integration")
        raise typer.Exit(1)
