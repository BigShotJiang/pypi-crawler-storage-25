"""Shared empty-result hint for `bt secrets <X> list` commands.

When server-side filtering returns 0 rows it's almost always one of:
  * --path points one level too high (items live in subfolders)
  * --shallow was passed but the user thought it was recursive
  * the path simply doesn't exist

The default "No results found" output gives no clue which. This helper
prints a one-liner that nudges the user toward the next thing to try.
"""

from typing import Optional

from bt_cli.core.output import console


def empty_hint(path: Optional[str], recursive: bool, kind: str) -> None:
    """Print a tip when a list call returns no rows."""
    if recursive:
        where = f" under {path!r}" if path else ""
        console.print(f"[dim]No {kind} found{where}.[/dim]")
        console.print(
            "[dim]Tip: pass --shallow for direct children only, or check the path.[/dim]"
        )
    else:
        at = f" directly at {path!r}" if path else " at the root"
        console.print(f"[dim]No {kind}{at} (--shallow mode).[/dim]")
        console.print(
            "[dim]Tip: drop --shallow (default is recursive) to search subfolders.[/dim]"
        )
