"""Secrets API dynamic-secret commands.

Live API uses /dynamic, NOT /dynamic-secrets (the doc page is stale).
"""

import json
from enum import Enum
from typing import Optional

import httpx
import typer

from bt_cli.core.output import (
    OutputFormat,
    confirm_action,
    print_api_error,
    print_error,
    print_json,
    print_success,
    print_table,
)
from bt_cli.secrets.client import split_path
from bt_cli.secrets.commands._hints import empty_hint

app = typer.Typer(no_args_is_help=True, help="Dynamic secrets (e.g. AWS STS, mint on demand)")


class GenerateFormat(str, Enum):
    """Output formats for `dynamic generate`."""

    EXPORT = "export"          # default — bash/zsh `export AWS_*` lines
    POWERSHELL = "powershell"  # PowerShell `$env:AWS_* = "..."` lines
    CMD = "cmd"                # Windows cmd.exe `set AWS_*=...` lines
    ENV = "env"                # bare KEY=value lines (no `export`)
    JSON = "json"              # raw API payload
    DOTENV = "dotenv"          # KEY="value" lines suitable for .env files


def _dynamic_row(item: dict) -> dict:
    meta = item.get("metadata") or {}
    return {
        "path": item.get("path"),
        "type": item.get("type"),
        "id": meta.get("id"),
        "createdAt": meta.get("createdAt"),
    }


def _apply_hint(full_path: str, fmt: GenerateFormat) -> str:
    """Build a one-line apply-recipe in syntax valid for the chosen format.

    `eval $(...)`, `| iex`, and `for /f` all swallow comment lines harmlessly,
    so embedding the hint costs nothing when the output is piped through —
    it's just discoverable for users who run the command on its own first.

    Non-shell formats (env / dotenv / json) get no hint: env/dotenv are for
    writing to files, json is for scripts; neither has a single canonical
    apply command.
    """
    if fmt is GenerateFormat.EXPORT:
        return f"# Tip: apply with -> eval $(bt secrets dynamic generate {full_path})"
    if fmt is GenerateFormat.POWERSHELL:
        return (
            f"# Tip: apply with -> "
            f"bt secrets dynamic generate {full_path} --format powershell | iex"
        )
    if fmt is GenerateFormat.CMD:
        return (
            f'REM Tip: apply with -> for /f "delims=" %i in '
            f"('bt secrets dynamic generate {full_path} --format cmd') do %i"
        )
    return ""


def _format_credentials(secret: dict, fmt: GenerateFormat) -> str:
    """Format an AWS STS credential triplet in the requested shape.

    The Secrets API returns AWS STS fields in camelCase
    (``accessKeyId``, ``secretAccessKey``, ``sessionToken``). For shell
    consumption we map those to the standard ``AWS_*`` env-var names that
    boto3, aws-cli, and the EC2 SDK all read.

    A subprocess can't mutate its parent shell's environment, so each
    format is designed to be piped into the shell's eval mechanism:

      * EXPORT     → `eval $(bt secrets dynamic generate <path>)`
      * POWERSHELL → `bt secrets dynamic generate <path> --format powershell | iex`
      * CMD        → cmd.exe needs a temp .bat or a `for /f` loop — see SKILL.md
    """
    aws_map = [
        ("AWS_ACCESS_KEY_ID", "accessKeyId"),
        ("AWS_SECRET_ACCESS_KEY", "secretAccessKey"),
        ("AWS_SESSION_TOKEN", "sessionToken"),
    ]
    lines = []
    for env_name, payload_key in aws_map:
        if payload_key in secret:
            value = secret[payload_key]
            if fmt is GenerateFormat.EXPORT:
                lines.append(f"export {env_name}={value}")
            elif fmt is GenerateFormat.POWERSHELL:
                # `Invoke-Expression` parses these as statements that set the
                # process env. Quote the value so PowerShell doesn't try to
                # interpret embedded characters.
                lines.append(f'$env:{env_name} = "{value}"')
            elif fmt is GenerateFormat.CMD:
                # `set` in cmd.exe doesn't quote and doesn't tolerate spaces
                # around `=`. Values from STS are alphanumeric-plus-/+=_-, so
                # bare assignment is safe.
                lines.append(f"set {env_name}={value}")
            elif fmt is GenerateFormat.ENV:
                lines.append(f"{env_name}={value}")
            elif fmt is GenerateFormat.DOTENV:
                lines.append(f'{env_name}="{value}"')
    if not lines:
        return ""
    if "expiration" in secret:
        # Trailing comment is informational — all four script-y formats
        # tolerate `#` (bash/PowerShell) or treat the line as a label-style
        # noop for cmd's set, which we replace with REM below.
        if fmt is GenerateFormat.CMD:
            lines.append(f"REM expires: {secret['expiration']}")
        else:
            lines.append(f"# expires: {secret['expiration']}")
    return "\n".join(lines)


@app.command("list")
def list_dynamic(
    path: Optional[str] = typer.Option(None, "--path", "-p", help="Path prefix to filter"),
    recursive: bool = typer.Option(
        True, "--recursive/--shallow", "-r/-S",
        help="Recurse into subfolders (default). Use --shallow / -S for direct children only.",
    ),
    deleted_only: bool = typer.Option(False, "--deleted-only", help="Only list soft-deleted configs"),
    output: OutputFormat = typer.Option(OutputFormat.TABLE, "--output", "-o", help="Output format"),
) -> None:
    """List dynamic-secret configs. Recursive by default — pass --shallow for direct children only."""
    from bt_cli.secrets.client import get_client

    try:
        with get_client() as client:
            data = client.list_dynamic(path=path, recursive=recursive, deleted_only=deleted_only)

        if output == OutputFormat.JSON:
            print_json(data)
        elif not data:
            empty_hint(path, recursive, "dynamic secrets")
        else:
            print_table(
                [_dynamic_row(r) for r in data],
                [
                    ("Path", "path"),
                    ("Type", "type"),
                    ("ID", "id"),
                    ("Created", "createdAt"),
                ],
                title="Dynamic Secrets",
            )
    except httpx.HTTPStatusError as e:
        print_api_error(e, "list dynamic secrets")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "list dynamic secrets")
        raise typer.Exit(1)


@app.command("get")
def get_dynamic(
    full_path: str = typer.Argument(..., help="Full dynamic-secret path, e.g. lab/aws/ec2-readonly"),
    output: OutputFormat = typer.Option(OutputFormat.JSON, "--output", "-o", help="Output format"),
) -> None:
    """Get a dynamic-secret config (NOT a fresh credential — use `generate` for that)."""
    from bt_cli.secrets.client import get_client

    folder, name = split_path(full_path)
    if not name:
        typer.echo("Path must include a name", err=True)
        raise typer.Exit(2)

    try:
        with get_client() as client:
            cfg = client.get_dynamic(name, folder=folder or None)

        if output == OutputFormat.JSON:
            print_json(cfg)
        else:
            for k, v in (cfg or {}).items():
                typer.echo(f"{k}: {v}")
    except httpx.HTTPStatusError as e:
        print_api_error(e, "get dynamic secret")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "get dynamic secret")
        raise typer.Exit(1)


@app.command("generate")
def generate(
    full_path: str = typer.Argument(..., help="Full dynamic-secret path"),
    format_: GenerateFormat = typer.Option(
        GenerateFormat.EXPORT, "--format", "-F",
        help="Output format: export | powershell | cmd | env | json | dotenv",
        case_sensitive=False,
    ),
) -> None:
    """Mint fresh credentials from a dynamic-secret config.

    Default ``--format export`` prints shell ``export AWS_*`` lines.

    \b
    Apply in your current session:
      bash / zsh:    eval $(bt secrets dynamic generate <path>)
      PowerShell:    bt secrets dynamic generate <path> --format powershell | iex
      cmd.exe:       for /f "delims=" %i in ('bt secrets dynamic generate <path> --format cmd') do %i

    Use ``--format json`` to see the full payload (lease id, expiration).

    Heads up: every call mints real STS credentials and shows up in the
    audit trail. Don't loop this in development.
    """
    from bt_cli.secrets.client import get_client

    folder, name = split_path(full_path)
    if not name:
        typer.echo("Path must include a name", err=True)
        raise typer.Exit(2)

    try:
        with get_client() as client:
            envelope = client.generate_dynamic(name, folder=folder or None)
    except httpx.HTTPStatusError as e:
        print_api_error(e, "generate dynamic credential")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "generate dynamic credential")
        raise typer.Exit(1)

    secret = envelope.get("secret") if isinstance(envelope, dict) else None
    if not isinstance(secret, dict) or not secret:
        print_error("Server returned no credential payload")
        if envelope:
            print_json(envelope)
        raise typer.Exit(1)

    if format_ is GenerateFormat.JSON:
        print_json(envelope)
        return

    text = _format_credentials(secret, format_)
    if not text:
        # Non-AWS dynamic credentials — fall back to raw JSON.
        print_error("Unrecognized credential shape; printing raw payload")
        print_json(secret)
        raise typer.Exit(1)
    hint = _apply_hint(full_path, format_)
    if hint:
        text = f"{text}\n{hint}"
    typer.echo(text)


@app.command("create")
def create_dynamic(
    full_path: str = typer.Argument(..., help="Full path to create"),
    data: Optional[str] = typer.Option(None, "--data", "-d", help="JSON object with the dynamic-secret config"),
    data_file: Optional[str] = typer.Option(None, "--data-file", help="Path to a JSON file with the config"),
    output: OutputFormat = typer.Option(OutputFormat.JSON, "--output", "-o", help="Output format"),
) -> None:
    """Create a dynamic-secret config.

    Example AWS config body:

        {
          "type": "aws",
          "integrationName": "my-aws",
          "credentialType": "assumed_role",
          "roleArn": "arn:aws:iam::123456789012:role/MyRole",
          "ttl": 900
        }
    """
    from bt_cli.secrets.client import get_client

    if not data and not data_file:
        print_error("Provide --data '<json>' or --data-file <path>")
        raise typer.Exit(2)
    if data and data_file:
        print_error("Provide either --data or --data-file, not both")
        raise typer.Exit(2)

    raw = data
    if data_file:
        try:
            with open(data_file, "r") as f:
                raw = f.read()
        except OSError as e:
            print_error(f"Cannot read --data-file: {e}")
            raise typer.Exit(2)

    try:
        payload = json.loads(raw)
    except json.JSONDecodeError as e:
        print_error(f"Invalid JSON: {e}")
        raise typer.Exit(2)
    if not isinstance(payload, dict):
        print_error("Config must be a JSON object")
        raise typer.Exit(2)

    folder, name = split_path(full_path)
    if not name:
        typer.echo("Path must include a name", err=True)
        raise typer.Exit(2)

    try:
        with get_client() as client:
            result = client.create_dynamic(name, config=payload, folder=folder or None)

        if output == OutputFormat.JSON:
            print_json(result)
        else:
            print_success(f"Created dynamic secret {full_path}")
    except httpx.HTTPStatusError as e:
        print_api_error(e, "create dynamic secret")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "create dynamic secret")
        raise typer.Exit(1)


@app.command("delete")
def delete_dynamic(
    full_path: str = typer.Argument(..., help="Full path of the dynamic-secret config to delete"),
    permanent: bool = typer.Option(False, "--permanent", help="Skip soft-delete and remove permanently"),
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation"),
) -> None:
    """Delete a dynamic-secret config."""
    from bt_cli.secrets.client import get_client

    folder, name = split_path(full_path)
    if not name:
        typer.echo("Path must include a name", err=True)
        raise typer.Exit(2)

    if not force:
        msg = f"Delete dynamic secret '{full_path}'"
        if permanent:
            msg += " (PERMANENT)"
        if not confirm_action(msg + "?"):
            typer.echo("Cancelled")
            raise typer.Exit(0)

    try:
        with get_client() as client:
            client.delete_dynamic(name, folder=folder or None, permanent=permanent)
        print_success(f"Deleted dynamic secret {full_path}")
    except httpx.HTTPStatusError as e:
        print_api_error(e, "delete dynamic secret")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "delete dynamic secret")
        raise typer.Exit(1)
