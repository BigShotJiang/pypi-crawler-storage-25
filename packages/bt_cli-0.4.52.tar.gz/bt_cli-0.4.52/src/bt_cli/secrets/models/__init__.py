"""BeyondTrust Secrets API models (none yet — responses are passed through as dicts)."""
