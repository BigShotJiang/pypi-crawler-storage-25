"""BeyondTrust Secrets API module."""
