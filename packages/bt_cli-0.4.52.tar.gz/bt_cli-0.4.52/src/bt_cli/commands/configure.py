"""Configure command for bt-cli CLI.

Provides interactive and non-interactive configuration management.
"""

import typer
from rich.console import Console
from rich.panel import Panel
from rich.prompt import Confirm, Prompt
from rich.table import Table
from typing import Optional

from ..core.config_file import (
    CONFIG_FILE,
    PRODUCTS,
    ConfigFile,
    ensure_config_dir,
    load_config_file,
    save_config_file,
    set_secret_in_keyring,
    _keyring_available,
)
from ..core.output import print_error, print_info, print_success, print_warning

app = typer.Typer(no_args_is_help=True, help="Configure bt-cli settings")
console = Console()


@app.callback(invoke_without_command=True)
def configure_callback(
    ctx: typer.Context,
    product: Optional[str] = typer.Option(
        None,
        "--product", "-p",
        help="Product to configure (pws, entitle, pra, epmw)",
    ),
    profile: Optional[str] = typer.Option(
        None,
        "--profile",
        help="Profile name (default: 'default')",
    ),
    api_url: Optional[str] = typer.Option(None, "--api-url", help="API URL"),
    client_id: Optional[str] = typer.Option(None, "--client-id", help="OAuth Client ID"),
    client_secret: Optional[str] = typer.Option(None, "--client-secret", help="OAuth Client Secret"),
    api_key: Optional[str] = typer.Option(None, "--api-key", help="API Key"),
    user_api_key: Optional[str] = typer.Option(
        None,
        "--user-api-key",
        help="Entitle user-context API key (only required for `bt entitle requests create`)",
    ),
) -> None:
    """Configure bt-cli interactively or via flags.

    Examples:

        # Interactive setup
        bt configure

        # Configure specific product
        bt configure --product pws

        # Configure with flags
        bt configure --product pws --api-url https://example.com/api --client-id xxx

        # Use a named profile
        bt configure --product pws --profile production
    """
    # If subcommand was invoked, don't run main configure
    if ctx.invoked_subcommand is not None:
        return

    # Check if any non-interactive flags were provided
    has_flags = any([api_url, client_id, client_secret, api_key, user_api_key])

    if has_flags and product:
        # Non-interactive mode with flags
        _configure_with_flags(
            product, profile, api_url, client_id, client_secret, api_key, user_api_key
        )
    else:
        # Interactive mode
        _configure_interactive(product, profile)


def _configure_interactive(product: Optional[str] = None, profile: Optional[str] = None) -> None:
    """Run interactive configuration wizard."""
    console.print()
    console.print(Panel.fit(
        "[bold blue]BeyondTrust CLI Configuration[/bold blue]\n\n"
        "This wizard will help you configure your BeyondTrust product connections.\n"
        f"Configuration will be saved to: [cyan]{CONFIG_FILE}[/cyan]",
        border_style="blue"
    ))
    console.print()

    # Load existing config
    config = load_config_file()

    # Select profile
    if not profile:
        existing_profiles = config.list_profiles()
        if existing_profiles:
            console.print(f"[dim]Existing profiles: {', '.join(existing_profiles)}[/dim]")
        profile = Prompt.ask(
            "Profile name",
            default=config.default_profile or "default"
        )

    # Select product
    if not product:
        console.print("\n[bold]Available products:[/bold]")
        for key, info in PRODUCTS.items():
            console.print(f"  [cyan]{key}[/cyan] - {info['name']}")

        product = Prompt.ask(
            "\nSelect product",
            choices=list(PRODUCTS.keys()),
        )

    if product not in PRODUCTS:
        print_error(f"Unknown product: {product}")
        raise typer.Exit(1)

    product_info = PRODUCTS[product]
    console.print(f"\n[bold]Configuring {product_info['name']}[/bold]\n")

    # Get existing config for this product/profile
    existing = config.get_product_config(product, profile)

    # Collect new configuration
    new_config: dict = {}
    use_keyring = False

    # Check keyring availability
    if _keyring_available():
        use_keyring = Confirm.ask(
            "Store secrets in system keyring (more secure)?",
            default=True
        )

    for field_name, field_info in product_info["fields"].items():
        # Skip conditional fields that don't apply
        if "if" in field_info:
            condition = field_info["if"]
            if "auth_method == oauth" in condition and new_config.get("auth_method") != "oauth":
                continue
            if "auth_method == apikey" in condition and new_config.get("auth_method") != "apikey":
                continue

        prompt_text = field_info["prompt"]
        default = existing.get(field_name) or field_info.get("default", "")

        # Show example if available
        if "example" in field_info:
            console.print(f"  [dim]Example: {field_info['example']}[/dim]")

        # Handle boolean fields
        if isinstance(default, bool):
            value = Confirm.ask(prompt_text, default=default)
        # Handle choice fields
        elif "choices" in field_info:
            value = Prompt.ask(
                prompt_text,
                choices=field_info["choices"],
                default=str(default) if default else None
            )
        # Handle secret fields - show the value (not hidden) for easier pasting verification
        elif field_info.get("secret"):
            if existing.get(field_name):
                existing_val = str(existing[field_name])
                if existing_val.startswith("keyring://"):
                    console.print(f"  [dim](current: stored in keyring)[/dim]")
                else:
                    console.print(f"  [dim](current: {existing_val[:20]}...)[/dim]" if len(existing_val) > 20 else f"  [dim](current: {existing_val})[/dim]")
            # Don't use password=True so users can see what they paste
            value = Prompt.ask(
                prompt_text,
                default="" if not default else None
            )
            if not value and default:
                value = default
        # Handle regular fields
        else:
            value = Prompt.ask(
                prompt_text,
                default=str(default) if default else ""
            )

        # Skip empty optional fields (but keep False booleans - they're valid)
        if value is None or (value == "" and not field_info.get("required")):
            continue

        # Store secrets in keyring if enabled
        if field_info.get("secret") and use_keyring and value:
            keyring_key = f"{product}-{profile}-{field_name}"
            if set_secret_in_keyring("bt-cli", keyring_key, value):
                new_config[field_name] = f"keyring://bt-cli/{keyring_key}"
                console.print(f"  [dim]Stored in keyring[/dim]")
            else:
                new_config[field_name] = value
        else:
            new_config[field_name] = value

    # Save configuration
    config.set_product_config(product, new_config, profile)

    # Set as default profile if it's the first one
    if not config.default_profile or profile == "default":
        config.default_profile = profile

    save_config_file(config)

    console.print()
    print_success(f"Configuration saved for {product_info['name']} (profile: {profile})")
    console.print(f"[dim]Config file: {CONFIG_FILE}[/dim]")

    # Offer to test connection
    if Confirm.ask("\nTest connection now?", default=True):
        _test_connection(product, profile)


def _configure_with_flags(
    product: str,
    profile: Optional[str],
    api_url: Optional[str],
    client_id: Optional[str],
    client_secret: Optional[str],
    api_key: Optional[str],
    user_api_key: Optional[str] = None,
) -> None:
    """Configure using command-line flags (non-interactive)."""
    if product not in PRODUCTS:
        print_error(f"Unknown product: {product}. Available: {', '.join(PRODUCTS.keys())}")
        raise typer.Exit(1)

    profile = profile or "default"
    config = load_config_file()
    existing = config.get_product_config(product, profile)

    # Merge with existing config
    new_config = dict(existing)

    if api_url:
        new_config["api_url"] = api_url
    if client_id:
        new_config["client_id"] = client_id
    if client_secret:
        new_config["client_secret"] = client_secret
    if api_key:
        new_config["api_key"] = api_key
    if user_api_key is not None:
        if product != "entitle":
            print_error("--user-api-key is only valid for product=entitle")
            raise typer.Exit(2)
        new_config["user_api_key"] = user_api_key

    # Infer auth method
    if api_key:
        new_config["auth_method"] = "apikey"
    elif client_id and client_secret:
        new_config["auth_method"] = "oauth"

    config.set_product_config(product, new_config, profile)
    if not config.default_profile:
        config.default_profile = profile

    save_config_file(config)
    print_success(f"Configuration saved for {product} (profile: {profile})")


def _test_connection(product: str, profile: str) -> None:
    """Test connection for a product."""
    console.print(f"\n[dim]Testing {product} connection...[/dim]")

    try:
        # Import and test based on product
        if product == "pws":
            from ..pws.client import get_client
            with get_client() as client:
                client.authenticate()
                # Test with Platforms endpoint (always accessible)
                platforms = client.get("/Platforms", params={"limit": 1})
                count = len(platforms) if isinstance(platforms, list) else 1
            print_success(f"Password Safe connection successful! ({count} platform(s) found)")

        elif product == "entitle":
            from ..entitle.client import get_client
            with get_client() as client:
                client.get("/integrations", params={"perPage": 1})
            print_success("Entitle connection successful!")

        elif product == "pra":
            from ..pra.client import get_client
            with get_client() as client:
                client.get("/jumpoint")
            print_success("PRA connection successful!")

        elif product == "epmw":
            from ..epmw.client import get_client
            with get_client() as client:
                # EPMW auto-authenticates on first request via OAuth
                client.get("/Computers", params={"pageSize": 1})
            print_success("EPM Windows connection successful!")

    except Exception as e:
        print_error(f"Connection failed: {e}")


@app.command("show")
def show_config(
    profile: Optional[str] = typer.Option(None, "--profile", help="Profile to show"),
    show_secrets: bool = typer.Option(False, "--show-secrets", help="Show secret values"),
) -> None:
    """Show configuration from config file.

    Note: This only shows profiles saved to ~/.bt-cli/config.yaml.
    If you're using environment variables or .env file, use:

        bt configure effective

    to see the actual configuration in use.
    """
    config = load_config_file()

    if not config.profiles:
        print_warning("No profiles in config file. Run 'bt configure' to set up.")
        console.print("\n[dim]Tip: If using .env or environment variables, run:[/dim]")
        console.print("[cyan]  bt configure effective[/cyan]")
        raise typer.Exit(0)

    profiles_to_show = [profile] if profile else config.list_profiles()

    for prof in profiles_to_show:
        if prof not in config.profiles:
            print_warning(f"Profile '{prof}' not found")
            continue

        is_default = prof == config.default_profile
        title = f"Profile: {prof}" + (" (default)" if is_default else "")

        table = Table(title=title, show_header=True)
        table.add_column("Product", style="cyan")
        table.add_column("Setting", style="green")
        table.add_column("Value")

        for product, settings in config.profiles[prof].items():
            first = True
            for key, value in settings.items():
                # Mask secrets
                if not show_secrets and any(s in key for s in ["secret", "key", "password"]):
                    if isinstance(value, str) and value.startswith("keyring://"):
                        display_value = "[dim]<stored in keyring>[/dim]"
                    else:
                        display_value = "****" + str(value)[-4:] if value else ""
                else:
                    display_value = str(value)

                table.add_row(
                    product if first else "",
                    key,
                    display_value
                )
                first = False

        console.print(table)
        console.print()


@app.command("profiles")
def list_profiles() -> None:
    """List all configured profiles."""
    config = load_config_file()

    if not config.profiles:
        print_warning("No profiles configured. Run 'bt configure' to set up.")
        raise typer.Exit(0)

    table = Table(title="Configured Profiles", show_header=True)
    table.add_column("Profile", style="cyan")
    table.add_column("Products", style="green")
    table.add_column("Default", style="yellow")

    for profile_name in config.list_profiles():
        products = list(config.profiles[profile_name].keys())
        is_default = "Yes" if profile_name == config.default_profile else ""
        table.add_row(profile_name, ", ".join(products), is_default)

    console.print(table)


@app.command("set-default")
def set_default_profile(
    profile: str = typer.Argument(..., help="Profile name to set as default"),
) -> None:
    """Set the default profile."""
    config = load_config_file()

    if profile not in config.profiles:
        print_error(f"Profile '{profile}' not found")
        raise typer.Exit(1)

    config.default_profile = profile
    save_config_file(config)
    print_success(f"Default profile set to '{profile}'")


@app.command("delete")
def delete_profile(
    profile: str = typer.Argument(..., help="Profile name to delete"),
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation"),
) -> None:
    """Delete a profile."""
    config = load_config_file()

    if profile not in config.profiles:
        print_error(f"Profile '{profile}' not found")
        raise typer.Exit(1)

    if not force:
        if not Confirm.ask(f"Delete profile '{profile}'?", default=False):
            print_info("Cancelled")
            raise typer.Exit(0)

    config.delete_profile(profile)
    save_config_file(config)
    print_success(f"Profile '{profile}' deleted")


@app.command("path")
def show_path() -> None:
    """Show configuration file path."""
    console.print(f"Config directory: [cyan]{ensure_config_dir()}[/cyan]")
    console.print(f"Config file: [cyan]{CONFIG_FILE}[/cyan]")

    if CONFIG_FILE.exists():
        console.print("[green]Config file exists[/green]")
    else:
        console.print("[yellow]Config file does not exist yet[/yellow]")


@app.command("import-env")
def import_from_env(
    profile: str = typer.Option("default", "--profile", "-p", help="Profile name to save as"),
    force: bool = typer.Option(False, "--force", "-f", help="Overwrite existing profile"),
) -> None:
    """Import configuration from environment variables into a profile.

    This saves the current BT_* environment variables (including .env file)
    into a named profile in the config file. Useful for:

    - Converting .env setup to profile-based config
    - Creating profiles from existing environment
    - Backing up current config to file

    Example:
        bt configure import-env --profile production
    """
    import os
    from dotenv import load_dotenv, find_dotenv
    from rich.prompt import Confirm

    # Load .env if present
    env_file = find_dotenv()
    if env_file:
        load_dotenv(env_file)
        console.print(f"[dim]Loaded .env from: {env_file}[/dim]\n")

    config = load_config_file()

    # Check if profile exists
    if profile in config.profiles and not force:
        if not Confirm.ask(f"Profile '{profile}' exists. Overwrite?", default=False):
            print_info("Cancelled")
            raise typer.Exit(0)

    # Product environment variable mappings
    env_mappings = {
        "pws": {
            "api_url": "BT_PWS_API_URL",
            "api_key": "BT_PWS_API_KEY",
            "client_id": "BT_PWS_CLIENT_ID",
            "client_secret": "BT_PWS_CLIENT_SECRET",
            "run_as": "BT_PWS_RUN_AS",
            "verify_ssl": "BT_PWS_VERIFY_SSL",
            "timeout": "BT_PWS_TIMEOUT",
        },
        "pra": {
            "api_url": "BT_PRA_API_URL",
            "client_id": "BT_PRA_CLIENT_ID",
            "client_secret": "BT_PRA_CLIENT_SECRET",
            "verify_ssl": "BT_PRA_VERIFY_SSL",
            "timeout": "BT_PRA_TIMEOUT",
        },
        "entitle": {
            "api_url": "BT_ENTITLE_API_URL",
            "api_key": "BT_ENTITLE_API_KEY",
            "user_api_key": "BT_ENTITLE_USER_API_KEY",
            "verify_ssl": "BT_ENTITLE_VERIFY_SSL",
            "timeout": "BT_ENTITLE_TIMEOUT",
        },
        "epmw": {
            "api_url": "BT_EPM_API_URL",
            "client_id": "BT_EPM_CLIENT_ID",
            "client_secret": "BT_EPM_CLIENT_SECRET",
            "verify_ssl": "BT_EPM_VERIFY_SSL",
            "timeout": "BT_EPM_TIMEOUT",
        },
    }

    imported = []
    for product, env_vars in env_mappings.items():
        product_config = {}
        for setting, env_var in env_vars.items():
            value = os.getenv(env_var)
            if value:
                # Convert types
                if setting == "verify_ssl":
                    product_config[setting] = value.lower() not in ("false", "0", "no")
                elif setting == "timeout":
                    try:
                        product_config[setting] = float(value)
                    except ValueError:
                        product_config[setting] = 30.0
                else:
                    product_config[setting] = value

        if product_config.get("api_url"):
            # Infer auth_method for PWS
            if product == "pws":
                if product_config.get("api_key"):
                    product_config["auth_method"] = "apikey"
                elif product_config.get("client_id"):
                    product_config["auth_method"] = "oauth"

            config.set_product_config(product, product_config, profile)
            imported.append(product)

    if imported:
        if not config.default_profile or profile == "default":
            config.default_profile = profile
        save_config_file(config)
        print_success(f"Imported {', '.join(imported)} into profile '{profile}'")
        console.print(f"[dim]Config saved to: {CONFIG_FILE}[/dim]")
    else:
        print_warning("No configuration found in environment variables")


@app.command("effective")
def show_effective_config(
    show_secrets: bool = typer.Option(False, "--show-secrets", help="Show secret values"),
) -> None:
    """Show effective configuration from all sources.

    Shows what configuration is actually in use, combining:
    - Environment variables (BT_PWS_*, BT_PRA_*, etc.)
    - .env file (if present)
    - Config file profiles (~/.bt-cli/config.yaml)

    This is useful for debugging why the CLI connects successfully
    but 'bt configure show' appears empty.
    """
    import os
    from dotenv import load_dotenv, find_dotenv

    # Load .env if present
    env_file = find_dotenv()
    if env_file:
        load_dotenv(env_file)
        console.print(f"[dim]Loaded .env from: {env_file}[/dim]\n")

    def mask_secret(key: str, value: str) -> str:
        if not value:
            return "[dim]not set[/dim]"
        if not show_secrets and any(s in key.lower() for s in ["secret", "key", "password"]):
            return "****" + value[-4:] if len(value) > 4 else "****"
        return value

    # Product environment variable mappings
    products = {
        "Password Safe": {
            "api_url": "BT_PWS_API_URL",
            "api_key": "BT_PWS_API_KEY",
            "client_id": "BT_PWS_CLIENT_ID",
            "client_secret": "BT_PWS_CLIENT_SECRET",
            "run_as": "BT_PWS_RUN_AS",
            "verify_ssl": "BT_PWS_VERIFY_SSL",
            "timeout": "BT_PWS_TIMEOUT",
        },
        "PRA": {
            "api_url": "BT_PRA_API_URL",
            "client_id": "BT_PRA_CLIENT_ID",
            "client_secret": "BT_PRA_CLIENT_SECRET",
            "verify_ssl": "BT_PRA_VERIFY_SSL",
            "timeout": "BT_PRA_TIMEOUT",
        },
        "Entitle": {
            "api_url": "BT_ENTITLE_API_URL",
            "api_key": "BT_ENTITLE_API_KEY",
            "user_api_key": "BT_ENTITLE_USER_API_KEY",
            "verify_ssl": "BT_ENTITLE_VERIFY_SSL",
            "timeout": "BT_ENTITLE_TIMEOUT",
        },
        "EPM Windows": {
            "api_url": "BT_EPM_API_URL",
            "client_id": "BT_EPM_CLIENT_ID",
            "client_secret": "BT_EPM_CLIENT_SECRET",
            "verify_ssl": "BT_EPM_VERIFY_SSL",
            "timeout": "BT_EPM_TIMEOUT",
        },
    }

    # Check active profile
    active_profile = os.getenv("BT_PROFILE", "default")
    console.print(f"[bold]Active Profile:[/bold] {active_profile}\n")

    # Show effective config for each product
    for product_name, env_vars in products.items():
        table = Table(title=product_name, show_header=True, title_style="bold cyan")
        table.add_column("Setting", style="green")
        table.add_column("Env Var", style="dim")
        table.add_column("Value")
        table.add_column("Source", style="dim")

        has_config = False
        for setting, env_var in env_vars.items():
            value = os.getenv(env_var, "")
            if value:
                has_config = True
                source = ".env" if env_file else "environment"
                table.add_row(setting, env_var, mask_secret(setting, value), source)

        if has_config:
            console.print(table)
            console.print()
        else:
            console.print(f"[dim]{product_name}: not configured[/dim]\n")

    # Also show config file info
    config = load_config_file()
    if config.profiles:
        console.print("[bold]Config File Profiles:[/bold]")
        for profile_name in config.list_profiles():
            products_list = list(config.profiles[profile_name].keys())
            is_default = " (default)" if profile_name == config.default_profile else ""
            console.print(f"  {profile_name}{is_default}: {', '.join(products_list)}")
        console.print(f"\n[dim]Note: Environment variables override config file settings[/dim]")
