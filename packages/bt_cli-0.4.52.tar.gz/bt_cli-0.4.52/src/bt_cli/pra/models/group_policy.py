"""Group Policy models."""

from typing import Optional

from .common import PRABaseModel


class GroupPolicy(PRABaseModel):
    id: Optional[int] = None
    name: str
    perm_access_allowed: Optional[bool] = None
    access_perm_status: Optional[str] = None


class GroupPolicyJumpoint(PRABaseModel):
    jumpoint_id: int


class GroupPolicyMember(PRABaseModel):
    id: Optional[int] = None
    security_provider_id: int
    distinguished_name: Optional[str] = None
    group_name: Optional[str] = None
    user_id: Optional[int] = None


class GroupPolicyJumpGroup(PRABaseModel):
    jump_group_id: int
    jump_item_role_id: Optional[int] = 0
    jump_policy_id: Optional[int] = 0


class GroupPolicyVaultAccount(PRABaseModel):
    account_id: int
    role: Optional[str] = "inject"


class GroupPolicyVaultAccountGroup(PRABaseModel):
    account_group_id: int
    role: Optional[str] = "inject"


class GroupPolicyTeam(PRABaseModel):
    team_id: int
    role: Optional[str] = "member"
