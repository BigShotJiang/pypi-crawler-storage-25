"""Group Policy commands.

Mirrors the spec: CRUD on /group-policy + 6 sub-resource families
(jumpoint, member, jump-group, vault-account, vault-account-group, team).
"""

import json as _json
from pathlib import Path
from typing import Optional

import httpx
import typer

from bt_cli.core.output import (
    OutputFormat,
    print_table,
    print_json,
    print_error,
    print_api_error,
)

app = typer.Typer(no_args_is_help=True, help="Group Policies")


# --- top-level Group Policy CRUD --------------------------------------------


@app.command("list")
def list_group_policies(
    name: Optional[str] = typer.Option(None, "--name", help="Exact name filter"),
    output: OutputFormat = typer.Option(OutputFormat.TABLE, "--output", "-o"),
):
    """List Group Policies."""
    from bt_cli.pra.client import get_client

    try:
        policies = get_client().list_group_policies(name=name)
        if output == OutputFormat.JSON:
            print_json(policies)
        else:
            print_table(
                policies,
                [("ID", "id"), ("Name", "name"), ("Access?", "perm_access_allowed")],
                title="Group Policies",
            )
    except (httpx.HTTPStatusError, httpx.RequestError, Exception) as e:
        print_api_error(e, "list group policies")
        raise typer.Exit(1)


@app.command("get")
def get_group_policy(
    policy_id: int = typer.Argument(..., help="Group Policy ID"),
    output: OutputFormat = typer.Option(OutputFormat.JSON, "--output", "-o"),
):
    """Get a Group Policy."""
    from bt_cli.pra.client import get_client

    try:
        policy = get_client().get_group_policy(policy_id)
        if output == OutputFormat.JSON:
            print_json(policy)
        else:
            from rich.console import Console
            from rich.panel import Panel
            Console().print(Panel(
                f"[bold]{policy.get('name', '')}[/bold]\n"
                f"[dim]access_perm_status:[/dim] {policy.get('access_perm_status', '-')}",
                title="Group Policy",
                subtitle=f"ID: {policy.get('id', '')}",
            ))
    except (httpx.HTTPStatusError, httpx.RequestError, Exception) as e:
        print_api_error(e, "get group policy")
        raise typer.Exit(1)


@app.command("create")
def create_group_policy(
    name: str = typer.Option(..., "--name", help="Group policy name"),
    json_body: Optional[Path] = typer.Option(
        None, "--json", help="JSON file with full body (other flags merge in)"
    ),
):
    """Create a Group Policy."""
    from bt_cli.pra.client import get_client

    data = _json.loads(json_body.read_text()) if json_body else {}
    data["name"] = name

    try:
        created = get_client().create_group_policy(data)
        print_json(created)
    except (httpx.HTTPStatusError, httpx.RequestError, Exception) as e:
        print_api_error(e, "create group policy")
        raise typer.Exit(1)


@app.command("update")
def update_group_policy(
    policy_id: int = typer.Argument(..., help="Group Policy ID"),
    name: Optional[str] = typer.Option(None, "--name"),
    json_body: Optional[Path] = typer.Option(
        None, "--json", help="JSON file with full PATCH body"
    ),
):
    """Update a Group Policy."""
    from bt_cli.pra.client import get_client

    data = _json.loads(json_body.read_text()) if json_body else {}
    if name is not None:
        data["name"] = name

    if not data:
        print_error("No update fields provided")
        raise typer.Exit(2)

    try:
        updated = get_client().update_group_policy(policy_id, data)
        print_json(updated)
    except (httpx.HTTPStatusError, httpx.RequestError, Exception) as e:
        print_api_error(e, "update group policy")
        raise typer.Exit(1)


@app.command("delete")
def delete_group_policy(
    policy_id: int = typer.Argument(..., help="Group Policy ID"),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation"),
):
    """Delete a Group Policy."""
    from bt_cli.pra.client import get_client
    from rich.console import Console

    if not yes:
        if not typer.confirm(f"Delete Group Policy {policy_id}?"):
            raise typer.Exit(0)
    try:
        get_client().delete_group_policy(policy_id)
        Console().print(f"[green]Deleted Group Policy {policy_id}[/green]")
    except (httpx.HTTPStatusError, httpx.RequestError, Exception) as e:
        print_api_error(e, "delete group policy")
        raise typer.Exit(1)


@app.command("copy")
def copy_group_policy(
    policy_id: int = typer.Argument(..., help="Source Group Policy ID"),
    name: str = typer.Option(..., "--name", help="Name for the new policy"),
):
    """Duplicate an existing Group Policy."""
    from bt_cli.pra.client import get_client
    try:
        copied = get_client().copy_group_policy(policy_id, name)
        print_json(copied)
    except (httpx.HTTPStatusError, httpx.RequestError, Exception) as e:
        print_api_error(e, "copy group policy")
        raise typer.Exit(1)


@app.command("provision")
def provision_group_policy(
    policy_id: int = typer.Argument(..., help="Group Policy ID"),
):
    """Provision the members of a Group Policy."""
    from bt_cli.pra.client import get_client
    from rich.console import Console
    try:
        get_client().provision_group_policy(policy_id)
        Console().print(f"[green]Provisioned Group Policy {policy_id}[/green]")
    except (httpx.HTTPStatusError, httpx.RequestError, Exception) as e:
        print_api_error(e, "provision group policy")
        raise typer.Exit(1)


# --- helper for sub-resource sub-typers -------------------------------------


def _exit_on_api_error(action: str, exc: Exception):
    print_api_error(exc, action)
    raise typer.Exit(1)


# --- /jumpoint ---------------------------------------------------------------

jumpoints_app = typer.Typer(no_args_is_help=True, help="Jumpoints in this Group Policy")
app.add_typer(jumpoints_app, name="jumpoints")


@jumpoints_app.command("list")
def gp_jumpoints_list(
    policy_id: int = typer.Argument(...),
    output: OutputFormat = typer.Option(OutputFormat.TABLE, "--output", "-o"),
):
    from bt_cli.pra.client import get_client
    try:
        items = get_client().list_group_policy_jumpoints(policy_id)
        if output == OutputFormat.JSON:
            print_json(items)
        else:
            print_table(items, [("Jumpoint ID", "jumpoint_id")], title=f"GP {policy_id} Jumpoints")
    except Exception as e:
        _exit_on_api_error("list group-policy jumpoints", e)


@jumpoints_app.command("add")
def gp_jumpoints_add(
    policy_id: int = typer.Argument(...),
    jumpoint_id: int = typer.Option(..., "--jumpoint-id"),
):
    from bt_cli.pra.client import get_client
    from rich.console import Console
    try:
        get_client().add_group_policy_jumpoint(policy_id, jumpoint_id)
        Console().print(f"[green]Added jumpoint {jumpoint_id} to GP {policy_id}[/green]")
    except Exception as e:
        _exit_on_api_error("add group-policy jumpoint", e)


@jumpoints_app.command("remove")
def gp_jumpoints_remove(
    policy_id: int = typer.Argument(...),
    jumpoint_id: int = typer.Option(..., "--jumpoint-id"),
):
    from bt_cli.pra.client import get_client
    from rich.console import Console
    try:
        get_client().remove_group_policy_jumpoint(policy_id, jumpoint_id)
        Console().print(f"[green]Removed jumpoint {jumpoint_id} from GP {policy_id}[/green]")
    except Exception as e:
        _exit_on_api_error("remove group-policy jumpoint", e)


# --- /member -----------------------------------------------------------------

members_app = typer.Typer(no_args_is_help=True, help="Members of this Group Policy")
app.add_typer(members_app, name="members")


@members_app.command("list")
def gp_members_list(
    policy_id: int = typer.Argument(...),
    output: OutputFormat = typer.Option(OutputFormat.TABLE, "--output", "-o"),
):
    from bt_cli.pra.client import get_client
    try:
        items = get_client().list_group_policy_members(policy_id)
        if output == OutputFormat.JSON:
            print_json(items)
        else:
            print_table(
                items,
                [
                    ("Member ID", "id"),
                    ("Sec Provider", "security_provider_id"),
                    ("User ID", "user_id"),
                    ("DN", "distinguished_name"),
                    ("Group Name", "group_name"),
                ],
                title=f"GP {policy_id} Members",
            )
    except Exception as e:
        _exit_on_api_error("list group-policy members", e)


@members_app.command("add")
def gp_members_add(
    policy_id: int = typer.Argument(...),
    security_provider_id: int = typer.Option(..., "--security-provider-id"),
    user_id: Optional[int] = typer.Option(None, "--user-id", help="Local/LDAP/RADIUS/Kerberos/SAML/SCIM user"),
    distinguished_name: Optional[str] = typer.Option(None, "--dn", help="LDAP user/group, SCIM user"),
    group_name: Optional[str] = typer.Option(None, "--group-name", help="SAML/SCIM group"),
):
    """Add a member. Body shape varies by security provider — see PRA spec."""
    from bt_cli.pra.client import get_client
    from rich.console import Console
    body = {"security_provider_id": security_provider_id}
    if user_id is not None:
        body["user_id"] = user_id
    if distinguished_name:
        body["distinguished_name"] = distinguished_name
    if group_name:
        body["group_name"] = group_name
    try:
        get_client().add_group_policy_member(policy_id, body)
        Console().print(f"[green]Added member to GP {policy_id}[/green]")
    except Exception as e:
        _exit_on_api_error("add group-policy member", e)


@members_app.command("remove")
def gp_members_remove(
    policy_id: int = typer.Argument(...),
    member_id: int = typer.Option(..., "--member-id"),
):
    from bt_cli.pra.client import get_client
    from rich.console import Console
    try:
        get_client().remove_group_policy_member(policy_id, member_id)
        Console().print(f"[green]Removed member {member_id} from GP {policy_id}[/green]")
    except Exception as e:
        _exit_on_api_error("remove group-policy member", e)


# --- /jump-group -------------------------------------------------------------

jg_app = typer.Typer(no_args_is_help=True, help="Jump Groups attached to this Group Policy")
app.add_typer(jg_app, name="jump-groups")


@jg_app.command("list")
def gp_jg_list(
    policy_id: int = typer.Argument(...),
    output: OutputFormat = typer.Option(OutputFormat.TABLE, "--output", "-o"),
):
    from bt_cli.pra.client import get_client
    try:
        items = get_client().list_group_policy_jump_groups(policy_id)
        if output == OutputFormat.JSON:
            print_json(items)
        else:
            print_table(
                items,
                [
                    ("Jump Group ID", "jump_group_id"),
                    ("Jump Item Role", "jump_item_role_id"),
                    ("Jump Policy", "jump_policy_id"),
                ],
                title=f"GP {policy_id} Jump Groups",
            )
    except Exception as e:
        _exit_on_api_error("list group-policy jump-groups", e)


@jg_app.command("add")
def gp_jg_add(
    policy_id: int = typer.Argument(...),
    jump_group_id: int = typer.Option(..., "--jump-group-id"),
    jump_item_role_id: int = typer.Option(0, "--jump-item-role-id", help="0 = User's Default"),
    jump_policy_id: int = typer.Option(0, "--jump-policy-id", help="0 = Set on Jump Items"),
):
    from bt_cli.pra.client import get_client
    from rich.console import Console
    try:
        get_client().add_group_policy_jump_group(
            policy_id, jump_group_id, jump_item_role_id, jump_policy_id
        )
        Console().print(f"[green]Added jump-group {jump_group_id} to GP {policy_id}[/green]")
    except Exception as e:
        _exit_on_api_error("add group-policy jump-group", e)


@jg_app.command("remove")
def gp_jg_remove(
    policy_id: int = typer.Argument(...),
    jump_group_id: int = typer.Option(..., "--jump-group-id"),
):
    from bt_cli.pra.client import get_client
    from rich.console import Console
    try:
        get_client().remove_group_policy_jump_group(policy_id, jump_group_id)
        Console().print(f"[green]Removed jump-group {jump_group_id} from GP {policy_id}[/green]")
    except Exception as e:
        _exit_on_api_error("remove group-policy jump-group", e)


# --- /vault-account ----------------------------------------------------------

va_app = typer.Typer(no_args_is_help=True, help="Vault Accounts attached to this Group Policy")
app.add_typer(va_app, name="vault-accounts")


@va_app.command("list")
def gp_va_list(
    policy_id: int = typer.Argument(...),
    output: OutputFormat = typer.Option(OutputFormat.TABLE, "--output", "-o"),
):
    from bt_cli.pra.client import get_client
    try:
        items = get_client().list_group_policy_vault_accounts(policy_id)
        if output == OutputFormat.JSON:
            print_json(items)
        else:
            print_table(
                items,
                [("Account ID", "account_id"), ("Role", "role")],
                title=f"GP {policy_id} Vault Accounts",
            )
    except Exception as e:
        _exit_on_api_error("list group-policy vault-accounts", e)


@va_app.command("add")
def gp_va_add(
    policy_id: int = typer.Argument(...),
    account_id: int = typer.Option(..., "--account-id"),
    role: str = typer.Option("inject", "--role", help="inject | inject_and_checkout"),
):
    from bt_cli.pra.client import get_client
    try:
        result = get_client().add_group_policy_vault_account(policy_id, account_id, role)
        print_json(result)
    except Exception as e:
        _exit_on_api_error("add group-policy vault-account", e)


@va_app.command("remove")
def gp_va_remove(
    policy_id: int = typer.Argument(...),
    account_id: int = typer.Option(..., "--account-id"),
):
    from bt_cli.pra.client import get_client
    from rich.console import Console
    try:
        get_client().remove_group_policy_vault_account(policy_id, account_id)
        Console().print(f"[green]Removed vault-account {account_id} from GP {policy_id}[/green]")
    except Exception as e:
        _exit_on_api_error("remove group-policy vault-account", e)


# --- /vault-account-group ----------------------------------------------------

vag_app = typer.Typer(
    no_args_is_help=True, help="Vault Account Groups attached to this Group Policy"
)
app.add_typer(vag_app, name="vault-account-groups")


@vag_app.command("list")
def gp_vag_list(
    policy_id: int = typer.Argument(...),
    output: OutputFormat = typer.Option(OutputFormat.TABLE, "--output", "-o"),
):
    from bt_cli.pra.client import get_client
    try:
        items = get_client().list_group_policy_vault_account_groups(policy_id)
        if output == OutputFormat.JSON:
            print_json(items)
        else:
            print_table(
                items,
                [("Account Group ID", "account_group_id"), ("Role", "role")],
                title=f"GP {policy_id} Vault Account Groups",
            )
    except Exception as e:
        _exit_on_api_error("list group-policy vault-account-groups", e)


@vag_app.command("add")
def gp_vag_add(
    policy_id: int = typer.Argument(...),
    account_group_id: int = typer.Option(..., "--account-group-id"),
    role: str = typer.Option("inject", "--role", help="inject | inject_and_checkout"),
):
    from bt_cli.pra.client import get_client
    try:
        result = get_client().add_group_policy_vault_account_group(
            policy_id, account_group_id, role
        )
        print_json(result)
    except Exception as e:
        _exit_on_api_error("add group-policy vault-account-group", e)


@vag_app.command("remove")
def gp_vag_remove(
    policy_id: int = typer.Argument(...),
    account_group_id: int = typer.Option(..., "--account-group-id"),
):
    from bt_cli.pra.client import get_client
    from rich.console import Console
    try:
        get_client().remove_group_policy_vault_account_group(policy_id, account_group_id)
        Console().print(
            f"[green]Removed vault-account-group {account_group_id} from GP {policy_id}[/green]"
        )
    except Exception as e:
        _exit_on_api_error("remove group-policy vault-account-group", e)


# --- /team -------------------------------------------------------------------

teams_app = typer.Typer(no_args_is_help=True, help="Teams attached to this Group Policy")
app.add_typer(teams_app, name="teams")


@teams_app.command("list")
def gp_teams_list(
    policy_id: int = typer.Argument(...),
    output: OutputFormat = typer.Option(OutputFormat.TABLE, "--output", "-o"),
):
    from bt_cli.pra.client import get_client
    try:
        items = get_client().list_group_policy_teams(policy_id)
        if output == OutputFormat.JSON:
            print_json(items)
        else:
            print_table(
                items,
                [("Team ID", "team_id"), ("Role", "role")],
                title=f"GP {policy_id} Teams",
            )
    except Exception as e:
        _exit_on_api_error("list group-policy teams", e)


@teams_app.command("add")
def gp_teams_add(
    policy_id: int = typer.Argument(...),
    team_id: int = typer.Option(..., "--team-id"),
    role: str = typer.Option("member", "--role", help="member | lead | manager"),
):
    from bt_cli.pra.client import get_client
    try:
        result = get_client().add_group_policy_team(policy_id, team_id, role)
        print_json(result)
    except Exception as e:
        _exit_on_api_error("add group-policy team", e)


@teams_app.command("remove")
def gp_teams_remove(
    policy_id: int = typer.Argument(...),
    team_id: int = typer.Option(..., "--team-id"),
):
    from bt_cli.pra.client import get_client
    from rich.console import Console
    try:
        get_client().remove_group_policy_team(policy_id, team_id)
        Console().print(f"[green]Removed team {team_id} from GP {policy_id}[/green]")
    except Exception as e:
        _exit_on_api_error("remove group-policy team", e)
