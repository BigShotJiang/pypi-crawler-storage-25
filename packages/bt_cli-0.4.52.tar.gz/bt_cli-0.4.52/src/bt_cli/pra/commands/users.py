"""User commands."""

import json as _json
from pathlib import Path
from typing import List, Optional

import httpx
import typer

from bt_cli.core.output import (
    OutputFormat,
    print_table,
    print_json,
    print_error,
    print_api_error,
)

app = typer.Typer(no_args_is_help=True)


@app.command("list")
def list_users(
    username: Optional[str] = typer.Option(None, "--username", help="Filter by exact username"),
    email: Optional[str] = typer.Option(None, "--email", help="Filter by exact email"),
    security_provider_id: Optional[int] = typer.Option(
        None, "--security-provider-id", help="Filter by security provider id"
    ),
    output: OutputFormat = typer.Option(OutputFormat.TABLE, "--output", "-o"),
):
    """List all users."""
    from bt_cli.pra.client import get_client

    try:
        client = get_client()
        users = client.list_users(
            username=username,
            email_address=email,
            security_provider_id=security_provider_id,
        )

        if output == OutputFormat.JSON:
            print_json(users)
        else:
            columns = [
                ("ID", "id"),
                ("Username", "username"),
                ("Display Name", "public_display_name"),
                ("Email", "email_address"),
                ("Enabled", "enabled"),
                ("Last Auth", "last_authentication"),
            ]
            print_table(users, columns, title="Users")
    except (httpx.HTTPStatusError, httpx.RequestError, Exception) as e:
        print_api_error(e, "list users")
        raise typer.Exit(1)


@app.command("get")
def get_user(
    user_id: int = typer.Argument(..., help="User ID"),
    output: OutputFormat = typer.Option(OutputFormat.TABLE, "--output", "-o"),
):
    """Get user details."""
    from bt_cli.pra.client import get_client
    from rich.console import Console
    from rich.panel import Panel

    console = Console()

    try:
        client = get_client()
        user = client.get_user(user_id)

        if output == OutputFormat.JSON:
            print_json(user)
        else:
            username = user.get("username", "")
            display_name = user.get("public_display_name", "") or "-"
            email = user.get("email_address", "") or "-"
            enabled = "Yes" if user.get("enabled") else "No"
            sp_id = user.get("security_provider_id", "-")

            console.print(Panel(
                f"[bold]{username}[/bold]\n\n"
                f"[dim]Display Name:[/dim] {display_name}\n"
                f"[dim]Email:[/dim] {email}\n"
                f"[dim]Enabled:[/dim] {enabled}\n"
                f"[dim]Security Provider ID:[/dim] {sp_id}",
                title="PRA User Details",
                subtitle=f"ID: {user.get('id', '')}",
            ))
    except (httpx.HTTPStatusError, httpx.RequestError, Exception) as e:
        print_api_error(e, "get user")
        raise typer.Exit(1)


@app.command("update")
def update_user(
    user_id: int = typer.Argument(..., help="User ID"),
    public_display_name: Optional[str] = typer.Option(None, "--display-name"),
    email: Optional[str] = typer.Option(None, "--email"),
    enabled: Optional[bool] = typer.Option(None, "--enabled/--disabled"),
    password: Optional[str] = typer.Option(None, "--password", help="(local users only)"),
    password_reset_next_login: Optional[bool] = typer.Option(
        None, "--reset-password-next-login/--no-reset-password-next-login"
    ),
    two_factor_required: Optional[bool] = typer.Option(
        None, "--require-2fa/--no-require-2fa"
    ),
    unlock: bool = typer.Option(
        False, "--unlock", help="Reset failed_logins to 0 (local users)"
    ),
    json_body: Optional[Path] = typer.Option(
        None,
        "--json",
        help="Path to a JSON file with the full PATCH body (overrides other flags)",
    ),
    output: OutputFormat = typer.Option(OutputFormat.JSON, "--output", "-o"),
):
    """Update a user (PATCH /user/{id})."""
    from bt_cli.pra.client import get_client

    if json_body:
        data = _json.loads(json_body.read_text())
    else:
        data = {}
        if public_display_name is not None:
            data["public_display_name"] = public_display_name
        if email is not None:
            data["email_address"] = email
        if enabled is not None:
            data["enabled"] = enabled
        if password is not None:
            data["password"] = password
        if password_reset_next_login is not None:
            data["password_reset_next_login"] = password_reset_next_login
        if two_factor_required is not None:
            data["two_factor_required"] = two_factor_required
        if unlock:
            data["failed_logins"] = 0

    if not data:
        print_error("No update fields provided")
        raise typer.Exit(2)

    try:
        client = get_client()
        updated = client.update_user(user_id, data)
        if output == OutputFormat.JSON:
            print_json(updated)
        else:
            from rich.console import Console
            Console().print(f"[green]Updated user {user_id}[/green]")
    except (httpx.HTTPStatusError, httpx.RequestError, Exception) as e:
        print_api_error(e, "update user")
        raise typer.Exit(1)


@app.command("delete")
def delete_user(
    user_id: int = typer.Argument(..., help="User ID"),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation"),
):
    """Delete a non-admin user."""
    from bt_cli.pra.client import get_client
    from rich.console import Console

    console = Console()
    if not yes:
        confirm = typer.confirm(
            f"Delete user {user_id}? This cannot be undone."
        )
        if not confirm:
            raise typer.Exit(0)

    try:
        client = get_client()
        client.delete_user(user_id)
        console.print(f"[green]Deleted user {user_id}[/green]")
    except (httpx.HTTPStatusError, httpx.RequestError, Exception) as e:
        print_api_error(e, "delete user")
        raise typer.Exit(1)


@app.command("group-policies")
def list_user_group_policies(
    user_id: int = typer.Argument(..., help="User ID"),
    output: OutputFormat = typer.Option(OutputFormat.TABLE, "--output", "-o"),
):
    """List the group policies a user is a member of."""
    from bt_cli.pra.client import get_client

    try:
        client = get_client()
        policies = client.list_user_group_policies(user_id)
        if output == OutputFormat.JSON:
            print_json(policies)
        else:
            columns = [("ID", "id"), ("Name", "name")]
            print_table(policies, columns, title=f"Group Policies for user {user_id}")
    except (httpx.HTTPStatusError, httpx.RequestError, Exception) as e:
        print_api_error(e, "list user group-policies")
        raise typer.Exit(1)


@app.command("provision")
def provision_users(
    user_ids: Optional[List[int]] = typer.Option(
        None, "--user", "-u", help="User ID (repeat for multiple). Empty = ALL users."
    ),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation when no -u given"),
):
    """Recompute permissions/memberships for users (POST /user/provision)."""
    from bt_cli.pra.client import get_client
    from rich.console import Console

    console = Console()
    ids = list(user_ids) if user_ids else []
    if not ids and not yes:
        confirm = typer.confirm(
            "No --user given. Provision ALL users? This can be expensive."
        )
        if not confirm:
            raise typer.Exit(0)

    try:
        client = get_client()
        client.provision_users(ids)
        if ids:
            console.print(f"[green]Provisioned users:[/green] {', '.join(map(str, ids))}")
        else:
            console.print("[green]Provisioned all users[/green]")
    except (httpx.HTTPStatusError, httpx.RequestError, Exception) as e:
        print_api_error(e, "provision users")
        raise typer.Exit(1)
