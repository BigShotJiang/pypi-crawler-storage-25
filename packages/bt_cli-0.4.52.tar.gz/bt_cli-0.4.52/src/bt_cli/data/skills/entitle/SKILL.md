---
name: entitle
description: Entitle commands for JIT access, bundles, workflows, and permissions. Use when working with access requests, approval workflows, or managing user entitlements.
---

# Entitle Commands (`bt entitle`)

## IMPORTANT: Destructive Operations

**ALWAYS confirm with the user before:**
- `bt entitle resources delete` - Deletes resource from integration
- `bt entitle bundles delete` - Deletes access bundle
- `bt entitle permissions revoke` - Revokes active permission

List affected resources first, then ask for explicit confirmation.

## Performance Tips

**ALWAYS use server-side filters** - never download all data and filter locally.

```bash
# ✓ FAST - Server-side filtering
bt entitle permissions list --resource <resource_id>
bt entitle permissions list --user <user_id>
bt entitle permissions list --integration <integration_id>

# ✗ SLOW - Downloads ALL 23k+ permissions, filters locally
bt entitle permissions list | jq 'select(...)'
bt entitle permissions list -o json | grep "something"
```

**Available filters for permissions list:**

| Flag | Purpose |
|------|---------|
| `--resource -r` | Filter by resource ID |
| `--user -u` | Filter by user ID |
| `--integration -i` | Filter by integration ID |

**Dataset size warning:** Entitle can have 20,000+ permissions. Unfiltered queries will be very slow.

**Workflow - Check standing access for a resource:**
```bash
# 1. Find resource ID
bt entitle resources list --integration <integration_id> | grep -i "admin"

# 2. Query permissions with resource filter (fast)
bt entitle permissions list --resource <resource_id> -o json | jq -r '.[] | "\(.actor.name) | \(.actor.email)"'
```

## Integrations & Resources

```bash
# List integrations (connected apps)
bt entitle integrations list
bt entitle integrations get <integration_id>

# List resources in an integration
bt entitle resources list --integration <integration_id>
bt entitle resources get <resource_id>

# Virtual integration resources (use integration ID from `bt entitle integrations list`)
bt entitle resources create-virtual \
    --name "Customer-05 (Bing7)" \
    --integration <virtual_integration_id> \
    --source-role-id <role_id> \
    --role-name "Start Session"
bt entitle resources delete <resource_id>
```

## Bundles

Access bundles group multiple roles across integrations.

```bash
bt entitle bundles list
bt entitle bundles get <bundle_id>
bt entitle bundles create \
    --name "Dev AWS Access" \
    --description "Development AWS console access" \
    --workflow <workflow_id> \
    --role <role_id> \
    --duration 3600
bt entitle bundles delete <bundle_id>
```

## Workflows

```bash
bt entitle workflows list
bt entitle workflows get <workflow_id>
```

**Available Workflows:**
| Name | Type | Use Case |
|------|------|----------|
| Auto Approve | Automatic | Requests <= 12 hours |
| Low sensitivity | Simple | Single approver |
| Medium Sensitivity | Standard | Standard approval |
| Production access | Multi-step | Duration-based tiers |

## Users & Permissions

```bash
# Users
bt entitle users list
bt entitle users get <user_id>

# Active permissions
bt entitle permissions list
bt entitle permissions list --user <user_id>
bt entitle permissions revoke <permission_id>

# Accounts
bt entitle accounts list --integration <integration_id>
```

## Access Requests

Submit a JIT access request for a bundle or a single role. Hybrid UX — pass flags
for non-interactive use, or omit them to get a filter-then-pick menu at every step.

```bash
# Fully interactive (asks: bundle/role -> target -> duration -> justification)
bt entitle requests create

# Non-interactive — bundle target
bt entitle requests create --bundle <bundle_id> --duration 3600 -j "On-call investigation"

# Non-interactive — role target
bt entitle requests create --role <role_id> -d 1800 -j "Reviewing prod logs"

# Look up a submitted request by id
bt entitle requests get <request_id>
```

**Target shape (POST /accessRequests):**
```json
{
  "duration": 3600,
  "justification": "...",
  "target": {
    "type": "bundle",         // or "role"
    "bundle": {"id": "<uuid>"} // or "role": {"id": "<uuid>"}
  }
}
```

**Duration menu** is curated 30-minute-aligned blocks (30m, 1h, 1h30m, 2h, 3h, 4h,
8h, 12h, 1d, 2d, 3d, 7d). When the target is a bundle and that bundle has
`allowedDurations` set, the menu restricts to those values instead — bundles
enforce server-side.

**Picker UX:** at any selection prompt, type a number to pick, any text to filter
the list by substring, `n` / `p` to page, or blank to cancel.

**Gotchas:**
- The Entitle public API does **not** expose a list endpoint for access requests.
  `bt entitle requests list` does not exist. Save the id printed by `requests
  create` (or use the Entitle UI) to follow up on a request.
- A bogus or policy-blocked role returns the same 404 with message `Role with id
  ... does not exist or unattainable.` — "unattainable" means the requester's
  policy disallows it, not that the role is missing.
- The token used must have a user identity (personal API token). Pure read-only
  org keys return `request.unauthenticated` on POST.

## Roles & Policies

```bash
bt entitle roles list
bt entitle roles list --resource <resource_id>
bt entitle roles get <role_id>

bt entitle policies list
bt entitle policies get <policy_id>
```

## Common Workflows

### Add PRA Jump Group to Entitle

**Important:** PRA integration sync is **asynchronous** (runs hourly). After creating a new PRA jump group, either:
- Wait up to 1 hour for auto-sync
- Or manually trigger sync in Entitle UI: Integrations → PRA → Sync Now

```bash
# 1. Find your PRA integration ID
bt entitle integrations list | grep -i pra

# 2. Trigger PRA sync in Entitle UI (or wait for hourly sync)

# 3. Find the new PRA resource
bt entitle resources list --integration <pra_integration_id>

# 4. Get "Start Sessions Only" role ID
bt entitle roles list --resource <pra_resource_id>

# 5. Add to virtual integration (find ID with `bt entitle integrations list`)
bt entitle resources create-virtual \
    --name "Customer-05" \
    --integration <virtual_integration_id> \
    --source-role-id <role_id> \
    --role-name "Start Session"
```

### Check User Access

```bash
bt entitle permissions list --user "user@example.com" -o json
```

## Discover IDs

```bash
# Find integration IDs
bt entitle integrations list

# Find workflow IDs
bt entitle workflows list

# Find resource IDs within an integration
bt entitle resources list --integration <integration_id>

# Find role IDs for a resource
bt entitle roles list --resource <resource_id>
```

## Integrations Available

- Cloud10 (Virtual Application)
- NexusDyn - Azure
- Customer Access (Virtual)
- Privileged Remote Access (PRA)
- AWS - SandBox Account
- Nexusdyn - Postgres ERP Database
- NexusDyn - EntraID

## Supported Applications (75+)

**Cloud:** AWS, Azure, GCP, Oracle OCI
**Identity:** Okta, Entra ID, OneLogin, JumpCloud
**DevOps:** GitHub, GitLab, Jenkins, Terraform Cloud
**Databases:** Postgres, MySQL, MSSQL, MongoDB, Snowflake
**Kubernetes:** EKS, AKS, GKE, Rancher
**BeyondTrust:** Password Safe, PRA, Remote Support

## API Notes

- Base path: `/public/v1`
- Pagination: `page`/`perPage`
- Response: `{"result": [...], "pagination": {...}}`
- All IDs are UUIDs (strings)
- Bearer token auth
