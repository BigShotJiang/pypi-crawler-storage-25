---
name: epml
description: EPM Linux commands for endpoint privilege management — RBP roles/cmdgrps/usergrps, policy import/export, test suites, transactions, audit. Use when working with PMUL/RBP, PAT auth against api.beyondtrust.io, or `/site/<id>/epm/linux/` URLs.
---

# EPM Linux Commands (`bt epml`)

## Configuration

EPM Linux speaks to the cloud gateway with a **Personal Access Token** (PAT).
The gateway URL takes a transform that the OpenAPI spec does NOT document — see "URL transform" below.

```bash
export BT_EPML_API_URL=https://api.beyondtrust.io       # default; usually omit
export BT_EPML_SITE_ID=<your-site-uuid>                 # required
export BT_EPML_PAT=PAT_xxxxxxxxxx                       # required (mint at app.beyondtrust.io)
export BT_EPML_DEFAULT_HOST=100                         # default PMUL host id (optional)

bt epml auth test     # confirms /settings is reachable
bt epml auth status   # show current config (no secrets)
```

## URL transform — important

The OpenAPI spec lists paths starting with `/api/...` and has an empty `servers`
block. The deployed gateway requires a site/product prefix that ISN'T in the
spec. The CLI handles this in one place (`_build_url`), but you'll see this if
you debug raw curl:

```
spec path:  /api/<rest>
real URL:   https://api.beyondtrust.io/site/<site-id>/epm/linux/<rest>
```

A direct `curl https://api.beyondtrust.io/api/v1/users -H "Authorization: Bearer <PAT>"` returns
`401 {"error":"Access denied for this site"}` — that's NOT a PAT/audience problem,
it's a missing path prefix.

## Two-authorizer reality (PAT-OK vs IAM-blocked)

The spec declares `nomine-authorizer` (PAT) globally with zero per-op overrides,
but the gateway has some routes wired to AWS IAM (SigV4) instead. PAT cannot
reach those — they return either `403 {"message":"Invalid key=value pair... SHA-256... Base64..."}`
or `403 {"Message":"User is not authorized... no identity-based policy allows
the execute-api:Invoke action"}`. Same root, different envelope.

Known IAM-only paths (PAT-blocked):
- `PUT /settings` (read is fine)
- `POST/PUT/DELETE /v4/siems` (read is fine)
- `/v1/hosts`, `/v6/users`, `/v6/auth`, `/v1/auth`, `/v2/appfeatures`
- `/v7/directoryservices/*`, `/epml/license` (root), `/epml/licenseinfo` (root)
  - Exception: `/epml/license/clients` and `/epml/licenseinfo/clients/retire` ARE Bearer-OK (used by `bt epml clients`)
- All `/v6/pbul/rbp/*` (use the legacy `/pbul/{hostid}/rbp/*` instead)
- **Inside testsuite**: `PUT /testsuite/{id}` and `POST /testsuite/test` (per-method split — list/get/create/delete/run *suites* are fine; PUT-test and DELETE-test are fine, but POST-add-test is IAM)

## Auth + connection

```bash
bt epml auth test           # GET /settings, reports 401 vs 403 distinctly
bt epml auth status         # show env config
bt whoami                   # includes EPM Linux row
```

## Settings, users, hosts, license

```bash
bt epml settings list                        # /api/settings
bt epml settings get session_timeout
bt epml users list                           # /api/v1/users (table)
bt epml users list --v2                      # /api/v2/users
bt epml users get <user_id>
bt epml hosts list                           # synthesized from /pbul/features
bt epml hosts features                       # full feature flags per PMUL host
bt epml license get                          # /api/epml/enhancedlicense
bt epml clients list                         # installed-agent inventory (active by default)
bt epml clients list --include-retired       # show retired seats too
bt epml clients list --component RBPClnts    # filter by license bucket
bt epml clients list --fqdn ip-10-0-0        # substring match on FQDN
bt epml clients retire --uuid UUID,UUID      # dry-run prints what would be retired
bt epml clients retire --fqdn host1,host2 --confirm   # actually free the seats
```

Note: `bt epml hosts list` is the **PMUL policy-server** list (synthesized from
`/api/pbul/features` because `/api/v1/hosts` is IAM-blocked). `bt epml clients
list` is the **installed-agent inventory** — every endpoint reporting in for
licensing. Two different things.

## Audit, SIEMs, External APIs, Iologs, Client packages

```bash
bt epml audit sessions list --take 50
bt epml audit sessions categories
bt epml siems list                                 # read only — write is IAM
bt epml external-apis list
bt epml external-apis get <id>
bt epml iolog list                                 # default host
bt epml iolog list -H 200 --start 0 --len 200
bt epml client-pkg list                            # signed S3 URLs (~30min TTL)
bt epml client-pkg status                          # build queue
bt epml client-pkg link epml-client.x86_64.rpm
```

## RBP — Role-Based Policy

All under `/api/pbul/{hostid}/rbp/...` (default host = `BT_EPML_DEFAULT_HOST`).
Use `-H/--host` to override.

```bash
# Command groups
bt epml rbp cmdgrps list
bt epml rbp cmdgrps create --name "Admin Tools" --description "..."
bt epml rbp cmdgrps delete 12,13
bt epml rbp cmdgrps commands list <cmdgrp_id>
bt epml rbp cmdgrps commands add <cmdgrp_id> --commands "vi,less,cat"
bt epml rbp cmdgrps commands clear <cmdgrp_id>            # NUKE all (no per-item delete)
bt epml rbp cmdgrps commands replace <cmdgrp_id> --commands "vi,more"

# Host groups (`type` defaults to I=Internal)
bt epml rbp hostgrps list
bt epml rbp hostgrps create --name "Admin Hosts" --type I
bt epml rbp hostgrps hosts add <hostgrp_id> --hosts "web-*,db-*"
bt epml rbp hostgrps hosts clear <hostgrp_id>
bt epml rbp hostgrps hosts replace <hostgrp_id> --hosts "web-01,web-02"

# User groups (`type` defaults to I=Internal)
bt epml rbp usergrps list
bt epml rbp usergrps create --name "Helpdesk" --type I
bt epml rbp usergrps create-multiple groups.json          # bulk create from JSON array
bt epml rbp usergrps users add <usergrp_id> --users "alice,bob"
bt epml rbp usergrps users clear <usergrp_id>
bt epml rbp usergrps users replace <usergrp_id> --users "alice"

# Time/date groups + tmdates
bt epml rbp tmdategrps list
bt epml rbp tmdategrps create --name "Working Hours"
bt epml rbp tmdategrps tmdates list <tmdategrp_id>
bt epml rbp tmdategrps tmdates add <tmdategrp_id> --from 09:00 --to 17:00 -d "weekday"
bt epml rbp tmdategrps tmdates add <tmdategrp_id> --file tmdates.json
bt epml rbp tmdategrps tmdates clear <tmdategrp_id>
bt epml rbp tmdategrps tmdates replace <tmdategrp_id> --file tmdates.json

# Roles + assignments
bt epml rbp roles list
bt epml rbp roles create --name "Helpdesk Role" --action A \
  --description "..." --comment "..." --tag "AdminAccess" \
  --risk 6 --rpt 1 \
  --iolog '/iologs/%date%/%uniqueid%.iolog' \
  --banner-text "Helpdesk Role"             # builds standard ###-framed banner
# or --message "raw multi-line message"
# or --banner                               # banner with %rbprole% template
bt epml rbp roles update <id> --tag NewTag --risk 9 --rpt 1     # in-place edit
bt epml rbp roles duplicate <role_id>
bt epml rbp roles cmdgrps   add <role_id> --ids 1,2          # cmdgrps & tmdategrps: just IDs
bt epml rbp roles tmdategrps add <role_id> --ids 1
bt epml rbp roles hostgrps  add <role_id> --ids 1 --kind B   # B = both Submit and Run-as
bt epml rbp roles usergrps  add <role_id> --ids 4 --kind S   # S = Submit (who requests)
bt epml rbp roles usergrps  add <role_id> --ids 3 --kind R   # R = Run-as (whose identity)
bt epml rbp roles cmdgrps   remove <role_id> <cmdgrp_id>
bt epml rbp roles hostgrps  list   <role_id>

# Entitlement report ('who can do what')
bt epml rbp entitlement run
bt epml rbp entitlement run --raw

# Policy export/import/versions
bt epml rbp policy export --file policy.json
bt epml rbp policy import policy.json
bt epml rbp policy versions
bt epml rbp policy diff
bt epml rbp policy snapshot
bt epml rbp policy revert
bt epml rbp policy delete-all --yes-i-mean-it      # destructive, gated
```

## Worked example: build a role from scratch

End-to-end recipe for a "users in group X can run shells on all hosts at any time" role with I/O logging and a session banner. Mirrors the pattern of the tenant's existing roles (Postgres, Docker Admin, etc.).

```bash
# 1. Command group containing the commands the role allows
bt epml rbp cmdgrps create --name "RootShells" --description "Root shells with arguments"
# captures: id 35
bt epml rbp cmdgrps commands add 35 --commands "bash *,sh *,ksh *,zsh *,csh *,bash,sh,ksh,zsh,csh"

# 2. Role itself, all metadata in one shot
bt epml rbp roles create \
  --name "RootShells" \
  --description "Root shell access — I/O logged" \
  --comment    "Root shell access — I/O logged"  \
  --tag        "RootAccess" \
  --risk        9 \
  --rpt         1 \
  --action      A \
  --iolog      '/iologs/%date%/%uniqueid%.iolog' \
  --banner-text "Root Shell Access"
# captures: id 126

# 3. Wire up the four group assignments
bt epml rbp roles cmdgrps   add 126 --ids 35              # cmdgrp: just IDs
bt epml rbp roles hostgrps  add 126 --ids 1 --kind B      # All Hosts, both Submit and Run-as
bt epml rbp roles usergrps  add 126 --ids 4 --kind S      # Administrators as Submit (who requests)
bt epml rbp roles usergrps  add 126 --ids 3 --kind R      # 'root' as Run-as (whose identity)
bt epml rbp roles tmdategrps add 126 --ids 1              # Any Time

# 4. Verify
bt epml rbp roles list -o json | python3 -c 'import json,sys;[print(json.dumps(r,indent=2)) for r in json.load(sys.stdin) if r["id"]==126]'
bt epml rbp roles cmdgrps   list 126
bt epml rbp roles hostgrps  list 126
bt epml rbp roles usergrps  list 126
bt epml rbp roles tmdategrps list 126
bt epml rbp entitlement run -o json | grep RootShells     # rpt=1 makes it surface
```

The resulting banner displayed to users (server-substituted at session time):
```
############################################################
 Policy:           Root Shell Access
 Status:           %event%
 Session Recorded: Yes
############################################################
```

## Test suites + transactions (the killer workflow)

```bash
# Suites (CRUD is mostly Bearer-OK; update-suite and add-test are IAM-only — see caveats)
bt epml rbp tests suites list
bt epml rbp tests suites create -n "production-policy" -d "..."
bt epml rbp tests suites get <suite_id>
bt epml rbp tests suites delete <suite_id>

# Tests within a suite (add is IAM-blocked → use the GUI to add tests; CLI to run)
bt epml rbp tests tests update <test_id> -f test.json
bt epml rbp tests tests delete <test_id>

# Run a suite — exits 0 on pass, 1 on any failure
bt epml rbp tests run --suite <suite_id>

# Transactions
bt epml rbp tx status
bt epml rbp tx begin
bt epml rbp tx commit
bt epml rbp tx rollback
bt epml rbp tx abort

# Quick: tests-then-deploy — open a tx, edit, then commit-or-rollback based on tests
bt epml rbp tx begin
# ... make changes via rbp cmdgrps/roles/etc ...
bt epml quick tests-then-deploy --suite <suite_id>      # commits if pass; rollbacks if fail
```

## Destructive operations (always confirm)

- `bt epml rbp policy delete-all --yes-i-mean-it` — wipes the entire RBP DB
- `bt epml rbp <resource> delete <ids>` — bulk delete by ID list
- `bt epml rbp tx commit` — applies in-flight changes
- `bt epml client-pkg ...` POST endpoints — triggers a real installer build

## API quirks worth knowing (caught while building, not in the spec)

- **Create-role `action`**: required despite spec saying optional. Must be exactly `"A"` (Allow) or `"R"` (Reject). CLI defaults to `A`.
- **Create-hostgrp / create-usergrp `type`**: required. Must be `"I"` (Internal — static list) or `"E"` (External — directory-resolved). CLI defaults to `I`.
- **Collection-level deletes** (cmdgrps/hostgrps/usergrps/tmdategrps/roles): the spec shows `id` as a query parameter, NOT a JSON body. Repeated `?id=A&id=B` is accepted at the HTTP layer but only the first value is honored — the CLI loops single-id requests under the hood.
- **Child-collection deletes** (commands inside cmdgrp, hosts inside hostgrp, users inside usergrp, tmdates inside tmdategrp): there is **no per-item delete**. `DELETE /<parent>/{id}/<children>` clears the whole list. To remove one entry, use `replace` (CLI does GET + DELETE-all + POST under the hood).
- **Add-children body shape**: each child item must be wrapped: commands → `[{"cmd": x}]`, hosts → `[{"host": x}]`, users → `[{"user": x}]`, tmdates → `{"tmdates": [...]}` (note the wrapper for tmdates; the spec doesn't document any of these wrappers).
- **`POST /usergrps/multiple`** (bulk create): body is `{"usergroups": [...]}` — undocumented wrapper key.
- **POST on child collections is additive**, not replacing. Calling `commands add` twice with the same command will get you a duplicate.
- **Children share the parent's `id`** in GET responses — the listed `id` field is the cmdgrp/hostgrp/usergrp ID, not unique per child. The actual identifier is the `cmd`/`host`/`user` text.
- **Role assignments take a single object per request, not an array**. The CLI loops under the hood; the wire body is e.g. `{"cmds": 35}`, `{"hosts": 1, "type": "S"}`, `{"users": 4, "type": "R"}`, `{"tmdates": 1}`.
- **Hostgrp / usergrp assignments require a `type` field** (`S` = Submit / who requests, `R` = Run-as / whose identity the command runs under). Without `type` the request 400s with "RBP role type not in: [S,R]". CLI: `--kind S|R|B` on `roles hostgrps add` and `roles usergrps add`. `B` (default) creates both an S row and an R row for the same id — appropriate when the same group plays both roles. For "Admin requests, runs as root", do `--ids 4 --kind S` and `--ids 3 --kind R` separately.
- **Roles need `rpt: 1`** to appear in `bt epml rbp entitlement run`. The role still functions for policy evaluation either way, but only `rpt=1` roles are surfaced in the report. Set with `--rpt 1` on `roles create` / `roles update` (added in 0.4.38).
- **Role update is upsert-on-id, not partial**: hitting POST `/roles` with `{id, ...}` *overwrites* the matching record — fields you omit get cleared. The CLI's `roles update` does read-modify-write (fetch the role, merge changes, post the whole record) so this feels partial. Role-child relations (rolecmds/roleusers/etc.) are filtered out of the merge so assignments survive an update. **If you hit the API directly via curl**, you must send the full record yourself.

## Known gaps (TODO)

- **`bt epml rbp roles get <id>`** — there is no GET-single-role in the v1 API. The detailed view (role with all child relations resolved) only exists at `/api/v6/pbul/{hostid}/rbp/roledetail/{id}`, which is on the IAM-only authorizer. Not callable with a PAT today. Workaround: use `bt epml rbp roles list` for the role row, then `bt epml rbp roles {cmdgrps,hostgrps,usergrps,tmdategrps} list <id>` to fetch each child relation.

## Tenant-side gotchas (not a CLI bug)

- **`bt epml rbp tx begin` may return** `400 "RBP Transactions not enabled on host"`. This is a per-tenant feature flag on the PMUL host — transactions need to be enabled at the appliance / settings level before they'll work. The CLI surfaces the server's exact message; nothing client-side to fix. (Verified 2026-05-01 against the lab tenant — host id 100 does not have transactions enabled.) The `quick tests-then-deploy` workflow depends on transactions, so it'll also fail until the host is configured for it.

## tmdate shape (`dotw` map)

The OpenAPI spec describes `tmdate` as a `string` field with `x-go-name: "JsonDefinition"`. The actual runtime shape is a structured object:

```json
{"dotw": {
  "mon": [{"from":"09:00","to":"17:00"}],
  "tue": [{"from":"09:00","to":"17:00"}],
  ...
  "sat": [],
  "sun": []
}}
```

A day with an empty list is inactive. A day can have multiple windows (e.g. split shift). The CLI's `--from/--to/--days` short flags build the map for you; for anything more complex use `--file` with the full JSON.

## Path-version policy (CLI internal)

Where the spec offers both legacy `/api/pbul/{hostid}/rbp/<x>` and newer
`/api/v6/pbul/rbp/<x>`, the CLI uses the **legacy** version because v6 routes
are mostly IAM-only. If the API team flips v6 to PAT later, the swap is a
single-PR change in `client/base.py`.

## Output formats

All `list` and `get` commands accept `-o/--output table|json`. Table is the
default for list; JSON is the default for single-resource gets.

## Troubleshooting

- **401 "Access denied for this site"** — the URL didn't include `/site/<id>/epm/linux/`. Should never happen via the CLI; if you see it, file a bug.
- **403 IAM error** — the operation is on an IAM-only route. See the IAM-blocked list above.
- **400 with detailed validation messages** — auth passed; the body shape is wrong. Cross-reference `/home/admin/epml-cloud-spec.json` schemas.
- **Build server returns "building": true** — `bt epml client-pkg status` keeps `true` while a build is queued; idempotent to re-check.
