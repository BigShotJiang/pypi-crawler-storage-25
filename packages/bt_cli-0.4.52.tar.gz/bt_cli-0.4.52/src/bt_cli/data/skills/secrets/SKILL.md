---
name: secrets
description: BeyondTrust Secrets API commands — folders, static secrets, dynamic AWS credentials, leases, integrations. Use when minting STS credentials, managing secret folders/values, or browsing/revoking dynamic-credential leases.
---

# Secrets API Commands (`bt secrets`)

Direct CLI for the BeyondTrust Secrets API. PAT-bearer auth, same gateway as
EPM-L (`api.beyondtrust.io`). **Not** a wrapper around Entitle.

## IMPORTANT: Destructive Operations

**ALWAYS confirm with the user before:**
- `bt secrets folders delete --recursive` — wipes the folder and all contents
- `bt secrets folders delete --permanent` — bypasses soft-delete
- `bt secrets static delete` / `dynamic delete` — removes the secret/config
- `bt secrets integrations delete` — disables downstream dynamic generation

List affected resources first, then ask for explicit confirmation. Every
delete supports `--force` to skip the prompt — only use it when the user has
already confirmed.

## IMPORTANT: Generate Sparingly

`bt secrets dynamic generate <path>` mints **real** AWS STS credentials and
shows up in the audit trail. Don't loop it during development. For exploring,
use `dynamic list` / `dynamic get` / `leases list` — those don't mint.

## Configuration

Set these before running commands. PAT comes from `app.beyondtrust.io`.

```bash
export BT_SECRETS_API_URL=https://api.beyondtrust.io    # default
export BT_SECRETS_SITE_ID=<site-uuid>                   # required
export BT_SECRETS_PAT=PAT_xxx                           # required
export BT_SECRETS_API_VERSION=2026-04-28                # default; doc page is stale
```

```bash
bt secrets auth test    # verifies PAT + site + version-header reach the API
bt secrets auth status  # env-var view (no network)
```

## Path Semantics

Every item lives at a "path" like `lab/aws/cloudwatch-readonly`. The CLI
auto-splits the trailing segment as the `name` and the rest as the parent
`folder`, so users (and you) pass single paths everywhere. The folder may be
empty for top-level items.

```bash
bt secrets dynamic get lab/aws/cloudwatch-readonly  # folder=lab/aws, name=cloudwatch-readonly
bt secrets folders get lab/aws                      # folder=lab, name=aws
```

## Folders

`list` is **recursive by default** (mirrors how users browse the UI tree).
Pass `--shallow` / `-S` for direct children only.

```bash
bt secrets folders list                  # all folders, anywhere in the site
bt secrets folders list -p lab           # everything under lab/ recursively
bt secrets folders list -p lab --shallow # only direct children of lab/
bt secrets folders get lab/aws           # metadata
bt secrets folders create lab/aws/staging
bt secrets folders delete lab/aws/staging
bt secrets folders delete lab/aws/staging --recursive --force   # nuke contents
```

## Static Secrets

Versioned key/value secrets. The body is a JSON object — pass it inline via
`--data` or from disk via `--data-file`.

```bash
bt secrets static list                   # everything in the site (recursive default)
bt secrets static list -p lab            # everything under lab/
bt secrets static list -p lab --shallow  # direct children of lab/ only
bt secrets static get lab/db-pass        # default JSON output (values are structured)
bt secrets static get lab/db-pass --version 2   # specific historical version
bt secrets static create lab/db-pass -d '{"password":"hunter2","username":"admin"}'
bt secrets static update lab/db-pass -d '{"password":"newpass"}'   # bumps version, returns 204
bt secrets static delete lab/db-pass --force
```

## Dynamic Secrets

Configurations that mint short-lived credentials on demand (AWS STS today).

```bash
bt secrets dynamic list                   # all dynamic-secret configs in the site
bt secrets dynamic list -p lab            # everything under lab/
bt secrets dynamic list -p lab --shallow  # only items directly at lab/ (usually none — they nest)
bt secrets dynamic get lab/aws/ec2-readonly

# Mint fresh credentials — default prints shell `export AWS_*` lines.
bt secrets dynamic generate lab/aws/ec2-readonly

# Apply to the current session (a child process can't mutate its parent's env,
# so the CLI emits shell-native syntax that you eval into your shell):

# bash / zsh:
eval $(bt secrets dynamic generate lab/aws/ec2-readonly)

# PowerShell:
bt secrets dynamic generate lab/aws/ec2-readonly --format powershell | iex

# cmd.exe:
for /f "delims=" %i in ('bt secrets dynamic generate lab/aws/ec2-readonly --format cmd') do %i

aws sts get-caller-identity   # verify the creds are active

# Other formats:
bt secrets dynamic generate lab/aws/ec2-readonly --format json    # full payload w/ leaseId
bt secrets dynamic generate lab/aws/ec2-readonly --format env     # bare KEY=value
bt secrets dynamic generate lab/aws/ec2-readonly --format dotenv  # KEY="value" for .env files
```

Create dynamic-secret config (AWS example):

```bash
bt secrets dynamic create lab/aws/my-new-role -d '{
  "type":"aws",
  "integrationName":"AWS-Green-SE-Lab",
  "credentialType":"assumed_role",
  "roleArn":"arn:aws:iam::614212341445:role/beyondtrust/my-role",
  "ttl":900
}'
```

## Leases

Each `generate` call creates a lease. Leases auto-expire at TTL; the
`revoke` endpoint is **scope-gated** and most lab PATs return 403 — that's
not a generic error, it's the expected "you can't revoke" signal.

```bash
bt secrets leases list lab/aws/ec2-readonly
bt secrets leases get <lease-uuid>         # rich detail: externalEntityId (assumed-role ARN), etc.
bt secrets leases revoke <lease-uuid>      # exit 3 + warning if PAT lacks the revoke scope
```

## Integrations

External-system connections (currently AWS). Required before a dynamic-secret
config can reference an `integrationName`.

```bash
bt secrets integrations list
bt secrets integrations list -t aws
bt secrets integrations get my-aws
bt secrets integrations create my-aws -d '{
  "type":"aws",
  "roleArn":"arn:aws:iam::123456789012:role/MyRole",
  "externalId":"ext-id"
}'
bt secrets integrations update my-aws -d '{...}'           # PUT (full replace)
bt secrets integrations update my-aws --partial -d '{...}' # PATCH (partial)
bt secrets integrations delete my-aws --force
```

## API Quirks (Gotchas)

- **Dynamic path is `/dynamic`, NOT `/dynamic-secrets`** — the static doc
  page hasn't caught up to the live API. The client handles this; never
  hand-hack URLs.
- **API version**: header value is `bt-secrets-api-version: 2026-04-28`. The
  doc says `2026-01-02` and the server rejects it. The server also rejects
  every earlier dated header it has retired, so an old default surfaces as
  `API version not found: <date> is not a known API version` (helpfully the
  error names the current version when you send one that's *newer* than
  current — `is newer than current version <date>`). Periodic bumps are
  mandatory; treat the default as a moving target, not a constant.
- **POST `/dynamic/{name}/generate` returns 201**, not 200. The client
  accepts both via `raise_for_status` semantics.
- **`/leases/revoke` is scope-gated** — `bt secrets leases revoke` exits 3
  with a clean warning when the server returns 403. TTL still expires the
  lease eventually.
- **Rate limit**: 500/window. The client retries 429 once, honoring
  `x-ratelimit-reset` (clamped to ≤ 30s so a bogus header can't park the
  CLI).
- **PAT redaction**: errors and logs route through `bt_cli.core.errors` which
  scrubs `Authorization` headers and bearer tokens before display. Never
  add a `print(client.pat)` to debug — the PAT must never echo back.

## Output Formats

- All `list` commands default to rich tables; pass `-o json` for scripting.
- `get` commands default to JSON since values are structured.
- `dynamic generate` defaults to `export` shell lines — designed for
  `eval $(...)`.

## Common Workflows

### Mint creds, run an AWS command, let TTL revoke

```bash
eval $(bt secrets dynamic generate lab/aws/ec2-readonly)
aws ec2 describe-instances --max-results 5
# (don't bother revoking — TTL handles it)
```

### Audit who currently has access via a dynamic config

```bash
bt secrets leases list lab/aws/full-admin -o json \
  | jq -r '.[] | "\(.leaseId) \(.expiration) \(.externalEntityId)"'
```

### Browse the tree

```bash
bt secrets folders list -p lab
bt secrets static  list -p lab
bt secrets dynamic list -p lab
```

`list` is recursive by default; the API otherwise only returns items
directly at the requested path (this trips up newcomers — passing
`-p lab` returns 0 in shallow mode because the items live in `lab/aws`).

## API Notes

- Base URL: `https://api.beyondtrust.io/site/<site-id>/secrets`
- Auth: `Authorization: Bearer <PAT>`
- Version header: `bt-secrets-api-version: 2026-04-28`
- Rate limit: 500/window — respect `x-ratelimit-reset` on 429.
