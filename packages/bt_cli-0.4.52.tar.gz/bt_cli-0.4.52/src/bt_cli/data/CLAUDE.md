# BT-CLI

BeyondTrust Platform CLI for Password Safe, Entitle, PRA, EPM Windows, and EPM Linux. **Version: 0.4.41**

## Setup

```bash
# From project root
source .venv/bin/activate && source .env
bt whoami   # Test all connections
```

Each product reads its own `BT_<PRODUCT>_*` env vars. EPM Linux is the odd one out — it uses a Personal Access Token (PAT) against the BeyondTrust public API gateway:

```bash
export BT_EPML_API_URL=https://api.beyondtrust.io   # default
export BT_EPML_SITE_ID=<site-uuid>                  # required
export BT_EPML_PAT=PAT_xxx                          # required (mint at app.beyondtrust.io)
export BT_EPML_DEFAULT_HOST=100                     # default PMUL host id (optional)
```

## Skills Available

Use these slash commands for detailed product guidance:

| Skill | Purpose |
|-------|---------|
| `/bt` | Cross-product commands (PASM onboard/offboard/search) |
| `/pws` | Password Safe - credentials, systems, secrets |
| `/pra` | PRA - jump items, vault, SSH CA |
| `/entitle` | Entitle - JIT access, bundles, workflows |
| `/epmw` | EPM Windows - computers, policies, requests |
| `/epml` | EPM Linux - RBP roles/cmdgrps/usergrps, policy, test suites, transactions |

## Command Structure

| Product | Command | Key Operations |
|---------|---------|----------------|
| Cross-product | `bt quick` | `pasm-onboard`, `pasm-offboard`, `pasm-search` |
| Password Safe | `bt pws` | `systems`, `accounts`, `credentials`, `secrets`, `quick` |
| PRA | `bt pra` | `jump-items`, `vault`, `jump-groups`, `quick` |
| Entitle | `bt entitle` | `integrations`, `resources`, `bundles`, `permissions` |
| EPM Windows | `bt epmw` | `computers`, `groups`, `policies`, `requests`, `quick` |
| EPM Linux | `bt epml` | `rbp` (cmdgrps/hostgrps/usergrps/tmdategrps/roles/policy/tests/tx), `settings`, `users`, `audit`, `siems`, `quick` |

## Common Patterns

```bash
# Version info
bt version          # or bt --version or bt -V

# All list commands support JSON output
bt pws systems list -o json
bt pra jump-items shell list -o json

# Quick commands combine multiple API calls
bt pws quick checkout -s "system" -a "account"
bt pws quick onboard -n "host" -i "10.0.1.50" -w 3

# Raw output for scripting
PASSWORD=$(bt pws quick checkout -s server -a admin --raw)
```

## API Quirks (Gotchas)

| Product | Pagination | Response Format |
|---------|------------|-----------------|
| PWS | `limit`/`offset` | `{"TotalCount": N, "Data": [...]}` |
| Entitle | `page`/`perPage` | `{"result": [...], "pagination": {...}}` |
| PRA | `per_page`/`current_page` (1-indexed) | Array (pagination in headers) |
| EPMW | `pageNumber`/`pageSize` | `{"data": [...], "totalCount": N}` |
| EPML | varies — `take`/`skip` (audit, siems), `start`/`len` (iologs), plain arrays | mostly arrays; some `{total, data}` |

**Important:**
- EPMW computers: Use `archive` not `delete` (405 error)
- PRA K8s tunnels: Require Linux jumpoint
- PWS assets: Must create via workgroup endpoint
- ECM integration: PWS system name must match PRA jump item name
- Entitle permissions: Use server-side filters (`--resource`, `--user`, `--integration`) - dataset can be 20k+ records
- Entitle users: Use `--all` flag only when needed - default fetches first page only
- Windows builds: Rich must be pinned to `<14.0.0` (Rich 14 has PyInstaller unicode issues)
- **EPML URL transform**: spec paths start with `/api/...` but real URL is `https://api.beyondtrust.io/site/<site-id>/epm/linux/<spec-path-minus-/api/>`. Encapsulated in client `_build_url` — never bypass it.
- **EPML two authorizers**: spec claims `nomine-authorizer` (PAT) globally but the gateway has IAM-only routes (return 403 with AWS-flavored body). PAT cannot reach those. Documented per-op in `src/bt_cli/data/skills/epml/SKILL.md`. Where `/v6/pbul/rbp/...` exists alongside legacy `/pbul/{hostid}/rbp/...`, prefer legacy — v6 is mostly IAM-only.
- **EPML body-shape gotchas**: role create needs `action ∈ {A,R}`; hostgrp/usergrp create needs `type ∈ {I,E}` (Internal=static / External=directory-resolved); role assignments need `--kind S|R|B` for hostgrps/usergrps (S=Submit user, R=Run-as user); collection deletes use `?id=N` query params (CLI loops); child collections (commands/hosts/users/tmdates) have **no per-item delete** — `clear` nukes all, use `replace` to keep some.
- **EPML role update is upsert-on-id (overwrite, not partial)**: hitting `POST /roles` with `{id, ...}` clears any field you don't include. The CLI's `roles update` does read-modify-write so it feels partial; child relations are filtered out of the merge so assignments survive. Direct `curl` users must send the full record.
- **EPML role banner format**: `bt epml rbp roles create --banner-text "Title"` builds a `############`-framed message using `%rbprole%`/`%event%` server substitutions, mirroring the appliance's existing roles. See the worked role example in the EPM-L SKILL.md.

## Functional vs Managed Accounts

**Functional accounts** (`bt pws functional`) - Service accounts used BY Password Safe to connect to systems for auto-management (password rotation, discovery). One functional account can manage many systems.

**Managed accounts** (`bt pws accounts`) - User accounts ON systems that Password Safe manages (stores/rotates passwords for). These are what users check out.

```bash
# List functional accounts to find the right one for your platform
bt pws functional list

# List workgroups to find the right one
bt pws workgroups list

# Use functional account when onboarding a system
bt pws quick onboard -n "server" -i "10.0.1.50" -w <WORKGROUP_ID> -f <FUNC_ACCT_ID> -e "sudo"
```

## Project Structure

```
src/bt_cli/
├── cli.py              # Root dispatcher
├── core/               # Shared (config, auth, output)
├── pws/                # Password Safe
├── pra/                # PRA
├── entitle/            # Entitle
├── epmw/               # EPM Windows
└── epml/               # EPM Linux (PAT auth, /site/<id>/epm/linux/... URLs)
```

Each product follows: `client/` (API), `commands/` (CLI), `models/` (Pydantic)
