# Plan: Add Pathfinder (PF) Product to BeyondTrust CLI

## Context

The BeyondTrust CLI (`bt-cli`) currently supports 4 products: PWS, PRA, Entitle, and EPMW. The Pathfinder platform (internally "Nomine Authentication API") handles identity management — users, machine-to-machine auth, SAML providers, site/product access control, tokens, and auditing. Its OpenAPI spec lives at `/projects/reference/apidoc/pf/swagger.yaml` (67+ endpoints, 80+ schemas). This plan adds full PF support following the established patterns.

## Command Tree: `bt pf`

```
bt pf
  auth test|status
  users list|get|me|access|my-access|update|delete|bulk-delete|invite|cancel-invite
  machines list|get|create|delete|activate
  auditing list
  saml list|create|import|update|delete
  product-access list|org|org-defaults|grant|revoke|grant-org|revoke-org
  site-access list|org|grant|revoke|grant-org|revoke-org
  tokens list|create|delete
  mcp-tokens list|create|delete
  mfa enable|disable|disable-user|count
```

## Implementation Phases

### Phase 1: Foundation (core infra + auth test)

**1a. Add `MachineAuth` strategy** — `src/bt_cli/core/auth.py`
- New class: `MachineAuth(AuthStrategy)` with `machine_id`, `machine_secret`
- `authenticate()`: POST `/bt.identity/Machine/AccessToken` with JSON `{machineId, machineSecret}`
- Returns `{access_token, token_type, expires_in}` → sets Bearer token
- No sign_out needed (JWT is stateless)

**1b. Add `PFConfig`** — `src/bt_cli/core/config.py`
- Dataclass: `PFConfig(ProductConfig)` with `machine_id: str`, `machine_secret: str`
- `load_pf_config()` function — env vars: `BT_PF_API_URL`, `BT_PF_MACHINE_ID`, `BT_PF_MACHINE_SECRET`, `BT_PF_VERIFY_SSL`, `BT_PF_TIMEOUT`
- Add `"pf": load_pf_config` to `load_config()` dispatcher

**1c. Update config_file.py** — `src/bt_cli/core/config_file.py`
- Add `"pf"` entry to `PRODUCTS` dict (fields: api_url, machine_id, machine_secret, verify_ssl, timeout)

**1d. Create module structure:**
- `src/bt_cli/pf/__init__.py`
- `src/bt_cli/pf/client/__init__.py` — exports `PFClient, get_client`
- `src/bt_cli/pf/client/base.py` — client with context manager, token caching, HTTP methods
- `src/bt_cli/pf/commands/__init__.py` — registers all sub-typer apps
- `src/bt_cli/pf/commands/auth.py` — `test` (call list_users limit=1) and `status`
- `src/bt_cli/pf/models/__init__.py`
- `src/bt_cli/pf/models/common.py` — `CommandResponse` base model

**1e. Register in CLI** — `src/bt_cli/cli.py`
- Add `_get_pf_app()` lazy loader (after line 83)
- Add `app.add_typer()` registration (after line 124)
- Update help text in `main_callback` docstring to include Pathfinder

**Verify:** `bt pf auth test` connects and authenticates.

### Phase 2: Core Resources (users, machines, auditing)

**2a. Models:**
- `models/user.py` — `NomineUser` (id, email, firstName, lastName, active, mfaEnabled)
- `models/machine.py` — `Machine` (id, activationToken, active, tenantId, organizationId, timestamps)
- `models/audit.py` — `AuditRecord` (id, userId, organizationId, auditTimeUtc, description, metadata)

**2b. Client methods** in `pf/client/base.py`:
- Users: `list_users()`, `get_user_info()`, `get_user_access()`, `get_my_access()`, `update_user()`, `delete_user()`, `bulk_delete_users()`, `invite_user()`, `cancel_invitation()`
- Machines: `list_machines()`, `get_machine()`, `create_machine()`, `delete_machine()`, `activate_machine()`
- Auditing: `list_audit_records()`

**2c. Commands:**
- `commands/users.py` — 10 subcommands
- `commands/machines.py` — 5 subcommands
- `commands/auditing.py` — 1 subcommand (list with date/email/description filters)

**API quirks:**
- `GET /api/Users` returns plain array (no pagination wrapper)
- `GET /api/Machine` returns only UUIDs in `machines[]`, need `GET /api/Machine/{id}` for details
- Machine create returns `activationToken` (30min TTL) → `activate` exchanges code for `machineSecret`

### Phase 3: Access Management (product-access, site-access, saml)

**3a. Models:**
- `models/access.py` — `ProductAccessRule`, `SiteAccessRule`
- `models/saml_provider.py` — `SamlProvider`

**3b. Client methods:**
- Product access: `list_product_access()`, `list_org_product_access()`, `get_org_defaults()`, `grant_product_access()`, `revoke_product_access()`, `grant_org_product_access()`, `revoke_org_product_access()`
- Site access: `list_site_access()`, `list_org_site_access()`, `grant_site_access()`, `revoke_site_access()`, `grant_org_site_access()`, `revoke_org_site_access()`
- SAML: `list_saml_providers()`, `create_saml_provider()`, `import_saml_provider()`, `update_saml_provider()`, `delete_saml_provider()`

**3c. Commands:**
- `commands/product_access.py` — 7 subcommands
- `commands/site_access.py` — 6 subcommands
- `commands/saml.py` — 5 subcommands (import reads XML file from disk)

### Phase 4: Tokens & MFA

**4a. Models:**
- `models/token.py` — `UserPersonalAccessToken`, `UserMcpAccessToken`

**4b. Commands:**
- `commands/tokens.py` — list, create (--expiration-days), delete
- `commands/mcp_tokens.py` — list, create (--expiration-days), delete
- `commands/mfa.py` — enable (--token-code), disable, disable-user, count

### Phase 5: CLI Integration

Update `src/bt_cli/cli.py`:
- Add `_test_pf_connection()` → call `get_user_info()` for whoami
- Add PF to `whoami` command results
- Add PF section to `tree_command` + add `"pf"` to valid product list
- Add all PF commands to `_get_all_commands()`
- Update `skills` command help text

### Phase 6: Tests

**6a. Fixtures** — `tests/conftest.py`: add `mock_pf_config`, `pf_env_vars`
**6b. Mock responses** — `tests/fixtures/responses.py`: add `PF_*` constants
**6c. Test files:**
- `tests/pf/__init__.py`
- `tests/pf/test_client.py` — client unit tests with `@respx.mock`
- `tests/pf/test_commands.py` — CLI command tests with patched config/client

### Phase 7: Skill File

- `src/bt_cli/data/skills/pf/SKILL.md` — command reference, destructive ops warnings, workflow examples, API quirks
- Update `btcli/CLAUDE.md` and `src/bt_cli/data/CLAUDE.md` to include PF

## Files to Create (27 files)

| File | Purpose |
|------|---------|
| `src/bt_cli/pf/__init__.py` | Package marker |
| `src/bt_cli/pf/client/__init__.py` | Export PFClient, get_client |
| `src/bt_cli/pf/client/base.py` | HTTP client with Machine auth token caching |
| `src/bt_cli/pf/commands/__init__.py` | Register all command sub-apps |
| `src/bt_cli/pf/commands/auth.py` | test, status |
| `src/bt_cli/pf/commands/users.py` | User management (10 commands) |
| `src/bt_cli/pf/commands/machines.py` | Machine registration (5 commands) |
| `src/bt_cli/pf/commands/auditing.py` | Audit log listing |
| `src/bt_cli/pf/commands/saml.py` | SAML provider CRUD + import |
| `src/bt_cli/pf/commands/product_access.py` | Product access rules (7 commands) |
| `src/bt_cli/pf/commands/site_access.py` | Site access rules (6 commands) |
| `src/bt_cli/pf/commands/tokens.py` | Personal access tokens |
| `src/bt_cli/pf/commands/mcp_tokens.py` | MCP access tokens |
| `src/bt_cli/pf/commands/mfa.py` | MFA management |
| `src/bt_cli/pf/models/__init__.py` | Package marker |
| `src/bt_cli/pf/models/common.py` | CommandResponse base |
| `src/bt_cli/pf/models/user.py` | NomineUser |
| `src/bt_cli/pf/models/machine.py` | Machine |
| `src/bt_cli/pf/models/audit.py` | AuditRecord |
| `src/bt_cli/pf/models/saml_provider.py` | SamlProvider |
| `src/bt_cli/pf/models/access.py` | ProductAccessRule, SiteAccessRule |
| `src/bt_cli/pf/models/token.py` | PAT, MCP token models |
| `tests/pf/__init__.py` | Test package |
| `tests/pf/test_client.py` | Client unit tests |
| `tests/pf/test_commands.py` | CLI command tests |
| `src/bt_cli/data/skills/pf/SKILL.md` | Claude Code skill |

## Files to Modify (7 files)

| File | Change |
|------|--------|
| `src/bt_cli/core/auth.py` | Add `MachineAuth` class (~30 lines) |
| `src/bt_cli/core/config.py` | Add `PFConfig` dataclass + `load_pf_config()` (~40 lines) |
| `src/bt_cli/core/config_file.py` | Add `"pf"` to PRODUCTS dict (~15 lines) |
| `src/bt_cli/cli.py` | Lazy loader, registration, whoami, tree, find, help text |
| `tests/conftest.py` | Add `mock_pf_config`, `pf_env_vars` fixtures |
| `tests/fixtures/responses.py` | Add `PF_*` mock response constants |
| `btcli/CLAUDE.md` + `src/bt_cli/data/CLAUDE.md` | Add PF to docs |

## Key Design Decisions

1. **Auth: New `MachineAuth` strategy** — PF uses `machineId`+`machineSecret` → JWT, not standard OAuth form-encoded flow. Clean separation.
2. **No path prefix** — PF endpoints are at `/api/*` and `/bt.identity/*` directly off base URL (unlike PWS `/api/public/v3` or Entitle `/public/v1`).
3. **Pagination** — PF uses `page`/`pageSize` but some endpoints (GET /api/Users) return plain arrays. Client handles both.
4. **Skip browser/internal endpoints** — `/bt.identity/Authentication/*`, `/api/noauth/*`, `/api/Support/*`, `/Test/*` are not CLI-appropriate.
5. **Env var prefix: `BT_PF_`** — Consistent with `BT_PWS_`, `BT_PRA_`, etc.

## Verification

1. `bt pf auth test` — connects with machine credentials
2. `bt pf users list` / `bt pf users me` — reads user data
3. `bt pf machines list` — lists registered machines
4. `bt tree pf` — shows full command tree
5. `bt whoami` — includes PF status
6. `pytest tests/pf/ -v` — all unit tests pass
7. `bt find saml` — finds PF SAML commands
