"""Tests for the BeyondTrust Secrets API CLI."""
