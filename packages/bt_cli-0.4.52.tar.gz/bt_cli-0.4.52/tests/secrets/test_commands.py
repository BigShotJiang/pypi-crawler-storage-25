"""CLI command tests for `bt secrets ...`."""

import httpx
import pytest
import respx
from typer.testing import CliRunner

from bt_cli.secrets.commands import app as secrets_app


SITE = "00000000-0000-0000-0000-000000000000"


def _url(path: str) -> str:
    return f"https://mock-secrets.example.com/site/{SITE}/secrets{path}"


@pytest.fixture
def env_overrides(monkeypatch):
    monkeypatch.setenv("BT_SECRETS_API_URL", "https://mock-secrets.example.com")
    monkeypatch.setenv("BT_SECRETS_SITE_ID", SITE)
    monkeypatch.setenv("BT_SECRETS_PAT", "PAT_test_xxxxxxxxxxxxxxxxxxxxxxxxxx")
    monkeypatch.setenv("BT_SECRETS_API_VERSION", "2026-04-28")
    monkeypatch.setenv("BT_SECRETS_VERIFY_SSL", "false")


class TestAuth:
    @respx.mock
    def test_auth_test_success(self, env_overrides):
        respx.get(_url("/folders")).mock(
            return_value=httpx.Response(200, json={"data": []})
        )
        result = CliRunner().invoke(secrets_app, ["auth", "test"])
        assert result.exit_code == 0
        assert "Connected to Secrets API" in result.stdout
        assert "2026-04-28" in result.stdout

    @respx.mock
    def test_auth_test_401_explains_pat(self, env_overrides):
        respx.get(_url("/folders")).mock(
            return_value=httpx.Response(401, json={"message": "Unauthorized"})
        )
        result = CliRunner().invoke(secrets_app, ["auth", "test"])
        assert result.exit_code == 1
        assert "401" in result.stdout
        assert "PAT" in result.stdout

    @respx.mock
    def test_auth_test_404_explains_site(self, env_overrides):
        respx.get(_url("/folders")).mock(
            return_value=httpx.Response(404, json={"message": "not found"})
        )
        result = CliRunner().invoke(secrets_app, ["auth", "test"])
        assert result.exit_code == 1
        assert "BT_SECRETS_SITE_ID" in result.stdout

    def test_auth_status_warns_unset(self, monkeypatch):
        for key in ("BT_SECRETS_SITE_ID", "BT_SECRETS_PAT"):
            monkeypatch.delenv(key, raising=False)
        result = CliRunner().invoke(secrets_app, ["auth", "status"])
        assert result.exit_code == 0
        assert "BT_SECRETS_SITE_ID is not set" in result.stdout
        assert "BT_SECRETS_PAT is not set" in result.stdout


class TestFolders:
    @respx.mock
    def test_folders_list(self, env_overrides):
        respx.get(_url("/folders")).mock(
            return_value=httpx.Response(200, json={"data": [
                {"path": "lab/aws", "type": "folder",
                 "metadata": {"id": "abc", "createdAt": "2026-01-01T00:00:00Z"}},
            ]})
        )
        result = CliRunner().invoke(secrets_app, ["folders", "list", "-p", "lab"])
        assert result.exit_code == 0
        assert "lab/aws" in result.stdout

    @respx.mock
    def test_folders_list_json(self, env_overrides):
        respx.get(_url("/folders")).mock(
            return_value=httpx.Response(200, json={"data": [{"path": "lab/aws"}]})
        )
        result = CliRunner().invoke(secrets_app, ["folders", "list", "-o", "json"])
        assert result.exit_code == 0
        assert "lab/aws" in result.stdout

    @respx.mock
    def test_folders_get_splits_path(self, env_overrides):
        route = respx.get(_url("/folders/aws/metadata")).mock(
            return_value=httpx.Response(200, json={"id": "abc"})
        )
        result = CliRunner().invoke(secrets_app, ["folders", "get", "lab/aws"])
        assert result.exit_code == 0
        # Confirm `folder=lab` query param was sent
        assert "folder=lab" in str(route.calls[0].request.url)

    @respx.mock
    def test_folders_create(self, env_overrides):
        respx.post(_url("/folders/newfolder")).mock(
            return_value=httpx.Response(201, json={"id": "new", "path": "/lab/newfolder"})
        )
        result = CliRunner().invoke(secrets_app, ["folders", "create", "lab/newfolder"])
        assert result.exit_code == 0

    @respx.mock
    def test_folders_delete_requires_confirm(self, env_overrides):
        # Without --force we cancel.
        result = CliRunner().invoke(secrets_app, ["folders", "delete", "lab/aws"], input="n\n")
        assert result.exit_code == 0
        assert "Cancelled" in result.stdout

    @respx.mock
    def test_folders_delete_force(self, env_overrides):
        route = respx.delete(_url("/folders/aws")).mock(return_value=httpx.Response(204))
        result = CliRunner().invoke(secrets_app, ["folders", "delete", "lab/aws", "--force"])
        assert result.exit_code == 0
        assert route.called


class TestDynamic:
    @respx.mock
    def test_dynamic_list_uses_singular_path(self, env_overrides):
        """Verify the CLI hits /dynamic, NOT /dynamic-secrets."""
        route = respx.get(_url("/dynamic")).mock(
            return_value=httpx.Response(200, json={"data": [
                {"path": "lab/aws/ec2-readonly", "type": "dynamic-aws",
                 "metadata": {"id": "abc", "createdAt": "2026-01-01T00:00:00Z"}},
            ]})
        )
        result = CliRunner().invoke(secrets_app, ["dynamic", "list", "-p", "lab/aws", "-r"])
        assert result.exit_code == 0
        assert "ec2-readonly" in result.stdout
        assert route.called

    @respx.mock
    def test_dynamic_list_recursive_is_default(self, env_overrides):
        """No -r / --recursive flag → still sends recursive=true (new default)."""
        route = respx.get(_url("/dynamic")).mock(
            return_value=httpx.Response(200, json={"data": []})
        )
        result = CliRunner().invoke(secrets_app, ["dynamic", "list", "-p", "lab"])
        assert result.exit_code == 0
        assert "recursive=true" in str(route.calls[0].request.url)

    @respx.mock
    def test_dynamic_list_shallow_opts_out(self, env_overrides):
        """--shallow turns off recursion."""
        route = respx.get(_url("/dynamic")).mock(
            return_value=httpx.Response(200, json={"data": []})
        )
        result = CliRunner().invoke(secrets_app, ["dynamic", "list", "-p", "lab", "--shallow"])
        assert result.exit_code == 0
        assert "recursive=true" not in str(route.calls[0].request.url)

    @respx.mock
    def test_dynamic_list_empty_recursive_hint(self, env_overrides):
        """Empty + recursive → hint nudges toward path check."""
        respx.get(_url("/dynamic")).mock(
            return_value=httpx.Response(200, json={"data": []})
        )
        result = CliRunner().invoke(secrets_app, ["dynamic", "list", "-p", "nowhere"])
        assert result.exit_code == 0
        assert "No dynamic secrets" in result.stdout
        assert "'nowhere'" in result.stdout
        assert "--shallow" in result.stdout  # hint mentions the alternative

    @respx.mock
    def test_dynamic_list_empty_shallow_hint(self, env_overrides):
        """Empty + --shallow → hint nudges toward dropping --shallow."""
        respx.get(_url("/dynamic")).mock(
            return_value=httpx.Response(200, json={"data": []})
        )
        result = CliRunner().invoke(secrets_app, ["dynamic", "list", "-p", "lab", "--shallow"])
        assert result.exit_code == 0
        assert "--shallow mode" in result.stdout
        assert "drop --shallow" in result.stdout

    @respx.mock
    def test_dynamic_generate_export_shape(self, env_overrides):
        respx.post(_url("/dynamic/ec2-readonly/generate")).mock(
            return_value=httpx.Response(201, json={"secret": {
                "accessKeyId": "ASIA-FAKE",
                "secretAccessKey": "SAK-FAKE",
                "sessionToken": "TOK-FAKE",
                "leaseId": "lease-1",
                "expiration": "2026-01-01T00:00:00Z",
            }})
        )
        result = CliRunner().invoke(secrets_app, ["dynamic", "generate", "lab/aws/ec2-readonly"])
        assert result.exit_code == 0
        assert "export AWS_ACCESS_KEY_ID=ASIA-FAKE" in result.stdout
        assert "export AWS_SECRET_ACCESS_KEY=SAK-FAKE" in result.stdout
        assert "export AWS_SESSION_TOKEN=TOK-FAKE" in result.stdout
        # PAT must not leak in any form
        assert "PAT_test" not in result.stdout
        # Inline apply-hint includes the actual path the user passed
        assert "eval $(bt secrets dynamic generate lab/aws/ec2-readonly)" in result.stdout

    @respx.mock
    def test_dynamic_generate_powershell_hint(self, env_overrides):
        respx.post(_url("/dynamic/ec2-readonly/generate")).mock(
            return_value=httpx.Response(201, json={"secret": {
                "accessKeyId": "ASIA-FAKE", "secretAccessKey": "SAK-FAKE",
                "sessionToken": "TOK-FAKE", "expiration": "2026-01-01T00:00:00Z",
            }})
        )
        result = CliRunner().invoke(
            secrets_app, ["dynamic", "generate", "lab/aws/ec2-readonly", "--format", "powershell"],
        )
        assert result.exit_code == 0
        assert "--format powershell | iex" in result.stdout
        # Hint must use # (valid PowerShell comment); not REM
        assert "REM Tip" not in result.stdout

    @respx.mock
    def test_dynamic_generate_cmd_hint(self, env_overrides):
        respx.post(_url("/dynamic/ec2-readonly/generate")).mock(
            return_value=httpx.Response(201, json={"secret": {
                "accessKeyId": "ASIA-FAKE", "secretAccessKey": "SAK-FAKE",
                "sessionToken": "TOK-FAKE", "expiration": "2026-01-01T00:00:00Z",
            }})
        )
        result = CliRunner().invoke(
            secrets_app, ["dynamic", "generate", "lab/aws/ec2-readonly", "--format", "cmd"],
        )
        assert result.exit_code == 0
        assert "for /f" in result.stdout
        assert "--format cmd" in result.stdout
        # cmd format must use REM (not #) for the apply hint
        assert "REM Tip" in result.stdout

    @respx.mock
    def test_dynamic_generate_no_hint_for_non_shell_formats(self, env_overrides):
        """env / dotenv / json shouldn't carry an apply hint — no canonical apply mode."""
        respx.post(_url("/dynamic/ec2-readonly/generate")).mock(
            return_value=httpx.Response(201, json={"secret": {
                "accessKeyId": "ASIA-FAKE", "secretAccessKey": "SAK-FAKE",
                "sessionToken": "TOK-FAKE", "expiration": "2026-01-01T00:00:00Z",
            }})
        )
        for fmt in ("env", "dotenv"):
            result = CliRunner().invoke(
                secrets_app, ["dynamic", "generate", "lab/aws/ec2-readonly", "--format", fmt],
            )
            assert result.exit_code == 0, fmt
            assert "Tip: apply with" not in result.stdout, fmt

    @respx.mock
    def test_dynamic_generate_json(self, env_overrides):
        respx.post(_url("/dynamic/ec2-readonly/generate")).mock(
            return_value=httpx.Response(201, json={"secret": {
                "accessKeyId": "ASIA-FAKE",
                "leaseId": "lease-1",
            }})
        )
        result = CliRunner().invoke(
            secrets_app, ["dynamic", "generate", "lab/aws/ec2-readonly", "--format", "json"],
        )
        assert result.exit_code == 0
        assert "lease-1" in result.stdout

    @respx.mock
    def test_dynamic_generate_env_no_export_prefix(self, env_overrides):
        respx.post(_url("/dynamic/ec2-readonly/generate")).mock(
            return_value=httpx.Response(201, json={"secret": {
                "accessKeyId": "AKIA-FAKE",
                "secretAccessKey": "SAK-FAKE",
                "sessionToken": "TOK-FAKE",
                "expiration": "2026-01-01T00:00:00Z",
            }})
        )
        result = CliRunner().invoke(
            secrets_app, ["dynamic", "generate", "lab/aws/ec2-readonly", "--format", "env"],
        )
        assert result.exit_code == 0
        assert "AWS_ACCESS_KEY_ID=AKIA-FAKE" in result.stdout
        assert "export" not in result.stdout.split("\n")[0]

    @respx.mock
    def test_dynamic_generate_powershell_shape(self, env_overrides):
        """PowerShell format: $env:VAR = "val" — pipe to Invoke-Expression."""
        respx.post(_url("/dynamic/ec2-readonly/generate")).mock(
            return_value=httpx.Response(201, json={"secret": {
                "accessKeyId": "ASIA-FAKE",
                "secretAccessKey": "SAK-FAKE",
                "sessionToken": "TOK-FAKE",
                "expiration": "2026-01-01T00:00:00Z",
            }})
        )
        result = CliRunner().invoke(
            secrets_app,
            ["dynamic", "generate", "lab/aws/ec2-readonly", "--format", "powershell"],
        )
        assert result.exit_code == 0
        assert '$env:AWS_ACCESS_KEY_ID = "ASIA-FAKE"' in result.stdout
        assert '$env:AWS_SECRET_ACCESS_KEY = "SAK-FAKE"' in result.stdout
        assert '$env:AWS_SESSION_TOKEN = "TOK-FAKE"' in result.stdout
        # Comment must use `#` (valid PowerShell line comment)
        assert "# expires:" in result.stdout
        # Must NOT contain bash `export` syntax
        assert "export AWS_" not in result.stdout

    @respx.mock
    def test_dynamic_generate_cmd_shape(self, env_overrides):
        """cmd.exe format: set VAR=val — for `for /f` extraction."""
        respx.post(_url("/dynamic/ec2-readonly/generate")).mock(
            return_value=httpx.Response(201, json={"secret": {
                "accessKeyId": "ASIA-FAKE",
                "secretAccessKey": "SAK-FAKE",
                "sessionToken": "TOK-FAKE",
                "expiration": "2026-01-01T00:00:00Z",
            }})
        )
        result = CliRunner().invoke(
            secrets_app,
            ["dynamic", "generate", "lab/aws/ec2-readonly", "--format", "cmd"],
        )
        assert result.exit_code == 0
        assert "set AWS_ACCESS_KEY_ID=ASIA-FAKE" in result.stdout
        assert "set AWS_SECRET_ACCESS_KEY=SAK-FAKE" in result.stdout
        # cmd.exe uses REM, not #, for comments
        assert "REM expires:" in result.stdout
        assert "# expires" not in result.stdout


class TestLeases:
    @respx.mock
    def test_leases_list(self, env_overrides):
        respx.get(_url("/leases/ec2-readonly")).mock(
            return_value=httpx.Response(200, json={"data": [
                {"leaseId": "L1", "issuedAt": "2026-01-01T00:00:00Z",
                 "expiration": "2026-01-01T01:00:00Z"},
            ]})
        )
        result = CliRunner().invoke(secrets_app, ["leases", "list", "lab/aws/ec2-readonly"])
        assert result.exit_code == 0
        assert "L1" in result.stdout

    @respx.mock
    def test_leases_revoke_403_exits_3_cleanly(self, env_overrides):
        """The lab PAT can't revoke — surface that distinctly, not as generic failure."""
        respx.get(_url("/leases/revoke")).mock(
            return_value=httpx.Response(403, json={"message": "forbidden"})
        )
        result = CliRunner().invoke(secrets_app, ["leases", "revoke", "abc-123"])
        assert result.exit_code == 3
        assert "403" in result.stdout
        assert "revoke scope" in result.stdout
        # Reassure user it'll still expire on its own.
        assert "TTL" in result.stdout

    @respx.mock
    def test_leases_revoke_success(self, env_overrides):
        respx.get(_url("/leases/revoke")).mock(return_value=httpx.Response(200))
        result = CliRunner().invoke(secrets_app, ["leases", "revoke", "abc-123"])
        assert result.exit_code == 0
        assert "Revoked lease" in result.stdout


class TestStatic:
    @respx.mock
    def test_static_create_inline_json(self, env_overrides):
        route = respx.post(_url("/static/db-pass")).mock(
            return_value=httpx.Response(201, json={"path": "/lab/db-pass"})
        )
        result = CliRunner().invoke(
            secrets_app,
            ["static", "create", "lab/db-pass", "-d", '{"password":"hunter2","username":"admin"}'],
        )
        assert result.exit_code == 0
        # Confirm the body wraps the payload in {"secret": ...}
        body = route.calls[0].request.content.decode("utf-8")
        assert '"secret"' in body
        assert '"password"' in body
        # Confirm folder query param made the trip.
        assert "folder=lab" in str(route.calls[0].request.url)

    @respx.mock
    def test_static_create_rejects_non_object_json(self, env_overrides):
        result = CliRunner().invoke(
            secrets_app, ["static", "create", "lab/foo", "-d", '"justastring"'],
        )
        assert result.exit_code == 2
        assert "JSON object" in result.stdout

    @respx.mock
    def test_static_update_passes_204(self, env_overrides):
        respx.patch(_url("/static/db-pass")).mock(return_value=httpx.Response(204))
        result = CliRunner().invoke(
            secrets_app, ["static", "update", "lab/db-pass", "-d", '{"password":"new"}'],
        )
        assert result.exit_code == 0


class TestIntegrations:
    @respx.mock
    def test_integrations_list(self, env_overrides):
        respx.get(_url("/integrations")).mock(
            return_value=httpx.Response(200, json={"data": [
                {"name": "my-aws", "type": "aws", "id": "abc",
                 "createdAt": "2026-01-01T00:00:00Z"},
            ]})
        )
        result = CliRunner().invoke(secrets_app, ["integrations", "list"])
        assert result.exit_code == 0
        assert "my-aws" in result.stdout

    @respx.mock
    def test_integrations_update_default_is_put(self, env_overrides):
        route = respx.put(_url("/integrations/my-aws")).mock(
            return_value=httpx.Response(200, json={"name": "my-aws"})
        )
        result = CliRunner().invoke(
            secrets_app,
            ["integrations", "update", "my-aws", "-d", '{"type":"aws","roleArn":"arn:..."}'],
        )
        assert result.exit_code == 0
        assert route.called

    @respx.mock
    def test_integrations_update_partial_uses_patch(self, env_overrides):
        route = respx.patch(_url("/integrations/my-aws")).mock(
            return_value=httpx.Response(200, json={"name": "my-aws"})
        )
        result = CliRunner().invoke(
            secrets_app,
            ["integrations", "update", "my-aws", "--partial", "-d", '{"externalId":"new"}'],
        )
        assert result.exit_code == 0
        assert route.called
