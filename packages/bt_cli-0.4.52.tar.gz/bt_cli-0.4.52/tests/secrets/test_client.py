"""Unit tests for the Secrets API client (URL build, headers, retry, dispatch)."""

import httpx
import pytest
import respx

from bt_cli.core.config import SecretsConfig
from bt_cli.secrets.client import SecretsClient, split_path


SITE = "00000000-0000-0000-0000-000000000000"
BASE = f"https://mock-secrets.example.com/site/{SITE}/secrets"


@pytest.fixture
def secrets_config() -> SecretsConfig:
    return SecretsConfig(
        api_url="https://mock-secrets.example.com",
        site_id=SITE,
        pat="PAT_test_xxxxxxxxxxxxxxxxxxxxxxxxxx",
        api_version="2026-04-28",
        verify_ssl=False,
        timeout=5.0,
    )


# ---------------------------------------------------------------------------
# split_path
# ---------------------------------------------------------------------------

class TestSplitPath:
    def test_two_segments(self):
        assert split_path("lab/aws/foo") == ("lab/aws", "foo")

    def test_bare_name(self):
        assert split_path("foo") == ("", "foo")

    def test_leading_slash(self):
        assert split_path("/lab/aws/foo") == ("lab/aws", "foo")

    def test_trailing_slash(self):
        assert split_path("/lab/aws/") == ("lab", "aws")

    def test_empty(self):
        assert split_path("") == ("", "")


# ---------------------------------------------------------------------------
# Headers / URL composition
# ---------------------------------------------------------------------------

class TestHeadersAndURL:
    def test_url_composition(self, secrets_config):
        c = SecretsClient(secrets_config)
        assert c._url("/folders") == f"{BASE}/folders"
        assert c._url("folders") == f"{BASE}/folders"

    def test_base_url_trailing_slash_normalized(self):
        cfg = SecretsConfig(
            api_url="https://mock-secrets.example.com/",
            site_id=SITE, pat="PAT", api_version="2026-04-28", verify_ssl=False,
        )
        c = SecretsClient(cfg)
        assert c._url("/folders") == f"{BASE}/folders"

    def test_headers_include_bearer_and_version(self, secrets_config):
        h = SecretsClient(secrets_config)._headers()
        assert h["Authorization"] == "Bearer PAT_test_xxxxxxxxxxxxxxxxxxxxxxxxxx"
        assert h["bt-secrets-api-version"] == "2026-04-28"
        assert h["Accept"] == "application/json"

    @respx.mock
    def test_request_sends_bearer_and_version(self, secrets_config):
        route = respx.get(f"{BASE}/folders").mock(
            return_value=httpx.Response(200, json={"data": []})
        )
        SecretsClient(secrets_config).list_folders()
        req = route.calls[0].request
        assert req.headers["Authorization"].startswith("Bearer PAT_test")
        assert req.headers["bt-secrets-api-version"] == "2026-04-28"


# ---------------------------------------------------------------------------
# 401 / 403 surface — NOT retried
# ---------------------------------------------------------------------------

class TestAuthErrors:
    @respx.mock
    def test_401_surfaces_immediately(self, secrets_config):
        respx.get(f"{BASE}/folders").mock(
            return_value=httpx.Response(401, json={"message": "Unauthorized"})
        )
        with pytest.raises(httpx.HTTPStatusError) as exc:
            SecretsClient(secrets_config).list_folders()
        assert exc.value.response.status_code == 401

    @respx.mock
    def test_403_surfaces_immediately(self, secrets_config):
        respx.get(f"{BASE}/leases/revoke", params={"id": "lease-id"}).mock(
            return_value=httpx.Response(403, json={"message": "forbidden"})
        )
        with pytest.raises(httpx.HTTPStatusError) as exc:
            SecretsClient(secrets_config).revoke_lease("lease-id")
        assert exc.value.response.status_code == 403


# ---------------------------------------------------------------------------
# 429 retry — honors x-ratelimit-reset
# ---------------------------------------------------------------------------

class TestRetry:
    @respx.mock
    def test_429_then_success(self, secrets_config, monkeypatch):
        # No real sleep in tests.
        slept = []
        monkeypatch.setattr("bt_cli.secrets.client.base.time.sleep", lambda s: slept.append(s))

        route = respx.get(f"{BASE}/folders").mock(side_effect=[
            httpx.Response(429, headers={"x-ratelimit-reset": "2"}, json={"message": "slow down"}),
            httpx.Response(200, json={"data": [{"path": "lab"}]}),
        ])
        result = SecretsClient(secrets_config).list_folders()
        assert result == [{"path": "lab"}]
        assert route.call_count == 2
        assert slept == [2.0]

    @respx.mock
    def test_429_clamps_bogus_reset(self, secrets_config, monkeypatch):
        slept = []
        monkeypatch.setattr("bt_cli.secrets.client.base.time.sleep", lambda s: slept.append(s))

        respx.get(f"{BASE}/folders").mock(side_effect=[
            httpx.Response(429, headers={"x-ratelimit-reset": "999999"}, json={}),
            httpx.Response(200, json={"data": []}),
        ])
        SecretsClient(secrets_config).list_folders()
        # Clamped to <= 30s so a malicious header can't park the CLI forever.
        assert slept and slept[0] <= 30.0

    @respx.mock
    def test_5xx_retried(self, secrets_config, monkeypatch):
        monkeypatch.setattr("bt_cli.secrets.client.base.time.sleep", lambda s: None)
        route = respx.get(f"{BASE}/folders").mock(side_effect=[
            httpx.Response(503),
            httpx.Response(200, json={"data": []}),
        ])
        SecretsClient(secrets_config).list_folders()
        assert route.call_count == 2

    @respx.mock
    def test_429_then_429_raises(self, secrets_config, monkeypatch):
        """Retry once only; a second 429 should surface."""
        monkeypatch.setattr("bt_cli.secrets.client.base.time.sleep", lambda s: None)
        respx.get(f"{BASE}/folders").mock(side_effect=[
            httpx.Response(429, headers={"x-ratelimit-reset": "0"}),
            httpx.Response(429, headers={"x-ratelimit-reset": "0"}),
        ])
        with pytest.raises(httpx.HTTPStatusError) as exc:
            SecretsClient(secrets_config).list_folders()
        assert exc.value.response.status_code == 429


# ---------------------------------------------------------------------------
# Path semantics: /dynamic (NOT /dynamic-secrets) — doc is stale
# ---------------------------------------------------------------------------

class TestDynamicPath:
    @respx.mock
    def test_list_dynamic_uses_singular_path(self, secrets_config):
        route = respx.get(f"{BASE}/dynamic").mock(
            return_value=httpx.Response(200, json={"data": []})
        )
        SecretsClient(secrets_config).list_dynamic(path="lab/aws", recursive=True)
        assert route.called
        req = route.calls[0].request
        assert "path=lab%2Faws" in str(req.url) or "path=lab/aws" in str(req.url)
        assert "recursive=true" in str(req.url)

    @respx.mock
    def test_dynamic_get_passes_folder_param(self, secrets_config):
        route = respx.get(f"{BASE}/dynamic/ec2-readonly").mock(
            return_value=httpx.Response(200, json={"path": "lab/aws/ec2-readonly"})
        )
        SecretsClient(secrets_config).get_dynamic("ec2-readonly", folder="lab/aws")
        assert "folder=lab" in str(route.calls[0].request.url)

    @respx.mock
    def test_generate_accepts_201(self, secrets_config):
        """POST /dynamic/{name}/generate returns 201, not 200."""
        respx.post(f"{BASE}/dynamic/cloudwatch-readonly/generate").mock(
            return_value=httpx.Response(201, json={
                "secret": {
                    "accessKeyId": "ASIA...",
                    "secretAccessKey": "...",
                    "sessionToken": "...",
                    "leaseId": "lease-1",
                    "expiration": "2026-01-01T00:00:00Z",
                }
            })
        )
        result = SecretsClient(secrets_config).generate_dynamic("cloudwatch-readonly", folder="lab/aws")
        assert result["secret"]["leaseId"] == "lease-1"


# ---------------------------------------------------------------------------
# Leases: list / get / revoke wiring
# ---------------------------------------------------------------------------

class TestLeases:
    @respx.mock
    def test_list_leases_passes_folder(self, secrets_config):
        route = respx.get(f"{BASE}/leases/ec2-readonly").mock(
            return_value=httpx.Response(200, json={"data": [{"leaseId": "X"}]})
        )
        out = SecretsClient(secrets_config).list_leases("ec2-readonly", folder="lab/aws")
        assert out == [{"leaseId": "X"}]
        assert "folder=lab" in str(route.calls[0].request.url)

    @respx.mock
    def test_get_lease_uses_id_path(self, secrets_config):
        route = respx.get(f"{BASE}/leases/id/abc-123").mock(
            return_value=httpx.Response(200, json={"id": "abc-123"})
        )
        SecretsClient(secrets_config).get_lease("abc-123")
        assert route.called

    @respx.mock
    def test_revoke_uses_get_with_id_param(self, secrets_config):
        """/leases/revoke?id=<id> — GET, not DELETE."""
        route = respx.get(f"{BASE}/leases/revoke").mock(
            return_value=httpx.Response(200, json={})
        )
        SecretsClient(secrets_config).revoke_lease("abc-123")
        assert route.called
        assert "id=abc-123" in str(route.calls[0].request.url)


# ---------------------------------------------------------------------------
# Response shape unification (list endpoints sometimes return bare arrays)
# ---------------------------------------------------------------------------

class TestResponseUnwrapping:
    @respx.mock
    def test_list_folders_handles_bare_array(self, secrets_config):
        respx.get(f"{BASE}/folders").mock(
            return_value=httpx.Response(200, json=[{"path": "lab"}])
        )
        assert SecretsClient(secrets_config).list_folders() == [{"path": "lab"}]

    @respx.mock
    def test_list_folders_handles_data_wrapper(self, secrets_config):
        respx.get(f"{BASE}/folders").mock(
            return_value=httpx.Response(200, json={"data": [{"path": "lab"}]})
        )
        assert SecretsClient(secrets_config).list_folders() == [{"path": "lab"}]

    @respx.mock
    def test_list_integrations_filters_by_type(self, secrets_config):
        route = respx.get(f"{BASE}/integrations").mock(
            return_value=httpx.Response(200, json={"data": []})
        )
        SecretsClient(secrets_config).list_integrations(type_="aws")
        assert "type=aws" in str(route.calls[0].request.url)


# ---------------------------------------------------------------------------
# Config loader strips ANSI/C0 control bytes from URL/header-bound fields
# ---------------------------------------------------------------------------

class TestLoaderSanitization:
    def test_strip_controls_removes_ansi_escapes(self, monkeypatch, tmp_path):
        from bt_cli.core.config import load_secrets_config

        # Pretend the user typed arrow keys at the `bt configure` prompt:
        # the site_id picks up cursor-forward/back ESC sequences. Without
        # the sanitizer these would land in the URL and httpx would reject
        # the request with a misleading non-printable-ASCII error.
        dirty_site = "7f735e1b-5ecb-49fa-87e8-eddf54a9c745\x1b[C\x1b[D"
        monkeypatch.setenv("BT_SECRETS_SITE_ID", dirty_site)
        monkeypatch.setenv("BT_SECRETS_PAT", "PAT_x")
        monkeypatch.setenv("BT_SECRETS_API_URL", "https://api.example.com")
        # Isolate from any real ~/.bt-cli/config.yaml on the dev box.
        monkeypatch.setenv("HOME", str(tmp_path))

        cfg = load_secrets_config()
        assert cfg.site_id == "7f735e1b-5ecb-49fa-87e8-eddf54a9c745"
        assert "\x1b" not in cfg.site_id
