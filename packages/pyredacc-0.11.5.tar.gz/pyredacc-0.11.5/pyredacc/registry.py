import os


class DockerRegistry:
    _instance = None

    def __init__(self):
        self._url: str = "lab.analogparadigm.com:5050/lucidac/software/softthat"
        self._username: str | None = None
        self._password: str | None = None
        self._logged_in = False

    @classmethod
    def configure(cls, username=None, password=None):
        """Set registry credentials. Call once before using Compiler/Simulator."""
        inst = cls._get()
        inst._username = username
        inst._password = password
        inst._logged_in = False

    @classmethod
    def _get(cls):
        """Return the singleton instance, creating it if needed."""
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    @classmethod
    def from_env(cls):
        """Configure from REDACC_REGISTRY_URL, CI_REGISTRY_USER, CI_REGISTRY_PASSWORD."""
        cls.configure(
            username=os.environ.get("CI_REGISTRY_USER"),
            password=os.environ.get("CI_REGISTRY_PASSWORD"),
        )

    @property
    def url(self) -> str | None:
        return self._url

    def login(self, client) -> None:
        """Login to registry via the docker client. No-op if already logged in or no URL."""
        if self._logged_in or not self._url:
            return
        kwargs = {"registry": self._url}
        if self._username:
            kwargs["username"] = self._username
        if self._password:
            kwargs["password"] = self._password
        client.login(**kwargs)
        self._logged_in = True

    @classmethod
    def _reset(cls):
        """Reset singleton state. For testing only."""
        cls._instance = None
