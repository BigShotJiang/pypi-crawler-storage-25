import logging
import os
import shutil
import tempfile
from typing import List, Optional, Union

from typing_extensions import runtime

from .executor import DockerExecutor, LocalExecutor
from .ode_adapter import ODEAdapter
import pybrid.base.proto.main_pb2 as pb
from .types import Backend, CompilerResult, ResourceLimits, SympyODE
from pybrid.base.proto.io import ProtoIO

logger = logging.getLogger(__name__)


class Compiler:
    """Compile ODE systems to analog hardware configurations.

    Accepts input as a file path, an analang text string, or a SympyODE
    instance.  Execution happens either inside a Docker container (default)
    or via a local ``redacc`` binary when *executable* is provided.
    """

    def __init__(
        self,
        backend: Backend,
        device: Optional[str] = None,
        no_upscaling: bool = False,
        k0_scaling: bool = False,
        time_factor: int = 10_000,
        sim_k0: int = 10_000,
        executable: Optional[str] = None,
        image_name: str = "redacc-compiler",
        image_tag: str = "latest",
        plugins_dir: Optional[str] = None,
        always_pull: bool = True,
        resource_limits: Optional[ResourceLimits] = None,
    ):
        self._backend = backend
        self._device = device
        self._no_upscaling = no_upscaling
        self._k0_scaling = k0_scaling
        self._time_factor = time_factor
        self._sim_k0 = sim_k0
        self._resource_limits = resource_limits

        if executable:
            self._executor = LocalExecutor(executable=executable, plugins_dir=plugins_dir)
            self._is_docker = False
        else:
            self._executor = DockerExecutor(
                image_name=image_name,
                image_tag=image_tag,
                plugins_dir=plugins_dir,
                always_pull=always_pull,
            )
            self._is_docker = True

    def _build_args(
        self,
        input_path: str,
        output_dir: str,
        output_apb: bool = True,
        container_output_dir: Optional[str] = None,
        container_input_path: Optional[str] = None,
        container_device_path: Optional[str] = None,
    ) -> List[str]:
        args: List[str] = []
        effective_output = container_output_dir or output_dir
        effective_input = container_input_path or input_path

        args.extend(["--backend", self._backend.name])
        
        if self._device:
            effective_device = container_device_path or self._device
            args.extend(["--entity", effective_device])

        if output_apb:
            args.extend(["--output", os.path.join(effective_output, "config.apb")])

        if self._no_upscaling:
            args.append("--no-upscaling")

        if self._k0_scaling:
            args.append("--k0-scaling")

        args.append(f"--sim-k0={self._sim_k0}")
        args.append(f"--time-factor={self._time_factor}")

        if self._resource_limits and self._resource_limits.num_workers is not None:
            args.append(f"--num-workers={self._resource_limits.num_workers}")

        args.append(effective_input)
        return args

    def run(
        self,
        input: Union[str, SympyODE],
        timeout: Optional[float] = None,
    ) -> CompilerResult:
        """Run the compiler on the given input.

        *input* may be a file path (str), an analang text string, or a
        ``SympyODE`` instance.  Strings that point to an existing file are
        used directly; all other strings are treated as inline analang text.

        If *timeout* is set (seconds), the underlying compiler subprocess or
        container is killed when it exceeds the limit and ``TimeoutError`` is
        raised. ``None`` (the default) waits indefinitely.
        """
        temp_input = None
        work_dir = None

        try:
            if isinstance(input, dict):
                raise TypeError(
                    "Dict input is no longer supported; "
                    "use a file path, analang text, or a SympyODE instance."
                )

            if isinstance(input, SympyODE):
                adapter = ODEAdapter()
                input = adapter.translate_sympy(input)

            if isinstance(input, str) and os.path.isfile(input):
                input_path = input
                if self._is_docker:
                    work_dir = tempfile.mkdtemp()
                    os.chmod(work_dir, 0o755)
                    copied_input = os.path.join(
                        work_dir, os.path.basename(input_path)
                    )
                    shutil.copy2(input_path, copied_input)
                    os.chmod(copied_input, 0o644)
                    input_path = copied_input
            else:
                analang_text = input
                if self._is_docker:
                    work_dir = tempfile.mkdtemp()
                    os.chmod(work_dir, 0o755)
                    import uuid
                    tmp_filename = f"input_{uuid.uuid4().hex[:8]}.ana"
                    tmp_path = os.path.join(work_dir, tmp_filename)
                    with open(tmp_path, "w") as f:
                        f.write(analang_text)
                        f.flush()
                        os.fsync(f.fileno())
                    os.chmod(tmp_path, 0o644)
                    input_path = tmp_path
                    temp_input = tmp_path
                else:
                    tf = tempfile.NamedTemporaryFile(
                        mode="w", suffix=".ana", delete=False
                    )
                    tf.write(analang_text)
                    tf.close()
                    input_path = tf.name
                    temp_input = tf.name

            container_output_dir = None
            container_input_path = None
            container_device_path = None
            volumes = None
            if self._is_docker:
                # Mount work_dir read-write for both input and output
                # This avoids issues with /tmp mounts in Docker
                container_output_dir = "/work"
                container_input_path = f"/work/{os.path.basename(input_path)}"
                if work_dir is None:
                    work_dir = tempfile.mkdtemp()
                volumes = {work_dir: "/work"}
                if self._device:
                    device_dir = os.path.dirname(os.path.abspath(self._device))
                    container_device_path = f"/device/{os.path.basename(self._device)}"
                    volumes[device_dir] = "/device"

            # For LocalExecutor, use output_dir directly (original behavior)
            # For Docker, use work_dir as the output source
            output_dir = work_dir or tempfile.mkdtemp()

            args = self._build_args(
                input_path=input_path,
                output_dir=output_dir,
                output_apb=True,
                container_output_dir=container_output_dir,
                container_input_path=container_input_path,
                container_device_path=container_device_path,
            )

            self._executor.ensure_available()
            exit_code, stdout, stderr = self._executor.run(
                args,
                input_file=None,
                output_dir=output_dir,
                volumes=volumes,
                timeout=timeout,
                resource_limits=self._resource_limits,
            )

            module = None

            apb_path = os.path.join(output_dir, "config.apb")
            if os.path.isfile(apb_path):
                with open(apb_path, "rb") as f:
                    file_msg = pb.File()
                    file_msg.ParseFromString(f.read())
                if file_msg.HasField("module"):
                    module = file_msg.module

            return CompilerResult(
                exit_code=exit_code,
                stdout=stdout,
                stderr=stderr,
                module=module,
            )
        finally:
            if temp_input and os.path.isfile(temp_input):
                os.unlink(temp_input)
            if work_dir:
                shutil.rmtree(work_dir, ignore_errors=True)
