import subprocess
import sys
import time
from typing import Optional

from .executor import DockerExecutor, LocalExecutor


class Simulator:
    """Lifecycle manager for the pybrid-compatible simulation server.

    Launches the simulator as a background Docker container (default) or local
    subprocess, exposing ``host`` and ``port`` for client connections.  Use as
    a context manager for automatic cleanup.
    """

    def __init__(
        self,
        executable: Optional[str] = None,
        image_name: str = "redacc-simulator",
        image_tag: str = "latest",
        port: int = 5732,
        plugins_dir: Optional[str] = None,
        always_pull: bool = True,
        debug: bool = False,
    ):
        self._port = port
        self._executable = executable
        self._debug = debug
        self._container_id: Optional[str] = None
        self._process: Optional[subprocess.Popen] = None

        if executable:
            self._executor = LocalExecutor(executable=executable, plugins_dir=plugins_dir)
        else:
            self._executor = DockerExecutor(
                image_name=image_name,
                image_tag=image_tag,
                plugins_dir=plugins_dir,
                always_pull=always_pull,
            )

    @property
    def host(self) -> str:
        return "127.0.0.1"

    @property
    def port(self) -> int:
        return self._port

    def start(self) -> None:
        """Launch the simulator as a background process."""
        self._executor.ensure_available()
        args = ["--port", str(self._port)]

        if self._executable:
            self._process = subprocess.Popen(
                [self._executable] + args,
                stdout=subprocess.PIPE if self._debug else subprocess.DEVNULL,
                stderr=subprocess.PIPE if self._debug else subprocess.DEVNULL,
            )
        else:
            self._container_id = self._executor.run_detached(
                args,
                ports={f"{self._port}/tcp": self._port},
            )

        time.sleep(2)  # allow the server to bind its listening socket

    def _print_debug_output(self, stdout: str, stderr: str) -> None:
        """Print captured stdout/stderr to sys.stderr for debugging."""
        if stdout:
            sys.stderr.write(f"--- simulator stdout ---\n{stdout}\n")
        if stderr:
            sys.stderr.write(f"--- simulator stderr ---\n{stderr}\n")

    def stop(self) -> None:
        """Stop the background simulator."""
        if self._container_id is not None:
            import docker

            client = docker.from_env()
            try:
                container = client.containers.get(self._container_id)
                if self._debug:
                    stdout = container.logs(stdout=True, stderr=False).decode(
                        "utf-8", errors="replace"
                    )
                    stderr = container.logs(stdout=False, stderr=True).decode(
                        "utf-8", errors="replace"
                    )
                    self._print_debug_output(stdout, stderr)
                container.stop(timeout=5)
                container.remove(force=True)
            except docker.errors.NotFound:
                pass
            self._container_id = None

        if self._process is not None:
            self._process.terminate()
            try:
                self._process.wait(timeout=10)
            except subprocess.TimeoutExpired:
                self._process.kill()
                self._process.wait()
            if self._debug:
                stdout = self._process.stdout.read().decode(
                    "utf-8", errors="replace"
                )
                stderr = self._process.stderr.read().decode(
                    "utf-8", errors="replace"
                )
                self._print_debug_output(stdout, stderr)
            self._process = None

    def __enter__(self) -> "Simulator":
        self.start()
        return self

    def __exit__(self, *exc) -> None:
        self.stop()
