from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, List, Optional

import pybrid.base.proto.main_pb2 as pb

try:
    import sympy as sp

    _HAS_SYMPY = True
except ImportError:
    _HAS_SYMPY = False


if _HAS_SYMPY:

    class Prod(sp.Function):
        """Non-associative binary product for analog circuit grouping.

        Standard ``*`` is associative in SymPy and flattens nested products.
        Use ``@`` (which maps to ``Prod``) when multiplication grouping must
        be preserved for correct analog circuit routing::

            # These produce different circuit topologies:
            (a @ b) @ c   # ((a*b)*c)  — two sequential multipliers
            a @ (b @ c)   # (a*(b*c))  — different routing

        ``Prod`` is a regular SymPy ``Function`` with ``nargs=2``, so it
        participates in differentiation, substitution, etc.
        """

        nargs = 2

    sp.Expr.__matmul__ = lambda self, other: Prod(self, other)
    sp.Expr.__rmatmul__ = lambda self, other: Prod(other, self)


class Backend(Enum):
    LANE = "lane"
    NETWORK = "network"


@dataclass
class SympyODE:
    """Represents an ODE system defined via SymPy expressions."""

    odes: list
    initial_conditions: dict
    probes: list
    name: Optional[str] = None


@dataclass
class ResourceLimits:
    """Caps applied to the redacc compiler subprocess.

    ``num_workers`` is forwarded as ``--or-num-workers`` so OR-Tools'
    CP-SAT solver respects it. ``memory_gb`` becomes a ``RLIMIT_AS``
    (virtual memory) cap on the child process.

    A ``None`` field means "do not constrain this dimension".
    """

    num_workers: Optional[int] = None
    memory_gb: Optional[float] = None


@dataclass
class CompilerResult:
    """Result of a redacc compilation run.

    After a successful compilation, ``module`` contains the compiled protobuf
    ``Module`` directly.  Use the ``configuration`` and ``specification``
    properties for convenient access to the most commonly needed fields.

    Instances can be persisted via ``save()`` and restored via ``from_file()``;
    the resulting ``.apb`` files are compatible with pybrid's ``ProtoIO``.
    """

    exit_code: int
    stdout: str
    stderr: str
    module: pb.Module | None = None

    @property
    def configuration(self) -> list[pb.Item]:
        """Hardware configuration list, ready for pybrid's deserializer.

        Filters out ``EntitySpecification`` entries from the module — those
        represent device specifications, not hardware configuration.
        """
        if self.module is None:
            return []
        return [c for c in self.module.items
                if not c.HasField("entity_specification")]

    @property
    def specification(self) -> list[pb.Entity]:
        """Device specification entities for pybrid's ``add_device()``.

        Extracts the ``Entity`` from each ``EntitySpecification`` entry in
        the module.
        """
        if self.module is None:
            return []
        return [c.entity_specification.entity for c in self.module.items
                if c.HasField("entity_specification")]

    def save(self, path: str) -> None:
        """Save the compiled output to an ``.apb`` protobuf file.

        Wraps the ``Module`` in a ``pb.File`` envelope for compatibility
        with pybrid's ``ProtoIO.open_pb_file()``.

        Args:
            path: Destination file path (should end in ``.apb``).

        Raises:
            ValueError: If no compiled output is available.
        """
        if self.module is None:
            raise ValueError("No compiled output to save.")
        file_msg = pb.File(module=self.module)
        with open(path, "wb") as f:
            f.write(file_msg.SerializeToString())

    @classmethod
    def from_file(cls, path: str) -> "CompilerResult":
        """Load a ``CompilerResult`` from a previously saved ``.apb`` file.

        Process metadata (``exit_code``, ``stdout``, ``stderr``) is not
        stored in the protobuf format; they default to neutral values.

        Args:
            path: Path to an ``.apb`` file containing a serialised ``pb.File``.

        Returns:
            A ``CompilerResult`` with the loaded protobuf data.
        """
        file_msg = pb.File()
        with open(path, "rb") as f:
            file_msg.ParseFromString(f.read())
        module = file_msg.module if file_msg.HasField("module") else None
        return cls(exit_code=0, stdout="", stderr="", module=module)


