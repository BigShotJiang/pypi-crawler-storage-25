"""
Simple CLI forwarding all given arguments to Docker containers. Allows users
to run both compiler and simulator from the CLI, freeing them from the burden
of updating their installation.
"""
import sys
import time

import typer
from typing import Annotated
from yaspin import yaspin
from yaspin.spinners import Spinners

from .compiler import Backend
from .registry import DockerRegistry

app = typer.Typer(
    help="Compile ODEs and run simulations for anabrid analog computers."
)
try:
    DockerRegistry.from_env()
except:
    print("Make sure to set CI_REGISTRY_USER and CI_REGISTRY_PASSWORD variables " +
        "for access to the Docker registry.")
    exit(1)

@app.command()
def compile(
    input: Annotated[
        str,
        typer.Argument(help="Path to an .ana analang source file")
    ],
    backend: Annotated[
        Backend,
        typer.Option(
            case_sensitive=False,
            help="LANE for LUCIDAC, NETWORK for REDAC"
        )
    ],
    device: Annotated[
        str,
        typer.Option(
            help="Path to a device specification in .apb format"
        )
    ],
    output: Annotated[
        str,
        typer.Option(
            help="Path to output artifact, format is .apb"
        )
    ],
    plugins_dir: Annotated[
        str,
        typer.Option(
            help="Paths to directories containing plugins"
        )
    ] = None,
    pull: Annotated[
        bool,
        typer.Option(
            help="Whether to always pull the most recent compiler image before using"
        )
    ] = True
):
    """Compile an ODE description to an analog hardware configuration."""
    from .compiler import Compiler

    compiler = Compiler(
        backend=backend,
        device=device,
        plugins_dir=plugins_dir,
        always_pull=pull
    )

    with yaspin(Spinners.dots, text="Compiling...") as sp:
        try:
            result = compiler.run(input=input)
            if result.exit_code == 0:
                sp.ok("✔")
            else:
                sp.fail("✘")
        except Exception as e:
            sp.fail("✘")
            sys.stderr.write(f"{e}\n")
            raise typer.Exit(code=1)

    if result.stdout:
        typer.echo(result.stdout.rstrip())

    if result.exit_code != 0:
        if result.stderr:
            sys.stderr.write(result.stderr)
        raise typer.Exit(code=result.exit_code)

    with yaspin(Spinners.dots, text=f"Saving to {output}...") as sp:
        try:
            result.save(output)
            sp.ok("✔")
        except Exception as e:
            sp.fail("✘")
            sys.stderr.write(f"{e}\n")
            raise typer.Exit(code=1)


@app.command()
def simulate(
    port: Annotated[
        int,
        typer.Option(
            help="Port to listen on"
        )
    ] = 5732,
    token: Annotated[
        str,
        typer.Option(
            help="If set, requires authentication by the client"
        )
    ] = None,
    plugins_dir: Annotated[
        str,
        typer.Option(
            help="Path to directory containing compiled plugins"
        )
    ] = None,
    pull: Annotated[
        bool,
        typer.Option(
            help="Whether to always pull the most recent simulator image before using"
        )
    ] = True
):
    """Run the simulator in the foreground until stopped with Ctrl+C."""
    from .simulator import Simulator

    sim = Simulator(
        port=port,
        plugins_dir=plugins_dir,
        always_pull=pull
    )

    with yaspin(Spinners.dots, text="Starting simulator...") as sp:
        try:
            sim.start()
            sp.ok("✔")
        except Exception as e:
            sp.fail("✘")
            sys.stderr.write(f"{e}\n")
            raise typer.Exit(code=1)

    typer.echo(f"Simulator listening on port {port}. Press Ctrl+C to stop.")

    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        pass

    with yaspin(Spinners.dots, text="Stopping simulator...") as sp:
        sim.stop()
        sp.ok("✔")


if __name__ == "__main__":
    typer.run(app)
