import uuid

import sympy as sp
from sympy import Function, Derivative, Symbol, Eq, solve
from typing import Dict, List, Union

from .types import Prod, SympyODE


class ODEAdapter:
    """Translate SymPy ODE expressions to the analang format used by redacc."""

    class _CustomPrinter(sp.StrPrinter):
        """Format SymPy expressions using analang syntax."""

        def __init__(self, implicit_variable: str = "t"):
            super().__init__()
            self.implicit_variable = implicit_variable

        def _print_Function(self, expr):
            return f"{expr.func.__name__}({self.implicit_variable})"

        def _print_Derivative(self, expr):
            function = expr.args[0]
            variables = expr.args[1:]
            order = 0
            t_sym = Symbol(self.implicit_variable)
            for v in variables:
                if isinstance(v, sp.core.containers.Tuple):
                    var, count = v
                    if var == t_sym:
                        order += count
                else:
                    if v == t_sym:
                        order += 1
            func_name = function.func.__name__
            return (
                "diff["
                + func_name
                + ", "
                + ", ".join([self.implicit_variable] * order)
                + "]("
                + self.implicit_variable
                + ")"
            )

        def _print_Mul(self, expr):
            """Group non-numeric factors when a numeric coefficient is present.

            Analang's ``*`` is binary and left-associative, so ``c*f1*f2``
            parses as ``(c*f1)*f2``.  For analog circuits we need
            ``c*(f1*f2)`` to keep the product as one operation.
            """
            coeff, rest = expr.as_coeff_Mul()
            if coeff == 1 or not rest.is_Mul:
                return super()._print_Mul(expr)
            rest_str = super()._print_Mul(rest)
            if coeff == -1:
                return f"-({rest_str})"
            return f"{self._print(coeff)}*({rest_str})"

        def _print_Prod(self, expr):
            """Print non-associative binary product as ``(left*right)``."""
            left = self._print(expr.args[0])
            right = self._print(expr.args[1])
            return f"({left}*{right})"

        def _print_Abs(self, expr):
            return "abs(%s)" % self._print(expr.args[0])

    def __init__(self, implicit_variable: str = "t"):
        self.implicit_variable = implicit_variable

    def translate_sympy(self, sympy_ode: SympyODE) -> str:
        """Translate a SympyODE instance to analang text."""
        ic_str = {
            f.func.__name__ if hasattr(f, "func") else str(f): v
            for f, v in sympy_ode.initial_conditions.items()
        }
        printer = ODEAdapter._CustomPrinter(self.implicit_variable)
        probes_str = []
        for p in sympy_ode.probes:
            if isinstance(p, Derivative):
                probes_str.append(printer.doprint(p))
            elif hasattr(p, "func"):
                probes_str.append(p.func.__name__)
            else:
                probes_str.append(str(p))
        return self.translate(
            odes=sympy_ode.odes,
            initial_conditions=ic_str,
            probes=probes_str,
            name=sympy_ode.name or str(uuid.uuid4()),
        )

    def translate(
        self,
        odes: Union[List[sp.Eq], sp.Eq],
        initial_conditions: Dict[str, float],
        probes: List[str],
        name: str = "unnamed",
    ) -> str:
        """Build analang text from SymPy equations.

        Raises ``TypeError`` if *odes* is a dict (no longer supported).
        Raises ``ValueError`` if initial conditions or probes are incomplete.
        """
        if isinstance(odes, dict):
            raise TypeError(
                "Dict input is no longer supported; "
                "use SymPy equations or analang files."
            )

        if isinstance(odes, Eq):
            odes = [odes]

        functions = self._extract_functions(odes)
        equations = self._build_equations(odes)

        for f in functions:
            if f not in initial_conditions:
                raise ValueError(
                    f"Initial condition missing for function '{f}'"
                )

        func_set = set(functions)
        for p in probes:
            if p.startswith("diff["):
                base = p[5:p.index(",")].strip()
            else:
                base = p
            if base not in func_set:
                raise ValueError(
                    f"Probe '{p}' does not match any known function"
                )

        lines = ["use display;", "use math;"]

        for lhs, rhs in equations.items():
            lines.append(f"let {lhs} = {rhs};")

        for f, v in initial_conditions.items():
            lines.append(
                f"let {f}({self.implicit_variable}: 0) = {v};"
            )

        for p in probes:
            if p.startswith("diff["):
                lines.append(f"probe {p};")
            else:
                lines.append(f"probe {p}({self.implicit_variable});")

        return "\n".join(lines) + "\n"

    def _extract_functions(self, odes: List[sp.Eq]) -> List[str]:
        """Extract the names of all undefined functions from the ODEs."""
        functions = set()
        for ode in odes:
            for atom in ode.atoms(Function):
                if not isinstance(atom, Derivative):
                    if isinstance(
                        atom.func, sp.core.function.UndefinedFunction
                    ):
                        functions.add(atom.func.__name__)
        return sorted(functions)

    def _build_equations(self, odes: List[sp.Eq]) -> Dict[str, str]:
        """Solve each ODE for its highest derivative and return as string pairs."""
        printer = ODEAdapter._CustomPrinter(self.implicit_variable)
        eqs = {}

        for ode in odes:
            derivatives = list(ode.atoms(Derivative))
            if not derivatives:
                raise ValueError("No derivatives found in the ODE")

            highest = max(derivatives, key=lambda d: d.derivative_count)

            if isinstance(ode, Eq):
                expr = ode.lhs - ode.rhs
            else:
                expr = ode

            solution = solve(expr, highest, simplify=False)
            if not solution:
                raise ValueError("Could not solve for the highest derivative")

            lhs_str = printer.doprint(highest)
            rhs_str = printer.doprint(solution[0])
            eqs[lhs_str] = rhs_str

        return eqs
