import logging
import os
import resource
import subprocess
import sys
from abc import ABC, abstractmethod
from typing import Callable, Dict, List, Optional, Tuple

from .registry import DockerRegistry
from .types import ResourceLimits

logger = logging.getLogger(__name__)


def _build_preexec_fn(limits: Optional[ResourceLimits]) -> Optional[Callable[[], None]]:
    """Return a child-side callback that applies a virtual-memory cap, or None.

    Only ``memory_gb`` translates to a setrlimit call (``RLIMIT_AS``);
    ``num_workers`` is forwarded to redacc as ``--or-num-workers`` and
    enforced inside OR-Tools. Runs after fork() and before exec().
    """
    if limits is None or limits.memory_gb is None:
        return None

    memory_bytes = int(limits.memory_gb * 1024**3)

    def _apply() -> None:
        resource.setrlimit(resource.RLIMIT_AS, (memory_bytes, memory_bytes))

    return _apply


def _path_in_volumes(path: str, volumes: Optional[Dict[str, str]]) -> bool:
    """Check if a path is covered by any volume mount."""
    if not volumes:
        return False
    abs_path = os.path.abspath(path)
    for host_path in volumes:
        abs_host = os.path.abspath(host_path)
        # Check if path is inside the host mount point
        if abs_path.startswith(abs_host + os.sep) or abs_path == abs_host:
            return True
    return False


class BaseExecutor(ABC):
    """Interface for running the redacc binary (Docker or local)."""

    @abstractmethod
    def ensure_available(self) -> None:
        """Verify the execution backend is ready (image pulled / binary exists)."""
        ...

    @abstractmethod
    def run(
        self,
        args: List[str],
        input_file: Optional[str],
        output_dir: Optional[str],
        volumes: Optional[Dict[str, str]],
        timeout: Optional[float] = None,
        resource_limits: Optional[ResourceLimits] = None,
    ) -> Tuple[int, str, str]:
        ...

    @abstractmethod
    def run_detached(
        self,
        args: List[str],
        ports: Optional[Dict[str, int]] = None,
    ) -> str:
        ...


class DockerExecutor(BaseExecutor):
    """Run redacc inside a Docker container pulled from the configured registry."""

    def __init__(
        self,
        image_name: str,
        image_tag: str = "latest",
        plugins_dir: Optional[str] = None,
        always_pull: bool = True,
    ):
        self._image_name = image_name
        self._image_tag = image_tag
        self._plugins_dir = plugins_dir
        self._always_pull = always_pull

        import docker
        self._docker = docker
        self._client = None

    def _get_client(self):
        if self._client is None:
            try:
                self._client = self._docker.from_env()
            except self._docker.errors.DockerException as e:
                raise ConnectionError(
                    f"Cannot connect to Docker daemon. Is Docker running? "
                    f"Original error: {e}"
                ) from e
        return self._client

    @property
    def full_image_name(self) -> str:
        registry_url = DockerRegistry._get().url
        if registry_url:
            return f"{registry_url}/{self._image_name}:{self._image_tag}"
        return f"{self._image_name}:{self._image_tag}"

    def _format_bytes(self, num_bytes: int) -> str:
        """Format bytes as human-readable string."""
        for unit in ["B", "KB", "MB", "GB", "TB"]:
            if abs(num_bytes) < 1024.0:
                return f"{num_bytes:.1f} {unit}"
            num_bytes /= 1024.0
        return f"{num_bytes:.1f} PB"

    def _pull_with_progress(self, image_name: str) -> None:
        """Pull an image with progress feedback to stderr."""
        repo, tag = image_name.rsplit(":", 1)

        is_tty = sys.stderr.isatty()
        layer_totals: Dict[str, int] = {}
        layer_current: Dict[str, int] = {}
        layers_complete = set()

        events = self._get_client().api.pull(repo, tag=tag, stream=True, decode=True)

        for event in events:
            status = event.get("status", "")
            layer_id = event.get("id", "")

            if status.startswith("Status: Image is up to date"):
                return

            if status.startswith("Status: Downloaded newer image"):
                if is_tty:
                    sys.stderr.write("\n")
                sys.stderr.write(f"Image {image_name}: {status}\n")
                return

            if status == "Already exists":
                if layer_id:
                    layers_complete.add(layer_id)
                continue

            # Track layer totals from progressDetail
            progress_detail = event.get("progressDetail", {})
            if progress_detail:
                current = progress_detail.get("current", 0)
                total = progress_detail.get("total", 0)
                if layer_id:
                    layer_totals[layer_id] = total
                    layer_current[layer_id] = current

            # Calculate total progress
            total_bytes = sum(layer_totals.values())
            current_bytes = sum(layer_current[lid] for lid in layer_totals if lid not in layers_complete)

            if is_tty and total_bytes > 0:
                # Update progress on same line
                sys.stderr.write(f"\rPulling {image_name}: {self._format_bytes(current_bytes)}/{self._format_bytes(total_bytes)}")
                sys.stderr.flush()
            elif not is_tty and total_bytes > 0:
                # Non-TTY: print status updates
                if status in ("Downloading", "Extracting"):
                    sys.stderr.write(f"Pulling {image_name}: {self._format_bytes(current_bytes)}/{self._format_bytes(total_bytes)}\n")
                    sys.stderr.flush()

            # Mark layer as complete
            if status == "Pull complete" and layer_id:
                layers_complete.add(layer_id)

        if is_tty and total_bytes > 0:
            sys.stderr.write("\n")
        sys.stderr.write(f"Image {image_name} pulled successfully\n")

    def ensure_available(self) -> None:
        DockerRegistry._get().login(self._get_client())
        # Only check if image exists locally when not always pulling
        if not self._always_pull:
            try:
                self._get_client().images.get(self.full_image_name)
                # Image exists and we're not set to always pull
                return
            except self._docker.errors.ImageNotFound:
                pass  # Image doesn't exist, will pull below

        # Pull the image with progress
        self._pull_with_progress(self.full_image_name)

    def run(
        self,
        args: List[str],
        input_file: Optional[str],
        output_dir: Optional[str],
        volumes: Optional[Dict[str, str]],
        timeout: Optional[float] = None,
        resource_limits: Optional[ResourceLimits] = None,
    ) -> Tuple[int, str, str]:
        if resource_limits is not None and (
            resource_limits.num_workers is not None
            or resource_limits.memory_gb is not None
        ):
            logger.debug(
                "DockerExecutor ignores host-level ResourceLimits; "
                "use docker engine mem_limit / cpus for container caps."
            )
        bind_volumes = {}
        if volumes:
            for host_path, container_path in volumes.items():
                bind_volumes[host_path] = {"bind": container_path, "mode": "rw"}
        # Only mount input_file separately if not already covered by custom volumes
        if input_file and not _path_in_volumes(input_file, volumes):
            bind_volumes[input_file] = {"bind": f"/work/{os.path.basename(input_file)}", "mode": "ro"}
        # Only mount output_dir to /output if it's not already covered by a custom volume
        if output_dir and output_dir not in volumes:
            bind_volumes[output_dir] = {"bind": "/output", "mode": "rw"}
        if self._plugins_dir:
            bind_volumes[self._plugins_dir] = {"bind": "/plugins", "mode": "ro"}

        container = self._get_client().containers.run(
            self.full_image_name,
            command=args,
            volumes=bind_volumes,
            detach=True,
            user="root",  # Run as root to ensure write permissions on mounted volumes
        )

        import requests
        try:
            wait_kwargs = {}
            if timeout is not None:
                wait_kwargs["timeout"] = timeout
            try:
                result = container.wait(**wait_kwargs)
            except (requests.exceptions.ReadTimeout,
                    requests.exceptions.ConnectionError) as e:
                # docker-py forwards urllib3's ReadTimeoutError as either a
                # ReadTimeout or a ConnectionError whose message contains
                # "Read timed out". Non-timeout ConnectionErrors are propagated.
                is_timeout = (
                    isinstance(e, requests.exceptions.ReadTimeout)
                    or "timed out" in str(e).lower()
                )
                if not is_timeout:
                    raise
                try:
                    container.kill()
                except Exception:
                    pass
                raise TimeoutError(
                    f"Compiler container timed out after {timeout}s"
                ) from e
            exit_code = result.get("StatusCode", -1)
            stdout = container.logs(stdout=True, stderr=False).decode("utf-8", errors="replace")
            stderr = container.logs(stdout=False, stderr=True).decode("utf-8", errors="replace")
        finally:
            container.remove(force=True)

        return exit_code, stdout, stderr

    def run_detached(
        self,
        args: List[str],
        ports: Optional[Dict[str, int]] = None,
    ) -> str:
        bind_volumes = {}
        if self._plugins_dir:
            bind_volumes[self._plugins_dir] = {"bind": "/plugins", "mode": "ro"}

        container = self._get_client().containers.run(
            self.full_image_name,
            command=args,
            volumes=bind_volumes,
            ports=ports or {},
            detach=True,
            environment={
                "REDACC_SIM_PLUGINS_PATH": "/plugins"
            }
        )

        return container.id


class LocalExecutor(BaseExecutor):
    """Run redacc as a local subprocess."""

    def __init__(
        self,
        executable: str,
        plugins_dir: Optional[str] = None,
    ):
        self._executable = executable
        self._plugins_dir = plugins_dir

    def ensure_available(self) -> None:
        if not os.path.isfile(self._executable):
            raise FileNotFoundError(f"Executable not found: {self._executable}")
        if not os.access(self._executable, os.X_OK):
            raise PermissionError(f"Not executable: {self._executable}")

    def run(
        self,
        args: List[str],
        input_file: Optional[str],
        output_dir: Optional[str],
        volumes: Optional[Dict[str, str]],
        timeout: Optional[float] = None,
        resource_limits: Optional[ResourceLimits] = None,
    ) -> Tuple[int, str, str]:
        cmd = [self._executable] + args
        if input_file:
            cmd.append(input_file)

        preexec_fn = _build_preexec_fn(resource_limits)

        try:
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                cwd=output_dir,
                timeout=timeout,
                env={
                    "REDACC_SIM_PLUGINS_PATH": self._plugins_dir
                } if self._plugins_dir else {},
                preexec_fn=preexec_fn,
            )
        except subprocess.TimeoutExpired as e:
            # subprocess.run already killed the child before re-raising.
            raise TimeoutError(
                f"Compiler subprocess timed out after {e.timeout}s"
            ) from e

        return result.returncode, result.stdout, result.stderr

    def run_detached(
        self,
        args: List[str],
        ports: Optional[Dict[str, int]] = None,
    ) -> str:
        raise NotImplementedError("Background mode not supported for local execution")
