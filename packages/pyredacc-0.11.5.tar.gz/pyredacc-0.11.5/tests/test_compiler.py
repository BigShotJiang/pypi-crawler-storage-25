import os
from unittest.mock import MagicMock, patch

import pytest

from pyredacc.compiler import Compiler
from pyredacc.types import Backend, ResourceLimits


class TestBuildArgs:
    def test_build_args_defaults(self):
        compiler = Compiler(backend=Backend.LANE)
        args = compiler._build_args("/tmp/input.ana", "/tmp/output")

        assert "--backend" in args
        backend_idx = args.index("--backend")
        assert args[backend_idx + 1] == "LANE"
        assert args[-1] == "/tmp/input.ana"

    def test_build_args_all_options(self):
        compiler = Compiler(
            backend=Backend.LANE,
            device="/etc/redacc/that.json",
        )
        args = compiler._build_args(
            "/tmp/input.ana",
            "/tmp/output"
        )

        assert "--backend" in args
        assert "--entity" in args
        assert "--output" in args
        assert args[-1] == "/tmp/input.ana"

    def test_build_args_backend_network(self):
        compiler = Compiler(backend=Backend.NETWORK)
        args = compiler._build_args("/tmp/input.ana", "/tmp/output")

        backend_idx = args.index("--backend")
        assert args[backend_idx + 1] == "NETWORK"

    def test_build_args_with_entity(self):
        compiler = Compiler(
            backend=Backend.LANE,
            device="/etc/redacc/lucidac.json",
        )
        args = compiler._build_args("/tmp/input.ana", "/tmp/output")

        assert "--entity" in args
        entity_idx = args.index("--entity")
        assert args[entity_idx + 1] == "/etc/redacc/lucidac.json"

    def test_build_args_with_device(self):
        compiler = Compiler(
            backend=Backend.LANE,
            device="/etc/redacc/lucidac.json",
        )
        args = compiler._build_args("/tmp/input.ana", "/tmp/output")

        assert "--entity" in args
        entity_idx = args.index("--entity")
        assert args[entity_idx + 1] == "/etc/redacc/lucidac.json"
        assert args[-1] == "/tmp/input.ana"

    def test_build_args_device_uses_container_path(self):
        compiler = Compiler(
            backend=Backend.LANE,
            device="/host/devices/lucidac.json",
        )
        args = compiler._build_args(
            "/tmp/input.ana",
            "/tmp/output",
            container_device_path="/device/lucidac.json",
        )

        entity_idx = args.index("--entity")
        assert args[entity_idx + 1] == "/device/lucidac.json"

    def test_build_args_includes_or_num_workers_when_set(self):
        compiler = Compiler(
            backend=Backend.LANE,
            resource_limits=ResourceLimits(num_workers=8),
        )
        args = compiler._build_args("/tmp/input.ana", "/tmp/output")
        assert "--num-workers=8" in args

    def test_build_args_omits_or_num_workers_when_unset(self):
        compiler = Compiler(backend=Backend.LANE)
        args = compiler._build_args("/tmp/input.ana", "/tmp/output")
        assert not any(a.startswith("--num-workers") for a in args)

    def test_build_args_omits_or_num_workers_when_only_memory_set(self):
        compiler = Compiler(
            backend=Backend.LANE,
            resource_limits=ResourceLimits(memory_gb=4.0),
        )
        args = compiler._build_args("/tmp/input.ana", "/tmp/output")
        assert not any(a.startswith("--num-workers") for a in args)


def _make_compiler_with_mock_executor(exit_code=0, stdout="", stderr="", raise_exc=None):
    compiler = Compiler(backend=Backend.LANE, executable="/usr/bin/redacc")
    mock_executor = MagicMock()
    mock_executor.ensure_available.return_value = None
    if raise_exc is not None:
        mock_executor.run.side_effect = raise_exc
    else:
        mock_executor.run.return_value = (exit_code, stdout, stderr)
    compiler._executor = mock_executor
    compiler._is_docker = False
    return compiler, mock_executor


class TestTimeout:
    def test_default_timeout_is_none(self):
        """Compiler.run without timeout forwards timeout=None to executor."""
        compiler, mock_executor = _make_compiler_with_mock_executor()

        compiler.run("x' = -x")

        assert mock_executor.run.called
        kwargs = mock_executor.run.call_args.kwargs
        assert kwargs.get("timeout") is None

    def test_timeout_forwarded_to_executor(self):
        """A timeout value passed to Compiler.run is forwarded to the executor."""
        compiler, mock_executor = _make_compiler_with_mock_executor()

        compiler.run("x' = -x", timeout=5.0)

        kwargs = mock_executor.run.call_args.kwargs
        assert kwargs.get("timeout") == 5.0

    def test_timeout_propagates_and_cleans_up(self, tmp_path):
        """When the executor raises TimeoutError, Compiler.run re-raises it and still removes tempfiles."""
        compiler, mock_executor = _make_compiler_with_mock_executor(
            raise_exc=TimeoutError("compiler timed out after 1.0s")
        )

        with pytest.raises(TimeoutError, match="timed out"):
            compiler.run("x' = -x", timeout=1.0)

        # The inline analang source should have produced a temp input file that is cleaned up.
        # We can't know its exact path, but /tmp should not contain any leftover input_*.ana that was just created.
        # The real guarantee tested here is that no exception escapes the finally block.


class TestResourceLimitsForwarding:
    def test_compiler_run_forwards_resource_limits_to_executor(self):
        limits = ResourceLimits(num_workers=4, memory_gb=2.0)
        compiler, mock_executor = _make_compiler_with_mock_executor()
        compiler._resource_limits = limits

        compiler.run("x' = -x")

        kwargs = mock_executor.run.call_args.kwargs
        assert kwargs.get("resource_limits") is limits

    def test_compiler_run_forwards_none_when_no_limits(self):
        compiler, mock_executor = _make_compiler_with_mock_executor()

        compiler.run("x' = -x")

        kwargs = mock_executor.run.call_args.kwargs
        assert kwargs.get("resource_limits") is None
