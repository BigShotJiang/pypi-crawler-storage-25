import re
from pathlib import Path

import sympy as sp
import pytest

from pyredacc.ode_adapter import ODEAdapter
from pyredacc.types import Prod, SympyODE

ANALANG_DIR = Path(__file__).resolve().parents[4] / "examples" / "analang"


class TestODEAdapterTranslate:

    def test_translate_returns_string(self, decay_system):
        ode, ics, probes = decay_system
        adapter = ODEAdapter()
        result = adapter.translate(ode, ics, probes, name="decay")
        assert isinstance(result, str)

    def test_translate_simple_decay(self, decay_system):
        ode, ics, probes = decay_system
        adapter = ODEAdapter()
        result = adapter.translate(ode, ics, probes, name="decay")

        assert "let diff[X, t](t) =" in result
        assert "let X(t: 0) = 1.0" in result
        assert "probe X(t);" in result

    def test_translate_lorenz(self, lorenz_system):
        odes, ics, probes = lorenz_system
        adapter = ODEAdapter()
        result = adapter.translate(odes, ics, probes, name="lorenz")

        assert result.count("let diff[") == 3
        assert "let X(t: 0) =" in result
        assert "let Y(t: 0) =" in result
        assert "let Z(t: 0) =" in result
        assert "probe X(t);" in result
        assert "probe Y(t);" in result
        assert "probe Z(t);" in result
        assert "sigma" in result
        assert "rho" in result
        assert "beta" in result

    def test_translate_preserves_casing(self):
        t = sp.Symbol("t")
        MyFunc = sp.Function("MyFunc")
        ode = sp.Eq(MyFunc(t).diff(t), -MyFunc(t))
        adapter = ODEAdapter()
        result = adapter.translate(ode, {"MyFunc": 0.5}, ["MyFunc"])

        assert "MyFunc" in result
        assert "probe MyFunc(t);" in result

    def test_translate_missing_ic_raises(self):
        t = sp.Symbol("t")
        X = sp.Function("X")
        ode = sp.Eq(X(t).diff(t), -X(t))
        adapter = ODEAdapter()

        with pytest.raises(ValueError, match="[Ii]nitial condition"):
            adapter.translate(ode, {}, ["X"])

    def test_translate_missing_probe_raises(self):
        t = sp.Symbol("t")
        X = sp.Function("X")
        ode = sp.Eq(X(t).diff(t), -X(t))
        adapter = ODEAdapter()

        with pytest.raises(ValueError, match="[Pp]robe"):
            adapter.translate(ode, {"X": 1.0}, ["NonExistent"])

    def test_translate_preamble(self, decay_system):
        ode, ics, probes = decay_system
        adapter = ODEAdapter()
        result = adapter.translate(ode, ics, probes)

        assert result.startswith("use display;\nuse math;\n")

    def test_translate_second_order(self):
        t = sp.Symbol("t")
        h = sp.Function("h")
        ode = sp.Eq(h(t).diff(t, 2), -h(t))
        adapter = ODEAdapter()
        result = adapter.translate(ode, {"h": 0.42}, ["h"])

        assert "let diff[h, t, t](t) =" in result
        assert "let h(t: 0) = 0.42" in result

    def test_translate_sympy_ode(self):
        t = sp.Symbol("t")
        X = sp.Function("X")
        ode = sp.Eq(X(t).diff(t), -X(t))
        sympy_ode = SympyODE(
            odes=[ode],
            initial_conditions={X(t): 1.0},
            probes=[X(t)],
            name="test_system",
        )
        adapter = ODEAdapter()
        result = adapter.translate_sympy(sympy_ode)

        assert isinstance(result, str)
        assert "let diff[X, t](t) =" in result
        assert "probe X(t);" in result

    def test_translate_does_not_accept_dict(self):
        raw = {"name": "prebuilt", "equations": {}}
        adapter = ODEAdapter()

        with pytest.raises(TypeError):
            adapter.translate(raw, {}, [])


class TestMulParenthesization:
    """Numeric coefficients times products of functions must be parenthesized
    so the analang parser sees binary multiplication, not left-to-right flat
    chaining."""

    @staticmethod
    def _rhs_of(result: str, diff_key: str) -> str:
        """Extract the RHS string from 'let <diff_key> = <rhs>;'."""
        line = next(l for l in result.splitlines() if diff_key in l)
        return line.split("=", 1)[1].strip().rstrip(";").strip()

    def test_negative_coeff_with_two_function_product(self):
        t = sp.Symbol("t")
        U, V, W = sp.Function("U"), sp.Function("V"), sp.Function("W")
        ode = sp.Eq(U(t).diff(t), -10.0 * (W(t) * V(t)))
        adapter = ODEAdapter()
        result = adapter.translate(
            ode, {"U": 0.0, "V": 0.0, "W": 0.0}, ["U"]
        )
        rhs = self._rhs_of(result, "diff[U, t](t)")
        assert re.match(
            r"-10\.0\*\((V\(t\)\*W\(t\)|W\(t\)\*V\(t\))\)$", rhs
        ), f"Expected parenthesized product, got: {rhs}"

    def test_positive_coeff_with_two_function_product(self):
        t = sp.Symbol("t")
        U, V, W = sp.Function("U"), sp.Function("V"), sp.Function("W")
        ode = sp.Eq(V(t).diff(t), 10.0 * (W(t) * U(t)))
        adapter = ODEAdapter()
        result = adapter.translate(
            ode, {"U": 0.0, "V": 0.0, "W": 0.0}, ["V"]
        )
        rhs = self._rhs_of(result, "diff[V, t](t)")
        assert re.match(
            r"10\.0\*\((U\(t\)\*W\(t\)|W\(t\)\*U\(t\))\)$", rhs
        ), f"Expected parenthesized product, got: {rhs}"

    def test_coeff_with_single_function_no_parens(self):
        t = sp.Symbol("t")
        X, U = sp.Function("X"), sp.Function("U")
        ode = sp.Eq(X(t).diff(t), 0.6 * U(t))
        adapter = ODEAdapter()
        result = adapter.translate(ode, {"X": 0.0, "U": 0.0}, ["X"])
        rhs = self._rhs_of(result, "diff[X, t](t)")
        assert rhs == "0.6*U(t)", f"Expected no extra parens, got: {rhs}"

    def test_no_coeff_product_no_parens(self):
        t = sp.Symbol("t")
        U, V, W = sp.Function("U"), sp.Function("V"), sp.Function("W")
        ode = sp.Eq(U(t).diff(t), W(t) * V(t))
        adapter = ODEAdapter()
        result = adapter.translate(
            ode, {"U": 0.0, "V": 0.0, "W": 0.0}, ["U"]
        )
        rhs = self._rhs_of(result, "diff[U, t](t)")
        assert re.match(
            r"(V\(t\)\*W\(t\)|W\(t\)\*V\(t\))$", rhs
        ), f"Expected plain product without extra parens, got: {rhs}"

    def test_hka3_system_parenthesization(self):
        t = sp.Symbol("t")
        X = sp.Function("X")
        Y = sp.Function("Y")
        U = sp.Function("U")
        V = sp.Function("V")
        W = sp.Function("W")

        sympy_ode = SympyODE(
            odes=[
                sp.Eq(X(t).diff(t), 0.6 * U(t)),
                sp.Eq(Y(t).diff(t), 0.6 * V(t)),
                sp.Eq(U(t).diff(t), -10.0 * (W(t) * V(t))),
                sp.Eq(V(t).diff(t), 10.0 * (W(t) * U(t))),
                sp.Eq(W(t).diff(t), 0.08),
            ],
            initial_conditions={
                X(t): 0.9, Y(t): 0.0, U(t): -1.0, V(t): 0.0, W(t): -0.1,
            },
            probes=[X(t), Y(t)],
            name="hka3",
        )
        adapter = ODEAdapter()
        result = adapter.translate_sympy(sympy_ode)

        u_rhs = self._rhs_of(result, "diff[U, t](t)")
        assert "*(" in u_rhs, f"U eq missing grouped product: {u_rhs}"

        v_rhs = self._rhs_of(result, "diff[V, t](t)")
        assert "*(" in v_rhs, f"V eq missing grouped product: {v_rhs}"

        x_rhs = self._rhs_of(result, "diff[X, t](t)")
        assert "*(" not in x_rhs, f"X eq has unexpected grouping: {x_rhs}"

        y_rhs = self._rhs_of(result, "diff[Y, t](t)")
        assert "*(" not in y_rhs, f"Y eq has unexpected grouping: {y_rhs}"


class TestProdOperator:
    """The @ operator (Prod) preserves multiplication grouping that sympy's
    associative * would flatten."""

    @staticmethod
    def _rhs_of(result: str, diff_key: str) -> str:
        line = next(l for l in result.splitlines() if diff_key in l)
        return line.split("=", 1)[1].strip().rstrip(";").strip()

    def test_at_basic_binary(self):
        """f @ g produces a parenthesized binary product."""
        t = sp.Symbol("t")
        f, g, X = sp.Function("f"), sp.Function("g"), sp.Function("X")
        ode = sp.Eq(X(t).diff(t), f(t) @ g(t))
        adapter = ODEAdapter()
        result = adapter.translate(
            ode, {"X": 0.0, "f": 0.0, "g": 0.0}, ["X"]
        )
        rhs = self._rhs_of(result, "diff[X, t](t)")
        assert re.match(
            r"\(f\(t\)\*g\(t\)\)$", rhs
        ), f"Expected (f(t)*g(t)), got: {rhs}"

    def test_at_left_nested(self):
        """(f @ g) @ h is distinct from f @ (g @ h)."""
        t = sp.Symbol("t")
        f, g, h = sp.Function("f"), sp.Function("g"), sp.Function("h")
        X = sp.Function("X")
        ode = sp.Eq(X(t).diff(t), (f(t) @ g(t)) @ h(t))
        adapter = ODEAdapter()
        result = adapter.translate(
            ode, {"X": 0.0, "f": 0.0, "g": 0.0, "h": 0.0}, ["X"]
        )
        rhs = self._rhs_of(result, "diff[X, t](t)")
        assert re.match(
            r"\(\(f\(t\)\*g\(t\)\)\*h\(t\)\)$", rhs
        ), f"Expected ((f(t)*g(t))*h(t)), got: {rhs}"

    def test_at_right_nested(self):
        """f @ (g @ h) preserves right-grouping."""
        t = sp.Symbol("t")
        f, g, h = sp.Function("f"), sp.Function("g"), sp.Function("h")
        X = sp.Function("X")
        ode = sp.Eq(X(t).diff(t), f(t) @ (g(t) @ h(t)))
        adapter = ODEAdapter()
        result = adapter.translate(
            ode, {"X": 0.0, "f": 0.0, "g": 0.0, "h": 0.0}, ["X"]
        )
        rhs = self._rhs_of(result, "diff[X, t](t)")
        assert re.match(
            r"\(f\(t\)\*\(g\(t\)\*h\(t\)\)\)$", rhs
        ), f"Expected (f(t)*(g(t)*h(t))), got: {rhs}"

    def test_at_non_associative(self):
        """Left- and right-nesting produce different analang."""
        t = sp.Symbol("t")
        f, g, h = sp.Function("f"), sp.Function("g"), sp.Function("h")
        X, Y = sp.Function("X"), sp.Function("Y")

        adapter = ODEAdapter()
        left = adapter.translate(
            sp.Eq(X(t).diff(t), (f(t) @ g(t)) @ h(t)),
            {"X": 0.0, "f": 0.0, "g": 0.0, "h": 0.0},
            ["X"],
        )
        right = adapter.translate(
            sp.Eq(Y(t).diff(t), f(t) @ (g(t) @ h(t))),
            {"Y": 0.0, "f": 0.0, "g": 0.0, "h": 0.0},
            ["Y"],
        )
        lhs = self._rhs_of(left, "diff[X, t](t)")
        rhs = self._rhs_of(right, "diff[Y, t](t)")
        assert lhs != rhs, "Left- and right-nested @ must produce different output"


class TestProdWithMul:
    """Combined use of * (associative, with _print_Mul coefficient handling)
    and @ (non-associative Prod) in the same equation."""

    @staticmethod
    def _rhs_of(result: str, diff_key: str) -> str:
        line = next(l for l in result.splitlines() if diff_key in l)
        return line.split("=", 1)[1].strip().rstrip(";").strip()

    def test_coeff_times_prod(self):
        """-10.0 * (W @ V) — coefficient scales a Prod."""
        t = sp.Symbol("t")
        U, V, W = sp.Function("U"), sp.Function("V"), sp.Function("W")
        ode = sp.Eq(U(t).diff(t), -10.0 * (W(t) @ V(t)))
        adapter = ODEAdapter()
        result = adapter.translate(
            ode, {"U": 0.0, "V": 0.0, "W": 0.0}, ["U"]
        )
        rhs = self._rhs_of(result, "diff[U, t](t)")
        assert re.match(
            r"-10\.0\*\(W\(t\)\*V\(t\)\)$", rhs
        ), f"Expected -10.0*(W(t)*V(t)), got: {rhs}"

    def test_coeff_times_nested_prods(self):
        """12 * ((a @ b) @ (c @ d)) — coefficient with nested sub-products."""
        t = sp.Symbol("t")
        a, b, c, d = (sp.Function(n) for n in "abcd")
        X = sp.Function("X")
        ode = sp.Eq(X(t).diff(t), 12 * ((a(t) @ b(t)) @ (c(t) @ d(t))))
        adapter = ODEAdapter()
        result = adapter.translate(
            ode,
            {n: 0.0 for n in ["X", "a", "b", "c", "d"]},
            ["X"],
        )
        rhs = self._rhs_of(result, "diff[X, t](t)")

        for name in "abcd":
            assert f"{name}(t)" in rhs, f"Missing function {name} in: {rhs}"
        assert rhs.startswith("12*"), f"Expected coefficient 12, got: {rhs}"
        # Must have binary-only multiplications (no flat 3+ chains)
        assert not re.search(
            r"\w+\(t\)\*\w+\(t\)\*\w+\(t\)", rhs
        ), f"Found non-binary multiplication chain in: {rhs}"

    def test_mixed_star_and_at_in_system(self):
        """System with both plain * (simple coeff) and @ (grouped product)."""
        t = sp.Symbol("t")
        X, U, V, W = (sp.Function(n) for n in ["X", "U", "V", "W"])

        sympy_ode = SympyODE(
            odes=[
                sp.Eq(X(t).diff(t), 0.6 * U(t)),
                sp.Eq(U(t).diff(t), -10.0 * (W(t) @ V(t))),
            ],
            initial_conditions={X(t): 0.9, U(t): -1.0, V(t): 0.0, W(t): -0.1},
            probes=[X(t)],
            name="mixed",
        )
        adapter = ODEAdapter()
        result = adapter.translate_sympy(sympy_ode)

        x_rhs = self._rhs_of(result, "diff[X, t](t)")
        assert x_rhs == "0.6*U(t)", f"Plain * should stay flat: {x_rhs}"

        u_rhs = self._rhs_of(result, "diff[U, t](t)")
        assert re.match(
            r"-10\.0\*\(W\(t\)\*V\(t\)\)$", u_rhs
        ), f"@ product should be grouped: {u_rhs}"


class TestODEAdapterAnalangComparison:
    """Compare ODEAdapter output against reference analang example files."""

    @staticmethod
    def _parse_structure(text):
        """Extract equation LHS keys, initial conditions, and probes."""
        eq_keys = set()
        ics = {}
        probes = []

        for line in text.strip().splitlines():
            line = line.strip()
            if not line or line.startswith("use ") or line.startswith("plot("):
                continue

            # Differential equations: let diff[...](t) = ...;
            m = re.match(r"let\s+(diff\[.+?\]\(\w+\))\s*=", line)
            if m:
                eq_keys.add(m.group(1))
                continue

            # Initial conditions: let f(t: <num>) = <value>;
            m = re.match(
                r"let\s+(\w+)\(\w+:\s*[\d.]+\)\s*=\s*(.+);", line
            )
            if m:
                name = m.group(1)
                val_str = m.group(2).strip()
                while val_str.startswith("(") and val_str.endswith(")"):
                    val_str = val_str[1:-1]
                ics[name] = float(val_str)
                continue

            # Probes: probe <expr>;
            m = re.match(r"probe\s+(.+);", line)
            if m:
                probes.append(m.group(1).strip())

        return eq_keys, ics, sorted(probes)

    def test_decay_matches_reference(self):
        """Adapter output for dX/dt = -0.8*X matches decay.ana."""
        t = sp.Symbol("t")
        X = sp.Function("X")
        ode = sp.Eq(X(t).diff(t), -0.8 * X(t))

        adapter = ODEAdapter()
        result = adapter.translate(ode, {"X": 0.8}, ["X"])

        ref = (ANALANG_DIR / "decay.ana").read_text()
        ref_keys, ref_ics, ref_probes = self._parse_structure(ref)
        out_keys, out_ics, out_probes = self._parse_structure(result)

        assert out_keys == ref_keys
        assert out_probes == ref_probes
        for name in ref_ics:
            assert name in out_ics
            assert abs(ref_ics[name] - out_ics[name]) < 1e-6

    def test_harmonic_matches_reference(self):
        """Adapter output for h'' = -h matches harmonic.ana."""
        t = sp.Symbol("t")
        h = sp.Function("h")
        ode = sp.Eq(h(t).diff(t, 2), -h(t))

        adapter = ODEAdapter()
        result = adapter.translate(ode, {"h": 0.42}, ["h"])

        ref = (ANALANG_DIR / "harmonic.ana").read_text()
        ref_keys, ref_ics, ref_probes = self._parse_structure(ref)
        out_keys, out_ics, out_probes = self._parse_structure(result)

        assert out_keys == ref_keys
        assert out_probes == ref_probes
        for name in ref_ics:
            assert name in out_ics
            assert abs(ref_ics[name] - out_ics[name]) < 1e-6

    def test_mass_spring_matches_reference(self):
        """Adapter output for Y'' = -0.5*(0.05*Y' + 0.5*Y) matches mass_spring.ana."""
        t = sp.Symbol("t")
        Y = sp.Function("Y")
        ode = sp.Eq(
            Y(t).diff(t, 2),
            -0.5 * (0.05 * Y(t).diff(t) + 0.5 * Y(t)),
        )

        adapter = ODEAdapter()
        result = adapter.translate(ode, {"Y": 0.8}, ["Y"])

        ref = (ANALANG_DIR / "mass_spring.ana").read_text()
        ref_keys, ref_ics, ref_probes = self._parse_structure(ref)
        out_keys, out_ics, out_probes = self._parse_structure(result)

        assert out_keys == ref_keys
        assert out_probes == ref_probes
        for name in ref_ics:
            assert name in out_ics
            assert abs(ref_ics[name] - out_ics[name]) < 1e-6
