from unittest.mock import MagicMock, patch
import pytest

from pyredacc.registry import DockerRegistry

REGISTRY_URL = "lab.analogparadigm.com:5050/lucidac/software/softthat"


@pytest.fixture(autouse=True)
def _reset_singleton():
    """Ensure each test starts with a fresh singleton."""
    DockerRegistry._reset()
    yield
    DockerRegistry._reset()


class TestConfigure:
    def test_configure_sets_credentials(self):
        DockerRegistry.configure(username="user", password="pass")
        inst = DockerRegistry._get()
        assert inst._url == REGISTRY_URL
        assert inst._username == "user"
        assert inst._password == "pass"

    def test_singleton_identity(self):
        DockerRegistry.configure(username="user1")
        a = DockerRegistry._get()
        DockerRegistry.configure(username="user2")
        b = DockerRegistry._get()
        assert a is b
        assert b._username == "user2"

    def test_configure_resets_logged_in(self):
        DockerRegistry.configure(username="user")
        inst = DockerRegistry._get()
        inst._logged_in = True

        DockerRegistry.configure(username="user")
        assert inst._logged_in is False


class TestFromEnv:
    def test_from_env_reads_env_vars(self):
        env = {
            "CI_REGISTRY_USER": "gitlab-user",
            "CI_REGISTRY_PASSWORD": "gitlab-pass",
        }
        with patch.dict("os.environ", env, clear=False):
            DockerRegistry.from_env()

        inst = DockerRegistry._get()
        assert inst._url == REGISTRY_URL
        assert inst._username == "gitlab-user"
        assert inst._password == "gitlab-pass"

    def test_from_env_without_credentials(self):
        with patch.dict("os.environ", {}, clear=True):
            DockerRegistry.from_env()

        inst = DockerRegistry._get()
        assert inst._username is None
        assert inst._password is None


class TestLogin:
    def test_login_calls_client_with_full_credentials(self):
        DockerRegistry.configure(username="user", password="pass")
        client = MagicMock()

        DockerRegistry._get().login(client)

        client.login.assert_called_once_with(
            registry=REGISTRY_URL, username="user", password="pass"
        )

    def test_login_calls_client_without_credentials(self):
        # Fresh instance, no configure — just the default URL
        client = MagicMock()

        DockerRegistry._get().login(client)

        client.login.assert_called_once_with(registry=REGISTRY_URL)

    def test_login_noop_when_already_logged_in(self):
        client = MagicMock()

        inst = DockerRegistry._get()
        inst.login(client)
        inst.login(client)

        client.login.assert_called_once()

    def test_login_noop_when_no_url(self):
        client = MagicMock()
        inst = DockerRegistry._get()
        inst._url = None

        inst.login(client)

        client.login.assert_not_called()
