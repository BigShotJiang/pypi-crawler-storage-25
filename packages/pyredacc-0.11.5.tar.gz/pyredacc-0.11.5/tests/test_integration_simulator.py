from unittest.mock import MagicMock, patch, PropertyMock

import pytest

from pyredacc.simulator import Simulator


class TestIntegrationSimulator:
    def test_context_manager_calls_start_stop(self):
        sim = Simulator(executable="/usr/bin/redacc-sim")
        sim.start = MagicMock()
        sim.stop = MagicMock()

        with sim:
            sim.start.assert_called_once()

        sim.stop.assert_called_once()

    def test_start_docker_publishes_port(self):
        sim = Simulator(image_name="redacc-simulator", image_tag="latest")
        mock_exec = MagicMock()
        mock_exec.run_detached.return_value = "abc123"
        sim._executor = mock_exec

        sim.start()

        mock_exec.run_detached.assert_called_once_with(
            ["--port", "5732"],
            ports={"5732/tcp": 5732},
        )

    def test_stop_removes_container(self):
        sim = Simulator(image_name="redacc-simulator", image_tag="latest")
        sim._container_id = "abc123"

        mock_container = MagicMock()
        mock_client = MagicMock()
        mock_client.containers.get.return_value = mock_container

        with patch("docker.from_env", return_value=mock_client):
            sim.stop()

        mock_client.containers.get.assert_called_once_with("abc123")
        mock_container.stop.assert_called_once_with(timeout=5)
        mock_container.remove.assert_called_once_with(force=True)
        assert sim._container_id is None

    def test_stop_idempotent(self):
        sim = Simulator(image_name="redacc-simulator", image_tag="latest")
        # No container or process running — stop() should not raise
        sim.stop()
        sim.stop()

    def test_start_local_subprocess(self):
        sim = Simulator(executable="/usr/bin/redacc-sim")
        mock_exec = MagicMock()
        sim._executor = mock_exec

        with patch("pyredacc.simulator.subprocess.Popen") as mock_popen:
            mock_popen.return_value = MagicMock()
            sim.start()

        mock_popen.assert_called_once_with(
            ["/usr/bin/redacc-sim", "--port", "5732"],
            stdout=-3,  # subprocess.DEVNULL
            stderr=-3,
        )

    def test_stop_local_terminates_process(self):
        sim = Simulator(executable="/usr/bin/redacc-sim")
        mock_proc = MagicMock()
        sim._process = mock_proc

        sim.stop()

        mock_proc.terminate.assert_called_once()
        mock_proc.wait.assert_called_once_with(timeout=10)
        assert sim._process is None

    def test_start_calls_ensure_available(self):
        sim = Simulator(image_name="redacc-simulator", image_tag="latest")
        mock_exec = MagicMock()
        mock_exec.run_detached.return_value = "abc123"
        sim._executor = mock_exec

        sim.start()

        mock_exec.ensure_available.assert_called_once()
