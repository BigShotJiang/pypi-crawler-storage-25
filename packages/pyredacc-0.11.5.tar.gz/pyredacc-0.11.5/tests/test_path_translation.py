import json
import os
import tempfile
from unittest.mock import MagicMock, patch

import pytest

from pyredacc.compiler import Compiler
from pyredacc.types import Backend, CompilerResult


class TestPathTranslation:
    def _make_mock_executor(self, exit_code=0):
        executor = MagicMock()
        executor.ensure_available.return_value = None
        executor.run.return_value = (exit_code, "", "")
        return executor

    def test_absolute_input_path(self, tmp_path):
        input_file = tmp_path / "input.ana"
        input_file.write_text("use math;\n")

        compiler = Compiler(backend=Backend.LANE, executable="/usr/bin/redacc")
        compiler._executor = self._make_mock_executor()

        compiler.run(input=str(input_file))

        call_args = compiler._executor.run.call_args
        args_list = call_args[1].get("args", call_args[0][0] if call_args[0] else None)
        assert any(str(input_file) in str(a) for a in (args_list or []))

    def test_dict_input_creates_temp_file(self):
        compiler = Compiler(backend=Backend.LANE, executable="/usr/bin/redacc")
        compiler._executor = self._make_mock_executor()

        ana_string = "use math;"

        with patch("pyredacc.compiler.tempfile") as mock_tempfile:
            mock_tempfile.mkdtemp.return_value = "/tmp/redacc_test"
            mock_tempfile.NamedTemporaryFile = tempfile.NamedTemporaryFile

            compiler.run(input=ana_string)

        compiler._executor.run.assert_called_once()

    def test_output_dir_is_temp(self, tmp_path):
        input_file = tmp_path / "input.ana"
        input_file.write_text("use math;\n")

        compiler = Compiler(backend=Backend.LANE, executable="/usr/bin/redacc")
        compiler._executor = self._make_mock_executor()

        with patch("pyredacc.compiler.tempfile") as mock_tempfile:
            mock_tempfile.mkdtemp.return_value = "/tmp/redacc_output_abc"
            compiler.run(input=str(input_file))

        mock_tempfile.mkdtemp.assert_called()
