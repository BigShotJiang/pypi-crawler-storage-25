import pytest
import sympy as sp


def _docker_daemon_available() -> bool:
    try:
        import docker
        docker.from_env().ping()
        return True
    except Exception:
        return False


requires_docker = pytest.mark.skipif(
    not _docker_daemon_available(),
    reason="Docker daemon not available",
)


@pytest.fixture
def decay_system():
    t = sp.Symbol("t")
    X = sp.Function("X")
    ode = sp.Eq(X(t).diff(t), -X(t))
    ics = {"X": 1.0}
    probes = ["X"]
    return ode, ics, probes


@pytest.fixture
def lorenz_system():
    t = sp.Symbol("t")
    X = sp.Function("X")
    Y = sp.Function("Y")
    Z = sp.Function("Z")
    sigma, rho, beta = sp.symbols("sigma rho beta")

    odes = [
        sp.Eq(X(t).diff(t), sigma * (Y(t) - X(t))),
        sp.Eq(Y(t).diff(t), X(t) * (rho - Z(t)) - Y(t)),
        sp.Eq(Z(t).diff(t), X(t) * Y(t) - beta * Z(t)),
    ]
    ics = {"X": 1.0, "Y": 1.0, "Z": 1.0}
    probes = ["X", "Y", "Z"]
    return odes, ics, probes
