import os, os.path
from pathlib import Path

import pytest

from pyredacc.compiler import Compiler
from pyredacc.registry import DockerRegistry
from pyredacc.types import Backend

SCRIPT_PATH=Path(__file__).parent
REDACC_BINARY = f"{SCRIPT_PATH}/../../../../build/src/redacc"
ENTITY_FILE = os.path.join(os.path.dirname(__file__), "fixtures", "lucidac.apb")

HARMONIC_ODE = """
use display;
use math;
let diff[h, t, t](t) = (-h(t));
let h(t: 0) = 0.420000;
probe h(t);
plot(x: ((t * 0.020000) - 1.000000), y: h(t));
"""

@pytest.fixture(autouse=True)
def _reset_registry():
    DockerRegistry._reset()
    yield
    DockerRegistry._reset()


class TestE2ECompilerLocal:
    @pytest.fixture(autouse=True)
    def _skip_if_no_binary(self):
        if not os.path.isfile(REDACC_BINARY):
            pytest.skip(f"redacc binary not found at {REDACC_BINARY}")

    def test_harmonic_oscillator_produces_config_apb(self):
        compiler = Compiler(
            backend=Backend.LANE,
            device=ENTITY_FILE,
            executable=REDACC_BINARY,
        )
        result = compiler.run(
            input=HARMONIC_ODE,
        )

        assert result.exit_code == 0, f"Compiler failed: {result.stderr}"
        assert result.module is not None

@pytest.mark.requires_docker
class TestE2ECompilerDocker:

    def test_harmonic_oscillator_produces_config_apb(self):
        DockerRegistry.from_env()
        compiler = Compiler(
            backend=Backend.LANE,
            device=ENTITY_FILE,
        )
        result = compiler.run(
            input=HARMONIC_ODE,
        )

        assert result.exit_code == 0, f"Compiler failed: {result.stderr}"
        assert result.module is not None
