import json
import os
import tempfile
from unittest.mock import MagicMock, patch

import pytest

from pyredacc.compiler import Compiler
from pyredacc.types import Backend, CompilerResult

FIXTURES_DIR = os.path.join(os.path.dirname(__file__), "fixtures")


class TestIntegrationCompiler:
    def _make_mock_executor(self, exit_code=0, stdout="", stderr=""):
        executor = MagicMock()
        executor.ensure_available.return_value = None
        executor.run.return_value = (exit_code, stdout, stderr)
        return executor

    def test_compile_analang_file(self, tmp_path):
        input_file = tmp_path / "decay.ana"
        input_file.write_text(
            "use display;\nuse math;\n"
            "let diff[X, t](t) = -X(t);\n"
            "let X(t: 0) = 1.0;\nprobe X(t);\n"
        )

        compiler = Compiler(backend=Backend.LANE, executable="/usr/bin/redacc")
        mock_exec = self._make_mock_executor(exit_code=0, stdout="OK")
        compiler._executor = mock_exec

        with patch("pyredacc.compiler.tempfile") as mock_tempfile:
            mock_tempfile.mkdtemp.return_value = str(tmp_path)
            result = compiler.run(
                input=str(input_file)
            )

        assert isinstance(result, CompilerResult)
        assert result.exit_code == 0
        assert result.stdout == "OK"
        mock_exec.ensure_available.assert_called_once()
        mock_exec.run.assert_called_once()

    def test_compile_dict_input_rejected(self, tmp_path):
        compiler = Compiler(backend=Backend.LANE, executable="/usr/bin/redacc")
        mock_exec = self._make_mock_executor(exit_code=0)
        compiler._executor = mock_exec

        ode_dict = {"odes": [{"lhs": "dX/dt", "rhs": "-X"}], "ics": {"X": 1.0}}

        with pytest.raises(TypeError):
            compiler.run(input=ode_dict)

    def test_compile_failure_returns_nonzero(self, tmp_path):
        input_file = tmp_path / "bad_input.ana"
        input_file.write_text("invalid content\n")

        compiler = Compiler(backend=Backend.LANE, executable="/usr/bin/redacc")
        mock_exec = self._make_mock_executor(
            exit_code=1,
            stdout="",
            stderr="error: invalid input",
        )
        compiler._executor = mock_exec

        with patch("pyredacc.compiler.tempfile") as mock_tempfile:
            mock_tempfile.mkdtemp.return_value = str(tmp_path)
            result = compiler.run(input=str(input_file))

        assert result.exit_code == 1
        assert "error" in result.stderr

    def test_compile_with_device(self, tmp_path):
        input_file = tmp_path / "decay.ana"
        input_file.write_text(
            "use display;\nuse math;\n"
            "let diff[X, t](t) = -X(t);\n"
            "let X(t: 0) = 1.0;\nprobe X(t);\n"
        )

        device_file = tmp_path / "lucidac.json"
        device_file.write_text('{"backend": {"type": "lane"}}')

        compiler = Compiler(
            backend=Backend.LANE,
            executable="/usr/bin/redacc",
            device=str(device_file),
        )
        mock_exec = self._make_mock_executor(exit_code=0)
        compiler._executor = mock_exec

        with patch("pyredacc.compiler.tempfile") as mock_tempfile:
            mock_tempfile.mkdtemp.return_value = str(tmp_path)
            result = compiler.run(input=str(input_file))

        args_call = mock_exec.run.call_args
        all_args = args_call[0][0] if args_call[0] else args_call[1].get("args", [])
        assert "--entity" in all_args
        entity_idx = all_args.index("--entity")
        assert all_args[entity_idx + 1] == str(device_file)
