from unittest.mock import patch, MagicMock
import pytest

from pyredacc.executor import DockerExecutor, LocalExecutor, _build_preexec_fn
from pyredacc.registry import DockerRegistry
from pyredacc.types import ResourceLimits

REGISTRY_URL = "lab.analogparadigm.com:5050/lucidac/software/softthat"


class _ImageNotFound(Exception):
    pass


class _DockerException(Exception):
    pass


class _APIError(Exception):
    pass


@pytest.fixture(autouse=True)
def _reset_registry():
    """Ensure each test starts with a fresh DockerRegistry singleton."""
    DockerRegistry._reset()
    yield
    DockerRegistry._reset()


def _make_docker_executor(**kwargs):
    """Create a DockerExecutor with a mocked docker client."""
    mock_docker = MagicMock()
    mock_client = MagicMock()
    mock_docker.from_env.return_value = mock_client
    mock_docker.errors.ImageNotFound = _ImageNotFound
    mock_docker.errors.DockerException = _DockerException
    mock_docker.errors.APIError = _APIError

    with patch.dict("sys.modules", {"docker": mock_docker, "docker.errors": mock_docker.errors}):
        executor = DockerExecutor(**kwargs)
        executor._client = mock_client

    return executor, mock_client, mock_docker


class TestDockerExecutorEnsureAvailable:
    def test_always_pull_fetches_latest(self):
        executor, mock_client, _ = _make_docker_executor(
            image_name="redacc", image_tag="v1",
            always_pull=True,
        )

        executor.ensure_available()

        mock_client.api.pull.assert_called_once()
        call_args = mock_client.api.pull.call_args
        # api.pull(repo, tag=tag, stream=True, decode=True)
        assert call_args[0][0] == f"{REGISTRY_URL}/redacc"
        assert call_args[1]["tag"] == "v1"
        assert call_args[1]["stream"] is True
        assert call_args[1]["decode"] is True
        mock_client.images.get.assert_not_called()

    def test_no_pull_pulls_when_image_not_found(self):
        executor, mock_client, _ = _make_docker_executor(
            image_name="redacc", image_tag="v1",
            always_pull=False,
        )
        mock_client.images.get.side_effect = _ImageNotFound("not found")

        executor.ensure_available()

        mock_client.api.pull.assert_called_once()
        call_args = mock_client.api.pull.call_args
        assert call_args[0][0] == f"{REGISTRY_URL}/redacc"
        assert call_args[1]["tag"] == "v1"

    def test_no_pull_skips_when_image_cached(self):
        executor, mock_client, _ = _make_docker_executor(
            image_name="redacc", image_tag="latest", always_pull=False,
        )
        mock_client.images.get.return_value = MagicMock()

        executor.ensure_available()

        mock_client.api.pull.assert_not_called()

    def test_login_called_with_default_registry(self):
        executor, mock_client, _ = _make_docker_executor(
            image_name="redacc", image_tag="v1",
        )

        executor.ensure_available()

        mock_client.login.assert_called_once_with(registry=REGISTRY_URL)

    def test_login_includes_credentials(self):
        DockerRegistry.configure(username="user", password="pass")
        executor, mock_client, _ = _make_docker_executor(
            image_name="redacc", image_tag="v1",
        )

        executor.ensure_available()

        mock_client.login.assert_called_once_with(
            registry=REGISTRY_URL, username="user", password="pass",
        )

    def test_login_only_once_across_calls(self):
        executor, mock_client, _ = _make_docker_executor(
            image_name="redacc", image_tag="v1",
        )

        executor.ensure_available()
        executor.ensure_available()

        mock_client.login.assert_called_once()


class TestLocalExecutorEnsureAvailable:
    def test_succeeds_when_executable_exists(self):
        with patch("pyredacc.executor.os.path.isfile", return_value=True), \
             patch("pyredacc.executor.os.access", return_value=True):
            executor = LocalExecutor(executable="/usr/bin/redacc")
            executor.ensure_available()

    def test_raises_when_executable_missing(self):
        with patch("pyredacc.executor.os.path.isfile", return_value=False):
            executor = LocalExecutor(executable="/no/such/binary")
            with pytest.raises(FileNotFoundError):
                executor.ensure_available()

    def test_raises_when_executable_not_executable(self):
        with patch("pyredacc.executor.os.path.isfile", return_value=True), \
             patch("pyredacc.executor.os.access", return_value=False):
            executor = LocalExecutor(executable="/usr/bin/redacc")
            with pytest.raises(PermissionError):
                executor.ensure_available()


class TestDockerExecutorRun:
    def test_run_creates_container_with_correct_args(self):
        executor, mock_client, _ = _make_docker_executor(
            image_name="redacc", image_tag="v1",
        )
        mock_container = MagicMock()
        mock_container.wait.return_value = {"StatusCode": 0}
        mock_container.logs.side_effect = [b"some output", b""]
        mock_client.containers.run.return_value = mock_container

        exit_code, stdout, stderr = executor.run(
            args=["--config", "that.json", "input.ana"],
            input_file="/host/input.ana",
            output_dir="/host/output",
            volumes={"/host/data": "/data"},
        )

        assert exit_code == 0

        call_args, call_kwargs = mock_client.containers.run.call_args
        assert call_args[0] == f"{REGISTRY_URL}/redacc:v1"
        assert call_kwargs["detach"] is True
        assert "/host/data" in call_kwargs["volumes"]
        assert call_kwargs["volumes"]["/host/data"]["bind"] == "/data"

        mock_container.remove.assert_called_once_with(force=True)


class TestDockerExecutorConnectionError:
    def test_raises_connection_error_when_daemon_unavailable(self):
        mock_docker = MagicMock()
        mock_docker.errors.ImageNotFound = _ImageNotFound
        mock_docker.errors.DockerException = _DockerException
        mock_docker.from_env.side_effect = _DockerException(
            "Error while fetching server API version"
        )

        with patch.dict("sys.modules", {"docker": mock_docker, "docker.errors": mock_docker.errors}):
            executor = DockerExecutor(
                image_name="redacc", image_tag="v1",
            )

        with pytest.raises(ConnectionError, match="Cannot connect to Docker daemon"):
            executor.ensure_available()


class TestPullProgress:
    """Tests for streamed pull with terminal progress feedback."""

    def _stream_events(self, layers):
        """Build a realistic Docker pull event stream from layer specs.

        Each layer is (layer_id, total_bytes).  The helper emits
        Downloading events at 0%, 50%, 100%, then a Pull-complete event.
        """
        events = []
        for lid, total in layers:
            events.append({"status": "Pulling fs layer", "id": lid})
        for lid, total in layers:
            for fraction in (0, 0.5, 1.0):
                events.append({
                    "status": "Downloading",
                    "id": lid,
                    "progressDetail": {"current": int(total * fraction), "total": total},
                })
            events.append({"status": "Pull complete", "id": lid})
        events.append({"status": "Status: Downloaded newer image for img:latest"})
        return events

    def test_progress_written_to_stderr(self):
        """A pull must write progress feedback containing the image name."""
        executor, mock_client, _ = _make_docker_executor(
            image_name="redacc", image_tag="v1", always_pull=True,
        )
        mock_client.api.pull.return_value = self._stream_events(
            [("abc1", 1000), ("abc2", 2000)],
        )

        import io
        buf = io.StringIO()
        with patch("sys.stderr", buf):
            buf.isatty = lambda: True
            executor.ensure_available()

        output = buf.getvalue()
        assert "redacc" in output.lower() or "pulling" in output.lower()
        assert "%" in output or "/" in output

    def test_progress_aggregates_layer_totals(self):
        """Aggregated byte counts must equal the sum across all layers."""
        executor, mock_client, _ = _make_docker_executor(
            image_name="redacc", image_tag="v1", always_pull=True,
        )
        layers = [("a1", 1_000_000), ("a2", 2_000_000), ("a3", 3_000_000)]
        mock_client.api.pull.return_value = self._stream_events(layers)

        import io
        buf = io.StringIO()
        with patch("sys.stderr", buf):
            buf.isatty = lambda: True
            executor.ensure_available()

        output = buf.getvalue()
        # Final state should show ~5.7 MB total (6_000_000 bytes = 5.7 MB)
        assert "5.7" in output or "6.0" in output

    def test_events_without_progress_detail_do_not_crash(self):
        """Events missing progressDetail (e.g. 'Already exists') must not raise."""
        executor, mock_client, _ = _make_docker_executor(
            image_name="redacc", image_tag="v1", always_pull=True,
        )
        mock_client.api.pull.return_value = [
            {"status": "Pulling fs layer", "id": "x1"},
            {"status": "Already exists", "id": "x1"},
            {"status": "Status: Image is up to date for img:latest"},
        ]

        import io
        buf = io.StringIO()
        with patch("sys.stderr", buf):
            buf.isatty = lambda: True
            executor.ensure_available()

    def test_up_to_date_image_no_progress_bar(self):
        """When image is already current, no percentage/progress bar appears."""
        executor, mock_client, _ = _make_docker_executor(
            image_name="redacc", image_tag="v1", always_pull=True,
        )
        mock_client.api.pull.return_value = [
            {"status": "Status: Image is up to date for img:latest"},
        ]

        import io
        buf = io.StringIO()
        with patch("sys.stderr", buf):
            buf.isatty = lambda: True
            executor.ensure_available()

        output = buf.getvalue()
        assert "%" not in output

    def test_ensure_available_leaves_image_usable(self):
        """After a streamed pull, images.get must not raise."""
        executor, mock_client, _ = _make_docker_executor(
            image_name="redacc", image_tag="v1", always_pull=False,
        )
        mock_client.images.get.side_effect = [
            _ImageNotFound("not found"),  # first call triggers pull
            MagicMock(),                  # second call succeeds
        ]
        mock_client.api.pull.return_value = [
            {"status": "Downloading", "id": "l1",
             "progressDetail": {"current": 500, "total": 500}},
            {"status": "Pull complete", "id": "l1"},
            {"status": "Status: Downloaded newer image"},
        ]

        import io
        buf = io.StringIO()
        with patch("sys.stderr", buf):
            buf.isatty = lambda: True
            executor.ensure_available()

        assert mock_client.api.pull.called

    def test_non_tty_shows_simple_message(self):
        """When stderr is not a TTY, output only start/done lines, no ANSI codes."""
        executor, mock_client, _ = _make_docker_executor(
            image_name="redacc", image_tag="v1", always_pull=True,
        )
        mock_client.api.pull.return_value = self._stream_events(
            [("a1", 5000)],
        )

        import io
        buf = io.StringIO()
        with patch("sys.stderr", buf):
            buf.isatty = lambda: False
            executor.ensure_available()

        output = buf.getvalue()
        assert "\r" not in output
        assert "\x1b" not in output


class TestLocalExecutorRun:
    def test_run_invokes_binary_with_correct_args(self):
        mock_result = MagicMock()
        mock_result.returncode = 0
        mock_result.stdout = "compiled successfully"
        mock_result.stderr = ""

        with patch("pyredacc.executor.subprocess.run", return_value=mock_result) as mock_run:
            executor = LocalExecutor(executable="/usr/bin/redacc")
            exit_code, stdout, stderr = executor.run(
                args=["--config", "that.json", "input.ana"],
                input_file=None,
                output_dir=None,
                volumes=None,
            )

        assert exit_code == 0
        assert stdout == "compiled successfully"
        assert stderr == ""

        invoked_cmd = mock_run.call_args[0][0]
        assert invoked_cmd[0] == "/usr/bin/redacc"
        assert "--config" in invoked_cmd


class TestLocalExecutorTimeout:
    def test_timeout_forwarded_to_subprocess_run(self):
        """When timeout is set, subprocess.run receives it."""
        import subprocess

        mock_result = MagicMock()
        mock_result.returncode = 0
        mock_result.stdout = ""
        mock_result.stderr = ""

        with patch("pyredacc.executor.subprocess.run", return_value=mock_result) as mock_run:
            executor = LocalExecutor(executable="/usr/bin/redacc")
            executor.run(
                args=["input.ana"],
                input_file=None,
                output_dir=None,
                volumes=None,
                timeout=2.5,
            )

        assert mock_run.call_args.kwargs.get("timeout") == 2.5

    def test_timeout_expired_converted_to_timeout_error(self):
        """subprocess.TimeoutExpired is converted to TimeoutError."""
        import subprocess

        with patch(
            "pyredacc.executor.subprocess.run",
            side_effect=subprocess.TimeoutExpired(cmd="redacc", timeout=1.0),
        ):
            executor = LocalExecutor(executable="/usr/bin/redacc")
            with pytest.raises(TimeoutError, match="1.0"):
                executor.run(
                    args=["input.ana"],
                    input_file=None,
                    output_dir=None,
                    volumes=None,
                    timeout=1.0,
                )

    def test_no_timeout_default(self):
        """When timeout is None, subprocess.run is called without a timeout kwarg (or with None)."""
        mock_result = MagicMock()
        mock_result.returncode = 0
        mock_result.stdout = ""
        mock_result.stderr = ""

        with patch("pyredacc.executor.subprocess.run", return_value=mock_result) as mock_run:
            executor = LocalExecutor(executable="/usr/bin/redacc")
            executor.run(
                args=["input.ana"],
                input_file=None,
                output_dir=None,
                volumes=None,
            )

        assert mock_run.call_args.kwargs.get("timeout") is None


class TestDockerExecutorTimeout:
    def _make_read_timeout_exc(self):
        """Return a requests.exceptions.ReadTimeout instance (lazy import)."""
        import requests
        return requests.exceptions.ReadTimeout("read timed out")

    def test_timeout_forwarded_to_wait(self):
        """When timeout is set, container.wait is called with that timeout."""
        executor, mock_client, _ = _make_docker_executor(
            image_name="redacc", image_tag="v1",
        )
        mock_container = MagicMock()
        mock_container.wait.return_value = {"StatusCode": 0}
        mock_container.logs.side_effect = [b"", b""]
        mock_client.containers.run.return_value = mock_container

        executor.run(
            args=["input.ana"],
            input_file=None,
            output_dir=None,
            volumes=None,
            timeout=3.0,
        )

        mock_container.wait.assert_called_once()
        assert mock_container.wait.call_args.kwargs.get("timeout") == 3.0

    def test_no_timeout_default(self):
        """When timeout is None, container.wait is called without a timeout."""
        executor, mock_client, _ = _make_docker_executor(
            image_name="redacc", image_tag="v1",
        )
        mock_container = MagicMock()
        mock_container.wait.return_value = {"StatusCode": 0}
        mock_container.logs.side_effect = [b"", b""]
        mock_client.containers.run.return_value = mock_container

        executor.run(
            args=["input.ana"],
            input_file=None,
            output_dir=None,
            volumes=None,
        )

        assert mock_container.wait.call_args.kwargs.get("timeout") is None

    def test_read_timeout_kills_container_and_raises(self):
        """A ReadTimeout from container.wait kills the container, removes it, and raises TimeoutError."""
        executor, mock_client, _ = _make_docker_executor(
            image_name="redacc", image_tag="v1",
        )
        mock_container = MagicMock()
        mock_container.wait.side_effect = self._make_read_timeout_exc()
        mock_client.containers.run.return_value = mock_container

        with pytest.raises(TimeoutError, match="2.0"):
            executor.run(
                args=["input.ana"],
                input_file=None,
                output_dir=None,
                volumes=None,
                timeout=2.0,
            )

        mock_container.kill.assert_called_once()
        mock_container.remove.assert_called_once_with(force=True)

    def test_connection_error_read_timed_out_converted_to_timeout_error(self):
        """docker-py wraps urllib3 ReadTimeoutError as requests.ConnectionError with 'Read timed out' — must still yield TimeoutError."""
        import requests

        executor, mock_client, _ = _make_docker_executor(
            image_name="redacc", image_tag="v1",
        )
        mock_container = MagicMock()
        # Mirror the real chain: ConnectionError whose message contains 'Read timed out'.
        mock_container.wait.side_effect = requests.exceptions.ConnectionError(
            "UnixHTTPConnectionPool(host='localhost', port=None): Read timed out."
        )
        mock_client.containers.run.return_value = mock_container

        with pytest.raises(TimeoutError, match="0.01"):
            executor.run(
                args=["input.ana"],
                input_file=None,
                output_dir=None,
                volumes=None,
                timeout=0.01,
            )

        mock_container.kill.assert_called_once()
        mock_container.remove.assert_called_once_with(force=True)

    def test_connection_error_without_timeout_reraised(self):
        """A non-timeout ConnectionError (e.g. daemon unreachable) is not masked as a timeout."""
        import requests

        executor, mock_client, _ = _make_docker_executor(
            image_name="redacc", image_tag="v1",
        )
        mock_container = MagicMock()
        mock_container.wait.side_effect = requests.exceptions.ConnectionError(
            "Connection refused"
        )
        mock_client.containers.run.return_value = mock_container

        with pytest.raises(requests.exceptions.ConnectionError):
            executor.run(
                args=["input.ana"],
                input_file=None,
                output_dir=None,
                volumes=None,
                timeout=5.0,
            )


class TestLocalExecutorResourceLimits:
    def _run_with_limits(self, limits):
        mock_result = MagicMock()
        mock_result.returncode = 0
        mock_result.stdout = ""
        mock_result.stderr = ""

        with patch("pyredacc.executor.subprocess.run", return_value=mock_result) as mock_run:
            executor = LocalExecutor(executable="/usr/bin/redacc")
            executor.run(
                args=["input.ana"],
                input_file=None,
                output_dir=None,
                volumes=None,
                resource_limits=limits,
            )
        return mock_run

    def test_no_preexec_when_no_limits(self):
        mock_run = self._run_with_limits(None)
        assert mock_run.call_args.kwargs.get("preexec_fn") is None

    def test_no_preexec_when_all_fields_none(self):
        mock_run = self._run_with_limits(ResourceLimits())
        assert mock_run.call_args.kwargs.get("preexec_fn") is None

    def test_sets_preexec_for_memory(self):
        mock_run = self._run_with_limits(ResourceLimits(memory_gb=2.0))
        preexec_fn = mock_run.call_args.kwargs.get("preexec_fn")
        assert preexec_fn is not None

        with patch("pyredacc.executor.resource") as mock_resource:
            mock_resource.RLIMIT_AS = 9
            preexec_fn()

        expected_bytes = 2 * 1024**3
        mock_resource.setrlimit.assert_called_once_with(9, (expected_bytes, expected_bytes))

    def test_no_preexec_when_only_num_workers_set(self):
        mock_run = self._run_with_limits(ResourceLimits(num_workers=4))
        assert mock_run.call_args.kwargs.get("preexec_fn") is None

    def test_preexec_for_both_only_caps_memory(self):
        mock_run = self._run_with_limits(ResourceLimits(num_workers=4, memory_gb=2.0))
        preexec_fn = mock_run.call_args.kwargs.get("preexec_fn")
        assert preexec_fn is not None

        with patch("pyredacc.executor.resource") as mock_resource:
            mock_resource.RLIMIT_AS = 9
            preexec_fn()

        expected_bytes = 2 * 1024**3
        mock_resource.setrlimit.assert_called_once_with(9, (expected_bytes, expected_bytes))

    def test_memory_gb_fractional_converted_to_bytes(self):
        mock_run = self._run_with_limits(ResourceLimits(memory_gb=0.5))
        preexec_fn = mock_run.call_args.kwargs.get("preexec_fn")

        with patch("pyredacc.executor.resource") as mock_resource:
            mock_resource.RLIMIT_AS = 9
            preexec_fn()

        expected_bytes = 512 * 1024 * 1024
        mock_resource.setrlimit.assert_called_once_with(9, (expected_bytes, expected_bytes))
