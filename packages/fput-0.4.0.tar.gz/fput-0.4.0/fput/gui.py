"""
FPUT GUI - Interactive graphical interface for the FPUT simulator.

A user-friendly interface for exploring the Fermi-Pasta-Ulam-Tsingou problem.
"""

import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import numpy as np
import matplotlib
matplotlib.use('TkAgg')
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.figure import Figure
from matplotlib import font_manager
import threading
import queue
import platform

from fput.simulator import FPUTSimulator, FPUTBetaSimulator
from fput.normal_modes import fundamental_period


class FontManager:
    """Manages font settings for the GUI."""

    # English labels
    LABELS_EN = {
        'title': 'FPUT Simulator',
        'system_params': 'System Parameters',
        'nonlinearity_type': 'Nonlinearity Type:',
        'alpha': 'Alpha (二次非线性)',
        'beta': 'Beta (三次非线性)',
        'n_particles': 'Number of Particles N:',
        'moving_particles': 'Moving particles:',
        'alpha_param': 'Alpha Parameter:',
        'beta_param': 'Beta Parameter:',
        'dt': 'Time Step dt:',
        'integrator': 'Integrator Method:',
        'integrator_rk4': 'RK4 (4th order Runge-Kutta)',
        'integrator_verlet': 'Verlet (Symplectic, energy-conserving)',
        'n_modes': 'Modes to Display:',
        'initial_cond': 'Initial Conditions',
        'init_mode': 'Initial Mode:',
        'mode': 'Mode',
        'amplitude': 'Amplitude A:',
        'quick_preset': 'Quick Presets:',
        'classic': 'Classic',
        'weak': 'Weak',
        'strong': 'Strong',
        'sim_control': 'Simulation Control',
        'sim_time': 'Simulation Time:',
        'periods': '(fundamental periods)',
        'run': 'Run Simulation',
        'pause': 'Pause',
        'resume': 'Resume',
        'reset': 'Reset',
        'progress': 'Progress:',
        'status_ready': 'Ready',
        'status_running': 'Running...',
        'status_paused': 'Paused',
        'status_done': 'Complete!',
        'sim_info': 'Simulation Info',
        'total_energy': 'Total Energy:',
        'mode1_energy': 'Mode 1 Energy:',
        'fput_recurrence': 'FPUT Recurrence:',
        'plot_main': 'Normal Mode Energy\nEvolution',
        'plot_mode1': 'Mode 1 Energy\nDetail',
        'plot_part': 'Participation\nRatio',
        'plot_phase': 'Mode 1 Phase\nSpace',
        'plot_water': 'Energy\nHeatmap',
        'xlabel_time': 'Time (fundamental periods)',
        'xlabel_mode': 'Mode Number',
        'ylabel_energy': 'Energy',
        'ylabel_mode': 'Coordinate A₁',
        'ylabel_momentum': 'Momentum Ā₁',
        'ylabel_modes': 'Effective Modes',
        'initial': 'Initial',
        'language': 'Language / 语言',
        'english': 'English',
        'chinese': '中文',
        'thumbnails': 'Thumbnails',
        'save': 'Save',
    }

    # Chinese labels
    LABELS_CN = {
        'title': 'FPUT 模拟器',
        'system_params': '系统参数',
        'nonlinearity_type': '非线性类型:',
        'alpha': 'α (二次项，力∝δ²)',
        'beta': 'β (三次项，力∝δ³)',
        'n_particles': '粒子数 N:',
        'moving_particles': '移动粒子:',
        'alpha_param': 'α 参数:',
        'beta_param': 'β 参数:',
        'dt': '时间步长 dt:',
        'integrator': '积分方法:',
        'integrator_rk4': 'RK4 (四阶龙格-库塔)',
        'integrator_verlet': 'Verlet (辛算法, 能量守恒)',
        'n_modes': '显示模数:',
        'initial_cond': '初始条件',
        'init_mode': '激发模数:',
        'mode': '模式',
        'amplitude': '振幅 A:',
        'quick_preset': '快速预设:',
        'classic': '经典FPUT',
        'weak': '弱非线性',
        'strong': '强非线性',
        'sim_control': '模拟控制',
        'sim_time': '模拟时长:',
        'periods': '(基本模周期数)',
        'run': '运行模拟',
        'pause': '暂停',
        'resume': '继续',
        'reset': '重置',
        'progress': '进度:',
        'status_ready': '就绪',
        'status_running': '运行中...',
        'status_paused': '已暂停',
        'status_done': '完成!',
        'sim_info': '模拟信息',
        'total_energy': '总能量:',
        'mode1_energy': '模式1能量:',
        'fput_recurrence': 'FPUT复现:',
        'plot_main': '简正模能量\n演化',
        'plot_mode1': '模式1 能量\n详情',
        'plot_part': '参与模数',
        'plot_phase': '模式1 相\n空间',
        'plot_water': '能量\n热图',
        'xlabel_time': '时间 (基本模周期)',
        'xlabel_mode': '模数',
        'ylabel_energy': '能量',
        'ylabel_mode': '坐标 A₁',
        'ylabel_momentum': '动量 Ā₁',
        'ylabel_modes': '有效模数',
        'initial': '初始值',
        'language': 'Language / 语言',
        'english': 'English',
        'chinese': '中文',
        'thumbnails': '缩略图',
        'save': '保存',
    }

    @staticmethod
    def get_chinese_font():
        """Get a suitable Chinese font for matplotlib."""
        system = platform.system()

        if system == 'Windows':
            fonts_to_try = ['Microsoft YaHei', 'SimHei', 'SimSun', 'KaiTi']
        elif system == 'Darwin':
            fonts_to_try = ['PingFang SC', 'Heiti SC', 'STHeiti', 'Arial Unicode MS']
        else:
            fonts_to_try = ['WenQuanYi Micro Hei', 'Droid Sans Fallback', 'Noto Sans CJK']

        available_fonts = [f.name for f in font_manager.fontManager.ttflist]
        for font in fonts_to_try:
            if font in available_fonts:
                return font
        return 'sans-serif'

    @staticmethod
    def configure_matplotlib_font(use_chinese=False):
        """Configure matplotlib font based on language selection."""
        if use_chinese:
            font = FontManager.get_chinese_font()
            plt.rcParams['font.sans-serif'] = [font, 'DejaVu Sans', 'Arial']
        else:
            plt.rcParams['font.sans-serif'] = ['DejaVu Sans', 'Arial', 'sans-serif']
        plt.rcParams['axes.unicode_minus'] = False


class PlotPanel:
    """A panel containing a matplotlib figure and its canvas."""

    def __init__(self, parent, title, figsize=(8, 6), is_thumbnail=False):
        self.parent = parent
        self.title = title
        self.is_thumbnail = is_thumbnail

        # Create figure
        scale = 0.5 if is_thumbnail else 1.0
        self.fig = Figure(figsize=(figsize[0] * scale, figsize[1] * scale), dpi=100)
        self.fig.patch.set_facecolor('#f0f0f0')

        # Create axes
        self.ax = self.fig.add_subplot(111)
        self.ax.set_title(title, fontsize=10 if is_thumbnail else 12, fontweight='bold')
        self.ax.grid(True, alpha=0.3)

        # Create canvas
        self.canvas = FigureCanvasTkAgg(self.fig, master=parent)
        self.canvas.draw()

    def get_widget(self):
        """Get the canvas widget for packing."""
        return self.canvas.get_tk_widget()

    def clear(self):
        """Clear the plot."""
        self.ax.clear()
        self.ax.grid(True, alpha=0.3)
        self.canvas.draw()

    def save(self, filename, dpi=150):
        """Save the figure to a file."""
        self.fig.savefig(filename, dpi=dpi, bbox_inches='tight')


class FPUTSimulatorGUI:
    """Main GUI application for FPUT simulation."""

    # Plot types
    PLOT_MAIN = 'main'
    PLOT_MODE1 = 'mode1'
    PLOT_PART = 'part'
    PLOT_PHASE = 'phase'
    PLOT_WATER = 'water'

    def __init__(self, root):
        """Initialize the GUI."""
        self.root = root
        self.root.title("FPUT Simulator - Fermi-Pasta-Ulam-Tsingou Problem")
        self.root.geometry("1600x900")

        # Language setting
        self.use_chinese = tk.BooleanVar(value=False)
        FontManager.configure_matplotlib_font(False)

        # Simulation state
        self.sim_running = False
        self.sim_paused = False
        self.simulator = None
        self.result_queue = queue.Queue()

        # Data storage
        self.time_points = []
        self.mode_energies = []
        self.max_modes = 6
        self.phase_coords = []
        self.phase_momenta = []

        # Current selected plot
        self.current_plot = self.PLOT_MAIN

        # Setup GUI
        self._setup_styles()
        self._create_layout()
        self._init_plots()

    def get_label(self, key):
        """Get label in current language."""
        labels = FontManager.LABELS_CN if self.use_chinese.get() else FontManager.LABELS_EN
        return labels.get(key, key)

    def _setup_styles(self):
        """Setup GUI styles."""
        style = ttk.Style()
        style.theme_use('clam')
        style.configure('Title.TLabel', font=('Arial', 14, 'bold'))
        style.configure('Header.TLabel', font=('Arial', 10, 'bold'))
        style.configure('Run.TButton', font=('Arial', 11, 'bold'))
        style.configure('Thumbnail.TButton', font=('Arial', 8))

    def _create_layout(self):
        """Create the main layout with three panels."""
        # Main container with paned window (horizontal)
        main_paned = ttk.PanedWindow(self.root, orient=tk.HORIZONTAL)
        main_paned.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

        # Left panel - Controls
        self.control_frame = ttk.Frame(main_paned, width=300)
        main_paned.add(self.control_frame, weight=0)

        # Middle panel - Main plot display
        self.main_plot_frame = ttk.Frame(main_paned)
        main_paned.add(self.main_plot_frame, weight=3)

        # Right panel - Thumbnails
        self.thumbnail_frame = ttk.Frame(main_paned, width=200)
        main_paned.add(self.thumbnail_frame, weight=0)

        self._create_controls()
        self._create_main_plot_area()
        self._create_thumbnail_area()

    def _create_controls(self):
        """Create control panel."""
        canvas = tk.Canvas(self.control_frame)
        scrollbar = ttk.Scrollbar(self.control_frame, orient="vertical", command=canvas.yview)
        self.scrollable_frame = ttk.Frame(canvas)

        self.scrollable_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )

        canvas.create_window((0, 0), window=self.scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)

        # Title
        self.title_label = ttk.Label(self.scrollable_frame, text=self.get_label('title'),
                                     style='Title.TLabel')
        self.title_label.pack(pady=(10, 20))

        # Language selection
        self._create_language_section()

        # Parameters section
        self.param_frame = ttk.LabelFrame(self.scrollable_frame, text=self.get_label('system_params'),
                                          padding=10)
        self.param_frame.pack(fill=tk.X, padx=10, pady=5)
        self.param_frame.bind('<Destroy>', self._save_param_frame)
        self._create_parameter_section()

        # Initial conditions section
        self.init_frame = ttk.LabelFrame(self.scrollable_frame, text=self.get_label('initial_cond'),
                                         padding=10)
        self.init_frame.pack(fill=tk.X, padx=10, pady=5)
        self.init_frame.bind('<Destroy>', self._save_init_frame)
        self._create_initial_conditions_section()

        # Simulation section
        self.sim_frame = ttk.LabelFrame(self.scrollable_frame, text=self.get_label('sim_control'),
                                        padding=10)
        self.sim_frame.pack(fill=tk.X, padx=10, pady=5)
        self.sim_frame.bind('<Destroy>', self._save_sim_frame)
        self._create_simulation_section()

        # Info section
        self.info_frame = ttk.LabelFrame(self.scrollable_frame, text=self.get_label('sim_info'),
                                         padding=10)
        self.info_frame.pack(fill=tk.X, padx=10, pady=5)
        self.info_frame.bind('<Destroy>', self._save_info_frame)
        self._create_info_section()

        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        def _on_mousewheel(event):
            canvas.yview_scroll(int(-1*(event.delta/120)), "units")
        canvas.bind_all("<MouseWheel>", _on_mousewheel)

    def _save_param_frame(self, event):
        self.param_frame = None

    def _save_init_frame(self, event):
        self.init_frame = None

    def _save_sim_frame(self, event):
        self.sim_frame = None

    def _save_info_frame(self, event):
        self.info_frame = None

    def _create_language_section(self):
        """Create language selection section."""
        lang_frame = ttk.Frame(self.scrollable_frame)
        lang_frame.pack(fill=tk.X, padx=10, pady=(0, 10))

        ttk.Label(lang_frame, text=self.get_label('language') + ':').pack(side=tk.LEFT, padx=(0, 10))

        lang_radio_frame = ttk.Frame(lang_frame)
        lang_radio_frame.pack(side=tk.LEFT)

        self.en_radio = ttk.Radiobutton(lang_radio_frame, text=self.get_label('english'),
                                        variable=self.use_chinese, value=False,
                                        command=self._toggle_language)
        self.en_radio.pack(side=tk.LEFT, padx=(0, 10))

        self.cn_radio = ttk.Radiobutton(lang_radio_frame, text=self.get_label('chinese'),
                                        variable=self.use_chinese, value=True,
                                        command=self._toggle_language)
        self.cn_radio.pack(side=tk.LEFT)

    def _toggle_language(self):
        """Toggle between English and Chinese."""
        use_chinese = self.use_chinese.get()
        FontManager.configure_matplotlib_font(use_chinese)
        self._recreate_controls()
        self._update_plot_labels()
        self._recreate_thumbnails()
        for panel in self.plot_panels.values():
            panel.canvas.draw()

    def _recreate_controls(self):
        """Recreate control panel with new language."""
        for widget in self.scrollable_frame.winfo_children():
            widget.destroy()

        self.title_label = ttk.Label(self.scrollable_frame, text=self.get_label('title'),
                                     style='Title.TLabel')
        self.title_label.pack(pady=(10, 20))
        self._create_language_section()

        self.param_frame = ttk.LabelFrame(self.scrollable_frame, text=self.get_label('system_params'),
                                          padding=10)
        self.param_frame.pack(fill=tk.X, padx=10, pady=5)
        self._create_parameter_section()

        self.init_frame = ttk.LabelFrame(self.scrollable_frame, text=self.get_label('initial_cond'),
                                         padding=10)
        self.init_frame.pack(fill=tk.X, padx=10, pady=5)
        self._create_initial_conditions_section()

        self.sim_frame = ttk.LabelFrame(self.scrollable_frame, text=self.get_label('sim_control'),
                                        padding=10)
        self.sim_frame.pack(fill=tk.X, padx=10, pady=5)
        self._create_simulation_section()

        self.info_frame = ttk.LabelFrame(self.scrollable_frame, text=self.get_label('sim_info'),
                                         padding=10)
        self.info_frame.pack(fill=tk.X, padx=10, pady=5)
        self._create_info_section()

    def _create_parameter_section(self):
        """Create parameter input section."""
        # Nonlinearity type
        ttk.Label(self.param_frame, text=self.get_label('nonlinearity_type')).pack(anchor=tk.W)
        self.nonlinearity_type = tk.StringVar(value="alpha")
        type_frame = ttk.Frame(self.param_frame)
        type_frame.pack(fill=tk.X, pady=(0, 10))
        ttk.Radiobutton(type_frame, text=self.get_label('alpha'), variable=self.nonlinearity_type,
                       value="alpha").pack(side=tk.LEFT)
        ttk.Radiobutton(type_frame, text=self.get_label('beta'), variable=self.nonlinearity_type,
                       value="beta").pack(side=tk.LEFT, padx=(10, 0))

        # N - Number of particles
        ttk.Label(self.param_frame, text=self.get_label('n_particles')).pack(anchor=tk.W)
        self.n_var = tk.IntVar(value=32)
        n_spinbox = ttk.Spinbox(self.param_frame, from_=8, to=128, textvariable=self.n_var,
                                width=10, command=self._update_n_display)
        n_spinbox.pack(fill=tk.X, pady=(0, 10))
        self.n_info = ttk.Label(self.param_frame,
                                text=f"{self.get_label('moving_particles')} {self.n_var.get()}")
        self.n_info.pack(anchor=tk.W, pady=(0, 10))

        # Alpha parameter
        self.alpha_frame = ttk.Frame(self.param_frame)
        self.alpha_frame.pack(fill=tk.X, pady=(0, 10))
        ttk.Label(self.alpha_frame, text=self.get_label('alpha_param')).pack(anchor=tk.W)
        self.alpha_var = tk.DoubleVar(value=0.25)
        ttk.Scale(self.alpha_frame, from_=0.0, to=2.0, variable=self.alpha_var,
                 orient=tk.HORIZONTAL).pack(fill=tk.X)
        self.alpha_label = ttk.Label(self.alpha_frame, text=f"α = {self.alpha_var.get():.3f}")
        self.alpha_label.pack(anchor=tk.E)
        self.alpha_var.trace('w', lambda *args: self._update_alpha_label())

        # Beta parameter
        self.beta_frame = ttk.Frame(self.param_frame)
        self.beta_frame.pack(fill=tk.X, pady=(0, 10))
        ttk.Label(self.beta_frame, text=self.get_label('beta_param')).pack(anchor=tk.W)
        self.beta_var = tk.DoubleVar(value=1.0)
        ttk.Scale(self.beta_frame, from_=0.0, to=5.0, variable=self.beta_var,
                 orient=tk.HORIZONTAL).pack(fill=tk.X)
        self.beta_label = ttk.Label(self.beta_frame, text=f"β = {self.beta_var.get():.3f}")
        self.beta_label.pack(anchor=tk.E)
        self.beta_var.trace('w', lambda *args: self._update_beta_label())

        # Time step
        ttk.Label(self.param_frame, text=self.get_label('dt')).pack(anchor=tk.W, pady=(10, 0))
        self.dt_var = tk.DoubleVar(value=0.05)
        dt_combo = ttk.Combobox(self.param_frame, textvariable=self.dt_var,
                                values=[0.01, 0.02, 0.05, 0.1], width=10)
        dt_combo.pack(fill=tk.X, pady=(0, 10))

        # Integrator selection
        ttk.Label(self.param_frame, text=self.get_label('integrator')).pack(anchor=tk.W, pady=(10, 0))
        self.integrator_var = tk.StringVar(value="verlet")
        integrator_frame = ttk.Frame(self.param_frame)
        integrator_frame.pack(fill=tk.X, pady=(0, 10))
        ttk.Radiobutton(integrator_frame, text=self.get_label('integrator_verlet'),
                       variable=self.integrator_var, value="verlet").pack(anchor=tk.W)
        ttk.Radiobutton(integrator_frame, text=self.get_label('integrator_rk4'),
                       variable=self.integrator_var, value="rk4").pack(anchor=tk.W)

        # Number of modes to display
        ttk.Label(self.param_frame, text=self.get_label('n_modes')).pack(anchor=tk.W)
        self.n_modes_var = tk.IntVar(value=6)
        ttk.Spinbox(self.param_frame, from_=3, to=12, textvariable=self.n_modes_var,
                   width=10).pack(fill=tk.X)

        self.n_var.trace('w', lambda *args: self._update_n_display())

    def _create_initial_conditions_section(self):
        """Create initial conditions section."""
        ttk.Label(self.init_frame, text=self.get_label('init_mode')).pack(anchor=tk.W)
        self.init_mode_var = tk.IntVar(value=1)
        mode_frame = ttk.Frame(self.init_frame)
        mode_frame.pack(fill=tk.X, pady=(0, 10))
        for i in range(1, 5):
            ttk.Radiobutton(mode_frame, text=f"{self.get_label('mode')} {i}",
                           variable=self.init_mode_var, value=i).pack(side=tk.LEFT)

        ttk.Label(self.init_frame, text=self.get_label('amplitude')).pack(anchor=tk.W)
        self.amplitude_var = tk.DoubleVar(value=4.0)
        amp_scale = ttk.Scale(self.init_frame, from_=0.5, to=10.0, variable=self.amplitude_var,
                             orient=tk.HORIZONTAL)
        amp_scale.pack(fill=tk.X)
        self.amp_label = ttk.Label(self.init_frame, text=f"A = {self.amplitude_var.get():.2f}")
        self.amp_label.pack(anchor=tk.E)
        self.amplitude_var.trace('w', lambda *args: self._update_amp_label())

        ttk.Label(self.init_frame, text=self.get_label('quick_preset')).pack(anchor=tk.W, pady=(10, 5))
        preset_frame = ttk.Frame(self.init_frame)
        preset_frame.pack(fill=tk.X)
        ttk.Button(preset_frame, text=self.get_label('classic'),
                  command=lambda: self._load_preset("classic")).pack(side=tk.LEFT, padx=2)
        ttk.Button(preset_frame, text=self.get_label('weak'),
                  command=lambda: self._load_preset("weak")).pack(side=tk.LEFT, padx=2)
        ttk.Button(preset_frame, text=self.get_label('strong'),
                  command=lambda: self._load_preset("strong")).pack(side=tk.LEFT, padx=2)

    def _create_simulation_section(self):
        """Create simulation control section."""
        ttk.Label(self.sim_frame, text=self.get_label('sim_time')).pack(anchor=tk.W)
        time_frame = ttk.Frame(self.sim_frame)
        time_frame.pack(fill=tk.X, pady=(0, 10))
        self.total_time_var = tk.DoubleVar(value=160.0)
        ttk.Entry(time_frame, textvariable=self.total_time_var, width=10).pack(side=tk.LEFT)
        ttk.Label(time_frame, text=self.get_label('periods')).pack(side=tk.LEFT, padx=(5, 0))

        btn_frame = ttk.Frame(self.sim_frame)
        btn_frame.pack(fill=tk.X, pady=10)

        self.run_btn = ttk.Button(btn_frame, text=self.get_label('run'),
                                 command=self.start_simulation, style='Run.TButton')
        self.run_btn.pack(side=tk.LEFT, padx=2)

        self.pause_btn = ttk.Button(btn_frame, text=self.get_label('pause'),
                                   command=self.pause_simulation, state=tk.DISABLED)
        self.pause_btn.pack(side=tk.LEFT, padx=2)

        self.reset_btn = ttk.Button(btn_frame, text=self.get_label('reset'),
                                   command=self.reset_simulation)
        self.reset_btn.pack(side=tk.LEFT, padx=2)

        ttk.Label(self.sim_frame, text=self.get_label('progress')).pack(anchor=tk.W, pady=(10, 0))
        self.progress_var = tk.DoubleVar(value=0)
        self.progress_bar = ttk.Progressbar(self.sim_frame, variable=self.progress_var,
                                           maximum=100, length=200)
        self.progress_bar.pack(fill=tk.X, pady=(5, 0))

        self.status_label = ttk.Label(self.sim_frame, text=self.get_label('status_ready'),
                                      foreground="green")
        self.status_label.pack(anchor=tk.W, pady=(10, 0))

    def _create_info_section(self):
        """Create information section."""
        self.energy_label = ttk.Label(self.info_frame, text=f"{self.get_label('total_energy')} -")
        self.energy_label.pack(anchor=tk.W)

        self.mode1_label = ttk.Label(self.info_frame, text=f"{self.get_label('mode1_energy')} -")
        self.mode1_label.pack(anchor=tk.W)

        self.recurrence_label = ttk.Label(self.info_frame, text=f"{self.get_label('fput_recurrence')} -")
        self.recurrence_label.pack(anchor=tk.W)

    def _create_main_plot_area(self):
        """Create the main plot display area."""
        # Header frame with title and save button
        header_frame = ttk.Frame(self.main_plot_frame)
        header_frame.pack(fill=tk.X, pady=5)

        self.main_plot_title = ttk.Label(header_frame, text=self.get_label('plot_main'),
                                         style='Header.TLabel')
        self.main_plot_title.pack(side=tk.LEFT)

        self.save_btn = ttk.Button(header_frame, text=self.get_label('save'),
                                   command=self._save_current_plot)
        self.save_btn.pack(side=tk.RIGHT)

        # Plot panels dictionary (will be populated in _init_plots)
        self.plot_panels = {}

        # Container for plot panels
        self.plot_container = ttk.Frame(self.main_plot_frame)
        self.plot_container.pack(fill=tk.BOTH, expand=True)

    def _create_thumbnail_area(self):
        """Create the thumbnail sidebar."""
        # Header
        header = ttk.Label(self.thumbnail_frame, text=self.get_label('thumbnails'),
                          style='Header.TLabel')
        header.pack(pady=10)

        # Scrollable thumbnail area
        canvas = tk.Canvas(self.thumbnail_frame, highlightthickness=0)
        scrollbar = ttk.Scrollbar(self.thumbnail_frame, orient="vertical", command=canvas.yview)

        self.thumbnail_container = ttk.Frame(canvas)
        self.thumbnail_container.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )

        canvas.create_window((0, 0), window=self.thumbnail_container, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)

        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        # Thumbnail buttons storage
        self.thumbnail_buttons = {}

        def _on_thumb_mousewheel(event):
            canvas.yview_scroll(int(-1*(event.delta/120)), "units")
        canvas.bind_all("<MouseWheel>", _on_thumb_mousewheel)

    def _recreate_thumbnails(self):
        """Recreate thumbnail buttons after language change."""
        for widget in self.thumbnail_container.winfo_children():
            widget.destroy()
        self.thumbnail_buttons = {}
        self._create_thumbnail_buttons()

    def _create_thumbnail_buttons(self):
        """Create clickable thumbnail buttons."""
        plot_configs = [
            (self.PLOT_MAIN, self.get_label('plot_main')),
            (self.PLOT_MODE1, self.get_label('plot_mode1')),
            (self.PLOT_PART, self.get_label('plot_part')),
            (self.PLOT_PHASE, self.get_label('plot_phase')),
            (self.PLOT_WATER, self.get_label('plot_water')),
        ]

        for plot_type, label in plot_configs:
            frame = ttk.Frame(self.thumbnail_container, relief="raised", borderwidth=2)
            frame.pack(fill=tk.X, padx=5, pady=5)

            # Thumbnail label
            lbl = ttk.Label(frame, text=label, font=('Arial', 8))
            lbl.pack(pady=2)

            # Create a small canvas for thumbnail preview
            thumb_fig = Figure(figsize=(2.5, 1.5), dpi=50)
            thumb_ax = thumb_fig.add_subplot(111)
            thumb_ax.set_xticks([])
            thumb_ax.set_yticks([])
            thumb_ax.set_title(label, fontsize=6)

            # Copy some visual style from main plot
            for line in self.plot_panels[plot_type].ax.get_lines():
                thumb_ax.plot([], [], color=line.get_color(), linewidth=1)

            thumb_canvas = FigureCanvasTkAgg(thumb_fig, master=frame)
            thumb_canvas.draw()
            thumb_canvas.get_tk_widget().pack()

            # Make the whole frame clickable
            def make_callback(pt):
                return lambda e: self._show_plot(pt)
            frame.bind("<Button-1>", make_callback(plot_type))
            lbl.bind("<Button-1>", make_callback(plot_type))
            thumb_canvas.get_tk_widget().bind("<Button-1>", make_callback(plot_type))

            # Store reference
            self.thumbnail_buttons[plot_type] = frame

        # Highlight current plot
        self._highlight_thumbnail(self.current_plot)

    def _highlight_thumbnail(self, plot_type):
        """Highlight the selected thumbnail."""
        for pt, frame in self.thumbnail_buttons.items():
            if pt == plot_type:
                frame.state(['selected'])
                frame.configure(relief="sunken", borderwidth=3)
            else:
                frame.state(['!selected'])
                frame.configure(relief="raised", borderwidth=2)

    def _show_plot(self, plot_type):
        """Show the selected plot in the main display area."""
        self.current_plot = plot_type
        self._highlight_thumbnail(plot_type)

        # Hide all plot panels
        for panel in self.plot_panels.values():
            panel.get_widget().pack_forget()

        # Show selected plot
        self.plot_panels[plot_type].get_widget().pack(fill=tk.BOTH, expand=True)

        # Update title
        title_map = {
            self.PLOT_MAIN: self.get_label('plot_main'),
            self.PLOT_MODE1: self.get_label('plot_mode1'),
            self.PLOT_PART: self.get_label('plot_part'),
            self.PLOT_PHASE: self.get_label('plot_phase'),
            self.PLOT_WATER: self.get_label('plot_water'),
        }
        self.main_plot_title.config(text=title_map.get(plot_type, ''))

    def _init_plots(self):
        """Initialize all plot panels."""
        # Create individual plot panels
        self.plot_panels = {
            self.PLOT_MAIN: PlotPanel(self.plot_container, self.get_label('plot_main'), (10, 6)),
            self.PLOT_MODE1: PlotPanel(self.plot_container, self.get_label('plot_mode1'), (8, 5)),
            self.PLOT_PART: PlotPanel(self.plot_container, self.get_label('plot_part'), (8, 5)),
            self.PLOT_PHASE: PlotPanel(self.plot_container, self.get_label('plot_phase'), (8, 5)),
            self.PLOT_WATER: PlotPanel(self.plot_container, self.get_label('plot_water'), (8, 5)),
        }

        # Initialize plot elements
        self._init_main_plot()
        self._init_mode1_plot()
        self._init_part_plot()
        self._init_phase_plot()
        self._init_water_plot()

        # Create thumbnail buttons
        self._create_thumbnail_buttons()

        # Show main plot initially
        self._show_plot(self.PLOT_MAIN)

    def _init_main_plot(self):
        """Initialize main energy evolution plot."""
        ax = self.plot_panels[self.PLOT_MAIN].ax
        ax.set_xlabel(self.get_label('xlabel_time'))
        ax.set_ylabel(self.get_label('ylabel_energy'))

        self.mode_lines = []
        colors = plt.cm.tab10(np.linspace(0, 1, 12))
        for i in range(12):
            line, = ax.plot([], [], label=f'M{i+1}', color=colors[i], linewidth=1.5)
            self.mode_lines.append(line)

        self.legend = ax.legend(loc='upper right', fontsize=8)
        self._update_legend()

    def _init_mode1_plot(self):
        """Initialize mode 1 detail plot."""
        ax = self.plot_panels[self.PLOT_MODE1].ax
        ax.set_xlabel(self.get_label('xlabel_time'))
        ax.set_ylabel(self.get_label('ylabel_energy'))

        self.mode1_line, = ax.plot([], [], 'b-', linewidth=1.5)
        self.mode1_ref = ax.axhline(y=0, color='r', linestyle='--',
                                   alpha=0.5, label=self.get_label('initial'))

    def _init_part_plot(self):
        """Initialize participation ratio plot."""
        ax = self.plot_panels[self.PLOT_PART].ax
        ax.set_xlabel(self.get_label('xlabel_time'))
        ax.set_ylabel(self.get_label('ylabel_modes'))
        self.part_line, = ax.plot([], [], 'purple', linewidth=1.5)

    def _init_phase_plot(self):
        """Initialize phase space plot."""
        ax = self.plot_panels[self.PLOT_PHASE].ax
        ax.set_xlabel(self.get_label('ylabel_mode'))
        ax.set_ylabel(self.get_label('ylabel_momentum'))
        self.phase_line, = ax.plot([], [], 'b-', linewidth=0.8, alpha=0.7)
        self.phase_point, = ax.plot([], [], 'ro', markersize=5)

    def _init_water_plot(self):
        """Initialize waterfall heatmap plot."""
        ax = self.plot_panels[self.PLOT_WATER].ax
        ax.set_xlabel(self.get_label('xlabel_time'))
        ax.set_ylabel(self.get_label('xlabel_mode'))

    def _update_plot_labels(self):
        """Update plot labels after language change."""
        # Main plot
        self.plot_panels[self.PLOT_MAIN].ax.set_title(self.get_label('plot_main'), fontsize=12, fontweight='bold')
        self.plot_panels[self.PLOT_MAIN].ax.set_xlabel(self.get_label('xlabel_time'))
        self.plot_panels[self.PLOT_MAIN].ax.set_ylabel(self.get_label('ylabel_energy'))

        # Mode 1 plot
        self.plot_panels[self.PLOT_MODE1].ax.set_title(self.get_label('plot_mode1'), fontsize=12, fontweight='bold')
        self.plot_panels[self.PLOT_MODE1].ax.set_xlabel(self.get_label('xlabel_time'))
        self.plot_panels[self.PLOT_MODE1].ax.set_ylabel(self.get_label('ylabel_energy'))
        self.mode1_ref.set_label(self.get_label('initial'))

        # Participation plot
        self.plot_panels[self.PLOT_PART].ax.set_title(self.get_label('plot_part'), fontsize=12, fontweight='bold')
        self.plot_panels[self.PLOT_PART].ax.set_xlabel(self.get_label('xlabel_time'))
        self.plot_panels[self.PLOT_PART].ax.set_ylabel(self.get_label('ylabel_modes'))

        # Phase plot
        self.plot_panels[self.PLOT_PHASE].ax.set_title(self.get_label('plot_phase'), fontsize=12, fontweight='bold')
        self.plot_panels[self.PLOT_PHASE].ax.set_xlabel(self.get_label('ylabel_mode'))
        self.plot_panels[self.PLOT_PHASE].ax.set_ylabel(self.get_label('ylabel_momentum'))

        # Waterfall plot
        self.plot_panels[self.PLOT_WATER].ax.set_title(self.get_label('plot_water'), fontsize=12, fontweight='bold')
        self.plot_panels[self.PLOT_WATER].ax.set_xlabel(self.get_label('xlabel_time'))
        self.plot_panels[self.PLOT_WATER].ax.set_ylabel(self.get_label('xlabel_mode'))

    def _update_legend(self):
        """Update legend based on number of modes to display."""
        n_modes = self.n_modes_var.get()
        lines = self.mode_lines[:n_modes]
        labels = [f'M{i+1}' for i in range(n_modes)]
        try:
            self.legend.remove()
        except:
            pass
        ax = self.plot_panels[self.PLOT_MAIN].ax
        self.legend = ax.legend(lines, labels, loc='upper right',
                               fontsize=8, ncol=min(6, n_modes))

    def _update_n_display(self, *args):
        n = self.n_var.get()
        self.n_info.config(text=f"{self.get_label('moving_particles')} {n}")
        self._update_max_modes()

    def _update_max_modes(self):
        self.max_modes = min(self.n_modes_var.get(), self.n_var.get())

    def _update_alpha_label(self, *args):
        self.alpha_label.config(text=f"α = {self.alpha_var.get():.3f}")

    def _update_beta_label(self, *args):
        self.beta_label.config(text=f"β = {self.beta_var.get():.3f}")

    def _update_amp_label(self, *args):
        self.amp_label.config(text=f"A = {self.amplitude_var.get():.2f}")

    def _load_preset(self, preset):
        if preset == "classic":
            self.n_var.set(32)
            self.nonlinearity_type.set("alpha")
            self.alpha_var.set(0.25)
            self.init_mode_var.set(1)
            self.amplitude_var.set(4.0)
            self.total_time_var.set(160.0)
        elif preset == "weak":
            self.n_var.set(32)
            self.nonlinearity_type.set("alpha")
            self.alpha_var.set(0.1)
            self.init_mode_var.set(1)
            self.amplitude_var.set(2.0)
            self.total_time_var.set(200.0)
        elif preset == "strong":
            self.n_var.set(16)
            self.nonlinearity_type.set("alpha")
            self.alpha_var.set(1.0)
            self.init_mode_var.set(1)
            self.amplitude_var.set(2.0)
            self.total_time_var.set(100.0)

        self._update_n_display()
        self._update_alpha_label()

    def start_simulation(self):
        if self.sim_running:
            return

        self._update_max_modes()
        self._update_legend()

        try:
            N = self.n_var.get()
            alpha = self.alpha_var.get() if self.nonlinearity_type.get() == "alpha" else 0
            beta = self.beta_var.get() if self.nonlinearity_type.get() == "beta" else 1.0
            dt = self.dt_var.get()

            if self.nonlinearity_type.get() == "beta":
                self.simulator = FPUTBetaSimulator(N=N, beta=beta, dt=dt)
            else:
                self.simulator = FPUTSimulator(N=N, alpha=alpha, dt=dt)

            self.simulator.set_initial_mode(mode=self.init_mode_var.get(),
                                           amplitude=self.amplitude_var.get())

            self.initial_energy = self.simulator.get_total_energy()
            self.initial_mode1_energy = self.simulator.compute_mode_energies()[0]

        except Exception as e:
            messagebox.showerror("Error", f"Failed to initialize simulator: {e}")
            return

        self.time_points = [0]
        self.mode_energies = [self.simulator.compute_mode_energies()]
        self.phase_coords = []
        self.phase_momenta = []

        self.energy_label.config(text=f"{self.get_label('total_energy')} {self.initial_energy:.6f}")
        self.mode1_label.config(text=f"{self.get_label('mode1_energy')} {self.initial_mode1_energy:.6f}")

        self._clear_plots()

        self.sim_running = True
        self.sim_paused = False
        self.run_btn.config(state=tk.DISABLED)
        self.pause_btn.config(state=tk.NORMAL, text=self.get_label('pause'))
        self.status_label.config(text=self.get_label('status_running'), foreground="blue")

        thread = threading.Thread(target=self._run_simulation, daemon=True)
        thread.start()

        self._update_plots()

    def _run_simulation(self):
        try:
            total_time = self.total_time_var.get()
            dt = self.dt_var.get()
            n_steps = int(total_time / dt)
            save_interval = max(1, n_steps // 500)

            integrator = self.integrator_var.get()
            if integrator == "verlet":
                step_func = self.simulator.step_velocity_verlet
            else:
                step_func = self.simulator.step_rk4

            for step in range(n_steps):
                if not self.sim_running:
                    break

                while self.sim_paused:
                    import time
                    time.sleep(0.1)

                step_func()

                if step % save_interval == 0:
                    self.time_points.append((step + 1) * dt)
                    self.mode_energies.append(self.simulator.compute_mode_energies())

                    Q = self.simulator.Q[1:self.simulator.N + 1]
                    P = self.simulator.P[1:self.simulator.N + 1]
                    from fput.normal_modes import compute_normal_mode_coordinates, compute_normal_mode_velocities
                    A = compute_normal_mode_coordinates(Q, self.simulator.N + 1)
                    A_dot = compute_normal_mode_velocities(P, self.simulator.N + 1)
                    self.phase_coords.append(A[0])
                    self.phase_momenta.append(A_dot[0])

                    progress = (step + 1) / n_steps * 100
                    self.result_queue.put(('progress', progress))

            mode1_energies = [e[0] for e in self.mode_energies]
            initial = self.initial_mode1_energy
            for i, e in enumerate(mode1_energies[10:]):
                if abs(e - initial) / initial < 0.03:
                    recurrence_time = self.time_points[i + 10]
                    self.result_queue.put(('recurrence', recurrence_time))
                    break

            self.result_queue.put(('done', None))

        except Exception as e:
            self.result_queue.put(('error', str(e)))

    def _update_plots(self):
        try:
            while True:
                msg_type, msg_data = self.result_queue.get_nowait()
                if msg_type == 'progress':
                    self.progress_var.set(msg_data)
                elif msg_type == 'recurrence':
                    self.recurrence_label.config(
                        text=f"{self.get_label('fput_recurrence')} t ≈ {msg_data:.1f}")
                elif msg_type == 'done':
                    self.sim_running = False
                    self.run_btn.config(state=tk.NORMAL)
                    self.pause_btn.config(state=tk.DISABLED)
                    self.status_label.config(text=self.get_label('status_done'), foreground="green")
                elif msg_type == 'error':
                    self.sim_running = False
                    self.run_btn.config(state=tk.NORMAL)
                    self.pause_btn.config(state=tk.DISABLED)
                    self.status_label.config(text="Error!", foreground="red")
                    messagebox.showerror("Simulation Error", msg_data)
        except queue.Empty:
            pass

        if len(self.time_points) > 1:
            time_arr = np.array(self.time_points)
            energies_arr = np.array(self.mode_energies)
            n_modes = min(self.n_modes_var.get(), self.n_var.get())

            # Update main plot
            for i in range(n_modes):
                self.mode_lines[i].set_data(time_arr, energies_arr[:, i])
            for i in range(n_modes, 12):
                self.mode_lines[i].set_data([], [])

            ax_main = self.plot_panels[self.PLOT_MAIN].ax
            ax_main.set_xlim(0, max(time_arr))
            ax_main.set_ylim(0, np.max(energies_arr[:, :n_modes]) * 1.1)

            # Update mode 1 detail
            self.mode1_line.set_data(time_arr, energies_arr[:, 0])
            self.mode1_ref.set_ydata([self.initial_mode1_energy])
            ax_mode1 = self.plot_panels[self.PLOT_MODE1].ax
            ax_mode1.set_xlim(0, max(time_arr))
            ax_mode1.set_ylim(0, max(energies_arr[:, 0]) * 1.1)

            # Update participation ratio
            p = energies_arr / energies_arr.sum(axis=1, keepdims=True)
            participation = 1.0 / np.sum(p**2, axis=1)
            self.part_line.set_data(time_arr, participation)
            ax_part = self.plot_panels[self.PLOT_PART].ax
            ax_part.set_xlim(0, max(time_arr))
            ax_part.set_ylim(0, max(participation) * 1.1)

            # Update phase space
            if len(self.phase_coords) > 1:
                self.phase_line.set_data(self.phase_coords, self.phase_momenta)
                self.phase_point.set_data([self.phase_coords[-1]], [self.phase_momenta[-1]])
                ax_phase = self.plot_panels[self.PLOT_PHASE].ax
                ax_phase.set_xlim(min(self.phase_coords) * 1.1, max(self.phase_coords) * 1.1)
                ax_phase.set_ylim(min(self.phase_momenta) * 1.1, max(self.phase_momenta) * 1.1)

            # Update waterfall
            ax_water = self.plot_panels[self.PLOT_WATER].ax
            ax_water.clear()
            ax_water.set_title(self.get_label('plot_water'), fontsize=12, fontweight='bold')
            ax_water.set_xlabel(self.get_label('xlabel_time'))
            ax_water.set_ylabel(self.get_label('xlabel_mode'))
            ax_water.grid(True, alpha=0.3)
            modes_to_show = list(range(1, min(n_modes + 1, 10)))
            T, M = np.meshgrid(time_arr, modes_to_show)
            E_subset = energies_arr[:, :len(modes_to_show)].T
            ax_water.pcolormesh(T, M, E_subset, shading='nearest', cmap='viridis')

            # Redraw current panel
            self.plot_panels[self.current_plot].canvas.draw()

        if self.sim_running:
            self.root.after(200, self._update_plots)

    def _clear_plots(self):
        for line in self.mode_lines:
            line.set_data([], [])
        self.mode1_line.set_data([], [])
        self.phase_line.set_data([], [])
        self.phase_point.set_data([], [])
        self.part_line.set_data([], [])

        for panel in self.plot_panels.values():
            ax = panel.ax
            ax.set_xlim(0, 1)
            ax.set_ylim(0, 1)
            panel.canvas.draw()

        # Clear waterfall
        self.plot_panels[self.PLOT_WATER].ax.clear()
        self.plot_panels[self.PLOT_WATER].ax.set_title(self.get_label('plot_water'), fontsize=12, fontweight='bold')
        self.plot_panels[self.PLOT_WATER].ax.set_xlabel(self.get_label('xlabel_time'))
        self.plot_panels[self.PLOT_WATER].ax.set_ylabel(self.get_label('xlabel_mode'))
        self.plot_panels[self.PLOT_WATER].ax.grid(True, alpha=0.3)
        self.plot_panels[self.PLOT_WATER].canvas.draw()

    def pause_simulation(self):
        self.sim_paused = not self.sim_paused
        if self.sim_paused:
            self.pause_btn.config(text=self.get_label('resume'))
            self.status_label.config(text=self.get_label('status_paused'), foreground="orange")
        else:
            self.pause_btn.config(text=self.get_label('pause'))
            self.status_label.config(text=self.get_label('status_running'), foreground="blue")

    def _save_current_plot(self):
        """Save the currently displayed plot."""
        from tkinter import filedialog
        filetypes = [
            ('PNG files', '*.png'),
            ('PDF files', '*.pdf'),
            ('SVG files', '*.svg'),
            ('All files', '*.*')
        ]
        filename = filedialog.asksaveasfilename(
            defaultextension='.png',
            filetypes=filetypes,
            title='Save Plot'
        )
        if filename:
            self.plot_panels[self.current_plot].save(filename)
            messagebox.showinfo('Success', f'Plot saved to {filename}')

    def reset_simulation(self):
        self.sim_running = False
        self.sim_paused = False
        self.time_points = []
        self.mode_energies = []
        self.phase_coords = []
        self.phase_momenta = []

        self.progress_var.set(0)
        self.run_btn.config(state=tk.NORMAL)
        self.pause_btn.config(state=tk.DISABLED, text=self.get_label('pause'))
        self.status_label.config(text=self.get_label('status_ready'), foreground="green")
        self.energy_label.config(text=f"{self.get_label('total_energy')} -")
        self.mode1_label.config(text=f"{self.get_label('mode1_energy')} -")
        self.recurrence_label.config(text=f"{self.get_label('fput_recurrence')} -")

        self._clear_plots()


def main():
    """Launch the FPUT GUI application."""
    root = tk.Tk()
    app = FPUTSimulatorGUI(root)
    root.mainloop()


if __name__ == "__main__":
    main()
