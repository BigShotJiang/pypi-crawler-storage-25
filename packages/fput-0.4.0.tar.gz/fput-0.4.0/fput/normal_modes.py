"""
Normal Mode Calculations for FPUT System.

This module provides functions for converting between physical coordinates
and normal mode coordinates, as well as computing mode energies.

The FPUT system has N moving particles (Q_1 to Q_N) with fixed endpoints:
Q_0 = 0 and Q_{N+1} = 0.
"""

import numpy as np
from typing import Tuple, Optional


def compute_normal_mode_coordinates(Q: np.ndarray, N_with_boundary: int) -> np.ndarray:
    """
    Convert physical coordinates to normal mode coordinates.

    A_l = sqrt(2/(N+1)) * sum_{k=1}^{N} Q_k * sin(k*l*pi/(N+1))

    Parameters
    ----------
    Q : ndarray
        Physical coordinates of moving particles, shape (N,)
    N_with_boundary : int
        N+1 where N is the number of moving particles.

    Returns
    -------
    A : ndarray
        Normal mode coordinates, shape (N,)
    """
    N = len(Q)
    A = np.zeros(N)
    prefactor = np.sqrt(2 / N_with_boundary)

    k = np.arange(1, N + 1)  # Particle indices

    for l in range(1, N + 1):  # Mode indices
        A[l - 1] = prefactor * np.sum(Q * np.sin(k * l * np.pi / N_with_boundary))

    return A


def compute_normal_mode_velocities(P: np.ndarray, N_with_boundary: int) -> np.ndarray:
    """
    Convert physical velocities to normal mode velocities.

    Parameters
    ----------
    P : ndarray
        Physical momenta of moving particles, shape (N,)
    N_with_boundary : int
        N+1 where N is the number of moving particles.

    Returns
    -------
    A_dot : ndarray
        Normal mode velocities, shape (N,)
    """
    return compute_normal_mode_coordinates(P, N_with_boundary)


def compute_normal_mode_energies(Q: np.ndarray, P: np.ndarray, N_with_boundary: int) -> np.ndarray:
    """
    Compute the energy in each normal mode.

    E_k = 1/2 * (A_dot_k^2 + omega_k^2 * A_k^2)

    where omega_k = 2*sin(k*pi/(2*(N+1)))

    Parameters
    ----------
    Q : ndarray
        Physical coordinates of moving particles, shape (N,)
    P : ndarray
        Physical momenta of moving particles, shape (N,)
    N_with_boundary : int
        N+1 where N is the number of moving particles.

    Returns
    -------
    energies : ndarray
        Energy in each normal mode, shape (N,)
    """
    A = compute_normal_mode_coordinates(Q, N_with_boundary)
    A_dot = compute_normal_mode_velocities(P, N_with_boundary)

    # Mode frequencies
    N = len(Q)
    k = np.arange(1, N + 1)
    omega = 2 * np.sin(k * np.pi / (2 * N_with_boundary))

    # Mode energies
    energies = 0.5 * (A_dot**2 + omega**2 * A**2)

    return energies


def mode_energy(A: float, A_dot: float, omega: float) -> float:
    """
    Compute energy of a single normal mode.

    Parameters
    ----------
    A : float
        Mode coordinate amplitude.
    A_dot : float
        Mode velocity amplitude.
    omega : float
        Mode frequency.

    Returns
    -------
    energy : float
        Mode energy.
    """
    return 0.5 * (A_dot**2 + omega**2 * A**2)


def frequencies(N_with_boundary: int, n_modes: Optional[int] = None) -> np.ndarray:
    """
    Compute normal mode frequencies.

    omega_k = 2*sin(k*pi/(2*(N+1)))

    Parameters
    ----------
    N_with_boundary : int
        N+1 where N is the number of moving particles.
    n_modes : int, optional
        Number of frequencies to compute. If None, compute all N modes.

    Returns
    -------
    omega : ndarray
        Mode frequencies.
    """
    if n_modes is None:
        n_modes = N_with_boundary - 1
    k = np.arange(1, n_modes + 1)
    return 2 * np.sin(k * np.pi / (2 * N_with_boundary))


def fundamental_period(N_with_boundary: int) -> float:
    """
    Compute the period of the fundamental (first) mode.

    T_1 = 2*pi / omega_1

    Parameters
    ----------
    N_with_boundary : int
        N+1 where N is the number of moving particles.

    Returns
    -------
    period : float
        Period of the fundamental mode.
    """
    omega_1 = 2 * np.sin(np.pi / (2 * N_with_boundary))
    return 2 * np.pi / omega_1
