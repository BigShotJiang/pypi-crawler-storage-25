"""
FPUT - Fermi-Pasta-Ulam-Tsingou Problem Simulator

A Python package for simulating the classic FPUT nonlinear oscillator chain.
"""

__version__ = "0.4.0"
__author__ = "FPUT Project Contributors"

from fput.simulator import FPUTSimulator, FPUTBetaSimulator
from fput.normal_modes import compute_normal_mode_energies, compute_normal_mode_coordinates
from fput.utils import energy, mode_energy
from fput.gui import FPUTSimulatorGUI

__all__ = [
    "FPUTSimulator",
    "FPUTBetaSimulator",
    "FPUTSimulatorGUI",
    "compute_normal_mode_energies",
    "compute_normal_mode_coordinates",
    "energy",
    "mode_energy",
]
