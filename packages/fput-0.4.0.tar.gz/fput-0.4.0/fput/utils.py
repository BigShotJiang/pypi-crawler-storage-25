"""
Utility functions for FPUT simulations.
"""

import numpy as np
import matplotlib.pyplot as plt
from typing import Optional, List, Tuple


def energy(Q: np.ndarray, P: np.ndarray, alpha: float = 0.25, beta: float = 0.0) -> float:
    """
    Compute the total Hamiltonian of the FPUT system.

    Parameters
    ----------
    Q : ndarray
        Coordinates including endpoints, shape (N,)
    P : ndarray
        Momenta including endpoints, shape (N,)
    alpha : float
        Quadratic nonlinear coupling parameter.
    beta : float
        Quartic nonlinear coupling parameter.

    Returns
    -------
    H : float
        Total energy.
    """
    # Kinetic energy
    KE = 0.5 * np.sum(P[1:-1]**2)

    # Potential energy
    delta_Q = Q[1:] - Q[:-1]
    PE_linear = 0.5 * np.sum(delta_Q**2)
    PE_alpha = (alpha / 3) * np.sum(delta_Q**3)
    PE_beta = (beta / 4) * np.sum(delta_Q**4)

    return KE + PE_linear + PE_alpha + PE_beta


def mode_energy(A: float, A_dot: float, omega: float) -> float:
    """
    Compute energy of a single normal mode.

    Parameters
    ----------
    A : float
        Mode coordinate amplitude.
    A_dot : float
        Mode velocity amplitude.
    omega : float
        Mode frequency.

    Returns
    -------
    energy : float
        Mode energy.
    """
    return 0.5 * (A_dot**2 + omega**2 * A**2)


def plot_mode_energies(
    time_points: np.ndarray,
    mode_energies: np.ndarray,
    n_modes: int = 6,
    time_unit: str = "periods",
    figsize: Tuple[int, int] = (12, 8),
    ax: Optional[plt.Axes] = None
) -> plt.Axes:
    """
    Plot the evolution of normal mode energies.

    Parameters
    ----------
    time_points : ndarray
        Time values.
    mode_energies : ndarray
        Mode energies, shape (n_time, n_modes).
    n_modes : int
        Number of modes to plot.
    time_unit : str
        Label for time axis ("periods" or "seconds").
    figsize : tuple
        Figure size if ax is None.
    ax : Axes, optional
        Existing axes to plot on.

    Returns
    -------
    ax : Axes
        The plot axes.
    """
    if ax is None:
        fig, ax = plt.subplots(figsize=figsize)

    colors = plt.cm.tab10(np.linspace(0, 1, n_modes))

    for i in range(min(n_modes, mode_energies.shape[1])):
        ax.plot(time_points, mode_energies[:, i],
                label=f'Mode {i+1}', color=colors[i], linewidth=1.5)

    ax.set_xlabel(f'Time ({time_unit})')
    ax.set_ylabel('Energy')
    ax.set_title('FPUT Normal Mode Energy Evolution')
    ax.legend(loc='upper right')
    ax.grid(True, alpha=0.3)

    return ax


def plot_mode_energies_classic(
    time_points: np.ndarray,
    mode_energies: np.ndarray,
    n_modes: int = 6,
    figsize: Tuple[int, int] = (10, 12)
) -> plt.Axes:
    """
    Create a classic FPUT-style plot with stacked subplots.

    Similar to the original FPUT paper figure.

    Parameters
    ----------
    time_points : ndarray
        Time values.
    mode_energies : ndarray
        Mode energies, shape (n_time, n_modes).
    n_modes : int
        Number of modes to plot.
    figsize : tuple
        Figure size.

    Returns
    -------
    axes : ndarray of Axes
        The plot axes.
    """
    n_plot = min(n_modes, mode_energies.shape[1])
    fig, axes = plt.subplots(n_plot, 1, figsize=figsize, sharex=True)

    for i in range(n_plot):
        ax = axes[i] if n_plot > 1 else axes
        ax.plot(time_points, mode_energies[:, i], 'k-', linewidth=1)
        ax.set_ylabel(f'$E_{i+1}$')
        ax.set_ylim(0, np.max(mode_energies[:, i]) * 1.1)
        ax.grid(True, alpha=0.3)

    axes[-1].set_xlabel('Time (fundamental periods)')
    fig.suptitle('FPUT Normal Mode Energies', y=0.995)

    plt.tight_layout()
    return axes


def compute_energy_sharing(time_points: np.ndarray, mode_energies: np.ndarray) -> dict:
    """
    Compute statistics about energy sharing among modes.

    Parameters
    ----------
    time_points : ndarray
        Time values.
    mode_energies : ndarray
        Mode energies, shape (n_time, n_modes).

    Returns
    -------
    stats : dict
        Dictionary containing:
        - 'total_energy': Total energy (should be conserved)
        - 'initial_mode_fraction': Fraction of energy in initial mode over time
        - 'participation_ratio': Number of modes significantly occupied
        - 'energy_entropy': Shannon entropy of energy distribution
    """
    total_energy = np.sum(mode_energies, axis=1)
    n_modes = mode_energies.shape[1]

    # Energy fraction in mode 1
    mode1_fraction = mode_energies[:, 0] / (total_energy + 1e-16)

    # Participation ratio: 1 / sum(p_i^2) where p_i = E_i / E_total
    p = mode_energies / (total_energy[:, np.newaxis] + 1e-16)
    participation_ratio = 1.0 / np.sum(p**2, axis=1)

    # Energy entropy
    entropy = -np.sum(p * np.log(p + 1e-16), axis=1)

    return {
        'total_energy': total_energy,
        'initial_mode_fraction': mode1_fraction,
        'participation_ratio': participation_ratio,
        'energy_entropy': entropy
    }


def find_recurrence_times(
    time_points: np.ndarray,
    mode1_energy: np.ndarray,
    initial_energy: float,
    threshold: float = 0.03
) -> np.ndarray:
    """
    Find times when energy returns close to the initial mode.

    Parameters
    ----------
    time_points : ndarray
        Time values.
    mode1_energy : ndarray
        Energy of mode 1 over time.
    initial_energy : float
        Initial energy in mode 1.
    threshold : float
        Threshold for considering energy "returned" (fraction of initial).

    Returns
    -------
    recurrence_times : ndarray
        Times when recurrence occurs.
    """
    # Find where mode 1 energy is within threshold of initial
    relative_diff = np.abs(mode1_energy - initial_energy) / initial_energy
    recurrence_indices = np.where(relative_diff < threshold)[0]

    # Group nearby indices
    if len(recurrence_indices) > 0:
        recurrence_times = time_points[recurrence_indices]
        # Filter to keep only significant recurrences
        significant = []
        last_t = -1000
        for t in recurrence_times:
            if t - last_t > 10:  # At least 10 time units apart
                significant.append(t)
                last_t = t
        return np.array(significant)

    return np.array([])
