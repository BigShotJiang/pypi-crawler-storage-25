"""Tests for FPUT package."""
