"""Tests for FPUT simulator."""

import pytest
import numpy as np
from fput import FPUTSimulator, FPUTBetaSimulator


class TestFPUTSimulator:
    """Test the FPUT simulator."""

    def test_initialization(self):
        """Test that simulator initializes correctly."""
        sim = FPUTSimulator(N=32, alpha=0.25)
        assert sim.N == 32
        assert sim.N_moving == 32
        assert sim.alpha == 0.25
        assert len(sim.omega) == 32
        assert len(sim.Q) == 34  # N + 2 for endpoints

    def test_frequencies(self):
        """Test normal mode frequencies."""
        sim = FPUTSimulator(N=8)
        # First mode frequency
        expected_omega1 = 2 * np.sin(np.pi / (2 * 9))  # 2*sin(pi/(2*(N+1)))
        assert np.isclose(sim.omega[0], expected_omega1)

    def test_initial_mode(self):
        """Test setting initial mode condition."""
        sim = FPUTSimulator(N=8)
        sim.set_initial_mode(mode=1, amplitude=2.0)

        # Check that momenta are zero
        assert np.allclose(sim.P, 0)

        # Check fundamental frequency pattern
        k = np.arange(1, sim.N + 1)
        expected_Q = 2.0 * np.sin(k * np.pi / (sim.N + 1))
        # Moving particles are Q[1] to Q[N]
        assert np.allclose(sim.Q[1:sim.N + 1], expected_Q)

    def test_initial_sine_wave(self):
        """Test sine wave initial condition."""
        sim = FPUTSimulator(N=16)
        sim.set_initial_sine_wave(amplitude=3.0)

        k = np.arange(1, sim.N + 1)
        expected_Q = 3.0 * np.sin(k * np.pi / (sim.N + 1))
        assert np.allclose(sim.Q[1:sim.N + 1], expected_Q)

    def test_endpoints_fixed(self):
        """Test that endpoints remain fixed."""
        sim = FPUTSimulator(N=10)
        sim.set_initial_mode(mode=1, amplitude=5.0)

        assert sim.Q[0] == 0
        assert sim.Q[sim.N + 1] == 0

    def test_energy_conservation(self):
        """Test that total energy is conserved."""
        sim = FPUTSimulator(N=32, alpha=0.25, dt=0.01)
        sim.set_initial_mode(mode=1, amplitude=1.0)

        initial_energy = sim.get_total_energy()

        # Run for some steps
        for _ in range(1000):
            sim.step_rk4()

        final_energy = sim.get_total_energy()

        # Energy should be conserved to within ~1% for RK4
        relative_error = abs(final_energy - initial_energy) / initial_energy
        assert relative_error < 0.01

    def test_mode_energies(self):
        """Test normal mode energy calculation."""
        sim = FPUTSimulator(N=8, alpha=0)
        sim.set_initial_mode(mode=1, amplitude=1.0)

        energies = sim.compute_mode_energies()

        # Only mode 1 should have energy (with alpha=0)
        assert energies[0] > 0
        # Other modes should have essentially zero energy
        assert np.all(energies[1:] < 1e-10)

    def test_simulation_run(self):
        """Test running a full simulation."""
        sim = FPUTSimulator(N=16, alpha=0.25, dt=0.05)
        sim.set_initial_mode(mode=1, amplitude=2.0)

        result = sim.run(total_time=10, save_interval=10)

        assert len(result.time_points) > 1
        assert result.mode_energies.shape[1] == 16  # N modes

    def test_velocity_verlet(self):
        """Test Velocity Verlet integrator."""
        sim = FPUTSimulator(N=16, alpha=0.25, dt=0.01)
        sim.set_initial_mode(mode=1, amplitude=1.0)

        initial_energy = sim.get_total_energy()

        for _ in range(100):
            sim.step_velocity_verlet()

        final_energy = sim.get_total_energy()

        # Verlet should conserve energy well
        relative_error = abs(final_energy - initial_energy) / initial_energy
        assert relative_error < 0.001


class TestFPUTBetaSimulator:
    """Test the FPUT-beta simulator."""

    def test_initialization(self):
        """Test beta simulator initialization."""
        sim = FPUTBetaSimulator(N=32, beta=1.0)
        assert sim.N == 32
        assert sim.beta == 1.0
        assert sim.alpha == 0

    def test_energy_conservation(self):
        """Test energy conservation for beta system."""
        sim = FPUTBetaSimulator(N=16, beta=1.0, dt=0.01)
        sim.set_initial_mode(mode=1, amplitude=0.5)

        initial_energy = sim.get_total_energy()

        for _ in range(1000):
            sim.step_rk4()

        final_energy = sim.get_total_energy()

        relative_error = abs(final_energy - initial_energy) / initial_energy
        assert relative_error < 0.01
