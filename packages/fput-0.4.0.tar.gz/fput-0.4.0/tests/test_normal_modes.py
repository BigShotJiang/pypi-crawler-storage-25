"""Tests for normal mode calculations."""

import pytest
import numpy as np
from fput.normal_modes import (
    compute_normal_mode_coordinates,
    compute_normal_mode_velocities,
    compute_normal_mode_energies,
    frequencies,
    fundamental_period,
    mode_energy
)


class TestNormalModes:
    """Test normal mode computations."""

    def test_frequencies(self):
        """Test frequency calculation."""
        N = 8
        omega = frequencies(N + 1)  # N+1 for boundary

        assert len(omega) == N

        # First mode
        expected_omega1 = 2 * np.sin(np.pi / (2 * (N + 1)))
        assert np.isclose(omega[0], expected_omega1)

        # Frequencies should increase
        assert np.all(np.diff(omega) > 0)

    def test_fundamental_period(self):
        """Test fundamental period calculation."""
        N = 16
        T1 = fundamental_period(N + 1)

        omega1 = 2 * np.sin(np.pi / (2 * (N + 1)))
        expected_T1 = 2 * np.pi / omega1

        assert np.isclose(T1, expected_T1)

    def test_mode_coordinates(self):
        """Test normal mode coordinate transformation."""
        N = 8
        k = np.arange(1, N + 1)

        # Single mode pattern
        Q = np.sin(k * np.pi / (N + 1))
        A = compute_normal_mode_coordinates(Q, N + 1)

        # Should primarily excite mode 1
        assert A[0] > 0.9  # Mode 1 amplitude
        assert np.all(np.abs(A[1:]) < 0.1)  # Other modes small

    def test_mode_energies_single_mode(self):
        """Test mode energy for single mode excitation."""
        N = 16
        k = np.arange(1, N + 1)
        N_boundary = N + 1

        # Excite only mode 1
        omega1 = 2 * np.sin(np.pi / (2 * N_boundary))
        A1 = 1.0
        Q = A1 * np.sqrt(2 / N_boundary) * np.sin(k * np.pi / N_boundary)
        P = np.zeros_like(Q)

        energies = compute_normal_mode_energies(Q, P, N_boundary)

        # Only first mode should have energy
        assert energies[0] > 0
        assert np.all(energies[1:] < 1e-10)

        # Energy should be 0.5 * omega^2 * A^2
        expected_E = 0.5 * omega1**2 * A1**2
        assert np.isclose(energies[0], expected_E, rtol=0.01)

    def test_mode_energy_function(self):
        """Test individual mode energy function."""
        A = 2.0
        A_dot = 1.0
        omega = 1.5

        E = mode_energy(A, A_dot, omega)

        expected = 0.5 * (A_dot**2 + omega**2 * A**2)
        assert np.isclose(E, expected)

    def test_energy_sum_consistency(self):
        """Test that mode energies sum to total energy."""
        N = 16
        k = np.arange(1, N + 1)
        N_boundary = N + 1

        # Random state
        np.random.seed(42)
        Q = 0.1 * np.random.randn(N)
        P = 0.1 * np.random.randn(N)

        mode_energies = compute_normal_mode_energies(Q, P, N_boundary)

        # Total energy in modes
        E_modes = np.sum(mode_energies)

        # Direct calculation
        E_kinetic = 0.5 * np.sum(P**2)
        # Add virtual endpoints
        Q_full = np.concatenate([[0], Q, [0]])
        delta_Q = np.diff(Q_full)
        E_potential = 0.5 * np.sum(delta_Q**2)
        E_direct = E_kinetic + E_potential

        assert np.isclose(E_modes, E_direct, rtol=0.01)

    def test_orthogonality(self):
        """Test orthogonality of mode transformation."""
        N = 32
        N_boundary = N + 1

        # Create unit patterns for each mode
        k = np.arange(1, N + 1)

        for m in range(1, N + 1):
            # Pure mode pattern
            Q = np.sin(k * m * np.pi / N_boundary)
            A = compute_normal_mode_coordinates(Q, N_boundary)

            # Should have amplitude primarily in mode m
            max_idx = np.argmax(np.abs(A))
            assert max_idx == m - 1  # 0-indexed
