# This is a web server that reads from a Quokko web scraper database.

from flask import Flask, render_template, request
from flask_limiter.util import get_remote_address
from flask_limiter import Limiter
from pathlib import Path
import wikipediaapi
import datetime
import logging
import sqlite3
import yake
import os

try:
  template_directory = os.environ.get("QUOKKO_WEBAPP_TEMPLATES_DIRECTORY", None)
  static_directory = os.environ.get("QUOKKO_WEBAPP_STATIC_DIRECTORY", None)
  snapshot_db_file = os.environ.get("QUOKKO_WEBAPP_SNAPSHOT_DB_FILE", None)
  log_file = os.environ.get("QUOKKO_WEBAPP_LOG_FILE", None)
  user_agent = os.environ.get("QUOKKO_WEBAPP_USER_AGENT", None)

  if not user_agent:
    raise RuntimeError("Missing environment variable 'QUOKKO_WEBAPP_USER_AGENT'.")
  
  if static_directory:
    static_directory = Path("/") / static_directory
  else:
    static_directory = "static"
    
  if template_directory:
    template_directory = Path("/") / template_directory
  else:
    template_directory = "templates"

  snapshot_db_file = Path("/") / snapshot_db_file
  
  log_file = Path("/") / log_file
  
  if not snapshot_db_file:
    raise RuntimeError("Missing environment variable 'QUOKKO_WEBAPP_SNAPSHOT_DB_FILE'.")
  
  if not log_file:
    raise RuntimeError("Missing environment variable 'QUOKKO_WEBAPP_LOG_FILE'.")
  
  app = Flask(__name__, template_folder=template_directory, static_folder=static_directory)
  limiter = Limiter(get_remote_address, app=app, storage_uri="memory://")
  logger = logging.getLogger(__name__)
  logging.basicConfig(filename=log_file, level=logging.INFO)
  keyword_extractor = yake.KeywordExtractor()
  wiki_wiki = wikipediaapi.Wikipedia(user_agent=user_agent, language="en")
except OSError as e:
  raise RuntimeError(f"{e}")
except Exception as e:
  raise RuntimeError(f"{e}")

@limiter.limit("25 per minute")
@app.route("/", methods=["GET"])
def index():
  try:
    return render_template("index.html")
  except OSError as e:
    logger.info(f"Operating system error: {e}")
    return "<h1>There's an issue with our server.</h1>", 500
  except Exception as e:
    logger.info(f"Internal error: {e}")
    return render_template("message.html", search="", title="Internal error.", message="There's an issue with our server."), 500

@limiter.limit("100 per minute", key_func=lambda: "global")
@app.route("/search", methods=["GET"])
def search():
  try:
    query = request.args.get("query", None)
    
    if not query:
      return render_template("message.html", search="", title="Oops!", message="Cannot submit empty search."), 400

    if len(query) > 200:
      return render_template("message.html", search="", title="Oops!", message="Query too long."), 400

    oldquery = query

    query = query.strip().lower()
    newquery = ""
    for char in query:
      if char.isalnum() or char in [" "]:
        newquery += char
    query = newquery

    if not query:
      return render_template("message.html", search=oldquery, title="Oops!", message="Cannot submit search with only meaningless characters."), 400
      
    with sqlite3.connect(snapshot_db_file) as con:
      cur = con.cursor()
      
      command_result = cur.execute("""
      SELECT url, description, date_scraped FROM _search WHERE url MATCH ? OR description MATCH ?; 
      """, (query, query))
      
      results = command_result.fetchall()

      if not results:
        keywords_query = keyword_extractor.extract_keywords(query)
  
        if len(keywords_query) == 1:          
          command_result = cur.execute("""
          SELECT url, description, date_scraped FROM _search WHERE url MATCH ? OR description MATCH ?; 
          """, (keywords_query[0][0], keywords_query[0][0]))
          results = command_result.fetchall()
          
        elif len(keywords_query) > 1:
          command_result = cur.execute("""
          SELECT url, description, date_scraped FROM _search WHERE url MATCH ? OR description MATCH ?; 
          """, (f"{keywords_query[0][0]} {keywords_query[1][0]}", f"{keywords_query[0][0]} {keywords_query[1][0]}"))
          results = command_result.fetchall()
  
          if not results:
            command_result = cur.execute("""
            SELECT url, description, date_scraped FROM _search WHERE url MATCH ? OR description MATCH ?; 
            """, (keywords_query[0][0], keywords_query[0][0]))
            results = command_result.fetchall()

    if not results:
      return render_template("message.html", search=oldquery, title="Sorry!", message="We can't find anything about your query!"), 404

    new_results = []
    
    page_py = wiki_wiki.page(oldquery)
    if not page_py.exists():
      page_py = wiki_wiki.page(query)
    if page_py.exists():
      summary = "Wikipedia Summary | " + page_py.summary
      if len(summary) > 321:
        summary = summary[:321] + "..."
      summary += " | Open the link for more information."
      new_results.append(( page_py.fullurl, summary, "" ))
    
    count = 0
    for result in results:
      if result[2] == 0:
        date_for_result = ""
      else:
        date_for_result = datetime.datetime.fromtimestamp(int(result[2])).strftime("%b %d, %Y")
      
      new_results.append(( result[0], result[1], date_for_result ))
      
      if count >= 20:
        break
      else:
        count += 1

    final_results = []
    for i in range(len(new_results)):
      j = i + 1
      if j % 2 == 0:
        final_results.append([new_results[i-1], new_results[i]])
        
      if j == len(new_results):
        if j % 2 != 0:
          final_results.append([new_results[i], None])
    
    return render_template("search.html", results = final_results, search = oldquery), 200
  except OSError as e:
    logger.info(f"Operating system error: {e}")
    return "<h1>There's an issue with our server.</h1>", 500
  except Exception as e:
    logger.info(f"Internal error: {e}")
    return render_template("message.html", search="", title="Internal error.", message="There's an issue with our server."), 500

@app.errorhandler(404)
def not_found(e):
  try:
    return render_template("message.html", search="", title="Not found.", message="We couldn't find your page."), 404
  except OSError as e:
    logger.info(f"Operating system error: {e}")
    return "<h1>There's an issue with our server.</h1>", 500
  except Exception as e:
    logger.info(f"Internal error: {e}")
    return render_template("message.html", search="", title="Internal error.", message="There's an issue with our server."), 500