from .downloader import get_binary_path, download_binaries

def get_ffmpeg_path():
    """
    Returns the absolute path to the ffmpeg binary.
    Downloads the binary if it's not already present.
    """
    return get_binary_path("ffmpeg")

def get_ffprobe_path():
    """
    Returns the absolute path to the ffprobe binary.
    Downloads the binary if it's not already present.
    """
    return get_binary_path("ffprobe")

__all__ = ["get_ffmpeg_path", "get_ffprobe_path", "download_binaries"]
