import os
import urllib.request
import stat
from pathlib import Path
from .utils import get_binary_names, get_platform, get_architecture
from .constants import DOWNLOAD_BASE_URL

def get_bin_dir():
    """
    Returns the directory where binaries are stored.
    Defaults to a 'bin' directory inside the package.
    """
    pkg_dir = Path(__file__).parent.absolute()
    bin_dir = pkg_dir / "bin"
    bin_dir.mkdir(exist_ok=True)
    return bin_dir

import sys

def progress_bar(count, block_size, total_size):
    if total_size <= 0:
        return
    progress = count * block_size
    percent = min(100, int(progress * 100 / total_size))
    bar_length = 40
    filled_length = int(bar_length * percent / 100)
    bar = "█" * filled_length + "-" * (bar_length - filled_length)
    
    # Format size in MB
    progress_mb = progress / (1024 * 1024)
    total_mb = total_size / (1024 * 1024)
    
    sys.stdout.write(f"\r|{bar}| {percent}% ({progress_mb:.1f}/{total_mb:.1f} MB)")
    sys.stdout.flush()

def download_binaries(force=False):
    """
    Downloads ffmpeg and ffprobe binaries if they don't exist.
    """
    bin_dir = get_bin_dir()
    names = get_binary_names()
    
    binaries = {
        "ffmpeg": bin_dir / names["ffmpeg"],
        "ffprobe": bin_dir / names["ffprobe"]
    }

    for key, path in binaries.items():
        if not path.exists() or force:
            url = f"{DOWNLOAD_BASE_URL}/{names[key]}"
            print(f"\nDownloading {key}...")
            
            try:
                urllib.request.urlretrieve(url, path, reporthook=progress_bar)
                print(f"\nDownloaded {key} to {path}")
                
                # Set executable permissions
                if os.name != 'nt':
                    st = os.stat(path)
                    os.chmod(path, st.st_mode | stat.S_IEXEC)
            except Exception as e:
                if path.exists():
                    os.remove(path)
                print(f"\nError downloading {key}: {e}")
                raise

    return binaries

def get_binary_path(name):
    """
    Returns the path to the requested binary, downloading if necessary.
    """
    bin_dir = get_bin_dir()
    names = get_binary_names()
    binary_name = names.get(name)
    if not binary_name:
        raise ValueError(f"Unknown binary: {name}")
    
    path = bin_dir / binary_name
    if not path.exists():
        download_binaries()
    
    return str(path)
