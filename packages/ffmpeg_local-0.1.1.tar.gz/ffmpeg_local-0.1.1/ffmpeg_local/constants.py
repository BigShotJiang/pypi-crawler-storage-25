DOWNLOAD_BASE_URL = "https://github.com/iqbal-rashed/ytdlp-nodejs/releases/download/ffmpeg-latest"

PLATFORM_MAPPINGS = {
    "win32": {
        "x64": ["win-x64-ffmpeg.exe", "win-x64-ffprobe.exe"],
        "ia32": ["win-ia32-ffmpeg.exe", "win-ia32-ffprobe.exe"],
        "arm64": ["win-arm64-ffmpeg.exe", "win-arm64-ffprobe.exe"],
    },
    "linux": {
        "x64": ["linux-x64-ffmpeg", "linux-x64-ffprobe"],
        "arm64": ["linux-arm64-ffmpeg", "linux-arm64-ffprobe"],
    },
    "darwin": {
        "x64": ["macos-x64-ffmpeg", "macos-x64-ffprobe"],
        "arm64": ["macos-arm64-ffmpeg", "macos-arm64-ffprobe"],
    },
    "android": {
        "arm64": ["linux-arm64-ffmpeg", "linux-arm64-ffprobe"],
    },
}
