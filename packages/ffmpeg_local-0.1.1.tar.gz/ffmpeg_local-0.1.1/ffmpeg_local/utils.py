import sys
import platform
import os
from .constants import PLATFORM_MAPPINGS

class UnsupportedPlatformError(Exception):
    def __init__(self, platform_name, architecture):
        self.platform_name = platform_name
        self.architecture = architecture
        super().__init__(f"Unsupported platform: {platform_name} {architecture}")

def get_platform():
    """
    Returns the platform name compatible with PLATFORM_MAPPINGS.
    """
    system = sys.platform
    if system == "win32":
        return "win32"
    if system == "darwin":
        return "darwin"
    if system.startswith("linux"):
        # Check for android
        if os.path.exists("/system/bin/app_process") or "android" in platform.release().lower():
            return "android"
        return "linux"
    return system

def get_architecture():
    """
    Returns the architecture name compatible with PLATFORM_MAPPINGS.
    """
    machine = platform.machine().lower()
    if machine in ["x86_64", "amd64"]:
        return "x64"
    if machine in ["i386", "i686", "x86"]:
        return "ia32"
    if machine in ["aarch64", "arm64"]:
        return "arm64"
    return machine

def get_binary_names(plat=None, arch=None):
    if plat is None:
        plat = get_platform()
    if arch is None:
        arch = get_architecture()
    
    platform_mappings = PLATFORM_MAPPINGS.get(plat)
    if not platform_mappings:
        raise UnsupportedPlatformError(plat, arch)

    binaries = platform_mappings.get(arch)
    if not binaries or len(binaries) < 2:
        raise UnsupportedPlatformError(plat, arch)

    return {"ffmpeg": binaries[0], "ffprobe": binaries[1]}

def is_windows():
    return sys.platform == "win32"
