# ffmpeg-local

A Python package that provides a simple way to get `ffmpeg` and `ffprobe` binaries for your platform. It automatically downloads the binaries from the official [nodejs-ffmpeg](https://github.com/iqbal-rashed/nodejs-ffmpeg) release source.

## Installation

```bash
pip install ffmpeg-local
```

The package is lightweight and does not include the large binaries in the initial download. Instead, the appropriate `ffmpeg` and `ffprobe` binaries will be **automatically downloaded with a progress bar** the first time you call `get_ffmpeg_path()` or `get_ffprobe_path()`.

## Usage

```python
from ffmpeg_local import get_ffmpeg_path, get_ffprobe_path
import subprocess

# Get the path to the ffmpeg binary
ffmpeg_path = get_ffmpeg_path()
print(f"FFmpeg is at: {ffmpeg_path}")

# Use it in a subprocess
subprocess.run([ffmpeg_path, "-version"])

# Get the path to ffprobe
ffprobe_path = get_ffprobe_path()
print(f"FFprobe is at: {ffprobe_path}")
```

## Supported Platforms

- **Windows**: x64, ia32, arm64
- **Linux**: x64, arm64
- **macOS**: x64, arm64
- **Android**: arm64 (Termux etc.)

## CLI Utility

You can manually trigger the download using the CLI:

```bash
ffmpeg-local-download
```

## Credits

This package is a Python port of [nodejs-ffmpeg](https://github.com/iqbal-rashed/nodejs-ffmpeg).
Binaries are sourced from [ytdlp-nodejs](https://github.com/iqbal-rashed/ytdlp-nodejs).
