import os
import sys
from ffmpeg_local import get_ffmpeg_path, get_ffprobe_path
import subprocess

def test_binaries():
    print("Testing FFmpeg path...")
    ffmpeg = get_ffmpeg_path()
    print(f"Path: {ffmpeg}")
    assert os.path.exists(ffmpeg), "FFmpeg binary does not exist"
    
    result = subprocess.run([ffmpeg, "-version"], capture_output=True, text=True)
    print(f"FFmpeg version output (first line): {result.stdout.splitlines()[0]}")
    
    print("\nTesting FFprobe path...")
    ffprobe = get_ffprobe_path()
    print(f"Path: {ffprobe}")
    assert os.path.exists(ffprobe), "FFprobe binary does not exist"
    
    result = subprocess.run([ffprobe, "-version"], capture_output=True, text=True)
    print(f"FFprobe version output (first line): {result.stdout.splitlines()[0]}")

if __name__ == "__main__":
    test_binaries()
