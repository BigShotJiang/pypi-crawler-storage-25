"""Neruva MCP server.

Exposes Neruva Memory + HD Substrate to any MCP-aware host as a small
set of tools. Pure thin wrapper over the REST API at api.neruva.io --
this process holds NO algorithmic state and imports nothing from the
substrate core. The hard work happens server-side; this is just glue.

Env:
  NERUVA_API_KEY  required, your key from app.neruva.io
  NERUVA_URL      optional, defaults to https://api.neruva.io
"""

from __future__ import annotations

import asyncio
import json
import os
import sys
import time
from typing import Any
from urllib.parse import quote

import httpx
from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import TextContent, Tool

API_KEY = os.environ.get("NERUVA_API_KEY")
BASE_URL = os.environ.get("NERUVA_URL", "https://api.neruva.io").rstrip("/")

# Current version (bumped in lockstep with pyproject.toml). Surfaced
# in the startup banner so users know when they're running a stale
# install.
CURRENT_VERSION = "0.17.0"


def _check_for_update() -> None:
    """One-shot PyPI version check at startup. Soft -- never blocks if
    PyPI is flaky. Prints to stderr so the MCP host surfaces the banner."""
    try:
        with httpx.Client(timeout=2.5) as cli:
            r = cli.get("https://pypi.org/pypi/neruva-mcp/json")
        if r.status_code != 200:
            return
        latest = r.json().get("info", {}).get("version")
        if not latest or latest == CURRENT_VERSION:
            return
        print(
            f"[neruva-mcp] update available: you have {CURRENT_VERSION}, "
            f"latest is {latest}. Refresh: "
            f"pip install --upgrade neruva-mcp",
            file=sys.stderr,
        )
    except Exception:
        # Silent: never block startup on a flaky registry call.
        pass


# Optional auto-record. Set NERUVA_AUTO_RECORD=namespace[:ttl_days] to
# capture every tool call into a Neruva Records namespace as a typed
# event ({kind:"tool_call", tool, ...}) via fire-and-forget POSTs that
# never block or fail the user's call.
#
# Accepted forms (the legacy `index/` prefix from 0.4.x is silently
# dropped -- records have no index abstraction):
#   NERUVA_AUTO_RECORD=main              # no TTL
#   NERUVA_AUTO_RECORD=main:30           # auto-expire after 30 days
#   NERUVA_AUTO_RECORD=brain/main:30     # legacy form; "brain/" stripped
_AUTO_RECORD_RAW = os.environ.get("NERUVA_AUTO_RECORD", "")


def _parse_auto_record(s: str) -> tuple[str, int | None]:
    if not s:
        return "", None
    main, ttl_days = s, None
    colon_idx = s.rfind(":")
    if colon_idx > 0 and colon_idx > s.rfind("/"):
        tail = s[colon_idx + 1 :]
        try:
            n = int(tail)
            if n > 0:
                ttl_days = n
                main = s[:colon_idx]
        except ValueError:
            pass
    if "/" in main:
        _idx, ns = main.split("/", 1)  # legacy 'index/' prefix dropped
        return ns, ttl_days
    return main, ttl_days


AR_NAMESPACE, AR_TTL_DAYS = _parse_auto_record(_AUTO_RECORD_RAW)

NO_RECORD_TOOLS: set[str] = {
    # Records I/O used by the recorder itself -- recording these would loop.
    "records_ingest",
    "records_query",
    "records_timeline",
    "records_get",
    "records_delete",
    "records_forget",
    "records_stats",
    "records_export",
    "records_import",
    "records_compact",
    # Memory index (legacy vector layer) I/O -- same recursion concern.
    "memory_embed",
    "memory_upsert",
    "memory_upsert_text",
    "memory_query",
    "memory_query_text",
    "memory_fetch",
    "memory_update",
    "memory_replace_text",
    "memory_delete",
    "memory_forget_where",
    "memory_export",
    "memory_import",
    "memory_stats",
    "memory_list_indexes",
    "memory_describe_index",
    "memory_create_index",
    "memory_bind_role",
    "memory_read_roles",
}


def _record_preview(value: Any, max_len: int) -> str:
    try:
        s = value if isinstance(value, str) else json.dumps(value, default=str)
    except Exception:
        s = str(value)
    return s if len(s) <= max_len else s[:max_len] + "..."


async def _maybe_record(
    client: httpx.AsyncClient,
    tool_name: str,
    args: dict[str, Any],
    result: Any,
    latency_ms: int,
) -> None:
    if not AR_NAMESPACE:
        return
    if tool_name in NO_RECORD_TOOLS:
        return
    text = (
        f"{tool_name}({_record_preview(args, 400)})\n"
        f"=> {_record_preview(result, 800)}"
    )
    rid = f"mcp-{int(time.time() * 1000)}-{os.urandom(3).hex()}"
    now_ms = int(time.time() * 1000)
    item: dict[str, Any] = {
        "id": rid,
        "kind": "tool_call",
        "text": text,
        "tags": ["mcp", f"tool:{tool_name}"],
        "ts": now_ms,
        "meta": {"tool": tool_name, "latency_ms": latency_ms},
    }
    if AR_TTL_DAYS:
        item["ttlDays"] = AR_TTL_DAYS
    try:
        await client.post(
            f"{BASE_URL}/v1/records/{quote(AR_NAMESPACE, safe='')}",
            headers={"Api-Key": API_KEY or "", "Content-Type": "application/json"},
            json={"items": [item]},
        )
    except Exception:
        # Never break the user's tool call.
        pass


def _enc(s: str) -> str:
    return quote(s, safe="")


def _fold_tags(
    filter_: dict[str, Any] | None,
    tags: list[str] | None,
    tags_any: list[str] | None = None,
) -> dict[str, Any] | None:
    """Sugar:
      tags     -> AND-of-$in (every tag must be present on metadata.tags)
      tagsAny  -> single $in (any one tag matches)
    Combines with explicit filter."""
    blocks: list[dict[str, Any]] = []
    if filter_:
        blocks.append(filter_)
    if tags:
        ands = [{"tags": {"$in": [t]}} for t in tags]
        blocks.append(ands[0] if len(ands) == 1 else {"$and": ands})
    if tags_any:
        blocks.append({"tags": {"$in": list(tags_any)}})
    if not blocks:
        return None
    if len(blocks) == 1:
        return blocks[0]
    return {"$and": blocks}


async def _call(
    client: httpx.AsyncClient,
    method: str,
    path: str,
    body: Any | None = None,
) -> Any:
    headers = {"Api-Key": API_KEY or ""}
    if body is not None:
        headers["Content-Type"] = "application/json"
    r = await client.request(method, BASE_URL + path, headers=headers, json=body)
    if r.status_code >= 400:
        raise RuntimeError(f"{method} {path} -> {r.status_code}: {r.text}")
    try:
        return r.json()
    except Exception:
        return r.text


TOOLS: list[Tool] = [
    # ==================================================================
    # Records -- the primary typed-event substrate. Use these first.
    # ==================================================================
    Tool(
        name="records_ingest",
        description=(
            "Append one or more typed events (decisions, mistakes, llm_turns, "
            "tool_calls, user_prompts, ...) to a namespace. Server auto-embeds "
            "the text via the static-MRL D=1024 encoder. Each item: "
            "{kind, text, tags?, ts?, meta?, id?, ttlDays?}. Returns ids. "
            "Records have first-class kind / tags / ts -- no metadata-dict "
            "filter gymnastics."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "namespace": {"type": "string", "default": ""},
                "items": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "kind": {"type": "string"},
                            "text": {"type": "string"},
                            "tags": {"type": "array", "items": {"type": "string"}, "default": []},
                            "ts": {"type": "integer"},
                            "meta": {"type": "object"},
                            "id": {"type": "string"},
                            "ttlDays": {"type": "integer"},
                            "userId": {"type": "string"},
                        },
                        "required": ["kind", "text"],
                    },
                },
            },
            "required": ["namespace", "items"],
        },
    ),
    Tool(
        name="records_query",
        description=(
            "Semantic + typed-filter query against a Records namespace. Pass "
            "`text` for cosine ranking; omit `text` for a typed-only scan "
            "ordered by ts descending. Filters: `kind` (array), `tagsAny`, "
            "`tagsAll`, `tsGte`, `tsLt`."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "namespace": {"type": "string", "default": ""},
                "text": {"type": "string"},
                "topK": {"type": "integer", "default": 10},
                "kind": {"type": "array", "items": {"type": "string"}},
                "tagsAny": {"type": "array", "items": {"type": "string"}},
                "tagsAll": {"type": "array", "items": {"type": "string"}},
                "tsGte": {"type": "integer"},
                "tsLt": {"type": "integer"},
                "userId": {"type": "string"},
                "includeText": {"type": "boolean", "default": True},
                "includeMeta": {"type": "boolean", "default": True},
            },
            "required": ["namespace"],
        },
    ),
    Tool(
        name="records_timeline",
        description=(
            "Return records in a namespace as a timeline (most-recent first). "
            "Filter by kind (comma-separated string), tagsAny, tagsAll, since, "
            "until. limit defaults to 50 (max 500). Use `until = nextCursor` "
            "from a prior response to page back in time."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "namespace": {"type": "string", "default": ""},
                "since": {"type": "integer"},
                "until": {"type": "integer"},
                "kind": {"type": "string"},
                "tagsAny": {"type": "string"},
                "tagsAll": {"type": "string"},
                "userId": {"type": "string"},
                "limit": {"type": "integer", "default": 50},
            },
            "required": ["namespace"],
        },
    ),
    Tool(
        name="records_get",
        description="Fetch a single record by id. 404 if not found.",
        inputSchema={
            "type": "object",
            "properties": {
                "namespace": {"type": "string", "default": ""},
                "id": {"type": "string"},
            },
            "required": ["namespace", "id"],
        },
    ),
    Tool(
        name="records_delete",
        description="Soft-delete one record by id.",
        inputSchema={
            "type": "object",
            "properties": {
                "namespace": {"type": "string", "default": ""},
                "id": {"type": "string"},
            },
            "required": ["namespace", "id"],
        },
    ),
    Tool(
        name="records_forget",
        description=(
            "GDPR-style bulk forget with typed predicates. Pass any combination "
            "of kind / tagsAny / tagsAll / tsGte / tsLt / ids. Returns "
            "forgottenCount."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "namespace": {"type": "string", "default": ""},
                "kind": {"type": "array", "items": {"type": "string"}},
                "tagsAny": {"type": "array", "items": {"type": "string"}},
                "tagsAll": {"type": "array", "items": {"type": "string"}},
                "tsGte": {"type": "integer"},
                "tsLt": {"type": "integer"},
                "userId": {"type": "string"},
                "ids": {"type": "array", "items": {"type": "string"}},
            },
            "required": ["namespace"],
        },
    ),
    Tool(
        name="records_compact",
        description=(
            "Consolidate a predicate-selected slice of records into one summary "
            "record + tombstone the originals. Keeps long-running namespaces "
            "lean. Summary carries kind=summary (configurable), tags=[summary, "
            "compacted, ...inherited], and meta {compacted_count, original_ids, "
            "compacted_kinds, compacted_oldest_ts, compacted_newest_ts}."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "namespace": {"type": "string", "default": ""},
                "kind": {"type": "array", "items": {"type": "string"}},
                "tagsAny": {"type": "array", "items": {"type": "string"}},
                "tagsAll": {"type": "array", "items": {"type": "string"}},
                "tsGte": {"type": "integer"},
                "tsLt": {"type": "integer"},
                "userId": {"type": "string"},
                "summaryKind": {"type": "string", "default": "summary"},
                "maxChars": {"type": "integer", "default": 4000},
            },
            "required": ["namespace"],
        },
    ),
    Tool(
        name="records_stats",
        description="Per-namespace stats: count, by_kind histogram, oldest_ts, newest_ts.",
        inputSchema={
            "type": "object",
            "properties": {"namespace": {"type": "string", "default": ""}},
            "required": ["namespace"],
        },
    ),
    Tool(
        name="records_export",
        description=(
            "Export the namespace as a portable .neruva container "
            "(zip of manifest + records section + reserved kg/scm/analogy "
            "slots). Returns base64 of the .neruva blob."
        ),
        inputSchema={
            "type": "object",
            "properties": {"namespace": {"type": "string", "default": ""}},
            "required": ["namespace"],
        },
    ),
    Tool(
        name="records_import",
        description=(
            "Import a .neruva container into a namespace (REPLACE semantic). "
            "Pass base64-encoded .neruva blob. Returns {imported: N, manifest}."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "namespace": {"type": "string", "default": ""},
                "neruva_base64": {"type": "string"},
            },
            "required": ["namespace", "neruva_base64"],
        },
    ),
    # ==================================================================
    # Memory index (legacy vector layer) -- migration on-ramp; records_* preferred.
    # ==================================================================
    Tool(
        name="memory_embed",
        description=(
            "Encode one or more texts to L2-normalized D=1024 float vectors using "
            "the server-side static-MRL encoder. Use this for memory_upsert and "
            "memory_query when you don't have a local encoder. ~7000 texts/sec on "
            "the hosted instance; first call adds ~5s for model load."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "texts": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Texts to embed (truncated at ~512 tokens internally).",
                },
            },
            "required": ["texts"],
        },
    ),
    Tool(
        name="memory_upsert_text",
        description=(
            "Embed and upsert text in a single call -- the all-in-one for new "
            "users. Server runs static-MRL D=1024 internally. Each item: "
            "{id, text, metadata?}. Original text auto-stored into metadata.text."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "index": {"type": "string"},
                "namespace": {"type": "string", "default": ""},
                "items": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "id": {"type": "string"},
                            "text": {"type": "string"},
                            "metadata": {"type": "object"},
                        },
                        "required": ["id", "text"],
                    },
                },
            },
            "required": ["index", "items"],
        },
    ),
    Tool(
        name="memory_query_text",
        description=(
            "Embed a text query and search the namespace in one call. Returns "
            "top-K matches by cosine; metadata included by default. Pass "
            "tags=['foo','bar'] for convenient AND-filter on metadata.tags."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "index": {"type": "string"},
                "namespace": {"type": "string", "default": ""},
                "text": {"type": "string"},
                "topK": {"type": "integer", "default": 10},
                "includeMetadata": {"type": "boolean", "default": True},
                "includeValues": {"type": "boolean", "default": False},
                "filter": {"type": "object", "description": "Metadata filter ({field: value} or {field: {$eq|$gte|$lte|$in: ...}})"},
                "tags": {
                    "type": "array", "items": {"type": "string"},
                    "description": "Convenience AND-filter on metadata.tags",
                },
            },
            "required": ["index", "text"],
        },
    ),
    Tool(
        name="memory_replace_text",
        description=(
            "Re-encode a new text and overwrite the existing vector + metadata.text "
            "in one call. Surgical: bipolar prefilter row, float rerank vector, and "
            "metadata all updated atomically. Use for refactor tracking or any "
            "existing memory whose content changed."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "index": {"type": "string"},
                "namespace": {"type": "string", "default": ""},
                "id": {"type": "string"},
                "newText": {"type": "string"},
            },
            "required": ["index", "id", "newText"],
        },
    ),
    Tool(
        name="memory_forget_where",
        description=(
            "Bulk-delete vectors whose metadata matches a filter. "
            "Filter: {field: value} or {field: {$eq|$gte|$lte|$in: ...}}. GDPR Article 17 "
            "in one call -- forget every vector tagged {user_id: 'alice'}."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "index": {"type": "string"},
                "namespace": {"type": "string", "default": ""},
                "filter": {"type": "object"},
            },
            "required": ["index", "filter"],
        },
    ),
    Tool(
        name="memory_bind_role",
        description=(
            "Bind a named role atom onto a stored vector's bipolar prefilter row. "
            "Lets you narrow future queries by compound roles like ['user', "
            "'from_alice'] without a secondary index."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "index": {"type": "string"},
                "namespace": {"type": "string", "default": ""},
                "id": {"type": "string"},
                "role": {"type": "string"},
            },
            "required": ["index", "id", "role"],
        },
    ),
    Tool(
        name="memory_read_roles",
        description=(
            "Approximate-unbind introspection: given a stored vector's id and its "
            "original encoder vector, recover the role atoms it was bound under. "
            "Pass roleDict mapping axis names to candidate role names; returns "
            "axis -> [best_role, score]."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "index": {"type": "string"},
                "namespace": {"type": "string", "default": ""},
                "id": {"type": "string"},
                "queryVector": {"type": "array", "items": {"type": "number"}},
                "roleDict": {"type": "object"},
                "known": {"type": "array", "items": {"type": "string"}},
            },
            "required": ["index", "id", "queryVector", "roleDict"],
        },
    ),
    Tool(
        name="memory_create_index",
        description=(
            "Create a vector index. Required once before "
            "memory_upsert / memory_query / memory_delete can be used. "
            "Idempotent on existing indexes."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "name": {"type": "string", "description": "Index name"},
                "dimension": {
                    "type": "integer",
                    "description": "Vector dimension (e.g. 1024 for static-MRL)",
                },
                "metric": {
                    "type": "string",
                    "enum": ["cosine", "dotproduct", "euclidean"],
                    "default": "cosine",
                },
            },
            "required": ["name", "dimension"],
        },
    ),
    Tool(
        name="memory_list_indexes",
        description="List all indexes for your account.",
        inputSchema={"type": "object", "properties": {}, "required": []},
    ),
    Tool(
        name="memory_describe_index",
        description="Describe one index (dimension, metric, host, status).",
        inputSchema={
            "type": "object",
            "properties": {"name": {"type": "string"}},
            "required": ["name"],
        },
    ),
    Tool(
        name="memory_stats",
        description="Per-namespace vector counts and total vector count for an index.",
        inputSchema={
            "type": "object",
            "properties": {"name": {"type": "string"}},
            "required": ["name"],
        },
    ),
    Tool(
        name="memory_fetch",
        description="Fetch one or more vectors by id from a namespace.",
        inputSchema={
            "type": "object",
            "properties": {
                "index": {"type": "string"},
                "ids": {"type": "array", "items": {"type": "string"}},
                "namespace": {"type": "string", "default": ""},
            },
            "required": ["index", "ids"],
        },
    ),
    Tool(
        name="memory_update",
        description=(
            "Update one vector in a namespace -- replace its values and/or metadata "
            "without re-upserting. ID must already exist."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "index": {"type": "string"},
                "id": {"type": "string"},
                "values": {"type": "array", "items": {"type": "number"}},
                "metadata": {"type": "object"},
                "namespace": {"type": "string", "default": ""},
            },
            "required": ["index", "id"],
        },
    ),
    Tool(
        name="memory_export",
        description=(
            "Export an index (or one namespace) to the portable .nmm format. "
            "Returns base64-encoded bytes. Take your memory between providers, "
            "environments, agents."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "index": {"type": "string"},
                "namespace": {"type": "string", "description": "Optional namespace; omit to export the whole index."},
            },
            "required": ["index"],
        },
    ),
    Tool(
        name="memory_import",
        description=(
            "Import a previously-exported .nmm blob into an index. Index must already "
            "exist with matching dimension. Pass base64-encoded bytes via nmm_base64."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "index": {"type": "string"},
                "nmm_base64": {"type": "string"},
            },
            "required": ["index", "nmm_base64"],
        },
    ),
    Tool(
        name="memory_upsert",
        description=(
            "Insert or update vectors in a Neruva Memory namespace. The "
            "index must exist (create it once with memory_create_index)."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "index": {"type": "string", "description": "Index name"},
                "namespace": {
                    "type": "string",
                    "description": "Namespace; defaults to ''",
                    "default": "",
                },
                "vectors": {
                    "type": "array",
                    "description": "Vectors: {id, values, metadata?}",
                    "items": {
                        "type": "object",
                        "properties": {
                            "id": {"type": "string"},
                            "values": {"type": "array", "items": {"type": "number"}},
                            "metadata": {"type": "object"},
                        },
                        "required": ["id", "values"],
                    },
                },
            },
            "required": ["index", "vectors"],
        },
    ),
    Tool(
        name="memory_query",
        description=(
            "Cosine-search a namespace by vector. Returns top-K matches with metadata. "
            "Pass tags=['foo','bar'] for convenient AND-filter on metadata.tags."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "index": {"type": "string"},
                "namespace": {"type": "string", "default": ""},
                "vector": {"type": "array", "items": {"type": "number"}},
                "topK": {"type": "integer", "default": 10},
                "includeMetadata": {"type": "boolean", "default": True},
                "includeValues": {"type": "boolean", "default": False},
                "filter": {"type": "object", "description": "Metadata filter ({field: value} or {field: {$eq|$gte|$lte|$in: ...}})"},
                "tags": {
                    "type": "array", "items": {"type": "string"},
                    "description": "Convenience AND-filter on metadata.tags",
                },
            },
            "required": ["index", "vector"],
        },
    ),
    Tool(
        name="memory_delete",
        description="Delete vectors by id from a namespace. The index must exist.",
        inputSchema={
            "type": "object",
            "properties": {
                "index": {"type": "string"},
                "namespace": {"type": "string", "default": ""},
                "ids": {"type": "array", "items": {"type": "string"}},
            },
            "required": ["index", "ids"],
        },
    ),
    Tool(
        name="hd_kg_add_fact",
        description=(
            "Add a (subject, relation, object) fact to a knowledge graph. "
            "The KG is auto-created on first add. Persists across restarts.\n\n"
            "engine (FRESH KGs only; ignored if KG exists):\n"
            "  hadamard       -- default; <10k facts, latency-critical.\n"
            "  opb            -- recommended for >10k facts; 250k facts in "
            "single matrix at 100% recall; supports hd_kg_derive_relation "
            "matrix-power.\n"
            "  multishard     -- 250k-1M+ facts; auto-routes via stable hash.\n"
            "  quorum         -- 3-shard redundant write; adversarial-resistant.\n"
            "  feature_bundle -- bundled-feature atoms; zero-shot generalization "
            "to unseen concepts (requires hd_kg_assign_features)."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "kg": {"type": "string", "description": "Knowledge-graph name"},
                "subject": {"type": "string"},
                "relation": {"type": "string"},
                "object": {"type": "string"},
                "engine": {
                    "type": "string",
                    "enum": ["hadamard", "opb", "multishard", "quorum", "feature_bundle"],
                    "description": "Fresh-KG engine selector.",
                },
            },
            "required": ["kg", "subject", "relation", "object"],
        },
    ),
    Tool(
        name="hd_kg_extraction_prompt",
        description=(
            "Return the canonical system prompt agents should run with "
            "their OWN LLM (Claude/GPT/etc) to extract (subject, "
            "predicate, object) triples from raw text. The substrate "
            "does NOT make external LLM calls -- extraction happens in "
            "your turn, then push the triples via hd_kg_add_facts. Pure "
            "/ deterministic / sub-ms / $0."
        ),
        inputSchema={"type": "object", "properties": {}, "required": []},
    ),
    Tool(
        name="hd_kg_add_facts",
        description=(
            "Batch add: insert N (subject, relation, object) triples in "
            "one call. ~100x latency vs N single hd_kg_add_fact calls. "
            "Same engine selector semantics (only applies on fresh KG)."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "kg": {"type": "string"},
                "facts": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "subject": {"type": "string"},
                            "relation": {"type": "string"},
                            "object": {"type": "string"},
                        },
                        "required": ["subject", "relation", "object"],
                    },
                },
                "engine": {
                    "type": "string",
                    "enum": ["hadamard", "opb", "multishard", "quorum", "feature_bundle"],
                },
            },
            "required": ["kg", "facts"],
        },
    ),
    Tool(
        name="hd_kg_query_topk",
        description=(
            "Like hd_kg_query but returns top-K candidate objects with "
            "confidences. Use when a subject has multiple facts for the "
            "same relation (e.g., Bob knows both Alice and Carol)."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "kg": {"type": "string"},
                "subject": {"type": "string"},
                "relation": {"type": "string"},
                "k": {"type": "integer", "default": 5, "minimum": 1, "maximum": 50},
            },
            "required": ["kg", "subject", "relation"],
        },
    ),
    Tool(
        name="hd_kg_list",
        description="List every KG name owned by the caller (in-memory + persisted).",
        inputSchema={"type": "object", "properties": {}, "required": []},
    ),
    Tool(
        name="hd_kg_describe",
        description=(
            "Return engine type, fact count, relations, derived relations "
            "for a KG. Use to discover what engine a KG uses before "
            "OPB-only ops (derive_relation, compress, quorum_audit)."
        ),
        inputSchema={
            "type": "object",
            "properties": {"kg": {"type": "string"}},
            "required": ["kg"],
        },
    ),
    Tool(
        name="hd_scm_list",
        description="List every causal SCM name owned by the caller.",
        inputSchema={"type": "object", "properties": {}, "required": []},
    ),
    Tool(
        name="hd_scm_describe",
        description="Return n_vars, vocab_per_var, n_worlds for a causal SCM.",
        inputSchema={
            "type": "object",
            "properties": {"scm": {"type": "string"}},
            "required": ["scm"],
        },
    ),
    Tool(
        name="hd_cbr_list",
        description="List every CBR episode-store name owned by the caller.",
        inputSchema={"type": "object", "properties": {}, "required": []},
    ),
    Tool(
        name="hd_cbr_describe",
        description="Return n_axes, vocab, n_labels, n_episodes for a CBR store.",
        inputSchema={
            "type": "object",
            "properties": {"cbr": {"type": "string"}},
            "required": ["cbr"],
        },
    ),
    Tool(
        name="records_update",
        description=(
            "Partial in-place update of an existing record. Any field "
            "omitted is left untouched. text triggers re-encode. setTags "
            "REPLACES the list; addTags APPENDS (dedup)."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "namespace": {"type": "string", "default": ""},
                "id": {"type": "string"},
                "text": {"type": "string"},
                "setTags": {"type": "array", "items": {"type": "string"}},
                "addTags": {"type": "array", "items": {"type": "string"}},
                "setMeta": {"type": "object"},
                "setKind": {"type": "string"},
            },
            "required": ["namespace", "id"],
        },
    ),
    Tool(
        name="records_replace_text",
        description=(
            "Atomic re-encode of an existing record's text. Other fields "
            "(tags / meta / kind / ts) preserved. Use for refined decisions "
            "without losing the id."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "namespace": {"type": "string", "default": ""},
                "id": {"type": "string"},
                "newText": {"type": "string"},
            },
            "required": ["namespace", "id", "newText"],
        },
    ),
    Tool(
        name="records_bind_tag",
        description=(
            "Append a single tag to an existing record's tags (dedup). "
            "No re-encode. Lightweight categorization."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "namespace": {"type": "string", "default": ""},
                "id": {"type": "string"},
                "tag": {"type": "string"},
            },
            "required": ["namespace", "id", "tag"],
        },
    ),
    Tool(
        name="memory_timeline",
        description=(
            "Chronological scan of a vector index namespace by metadata.ts "
            "(descending). Page back via until=<nextCursor>."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "index": {"type": "string"},
                "namespace": {"type": "string", "default": ""},
                "since": {"type": "integer"},
                "until": {"type": "integer"},
                "limit": {"type": "integer", "default": 50, "minimum": 1, "maximum": 500},
                "includeValues": {"type": "boolean", "default": False},
            },
            "required": ["index"],
        },
    ),
    Tool(
        name="memory_delete_index",
        description=(
            "Delete a vector index AND all its namespaces. Hard delete -- "
            "blobs removed from GCS, in-memory cache evicted. Use to "
            "clean up zombie indexes from old tests / probes."
        ),
        inputSchema={
            "type": "object",
            "properties": {"name": {"type": "string"}},
            "required": ["name"],
        },
    ),
    Tool(
        name="hd_kg_context",
        description=(
            "Return a customizable context block ready to drop into an LLM "
            "prompt. Pass a natural-language question; the server retrieves "
            "top-K relevant facts via entity-grounded scoring and formats "
            "them as markdown / plain / jsonl. Sub-ms, deterministic, "
            "$0 per call."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "kg": {"type": "string"},
                "question": {"type": "string"},
                "top_k": {"type": "integer", "default": 10},
                "format": {
                    "type": "string",
                    "enum": ["markdown", "plain", "jsonl"],
                    "default": "markdown",
                },
            },
            "required": ["kg", "question"],
        },
    ),
    Tool(
        name="hd_kg_derive_relation",
        description=(
            "Derive an N-hop relation from a 1-hop base via matrix-power "
            "composition (M^n). Subsequent hd_kg_query calls can use the "
            "derived relation name for N-hop answers in a single matmul. "
            "Requires OPB-family engine. Probes 100r/100s."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "kg": {"type": "string"},
                "base_relation": {"type": "string"},
                "n_hops": {"type": "integer", "minimum": 1},
                "derived_name": {"type": "string"},
            },
            "required": ["kg", "base_relation", "n_hops"],
        },
    ),
    Tool(
        name="hd_kg_replace_fact",
        description=(
            "Atomic fact invalidation: delete current (s, r, old_object) "
            "+ add (s, r, new_object) in one critical section. Zep-style "
            "temporal fact resolution. old_object optional; if set, must "
            "match current state (409 if not)."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "kg": {"type": "string"},
                "subject": {"type": "string"},
                "relation": {"type": "string"},
                "new_object": {"type": "string"},
                "old_object": {"type": "string"},
            },
            "required": ["kg", "subject", "relation", "new_object"],
        },
    ),
    Tool(
        name="hd_kg_query",
        description=(
            "Query a knowledge graph for the object of (subject, relation). "
            "Returns object + confidence. Returns object=null with confidence=0 "
            "when the subject is unknown or no fact matches above the noise "
            "threshold (cosine 0.05).\n\n"
            "retrieval='hybrid' (optional) enables cosine + OPB-entity hybrid "
            "scoring with reciprocal-rank-fusion. +11pp R@1 on 2WikiMultiHopQA "
            "n=500 ."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "kg": {"type": "string"},
                "subject": {"type": "string"},
                "relation": {"type": "string"},
                "retrieval": {
                    "type": "string",
                    "enum": ["hybrid"],
                    "description": "Optional. 'hybrid' = cosine + OPB-entity + RRF.",
                },
            },
            "required": ["kg", "subject", "relation"],
        },
    ),
    Tool(
        name="hd_kg_assign_features",
        description=(
            "Assign a feature-id list to a concept in a FeatureBundle KG. "
            "Same-category concepts SHOULD share 60-80% of feature ids for "
            "the zero-shot generalization claim (84% on UNSEEN "
            "concepts vs 0% with random atoms). Requires engine=feature_bundle."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "kg": {"type": "string"},
                "concept": {"type": "string"},
                "feature_ids": {"type": "array", "items": {"type": "integer"}},
            },
            "required": ["kg", "concept", "feature_ids"],
        },
    ),
    Tool(
        name="hd_kg_quorum_audit",
        description=(
            "For Quorum KGs: return per-shard answers so callers can detect "
            "adversarial injection. Any shard disagreeing with the majority "
            "is suspicious. Returns is_unanimous, n_agree, per_shard. "
            "Requires engine=quorum. 100% single-shard attack "
            "detection."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "kg": {"type": "string"},
                "subject": {"type": "string"},
                "relation": {"type": "string"},
            },
            "required": ["kg", "subject", "relation"],
        },
    ),
    Tool(
        name="hd_kg_compress",
        description=(
            "SVD-truncate a relation shard to rank-r (TT compression). "
            "r=64 holds 1000-turn sequences at 99% recall in "
            "0.5MB vs full 16MB at D=2048. Requires OPB-family engine."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "kg": {"type": "string"},
                "relation": {"type": "string"},
                "rank": {"type": "integer", "default": 64},
            },
            "required": ["kg", "relation"],
        },
    ),
    Tool(
        name="hd_kg_export",
        description=(
            "Export a knowledge graph to the portable .hdkg format. Returns "
            "base64-encoded bytes. Take your KG between providers, environments."
        ),
        inputSchema={
            "type": "object",
            "properties": {"kg": {"type": "string"}},
            "required": ["kg"],
        },
    ),
    Tool(
        name="hd_kg_import",
        description=(
            "Import (or replace) a knowledge graph from a previously-exported "
            ".hdkg blob. Pass base64-encoded bytes via hdkg_base64."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "kg": {"type": "string"},
                "hdkg_base64": {"type": "string"},
            },
            "required": ["kg", "hdkg_base64"],
        },
    ),
    Tool(
        name="hd_causal_export",
        description=(
            "Export a structural causal model to the portable .hdscm format. "
            "Returns base64-encoded bytes."
        ),
        inputSchema={
            "type": "object",
            "properties": {"scm": {"type": "string"}},
            "required": ["scm"],
        },
    ),
    Tool(
        name="hd_causal_import",
        description=(
            "Import (or replace) an SCM from a previously-exported .hdscm blob. "
            "Pass base64-encoded bytes via hdscm_base64."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "scm": {"type": "string"},
                "hdscm_base64": {"type": "string"},
            },
            "required": ["scm", "hdscm_base64"],
        },
    ),
    Tool(
        name="hd_kg_delete_fact",
        description=(
            "Remove a previously-added (subject, relation, object) triple from a "
            "knowledge graph. Subtracts the bound vector from the relation shard, "
            "exactly cancelling the original add. Required for any mutable-state "
            "use case (refactor tracking, deploy status, project state). Triples "
            "whose tokens are unknown are skipped (no-op, not error)."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "kg": {"type": "string", "description": "Knowledge-graph name"},
                "subject": {"type": "string"},
                "relation": {"type": "string"},
                "object": {"type": "string"},
            },
            "required": ["kg", "subject", "relation", "object"],
        },
    ),
    Tool(
        name="hd_cbr_create",
        description=(
            "Initialize an episodic CBR store. Cases are integer-coded "
            "over n_axes role-filler axes; labels are integer cluster "
            "ids in [0, n_labels). 99.1% novel-case retrieval "
            "at 10k episodes, 617us/query. In-memory only for v1."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "cbr": {"type": "string"},
                "n_axes": {"type": "integer", "minimum": 1, "maximum": 64},
                "vocab": {"type": "integer", "minimum": 2},
                "n_labels": {"type": "integer", "minimum": 2},
                "seed": {"type": "integer", "default": 4601},
            },
            "required": ["cbr", "n_axes", "vocab", "n_labels"],
        },
    ),
    Tool(
        name="hd_cbr_add_episodes",
        description=(
            "Add (N, n_axes) integer-coded cases + (N,) integer cluster "
            "labels. Store must exist (hd_cbr_create first)."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "cbr": {"type": "string"},
                "cases": {"type": "array", "items": {"type": "array", "items": {"type": "integer"}}},
                "labels": {"type": "array", "items": {"type": "integer"}},
            },
            "required": ["cbr", "cases", "labels"],
        },
    ),
    Tool(
        name="hd_cbr_query",
        description=(
            "Predict the cluster id of a fresh (n_axes,) case via "
            "HD-cosine top-K majority vote. Returns predicted_label + "
            "neighbor_ids + vote_margin + confidence."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "cbr": {"type": "string"},
                "case": {"type": "array", "items": {"type": "integer"}},
                "k": {"type": "integer", "default": 15},
            },
            "required": ["cbr", "case"],
        },
    ),
    Tool(
        name="hd_blend_query",
        description=(
            "Bundle N typed parents into one HD vector and recover any "
            "one parent unchanged. Role tag preserves provenance: even "
            "at 99% shared attributes per-parent Jaccard recovery is "
            ">= 0.99 . Stateless: codebook deterministic in "
            "(n_attrs, n_roles, seed). Use to merge N memories into one "
            "audit-friendly bundle without losing source identity. "
            "Capacity: keep total atoms << sqrt(D) (~90 at D=8192)."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "n_attrs": {"type": "integer", "minimum": 2},
                "n_roles": {"type": "integer", "default": 16},
                "role_parents": {
                    "type": "array",
                    "description": "List of [role_id, [attr_ids,...]] pairs.",
                    "items": {"type": "array"},
                },
                "recover_role": {"type": "integer"},
                "seed": {"type": "integer", "default": 5701},
            },
            "required": ["n_attrs", "role_parents", "recover_role"],
        },
    ),
    Tool(
        name="hd_analogy",
        description=(
            "Solve a four-term analogy in HD feature space: a is to b as c is to ? "
            "Items are integer feature IDs in [0, 2^n_feat). Returns the cleaned-up "
            "candidate plus cosine, runner-up cosine, and a confidence gap."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "n_feat": {"type": "integer", "description": "Number of binary features. Item space size is 2^n_feat."},
                "a": {"type": "integer"},
                "b": {"type": "integer"},
                "c": {"type": "integer"},
                "seed": {"type": "integer", "default": 4301},
            },
            "required": ["n_feat", "a", "b", "c"],
        },
    ),
    Tool(
        name="hd_causal_add_worlds",
        description=(
            "Add or extend a structural causal model (SCM) with integer-coded worlds. "
            "Required once before hd_causal_query can run on a given SCM name. Worlds "
            "are rows of length n_vars; each entry is the value of that variable."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "scm": {"type": "string", "description": "SCM name"},
                "n_vars": {"type": "integer", "description": "Number of variables"},
                "vocab_per_var": {
                    "type": "array",
                    "items": {"type": "integer"},
                    "description": "Cardinality per variable; length must equal n_vars",
                },
                "worlds": {
                    "type": "array",
                    "items": {"type": "array", "items": {"type": "integer"}},
                    "description": "Shape (N, n_vars). Each row is one world.",
                },
                "seed": {"type": "integer", "default": 4401},
            },
            "required": ["scm", "n_vars", "vocab_per_var", "worlds"],
        },
    ),
    Tool(
        name="hd_causal_query",
        description=(
            "Run an observational or interventional query against a stored causal model. "
            "The SCM must exist (call hd_causal_add_worlds first). query_type is "
            "'observation' or 'intervention' -- arithmetically distinct."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "scm": {"type": "string", "description": "Causal-model name"},
                "query_type": {"type": "string", "enum": ["observation", "intervention"]},
                "condition_var": {"type": "integer"},
                "condition_value": {"type": "integer"},
                "query_var": {"type": "integer"},
                "query_value": {"type": "integer"},
            },
            "required": [
                "scm",
                "query_type",
                "condition_var",
                "condition_value",
                "query_var",
                "query_value",
            ],
        },
    ),
    # hd_plan removed in 0.2.0. Returning in 0.2.x with
    # hd_plan_register_model + hd_plan_with_model so users can describe
    # their actual transition kernels.

    Tool(
        name="agent_snapshot",
        description=(
            "Capture a namespace's complete records state as a portable "
            ".neruva blob in GCS, indexed by snapshot_id. Immutable + "
            "byte-identical replays. Use for audit, debugging, time-travel."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "namespace": {"type": "string"},
                "snapshot_id": {"type": "string"},
                "note": {"type": "string"},
            },
            "required": ["namespace"],
        },
    ),
    Tool(
        name="agent_restore",
        description=(
            "Restore a snapshot into a target namespace (OVERWRITES). "
            "Pairs with agent_snapshot for provable replay -- audit any "
            "agent decision against historical state."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "snapshot_id": {"type": "string"},
                "target_namespace": {"type": "string"},
            },
            "required": ["snapshot_id", "target_namespace"],
        },
    ),
    Tool(
        name="agent_check_consistency",
        description=(
            "Anomaly detection on Quorum KGs. Scans every (s, r) across "
            "all shards, flags disagreements. Severity: high=full disagree, "
            "medium=split, low=single dissent. Requires engine='quorum'."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "kg": {"type": "string"},
                "max_anomalies": {"type": "integer", "default": 100},
            },
            "required": ["kg"],
        },
    ),
    Tool(
        name="agent_postmortem",
        description=(
            "Distill a failed agent run into {failure_class, lesson, "
            "corrected_plan} via Magistral reasoning. Pair with "
            "agent_remember to store the lesson back so future similar "
            "tasks see it as LEARNED context. The recursive-intelligence "
            "loop: fail -> postmortem -> remember -> recall surfaces it "
            "next run. failure_class is one of: tool_arg_missing | "
            "primitive_mismatch | context_drift | wrong_target | timeout "
            "| captcha_blocked | unknown."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "agent": {"type": "string", "enum": ["computer", "code"]},
                "task_text": {"type": "string"},
                "plan": {"type": "array", "items": {"type": "string"},
                          "default": []},
                "history": {"type": "array", "items": {"type": "object"},
                             "default": []},
                "error": {"type": "string"},
                "task_class": {"type": "string"},
                "app": {"type": "string"},
            },
            "required": ["agent", "task_text"],
        },
    ),
    # ==================================================================
    # Federated agent_* (substrate-routes-not-the-agent).
    # ==================================================================
    Tool(
        name="agent_remember",
        description=(
            "One-call agent memory write. Always pushes a Records entry.\n\n"
            "extract='off' (default): records only.\n"
            "extract='byo' + triples=[...]: caller-extracted triples bound to KG.\n"
            "extract='managed': substrate extracts triples server-side (~0.3-1s)."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "text": {"type": "string"},
                "namespace": {"type": "string", "default": "agent"},
                "extract": {
                    "type": "string",
                    "enum": ["off", "byo", "managed"],
                    "default": "off",
                },
                "triples": {
                    "type": "array",
                    "items": {"type": "array", "items": {"type": "string"}},
                },
                "tags": {"type": "array", "items": {"type": "string"}},
                "kind": {"type": "string"},
                "user_id": {"type": "string"},
            },
            "required": ["text"],
        },
    ),
    Tool(
        name="agent_recall",
        description=(
            "One-call federated query. Semantic search across Records + "
            "entity-overlap scan of KG. Returns both streams with `source` "
            "tag.\n\n"
            "Cross-session graph RAG: pass `namespaces=[...]` to fan-out "
            "across multiple sessions (Zep-style cross-session recall, "
            "records re-ranked by score, KG facts merged by entity overlap)."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "query": {"type": "string"},
                "namespace": {"type": "string", "default": "agent"},
                "namespaces": {"type": "array", "items": {"type": "string"}},
                "top_k": {"type": "integer", "default": 10},
                "user_id": {"type": "string"},
            },
            "required": ["query"],
        },
    ),
    Tool(
        name="agent_context",
        description=(
            "One-call LLM context block with question-type dispatch. "
            "Auto-classifies question (temporal / multi_hop / single_hop / "
            "open_domain / adversarial) and routes accordingly. Override "
            "via question_type. Drop returned `context` into system prompt."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "question": {"type": "string"},
                "namespace": {"type": "string", "default": "agent"},
                "question_type": {
                    "type": "string",
                    "enum": ["auto", "temporal", "multi_hop", "single_hop", "open_domain", "adversarial"],
                    "default": "auto",
                },
                "top_k": {"type": "integer", "default": 10},
                "max_chars": {"type": "integer", "default": 4000},
                "user_id": {"type": "string"},
            },
            "required": ["question"],
        },
    ),
    Tool(
        name="agent_causal_query",
        description=(
            "Pearl do-operator on agent memory. Returns BOTH P(Q|X) "
            "(observation) and P(Q|do(X)) (intervention). The gap is "
            "the formal causal answer. Zep can't do this; we can."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "scm": {"type": "string"},
                "condition_var": {"type": "integer"},
                "condition_value": {"type": "integer"},
                "query_var": {"type": "integer"},
                "query_value": {"type": "integer"},
            },
            "required": ["scm", "condition_var", "condition_value", "query_var", "query_value"],
        },
    ),
    Tool(
        name="agent_plan_cache_save",
        description=(
            "Save a completed GUI agent plan as a reusable template. "
            "Stores under kind='plan_template'. Reused via "
            "agent_plan_cache_lookup on semantically similar tasks -- "
            "this is the Agentic Plan Caching (APC) primitive that cuts "
            "GUI agent cost ~50% and latency ~27% over time as the cache "
            "fills (arxiv 2506.14852).\n\n"
            "Each step: {action: 'click'|'type'|'key'|'scroll'|'wait'|'screenshot', "
            "args: {...}, selector?: 'optional re-grounding hint'}."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "task_text": {"type": "string"},
                "plan": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "action": {"type": "string"},
                            "args": {"type": "object"},
                            "selector": {"type": "string"},
                        },
                        "required": ["action"],
                    },
                },
                "namespace": {"type": "string", "default": "agent"},
                "success": {"type": "boolean", "default": True},
                "duration_ms": {"type": "integer"},
                "user_id": {"type": "string"},
                "tags": {"type": "array", "items": {"type": "string"}},
                "ttl_days": {"type": "integer"},
            },
            "required": ["task_text", "plan"],
        },
    ),
    Tool(
        name="agent_plan_cache_lookup",
        description=(
            "Look up cached GUI agent plans matching `task_text` "
            "semantically. Empty hits = cache miss; caller derives a "
            "fresh plan (via any vision-capable agent) and stores "
            "via agent_plan_cache_save.\n\n"
            "Cache hit pattern: if hits[0].score >= 0.85 and "
            "hits[0].success_rate >= 0.8 execute the cached plan "
            "directly, skipping LLM round-trips."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "task_text": {"type": "string"},
                "namespace": {"type": "string", "default": "agent"},
                "top_k": {"type": "integer", "default": 3},
                "min_score": {"type": "number", "default": 0.5},
                "user_id": {"type": "string"},
            },
            "required": ["task_text"],
        },
    ),
    # ==================================================================
    # Self-introspection -- what's in MY substrate, what did I just do,
    # how is my wallet doing. The wedge: agents introspect themselves
    # without leaving the loop to read a dashboard.
    # ==================================================================
    Tool(
        name="neruva_wallet_status",
        description=(
            "Caller's wallet snapshot: balance_usd, low_balance, "
            "projected_days_left (based on 7-day burn), last_topup_usd, "
            "last_topup_capture_id, last_charge_ts, burn_7d_usd. Use this "
            "when an agent should warn the user that funds are low before "
            "continuing an expensive task."
        ),
        inputSchema={"type": "object", "properties": {}},
    ),
    Tool(
        name="neruva_op_stats",
        description=(
            "Aggregate API usage over the trailing window. Returns total "
            "calls, total cost_usd, by_op (per op-class), by_namespace, "
            "by_day. Use this to answer 'how much has my agent spent on "
            "records vs HD KG today?' or 'which namespace is burning the "
            "most?'."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "window": {"type": "string", "enum": ["7d", "30d"], "default": "30d"},
            },
        },
    ),
    Tool(
        name="neruva_keys_list",
        description=(
            "List the caller's API keys (metadata only -- never raw key "
            "material). Returns id, prefix (last chars of the key), label, "
            "created_at_ms, revoked. Use this to audit which keys exist "
            "and whether stale ones should be revoked."
        ),
        inputSchema={"type": "object", "properties": {}},
    ),
    Tool(
        name="neruva_op_log",
        description=(
            "Last N op events for the caller (most recent first). Each "
            "entry: ts_ms, op (op-class string), namespace, latency_ms, "
            "status (HTTP). Powered by the metering ring buffer; typical "
            "lag is ~3 seconds. Use this for live agent debugging: 'why "
            "was my last query slow?', 'did my last ingest actually "
            "succeed?'."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "limit": {"type": "integer", "minimum": 1, "maximum": 200, "default": 50},
            },
        },
    ),
    # ==================================================================
    # Cognitive primitives (substrate v0.4.0): counterfactual rollouts,
    # theory-of-mind, schema lifting, EFE planning, continual K-gram,
    # hierarchical chunking, few-shot rule induction + persistence.
    # ==================================================================
    Tool(
        name="agent_counterfactual_rollout",
        description=(
            "Replay an action sequence with one action substituted at "
            "step_k. Returns the predicted final factored state. "
            "Stateless. Use when you need 'what if at step k the agent "
            "had taken action a' instead?'."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "initial_state": {"type": "array", "items": {"type": "integer"}},
                "action_seq": {"type": "array", "items": {"type": "integer"}},
                "step_k": {"type": "integer"},
                "alternate_action": {"type": "integer"},
                "n_axes": {"type": "integer", "default": 3, "minimum": 1, "maximum": 16},
                "n_values": {"type": "integer", "default": 8, "minimum": 2, "maximum": 32},
                "seed": {"type": "integer", "default": 2047},
            },
            "required": ["initial_state", "action_seq", "step_k", "alternate_action"],
        },
    ),
    Tool(
        name="agent_model_belief_add",
        description=(
            "Store a nested belief in the namespace's Theory-of-Mind "
            "store. `chain` is outer-to-inner person indices: [0,1,2] "
            "means person 0 believes person 1 believes person 2 believes "
            "prop=val. Per-tenant stateful (keyed by tenant_id+namespace)."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "tenant_id": {"type": "string", "default": "default"},
                "namespace": {"type": "string", "default": "tom"},
                "chain": {"type": "array", "items": {"type": "integer"}},
                "prop": {"type": "integer"},
                "val": {"type": "integer"},
                "n_people": {"type": "integer", "default": 10},
                "n_props": {"type": "integer", "default": 50},
                "n_vals": {"type": "integer", "default": 20},
                "max_depth": {"type": "integer", "default": 4},
                "seed": {"type": "integer", "default": 2048},
            },
            "required": ["chain", "prop", "val"],
        },
    ),
    Tool(
        name="agent_model_belief",
        description=(
            "Recall what the nested `chain` believes about prop. Returns "
            "{val, confidence}. 404 if no beliefs stored in this "
            "namespace yet."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "tenant_id": {"type": "string", "default": "default"},
                "namespace": {"type": "string", "default": "tom"},
                "chain": {"type": "array", "items": {"type": "integer"}},
                "prop": {"type": "integer"},
            },
            "required": ["chain", "prop"],
        },
    ),
    Tool(
        name="agent_extract_schema",
        description=(
            "Given (role_idx, filler_idx) pairs for one instance, return "
            "the per-role signature score vector and the inferred role "
            "indices above the noise threshold. Use for analogical "
            "pattern matching: 'which roles are bound in this instance?'. "
            "Per-tenant stateful."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "tenant_id": {"type": "string", "default": "default"},
                "namespace": {"type": "string", "default": "schema"},
                "role_filler_pairs": {
                    "type": "array",
                    "items": {
                        "type": "array",
                        "items": {"type": "integer"},
                        "minItems": 2,
                        "maxItems": 2,
                    },
                },
                "n_roles": {"type": "integer", "default": 10},
                "n_fillers_per_role": {"type": "integer", "default": 100},
                "seed": {"type": "integer", "default": 2049},
            },
            "required": ["role_filler_pairs"],
        },
    ),
    Tool(
        name="agent_register_action",
        description=(
            "Register an action's add/del effects with the planner. "
            "add_effects/del_effects are {attr_idx: probability_in_[0,1]}. "
            "Call once per available action before agent_plan_efe. "
            "Per-tenant stateful."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "tenant_id": {"type": "string", "default": "default"},
                "namespace": {"type": "string", "default": "planner"},
                "action_id": {"type": "integer"},
                "add_effects": {"type": "object", "additionalProperties": {"type": "number"}},
                "del_effects": {"type": "object", "additionalProperties": {"type": "number"}},
                "n_attrs": {"type": "integer", "default": 100},
                "seed": {"type": "integer", "default": 6001},
            },
            "required": ["action_id"],
        },
    ),
    Tool(
        name="agent_plan_efe",
        description=(
            "Score candidate action sequences against goal attribute "
            "marginals and return the one minimising KL(predicted || "
            "goal). Returns {best_plan_index, best_kl, all_kls}. "
            "Register actions first via agent_register_action. "
            "400 if no actions registered."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "tenant_id": {"type": "string", "default": "default"},
                "namespace": {"type": "string", "default": "planner"},
                "state": {"type": "array", "items": {"type": "integer"}},
                "candidate_plans": {
                    "type": "array",
                    "items": {"type": "array", "items": {"type": "integer"}},
                },
                "want_on": {"type": "array", "items": {"type": "integer"}},
                "want_off": {"type": "array", "items": {"type": "integer"}},
                "p_on": {"type": "number", "default": 0.95},
                "p_off": {"type": "number", "default": 0.05},
            },
            "required": ["state", "candidate_plans"],
        },
    ),
    Tool(
        name="agent_continual_train",
        description=(
            "Train a sharded K-gram next-token predictor on a token "
            "stream. Repeated calls accumulate without forgetting earlier "
            "patterns. Per-tenant stateful."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "tenant_id": {"type": "string", "default": "default"},
                "namespace": {"type": "string", "default": "continual"},
                "token_stream": {"type": "array", "items": {"type": "integer"}},
                "vocab_size": {"type": "integer", "default": 200},
                "k": {"type": "integer", "default": 2},
                "seed": {"type": "integer", "default": 7000},
            },
            "required": ["token_stream"],
        },
    ),
    Tool(
        name="agent_continual_predict",
        description=(
            "Predict the next-token sequence from a primed context using "
            "the previously trained K-gram. Returns N-K predicted tokens. "
            "404 if the namespace has not been trained yet."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "tenant_id": {"type": "string", "default": "default"},
                "namespace": {"type": "string", "default": "continual"},
                "token_stream": {"type": "array", "items": {"type": "integer"}},
            },
            "required": ["token_stream"],
        },
    ),
    Tool(
        name="agent_hierarchical_add",
        description=(
            "Encode a tree of L^K leaf ids under top_id (must supply "
            "exactly L^K leaf_ids in row-major order). Lets a single "
            "top-level id resolve to any leaf via a K-position path. "
            "Per-tenant stateful."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "tenant_id": {"type": "string", "default": "default"},
                "namespace": {"type": "string", "default": "hier"},
                "top_id": {"type": "string"},
                "leaf_ids": {"type": "array", "items": {"type": "integer"}},
                "L": {"type": "integer", "default": 4},
                "K": {"type": "integer", "default": 5},
                "n_leaf_vocab": {"type": "integer", "default": 1000},
                "seed": {"type": "integer", "default": 2050},
            },
            "required": ["top_id", "leaf_ids"],
        },
    ),
    Tool(
        name="agent_hierarchical_decode",
        description=(
            "Walk a path of K position indices (outer-to-inner, each in "
            "[0, L)) from top_id and return the leaf_id at that path. "
            "404 if no tree stored."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "tenant_id": {"type": "string", "default": "default"},
                "namespace": {"type": "string", "default": "hier"},
                "top_id": {"type": "string"},
                "path": {"type": "array", "items": {"type": "integer"}},
            },
            "required": ["top_id", "path"],
        },
    ),
    Tool(
        name="agent_induce_rule",
        description=(
            "Given matched (xs, ys) demo grids, infer which named "
            "transformation rule applies (e.g. rot90, color_invert, "
            "mirror_h). Returns {rule_name, confidence}. Stateless. xs "
            "and ys must be same length."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "xs": {
                    "type": "array",
                    "items": {
                        "type": "array",
                        "items": {"type": "array", "items": {"type": "integer"}},
                    },
                },
                "ys": {
                    "type": "array",
                    "items": {
                        "type": "array",
                        "items": {"type": "array", "items": {"type": "integer"}},
                    },
                },
            },
            "required": ["xs", "ys"],
        },
    ),
    Tool(
        name="agent_persist_rule",
        description=(
            "Induce a rule from (xs, ys) demos AND store it under "
            "rule_id for later recall. Returns {rule_name, confidence, "
            "n_rules_stored}. Per-tenant stateful."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "tenant_id": {"type": "string", "default": "default"},
                "namespace": {"type": "string", "default": "rules"},
                "rule_id": {"type": "string"},
                "xs": {
                    "type": "array",
                    "items": {
                        "type": "array",
                        "items": {"type": "array", "items": {"type": "integer"}},
                    },
                },
                "ys": {
                    "type": "array",
                    "items": {
                        "type": "array",
                        "items": {"type": "array", "items": {"type": "integer"}},
                    },
                },
            },
            "required": ["rule_id", "xs", "ys"],
        },
    ),
    Tool(
        name="agent_recall_rule",
        description=(
            "Recall a previously persisted rule by rule_id. Returns "
            "{rule_name, confidence}. 404 if no rules stored in this "
            "namespace yet."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "tenant_id": {"type": "string", "default": "default"},
                "namespace": {"type": "string", "default": "rules"},
                "rule_id": {"type": "string"},
            },
            "required": ["rule_id"],
        },
    ),
]


async def _dispatch(client: httpx.AsyncClient, name: str, args: dict[str, Any]) -> Any:
    # ----- Records -----
    if name == "records_ingest":
        return await _call(
            client, "POST",
            f"/v1/records/{_enc(args.get('namespace', ''))}",
            {"items": args["items"]},
        )
    if name == "records_query":
        body: dict[str, Any] = {
            "topK": args.get("topK", 10),
            "includeText": args.get("includeText", True),
            "includeMeta": args.get("includeMeta", True),
        }
        for k in ("text", "kind", "tagsAny", "tagsAll", "tsGte", "tsLt", "userId"):
            if k in args:
                body[k] = args[k]
        return await _call(
            client, "POST",
            f"/v1/records/{_enc(args.get('namespace', ''))}/query", body,
        )
    if name == "records_timeline":
        params: list[str] = []
        for k in ("since", "until", "limit"):
            if args.get(k) is not None:
                params.append(f"{k}={int(args[k])}")
        for k in ("kind", "tagsAny", "tagsAll", "userId"):
            if args.get(k):
                params.append(f"{k}={_enc(str(args[k]))}")
        qs = ("?" + "&".join(params)) if params else ""
        return await _call(
            client, "GET",
            f"/v1/records/{_enc(args.get('namespace', ''))}/timeline{qs}",
        )
    if name == "records_get":
        return await _call(
            client, "GET",
            f"/v1/records/{_enc(args.get('namespace', ''))}/{_enc(args['id'])}",
        )
    if name == "records_delete":
        return await _call(
            client, "DELETE",
            f"/v1/records/{_enc(args.get('namespace', ''))}/{_enc(args['id'])}",
        )
    if name == "records_forget":
        body = {}
        for k in ("kind", "tagsAny", "tagsAll", "tsGte", "tsLt", "ids", "userId"):
            if args.get(k) is not None:
                body[k] = args[k]
        return await _call(
            client, "POST",
            f"/v1/records/{_enc(args.get('namespace', ''))}/forget", body,
        )
    if name == "records_compact":
        body = {
            "summaryKind": args.get("summaryKind", "summary"),
            "maxChars": args.get("maxChars", 4000),
        }
        for k in ("kind", "tagsAny", "tagsAll", "tsGte", "tsLt", "userId"):
            if args.get(k) is not None:
                body[k] = args[k]
        return await _call(
            client, "POST",
            f"/v1/records/{_enc(args.get('namespace', ''))}/compact", body,
        )
    if name == "records_stats":
        return await _call(
            client, "GET",
            f"/v1/records/{_enc(args.get('namespace', ''))}/stats",
        )
    if name == "records_export":
        import base64
        url = f"{BASE_URL}/v1/records/{_enc(args.get('namespace', ''))}/export"
        r = await client.get(url, headers={"Api-Key": API_KEY or ""})
        if r.status_code >= 400:
            raise RuntimeError(f"GET records export -> {r.status_code}: {r.text}")
        return {
            "neruva_base64": base64.b64encode(r.content).decode("ascii"),
            "bytes": len(r.content),
        }
    if name == "records_import":
        import base64
        blob = base64.b64decode(args["neruva_base64"])
        url = f"{BASE_URL}/v1/records/{_enc(args.get('namespace', ''))}/import"
        files = {"file": ("ns.neruva", blob, "application/x-neruva")}
        r = await client.post(
            url, headers={"Api-Key": API_KEY or ""}, files=files,
        )
        if r.status_code >= 400:
            raise RuntimeError(f"POST records import -> {r.status_code}: {r.text}")
        try:
            return r.json()
        except Exception:
            return r.text
    # ----- Memory index (legacy vector layer) -----
    if name == "memory_embed":
        return await _call(client, "POST", "/v1/memory/embed", {"texts": args["texts"]})
    if name == "memory_list_indexes":
        return await _call(client, "GET", "/v1/indexes")
    if name == "memory_describe_index":
        return await _call(client, "GET", f"/v1/indexes/{_enc(args['name'])}")
    if name == "memory_stats":
        return await _call(
            client, "GET", f"/v1/indexes/{_enc(args['name'])}/describe_index_stats",
        )
    if name == "memory_fetch":
        ids_qs = "&".join(f"ids={_enc(i)}" for i in args["ids"])
        ns_qs = f"&namespace={_enc(args['namespace'])}" if args.get("namespace") else ""
        return await _call(
            client, "GET",
            f"/v1/indexes/{_enc(args['index'])}/vectors/fetch?{ids_qs}{ns_qs}",
        )
    if name == "memory_update":
        body: dict[str, Any] = {"id": args["id"], "namespace": args.get("namespace", "")}
        if "values" in args:
            body["values"] = args["values"]
        # Server expects setMetadata; sending metadata is a silent no-op.
        if "metadata" in args:
            body["setMetadata"] = args["metadata"]
        return await _call(
            client, "POST", f"/v1/indexes/{_enc(args['index'])}/vectors/update", body,
        )
    if name == "memory_export":
        import base64
        ns_qs = f"?namespace={_enc(args['namespace'])}" if args.get("namespace") is not None else ""
        url = f"{BASE_URL}/v1/indexes/{_enc(args['index'])}/export{ns_qs}"
        r = await client.get(url, headers={"Api-Key": API_KEY or ""})
        if r.status_code >= 400:
            raise RuntimeError(f"GET export -> {r.status_code}: {r.text}")
        return {"nmm_base64": base64.b64encode(r.content).decode("ascii"), "bytes": len(r.content)}
    if name == "memory_import":
        import base64
        url = f"{BASE_URL}/v1/indexes/{_enc(args['index'])}/import"
        r = await client.post(
            url,
            headers={"Api-Key": API_KEY or "", "Content-Type": "application/octet-stream"},
            content=base64.b64decode(args["nmm_base64"]),
        )
        if r.status_code >= 400:
            raise RuntimeError(f"POST import -> {r.status_code}: {r.text}")
        try:
            return r.json()
        except Exception:
            return r.text
    if name == "memory_upsert_text":
        return await _call(
            client, "POST",
            f"/v1/indexes/{_enc(args['index'])}/text/upsert",
            {"items": args["items"], "namespace": args.get("namespace", "")},
        )
    if name == "memory_query_text":
        return await _call(
            client, "POST",
            f"/v1/indexes/{_enc(args['index'])}/text/query",
            {
                "text": args["text"],
                "namespace": args.get("namespace", ""),
                "topK": args.get("topK", 10),
                "includeMetadata": args.get("includeMetadata", True),
                "includeValues": args.get("includeValues", False),
                "filter": _fold_tags(args.get("filter"), args.get("tags"), args.get("tagsAny")),
            },
        )
    if name == "memory_replace_text":
        return await _call(
            client, "POST",
            f"/v1/indexes/{_enc(args['index'])}/text/replace",
            {"id": args["id"], "newText": args["newText"], "namespace": args.get("namespace", "")},
        )
    if name == "memory_forget_where":
        return await _call(
            client, "POST",
            f"/v1/indexes/{_enc(args['index'])}/vectors/delete",
            {"filter": args["filter"], "namespace": args.get("namespace", "")},
        )
    if name == "memory_bind_role":
        return await _call(
            client, "POST",
            f"/v1/indexes/{_enc(args['index'])}/roles/bind",
            {"id": args["id"], "role": args["role"], "namespace": args.get("namespace", "")},
        )
    if name == "memory_read_roles":
        body: dict[str, Any] = {
            "id": args["id"],
            "queryVector": args["queryVector"],
            "roleDict": args["roleDict"],
            "namespace": args.get("namespace", ""),
        }
        if "known" in args:
            body["known"] = args["known"]
        return await _call(
            client, "POST",
            f"/v1/indexes/{_enc(args['index'])}/roles/read",
            body,
        )
    if name == "memory_create_index":
        return await _call(
            client,
            "POST",
            "/v1/indexes",
            {
                "name": args["name"],
                "dimension": args["dimension"],
                "metric": args.get("metric", "cosine"),
            },
        )
    if name == "memory_upsert":
        return await _call(
            client,
            "POST",
            f"/v1/indexes/{_enc(args['index'])}/vectors/upsert",
            {
                "vectors": args["vectors"],
                "namespace": args.get("namespace", ""),
            },
        )
    if name == "memory_query":
        return await _call(
            client,
            "POST",
            f"/v1/indexes/{_enc(args['index'])}/query",
            {
                "vector": args["vector"],
                "namespace": args.get("namespace", ""),
                "topK": args.get("topK", 10),
                "includeMetadata": args.get("includeMetadata", True),
                "includeValues": args.get("includeValues", False),
                "filter": _fold_tags(args.get("filter"), args.get("tags"), args.get("tagsAny")),
            },
        )
    if name == "memory_delete":
        return await _call(
            client,
            "POST",
            f"/v1/indexes/{_enc(args['index'])}/vectors/delete",
            {
                "ids": args["ids"],
                "namespace": args.get("namespace", ""),
            },
        )
    if name == "hd_kg_add_fact":
        body: dict[str, Any] = {
            "facts": [
                {
                    "subject": args["subject"],
                    "relation": args["relation"],
                    "object": args["object"],
                }
            ]
        }
        if args.get("engine"):
            body["engine"] = args["engine"]
        return await _call(
            client,
            "POST",
            f"/v1/hd/kg/{_enc(args['kg'])}/facts",
            body,
        )
    if name == "hd_kg_extraction_prompt":
        return await _call(client, "GET", "/v1/hd/kg/extraction_prompt")
    if name == "hd_kg_add_facts":
        body: dict[str, Any] = {"facts": args["facts"]}
        if args.get("engine"):
            body["engine"] = args["engine"]
        return await _call(
            client, "POST", f"/v1/hd/kg/{_enc(args['kg'])}/facts", body,
        )
    if name == "hd_kg_query_topk":
        return await _call(
            client, "POST", f"/v1/hd/kg/{_enc(args['kg'])}/query_topk",
            {
                "subject": args["subject"],
                "relation": args["relation"],
                "k": args.get("k", 5),
            },
        )
    if name == "hd_kg_list":
        return await _call(client, "GET", "/v1/hd/kg")
    if name == "hd_kg_describe":
        return await _call(client, "GET", f"/v1/hd/kg/{_enc(args['kg'])}/describe")
    if name == "hd_scm_list":
        return await _call(client, "GET", "/v1/hd/causal")
    if name == "hd_scm_describe":
        return await _call(client, "GET", f"/v1/hd/causal/{_enc(args['scm'])}/describe")
    if name == "hd_cbr_list":
        return await _call(client, "GET", "/v1/hd/cbr")
    if name == "hd_cbr_describe":
        return await _call(client, "GET", f"/v1/hd/cbr/{_enc(args['cbr'])}/describe")
    if name == "memory_delete_index":
        return await _call(client, "DELETE", f"/v1/indexes/{_enc(args['name'])}")
    if name == "records_update":
        body = {}
        for k_in, k_out in (("text", "text"), ("setTags", "setTags"),
                             ("addTags", "addTags"), ("setMeta", "setMeta"),
                             ("setKind", "setKind")):
            if args.get(k_in) is not None:
                body[k_out] = args[k_in]
        return await _call(
            client, "POST",
            f"/v1/records/{_enc(args.get('namespace', ''))}/{_enc(args['id'])}/update",
            body,
        )
    if name == "records_replace_text":
        return await _call(
            client, "POST",
            f"/v1/records/{_enc(args.get('namespace', ''))}/{_enc(args['id'])}/replace_text",
            {"newText": args["newText"]},
        )
    if name == "records_bind_tag":
        return await _call(
            client, "POST",
            f"/v1/records/{_enc(args.get('namespace', ''))}/{_enc(args['id'])}/bind_tag",
            {"tag": args["tag"]},
        )
    if name == "memory_timeline":
        params: list[str] = []
        if args.get("namespace") is not None:
            params.append(f"namespace={_enc(args['namespace'])}")
        for k in ("since", "until", "limit"):
            if args.get(k) is not None:
                params.append(f"{k}={int(args[k])}")
        if args.get("includeValues"):
            params.append("includeValues=true")
        qs = ("?" + "&".join(params)) if params else ""
        return await _call(
            client, "GET", f"/v1/indexes/{_enc(args['index'])}/timeline{qs}",
        )
    if name == "hd_kg_context":
        return await _call(
            client,
            "POST",
            f"/v1/hd/kg/{_enc(args['kg'])}/context",
            {
                "question": args["question"],
                "top_k": args.get("top_k", 10),
                "format": args.get("format", "markdown"),
            },
        )
    if name == "hd_kg_derive_relation":
        derive_body: dict[str, Any] = {
            "base_relation": args["base_relation"],
            "n_hops": args["n_hops"],
        }
        if args.get("derived_name"):
            derive_body["derived_name"] = args["derived_name"]
        return await _call(
            client,
            "POST",
            f"/v1/hd/kg/{_enc(args['kg'])}/derive",
            derive_body,
        )
    if name == "hd_kg_replace_fact":
        body = {
            "subject": args["subject"],
            "relation": args["relation"],
            "new_object": args["new_object"],
        }
        if args.get("old_object") is not None:
            body["old_object"] = args["old_object"]
        return await _call(
            client, "POST",
            f"/v1/hd/kg/{_enc(args['kg'])}/replace_fact",
            body,
        )
    if name == "hd_kg_query":
        q_body: dict[str, Any] = {
            "subject": args["subject"],
            "relation": args["relation"],
        }
        if args.get("retrieval"):
            q_body["retrieval"] = args["retrieval"]
        return await _call(
            client,
            "POST",
            f"/v1/hd/kg/{_enc(args['kg'])}/query",
            q_body,
        )
    if name == "hd_kg_assign_features":
        return await _call(
            client,
            "POST",
            f"/v1/hd/kg/{_enc(args['kg'])}/assign_features",
            {"concept": args["concept"], "feature_ids": args["feature_ids"]},
        )
    if name == "hd_kg_quorum_audit":
        return await _call(
            client,
            "POST",
            f"/v1/hd/kg/{_enc(args['kg'])}/quorum_audit",
            {"subject": args["subject"], "relation": args["relation"]},
        )
    if name == "hd_kg_compress":
        return await _call(
            client,
            "POST",
            f"/v1/hd/kg/{_enc(args['kg'])}/compress",
            {"relation": args["relation"], "rank": args.get("rank", 64)},
        )
    if name == "hd_kg_delete_fact":
        return await _call(
            client,
            "POST",
            f"/v1/hd/kg/{_enc(args['kg'])}/facts/delete",
            {
                "facts": [
                    {
                        "subject": args["subject"],
                        "relation": args["relation"],
                        "object": args["object"],
                    }
                ]
            },
        )
    if name == "hd_kg_export":
        import base64
        url = f"{BASE_URL}/v1/hd/kg/{_enc(args['kg'])}/export"
        r = await client.get(url, headers={"Api-Key": API_KEY or ""})
        if r.status_code >= 400:
            raise RuntimeError(f"GET kg export -> {r.status_code}: {r.text}")
        return {"hdkg_base64": base64.b64encode(r.content).decode("ascii"), "bytes": len(r.content)}
    if name == "hd_kg_import":
        import base64
        url = f"{BASE_URL}/v1/hd/kg/{_enc(args['kg'])}/import"
        r = await client.post(
            url,
            headers={"Api-Key": API_KEY or "", "Content-Type": "application/octet-stream"},
            content=base64.b64decode(args["hdkg_base64"]),
        )
        if r.status_code >= 400:
            raise RuntimeError(f"POST kg import -> {r.status_code}: {r.text}")
        try: return r.json()
        except Exception: return r.text
    if name == "hd_causal_export":
        import base64
        url = f"{BASE_URL}/v1/hd/causal/{_enc(args['scm'])}/export"
        r = await client.get(url, headers={"Api-Key": API_KEY or ""})
        if r.status_code >= 400:
            raise RuntimeError(f"GET scm export -> {r.status_code}: {r.text}")
        return {"hdscm_base64": base64.b64encode(r.content).decode("ascii"), "bytes": len(r.content)}
    if name == "hd_causal_import":
        import base64
        url = f"{BASE_URL}/v1/hd/causal/{_enc(args['scm'])}/import"
        r = await client.post(
            url,
            headers={"Api-Key": API_KEY or "", "Content-Type": "application/octet-stream"},
            content=base64.b64decode(args["hdscm_base64"]),
        )
        if r.status_code >= 400:
            raise RuntimeError(f"POST scm import -> {r.status_code}: {r.text}")
        try: return r.json()
        except Exception: return r.text
    if name == "hd_cbr_create":
        return await _call(
            client, "POST",
            f"/v1/hd/cbr/{_enc(args['cbr'])}/create",
            {
                "n_axes": args["n_axes"], "vocab": args["vocab"],
                "n_labels": args["n_labels"], "seed": args.get("seed", 4601),
            },
        )
    if name == "hd_cbr_add_episodes":
        return await _call(
            client, "POST",
            f"/v1/hd/cbr/{_enc(args['cbr'])}/episodes",
            {"cases": args["cases"], "labels": args["labels"]},
        )
    if name == "hd_cbr_query":
        return await _call(
            client, "POST",
            f"/v1/hd/cbr/{_enc(args['cbr'])}/query",
            {"case": args["case"], "k": args.get("k", 15)},
        )
    if name == "hd_blend_query":
        return await _call(
            client, "POST", "/v1/hd/blend/query",
            {
                "n_attrs": args["n_attrs"],
                "n_roles": args.get("n_roles", 16),
                "role_parents": args["role_parents"],
                "recover_role": args["recover_role"],
                "seed": args.get("seed", 5701),
            },
        )
    if name == "hd_analogy":
        return await _call(
            client,
            "POST",
            "/v1/hd/analogy",
            {
                "n_feat": args["n_feat"],
                "a": args["a"],
                "b": args["b"],
                "c": args["c"],
                "seed": args.get("seed", 4301),
            },
        )
    if name == "hd_causal_add_worlds":
        return await _call(
            client,
            "POST",
            f"/v1/hd/causal/{_enc(args['scm'])}/worlds",
            {
                "n_vars": args["n_vars"],
                "vocab_per_var": args["vocab_per_var"],
                "worlds": args["worlds"],
                "seed": args.get("seed", 4401),
            },
        )
    if name == "hd_causal_query":
        return await _call(
            client,
            "POST",
            f"/v1/hd/causal/{_enc(args['scm'])}/query",
            {
                "query_type": args["query_type"],
                "condition_var": args["condition_var"],
                "condition_value": args["condition_value"],
                "query_var": args["query_var"],
                "query_value": args["query_value"],
            },
        )

    # ----- Federated agent_* -----
    if name == "agent_remember":
        body = {"text": args["text"]}
        for k in ("namespace", "extract", "triples", "tags", "kind", "user_id"):
            if args.get(k) is not None:
                body[k] = args[k]
        return await _call(client, "POST", "/v1/agent/remember", body)
    if name == "agent_recall":
        body = {"query": args["query"], "top_k": args.get("top_k", 10)}
        for k in ("namespace", "namespaces", "user_id"):
            if args.get(k) is not None:
                body[k] = args[k]
        return await _call(client, "POST", "/v1/agent/recall", body)
    if name == "agent_context":
        body = {
            "question": args["question"],
            "top_k": args.get("top_k", 10),
            "max_chars": args.get("max_chars", 4000),
        }
        for k in ("namespace", "question_type", "user_id"):
            if args.get(k) is not None:
                body[k] = args[k]
        return await _call(client, "POST", "/v1/agent/context", body)
    if name == "agent_causal_query":
        return await _call(client, "POST", "/v1/agent/causal_query", {
            "scm": args["scm"],
            "condition_var": args["condition_var"],
            "condition_value": args["condition_value"],
            "query_var": args["query_var"],
            "query_value": args["query_value"],
        })
    if name == "agent_snapshot":
        body = {"namespace": args["namespace"]}
        for k in ("snapshot_id", "note"):
            if args.get(k) is not None:
                body[k] = args[k]
        return await _call(client, "POST", "/v1/agent/snapshot", body)
    if name == "agent_restore":
        return await _call(client, "POST", "/v1/agent/restore", {
            "snapshot_id": args["snapshot_id"],
            "target_namespace": args["target_namespace"],
        })
    if name == "agent_check_consistency":
        return await _call(client, "POST", "/v1/agent/check_consistency", {
            "kg": args["kg"],
            "max_anomalies": args.get("max_anomalies", 100),
        })
    if name == "agent_postmortem":
        body = {
            "agent": args["agent"],
            "task_text": args["task_text"],
            "plan": args.get("plan") or [],
            "history": args.get("history") or [],
        }
        for k in ("error", "task_class", "app"):
            if args.get(k) is not None:
                body[k] = args[k]
        return await _call(client, "POST", "/v1/agent/postmortem", body)
    if name == "agent_plan_cache_save":
        body = {"task_text": args["task_text"], "plan": args["plan"]}
        for k in ("namespace", "success", "duration_ms", "user_id",
                  "tags", "ttl_days"):
            if args.get(k) is not None:
                body[k] = args[k]
        return await _call(client, "POST", "/v1/agent/plan_cache_save", body)
    if name == "agent_plan_cache_lookup":
        body = {"task_text": args["task_text"]}
        for k in ("namespace", "top_k", "min_score", "user_id"):
            if args.get(k) is not None:
                body[k] = args[k]
        return await _call(client, "POST", "/v1/agent/plan_cache_lookup", body)

    # ----- Self-introspection -----
    if name == "neruva_wallet_status":
        return await _call(client, "GET", "/v1/me/wallet")
    if name == "neruva_op_stats":
        window = args.get("window", "30d")
        return await _call(client, "GET", f"/v1/me/usage?window={_enc(window)}")
    if name == "neruva_keys_list":
        return await _call(client, "GET", "/v1/me/keys")
    if name == "neruva_op_log":
        limit = int(args.get("limit", 50))
        return await _call(client, "GET", f"/v1/me/op_log?limit={limit}")

    # ----- Cognitive primitives (substrate v0.4.0) -----
    if name == "agent_counterfactual_rollout":
        return await _call(client, "POST", "/v1/agent/counterfactual_rollout", {
            "initial_state": args["initial_state"],
            "action_seq": args["action_seq"],
            "step_k": args["step_k"],
            "alternate_action": args["alternate_action"],
            "n_axes": args.get("n_axes", 3),
            "n_values": args.get("n_values", 8),
            "seed": args.get("seed", 2047),
        })
    if name == "agent_model_belief_add":
        return await _call(client, "POST", "/v1/agent/model_belief_add", {
            "tenant_id": args.get("tenant_id", "default"),
            "namespace": args.get("namespace", "tom"),
            "chain": args["chain"],
            "prop": args["prop"],
            "val": args["val"],
            "n_people": args.get("n_people", 10),
            "n_props": args.get("n_props", 50),
            "n_vals": args.get("n_vals", 20),
            "max_depth": args.get("max_depth", 4),
            "seed": args.get("seed", 2048),
        })
    if name == "agent_model_belief":
        return await _call(client, "POST", "/v1/agent/model_belief", {
            "tenant_id": args.get("tenant_id", "default"),
            "namespace": args.get("namespace", "tom"),
            "chain": args["chain"],
            "prop": args["prop"],
        })
    if name == "agent_extract_schema":
        return await _call(client, "POST", "/v1/agent/extract_schema", {
            "tenant_id": args.get("tenant_id", "default"),
            "namespace": args.get("namespace", "schema"),
            "role_filler_pairs": args["role_filler_pairs"],
            "n_roles": args.get("n_roles", 10),
            "n_fillers_per_role": args.get("n_fillers_per_role", 100),
            "seed": args.get("seed", 2049),
        })
    if name == "agent_register_action":
        return await _call(client, "POST", "/v1/agent/register_action", {
            "tenant_id": args.get("tenant_id", "default"),
            "namespace": args.get("namespace", "planner"),
            "action_id": args["action_id"],
            "add_effects": args.get("add_effects", {}),
            "del_effects": args.get("del_effects", {}),
            "n_attrs": args.get("n_attrs", 100),
            "seed": args.get("seed", 6001),
        })
    if name == "agent_plan_efe":
        return await _call(client, "POST", "/v1/agent/plan_efe", {
            "tenant_id": args.get("tenant_id", "default"),
            "namespace": args.get("namespace", "planner"),
            "state": args["state"],
            "candidate_plans": args["candidate_plans"],
            "want_on": args.get("want_on", []),
            "want_off": args.get("want_off", []),
            "p_on": args.get("p_on", 0.95),
            "p_off": args.get("p_off", 0.05),
        })
    if name == "agent_continual_train":
        return await _call(client, "POST", "/v1/agent/continual_train", {
            "tenant_id": args.get("tenant_id", "default"),
            "namespace": args.get("namespace", "continual"),
            "token_stream": args["token_stream"],
            "vocab_size": args.get("vocab_size", 200),
            "k": args.get("k", 2),
            "seed": args.get("seed", 7000),
        })
    if name == "agent_continual_predict":
        return await _call(client, "POST", "/v1/agent/continual_predict", {
            "tenant_id": args.get("tenant_id", "default"),
            "namespace": args.get("namespace", "continual"),
            "token_stream": args["token_stream"],
        })
    if name == "agent_hierarchical_add":
        return await _call(client, "POST", "/v1/agent/hierarchical_add", {
            "tenant_id": args.get("tenant_id", "default"),
            "namespace": args.get("namespace", "hier"),
            "top_id": args["top_id"],
            "leaf_ids": args["leaf_ids"],
            "L": args.get("L", 4),
            "K": args.get("K", 5),
            "n_leaf_vocab": args.get("n_leaf_vocab", 1000),
            "seed": args.get("seed", 2050),
        })
    if name == "agent_hierarchical_decode":
        return await _call(client, "POST", "/v1/agent/hierarchical_decode", {
            "tenant_id": args.get("tenant_id", "default"),
            "namespace": args.get("namespace", "hier"),
            "top_id": args["top_id"],
            "path": args["path"],
        })
    if name == "agent_induce_rule":
        return await _call(client, "POST", "/v1/agent/induce_rule", {
            "xs": args["xs"],
            "ys": args["ys"],
        })
    if name == "agent_persist_rule":
        return await _call(client, "POST", "/v1/agent/persist_rule", {
            "tenant_id": args.get("tenant_id", "default"),
            "namespace": args.get("namespace", "rules"),
            "rule_id": args["rule_id"],
            "xs": args["xs"],
            "ys": args["ys"],
        })
    if name == "agent_recall_rule":
        return await _call(client, "POST", "/v1/agent/recall_rule", {
            "tenant_id": args.get("tenant_id", "default"),
            "namespace": args.get("namespace", "rules"),
            "rule_id": args["rule_id"],
        })

    raise ValueError(f"unknown tool: {name}")


async def _run() -> None:
    if not API_KEY:
        print(
            "[neruva-mcp] NERUVA_API_KEY not set. Get one at https://app.neruva.io",
            file=sys.stderr,
        )
        sys.exit(1)

    if AR_NAMESPACE:
        ttl_note = f" (TTL {AR_TTL_DAYS}d)" if AR_TTL_DAYS else ""
        print(
            f"[neruva-mcp] auto-record ON: tool calls -> "
            f"records/{AR_NAMESPACE}{ttl_note}",
            file=sys.stderr,
        )

    server: Server = Server("neruva")

    @server.list_tools()
    async def list_tools() -> list[Tool]:
        return TOOLS

    async with httpx.AsyncClient(timeout=60.0) as client:

        @server.call_tool()
        async def call_tool(name: str, arguments: dict[str, Any]) -> list[TextContent]:
            t0 = time.perf_counter()
            try:
                result = await _dispatch(client, name, arguments or {})
                # Fire-and-forget recording (never blocks return, never throws).
                asyncio.create_task(
                    _maybe_record(
                        client, name, arguments or {}, result,
                        int((time.perf_counter() - t0) * 1000),
                    )
                )
                return [TextContent(type="text", text=json.dumps(result, indent=2))]
            except Exception as e:
                return [TextContent(type="text", text=f"error: {e}")]

        async with stdio_server() as (read_stream, write_stream):
            await server.run(
                read_stream,
                write_stream,
                server.create_initialization_options(),
            )


def main() -> None:
    _check_for_update()  # one-shot banner if newer version available
    asyncio.run(_run())


if __name__ == "__main__":
    main()
