import json
import os
from abc import ABC, abstractmethod
from datetime import datetime

from .models import AlertReport, CorrelationResult


def _build_prompt(r: CorrelationResult) -> str:
    return (
        "Datos estadísticos CALCULADOS (no los inventes ni los modifiques):\n"
        f"Variable: {r.metric_name}\n"
        f"Mediana baseline: {r.baseline_median}\n"
        f"Mediana pre-evento: {r.pre_event_median}\n"
        f"p-valor Mann-Whitney U: {r.p_value}\n"
        f"Tamaño del efecto (rank-biserial): {r.effect_size}\n"
        "Escribe UNA frase en español. Máximo 20 palabras.\n"
        "Usa: patrón detectado, asociación observada.\n"
        "Prohibido: diagnóstico, causa, predice, confirma."
    )


def _write_audit(path: str, result: CorrelationResult, prompt: str) -> None:
    """Append one JSONL entry: stats + prompt + LLM response."""
    entry = {
        "ts": datetime.now().isoformat(),
        "metric": result.metric_name,
        "stats": {
            "p_value": result.p_value,
            "effect_size": result.effect_size,
            "causality_score": result.causality_score,
            "signal_strength": result.signal_strength,
            "baseline_median": result.baseline_median,
            "pre_event_median": result.pre_event_median,
        },
        "prompt": prompt,
        "response": result.narrative,
    }
    with open(path, "a", encoding="utf-8") as f:
        f.write(json.dumps(entry, ensure_ascii=False) + "\n")


class BaseNarrator(ABC):
    """Abstract base for LLM narrator providers."""

    @abstractmethod
    def generate(self, prompt: str) -> str:
        """Return a single narration sentence for the given prompt."""

    def narrate(self, report: AlertReport, audit_log: str | None = None) -> AlertReport:
        if report.level == "green":
            return report

        individual_narratives: list[str] = []
        for result in report.results:
            if result.significant:
                prompt = _build_prompt(result)
                result.narrative = self.generate(prompt)
                if audit_log:
                    _write_audit(audit_log, result, prompt)
                individual_narratives.append(f"[{result.metric_name}] {result.narrative}")

        report.narrative = "\n".join(individual_narratives) if individual_narratives else None
        return report


class GroqNarrator(BaseNarrator):
    def __init__(self, api_key: str | None = None, model: str = "llama3-8b-8192"):
        try:
            from groq import Groq
        except ImportError:
            raise ImportError(
                "groq is not installed. Run: pip install chrono-correlator[groq]"
            )
        key = api_key or os.environ.get("GROQ_API_KEY")
        if not key:
            raise RuntimeError(
                "GROQ_API_KEY not set. Export it or pass api_key=... to GroqNarrator()."
            )
        self._client = Groq(api_key=key)
        self._model = model

    def generate(self, prompt: str) -> str:
        response = self._client.chat.completions.create(
            model=self._model,
            messages=[{"role": "user", "content": prompt}],
            max_tokens=80,
        )
        return response.choices[0].message.content.strip()


class AnthropicNarrator(BaseNarrator):
    def __init__(self, api_key: str | None = None, model: str = "claude-haiku-4-5-20251001"):
        try:
            import anthropic as _anthropic
        except ImportError:
            raise ImportError(
                "anthropic is not installed. Run: pip install chrono-correlator[anthropic]"
            )
        key = api_key or os.environ.get("ANTHROPIC_API_KEY")
        if not key:
            raise RuntimeError(
                "ANTHROPIC_API_KEY not set. Export it or pass api_key=... to AnthropicNarrator()."
            )
        self._client = _anthropic.Anthropic(api_key=key)
        self._model = model

    def generate(self, prompt: str) -> str:
        response = self._client.messages.create(
            model=self._model,
            max_tokens=80,
            messages=[{"role": "user", "content": prompt}],
        )
        return response.content[0].text.strip()


class OllamaNarrator(BaseNarrator):
    """Local LLM narrator via Ollama — no API key, full privacy."""

    def __init__(self, model: str = "llama3", host: str = "http://localhost:11434"):
        try:
            import ollama as _ollama  # noqa: F401
        except ImportError:
            raise ImportError(
                "ollama is not installed. Run: pip install ollama"
            )
        self._model = model
        self._host = host

    def generate(self, prompt: str) -> str:
        import ollama
        client = ollama.Client(host=self._host)
        response = client.chat(
            model=self._model,
            messages=[{"role": "user", "content": prompt}],
        )
        return response.message.content.strip()


def narrate(
    report: AlertReport,
    provider: str = "groq",
    audit_log: str | None = None,
) -> AlertReport:
    """Convenience wrapper — picks narrator by provider name string.

    audit_log: path to a JSONL file where each LLM call is recorded
               (stats + prompt + response). Useful for audits in regulated environments.
    """
    narrator: BaseNarrator
    if provider == "groq":
        narrator = GroqNarrator()
    elif provider == "anthropic":
        narrator = AnthropicNarrator()
    elif provider == "ollama":
        narrator = OllamaNarrator()
    else:
        raise ValueError(
            f"Unknown provider '{provider}'. Use 'groq', 'anthropic', 'ollama', "
            "or instantiate a BaseNarrator subclass directly."
        )
    return narrator.narrate(report, audit_log=audit_log)
