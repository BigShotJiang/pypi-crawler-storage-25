"""HTML and Markdown export for AlertReport — zero external dependencies."""
from __future__ import annotations

from datetime import datetime

from .models import AlertReport

_HTML = """\
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>chrono-correlator report</title>
<style>
  body{{font-family:system-ui,sans-serif;max-width:960px;margin:2rem auto;color:#1a1a1a;line-height:1.5}}
  h1{{font-size:1.4rem;margin-bottom:.25rem}}
  .meta{{color:#555;font-size:.9rem;margin-bottom:1rem}}
  .green{{color:#16a34a;font-weight:600}}
  .yellow{{color:#ca8a04;font-weight:600}}
  .red{{color:#dc2626;font-weight:600}}
  blockquote{{border-left:3px solid #d1d5db;margin:1rem 0;padding:.4rem 1rem;color:#555;font-style:italic}}
  table{{border-collapse:collapse;width:100%;font-size:.875rem;margin-top:1rem}}
  th,td{{border:1px solid #e5e7eb;padding:.45rem .75rem;text-align:left}}
  th{{background:#f9fafb;font-weight:600}}
  .yes{{color:#16a34a}}.no{{color:#9ca3af}}
  h2{{font-size:1.1rem;margin-top:1.75rem}}
  li{{margin:.25rem 0}}
</style>
</head>
<body>
<h1>chrono-correlator &mdash; Alert Report</h1>
<p class="meta">Generated: {generated} &nbsp;|&nbsp; Level: <span class="{level}">{level_upper}</span>
&nbsp;|&nbsp; Active signals: {active}/{total}</p>
{narrative_block}
<table>
<thead><tr>
  <th>Metric</th><th>Sig.</th><th>Strength</th><th>p-value</th>
  <th>Effect (CI)</th><th>Consistency</th><th>Causality</th>
  <th>Baseline</th><th>Pre-event</th>
</tr></thead>
<tbody>
{rows}
</tbody>
</table>
{narratives_block}
</body>
</html>"""


def export_html(report: AlertReport, path: str) -> None:
    """Write an HTML report to path."""
    generated = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    narrative_block = (
        f"<blockquote>{report.narrative}</blockquote>" if report.narrative else ""
    )

    rows = []
    for r in report.results:
        p = r.adjusted_p_value if r.adjusted_p_value is not None else r.p_value
        ci = (
            f" <small>[{r.effect_ci[0]:.3f}, {r.effect_ci[1]:.3f}]</small>"
            if r.effect_ci else ""
        )
        sig_cls = "yes" if r.significant else "no"
        sig_lbl = "yes" if r.significant else "no"
        rows.append(
            f"<tr>"
            f"<td>{r.metric_name}</td>"
            f'<td class="{sig_cls}">{sig_lbl}</td>'
            f"<td>{r.signal_strength}</td>"
            f"<td>{p:.4f}</td>"
            f"<td>{r.effect_size:.3f}{ci}</td>"
            f"<td>{r.consistency:.2f}</td>"
            f"<td>{r.causality_score:.2f}</td>"
            f"<td>{r.baseline_median:.2f}</td>"
            f"<td>{r.pre_event_median:.2f}</td>"
            f"</tr>"
        )

    narrated = [(r.metric_name, r.narrative) for r in report.results if r.narrative]
    narratives_block = ""
    if narrated:
        items = "".join(f"<li><strong>{n}</strong>: {t}</li>" for n, t in narrated)
        narratives_block = f"<h2>Signal narratives</h2><ul>{items}</ul>"

    html = _HTML.format(
        generated=generated,
        level=report.level,
        level_upper=report.level.upper(),
        active=report.active_signals,
        total=report.total_signals,
        narrative_block=narrative_block,
        rows="\n".join(rows),
        narratives_block=narratives_block,
    )

    with open(path, "w", encoding="utf-8") as f:
        f.write(html)


def export_markdown(report: AlertReport, path: str) -> None:
    """Write a Markdown report to path."""
    lines: list[str] = [
        "# chrono-correlator — Alert Report",
        "",
        f"**Generated:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}  ",
        f"**Level:** {report.level.upper()}  ",
        f"**Active signals:** {report.active_signals}/{report.total_signals}",
        "",
    ]

    if report.narrative:
        lines += [f"> {report.narrative}", ""]

    lines += [
        "| Metric | Sig. | Strength | p-value | Effect (CI) | Consistency | Causality | Baseline | Pre-event |",
        "|--------|------|----------|---------|-------------|-------------|-----------|----------|-----------|",
    ]

    for r in report.results:
        p = r.adjusted_p_value if r.adjusted_p_value is not None else r.p_value
        ci = f" [{r.effect_ci[0]:.3f},{r.effect_ci[1]:.3f}]" if r.effect_ci else ""
        sig = "yes" if r.significant else "no"
        lines.append(
            f"| {r.metric_name} | {sig} | {r.signal_strength} | {p:.4f} | "
            f"{r.effect_size:.3f}{ci} | {r.consistency:.2f} | {r.causality_score:.2f} | "
            f"{r.baseline_median:.2f} | {r.pre_event_median:.2f} |"
        )

    narrated = [(r.metric_name, r.narrative) for r in report.results if r.narrative]
    if narrated:
        lines += ["", "## Signal narratives", ""]
        for name, text in narrated:
            lines.append(f"- **{name}**: {text}")

    with open(path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")
