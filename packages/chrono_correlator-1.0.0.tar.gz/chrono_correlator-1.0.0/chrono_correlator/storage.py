"""SQLite persistence for AlertReport — zero external dependencies (stdlib only)."""
from __future__ import annotations

import json
import sqlite3
from datetime import datetime
from typing import Optional

from .models import AlertReport, CorrelationResult

_DDL = """
CREATE TABLE IF NOT EXISTS reports (
    id        INTEGER PRIMARY KEY AUTOINCREMENT,
    ts        TEXT    NOT NULL,
    level     TEXT    NOT NULL,
    active    INTEGER NOT NULL,
    total     INTEGER NOT NULL,
    narrative TEXT,
    results   TEXT    NOT NULL
)"""


def _result_to_dict(r: CorrelationResult) -> dict:
    return {
        "metric_name": r.metric_name,
        "p_value": r.p_value,
        "significant": r.significant,
        "effect_size": r.effect_size,
        "baseline_median": r.baseline_median,
        "pre_event_median": r.pre_event_median,
        "consistency": r.consistency,
        "signal_strength": r.signal_strength,
        "causality_score": r.causality_score,
        "adjusted_p_value": r.adjusted_p_value,
        "effect_ci": list(r.effect_ci) if r.effect_ci else None,
        "narrative": r.narrative,
    }


def _result_from_dict(d: dict) -> CorrelationResult:
    ci = d.get("effect_ci")
    return CorrelationResult(
        metric_name=d["metric_name"],
        p_value=d["p_value"],
        significant=d["significant"],
        effect_size=d["effect_size"],
        baseline_median=d["baseline_median"],
        pre_event_median=d["pre_event_median"],
        consistency=d["consistency"],
        signal_strength=d["signal_strength"],
        causality_score=d["causality_score"],
        adjusted_p_value=d.get("adjusted_p_value"),
        effect_ci=tuple(ci) if ci else None,
        narrative=d.get("narrative"),
    )


def save_report(report: AlertReport, db_path: str = "chrono.db") -> int:
    """Persist an AlertReport to SQLite. Returns the inserted row ID."""
    con = sqlite3.connect(db_path)
    with con:
        con.execute(_DDL)
        cur = con.execute(
            "INSERT INTO reports (ts, level, active, total, narrative, results) "
            "VALUES (?, ?, ?, ?, ?, ?)",
            (
                datetime.now().isoformat(),
                report.level,
                report.active_signals,
                report.total_signals,
                report.narrative,
                json.dumps([_result_to_dict(r) for r in report.results]),
            ),
        )
        return cur.lastrowid


def load_reports(
    db_path: str = "chrono.db",
    since: Optional[datetime] = None,
    level: Optional[str] = None,
) -> list[AlertReport]:
    """Load historical reports, optionally filtered by timestamp and/or alert level."""
    con = sqlite3.connect(db_path)
    con.execute(_DDL)

    where, params = [], []
    if since:
        where.append("ts >= ?")
        params.append(since.isoformat())
    if level:
        where.append("level = ?")
        params.append(level)

    clause = f"WHERE {' AND '.join(where)}" if where else ""
    rows = con.execute(
        f"SELECT level, active, total, narrative, results FROM reports "
        f"{clause} ORDER BY ts DESC",
        params,
    ).fetchall()

    return [
        AlertReport(
            level=row[0],
            active_signals=row[1],
            total_signals=row[2],
            narrative=row[3],
            results=[_result_from_dict(d) for d in json.loads(row[4])],
        )
        for row in rows
    ]
