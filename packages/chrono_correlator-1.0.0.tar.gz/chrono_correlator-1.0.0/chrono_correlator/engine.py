import warnings
from datetime import datetime

import numpy as np

from .correlator import analyze
from .models import AlertReport, CorrelationResult, Event, Metric, SignificanceConfig

THRESHOLDS = {"green": (0, 2), "yellow": (3, 4), "red": (5, 7)}


def _apply_correction(
    results: list[CorrelationResult], method: str, cfg: SignificanceConfig
) -> None:
    p_values = np.array([r.p_value for r in results])

    if method == "bonferroni":
        adjusted = np.minimum(p_values * len(p_values), 1.0)
    elif method == "fdr":
        from scipy.stats import false_discovery_control
        adjusted = false_discovery_control(p_values, method="bh")
    else:
        raise ValueError(f"Unknown correction method '{method}'. Use 'bonferroni' or 'fdr'.")

    for r, p_adj in zip(results, adjusted):
        r.adjusted_p_value = float(p_adj)
        r.significant = bool(
            p_adj < cfg.alpha and r.signal_strength in ("strong", "moderate")
        )


def _warn_overlapping_events(events: list[Event], lookback_hours: int) -> None:
    """Emit UserWarning for any pair of events whose pre-event windows overlap."""
    sorted_events = sorted(events, key=lambda e: e.timestamp)
    for a, b in zip(sorted_events, sorted_events[1:]):
        gap_hours = (b.timestamp - a.timestamp).total_seconds() / 3600
        if gap_hours < lookback_hours:
            warnings.warn(
                f"Events '{a.label}' ({a.timestamp.date()}) and '{b.label}' "
                f"({b.timestamp.date()}) are {gap_hours:.0f}h apart — "
                f"pre-event windows overlap (lookback={lookback_hours}h). "
                "Pooled results may be inflated.",
                UserWarning,
                stacklevel=4,
            )


def evaluate(
    events: list[Event],
    metrics: list[Metric],
    lookback_hours: int = 48,
    baseline_days: int = 28,
    lag_hours: int = 0,
    correction: str | None = "fdr",
    direction: str = "two-sided",
    config: SignificanceConfig | None = None,
    bootstrap_ci: bool = False,
    bootstrap_resamples: int = 999,
    baseline_strategy: str = "rolling",
) -> AlertReport:
    cfg = config or SignificanceConfig()
    _warn_overlapping_events(events, lookback_hours)
    results: list[CorrelationResult] = []

    for metric in metrics:
        try:
            results.append(
                analyze(
                    events, metric, lookback_hours, baseline_days, lag_hours,
                    direction, cfg, bootstrap_ci, bootstrap_resamples, baseline_strategy,
                )
            )
        except ValueError:
            continue

    if correction and results:
        _apply_correction(results, correction, cfg)

    active = sum(1 for r in results if r.significant)

    if active <= 2:
        level = "green"
    elif active <= 4:
        level = "yellow"
    else:
        level = "red"

    return AlertReport(
        level=level,
        active_signals=active,
        total_signals=len(results),
        results=results,
        narrative=None,
    )


def find_best_lag(
    events: list[Event],
    metric: Metric,
    lag_range: range | list[int] = range(0, 72, 6),
    lookback_hours: int = 48,
    baseline_days: int = 28,
    direction: str = "two-sided",
    config: SignificanceConfig | None = None,
    baseline_strategy: str = "rolling",
) -> dict[int, CorrelationResult]:
    """Sweep lag values and return a CorrelationResult per lag.

    Example:
        results = find_best_lag(events, hrv_metric)
        best = max(results, key=lambda k: results[k].causality_score)
        print(f"Strongest signal at lag={best}h  causality={results[best].causality_score:.2f}")
    """
    cfg = config or SignificanceConfig()
    out: dict[int, CorrelationResult] = {}
    for lag in lag_range:
        try:
            out[lag] = analyze(
                events, metric, lookback_hours, baseline_days, lag,
                direction, cfg, False, 999, baseline_strategy,
            )
        except ValueError:
            continue
    return out


def monitor(
    metrics: list[Metric],
    lookback_hours: int = 48,
    baseline_days: int = 28,
    lag_hours: int = 0,
    correction: str | None = "fdr",
    direction: str = "two-sided",
    config: SignificanceConfig | None = None,
    bootstrap_ci: bool = False,
    baseline_strategy: str = "rolling",
    provider: str = "groq",
    narrate: bool = True,
) -> AlertReport:
    """Evaluate current state without requiring past events."""
    from .narrator import narrate as _narrate

    now = datetime.now()
    synthetic_event = [Event(timestamp=now, label="monitor")]

    report = evaluate(
        synthetic_event, metrics, lookback_hours, baseline_days, lag_hours,
        correction, direction, config, bootstrap_ci, 999, baseline_strategy,
    )

    if narrate and report.level != "green":
        report = _narrate(report, provider=provider)

    return report
