import pytest
from datetime import datetime, timedelta

from chrono_correlator.models import Metric


def test_from_dataframe():
    pd = pytest.importorskip("pandas")
    base = datetime(2024, 1, 1)
    df = pd.DataFrame({
        "timestamp": [base + timedelta(hours=h) for h in range(10)],
        "value": [float(h) for h in range(10)],
    })
    metric = Metric.from_dataframe(df, name="test")
    assert metric.name == "test"
    assert len(metric.timestamps) == 10
    assert metric.values[3] == 3.0


def test_from_dataframe_custom_cols():
    pd = pytest.importorskip("pandas")
    base = datetime(2024, 1, 1)
    df = pd.DataFrame({
        "ts": [base + timedelta(hours=h) for h in range(5)],
        "hrv": [55.0] * 5,
    })
    metric = Metric.from_dataframe(df, name="hrv", timestamp_col="ts", value_col="hrv")
    assert len(metric.values) == 5
