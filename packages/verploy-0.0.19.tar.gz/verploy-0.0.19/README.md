# Verploy

[![PyPI version](https://img.shields.io/pypi/v/verploy)](https://pypi.org/project/verploy/)
[![Python versions](https://img.shields.io/pypi/pyversions/verploy)](https://pypi.org/project/verploy/)
[![License](https://img.shields.io/pypi/l/verploy)](./LICENSE)
[![Coverage](https://img.shields.io/badge/coverage-100%25-brightgreen)](https://github.com/Peter-Lavigne/verploy)
<!-- Coverage is enforced by pytest --cov-fail-under=100 -->

The fastest CI/CD system for agentic engineering.

Users run `verploy`, which runs manual verification, fast-forward merges worktrees, pushes, and deploys.

## Features

- Uses a local-first workflow to significantly reduce per-prompt latency compared to using remote agents and GitHub's CI/CD
- Manual verification is programmatically defined on a per-project basis
- Worktree support enables agents to work independently
- Works with Docker to sandbox agent execution and isolate deployment credentials

## Installation

Verploy is available as [`verploy`](https://pypi.org/project/verploy/) on PyPI.

Because Verploy uses other tools you have installed, it's recommended to install it per-project instead of globally:

```bash
uv add --dev verploy
```

## Setup

Verploy expects changes to be committed and worktrees to be rebased onto main before it runs. Set up a Claude Code [Stop hook](https://docs.anthropic.com/en/docs/claude-code/hooks) to enforce this automatically. The hook should check that there are no uncommitted changes, the branch is rebased onto main (in worktrees), and run any automated quality checks (linting, type checking, tests).

Add a `.verploy/` directory to your project with any of these executable scripts:

- `manual` -- runs manual checks (e.g. human review, expensive tests)
- `deploy` -- runs after pushing (e.g. publishing to PyPI)

### Example `.verploy/` scripts

`.verploy/deploy`:
```bash
#!/bin/bash
set -euo pipefail

uv build --no-sources
uv publish
```

`.verploy/manual`:
```sh
#!/bin/sh
read -p "Review the code. Is it acceptable? (y/n) " answer
[ "$answer" = "y" ]
```

## Usage

```bash
uv run verploy
```

## License

Licensed under the Apache License 2.0. See [LICENSE](./LICENSE).
