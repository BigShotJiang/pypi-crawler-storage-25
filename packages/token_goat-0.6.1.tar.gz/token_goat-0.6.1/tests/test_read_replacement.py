"""Tests for read_replacement module and the read/section CLI commands."""
from __future__ import annotations

import json
import shutil
from pathlib import Path

import pytest

from token_goat import read_replacement
from token_goat.parser import index_project
from token_goat.read_commands import _FileTarget

# Sample fixture directories (for direct use in test methods)
FIXTURE_DIR = Path(__file__).parent / "fixtures"
PY_SAMPLE = FIXTURE_DIR / "py_sample"

# Re-export shared fixtures from conftest with tuple variant aliases
# (conftest provides ts_project_tuple, py_project_tuple, md_project_tuple)
@pytest.fixture
def ts_project(ts_project_tuple):
    """Alias ts_project_tuple for backward compatibility in this test file."""
    return ts_project_tuple


@pytest.fixture
def py_project(py_project_tuple):
    """Alias py_project_tuple for backward compatibility in this test file."""
    return py_project_tuple


@pytest.fixture
def md_project(md_project_tuple):
    """Alias md_project_tuple for backward compatibility in this test file."""
    return md_project_tuple


def _make_ambiguous_project(
    tmp_path,
    make_project,
    rel_name: str,
    content_a: str,
    content_b: str,
):
    proj_root = tmp_path / "ambiguous"
    (proj_root / "a").mkdir(parents=True)
    (proj_root / "b").mkdir(parents=True)
    (proj_root / "a" / rel_name).write_text(content_a, encoding="utf-8")
    (proj_root / "b" / rel_name).write_text(content_b, encoding="utf-8")
    proj = make_project(proj_root)
    index_project(proj, full=True)
    return proj_root, proj


def _make_dependency_project(tmp_path, make_project):
    proj_root = tmp_path / "deps"
    proj_root.mkdir()
    (proj_root / ".git").mkdir()
    (proj_root / "a.ts").write_text(
        'import { b } from "./b";\nexport function a() { return b(); }\n',
        encoding="utf-8",
    )
    (proj_root / "b.ts").write_text("export function b() { return 1; }\n", encoding="utf-8")
    proj = make_project(proj_root)
    index_project(proj, full=True)
    return proj_root, proj


# ---------------------------------------------------------------------------
# resolve_file_rel tests
# ---------------------------------------------------------------------------

def test_resolve_exact_match(ts_project):
    _, proj = ts_project
    rel = read_replacement.resolve_file_rel(proj, "index.ts")
    assert rel == "index.ts"


def test_resolve_bare_filename(ts_project):
    _, proj = ts_project
    # bare filename should match
    rel = read_replacement.resolve_file_rel(proj, "index.ts")
    assert rel is not None
    assert rel.endswith("index.ts")


def test_resolve_absolute_path(ts_project):
    proj_root, proj = ts_project
    abs_path = str(proj_root / "index.ts")
    rel = read_replacement.resolve_file_rel(proj, abs_path)
    assert rel == "index.ts"


def test_resolve_garbage_returns_none(ts_project):
    _, proj = ts_project
    rel = read_replacement.resolve_file_rel(proj, "totally_nonexistent_xyz_abc.ts")
    assert rel is None


def test_resolve_ambiguous_bare_filename_raises(tmp_path, tmp_data_dir, make_project):
    from token_goat.read_replacement import AmbiguousFileMatch

    _proj_root, proj = _make_ambiguous_project(
        tmp_path,
        make_project,
        "index.ts",
        "export const a = 1;\n",
        "export const b = 2;\n",
    )

    with pytest.raises(AmbiguousFileMatch) as excinfo:
        read_replacement.resolve_file_rel(proj, "index.ts")
    assert excinfo.value.code == "ambiguous_file"
    assert excinfo.value.file_part == "index.ts"
    assert excinfo.value.candidates == ("a/index.ts", "b/index.ts")


def test_resolve_bare_filename_with_literal_sql_like_chars(tmp_path, tmp_data_dir, make_project):
    proj_root = tmp_path / "wildcards"
    (proj_root / "src").mkdir(parents=True)
    (proj_root / "src" / "a%file.ts").write_text("export const a = 1;\n", encoding="utf-8")
    (proj_root / "src" / "afile.ts").write_text("export const b = 2;\n", encoding="utf-8")
    proj = make_project(proj_root)
    index_project(proj, full=True)

    rel = read_replacement.resolve_file_rel(proj, "a%file.ts")
    assert rel == "src/a%file.ts"


@pytest.mark.parametrize(
    "path_value",
    [
        "/etc/passwd",
        r"C:\Windows\win.ini",
        r"\\server\share\file.txt",
        "../escape.py",
        r"..\escape.py",
    ],
)
def test_safe_rel_path_rejects_absolute_and_traversal(path_value):
    # _is_safe_rel_path now lives in token_goat.paths and is re-exported by
    # read_replacement; embeddings no longer owns its own copy.
    assert read_replacement._is_safe_rel_path(path_value) is False


# ---------------------------------------------------------------------------
# read_symbol tests
# ---------------------------------------------------------------------------

def test_read_symbol_greet_text(ts_project):
    _, proj = ts_project
    result = read_replacement.read_symbol(proj, "index.ts", "greet")
    assert result is not None
    assert "function greet" in result["text"]
    assert "return" in result["text"]


def test_read_symbol_greet_lines(ts_project):
    _, proj = ts_project
    result = read_replacement.read_symbol(proj, "index.ts", "greet")
    assert result is not None
    # greet is on lines 4-6 per DB
    assert result["start_line"] == 4
    assert result["end_line"] == 6


def test_read_symbol_nonexistent_returns_none(ts_project):
    _, proj = ts_project
    result = read_replacement.read_symbol(proj, "index.ts", "__totally_nonexistent__")
    assert result is None


def test_read_symbol_context_lines(ts_project):
    _, proj = ts_project
    result_no_ctx = read_replacement.read_symbol(proj, "index.ts", "greet")
    result_with_ctx = read_replacement.read_symbol(proj, "index.ts", "greet", context_lines=2)
    assert result_with_ctx is not None
    # With context, start_line should be earlier (or equal if already at top)
    assert result_with_ctx["start_line"] <= result_no_ctx["start_line"]
    assert result_with_ctx["end_line"] >= result_no_ctx["end_line"]
    # The snippet must be longer (or equal if clipped at file boundaries)
    assert len(result_with_ctx["text"]) >= len(result_no_ctx["text"])


def test_read_symbol_userservice_class(ts_project):
    _, proj = ts_project
    result = read_replacement.read_symbol(proj, "index.ts", "UserService")
    assert result is not None
    assert result["kind"] == "class"
    assert "UserService" in result["text"]


def test_read_symbol_bytes_saved_positive(ts_project):
    _, proj = ts_project
    result = read_replacement.read_symbol(proj, "index.ts", "greet")
    assert result is not None
    assert result["bytes_saved"] > 0
    assert result["bytes_total"] > result["bytes_extracted"]


def test_read_symbol_result_fields(ts_project):
    _, proj = ts_project
    result = read_replacement.read_symbol(proj, "index.ts", "greet")
    assert result is not None
    for key in ("file", "symbol", "kind", "start_line", "end_line", "text",
                "signature", "bytes_total", "bytes_extracted", "bytes_saved"):
        assert key in result, f"Missing key: {key}"


# ---------------------------------------------------------------------------
# read_section tests
# ---------------------------------------------------------------------------

def test_read_section_methodology(md_project):
    _, proj = md_project
    result = read_replacement.read_section(proj, "article.md", "Methodology")
    assert result is not None
    assert "Methodology" in result["text"]


def test_read_section_case_insensitive(md_project):
    _, proj = md_project
    result = read_replacement.read_section(proj, "article.md", "methodology")
    assert result is not None
    assert "Methodology" in result["text"]


def test_read_section_nonexistent_returns_none(md_project):
    _, proj = md_project
    result = read_replacement.read_section(proj, "article.md", "Nonexistent Section XYZ")
    assert result is None


def test_read_section_bytes_saved_positive(md_project):
    _, proj = md_project
    result = read_replacement.read_section(proj, "article.md", "Methodology")
    assert result is not None
    assert result["bytes_saved"] > 0


def test_read_section_result_fields(md_project):
    _, proj = md_project
    result = read_replacement.read_section(proj, "article.md", "Methodology")
    assert result is not None
    for key in ("file", "heading", "level", "start_line", "end_line", "text",
                "bytes_total", "bytes_extracted", "bytes_saved"):
        assert key in result, f"Missing key: {key}"


# ---------------------------------------------------------------------------
# Qualified Class.method symbol lookup (read_symbol "file::Class.method")
# ---------------------------------------------------------------------------


def _make_method_collision_project(tmp_path, make_project):
    """Project with a free function and a class method that share a name."""
    proj_root = tmp_path / "method_collision"
    proj_root.mkdir()
    (proj_root / ".git").mkdir()
    (proj_root / "app.py").write_text(
        # NOTE: keep both `hello` symbols on distinct line ranges so the
        # qualifier-by-line-containment filter has something to discriminate.
        "def hello() -> str:\n"
        "    return 'free'\n"
        "\n"
        "\n"
        "class Greeter:\n"
        "    def hello(self) -> str:\n"
        "        return 'method'\n",
        encoding="utf-8",
    )
    proj = make_project(proj_root)
    index_project(proj, full=True)
    return proj_root, proj


def test_read_symbol_qualified_picks_method(tmp_path, tmp_data_dir, make_project):
    """``Class.method`` lookup returns the method, not the free function."""
    _, proj = _make_method_collision_project(tmp_path, make_project)
    result = read_replacement.read_symbol(proj, "app.py", "Greeter.hello")
    assert result is not None
    assert result["kind"] == "method"
    # The method body is on lines 6-7 of the fixture; the free function is at 1-2.
    assert result["start_line"] >= 6
    assert "method" in result["text"]


def test_read_symbol_unqualified_falls_back_to_priority(
    tmp_path, tmp_data_dir, make_project,
):
    """Bare ``hello`` still picks by kind priority (function over method)."""
    _, proj = _make_method_collision_project(tmp_path, make_project)
    result = read_replacement.read_symbol(proj, "app.py", "hello")
    assert result is not None
    # Free function ranks higher than method in _KIND_PRIORITY.
    assert result["kind"] == "function"
    assert "free" in result["text"]


def test_read_symbol_qualified_wrong_class_falls_back(
    tmp_path, tmp_data_dir, make_project,
):
    """When the qualifier does not match any class, fall back to unqualified."""
    _, proj = _make_method_collision_project(tmp_path, make_project)
    # ``Nope`` is not a class in the file — fall back to bare ``hello`` lookup.
    result = read_replacement.read_symbol(proj, "app.py", "Nope.hello")
    assert result is not None
    # Falls back to the kind-priority winner from unqualified lookup.
    assert result["kind"] == "function"


def test_split_qualified_symbol_handles_bare_name():
    """``_split_qualified_symbol`` returns (None, name) for unqualified input."""
    qualifier, leaf = read_replacement._split_qualified_symbol("hello")
    assert qualifier is None
    assert leaf == "hello"


def test_split_qualified_symbol_handles_nested_qualifier():
    """``A.B.method`` collapses to immediate parent ``B`` + leaf ``method``."""
    qualifier, leaf = read_replacement._split_qualified_symbol("Outer.Inner.method")
    assert qualifier == "Inner"
    assert leaf == "method"


# ---------------------------------------------------------------------------
# Section ordinal disambiguation (Heading#N)
# ---------------------------------------------------------------------------


def _make_duplicate_section_project(tmp_path, make_project):
    """Doc with two ``## Example`` headings to exercise ordinal selection."""
    proj_root = tmp_path / "dup_sections"
    proj_root.mkdir()
    (proj_root / ".git").mkdir()
    (proj_root / "doc.md").write_text(
        "# Top\n"
        "\n"
        "## Example\n"
        "\n"
        "first example body\n"
        "\n"
        "## Other\n"
        "\n"
        "filler\n"
        "\n"
        "## Example\n"
        "\n"
        "second example body\n",
        encoding="utf-8",
    )
    proj = make_project(proj_root)
    index_project(proj, full=True)
    return proj_root, proj


def test_read_section_duplicate_returns_first_with_warning(
    tmp_path, tmp_data_dir, make_project, caplog,
):
    """Unqualified duplicate heading lookup picks the first by line order."""
    import logging as _logging
    _, proj = _make_duplicate_section_project(tmp_path, make_project)
    with caplog.at_level(_logging.WARNING, logger="token_goat.read_replacement"):
        result = read_replacement.read_section(proj, "doc.md", "Example")
    assert result is not None
    assert "first example body" in result["text"]
    # A warning must explain how to pick the second occurrence.
    assert any("share heading" in r.getMessage() for r in caplog.records)


def test_read_section_ordinal_picks_nth(tmp_path, tmp_data_dir, make_project):
    """``Heading#2`` returns the second occurrence."""
    _, proj = _make_duplicate_section_project(tmp_path, make_project)
    result = read_replacement.read_section(proj, "doc.md", "Example#2")
    assert result is not None
    assert "second example body" in result["text"]


def test_read_section_ordinal_out_of_range_returns_none(
    tmp_path, tmp_data_dir, make_project,
):
    """``Heading#99`` for a doc with two matches returns None (not the first)."""
    _, proj = _make_duplicate_section_project(tmp_path, make_project)
    result = read_replacement.read_section(proj, "doc.md", "Example#99")
    assert result is None


def test_parse_section_ordinal_rejects_zero_and_negatives():
    """Ordinal ``0`` and negatives are treated as no-ordinal (heading kept whole)."""
    assert read_replacement._parse_section_ordinal("Example#0") == ("Example#0", None)
    assert read_replacement._parse_section_ordinal("Example#-1") == ("Example#-1", None)


def test_parse_section_ordinal_rejects_nondigit_suffix():
    """``Foo#bar`` is a real heading, not an ordinal — leave it alone."""
    assert read_replacement._parse_section_ordinal("Foo#bar") == ("Foo#bar", None)


def test_parse_section_ordinal_empty_base_is_left_intact():
    """``#42`` has no base name and must not be split (no implicit heading)."""
    assert read_replacement._parse_section_ordinal("#42") == ("#42", None)


# ---------------------------------------------------------------------------
# CLI tests via typer.testing.CliRunner
# ---------------------------------------------------------------------------

@pytest.fixture
def indexed_ts_cli(ts_project, monkeypatch):
    """Return (proj_root, proj) with cwd set to proj_root."""
    proj_root, proj = ts_project
    monkeypatch.chdir(proj_root)
    return proj_root, proj


@pytest.fixture
def indexed_md_cli(md_project, monkeypatch):
    """Return (proj_root, proj) with cwd set to proj_root."""
    proj_root, proj = md_project
    monkeypatch.chdir(proj_root)
    return proj_root, proj


def test_cli_read_greet_emits_body(indexed_ts_cli):
    from typer.testing import CliRunner

    from token_goat.cli import app

    runner = CliRunner()
    result = runner.invoke(app, ["read", "index.ts::greet"])
    assert result.exit_code == 0
    assert "greet" in result.output
    assert "return" in result.output


def test_cli_read_nonexistent_symbol_exit_zero(indexed_ts_cli):
    from typer.testing import CliRunner

    from token_goat.cli import app

    runner = CliRunner()
    result = runner.invoke(app, ["read", "index.ts::__totally_nonexistent__"])
    assert result.exit_code == 0


def test_cli_read_missing_separator_exit_2(indexed_ts_cli):
    from typer.testing import CliRunner

    from token_goat.cli import app

    runner = CliRunner()
    result = runner.invoke(app, ["read", "index.ts"])
    assert result.exit_code == 2


def test_cli_section_methodology(indexed_md_cli):
    from typer.testing import CliRunner

    from token_goat.cli import app

    runner = CliRunner()
    result = runner.invoke(app, ["section", "article.md::Methodology"])
    assert result.exit_code == 0
    assert "Methodology" in result.output


def test_cli_read_json_output(indexed_ts_cli):
    from typer.testing import CliRunner

    from token_goat.cli import app

    runner = CliRunner()
    result = runner.invoke(app, ["read", "--json", "index.ts::greet"])
    assert result.exit_code == 0
    data = json.loads(result.output.strip())
    assert data["symbol"] == "greet"
    assert data["kind"] == "function"
    assert "text" in data
    assert "bytes_saved" in data
    assert "start_line" in data
    assert "end_line" in data
    assert data["bytes_saved"] > 0


def test_cli_read_with_session_id(indexed_ts_cli, tmp_data_dir):
    from typer.testing import CliRunner

    from token_goat import session as session_mod
    from token_goat.cli import app

    proj_root, _ = indexed_ts_cli
    session_id = "test-phase11-session"
    runner = CliRunner()
    result = runner.invoke(app, ["read", "--session-id", session_id, f"{proj_root / 'index.ts'}::greet"])
    assert result.exit_code == 0

    # Verify the session cache has greet recorded under the canonical relative path.
    entry = session_mod.get_file_entry(session_id, "index.ts")
    assert entry is not None
    assert entry.rel_or_abs == "index.ts"
    assert "greet" in entry.symbols_read


def test_cli_section_json_output(indexed_md_cli):
    from typer.testing import CliRunner

    from token_goat.cli import app

    runner = CliRunner()
    result = runner.invoke(app, ["section", "--json", "article.md::Methodology"])
    assert result.exit_code == 0
    data = json.loads(result.output.strip())
    assert data["heading"] == "Methodology"
    assert "text" in data
    assert "bytes_saved" in data
    assert data["bytes_saved"] > 0


def test_cli_read_reports_ambiguous_file_match(tmp_path, tmp_data_dir, make_project, monkeypatch):
    from typer.testing import CliRunner

    from token_goat.cli import app

    proj_root, _ = _make_ambiguous_project(
        tmp_path,
        make_project,
        "index.ts",
        "export const a = 1;\n",
        "export const b = 2;\n",
    )
    monkeypatch.chdir(proj_root)

    runner = CliRunner()
    result = runner.invoke(app, ["read", "index.ts::greet"])
    assert result.exit_code == 0
    assert "Ambiguous file match: index.ts" in result.output
    assert "a/index.ts" in result.output
    assert "b/index.ts" in result.output


def test_cli_read_reports_structured_json_error_for_ambiguous_match(
    tmp_path, tmp_data_dir, make_project, monkeypatch
):
    from typer.testing import CliRunner

    from token_goat.cli import app

    proj_root, _ = _make_ambiguous_project(
        tmp_path,
        make_project,
        "index.ts",
        "export const a = 1;\n",
        "export const b = 2;\n",
    )
    monkeypatch.chdir(proj_root)

    runner = CliRunner()
    result = runner.invoke(app, ["read", "index.ts::greet", "--json"])
    assert result.exit_code == 0
    payload = json.loads(result.output)
    assert payload["ok"] is False
    assert payload["error"]["code"] == "ambiguous_file"
    assert payload["error"]["file_part"] == "index.ts"
    assert [candidate.split(":", 1)[-1] for candidate in payload["error"]["candidates"]] == [
        "a/index.ts",
        "b/index.ts",
    ]


def test_cli_read_reports_structured_json_error_for_missing_symbol(
    ts_project, monkeypatch
):
    from typer.testing import CliRunner

    from token_goat.cli import app

    proj_root, _ = ts_project
    monkeypatch.chdir(proj_root)

    runner = CliRunner()
    result = runner.invoke(app, ["read", "index.ts::does_not_exist", "--json"])
    assert result.exit_code == 0
    payload = json.loads(result.output)
    assert payload["ok"] is False
    assert payload["error"]["code"] == "symbol_not_found"
    assert payload["error"]["item"] == "does_not_exist"
    assert payload["error"]["rel_path"] == "index.ts"


def test_cli_read_reports_structured_json_error_for_project_not_indexed(
    tmp_path, tmp_data_dir, make_project, monkeypatch
):
    from typer.testing import CliRunner

    from token_goat.cli import app

    proj_root = tmp_path / "empty_proj"
    proj_root.mkdir()
    (proj_root / ".git").mkdir()
    proj = make_project(proj_root)
    monkeypatch.chdir(proj_root)

    runner = CliRunner()
    result = runner.invoke(app, ["read", "index.ts::does_not_exist", "--json"])
    assert result.exit_code == 0
    payload = json.loads(result.output)
    assert payload["ok"] is False
    assert payload["error"]["code"] == "project_not_indexed"
    assert payload["error"]["project_hash"] == proj.hash
    assert "not yet indexed" in payload["error"]["message"]


def test_cli_deps_reports_dependency_graph(tmp_path, make_project, monkeypatch):
    from contextlib import contextmanager

    from typer.testing import CliRunner

    from token_goat import read_commands
    from token_goat.cli import app

    proj_root = tmp_path / "deps"
    proj_root.mkdir()
    (proj_root / ".git").mkdir()
    fake_proj = make_project(proj_root)

    @contextmanager
    def _fake_conn():
        yield object()

    monkeypatch.setattr(read_commands.db, "open_project", lambda _hash: _fake_conn())
    monkeypatch.setattr(
        read_commands,
        "_resolve_file_target",
        lambda _file: _FileTarget(fake_proj, "a.ts", fake_proj),
    )
    monkeypatch.setattr(
        read_commands,
        "_collect_dependency_graph",
        lambda _conn, _rel: ({"b.ts": {"greet"}}, {"c.ts": {"greet", "router"}}, []),
    )

    runner = CliRunner()
    result = runner.invoke(app, ["deps", "a.ts"])
    assert result.exit_code == 0
    assert "Dependency graph for a.ts" in result.output
    assert "Dependencies" in result.output
    assert "b.ts" in result.output
    assert "greet" in result.output
    assert "Dependents" in result.output
    assert "c.ts" in result.output


def test_cli_deps_json_output(tmp_path, make_project, monkeypatch):
    """deps --json emits a valid JSON object with 'file', 'dependencies', 'dependents'."""
    import json as _json
    from contextlib import contextmanager

    from typer.testing import CliRunner

    from token_goat import read_commands
    from token_goat.cli import app

    proj_root = tmp_path / "deps_json"
    proj_root.mkdir()
    (proj_root / ".git").mkdir()
    fake_proj = make_project(proj_root)

    @contextmanager
    def _fake_conn():
        yield object()

    monkeypatch.setattr(read_commands.db, "open_project", lambda _hash: _fake_conn())
    monkeypatch.setattr(
        read_commands,
        "_resolve_file_target",
        lambda _file: _FileTarget(fake_proj, "a.ts", fake_proj),
    )
    monkeypatch.setattr(
        read_commands,
        "_collect_dependency_graph",
        lambda _conn, _rel: ({"b.ts": {"greet"}}, {"c.ts": {"router"}}, ["UnknownThing"]),
    )

    runner = CliRunner()
    result = runner.invoke(app, ["deps", "a.ts", "--json"])
    assert result.exit_code == 0
    data = _json.loads(result.output.strip())
    assert data["file"] == "a.ts"
    assert "b.ts" in data["dependencies"]
    assert "greet" in data["dependencies"]["b.ts"]
    assert "c.ts" in data["dependents"]
    assert "router" in data["dependents"]["c.ts"]
    assert data["unresolved_ref_count"] == 1
    assert "UnknownThing" in data["unresolved_refs"]
    assert data["dependency_edge_count"] == 1
    assert data["dependent_edge_count"] == 1


def test_cli_deps_transitive_json_output(tmp_path, make_project, monkeypatch):
    """deps --depth 2 --json emits all_dependencies with depth/via/symbols."""
    import json as _json
    from contextlib import contextmanager

    from typer.testing import CliRunner

    from token_goat import read_commands
    from token_goat.cli import app

    proj_root = tmp_path / "deps_transitive"
    proj_root.mkdir()
    (proj_root / ".git").mkdir()
    fake_proj = make_project(proj_root)

    @contextmanager
    def _fake_conn():
        yield object()

    # Depth-1: a.ts → b.ts (greet); depth-2: b.ts → c.ts (helper)
    def _fake_collect_graph(_conn, _rel):
        return ({"b.ts": {"greet"}}, {}, [])

    def _fake_collect_transitive(_conn, _start, *, max_depth):
        return {
            "b.ts": {"depth": 1, "via": "a.ts", "symbols": {"greet"}},
            "c.ts": {"depth": 2, "via": "b.ts", "symbols": {"helper"}},
        }

    monkeypatch.setattr(read_commands.db, "open_project", lambda _hash: _fake_conn())
    monkeypatch.setattr(read_commands, "_resolve_file_target", lambda _f: _FileTarget(fake_proj, "a.ts", fake_proj))
    monkeypatch.setattr(read_commands, "_collect_dependency_graph", _fake_collect_graph)
    monkeypatch.setattr(read_commands, "_collect_transitive_outgoing", _fake_collect_transitive)

    runner = CliRunner()
    result = runner.invoke(app, ["deps", "a.ts", "--depth", "2", "--json"])
    assert result.exit_code == 0
    data = _json.loads(result.output.strip())
    assert data["depth"] == 2
    assert "all_dependencies" in data
    assert data["all_dependencies"]["b.ts"]["depth"] == 1
    assert data["all_dependencies"]["c.ts"]["depth"] == 2
    assert data["all_dependencies"]["c.ts"]["via"] == "b.ts"
    assert "helper" in data["all_dependencies"]["c.ts"]["symbols"]


def test_cli_read_reports_index_unavailable(tmp_path, monkeypatch):
    from typer.testing import CliRunner

    from token_goat import read_replacement
    from token_goat.cli import app
    from token_goat.read_replacement import ProjectIndexUnavailable

    proj_root = tmp_path / "read_unavailable"
    proj_root.mkdir()
    (proj_root / ".git").mkdir()
    monkeypatch.chdir(proj_root)

    def _raise(_file_part: str) -> None:
        raise ProjectIndexUnavailable(
            "Project index database is unavailable. Run `token-goat index --full` again."
        )

    monkeypatch.setattr(read_replacement, "find_in_all_projects", _raise)

    runner = CliRunner()
    result = runner.invoke(app, ["read", "missing.ts::sym"])
    assert result.exit_code == 0
    assert "project index database is unavailable" in result.output.lower()


def test_cli_deps_reports_index_unavailable(tmp_path, monkeypatch):
    from typer.testing import CliRunner

    from token_goat import read_replacement
    from token_goat.cli import app
    from token_goat.read_replacement import ProjectIndexUnavailable

    proj_root = tmp_path / "deps_unavailable"
    proj_root.mkdir()
    (proj_root / ".git").mkdir()
    monkeypatch.chdir(proj_root)

    def _raise(_file_part: str) -> None:
        raise ProjectIndexUnavailable(
            "Project index database is unavailable. Run `token-goat index --full` again."
        )

    monkeypatch.setattr(read_replacement, "find_in_all_projects", _raise)

    runner = CliRunner()
    result = runner.invoke(app, ["deps", "missing.ts"])
    assert result.exit_code == 0
    assert "project index database is unavailable" in result.output.lower()


def test_cli_section_reports_ambiguous_file_match(tmp_path, tmp_data_dir, make_project, monkeypatch):
    from typer.testing import CliRunner

    from token_goat.cli import app

    proj_root, _ = _make_ambiguous_project(
        tmp_path,
        make_project,
        "article.md",
        "# One\n\n## Methodology\n\nA.\n",
        "# Two\n\n## Methodology\n\nB.\n",
    )
    monkeypatch.chdir(proj_root)

    runner = CliRunner()
    result = runner.invoke(app, ["section", "article.md::Methodology"])
    assert result.exit_code == 0
    assert "Ambiguous file match: article.md" in result.output
    assert "a/article.md" in result.output
    assert "b/article.md" in result.output


def test_cli_section_reports_structured_json_error_for_missing_heading(indexed_md_cli):
    from typer.testing import CliRunner

    from token_goat.cli import app

    runner = CliRunner()
    result = runner.invoke(app, ["section", "article.md::NoSuchHeading", "--json"])
    assert result.exit_code == 0
    payload = json.loads(result.output)
    assert payload["ok"] is False
    assert payload["error"]["code"] == "section_not_found"
    assert payload["error"]["item"] == "NoSuchHeading"
    assert payload["error"]["item_kind"] == "section"
    assert payload["error"]["rel_path"] == "article.md"


# ---------------------------------------------------------------------------
# read_commands._not_indexed_hint — unindexed project produces a hint
# ---------------------------------------------------------------------------

class TestNotIndexedHint:
    """_not_indexed_hint returns a prompt when the project has 0 indexed files."""

    def test_returns_hint_for_empty_project(self, tmp_data_dir, make_project, tmp_path):
        """When file_count == 0 (never indexed), _not_indexed_hint returns a string."""
        from token_goat.read_commands import _not_indexed_hint

        proj_root = tmp_path / "empty_proj"
        proj_root.mkdir()
        proj = make_project(proj_root)
        # Project DB is created but never indexed — file count is 0.
        hint = _not_indexed_hint(proj.hash)
        assert hint is not None
        assert "not yet indexed" in hint

    def test_returns_none_for_indexed_project(self, py_project):
        """When files are indexed, _not_indexed_hint returns None."""
        from token_goat.read_commands import _not_indexed_hint

        _proj_root, proj = py_project
        hint = _not_indexed_hint(proj.hash)
        assert hint is None

    @pytest.mark.skip(
        reason="CI-only flake on Python 3.13: monkeypatch on db.project_has_files "
        "doesn't propagate to read_commands.db.project_has_files lookup. The "
        "underlying except-OSError branch is exercised by integration tests."
    )
    def test_returns_diagnostic_on_db_error(self, tmp_data_dir, monkeypatch):
        """If the indexed-file probe raises, _not_indexed_hint should surface that fact."""
        from token_goat import db
        from token_goat.read_commands import _not_indexed_hint

        def _boom(_project_hash):
            raise OSError("db gone")

        monkeypatch.setattr(db, "project_has_files", _boom)
        hint = _not_indexed_hint("deadbeef1234567890ab")
        assert hint is not None
        assert "unable to check whether this project is indexed" in hint


def test_find_in_all_projects_raises_when_global_db_unavailable(monkeypatch):
    from token_goat import db
    from token_goat.read_replacement import ProjectIndexUnavailable, find_in_all_projects

    def _boom():
        raise OSError("disk I/O error")

    monkeypatch.setattr(db, "open_global_readonly", _boom)

    with pytest.raises(ProjectIndexUnavailable):
        find_in_all_projects("index.ts")


# ---------------------------------------------------------------------------
# read_commands — "no project detected" error path (lines 75-83)
# ---------------------------------------------------------------------------

class TestReadCommandNoProject:
    """When no project is detected for the cwd, read/section emits an error."""

    def test_read_no_project_exits_cleanly(self, tmp_data_dir, monkeypatch, tmp_path):
        """token-goat read <file>::<sym> when cwd has no project must exit 0 with error text."""
        from typer.testing import CliRunner

        from token_goat import project as project_mod
        from token_goat.cli import app

        monkeypatch.setattr(project_mod, "find_project", lambda _cwd: None)
        monkeypatch.chdir(tmp_path)

        runner = CliRunner()
        result = runner.invoke(app, ["read", "nosuchfile.py::nosuchsym"])
        # Must exit cleanly (not crash) even with no project
        assert result.exit_code == 0

    def test_section_no_project_exits_cleanly(self, tmp_data_dir, monkeypatch, tmp_path):
        """token-goat section <file>::<heading> with no project must exit 0 with error text."""
        from typer.testing import CliRunner

        from token_goat import project as project_mod
        from token_goat.cli import app

        monkeypatch.setattr(project_mod, "find_project", lambda _cwd: None)
        monkeypatch.chdir(tmp_path)

        runner = CliRunner()
        result = runner.invoke(app, ["section", "nosuchfile.md::NoHeading"])
        assert result.exit_code == 0


# ---------------------------------------------------------------------------
# read_commands — cross-project fallback (_resolve_file_target lines 46-48)
# ---------------------------------------------------------------------------

class TestResolveFileCrossProject:
    """When the file is not in the current project, _resolve_file_target falls
    back to find_in_all_projects and resolves from another indexed project."""

    def test_read_resolves_cross_project_symbol(
        self, tmp_data_dir, make_project, tmp_path, monkeypatch
    ):
        """A symbol in a *different* indexed project is found via cross-project lookup."""
        from typer.testing import CliRunner

        from token_goat import project as project_mod
        from token_goat.cli import app

        # Build and index a "foreign" project with a known Python file
        foreign_root = tmp_path / "foreign"
        shutil.copytree(PY_SAMPLE, foreign_root)
        foreign_proj = make_project(foreign_root)
        index_project(foreign_proj, full=True)

        # CWD points to an *unrelated* directory with no project marker
        cwd = tmp_path / "unrelated"
        cwd.mkdir()
        monkeypatch.setattr(project_mod, "find_project", lambda _cwd: None)
        monkeypatch.chdir(cwd)

        runner = CliRunner()
        # app.py is in py_sample; MyClass is a known symbol there
        result = runner.invoke(app, ["read", "app.py::MyClass"])
        # Should resolve via cross-project lookup — either finds the symbol
        # or exits cleanly (no exception / non-zero exit).
        assert result.exit_code == 0


# ---------------------------------------------------------------------------
# read_commands.deps — error path coverage
# ---------------------------------------------------------------------------

class TestDepsCommandErrors:
    """deps() should fail cleanly when the target file is missing."""

    def test_deps_missing_file_exits_without_error(
        self, tmp_path, tmp_data_dir, make_project, monkeypatch
    ):
        from typer.testing import CliRunner

        from token_goat.cli import app

        proj_root = tmp_path / "deps_missing"
        proj_root.mkdir()
        (proj_root / ".git").mkdir()
        (proj_root / "a.ts").write_text("export function a() { return 1; }\n", encoding="utf-8")
        proj = make_project(proj_root)
        index_project(proj, full=True)
        monkeypatch.chdir(proj_root)

        runner = CliRunner()
        result = runner.invoke(app, ["deps", "missing.ts"])
        assert result.exit_code == 0
        assert "File not found in any indexed project: missing.ts" in result.output


# ---------------------------------------------------------------------------
# File-resolution cache (item 8) and specificity ranking (item 14)
# ---------------------------------------------------------------------------

class TestMatchSpecificity:
    """Unit tests for _match_specificity and _pick_best_match."""

    def test_bare_filename_scores_above_partial_path(self):
        from token_goat.read_replacement import _match_specificity
        # "parser.py" matching "src/token_goat/parser.py" vs "vendor/parser.py"
        score_deep = _match_specificity("parser.py", "src/token_goat/parser.py")
        score_shallow = _match_specificity("parser.py", "vendor/parser.py")
        # Both have suffix_len=1 (bare filename), but shallow has fewer components
        assert score_deep[0] == score_shallow[0] == 1
        assert score_shallow > score_deep  # neg_path_depth closer to 0

    def test_longer_suffix_wins(self):
        from token_goat.read_replacement import _match_specificity
        score_short = _match_specificity("parser.py", "src/token_goat/parser.py")
        score_long = _match_specificity("token_goat/parser.py", "src/token_goat/parser.py")
        assert score_long > score_short

    def test_pick_best_match_resolves_unambiguous(self):
        from token_goat.read_replacement import _pick_best_match
        candidates = ["src/token_goat/parser.py", "vendor/lib/parser.py"]
        # "token_goat/parser.py" is a longer suffix of the first but not the second
        best = _pick_best_match("token_goat/parser.py", candidates)
        assert best == "src/token_goat/parser.py"

    def test_pick_best_match_returns_none_on_tie(self):
        from token_goat.read_replacement import _pick_best_match
        # Two equally shallow bare-filename matches
        candidates = ["a/foo.py", "b/foo.py"]
        assert _pick_best_match("foo.py", candidates) is None

    def test_pick_best_match_single_candidate(self):
        from token_goat.read_replacement import _pick_best_match
        assert _pick_best_match("foo.py", ["src/foo.py"]) == "src/foo.py"

    def test_pick_best_match_empty(self):
        from token_goat.read_replacement import _pick_best_match
        assert _pick_best_match("foo.py", []) is None


class TestResolveFileCache:
    """Tests for _resolve_cache_lookup/put and invalidate_file_cache."""

    def setup_method(self):
        from token_goat import read_replacement as rr
        rr._RESOLVE_CACHE.clear()

    def test_cache_miss_returns_sentinel(self):
        from token_goat.read_replacement import _CACHE_MISS, _resolve_cache_lookup
        result = _resolve_cache_lookup("proj-abc", "src/foo.py")
        assert result is _CACHE_MISS

    def test_cache_put_and_hit(self):
        from token_goat.read_replacement import (
            _CACHE_MISS,
            _resolve_cache_lookup,
            _resolve_cache_put,
        )
        _resolve_cache_put("proj-abc", "foo.py", "src/foo.py")
        result = _resolve_cache_lookup("proj-abc", "foo.py")
        assert result is not _CACHE_MISS
        assert result == "src/foo.py"

    def test_cache_stores_none_result(self):
        from token_goat.read_replacement import (
            _CACHE_MISS,
            _resolve_cache_lookup,
            _resolve_cache_put,
        )
        _resolve_cache_put("proj-abc", "missing.py", None)
        result = _resolve_cache_lookup("proj-abc", "missing.py")
        assert result is not _CACHE_MISS
        assert result is None

    def test_invalidate_clears_only_that_project(self):
        from token_goat.read_replacement import (
            _CACHE_MISS,
            _resolve_cache_lookup,
            _resolve_cache_put,
            invalidate_file_cache,
        )
        _resolve_cache_put("proj-A", "foo.py", "src/foo.py")
        _resolve_cache_put("proj-B", "foo.py", "lib/foo.py")
        count = invalidate_file_cache("proj-A")
        assert count == 1
        assert _resolve_cache_lookup("proj-A", "foo.py") is _CACHE_MISS
        assert _resolve_cache_lookup("proj-B", "foo.py") is not _CACHE_MISS

    def test_cache_evicts_oldest_when_full(self):
        from token_goat import read_replacement as rr
        rr._RESOLVE_CACHE.clear()
        # Fill beyond MAX to trigger eviction
        for i in range(rr._RESOLVE_CACHE_MAX):
            rr._resolve_cache_put("proj", f"file{i}.py", f"src/file{i}.py")
        assert len(rr._RESOLVE_CACHE) == rr._RESOLVE_CACHE_MAX
        # Adding one more triggers eviction of _RESOLVE_CACHE_EVICT entries
        rr._resolve_cache_put("proj", "new.py", "src/new.py")
        assert len(rr._RESOLVE_CACHE) == rr._RESOLVE_CACHE_MAX - rr._RESOLVE_CACHE_EVICT + 1
        # Oldest entries were evicted
        assert rr._resolve_cache_lookup("proj", "file0.py") is rr._CACHE_MISS
        # Newest entry is present
        assert rr._resolve_cache_lookup("proj", "new.py") == "src/new.py"

    def test_resolve_file_rel_uses_cache(self, tmp_data_dir, make_project, tmp_path):
        """resolve_file_rel result is cached; second call skips DB entirely."""
        import shutil

        from token_goat import read_replacement as rr
        from token_goat.parser import index_project

        rr._RESOLVE_CACHE.clear()
        proj_root = tmp_path / "cache_test_proj"
        shutil.copytree(PY_SAMPLE, proj_root)
        proj = make_project(proj_root)
        index_project(proj, full=True)

        # First call populates cache
        rel1 = rr.resolve_file_rel(proj, "app.py")
        assert rel1 == "app.py"
        assert (proj.hash, "app.py") in rr._RESOLVE_CACHE

        # Corrupt DB path to ensure second call uses cache (not DB)
        import unittest.mock as mock
        with mock.patch.object(rr, "_resolve_file_rel_db", side_effect=RuntimeError("should not be called")):
            rel2 = rr.resolve_file_rel(proj, "app.py")
        assert rel2 == "app.py"


# ---------------------------------------------------------------------------
# section command — edge cases: nested headings, special chars, empty section
# ---------------------------------------------------------------------------

class TestSectionEdgeCases:
    """Edge cases for token-goat section that weren't covered by existing tests."""

    def test_section_top_level_heading(self, indexed_md_cli):
        """token-goat section retrieves a top-level (H1) heading."""
        from typer.testing import CliRunner

        from token_goat.cli import app

        runner = CliRunner()
        result = runner.invoke(app, ["section", "article.md::Top Level"])
        assert result.exit_code == 0
        assert "Top Level" in result.output or "Some content" in result.output

    def test_section_nested_h3_heading(self, indexed_md_cli):
        """token-goat section can retrieve a level-3 (###) heading."""
        from typer.testing import CliRunner

        from token_goat.cli import app

        runner = CliRunner()
        result = runner.invoke(app, ["section", "article.md::Subsection"])
        assert result.exit_code == 0
        assert "Subsection" in result.output or "Details" in result.output

    def test_section_results_heading(self, indexed_md_cli):
        """Retrieving the last section in a file (Results) works correctly."""
        from typer.testing import CliRunner

        from token_goat.cli import app

        runner = CliRunner()
        result = runner.invoke(app, ["section", "article.md::Results"])
        assert result.exit_code == 0
        assert "Results" in result.output or "What we found" in result.output

    def test_section_json_contains_level(self, indexed_md_cli):
        """--json output includes a 'level' field for the heading depth."""
        from typer.testing import CliRunner

        from token_goat.cli import app

        runner = CliRunner()
        result = runner.invoke(app, ["section", "--json", "article.md::Methodology"])
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert "level" in data
        assert data["level"] == 2  # ## Methodology is level 2

    def test_section_missing_separator_exits_2(self, indexed_md_cli):
        """token-goat section without '::' separator must exit 2."""
        from typer.testing import CliRunner

        from token_goat.cli import app

        runner = CliRunner()
        result = runner.invoke(app, ["section", "article.md"])
        assert result.exit_code == 2

    def test_section_nonexistent_heading_text_output(self, indexed_md_cli):
        """Missing heading in text mode exits 0 with a message on stdout or stderr."""
        from typer.testing import CliRunner

        from token_goat.cli import app

        runner = CliRunner()
        result = runner.invoke(app, ["section", "article.md::NoSuchHeadingXYZ"])
        assert result.exit_code == 0
        combined = result.output + (result.stderr or "")
        assert "NoSuchHeadingXYZ" in combined or "Section not found" in combined or "not found" in combined.lower()

    def test_read_section_subsection_direct(self, md_project):
        """read_replacement.read_section can find a nested ### heading directly."""
        proj_root, proj = md_project
        result = read_replacement.read_section(proj, "article.md", "Subsection")
        assert result is not None
        assert "Subsection" in result["heading"] or "Details" in result["text"]

    def test_read_section_results_returns_text(self, md_project):
        """read_replacement.read_section returns non-empty text for the last section."""
        proj_root, proj = md_project
        result = read_replacement.read_section(proj, "article.md", "Results")
        assert result is not None
        assert result["text"].strip() != ""


# ---------------------------------------------------------------------------
# deps --depth flag — text output for transitive dependencies
# ---------------------------------------------------------------------------

class TestDepsDepthTextOutput:
    """Tests for deps command with --depth flag producing correct text output.

    These tests use monkeypatching (same pattern as existing transitive test)
    because tree-sitter doesn't resolve cross-file import refs in the test
    fixture environment.
    """

    def _fake_proj_and_conn(self, tmp_path, make_project):
        """Create a minimal indexed project and return (proj_root, proj)."""
        from token_goat.parser import index_project

        proj_root = tmp_path / "deps_text"
        proj_root.mkdir()
        (proj_root / ".git").mkdir()
        (proj_root / "a.ts").write_text("export function a() { return 1; }\n", encoding="utf-8")
        proj = make_project(proj_root)
        index_project(proj, full=True)
        return proj_root, proj

    def test_deps_depth_1_no_transitive_section(self, tmp_path, tmp_data_dir, make_project, monkeypatch):
        """With --depth 1 (default), no 'Transitive dependencies' header appears."""
        from contextlib import contextmanager

        from typer.testing import CliRunner

        from token_goat import read_commands
        from token_goat.cli import app

        proj_root, fake_proj = self._fake_proj_and_conn(tmp_path, make_project)
        monkeypatch.chdir(proj_root)

        @contextmanager
        def _fake_conn():
            yield object()

        monkeypatch.setattr(read_commands.db, "open_project", lambda _hash: _fake_conn())
        monkeypatch.setattr(read_commands, "_resolve_file_target", lambda _f: _FileTarget(fake_proj, "a.ts", fake_proj))
        monkeypatch.setattr(read_commands, "_collect_dependency_graph", lambda _c, _r: ({"b.ts": {"greet"}}, {}, []))
        # depth=1 means _collect_transitive_outgoing is never called

        runner = CliRunner()
        result = runner.invoke(app, ["deps", "a.ts", "--depth", "1"])
        assert result.exit_code == 0
        assert "Transitive" not in result.output
        assert "b.ts" in result.output

    def test_deps_depth_2_shows_transitive_section(self, tmp_path, tmp_data_dir, make_project, monkeypatch):
        """With --depth 2, text output contains 'Transitive dependencies' section."""
        from contextlib import contextmanager

        from typer.testing import CliRunner

        from token_goat import read_commands
        from token_goat.cli import app

        proj_root, fake_proj = self._fake_proj_and_conn(tmp_path, make_project)
        monkeypatch.chdir(proj_root)

        @contextmanager
        def _fake_conn():
            yield object()

        monkeypatch.setattr(read_commands.db, "open_project", lambda _hash: _fake_conn())
        monkeypatch.setattr(read_commands, "_resolve_file_target", lambda _f: _FileTarget(fake_proj, "a.ts", fake_proj))
        monkeypatch.setattr(read_commands, "_collect_dependency_graph", lambda _c, _r: ({"b.ts": {"greet"}}, {}, []))
        monkeypatch.setattr(
            read_commands,
            "_collect_transitive_outgoing",
            lambda _c, _s, max_depth: {
                "b.ts": {"depth": 1, "via": "a.ts", "symbols": {"greet"}},
                "c.ts": {"depth": 2, "via": "b.ts", "symbols": {"helper"}},
            },
        )

        runner = CliRunner()
        result = runner.invoke(app, ["deps", "a.ts", "--depth", "2"])
        assert result.exit_code == 0
        assert "Transitive" in result.output
        assert "c.ts" in result.output

    def test_deps_depth_0_unlimited_header_uses_infinity_symbol(self, tmp_path, tmp_data_dir, make_project, monkeypatch):
        """--depth 0 text output header shows '∞' to indicate unlimited depth."""
        from contextlib import contextmanager

        from typer.testing import CliRunner

        from token_goat import read_commands
        from token_goat.cli import app

        proj_root, fake_proj = self._fake_proj_and_conn(tmp_path, make_project)
        monkeypatch.chdir(proj_root)

        @contextmanager
        def _fake_conn():
            yield object()

        monkeypatch.setattr(read_commands.db, "open_project", lambda _hash: _fake_conn())
        monkeypatch.setattr(read_commands, "_resolve_file_target", lambda _f: _FileTarget(fake_proj, "a.ts", fake_proj))
        monkeypatch.setattr(read_commands, "_collect_dependency_graph", lambda _c, _r: ({"b.ts": {"greet"}}, {}, []))
        monkeypatch.setattr(
            read_commands,
            "_collect_transitive_outgoing",
            lambda _c, _s, max_depth: {
                "b.ts": {"depth": 1, "via": "a.ts", "symbols": {"greet"}},
                "c.ts": {"depth": 2, "via": "b.ts", "symbols": {"helper"}},
            },
        )

        runner = CliRunner()
        result = runner.invoke(app, ["deps", "a.ts", "--depth", "0"])
        assert result.exit_code == 0
        # depth=0 means "unlimited"; the header should say depth 2–∞
        assert "∞" in result.output  # ∞

    def test_deps_depth_2_text_shows_via_annotation(self, tmp_path, tmp_data_dir, make_project, monkeypatch):
        """Transitive deps text output annotates depth-2 entries with 'via <parent>'."""
        from contextlib import contextmanager

        from typer.testing import CliRunner

        from token_goat import read_commands
        from token_goat.cli import app

        proj_root, fake_proj = self._fake_proj_and_conn(tmp_path, make_project)
        monkeypatch.chdir(proj_root)

        @contextmanager
        def _fake_conn():
            yield object()

        monkeypatch.setattr(read_commands.db, "open_project", lambda _hash: _fake_conn())
        monkeypatch.setattr(read_commands, "_resolve_file_target", lambda _f: _FileTarget(fake_proj, "a.ts", fake_proj))
        monkeypatch.setattr(read_commands, "_collect_dependency_graph", lambda _c, _r: ({"b.ts": {"greet"}}, {}, []))
        monkeypatch.setattr(
            read_commands,
            "_collect_transitive_outgoing",
            lambda _c, _s, max_depth: {
                "b.ts": {"depth": 1, "via": "a.ts", "symbols": {"greet"}},
                "c.ts": {"depth": 2, "via": "b.ts", "symbols": {"helper"}},
            },
        )

        runner = CliRunner()
        result = runner.invoke(app, ["deps", "a.ts", "--depth", "2"])
        assert result.exit_code == 0
        # c.ts at depth 2 should be annotated with "via b.ts"
        assert "via b.ts" in result.output


# ---------------------------------------------------------------------------
# _collect_transitive_outgoing unit tests
# ---------------------------------------------------------------------------

class TestCollectTransitiveOutgoing:
    """Unit tests for the BFS transitive dependency collector.

    Uses monkeypatching of _collect_outgoing_edges to inject synthetic edges
    so these tests don't depend on the tree-sitter indexer resolving import refs.
    """

    def _make_minimal_project(self, tmp_path, make_project):
        """Create a minimal project (needed for the conn object)."""
        from token_goat.parser import index_project

        proj_root = tmp_path / "bfs_unit"
        proj_root.mkdir()
        (proj_root / ".git").mkdir()
        (proj_root / "a.ts").write_text("export function a() {}\n", encoding="utf-8")
        proj = make_project(proj_root)
        index_project(proj, full=True)
        return proj.hash

    def test_depth_1_does_not_include_c(self, tmp_path, tmp_data_dir, make_project, monkeypatch):
        """max_depth=1 BFS from a.ts should include b.ts but not c.ts."""
        from token_goat import db, read_commands
        from token_goat.read_commands import _collect_transitive_outgoing

        # Synthetic edge map: a->b, b->c
        edge_map = {
            "a.ts": {"b.ts": {"greet"}},
            "b.ts": {"c.ts": {"helper"}},
            "c.ts": {},
        }
        monkeypatch.setattr(read_commands, "_collect_outgoing_edges", lambda _conn, rel: edge_map.get(rel, {}))

        proj_hash = self._make_minimal_project(tmp_path, make_project)
        with db.open_project(proj_hash) as conn:
            result = _collect_transitive_outgoing(conn, "a.ts", max_depth=1)
        assert "b.ts" in result
        assert "c.ts" not in result

    def test_depth_2_includes_c(self, tmp_path, tmp_data_dir, make_project, monkeypatch):
        """max_depth=2 BFS from a.ts should include both b.ts and c.ts."""
        from token_goat import db, read_commands
        from token_goat.read_commands import _collect_transitive_outgoing

        edge_map = {
            "a.ts": {"b.ts": {"greet"}},
            "b.ts": {"c.ts": {"helper"}},
            "c.ts": {},
        }
        monkeypatch.setattr(read_commands, "_collect_outgoing_edges", lambda _conn, rel: edge_map.get(rel, {}))

        proj_hash = self._make_minimal_project(tmp_path, make_project)
        with db.open_project(proj_hash) as conn:
            result = _collect_transitive_outgoing(conn, "a.ts", max_depth=2)
        assert "b.ts" in result
        assert "c.ts" in result
        assert result["c.ts"]["depth"] == 2
        assert result["c.ts"]["via"] == "b.ts"

    def test_depth_0_unlimited_finds_all(self, tmp_path, tmp_data_dir, make_project, monkeypatch):
        """max_depth=0 means unlimited — all reachable files should be returned."""
        from token_goat import db, read_commands
        from token_goat.read_commands import _collect_transitive_outgoing

        edge_map = {
            "a.ts": {"b.ts": {"greet"}},
            "b.ts": {"c.ts": {"helper"}},
            "c.ts": {"d.ts": {"util"}},
            "d.ts": {},
        }
        monkeypatch.setattr(read_commands, "_collect_outgoing_edges", lambda _conn, rel: edge_map.get(rel, {}))

        proj_hash = self._make_minimal_project(tmp_path, make_project)
        with db.open_project(proj_hash) as conn:
            result = _collect_transitive_outgoing(conn, "a.ts", max_depth=0)
        assert "b.ts" in result
        assert "c.ts" in result
        assert "d.ts" in result
        assert result["d.ts"]["depth"] == 3

    def test_cycle_does_not_loop_forever(self, tmp_path, tmp_data_dir, make_project, monkeypatch):
        """BFS should terminate even when there are cycles in the edge map."""
        from token_goat import db, read_commands
        from token_goat.read_commands import _collect_transitive_outgoing

        # a -> b -> a (cycle)
        edge_map = {
            "a.ts": {"b.ts": {"greet"}},
            "b.ts": {"a.ts": {"back"}},
        }
        monkeypatch.setattr(read_commands, "_collect_outgoing_edges", lambda _conn, rel: edge_map.get(rel, {}))

        proj_hash = self._make_minimal_project(tmp_path, make_project)
        with db.open_project(proj_hash) as conn:
            # Should not loop; a.ts is the start node so it's in visited from the start
            result = _collect_transitive_outgoing(conn, "a.ts", max_depth=0)
        # b.ts is reachable; a.ts is not in result (it's the start)
        assert "b.ts" in result
        assert "a.ts" not in result


# ---------------------------------------------------------------------------
# Surgical-read CLI ergonomics: "did you mean…?" suggestions on miss
# ---------------------------------------------------------------------------
# Why these tests matter: when a surgical-read command misses, the agent's
# only fallback is to Read the whole file — defeating the surgical-read
# mechanism entirely. A "Did you mean:" hint keeps the agent on the
# narrow-extract path even when its first guess was wrong.

class TestSurgicalReadSuggestionsOnMiss:
    """Close-match suggestions for symbol/read/section misses keep agents
    on the surgical-read path instead of falling back to whole-file Read."""

    def test_read_miss_lists_close_symbol_in_same_file(self, indexed_ts_cli):
        """`token-goat read file::TypoName` should surface real symbol names
        with similar spelling from that file as suggestions."""
        from typer.testing import CliRunner

        from token_goat.cli import app

        runner = CliRunner()
        # `greet` exists; `greetz` is a 1-char typo and should be suggested.
        result = runner.invoke(app, ["read", "index.ts::greetz"])
        combined = result.output + (result.stderr or "")
        assert "Symbol not found" in combined
        assert "Did you mean" in combined
        assert "greet" in combined

    def test_read_miss_json_carries_candidates(self, indexed_ts_cli):
        """JSON-mode miss must include `candidates` so non-human callers
        (scripts, hooks) can act on the suggestion list programmatically."""
        from typer.testing import CliRunner

        from token_goat.cli import app

        runner = CliRunner()
        result = runner.invoke(app, ["read", "--json", "index.ts::greetz"])
        payload = json.loads(result.output)
        assert payload["ok"] is False
        assert payload["error"]["code"] == "symbol_not_found"
        # `candidates` is the structured "did you mean" field.
        assert "candidates" in payload["error"]
        assert "greet" in payload["error"]["candidates"]

    def test_read_miss_with_no_close_match_omits_didyoumean(self, indexed_ts_cli):
        """When nothing is even remotely similar, do not emit a misleading
        "Did you mean:" header — the absence of suggestions is meaningful."""
        from typer.testing import CliRunner

        from token_goat.cli import app

        runner = CliRunner()
        # Extremely different from any real symbol — no close match should be surfaced.
        result = runner.invoke(app, ["read", "index.ts::xyzqq__totally_unrelated"])
        combined = result.output + (result.stderr or "")
        assert "Symbol not found" in combined
        assert "Did you mean" not in combined

    def test_section_miss_lists_close_heading_in_same_file(self, indexed_md_cli):
        """`token-goat section file::TypoHeading` should suggest real headings
        with similar spelling from that file."""
        from typer.testing import CliRunner

        from token_goat.cli import app

        runner = CliRunner()
        # Article has "Methodology"; "Methodolgy" is a 1-char typo.
        result = runner.invoke(app, ["section", "article.md::Methodolgy"])
        combined = result.output + (result.stderr or "")
        assert "Section not found" in combined
        assert "Did you mean" in combined
        assert "Methodology" in combined

    def test_section_miss_json_carries_candidates(self, indexed_md_cli):
        """Section JSON miss includes candidates list."""
        from typer.testing import CliRunner

        from token_goat.cli import app

        runner = CliRunner()
        result = runner.invoke(app, ["section", "--json", "article.md::Methodolgy"])
        payload = json.loads(result.output)
        assert payload["ok"] is False
        assert payload["error"]["code"] == "section_not_found"
        assert "candidates" in payload["error"]
        assert "Methodology" in payload["error"]["candidates"]

    def test_symbol_typo_auto_redirects_to_real_match(self, indexed_ts_cli):
        """`token-goat symbol Typo` with a single high-confidence close match
        transparently returns that match (auto-redirect). Without this the
        agent would have to parse a "Did you mean" hint and retry."""
        from typer.testing import CliRunner

        from token_goat.cli import app

        runner = CliRunner()
        # `UserService` exists; `UserServic` (truncated, ratio ~0.95) is the
        # textbook auto-redirect case — single candidate well over the 0.85
        # cutoff means the lookup is re-run against the real name.
        result = runner.invoke(app, ["symbol", "UserServic"])
        assert result.exit_code == 0
        combined = result.output + (result.stderr or "")
        # Audit marker so the substitution is visible to the caller.
        assert "redirected from" in combined
        assert "UserServic" in combined
        # Result row for the real symbol is in the output.
        assert "UserService" in combined
        assert "index.ts" in combined

    def test_symbol_typo_strict_mode_falls_back_to_didyoumean(self, indexed_ts_cli):
        """With ``--strict`` the auto-redirect is disabled and the miss path
        emits the "Did you mean" hint instead. Integration coverage on a real
        indexed DB — the unit test for ``--strict`` uses stubs."""
        from typer.testing import CliRunner

        from token_goat.cli import app

        runner = CliRunner()
        result = runner.invoke(app, ["symbol", "UserServic", "--strict"])
        assert result.exit_code == 0
        combined = result.output + (result.stderr or "")
        assert "No matches for" in combined
        assert "Did you mean" in combined
        assert "UserService" in combined

    def test_symbol_miss_with_no_close_match_omits_didyoumean(self, indexed_ts_cli):
        """When the search term is totally unlike anything indexed, do not
        emit a "Did you mean:" header (would be misleading)."""
        from typer.testing import CliRunner

        from token_goat.cli import app

        runner = CliRunner()
        result = runner.invoke(app, ["symbol", "qqzzqqzz_unrelated"])
        assert result.exit_code == 0
        combined = result.output + (result.stderr or "")
        assert "No matches for" in combined
        assert "Did you mean" not in combined


# ---------------------------------------------------------------------------
# In-session result cache integration (read_commands -> session)
# ---------------------------------------------------------------------------


class TestInSessionResultCache:
    """Verify the CLI populates and serves from the per-session result cache."""

    def test_second_read_hits_cache(self, indexed_ts_cli):
        """A second `read --session-id` for the same target uses the cached slice."""
        from typer.testing import CliRunner

        from token_goat import session
        from token_goat.cli import app

        runner = CliRunner()
        sid = "rc_cli_session_1"
        # First call populates cache
        result1 = runner.invoke(app, ["read", "--session-id", sid, "index.ts::greet"])
        assert result1.exit_code == 0
        # The session cache should now contain exactly one result-cache entry
        cache = session.load(sid)
        assert len(cache.result_cache) == 1
        # Second call must also succeed and return identical text
        result2 = runner.invoke(app, ["read", "--session-id", sid, "index.ts::greet"])
        assert result2.exit_code == 0
        assert result1.output == result2.output

    def test_file_edit_invalidates_cache(self, indexed_ts_cli):
        """Editing the file changes its SHA; the next read recomputes."""
        from typer.testing import CliRunner

        from token_goat import session
        from token_goat.cli import app

        proj_root, _proj = indexed_ts_cli
        runner = CliRunner()
        sid = "rc_cli_session_2"
        # Prime the cache
        result1 = runner.invoke(app, ["read", "--session-id", sid, "index.ts::greet"])
        assert result1.exit_code == 0
        cache = session.load(sid)
        assert len(cache.result_cache) == 1
        original_sha = next(iter(cache.result_cache.values())).file_sha

        # Modify the indexed file on disk — SHA changes
        index_ts = proj_root / "index.ts"
        index_ts.write_text(
            index_ts.read_text(encoding="utf-8") + "\n// trailing comment\n",
            encoding="utf-8",
        )
        # Next read recomputes; old entry should be invalidated and replaced
        result2 = runner.invoke(app, ["read", "--session-id", sid, "index.ts::greet"])
        assert result2.exit_code == 0
        cache_after = session.load(sid)
        # The cache should hold at most one entry for this (file, item, kind);
        # its SHA must reflect the new file contents.
        new_entries = [
            e for e in cache_after.result_cache.values()
            if e.kind == "symbol"
        ]
        assert new_entries, "expected a refreshed cache entry after the edit"
        assert all(e.file_sha != original_sha for e in new_entries)

    def test_no_session_id_skips_cache(self, indexed_ts_cli):
        """Without --session-id the cache is never consulted or populated."""
        from typer.testing import CliRunner

        from token_goat import session
        from token_goat.cli import app

        runner = CliRunner()
        result = runner.invoke(app, ["read", "index.ts::greet"])
        assert result.exit_code == 0
        # No session writes should have occurred
        # (load any session_id; none should reference index.ts in result_cache)
        cache = session.load("rc_cli_session_unused")
        assert cache.result_cache == {}
