[![regex-ai-mcp MCP server](https://glama.ai/mcp/servers/CSOAI-ORG/regex-ai-mcp/badges/score.svg)](https://glama.ai/mcp/servers/CSOAI-ORG/regex-ai-mcp)
[![MCP Registry](https://img.shields.io/badge/MCP_Registry-Published-green)](https://registry.modelcontextprotocol.io)
[![PyPI](https://img.shields.io/pypi/v/regex-ai-mcp)](https://pypi.org/project/regex-ai-mcp/)

[![regex-ai-mcp MCP server](https://glama.ai/mcp/servers/CSOAI-ORG/regex-ai-mcp/badges/card.svg)](https://glama.ai/mcp/servers/CSOAI-ORG/regex-ai-mcp)

<div align="center">

[![GitHub stars](https://img.shields.io/github/stars/CSOAI-ORG/regex-ai-mcp)](https://github.com/CSOAI-ORG/regex-ai-mcp/stargazers)

# uregexU aiU mcp

**Regex AI MCP Server — Regular expression helper tools.**

[![npm version](https://img.shields.io/npm/v/@meok-ai/regex-ai-mcp)](https://www.npmjs.com/package/@meok-ai/regex-ai-mcp)
[![License: MIT](https://img.shields.io/badge/License-MIT-green.svg)](LICENSE)
[![MEOK AI Labs](https://img.shields.io/badge/MEOK_AI_Labs-255+_servers-purple)](https://meok.ai)

[Installation](#installation) · [Docs](https://csoai.org) · [Report Bug](https://github.com/CSOAI-ORG/regex-ai-mcp/issues)

</div>

---

## Installation

```bash
pip install regex-ai-mcp
# or
npm install -g @meok-ai/regex-ai-mcp
```

## Quick Start

See the project repository for full documentation and examples.

## Enterprise Support

- 📧 nicholas@csoai.org
- 🌐 [CSOAI.org](https://csoai.org)

## License

MIT © [CSOAI](https://csoai.org)
<!-- mcp-name: io.github.CSOAI-ORG/regex-ai-mcp -->
