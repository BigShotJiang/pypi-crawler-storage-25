from __future__ import annotations

import time
from collections import defaultdict

from fastapi import WebSocket

from ._debug import dlog, _sizeof


class ConnectionManager:
    """Pub/sub manager for WebSocket connections.

    Each connection can subscribe to multiple channels simultaneously.

    Channels:
        "workflow_list"          – run_created / run_updated to all list-page viewers
        "workflow_detail:{id}"   – run_updated to viewers of a specific run
        "table:{id}"             – row and schema change events for a table
        "table_list"             – table_created / table_deleted events

    All broadcast messages are augmented with a ``_channel`` field so the
    client can route messages to the correct handler on a multiplexed connection.
    """

    def __init__(self) -> None:
        self._channels: dict[str, set[WebSocket]] = defaultdict(set)
        # id(ws) → set of subscribed channels
        self._ws_channels: dict[int, set[str]] = {}

    def subscribe(self, ws: WebSocket, channel: str) -> None:
        ws_id = id(ws)
        if ws_id not in self._ws_channels:
            self._ws_channels[ws_id] = set()
        self._ws_channels[ws_id].add(channel)
        self._channels[channel].add(ws)

    def unsubscribe(self, ws: WebSocket, channel: str) -> None:
        ws_id = id(ws)
        channels = self._ws_channels.get(ws_id)
        if channels:
            channels.discard(channel)
            if not channels:
                del self._ws_channels[ws_id]
        self._channels[channel].discard(ws)

    def disconnect(self, ws: WebSocket) -> None:
        ws_id = id(ws)
        channels = self._ws_channels.pop(ws_id, None)
        if channels:
            for channel in channels:
                self._channels[channel].discard(ws)

    async def broadcast(self, channel: str, message: dict) -> None:
        subscribers = list(self._channels.get(channel, set()))
        dead: list[WebSocket] = []
        t0 = time.perf_counter()
        n_sent = 0
        payload = {**message, "_channel": channel}
        for ws in subscribers:
            try:
                await ws.send_json(payload)
                n_sent += 1
            except Exception:
                dead.append(ws)
        for ws in dead:
            self.disconnect(ws)
        if n_sent:
            ms = (time.perf_counter() - t0) * 1000
            dlog("WS_SEND", channel, ms, _sizeof(payload), f"→ {n_sent} client(s)")


manager = ConnectionManager()
