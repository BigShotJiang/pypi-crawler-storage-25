from __future__ import annotations

import asyncio
import functools
from datetime import datetime, timezone

from ..database import _SessionLocal
from ..models import RunNode, TriggerType, Workflow, WorkflowRun, WorkflowStatus
from ..trigger_context import TriggerContext
from ._context import _active_node_slot, _active_run_ctx, _running_tasks
from ._drain import _ensure_drain_task, _notify_drain
from ._execution import _RunExecState, _execute_fn_task
from sqlalchemy import nullslast

from ._persistence import broadcast_run_nodes, insert_run_node
from ._serialization import (
    _build_children_map,
    _json_safe,
    _run_detail,
    _run_summary,
    _serialize_db_node,
)
from ..types import WorkflowFn


def make_workflow_wrapper(fn, *, restart_on_failure_check=None) -> WorkflowFn:
    @functools.wraps(fn)
    async def wrapper(inputs: dict, *, _ctx: TriggerContext | None = None):
        if _ctx is None:
            _ctx = TriggerContext("manual", inputs)

        if _SessionLocal is None:
            return await fn(inputs)

        from ..broadcast import manager
        from sqlmodel import func, select

        _parent_ctx = _active_run_ctx.get()
        _parent_run_id: int | None = _parent_ctx.get("run_id") if _parent_ctx else None

        # --- Phase 1: short session — read config, create WorkflowRun, release connection ---
        async with _SessionLocal() as session:
            cfg = (
                await session.exec(select(Workflow).where(Workflow.name == fn.__name__))
            ).first()

            if cfg is not None and cfg.max_concurrent_runs is not None:
                if cfg.max_concurrent_runs == 0:
                    return None
                running_count: int = (
                    await session.execute(
                        select(func.count(WorkflowRun.id)).where(
                            WorkflowRun.workflow_id == cfg.id,
                            WorkflowRun.status == WorkflowStatus.running,
                            WorkflowRun.parent_id == None,  # noqa: E711
                        )
                    )
                ).scalar_one()
                if running_count >= cfg.max_concurrent_runs:
                    trigger_type = (
                        TriggerType(_ctx.type)
                        if _ctx.type in TriggerType._value2member_map_
                        else TriggerType.manual
                    )
                    queued = WorkflowRun(
                        workflow_id=cfg.id,
                        status=WorkflowStatus.pending,
                        triggered_by=trigger_type,
                        data={
                            "trigger_context": _ctx.to_db(),
                            "inputs": inputs,
                            "outputs": {},
                        },
                    )
                    session.add(queued)
                    await session.commit()
                    await session.refresh(queued)
                    await manager.broadcast(
                        "workflow_list",
                        {
                            "type": "run_created",
                            "data": _run_summary(queued, fn.__name__),
                        },
                    )
                    _ensure_drain_task(fn.__name__, fn)
                    return None

            if cfg is None:
                cfg = Workflow(name=fn.__name__)
                session.add(cfg)
                await session.commit()
                await session.refresh(cfg)

            trigger_type = (
                TriggerType(_ctx.type)
                if _ctx.type in TriggerType._value2member_map_
                else TriggerType.manual
            )
            timeout = cfg.timeout_seconds if cfg else None
            run = WorkflowRun(
                workflow_id=cfg.id,
                status=WorkflowStatus.running,
                triggered_by=trigger_type,
                parent_id=_parent_run_id,
                data={
                    "trigger_context": _ctx.to_db(),
                    "inputs": inputs,
                    "outputs": {},
                },
                started_at=datetime.now(timezone.utc),
            )
            session.add(run)
            await session.commit()
            await session.refresh(run)
        # connection returned to pool here

        await manager.broadcast(
            "workflow_list",
            {"type": "run_created", "data": _run_summary(run, fn.__name__)},
        )

        # --- Execute workflow — no DB connection held during LLM/API calls ---
        ctx: dict = {
            "plan": [],
            "logs": [],
            "run_id": run.id,
            "_executed_names": set(),
            "_row_history": {},
            "_run_meta": {
                "id": run.id,
                "name": fn.__name__,
                "triggeredBy": trigger_type.value,
                "triggerContext": _ctx.to_db(),
                "inputs": inputs,
                "outputs": {},
                "startedAt": run.started_at.isoformat() if run.started_at else None,
                "finishedAt": None,
                "createdAt": run.created_at.isoformat(),
                "parentId": _parent_run_id,
                "children": [],
            },
        }
        # Pre-register rows for table-action triggered workflows so they always
        # get a history entry, even when no db.update_row is called on them.
        table_action_ctx = (_ctx.metadata or {}).get("table_action_context")
        if table_action_ctx:
            ta_table_id = table_action_ctx.get("table_id")
            ta_row_ids = table_action_ctx.get("row_ids") or []
            if ta_table_id is not None:
                for rid in ta_row_ids:
                    key = (ta_table_id, int(rid))
                    ctx["_row_history"][key] = {"wr_id": run.id}
        ctx_token = _active_run_ctx.set(ctx)
        slot_token = _active_node_slot.set(None)
        coro = fn(inputs)
        fn_task = asyncio.create_task(
            asyncio.wait_for(coro, timeout=timeout) if timeout else coro
        )
        _running_tasks[run.id] = fn_task
        state = _RunExecState(
            run=run,
            inputs=inputs,
            name=fn.__name__,
            ctx=ctx,
            ctx_token=ctx_token,
            slot_token=slot_token,
        )
        result, was_cancelled, failure_exc = await _execute_fn_task(fn_task, state)

        # --- Phase 2: short session — persist final status, release connection ---
        if not was_cancelled:
            run.finished_at = datetime.now(timezone.utc)
            db_nodes: list = []
            async with _SessionLocal() as session:
                await session.merge(run)
                # Insert pending nodes for planned-but-not-executed names.
                executed_names = ctx.get("_executed_names", set())
                for name in ctx.get("plan", []):
                    if name not in executed_names:
                        node = RunNode(
                            run_id=run.id,
                            parent_node_id=None,
                            name=name,
                            status=WorkflowStatus.pending,
                            duration_ms=0,
                        )
                        session.add(node)
                await session.commit()
                # Reload nodes for the final broadcast.
                from sqlmodel import select as _select

                db_nodes = list(
                    (
                        await session.exec(
                            _select(RunNode)
                            .where(RunNode.run_id == run.id)
                            .order_by(nullslast(RunNode.started_at), RunNode.id)
                        )
                    ).all()
                )

            root_nodes = [n for n in db_nodes if n.parent_node_id is None]
            _cm = _build_children_map(db_nodes)
            db_actions = [_serialize_db_node(n, _cm) for n in root_nodes]

            await manager.broadcast(
                "workflow_list",
                {"type": "run_updated", "data": _run_summary(run, fn.__name__)},
            )
            await manager.broadcast(
                f"workflow_detail:{run.id}",
                {
                    "type": "run_updated",
                    "data": _run_detail(run, fn.__name__, db_actions),
                },
            )

            if _parent_ctx is not None:
                duration_ms = (
                    int((run.finished_at - run.started_at).total_seconds() * 1000)
                    if run.started_at
                    else 0
                )
                parent_slot = _active_node_slot.get()
                parent_db_id: int | None = (
                    parent_slot["_db_id"] if parent_slot is not None else None
                )
                await insert_run_node(
                    run_id=_parent_run_id,
                    parent_db_id=parent_db_id,
                    name=fn.__name__,
                    slug=None,
                    inputs=inputs,
                    started_at=run.started_at or datetime.now(timezone.utc),
                    child_run_id=run.id,
                    node_status=run.status,
                    duration_ms=duration_ms,
                    outputs=_json_safe((run.data or {}).get("outputs", {})),
                )

        # Flush buffered row-history entries for all rows touched (or pre-registered
        # as table-action targets) during this workflow run.  This sends a final
        # row_updated broadcast for rows that were registered but never updated,
        # ensuring the frontend clears any stale optimistic state.
        if not was_cancelled:
            from ..db_store import flush_row_history

            await flush_row_history(ctx, failed_exc=failure_exc)

        _notify_drain(fn.__name__)

        if failure_exc is not None:
            raise failure_exc

        return result

    wrapper._gtm_fn = fn
    wrapper._restart_on_failure_check = restart_on_failure_check
    return wrapper
