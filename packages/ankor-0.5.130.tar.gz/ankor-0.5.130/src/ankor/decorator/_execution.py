from __future__ import annotations

import asyncio
import dataclasses
from typing import Any

from ..models import WorkflowRun, WorkflowStatus
from ._context import _active_node_slot, _active_run_ctx, _running_tasks
from ._serialization import _json_safe


@dataclasses.dataclass
class _RunExecState:
    run: WorkflowRun
    inputs: dict
    name: str
    ctx: dict
    ctx_token: Any
    slot_token: Any


async def _execute_fn_task(
    fn_task: asyncio.Task,
    state: _RunExecState,
) -> tuple[Any, bool, Exception | None]:
    """Execute fn_task; update run.status/data; reset context vars.

    Returns (result, was_cancelled, failure_exc).
    """
    was_cancelled = False
    failure_exc: Exception | None = None
    result = None
    try:
        result = await fn_task
        state.run.status = WorkflowStatus.success
        wf_outputs = result if isinstance(result, dict) else {}
        state.run.data = {
            **state.run.data,
            "outputs": _json_safe(wf_outputs),
            "logs": _json_safe(state.ctx["logs"]),
        }
    except asyncio.CancelledError:
        was_cancelled = True
    except Exception as exc:
        failure_exc = exc
        state.run.status = WorkflowStatus.failed
        from datetime import datetime, timezone as _tz

        state.ctx["logs"].append(
            {
                "timestamp": datetime.now(_tz.utc).isoformat(),
                "body": f"{type(exc).__name__}: {exc}",
                "type": "error",
                "json": False,
            }
        )
        state.run.data = {
            **state.run.data,
            "outputs": {},
            "logs": _json_safe(state.ctx["logs"]),
        }
    finally:
        _running_tasks.pop(state.run.id, None)
        _active_run_ctx.reset(state.ctx_token)
        _active_node_slot.reset(state.slot_token)
    return result, was_cancelled, failure_exc
