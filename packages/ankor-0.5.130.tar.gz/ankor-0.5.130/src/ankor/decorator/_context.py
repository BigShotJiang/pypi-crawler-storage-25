from __future__ import annotations

import asyncio
import contextvars

_active_run_ctx: contextvars.ContextVar[dict | None] = contextvars.ContextVar(
    "_active_run_ctx", default=None
)
_active_node_logs: contextvars.ContextVar[list | None] = contextvars.ContextVar(
    "_active_node_logs", default=None
)
_active_node_slot: contextvars.ContextVar[dict | None] = contextvars.ContextVar(
    "_active_node_slot", default=None
)

_running_tasks: dict[int, asyncio.Task] = {}
