"""Convert row history to run-pointer format (v3).

Old format (v2):
    {"wr_id": …, "wf_name": …, "date": …,
     "actions": [{"type": "row_update", "state": {…}, "date": …}, …],
     "status": "failed", "error": "…"}

New format (v3):
    {"wr_id": …, "node_action_id": …}   -- node_action_id may be null
    -- plus optional "status": "failed", "error": "…"

History items now point to run records instead of storing a copy of the diff.
Also adds action_id column to run_nodes so that the frontend can match a
history pointer back to the correct node in the run's node tree.

Revision ID: 0028
Revises: 0027
Create Date: 2026-04-23
"""

from __future__ import annotations

import json
from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op

revision: str = "0028"
down_revision: Union[str, None] = "0027"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    conn = op.get_bind()

    # ── 1. Add action_id column to run_nodes ────────────────────────────────
    op.add_column("run_nodes", sa.Column("action_id", sa.Integer(), nullable=True))
    op.create_index(
        "ix_run_nodes_run_id_action_id",
        "run_nodes",
        ["run_id", "action_id"],
        unique=True,
        postgresql_where=sa.text("action_id IS NOT NULL"),
    )

    # ── 2. Convert all data-table history entries to the v3 pointer format ──
    table_rows = conn.execute(
        sa.text(
            "SELECT table_name FROM information_schema.tables "
            "WHERE table_schema = 'public' "
            "  AND table_name ~ '^data_table_[0-9]+$' "
            "ORDER BY table_name"
        )
    ).fetchall()

    for (tbl,) in table_rows:
        has_history = conn.execute(
            sa.text(
                "SELECT 1 FROM information_schema.columns "
                "WHERE table_schema = 'public' AND table_name = :tbl AND column_name = 'history'"
            ),
            {"tbl": tbl},
        ).fetchone()
        if not has_history:
            continue

        rows = conn.execute(
            sa.text(f"SELECT id, history FROM \"{tbl}\" WHERE history != '[]'::jsonb")
        ).fetchall()

        for row_id, history_raw in rows:
            if history_raw is None:
                continue
            if isinstance(history_raw, str):
                try:
                    history_raw = json.loads(history_raw)
                except (json.JSONDecodeError, ValueError):
                    continue
            if not isinstance(history_raw, list) or not history_raw:
                continue

            new_history = []
            for entry in history_raw:
                if not isinstance(entry, dict):
                    continue
                # Preserve wr_id (may be stored as wf_id in very old entries).
                wr_id = entry.get("wr_id") or entry.get("wf_id")
                new_entry: dict = {"wr_id": wr_id, "node_action_id": None}
                # Preserve failure marker.
                if entry.get("status") == "failed":
                    new_entry["status"] = "failed"
                    if entry.get("error"):
                        new_entry["error"] = entry["error"]
                new_history.append(new_entry)

            conn.execute(
                sa.text(
                    f'UPDATE "{tbl}" SET history = CAST(:h AS jsonb) WHERE id = :rid'
                ),
                {"h": json.dumps(new_history), "rid": row_id},
            )


def downgrade() -> None:
    op.drop_index("ix_run_nodes_run_id_action_id", table_name="run_nodes")
    op.drop_column("run_nodes", "action_id")
    # History data migration is lossy — not reversible.
