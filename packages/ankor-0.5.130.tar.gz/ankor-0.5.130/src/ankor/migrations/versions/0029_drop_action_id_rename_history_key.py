"""Drop action_id from run_nodes; rename node_action_id → node_run_id in history.

Old run_nodes:
    action_id INT NULL  — slot counter used as workaround for unstable PKs

New run_nodes:
    (column removed) — PKs are now stable (INSERT on start, UPDATE on finish)

Old history entry format (v3.0):
    {"wr_id": …, "node_action_id": …}

New history entry format (v3.1):
    {"wr_id": …, "node_run_id": …}

Revision ID: 0029
Revises: 0028
Create Date: 2026-04-24
"""

from __future__ import annotations

import json
from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op

revision: str = "0029"
down_revision: Union[str, None] = "0028"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    conn = op.get_bind()

    # ── 1. Drop partial index and action_id column from run_nodes ───────────
    op.drop_index("ix_run_nodes_run_id_action_id", table_name="run_nodes")
    op.drop_column("run_nodes", "action_id")

    # ── 2. Rename node_action_id → node_run_id in all data-table history ────
    # All existing entries were written with node_action_id = null (migration
    # 0028 set them all to null), so we just rename the key to node_run_id.
    table_rows = conn.execute(
        sa.text(
            "SELECT table_name FROM information_schema.tables "
            "WHERE table_schema = 'public' "
            "  AND table_name ~ '^data_table_[0-9]+$' "
            "ORDER BY table_name"
        )
    ).fetchall()

    for (tbl,) in table_rows:
        has_history = conn.execute(
            sa.text(
                "SELECT 1 FROM information_schema.columns "
                "WHERE table_schema = 'public' AND table_name = :tbl AND column_name = 'history'"
            ),
            {"tbl": tbl},
        ).fetchone()
        if not has_history:
            continue

        rows = conn.execute(
            sa.text(f"SELECT id, history FROM \"{tbl}\" WHERE history != '[]'::jsonb")
        ).fetchall()

        for row_id, history_raw in rows:
            if history_raw is None:
                continue
            if isinstance(history_raw, str):
                try:
                    history_raw = json.loads(history_raw)
                except (json.JSONDecodeError, ValueError):
                    continue
            if not isinstance(history_raw, list) or not history_raw:
                continue

            changed = False
            new_history = []
            for entry in history_raw:
                if not isinstance(entry, dict):
                    new_history.append(entry)
                    continue
                if "node_action_id" in entry:
                    new_entry = {
                        k if k != "node_action_id" else "node_run_id": v
                        for k, v in entry.items()
                    }
                    new_history.append(new_entry)
                    changed = True
                else:
                    new_history.append(entry)

            if changed:
                conn.execute(
                    sa.text(
                        f'UPDATE "{tbl}" SET history = CAST(:h AS jsonb) WHERE id = :rid'
                    ),
                    {"h": json.dumps(new_history), "rid": row_id},
                )


def downgrade() -> None:
    op.add_column("run_nodes", sa.Column("action_id", sa.Integer(), nullable=True))
    op.create_index(
        "ix_run_nodes_run_id_action_id",
        "run_nodes",
        ["run_id", "action_id"],
        unique=True,
        postgresql_where=sa.text("action_id IS NOT NULL"),
    )
    # History key rename is lossy in reverse — not worth implementing.
