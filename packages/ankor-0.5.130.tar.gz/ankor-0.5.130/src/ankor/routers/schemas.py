from __future__ import annotations

from datetime import datetime
from enum import Enum
from typing import Any

from pydantic import BaseModel, ConfigDict, Field

from ..models import WorkflowStatus


def _to_camel(s: str) -> str:
    parts = s.split("_")
    return parts[0] + "".join(p.capitalize() for p in parts[1:])


class CamelModel(BaseModel):
    model_config = ConfigDict(alias_generator=_to_camel, populate_by_name=True)


# ── Workflow runs ─────────────────────────────────────────────────────────────


class LogEntry(CamelModel):
    timestamp: str
    body: str
    type: str = "info"
    is_json: bool = Field(default=False, alias="json")


class WorkflowNodeSummary(CamelModel):
    """Slim projection returned by the list endpoint — no inputs, outputs, or logs."""

    id: int
    name: str
    slug: str | None = None
    status: WorkflowStatus
    duration_ms: int = 0
    started_at: datetime | None = None
    child_run_id: int | None = None
    children: list[WorkflowNodeSummary] = []


WorkflowNodeSummary.model_rebuild()


class WorkflowNodeRead(CamelModel):
    id: int
    name: str
    slug: str | None = None
    status: WorkflowStatus
    inputs: dict[str, Any] = {}
    outputs: dict[str, Any] = {}
    duration_ms: int = 0
    started_at: datetime | None = None
    logs: list[LogEntry] | None = None
    child_run_id: int | None = None
    children: list[WorkflowNodeRead] = []


WorkflowNodeRead.model_rebuild()


class WorkflowRunSummary(CamelModel):
    id: int
    name: str
    status: str
    triggered_by: str
    trigger_context: dict[str, Any] = {}
    inputs: dict[str, Any] = {}
    outputs: dict[str, Any] = {}
    logs: list[dict[str, Any]] = []
    started_at: datetime | None
    finished_at: datetime | None
    created_at: datetime
    parent_id: int | None = None
    children: list[WorkflowRunSummary] = []
    row_ids: list[int] | None = None
    table_id: int | None = None


WorkflowRunSummary.model_rebuild()


class WorkflowRunChild(CamelModel):
    """Minimal child-run entry embedded in a parent WorkflowRunRead.

    Only carries the fields needed to render the tree row and synthesize an
    action node.  Heavy data (inputs / outputs / logs / triggerContext) are
    omitted and fetched on demand when the user selects the child.
    """

    id: int
    name: str
    status: str
    started_at: datetime | None
    finished_at: datetime | None
    created_at: datetime
    parent_id: int | None = None
    children: list[WorkflowRunChild] = []


WorkflowRunChild.model_rebuild()


class WorkflowRunRead(CamelModel):
    id: int
    name: str
    status: str
    triggered_by: str
    trigger_context: dict[str, Any] = {}
    inputs: dict[str, Any] = {}
    outputs: dict[str, Any] = {}
    logs: list[dict[str, Any]] = []
    started_at: datetime | None
    finished_at: datetime | None
    created_at: datetime
    parent_id: int | None = None
    # Node data is stored separately in run_nodes — fetch via GET /workflow-runs/{id}/nodes.
    actions: list[WorkflowNodeRead] = []
    children: list[WorkflowRunChild] = []


WorkflowRunRead.model_rebuild()


class WorkflowStats(CamelModel):
    counts: dict[str, int]
    active: list[WorkflowRunSummary]
    recent: list[WorkflowRunSummary]


# ── Auth ──────────────────────────────────────────────────────────────────────


class SetupRequest(BaseModel):
    username: str
    email: str | None = None
    password: str


# ── Configs ───────────────────────────────────────────────────────────────────


class ConfigRead(CamelModel):
    id: int
    key: str
    value: str
    type: str
    select_options: list[str] | None = None
    description: str | None = None
    folder: str | None = None
    created_at: datetime
    updated_at: datetime


class ConfigCreate(CamelModel):
    key: str
    value: str
    type: str
    select_options: list[str] | None = None
    description: str | None = None
    folder: str | None = None


class ConfigUpdate(CamelModel):
    key: str | None = None
    value: str | None = None
    type: str | None = None
    select_options: list[str] | None = None
    description: str | None = None
    folder: str | None = None


# ── Data tables ───────────────────────────────────────────────────────────────


class DbTableView(CamelModel):
    id: str
    name: str
    filter_model: dict[str, Any]


class DbTableViewCreate(CamelModel):
    name: str
    filter_model: dict[str, Any]


class DbTableViewsReorder(CamelModel):
    ids: list[str]


class DbTableRead(CamelModel):
    id: int
    name: str
    description: str | None = None
    actions: list[str] | None = None
    views: list[DbTableView] = []
    columns: list[dict[str, Any]] = []
    rows: list[dict[str, Any]] = []
    created_at: datetime
    updated_at: datetime


class DbRowsPage(CamelModel):
    rows: list[dict[str, Any]]
    total: int


class DbTableCreate(CamelModel):
    name: str
    description: str | None = None
    actions: list[str] | None = None
    columns: list[dict[str, Any]] = []
    rows: list[dict[str, Any]] = []


class DbTableUpdate(CamelModel):
    name: str | None = None
    description: str | None = None
    actions: list[str] | None = None
    columns: list[dict[str, Any]] | None = None
    rows: list[dict[str, Any]] | None = None


class DbAddColumnsRequest(CamelModel):
    columns: list[dict[str, Any]]


# ── Users ─────────────────────────────────────────────────────────────────────


class UserRead(CamelModel):
    username: str
    created_at: datetime


class UserCreate(CamelModel):
    username: str
    password: str


class UserPasswordUpdate(CamelModel):
    password: str


# ── API tokens ────────────────────────────────────────────────────────────────


class ApiTokenRead(CamelModel):
    id: int
    name: str
    username: str
    created_at: datetime
    expires_at: datetime | None


class ApiTokenCreate(CamelModel):
    name: str
    expires_days: int | None = None


class ApiTokenCreated(CamelModel):
    id: int
    name: str
    username: str
    created_at: datetime
    expires_at: datetime | None
    token: str


class WebhookTokenRead(CamelModel):
    token: str
    created_at: datetime


# ── Workflow definitions ──────────────────────────────────────────────────────


class InputFieldDef(CamelModel):
    key: str
    type: str  # "string" | "number" | "boolean" | "select" | "text" | "json"
    label: str | None = None
    description: str | None = None
    required: bool = False
    default: Any = None
    options: list[str] | None = None  # for "select" type


class TableActionValidation(CamelModel):
    column_name: str
    type: str
    why_needed: str


class TableActionConfig(CamelModel):
    enabled: bool = False
    selected_only: bool = False
    validation: list[TableActionValidation] = []


class WorkflowDefinitionRead(CamelModel):
    name: str
    folder: str | None
    trigger_type: str
    schedule: str | None
    is_webhook: bool
    webhook_path: str | None
    enabled: bool
    schedule_override: str | None
    timeout_seconds: int | None
    max_concurrent_runs: int | None
    recent_nodes: list[str]
    last_run_at: datetime | None
    last_run_status: str | None
    total_runs: int
    failure_rate: float
    input_schema: list[InputFieldDef] = []
    description: str | None = None
    how_it_works: str | None = Field(
        default=None,
        description=(
            "Step-by-step description of what the workflow does. "
            "Required — lets a human evaluate the workflow's logic without reading the code."
        ),
    )
    table_action: TableActionConfig = Field(default_factory=TableActionConfig)


class WorkflowConfigUpdate(CamelModel):
    enabled: bool | None = None
    schedule_override: str | None = None
    timeout_seconds: int | None = None
    max_concurrent_runs: int | None = None


class TableActionContext(CamelModel):
    table_id: int
    table_name: str
    row_ids: list[int] = []


class WorkflowTriggerRequest(CamelModel):
    inputs: dict[str, Any] = {}
    table_action_context: TableActionContext | None = None
