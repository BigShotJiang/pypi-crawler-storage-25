from __future__ import annotations

import time

from fastapi import APIRouter, WebSocket, WebSocketDisconnect

from ..auth import decode_token
from ..broadcast import manager
from .._debug import dlog, _sizeof


def create_websocket_router() -> APIRouter:
    router = APIRouter()

    @router.websocket("/ws")
    async def ws_endpoint(ws: WebSocket, token: str = ""):
        """Real-time event stream.

        Connect with ?token=<jwt>.  One connection supports multiple simultaneous
        subscriptions.  Send subscription messages at any time:

            {"type": "subscribe", "channel": "workflow_list"}
            {"type": "subscribe", "channel": "workflow_detail", "id": "<run-id>"}
            {"type": "subscribe", "channel": "table", "id": "<table-id>"}
            {"type": "subscribe", "channel": "table_list"}

        To unsubscribe from a channel, send the fully-formed channel name:

            {"type": "unsubscribe", "channel": "workflow_list"}
            {"type": "unsubscribe", "channel": "workflow_detail:123"}
            {"type": "unsubscribe", "channel": "table:5"}

        The server replies with {"type": "subscribed"|"unsubscribed", "channel": "..."}.

        Events pushed by the server always include a ``_channel`` field so
        the client can route them to the correct handler:

            workflow_list      → {"type": "run_created"|"run_updated", "data": ..., "_channel": "workflow_list"}
            workflow_detail:id → {"type": "run_updated", "data": ..., "_channel": "workflow_detail:{id}"}
            table:id           → {"type": "rows_changed"|"schema_changed"|"row_updated", ..., "_channel": "table:{id}"}
            table_list         → {"type": "table_created"|"table_deleted", "id": ..., "_channel": "table_list"}
        """
        if not decode_token(token):
            await ws.close(code=4001)
            return
        await ws.accept()
        try:
            while True:
                t_recv = time.perf_counter()
                data = await ws.receive_json()
                recv_ms = (time.perf_counter() - t_recv) * 1000
                dlog("WS_RECV", data.get("type", "?"), recv_ms, _sizeof(data))
                msg_type = data.get("type")

                if msg_type == "subscribe":
                    channel = data.get("channel", "")
                    if channel == "workflow_detail":
                        channel = f"workflow_detail:{data.get('id', '')}"
                    elif channel == "table":
                        channel = f"table:{data.get('id', '')}"
                    if channel:
                        manager.subscribe(ws, channel)
                        await ws.send_json({"type": "subscribed", "channel": channel})

                elif msg_type == "unsubscribe":
                    channel = data.get("channel", "")
                    if channel:
                        manager.unsubscribe(ws, channel)
                        await ws.send_json({"type": "unsubscribed", "channel": channel})

                elif msg_type == "ping":
                    await ws.send_json({"type": "pong"})

        except WebSocketDisconnect:
            manager.disconnect(ws)
        except Exception:
            manager.disconnect(ws)

    return router
