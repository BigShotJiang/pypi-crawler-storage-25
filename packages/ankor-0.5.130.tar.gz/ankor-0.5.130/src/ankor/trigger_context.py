from __future__ import annotations

from dataclasses import dataclass, field

_BLOCKED_HEADERS = frozenset({"authorization", "cookie", "set-cookie", "x-api-key"})


def _safe_headers(headers) -> dict[str, str]:
    return {k: v for k, v in headers.items() if k.lower() not in _BLOCKED_HEADERS}


@dataclass
class TriggerContext:
    type: str
    inputs: dict
    metadata: dict = field(default_factory=dict)

    def to_db(self) -> dict:
        return {"type": self.type, "inputs": self.inputs, **self.metadata}

    @classmethod
    def from_db(cls, data: dict) -> "TriggerContext":
        data = dict(data)

        return cls(
            type=data.pop("type", "manual"),
            inputs=data.pop("inputs", {}),
            metadata=data,
        )
