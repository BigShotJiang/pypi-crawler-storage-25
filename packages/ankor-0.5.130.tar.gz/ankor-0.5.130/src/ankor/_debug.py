"""Optional structured debug logging for ANKOR_DEBUG=true.

When the environment variable ``ANKOR_DEBUG=true`` is set, ankor emits
one-line timing entries for every:

- DB operation  (duration + estimated output size)
- WebSocket broadcast (duration + message size + recipient count)
- WebSocket receive   (wait duration + message size)
- HTTP request        (duration + response size + status code)
- Node execution      (duration + final status)

Format::

    [ANKOR_DEBUG HH:MM:SS.mmm] CATEGORY     |  <dur> [<size>] | <label> <extra>

Logs are written to both stderr and a rotating file in the directory set by
``ANKOR_DEBUG_LOG_DIR`` (default: ``logs/``).

No output is produced when ``ANKOR_DEBUG`` is not ``true``.
"""

from __future__ import annotations

import logging

try:
    import orjson as _json_impl

    def _json_dumps(obj: Any) -> bytes:
        return _json_impl.dumps(obj, option=_json_impl.OPT_NON_STR_KEYS)

except ImportError:
    import json as _stdlib_json

    def _json_dumps(obj: Any) -> bytes:  # type: ignore[misc]
        return _stdlib_json.dumps(obj, default=str).encode()


import logging.handlers
import os
import time
from datetime import datetime, timezone
from typing import Any

DEBUG: bool = os.environ.get("ANKOR_DEBUG", "").strip().lower() == "true"
LOG_DIR: str = os.environ.get("ANKOR_DEBUG_LOG_DIR", "logs")


def _setup_logger() -> logging.Logger | None:
    if not DEBUG:
        return None

    logger = logging.getLogger("ankor.debug")
    logger.setLevel(logging.DEBUG)
    logger.propagate = False

    fmt = logging.Formatter("%(message)s")

    stderr_handler = logging.StreamHandler()
    stderr_handler.setFormatter(fmt)
    logger.addHandler(stderr_handler)

    os.makedirs(LOG_DIR, exist_ok=True)
    file_handler = logging.handlers.RotatingFileHandler(
        os.path.join(LOG_DIR, "ankor_debug.log"),
        maxBytes=10 * 1024 * 1024,
        backupCount=5,
        encoding="utf-8",
    )
    file_handler.setFormatter(fmt)
    logger.addHandler(file_handler)

    return logger


_logger: logging.Logger | None = None
_logger_initialized: bool = False


def _get_logger() -> logging.Logger | None:
    """Lazily initialize the logger so .env is loaded before we check the flag."""
    global _logger, _logger_initialized, DEBUG, LOG_DIR
    if not _logger_initialized:
        _logger_initialized = True
        DEBUG = os.environ.get("ANKOR_DEBUG", "").strip().lower() == "true"
        LOG_DIR = os.environ.get("ANKOR_DEBUG_LOG_DIR", "logs")
        _logger = _setup_logger()
    return _logger


def _fmt_size(n: int) -> str:
    if n < 1024:
        return f"{n} B"
    if n < 1024**2:
        return f"{n / 1024:.1f} KB"
    if n < 1024**3:
        return f"{n / 1024 ** 2:.2f} MB"
    return f"{n / 1024 ** 3:.2f} GB"


def _fmt_dur(ms: float) -> str:
    if ms < 1000:
        return f"{ms:.0f}ms"
    return f"{ms / 1000:.2f}s"


def _sizeof(obj: Any) -> int:
    """Estimate serialised JSON byte size of *obj*."""
    try:
        return len(_json_dumps(obj))
    except Exception:
        return 0


def dlog(
    category: str,
    label: str,
    duration_ms: float,
    size_bytes: int | None = None,
    extra: str = "",
) -> None:
    logger = _get_logger()
    if logger is None:
        return
    ts = datetime.now(timezone.utc).strftime("%H:%M:%S.%f")[:-3]
    size_str = f" [{_fmt_size(size_bytes)}]" if size_bytes is not None else ""
    extra_str = f" {extra}" if extra else ""
    logger.debug(
        "[ANKOR_DEBUG %s] %-12s| %8s%s | %s%s",
        ts,
        category,
        _fmt_dur(duration_ms),
        size_str,
        label,
        extra_str,
    )


def patch_httpx() -> None:
    """Monkey-patch ``httpx.AsyncClient`` to log every request's timing.

    Called once at startup when ANKOR_DEBUG=true. Uses httpx event hooks so it
    does not interfere with existing per-instance hooks.
    """
    if _get_logger() is None:
        return
    try:
        import httpx
    except ImportError:
        return

    if getattr(httpx.AsyncClient, "_ankor_debug_patched", False):
        return

    _orig_init = httpx.AsyncClient.__init__

    def _patched_init(self: httpx.AsyncClient, *args: Any, **kwargs: Any) -> None:
        existing: dict = kwargs.pop("event_hooks", None) or {}
        req_hooks: list = list(existing.get("request", []))
        res_hooks: list = list(existing.get("response", []))

        _start_times: dict[int, float] = {}

        async def _on_request(request: httpx.Request) -> None:
            _start_times[id(request)] = time.perf_counter()

        async def _on_response(response: httpx.Response) -> None:
            t0 = _start_times.pop(id(response.request), None)
            if t0 is None:
                return
            ms = (time.perf_counter() - t0) * 1000
            # content-length may be absent (chunked / streaming)
            cl = response.headers.get("content-length")
            size = int(cl) if cl and cl.isdigit() else None
            url = response.request.url
            label = f"{response.request.method} {url.host}{url.path}"
            dlog("HTTP", label, ms, size, f"→ {response.status_code}")

        req_hooks.append(_on_request)
        res_hooks.append(_on_response)
        kwargs["event_hooks"] = {"request": req_hooks, "response": res_hooks}
        _orig_init(self, *args, **kwargs)

    httpx.AsyncClient.__init__ = _patched_init  # type: ignore[method-assign]
    httpx.AsyncClient._ankor_debug_patched = True  # type: ignore[attr-defined]
