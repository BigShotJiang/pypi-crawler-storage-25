"""Tests for _recover_from_restart — startup recovery of interrupted workflow runs.

Simulates server stoppage by pre-populating a mock session with runs in various
states, then calling _recover_from_restart directly.  No live server needed.
"""

from __future__ import annotations

import asyncio
from datetime import datetime, timezone
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from ankor.core import _recover_from_restart
from ankor.models import TriggerType, Workflow, WorkflowRun, WorkflowStatus

# Lazy imports patched inside _recover_from_restart live in ankor.decorator.
_DRAIN_ENSURE = "ankor.decorator._ensure_drain_task"
_DRAIN_NOTIFY = "ankor.decorator._notify_drain"
_RESUME = "ankor.decorator._resume_existing_run"


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_run(run_id: int, status: WorkflowStatus, workflow_id: int = 1) -> WorkflowRun:
    return WorkflowRun(
        id=run_id,
        workflow_id=workflow_id,
        status=status,
        triggered_by=TriggerType.manual,
        data={"inputs": {}, "outputs": {}, "actions": []},
    )


def _make_workflow(wf_id: int, name: str) -> Workflow:
    return Workflow(id=wf_id, name=name)


def _mock_session(
    orphaned_runs: list,
    pending_wf_names: list,
    wf_objects: list | None = None,
) -> AsyncMock:
    """Build a mock async session.

    session.execute call order:
      0 -> slim SELECT (WorkflowRun.id, workflow_id) for orphaned runs
      1 -> bulk UPDATE WorkflowRun (only if there are runs to cancel)

    session.exec call order (when orphaned_runs non-empty):
      0 -> Workflow records for name lookup
      1 -> pending workflow names

    When orphaned_runs is empty, session.exec only returns pending names.
    """
    # --- session.exec (ORM selects) ---
    exec_results: list = []
    if orphaned_runs:
        exec_results.append(wf_objects if wf_objects is not None else [])
    exec_results.append(pending_wf_names)
    exec_idx = [0]

    async def _mock_exec(stmt):
        result = MagicMock()
        i = exec_idx[0]
        exec_idx[0] += 1
        result.all.return_value = exec_results[i] if i < len(exec_results) else []
        return result

    # --- session.execute (slim SELECT + bulk UPDATE) ---
    execute_idx = [0]

    async def _mock_execute_fn(stmt):
        result = MagicMock()
        i = execute_idx[0]
        execute_idx[0] += 1
        if i == 0:
            # Slim orphaned-runs SELECT — return run objects (they have .id/.workflow_id)
            result.all.return_value = orphaned_runs
        # i == 1 is the bulk UPDATE — return value is not used
        return result

    session = AsyncMock()
    session.add = MagicMock()
    session.exec = _mock_exec
    session.execute = AsyncMock(side_effect=_mock_execute_fn)
    return session


# ---------------------------------------------------------------------------
# Tests: orphaned running runs WITHOUT a wrapper are cancelled
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_running_runs_without_wrapper_are_cancelled():
    """Runs for unregistered workflows are cancelled via bulk UPDATE."""
    runs = [_make_run(1, WorkflowStatus.running), _make_run(2, WorkflowStatus.running)]
    wf = _make_workflow(1, "unknown_workflow")
    session = _mock_session(orphaned_runs=runs, pending_wf_names=[], wf_objects=[wf])

    with patch(_DRAIN_ENSURE), patch(_DRAIN_NOTIFY), patch(_RESUME):
        await _recover_from_restart(session, wrappers={})

    # Bulk UPDATE + commit — run objects themselves are not mutated.
    assert session.execute.call_count == 2  # SELECT + bulk UPDATE
    session.commit.assert_called_once()


@pytest.mark.asyncio
async def test_cancelled_runs_have_finished_at_set():
    run = _make_run(1, WorkflowStatus.running)
    wf = _make_workflow(1, "gone_workflow")
    session = _mock_session(orphaned_runs=[run], pending_wf_names=[], wf_objects=[wf])

    with patch(_DRAIN_ENSURE), patch(_DRAIN_NOTIFY), patch(_RESUME):
        await _recover_from_restart(session, wrappers={})

    # finished_at is set via bulk UPDATE; verify commit was issued.
    session.commit.assert_called_once()


@pytest.mark.asyncio
async def test_orphaned_runs_without_wrapper_are_added_to_session():
    """Cancelled runs use a bulk UPDATE — session.add is never called."""
    runs = [_make_run(1, WorkflowStatus.running), _make_run(2, WorkflowStatus.running)]
    wf = _make_workflow(1, "gone_workflow")
    session = _mock_session(orphaned_runs=runs, pending_wf_names=[], wf_objects=[wf])

    with patch(_DRAIN_ENSURE), patch(_DRAIN_NOTIFY), patch(_RESUME):
        await _recover_from_restart(session, wrappers={})

    session.add.assert_not_called()
    assert session.execute.call_count == 2  # slim SELECT + bulk UPDATE


@pytest.mark.asyncio
async def test_commit_called_when_runs_to_cancel_exist():
    run = _make_run(1, WorkflowStatus.running)
    wf = _make_workflow(1, "unknown_workflow")
    session = _mock_session(orphaned_runs=[run], pending_wf_names=[], wf_objects=[wf])

    with patch(_DRAIN_ENSURE), patch(_DRAIN_NOTIFY), patch(_RESUME):
        await _recover_from_restart(session, wrappers={})

    session.commit.assert_called_once()


# ---------------------------------------------------------------------------
# Tests: orphaned running runs WITH a wrapper are resumed
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_running_run_with_wrapper_is_not_cancelled():
    """A run whose workflow is registered must NOT be cancelled."""
    run = _make_run(1, WorkflowStatus.running)
    wf = _make_workflow(1, "my_workflow")

    async def my_workflow(inputs: dict):
        return {}

    session = _mock_session(orphaned_runs=[run], pending_wf_names=[], wf_objects=[wf])

    with patch(_DRAIN_ENSURE), patch(_DRAIN_NOTIFY), patch(_RESUME):
        await _recover_from_restart(session, wrappers={"my_workflow": my_workflow})

    assert run.status == WorkflowStatus.running
    assert run.finished_at is None
    session.add.assert_not_called()


@pytest.mark.asyncio
async def test_running_run_with_wrapper_no_commit():
    """No cancel-commit when all orphaned runs have wrappers and will be resumed."""
    run = _make_run(1, WorkflowStatus.running)
    wf = _make_workflow(1, "my_workflow")

    async def my_workflow(inputs: dict):
        return {}

    session = _mock_session(orphaned_runs=[run], pending_wf_names=[], wf_objects=[wf])

    with patch(_DRAIN_ENSURE), patch(_DRAIN_NOTIFY), patch(_RESUME):
        await _recover_from_restart(session, wrappers={"my_workflow": my_workflow})

    session.commit.assert_not_called()


@pytest.mark.asyncio
async def test_resume_task_scheduled_for_resumable_run():
    """_resume_existing_run is invoked via create_task for each resumable run."""
    run = _make_run(1, WorkflowStatus.running)
    wf = _make_workflow(1, "my_workflow")

    async def raw_fn(inputs: dict):
        return {}

    wrapper = MagicMock()
    wrapper._gtm_fn = raw_fn
    del wrapper._restart_on_failure_check  # simulate attribute not set

    session = _mock_session(orphaned_runs=[run], pending_wf_names=[], wf_objects=[wf])

    resume_calls: list = []

    async def _fake_resume(*args, **kwargs):
        resume_calls.append(args)

    loop = asyncio.get_event_loop()
    with patch(_DRAIN_ENSURE), patch(_DRAIN_NOTIFY):
        with patch(_RESUME, side_effect=_fake_resume):
            with patch("asyncio.get_running_loop", return_value=loop):
                await _recover_from_restart(session, wrappers={"my_workflow": wrapper})
                await asyncio.sleep(0)

    assert len(resume_calls) == 1
    assert resume_calls[0][0] is raw_fn
    assert resume_calls[0][1] == 1
    assert resume_calls[0][2] == "my_workflow"


@pytest.mark.asyncio
async def test_resume_passes_restart_on_failure_check_attribute():
    """_restart_on_failure_check on the wrapper is forwarded to _resume_existing_run."""
    run = _make_run(1, WorkflowStatus.running)
    wf = _make_workflow(1, "my_workflow")

    async def raw_fn(inputs: dict):
        return {}

    async def check_fn(inputs: dict):
        return None

    wrapper = MagicMock()
    wrapper._gtm_fn = raw_fn
    wrapper._restart_on_failure_check = check_fn

    session = _mock_session(orphaned_runs=[run], pending_wf_names=[], wf_objects=[wf])

    resume_calls: list = []

    async def _fake_resume(*args, **kwargs):
        resume_calls.append(args)

    loop = asyncio.get_event_loop()
    with patch(_DRAIN_ENSURE), patch(_DRAIN_NOTIFY):
        with patch(_RESUME, side_effect=_fake_resume):
            with patch("asyncio.get_running_loop", return_value=loop):
                await _recover_from_restart(session, wrappers={"my_workflow": wrapper})
                await asyncio.sleep(0)

    assert len(resume_calls) == 1
    assert resume_calls[0] == (raw_fn, 1, "my_workflow", check_fn)


# ---------------------------------------------------------------------------
# Tests: mixed cancel + resume
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_mixed_cancel_and_resume():
    """Runs with wrappers are resumed; runs without wrappers are bulk-cancelled."""
    run_resumable = _make_run(1, WorkflowStatus.running, workflow_id=1)
    run_cancellable = _make_run(2, WorkflowStatus.running, workflow_id=2)
    wf1 = _make_workflow(1, "known_workflow")
    wf2 = _make_workflow(2, "unknown_workflow")

    async def known_workflow(inputs: dict):
        return {}

    session = _mock_session(
        orphaned_runs=[run_resumable, run_cancellable],
        pending_wf_names=[],
        wf_objects=[wf1, wf2],
    )

    with patch(_DRAIN_ENSURE), patch(_DRAIN_NOTIFY), patch(_RESUME):
        await _recover_from_restart(session, wrappers={"known_workflow": known_workflow})

    # Resumable run is untouched; cancellable run is handled via bulk UPDATE.
    assert run_resumable.status == WorkflowStatus.running
    session.add.assert_not_called()
    session.commit.assert_called_once()


# ---------------------------------------------------------------------------
# Tests: pending runs resume drain (unchanged behaviour)
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_commit_not_called_when_no_orphaned_runs():
    session = _mock_session(orphaned_runs=[], pending_wf_names=[])

    with patch(_DRAIN_ENSURE), patch(_DRAIN_NOTIFY), patch(_RESUME):
        await _recover_from_restart(session, wrappers={})

    session.commit.assert_not_called()


@pytest.mark.asyncio
async def test_pending_runs_start_drain_task():
    async def my_workflow(inputs: dict):
        return {}

    session = _mock_session(orphaned_runs=[], pending_wf_names=["my_workflow"])

    with patch(_DRAIN_ENSURE) as mock_ensure, patch(_DRAIN_NOTIFY) as mock_notify, patch(_RESUME):
        await _recover_from_restart(session, wrappers={"my_workflow": my_workflow})

    mock_ensure.assert_called_once_with("my_workflow", my_workflow)
    mock_notify.assert_called_once_with("my_workflow")


@pytest.mark.asyncio
async def test_pending_runs_for_multiple_workflows():
    async def wf_one(inputs: dict):
        return {}

    async def wf_two(inputs: dict):
        return {}

    session = _mock_session(orphaned_runs=[], pending_wf_names=["wf_one", "wf_two"])

    with patch(_DRAIN_ENSURE) as mock_ensure, patch(_DRAIN_NOTIFY) as mock_notify, patch(_RESUME):
        await _recover_from_restart(
            session, wrappers={"wf_one": wf_one, "wf_two": wf_two}
        )

    assert mock_ensure.call_count == 2
    assert mock_notify.call_count == 2


@pytest.mark.asyncio
async def test_pending_runs_for_unregistered_workflow_are_skipped():
    """Pending runs for a workflow no longer in wrappers must not start a drain."""
    session = _mock_session(orphaned_runs=[], pending_wf_names=["removed_workflow"])

    with patch(_DRAIN_ENSURE) as mock_ensure, patch(_DRAIN_NOTIFY) as mock_notify, patch(_RESUME):
        await _recover_from_restart(session, wrappers={})

    mock_ensure.assert_not_called()
    mock_notify.assert_not_called()


# ---------------------------------------------------------------------------
# Tests: mixed and edge cases
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_clean_state_is_a_noop():
    """No running or pending runs — nothing should be written or started."""
    session = _mock_session(orphaned_runs=[], pending_wf_names=[])

    with patch(_DRAIN_ENSURE) as mock_ensure, patch(_DRAIN_NOTIFY) as mock_notify, patch(_RESUME):
        await _recover_from_restart(session, wrappers={})

    session.add.assert_not_called()
    session.commit.assert_not_called()
    mock_ensure.assert_not_called()
    mock_notify.assert_not_called()


@pytest.mark.asyncio
async def test_mixed_running_without_wrapper_and_pending_both_handled():
    """A non-resumable running run is cancelled AND pending runs get drained."""

    async def my_workflow(inputs: dict):
        return {}

    orphaned = [_make_run(10, WorkflowStatus.running)]
    wf = _make_workflow(1, "orphaned_workflow")  # not in wrappers
    session = _mock_session(
        orphaned_runs=orphaned,
        pending_wf_names=["my_workflow"],
        wf_objects=[wf],
    )

    with patch(_DRAIN_ENSURE) as mock_ensure, patch(_DRAIN_NOTIFY) as mock_notify, patch(_RESUME):
        await _recover_from_restart(session, wrappers={"my_workflow": my_workflow})

    assert orphaned[0].status == WorkflowStatus.running  # bulk UPDATE, object not mutated
    session.commit.assert_called_once()
    mock_ensure.assert_called_once_with("my_workflow", my_workflow)
    mock_notify.assert_called_once_with("my_workflow")


@pytest.mark.asyncio
async def test_wrapper_with_gtm_fn_attribute_uses_raw_fn():
    """When wrapper has _gtm_fn attribute, the raw underlying fn is passed to drain."""

    async def raw_fn(inputs: dict):
        return {}

    wrapper = MagicMock()
    wrapper._gtm_fn = raw_fn

    session = _mock_session(orphaned_runs=[], pending_wf_names=["my_workflow"])

    with patch(_DRAIN_ENSURE) as mock_ensure, patch(_DRAIN_NOTIFY), patch(_RESUME):
        await _recover_from_restart(session, wrappers={"my_workflow": wrapper})

    mock_ensure.assert_called_once_with("my_workflow", raw_fn)


@pytest.mark.asyncio
async def test_multiple_orphaned_runs_no_wrapper_all_cancelled():
    """All orphaned runs without wrappers are batched and committed in one go."""
    runs = [_make_run(i, WorkflowStatus.running) for i in range(1, 6)]
    wf = _make_workflow(1, "gone_workflow")
    session = _mock_session(orphaned_runs=runs, pending_wf_names=[], wf_objects=[wf])

    with patch(_DRAIN_ENSURE), patch(_DRAIN_NOTIFY), patch(_RESUME):
        await _recover_from_restart(session, wrappers={})

    assert session.add.call_count == 0  # bulk UPDATE \u2014 no add() calls
    session.commit.assert_called_once()
    assert all(r.status == WorkflowStatus.running for r in runs)  # objects not mutated


@pytest.mark.asyncio
async def test_child_runs_with_wrapper_also_resumed():
    """Sub-workflow runs sharing the same workflow_id get resumed when a wrapper exists."""

    async def my_workflow(inputs: dict):
        return {}

    parent_run = _make_run(1, WorkflowStatus.running)
    child_run = WorkflowRun(
        id=2,
        workflow_id=1,
        parent_id=1,
        status=WorkflowStatus.running,
        triggered_by=TriggerType.manual,
        data={},
    )
    wf = _make_workflow(1, "my_workflow")
    session = _mock_session(
        orphaned_runs=[parent_run, child_run],
        pending_wf_names=[],
        wf_objects=[wf],
    )

    with patch(_DRAIN_ENSURE), patch(_DRAIN_NOTIFY), patch(_RESUME):
        await _recover_from_restart(
            session, wrappers={"my_workflow": my_workflow}
        )

    assert parent_run.status == WorkflowStatus.running
    assert child_run.status == WorkflowStatus.running
    session.add.assert_not_called()
