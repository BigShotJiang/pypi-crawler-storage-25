"""Tests for ConnectionManager multi-channel pub/sub behaviour."""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock

import pytest

from ankor.broadcast import ConnectionManager


def make_ws() -> MagicMock:
    ws = MagicMock()
    ws.send_json = AsyncMock()
    return ws


class TestSubscribe:
    def test_subscribe_adds_to_channel(self):
        mgr = ConnectionManager()
        ws = make_ws()
        mgr.subscribe(ws, "workflow_list")

        assert ws in mgr._channels["workflow_list"]
        assert "workflow_list" in mgr._ws_channels[id(ws)]

    def test_subscribe_multiple_channels(self):
        mgr = ConnectionManager()
        ws = make_ws()
        mgr.subscribe(ws, "workflow_list")
        mgr.subscribe(ws, "table:1")

        assert ws in mgr._channels["workflow_list"]
        assert ws in mgr._channels["table:1"]
        assert mgr._ws_channels[id(ws)] == {"workflow_list", "table:1"}

    def test_subscribe_same_channel_twice_is_idempotent(self):
        mgr = ConnectionManager()
        ws = make_ws()
        mgr.subscribe(ws, "workflow_list")
        mgr.subscribe(ws, "workflow_list")

        assert len(mgr._channels["workflow_list"]) == 1
        assert mgr._ws_channels[id(ws)] == {"workflow_list"}

    def test_two_sockets_same_channel(self):
        mgr = ConnectionManager()
        ws1, ws2 = make_ws(), make_ws()
        mgr.subscribe(ws1, "workflow_list")
        mgr.subscribe(ws2, "workflow_list")

        assert len(mgr._channels["workflow_list"]) == 2


class TestUnsubscribe:
    def test_unsubscribe_removes_from_channel(self):
        mgr = ConnectionManager()
        ws = make_ws()
        mgr.subscribe(ws, "workflow_list")
        mgr.unsubscribe(ws, "workflow_list")

        assert ws not in mgr._channels["workflow_list"]

    def test_unsubscribe_leaves_other_channels_intact(self):
        mgr = ConnectionManager()
        ws = make_ws()
        mgr.subscribe(ws, "workflow_list")
        mgr.subscribe(ws, "table:1")
        mgr.unsubscribe(ws, "workflow_list")

        assert ws not in mgr._channels["workflow_list"]
        assert ws in mgr._channels["table:1"]
        assert "workflow_list" not in mgr._ws_channels.get(id(ws), set())
        assert "table:1" in mgr._ws_channels[id(ws)]

    def test_unsubscribe_last_channel_cleans_up_ws_entry(self):
        mgr = ConnectionManager()
        ws = make_ws()
        mgr.subscribe(ws, "workflow_list")
        mgr.unsubscribe(ws, "workflow_list")

        assert id(ws) not in mgr._ws_channels

    def test_unsubscribe_unknown_channel_does_not_raise(self):
        mgr = ConnectionManager()
        ws = make_ws()
        mgr.unsubscribe(ws, "workflow_list")  # ws was never subscribed

    def test_unsubscribe_unknown_ws_does_not_raise(self):
        mgr = ConnectionManager()
        ws = make_ws()
        mgr.subscribe(ws, "workflow_list")
        other_ws = make_ws()
        mgr.unsubscribe(other_ws, "workflow_list")  # different ws


class TestDisconnect:
    def test_disconnect_removes_from_all_channels(self):
        mgr = ConnectionManager()
        ws = make_ws()
        mgr.subscribe(ws, "workflow_list")
        mgr.subscribe(ws, "table:1")
        mgr.subscribe(ws, "workflow_detail:42")
        mgr.disconnect(ws)

        assert ws not in mgr._channels["workflow_list"]
        assert ws not in mgr._channels["table:1"]
        assert ws not in mgr._channels["workflow_detail:42"]
        assert id(ws) not in mgr._ws_channels

    def test_disconnect_leaves_other_sockets(self):
        mgr = ConnectionManager()
        ws1, ws2 = make_ws(), make_ws()
        mgr.subscribe(ws1, "workflow_list")
        mgr.subscribe(ws2, "workflow_list")
        mgr.disconnect(ws1)

        assert ws2 in mgr._channels["workflow_list"]

    def test_disconnect_unknown_ws_does_not_raise(self):
        mgr = ConnectionManager()
        ws = make_ws()
        mgr.disconnect(ws)  # was never subscribed


class TestBroadcast:
    @pytest.mark.asyncio
    async def test_sends_to_subscribers(self):
        mgr = ConnectionManager()
        ws = make_ws()
        mgr.subscribe(ws, "workflow_list")

        await mgr.broadcast("workflow_list", {"type": "run_created", "data": {}})

        ws.send_json.assert_called_once()

    @pytest.mark.asyncio
    async def test_injects_channel_field(self):
        mgr = ConnectionManager()
        ws = make_ws()
        mgr.subscribe(ws, "table:5")

        await mgr.broadcast("table:5", {"type": "rows_changed"})

        sent = ws.send_json.call_args[0][0]
        assert sent["_channel"] == "table:5"
        assert sent["type"] == "rows_changed"

    @pytest.mark.asyncio
    async def test_does_not_mutate_original_message(self):
        mgr = ConnectionManager()
        ws = make_ws()
        mgr.subscribe(ws, "workflow_list")
        msg = {"type": "run_created"}

        await mgr.broadcast("workflow_list", msg)

        assert "_channel" not in msg

    @pytest.mark.asyncio
    async def test_only_sends_to_subscribed_channel(self):
        mgr = ConnectionManager()
        ws1, ws2 = make_ws(), make_ws()
        mgr.subscribe(ws1, "workflow_list")
        mgr.subscribe(ws2, "table:1")

        await mgr.broadcast("workflow_list", {"type": "run_created"})

        ws1.send_json.assert_called_once()
        ws2.send_json.assert_not_called()

    @pytest.mark.asyncio
    async def test_removes_dead_connections(self):
        mgr = ConnectionManager()
        ws = make_ws()
        ws.send_json.side_effect = Exception("connection lost")
        mgr.subscribe(ws, "workflow_list")

        await mgr.broadcast("workflow_list", {"type": "run_created"})

        assert ws not in mgr._channels["workflow_list"]

    @pytest.mark.asyncio
    async def test_ws_subscribed_to_multiple_channels_receives_only_targeted(self):
        mgr = ConnectionManager()
        ws = make_ws()
        mgr.subscribe(ws, "workflow_list")
        mgr.subscribe(ws, "table:1")

        await mgr.broadcast("table:1", {"type": "rows_changed"})

        ws.send_json.assert_called_once()
        sent = ws.send_json.call_args[0][0]
        assert sent["_channel"] == "table:1"

    @pytest.mark.asyncio
    async def test_no_subscribers_sends_nothing(self):
        mgr = ConnectionManager()

        # Should not raise
        await mgr.broadcast("workflow_list", {"type": "run_created"})
