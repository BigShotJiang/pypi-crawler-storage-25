"""Tests for the tracks_row=True node decorator feature."""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch

import pytest

import ankor.decorator as dec
from ankor.decorator.node import make_node_wrapper


@pytest.fixture(autouse=True)
def _patch_broadcast():
    mock_manager = MagicMock()
    mock_manager.broadcast = AsyncMock()
    with patch("ankor.broadcast.manager", mock_manager):
        yield mock_manager


@pytest.fixture()
def _patch_fsh():
    """Patch flush_single_row_history so tests don't need a real DB session."""
    mock_fsh = AsyncMock()
    with patch("ankor.decorator.node.flush_single_row_history", mock_fsh):
        yield mock_fsh


def _make_ctx(table_id: int = 7, row_ids: list[int] | None = None) -> dict:
    """Build a minimal run context with a table_action_context."""
    return {
        "plan": [],
        "logs": [],
        "run_id": 42,
        "_executed_names": set(),
        "_run_meta": {
            "id": 42,
            "name": "test_workflow",
            "triggeredBy": "manual",
            "triggerContext": {
                "type": "manual",
                "inputs": {},
                "table_action_context": {
                    "table_id": table_id,
                    "table_name": "Contacts",
                    "row_ids": row_ids or [],
                },
            },
            "inputs": {},
            "outputs": {},
            "startedAt": None,
            "finishedAt": None,
            "createdAt": "2026-01-01T00:00:00",
            "parentId": None,
            "children": [],
        },
    }


# ---------------------------------------------------------------------------
# tracks_row broadcasts processing → completed on success
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_tracks_row_broadcasts_processing_then_completed(
    _patch_broadcast, _patch_fsh
):
    mock_manager = _patch_broadcast
    mock_fsh = _patch_fsh

    async def process_row(inputs: dict) -> dict:
        return {"ok": True}

    wrapped = make_node_wrapper(process_row, tracks_row=True)

    ctx = _make_ctx(table_id=7)
    token = dec._active_run_ctx.set(ctx)
    try:
        result = await wrapped({"row_id": 3})
    finally:
        dec._active_run_ctx.reset(token)

    assert result == {"ok": True}

    # Loading badge comes from workflow_list run_created (not from node).
    # Node calls flush_single_row_history on success — no row_run_status broadcasts.
    row_status_calls = [
        c
        for c in mock_manager.broadcast.call_args_list
        if c.args and c.args[0] == "table:7"
    ]
    assert row_status_calls == []

    mock_fsh.assert_called_once()
    call = mock_fsh.call_args
    assert call.args[1] == 7  # table_id
    assert call.args[2] == 3  # row_id
    assert call.kwargs.get("failed_exc") is None
    assert call.kwargs.get("node_slot") is not None  # slot dict passed


# ---------------------------------------------------------------------------
# tracks_row broadcasts processing → failed on exception
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_tracks_row_broadcasts_failed_on_exception(_patch_broadcast, _patch_fsh):
    mock_manager = _patch_broadcast
    mock_fsh = _patch_fsh

    async def failing_node(inputs: dict) -> dict:
        raise ValueError("something went wrong")

    wrapped = make_node_wrapper(failing_node, tracks_row=True)

    ctx = _make_ctx(table_id=7)
    token = dec._active_run_ctx.set(ctx)
    with pytest.raises(ValueError, match="something went wrong"):
        try:
            await wrapped({"row_id": 5})
        finally:
            dec._active_run_ctx.reset(token)

    # Node calls flush_single_row_history with the exception — no row_run_status broadcast.
    row_status_calls = [
        c
        for c in mock_manager.broadcast.call_args_list
        if c.args and c.args[0] == "table:7"
    ]
    assert row_status_calls == []

    mock_fsh.assert_called_once()
    call = mock_fsh.call_args
    assert call.args[1] == 7  # table_id
    assert call.args[2] == 5  # row_id
    assert isinstance(call.kwargs.get("failed_exc"), ValueError)
    assert call.kwargs.get("node_slot") is not None  # slot dict passed


# ---------------------------------------------------------------------------
# tracks_row=False: no row_run_status events emitted
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_no_row_status_when_tracks_row_false(_patch_broadcast):
    mock_manager = _patch_broadcast

    async def plain_node(inputs: dict) -> dict:
        return {}

    wrapped = make_node_wrapper(plain_node, tracks_row=False)

    ctx = _make_ctx(table_id=7)
    token = dec._active_run_ctx.set(ctx)
    try:
        await wrapped({"row_id": 1})
    finally:
        dec._active_run_ctx.reset(token)

    row_status_calls = [
        c
        for c in mock_manager.broadcast.call_args_list
        if c.args and c.args[0] == "table:7"
    ]
    assert row_status_calls == []


# ---------------------------------------------------------------------------
# tracks_row=True outside a workflow context: no broadcast, no crash
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_tracks_row_no_op_outside_workflow_context(_patch_broadcast):
    mock_manager = _patch_broadcast

    async def solo_node(inputs: dict) -> dict:
        return {"value": inputs.get("x")}

    wrapped = make_node_wrapper(solo_node, tracks_row=True)

    # No active run context — should just run the function normally
    result = await wrapped({"row_id": 99, "x": "hello"})

    assert result == {"value": "hello"}
    mock_manager.broadcast.assert_not_called()


# ---------------------------------------------------------------------------
# tracks_row=True without table_action_context: no row status events
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_tracks_row_no_op_without_table_action_context(_patch_broadcast):
    mock_manager = _patch_broadcast

    async def some_node(inputs: dict) -> dict:
        return {}

    wrapped = make_node_wrapper(some_node, tracks_row=True)

    # Context exists but no table_action_context in triggerContext
    ctx: dict = {
        "plan": [],
        "logs": [],
        "run_id": 1,
        "_executed_names": set(),
        "_run_meta": {
            "id": 1,
            "name": "wf",
            "triggeredBy": "manual",
            "triggerContext": {"type": "manual", "inputs": {}},
            "inputs": {},
            "outputs": {},
            "startedAt": None,
            "finishedAt": None,
            "createdAt": "2026-01-01T00:00:00",
            "parentId": None,
            "children": [],
        },
    }
    token = dec._active_run_ctx.set(ctx)
    try:
        await wrapped({"row_id": 11})
    finally:
        dec._active_run_ctx.reset(token)

    row_status_calls = [
        c
        for c in mock_manager.broadcast.call_args_list
        if c.args and c.args[0].startswith("table:")
    ]
    assert row_status_calls == []


# ---------------------------------------------------------------------------
# row_id coercion: string "3" should be cast to int 3
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_tracks_row_coerces_string_row_id(_patch_broadcast, _patch_fsh):
    mock_fsh = _patch_fsh

    async def node_fn(inputs: dict) -> dict:
        return {}

    wrapped = make_node_wrapper(node_fn, tracks_row=True)

    ctx = _make_ctx(table_id=2)
    token = dec._active_run_ctx.set(ctx)
    try:
        await wrapped({"row_id": "8"})  # string row_id
    finally:
        dec._active_run_ctx.reset(token)

    # String row_id "8" is coerced to int 8 before calling flush_single_row_history.
    mock_fsh.assert_called_once()
    call = mock_fsh.call_args
    assert call.args[2] == 8  # coerced to int
    assert call.kwargs.get("node_slot") is not None


# ---------------------------------------------------------------------------
# Missing row_id: no row_run_status events (no crash)
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_tracks_row_no_op_when_row_id_missing(_patch_broadcast):
    mock_manager = _patch_broadcast

    async def node_fn(inputs: dict) -> dict:
        return {}

    wrapped = make_node_wrapper(node_fn, tracks_row=True)

    ctx = _make_ctx(table_id=5)
    token = dec._active_run_ctx.set(ctx)
    try:
        await wrapped({})  # no row_id at all
    finally:
        dec._active_run_ctx.reset(token)

    row_status_calls = [
        c
        for c in mock_manager.broadcast.call_args_list
        if c.args and c.args[0].startswith("table:")
    ]
    assert row_status_calls == []


# ---------------------------------------------------------------------------
# Scenario 1: node A (tracks_row=True) calls sub-nodes B (tracks_row=False)
# Only A should emit row status events; B must never touch row status,
# even when B fails and the exception cascades up to A.
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_sub_node_does_not_emit_row_status(_patch_broadcast, _patch_fsh):
    """node B (tracks_row=False) called inside A — only A calls flush_single_row_history."""
    mock_manager = _patch_broadcast
    mock_fsh = _patch_fsh

    async def b_fn(inputs: dict) -> dict:
        return {"b": "done"}

    node_b = make_node_wrapper(b_fn, tracks_row=False)

    async def a_fn(inputs: dict) -> dict:
        await node_b({"x": 1})
        await node_b({"x": 2})
        await node_b({"x": 3})
        return {"a": "done"}

    node_a = make_node_wrapper(a_fn, tracks_row=True)

    ctx = _make_ctx(table_id=10)
    token = dec._active_run_ctx.set(ctx)
    try:
        result = await node_a({"row_id": 7})
    finally:
        dec._active_run_ctx.reset(token)

    assert result == {"a": "done"}

    # Only A (tracks_row=True) calls flush_single_row_history — B (tracks_row=False) never does.
    mock_fsh.assert_called_once()
    call = mock_fsh.call_args
    assert call.args[1] == 10  # table_id
    assert call.args[2] == 7  # row_id
    assert call.kwargs.get("failed_exc") is None
    assert call.kwargs.get("node_slot") is not None
    # No row_run_status broadcasts.
    table_calls = [
        c
        for c in mock_manager.broadcast.call_args_list
        if c.args and c.args[0] == "table:10"
    ]
    assert table_calls == []


@pytest.mark.asyncio
async def test_sub_node_failure_cascades_to_parent_row_status(
    _patch_broadcast, _patch_fsh
):
    """When B fails inside A (tracks_row=True), A calls flush_single_row_history with the error."""
    mock_manager = _patch_broadcast
    mock_fsh = _patch_fsh

    async def b_fn(inputs: dict) -> dict:
        raise RuntimeError("B broke")

    node_b = make_node_wrapper(b_fn, tracks_row=False)

    async def a_fn(inputs: dict) -> dict:
        await node_b({"x": 1})
        return {}

    node_a = make_node_wrapper(a_fn, tracks_row=True)

    ctx = _make_ctx(table_id=10)
    token = dec._active_run_ctx.set(ctx)
    with pytest.raises(RuntimeError, match="B broke"):
        try:
            await node_a({"row_id": 9})
        finally:
            dec._active_run_ctx.reset(token)

    # A calls flush_single_row_history with the exception B raised.
    mock_fsh.assert_called_once()
    call = mock_fsh.call_args
    assert call.args[1] == 10  # table_id
    assert call.args[2] == 9  # row_id
    assert isinstance(call.kwargs.get("failed_exc"), RuntimeError)
    assert call.kwargs.get("node_slot") is not None


# ---------------------------------------------------------------------------
# Scenario 2: node C (no tracks_row) calls node D (tracks_row=True)
# D should correctly read table_action_context from the run-level metadata
# and track the row, regardless of C being the direct parent.
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_deeply_nested_tracks_row_node_reads_run_context(
    _patch_broadcast, _patch_fsh
):
    """D (tracks_row=True) called inside C (no tracks_row) still tracks the row correctly."""
    mock_manager = _patch_broadcast
    mock_fsh = _patch_fsh

    async def d_fn(inputs: dict) -> dict:
        return {"d": "done"}

    node_d = make_node_wrapper(d_fn, tracks_row=True)

    async def c_fn(inputs: dict) -> dict:
        # C passes row_id through to D
        await node_d({"row_id": inputs["row_id"], "extra": "data"})
        return {"c": "done"}

    node_c = make_node_wrapper(c_fn, tracks_row=False)

    ctx = _make_ctx(table_id=20)
    token = dec._active_run_ctx.set(ctx)
    try:
        result = await node_c({"row_id": 13})
    finally:
        dec._active_run_ctx.reset(token)

    assert result == {"c": "done"}

    # D (tracks_row=True) calls flush_single_row_history — C (tracks_row=False) does not.
    mock_fsh.assert_called_once()
    call = mock_fsh.call_args
    assert call.args[1] == 20  # table_id
    assert call.args[2] == 13  # row_id
    assert call.kwargs.get("failed_exc") is None
    assert call.kwargs.get("node_slot") is not None

    # No row_run_status broadcasts.
    table_calls = [
        c
        for c in mock_manager.broadcast.call_args_list
        if c.args and c.args[0] == "table:20"
    ]
    assert table_calls == []


@pytest.mark.asyncio
async def test_deeply_nested_tracks_row_node_failure(_patch_broadcast, _patch_fsh):
    """D (tracks_row=True) failing inside C calls flush_single_row_history with the error."""
    mock_manager = _patch_broadcast
    mock_fsh = _patch_fsh

    async def d_fn(inputs: dict) -> dict:
        raise ValueError("D failed")

    node_d = make_node_wrapper(d_fn, tracks_row=True)

    async def c_fn(inputs: dict) -> dict:
        await node_d({"row_id": inputs["row_id"]})
        return {}

    node_c = make_node_wrapper(c_fn, tracks_row=False)

    ctx = _make_ctx(table_id=20)
    token = dec._active_run_ctx.set(ctx)
    with pytest.raises(ValueError, match="D failed"):
        try:
            await node_c({"row_id": 14})
        finally:
            dec._active_run_ctx.reset(token)

    # D calls flush_single_row_history with the exception it raised.
    mock_fsh.assert_called_once()
    call = mock_fsh.call_args
    assert call.args[1] == 20  # table_id
    assert call.args[2] == 14  # row_id
    assert isinstance(call.kwargs.get("failed_exc"), ValueError)
    assert call.kwargs.get("node_slot") is not None
