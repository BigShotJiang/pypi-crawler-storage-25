"""Rich Editor package."""
