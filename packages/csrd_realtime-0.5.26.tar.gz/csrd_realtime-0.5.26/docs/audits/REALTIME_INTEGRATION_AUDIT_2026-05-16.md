# Realtime Integration Audit — 2026-05-16

## Scope

Target: `csrd-realtime` (`packages/realtime`)

Audit goal:

- Determine integration compatibility with all current `csrd-*` packages
- Identify required, optional, and no-op integration surfaces
- Rank findings by severity and provide rollout actions

## Method

- Reviewed package docs and public API surfaces across all workspace packages
- Reviewed versioning dispatch/mount behavior for websocket compatibility
- Reviewed realtime package API/design/implementation alignment
- Validated with targeted lint/type/tests where behavior changed

## Package-by-package integration surface matrix

| Package | Integration surface with `csrd-realtime` | Level | Notes |
|---|---|---|---|
| `csrd-auth` | Handshake JWT auth + per-message policy callbacks | Optional/Recommended | Keep auth in consumer layer; pass claims into `ConnectionContext` |
| `csrd-context` | Optional adapter for per-message context binding | Optional | Do not make `csrd-realtime` depend directly on `csrd-context` |
| `csrd` (meta) | Optional future inclusion in meta dependency set | Optional | Not required for realtime correctness |
| `csrd-delegate` | Worker/service callback patterns (emit events to WS-facing service) | Optional | Useful for async/event workflows |
| `csrd-lifespan` | Optional startup/shutdown wiring for manager/router singletons | Optional/Recommended | Good ergonomics for FastAPI apps |
| `csrd-logging` | Context-enriched WS logging in consumer service | Optional/Recommended | Pair with context adapter for better traceability |
| `csrd-message` | Cross-service event ingress to WS broadcast layer | Optional/Future scale | Not required for single-service WS flows |
| `csrd-metrics` | Future connection/send failure metrics hooks | Optional/Future | Stub package today |
| `csrd-migration` | None (transport library) | None | No persistence in v1 |
| `csrd-models` | None required; keep realtime models local | None (intentional) | `ConnectionContext` / `MessageEnvelope` should remain in realtime |
| `csrd-repository` | None in core; consumer services may persist events/sessions | Optional (consumer-level) | Out of scope for realtime core |
| `csrd-scheduler` | Future timed fan-out/heartbeat orchestration | Optional/Future | Stub package today |
| `csrd-service` | Optional use in WS-facing app service architecture | Optional | Service errors mostly HTTP-oriented |
| `csrd-testing` | Future websocket test helpers | Optional/Future | Stub package today |
| `csrd-utils` | Generator/augment integration (`realtime-websocket`) | Required for scaffold support | Planned in `packages/utils/docs/REALTIME_AUGMENT_PLAN.md` |
| `csrd-versioning` | Prefix/version dispatch for websocket paths | Required in versioned APIs | WebSocket dispatch support added and tested |

## Findings (severity-ranked)

### High

1. **Versioning websocket dispatch compatibility was incomplete (fixed)**
   - `VersionDispatchMiddleware` originally handled only HTTP scopes.
   - Prefix stripping in dependency wiring did not include `WebSocketRoute`.
   - Impact: versioned websocket endpoints could misroute or fail under composed versioned apps.
   - Status: **Fixed** with tests in `packages/versioning/tests/test_dispatch.py`.

### Medium

2. **Gateway websocket proxy contract definition**
   - Current gateway flow is HTTP-route-centric (`gateway-routes.yaml`).
   - v1 mode has now been explicitly locked to direct-to-service websocket connections.
   - Impact addressed by removing ambiguous gateway expectation from v1 rollout.
   - Status: **Fixed** in `packages/utils/docs/REALTIME_AUGMENT_PLAN.md`.

3. **Realtime-context adapter pattern standardization**
   - Added optional `RealtimeContextAdapter` and dispatch context model in core package.
   - Added docs pattern for binding/resetting external contextvars around dispatch.
   - Status: **Fixed** in `packages/realtime/src/csrd/realtime/context_adapter.py` and README.

### Low

4. **Meta package (`csrd`) realtime inclusion**
   - Added `csrd-realtime` to meta package dependencies and README.
   - Status: **Fixed** in `packages/csrd/pyproject.toml`.

## Design boundary decisions

- Keep `ConnectionContext` and `MessageEnvelope` in `csrd-realtime` (do not move to `csrd-models`).
- Keep `csrd-realtime` standalone (no direct dependency on `csrd-context`/`csrd-auth` in core).
- Integrate auth/context/logging via consumer-level adapters/hooks.

## Validation summary

Commands executed during the audit/fix cycle:

- `ruff check packages/realtime --config pyproject.toml`
- `python -m mypy packages/realtime/src`
- `python -m pytest packages/realtime/tests -q`
- `ruff check packages/versioning --config pyproject.toml`
- `python -m mypy packages/versioning/src`
- `python -m pytest packages/versioning/tests/test_dispatch.py -q`

Result: passing at package scope for touched areas.

## Recommended rollout order

1. Implement `csrd-utils` `realtime-websocket` augment (`U0`-`U3`) using locked v1 direct-connect WS mode.
2. Add package capability/docs updates in utils and service templates.
3. Keep distributed fan-out and gateway WS proxy upgrade relay as explicit follow-up milestones.
