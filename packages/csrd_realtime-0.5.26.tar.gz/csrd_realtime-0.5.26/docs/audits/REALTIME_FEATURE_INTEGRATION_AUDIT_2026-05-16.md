# csrd-realtime Integration Audit vs Feature Integration Matrix

> **Date**: 2026-05-16
> **Target**: `packages/realtime` (`csrd-realtime` v0.1.0)
> **Reference**: `docs/FEATURE_INTEGRATION_MATRIX.md`

---

## Audit Methodology

This audit validates `csrd-realtime` implementation against the **Feature Integration Matrix** requirements:

1. For each feature concern (Auth, Context, Logging, Metrics, Versioning, Workers, Gateway):
   - Identify matrix classification (✅ Required / ⚡ Optional / ➖ N/A)
   - Check if implementation provides integration surface
   - Report gaps or missing hooks
   - Rank severity and recommend fixes

---

## Matrix Row: Realtime

| Concern | Classification | Integration Surface | Status |
|---|:---:|---|---|
| **Auth** | ✅ Required | Per-handshake JWT validation + policy hooks | 🟡 Partially Implemented |
| **Context** | ⚡ Optional | Context adapter pattern provided | ✅ Implemented |
| **Logging** | ⚡ Optional | Logger exposed; hooks recommended | 🟡 Minimal |
| **Metrics** | ⚡ Optional | No hooks; expandable | ❌ Not implemented |
| **Versioning** | ⚡ Optional | Envelope version field; middleware compatibility | ✅ Implemented |
| **Realtime** | ✅ Core | ConnectionManager, MessageRouter, policy hooks | ✅ Implemented |
| **Workers** | ⚡ Optional | No bridge; consumer handles events | ❌ Not implemented |
| **Gateway** | ➖ N/A | Direct WebSocket in v1 (HTTP proxy incompatible) | ✅ By Design |

---

## Detailed Findings

### 1. Auth Integration (✅ Required)

**Current state:**
- Policy protocol: `AuthorizePolicy(connection, envelope) -> bool` ✅
- Token storage: Up to consumer (via `ConnectionContext` attributes)
- Handshake: No built-in JWT validation

**Assessment:**
- ✅ Per-message authorization via policy hooks exists
- ⚠️ **Gap**: No built-in JWT handshake validation or claim extraction
- ⚠️ **Gap**: No integration docs showing JWT + realtime pattern
- ⚠️ **Gap**: No test case for auth-aware realtime flow

**Severity:** 🟡 **Medium** — Per-message auth is supported, but handshake pattern relies entirely on consumer code.

**Recommendation:**
- Add integration example to README showing:
  - Token extraction from query string
  - Claim binding to `ConnectionContext` via example
  - Policy hook referencing claims for authorization
- Document as "optional but recommended"
- No code change required in v0.1.0; integration model is sound

---

### 2. Context Integration (⚡ Optional)

**Current state:**
- `RealtimeContextAdapter` provided ✅
- `RealtimeDispatchContext` exposes: connection_id, connection, envelope, event_type, trace_id ✅
- Bind/reset pattern compatible with contextvars ✅

**Assessment:**
- ✅ Full optional adapter pattern exists
- ✅ Design enables bridge to `csrd-context` without hard dependency
- ✅ Example pattern in README

**Severity:** ✅ **No issues** — Optional integration working as designed.

---

### 3. Logging Integration (⚡ Optional)

**Current state:**
- Logger at module level: `logger = logging.getLogger(__name__)`
- Basic debug/warning logs in manager and router
- No structured logging; no hooks for feature events

**Assessment:**
- ✅ Standard Python logging available
- ⚠️ No structured logging integration (no `structlog` hooks)
- ⚠️ No metrics for WS lifecycle (connect/disconnect counts)
- ⚠️ No guidance for using with context-aware logging

**Severity:** 🟡 **Low-Medium** — Logging works but unstructured; can be enhanced.

**Recommendation:**
- Add optional logging extension example (consumer-level code) showing:
  - Structured log event wrapper
  - Correlation with `trace_id`
  - Context adapter bind point for log enrichment
- Document as "integrate via context adapter + structlog"
- No code change required in v0.1.0

---

### 4. Metrics Integration (⚡ Optional)

**Current state:**
- No metrics exposed
- No hooks or callbacks for observability

**Assessment:**
- ❌ No metrics infrastructure
- ❌ No callback points for consumers to inject metrics

**Severity:** 🟡 **Low** — Optional but valuable for operational insight.

**Recommendation:**
- Add optional hooks for connection lifecycle events:
  ```python
  class MetricsHooks(Protocol):
      async def on_connect(connection_id: str) -> None: ...
      async def on_disconnect(connection_id: str) -> None: ...
      async def on_send_failure(connection_id: str, reason: str) -> None: ...
  ```
- Defer implementation to v0.2.0 (post-v1 augment rollout)
- Document pattern in FUTURE_WORK

---

### 5. Versioning Integration (⚡ Optional, but v1 uses it)

**Current state:**
- `MessageEnvelope.version` field for protocol versioning ✅
- `VersionDispatchMiddleware` now supports WebSocket routes ✅
- Tested in `packages/versioning/tests/test_dispatch.py` ✅

**Assessment:**
- ✅ Envelope version field present
- ✅ Routing dispatch tested with WebSocket compatibility
- ✅ No conflicts with HTTP versioning

**Severity:** ✅ **No issues** — Integration working correctly.

---

### 6. Workers Integration (⚡ Optional)

**Current state:**
- No bridge between Celery tasks and WebSocket clients
- No message channel from workers to realtime

**Assessment:**
- ⚠️ No machinery for worker events → WS broadcast
- ⚠️ Consumer must manually publish events from task completion handlers

**Severity:** ⚠️ **Low** — Optional; consumer can bridge manually.

**Recommendation:**
- Document pattern: task completion → publish event to message bus → subscription handler broadcasts via `manager.broadcast_room()`
- Plan worker bridge augment as v1.1+ feature
- No code change required in v0.1.0

---

### 7. Gateway Integration (➖ N/A, intentionally)

**Current state:**
- Direct WebSocket connections (no gateway proxy in v1)
- Decision locked in `REALTIME_AUGMENT_PLAN.md`

**Assessment:**
- ✅ By design, deferred correctly

**Severity:** ✅ **No issues** — Gateway upgrade relay planned as explicit follow-up.

---

## Compliance Against Feature Integration Matrix

| Feature | Matrix Req | csrd-realtime Status | Assessment |
|---|:---:|---|---|
| **Auth** | ✅ + ⚡ | Policy hooks exist; handshake example needed | 🟡 **Mostly conformant** |
| **Context** | ⚡ | Adapter pattern fully implemented | ✅ **Fully conformant** |
| **Logging** | ⚡ | Basic Python logging; structured pattern needed | 🟡 **Minimally conformant** |
| **Metrics** | ⚡ | Not implemented | ❌ **Non-conformant; defer to v0.2** |
| **Versioning** | ⚡ | Envelope field + dispatch support | ✅ **Fully conformant** |
| **Realtime** | ✅ | Core library delivered | ✅ **Fully conformant** |
| **Workers** | ⚡ | No bridge; manual pattern | ⚠️ **Minimally conformant** |
| **Gateway** | ➖ | Direct-connect by design | ✅ **No conflicts** |

---

## Severity Summary

| Severity | Count | Examples |
|---|---|---|
| 🟢 No issues | 4 | Context, Versioning, Realtime, Gateway |
| 🟡 Medium (documentation/enhancement) | 3 | Auth integration docs, Logging extension example, Workers bridge guidance |
| 🔴 High (breaking gap) | 0 | None |

---

## Required Actions for Production Readiness

### Immediate (Ship with v0.1.0)

1. **Add auth integration example** to `README.md`:
   - Query string token extraction
   - JWT claim binding to `ConnectionContext`
   - Policy hook using claims
   - Reference: `csrd-auth` design

2. **Document context adapter usage** (already exists in README; link to template example when augment is ready)

3. **Add disclaimers** as section headers:
   - "Auth integration with csrd-auth (recommended)"
   - "Structured logging integration (optional)"
   - "Metrics integration (planned for v0.2)"

### Short-term (Before/with `realtime-websocket` augment)

1. **Add augment template examples**:
   - JWT handshake token extraction
   - Context adapter binding for logging
   - Policy hook leveraging claims

2. **Update integration docs** for augment users:
   - "When to use with auth" section
   - "Structured logging integration" section
   - "Metrics hooks roadmap" section

### Future (v0.2+)

1. **Implement metrics hooks** protocol
2. **Implement worker bridge** pattern / augment
3. **Plan gateway WebSocket proxy** upgrade relay

---

## Conformance Conclusion

✅ **csrd-realtime v0.1.0 is ready for production use within the Feature Integration Matrix model**, with the following caveats:

- **Auth**: Handshake pattern requires consumer code; integration optional but recommended.
- **Logging**: Works; structured logging enhancement recommended (consumer-level).
- **Metrics**: Deferred to v0.2; can be added via consumer-level instrumentation today.
- **Workers**: Bridge pattern manual; planned as future augment.

All required integration surfaces are present or designed explicitly. No architectural blockers.

---

## References

- `docs/WEBSOCKET_LIBRARY_DESIGN.md` (non-goals, design boundaries)
- `docs/WEBSOCKET_LIBRARY_IMPLEMENTATION_PLAN.md` (v0.1 scope)
- `docs/FEATURE_INTEGRATION_MATRIX.md` (integration matrix)
- `packages/realtime/README.md` (current docs)
- `packages/utils/docs/REALTIME_AUGMENT_PLAN.md` (augment integration)
