"""Tests for MessageRouter policy integration."""

from unittest.mock import AsyncMock

import pytest

from csrd.realtime import ConnectionContext, ConnectionManager, MessageEnvelope, MessageRouter
from csrd.realtime.errors import EnvelopeValidationError, PolicyDeniedError


@pytest.fixture
def manager() -> ConnectionManager:
    return ConnectionManager()


@pytest.fixture
def envelope() -> MessageEnvelope:
    return MessageEnvelope(type="chat.message", payload={"text": "hi"})


@pytest.fixture
async def connected_manager(manager: ConnectionManager) -> ConnectionManager:
    ws = AsyncMock()
    ctx = ConnectionContext(connection_id="conn-1", tenant_id="t1", user_id="u1")
    await manager.connect(ws, ctx)
    return manager


async def test_authorize_policy_denies(
    connected_manager: ConnectionManager, envelope: MessageEnvelope
):
    async def deny_auth(_ctx: ConnectionContext, _env: MessageEnvelope) -> bool:
        return False

    router = MessageRouter(authorize_policy=deny_auth)

    with pytest.raises(PolicyDeniedError, match="authorize"):
        await router.dispatch("conn-1", envelope, connected_manager)


async def test_rate_limit_policy_denies(
    connected_manager: ConnectionManager, envelope: MessageEnvelope
):
    async def deny_rate(_ctx: ConnectionContext, _env: MessageEnvelope) -> bool:
        return False

    router = MessageRouter(rate_limit_policy=deny_rate)

    with pytest.raises(PolicyDeniedError, match="rate_limit"):
        await router.dispatch("conn-1", envelope, connected_manager)


async def test_validate_policy_failure_maps_to_envelope_error(
    connected_manager: ConnectionManager, envelope: MessageEnvelope
):
    async def invalid(_env: MessageEnvelope) -> None:
        raise ValueError("missing required field")

    router = MessageRouter(validate_policy=invalid)

    with pytest.raises(EnvelopeValidationError, match="missing required field"):
        await router.dispatch("conn-1", envelope, connected_manager)


async def test_policy_allow_path_dispatches_handler(
    connected_manager: ConnectionManager, envelope: MessageEnvelope
):
    handled: list[str] = []

    async def allow_auth(_ctx: ConnectionContext, _env: MessageEnvelope) -> bool:
        return True

    async def allow_rate(_ctx: ConnectionContext, _env: MessageEnvelope) -> bool:
        return True

    async def validate_ok(_env: MessageEnvelope) -> None:
        return None

    async def handler(
        connection_id: str, _envelope: MessageEnvelope, _manager: ConnectionManager
    ) -> None:
        handled.append(connection_id)

    router = MessageRouter(
        authorize_policy=allow_auth,
        validate_policy=validate_ok,
        rate_limit_policy=allow_rate,
    )
    router.register("chat.message", handler)

    await router.dispatch("conn-1", envelope, connected_manager)

    assert handled == ["conn-1"]
