"""Lightweight integration flow tests for csrd.realtime."""

from dataclasses import dataclass, field
from typing import Any

from starlette.websockets import WebSocketDisconnect

from csrd.realtime import ConnectionContext, ConnectionManager, MessageEnvelope, MessageRouter


@dataclass
class FakeWebSocket:
    """Small test double for websocket receive/send flow."""

    incoming: list[dict[str, Any]]
    accepted: bool = False
    sent: list[dict[str, Any]] = field(default_factory=list)

    async def accept(self) -> None:
        self.accepted = True

    async def receive_json(self) -> dict[str, Any]:
        if self.incoming:
            return self.incoming.pop(0)
        raise WebSocketDisconnect(code=1000)

    async def send_json(self, data: dict[str, Any]) -> None:
        self.sent.append(data)


async def _run_ws_session(
    ws: FakeWebSocket,
    manager: ConnectionManager,
    router: MessageRouter,
    *,
    connection_id: str,
) -> None:
    """Reference websocket endpoint loop using realtime primitives."""
    await ws.accept()
    context = ConnectionContext(connection_id=connection_id, tenant_id="tenant-1")
    cid = await manager.connect(ws, context)
    try:
        while True:
            data = await ws.receive_json()
            envelope = MessageEnvelope.model_validate(data)
            await router.dispatch(cid, envelope, manager)
    except WebSocketDisconnect:
        pass
    finally:
        await manager.disconnect(cid)


async def test_lightweight_ws_flow_echo_ack() -> None:
    """Inbound message dispatches handler and sends an ack response."""
    manager = ConnectionManager()
    router = MessageRouter()

    async def echo_handler(
        connection_id: str,
        envelope: MessageEnvelope,
        manager: ConnectionManager,
    ) -> None:
        response = MessageEnvelope(type="chat.ack", payload={"echo": envelope.payload})
        await manager.send_to(connection_id, response)

    router.register("chat.echo", echo_handler)

    ws = FakeWebSocket(incoming=[{"type": "chat.echo", "payload": {"text": "hello"}}])
    await _run_ws_session(ws, manager, router, connection_id="conn-1")

    assert ws.accepted is True
    assert len(ws.sent) == 1
    assert ws.sent[0]["type"] == "chat.ack"
    assert ws.sent[0]["payload"] == {"echo": {"text": "hello"}}

    stats = await manager.stats()
    assert stats["connection_count"] == 0
