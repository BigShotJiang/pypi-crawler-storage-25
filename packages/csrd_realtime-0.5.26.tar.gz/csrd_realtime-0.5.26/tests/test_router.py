"""Tests for csrd.realtime message router."""

from unittest.mock import AsyncMock

import pytest

from csrd.realtime import (
    ConnectionContext,
    ConnectionManager,
    MessageEnvelope,
    MessageRouter,
)


@pytest.fixture
def router():
    """Create a fresh MessageRouter for each test."""
    return MessageRouter()


@pytest.fixture
def manager():
    """Create a fresh ConnectionManager for each test."""
    return ConnectionManager()


@pytest.fixture
def envelope():
    """Create a sample message envelope."""
    return MessageEnvelope(type="test_event", payload={"key": "value"})


class TestRouterRegistration:
    """Test handler registration."""

    async def test_register_handler(self, router):
        """register() stores a handler."""
        handler = AsyncMock()
        router.register("test_event", handler)
        assert "test_event" in router._handlers

    async def test_register_multiple_handlers(self, router):
        """Multiple handlers can be registered for different event types."""
        handler1 = AsyncMock()
        handler2 = AsyncMock()
        router.register("event1", handler1)
        router.register("event2", handler2)
        assert len(router._handlers) == 2


class TestRouterDispatch:
    """Test message dispatch."""

    async def _register_connection(self, manager: ConnectionManager) -> None:
        ws = AsyncMock()
        ctx = ConnectionContext(connection_id="conn-1")
        await manager.connect(ws, ctx)

    async def test_dispatch_calls_handler(self, router, manager, envelope):
        """dispatch() invokes the registered handler."""
        handler = AsyncMock()
        router.register("test_event", handler)

        await self._register_connection(manager)

        await router.dispatch("conn-1", envelope, manager)
        handler.assert_called_once_with("conn-1", envelope, manager)

    async def test_dispatch_unknown_event(self, router, manager, envelope):
        """dispatch() logs warning for unknown event types (doesn't crash)."""
        envelope_unknown = MessageEnvelope(type="unknown_event", payload={"key": "value"})
        await self._register_connection(manager)
        # Should not raise
        await router.dispatch("conn-1", envelope_unknown, manager)

    async def test_dispatch_handler_exception_raises_by_default(self, router, manager, envelope):
        """dispatch() surfaces handler exceptions by default."""
        handler = AsyncMock(side_effect=ValueError("Test error"))
        router.register("test_event", handler)

        await self._register_connection(manager)

        with pytest.raises(ValueError, match="Test error"):
            await router.dispatch("conn-1", envelope, manager)

    async def test_dispatch_handler_exception_can_be_suppressed(self, manager, envelope):
        """dispatch() can log-and-continue when suppression mode is enabled."""
        router = MessageRouter(raise_handler_exceptions=False)
        handler = AsyncMock(side_effect=ValueError("Test error"))
        router.register("test_event", handler)

        await self._register_connection(manager)

        # Should not raise in suppression mode
        await router.dispatch("conn-1", envelope, manager)
        handler.assert_called_once()
