"""Tests for optional realtime context adapter integration."""

from unittest.mock import AsyncMock

import pytest

from csrd.realtime import (
    ConnectionContext,
    ConnectionManager,
    MessageEnvelope,
    MessageRouter,
    RealtimeContextAdapter,
)


async def test_context_adapter_bind_and_reset_around_handler() -> None:
    manager = ConnectionManager()
    ws = AsyncMock()
    await manager.connect(ws, ConnectionContext(connection_id="conn-1", tenant_id="t1"))

    envelope = MessageEnvelope(type="chat.message", payload={"text": "hello"}, trace_id="tr-1")

    events: list[str] = []
    captured: dict[str, str] = {}

    def bind(ctx):
        events.append("bind")
        captured["connection_id"] = ctx.connection_id
        captured["event_type"] = ctx.event_type
        captured["trace_id"] = ctx.trace_id or ""
        return "token-1"

    def reset(token):
        events.append(f"reset:{token}")

    adapter = RealtimeContextAdapter(bind=bind, reset=reset)
    router = MessageRouter(context_adapter=adapter)

    async def handler(connection_id: str, _env: MessageEnvelope, _manager: ConnectionManager):
        events.append(f"handler:{connection_id}")

    router.register("chat.message", handler)
    await router.dispatch("conn-1", envelope, manager)

    assert events == ["bind", "handler:conn-1", "reset:token-1"]
    assert captured == {
        "connection_id": "conn-1",
        "event_type": "chat.message",
        "trace_id": "tr-1",
    }


async def test_context_adapter_resets_when_handler_raises() -> None:
    manager = ConnectionManager()
    ws = AsyncMock()
    await manager.connect(ws, ConnectionContext(connection_id="conn-1"))

    envelope = MessageEnvelope(type="chat.fail", payload={})

    events: list[str] = []

    adapter = RealtimeContextAdapter(
        bind=lambda _ctx: "token-x",
        reset=lambda token: events.append(f"reset:{token}"),
    )
    router = MessageRouter(context_adapter=adapter, raise_handler_exceptions=True)

    async def failing_handler(
        _connection_id: str, _env: MessageEnvelope, _manager: ConnectionManager
    ):
        raise ValueError("boom")

    router.register("chat.fail", failing_handler)

    with pytest.raises(ValueError, match="boom"):
        await router.dispatch("conn-1", envelope, manager)

    assert events == ["reset:token-x"]
