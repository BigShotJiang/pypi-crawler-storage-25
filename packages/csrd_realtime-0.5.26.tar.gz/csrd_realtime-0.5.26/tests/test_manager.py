"""Tests for csrd.realtime connection manager."""

import asyncio
from unittest.mock import AsyncMock

import pytest

from csrd.realtime import ConnectionContext, ConnectionManager, MessageEnvelope
from csrd.realtime.errors import ConnectionNotFoundError


@pytest.fixture
def manager():
    """Create a fresh ConnectionManager for each test."""
    return ConnectionManager()


@pytest.fixture
def context():
    """Create a sample connection context."""
    return ConnectionContext(
        connection_id="test-conn-1",
        tenant_id="tenant-1",
        user_id="user-1",
        scopes={"read", "write"},
    )


@pytest.fixture
def envelope():
    """Create a sample message envelope."""
    return MessageEnvelope(type="test_event", payload={"key": "value"})


class TestConnectionLifecycle:
    """Test connect/disconnect lifecycle."""

    async def test_connect_registers_connection(self, manager, context):
        """Connection.connect() registers and returns the connection_id."""
        mock_ws = AsyncMock()
        cid = await manager.connect(mock_ws, context)
        assert cid == "test-conn-1"

    async def test_disconnect_removes_connection(self, manager, context):
        """Connection.disconnect() removes a connection."""
        mock_ws = AsyncMock()
        await manager.connect(mock_ws, context)
        await manager.disconnect("test-conn-1")

        with pytest.raises(ConnectionNotFoundError):
            await manager.disconnect("test-conn-1")

    async def test_disconnect_nonexistent_raises(self, manager):
        """Disconnecting a nonexistent connection raises error."""
        with pytest.raises(ConnectionNotFoundError):
            await manager.disconnect("nonexistent")

    async def test_connect_duplicate_raises(self, manager, context):
        """Connecting with duplicate connection_id raises error."""
        mock_ws = AsyncMock()
        await manager.connect(mock_ws, context)

        with pytest.raises(ValueError, match="already registered"):
            await manager.connect(mock_ws, context)


class TestRooms:
    """Test room membership."""

    async def test_join_room(self, manager, context):
        """join_room() adds connection to a room."""
        mock_ws = AsyncMock()
        await manager.connect(mock_ws, context)
        await manager.join_room("test-conn-1", "room-1")

    async def test_leave_room(self, manager, context):
        """leave_room() removes connection from a room."""
        mock_ws = AsyncMock()
        await manager.connect(mock_ws, context)
        await manager.join_room("test-conn-1", "room-1")
        await manager.leave_room("test-conn-1", "room-1")

    async def test_room_cleanup_on_disconnect(self, manager, context):
        """Disconnecting cleans up room membership."""
        mock_ws = AsyncMock()
        await manager.connect(mock_ws, context)
        await manager.join_room("test-conn-1", "room-1")
        await manager.disconnect("test-conn-1")

        # After disconnect, should not be able to leave a room
        with pytest.raises(ConnectionNotFoundError):
            await manager.leave_room("test-conn-1", "room-1")


class TestBroadcast:
    """Test broadcast operations."""

    async def test_send_to_success(self, manager, context, envelope):
        """send_to() returns True on successful send."""
        mock_ws = AsyncMock()
        await manager.connect(mock_ws, context)
        result = await manager.send_to("test-conn-1", envelope)
        assert result is True
        mock_ws.send_json.assert_called_once()

    async def test_send_to_nonexistent_raises(self, manager, envelope):
        """send_to() raises on nonexistent connection."""
        with pytest.raises(ConnectionNotFoundError):
            await manager.send_to("nonexistent", envelope)

    async def test_send_to_timeout_evicts_connection(self, context, envelope):
        """send_to() evicts connection when send exceeds timeout."""
        manager = ConnectionManager(send_timeout_seconds=0.001)

        async def slow_send(_data):
            await asyncio.sleep(0.05)

        mock_ws = AsyncMock()
        mock_ws.send_json.side_effect = slow_send

        await manager.connect(mock_ws, context)
        result = await manager.send_to("test-conn-1", envelope)

        assert result is False
        with pytest.raises(ConnectionNotFoundError):
            await manager.get_context("test-conn-1")

    async def test_broadcast_room(self, manager, envelope):
        """broadcast_room() sends to all connections in a room."""
        mock_ws1 = AsyncMock()
        mock_ws2 = AsyncMock()

        ctx1 = ConnectionContext(connection_id="conn-1", tenant_id="t1")
        ctx2 = ConnectionContext(connection_id="conn-2", tenant_id="t1")

        await manager.connect(mock_ws1, ctx1)
        await manager.connect(mock_ws2, ctx2)
        await manager.join_room("conn-1", "room-1")
        await manager.join_room("conn-2", "room-1")

        delivered = await manager.broadcast_room("room-1", envelope)
        assert delivered == 2
        mock_ws1.send_json.assert_called_once()
        mock_ws2.send_json.assert_called_once()

    async def test_broadcast_room_with_exclude(self, manager, envelope):
        """broadcast_room() respects exclude set."""
        mock_ws1 = AsyncMock()
        mock_ws2 = AsyncMock()

        ctx1 = ConnectionContext(connection_id="conn-1")
        ctx2 = ConnectionContext(connection_id="conn-2")

        await manager.connect(mock_ws1, ctx1)
        await manager.connect(mock_ws2, ctx2)
        await manager.join_room("conn-1", "room-1")
        await manager.join_room("conn-2", "room-1")

        delivered = await manager.broadcast_room("room-1", envelope, exclude={"conn-2"})
        assert delivered == 1
        mock_ws1.send_json.assert_called_once()
        mock_ws2.send_json.assert_not_called()

    async def test_broadcast_all(self, manager, envelope):
        """broadcast_all() sends to all connections."""
        mock_ws1 = AsyncMock()
        mock_ws2 = AsyncMock()

        ctx1 = ConnectionContext(connection_id="conn-1")
        ctx2 = ConnectionContext(connection_id="conn-2")

        await manager.connect(mock_ws1, ctx1)
        await manager.connect(mock_ws2, ctx2)

        delivered = await manager.broadcast_all(envelope)
        assert delivered == 2

    async def test_broadcast_all_tenant_filtered(self, manager, envelope):
        """broadcast_all() filters by tenant_id when provided."""
        mock_ws1 = AsyncMock()
        mock_ws2 = AsyncMock()

        ctx1 = ConnectionContext(connection_id="conn-1", tenant_id="t1")
        ctx2 = ConnectionContext(connection_id="conn-2", tenant_id="t2")

        await manager.connect(mock_ws1, ctx1)
        await manager.connect(mock_ws2, ctx2)

        delivered = await manager.broadcast_all(envelope, tenant_id="t1")
        assert delivered == 1
        mock_ws1.send_json.assert_called_once()
        mock_ws2.send_json.assert_not_called()


class TestStats:
    """Test statistics."""

    async def test_stats_empty(self, manager):
        """stats() returns empty counts initially."""
        stats = await manager.stats()
        assert stats["connection_count"] == 0
        assert stats["room_count"] == 0

    async def test_stats_with_connections(self, manager):
        """stats() reports connection and room counts."""
        mock_ws1 = AsyncMock()
        mock_ws2 = AsyncMock()

        ctx1 = ConnectionContext(connection_id="conn-1", tenant_id="t1")
        ctx2 = ConnectionContext(connection_id="conn-2", tenant_id="t1")

        await manager.connect(mock_ws1, ctx1)
        await manager.connect(mock_ws2, ctx2)
        await manager.join_room("conn-1", "room-1")

        stats = await manager.stats()
        assert stats["connection_count"] == 2
        assert stats["room_count"] == 1
        assert stats["by_tenant"]["t1"] == 2
