"""Tests for csrd.realtime package."""
