"""Core data models for csrd.realtime."""

from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import Any


@dataclass
class ConnectionContext:
    """Per-connection metadata known to the manager.

    Attributes:
        connection_id: Unique identifier for this connection.
        tenant_id: Tenant scope (optional, for multi-tenant isolation).
        user_id: User identifier (optional).
        scopes: Authorization scopes (e.g., roles, permissions).
        attrs: Consumer-defined metadata (string-valued).
    """

    connection_id: str
    tenant_id: str | None = None
    user_id: str | None = None
    scopes: set[str] = field(default_factory=set)
    attrs: dict[str, str] = field(default_factory=dict)


@dataclass
class MessageEnvelope:
    """Transport envelope for real-time messages.

    Attributes:
        type: Event/message type (e.g., 'token_move', 'dice_roll').
        payload: Message content (any JSON-serializable dict).
        trace_id: Optional request correlation ID.
        timestamp: ISO8601 timestamp (set at creation if not provided).
        version: Consumer-defined protocol version (default: '1.0').
    """

    type: str
    payload: dict[str, Any]
    trace_id: str | None = None
    timestamp: str = field(default_factory=lambda: datetime.now(UTC).isoformat())
    version: str = "1.0"

    def model_dump(self) -> dict[str, Any]:
        """Convert to dict for JSON serialization."""
        return {
            "type": self.type,
            "payload": self.payload,
            "trace_id": self.trace_id,
            "timestamp": self.timestamp,
            "version": self.version,
        }

    @classmethod
    def model_validate(cls, data: dict[str, Any]) -> "MessageEnvelope":
        """Create from validated dict.

        Raises:
            ValueError: If required envelope fields are missing/invalid.
        """
        if not isinstance(data, dict):
            raise ValueError("Envelope must be a JSON object")

        msg_type = data.get("type")
        if not isinstance(msg_type, str) or not msg_type.strip():
            raise ValueError("Envelope 'type' must be a non-empty string")

        payload = data.get("payload")
        if not isinstance(payload, dict):
            raise ValueError("Envelope 'payload' must be an object")

        trace_id = data.get("trace_id")
        if trace_id is not None and not isinstance(trace_id, str):
            raise ValueError("Envelope 'trace_id' must be a string when provided")

        timestamp = data.get("timestamp")
        if timestamp is not None and not isinstance(timestamp, str):
            raise ValueError("Envelope 'timestamp' must be a string when provided")

        version = data.get("version")
        if version is not None and not isinstance(version, str):
            raise ValueError("Envelope 'version' must be a string when provided")

        return cls(
            type=msg_type,
            payload=payload,
            trace_id=trace_id,
            timestamp=timestamp or datetime.now(UTC).isoformat(),
            version=version or "1.0",
        )
