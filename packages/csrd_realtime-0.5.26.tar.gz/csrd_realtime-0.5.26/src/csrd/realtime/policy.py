"""Policy hook protocols for authorization, validation, and rate limiting."""

from typing import Protocol

from .models import ConnectionContext, MessageEnvelope


class AuthorizePolicy(Protocol):
    """Policy hook for per-message authorization.

    Invoked before routing dispatches a message. Return False to deny.
    """

    async def __call__(self, connection: ConnectionContext, envelope: MessageEnvelope) -> bool:
        """Authorize the message.

        Args:
            connection: Connection metadata.
            envelope: Message to authorize.

        Returns:
            True to allow, False to deny.
        """
        ...


class ValidatePolicy(Protocol):
    """Policy hook for message validation.

    Invoked before routing dispatches a message. Raise to reject.
    """

    async def __call__(self, envelope: MessageEnvelope) -> None:
        """Validate the message.

        Args:
            envelope: Message to validate.

        Raises:
            Exception: On validation failure.
        """
        ...


class RateLimitPolicy(Protocol):
    """Policy hook for per-connection rate limiting.

    Invoked before routing dispatches a message. Return False to rate-limit.
    """

    async def __call__(self, connection: ConnectionContext, envelope: MessageEnvelope) -> bool:
        """Check rate limit.

        Args:
            connection: Connection metadata.
            envelope: Message being sent.

        Returns:
            True to allow, False to rate-limit.
        """
        ...


class DefaultPolicies:
    """Default no-op policies (permissive)."""

    @staticmethod
    async def authorize_allow(connection: ConnectionContext, envelope: MessageEnvelope) -> bool:
        """Allow all messages."""
        return True

    @staticmethod
    async def validate_noop(envelope: MessageEnvelope) -> None:
        """No validation."""
        pass

    @staticmethod
    async def rate_limit_none(connection: ConnectionContext, envelope: MessageEnvelope) -> bool:
        """No rate limiting."""
        return True
