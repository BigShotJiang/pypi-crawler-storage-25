"""csrd WebSocket Library — real-time connection lifecycle and routing.

Provides generic WebSocket primitives: connection management, room broadcast,
message routing, and optional policy hooks.

See: docs/WEBSOCKET_LIBRARY_DESIGN.md
"""

from .context_adapter import (
    ContextBindCallback,
    ContextResetCallback,
    RealtimeContextAdapter,
    RealtimeDispatchContext,
)
from .errors import (
    ConnectionNotFoundError,
    EnvelopeValidationError,
    PolicyDeniedError,
    RealtimeError,
)
from .manager import ConnectionManager
from .models import ConnectionContext, MessageEnvelope
from .policy import AuthorizePolicy, DefaultPolicies, RateLimitPolicy, ValidatePolicy
from .router import MessageRouter

__version__ = "0.1.0"
__all__ = (
    "AuthorizePolicy",
    "ConnectionContext",
    "ConnectionManager",
    "ConnectionNotFoundError",
    "ContextBindCallback",
    "ContextResetCallback",
    "DefaultPolicies",
    "EnvelopeValidationError",
    "MessageEnvelope",
    "MessageRouter",
    "PolicyDeniedError",
    "RateLimitPolicy",
    "RealtimeContextAdapter",
    "RealtimeDispatchContext",
    "RealtimeError",
    "ValidatePolicy",
)
