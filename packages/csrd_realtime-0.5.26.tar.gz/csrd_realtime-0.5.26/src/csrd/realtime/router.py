"""Message routing: dispatch by event type to handlers."""

import logging
from collections.abc import Awaitable, Callable
from typing import Any

from .context_adapter import RealtimeContextAdapter, RealtimeDispatchContext
from .errors import EnvelopeValidationError, PolicyDeniedError
from .manager import ConnectionManager
from .models import MessageEnvelope
from .policy import AuthorizePolicy, DefaultPolicies, RateLimitPolicy, ValidatePolicy

logger = logging.getLogger(__name__)

# Handler signature: async def handle(connection_id, envelope, manager)
MessageHandler = Callable[[str, MessageEnvelope, ConnectionManager], Awaitable[Any]]


class MessageRouter:
    """Routes inbound messages to handlers by event type.

    Handlers are consumer-provided async callables that receive:
    - connection_id: unique connection identifier
    - envelope: the MessageEnvelope
    - manager: the ConnectionManager (for broadcasting, etc.)
    """

    def __init__(
        self,
        *,
        authorize_policy: AuthorizePolicy | None = None,
        validate_policy: ValidatePolicy | None = None,
        rate_limit_policy: RateLimitPolicy | None = None,
        context_adapter: RealtimeContextAdapter | None = None,
        raise_handler_exceptions: bool = True,
    ) -> None:
        """Initialize the router.

        Policy hooks are optional. If omitted, permissive defaults are used.
        """
        self._handlers: dict[str, MessageHandler] = {}
        self._authorize_policy = authorize_policy or DefaultPolicies.authorize_allow
        self._validate_policy = validate_policy or DefaultPolicies.validate_noop
        self._rate_limit_policy = rate_limit_policy or DefaultPolicies.rate_limit_none
        self._context_adapter = context_adapter
        self._raise_handler_exceptions = raise_handler_exceptions

    def register(self, event_type: str, handler: MessageHandler) -> None:
        """Register a handler for an event type.

        Args:
            event_type: Event type string (e.g., 'token_move').
            handler: Async callable(connection_id, envelope, manager).
        """
        self._handlers[event_type] = handler
        logger.debug(f"Registered handler for event type: {event_type}")

    async def dispatch(
        self,
        connection_id: str,
        envelope: MessageEnvelope,
        manager: ConnectionManager,
    ) -> None:
        """Dispatch a message to its registered handler.

        Args:
            connection_id: The sending connection.
            envelope: The message.
            manager: The ConnectionManager instance.

        Raises:
            EnvelopeValidationError: If validate_policy rejects the envelope.
            PolicyDeniedError: If authorize/rate limit policy denies.
        """
        context = await manager.get_context(connection_id)

        try:
            await self._validate_policy(envelope)
        except EnvelopeValidationError:
            raise
        except Exception as exc:
            raise EnvelopeValidationError(str(exc)) from exc

        if not await self._authorize_policy(context, envelope):
            raise PolicyDeniedError("authorize", "message not authorized")

        if not await self._rate_limit_policy(context, envelope):
            raise PolicyDeniedError("rate_limit", "rate limit exceeded")

        dispatch_context = RealtimeDispatchContext(
            connection_id=connection_id,
            connection=context,
            envelope=envelope,
            event_type=envelope.type,
            trace_id=envelope.trace_id,
        )

        handler = self._handlers.get(envelope.type)
        if handler is None:
            logger.warning(
                f"No handler for event type '{envelope.type}' (connection {connection_id})"
            )
            return

        try:
            if self._context_adapter is None:
                await handler(connection_id, envelope, manager)
            else:
                with self._context_adapter.bind_scope(dispatch_context):
                    await handler(connection_id, envelope, manager)
        except Exception as exc:
            if self._raise_handler_exceptions:
                raise
            logger.exception(f"Error dispatching {envelope.type} from {connection_id}: {exc}")
