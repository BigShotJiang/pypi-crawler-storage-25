"""Typed errors for csrd.realtime."""


class RealtimeError(Exception):
    """Base exception for csrd.realtime."""

    pass


class ConnectionNotFoundError(RealtimeError):
    """Connection with given ID not found."""

    def __init__(self, connection_id: str) -> None:
        self.connection_id = connection_id
        super().__init__(f"Connection not found: {connection_id}")


class EnvelopeValidationError(RealtimeError):
    """Message envelope failed validation."""

    def __init__(self, reason: str) -> None:
        self.reason = reason
        super().__init__(f"Envelope validation failed: {reason}")


class PolicyDeniedError(RealtimeError):
    """Policy hook denied the operation."""

    def __init__(self, policy: str, reason: str) -> None:
        self.policy = policy
        self.reason = reason
        super().__init__(f"Policy '{policy}' denied: {reason}")
