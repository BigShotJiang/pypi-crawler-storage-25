"""Connection lifecycle and room broadcast management."""

import asyncio
import logging
from contextlib import suppress
from typing import Any

from starlette.websockets import WebSocket, WebSocketDisconnect

from .errors import ConnectionNotFoundError
from .models import ConnectionContext, MessageEnvelope

logger = logging.getLogger(__name__)


class ConnectionManager:
    """Manages WebSocket connections, rooms, and broadcasts.

    Thread-safe in-memory registry of active connections organized by room.
    Handles connect/disconnect lifecycle, room membership, and best-effort
    broadcast delivery.
    """

    def __init__(self, *, send_timeout_seconds: float | None = 5.0) -> None:
        """Initialize the connection manager.

        Args:
            send_timeout_seconds: Timeout applied to each websocket send.
                ``None`` disables timeout enforcement.
        """
        # connection_id -> (websocket, context)
        self._connections: dict[str, tuple[WebSocket, ConnectionContext]] = {}
        # room -> set of connection_ids
        self._rooms: dict[str, set[str]] = {}
        # connection_id -> set of room names
        self._membership: dict[str, set[str]] = {}
        self._lock = asyncio.Lock()
        self._send_timeout_seconds = send_timeout_seconds

    async def connect(self, websocket: WebSocket, context: ConnectionContext) -> str:
        """Register a new connection.

        Args:
            websocket: Accepted Starlette WebSocket instance.
            context: ConnectionContext with metadata.

        Returns:
            connection_id from the context.

        Raises:
            ValueError: If connection_id is already registered.
        """
        async with self._lock:
            cid = context.connection_id
            if cid in self._connections:
                raise ValueError(f"Connection {cid} already registered")
            self._connections[cid] = (websocket, context)
            self._membership[cid] = set()
            logger.debug(f"Connection {cid} registered (tenant={context.tenant_id})")
            return cid

    async def disconnect(self, connection_id: str) -> None:
        """Unregister a connection and clean up room membership.

        Args:
            connection_id: The connection to remove.

        Raises:
            ConnectionNotFoundError: If connection not found.
        """
        async with self._lock:
            if connection_id not in self._connections:
                raise ConnectionNotFoundError(connection_id)

            # Remove from all rooms
            for room in list(self._membership[connection_id]):
                if room in self._rooms:
                    self._rooms[room].discard(connection_id)
                    if not self._rooms[room]:
                        del self._rooms[room]

            del self._connections[connection_id]
            del self._membership[connection_id]
            logger.debug(f"Connection {connection_id} disconnected")

    async def join_room(self, connection_id: str, room: str) -> None:
        """Add a connection to a room.

        Args:
            connection_id: The connection to add.
            room: Room identifier (consumer-defined, e.g., 'session:123').

        Raises:
            ConnectionNotFoundError: If connection not found.
        """
        async with self._lock:
            if connection_id not in self._connections:
                raise ConnectionNotFoundError(connection_id)

            if room not in self._rooms:
                self._rooms[room] = set()
            self._rooms[room].add(connection_id)
            self._membership[connection_id].add(room)
            logger.debug(f"Connection {connection_id} joined room {room}")

    async def leave_room(self, connection_id: str, room: str) -> None:
        """Remove a connection from a room.

        Args:
            connection_id: The connection to remove.
            room: Room identifier.

        Raises:
            ConnectionNotFoundError: If connection not found.
        """
        async with self._lock:
            if connection_id not in self._connections:
                raise ConnectionNotFoundError(connection_id)

            if room in self._rooms:
                self._rooms[room].discard(connection_id)
                if not self._rooms[room]:
                    del self._rooms[room]
            self._membership[connection_id].discard(room)
            logger.debug(f"Connection {connection_id} left room {room}")

    async def get_context(self, connection_id: str) -> ConnectionContext:
        """Return metadata context for a connection.

        Args:
            connection_id: Connection identifier.

        Returns:
            ConnectionContext for the target connection.

        Raises:
            ConnectionNotFoundError: If connection not found.
        """
        async with self._lock:
            if connection_id not in self._connections:
                raise ConnectionNotFoundError(connection_id)
            _, context = self._connections[connection_id]
            return context

    async def send_to(self, connection_id: str, envelope: MessageEnvelope) -> bool:
        """Send a message to a specific connection.

        Best-effort: on send failure, the connection is evicted.

        Args:
            connection_id: Target connection.
            envelope: Message to send.

        Returns:
            True if sent successfully, False if connection dead/evicted.

        Raises:
            ConnectionNotFoundError: If connection not found at call time.
        """
        async with self._lock:
            if connection_id not in self._connections:
                raise ConnectionNotFoundError(connection_id)
            ws, _ = self._connections[connection_id]

        try:
            if self._send_timeout_seconds is None:
                await ws.send_json(envelope.model_dump())
            else:
                async with asyncio.timeout(self._send_timeout_seconds):
                    await ws.send_json(envelope.model_dump())
            return True
        except (TimeoutError, WebSocketDisconnect, RuntimeError, Exception) as e:
            logger.debug(f"Send to {connection_id} failed: {e}, evicting")
            with suppress(ConnectionNotFoundError):
                await self.disconnect(connection_id)
            return False

    async def broadcast_room(
        self,
        room: str,
        envelope: MessageEnvelope,
        *,
        exclude: set[str] | None = None,
    ) -> int:
        """Broadcast a message to all connections in a room.

        Args:
            room: Room identifier.
            envelope: Message to broadcast.
            exclude: Optional set of connection_ids to skip.

        Returns:
            Number of connections the message was successfully sent to.
        """
        exclude = exclude or set()
        delivered = 0

        async with self._lock:
            if room not in self._rooms:
                return 0
            targets = self._rooms[room] - exclude

        for connection_id in targets:
            if await self.send_to(connection_id, envelope):
                delivered += 1

        logger.debug(f"Broadcast to room {room}: {delivered}/{len(targets)} delivered")
        return delivered

    async def broadcast_all(
        self,
        envelope: MessageEnvelope,
        *,
        tenant_id: str | None = None,
    ) -> int:
        """Broadcast a message to all (or tenant-filtered) connections.

        Args:
            envelope: Message to broadcast.
            tenant_id: If provided, only send to connections in this tenant.

        Returns:
            Number of connections the message was successfully sent to.
        """
        delivered = 0

        async with self._lock:
            targets = []
            for cid, (_, ctx) in self._connections.items():
                if tenant_id is None or ctx.tenant_id == tenant_id:
                    targets.append(cid)

        for connection_id in targets:
            if await self.send_to(connection_id, envelope):
                delivered += 1

        scope = f"tenant {tenant_id}" if tenant_id else "all connections"
        logger.debug(f"Broadcast to {scope}: {delivered}/{len(targets)} delivered")
        return delivered

    async def stats(self) -> dict[str, Any]:
        """Return connection and room statistics.

        Returns:
            Dict with connection_count, room_count, and per-tenant breakdown.
        """
        async with self._lock:
            total = len(self._connections)
            by_tenant: dict[str, int] = {}
            for _, ctx in self._connections.values():
                tenant = ctx.tenant_id or "(unscoped)"
                by_tenant[tenant] = by_tenant.get(tenant, 0) + 1
            return {
                "connection_count": total,
                "room_count": len(self._rooms),
                "by_tenant": by_tenant,
            }
