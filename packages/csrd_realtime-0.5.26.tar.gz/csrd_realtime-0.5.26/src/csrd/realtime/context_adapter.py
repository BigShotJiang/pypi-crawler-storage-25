"""Optional context-binding adapter for websocket message dispatch.

This module lets consumer services bridge `csrd.realtime` dispatch events into
any context system (for example `csrd-context` or custom contextvars) without
adding direct runtime dependencies from `csrd.realtime` core.
"""

from contextlib import contextmanager
from dataclasses import dataclass, field
from typing import Any, Protocol

from .models import ConnectionContext, MessageEnvelope


@dataclass(frozen=True)
class RealtimeDispatchContext:
    """Metadata exposed to context-binding callbacks for one dispatch cycle."""

    connection_id: str
    connection: ConnectionContext
    envelope: MessageEnvelope
    event_type: str
    trace_id: str | None
    attrs: dict[str, str] = field(default_factory=dict)


class ContextBindCallback(Protocol):
    """Bind dispatch metadata into an external context carrier.

    Returns an opaque token used later by `ContextResetCallback`.
    """

    def __call__(self, dispatch_context: RealtimeDispatchContext) -> Any: ...


class ContextResetCallback(Protocol):
    """Reset/cleanup callback for a prior bind token."""

    def __call__(self, token: Any) -> None: ...


class RealtimeContextAdapter:
    """Adapter that binds and resets context around one dispatch execution."""

    def __init__(
        self,
        *,
        bind: ContextBindCallback,
        reset: ContextResetCallback,
    ) -> None:
        self._bind = bind
        self._reset = reset

    @contextmanager
    def bind_scope(self, dispatch_context: RealtimeDispatchContext):
        """Bind context and guarantee reset after scope exit."""
        token = self._bind(dispatch_context)
        try:
            yield
        finally:
            self._reset(token)
