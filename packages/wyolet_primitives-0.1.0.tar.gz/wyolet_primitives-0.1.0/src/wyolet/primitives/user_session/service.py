import uuid
from datetime import datetime, timezone
from typing import Generic, TypeVar

from wyolet.primitives.user_session.model import UserSessionBase
from wyolet.primitives.user_session.repo import UserSessionRepo

T = TypeVar("T", bound=UserSessionBase)


class UserSessionService(Generic[T]):
    """Thin convenience layer over `UserSessionRepo`.

    Adds two things the repo deliberately doesn't:
    - `touch` throttling — only writes `last_seen_at` once per `touch_every`
      seconds per sid, to avoid one DB write per request.
    - `create` / `revoke_all_for_user` helpers that app code reaches for often.
    """

    def __init__(
        self,
        repo: UserSessionRepo[T],
        *,
        model: type[T],
        touch_every: int = 60,
    ) -> None:
        self.repo = repo
        self._model = model
        self._touch_every = touch_every
        self._last_touched: dict[str, float] = {}  # sid → unix ts

    async def create(self, *, user_id: str, sid: str | None = None, **fields) -> T:
        now = datetime.now(timezone.utc)
        session = self._model(
            sid=sid or str(uuid.uuid4()),
            user_id=user_id,
            created_at=now,
            last_seen_at=now,
            **fields,
        )
        await self.repo.save(session)
        return session

    async def get(self, sid: str) -> T | None:
        return await self.repo.get(sid)

    async def touch(self, sid: str) -> None:
        now = datetime.now(timezone.utc)
        last = self._last_touched.get(sid, 0.0)
        if now.timestamp() - last < self._touch_every:
            return
        self._last_touched[sid] = now.timestamp()
        await self.repo.touch(sid, at=now)

    async def revoke(self, sid: str) -> None:
        await self.repo.revoke(sid, at=datetime.now(timezone.utc))
        self._last_touched.pop(sid, None)

    async def revoke_all_for_user(self, user_id: str) -> int:
        sessions = await self.repo.list_for_user(user_id, active_only=True, limit=1000)
        now = datetime.now(timezone.utc)
        for s in sessions:
            await self.repo.revoke(s.sid, at=now)
            self._last_touched.pop(s.sid, None)
        return len(sessions)

    async def list_active(self, user_id: str, *, limit: int = 50) -> list[T]:
        return await self.repo.list_for_user(user_id, active_only=True, limit=limit)
