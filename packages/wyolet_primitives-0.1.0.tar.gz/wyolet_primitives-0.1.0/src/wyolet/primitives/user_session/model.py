from datetime import datetime
from typing import Any

from pydantic import BaseModel, ConfigDict, Field


class UserSessionBase(BaseModel):
    """Base device/login session record.

    Subclass to add typed columns, or just stash custom fields in `extra`
    (JSONB on Postgres). Pydantic so SQLModel users can extend without
    redeclaring fields: `class MySession(UserSessionBase, SQLModel, table=True): ...`
    """

    model_config = ConfigDict(from_attributes=True)

    sid: str
    user_id: str
    user_agent: str | None = None
    ip: str | None = None
    os: str | None = None
    device: str | None = None
    created_at: datetime
    last_seen_at: datetime
    revoked_at: datetime | None = None
    extra: dict[str, Any] = Field(default_factory=dict)

    @property
    def is_active(self) -> bool:
        return self.revoked_at is None


class UserSession(UserSessionBase):
    """Default concrete model. Swap in your own subclass via the repo type
    parameter if you need typed extras."""
