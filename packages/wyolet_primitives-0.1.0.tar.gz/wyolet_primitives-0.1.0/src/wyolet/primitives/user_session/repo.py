from abc import ABC, abstractmethod
from datetime import datetime
from typing import Generic, TypeVar

from wyolet.primitives.user_session.model import UserSessionBase

T = TypeVar("T", bound=UserSessionBase)


class UserSessionRepo(ABC, Generic[T]):
    """Storage contract for device/login sessions.

    Ship an adapter per store (Postgres, MySQL, DynamoDB, …) by subclassing.
    The `CachedUserSessionRepo` wrapper adds a read-through cache on top, so
    adapters don't need to know about caching.
    """

    @abstractmethod
    async def get(self, sid: str) -> T | None: ...

    @abstractmethod
    async def save(self, session: T) -> None:
        """Upsert by `sid`."""
        ...

    @abstractmethod
    async def list_for_user(
        self,
        user_id: str,
        *,
        active_only: bool = True,
        limit: int = 50,
        before: datetime | None = None,  # keyset pagination on last_seen_at
    ) -> list[T]: ...

    @abstractmethod
    async def revoke(self, sid: str, *, at: datetime) -> None: ...

    @abstractmethod
    async def touch(self, sid: str, *, at: datetime) -> None:
        """Update `last_seen_at` without loading the row."""
        ...

    @abstractmethod
    async def delete(self, sid: str) -> None:
        """Hard-delete. Prefer `revoke()` for audit trails."""
        ...
