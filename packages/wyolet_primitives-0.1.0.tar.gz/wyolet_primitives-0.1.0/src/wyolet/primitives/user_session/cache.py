from datetime import datetime
from typing import Generic, TypeVar

from wyolet.primitives.backends.base import Backend
from wyolet.primitives.user_session.model import UserSessionBase
from wyolet.primitives.user_session.repo import UserSessionRepo

T = TypeVar("T", bound=UserSessionBase)


class CachedUserSessionRepo(UserSessionRepo[T], Generic[T]):
    """Read-through, write-through cache wrapper around any `UserSessionRepo`.

    - `get`: cache hit returns immediately; miss loads from source + warms cache.
    - `save` / `revoke` / `delete`: write to source first, then invalidate or
      refresh the cache entry. Source is the source of truth — a cache write
      failure cannot leave stale data that survives TTL.
    """

    def __init__(
        self,
        source: UserSessionRepo[T],
        backend: Backend,
        *,
        model: type[T],
        ttl: int = 3600,
        key_prefix: str = "us:",
    ) -> None:
        self._source = source
        self._backend = backend
        self._model = model
        self._ttl = ttl
        self._prefix = key_prefix

    def _key(self, sid: str) -> str:
        return f"{self._prefix}{sid}"

    async def get(self, sid: str) -> T | None:
        raw = await self._backend.get(self._key(sid))
        if raw is not None:
            return self._model.model_validate_json(raw)
        loaded = await self._source.get(sid)
        if loaded is not None:
            await self._backend.set(
                self._key(sid), loaded.model_dump_json().encode(), ttl=self._ttl
            )
        return loaded

    async def save(self, session: T) -> None:
        await self._source.save(session)
        await self._backend.set(
            self._key(session.sid), session.model_dump_json().encode(), ttl=self._ttl
        )

    async def list_for_user(
        self,
        user_id: str,
        *,
        active_only: bool = True,
        limit: int = 50,
        before: datetime | None = None,
    ) -> list[T]:
        # Listing is rare and hard to cache correctly — pass through.
        return await self._source.list_for_user(
            user_id, active_only=active_only, limit=limit, before=before
        )

    async def revoke(self, sid: str, *, at: datetime) -> None:
        await self._source.revoke(sid, at=at)
        await self._backend.delete(self._key(sid))

    async def touch(self, sid: str, *, at: datetime) -> None:
        await self._source.touch(sid, at=at)
        # Don't reload just to refresh last_seen_at in cache — it's non-critical
        # and next `get` will repopulate from source on TTL expiry anyway.

    async def delete(self, sid: str) -> None:
        await self._source.delete(sid)
        await self._backend.delete(self._key(sid))
