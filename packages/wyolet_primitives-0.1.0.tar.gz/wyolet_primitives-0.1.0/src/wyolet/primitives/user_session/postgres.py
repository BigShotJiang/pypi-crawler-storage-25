from datetime import datetime
from typing import TYPE_CHECKING, Generic, TypeVar

from wyolet.primitives.user_session.model import UserSession, UserSessionBase
from wyolet.primitives.user_session.repo import UserSessionRepo

if TYPE_CHECKING:
    from psycopg import AsyncConnection
    from psycopg_pool import AsyncConnectionPool

T = TypeVar("T", bound=UserSessionBase)


USER_SESSION_DDL = """
CREATE TABLE IF NOT EXISTS user_sessions (
    sid           TEXT PRIMARY KEY,
    user_id       TEXT NOT NULL,
    user_agent    TEXT,
    ip            TEXT,
    os            TEXT,
    device        TEXT,
    created_at    TIMESTAMPTZ NOT NULL,
    last_seen_at  TIMESTAMPTZ NOT NULL,
    revoked_at    TIMESTAMPTZ,
    extra         JSONB NOT NULL DEFAULT '{}'::jsonb
);
CREATE INDEX IF NOT EXISTS user_sessions_user_id_last_seen_idx
    ON user_sessions (user_id, last_seen_at DESC);
CREATE INDEX IF NOT EXISTS user_sessions_active_idx
    ON user_sessions (user_id) WHERE revoked_at IS NULL;
"""


class PostgresUserSessionRepo(UserSessionRepo[T], Generic[T]):
    """`UserSessionRepo` backed by PostgreSQL via psycopg 3 (async).

    Accepts either a single `AsyncConnection` or an `AsyncConnectionPool` —
    pass the pool for production, a bare connection for tests. Subclass this
    and override `_row_to_model` / `_model_to_row` if you store extra columns.
    """

    def __init__(
        self,
        conn: "AsyncConnection | AsyncConnectionPool",
        *,
        model: type[T] = UserSession,  # type: ignore[assignment]
        table: str = "user_sessions",
    ) -> None:
        self._conn = conn
        self._model = model
        self._table = table

    async def ensure_schema(self) -> None:
        async with self._cursor() as cur:
            await cur.execute(USER_SESSION_DDL)

    # ── repo API ───────────────────────────────────────────────────────────
    async def get(self, sid: str) -> T | None:
        async with self._cursor() as cur:
            await cur.execute(
                f"SELECT {self._cols()} FROM {self._table} WHERE sid = %s", (sid,)
            )
            row = await cur.fetchone()
        return self._row_to_model(row) if row else None

    async def save(self, session: T) -> None:
        row = self._model_to_row(session)
        async with self._cursor() as cur:
            await cur.execute(
                f"""
                INSERT INTO {self._table}
                    (sid, user_id, user_agent, ip, os, device,
                     created_at, last_seen_at, revoked_at, extra)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                ON CONFLICT (sid) DO UPDATE SET
                    user_id      = EXCLUDED.user_id,
                    user_agent   = EXCLUDED.user_agent,
                    ip           = EXCLUDED.ip,
                    os           = EXCLUDED.os,
                    device       = EXCLUDED.device,
                    last_seen_at = EXCLUDED.last_seen_at,
                    revoked_at   = EXCLUDED.revoked_at,
                    extra        = EXCLUDED.extra
                """,
                row,
            )

    async def list_for_user(
        self,
        user_id: str,
        *,
        active_only: bool = True,
        limit: int = 50,
        before: datetime | None = None,
    ) -> list[T]:
        clauses = ["user_id = %s"]
        params: list[object] = [user_id]
        if active_only:
            clauses.append("revoked_at IS NULL")
        if before is not None:
            clauses.append("last_seen_at < %s")
            params.append(before)
        params.append(limit)

        sql = (
            f"SELECT {self._cols()} FROM {self._table} "
            f"WHERE {' AND '.join(clauses)} "
            f"ORDER BY last_seen_at DESC LIMIT %s"
        )
        async with self._cursor() as cur:
            await cur.execute(sql, tuple(params))
            rows = await cur.fetchall()
        return [self._row_to_model(r) for r in rows]

    async def revoke(self, sid: str, *, at: datetime) -> None:
        async with self._cursor() as cur:
            await cur.execute(
                f"UPDATE {self._table} SET revoked_at = %s "
                f"WHERE sid = %s AND revoked_at IS NULL",
                (at, sid),
            )

    async def touch(self, sid: str, *, at: datetime) -> None:
        async with self._cursor() as cur:
            await cur.execute(
                f"UPDATE {self._table} SET last_seen_at = %s WHERE sid = %s",
                (at, sid),
            )

    async def delete(self, sid: str) -> None:
        async with self._cursor() as cur:
            await cur.execute(f"DELETE FROM {self._table} WHERE sid = %s", (sid,))

    # ── mapping (override to add typed columns) ────────────────────────────
    _COLUMNS = (
        "sid, user_id, user_agent, ip, os, device, "
        "created_at, last_seen_at, revoked_at, extra"
    )

    def _cols(self) -> str:
        return self._COLUMNS

    def _row_to_model(self, row: tuple) -> T:
        (
            sid, user_id, ua, ip, os_, device,
            created_at, last_seen_at, revoked_at, extra,
        ) = row
        return self._model(
            sid=sid,
            user_id=user_id,
            user_agent=ua,
            ip=ip,
            os=os_,
            device=device,
            created_at=created_at,
            last_seen_at=last_seen_at,
            revoked_at=revoked_at,
            extra=extra or {},
        )

    def _model_to_row(self, s: T) -> tuple:
        from psycopg.types.json import Jsonb  # local import: optional dep

        return (
            s.sid, s.user_id, s.user_agent, s.ip, s.os, s.device,
            s.created_at, s.last_seen_at, s.revoked_at, Jsonb(s.extra),
        )

    # ── connection handling ────────────────────────────────────────────────
    def _cursor(self):
        # Works with both a bare AsyncConnection and a pool.
        from psycopg_pool import AsyncConnectionPool

        if isinstance(self._conn, AsyncConnectionPool):
            return _PoolCursor(self._conn)
        return self._conn.cursor()


class _PoolCursor:
    """Context manager that grabs a connection from the pool and yields a cursor."""

    def __init__(self, pool: "AsyncConnectionPool") -> None:
        self._pool = pool
        self._conn_cm = None
        self._cur_cm = None

    async def __aenter__(self):
        self._conn_cm = self._pool.connection()
        conn = await self._conn_cm.__aenter__()
        self._cur_cm = conn.cursor()
        return await self._cur_cm.__aenter__()

    async def __aexit__(self, exc_type, exc, tb):
        try:
            if self._cur_cm is not None:
                await self._cur_cm.__aexit__(exc_type, exc, tb)
        finally:
            if self._conn_cm is not None:
                await self._conn_cm.__aexit__(exc_type, exc, tb)
