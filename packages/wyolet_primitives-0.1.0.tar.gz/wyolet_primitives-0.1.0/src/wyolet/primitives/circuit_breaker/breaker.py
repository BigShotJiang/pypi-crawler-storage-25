"""Circuit breaker — fail fast when a dependency is down.

Per-process state (no Backend). Each replica keeps its own counters; that's
the *right* model for a breaker — network blips and pod-local issues
shouldn't trip every replica simultaneously through a shared store.

State machine:

    ┌─ CLOSED ──────────── fail_threshold consecutive failures ──┐
    │                                                            ▼
    │                                                         OPEN
    │                                                            │
    │                                           recovery_timeout elapsed
    │                                                            ▼
    └── probe succeeded ─────────────── HALF_OPEN ──── probe failed ──► OPEN

- **CLOSED**: normal operation. Count consecutive failures.
- **OPEN**: all calls fail instantly with `CircuitOpenError`. No upstream
  call is attempted. Cooldown runs for `recovery_timeout` seconds.
- **HALF_OPEN**: a single probe call is permitted through. Concurrent
  callers during probe get `CircuitOpenError`. Probe success → CLOSED and
  failure count reset. Probe failure → OPEN for another cooldown.

What counts as a failure is controlled by `expected_exception`. Anything
else propagates untouched and does not count — an assertion error in your
code shouldn't trip a breaker that's supposed to protect a payments API.

Canonical uses: HTTP calls to external APIs (Stripe, OpenAI, mailers),
internal service-to-service calls, secondary DB replicas — anywhere a slow
or broken dependency would otherwise pile up stuck requests and cascade
failure into your own service.
"""

import asyncio
import functools
import time
from enum import Enum
from types import TracebackType
from typing import Any, Awaitable, Callable, TypeVar

T = TypeVar("T")

ExcSpec = type[BaseException] | tuple[type[BaseException], ...]


class CircuitOpenError(Exception):
    """Raised when a call is rejected because the breaker is OPEN (or
    HALF_OPEN with a probe already in flight)."""


class CircuitState(str, Enum):
    CLOSED = "closed"
    OPEN = "open"
    HALF_OPEN = "half_open"


class CircuitBreaker:
    """Async circuit breaker. Safe across concurrent tasks in one event loop."""

    def __init__(
        self,
        *,
        fail_threshold: int = 5,
        recovery_timeout: float = 30.0,
        expected_exception: ExcSpec = Exception,
        name: str | None = None,
    ) -> None:
        """
        Args:
            fail_threshold: Consecutive failures in CLOSED state before the
                breaker trips OPEN. Must be >= 1.
            recovery_timeout: Seconds to stay OPEN before allowing a probe.
            expected_exception: Exception type(s) that count as failures.
                Anything else propagates without affecting state.
            name: Human label used in error messages and `repr`.
        """
        if fail_threshold < 1:
            raise ValueError("fail_threshold must be >= 1")
        if recovery_timeout <= 0:
            raise ValueError("recovery_timeout must be > 0")
        self._fail_threshold = fail_threshold
        self._recovery_timeout = recovery_timeout
        self._expected = expected_exception
        self._name = name or "circuit"

        self._state = CircuitState.CLOSED
        self._failures = 0
        self._opened_at: float = 0.0
        self._probe_in_flight = False
        self._lock = asyncio.Lock()

    @property
    def state(self) -> CircuitState:
        """Current state. Does not trigger the OPEN→HALF_OPEN transition —
        that happens lazily on the next call."""
        return self._state

    @property
    def name(self) -> str:
        return self._name

    def __repr__(self) -> str:
        return f"CircuitBreaker(name={self._name!r}, state={self._state.value}, failures={self._failures})"

    async def call(self, fn: Callable[..., Awaitable[T]], *args: Any, **kwargs: Any) -> T:
        """Run `fn(*args, **kwargs)` through the breaker. Raises
        `CircuitOpenError` when the circuit is open."""
        await self._before_call()
        try:
            result = await fn(*args, **kwargs)
        except BaseException as e:
            await self._on_failure(e)
            raise
        await self._on_success()
        return result

    def guard(self, fn: Callable[..., Awaitable[T]]) -> Callable[..., Awaitable[T]]:
        """Decorator form of `.call()`."""
        if not asyncio.iscoroutinefunction(fn):
            raise TypeError("CircuitBreaker.guard requires an async function")

        @functools.wraps(fn)
        async def wrapper(*args: Any, **kwargs: Any) -> T:
            return await self.call(fn, *args, **kwargs)

        return wrapper

    async def __aenter__(self) -> "CircuitBreaker":
        await self._before_call()
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc: BaseException | None,
        tb: TracebackType | None,
    ) -> None:
        if exc is not None:
            await self._on_failure(exc)
        else:
            await self._on_success()

    async def reset(self) -> None:
        """Manual reset to CLOSED. Useful for tests and ops runbooks."""
        async with self._lock:
            self._state = CircuitState.CLOSED
            self._failures = 0
            self._probe_in_flight = False

    # ── internals ──────────────────────────────────────────────────────────
    async def _before_call(self) -> None:
        async with self._lock:
            if self._state is CircuitState.OPEN:
                if time.monotonic() - self._opened_at >= self._recovery_timeout:
                    self._state = CircuitState.HALF_OPEN
                    self._probe_in_flight = False
                else:
                    raise CircuitOpenError(f"{self._name} is OPEN")

            if self._state is CircuitState.HALF_OPEN:
                if self._probe_in_flight:
                    raise CircuitOpenError(
                        f"{self._name} is HALF_OPEN, probe in flight"
                    )
                self._probe_in_flight = True

    async def _on_success(self) -> None:
        async with self._lock:
            if self._state is CircuitState.HALF_OPEN:
                self._state = CircuitState.CLOSED
                self._failures = 0
                self._probe_in_flight = False
            elif self._state is CircuitState.CLOSED:
                self._failures = 0

    async def _on_failure(self, exc: BaseException) -> None:
        if not isinstance(exc, self._expected):
            # Unexpected error: don't attribute to the guarded dependency.
            # Release a HALF_OPEN probe slot so the next caller can try.
            async with self._lock:
                if self._state is CircuitState.HALF_OPEN:
                    self._probe_in_flight = False
            return

        async with self._lock:
            if self._state is CircuitState.HALF_OPEN:
                self._trip_locked()
                return
            if self._state is CircuitState.CLOSED:
                self._failures += 1
                if self._failures >= self._fail_threshold:
                    self._trip_locked()

    def _trip_locked(self) -> None:
        self._state = CircuitState.OPEN
        self._opened_at = time.monotonic()
        self._probe_in_flight = False
