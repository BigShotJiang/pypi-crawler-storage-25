"""Postgres-backed `Backend` via `psycopg` (3.x, async).

For teams that run Postgres but not Redis — fine choice for low-to-medium
throughput: rate limits, idempotency keys, sessions, feature flags,
distributed locks. Not ideal for very hot primitives (cache on every
request, high-QPS counters) — Redis remains faster there.

Schema (created on `ensure_schema()`):

    CREATE TABLE IF NOT EXISTS wyolet_kv (
        key TEXT PRIMARY KEY,
        value BYTEA NOT NULL,
        expires_at TIMESTAMPTZ  -- NULL = no expiry
    );
    CREATE INDEX IF NOT EXISTS wyolet_kv_expires ON wyolet_kv(expires_at);

Expiry is lazy (checked on access) with an optional background sweep.
Clock: server-side `now()` (TIMESTAMPTZ) — immune to client clock skew.

Concurrency: relies on Postgres row-level locking via ON CONFLICT clauses
for `set_nx` / `compare_and_delete`. Safe across any number of app
replicas sharing the same database.

Requires: `psycopg[binary,pool]>=3.3` (install via the `postgres` extra).
"""

import asyncio
from typing import Any

from wyolet.primitives.backends.base import Backend

_SCHEMA = """
CREATE TABLE IF NOT EXISTS wyolet_kv (
    key TEXT PRIMARY KEY,
    value BYTEA NOT NULL,
    expires_at TIMESTAMPTZ
);
CREATE INDEX IF NOT EXISTS wyolet_kv_expires ON wyolet_kv(expires_at);
"""


class PostgresBackend(Backend):
    """Full `Backend` implementation over an `AsyncConnectionPool`."""

    def __init__(
        self,
        pool: Any,
        *,
        table: str = "wyolet_kv",
        sweep_interval: float = 60.0,
    ) -> None:
        """
        Args:
            pool: `psycopg_pool.AsyncConnectionPool` (already opened).
            table: Override the table name if the default clashes.
            sweep_interval: Seconds between background deletes of expired
                rows. Set to 0 to disable (lazy-delete on read still runs).
        """
        self._pool = pool
        self._table = table
        self._sweep_interval = sweep_interval
        self._sweep_task: asyncio.Task[None] | None = None

    # ── lifecycle ──────────────────────────────────────────────────────────
    async def ensure_schema(self) -> None:
        async with self._pool.connection() as conn:
            async with conn.cursor() as cur:
                await cur.execute(_SCHEMA.replace("wyolet_kv", self._table))
            await conn.commit()

    async def start(self) -> None:
        if self._sweep_interval > 0 and (
            self._sweep_task is None or self._sweep_task.done()
        ):
            self._sweep_task = asyncio.create_task(self._sweep_loop())

    async def close(self) -> None:
        if self._sweep_task is not None:
            self._sweep_task.cancel()
            try:
                await self._sweep_task
            except (asyncio.CancelledError, Exception):
                pass
            self._sweep_task = None

    # ── Backend protocol ───────────────────────────────────────────────────
    async def get(self, key: str) -> bytes | None:
        async with self._pool.connection() as conn:
            async with conn.cursor() as cur:
                await cur.execute(
                    f"SELECT value FROM {self._table} "
                    f"WHERE key=%s AND (expires_at IS NULL OR expires_at > now())",
                    (key,),
                )
                row = await cur.fetchone()
        return bytes(row[0]) if row is not None else None

    async def set(self, key: str, value: bytes, ttl: int | None = None) -> None:
        expires_sql, params = _expires_clause(ttl)
        async with self._pool.connection() as conn:
            async with conn.cursor() as cur:
                await cur.execute(
                    f"INSERT INTO {self._table}(key, value, expires_at) VALUES (%s, %s, {expires_sql}) "
                    f"ON CONFLICT (key) DO UPDATE SET value=EXCLUDED.value, expires_at=EXCLUDED.expires_at",
                    (key, value, *params),
                )
            await conn.commit()

    async def delete(self, key: str) -> None:
        async with self._pool.connection() as conn:
            async with conn.cursor() as cur:
                await cur.execute(f"DELETE FROM {self._table} WHERE key=%s", (key,))
            await conn.commit()

    async def incr(self, key: str, by: int = 1, ttl: int | None = None) -> int:
        # Atomic read-modify-write via UPSERT with RETURNING. Expired rows
        # are treated as missing: replaced with a fresh row carrying `by`.
        expires_sql, params = _expires_clause(ttl)
        sql = (
            f"INSERT INTO {self._table}(key, value, expires_at) VALUES (%s, %s, {expires_sql}) "
            f"ON CONFLICT (key) DO UPDATE SET "
            f"  value = CASE "
            f"    WHEN {self._table}.expires_at IS NOT NULL AND {self._table}.expires_at <= now() "
            f"      THEN EXCLUDED.value "
            f"    ELSE (convert_from({self._table}.value, 'UTF8')::bigint + %s)::text::bytea "
            f"  END, "
            f"  expires_at = CASE "
            f"    WHEN {self._table}.expires_at IS NOT NULL AND {self._table}.expires_at <= now() "
            f"      THEN EXCLUDED.expires_at "
            f"    ELSE {self._table}.expires_at "
            f"  END "
            f"RETURNING value"
        )
        async with self._pool.connection() as conn:
            async with conn.cursor() as cur:
                await cur.execute(
                    sql, (key, str(by).encode(), *params, by)
                )
                row = await cur.fetchone()
            await conn.commit()
        return int(bytes(row[0]))

    async def expire(self, key: str, ttl: int) -> None:
        async with self._pool.connection() as conn:
            async with conn.cursor() as cur:
                await cur.execute(
                    f"UPDATE {self._table} "
                    f"SET expires_at = now() + (%s || ' seconds')::interval "
                    f"WHERE key=%s AND (expires_at IS NULL OR expires_at > now())",
                    (str(ttl), key),
                )
            await conn.commit()

    async def set_nx(self, key: str, value: bytes, ttl: int | None = None) -> bool:
        # Upsert with a WHERE on the UPDATE branch: only replace if the
        # existing row has expired. RETURNING lets us detect whether we
        # actually wrote — no row returned = existing live row blocked us.
        expires_sql, params = _expires_clause(ttl)
        sql = (
            f"INSERT INTO {self._table}(key, value, expires_at) VALUES (%s, %s, {expires_sql}) "
            f"ON CONFLICT (key) DO UPDATE SET value=EXCLUDED.value, expires_at=EXCLUDED.expires_at "
            f"WHERE {self._table}.expires_at IS NOT NULL AND {self._table}.expires_at <= now() "
            f"RETURNING xmax"
        )
        async with self._pool.connection() as conn:
            async with conn.cursor() as cur:
                await cur.execute(sql, (key, value, *params))
                row = await cur.fetchone()
            await conn.commit()
        return row is not None

    async def compare_and_delete(self, key: str, expected: bytes) -> bool:
        async with self._pool.connection() as conn:
            async with conn.cursor() as cur:
                await cur.execute(
                    f"DELETE FROM {self._table} "
                    f"WHERE key=%s AND value=%s "
                    f"AND (expires_at IS NULL OR expires_at > now())",
                    (key, expected),
                )
                deleted = cur.rowcount
            await conn.commit()
        return deleted == 1

    # ── internals ──────────────────────────────────────────────────────────
    async def _sweep_loop(self) -> None:
        try:
            while True:
                await asyncio.sleep(self._sweep_interval)
                try:
                    async with self._pool.connection() as conn:
                        async with conn.cursor() as cur:
                            await cur.execute(
                                f"DELETE FROM {self._table} "
                                f"WHERE expires_at IS NOT NULL AND expires_at <= now()"
                            )
                        await conn.commit()
                except Exception:
                    # Sweep is best-effort — lazy delete on access still works.
                    pass
        except asyncio.CancelledError:
            raise


def _expires_clause(ttl: int | None) -> tuple[str, tuple[Any, ...]]:
    if ttl is None:
        return "NULL", ()
    return "now() + (%s || ' seconds')::interval", (str(ttl),)
