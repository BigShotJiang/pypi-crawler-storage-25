"""SQLite-backed `Backend` via `aiosqlite`.

Useful for:
- Local development without docker (no Redis dependency).
- Single-node deploys where Redis would be overkill.
- Persistence of session / user-session / idempotency state across
  app restarts on a single host.

Not a fit for multi-process or multi-node — SQLite's one-writer model
will bottleneck, and a crashed-but-not-closed process can keep a lock
that blocks others. For those, use `RedisBackend` / `ValkeyBackend` or
`PostgresBackend`.

Clock:
- Uses wall-clock `time.time()` for TTL comparisons (not monotonic)
  because values persist across process restarts. NTP clock jumps will
  therefore affect pending expirations; acceptable for a primitive at
  this tier.

Concurrency:
- One `aiosqlite.Connection` per instance, serialized by `asyncio.Lock`.
  WAL mode enabled for better read/write overlap within the process.

Schema:
    CREATE TABLE kv (
        key TEXT PRIMARY KEY,
        value BLOB NOT NULL,
        expires_at REAL  -- unix seconds; NULL = no expiry
    );
    CREATE INDEX kv_expires ON kv(expires_at);

Schema is created lazily on `start()` — no migrations required.
"""

import asyncio
import time

from wyolet.primitives.backends.base import Backend

_SCHEMA = """
CREATE TABLE IF NOT EXISTS kv (
    key TEXT PRIMARY KEY,
    value BLOB NOT NULL,
    expires_at REAL
);
CREATE INDEX IF NOT EXISTS kv_expires ON kv(expires_at);
"""


class SQLiteBackend(Backend):
    """SQLite implementation of `Backend`. Pass `:memory:` for an ephemeral
    in-process store, or a file path for persistence."""

    def __init__(
        self,
        path: str = ":memory:",
        *,
        sweep_interval: float = 60.0,
    ) -> None:
        self._path = path
        self._sweep_interval = sweep_interval
        self._lock = asyncio.Lock()
        self._conn = None  # aiosqlite.Connection, lazily opened
        self._sweep_task: asyncio.Task[None] | None = None

    # ── lifecycle ──────────────────────────────────────────────────────────
    async def start(self) -> None:
        import aiosqlite

        if self._conn is not None:
            return
        self._conn = await aiosqlite.connect(self._path)
        await self._conn.execute("PRAGMA journal_mode=WAL")
        await self._conn.execute("PRAGMA synchronous=NORMAL")
        await self._conn.executescript(_SCHEMA)
        await self._conn.commit()
        self._sweep_task = asyncio.create_task(self._sweep_loop())

    async def close(self) -> None:
        if self._sweep_task is not None:
            self._sweep_task.cancel()
            try:
                await self._sweep_task
            except (asyncio.CancelledError, Exception):
                pass
            self._sweep_task = None
        if self._conn is not None:
            await self._conn.close()
            self._conn = None

    # ── Backend protocol ───────────────────────────────────────────────────
    async def get(self, key: str) -> bytes | None:
        now = time.time()
        async with self._lock:
            conn = self._require()
            async with conn.execute(
                "SELECT value, expires_at FROM kv WHERE key=?", (key,)
            ) as cur:
                row = await cur.fetchone()
            if row is None:
                return None
            value, expires_at = row
            if _is_expired(expires_at, now):
                await conn.execute("DELETE FROM kv WHERE key=?", (key,))
                await conn.commit()
                return None
            return bytes(value)

    async def set(self, key: str, value: bytes, ttl: int | None = None) -> None:
        expires_at = _deadline(ttl)
        async with self._lock:
            conn = self._require()
            await conn.execute(
                "INSERT INTO kv(key, value, expires_at) VALUES(?, ?, ?) "
                "ON CONFLICT(key) DO UPDATE SET value=excluded.value, expires_at=excluded.expires_at",
                (key, value, expires_at),
            )
            await conn.commit()

    async def delete(self, key: str) -> None:
        async with self._lock:
            conn = self._require()
            await conn.execute("DELETE FROM kv WHERE key=?", (key,))
            await conn.commit()

    async def incr(self, key: str, by: int = 1, ttl: int | None = None) -> int:
        now = time.time()
        async with self._lock:
            conn = self._require()
            async with conn.execute(
                "SELECT value, expires_at FROM kv WHERE key=?", (key,)
            ) as cur:
                row = await cur.fetchone()
            if row is None or _is_expired(row[1], now):
                new_val = by
                await conn.execute(
                    "INSERT INTO kv(key, value, expires_at) VALUES(?, ?, ?) "
                    "ON CONFLICT(key) DO UPDATE SET value=excluded.value, expires_at=excluded.expires_at",
                    (key, str(new_val).encode(), _deadline(ttl)),
                )
                await conn.commit()
                return new_val
            # Existing key — preserve TTL per the contract.
            new_val = int(row[0]) + by
            await conn.execute(
                "UPDATE kv SET value=? WHERE key=?", (str(new_val).encode(), key)
            )
            await conn.commit()
            return new_val

    async def expire(self, key: str, ttl: int) -> None:
        now = time.time()
        async with self._lock:
            conn = self._require()
            # Only set expiry on a live row.
            await conn.execute(
                "UPDATE kv SET expires_at=? "
                "WHERE key=? AND (expires_at IS NULL OR expires_at > ?)",
                (_deadline(ttl), key, now),
            )
            await conn.commit()

    async def set_nx(self, key: str, value: bytes, ttl: int | None = None) -> bool:
        now = time.time()
        async with self._lock:
            conn = self._require()
            # Upsert only if the row is absent OR expired. SQLite lacks
            # conditional ON CONFLICT, so do it in two steps inside the lock.
            async with conn.execute(
                "SELECT expires_at FROM kv WHERE key=?", (key,)
            ) as cur:
                row = await cur.fetchone()
            if row is not None and not _is_expired(row[0], now):
                return False
            await conn.execute(
                "INSERT INTO kv(key, value, expires_at) VALUES(?, ?, ?) "
                "ON CONFLICT(key) DO UPDATE SET value=excluded.value, expires_at=excluded.expires_at",
                (key, value, _deadline(ttl)),
            )
            await conn.commit()
            return True

    async def compare_and_delete(self, key: str, expected: bytes) -> bool:
        now = time.time()
        async with self._lock:
            conn = self._require()
            cur = await conn.execute(
                "DELETE FROM kv WHERE key=? AND value=? "
                "AND (expires_at IS NULL OR expires_at > ?)",
                (key, expected, now),
            )
            await conn.commit()
            return cur.rowcount == 1

    # ── internals ──────────────────────────────────────────────────────────
    def _require(self):
        if self._conn is None:
            raise RuntimeError("SQLiteBackend not started — call `await backend.start()` first")
        return self._conn

    async def _sweep_loop(self) -> None:
        try:
            while True:
                await asyncio.sleep(self._sweep_interval)
                async with self._lock:
                    if self._conn is None:
                        return
                    await self._conn.execute(
                        "DELETE FROM kv WHERE expires_at IS NOT NULL AND expires_at <= ?",
                        (time.time(),),
                    )
                    await self._conn.commit()
        except asyncio.CancelledError:
            raise


def _deadline(ttl: int | None) -> float | None:
    return None if ttl is None else time.time() + ttl


def _is_expired(expires_at: float | None, now: float) -> bool:
    return expires_at is not None and expires_at <= now
