from typing import TYPE_CHECKING

from wyolet.primitives.backends.base import Backend

if TYPE_CHECKING:
    from redis.asyncio import Redis


class RedisBackend(Backend):
    """`Backend` implementation over `redis.asyncio.Redis`.

    Also works with Valkey and other redis-protocol servers that speak RESP3.
    The client is injected so the caller controls pool config and lifecycle —
    this class never opens or closes connections.
    """

    def __init__(self, client: "Redis") -> None:
        self._client = client

    async def get(self, key: str) -> bytes | None:
        return await self._client.get(key)

    async def set(self, key: str, value: bytes, ttl: int | None = None) -> None:
        await self._client.set(key, value, ex=ttl)

    async def delete(self, key: str) -> None:
        await self._client.delete(key)

    async def incr(self, key: str, by: int = 1, ttl: int | None = None) -> int:
        # INCRBY returns the new value. If the key is newly created and ttl is
        # given, set expiry with NX so we don't clobber an existing TTL.
        pipe = self._client.pipeline(transaction=True)
        await pipe.incrby(key, by)
        if ttl is not None:
            await pipe.expire(key, ttl, nx=True)
        results = await pipe.execute()
        return int(results[0])

    async def expire(self, key: str, ttl: int) -> None:
        await self._client.expire(key, ttl)

    async def set_nx(self, key: str, value: bytes, ttl: int | None = None) -> bool:
        # SET key value NX EX ttl — returns OK (truthy) on insert, None if key exists.
        result = await self._client.set(key, value, nx=True, ex=ttl)
        return result is True or result == b"OK" or result == "OK"

    async def compare_and_delete(self, key: str, expected: bytes) -> bool:
        # Atomic compare-and-delete via Lua — DEL only if GET matches.
        result = await self._client.eval(_CAD_SCRIPT, 1, key, expected)
        return int(result) == 1


_CAD_SCRIPT = """
if redis.call('get', KEYS[1]) == ARGV[1] then
    return redis.call('del', KEYS[1])
else
    return 0
end
"""
