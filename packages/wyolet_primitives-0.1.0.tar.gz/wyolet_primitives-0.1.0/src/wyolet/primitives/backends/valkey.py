from typing import TYPE_CHECKING

from wyolet.primitives.backends.base import Backend

if TYPE_CHECKING:
    from valkey.asyncio import Valkey


class ValkeyBackend(Backend):
    """`Backend` implementation over `valkey.asyncio.Valkey`.

    Mirrors `RedisBackend`; separate class so apps using only Valkey don't have
    to install redis-py (and vice versa). The client is injected — this class
    never opens or closes connections.
    """

    def __init__(self, client: "Valkey") -> None:
        self._client = client

    async def get(self, key: str) -> bytes | None:
        return await self._client.get(key)

    async def set(self, key: str, value: bytes, ttl: int | None = None) -> None:
        await self._client.set(key, value, ex=ttl)

    async def delete(self, key: str) -> None:
        await self._client.delete(key)

    async def incr(self, key: str, by: int = 1, ttl: int | None = None) -> int:
        pipe = self._client.pipeline(transaction=True)
        await pipe.incrby(key, by)
        if ttl is not None:
            await pipe.expire(key, ttl, nx=True)
        results = await pipe.execute()
        return int(results[0])

    async def expire(self, key: str, ttl: int) -> None:
        await self._client.expire(key, ttl)

    async def set_nx(self, key: str, value: bytes, ttl: int | None = None) -> bool:
        result = await self._client.set(key, value, nx=True, ex=ttl)
        return result is True or result == b"OK" or result == "OK"

    async def compare_and_delete(self, key: str, expected: bytes) -> bool:
        result = await self._client.eval(_CAD_SCRIPT, 1, key, expected)
        return int(result) == 1


_CAD_SCRIPT = """
if redis.call('get', KEYS[1]) == ARGV[1] then
    return redis.call('del', KEYS[1])
else
    return 0
end
"""
