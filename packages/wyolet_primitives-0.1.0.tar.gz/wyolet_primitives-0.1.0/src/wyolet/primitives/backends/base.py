from abc import ABC, abstractmethod


class Backend(ABC):
    """Minimal async KV contract shared by all wyolet.primitives primitives.

    Values are opaque bytes — serialization is the caller's job. TTLs are in
    seconds; `None` means no expiry. Keys are plain strings; namespacing
    (prefixes) is the caller's job too.

    Ship an adapter per store (memory, redis, valkey, …) by subclassing this
    and implementing every method. Primitives depend only on `Backend`, never
    on a concrete adapter.
    """

    @abstractmethod
    async def get(self, key: str) -> bytes | None: ...

    @abstractmethod
    async def set(self, key: str, value: bytes, ttl: int | None = None) -> None: ...

    @abstractmethod
    async def delete(self, key: str) -> None: ...

    @abstractmethod
    async def incr(self, key: str, by: int = 1, ttl: int | None = None) -> int:
        """Atomic increment. Creates the key (at `by`) if missing. If `ttl` is
        given and the key is newly created, sets expiry; existing TTLs are left
        alone."""
        ...

    @abstractmethod
    async def expire(self, key: str, ttl: int) -> None: ...

    @abstractmethod
    async def set_nx(self, key: str, value: bytes, ttl: int | None = None) -> bool:
        """Atomic set-if-not-exists. Returns `True` if the key was written,
        `False` if it already existed. Foundation of distributed locking."""
        ...

    @abstractmethod
    async def compare_and_delete(self, key: str, expected: bytes) -> bool:
        """Delete `key` only if its current value equals `expected`. Returns
        `True` on successful delete. Used to safely release locks without
        accidentally killing someone else's critical section."""
        ...
