import asyncio
import time
from dataclasses import dataclass

from wyolet.primitives.backends.base import Backend


@dataclass(slots=True)
class _Entry:
    value: bytes
    expires_at: float | None  # monotonic seconds; None = no expiry


class MemoryBackend(Backend):
    """In-process `Backend` implementation.

    Intended for dev, tests, and single-process deployments. Uses monotonic
    clock for TTL so system clock changes don't break expiry. Expiry is lazy
    (checked on access) plus a best-effort background sweep.
    """

    def __init__(self, *, sweep_interval: float = 30.0) -> None:
        self._data: dict[str, _Entry] = {}
        self._lock = asyncio.Lock()
        self._sweep_interval = sweep_interval
        self._sweep_task: asyncio.Task[None] | None = None

    # ── lifecycle ──────────────────────────────────────────────────────────
    async def start(self) -> None:
        if self._sweep_task is None or self._sweep_task.done():
            self._sweep_task = asyncio.create_task(self._sweep_loop())

    async def close(self) -> None:
        if self._sweep_task is not None:
            self._sweep_task.cancel()
            try:
                await self._sweep_task
            except (asyncio.CancelledError, Exception):
                pass
            self._sweep_task = None
        async with self._lock:
            self._data.clear()

    # ── Backend protocol ───────────────────────────────────────────────────
    async def get(self, key: str) -> bytes | None:
        async with self._lock:
            entry = self._data.get(key)
            if entry is None:
                return None
            if self._expired(entry):
                del self._data[key]
                return None
            return entry.value

    async def set(self, key: str, value: bytes, ttl: int | None = None) -> None:
        async with self._lock:
            self._data[key] = _Entry(value=value, expires_at=self._deadline(ttl))

    async def delete(self, key: str) -> None:
        async with self._lock:
            self._data.pop(key, None)

    async def incr(self, key: str, by: int = 1, ttl: int | None = None) -> int:
        async with self._lock:
            entry = self._data.get(key)
            if entry is None or self._expired(entry):
                new_val = by
                self._data[key] = _Entry(
                    value=str(new_val).encode(), expires_at=self._deadline(ttl)
                )
                return new_val
            new_val = int(entry.value) + by
            entry.value = str(new_val).encode()
            return new_val

    async def expire(self, key: str, ttl: int) -> None:
        async with self._lock:
            entry = self._data.get(key)
            if entry is None or self._expired(entry):
                return
            entry.expires_at = self._deadline(ttl)

    async def set_nx(self, key: str, value: bytes, ttl: int | None = None) -> bool:
        async with self._lock:
            entry = self._data.get(key)
            if entry is not None and not self._expired(entry):
                return False
            self._data[key] = _Entry(value=value, expires_at=self._deadline(ttl))
            return True

    async def compare_and_delete(self, key: str, expected: bytes) -> bool:
        async with self._lock:
            entry = self._data.get(key)
            if entry is None or self._expired(entry):
                return False
            if entry.value != expected:
                return False
            del self._data[key]
            return True

    # ── internals ──────────────────────────────────────────────────────────
    @staticmethod
    def _deadline(ttl: int | None) -> float | None:
        return None if ttl is None else time.monotonic() + ttl

    @staticmethod
    def _expired(entry: _Entry) -> bool:
        return entry.expires_at is not None and entry.expires_at <= time.monotonic()

    async def _sweep_loop(self) -> None:
        while True:
            await asyncio.sleep(self._sweep_interval)
            async with self._lock:
                now = time.monotonic()
                for key in [
                    k
                    for k, e in self._data.items()
                    if e.expires_at is not None and e.expires_at <= now
                ]:
                    del self._data[key]
