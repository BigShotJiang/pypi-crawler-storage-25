"""Pure-ASGI idempotency middleware.

Usage pattern matches the `Idempotency-Key` header convention popularised by
Stripe: clients send `Idempotency-Key: <uuid>` on mutating requests; on retry
with the same key within the TTL, the server replays the original response
without re-running the handler.

Concurrency:
- First request acquires a per-key `DistributedLock`.
- Retry that arrives *during* the first request waits on the lock up to
  `wait_for_first` seconds, then re-checks the store and returns the cached
  response. If the first request is still pending when the wait expires,
  returns 409 Conflict.
- Retry that arrives *after* the first finished is a pure store hit — fast
  path, no lock acquisition.

Limits (v0.1):
- Full response body is buffered in memory. Not for streaming/large files.
- 5xx responses are NOT cached — retrying on transient errors is the whole
  point of idempotency keys; caching a 500 would defeat it.
- No request-fingerprint check. If a client sends the same key with a
  different payload, the first payload's response is returned. Future work.
"""

from typing import Any, Awaitable, Callable, MutableMapping

from wyolet.primitives.backends.base import Backend
from wyolet.primitives.idempotency.store import IdempotencyStore, StoredResponse
from wyolet.primitives.lock.lock import DistributedLock, LockAcquireError

Scope = MutableMapping[str, Any]
Message = MutableMapping[str, Any]
Receive = Callable[[], Awaitable[Message]]
Send = Callable[[Message], Awaitable[None]]
ASGIApp = Callable[[Scope, Receive, Send], Awaitable[None]]

DEFAULT_METHODS = frozenset({"POST", "PUT", "PATCH", "DELETE"})


class IdempotencyMiddleware:
    def __init__(
        self,
        app: ASGIApp,
        *,
        backend: Backend,
        ttl: int = 24 * 60 * 60,
        header_name: str = "idempotency-key",
        methods: frozenset[str] = DEFAULT_METHODS,
        wait_for_first: float = 30.0,
        handler_timeout: int = 60,
        store: IdempotencyStore | None = None,
        lock: DistributedLock | None = None,
    ) -> None:
        """
        Args:
            backend: Shared backend for store + lock.
            ttl: Seconds to retain cached responses. Default 24h.
            header_name: Incoming header carrying the key (case-insensitive).
            methods: HTTP methods the middleware acts on. Others pass through.
            wait_for_first: Seconds a replay will wait for an in-flight original.
            handler_timeout: TTL of the per-key lock — upper bound on how long
                the original handler is allowed to run before a replay takes over.
            store / lock: Optional pre-built instances, otherwise created for you.
        """
        self.app = app
        self.header_name = header_name.lower().encode("latin-1")
        self.methods = methods
        self.wait_for_first = wait_for_first
        self.store = store or IdempotencyStore(backend, ttl=ttl)
        self.lock = lock or DistributedLock(
            backend,
            ttl=handler_timeout,
            wait=wait_for_first,
            retry_delay=0.05,
            prefix="idem-lock:",
        )

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope["type"] != "http" or scope.get("method", "").upper() not in self.methods:
            await self.app(scope, receive, send)
            return

        key = self._read_header(scope)
        if key is None:
            await self.app(scope, receive, send)
            return

        # Fast path: cached response already exists.
        cached = await self.store.get(key)
        if cached is not None:
            await self._replay(send, cached)
            return

        # Slow path: acquire lock, re-check, then run the app and capture.
        try:
            async with self.lock.acquire(key):
                cached = await self.store.get(key)
                if cached is not None:
                    await self._replay(send, cached)
                    return
                await self._run_and_capture(scope, receive, send, key)
        except LockAcquireError:
            # Original request is still running past our wait. Don't double-run.
            await self._send_conflict(send)

    # ── ASGI helpers ────────────────────────────────────────────────────────
    def _read_header(self, scope: Scope) -> str | None:
        for name, value in scope.get("headers", []):
            if name == self.header_name:
                return value.decode("latin-1").strip() or None
        return None

    async def _run_and_capture(
        self, scope: Scope, receive: Receive, send: Send, key: str
    ) -> None:
        status: int | None = None
        resp_headers: list[tuple[bytes, bytes]] = []
        body_chunks: list[bytes] = []

        async def capture_send(message: Message) -> None:
            nonlocal status, resp_headers
            if message["type"] == "http.response.start":
                status = message["status"]
                resp_headers = list(message.get("headers") or [])
            elif message["type"] == "http.response.body":
                chunk = message.get("body", b"")
                if chunk:
                    body_chunks.append(chunk)
            await send(message)

        await self.app(scope, receive, capture_send)

        # Only cache final, deterministic responses. 5xx would trap clients in
        # the error permanently; skip.
        if status is None or status >= 500:
            return
        await self.store.put(
            key,
            StoredResponse(
                status=status, headers=resp_headers, body=b"".join(body_chunks)
            ),
        )

    async def _replay(self, send: Send, stored: StoredResponse) -> None:
        headers = list(stored.headers)
        headers.append((b"idempotent-replayed", b"true"))
        await send(
            {"type": "http.response.start", "status": stored.status, "headers": headers}
        )
        await send({"type": "http.response.body", "body": stored.body, "more_body": False})

    async def _send_conflict(self, send: Send) -> None:
        body = b'{"error":"idempotency_in_progress"}'
        await send(
            {
                "type": "http.response.start",
                "status": 409,
                "headers": [
                    (b"content-type", b"application/json"),
                    (b"content-length", str(len(body)).encode()),
                ],
            }
        )
        await send({"type": "http.response.body", "body": body, "more_body": False})
