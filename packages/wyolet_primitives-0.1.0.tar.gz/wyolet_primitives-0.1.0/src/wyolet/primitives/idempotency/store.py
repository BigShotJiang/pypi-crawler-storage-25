"""Persistence for captured responses, keyed by `Idempotency-Key` value.

Responses are stored as `(status, headers, body)`. Headers and bodies can be
binary, so we base64-encode them inside a JSON envelope — keeps the payload
portable across any `Backend` and readable in a Redis CLI for debugging.
"""

import base64
import json
from dataclasses import dataclass

from wyolet.primitives.backends.base import Backend


@dataclass(slots=True)
class StoredResponse:
    status: int
    headers: list[tuple[bytes, bytes]]
    body: bytes

    def encode(self) -> bytes:
        return json.dumps(
            {
                "s": self.status,
                "h": [
                    [base64.b64encode(n).decode(), base64.b64encode(v).decode()]
                    for n, v in self.headers
                ],
                "b": base64.b64encode(self.body).decode(),
            }
        ).encode()

    @classmethod
    def decode(cls, raw: bytes) -> "StoredResponse":
        obj = json.loads(raw)
        return cls(
            status=obj["s"],
            headers=[
                (base64.b64decode(n), base64.b64decode(v)) for n, v in obj["h"]
            ],
            body=base64.b64decode(obj["b"]),
        )


class IdempotencyStore:
    """Backend-backed store for captured responses.

    Thin wrapper — no caching logic beyond `get`/`put`. The middleware owns
    concurrency control via the `lock` primitive.
    """

    def __init__(self, backend: Backend, *, ttl: int = 24 * 60 * 60, prefix: str = "idem:") -> None:
        if ttl <= 0:
            raise ValueError("ttl must be > 0")
        self._backend = backend
        self._ttl = ttl
        self._prefix = prefix

    def _key(self, idem_key: str) -> str:
        return self._prefix + idem_key

    async def get(self, idem_key: str) -> StoredResponse | None:
        raw = await self._backend.get(self._key(idem_key))
        return StoredResponse.decode(raw) if raw is not None else None

    async def put(self, idem_key: str, response: StoredResponse) -> None:
        await self._backend.set(self._key(idem_key), response.encode(), ttl=self._ttl)

    async def delete(self, idem_key: str) -> None:
        await self._backend.delete(self._key(idem_key))
