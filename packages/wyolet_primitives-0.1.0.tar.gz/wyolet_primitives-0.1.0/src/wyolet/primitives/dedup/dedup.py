"""Dedup — "have I already processed this ID?" in one primitive.

The contract is deliberately tiny: atomic `SET NX` with TTL. First caller
wins and gets `True` from `claim()`; anyone arriving with the same key
within the TTL gets `False` and should skip whatever side-effect the first
caller is running.

Canonical uses:
- Webhook receivers (Stripe, GitHub, Slack) where the provider retries on
  timeout and you must not double-process `event.id`.
- Queue consumers with at-least-once delivery (SQS, Kafka) where the same
  message can be redelivered after a crash.
- Outbound notifications — never send the same email / SMS / push twice for
  the same logical event.
- Cron-once across replicas: `f"daily-report:{date}"` → only the first pod
  to claim proceeds.

How it differs from `idempotency`:
- `idempotency` replays the captured response to the client — request/
  response shaped.
- `dedup` is a yes/no test with no stored response. Simpler, cheaper,
  usable anywhere (workers, background jobs, inside handlers).

Failure model: `claim()` marks *before* the work runs — otherwise two
concurrent duplicates both slip through. If the work then fails and you
want the next retry to proceed, use the `once()` context manager (which
rolls back the mark on exception), or call `forget()` manually.
"""

from types import TracebackType
from typing import AsyncIterator
from contextlib import asynccontextmanager

from wyolet.primitives.backends.base import Backend


class Dedup:
    """Short-window dedup over any `Backend`."""

    __slots__ = ("_backend", "_ttl", "_prefix")

    def __init__(
        self,
        backend: Backend,
        *,
        ttl: int = 24 * 60 * 60,
        prefix: str = "dedup:",
    ) -> None:
        """
        Args:
            backend: Shared backend.
            ttl: Seconds a claimed key remains marked. Should comfortably
                exceed the provider's retry window (e.g. Stripe retries for
                up to 3 days — set `ttl=3*24*3600` for webhook dedup).
            prefix: Namespacing prefix for dedup keys.
        """
        if ttl <= 0:
            raise ValueError("ttl must be > 0")
        self._backend = backend
        self._ttl = ttl
        self._prefix = prefix

    def _key(self, key: str) -> str:
        return self._prefix + key

    async def claim(self, key: str, *, ttl: int | None = None) -> bool:
        """Attempt to claim `key`. Returns `True` if this is the first time
        we've seen it (caller should proceed), `False` if it was already
        claimed within the TTL (caller should skip).

        Atomic — concurrent callers with the same key produce exactly one
        `True` result across the fleet.
        """
        return await self._backend.set_nx(
            self._key(key), b"1", ttl=ttl if ttl is not None else self._ttl
        )

    async def seen(self, key: str) -> bool:
        """Non-destructive check. Returns `True` if the key is currently
        marked. Prefer `claim()` for the check-and-mark path — using
        `seen()` then `claim()` is racy."""
        return (await self._backend.get(self._key(key))) is not None

    async def forget(self, key: str) -> None:
        """Remove a claim. Use after a failed work attempt so the next
        retry is allowed to proceed."""
        await self._backend.delete(self._key(key))

    @asynccontextmanager
    async def once(
        self, key: str, *, ttl: int | None = None
    ) -> AsyncIterator[bool]:
        """Claim with automatic rollback on exception.

        Usage:
            async with dedup.once(f"stripe:{event.id}") as first:
                if not first:
                    return  # duplicate, skip
                await process(event)

        On successful exit, the claim persists for the TTL. If the body
        raises, the claim is released so a subsequent retry can proceed.
        """
        first = await self.claim(key, ttl=ttl)
        try:
            yield first
        except BaseException:
            if first:
                await self.forget(key)
            raise
