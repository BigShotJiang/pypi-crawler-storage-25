"""wyolet.primitives — stateful FastAPI primitives sharing one Backend protocol."""

from wyolet.primitives.backends import Backend, MemoryBackend
from wyolet.primitives.circuit_breaker import (
    CircuitBreaker,
    CircuitOpenError,
    CircuitState,
)
from wyolet.primitives.cache import (
    Cache,
    HTTPCacheMiddleware,
    PickleSerializer,
    Serializer,
    cached,
)
from wyolet.primitives.dedup import Dedup
from wyolet.primitives.feature_flags import FeatureFlags, Flag
from wyolet.primitives.otp import (
    Otp,
    OtpCooldownError,
    OtpError,
    OtpNotFoundError,
    OtpTooManyAttemptsError,
)
from wyolet.primitives.session import Session, SessionMiddleware, SessionState

__version__ = "0.0.1"
__all__ = [
    "Backend",
    "Cache",
    "CircuitBreaker",
    "CircuitOpenError",
    "CircuitState",
    "Dedup",
    "FeatureFlags",
    "Flag",
    "HTTPCacheMiddleware",
    "MemoryBackend",
    "Otp",
    "OtpCooldownError",
    "OtpError",
    "OtpNotFoundError",
    "OtpTooManyAttemptsError",
    "PickleSerializer",
    "Serializer",
    "Session",
    "SessionMiddleware",
    "SessionState",
    "cached",
]
