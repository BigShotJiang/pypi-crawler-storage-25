"""Pure-ASGI HTTP response cache.

Caches full responses for safe methods (GET/HEAD) keyed on
`method + path + query + selected request headers`. Reuses the `Cache`
machinery, so stampede protection applies: concurrent first-hits to the
same URL result in one upstream call, not N.

Policy (v0.1):
- Only GET/HEAD by default (configurable via `methods`).
- Skip if request carries `Cache-Control: no-store` or `no-cache`.
- Skip if response carries `Cache-Control: no-store`, `private`, or
  `max-age=0`.
- A response `Cache-Control: max-age=N` overrides the middleware's default
  TTL (capped at `max_ttl`).
- Only 2xx responses are cached. 3xx/4xx/5xx pass through untouched.
- Vary handling is *explicit*: you declare which request headers participate
  in the cache key via `vary=("accept-encoding", "authorization", ...)`.
  This avoids the classic footgun where a response's `Vary` header silently
  explodes the key space.

Limits:
- Full response body is buffered in memory before caching. Not suitable for
  streaming responses.
- No conditional request handling (If-None-Match / 304). Future work.
- No shared-with-private distinction beyond the blanket `private` skip.

Each served response carries `X-Cache: HIT` or `X-Cache: MISS` for
observability.
"""

from typing import Any, Awaitable, Callable, MutableMapping

from wyolet.primitives.backends.base import Backend
from wyolet.primitives.cache.cache import Cache
from wyolet.primitives.cache.serializer import PickleSerializer, Serializer

Scope = MutableMapping[str, Any]
Message = MutableMapping[str, Any]
Receive = Callable[[], Awaitable[Message]]
Send = Callable[[Message], Awaitable[None]]
ASGIApp = Callable[[Scope, Receive, Send], Awaitable[None]]

DEFAULT_METHODS = frozenset({"GET", "HEAD"})


class HTTPCacheMiddleware:
    def __init__(
        self,
        app: ASGIApp,
        *,
        backend: Backend,
        ttl: int = 60,
        max_ttl: int = 24 * 60 * 60,
        methods: frozenset[str] = DEFAULT_METHODS,
        vary: tuple[str, ...] = (),
        prefix: str = "httpcache:",
        cache: Cache | None = None,
        serializer: Serializer | None = None,
        stampede: bool = True,
    ) -> None:
        """
        Args:
            backend: Shared backend.
            ttl: Default TTL in seconds for cached responses.
            max_ttl: Upper bound when a response's `Cache-Control: max-age`
                overrides `ttl`.
            methods: HTTP methods eligible for caching.
            vary: Request header names (lowercase) to include in the cache
                key — e.g. `("accept-encoding", "accept-language")`.
            prefix: Namespacing prefix for cache keys.
            cache: Pre-built `Cache` instance. If given, `ttl`, `prefix`,
                and `serializer` are ignored.
            serializer: Serializer for stored response envelopes. Pickle is
                the sensible default — entries stay internal to the app.
            stampede: If True, concurrent first-hits to the same URL
                serialize on a `DistributedLock` so only one request reaches
                the upstream handler.
        """
        self.app = app
        self.methods = methods
        self.max_ttl = max_ttl
        self.default_ttl = ttl
        self.vary_headers = tuple(v.lower().encode("latin-1") for v in vary)
        self.stampede = stampede
        self.cache = cache or Cache(
            backend,
            ttl=ttl,
            prefix=prefix,
            serializer=serializer or PickleSerializer(),
        )

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope["type"] != "http":
            await self.app(scope, receive, send)
            return

        method = scope.get("method", "").upper()
        if method not in self.methods:
            await self.app(scope, receive, send)
            return

        headers = scope.get("headers", [])
        if _request_opts_out(headers):
            await self.app(scope, receive, send)
            return

        key = self._build_key(method, scope, headers)

        async def factory() -> dict[str, Any] | None:
            return await self._run_and_capture(scope, receive, send_drop=True)

        # We can't just wrap the downstream app in `get_or_set`, because on a
        # HIT we need to emit events to the *current* `send` without invoking
        # the app at all. Split the paths explicitly.
        cached = await self.cache.get(key)
        if cached is not None:
            await _emit(send, cached, hit=True)
            return

        if self.stampede:
            try:
                async with self.cache._lock.acquire(key):  # noqa: SLF001
                    cached = await self.cache.get(key)
                    if cached is not None:
                        await _emit(send, cached, hit=True)
                        return
                    await self._run_capture_emit(scope, receive, send, key)
                    return
            except Exception:
                pass  # fall through to unprotected path

        await self._run_capture_emit(scope, receive, send, key)

    def _build_key(
        self, method: str, scope: Scope, headers: list[tuple[bytes, bytes]]
    ) -> str:
        path = scope.get("path", "")
        query = scope.get("query_string", b"").decode("latin-1")
        parts = [method, path, query]
        if self.vary_headers:
            lookup = {name: value for name, value in headers}
            for name in self.vary_headers:
                parts.append(lookup.get(name, b"").decode("latin-1"))
        return "|".join(parts)

    async def _run_capture_emit(
        self, scope: Scope, receive: Receive, send: Send, key: str
    ) -> None:
        captured: dict[str, Any] = {"status": None, "headers": [], "body": []}

        async def capture_send(message: Message) -> None:
            t = message["type"]
            if t == "http.response.start":
                captured["status"] = message["status"]
                captured["headers"] = list(message.get("headers") or [])
                # Inject X-Cache: MISS before the headers leave.
                message = {
                    **message,
                    "headers": captured["headers"] + [(b"x-cache", b"MISS")],
                }
            elif t == "http.response.body":
                chunk = message.get("body", b"")
                if chunk:
                    captured["body"].append(chunk)
            await send(message)

        await self.app(scope, receive, capture_send)

        status = captured["status"]
        if status is None or not (200 <= status < 300):
            return
        ttl = _resolve_ttl(captured["headers"], self.default_ttl, self.max_ttl)
        if ttl is None:
            return
        envelope = {
            "status": status,
            "headers": captured["headers"],
            "body": b"".join(captured["body"]),
        }
        await self.cache.set(key, envelope, ttl=ttl)

    async def _run_and_capture(
        self, scope: Scope, receive: Receive, send_drop: bool
    ) -> dict[str, Any] | None:
        # Unused in current flow — retained for future refactor.
        raise NotImplementedError


def _request_opts_out(headers: list[tuple[bytes, bytes]]) -> bool:
    for name, value in headers:
        if name == b"cache-control":
            v = value.lower()
            if b"no-store" in v or b"no-cache" in v:
                return True
    return False


def _resolve_ttl(
    headers: list[tuple[bytes, bytes]], default: int, max_ttl: int
) -> int | None:
    """Parse response Cache-Control. Return `None` if response forbids caching,
    otherwise an int TTL in seconds."""
    for name, value in headers:
        if name != b"cache-control":
            continue
        v = value.lower()
        if b"no-store" in v or b"private" in v:
            return None
        for directive in v.split(b","):
            directive = directive.strip()
            if directive.startswith(b"max-age="):
                try:
                    n = int(directive.removeprefix(b"max-age="))
                except ValueError:
                    continue
                if n <= 0:
                    return None
                return min(n, max_ttl)
    return default


async def _emit(send: Send, envelope: dict[str, Any], *, hit: bool) -> None:
    headers = list(envelope["headers"])
    headers.append((b"x-cache", b"HIT" if hit else b"MISS"))
    await send(
        {
            "type": "http.response.start",
            "status": envelope["status"],
            "headers": headers,
        }
    )
    await send(
        {"type": "http.response.body", "body": envelope["body"], "more_body": False}
    )
