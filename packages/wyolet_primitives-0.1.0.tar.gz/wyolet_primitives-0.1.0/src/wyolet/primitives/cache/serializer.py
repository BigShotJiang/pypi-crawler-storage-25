"""Serializers for cache values.

Two built-ins — pick one at construction time, no user-supplied hooks needed.

- `PickleSerializer` (default): stores any Python object, including dataclasses
  and Pydantic models, round-tripping full types. Not safe on untrusted input
  and not readable from non-Python consumers.
- `JSONSerializer`: `orjson` under the hood, fast and cross-language. Handles
  common types (datetime/date/UUID/Decimal/set/bytes/dataclass/Pydantic)
  through a built-in `default=` hook. Values come back as plain JSON types
  (dict/list/str/int/float/bool/None) — type info is lost.

Custom serializers are supported via the `Serializer` protocol but not
required for typical use.
"""

import base64
import dataclasses
import pickle
from decimal import Decimal
from typing import Any, Protocol


class Serializer(Protocol):
    def dumps(self, obj: Any) -> bytes: ...
    def loads(self, data: bytes) -> Any: ...


class PickleSerializer:
    """Default. Any Python object in, same object out. Python-only, unsafe on
    untrusted data."""

    __slots__ = ("_protocol",)

    def __init__(self, protocol: int = pickle.HIGHEST_PROTOCOL) -> None:
        self._protocol = protocol

    def dumps(self, obj: Any) -> bytes:
        return pickle.dumps(obj, protocol=self._protocol)

    def loads(self, data: bytes) -> Any:
        return pickle.loads(data)


class JSONSerializer:
    """`orjson`-backed JSON. Cross-language, fast, lossy on type round-trip.

    Handled by the built-in `default=` hook:
    - `Decimal` → str
    - `set`/`frozenset` → list
    - `bytes` → base64 str
    - `dataclass` instance → dict via `dataclasses.asdict`
    - Pydantic `BaseModel` → `.model_dump()`
    - Anything with `__json__()` → whatever it returns

    `datetime`/`date`/`time`/`UUID` are native in orjson.
    """

    __slots__ = ("_option",)

    def __init__(self, *, sort_keys: bool = False) -> None:
        import orjson

        option = orjson.OPT_SERIALIZE_NUMPY | orjson.OPT_NON_STR_KEYS
        if sort_keys:
            option |= orjson.OPT_SORT_KEYS
        self._option = option

    def dumps(self, obj: Any) -> bytes:
        import orjson

        return orjson.dumps(obj, default=_json_default, option=self._option)

    def loads(self, data: bytes) -> Any:
        import orjson

        return orjson.loads(data)


def _json_default(obj: Any) -> Any:
    if isinstance(obj, Decimal):
        return str(obj)
    if isinstance(obj, (set, frozenset)):
        return list(obj)
    if isinstance(obj, bytes):
        return base64.b64encode(obj).decode("ascii")
    if dataclasses.is_dataclass(obj) and not isinstance(obj, type):
        return dataclasses.asdict(obj)
    model_dump = getattr(obj, "model_dump", None)
    if callable(model_dump):
        return model_dump()
    to_json = getattr(obj, "__json__", None)
    if callable(to_json):
        return to_json()
    raise TypeError(f"Object of type {type(obj).__name__} is not JSON-serializable")
