"""Function-level cache with stampede protection.

Two shapes:

- `Cache` — low-level async KV with `get / set / delete / get_or_set`. Keys
  are plain strings; values are any type the chosen `Serializer` can handle.
- `@cached(cache, ttl, key=...)` — decorator for async functions. Keys on
  the call args (or a user-supplied callable), serves from cache until TTL
  expires.

Stampede protection (the whole reason this primitive exists over rolling
your own `backend.get`/`backend.set`):

When a cache miss happens, only one caller runs the expensive factory. Any
concurrent callers take a `DistributedLock` on the cache key, and on
acquisition re-check the cache — by then the first caller has populated it,
so they hit and return without a duplicate factory call. This turns 1000
concurrent misses into 1 factory invocation instead of 1000.

Set `stampede=False` on `get_or_set` / `@cached` to opt out (small code paths
where the extra round trip isn't worth it).
"""

import asyncio
import functools
import hashlib
from typing import Any, Awaitable, Callable, TypeVar

from wyolet.primitives.backends.base import Backend
from wyolet.primitives.cache.serializer import PickleSerializer, Serializer
from wyolet.primitives.lock.lock import DistributedLock

T = TypeVar("T")


class Cache:
    """Async cache over any `Backend`, with optional stampede protection."""

    def __init__(
        self,
        backend: Backend,
        *,
        ttl: int | None = 300,
        prefix: str = "cache:",
        serializer: Serializer | None = None,
        lock: DistributedLock | None = None,
        lock_ttl: int = 30,
        lock_wait: float = 10.0,
    ) -> None:
        """
        Args:
            backend: Shared backend. Stampede lock reuses the same backend.
            ttl: Default TTL in seconds for `set` / `get_or_set`. `None` = no
                expiry. Override per-call via the `ttl=` kwarg.
            prefix: Namespacing prefix for cache keys.
            serializer: Defaults to `PickleSerializer`. Swap in `JSONSerializer`
                for cross-language / untrusted-data scenarios.
            lock: Pre-built `DistributedLock`; otherwise one is created with
                the `lock_ttl` / `lock_wait` below and prefix `cache-lock:`.
            lock_ttl: TTL of the stampede lock — upper bound on how long a
                factory call is allowed to run before a waiter takes over.
            lock_wait: Seconds a waiter will block on the lock. If exceeded,
                the waiter falls through and calls the factory itself (rather
                than failing) — degrades to no-protection under extreme
                contention instead of erroring.
        """
        self._backend = backend
        self._ttl = ttl
        self._prefix = prefix
        self._serializer = serializer or PickleSerializer()
        self._lock = lock or DistributedLock(
            backend,
            ttl=lock_ttl,
            wait=lock_wait,
            retry_delay=0.02,
            renew=True,
            prefix="cache-lock:",
        )

    def _key(self, key: str) -> str:
        return self._prefix + key

    async def get(self, key: str, default: Any = None) -> Any:
        raw = await self._backend.get(self._key(key))
        if raw is None:
            return default
        return self._serializer.loads(raw)

    async def set(self, key: str, value: Any, ttl: int | None = ...) -> None:
        effective = self._ttl if ttl is ... else ttl
        await self._backend.set(
            self._key(key), self._serializer.dumps(value), ttl=effective
        )

    async def delete(self, key: str) -> None:
        await self._backend.delete(self._key(key))

    async def get_or_set(
        self,
        key: str,
        factory: Callable[[], Awaitable[T]],
        *,
        ttl: int | None = ...,
        stampede: bool = True,
    ) -> T:
        """Return cached value, or call `factory()` and cache its result.

        With `stampede=True` (default), concurrent misses serialize on a
        `DistributedLock`; only one caller runs `factory`, the rest read the
        freshly-cached value.
        """
        raw = await self._backend.get(self._key(key))
        if raw is not None:
            return self._serializer.loads(raw)

        if not stampede:
            value = await factory()
            await self.set(key, value, ttl=ttl)
            return value

        try:
            async with self._lock.acquire(key):
                raw = await self._backend.get(self._key(key))
                if raw is not None:
                    return self._serializer.loads(raw)
                value = await factory()
                await self.set(key, value, ttl=ttl)
                return value
        except Exception:
            # Lock subsystem failure (timeout, backend error): degrade to
            # unprotected factory call rather than propagate — caching is
            # best-effort by nature.
            value = await factory()
            await self.set(key, value, ttl=ttl)
            return value


def _default_key(args: tuple[Any, ...], kwargs: dict[str, Any]) -> str:
    # Stable hash of repr — fine for ints/strs/etc.; not for objects with
    # nondeterministic repr. Users who need custom shape pass `key=`.
    payload = repr((args, sorted(kwargs.items()))).encode()
    return hashlib.blake2b(payload, digest_size=16).hexdigest()


def cached(
    cache: Cache,
    *,
    ttl: int | None = ...,
    key: Callable[..., str] | None = None,
    namespace: str | None = None,
    stampede: bool = True,
) -> Callable[[Callable[..., Awaitable[T]]], Callable[..., Awaitable[T]]]:
    """Decorator. Wrap an async function so its return value is cached.

    Args:
        cache: The `Cache` instance to use.
        ttl: Override the cache's default TTL for this function.
        key: Callable `(*args, **kwargs) -> str` producing the cache key.
            Default hashes a repr of the call args.
        namespace: Prepended to every generated key. Defaults to the wrapped
            function's qualified name — change this if you rename the function
            and want to invalidate prior entries.
        stampede: Serialize concurrent misses. Default True.
    """

    def decorator(fn: Callable[..., Awaitable[T]]) -> Callable[..., Awaitable[T]]:
        if not asyncio.iscoroutinefunction(fn):
            raise TypeError("@cached requires an async function")

        ns = namespace if namespace is not None else f"{fn.__module__}.{fn.__qualname__}"
        key_fn = key or (lambda *a, **kw: _default_key(a, kw))

        @functools.wraps(fn)
        async def wrapper(*args: Any, **kwargs: Any) -> T:
            k = f"{ns}:{key_fn(*args, **kwargs)}"
            return await cache.get_or_set(
                k, lambda: fn(*args, **kwargs), ttl=ttl, stampede=stampede
            )

        wrapper.cache = cache  # type: ignore[attr-defined]
        wrapper.cache_key = lambda *a, **kw: f"{ns}:{key_fn(*a, **kw)}"  # type: ignore[attr-defined]
        return wrapper

    return decorator
