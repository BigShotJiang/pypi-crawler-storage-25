"""Distributed lock over any `Backend`.

Single-node correctness model (redlock-over-one-Redis, not the full redlock
multi-node quorum). Good enough for 99% of app-level locks: job dedupe,
cron-lite leader election, per-resource critical sections. Never use this for
consistency guarantees that require consensus.

Key properties:
- Atomic acquire via `Backend.set_nx` (SET NX EX on Redis, lock-protected on
  MemoryBackend).
- Safe release via `Backend.compare_and_delete` — a holder can't accidentally
  release a lock whose TTL expired and was re-acquired by someone else.
- Optional auto-renew: a background task extends the TTL while the critical
  section runs, so a long-running job doesn't get interrupted mid-work.
"""

import asyncio
import secrets
from dataclasses import dataclass
from types import TracebackType

from wyolet.primitives.backends.base import Backend


class LockAcquireError(TimeoutError):
    """Raised when `acquire()` cannot obtain the lock within `wait` seconds."""


@dataclass(slots=True)
class _Config:
    ttl: int
    wait: float
    retry_delay: float
    renew: bool
    renew_ratio: float


class DistributedLock:
    """Factory that produces per-key `LockHandle`s with shared config.

    Typical use:
        lock = DistributedLock(backend, ttl=30)
        async with lock.acquire("order:42"):
            await do_work()
    """

    def __init__(
        self,
        backend: Backend,
        *,
        ttl: int = 30,
        wait: float = 0.0,
        retry_delay: float = 0.05,
        renew: bool = True,
        renew_ratio: float = 0.5,
        prefix: str = "lock:",
    ) -> None:
        """
        Args:
            ttl: Seconds the lock is held in the backend if the holder dies.
                Must be > 0. On a crashed holder, the lock auto-releases after
                `ttl` seconds.
            wait: Seconds to keep retrying acquire. `0` = fail immediately.
            retry_delay: Seconds to sleep between acquire attempts.
            renew: If True, a background task extends the TTL every
                `ttl * renew_ratio` seconds while the lock is held.
            renew_ratio: Fraction of `ttl` between renewals. Default 0.5.
        """
        if ttl <= 0:
            raise ValueError("ttl must be > 0")
        if not 0 < renew_ratio < 1:
            raise ValueError("renew_ratio must be in (0, 1)")
        self._backend = backend
        self._prefix = prefix
        self._cfg = _Config(
            ttl=ttl,
            wait=wait,
            retry_delay=retry_delay,
            renew=renew,
            renew_ratio=renew_ratio,
        )

    def acquire(self, key: str) -> "LockHandle":
        """Build a handle. Use as `async with lock.acquire(key): ...`.
        The actual acquire happens in `__aenter__`."""
        return LockHandle(self._backend, self._prefix + key, self._cfg)


class LockHandle:
    """One acquisition attempt. Single-use async context manager."""

    __slots__ = ("_backend", "_key", "_cfg", "_token", "_renew_task", "_held")

    def __init__(self, backend: Backend, key: str, cfg: _Config) -> None:
        self._backend = backend
        self._key = key
        self._cfg = cfg
        self._token = secrets.token_urlsafe(24).encode()
        self._renew_task: asyncio.Task[None] | None = None
        self._held = False

    @property
    def held(self) -> bool:
        return self._held

    async def __aenter__(self) -> "LockHandle":
        loop = asyncio.get_running_loop()
        deadline = loop.time() + self._cfg.wait
        while True:
            acquired = await self._backend.set_nx(
                self._key, self._token, ttl=self._cfg.ttl
            )
            if acquired:
                self._held = True
                if self._cfg.renew:
                    self._renew_task = asyncio.create_task(self._renew_loop())
                return self
            if loop.time() >= deadline:
                raise LockAcquireError(
                    f"could not acquire lock {self._key!r} within "
                    f"{self._cfg.wait}s"
                )
            await asyncio.sleep(self._cfg.retry_delay)

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc: BaseException | None,
        tb: TracebackType | None,
    ) -> None:
        await self.release()

    async def release(self) -> bool:
        """Release the lock. Returns `True` if we still held it (fencing-safe),
        `False` if the TTL expired first and someone else may have taken over."""
        if not self._held:
            return False
        self._held = False
        if self._renew_task is not None:
            self._renew_task.cancel()
            try:
                await self._renew_task
            except (asyncio.CancelledError, Exception):
                pass
            self._renew_task = None
        return await self._backend.compare_and_delete(self._key, self._token)

    async def _renew_loop(self) -> None:
        interval = self._cfg.ttl * self._cfg.renew_ratio
        try:
            while True:
                await asyncio.sleep(interval)
                # Only renew if we still hold it — if compare-and-delete raced
                # with us, don't extend someone else's lock.
                current = await self._backend.get(self._key)
                if current != self._token:
                    self._held = False
                    return
                await self._backend.expire(self._key, self._cfg.ttl)
        except asyncio.CancelledError:
            raise
