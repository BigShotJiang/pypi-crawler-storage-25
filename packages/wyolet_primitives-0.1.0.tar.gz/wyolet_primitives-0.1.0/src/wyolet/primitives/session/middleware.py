import uuid
from http.cookies import SimpleCookie
from typing import Any, Awaitable, Callable, Literal, MutableMapping

from itsdangerous import BadSignature, SignatureExpired, TimestampSigner

from wyolet.primitives.backends.base import Backend
from wyolet.primitives.session.store import Session, SessionState

Scope = MutableMapping[str, Any]
Message = MutableMapping[str, Any]
Receive = Callable[[], Awaitable[Message]]
Send = Callable[[Message], Awaitable[None]]
ASGIApp = Callable[[Scope, Receive, Send], Awaitable[None]]

SameSite = Literal["lax", "strict", "none"]


class SessionMiddleware:
    """Pure ASGI session middleware.

    Reads a signed session id from a cookie, loads the backing `Session`,
    attaches it to `scope["session"]`, and writes back any changes after the
    response starts. Avoids Starlette's `BaseHTTPMiddleware` — that class is
    known to break streaming and background tasks.
    """

    def __init__(
        self,
        app: ASGIApp,
        *,
        backend: Backend,
        secret_key: str,
        cookie_name: str = "sid",
        max_age: int = 14 * 24 * 60 * 60,  # 14 days
        path: str = "/",
        domain: str | None = None,
        http_only: bool = True,
        secure: bool = True,
        same_site: SameSite = "lax",
        scope_key: str = "session",
    ) -> None:
        self.app = app
        self.backend = backend
        self.cookie_name = cookie_name
        self.max_age = max_age
        self.path = path
        self.domain = domain
        self.http_only = http_only
        self.secure = secure
        self.same_site = same_site
        self.scope_key = scope_key
        self.signer = TimestampSigner(secret_key)

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope["type"] not in ("http", "websocket"):
            await self.app(scope, receive, send)
            return

        session, action = await self._resolve_session(scope)
        scope[self.scope_key] = session

        # WebSockets don't re-issue cookies; just attach session and pass through.
        if scope["type"] == "websocket":
            await self.app(scope, receive, send)
            return

        initial_id = session.id

        async def send_wrapper(message: Message) -> None:
            if message["type"] == "http.response.start":
                wrote = await session.save(ttl=self.max_age)
                id_changed = session.id != initial_id
                needs_cookie = action == "mint" or id_changed or wrote
                if session.state is SessionState.CLEARED:
                    self._set_header(message, self._clear_cookie())
                elif needs_cookie:
                    self._set_header(message, self._issue_cookie(session.id))
            await send(message)

        await self.app(scope, receive, send_wrapper)

    # ── session resolution ─────────────────────────────────────────────────
    async def _resolve_session(
        self, scope: Scope
    ) -> tuple[Session, Literal["mint", "reuse"]]:
        signed = self._read_cookie(scope)
        if signed is None:
            return self._mint(cause="new"), "mint"

        try:
            raw = self.signer.unsign(signed, max_age=self.max_age)
            sid = raw.decode()
        except SignatureExpired:
            return self._mint(cause="expired"), "mint"
        except BadSignature:
            return self._mint(cause="bad_signature"), "mint"

        session = Session(self.backend, sid, cause="reuse")
        await session.load()
        return session, "reuse"

    def _mint(self, *, cause: str) -> Session:
        return Session(
            self.backend,
            str(uuid.uuid4()),
            state=SessionState.NEW,
            cause=cause,
        )

    # ── cookie plumbing ────────────────────────────────────────────────────
    def _read_cookie(self, scope: Scope) -> str | None:
        for name, value in scope.get("headers", []):
            if name == b"cookie":
                jar = SimpleCookie()
                jar.load(value.decode("latin-1"))
                morsel = jar.get(self.cookie_name)
                return morsel.value if morsel is not None else None
        return None

    def _issue_cookie(self, sid: str) -> bytes:
        signed = self.signer.sign(sid).decode()
        return self._build_cookie(signed, max_age=self.max_age).encode("latin-1")

    def _clear_cookie(self) -> bytes:
        return self._build_cookie("", max_age=0).encode("latin-1")

    def _build_cookie(self, value: str, *, max_age: int) -> str:
        parts = [f"{self.cookie_name}={value}", f"Path={self.path}", f"Max-Age={max_age}"]
        if self.domain:
            parts.append(f"Domain={self.domain}")
        if self.http_only:
            parts.append("HttpOnly")
        if self.secure:
            parts.append("Secure")
        parts.append(f"SameSite={self.same_site.capitalize()}")
        return "; ".join(parts)

    @staticmethod
    def _set_header(message: Message, value: bytes) -> None:
        headers = list(message.get("headers") or [])
        headers.append((b"set-cookie", value))
        message["headers"] = headers
