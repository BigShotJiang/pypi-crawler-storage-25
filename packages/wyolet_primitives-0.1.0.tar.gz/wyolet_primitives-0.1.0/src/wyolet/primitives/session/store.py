import enum
import json
import uuid
from typing import Any, Iterator

from wyolet.primitives.backends.base import Backend


class SessionState(enum.Enum):
    UNLOADED = "unloaded"  # no backend round-trip yet
    LOADED = "loaded"      # data reflects backend state
    NEW = "new"            # fresh session, never persisted
    CLEARED = "cleared"    # explicitly dropped; will delete cookie


class Session:
    """Dict-like session bound to one backend key.

    Flat payload (no `{"store": {...}}` envelope). Dirty-tracks mutations so
    unchanged sessions don't round-trip to the backend. Metadata like "why was
    this session created" is a per-request attribute (`cause`), not persisted.
    """

    __slots__ = ("_backend", "_id", "_data", "_state", "_dirty", "cause")

    def __init__(
        self,
        backend: Backend,
        session_id: str,
        *,
        state: SessionState = SessionState.UNLOADED,
        cause: str | None = None,
    ) -> None:
        self._backend = backend
        self._id = session_id
        self._data: dict[str, Any] = {}
        self._state = state
        self._dirty = False
        self.cause = cause

    # ── identity / state ───────────────────────────────────────────────────
    @property
    def id(self) -> str:
        return self._id

    @property
    def state(self) -> SessionState:
        return self._state

    @property
    def modified(self) -> bool:
        return self._dirty

    # ── dict-like access ───────────────────────────────────────────────────
    # Reads raise if called before load() on a non-new session — silent empty
    # reads were the biggest footgun in the previous implementation.
    def __getitem__(self, key: str) -> Any:
        self._require_loaded()
        return self._data[key]

    def get(self, key: str, default: Any = None) -> Any:
        self._require_loaded()
        return self._data.get(key, default)

    def __setitem__(self, key: str, value: Any) -> None:
        self._require_loaded()
        if self._data.get(key, _MISSING) != value:
            self._data[key] = value
            self._dirty = True

    def __delitem__(self, key: str) -> None:
        self._require_loaded()
        if key in self._data:
            del self._data[key]
            self._dirty = True

    def __contains__(self, key: str) -> bool:
        self._require_loaded()
        return key in self._data

    def __iter__(self) -> Iterator[str]:
        self._require_loaded()
        return iter(self._data)

    def __len__(self) -> int:
        self._require_loaded()
        return len(self._data)

    # ── lifecycle ──────────────────────────────────────────────────────────
    async def load(self) -> None:
        """Load from backend. Missing key → empty NEW session."""
        raw = await self._backend.get(self._id)
        if raw is None:
            self._data = {}
            self._state = SessionState.NEW
        else:
            self._data = json.loads(raw)
            self._state = SessionState.LOADED
        self._dirty = False

    async def save(self, ttl: int | None = None) -> bool:
        """Persist if dirty or NEW with data. Returns True if a write happened."""
        if self._state is SessionState.CLEARED:
            return False
        if not self._dirty and self._state is SessionState.LOADED:
            return False
        if not self._data and self._state is SessionState.NEW:
            return False
        await self._backend.set(self._id, json.dumps(self._data).encode(), ttl=ttl)
        self._state = SessionState.LOADED
        self._dirty = False
        return True

    async def clear(self) -> None:
        await self._backend.delete(self._id)
        self._data = {}
        self._state = SessionState.CLEARED
        self._dirty = False

    async def regenerate(self) -> str:
        """Rotate session_id (call on login to defeat fixation). Deletes the old
        backend entry. Caller is responsible for re-issuing the cookie — the
        middleware does this automatically on response."""
        old_id = self._id
        self._id = str(uuid.uuid4())
        await self._backend.delete(old_id)
        self._dirty = True  # force save under new id
        if self._state is SessionState.LOADED:
            self._state = SessionState.NEW
        return self._id

    # ── internals ──────────────────────────────────────────────────────────
    def _require_loaded(self) -> None:
        if self._state is SessionState.UNLOADED:
            raise RuntimeError(
                "Session accessed before load(). Call `await session.load()` "
                "or let SessionMiddleware manage it."
            )


_MISSING = object()
