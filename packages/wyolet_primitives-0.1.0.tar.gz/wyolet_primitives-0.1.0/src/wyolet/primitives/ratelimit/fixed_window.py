from datetime import datetime, timedelta, timezone

from wyolet.primitives.backends.base import Backend
from wyolet.primitives.ratelimit.base import RateLimitResult, RateLimitStrategy


class FixedWindow(RateLimitStrategy):
    """Fixed-window counter.

    Each request atomically increments a counter bucketed by key. The window
    starts on the first request that creates the counter and expires `window`
    seconds later. Simple, cheap, one round-trip per check — but susceptible
    to bursts at window boundaries (up to 2×limit across a narrow boundary).

    Needs only `Backend.incr(key, by, ttl)` with the "set TTL only on create"
    semantics our `Backend` contract already guarantees. Works on every
    backend, no capability mixins required.

    Reset time is approximate (`now + window`), representing an upper bound.
    Accurate reset would require a `ttl()` backend method — deferred until a
    strategy actually needs it for correctness.
    """

    def __init__(
        self,
        backend: Backend,
        *,
        limit: int,
        window: int,
        prefix: str = "rl:fw:",
    ) -> None:
        if limit <= 0:
            raise ValueError("limit must be > 0")
        if window <= 0:
            raise ValueError("window must be > 0 seconds")
        self._backend = backend
        self.limit = limit
        self.window = window
        self._prefix = prefix

    async def check(self, key: str, *, cost: int = 1) -> RateLimitResult:
        if cost <= 0:
            raise ValueError("cost must be > 0")

        count = await self._backend.incr(
            self._prefix + key, by=cost, ttl=self.window
        )
        now = datetime.now(timezone.utc)
        reset_at = now + timedelta(seconds=self.window)

        if count <= self.limit:
            return RateLimitResult(
                allowed=True,
                limit=self.limit,
                remaining=self.limit - count,
                reset_at=reset_at,
                retry_after=None,
            )

        # Over the limit. We don't know exact remaining TTL without another
        # round-trip; surface the window as the worst-case `retry_after`.
        return RateLimitResult(
            allowed=False,
            limit=self.limit,
            remaining=0,
            reset_at=reset_at,
            retry_after=self.window,
        )
