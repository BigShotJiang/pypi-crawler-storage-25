"""Pure-ASGI rate-limit middleware.

Works with any ASGI framework (FastAPI, Starlette, Litestar, BlackSheep, …).
No framework imports. Mirrors the structure of `session/middleware.py`.
"""

import inspect
from typing import Any, Awaitable, Callable, MutableMapping

from wyolet.primitives.ratelimit.base import RateLimitResult, RateLimitStrategy
from wyolet.primitives.ratelimit.headers import (
    build_429,
    merge_headers,
    rate_limit_headers,
)
from wyolet.primitives.ratelimit.keys import KeyExtractor

Scope = MutableMapping[str, Any]
Message = MutableMapping[str, Any]
Receive = Callable[[], Awaitable[Message]]
Send = Callable[[Message], Awaitable[None]]
ASGIApp = Callable[[Scope, Receive, Send], Awaitable[None]]
SkipFn = Callable[[Scope], bool]


class RateLimitMiddleware:
    """Apply a `RateLimitStrategy` to incoming HTTP requests.

    On deny: short-circuits with a 429 response (headers + JSON body).
    On allow: attaches the `RateLimitResult` to `scope[scope_key]` so
    downstream handlers / framework deps can read it, and decorates the
    outgoing response with `X-RateLimit-*` headers.

    When the key extractor returns `None`, the request is passed through
    unthrottled — `compose(..., from_ip())` is the typical way to avoid this.
    """

    def __init__(
        self,
        app: ASGIApp,
        *,
        strategy: RateLimitStrategy,
        key: KeyExtractor,
        cost: int = 1,
        skip: SkipFn | None = None,
        scope_key: str = "rate_limit",
        deny_body: bytes | None = None,
    ) -> None:
        self.app = app
        self.strategy = strategy
        self.key = key
        self.cost = cost
        self.skip = skip
        self.scope_key = scope_key
        self.deny_body = deny_body

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope["type"] != "http" or (self.skip is not None and self.skip(scope)):
            await self.app(scope, receive, send)
            return

        key = self.key(scope)
        if inspect.isawaitable(key):
            key = await key
        if key is None:
            # No key → no limit applied. Deliberate: an auth-scoped extractor
            # returning None on anonymous requests shouldn't block them.
            await self.app(scope, receive, send)
            return

        result = await self.strategy.check(key, cost=self.cost)
        scope[self.scope_key] = result

        if not result.allowed:
            await self._send_denial(send, result)
            return

        # Allowed — inject headers on the outgoing response.
        async def send_wrapper(message: Message) -> None:
            if message["type"] == "http.response.start":
                message["headers"] = merge_headers(
                    message.get("headers"), rate_limit_headers(result)
                )
            await send(message)

        await self.app(scope, receive, send_wrapper)

    async def _send_denial(self, send: Send, result: RateLimitResult) -> None:
        status, headers, body = build_429(result, body=self.deny_body)
        await send(
            {"type": "http.response.start", "status": status, "headers": headers}
        )
        await send({"type": "http.response.body", "body": body, "more_body": False})
