from abc import ABC, abstractmethod
from dataclasses import dataclass
from datetime import datetime


class UnsupportedBackendError(TypeError):
    """Raised when a rate-limit strategy is constructed against a backend
    that lacks a required capability. Surfaces at construction, not at
    request time, so misconfigurations fail in CI instead of in production."""


@dataclass(slots=True)
class RateLimitResult:
    """Outcome of a single `check` call.

    Maps directly onto the standard response headers:
    - `X-RateLimit-Limit`:     `limit`
    - `X-RateLimit-Remaining`: `remaining`
    - `X-RateLimit-Reset`:     `reset_at` (as unix ts)
    - `Retry-After`:           `retry_after` (when `allowed=False`)
    """

    allowed: bool
    limit: int
    remaining: int
    reset_at: datetime
    retry_after: int | None = None


class RateLimitStrategy(ABC):
    """Algorithm contract. Subclasses hold config; `check` does per-request work."""

    limit: int

    @abstractmethod
    async def check(self, key: str, *, cost: int = 1) -> RateLimitResult:
        """Attempt to consume `cost` units against `key`. Never raises for
        normal flow — denial is signalled by `result.allowed == False`."""
        ...
