"""Key extractors for rate limiting.

A key extractor is a callable that takes an ASGI scope and returns a string
used to bucket the rate limit (e.g. an IP, a user id, an API key). Extractors
may be sync or async; the middleware awaits as needed.

Return `None` to signal "no key here" — useful for composition with `compose`
so you can chain fallbacks (e.g. try user_id, fall back to IP).
"""

import inspect
from typing import Any, Awaitable, Callable, MutableMapping

Scope = MutableMapping[str, Any]
KeyExtractor = Callable[[Scope], str | None | Awaitable[str | None]]


def from_ip(*, trust_forwarded_for: bool = False) -> KeyExtractor:
    """Extract client IP from `scope['client']`.

    If `trust_forwarded_for=True`, prefers the first entry of
    `X-Forwarded-For` (or `X-Real-IP`). Only enable this when you actually
    run behind a proxy that sets these headers — otherwise clients can spoof
    their rate-limit key by sending the header themselves.
    """

    def extract(scope: Scope) -> str | None:
        if trust_forwarded_for:
            headers = dict(scope.get("headers", []))
            xff = headers.get(b"x-forwarded-for")
            if xff:
                return xff.decode("latin-1").split(",", 1)[0].strip()
            real = headers.get(b"x-real-ip")
            if real:
                return real.decode("latin-1").strip()
        client = scope.get("client")
        return client[0] if client else None

    return extract


def from_header(name: str) -> KeyExtractor:
    """Extract from a request header (case-insensitive)."""
    target = name.lower().encode("latin-1")

    def extract(scope: Scope) -> str | None:
        for k, v in scope.get("headers", []):
            if k == target:
                return v.decode("latin-1")
        return None

    return extract


def from_cookie(name: str) -> KeyExtractor:
    """Extract a cookie value from the `Cookie` header."""
    from http.cookies import SimpleCookie

    def extract(scope: Scope) -> str | None:
        for k, v in scope.get("headers", []):
            if k == b"cookie":
                jar = SimpleCookie()
                jar.load(v.decode("latin-1"))
                morsel = jar.get(name)
                return morsel.value if morsel is not None else None
        return None

    return extract


def from_scope(key: str) -> KeyExtractor:
    """Extract a string from `scope[key]` — useful for upstream middlewares
    that stash `user_id`, `tenant_id`, etc. on the scope."""

    def extract(scope: Scope) -> str | None:
        value = scope.get(key)
        return str(value) if value is not None else None

    return extract


def compose(*extractors: KeyExtractor) -> KeyExtractor:
    """Try extractors in order, returning the first non-`None` result.

    Typical use: prefer authenticated user, fall back to IP.
        compose(from_scope("user_id"), from_ip())
    """

    async def extract(scope: Scope) -> str | None:
        for e in extractors:
            result = e(scope)
            if inspect.isawaitable(result):
                result = await result
            if result is not None:
                return result
        return None

    return extract
