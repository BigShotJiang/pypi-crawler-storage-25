"""Header + response helpers for the rate-limit middleware.

Kept in their own module so framework glue (FastAPI `Depends`, Litestar guards,
etc.) can reuse the same formatting without depending on the middleware.
"""

import json

from wyolet.primitives.ratelimit.base import RateLimitResult

HeaderList = list[tuple[bytes, bytes]]


def rate_limit_headers(result: RateLimitResult) -> HeaderList:
    """Standard `X-RateLimit-*` headers + `Retry-After` on denial."""
    headers: HeaderList = [
        (b"x-ratelimit-limit", str(result.limit).encode()),
        (b"x-ratelimit-remaining", str(result.remaining).encode()),
        (b"x-ratelimit-reset", str(int(result.reset_at.timestamp())).encode()),
    ]
    if not result.allowed and result.retry_after is not None:
        headers.append((b"retry-after", str(result.retry_after).encode()))
    return headers


def merge_headers(existing: HeaderList | None, extra: HeaderList) -> HeaderList:
    """Append `extra` after `existing`, filtering out any duplicate names from
    `existing` so the rate-limit values win. Safe to call with `None`."""
    names = {name for name, _ in extra}
    base = [(n, v) for n, v in (existing or []) if n not in names]
    return base + extra


def build_429(
    result: RateLimitResult,
    *,
    body: bytes | None = None,
    content_type: str = "application/json",
) -> tuple[int, HeaderList, bytes]:
    """Compose a complete 429 response. Default body is a tiny JSON payload;
    pass `body=b""` for an empty response, or your own bytes to override."""
    if body is None:
        payload = {
            "error": "rate_limited",
            "retry_after": result.retry_after,
            "reset_at": int(result.reset_at.timestamp()),
        }
        body = json.dumps(payload).encode()

    headers = rate_limit_headers(result)
    headers.append((b"content-type", content_type.encode("latin-1")))
    headers.append((b"content-length", str(len(body)).encode()))
    return 429, headers, body
