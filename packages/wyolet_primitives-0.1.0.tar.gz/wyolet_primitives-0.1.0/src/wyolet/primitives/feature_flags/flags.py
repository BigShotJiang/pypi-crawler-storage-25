"""Feature flags with percentage rollout, allow/block lists, and a tiny
in-process cache in front of the shared `Backend`.

Storage model — one key per flag:

    flag:<name> → JSON {
        "enabled": bool,
        "rollout": int (0..100),
        "allow": [subject, ...],
        "block": [subject, ...],
    }

Evaluation precedence for `is_enabled(name, subject=...)`:

1. Flag missing or `enabled: False` → False (hard off).
2. `subject` in `block` → False (per-subject killswitch).
3. `subject` in `allow` → True (force-on for beta testers / staff).
4. `rollout == 100` → True (full rollout).
5. `rollout == 0` → False.
6. Deterministic bucket: `bucket(subject, name) < rollout` → True.
   Same (subject, name) always falls in the same bucket, so users don't
   flicker between variants across requests.
7. If `subject is None`, rollout/allow/block are skipped — flag becomes
   a pure killswitch (`enabled` is the only factor).

Bucketing identity — the caller picks. `user_id` for logged-in features,
`session_id` for pre-login A/B, `org_id` for B2B per-tenant rollout,
`device_id` for mobile. Don't use IP.

In-process cache:
- Each `FeatureFlags` instance keeps a private `dict[name, (flag, expires_at)]`.
- Every replica hits the backend at most once per flag per `cache_ttl`.
- Writes via `set()` / `delete()` invalidate the local cache only in the
  writing process; other replicas pick up the change within their TTL.
- Set `cache_ttl=0` to disable the cache (useful in tests or when the
  Backend is already `MemoryBackend`).
"""

import hashlib
import json
import time
from dataclasses import asdict, dataclass, field

from wyolet.primitives.backends.base import Backend


@dataclass(slots=True)
class Flag:
    name: str
    enabled: bool = False
    rollout: int = 0
    allow: list[str] = field(default_factory=list)
    block: list[str] = field(default_factory=list)

    def __post_init__(self) -> None:
        if not 0 <= self.rollout <= 100:
            raise ValueError("rollout must be in [0, 100]")

    def evaluate(self, subject: str | None) -> bool:
        if not self.enabled:
            return False
        if subject is None:
            return True
        if subject in self.block:
            return False
        if subject in self.allow:
            return True
        if self.rollout >= 100:
            return True
        if self.rollout <= 0:
            return False
        return _bucket(subject, self.name) < self.rollout

    def to_json(self) -> bytes:
        d = asdict(self)
        d.pop("name", None)  # stored under the key; no need to duplicate
        return json.dumps(d).encode()

    @classmethod
    def from_json(cls, name: str, raw: bytes) -> "Flag":
        obj = json.loads(raw)
        return cls(
            name=name,
            enabled=bool(obj.get("enabled", False)),
            rollout=int(obj.get("rollout", 0)),
            allow=list(obj.get("allow") or []),
            block=list(obj.get("block") or []),
        )


class FeatureFlags:
    """Read/write feature flags with an in-process TTL cache."""

    __slots__ = ("_backend", "_prefix", "_cache_ttl", "_cache")

    def __init__(
        self,
        backend: Backend,
        *,
        prefix: str = "flag:",
        cache_ttl: float = 10.0,
    ) -> None:
        """
        Args:
            backend: Shared backend — source of truth for flag state.
            prefix: Namespacing prefix for flag keys.
            cache_ttl: Seconds to cache flag values in-process. Lower =
                faster propagation, more backend load. Default 10s suits
                most cases. Set to 0 to bypass the cache entirely.
        """
        if cache_ttl < 0:
            raise ValueError("cache_ttl must be >= 0")
        self._backend = backend
        self._prefix = prefix
        self._cache_ttl = cache_ttl
        self._cache: dict[str, tuple[Flag | None, float]] = {}

    def _key(self, name: str) -> str:
        return self._prefix + name

    async def get(self, name: str) -> Flag | None:
        """Return the flag, using the local cache if fresh. `None` if the
        flag doesn't exist."""
        if self._cache_ttl:
            entry = self._cache.get(name)
            if entry is not None and entry[1] > time.monotonic():
                return entry[0]
        raw = await self._backend.get(self._key(name))
        flag = Flag.from_json(name, raw) if raw is not None else None
        if self._cache_ttl:
            self._cache[name] = (flag, time.monotonic() + self._cache_ttl)
        return flag

    async def is_enabled(self, name: str, *, subject: str | None = None) -> bool:
        """Hot-path evaluation. Returns `False` for missing flags so a
        typo or not-yet-created flag defaults to off."""
        flag = await self.get(name)
        if flag is None:
            return False
        return flag.evaluate(subject)

    async def set(
        self,
        name: str,
        *,
        enabled: bool = False,
        rollout: int = 0,
        allow: list[str] | None = None,
        block: list[str] | None = None,
    ) -> Flag:
        flag = Flag(
            name=name,
            enabled=enabled,
            rollout=rollout,
            allow=list(allow or []),
            block=list(block or []),
        )
        await self._backend.set(self._key(name), flag.to_json())
        if self._cache_ttl:
            self._cache[name] = (flag, time.monotonic() + self._cache_ttl)
        return flag

    async def delete(self, name: str) -> None:
        await self._backend.delete(self._key(name))
        self._cache.pop(name, None)

    def invalidate(self, name: str | None = None) -> None:
        """Drop the local cache. Pass a name to evict one entry, or leave
        blank to clear all. Useful after an out-of-band write you know
        about (e.g. an admin panel updated Redis directly)."""
        if name is None:
            self._cache.clear()
        else:
            self._cache.pop(name, None)


def _bucket(subject: str, flag_name: str) -> int:
    """Deterministic 0..99 bucket. Salted with the flag name so the same
    subject lands in different buckets across different flags (otherwise a
    user unlucky enough to be in bucket 99 would be last for every
    rollout)."""
    h = hashlib.blake2b(f"{flag_name}|{subject}".encode(), digest_size=8).digest()
    return int.from_bytes(h, "big") % 100
