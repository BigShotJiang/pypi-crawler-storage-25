"""One-time password issue/verify, backend-agnostic.

Covers the flow that `pyotp` doesn't:

1. **Issue** — generate a short code for a subject (phone number, email,
   user id), store a salted hash, return the plaintext so the caller can
   send it via SMS / email / push.
2. **Verify** — constant-time compare against the stored hash, single-use
   on success, rate-limited attempts to block brute force.
3. **Resend cooldown** — block re-issuing a new code for a window, so a
   caller can't be tricked into burning your Twilio budget.

Keys used per subject `s`:
    otp:<s>           — salted hash of the code (bytes), TTL = `ttl`
    otp-attempts:<s>  — integer counter, same TTL
    otp-cooldown:<s>  — presence flag, TTL = `resend_cooldown`

Storage stores the hash, not the plaintext — a leaked Redis dump still
doesn't hand an attacker usable codes (though brute-forcing a 6-digit
space is trivial; hashing is belt-and-suspenders).

Attempt counting: every `verify()` call — success or failure — consumes
one attempt. When `max_attempts` is reached, the code is invalidated
immediately; the user must request a resend.

Not in scope (out of the box): TOTP / HOTP rotating codes (use `pyotp`
for those), SMS/email delivery (user's job), phone-number validation.
"""

import hmac
import secrets
from hashlib import blake2b

from wyolet.primitives.backends.base import Backend


class OtpError(Exception):
    """Base for OTP errors."""


class OtpCooldownError(OtpError):
    """Raised when `issue()` is called before the resend cooldown elapses."""


class OtpNotFoundError(OtpError):
    """Raised when `verify()` is called but no active code exists (expired
    or never issued)."""


class OtpTooManyAttemptsError(OtpError):
    """Raised when verify attempts exceed `max_attempts`. The code is
    invalidated when this is raised."""


_DIGITS = "0123456789"


class Otp:
    """Issue and verify one-time passwords backed by any `Backend`."""

    __slots__ = (
        "_backend",
        "_ttl",
        "_code_length",
        "_max_attempts",
        "_resend_cooldown",
        "_prefix",
        "_alphabet",
        "_salt",
    )

    def __init__(
        self,
        backend: Backend,
        *,
        ttl: int = 300,
        code_length: int = 6,
        max_attempts: int = 5,
        resend_cooldown: int = 30,
        prefix: str = "otp:",
        alphabet: str = _DIGITS,
        salt: bytes = b"wyolet.otp",
    ) -> None:
        """
        Args:
            backend: Shared backend.
            ttl: Seconds the code is valid after issue. Default 5min.
            code_length: Characters in the generated code. 6 is standard;
                4 is weaker, 8+ friction-heavy.
            max_attempts: Total verify attempts allowed per code (success
                and failure both count). Hitting the limit invalidates the
                code — user must request a resend.
            resend_cooldown: Seconds to block re-issue for a subject.
                Default 30s — gates SMS spam.
            prefix: Namespacing for OTP keys.
            alphabet: Characters used for the code. Default digits only —
                easiest for SMS entry. Pass a wider alphabet for
                higher-entropy codes at short lengths.
            salt: Application-specific salt mixed into the stored hash.
                Override per-install if you want to invalidate all
                outstanding codes after a deploy.
        """
        if ttl <= 0:
            raise ValueError("ttl must be > 0")
        if code_length < 4:
            raise ValueError("code_length must be >= 4")
        if max_attempts < 1:
            raise ValueError("max_attempts must be >= 1")
        if resend_cooldown < 0:
            raise ValueError("resend_cooldown must be >= 0")
        if len(alphabet) < 2:
            raise ValueError("alphabet must have at least 2 characters")
        self._backend = backend
        self._ttl = ttl
        self._code_length = code_length
        self._max_attempts = max_attempts
        self._resend_cooldown = resend_cooldown
        self._prefix = prefix
        self._alphabet = alphabet
        self._salt = salt

    # ── keys ───────────────────────────────────────────────────────────────
    def _code_key(self, subject: str) -> str:
        return f"{self._prefix}{subject}"

    def _attempts_key(self, subject: str) -> str:
        return f"{self._prefix}attempts:{subject}"

    def _cooldown_key(self, subject: str) -> str:
        return f"{self._prefix}cooldown:{subject}"

    # ── hashing ────────────────────────────────────────────────────────────
    def _hash(self, subject: str, code: str) -> bytes:
        # Subject-bound so the same code for different subjects doesn't
        # collide — constrains an attacker who compromised one hash.
        return blake2b(
            f"{subject}|{code}".encode(), key=self._salt, digest_size=32
        ).digest()

    def _generate(self) -> str:
        return "".join(secrets.choice(self._alphabet) for _ in range(self._code_length))

    # ── public API ─────────────────────────────────────────────────────────
    async def issue(self, subject: str) -> str:
        """Generate a new code, store its hash, return the plaintext.

        Raises `OtpCooldownError` if called within `resend_cooldown` of a
        previous issue for the same subject.
        """
        if self._resend_cooldown > 0:
            locked = not await self._backend.set_nx(
                self._cooldown_key(subject), b"1", ttl=self._resend_cooldown
            )
            if locked:
                raise OtpCooldownError(f"resend cooldown active for {subject!r}")

        code = self._generate()
        await self._backend.set(
            self._code_key(subject), self._hash(subject, code), ttl=self._ttl
        )
        # Reset any stale attempt counter from a prior code.
        await self._backend.delete(self._attempts_key(subject))
        return code

    async def verify(self, subject: str, code: str) -> bool:
        """Check `code` against the stored hash. Returns `True` on match
        (and consumes the code — single-use), `False` on mismatch.

        Raises `OtpNotFoundError` if no active code exists for the
        subject. Raises `OtpTooManyAttemptsError` when attempts exceed
        `max_attempts` — the code is invalidated in that case.
        """
        stored = await self._backend.get(self._code_key(subject))
        if stored is None:
            raise OtpNotFoundError(f"no active code for {subject!r}")

        attempts = await self._backend.incr(
            self._attempts_key(subject), by=1, ttl=self._ttl
        )
        if attempts > self._max_attempts:
            await self._invalidate(subject)
            raise OtpTooManyAttemptsError(
                f"exceeded {self._max_attempts} attempts for {subject!r}"
            )

        candidate = self._hash(subject, code)
        if hmac.compare_digest(candidate, stored):
            await self._invalidate(subject)
            return True
        return False

    async def invalidate(self, subject: str) -> None:
        """Revoke any outstanding code for `subject`. Does NOT clear the
        resend cooldown — a freshly-revoked code still counts toward
        rate-limiting new issues."""
        await self._invalidate(subject)

    async def _invalidate(self, subject: str) -> None:
        await self._backend.delete(self._code_key(subject))
        await self._backend.delete(self._attempts_key(subject))
