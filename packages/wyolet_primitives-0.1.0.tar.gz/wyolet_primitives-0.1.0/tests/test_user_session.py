from datetime import datetime

from wyolet.primitives.user_session import (
    CachedUserSessionRepo,
    UserSession,
    UserSessionRepo,
    UserSessionService,
)


class InMemoryRepo(UserSessionRepo[UserSession]):
    def __init__(self):
        self.rows: dict[str, UserSession] = {}
        self.reads = 0
        self.writes = 0

    async def get(self, sid):
        self.reads += 1
        return self.rows.get(sid)

    async def save(self, session):
        self.writes += 1
        self.rows[session.sid] = session

    async def list_for_user(self, user_id, *, active_only=True, limit=50, before=None):
        out = [s for s in self.rows.values() if s.user_id == user_id]
        if active_only:
            out = [s for s in out if s.revoked_at is None]
        out.sort(key=lambda s: s.last_seen_at, reverse=True)
        return out[:limit]

    async def revoke(self, sid, *, at):
        if sid in self.rows and self.rows[sid].revoked_at is None:
            self.rows[sid] = self.rows[sid].model_copy(update={"revoked_at": at})

    async def touch(self, sid, *, at):
        self.writes += 1
        if sid in self.rows:
            self.rows[sid] = self.rows[sid].model_copy(update={"last_seen_at": at})

    async def delete(self, sid):
        self.rows.pop(sid, None)


async def test_create_and_get(memory_backend):
    source = InMemoryRepo()
    cached = CachedUserSessionRepo(source, memory_backend, model=UserSession)
    svc = UserSessionService(cached, model=UserSession)

    s = await svc.create(user_id="u", user_agent="UA", ip="1.1.1.1")
    assert s.user_id == "u"
    assert s.is_active

    got = await svc.get(s.sid)
    assert got is not None and got.user_id == "u"


async def test_cache_hit_avoids_source_read(memory_backend):
    source = InMemoryRepo()
    cached = CachedUserSessionRepo(source, memory_backend, model=UserSession)
    svc = UserSessionService(cached, model=UserSession)

    s = await svc.create(user_id="u")
    reads_before = source.reads
    await svc.get(s.sid)
    assert source.reads == reads_before  # served from cache


async def test_cache_miss_populates_from_source(memory_backend):
    source = InMemoryRepo()
    cached = CachedUserSessionRepo(
        source, memory_backend, model=UserSession, key_prefix="us:"
    )
    svc = UserSessionService(cached, model=UserSession)

    s = await svc.create(user_id="u")
    await memory_backend.delete(f"us:{s.sid}")

    reads_before = source.reads
    await svc.get(s.sid)
    assert source.reads == reads_before + 1

    reads_before = source.reads
    await svc.get(s.sid)
    assert source.reads == reads_before  # now warmed


async def test_touch_is_throttled(memory_backend):
    source = InMemoryRepo()
    cached = CachedUserSessionRepo(source, memory_backend, model=UserSession)
    svc = UserSessionService(cached, model=UserSession, touch_every=1)

    s = await svc.create(user_id="u")
    writes_before = source.writes
    await svc.touch(s.sid)
    first_delta = source.writes - writes_before
    assert first_delta == 1

    writes_before = source.writes
    await svc.touch(s.sid)
    assert source.writes == writes_before  # throttled


async def test_revoke_invalidates_cache(memory_backend):
    source = InMemoryRepo()
    cached = CachedUserSessionRepo(
        source, memory_backend, model=UserSession, key_prefix="us:"
    )
    svc = UserSessionService(cached, model=UserSession)

    s = await svc.create(user_id="u")
    await svc.revoke(s.sid)
    assert await memory_backend.get(f"us:{s.sid}") is None

    reloaded = await svc.get(s.sid)
    assert reloaded is not None and reloaded.revoked_at is not None


async def test_custom_model_roundtrips(memory_backend):
    class MyUserSession(UserSession):
        tenant_id: str = "default"

    source = InMemoryRepo()  # type: ignore[type-var]
    cached = CachedUserSessionRepo(
        source, memory_backend, model=MyUserSession, key_prefix="myus:"
    )
    svc = UserSessionService(cached, model=MyUserSession)

    m = await svc.create(user_id="u", tenant_id="acme")
    assert m.tenant_id == "acme"

    # Hit source directly (bypass cache)
    await memory_backend.delete(f"myus:{m.sid}")
    reloaded = await svc.get(m.sid)
    assert isinstance(reloaded, MyUserSession)
    assert reloaded.tenant_id == "acme"


async def test_revoke_all_for_user(memory_backend):
    source = InMemoryRepo()
    cached = CachedUserSessionRepo(source, memory_backend, model=UserSession)
    svc = UserSessionService(cached, model=UserSession)

    await svc.create(user_id="u")
    await svc.create(user_id="u")
    await svc.create(user_id="other")

    n = await svc.revoke_all_for_user("u")
    assert n == 2
    assert len(await svc.list_active("u")) == 0
    assert len(await svc.list_active("other")) == 1
