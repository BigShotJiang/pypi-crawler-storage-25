import asyncio

import pytest

from wyolet.primitives.feature_flags import FeatureFlags, Flag


async def test_missing_flag_is_off(any_backend):
    ff = FeatureFlags(any_backend, cache_ttl=0)
    assert await ff.is_enabled("missing") is False
    assert await ff.is_enabled("missing", subject="u1") is False


async def test_set_and_read_back(any_backend):
    ff = FeatureFlags(any_backend, cache_ttl=0)
    await ff.set("x", enabled=True, rollout=100)
    flag = await ff.get("x")
    assert flag is not None
    assert flag.enabled and flag.rollout == 100


async def test_enabled_false_overrides_everything(any_backend):
    ff = FeatureFlags(any_backend, cache_ttl=0)
    await ff.set("x", enabled=False, rollout=100, allow=["u1"])
    assert await ff.is_enabled("x", subject="u1") is False


async def test_no_subject_acts_as_killswitch(any_backend):
    ff = FeatureFlags(any_backend, cache_ttl=0)
    await ff.set("x", enabled=True, rollout=0)  # 0% rollout…
    # …but no subject → pure killswitch semantics, returns enabled
    assert await ff.is_enabled("x") is True
    await ff.set("x", enabled=False)
    assert await ff.is_enabled("x") is False


async def test_block_beats_allow(any_backend):
    ff = FeatureFlags(any_backend, cache_ttl=0)
    await ff.set("x", enabled=True, rollout=100, allow=["u1"], block=["u1"])
    assert await ff.is_enabled("x", subject="u1") is False


async def test_allow_forces_on_despite_zero_rollout(any_backend):
    ff = FeatureFlags(any_backend, cache_ttl=0)
    await ff.set("x", enabled=True, rollout=0, allow=["u1"])
    assert await ff.is_enabled("x", subject="u1") is True
    assert await ff.is_enabled("x", subject="u2") is False


async def test_rollout_is_deterministic_per_subject(any_backend):
    ff = FeatureFlags(any_backend, cache_ttl=0)
    await ff.set("x", enabled=True, rollout=50)
    first = await ff.is_enabled("x", subject="user-42")
    for _ in range(20):
        assert await ff.is_enabled("x", subject="user-42") is first


async def test_rollout_distribution_roughly_matches(any_backend):
    ff = FeatureFlags(any_backend, cache_ttl=0)
    await ff.set("x", enabled=True, rollout=30)
    on = 0
    n = 2000
    for i in range(n):
        if await ff.is_enabled("x", subject=f"user-{i}"):
            on += 1
    # allow ±5% slack
    assert 0.25 * n <= on <= 0.35 * n


async def test_rollout_salted_by_flag_name(any_backend):
    ff = FeatureFlags(any_backend, cache_ttl=0)
    await ff.set("a", enabled=True, rollout=50)
    await ff.set("b", enabled=True, rollout=50)
    disagree = 0
    for i in range(500):
        s = f"user-{i}"
        if (await ff.is_enabled("a", subject=s)) != (await ff.is_enabled("b", subject=s)):
            disagree += 1
    # Independent buckets → ~50% disagreement. Tight bound would flake; allow wide band.
    assert 150 < disagree < 350


async def test_delete_removes_flag(any_backend):
    ff = FeatureFlags(any_backend, cache_ttl=0)
    await ff.set("x", enabled=True)
    await ff.delete("x")
    assert await ff.get("x") is None
    assert await ff.is_enabled("x") is False


async def test_cache_serves_stale_within_ttl(memory_backend):
    ff = FeatureFlags(memory_backend, cache_ttl=60)
    await ff.set("x", enabled=True)
    assert await ff.is_enabled("x") is True
    # Mutate backend out-of-band (simulate another replica writing).
    await memory_backend.delete("flag:x")
    # Still True because our cache hasn't expired.
    assert await ff.is_enabled("x") is True
    ff.invalidate("x")
    assert await ff.is_enabled("x") is False


async def test_cache_ttl_expires(memory_backend):
    ff = FeatureFlags(memory_backend, cache_ttl=0.1)
    await ff.set("x", enabled=True)
    assert await ff.is_enabled("x") is True
    await memory_backend.delete("flag:x")
    await asyncio.sleep(0.15)
    assert await ff.is_enabled("x") is False


async def test_invalidate_all(memory_backend):
    ff = FeatureFlags(memory_backend, cache_ttl=60)
    await ff.set("a", enabled=True)
    await ff.set("b", enabled=True)
    await memory_backend.delete("flag:a")
    await memory_backend.delete("flag:b")
    ff.invalidate()
    assert await ff.is_enabled("a") is False
    assert await ff.is_enabled("b") is False


def test_flag_rejects_invalid_rollout():
    with pytest.raises(ValueError):
        Flag(name="x", rollout=101)
    with pytest.raises(ValueError):
        Flag(name="x", rollout=-1)


def test_rejects_negative_cache_ttl(memory_backend):
    with pytest.raises(ValueError):
        FeatureFlags(memory_backend, cache_ttl=-1)
