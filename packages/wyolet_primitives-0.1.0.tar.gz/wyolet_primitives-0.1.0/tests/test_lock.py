import asyncio

import pytest

from wyolet.primitives.lock import DistributedLock, LockAcquireError


async def test_acquire_release(memory_backend):
    lock = DistributedLock(memory_backend, ttl=5, wait=0.0)
    async with lock.acquire("k") as h:
        assert h.held
    async with lock.acquire("k"):
        pass  # re-acquirable after release


async def test_contention_fails_immediately(memory_backend):
    lock = DistributedLock(memory_backend, ttl=5, wait=0.0)
    async with lock.acquire("k"):
        with pytest.raises(LockAcquireError):
            async with lock.acquire("k"):
                pass


async def test_wait_acquires_after_release(memory_backend):
    lock = DistributedLock(memory_backend, ttl=5, wait=2.0, retry_delay=0.02)
    h1 = lock.acquire("k")
    await h1.__aenter__()

    async def release_soon():
        await asyncio.sleep(0.1)
        await h1.release()

    async def waiter():
        async with lock.acquire("k"):
            return "got"

    _, result = await asyncio.gather(release_soon(), waiter())
    assert result == "got"


async def test_fencing_via_compare_and_delete(memory_backend):
    # Old holder's TTL expires, new holder takes over, old holder tries to release.
    lock = DistributedLock(memory_backend, ttl=1, wait=0.0, renew=False)
    old = lock.acquire("k")
    await old.__aenter__()
    await asyncio.sleep(1.2)
    new = lock.acquire("k")
    await new.__aenter__()
    assert (await old.release()) is False  # must not steal new holder's lock
    assert new.held
    await new.release()


async def test_auto_renew_keeps_lock_alive(memory_backend):
    lock = DistributedLock(
        memory_backend, ttl=1, wait=0.0, renew=True, renew_ratio=0.3
    )
    async with lock.acquire("k"):
        await asyncio.sleep(1.5)  # past original ttl
        # Contention proves we still hold it
        other = lock.acquire("k")
        with pytest.raises(LockAcquireError):
            await other.__aenter__()


@pytest.mark.parametrize("bad_ttl", [0, -1])
async def test_invalid_ttl_rejected(memory_backend, bad_ttl):
    with pytest.raises(ValueError):
        DistributedLock(memory_backend, ttl=bad_ttl)


@pytest.mark.parametrize("bad_ratio", [0, 1, 1.5])
async def test_invalid_renew_ratio(memory_backend, bad_ratio):
    with pytest.raises(ValueError):
        DistributedLock(memory_backend, ttl=5, renew_ratio=bad_ratio)
