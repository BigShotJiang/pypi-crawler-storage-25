import asyncio
import dataclasses
from datetime import datetime, timezone
from decimal import Decimal
from uuid import UUID

import pytest

from wyolet.primitives.cache import (
    Cache,
    HTTPCacheMiddleware,
    JSONSerializer,
    PickleSerializer,
    cached,
)


# ── Serializer tests ──────────────────────────────────────────────────────


@dataclasses.dataclass
class _Point:
    x: int
    y: int


class _PydanticStub:
    def __init__(self, a: int) -> None:
        self.a = a

    def model_dump(self) -> dict:
        return {"a": self.a}


def test_pickle_roundtrip_preserves_types():
    s = PickleSerializer()
    p = _Point(1, 2)
    assert s.loads(s.dumps(p)) == p
    assert s.loads(s.dumps(None)) is None
    assert s.loads(s.dumps({1, 2})) == {1, 2}


def test_json_handles_common_types():
    s = JSONSerializer()
    # datetime / UUID native in orjson
    dt = datetime(2026, 1, 1, tzinfo=timezone.utc)
    u = UUID("12345678-1234-5678-1234-567812345678")
    assert "2026" in s.loads(s.dumps(dt))
    assert s.loads(s.dumps(u)) == str(u)
    # default= hook
    assert s.loads(s.dumps(Decimal("1.5"))) == "1.5"
    assert sorted(s.loads(s.dumps({1, 2, 3}))) == [1, 2, 3]
    assert s.loads(s.dumps(_Point(1, 2))) == {"x": 1, "y": 2}
    assert s.loads(s.dumps(_PydanticStub(7))) == {"a": 7}


def test_json_rejects_unsupported():
    s = JSONSerializer()
    with pytest.raises(TypeError):
        s.dumps(object())


# ── Cache core ─────────────────────────────────────────────────────────────


async def test_cache_basic_set_get_delete(any_backend):
    c = Cache(any_backend, ttl=60)
    assert await c.get("missing") is None
    assert await c.get("missing", default="x") == "x"
    await c.set("k", {"v": 1})
    assert await c.get("k") == {"v": 1}
    await c.delete("k")
    assert await c.get("k") is None


async def test_cache_ttl_expires(memory_backend):
    c = Cache(memory_backend, ttl=1)
    await c.set("k", "v", ttl=1)
    assert await c.get("k") == "v"
    await asyncio.sleep(1.2)
    assert await c.get("k") is None


async def test_get_or_set_calls_factory_once(any_backend):
    c = Cache(any_backend, ttl=60)
    calls = 0

    async def factory():
        nonlocal calls
        calls += 1
        return 42

    v1 = await c.get_or_set("k", factory)
    v2 = await c.get_or_set("k", factory)
    assert v1 == 42 and v2 == 42
    assert calls == 1


async def test_stampede_protection_serializes_concurrent_misses(memory_backend):
    c = Cache(memory_backend, ttl=60)
    calls = 0

    async def factory():
        nonlocal calls
        calls += 1
        await asyncio.sleep(0.1)  # simulate slow DB
        return "value"

    results = await asyncio.gather(
        *[c.get_or_set("hot", factory) for _ in range(20)]
    )
    assert all(r == "value" for r in results)
    assert calls == 1


async def test_stampede_disabled_allows_herd(memory_backend):
    c = Cache(memory_backend, ttl=60)
    calls = 0

    async def factory():
        nonlocal calls
        calls += 1
        await asyncio.sleep(0.05)
        return "v"

    await asyncio.gather(
        *[c.get_or_set("k", factory, stampede=False) for _ in range(10)]
    )
    assert calls > 1  # no protection


# ── @cached decorator ──────────────────────────────────────────────────────


async def test_cached_decorator_caches_by_args(memory_backend):
    c = Cache(memory_backend, ttl=60)
    calls = 0

    @cached(c)
    async def expensive(user_id: int, role: str = "user") -> dict:
        nonlocal calls
        calls += 1
        return {"user_id": user_id, "role": role}

    assert await expensive(1) == {"user_id": 1, "role": "user"}
    assert await expensive(1) == {"user_id": 1, "role": "user"}
    assert calls == 1
    await expensive(2)
    assert calls == 2
    await expensive(1, role="admin")
    assert calls == 3


async def test_cached_rejects_sync_function(memory_backend):
    c = Cache(memory_backend)
    with pytest.raises(TypeError):

        @cached(c)
        def f():
            return 1


async def test_cached_custom_key_fn(memory_backend):
    c = Cache(memory_backend, ttl=60)
    calls = 0

    @cached(c, key=lambda user_id, **_: f"u:{user_id}")
    async def lookup(user_id: int, request_id: str) -> int:
        nonlocal calls
        calls += 1
        return user_id * 10

    # Different request_id shouldn't change cache key.
    await lookup(5, request_id="a")
    await lookup(5, request_id="b")
    assert calls == 1


# ── HTTPCacheMiddleware ────────────────────────────────────────────────────


async def _drive(app, scope):
    sent = []

    async def send(m):
        sent.append(m)

    async def receive():
        return {"type": "http.request", "body": b"", "more_body": False}

    await app(scope, receive, send)
    start = next(m for m in sent if m["type"] == "http.response.start")
    body = b"".join(
        m.get("body", b"") for m in sent if m["type"] == "http.response.body"
    )
    return start["status"], dict(start["headers"]), body


def _scope(method="GET", path="/", query=b"", headers=None):
    return {
        "type": "http",
        "method": method,
        "path": path,
        "query_string": query,
        "headers": headers or [],
    }


def _inner(counter, *, status=200, body=b"hello", extra_headers=()):
    async def app(scope, receive, send):
        counter["n"] += 1
        headers = [(b"content-type", b"text/plain")] + list(extra_headers)
        await send({"type": "http.response.start", "status": status, "headers": headers})
        await send({"type": "http.response.body", "body": body})

    return app


async def test_http_cache_hits_on_repeat(memory_backend):
    c = {"n": 0}
    app = HTTPCacheMiddleware(_inner(c), backend=memory_backend, ttl=60)
    s1, h1, b1 = await _drive(app, _scope())
    s2, h2, b2 = await _drive(app, _scope())
    assert s1 == s2 == 200
    assert b1 == b2 == b"hello"
    assert h1[b"x-cache"] == b"MISS"
    assert h2[b"x-cache"] == b"HIT"
    assert c["n"] == 1


async def test_http_cache_skips_non_get(memory_backend):
    c = {"n": 0}
    app = HTTPCacheMiddleware(_inner(c), backend=memory_backend)
    await _drive(app, _scope(method="POST"))
    await _drive(app, _scope(method="POST"))
    assert c["n"] == 2


async def test_http_cache_skips_on_no_store_request(memory_backend):
    c = {"n": 0}
    app = HTTPCacheMiddleware(_inner(c), backend=memory_backend)
    headers = [(b"cache-control", b"no-store")]
    await _drive(app, _scope(headers=headers))
    await _drive(app, _scope(headers=headers))
    assert c["n"] == 2


async def test_http_cache_respects_response_no_store(memory_backend):
    c = {"n": 0}
    app = HTTPCacheMiddleware(
        _inner(c, extra_headers=[(b"cache-control", b"no-store")]),
        backend=memory_backend,
    )
    await _drive(app, _scope())
    await _drive(app, _scope())
    assert c["n"] == 2


async def test_http_cache_skips_non_2xx(memory_backend):
    c = {"n": 0}
    app = HTTPCacheMiddleware(_inner(c, status=404), backend=memory_backend)
    await _drive(app, _scope())
    await _drive(app, _scope())
    assert c["n"] == 2


async def test_http_cache_vary_distinguishes_keys(memory_backend):
    c = {"n": 0}
    app = HTTPCacheMiddleware(
        _inner(c), backend=memory_backend, vary=("accept-encoding",)
    )
    await _drive(app, _scope(headers=[(b"accept-encoding", b"gzip")]))
    await _drive(app, _scope(headers=[(b"accept-encoding", b"br")]))
    assert c["n"] == 2  # different vary values → both miss
    await _drive(app, _scope(headers=[(b"accept-encoding", b"gzip")]))
    assert c["n"] == 2  # same as first → hit


async def test_http_cache_max_age_overrides_ttl(memory_backend):
    c = {"n": 0}
    app = HTTPCacheMiddleware(
        _inner(c, extra_headers=[(b"cache-control", b"max-age=1")]),
        backend=memory_backend,
        ttl=3600,
    )
    await _drive(app, _scope())
    await _drive(app, _scope())
    assert c["n"] == 1
    await asyncio.sleep(1.2)
    await _drive(app, _scope())
    assert c["n"] == 2  # expired per max-age
