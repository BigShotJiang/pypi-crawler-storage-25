"""Backend contract tests — parametrized over every available backend."""

import asyncio

import pytest


async def test_get_set_delete(any_backend):
    assert await any_backend.get("x") is None
    await any_backend.set("x", b"hello")
    assert await any_backend.get("x") == b"hello"
    await any_backend.delete("x")
    assert await any_backend.get("x") is None


async def test_ttl_expiry(any_backend):
    await any_backend.set("tmp", b"short", ttl=1)
    assert await any_backend.get("tmp") == b"short"
    await asyncio.sleep(1.2)
    assert await any_backend.get("tmp") is None


async def test_incr_creates_with_ttl(any_backend):
    assert await any_backend.incr("c", by=3, ttl=60) == 3
    assert await any_backend.incr("c", by=2) == 5


async def test_incr_ttl_not_reset_on_existing_key(any_backend):
    await any_backend.incr("c", by=1, ttl=1)
    await asyncio.sleep(0.2)
    # A later incr with a new ttl must NOT extend the existing expiry.
    await any_backend.incr("c", by=1, ttl=999)
    await asyncio.sleep(1.0)
    assert await any_backend.get("c") is None


async def test_expire(any_backend):
    await any_backend.set("k", b"v")
    await any_backend.expire("k", 1)
    await asyncio.sleep(1.2)
    assert await any_backend.get("k") is None


async def test_set_nx(any_backend):
    assert await any_backend.set_nx("lock", b"token", ttl=5) is True
    assert await any_backend.set_nx("lock", b"other", ttl=5) is False
    assert await any_backend.get("lock") == b"token"


async def test_compare_and_delete_match(any_backend):
    await any_backend.set("lock", b"tok")
    assert await any_backend.compare_and_delete("lock", b"tok") is True
    assert await any_backend.get("lock") is None


async def test_compare_and_delete_mismatch(any_backend):
    await any_backend.set("lock", b"tok")
    assert await any_backend.compare_and_delete("lock", b"wrong") is False
    assert await any_backend.get("lock") == b"tok"


async def test_compare_and_delete_missing(any_backend):
    assert await any_backend.compare_and_delete("nope", b"tok") is False
