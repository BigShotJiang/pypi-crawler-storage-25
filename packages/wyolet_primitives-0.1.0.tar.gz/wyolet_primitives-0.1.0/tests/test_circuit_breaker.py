import asyncio

import pytest

from wyolet.primitives.circuit_breaker import (
    CircuitBreaker,
    CircuitOpenError,
    CircuitState,
)


class Upstream(Exception):
    pass


async def test_closed_passes_calls():
    b = CircuitBreaker(fail_threshold=3, recovery_timeout=1.0)

    async def ok():
        return "v"

    for _ in range(5):
        assert await b.call(ok) == "v"
    assert b.state is CircuitState.CLOSED


async def test_trips_open_after_threshold():
    b = CircuitBreaker(fail_threshold=3, recovery_timeout=10.0)

    async def fail():
        raise Upstream()

    for _ in range(3):
        with pytest.raises(Upstream):
            await b.call(fail)
    assert b.state is CircuitState.OPEN
    with pytest.raises(CircuitOpenError):
        await b.call(fail)


async def test_success_resets_failure_count():
    b = CircuitBreaker(fail_threshold=3, recovery_timeout=10.0)

    async def fail():
        raise Upstream()

    async def ok():
        return 1

    for _ in range(2):
        with pytest.raises(Upstream):
            await b.call(fail)
    assert await b.call(ok) == 1
    # counter cleared; need 3 more failures to trip
    for _ in range(2):
        with pytest.raises(Upstream):
            await b.call(fail)
    assert b.state is CircuitState.CLOSED


async def test_half_open_probe_success_closes():
    b = CircuitBreaker(fail_threshold=2, recovery_timeout=0.1)

    async def fail():
        raise Upstream()

    async def ok():
        return "v"

    for _ in range(2):
        with pytest.raises(Upstream):
            await b.call(fail)
    assert b.state is CircuitState.OPEN
    await asyncio.sleep(0.15)
    assert await b.call(ok) == "v"
    assert b.state is CircuitState.CLOSED


async def test_half_open_probe_failure_reopens():
    b = CircuitBreaker(fail_threshold=2, recovery_timeout=0.1)

    async def fail():
        raise Upstream()

    for _ in range(2):
        with pytest.raises(Upstream):
            await b.call(fail)
    await asyncio.sleep(0.15)
    # HALF_OPEN probe fails → back to OPEN
    with pytest.raises(Upstream):
        await b.call(fail)
    assert b.state is CircuitState.OPEN
    # Immediate retry rejected fast
    with pytest.raises(CircuitOpenError):
        await b.call(fail)


async def test_half_open_rejects_concurrent_probes():
    b = CircuitBreaker(fail_threshold=1, recovery_timeout=0.1)

    async def fail():
        raise Upstream()

    with pytest.raises(Upstream):
        await b.call(fail)
    await asyncio.sleep(0.15)

    gate = asyncio.Event()

    async def slow():
        await gate.wait()
        return "v"

    probe = asyncio.create_task(b.call(slow))
    await asyncio.sleep(0.01)  # let probe claim the slot
    # Second concurrent call during HALF_OPEN probe — rejected
    with pytest.raises(CircuitOpenError):
        await b.call(slow)
    gate.set()
    assert await probe == "v"
    assert b.state is CircuitState.CLOSED


async def test_unexpected_exception_does_not_count():
    b = CircuitBreaker(fail_threshold=2, recovery_timeout=10.0, expected_exception=Upstream)

    async def bug():
        raise ValueError("programmer error")

    for _ in range(5):
        with pytest.raises(ValueError):
            await b.call(bug)
    assert b.state is CircuitState.CLOSED


async def test_guard_decorator():
    b = CircuitBreaker(fail_threshold=2, recovery_timeout=10.0)
    calls = {"n": 0}

    @b.guard
    async def upstream() -> str:
        calls["n"] += 1
        raise Upstream()

    for _ in range(2):
        with pytest.raises(Upstream):
            await upstream()
    # Open — next call short-circuits, does not invoke the function
    with pytest.raises(CircuitOpenError):
        await upstream()
    assert calls["n"] == 2


async def test_guard_rejects_sync():
    b = CircuitBreaker()
    with pytest.raises(TypeError):

        @b.guard
        def f():
            return 1


async def test_context_manager_counts_failures():
    b = CircuitBreaker(fail_threshold=2, recovery_timeout=10.0)
    for _ in range(2):
        with pytest.raises(Upstream):
            async with b:
                raise Upstream()
    assert b.state is CircuitState.OPEN
    with pytest.raises(CircuitOpenError):
        async with b:
            pass


async def test_reset_clears_state():
    b = CircuitBreaker(fail_threshold=1, recovery_timeout=10.0)

    async def fail():
        raise Upstream()

    with pytest.raises(Upstream):
        await b.call(fail)
    assert b.state is CircuitState.OPEN
    await b.reset()
    assert b.state is CircuitState.CLOSED


def test_validates_config():
    with pytest.raises(ValueError):
        CircuitBreaker(fail_threshold=0)
    with pytest.raises(ValueError):
        CircuitBreaker(recovery_timeout=0)
