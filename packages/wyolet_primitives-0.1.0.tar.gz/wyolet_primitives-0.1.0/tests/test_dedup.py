import asyncio

import pytest

from wyolet.primitives.dedup import Dedup


async def test_claim_first_wins(any_backend):
    d = Dedup(any_backend, ttl=60)
    assert await d.claim("evt-1") is True
    assert await d.claim("evt-1") is False
    assert await d.claim("evt-2") is True


async def test_seen_reflects_claim(any_backend):
    d = Dedup(any_backend, ttl=60)
    assert await d.seen("evt-1") is False
    await d.claim("evt-1")
    assert await d.seen("evt-1") is True


async def test_forget_releases(any_backend):
    d = Dedup(any_backend, ttl=60)
    await d.claim("evt-1")
    await d.forget("evt-1")
    assert await d.claim("evt-1") is True


async def test_ttl_expires(memory_backend):
    d = Dedup(memory_backend, ttl=1)
    await d.claim("evt-1")
    await asyncio.sleep(1.2)
    assert await d.claim("evt-1") is True


async def test_concurrent_claims_exactly_one_winner(memory_backend):
    d = Dedup(memory_backend, ttl=60)
    results = await asyncio.gather(*[d.claim("hot") for _ in range(50)])
    assert sum(results) == 1


async def test_once_commits_on_success(any_backend):
    d = Dedup(any_backend, ttl=60)
    async with d.once("evt-1") as first:
        assert first is True
    # persists — second claim sees duplicate
    async with d.once("evt-1") as first:
        assert first is False


async def test_once_rolls_back_on_exception(any_backend):
    d = Dedup(any_backend, ttl=60)

    class Boom(Exception):
        pass

    with pytest.raises(Boom):
        async with d.once("evt-1") as first:
            assert first is True
            raise Boom()

    # rollback: next attempt should succeed
    async with d.once("evt-1") as first:
        assert first is True


async def test_once_duplicate_does_not_rollback(any_backend):
    d = Dedup(any_backend, ttl=60)
    await d.claim("evt-1")

    class Boom(Exception):
        pass

    with pytest.raises(Boom):
        async with d.once("evt-1") as first:
            assert first is False
            raise Boom()  # duplicate path — must NOT forget

    assert await d.seen("evt-1") is True


async def test_per_call_ttl_override(memory_backend):
    d = Dedup(memory_backend, ttl=60)
    await d.claim("evt-1", ttl=1)
    await asyncio.sleep(1.2)
    assert await d.claim("evt-1") is True


def test_rejects_bad_ttl(memory_backend):
    with pytest.raises(ValueError):
        Dedup(memory_backend, ttl=0)
