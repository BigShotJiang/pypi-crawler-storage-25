import asyncio
import json

import pytest

from wyolet.primitives.ratelimit import (
    FixedWindow,
    RateLimitMiddleware,
    compose,
    from_ip,
    from_scope,
)


# ── strategy ────────────────────────────────────────────────────────────────
async def test_fixed_window_allow_until_limit(memory_backend):
    limiter = FixedWindow(memory_backend, limit=3, window=60)
    for i in range(3):
        r = await limiter.check("u")
        assert r.allowed
        assert r.remaining == 2 - i

    r = await limiter.check("u")
    assert not r.allowed
    assert r.retry_after == 60


async def test_fixed_window_keys_are_independent(memory_backend):
    limiter = FixedWindow(memory_backend, limit=1, window=60)
    assert (await limiter.check("a")).allowed
    assert (await limiter.check("b")).allowed
    assert not (await limiter.check("a")).allowed


async def test_fixed_window_cost(memory_backend):
    limiter = FixedWindow(memory_backend, limit=10, window=60)
    assert (await limiter.check("a", cost=7)).allowed
    assert (await limiter.check("a", cost=3)).allowed
    assert not (await limiter.check("a", cost=1)).allowed


async def test_fixed_window_resets_after_window(memory_backend):
    limiter = FixedWindow(memory_backend, limit=1, window=1)
    assert (await limiter.check("k")).allowed
    assert not (await limiter.check("k")).allowed
    await asyncio.sleep(1.1)
    assert (await limiter.check("k")).allowed


@pytest.mark.parametrize("bad", [0, -1])
async def test_fixed_window_rejects_bad_limit(memory_backend, bad):
    with pytest.raises(ValueError):
        FixedWindow(memory_backend, limit=bad, window=60)


# ── middleware ──────────────────────────────────────────────────────────────
async def _drive(app, scope):
    sent = []

    async def send(m):
        sent.append(m)

    async def receive():
        return {"type": "http.request", "body": b"", "more_body": False}

    await app(scope, receive, send)
    start = next(m for m in sent if m["type"] == "http.response.start")
    body = b"".join(m["body"] for m in sent if m["type"] == "http.response.body")
    return start["status"], dict(start["headers"]), body


async def _inner(scope, receive, send):
    await send({"type": "http.response.start", "status": 200, "headers": []})
    await send({"type": "http.response.body", "body": b"ok"})


def _scope(**overrides):
    s = {"type": "http", "method": "GET", "path": "/", "headers": [], "client": ("1.2.3.4", 1)}
    s.update(overrides)
    return s


async def test_middleware_adds_headers_on_success(memory_backend):
    app = RateLimitMiddleware(
        _inner,
        strategy=FixedWindow(memory_backend, limit=5, window=60),
        key=from_ip(),
    )
    status, headers, _ = await _drive(app, _scope())
    assert status == 200
    assert headers[b"x-ratelimit-limit"] == b"5"
    assert headers[b"x-ratelimit-remaining"] == b"4"
    assert b"x-ratelimit-reset" in headers


async def test_middleware_denies_over_limit(memory_backend):
    app = RateLimitMiddleware(
        _inner,
        strategy=FixedWindow(memory_backend, limit=1, window=60),
        key=from_ip(),
    )
    await _drive(app, _scope())
    status, headers, body = await _drive(app, _scope())
    assert status == 429
    assert headers[b"retry-after"] == b"60"
    assert json.loads(body)["error"] == "rate_limited"


async def test_middleware_skip_predicate(memory_backend):
    app = RateLimitMiddleware(
        _inner,
        strategy=FixedWindow(memory_backend, limit=1, window=60),
        key=from_ip(),
        skip=lambda s: s["path"].startswith("/health"),
    )
    for _ in range(5):
        status, _, _ = await _drive(app, _scope(path="/health"))
        assert status == 200


async def test_middleware_none_key_passes_through(memory_backend):
    app = RateLimitMiddleware(
        _inner,
        strategy=FixedWindow(memory_backend, limit=1, window=60),
        key=from_scope("nonexistent"),
    )
    for _ in range(3):
        status, _, _ = await _drive(app, _scope())
        assert status == 200


async def test_compose_prefers_first_non_none(memory_backend):
    app = RateLimitMiddleware(
        _inner,
        strategy=FixedWindow(memory_backend, limit=2, window=60),
        key=compose(from_scope("user_id"), from_ip()),
    )
    # Scope has user_id → that's the key, not IP
    for _ in range(2):
        status, _, _ = await _drive(app, _scope(user_id="u-1"))
        assert status == 200
    status, _, _ = await _drive(app, _scope(user_id="u-1"))
    assert status == 429
    # Different user_id has its own bucket
    status, _, _ = await _drive(app, _scope(user_id="u-2"))
    assert status == 200
