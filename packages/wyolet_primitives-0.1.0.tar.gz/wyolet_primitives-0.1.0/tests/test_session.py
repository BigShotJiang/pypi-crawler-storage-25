import pytest

from wyolet.primitives import Session, SessionState


async def test_guard_before_load(memory_backend):
    s = Session(memory_backend, "sid")
    with pytest.raises(RuntimeError, match="before load"):
        s.get("x")


async def test_empty_new_session_does_not_persist(memory_backend):
    s = Session(memory_backend, "sid")
    await s.load()
    assert s.state is SessionState.NEW
    assert await s.save(ttl=60) is False


async def test_save_and_reload(memory_backend):
    s = Session(memory_backend, "sid")
    await s.load()
    s["user_id"] = 42
    assert s.modified
    assert await s.save(ttl=60) is True

    s2 = Session(memory_backend, "sid")
    await s2.load()
    assert s2.state is SessionState.LOADED
    assert s2["user_id"] == 42
    assert not s2.modified


async def test_dirty_only_on_real_change(memory_backend):
    s = Session(memory_backend, "sid")
    await s.load()
    s["x"] = 1
    await s.save(ttl=60)
    s["x"] = 1  # same value
    assert not s.modified
    assert await s.save(ttl=60) is False


async def test_regenerate_moves_data(memory_backend):
    s = Session(memory_backend, "sid")
    await s.load()
    s["x"] = 1
    await s.save(ttl=60)

    old_id = s.id
    new_id = await s.regenerate()
    assert new_id != old_id
    await s.save(ttl=60)
    assert await memory_backend.get(old_id) is None
    assert await memory_backend.get(new_id) is not None


async def test_clear(memory_backend):
    s = Session(memory_backend, "sid")
    await s.load()
    s["x"] = 1
    await s.save(ttl=60)
    await s.clear()
    assert s.state is SessionState.CLEARED
    assert await memory_backend.get("sid") is None
