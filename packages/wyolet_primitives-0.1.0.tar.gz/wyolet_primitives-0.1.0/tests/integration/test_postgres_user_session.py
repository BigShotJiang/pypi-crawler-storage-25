"""Live-Postgres tests for `PostgresUserSessionRepo`. Skipped when the DB
isn't reachable — bring it up with `docker compose up postgres`."""

from datetime import datetime, timezone

import pytest

pytestmark = pytest.mark.integration


async def test_schema_and_roundtrip(postgres_pool):
    from wyolet.primitives.user_session import UserSession
    from wyolet.primitives.user_session.postgres import PostgresUserSessionRepo

    repo = PostgresUserSessionRepo(postgres_pool)
    await repo.ensure_schema()

    now = datetime.now(timezone.utc)
    s = UserSession(
        sid="sid-1",
        user_id="u-1",
        user_agent="pytest",
        ip="127.0.0.1",
        os="macOS",
        device="Desktop",
        created_at=now,
        last_seen_at=now,
        extra={"fingerprint": "abc"},
    )
    await repo.save(s)

    loaded = await repo.get("sid-1")
    assert loaded is not None
    assert loaded.user_id == "u-1"
    assert loaded.extra == {"fingerprint": "abc"}


async def test_list_for_user_filters_revoked(postgres_pool):
    from wyolet.primitives.user_session import UserSessionService
    from wyolet.primitives.user_session.postgres import (
        PostgresUserSessionRepo,
        UserSession,
    )

    repo = PostgresUserSessionRepo(postgres_pool)
    await repo.ensure_schema()
    svc = UserSessionService(repo, model=UserSession)

    a = await svc.create(user_id="alice")
    b = await svc.create(user_id="alice")
    await svc.create(user_id="bob")

    active = await svc.list_active("alice")
    assert {s.sid for s in active} == {a.sid, b.sid}

    await svc.revoke(a.sid)
    active = await svc.list_active("alice")
    assert {s.sid for s in active} == {b.sid}
