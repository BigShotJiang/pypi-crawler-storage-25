import asyncio

import pytest

from wyolet.primitives.otp import (
    Otp,
    OtpCooldownError,
    OtpNotFoundError,
    OtpTooManyAttemptsError,
)


async def test_issue_returns_code_of_expected_shape(any_backend):
    otp = Otp(any_backend, ttl=60, code_length=6, resend_cooldown=0)
    code = await otp.issue("u1")
    assert len(code) == 6
    assert code.isdigit()


async def test_verify_accepts_correct_code(any_backend):
    otp = Otp(any_backend, ttl=60, resend_cooldown=0)
    code = await otp.issue("u1")
    assert await otp.verify("u1", code) is True


async def test_verify_rejects_wrong_code(any_backend):
    otp = Otp(any_backend, ttl=60, resend_cooldown=0)
    await otp.issue("u1")
    assert await otp.verify("u1", "000000") is False


async def test_verify_is_single_use(any_backend):
    otp = Otp(any_backend, ttl=60, resend_cooldown=0)
    code = await otp.issue("u1")
    assert await otp.verify("u1", code) is True
    with pytest.raises(OtpNotFoundError):
        await otp.verify("u1", code)


async def test_verify_without_issue_raises_not_found(any_backend):
    otp = Otp(any_backend, resend_cooldown=0)
    with pytest.raises(OtpNotFoundError):
        await otp.verify("u1", "123456")


async def test_too_many_attempts_invalidates(any_backend):
    otp = Otp(any_backend, max_attempts=3, resend_cooldown=0)
    code = await otp.issue("u1")
    for _ in range(3):
        assert await otp.verify("u1", "000000") is False
    # next attempt — even with the correct code — is rejected and clears state
    with pytest.raises(OtpTooManyAttemptsError):
        await otp.verify("u1", code)
    # subsequent calls now see no active code
    with pytest.raises(OtpNotFoundError):
        await otp.verify("u1", code)


async def test_codes_are_subject_bound(any_backend):
    otp = Otp(any_backend, resend_cooldown=0)
    code = await otp.issue("u1")
    await otp.issue("u2")
    # u1's code should not verify for u2
    assert await otp.verify("u2", code) is False


async def test_resend_cooldown_blocks_reissue(any_backend):
    otp = Otp(any_backend, resend_cooldown=60)
    await otp.issue("u1")
    with pytest.raises(OtpCooldownError):
        await otp.issue("u1")


async def test_resend_cooldown_zero_allows_rapid_reissue(any_backend):
    otp = Otp(any_backend, resend_cooldown=0)
    c1 = await otp.issue("u1")
    c2 = await otp.issue("u1")
    # new code invalidates the old one
    assert await otp.verify("u1", c1) is False or c1 == c2


async def test_issue_resets_attempt_counter(memory_backend):
    otp = Otp(memory_backend, max_attempts=3, resend_cooldown=0)
    await otp.issue("u1")
    for _ in range(2):
        assert await otp.verify("u1", "000000") is False
    code = await otp.issue("u1")  # fresh issue → counter reset
    # Should still have 3 attempts left — burn 2 wrong, then the correct works
    for _ in range(2):
        assert await otp.verify("u1", "000000") is False
    assert await otp.verify("u1", code) is True


async def test_invalidate_revokes_code(any_backend):
    otp = Otp(any_backend, resend_cooldown=0)
    code = await otp.issue("u1")
    await otp.invalidate("u1")
    with pytest.raises(OtpNotFoundError):
        await otp.verify("u1", code)


async def test_ttl_expires(memory_backend):
    otp = Otp(memory_backend, ttl=1, resend_cooldown=0)
    code = await otp.issue("u1")
    await asyncio.sleep(1.2)
    with pytest.raises(OtpNotFoundError):
        await otp.verify("u1", code)


async def test_custom_alphabet(any_backend):
    otp = Otp(
        any_backend, code_length=8, alphabet="ABCDEFGH", resend_cooldown=0
    )
    code = await otp.issue("u1")
    assert len(code) == 8
    assert all(c in "ABCDEFGH" for c in code)
    assert await otp.verify("u1", code) is True


def test_validation(memory_backend):
    with pytest.raises(ValueError):
        Otp(memory_backend, ttl=0)
    with pytest.raises(ValueError):
        Otp(memory_backend, code_length=3)
    with pytest.raises(ValueError):
        Otp(memory_backend, max_attempts=0)
    with pytest.raises(ValueError):
        Otp(memory_backend, resend_cooldown=-1)
    with pytest.raises(ValueError):
        Otp(memory_backend, alphabet="x")
