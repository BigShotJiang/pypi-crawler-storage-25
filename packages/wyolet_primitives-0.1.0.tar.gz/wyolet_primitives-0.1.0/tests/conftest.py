"""Test fixtures.

Unit tests use `MemoryBackend` and run with plain `pytest`. Integration tests
are gated behind `-m integration` and require `docker compose up` to provide
redis/valkey/postgres. Integration fixtures skip when the service isn't reachable
instead of erroring, so the suite is runnable without docker.
"""

import os

import pytest
import pytest_asyncio

from wyolet.primitives import MemoryBackend
from wyolet.primitives.backends.base import Backend

REDIS_URL = os.environ.get("TEST_REDIS_URL", "redis://localhost:6379/0")
VALKEY_URL = os.environ.get("TEST_VALKEY_URL", "redis://localhost:6380/0")
POSTGRES_URL = os.environ.get(
    "TEST_POSTGRES_URL",
    "postgresql://wyolet:wyolet@localhost:5433/wyolet_test",
)


# ── unit fixtures ──────────────────────────────────────────────────────────
@pytest_asyncio.fixture
async def memory_backend() -> MemoryBackend:
    b = MemoryBackend(sweep_interval=0.05)
    await b.start()
    yield b
    await b.close()


# ── integration fixtures ───────────────────────────────────────────────────
@pytest_asyncio.fixture
async def redis_backend():
    from redis.asyncio import Redis

    from wyolet.primitives.backends.redis import RedisBackend

    client = Redis.from_url(REDIS_URL)
    try:
        await client.ping()
    except Exception as e:
        pytest.skip(f"redis not reachable at {REDIS_URL}: {e}")
    await client.flushdb()
    yield RedisBackend(client)
    await client.flushdb()
    await client.aclose()


@pytest_asyncio.fixture
async def valkey_backend():
    from valkey.asyncio import Valkey

    from wyolet.primitives.backends.valkey import ValkeyBackend

    client = Valkey.from_url(VALKEY_URL)
    try:
        await client.ping()
    except Exception as e:
        pytest.skip(f"valkey not reachable at {VALKEY_URL}: {e}")
    await client.flushdb()
    yield ValkeyBackend(client)
    await client.flushdb()
    await client.aclose()


@pytest_asyncio.fixture
async def postgres_pool():
    from psycopg_pool import AsyncConnectionPool

    pool = AsyncConnectionPool(POSTGRES_URL, min_size=1, max_size=4, open=False)
    try:
        await pool.open(wait=True, timeout=2.0)
    except Exception as e:
        pytest.skip(f"postgres not reachable at {POSTGRES_URL}: {e}")
    try:
        async with pool.connection() as conn:
            async with conn.cursor() as cur:
                await cur.execute("DROP TABLE IF EXISTS user_sessions")
        yield pool
    finally:
        await pool.close()


# ── cross-backend parametrization ──────────────────────────────────────────
@pytest_asyncio.fixture(params=["memory", "sqlite", "redis", "valkey", "postgres"])
async def any_backend(request) -> Backend:
    """Parametrized fixture — tests written against this run once per backend.
    Redis/Valkey/Postgres skip when the service is unreachable."""
    if request.param == "memory":
        backend = MemoryBackend(sweep_interval=0.05)
        await backend.start()
        yield backend
        await backend.close()
    elif request.param == "sqlite":
        pytest.importorskip("aiosqlite")
        from wyolet.primitives.backends.sqlite import SQLiteBackend

        backend = SQLiteBackend(":memory:", sweep_interval=3600)
        await backend.start()
        yield backend
        await backend.close()
    elif request.param == "redis":
        pytest.importorskip("redis")
        from redis.asyncio import Redis

        from wyolet.primitives.backends.redis import RedisBackend

        client = Redis.from_url(REDIS_URL)
        try:
            await client.ping()
        except Exception as e:
            pytest.skip(f"redis not reachable: {e}")
        await client.flushdb()
        yield RedisBackend(client)
        await client.flushdb()
        await client.aclose()
    elif request.param == "valkey":
        pytest.importorskip("valkey")
        from valkey.asyncio import Valkey

        from wyolet.primitives.backends.valkey import ValkeyBackend

        client = Valkey.from_url(VALKEY_URL)
        try:
            await client.ping()
        except Exception as e:
            pytest.skip(f"valkey not reachable: {e}")
        await client.flushdb()
        yield ValkeyBackend(client)
        await client.flushdb()
        await client.aclose()
    else:
        pytest.importorskip("psycopg")
        from psycopg_pool import AsyncConnectionPool

        from wyolet.primitives.backends.postgres import PostgresBackend

        pool = AsyncConnectionPool(POSTGRES_URL, min_size=1, max_size=4, open=False)
        try:
            await pool.open(wait=True, timeout=2.0)
        except Exception as e:
            pytest.skip(f"postgres not reachable at {POSTGRES_URL}: {e}")
        table = "wyolet_kv_test"
        backend = PostgresBackend(pool, table=table, sweep_interval=3600)
        await backend.ensure_schema()
        async with pool.connection() as conn:
            async with conn.cursor() as cur:
                await cur.execute(f"TRUNCATE {table}")
            await conn.commit()
        await backend.start()
        try:
            yield backend
        finally:
            await backend.close()
            async with pool.connection() as conn:
                async with conn.cursor() as cur:
                    await cur.execute(f"DROP TABLE IF EXISTS {table}")
                await conn.commit()
            await pool.close()
