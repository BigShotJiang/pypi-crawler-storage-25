import asyncio
import json

import pytest

from wyolet.primitives.idempotency import IdempotencyMiddleware


class Counter:
    def __init__(self):
        self.n = 0


async def _drive(app, scope):
    sent = []

    async def send(m):
        sent.append(m)

    async def receive():
        return {"type": "http.request", "body": b"", "more_body": False}

    await app(scope, receive, send)
    start = next(m for m in sent if m["type"] == "http.response.start")
    body = b"".join(m["body"] for m in sent if m["type"] == "http.response.body")
    return start["status"], dict(start["headers"]), body


def _scope(method="POST", key=None):
    headers = []
    if key is not None:
        headers.append((b"idempotency-key", key.encode()))
    return {"type": "http", "method": method, "path": "/", "headers": headers}


def _make_inner(counter: Counter, status=201, body=None):
    async def app(scope, receive, send):
        counter.n += 1
        payload = body if body is not None else json.dumps({"n": counter.n}).encode()
        await send({"type": "http.response.start", "status": status, "headers": []})
        await send({"type": "http.response.body", "body": payload})

    return app


async def test_passthrough_without_header(memory_backend):
    c = Counter()
    app = IdempotencyMiddleware(_make_inner(c), backend=memory_backend)
    for _ in range(3):
        status, _, _ = await _drive(app, _scope())
        assert status == 201
    assert c.n == 3


async def test_replay_returns_cached_response(memory_backend):
    c = Counter()
    app = IdempotencyMiddleware(_make_inner(c), backend=memory_backend)
    s1, _, b1 = await _drive(app, _scope(key="k"))
    s2, h2, b2 = await _drive(app, _scope(key="k"))
    assert s1 == s2 == 201
    assert b1 == b2
    assert c.n == 1
    assert h2[b"idempotent-replayed"] == b"true"


async def test_different_keys_run_separately(memory_backend):
    c = Counter()
    app = IdempotencyMiddleware(_make_inner(c), backend=memory_backend)
    await _drive(app, _scope(key="a"))
    await _drive(app, _scope(key="b"))
    assert c.n == 2


async def test_get_is_not_intercepted(memory_backend):
    c = Counter()
    app = IdempotencyMiddleware(_make_inner(c), backend=memory_backend)
    for _ in range(2):
        await _drive(app, _scope(method="GET", key="k"))
    assert c.n == 2


async def test_5xx_not_cached(memory_backend):
    c = Counter()
    app = IdempotencyMiddleware(
        _make_inner(c, status=500, body=b"boom"), backend=memory_backend
    )
    for _ in range(2):
        s, _, _ = await _drive(app, _scope(key="k"))
        assert s == 500
    assert c.n == 2


async def test_concurrent_replays_run_handler_once(memory_backend):
    c = Counter()

    async def slow(scope, receive, send):
        c.n += 1
        await asyncio.sleep(0.3)
        await send({"type": "http.response.start", "status": 201, "headers": []})
        await send({"type": "http.response.body", "body": b"done"})

    app = IdempotencyMiddleware(slow, backend=memory_backend, wait_for_first=5.0)
    results = await asyncio.gather(
        *[_drive(app, _scope(key="k")) for _ in range(4)]
    )
    assert all(r[0] == 201 for r in results)
    assert all(r[2] == b"done" for r in results)
    assert c.n == 1


async def test_wait_exceeded_returns_409(memory_backend):
    c = Counter()

    async def slow(scope, receive, send):
        c.n += 1
        await asyncio.sleep(0.5)
        await send({"type": "http.response.start", "status": 201, "headers": []})
        await send({"type": "http.response.body", "body": b"done"})

    app = IdempotencyMiddleware(slow, backend=memory_backend, wait_for_first=0.1)
    first = asyncio.create_task(_drive(app, _scope(key="k")))
    await asyncio.sleep(0.05)  # let the first one grab the lock
    status, _, body = await _drive(app, _scope(key="k"))
    assert status == 409
    assert b"idempotency_in_progress" in body
    await first
