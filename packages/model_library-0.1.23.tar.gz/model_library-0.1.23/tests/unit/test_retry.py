"""
Unit tests for retry logic.
"""

from typing import Type
from unittest.mock import AsyncMock, MagicMock, Mock, patch

import httpcore
import httpx
import pytest

from model_library.base import LLM, QueryResult
from model_library.base import FinishReason
from model_library.base.output import FinishReasonInfo
from model_library.exceptions import (
    BackoffRetryException,
    BadInputError,
    ContentFilterError,
    ImmediateRetryException,
    MaxContextWindowExceededError,
    MaxOutputTokensExceededError,
    ModelNoOutputError,
    RateLimitException,
    RetryException,
    ToolCallingNotSupportedError,
    is_retriable_error,
    handle_empty_response,
)
from model_library.retriers.backoff import ExponentialBackoffRetrier
from model_library.retriers.base import BaseRetrier, retry_decorator
from model_library.retriers.utils import jitter


@pytest.fixture(autouse=True)
def mock_asyncio_sleep():
    with patch("asyncio.sleep", new_callable=AsyncMock) as mock_sleep:
        yield mock_sleep


async def test_jitter():
    """
    Test that jitter function returns values within expected range
    """
    wait = 10.0
    for _ in range(100):
        jittered = jitter(wait)
        # Should be within 20% of original wait time
        assert 8.0 <= jittered <= 12.0


async def test_retry_with_backoff_callback():
    """
    Test retry behavior with custom backoff_callback
    """

    # function raises RetryException, and retries
    # callback raises exception after 2 retries

    def callback(tries: int, exception: Exception | None, elapsed: float, wait: float):
        if tries > 2:
            raise Exception(tries, exception, elapsed, wait)

    callback_mock = Mock(side_effect=callback)

    retrier = ExponentialBackoffRetrier(
        MagicMock(), max_tries=2, retry_callback=callback_mock
    )
    decorator = retry_decorator(retrier)

    mock_func = Mock(side_effect=RetryException())

    @decorator
    async def func():
        mock_func()

    with pytest.raises(Exception):
        await func()

    assert callback_mock.call_count >= 1
    assert mock_func.call_count == 2


async def test_max_retries_giveup():
    """
    Test that after max retries, it gives up and re raises the exception
    """
    mock_func = Mock(side_effect=RetryException())

    retrier = ExponentialBackoffRetrier(MagicMock(), max_tries=3)
    decorator = retry_decorator(retrier)

    @decorator
    async def func():
        mock_func()

    with pytest.raises(RetryException):
        await func()

    assert mock_func.call_count == 3


async def test_retry_success_after_failures():
    """
    Test that after some retryable exceptions, the function succeeds
    """
    mock_func = Mock()
    mock_func.side_effect = [
        RetryException(),
        RetryException(),
        "success",
    ]

    retrier = ExponentialBackoffRetrier(MagicMock(), max_tries=5)
    decorator = retry_decorator(retrier)

    @decorator
    async def failing_func():
        result = mock_func()
        if isinstance(result, Exception):
            raise result
        return result

    result = await failing_func()
    assert result == "success"
    assert mock_func.call_count == 3


@pytest.mark.parametrize(
    "exception,retriable",
    [
        (RetryException, True),
        (ImmediateRetryException, True),
        (BackoffRetryException, True),
        (RateLimitException, True),
        (MaxOutputTokensExceededError, False),
        (MaxContextWindowExceededError, False),
        (ContentFilterError, False),
        (ModelNoOutputError, True),
        (ToolCallingNotSupportedError, False),
        (BadInputError, False),
        (ValueError, False),
        # httpx/httpcore
        (httpx.ReadError, True),
        (httpx.ConnectError, True),
        (httpcore.ReadError, True),
        (httpx.RemoteProtocolError, True),
    ],
)
async def test_core_errors(
    mock_llm: LLM,
    exception: Type[Exception],
    retriable: bool,
):
    """
    Test that core errors are / are not retriable
    """

    query_impl_mock = AsyncMock(
        side_effect=[exception("Mock"), QueryResult(output_text="success")]
    )
    mock_llm._query_impl = query_impl_mock  # pyright: ignore[reportPrivateUsage]

    if retriable:
        await mock_llm.query("Mock Input")
        assert query_impl_mock.call_count == 2
    else:
        with pytest.raises(exception):
            await mock_llm.query("Mock Input")
        assert query_impl_mock.call_count == 1


async def test_immediate_retry_exception_success(mock_llm: LLM):
    """
    Test that ImmediateRetryException triggers immediate retries
    """
    # raise ImmediateRetryException twice, then succeed
    query_impl_mock = AsyncMock(
        side_effect=[
            ImmediateRetryException("Immediate retry"),
            ImmediateRetryException("Immediate retry"),
            QueryResult(output_text="success"),
        ]
    )
    mock_llm._query_impl = query_impl_mock  # pyright: ignore[reportPrivateUsage]

    # track calls
    with (
        patch.object(
            BaseRetrier,
            "immediate_retry_wrapper",
            wraps=BaseRetrier.immediate_retry_wrapper,
        ) as mock_immediate_retry,
        patch.object(
            ExponentialBackoffRetrier,
            "execute",
            autospec=True,
            wraps=ExponentialBackoffRetrier.execute,
        ) as mock_backoff_retry,
    ):
        result = await mock_llm.query("Mock Input")

    assert result.output_text == "success"
    # called by immediate_retry_wrapper (2 immediate retries + 1 success)
    assert query_impl_mock.call_count == 3
    # called once by backoff_retry_wrapper
    assert mock_immediate_retry.call_count == 1
    # called once by query()
    assert mock_backoff_retry.call_count == 1


async def test_immediate_retry_exception_limit(mock_llm: LLM):
    """
    Test that ImmediateRetryException reaches limit
    """

    # raise ImmediateRetryException twice, then succeed
    query_impl_mock = AsyncMock(
        side_effect=[
            ImmediateRetryException("Immediate retry"),
            ImmediateRetryException("Immediate retry"),
            ImmediateRetryException("Immediate retry"),
            ImmediateRetryException("Immediate retry"),
            ImmediateRetryException("Immediate retry"),
            ImmediateRetryException("Immediate retry"),
            ImmediateRetryException("Immediate retry"),
            ImmediateRetryException("Immediate retry"),
            ImmediateRetryException("Immediate retry"),
            ImmediateRetryException("Immediate retry"),
            ImmediateRetryException("Immediate retry"),
        ]
    )
    mock_llm._query_impl = query_impl_mock  # pyright: ignore[reportPrivateUsage]

    # track calls
    with (
        patch.object(
            BaseRetrier,
            "immediate_retry_wrapper",
            wraps=BaseRetrier.immediate_retry_wrapper,
        ) as mock_immediate_retry,
        patch.object(
            ExponentialBackoffRetrier,
            "execute",
            autospec=True,
            wraps=ExponentialBackoffRetrier.execute,
        ) as mock_backoff_retry,
    ):
        with pytest.raises(Exception):
            await mock_llm.query("Mock Input")

    assert query_impl_mock.call_count == 12
    assert mock_immediate_retry.call_count == 2
    assert mock_backoff_retry.call_count == 1


@pytest.mark.parametrize(
    "exception_message,expected_retriable",
    [
        ("Error 429", True),  # rate limit
        ("Error 500", True),  # internal server error
        ("Error 502", True),  # bad gateway
        ("Error 503", True),  # service unavailable
        ("Error 504", True),  # gateway timeout
        ("Error 529", True),  # overloaded, service unavailable
        ("retry failed", True),  # retry keyword
        ("timeout occurred", True),  # timeout keyword
        ("connection_error happened", True),  # connection_error keyword
        ("service_unavailable now", True),  # service_unavailable keyword
        ("rate_limit exceeded", True),  # rate_limit keyword
        ("internal_error detected", True),  # internal_error keyword
        ("server_error occurred", True),  # server_error keyword
        ("Error 404", False),  # not found
        ("Error 400", False),  # bad request
        ("Misc Error", False),  # generic error
        ("overloaded", True),  # overloaded error from anthropic
    ],
)
async def test_retry_by_exception_message(
    exception_message: str,
    expected_retriable: bool,
):
    """
    Test retriable exception messages
    """
    exc = ValueError(exception_message)
    assert is_retriable_error(exc) == expected_retriable


async def test_context_window_error_gives_up(mock_llm: LLM):
    """
    Tests against various context window exceeded errors from model providers,
    ensures that we are correctly identifying them and raising with the correct message

    Separate test was created with real api calls to remove the controlled environment aspect
    """

    # List that was generated directly from model providers' error messages
    exception_messages = [
        "The input token count exceeds the maximum number of tokens allowed.",
        "This model's maximum context length is 262144 tokens. However, your request has 1000010 input tokens. Please reduce the length of the input messages. None",
        "Range of input length should be [1, 258048]",
        "Input Tokens Exceeded: Number of input tokens exceeds maximum length. Please update the input to try again.",
        "prompt is too long: 200005 tokens > 200000 maximum",
        "Your input exceeds the context window of this model. Please adjust your input and try again.",
        "This model's maximum context length is 131072 tokens. However, you requested 1008004 tokens (1000004 in the messages, 8000 in the completion). Please reduce the length of the messages or completion.",
        "The prompt is too long: 1000008, model maximum context length: 131071",
        "Prompt contains 1000172 tokens and 0 draft tokens, too large for model with 40960 maximum context length",
        "The total length of all messages is too long.",
        "The input (1000016 tokens) is longer than the model's context length (131072 tokens).",
        "Sent message larger than max (50000056 vs. 20971520)",
        "too many tokens: size limit exceeded by 713295 tokens. Try using shorter or fewer inputs. The limit for this model is 288000 tokens.",
        "input length and max_tokens exceed context limit: 200043 + 32000 > 204658, decrease input length or max_tokens and try again",
        "Payload Too Large",
        "invalid params, context window exceeds limit (2013)",  # minimax
    ]

    for exception_message in exception_messages:
        query_impl_mock = AsyncMock(side_effect=[Exception(exception_message)])

        mock_llm._query_impl = query_impl_mock  # pyright: ignore[reportPrivateUsage]

        with pytest.raises(MaxContextWindowExceededError) as exc_info:
            await mock_llm.query("Mock Input")

        assert exc_info.value.args[0] == exception_message


@pytest.mark.parametrize(
    "finish_reason,expected_exception",
    [
        (FinishReason.CONTEXT_WINDOW_EXCEEDED, MaxContextWindowExceededError),
        (FinishReason.MAX_TOKENS, MaxOutputTokensExceededError),
        (FinishReason.STOP, ModelNoOutputError),
        (FinishReason.UNKNOWN, ModelNoOutputError),
    ],
)
async def test_handle_empty_response(
    finish_reason: FinishReason,
    expected_exception: type[Exception],
):
    """
    Test that handle_empty_response raises the correct exception for each finish reason
    """
    with pytest.raises(expected_exception):
        handle_empty_response(FinishReasonInfo(reason=finish_reason, raw=str(finish_reason.value)))


async def test_no_retry_exception_not_retried_despite_retriable_message():
    """
    NoRetryException subclasses should never be retried, even if their
    message contains strings that match RETRIABLE_EXCEPTION_CODES (e.g. "500"
    appearing in a base64 blob or raw API response dump).
    """
    # Message contains multiple retriable code substrings
    poison_message = "Error 500 with timeout and retry and server_error"
    assert is_retriable_error(MaxOutputTokensExceededError(poison_message)) is False
    assert is_retriable_error(MaxContextWindowExceededError(poison_message)) is False
    assert is_retriable_error(ContentFilterError(poison_message)) is False
