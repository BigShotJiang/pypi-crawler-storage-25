# debtscanner

`debtscanner` is a Python CLI that scans codebases for technical debt using AI and produces prioritized results in terminal and HTML.

## Install

```bash
pip install -e .
```

## Configure

Create a `.env` file in the project root:

```env
GITHUB_TOKEN=ghp_your_token_here
```

Or export `GITHUB_TOKEN` in your shell.

## Commands

```bash
debtscanner scan .
debtscanner scan src/ --output report.html
debtscanner report
debtscanner fix auth.py
```

## Options

- `--ignore`: skip specific folders (repeatable or comma-separated)
- `--severity`: minimum level to include (`LOW`, `MEDIUM`, `HIGH`, `CRITICAL`)

## Supported languages

- `.py`, `.js`, `.ts`, `.jsx`, `.tsx`, `.java`, `.go`, `.rb`

## Behavior

- Skips: `node_modules`, `.git`, `__pycache__`, `dist`, `build`, `.env`
- Skips files larger than 100KB with warning
- Skips binary files automatically
- Retries once on API rate limits with a 2-second pause
