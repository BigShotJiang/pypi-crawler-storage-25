from setuptools import find_packages, setup

setup(
    name="debtscanner",
    version="0.2.0",
    description="AI-powered technical debt scanner for codebases",
    packages=find_packages(),
    include_package_data=True,
    install_requires=[
        "click",
        "openai",
        "tqdm",
        "colorama",
        "rich",
        "python-dotenv",
    ],
    extras_require={
        "watch": ["watchdog"],
    },
    entry_points={
        "console_scripts": [
            "debtscanner=debtscanner.cli:main",
        ]
    },
)
