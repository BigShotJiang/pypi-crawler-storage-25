from __future__ import annotations

import json
from collections import Counter
from html import escape
from pathlib import Path
from typing import Sequence

from rich.console import Console
from rich.table import Table

from .scanner import (
    DebtItem,
    FileScore,
    compute_file_scores,
    sort_debt_items,
    top_critical_files,
)

SEVERITY_STYLES = {
    "CRITICAL": "red",
    "HIGH": "dark_orange",
    "MEDIUM": "yellow",
    "LOW": "bright_blue",
}

console = Console()


def render_terminal_table(items: Sequence[DebtItem]) -> None:
    table = Table(title="Technical Debt Report", show_lines=True)
    table.add_column("Severity", style="bold")
    table.add_column("File", overflow="fold")
    table.add_column("Line", justify="right")
    table.add_column("Issue", overflow="fold")
    table.add_column("Suggested Fix", overflow="fold")

    for item in sort_debt_items(items):
        style = SEVERITY_STYLES.get(item.severity, "white")
        table.add_row(
            f"[{style}]{item.severity}[/{style}]",
            item.file,
            str(item.line),
            item.issue,
            item.fix,
        )

    console.print(table)


def render_file_scores_table(scores: Sequence[FileScore]) -> None:
    table = Table(title="Top Critical Files", show_lines=True)
    table.add_column("Score", justify="right", style="bold")
    table.add_column("File", overflow="fold")
    table.add_column("CRIT", justify="right", style="red")
    table.add_column("HIGH", justify="right", style="dark_orange")
    table.add_column("MED", justify="right", style="yellow")
    table.add_column("LOW", justify="right", style="bright_blue")

    for fs in scores:
        if fs.score >= 70:
            score_style = "red bold"
        elif fs.score >= 40:
            score_style = "dark_orange bold"
        else:
            score_style = "green bold"

        table.add_row(
            f"[{score_style}]{fs.score}[/{score_style}]",
            fs.file,
            str(fs.critical),
            str(fs.high),
            str(fs.medium),
            str(fs.low),
        )

    console.print(table)


def summarize(items: Sequence[DebtItem]) -> str:
    counts = Counter(item.severity for item in items)
    return (
        f"CRITICAL: {counts.get('CRITICAL', 0)}  "
        f"HIGH: {counts.get('HIGH', 0)}  "
        f"MEDIUM: {counts.get('MEDIUM', 0)}  "
        f"LOW: {counts.get('LOW', 0)}"
    )


def summary_line(total_files: int, items: Sequence[DebtItem]) -> str:
  return f"Scanned {total_files} files - Found {len(items)} debt items"


def render_json(items: Sequence[DebtItem], total_files: int) -> str:
    file_scores = compute_file_scores(items)

    payload = {
        "summary": {
            "total_files_scanned": total_files,
            "total_debt_items": len(items),
            "severity_counts": dict(Counter(i.severity for i in items)),
        },
        "file_scores": [
            {
                "file": fs.file,
                "score": fs.score,
                "critical": fs.critical,
                "high": fs.high,
                "medium": fs.medium,
                "low": fs.low,
            }
            for fs in file_scores
        ],
        "items": [
            {
                "severity": i.severity,
                "file": i.file,
                "line": i.line,
                "issue": i.issue,
                "fix": i.fix,
            }
            for i in sort_debt_items(items)
        ],
    }
    return json.dumps(payload, indent=2)


def render_markdown(items: Sequence[DebtItem], total_files: int) -> str:
    lines: list[str] = []
    lines.append("# Technical Debt Report\n")
    lines.append(f"{summary_line(total_files, items)}\n")
    lines.append(f"{summarize(items)}\n")

    top_files = top_critical_files(items)
    if top_files:
        lines.append("## Top Critical Files\n")
        lines.append("| Score | File | CRIT | HIGH | MED | LOW |")
        lines.append("|------:|------|-----:|-----:|----:|----:|")
        for fs in top_files:
            lines.append(
                f"| {fs.score} | `{fs.file}` | {fs.critical} | {fs.high} "
                f"| {fs.medium} | {fs.low} |"
            )
        lines.append("")

    lines.append("## All Debt Items\n")
    lines.append("| Severity | File | Line | Issue | Suggested Fix |")
    lines.append("|----------|------|-----:|-------|---------------|")
    for item in sort_debt_items(items):
        lines.append(
            f"| **{item.severity}** | `{item.file}` | {item.line} "
            f"| {item.issue} | {item.fix} |"
        )
    lines.append("")
    return "\n".join(lines)


def write_html_report(
    items: Sequence[DebtItem],
    output_path: str,
    total_files: int,
) -> str:
    sorted_items = sort_debt_items(items)
    file_scores = compute_file_scores(items)
    top5 = file_scores[:5]
    path = Path(output_path)
    path.parent.mkdir(parents=True, exist_ok=True)

    counts = Counter(i.severity for i in items)

    rows = []
    for item in sorted_items:
        css_class = item.severity.lower()
        rows.append(
            "<tr>"
            f"<td class='sev {css_class}'>{escape(item.severity)}</td>"
            f"<td>{escape(item.file)}</td>"
            f"<td class='num'>{item.line}</td>"
            f"<td>{escape(item.issue)}</td>"
            f"<td>{escape(item.fix)}</td>"
            "</tr>"
        )

    top_rows = []
    for fs in top5:
        bar_width = fs.score
        if fs.score >= 70:
            bar_cls = "bar-red"
        elif fs.score >= 40:
            bar_cls = "bar-orange"
        else:
            bar_cls = "bar-green"
        top_rows.append(
            "<tr>"
            f"<td class='score-cell'>"
            f"<div class='score-bar {bar_cls}' style='width:{bar_width}%'>"
            f"<span>{fs.score}</span></div></td>"
            f"<td>{escape(fs.file)}</td>"
            f"<td class='num'>{fs.critical}</td>"
            f"<td class='num'>{fs.high}</td>"
            f"<td class='num'>{fs.medium}</td>"
            f"<td class='num'>{fs.low}</td>"
            "</tr>"
        )

    chart_labels = json.dumps([fs.file for fs in file_scores[:10]])
    chart_scores = json.dumps([fs.score for fs in file_scores[:10]])
    chart_colors = json.dumps([
        "#e53935" if fs.score >= 70 else "#fb8c00" if fs.score >= 40 else "#43a047"
        for fs in file_scores[:10]
    ])

    sev_labels = json.dumps(["Critical", "High", "Medium", "Low"])
    sev_data = json.dumps([
        counts.get("CRITICAL", 0),
        counts.get("HIGH", 0),
        counts.get("MEDIUM", 0),
        counts.get("LOW", 0),
    ])
    sev_colors = json.dumps(["#e53935", "#fb8c00", "#fdd835", "#1e88e5"])

    html = f"""<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>debtscanner report</title>
  <script src="https://cdn.jsdelivr.net/npm/chart.js@4"></script>
  <style>
    :root {{
      --bg: #0f1117;
      --surface: #181b23;
      --surface2: #22262f;
      --border: #2d3140;
      --text: #e4e6ed;
      --text-dim: #8b8fa3;
      --accent: #6c63ff;
      --critical: #e53935;
      --high: #fb8c00;
      --medium: #fdd835;
      --low: #1e88e5;
    }}

    * {{ margin: 0; padding: 0; box-sizing: border-box; }}

    body {{
      font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
      background: var(--bg);
      color: var(--text);
      line-height: 1.6;
    }}

    .container {{
      max-width: 1200px;
      margin: 0 auto;
      padding: 32px 24px;
    }}

    header {{
      text-align: center;
      margin-bottom: 40px;
    }}

    header h1 {{
      font-size: 2rem;
      font-weight: 700;
      background: linear-gradient(135deg, var(--accent), #a78bfa);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      background-clip: text;
      margin-bottom: 8px;
    }}

    header .subtitle {{
      color: var(--text-dim);
      font-size: 1rem;
    }}

    .stats {{
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(160px, 1fr));
      gap: 16px;
      margin-bottom: 32px;
    }}

    .stat-card {{
      background: var(--surface);
      border: 1px solid var(--border);
      border-radius: 12px;
      padding: 20px;
      text-align: center;
    }}

    .stat-card .number {{
      font-size: 2rem;
      font-weight: 700;
    }}

    .stat-card .label {{
      color: var(--text-dim);
      font-size: 0.85rem;
      text-transform: uppercase;
      letter-spacing: 0.05em;
    }}

    .stat-card.critical .number {{ color: var(--critical); }}
    .stat-card.high .number {{ color: var(--high); }}
    .stat-card.medium .number {{ color: var(--medium); }}
    .stat-card.low .number {{ color: var(--low); }}
    .stat-card.total .number {{ color: var(--accent); }}

    .charts {{
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 24px;
      margin-bottom: 32px;
    }}

    .chart-card {{
      background: var(--surface);
      border: 1px solid var(--border);
      border-radius: 12px;
      padding: 24px;
    }}

    .chart-card h2 {{
      font-size: 1.1rem;
      margin-bottom: 16px;
      color: var(--text-dim);
    }}

    .section-title {{
      font-size: 1.25rem;
      font-weight: 600;
      margin: 32px 0 16px 0;
      padding-bottom: 8px;
      border-bottom: 1px solid var(--border);
    }}

    .score-cell {{
      width: 120px;
      min-width: 120px;
    }}

    .score-bar {{
      height: 24px;
      border-radius: 4px;
      display: flex;
      align-items: center;
      justify-content: center;
      min-width: 30px;
      transition: width 0.4s ease;
    }}

    .score-bar span {{
      font-size: 0.8rem;
      font-weight: 700;
      color: #fff;
      text-shadow: 0 1px 2px rgba(0,0,0,0.4);
    }}

    .bar-red {{ background: linear-gradient(90deg, #e53935, #c62828); }}
    .bar-orange {{ background: linear-gradient(90deg, #fb8c00, #ef6c00); }}
    .bar-green {{ background: linear-gradient(90deg, #43a047, #2e7d32); }}

    table {{
      width: 100%;
      border-collapse: collapse;
      background: var(--surface);
      border-radius: 12px;
      overflow: hidden;
      border: 1px solid var(--border);
      margin-bottom: 24px;
    }}

    th {{
      background: var(--surface2);
      color: var(--text-dim);
      font-weight: 600;
      font-size: 0.8rem;
      text-transform: uppercase;
      letter-spacing: 0.05em;
      padding: 12px 16px;
      text-align: left;
    }}

    td {{
      padding: 12px 16px;
      border-top: 1px solid var(--border);
      font-size: 0.9rem;
      vertical-align: top;
    }}

    tr:hover td {{ background: var(--surface2); }}

    .num {{ text-align: right; font-variant-numeric: tabular-nums; }}

    .sev {{
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.04em;
    }}

    .sev.critical {{ color: var(--critical); }}
    .sev.high {{ color: var(--high); }}
    .sev.medium {{ color: var(--medium); }}
    .sev.low {{ color: var(--low); }}

    footer {{
      text-align: center;
      color: var(--text-dim);
      font-size: 0.8rem;
      margin-top: 40px;
      padding-top: 20px;
      border-top: 1px solid var(--border);
    }}

    @media (max-width: 768px) {{
      .charts {{ grid-template-columns: 1fr; }}
      .stats {{ grid-template-columns: repeat(2, 1fr); }}
    }}
  </style>
</head>
<body>
  <div class="container">
    <header>
      <h1>Technical Debt Report</h1>
      <p class="subtitle">{escape(summary_line(total_files, sorted_items))}</p>
    </header>

    <div class="stats">
      <div class="stat-card total">
        <div class="number">{total_files}</div>
        <div class="label">Files Scanned</div>
      </div>
      <div class="stat-card critical">
        <div class="number">{counts.get('CRITICAL', 0)}</div>
        <div class="label">Critical</div>
      </div>
      <div class="stat-card high">
        <div class="number">{counts.get('HIGH', 0)}</div>
        <div class="label">High</div>
      </div>
      <div class="stat-card medium">
        <div class="number">{counts.get('MEDIUM', 0)}</div>
        <div class="label">Medium</div>
      </div>
      <div class="stat-card low">
        <div class="number">{counts.get('LOW', 0)}</div>
        <div class="label">Low</div>
      </div>
    </div>

    <div class="charts">
      <div class="chart-card">
        <h2>Severity Distribution</h2>
        <canvas id="sevChart"></canvas>
      </div>
      <div class="chart-card">
        <h2>Debt Score by File (Top 10)</h2>
        <canvas id="fileChart"></canvas>
      </div>
    </div>

    <h2 class="section-title">Top Critical Files</h2>
    <table>
      <thead>
        <tr>
          <th>Score</th>
          <th>File</th>
          <th>Crit</th>
          <th>High</th>
          <th>Med</th>
          <th>Low</th>
        </tr>
      </thead>
      <tbody>
        {''.join(top_rows) if top_rows else '<tr><td colspan="6" style="text-align:center;color:var(--text-dim)">No issues found</td></tr>'}
      </tbody>
    </table>

    <h2 class="section-title">All Debt Items</h2>
    <table>
      <thead>
        <tr>
          <th>Severity</th>
          <th>File</th>
          <th>Line</th>
          <th>Issue</th>
          <th>Suggested Fix</th>
        </tr>
      </thead>
      <tbody>
        {''.join(rows) if rows else '<tr><td colspan="5" style="text-align:center;color:var(--text-dim)">No debt items found</td></tr>'}
      </tbody>
    </table>

    <footer>
      Generated by <strong>debtscanner</strong>
    </footer>
  </div>

  <script>
    new Chart(document.getElementById('sevChart'), {{
      type: 'doughnut',
      data: {{
        labels: {sev_labels},
        datasets: [{{
          data: {sev_data},
          backgroundColor: {sev_colors},
          borderColor: '#181b23',
          borderWidth: 3,
        }}]
      }},
      options: {{
        responsive: true,
        plugins: {{
          legend: {{
            position: 'bottom',
            labels: {{ color: '#8b8fa3', padding: 16, font: {{ size: 13 }} }}
          }}
        }}
      }}
    }});

    new Chart(document.getElementById('fileChart'), {{
      type: 'bar',
      data: {{
        labels: {chart_labels},
        datasets: [{{
          label: 'Debt Score',
          data: {chart_scores},
          backgroundColor: {chart_colors},
          borderRadius: 6,
          maxBarThickness: 40,
        }}]
      }},
      options: {{
        indexAxis: 'y',
        responsive: true,
        scales: {{
          x: {{
            min: 0,
            max: 100,
            grid: {{ color: '#2d3140' }},
            ticks: {{ color: '#8b8fa3' }}
          }},
          y: {{
            grid: {{ display: false }},
            ticks: {{ color: '#8b8fa3', font: {{ size: 11 }} }}
          }}
        }},
        plugins: {{
          legend: {{ display: false }}
        }}
      }}
    }});
  </script>
</body>
</html>
"""

    path.write_text(html, encoding="utf-8")
    return str(path)
