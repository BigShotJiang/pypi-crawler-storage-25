from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass, field
import os
import re
from typing import Iterable, List, Sequence

SUPPORTED_EXTENSIONS = {".py", ".js", ".ts", ".jsx", ".tsx", ".java", ".go", ".rb"}
DEFAULT_EXCLUDED_DIRS = {"node_modules", ".git", "__pycache__", "dist", "build", ".env"}
MAX_FILE_SIZE_BYTES = 100 * 1024

SEVERITY_ORDER = {"CRITICAL": 4, "HIGH": 3, "MEDIUM": 2, "LOW": 1}

SEVERITY_WEIGHTS = {"CRITICAL": 25, "HIGH": 15, "MEDIUM": 8, "LOW": 3}


@dataclass(frozen=True)
class DebtItem:
    severity: str
    file: str
    line: int
    issue: str
    fix: str


@dataclass(frozen=True)
class ScannedFile:
    path: str
    content: str


@dataclass
class FileScore:
    file: str
    score: int = 0
    critical: int = 0
    high: int = 0
    medium: int = 0
    low: int = 0
    items: list[DebtItem] = field(default_factory=list)


def is_binary_file(file_path: str) -> bool:
    try:
        with open(file_path, "rb") as binary_file:
            chunk = binary_file.read(2048)
        return b"\x00" in chunk
    except OSError:
        return True


def _normalized_ignores(ignore_dirs: Sequence[str] | None) -> set[str]:
    if not ignore_dirs:
        return set()

    normalized = set()
    for directory in ignore_dirs:
        for piece in directory.split(","):
            part = piece.strip().strip("/\\")
            if part:
                normalized.add(part)
    return normalized


def iter_source_files(root_dir: str, ignore_dirs: Sequence[str] | None = None) -> Iterable[str]:
    skip_dirs = DEFAULT_EXCLUDED_DIRS | _normalized_ignores(ignore_dirs)

    for current_root, dirs, files in os.walk(root_dir):
        dirs[:] = [directory for directory in dirs if directory not in skip_dirs]

        for file_name in files:
            if os.path.splitext(file_name)[1].lower() not in SUPPORTED_EXTENSIONS:
                continue
            yield os.path.join(current_root, file_name)


def scan_files(root_dir: str, ignore_dirs: Sequence[str] | None = None) -> tuple[List[ScannedFile], List[str]]:
    scanned_files: List[ScannedFile] = []
    warnings: List[str] = []

    for file_path in iter_source_files(root_dir, ignore_dirs=ignore_dirs):
        try:
            size = os.path.getsize(file_path)
        except OSError:
            warnings.append(f"Skipping unreadable file: {file_path}")
            continue

        if size > MAX_FILE_SIZE_BYTES:
            warnings.append(f"Skipping file >100KB: {file_path}")
            continue

        if is_binary_file(file_path):
            warnings.append(f"Skipping binary file: {file_path}")
            continue

        try:
            with open(file_path, "r", encoding="utf-8", errors="ignore") as source_file:
                content = source_file.read()
        except OSError:
            warnings.append(f"Skipping unreadable file: {file_path}")
            continue

        if not content.strip():
            continue

        scanned_files.append(ScannedFile(path=file_path, content=content))

    return scanned_files, warnings


def parse_ai_scan_response(response_text: str, fallback_filename: str) -> List[DebtItem]:
    entries: List[DebtItem] = []

    blocks = [block.strip() for block in response_text.split("---") if block.strip()]
    for block in blocks:
        match = re.search(
            r"SEVERITY:\s*(?P<severity>CRITICAL|HIGH|MEDIUM|LOW)\s*\n"
            r"FILE:\s*(?P<file>.+?)\s*\n"
            r"LINE:\s*(?P<line>\d+)\s*\n"
            r"ISSUE:\s*(?P<issue>.+?)\s*\n"
            r"FIX:\s*(?P<fix>.+)",
            block,
            flags=re.IGNORECASE | re.DOTALL,
        )
        if not match:
            continue

        severity = match.group("severity").upper()
        file_name = match.group("file").strip() or fallback_filename
        issue = " ".join(match.group("issue").splitlines()).strip()
        fix = " ".join(match.group("fix").splitlines()).strip()

        try:
            line = int(match.group("line"))
        except ValueError:
            line = 0

        entries.append(
            DebtItem(
                severity=severity,
                file=file_name,
                line=max(0, line),
                issue=issue,
                fix=fix,
            )
        )

    return entries


def severity_rank(severity: str) -> int:
    return SEVERITY_ORDER.get(severity.upper(), 0)


def filter_min_severity(items: Sequence[DebtItem], minimum: str) -> List[DebtItem]:
    threshold = severity_rank(minimum)
    return [item for item in items if severity_rank(item.severity) >= threshold]


def sort_debt_items(items: Sequence[DebtItem]) -> List[DebtItem]:
    return sorted(
        items,
        key=lambda item: (-severity_rank(item.severity), item.file.lower(), item.line),
    )


def compute_file_scores(items: Sequence[DebtItem]) -> List[FileScore]:
    by_file: dict[str, list[DebtItem]] = defaultdict(list)
    for item in items:
        by_file[item.file].append(item)

    scores: List[FileScore] = []
    for file_name, file_items in by_file.items():
        raw = sum(SEVERITY_WEIGHTS.get(i.severity, 0) for i in file_items)
        score = min(100, raw)

        counts: dict[str, int] = defaultdict(int)
        for i in file_items:
            counts[i.severity] += 1

        scores.append(
            FileScore(
                file=file_name,
                score=score,
                critical=counts.get("CRITICAL", 0),
                high=counts.get("HIGH", 0),
                medium=counts.get("MEDIUM", 0),
                low=counts.get("LOW", 0),
                items=file_items,
            )
        )

    scores.sort(key=lambda fs: -fs.score)
    return scores


def top_critical_files(items: Sequence[DebtItem], n: int = 5) -> List[FileScore]:
    return compute_file_scores(items)[:n]
