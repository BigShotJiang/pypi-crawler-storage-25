from __future__ import annotations

import os
import time
from typing import Any

from dotenv import load_dotenv
from openai import OpenAI

from .prompts import FIX_PROMPT, SCAN_PROMPT

PROVIDERS: dict[str, dict[str, Any]] = {
    "github": {
        "label": "GitHub Models (free with GitHub token)",
        "base_url": "https://models.inference.ai.azure.com",
        "default_model": "gpt-4o-mini",
        "env_key": "GITHUB_TOKEN",
        "env_hint": "ghp_xxxxxxxxxxxxxxxxxxxx",
    },
    "openai": {
        "label": "OpenAI (requires API key)",
        "base_url": "https://api.openai.com/v1",
        "default_model": "gpt-4o-mini",
        "env_key": "OPENAI_API_KEY",
        "env_hint": "sk-xxxxxxxxxxxxxxxxxxxx",
    },
    "anthropic": {
        "label": "Anthropic Claude (via OpenAI-compat proxy)",
        "base_url": "https://api.anthropic.com/v1",
        "default_model": "claude-sonnet-4-20250514",
        "env_key": "ANTHROPIC_API_KEY",
        "env_hint": "sk-ant-xxxxxxxxxxxxxxxxxxxx",
    },
    "ollama": {
        "label": "Ollama (local, no key needed)",
        "base_url": "http://localhost:11434/v1",
        "default_model": "llama3",
        "env_key": "",
        "env_hint": "",
    },
}


def _resolve_provider() -> tuple[str, str, str]:
    load_dotenv()

    provider_name = os.getenv("DEBTSCANNER_PROVIDER", "github").lower()
    info = PROVIDERS.get(provider_name)

    if info is None:
        raise RuntimeError(
            f"Unknown provider '{provider_name}'. "
            f"Valid choices: {', '.join(PROVIDERS)}"
        )

    model = os.getenv("DEBTSCANNER_MODEL", info["default_model"])
    base_url = os.getenv("DEBTSCANNER_BASE_URL", info["base_url"])

    if provider_name == "ollama":
        return base_url, "ollama", model

    env_key = info["env_key"]
    token = os.getenv(env_key, "")
    if not token:
        raise RuntimeError(
            f"Missing {env_key} for provider '{provider_name}'. "
            f"Run `debtscanner init` or add it to your .env file."
        )

    return base_url, token, model


class AIClient:
    def __init__(self) -> None:
        base_url, api_key, model = _resolve_provider()
        self.model = model
        self.client = OpenAI(base_url=base_url, api_key=api_key)

    def _create_completion(self, user_content: str) -> str:
        for attempt in range(2):
            try:
                response = self.client.chat.completions.create(
                    model=self.model,
                    messages=[
                        {
                            "role": "user",
                            "content": user_content,
                        }
                    ],
                    temperature=0.2,
                )
                return (response.choices[0].message.content or "").strip()
            except Exception as exc:
                error_text = str(exc).lower()
                should_retry = "429" in error_text or "rate limit" in error_text
                if should_retry and attempt == 0:
                    time.sleep(2)
                    continue
                raise

        return ""

    def analyze_code(self, filename: str, content: str) -> str:
        prompt = f"{SCAN_PROMPT}\n\nFILE UNDER REVIEW: {filename}\n\nCODE:\n{content}"
        return self._create_completion(prompt)

    def suggest_fixes(self, filename: str, content: str) -> str:
        prompt = f"{FIX_PROMPT}\n\nFILE UNDER REVIEW: {filename}\n\nCODE:\n{content}"
        return self._create_completion(prompt)
