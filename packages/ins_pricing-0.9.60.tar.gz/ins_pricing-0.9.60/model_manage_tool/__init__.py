"""Standalone model management tool for ins_pricing projects."""

from model_manage_tool.manager import ModelManagerService

__all__ = ["ModelManagerService"]

