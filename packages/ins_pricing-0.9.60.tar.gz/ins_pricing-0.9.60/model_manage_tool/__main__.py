from __future__ import annotations

from model_manage_tool.server import main


if __name__ == "__main__":
    main()
