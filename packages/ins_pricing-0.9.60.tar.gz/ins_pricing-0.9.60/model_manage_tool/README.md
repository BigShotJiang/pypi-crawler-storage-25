﻿# Model Manager Tool (Standalone Folder)

这是基于 `ins_pricing` 的独立模型管理工具目录，当前使用 **NiceGUI** 提供前后端一体化控制台。

主要功能包括：
- 浏览器访问的管理页面
- 模型导入（支持任意文件类型、支持多文件上传）
- Excel 配置自动导入（如因子定义、下拉选项、因子取值、计算逻辑）
- 版本管理
- 发布与回滚
- RBAC 权限管理（用户、角色、权限）
- 审计日志

## 启动

在项目根目录执行：

```bash
python -m model_manage_tool --host 127.0.0.1 --port 8092 --max-upload-mb 64
# or, after pip install:
model-manage-tool --host 127.0.0.1 --port 8092 --max-upload-mb 64
```

默认数据目录：`~/.ins_pricing/model_manage_tool/`（可通过 `--data-root` 或 `MODEL_MANAGER_DATA_ROOT` 覆盖）  
默认 UI 地址：`http://127.0.0.1:8092/`

## 环境变量

- `MODEL_MANAGER_DATA_ROOT`
- `MODEL_MANAGER_HOST`
- `MODEL_MANAGER_PORT`
- `MODEL_MANAGER_ADMIN_PASSWORD`
- `MODEL_MANAGER_STORAGE_SECRET`（可选，NiceGUI 用户会话签名密钥）
- `MODEL_MANAGER_MAX_UPLOAD_MB`（可选，单文件上传上限，单位 MB，默认 64）

## 依赖

需要安装 `nicegui` 与 `openpyxl`（建议通过项目 `frontend` extra 一并安装）：

```bash
pip install -e ".[frontend]"
```

## 上传限制说明

- 当前按“单文件”限制上传大小，默认 `64 MB`。
- 可通过 `--max-upload-mb` 或 `MODEL_MANAGER_MAX_UPLOAD_MB` 调整。
- `xls` / `xlsx` / `xlsm` 均支持，是否失败通常与文件大小限制或上传链路限制有关，而非扩展名本身。

## Excel 自动导入约定

为提高解析准确性，建议使用以下 sheet 名（支持中英文同义名）：

- 因子定义：`factor_definitions`
- 下拉选项：`dropdown_options`
- 因子取值：`factor_values`
- 计算逻辑：`calculation_logic`

导入后会在版本记录的 `artifact_manifest[].excel_profile.config_auto_import` 中保存结构化配置。

## 默认账号

- 用户名：`admin`
- 密码：`admin123!`（建议通过 `MODEL_MANAGER_ADMIN_PASSWORD` 覆盖）

## API 概览

- `POST /api/login`
- `GET /api/whoami`
- `POST /api/models/import`
- `GET /api/models`
- `GET /api/models/<model_name>/versions`
- `POST /api/deploy`
- `POST /api/rollback`
- `GET /api/environments`
- `GET /api/audit`
- `GET /api/admin/users`
- `POST /api/admin/users`
- `POST /api/admin/users/roles`
- `GET /api/admin/roles`
- `POST /api/admin/roles`

