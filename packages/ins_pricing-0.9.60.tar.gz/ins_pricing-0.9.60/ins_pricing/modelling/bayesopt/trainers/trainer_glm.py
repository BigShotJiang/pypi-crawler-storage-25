from __future__ import annotations

import contextlib
import inspect
import os
import signal
import threading
import time
import warnings
from typing import Any, Dict, Iterable, List, Optional, Tuple

import numpy as np
import optuna
import pandas as pd
from sklearn.exceptions import ConvergenceWarning
from sklearn.metrics import log_loss

try:
    import tabmat as tm  # type: ignore
    from glum import GeneralizedLinearRegressor, TweedieDistribution  # type: ignore

    _GLM_AVAILABLE = True
    _GLM_IMPORT_ERROR: Optional[BaseException] = None
except Exception as _glm_import_err:  # pragma: no cover - exercised in env w/o or incompatible glum
    tm = None  # type: ignore
    GeneralizedLinearRegressor = None  # type: ignore
    TweedieDistribution = None  # type: ignore
    _GLM_AVAILABLE = False
    _GLM_IMPORT_ERROR = _glm_import_err

from ins_pricing.modelling.bayesopt.trainers.trainer_base import TrainerBase
from ins_pricing.utils import EPS, get_logger, log_print
from ins_pricing.utils.losses import regression_loss

_logger = get_logger("ins_pricing.trainer.glm")


def _log(*args, **kwargs) -> None:
    log_print(_logger, *args, **kwargs)


def _require_glm_available() -> None:
    """Raise a clear error if glum/tabmat are not installed.

    The module stays importable even without these optional deps (so smoke
    tests and non-GLM workflows aren't blocked), but instantiating or using
    GLMTrainer demands them.
    """
    if not _GLM_AVAILABLE:
        raise ImportError(
            "GLMTrainer requires the optional 'glum' and 'tabmat' packages. "
            "Install with: pip install 'ins_pricing[bayesopt]'  "
            f"(original error: {_GLM_IMPORT_ERROR!r})"
        )


_GLM_DTYPE = np.float64
_GLM_MISSING_CATEGORY_BASE = "__INS_PRICING_MISSING__"
_GLM_UNKNOWN_CATEGORY_BASE = "__INS_PRICING_UNKNOWN__"
_GLM_DEFAULT_TUNING_MAX_ITER = 200
_GLM_DEFAULT_FINAL_MAX_ITER = 300
_GLM_DEFAULT_TUNING_FIT_TIMEOUT_SECONDS = 300.0
_GLM_DEFAULT_FINAL_FIT_TIMEOUT_SECONDS = 900.0
_GLM_NONCONVERGENCE_KEYWORDS = (
    "failed to converge",
    "convergence",
    "max_iter",
    "maximum number of iterations",
)
_GLM_TABMAT_PATCH_LOGGED = False


class _GLMFitTimeoutError(TimeoutError):
    """Raised when a GLM fit exceeds the configured wall-clock guard."""


@contextlib.contextmanager
def _glm_fit_deadline(seconds: Optional[float]):
    """Best-effort wall-clock timeout for GLM fit on Unix main threads."""
    if seconds is None or seconds <= 0:
        yield
        return
    if threading.current_thread() is not threading.main_thread():
        yield
        return
    if not hasattr(signal, "setitimer") or not hasattr(signal, "SIGALRM"):
        yield
        return

    previous_handler = signal.getsignal(signal.SIGALRM)
    try:
        previous_timer = signal.setitimer(signal.ITIMER_REAL, 0.0)
    except (AttributeError, OSError, ValueError):
        yield
        return

    def _raise_timeout(_signum, _frame):
        raise _GLMFitTimeoutError(
            f"GLM fit exceeded timeout_seconds={float(seconds):.1f}"
        )

    signal.signal(signal.SIGALRM, _raise_timeout)
    signal.setitimer(signal.ITIMER_REAL, float(seconds))
    try:
        yield
    finally:
        signal.setitimer(signal.ITIMER_REAL, 0.0)
        signal.signal(signal.SIGALRM, previous_handler)
        if previous_timer[0] > 0:
            signal.setitimer(signal.ITIMER_REAL, previous_timer[0], previous_timer[1])


# --- Runtime defense: force every tabmat constructor to float64 ----------------
#
# tabmat's Cython kernels (e.g. csc_rmatvec_unrestricted) are fused-type
# specialized and dispatched on the matrix data dtype. If any code path inside
# glum/tabmat builds a sparse/dense sub-matrix with float32 data while
# sample_weight stays float64, standardize() crashes with
# `Buffer dtype mismatch, expected 'float' but got 'double'`. To make this
# *impossible* regardless of which code path is taken, we wrap the public
# tabmat factories at import time and force `dtype=float64` on every call.
# This runs the moment trainer_glm is imported, before any GLM is fit.

def _patch_tabmat_force_f64() -> None:
    """Force every tabmat matrix to use float64 data where Python hooks allow it.

    Some tabmat matrix classes are Cython extension types whose constructor
    arguments are consumed before Python-level __init__. In tabmat 3.1.14 those
    classes expose object.__init__; wrapping that method breaks normal
    construction. Factory and matvec hooks are still safe and cover the known
    mixed float32/float64 failure path.
    """
    if not _GLM_AVAILABLE or tm is None:
        return
    target_dtype = _GLM_DTYPE

    # --- 1. factory functions: always pass dtype=float64 ---------------------
    def _wrap_factory(original):
        if original is None or getattr(original, "_ins_pricing_f64_patched", False):
            return original

        def wrapped(*args, **kwargs):
            kwargs.setdefault("dtype", target_dtype)
            kwargs["dtype"] = target_dtype
            return original(*args, **kwargs)

        wrapped._ins_pricing_f64_patched = True
        wrapped.__wrapped__ = original
        wrapped.__name__ = getattr(original, "__name__", "tabmat_factory")
        return wrapped

    for name in ("from_pandas", "from_df", "from_csc", "from_csr"):
        fn = getattr(tm, name, None)
        if fn is not None and not getattr(fn, "_ins_pricing_f64_patched", False):
            setattr(tm, name, _wrap_factory(fn))

    # --- 2. matrix classes: recast .data only when __init__ is real Python ---
    def _wrap_init(cls):
        if cls is None:
            return
        orig_init = cls.__init__
        if orig_init is object.__init__ or (
            getattr(orig_init, "__name__", "") == "__init__"
            and getattr(orig_init, "__objclass__", None) is object
        ):
            return
        if getattr(orig_init, "_ins_pricing_f64_patched", False):
            return

        def patched_init(self, *args, **kwargs):
            orig_init(self, *args, **kwargs)
            data = getattr(self, "data", None)
            if isinstance(data, np.ndarray) and data.dtype != target_dtype:
                try:
                    self.data = np.ascontiguousarray(
                        data.astype(target_dtype, copy=False)
                    )
                except Exception:
                    pass

        patched_init._ins_pricing_f64_patched = True
        cls.__init__ = patched_init

    for cls_name in ("SparseMatrix", "DenseMatrix", "StandardizedMatrix"):
        _wrap_init(getattr(tm, cls_name, None))

    # --- 3. last-line defense: align dtypes at the matvec dispatch site -----
    sm_cls = getattr(tm, "SparseMatrix", None)
    if sm_cls is not None and not getattr(
        getattr(sm_cls, "_matvec_helper", None),
        "_ins_pricing_f64_patched",
        False,
    ):
        orig_helper = sm_cls._matvec_helper

        def patched_helper(self, vec, rows, cols, out, transpose):
            data = getattr(self, "data", None)
            if isinstance(data, np.ndarray) and data.dtype != target_dtype:
                self.data = np.ascontiguousarray(
                    data.astype(target_dtype, copy=False)
                )
            if isinstance(vec, np.ndarray) and vec.dtype != target_dtype:
                vec = np.ascontiguousarray(vec.astype(target_dtype, copy=False))
            if isinstance(out, np.ndarray) and out.dtype != target_dtype:
                out = np.zeros(out.shape, dtype=target_dtype)
            return orig_helper(self, vec, rows, cols, out, transpose)

        patched_helper._ins_pricing_f64_patched = True
        sm_cls._matvec_helper = patched_helper


def _ensure_tabmat_force_f64() -> None:
    """Patch tabmat only when the GLM trainer is actually used."""
    global _GLM_TABMAT_PATCH_LOGGED
    _patch_tabmat_force_f64()
    if not _GLM_AVAILABLE or tm is None or _GLM_TABMAT_PATCH_LOGGED:
        return
    _GLM_TABMAT_PATCH_LOGGED = True
    _log(
        f"[GLM] tabmat float64 patch active "
        f"(tabmat={getattr(tm, '__version__', 'n/a')}, "
        f"patched={[n for n in ('from_pandas','from_df','from_csc','from_csr') if getattr(getattr(tm, n, None), '_ins_pricing_f64_patched', False)]})",
        flush=True,
    )
# -----------------------------------------------------------------------------


def _as_f64_array(a: Any) -> Optional[np.ndarray]:
    if a is None:
        return None
    return np.ascontiguousarray(np.asarray(a, dtype=_GLM_DTYPE))


def _to_dense_f64_matrix(X: Any) -> tm.DenseMatrix:
    """Pre-convert X into a tabmat DenseMatrix with explicit float64 data.

    glum auto-converts DataFrames via tabmat.from_pandas, which can build the
    sparse sub-matrix with float32 data while sample_weight stays float64;
    tabmat's Cython kernel csc_rmatvec_unrestricted is dtype-specialized and
    raises `Buffer dtype mismatch, expected 'float' but got 'double'` in that
    case. By handing glum a tabmat object we built ourselves with float64
    contiguous data, we bypass the sparse-default path entirely and force the
    double specialization on every kernel call (matvec, transpose_matvec,
    standardize, _get_col_means, ...).

    For 40-ish already one-hot-encoded numeric columns the memory cost of
    Dense vs Split (sparse+dense) is small and never triggers the dtype bug.
    """
    if isinstance(X, tm.MatrixBase):
        return X
    if isinstance(X, pd.DataFrame):
        arr = X.to_numpy(dtype=_GLM_DTYPE, copy=False)
    else:
        arr = np.asarray(X, dtype=_GLM_DTYPE)
    arr = np.ascontiguousarray(arr)
    return tm.DenseMatrix(arr)


class GLMTrainer(TrainerBase):
    _GLM_PARAM_KEYS = {"alpha", "l1_ratio", "tweedie_power"}

    def __init__(self, context: "BayesOptModel") -> None:
        _require_glm_available()
        _ensure_tabmat_force_f64()
        super().__init__(context, 'GLM', 'GLM')
        self.model = None
        self._raw_fallback_logged = False
        self._raw_categorical_specs: Dict[str, Dict[str, Any]] = {}

    def _sanitize_best_params(
        self,
        params: Dict[str, Any],
        *,
        context: str = "best_params",
    ) -> Dict[str, Any]:
        return self._sanitize_with_allowlist(
            params,
            allowed_keys=set(self._GLM_PARAM_KEYS),
            context=f"{context} (GLM params)",
        )

    def _resolve_tuned_params(self) -> Dict[str, Any]:
        params = self._sanitize_with_allowlist(
            self.best_params,
            allowed_keys=set(self._GLM_PARAM_KEYS),
            context="GLM tuned params",
        )
        if "alpha" not in params or "l1_ratio" not in params:
            raise RuntimeError(
                "GLM best_params must contain both 'alpha' and 'l1_ratio' after filtering."
            )
        return params

    def _config_value(self, name: str, default: Any) -> Any:
        config = getattr(self.ctx, "config", None)
        if config is not None and hasattr(config, name):
            value = getattr(config, name)
            if value is not None:
                return value
        if hasattr(self.ctx, name):
            value = getattr(self.ctx, name)
            if value is not None:
                return value
        return default

    def _config_int(
        self,
        name: str,
        *,
        env_name: str,
        default: int,
        minimum: int = 1,
    ) -> int:
        raw = os.environ.get(env_name)
        if raw is None:
            raw = self._config_value(name, default)
        try:
            value = int(raw)
        except (TypeError, ValueError):
            _log(
                f"[GLM] Invalid {name}={raw!r}; using default {default}.",
                flush=True,
            )
            return int(default)
        if value < minimum:
            _log(
                f"[GLM] Invalid {name}={raw!r}; using default {default}.",
                flush=True,
            )
            return int(default)
        return value

    def _config_timeout(
        self,
        name: str,
        *,
        env_name: str,
        default: Optional[float],
    ) -> Optional[float]:
        raw = os.environ.get(env_name)
        if raw is None:
            raw = self._config_value(name, default)
        if raw is None:
            return None
        try:
            value = float(raw)
        except (TypeError, ValueError):
            _log(
                f"[GLM] Invalid {name}={raw!r}; using default {default}.",
                flush=True,
            )
            return default
        if value <= 0:
            return None
        return value

    def _tuning_max_iter(self) -> int:
        return self._config_int(
            "glm_tuning_max_iter",
            env_name="BAYESOPT_GLM_TUNING_MAX_ITER",
            default=_GLM_DEFAULT_TUNING_MAX_ITER,
        )

    def _final_max_iter(self) -> int:
        return self._config_int(
            "glm_final_max_iter",
            env_name="BAYESOPT_GLM_FINAL_MAX_ITER",
            default=_GLM_DEFAULT_FINAL_MAX_ITER,
        )

    def _tuning_fit_timeout_seconds(self) -> Optional[float]:
        return self._config_timeout(
            "glm_tuning_fit_timeout_seconds",
            env_name="BAYESOPT_GLM_TUNING_FIT_TIMEOUT_SECONDS",
            default=_GLM_DEFAULT_TUNING_FIT_TIMEOUT_SECONDS,
        )

    def _final_fit_timeout_seconds(self) -> Optional[float]:
        return self._config_timeout(
            "glm_final_fit_timeout_seconds",
            env_name="BAYESOPT_GLM_FINAL_FIT_TIMEOUT_SECONDS",
            default=_GLM_DEFAULT_FINAL_FIT_TIMEOUT_SECONDS,
        )

    @staticmethod
    def _warning_indicates_nonconvergence(warning_obj: warnings.WarningMessage) -> bool:
        if issubclass(warning_obj.category, ConvergenceWarning):
            return True
        text = str(warning_obj.message).lower()
        return any(keyword in text for keyword in _GLM_NONCONVERGENCE_KEYWORDS)

    @staticmethod
    def _max_numeric(values: Any) -> Optional[float]:
        try:
            arr = np.asarray(values, dtype=float)
        except (TypeError, ValueError):
            return None
        if arr.size == 0:
            return None
        arr = arr[np.isfinite(arr)]
        if arr.size == 0:
            return None
        return float(np.nanmax(arr))

    def _iteration_counts(self, model: Any) -> Iterable[Tuple[str, float]]:
        for attr in ("n_iter_", "n_iter", "_n_iter"):
            if not hasattr(model, attr):
                continue
            value = self._max_numeric(getattr(model, attr))
            if value is not None:
                yield attr, value

    def _fit_reached_iteration_limit(self, model: Any, max_iter: int) -> Optional[str]:
        for attr, value in self._iteration_counts(model):
            if value >= int(max_iter):
                return f"{attr}={value:g}"
        return None

    @staticmethod
    def _fit_has_nonfinite_params(model: Any) -> bool:
        for attr in ("coef_", "intercept_"):
            if not hasattr(model, attr):
                continue
            try:
                arr = np.asarray(getattr(model, attr), dtype=float)
            except (TypeError, ValueError):
                continue
            if arr.size and not np.all(np.isfinite(arr)):
                return True
        return False

    def _interrupt_fit(
        self,
        message: str,
        *,
        prune_on_guard: bool,
    ) -> None:
        _log(f"[GLM] {message}", flush=True)
        if prune_on_guard:
            raise optuna.TrialPruned(message)
        raise RuntimeError(message)

    def _fit_with_guard(
        self,
        model: GeneralizedLinearRegressor,
        X_train: Any,
        y_train: Optional[np.ndarray],
        sample_weight: Optional[np.ndarray],
        *,
        phase: str,
        max_iter: int,
        timeout_seconds: Optional[float],
        prune_on_guard: bool,
    ) -> GeneralizedLinearRegressor:
        start = time.monotonic()
        guard_action = (
            "interrupting current tuning sample"
            if prune_on_guard
            else "aborting GLM fit"
        )
        try:
            with warnings.catch_warnings(record=True) as caught:
                warnings.simplefilter("always")
                with _glm_fit_deadline(timeout_seconds):
                    model.fit(X_train, y_train, sample_weight=sample_weight)
        except _GLMFitTimeoutError as exc:
            elapsed = time.monotonic() - start
            self._interrupt_fit(
                f"{phase} fit exceeded timeout after {elapsed:.1f}s; "
                f"{guard_action}.",
                prune_on_guard=prune_on_guard,
            )
            raise AssertionError("unreachable") from exc

        elapsed = time.monotonic() - start
        for warning_obj in caught:
            if self._warning_indicates_nonconvergence(warning_obj):
                self._interrupt_fit(
                    f"{phase} fit did not converge after {elapsed:.1f}s "
                    f"(max_iter={max_iter}); {guard_action}. "
                    f"warning={warning_obj.message}",
                    prune_on_guard=prune_on_guard,
                )

        iteration_info = self._fit_reached_iteration_limit(model, max_iter)
        if iteration_info is not None:
            self._interrupt_fit(
                f"{phase} fit reached iteration limit ({iteration_info}, "
                f"max_iter={max_iter}); {guard_action}.",
                prune_on_guard=prune_on_guard,
            )

        if self._fit_has_nonfinite_params(model):
            self._interrupt_fit(
                f"{phase} fit produced non-finite coefficients; "
                f"{guard_action}.",
                prune_on_guard=prune_on_guard,
            )

        return model

    def _filter_search_space_for_distribution(
        self,
        search_space: Optional[Dict[str, Any]],
    ) -> Dict[str, Any]:
        filtered = self._sanitize_with_allowlist(
            search_space,
            allowed_keys=set(self._GLM_PARAM_KEYS),
            context="GLM search_space",
        )
        if self.ctx.task_type != 'regression' or getattr(self.ctx, "loss_name", "tweedie") != "tweedie":
            dropped = filtered.pop("tweedie_power", None)
            if dropped is not None:
                _log(
                    "[GLM] Ignoring glm_search_space.tweedie_power because "
                    "the configured task/loss does not use Tweedie variance power.",
                    flush=True,
                )
        return filtered

    def _resolve_family(
        self, tweedie_power: Optional[float] = None
    ) -> Tuple[str, Optional[float]]:
        """Return (family_name, power) for glum.GeneralizedLinearRegressor."""
        if self.ctx.task_type == 'classification':
            return 'binomial', None
        loss_name = getattr(self.ctx, "loss_name", "tweedie")
        if loss_name == "poisson":
            return 'poisson', None
        if loss_name == "gamma":
            return 'gamma', None
        if loss_name in {"mse", "mae"}:
            return 'normal', None
        power = tweedie_power if tweedie_power is not None else 1.5
        return 'tweedie', float(power)

    def _metric_power(self, family: str, tweedie_power: Optional[float]) -> float:
        if family == 'poisson':
            return 1.0
        if family == 'gamma':
            return 2.0
        if family == 'tweedie':
            return tweedie_power if tweedie_power is not None else 1.5
        return 1.5

    def _uses_oht_design(self) -> bool:
        return getattr(self.ctx, "train_oht_scl_data", None) is not None

    def _feature_names(self) -> List[str]:
        names = list(getattr(self.ctx, "var_nmes", []) or [])
        if not names:
            names = list(getattr(self.ctx, "factor_nmes", []) or [])
        return names

    @staticmethod
    def _coerce_numeric_series(series: pd.Series) -> pd.Series:
        dtype = series.dtype
        if isinstance(dtype, pd.SparseDtype):
            fill_value = dtype.fill_value
            if pd.isna(fill_value):
                fill_value = 0.0
            return series.astype(pd.SparseDtype(_GLM_DTYPE, fill_value), copy=False)
        return pd.to_numeric(series, errors="coerce").astype(_GLM_DTYPE, copy=False)

    @staticmethod
    def _contains_category(values: List[Any], target: Any) -> bool:
        for value in values:
            try:
                if value == target:
                    return True
            except Exception:
                continue
        return False

    @classmethod
    def _unique_reserved_category(cls, observed: List[Any], base: str) -> str:
        candidate = base
        suffix = 1
        while cls._contains_category(observed, candidate):
            candidate = f"{base}_{suffix}"
            suffix += 1
        return candidate

    @classmethod
    def _non_missing_categories(cls, series: pd.Series) -> List[Any]:
        values = series.astype("object")
        observed: List[Any] = []
        for value in pd.unique(values):
            try:
                is_missing = bool(pd.isna(value))
            except Exception:
                is_missing = False
            if is_missing:
                continue
            if not cls._contains_category(observed, value):
                observed.append(value)
        return observed

    @classmethod
    def _build_categorical_spec(cls, series: pd.Series) -> Dict[str, Any]:
        observed = cls._non_missing_categories(series)
        missing_value = cls._unique_reserved_category(
            observed, _GLM_MISSING_CATEGORY_BASE
        )
        unknown_value = cls._unique_reserved_category(
            observed + [missing_value], _GLM_UNKNOWN_CATEGORY_BASE
        )
        categories = list(observed)
        for sentinel in (missing_value, unknown_value):
            if not cls._contains_category(categories, sentinel):
                categories.append(sentinel)
        return {
            "categories": categories,
            "missing_value": missing_value,
            "unknown_value": unknown_value,
        }

    def _raw_categorical_columns(self) -> List[str]:
        raw_categoricals = set(getattr(self.ctx, "cate_list", []) or [])
        return [
            col for col in self._feature_names()
            if col in raw_categoricals
        ]

    def _build_raw_categorical_specs(
        self,
        data: pd.DataFrame,
    ) -> Dict[str, Dict[str, Any]]:
        if self._uses_oht_design():
            return {}
        specs: Dict[str, Dict[str, Any]] = {}
        for col in self._raw_categorical_columns():
            if col in data.columns:
                specs[col] = self._build_categorical_spec(data[col])
        return specs

    @classmethod
    def _coerce_categorical_series(
        cls,
        series: pd.Series,
        *,
        spec: Optional[Dict[str, Any]] = None,
    ) -> pd.Series:
        if spec is None:
            spec = cls._build_categorical_spec(series)

        categories = list(spec.get("categories") or [])
        missing_value = spec.get("missing_value", _GLM_MISSING_CATEGORY_BASE)
        unknown_value = spec.get("unknown_value", _GLM_UNKNOWN_CATEGORY_BASE)
        for sentinel in (missing_value, unknown_value):
            if not cls._contains_category(categories, sentinel):
                categories.append(sentinel)

        values = series.astype("object").where(series.notna(), missing_value)
        mapped: List[Any] = []
        for value in values.to_numpy(dtype=object, copy=False):
            if cls._contains_category(categories, value):
                mapped.append(value)
            else:
                mapped.append(unknown_value)
        return pd.Series(
            pd.Categorical(mapped, categories=categories),
            index=series.index,
            name=series.name,
        )

    def _prepare_design(
        self,
        data: pd.DataFrame,
        *,
        category_specs: Optional[Dict[str, Dict[str, Any]]] = None,
    ) -> pd.DataFrame:
        design = data[self._feature_names()].copy()
        raw_categoricals = set(getattr(self.ctx, "cate_list", []) or [])
        use_raw_categoricals = not self._uses_oht_design()
        for col in design.columns:
            if use_raw_categoricals and col in raw_categoricals:
                spec = (category_specs or {}).get(col)
                design[col] = self._coerce_categorical_series(
                    design[col],
                    spec=spec,
                )
            else:
                design[col] = self._coerce_numeric_series(design[col])
        return design

    def _to_model_input(self, design: pd.DataFrame) -> Any:
        if self._uses_oht_design():
            return _to_dense_f64_matrix(design)
        return design

    def _cv_source_data(self) -> pd.DataFrame:
        data = (
            self.ctx.train_oht_data
            if self.ctx.train_oht_data is not None
            else self.ctx.train_oht_scl_data
        )
        if data is not None:
            return data
        if not self._raw_fallback_logged:
            _log(
                "[GLM] build_oht=false fallback: using raw numeric/categorical "
                "features via glum/tabmat.",
                flush=True,
            )
            self._raw_fallback_logged = True
        return self.ctx.train_data

    def _final_source_data(self, *, train: bool) -> pd.DataFrame:
        if self.ctx.train_oht_scl_data is not None:
            return self.ctx.train_oht_scl_data if train else self.ctx.test_oht_scl_data
        if not self._raw_fallback_logged:
            _log(
                "[GLM] build_oht=false fallback: using raw numeric/categorical "
                "features via glum/tabmat.",
                flush=True,
            )
            self._raw_fallback_logged = True
        return self.ctx.train_data if train else self.ctx.test_data

    def _build_estimator(
        self,
        *,
        alpha: float,
        l1_ratio: float,
        family: str,
        power: Optional[float],
        max_iter: int,
    ) -> GeneralizedLinearRegressor:
        # glum 2.7 dropped the standalone `power` kwarg: Tweedie's variance
        # power must be carried by a TweedieDistribution object passed via
        # `family=`. For other families a string is still accepted.
        family_arg: Any
        if family == 'tweedie':
            family_arg = TweedieDistribution(power=float(power) if power is not None else 1.5)
        else:
            family_arg = family
        kwargs: Dict[str, Any] = {
            "alpha": float(alpha),
            "l1_ratio": float(l1_ratio),
            "family": family_arg,
            "fit_intercept": True,
            "max_iter": int(max_iter),
        }
        try:
            supported = inspect.signature(GeneralizedLinearRegressor).parameters
        except (TypeError, ValueError):
            supported = {}
        optional_kwargs = {
            "drop_first": True,
            "cat_missing_method": "convert",
            "cat_missing_name": "<NA>",
        }
        kwargs.update(
            {
                key: value
                for key, value in optional_kwargs.items()
                if key in supported
            }
        )
        return GeneralizedLinearRegressor(**kwargs)

    def cross_val(self, trial: optuna.trial.Trial) -> float:
        search_space = self._filter_search_space_for_distribution(
            self._get_search_space_config("glm_search_space")
        )
        param_space = {
            "alpha": lambda t: self._sample_param(
                t,
                model_key="glm",
                param_name="alpha",
                default_sampler=lambda _t: _t.suggest_float('alpha', 1e-6, 1e2, log=True),
                search_space=search_space,
            ),
            "l1_ratio": lambda t: self._sample_param(
                t,
                model_key="glm",
                param_name="l1_ratio",
                default_sampler=lambda _t: _t.suggest_float('l1_ratio', 0.0, 1.0),
                search_space=search_space,
            ),
        }
        loss_name = getattr(self.ctx, "loss_name", "tweedie")
        if self.ctx.task_type == 'regression' and loss_name == 'tweedie':
            param_space["tweedie_power"] = lambda t: self._sample_param(
                t,
                model_key="glm",
                param_name="tweedie_power",
                default_sampler=lambda _t: _t.suggest_float('tweedie_power', 1.0, 2.0),
                search_space=search_space,
            )

        def data_provider():
            data = self._cv_source_data()
            return data[self._feature_names()], data[self.ctx.resp_nme], data[self.ctx.weight_nme]

        def preprocess_fn(X_train, X_val):
            if self._uses_oht_design():
                X_train, X_val, _ = self._standardize_fold(
                    X_train, X_val, self.ctx.num_features)
                return self._prepare_design(X_train), self._prepare_design(X_val)
            category_specs = self._build_raw_categorical_specs(X_train)
            return (
                self._prepare_design(X_train, category_specs=category_specs),
                self._prepare_design(X_val, category_specs=category_specs),
            )

        metric_ctx: Dict[str, Any] = {}
        tuning_max_iter = self._tuning_max_iter()
        tuning_timeout = self._tuning_fit_timeout_seconds()

        def model_builder(params):
            family, power = self._resolve_family(params.get("tweedie_power"))
            metric_ctx["family"] = family
            metric_ctx["tweedie_power"] = params.get("tweedie_power")
            return self._build_estimator(
                alpha=params["alpha"],
                l1_ratio=params["l1_ratio"],
                family=family,
                power=power,
                max_iter=tuning_max_iter,
            )

        def fit_predict(model, X_train, y_train, w_train, X_val, y_val, w_val, _trial):
            X_train_model = self._to_model_input(X_train)
            X_val_model = self._to_model_input(X_val)
            y_train_f = _as_f64_array(y_train)
            w_train_f = _as_f64_array(w_train)
            self._fit_with_guard(
                model,
                X_train_model,
                y_train_f,
                w_train_f,
                phase="CV",
                max_iter=tuning_max_iter,
                timeout_seconds=tuning_timeout,
                prune_on_guard=True,
            )
            return model.predict(X_val_model)

        def metric_fn(y_true, y_pred, weight):
            if self.ctx.task_type == 'classification':
                y_pred_clipped = np.clip(y_pred, EPS, 1 - EPS)
                return log_loss(y_true, y_pred_clipped, sample_weight=weight)
            return regression_loss(
                y_true,
                y_pred,
                weight,
                loss_name=loss_name,
                tweedie_power=metric_ctx.get("tweedie_power"),
            )

        return self.cross_val_generic(
            trial=trial,
            hyperparameter_space=param_space,
            data_provider=data_provider,
            model_builder=model_builder,
            metric_fn=metric_fn,
            preprocess_fn=preprocess_fn,
            fit_predict_fn=fit_predict
        )

    def train(self) -> None:
        if not self.best_params:
            raise RuntimeError("Run tune() first to obtain best GLM parameters.")
        params = self._resolve_tuned_params()
        tweedie_power = params.get('tweedie_power')
        family, power = self._resolve_family(tweedie_power)

        data = self._final_source_data(train=True)
        self._raw_categorical_specs = self._build_raw_categorical_specs(data)
        X_train = self._to_model_input(
            self._prepare_design(
                data,
                category_specs=self._raw_categorical_specs,
            )
        )
        y_train = _as_f64_array(data[self.ctx.resp_nme])
        w_train = _as_f64_array(data[self.ctx.weight_nme])
        final_max_iter = self._final_max_iter()
        final_timeout = self._final_fit_timeout_seconds()

        model = self._build_estimator(
            alpha=params['alpha'],
            l1_ratio=params['l1_ratio'],
            family=family,
            power=power,
            max_iter=final_max_iter,
        )
        self._fit_with_guard(
            model,
            X_train,
            y_train,
            w_train,
            phase="final",
            max_iter=final_max_iter,
            timeout_seconds=final_timeout,
            prune_on_guard=False,
        )
        self.model = model
        self.best_params = params

        self.ctx.glm_best = self.model
        self.ctx.model_label += [self.label]
        self._predict_and_cache(
            self.model,
            'glm',
            design_fn=lambda train: self._to_model_input(
                self._prepare_design(
                    self._final_source_data(train=train),
                    category_specs=self._raw_categorical_specs,
                )
            ),
        )

    def ensemble_predict(self, k: int) -> None:
        if not self.best_params:
            raise RuntimeError("Run tune() first to obtain best GLM parameters.")
        params = self._resolve_tuned_params()
        k = max(2, int(k))
        data = self._final_source_data(train=True)
        category_specs = self._build_raw_categorical_specs(data)
        X_all_df = self._prepare_design(data, category_specs=category_specs)
        y_all = _as_f64_array(data[self.ctx.resp_nme])
        w_all = _as_f64_array(data[self.ctx.weight_nme])
        test_data = self._final_source_data(train=False)
        X_test_df = self._prepare_design(
            test_data,
            category_specs=category_specs,
        )
        X_all_model = self._to_model_input(X_all_df)
        X_test_model = self._to_model_input(X_test_df)

        n_samples = len(X_all_df)
        tweedie_power = params.get('tweedie_power')
        family, power = self._resolve_family(tweedie_power)

        split_iter, _ = self._resolve_ensemble_splits(X_all_df, k=k)
        if split_iter is None:
            _log(
                f"[GLM Ensemble] unable to build CV split (n_samples={n_samples}); skip ensemble.",
                flush=True,
            )
            return
        preds_train_sum = np.zeros(n_samples, dtype=_GLM_DTYPE)
        preds_test_sum = np.zeros(len(X_test_df), dtype=_GLM_DTYPE)

        split_count = 0
        final_max_iter = self._final_max_iter()
        final_timeout = self._final_fit_timeout_seconds()
        for train_idx, _val_idx in split_iter:
            X_train_model = self._to_model_input(X_all_df.iloc[train_idx])
            y_train = y_all[train_idx]
            w_train = w_all[train_idx]

            model = self._build_estimator(
                alpha=params['alpha'],
                l1_ratio=params['l1_ratio'],
                family=family,
                power=power,
                max_iter=final_max_iter,
            )
            self._fit_with_guard(
                model,
                X_train_model,
                y_train,
                w_train,
                phase="ensemble",
                max_iter=final_max_iter,
                timeout_seconds=final_timeout,
                prune_on_guard=False,
            )
            pred_train = model.predict(X_all_model)
            pred_test = model.predict(X_test_model)
            preds_train_sum += np.asarray(pred_train, dtype=_GLM_DTYPE)
            preds_test_sum += np.asarray(pred_test, dtype=_GLM_DTYPE)
            split_count += 1

        if split_count < 1:
            _log(
                f"[GLM Ensemble] no CV splits generated; skip ensemble.",
                flush=True,
            )
            return
        preds_train = preds_train_sum / float(split_count)
        preds_test = preds_test_sum / float(split_count)
        self._cache_predictions("glm", preds_train, preds_test)
