"""BayesOpt subpackage (split from monolithic BayesOpt.py)."""

from __future__ import annotations

from importlib import import_module

from ins_pricing.utils.torch_compat import disable_torch_dynamo_if_requested

disable_torch_dynamo_if_requested()

from ins_pricing.modelling.bayesopt.config_runtime import OutputManager, VersionManager
from ins_pricing.modelling.bayesopt.config_schema import BayesOptConfig
from ins_pricing.modelling.bayesopt.dataset_preprocessor import DatasetPreprocessor
from ins_pricing.modelling.bayesopt.core import BayesOptModel
from ins_pricing.modelling.bayesopt.models import (
    FeatureTokenizer,
    FTTransformerCore,
    FTTransformerSklearn,
    GraphNeuralNetSklearn,
    MaskedTabularDataset,
    ResBlock,
    ResNetSequential,
    ResNetSklearn,
    ScaledTransformerEncoderLayer,
    SimpleGraphLayer,
    SimpleGNN,
    TabularDataset,
)

_TRAINER_EXPORTS = {
    "FTTrainer": "ins_pricing.modelling.bayesopt.trainers.trainer_ft",
    "GLMTrainer": "ins_pricing.modelling.bayesopt.trainers.trainer_glm",
    "GNNTrainer": "ins_pricing.modelling.bayesopt.trainers.trainer_gnn",
    "ResNetTrainer": "ins_pricing.modelling.bayesopt.trainers.trainer_resn",
    "TrainerBase": "ins_pricing.modelling.bayesopt.trainers.trainer_base",
    "XGBTrainer": "ins_pricing.modelling.bayesopt.trainers.trainer_xgb",
    "_xgb_cuda_available": "ins_pricing.modelling.bayesopt.trainers.trainer_xgb",
}


def __getattr__(name: str):
    target = _TRAINER_EXPORTS.get(name)
    if target is None:
        raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
    module = import_module(target)
    value = getattr(module, name)
    globals()[name] = value
    return value


__all__ = [
    "BayesOptConfig",
    "DatasetPreprocessor",
    "OutputManager",
    "VersionManager",
    "BayesOptModel",
    "FeatureTokenizer",
    "FTTransformerCore",
    "FTTransformerSklearn",
    "GraphNeuralNetSklearn",
    "MaskedTabularDataset",
    "ResBlock",
    "ResNetSequential",
    "ResNetSklearn",
    "ScaledTransformerEncoderLayer",
    "SimpleGraphLayer",
    "SimpleGNN",
    "TabularDataset",
    "FTTrainer",
    "GLMTrainer",
    "GNNTrainer",
    "ResNetTrainer",
    "TrainerBase",
    "XGBTrainer",
    "_xgb_cuda_available",
]
