from __future__ import annotations

import numpy as np
import pandas as pd
import pytest


def _sample_data(n_rows: int = 20) -> pd.DataFrame:
    rng = np.random.default_rng(42)
    return pd.DataFrame(
        {
            "feature_num": rng.normal(size=n_rows),
            "feature_cat": rng.choice(["A", "B", "C"], size=n_rows),
            "target": rng.random(size=n_rows),
            "weight": np.ones(n_rows),
        }
    )


def test_bayesopt_model_accepts_config_api():
    pytest.importorskip("torch")
    pytest.importorskip("sklearn")

    from ins_pricing.modelling.bayesopt import BayesOptConfig, BayesOptModel

    data = _sample_data()
    config = BayesOptConfig(
        model_nme="test_model",
        resp_nme="target",
        weight_nme="weight",
        factor_nmes=["feature_num", "feature_cat"],
        task_type="regression",
        epochs=3,
        use_gpu=False,
        rand_seed=42,
    )

    model = BayesOptModel(data, data.copy(), config=config)

    assert model.model_nme == "test_model"
    assert model.resp_nme == "target"
    assert model.weight_nme == "weight"
    assert model.task_type == "regression"
    assert model.epochs == 3
    assert model.rand_seed == 42
    assert isinstance(model.config, BayesOptConfig)
    assert model.config is not config


def test_bayesopt_model_lazily_instantiates_trainers():
    pytest.importorskip("torch")
    pytest.importorskip("sklearn")

    from ins_pricing.modelling.bayesopt import BayesOptConfig, BayesOptModel

    data = _sample_data()
    config = BayesOptConfig(
        model_nme="test_model",
        resp_nme="target",
        weight_nme="weight",
        factor_nmes=["feature_num", "feature_cat"],
        task_type="regression",
        use_gpu=False,
        rand_seed=42,
    )

    model = BayesOptModel(data, data.copy(), config=config)

    instances = getattr(model.trainers, "_instances", {})
    assert instances == {}
    assert "glm" in model.trainers
    assert getattr(model.trainers, "_instances", {}) == {}
    _ = model.trainers["xgb"]
    assert set(getattr(model.trainers, "_instances", {})) == {"xgb"}


def test_bayesopt_model_rejects_invalid_config_type():
    pytest.importorskip("torch")
    pytest.importorskip("sklearn")

    from ins_pricing.modelling.bayesopt import BayesOptModel

    data = _sample_data()

    with pytest.raises(TypeError, match="config must be a BayesOptConfig instance"):
        BayesOptModel(data, data.copy(), config={"model_nme": "bad"})
