from __future__ import annotations

import types

import pandas as pd
import pytest

from ins_pricing.modelling.bayesopt.trainers.cv_utils import CVStrategyResolver


def test_cv_strategy_resolver_uses_stratified_shuffle_split() -> None:
    X = pd.DataFrame({"x": range(20)})
    y = pd.Series([0] * 10 + [1] * 10, index=X.index)
    cfg = types.SimpleNamespace(cv_strategy="stratified")

    resolver = CVStrategyResolver(cfg, X, rand_seed=13)
    split_iter, actual_splits = resolver.create_cv_splitter(
        X, y, n_splits=3, val_ratio=0.2
    )
    splits = list(split_iter)

    assert actual_splits == 3
    assert len(splits) == 3
    for _train_idx, val_idx in splits:
        assert y.iloc[val_idx].value_counts().to_dict() == {0: 2, 1: 2}


def test_cv_strategy_resolver_rejects_unknown_strategy() -> None:
    X = pd.DataFrame({"x": range(4)})
    cfg = types.SimpleNamespace(cv_strategy="typo")

    with pytest.raises(ValueError, match="Unsupported cv_strategy"):
        CVStrategyResolver(cfg, X, rand_seed=13)
