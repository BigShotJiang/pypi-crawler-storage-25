import warnings
from types import SimpleNamespace

import pytest

np = pytest.importorskip("numpy")
pd = pytest.importorskip("pandas")
pytest.importorskip("sklearn")
optuna = pytest.importorskip("optuna")
from sklearn.exceptions import ConvergenceWarning

from ins_pricing.modelling.bayesopt.trainers.trainer_glm import GLMTrainer


def test_glm_raw_design_preserves_categorical_columns():
    ctx = SimpleNamespace(
        var_nmes=["x_num", "x_cat"],
        factor_nmes=["x_num", "x_cat"],
        cate_list=["x_cat"],
        train_oht_scl_data=None,
    )
    trainer = GLMTrainer(ctx)
    data = pd.DataFrame(
        {
            "x_num": np.array([1.0, 2.0, 3.0], dtype=np.float32),
            "x_cat": ["a", None, "b"],
        }
    )

    design = trainer._prepare_design(data)

    assert design["x_num"].dtype == np.float64
    assert isinstance(design["x_cat"].dtype, pd.CategoricalDtype)
    assert "__INS_PRICING_MISSING__" in set(design["x_cat"].cat.categories)


def test_glm_raw_design_uses_training_category_specs_without_mutating_inputs():
    ctx = SimpleNamespace(
        var_nmes=["x_num", "x_cat"],
        factor_nmes=["x_num", "x_cat"],
        cate_list=["x_cat"],
        train_oht_scl_data=None,
    )
    trainer = GLMTrainer(ctx)
    train = pd.DataFrame(
        {
            "x_num": np.array([1.0, 2.0], dtype=np.float32),
            "x_cat": ["a", "b"],
        }
    )
    val = pd.DataFrame(
        {
            "x_num": np.array([3.0, 4.0, 5.0], dtype=np.float32),
            "x_cat": ["a", None, "c"],
        }
    )
    val_before = val.copy(deep=True)

    specs = trainer._build_raw_categorical_specs(train)
    design = trainer._prepare_design(val, category_specs=specs)

    assert val.equals(val_before)
    assert design["x_cat"].isna().sum() == 0
    assert "__INS_PRICING_MISSING__" in set(design["x_cat"].cat.categories)
    assert "__INS_PRICING_UNKNOWN__" in set(design["x_cat"].cat.categories)
    assert design["x_cat"].astype("object").tolist() == [
        "a",
        "__INS_PRICING_MISSING__",
        "__INS_PRICING_UNKNOWN__",
    ]


def test_glm_oht_design_uses_float64_without_densifying_sparse_columns():
    ctx = SimpleNamespace(
        var_nmes=["x_num", "x_cat_b"],
        factor_nmes=["x_num", "x_cat"],
        cate_list=["x_cat"],
        train_oht_scl_data=object(),
    )
    trainer = GLMTrainer(ctx)
    sparse_values = pd.arrays.SparseArray(
        np.array([0.0, 1.0, 0.0], dtype=np.float32),
        fill_value=0.0,
    )
    data = pd.DataFrame(
        {
            "x_num": np.array([1.0, 2.0, 3.0], dtype=np.float32),
            "x_cat_b": pd.Series(sparse_values),
        }
    )

    design = trainer._prepare_design(data)

    assert design["x_num"].dtype == np.float64
    assert isinstance(design["x_cat_b"].dtype, pd.SparseDtype)
    assert design["x_cat_b"].dtype.subtype == np.float64


def test_glm_fit_guard_prunes_convergence_warning():
    class WarningModel:
        def fit(self, X, y, sample_weight=None):
            warnings.warn("IRLS failed to converge", ConvergenceWarning)
            self.n_iter_ = 1
            self.coef_ = np.array([1.0])
            return self

    trainer = GLMTrainer(
        SimpleNamespace(
            var_nmes=["x"],
            factor_nmes=["x"],
            cate_list=[],
            train_oht_scl_data=None,
            config=SimpleNamespace(),
        )
    )

    with pytest.raises(optuna.TrialPruned, match="did not converge"):
        trainer._fit_with_guard(
            WarningModel(),
            np.ones((3, 1), dtype=np.float64),
            np.ones(3, dtype=np.float64),
            None,
            phase="CV",
            max_iter=10,
            timeout_seconds=None,
            prune_on_guard=True,
        )


def test_glm_fit_guard_prunes_iteration_limit():
    class LimitModel:
        def fit(self, X, y, sample_weight=None):
            self.n_iter_ = 5
            self.coef_ = np.array([1.0])
            return self

    trainer = GLMTrainer(
        SimpleNamespace(
            var_nmes=["x"],
            factor_nmes=["x"],
            cate_list=[],
            train_oht_scl_data=None,
            config=SimpleNamespace(),
        )
    )

    with pytest.raises(optuna.TrialPruned, match="iteration limit"):
        trainer._fit_with_guard(
            LimitModel(),
            np.ones((3, 1), dtype=np.float64),
            np.ones(3, dtype=np.float64),
            None,
            phase="CV",
            max_iter=5,
            timeout_seconds=None,
            prune_on_guard=True,
        )


def test_glm_fit_guard_raises_for_final_nonconvergence():
    class LimitModel:
        def fit(self, X, y, sample_weight=None):
            self.n_iter_ = 5
            self.coef_ = np.array([1.0])
            return self

    trainer = GLMTrainer(
        SimpleNamespace(
            var_nmes=["x"],
            factor_nmes=["x"],
            cate_list=[],
            train_oht_scl_data=None,
            config=SimpleNamespace(),
        )
    )

    with pytest.raises(RuntimeError, match="iteration limit"):
        trainer._fit_with_guard(
            LimitModel(),
            np.ones((3, 1), dtype=np.float64),
            np.ones(3, dtype=np.float64),
            None,
            phase="final",
            max_iter=5,
            timeout_seconds=None,
            prune_on_guard=False,
        )
