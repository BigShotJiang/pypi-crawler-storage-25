from __future__ import annotations

import types
from typing import Optional

import pytest

optuna = pytest.importorskip("optuna")

from ins_pricing.modelling.bayesopt.trainers.trainer_glm import GLMTrainer


def _make_minimal_glm_trainer(
    invalid_param_policy: str = "warn",
    *,
    task_type: str = "regression",
    loss_name: str = "tweedie",
    glm_search_space: Optional[dict] = None,
) -> GLMTrainer:
    trainer = object.__new__(GLMTrainer)
    trainer.label = "GLM"
    trainer.model_name_prefix = "GLM"
    trainer._invalid_param_warnings_emitted = set()
    trainer.ctx = types.SimpleNamespace(
        task_type=task_type,
        loss_name=loss_name,
        config=types.SimpleNamespace(
            invalid_param_policy=invalid_param_policy,
            glm_search_space=glm_search_space or {},
        ),
    )
    return trainer


def test_glm_filter_search_space_drops_tweedie_power_for_gamma_loss() -> None:
    trainer = _make_minimal_glm_trainer(loss_name="gamma")
    filtered = trainer._filter_search_space_for_distribution(
        {
            "alpha": {"type": "float", "low": 1e-6, "high": 1.0, "log": True},
            "tweedie_power": {"type": "float", "low": 1.0, "high": 2.0},
        }
    )
    assert "alpha" in filtered
    assert "tweedie_power" not in filtered


def test_glm_filter_search_space_rejects_unknown_params_under_error_policy() -> None:
    trainer = _make_minimal_glm_trainer(invalid_param_policy="error")
    with pytest.raises(ValueError, match="Unsupported params"):
        trainer._filter_search_space_for_distribution(
            {
                "alpha": {"type": "float", "low": 1e-6, "high": 1.0, "log": True},
                "learning_rate": {"type": "float", "low": 1e-4, "high": 1e-2},
            }
        )


def test_glm_cross_val_uses_json_search_space_values() -> None:
    trainer = _make_minimal_glm_trainer(
        glm_search_space={
            "alpha": {"value": 0.125},
            "l1_ratio": {"value": 0.75},
            "tweedie_power": {"value": 1.4},
        }
    )
    captured = {}

    def fake_cross_val_generic(**kwargs):
        captured.update(kwargs)
        return 0.0

    trainer.cross_val_generic = fake_cross_val_generic
    study = optuna.create_study(direction="minimize")
    trial = study.ask()

    assert trainer.cross_val(trial) == 0.0
    param_space = captured["hyperparameter_space"]
    assert param_space["alpha"](trial) == 0.125
    assert param_space["l1_ratio"](trial) == 0.75
    assert param_space["tweedie_power"](trial) == 1.4
