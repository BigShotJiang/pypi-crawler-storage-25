from __future__ import annotations

import types

import numpy as np
import pandas as pd
import pytest

pytest.importorskip("optuna")
pytest.importorskip("torch")

from ins_pricing.modelling.bayesopt.config_schema import BayesOptConfig
from ins_pricing.modelling.bayesopt.trainers.trainer_ft import FTTrainer


class _FakeFTFeatureModel:
    def __init__(self) -> None:
        self.epochs = 20
        self.training_history = {
            "train": [0.6, 0.5, 0.55],
            "val": [0.5, 0.4, 0.45],
        }
        self.fit_calls = []

    def fit(self, X_train, y_train, **kwargs):
        self.fit_calls.append(
            {
                "rows": len(X_train),
                "has_val": kwargs.get("X_val") is not None,
                "epochs": self.epochs,
            }
        )
        return self

    def predict(self, X, **kwargs):
        if kwargs.get("return_embedding"):
            return np.full((len(X), 2), float(self.epochs))
        return np.full(len(X), float(self.epochs))


def _make_trainer(*, ft_embedding_use_oof: bool = False) -> FTTrainer:
    train_df = pd.DataFrame(
        {
            "x": np.arange(12, dtype=float),
            "y": np.linspace(1.0, 2.0, 12),
            "w": np.ones(12),
        }
    )
    test_df = pd.DataFrame(
        {
            "x": np.arange(4, dtype=float),
            "y": np.linspace(1.0, 1.5, 4),
            "w": np.ones(4),
        }
    )
    config = types.SimpleNamespace(
        final_refit=True,
        ft_embedding_use_oof=ft_embedding_use_oof,
    )
    ctx = types.SimpleNamespace(
        config=config,
        train_data=train_df,
        test_data=test_df,
        factor_nmes=["x"],
        resp_nme="y",
        weight_nme="w",
        train_geo_tokens=None,
        test_geo_tokens=None,
        prop_test=0.25,
        rand_seed=13,
        epochs=20,
    )
    trainer = object.__new__(FTTrainer)
    trainer.ctx = ctx
    trainer.best_params = {"d_model": 8}
    trainer.model = None
    trainer._last_oof_best_epochs = []
    trainer._sanitize_best_params = lambda params, **_kwargs: dict(params)
    trainer._build_geo_io_kwargs = (
        lambda **_kwargs: ({}, {"return_embedding": True}, {"return_embedding": True})
    )
    trainer._resolve_train_val_indices = (
        lambda _X_all, allow_default=False: (np.arange(0, 8), np.arange(8, 12))
    )
    trainer._maybe_cleanup_gpu = lambda _model: None
    return trainer


def test_config_accepts_ft_embedding_use_oof() -> None:
    cfg = BayesOptConfig.from_flat_dict(
        {
            "model_nme": "demo",
            "resp_nme": "y",
            "weight_nme": "w",
            "factor_nmes": ["x"],
            "ft_embedding_use_oof": True,
        }
    )

    assert cfg.ft_embedding_use_oof is True
    assert cfg.ft_transformer.embedding_use_oof is True


def test_embedding_features_skip_oof_by_default_and_use_refit_epoch() -> None:
    trainer = _make_trainer(ft_embedding_use_oof=False)
    built_models = []
    captured = {}

    def _build_model(_params):
        model = _FakeFTFeatureModel()
        built_models.append(model)
        return model

    def _fail_oof(*_args, **_kwargs):
        pytest.fail("embedding features should not use OOF by default")

    def _fit_predict_cache(model, X_train, y_train, **kwargs):
        captured["model"] = model
        captured["predict_kwargs_train"] = kwargs.get("predict_kwargs_train")
        model.fit(X_train, y_train, **(kwargs.get("fit_kwargs") or {}))

    trainer._build_ft_feature_model = _build_model
    trainer._oof_predict_train = _fail_oof
    trainer._fit_predict_cache = _fit_predict_cache

    trainer.train_as_feature(pred_prefix="ft_emb", feature_mode="embedding")

    assert len(built_models) == 2
    assert built_models[0].fit_calls[0]["has_val"] is True
    assert captured["model"] is built_models[1]
    assert captured["model"].epochs == 2
    assert captured["model"].fit_calls[0]["has_val"] is False
    assert captured["predict_kwargs_train"]["return_embedding"] is True


def test_embedding_features_can_use_legacy_oof_and_oof_best_epoch() -> None:
    trainer = _make_trainer(ft_embedding_use_oof=True)
    built_models = []
    cached = {}
    oof_preds = np.ones((len(trainer.ctx.train_data), 2), dtype=float)

    def _build_model(_params):
        model = _FakeFTFeatureModel()
        built_models.append(model)
        return model

    def _oof_predict_train(*_args, **_kwargs):
        trainer._last_oof_best_epochs = [3, 5, 4]
        return oof_preds

    def _cache_predictions(pred_prefix, preds_train, preds_test):
        cached["pred_prefix"] = pred_prefix
        cached["preds_train"] = preds_train
        cached["preds_test"] = preds_test

    trainer._build_ft_feature_model = _build_model
    trainer._oof_predict_train = _oof_predict_train
    trainer._cache_predictions = _cache_predictions

    trainer.train_as_feature(pred_prefix="ft_emb", feature_mode="embedding")

    assert len(built_models) == 1
    assert built_models[0].epochs == 4
    assert built_models[0].fit_calls[0]["has_val"] is False
    assert cached["pred_prefix"] == "ft_emb"
    assert cached["preds_train"] is oof_preds
    assert cached["preds_test"].shape == (len(trainer.ctx.test_data), 2)


def test_ft_oof_strategy_uses_stratified_kfold_for_classification() -> None:
    train_df = pd.DataFrame(
        {
            "x": np.arange(20, dtype=float),
            "y": [0] * 10 + [1] * 10,
            "w": np.ones(20),
        }
    )
    config = types.SimpleNamespace(
        ft_oof_strategy="stratified",
        ft_oof_folds=5,
        ft_oof_shuffle=True,
    )
    trainer = object.__new__(FTTrainer)
    trainer.ctx = types.SimpleNamespace(
        config=config,
        train_data=train_df,
        prop_test=0.25,
        rand_seed=13,
        task_type="classification",
        resp_nme="y",
    )

    splitter, groups, folds = trainer._resolve_oof_splitter(len(train_df))
    splits = list(splitter.split(train_df[["x"]], train_df["y"], groups=groups))

    assert groups is None
    assert folds == 5
    for _train_idx, val_idx in splits:
        assert train_df["y"].iloc[val_idx].value_counts().to_dict() == {0: 2, 1: 2}


def test_ft_oof_strategy_rejects_unknown_strategy() -> None:
    train_df = pd.DataFrame(
        {
            "x": np.arange(10, dtype=float),
            "y": [0] * 5 + [1] * 5,
        }
    )
    config = types.SimpleNamespace(ft_oof_strategy="typo", ft_oof_folds=3)
    trainer = object.__new__(FTTrainer)
    trainer.ctx = types.SimpleNamespace(
        config=config,
        train_data=train_df,
        prop_test=0.25,
        rand_seed=13,
        task_type="classification",
        resp_nme="y",
    )

    with pytest.raises(ValueError, match="Unsupported ft_oof_strategy"):
        trainer._resolve_oof_splitter(len(train_df))
