from __future__ import annotations

from pathlib import Path


def test_double_lift_target_default_value_is_response() -> None:
    root = Path(__file__).resolve().parents[2]
    source = (root / "frontend" / "ui_frontend.py").read_text(encoding="utf-8")
    assert (
        'dl_tgt = ui.input("Target", value="response")' in source
        or 'dl_tgt = self._field_inp("Target", "response", classes="flex-1")' in source
    )


def test_frontend_exposes_model_processing_workflow_tabs() -> None:
    root = Path(__file__).resolve().parents[2]
    source = (root / "frontend" / "ui_frontend.py").read_text(encoding="utf-8")

    assert 'ui.tab("Explain", icon="manage_search")' in source
    assert 'ui.tab("XGB vs GLM")' in source
    assert 'ui.tab("Current vs XGB")' in source
    assert '"Best Params Files (JSON)"' in source
    assert '"Tuning Timeout Seconds"' in source
