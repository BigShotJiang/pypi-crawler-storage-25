from __future__ import annotations

from ins_pricing.frontend.config_builder import ConfigBuilder


def test_build_config_includes_glm_controls_and_best_params_files() -> None:
    cfg = ConfigBuilder().build_config(
        data_dir="./Data",
        model_list=["od"],
        model_categories=["bc"],
        target="response",
        weight="weights",
        feature_list=["f1"],
        categorical_features=["f2"],
        model_keys=["glm"],
        glm_tuning_max_iter=11,
        glm_final_max_iter=22,
        glm_tuning_fit_timeout_seconds=33.5,
        glm_final_fit_timeout_seconds=44.5,
        best_params_files={"glm": "./Results/versions/od_bc_glm_best.json"},
    )

    assert cfg["runner"]["model_keys"] == ["glm"]
    assert cfg["glm_tuning_max_iter"] == 11
    assert cfg["glm_final_max_iter"] == 22
    assert cfg["glm_tuning_fit_timeout_seconds"] == 33.5
    assert cfg["glm_final_fit_timeout_seconds"] == 44.5
    assert cfg["best_params_files"] == {"glm": "./Results/versions/od_bc_glm_best.json"}
