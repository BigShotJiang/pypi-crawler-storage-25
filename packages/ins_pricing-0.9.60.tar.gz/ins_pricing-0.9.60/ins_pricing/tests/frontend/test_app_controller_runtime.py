from __future__ import annotations

import json
from types import SimpleNamespace

from ins_pricing.frontend.app_controller import PricingApp


class _FakeRunner:
    def run_task(self, _config_path: str):
        for i in range(120):
            yield f"line-{i:03d} " + ("x" * 20)


def test_run_training_caps_log_tail(monkeypatch) -> None:
    monkeypatch.setenv("INS_PRICING_FRONTEND_LOG_MAX_CHARS", "240")
    app = PricingApp()
    app.runner = _FakeRunner()

    updates = list(app.run_training('{"runner": {"mode": "entry"}}'))
    assert updates

    final_status, final_log = updates[-1]
    assert "completed" in final_status.lower()
    assert len(final_log) <= 240
    assert "line-000" not in final_log
    assert "line-119" in final_log


def test_run_training_denies_viewer_actor(monkeypatch, tmp_path) -> None:
    monkeypatch.setenv("INS_PRICING_FRONTEND_AUTH_FILE", str(tmp_path / "frontend_users.json"))
    app = PricingApp()
    app.auth_store.create_user("viewer_1", "pass123", ["viewer"])
    app.runner = _FakeRunner()

    updates = list(app.run_training('{"runner": {"mode": "entry"}}', actor="viewer_1"))
    assert updates
    final_status, final_log = updates[-1]
    assert "permission denied" in final_status.lower()
    assert "task:run" in final_log.lower()


def test_run_training_allows_operator_actor(monkeypatch, tmp_path) -> None:
    monkeypatch.setenv("INS_PRICING_FRONTEND_AUTH_FILE", str(tmp_path / "frontend_users.json"))
    app = PricingApp()
    app.auth_store.create_user("operator_1", "pass123", ["operator"])
    app.runner = _FakeRunner()

    updates = list(app.run_training('{"runner": {"mode": "entry"}}', actor="operator_1"))
    assert updates
    final_status, final_log = updates[-1]
    assert "completed" in final_status.lower()
    assert "line-119" in final_log


def test_prepare_ft_step2_preserves_raw_features_from_helper(monkeypatch, tmp_path) -> None:
    app = PricingApp()
    app.working_dir = tmp_path
    app.current_config_dir = tmp_path

    step1_path = tmp_path / "config_ft_ddp_embed.json"
    step1_path.write_text(
        json.dumps(
            {
                "model_list": ["od"],
                "model_categories": ["bc"],
                "feature_list": ["f1"],
                "categorical_features": ["f2"],
            }
        ),
        encoding="utf-8",
    )

    def _fake_generate_step2_configs(**kwargs):
        assert kwargs["target_models"] == ["xgb"]
        assert kwargs["augmented_data_dir"] == "step2_cache/runtime"
        return (
            {
                "feature_list": ["f2", "pred_ft_emb_0"],
                "categorical_features": ["f2"],
                "runner": {"model_keys": ["xgb"]},
            },
            None,
        )

    monkeypatch.setattr(app.ft_workflow, "generate_step2_configs", _fake_generate_step2_configs)

    status, xgb_json, resn_json = app.prepare_ft_step2(
        str(step1_path),
        "xgb",
        "",
        "{}",
        "{}",
    )

    assert "prepared" in status.lower()
    assert resn_json == ""
    xgb_cfg = json.loads(xgb_json)
    assert xgb_cfg["feature_list"] == ["f2", "pred_ft_emb_0"]
    assert xgb_cfg["categorical_features"] == ["f2"]


def test_workflow_dispatch_supports_current_vs_direct_xgb(monkeypatch, tmp_path) -> None:
    app = PricingApp()
    app.working_dir = tmp_path
    cfg_path = tmp_path / "config_xgb_direct.json"
    cfg_path.write_text("{}", encoding="utf-8")
    calls = {}

    def _fake_compare(**kwargs):
        calls.update(kwargs)
        return "ok"

    monkeypatch.setattr(
        app,
        "_load_workflows_module",
        lambda: SimpleNamespace(run_compare_current_model_vs_direct_xgb=_fake_compare),
    )

    result = app._run_workflow_from_config(
        {
            "workflow": {
                "mode": "compare_current_vs_direct_xgb",
                "xgb_cfg_path": "config_xgb_direct.json",
                "current_model_col": "curr_score",
                "xgb_pred_col": "pred_xgb",
                "n_bins": 7,
                "split_cache_force_rebuild": True,
            }
        },
        tmp_path,
    )

    assert result == "ok"
    assert calls["xgb_cfg_path"] == str(cfg_path.resolve())
    assert calls["current_model_col"] == "curr_score"
    assert calls["xgb_pred_col"] == "pred_xgb"
    assert calls["n_bins"] == 7
    assert calls["split_cache_force_rebuild"] is True
