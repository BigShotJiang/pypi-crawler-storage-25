from __future__ import annotations

import pickle
import sys
import types
import _codecs
from pathlib import Path

import pytest

from ins_pricing.exceptions import ModelLoadError
import ins_pricing.utils.model_loading as model_loading
from ins_pricing.utils.model_loading import (
    load_pickle_artifact,
    load_torch_payload_with_trusted_fallback,
)


def test_load_pickle_artifact_allows_safe_payload(tmp_path):
    path = tmp_path / "safe.pkl"
    with path.open("wb") as fh:
        pickle.dump({"values": [1, 2, 3]}, fh, protocol=pickle.HIGHEST_PROTOCOL)

    payload = load_pickle_artifact(path)
    assert payload == {"values": [1, 2, 3]}


def test_load_pickle_artifact_allows_bytearray_payload(tmp_path):
    path = tmp_path / "bytearray.pkl"
    payload = {"blob": bytearray(b"\x01\x02\x03")}
    with path.open("wb") as fh:
        pickle.dump(payload, fh, protocol=pickle.HIGHEST_PROTOCOL)

    loaded = load_pickle_artifact(path)
    assert isinstance(loaded, dict)
    assert loaded["blob"] == payload["blob"]
    assert isinstance(loaded["blob"], bytearray)


def test_load_pickle_artifact_blocks_untrusted_global_by_default(tmp_path):
    path = tmp_path / "unsafe.pkl"
    with path.open("wb") as fh:
        pickle.dump(Path("abc"), fh, protocol=pickle.HIGHEST_PROTOCOL)

    with pytest.raises(ModelLoadError):
        load_pickle_artifact(path)


def test_load_pickle_artifact_allows_xgb_wrapper_payload(tmp_path):
    pytest.importorskip("xgboost")
    pytest.importorskip("optuna")
    pytest.importorskip("torch")
    pytest.importorskip("sklearn")

    from ins_pricing.modelling.bayesopt.trainers.trainer_xgb import _XGBDMatrixWrapper

    path = tmp_path / "xgb_wrapper.pkl"
    payload = {
        "model": _XGBDMatrixWrapper(
            params={"n_estimators": 1},
            task_type="regression",
            use_gpu=False,
        )
    }
    with path.open("wb") as fh:
        pickle.dump(payload, fh, protocol=pickle.HIGHEST_PROTOCOL)

    loaded = load_pickle_artifact(path)
    assert isinstance(loaded, dict)
    assert isinstance(loaded.get("model"), _XGBDMatrixWrapper)


def test_load_pickle_artifact_allows_glum_glm_payload(tmp_path, monkeypatch):
    glum_module = types.ModuleType("glum")
    glm_module = types.ModuleType("glum._glm")
    exec("class GeneralizedLinearRegressor:\n    pass\n", glm_module.__dict__)
    glum_module._glm = glm_module
    monkeypatch.setitem(sys.modules, "glum", glum_module)
    monkeypatch.setitem(sys.modules, "glum._glm", glm_module)

    model_cls = glm_module.GeneralizedLinearRegressor
    path = tmp_path / "glm.pkl"
    with path.open("wb") as fh:
        pickle.dump({"model": model_cls()}, fh, protocol=pickle.HIGHEST_PROTOCOL)

    loaded = load_pickle_artifact(path)
    assert isinstance(loaded, dict)
    assert isinstance(loaded.get("model"), model_cls)


def test_load_pickle_artifact_allows_joblib_numpy_pickle_root_module(tmp_path):
    pytest.importorskip("joblib")
    np = pytest.importorskip("numpy")

    import joblib

    path = tmp_path / "joblib_payload.pkl"
    payload = {"array": np.asarray([1.0, 2.0, 3.0])}
    joblib.dump(payload, path)

    loaded = load_pickle_artifact(path)
    assert isinstance(loaded, dict)
    assert np.allclose(loaded["array"], payload["array"])


def test_load_pickle_artifact_allows_joblib_numpy_array_wrapper_symbol(
    tmp_path,
    monkeypatch,
):
    joblib_module = types.ModuleType("joblib")
    numpy_pickle_module = types.ModuleType("joblib.numpy_pickle")
    exec("class NumpyArrayWrapper:\n    pass\n", numpy_pickle_module.__dict__)
    joblib_module.numpy_pickle = numpy_pickle_module
    monkeypatch.setitem(sys.modules, "joblib", joblib_module)
    monkeypatch.setitem(sys.modules, "joblib.numpy_pickle", numpy_pickle_module)

    wrapper_cls = numpy_pickle_module.NumpyArrayWrapper
    path = tmp_path / "joblib_wrapper.pkl"
    with path.open("wb") as fh:
        pickle.dump({"wrapper": wrapper_cls()}, fh, protocol=pickle.HIGHEST_PROTOCOL)

    loaded = load_pickle_artifact(path)
    assert isinstance(loaded, dict)
    assert isinstance(loaded.get("wrapper"), wrapper_cls)


def test_load_pickle_artifact_allows_codecs_encode_reduce(tmp_path):
    class _EncodedPayload:
        def __reduce__(self):
            return (_codecs.encode, ("abc", "utf-8"))

    path = tmp_path / "codecs_encode.pkl"
    with path.open("wb") as fh:
        pickle.dump({"value": _EncodedPayload()}, fh, protocol=pickle.HIGHEST_PROTOCOL)

    loaded = load_pickle_artifact(path)
    assert loaded == {"value": b"abc"}


def test_load_torch_payload_with_trusted_fallback_is_secure_by_default(
    tmp_path,
    monkeypatch,
):
    path = tmp_path / "legacy.pth"
    path.write_bytes(b"legacy")

    def _secure_load(*_args, **_kwargs):
        raise ModelLoadError("secure torch load failed")

    monkeypatch.setattr(model_loading, "load_torch_payload", _secure_load)

    with pytest.raises(ModelLoadError, match="secure torch load failed"):
        load_torch_payload_with_trusted_fallback(path)


def test_load_torch_payload_with_trusted_fallback_retries_when_enabled(
    tmp_path,
    monkeypatch,
):
    path = tmp_path / "legacy.pth"
    path.write_bytes(b"legacy")
    calls = []

    def _secure_load(*_args, **_kwargs):
        calls.append("secure")
        raise ModelLoadError("secure torch load failed")

    def _trusted_load(*_args, **_kwargs):
        calls.append("trusted")
        return {"model": "legacy"}

    monkeypatch.setattr(model_loading, "load_torch_payload", _secure_load)
    monkeypatch.setattr(model_loading, "load_trusted_torch_payload", _trusted_load)

    payload = load_torch_payload_with_trusted_fallback(
        path,
        allow_unsafe_fallback=True,
    )

    assert payload == {"model": "legacy"}
    assert calls == ["secure", "trusted"]


def test_bayesopt_config_accepts_allow_unsafe_model_load(monkeypatch):
    repo_root = Path(__file__).resolve().parents[2]
    fake_modelling = types.ModuleType("ins_pricing.modelling")
    fake_modelling.__path__ = [str(repo_root / "modelling")]
    fake_bayesopt = types.ModuleType("ins_pricing.modelling.bayesopt")
    fake_bayesopt.__path__ = [str(repo_root / "modelling" / "bayesopt")]
    monkeypatch.setitem(sys.modules, "ins_pricing.modelling", fake_modelling)
    monkeypatch.setitem(sys.modules, "ins_pricing.modelling.bayesopt", fake_bayesopt)

    from ins_pricing.modelling.bayesopt.config_schema import BayesOptConfig

    cfg = BayesOptConfig.from_flat_dict(
        {
            "model_nme": "demo",
            "resp_nme": "y",
            "weight_nme": "w",
            "factor_nmes": ["x"],
            "allow_unsafe_model_load": True,
        }
    )

    assert cfg.allow_unsafe_model_load is True
    monkeypatch.delitem(
        sys.modules,
        "ins_pricing.modelling.bayesopt.config_schema",
        raising=False,
    )
    monkeypatch.delitem(
        sys.modules,
        "ins_pricing.modelling.bayesopt.config_components",
        raising=False,
    )
