from __future__ import annotations

import pytest


def test_device_manager_exports_are_shared():
    pytest.importorskip("torch")

    from ins_pricing.modelling.bayesopt.utils import (
        DeviceManager as BayesOptDeviceManager,
        GPUMemoryManager as BayesOptGPUMemoryManager,
    )
    from ins_pricing.utils import DeviceManager, GPUMemoryManager
    from ins_pricing.utils.device import (
        DeviceManager as DirectDeviceManager,
        GPUMemoryManager as DirectGPUMemoryManager,
    )

    assert DeviceManager is BayesOptDeviceManager is DirectDeviceManager
    assert GPUMemoryManager is BayesOptGPUMemoryManager is DirectGPUMemoryManager


def test_device_manager_public_methods_remain_available():
    pytest.importorskip("torch")

    from ins_pricing.utils import DeviceManager, GPUMemoryManager

    assert hasattr(DeviceManager, "get_best_device")
    assert hasattr(DeviceManager, "move_to_device")
    assert hasattr(DeviceManager, "unwrap_module")
    assert hasattr(DeviceManager, "reset_cache")

    assert hasattr(GPUMemoryManager, "clean")
    assert hasattr(GPUMemoryManager, "cleanup_context")
    assert hasattr(GPUMemoryManager, "get_memory_info")
    assert hasattr(GPUMemoryManager, "move_model_to_cpu")
