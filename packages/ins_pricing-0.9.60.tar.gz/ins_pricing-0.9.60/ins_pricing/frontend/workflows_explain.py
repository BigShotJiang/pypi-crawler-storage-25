"""Explainability workflows used by the frontend UI."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence

import numpy as np
import pandas as pd

from ins_pricing.cli.utils.cli_common import split_train_test
from ins_pricing.frontend.ft_workflow import FTWorkflowHelper
from ins_pricing.frontend.logging_utils import get_frontend_logger, log_print
from ins_pricing.modelling.plotting.common import plt
from ins_pricing.split_cache import (
    load_split_cache,
    resolve_model_scoped_path,
    validate_split_cache_metadata,
    validate_split_indices,
)
from ins_pricing.utils.metrics import tweedie_deviance

from .workflows_common import (
    _build_search_roots,
    _discover_model_file,
    _load_ft_embedding_model,
    _load_pickled_model_payload,
    _resolve_output_dir,
)

_logger = get_frontend_logger("ins_pricing.frontend.workflows_explain")


def _log(*args, **kwargs) -> None:
    log_print(_logger, *args, **kwargs)


def _read_json(path_obj: Path) -> dict:
    if not path_obj.exists():
        raise FileNotFoundError(f"Config not found: {path_obj}")
    payload = json.loads(path_obj.read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError(f"Config must be a JSON object: {path_obj}")
    return payload


def _resolve_model_name(cfg: dict) -> str:
    model_list = list(cfg.get("model_list") or [])
    model_categories = list(cfg.get("model_categories") or [])
    if len(model_list) != 1 or len(model_categories) != 1:
        raise ValueError("Workflow expects exactly one model_list and one model_categories entry.")
    return f"{model_list[0]}_{model_categories[0]}"


def _detect_embedding_columns(step1_cfg: dict, step2_cfg: dict) -> List[str]:
    step2_features = [str(c) for c in (step2_cfg.get("feature_list") or [])]
    step1_features = [str(c) for c in (step1_cfg.get("feature_list") or [])]
    ft_prefix = str(
        step1_cfg.get("ft_feature_prefix", step2_cfg.get("ft_feature_prefix", "ft_emb"))
    ).strip()
    embed_prefixes = [f"pred_{ft_prefix}_", f"{ft_prefix}_", ft_prefix]
    embed_cols = [
        col for col in step2_features
        if any(col.startswith(prefix) for prefix in embed_prefixes if prefix)
    ]
    if not embed_cols:
        step1_feature_set = set(step1_features)
        embed_cols = [col for col in step2_features if col not in step1_feature_set]
    return embed_cols


def _load_raw_frame(step1_cfg: dict, step1_cfg_path: Path, model_name: str) -> pd.DataFrame:
    helper = FTWorkflowHelper()
    data_dir = Path(str(step1_cfg.get("data_dir", ".")))
    if not data_dir.is_absolute():
        data_dir = (step1_cfg_path.parent / data_dir).resolve()
    data_format = str(step1_cfg.get("data_format", "csv"))
    raw_path = helper._resolve_input_data_path(
        data_dir=data_dir,
        model_name=model_name,
        data_format=data_format,
        data_path_template=step1_cfg.get("data_path_template"),
        label="Raw data",
    )
    return helper._load_table(raw_path, data_format="auto")


def _split_with_cache_fallback(
    raw: pd.DataFrame,
    cfg: dict,
    cfg_path: Path,
    model_name: str,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    holdout_ratio = float(cfg.get("holdout_ratio", cfg.get("prop_test", 0.25)))
    split_strategy = str(cfg.get("split_strategy", "random") or "random").strip().lower()
    rand_seed = cfg.get("rand_seed", 13)
    split_cache_path = resolve_model_scoped_path(
        cfg.get("split_cache_path"),
        model_name=model_name,
        base_dir=cfg_path.parent,
    )

    if split_cache_path is not None and split_cache_path.exists():
        try:
            train_idx, test_idx, cached_row_count, cache_meta = load_split_cache(split_cache_path)
            validate_split_cache_metadata(
                cache_path=split_cache_path,
                cached_row_count=cached_row_count,
                current_row_count=int(len(raw)),
                cache_meta=cache_meta,
                split_strategy=split_strategy,
                holdout_ratio=holdout_ratio,
                rand_seed=rand_seed,
                split_stratify_col=cfg.get("split_stratify_col"),
            )
            validate_split_indices(
                train_idx=train_idx,
                test_idx=test_idx,
                row_count=int(len(raw)),
                cache_path=split_cache_path,
            )
            _log(f"[Explain] Reused split cache: {split_cache_path}")
            return raw.iloc[train_idx].copy(), raw.iloc[test_idx].copy()
        except Exception as exc:
            _log(f"[Warn] split cache reuse failed; fallback to split_train_test: {exc}")

    return split_train_test(
        raw,
        holdout_ratio=holdout_ratio,
        strategy=split_strategy,
        group_col=cfg.get("split_group_col"),
        stratify_col=(
            cfg.get("split_stratify_col")
            or cfg.get("binary_target")
            or cfg.get("binary_resp_nme")
            or cfg.get("target")
        ),
        time_col=cfg.get("split_time_col"),
        time_ascending=bool(cfg.get("split_time_ascending", True)),
        rand_seed=rand_seed,
        reset_index_mode="none",
        ratio_label="holdout_ratio",
    )


def _prepare_metric_arrays(
    y_true: np.ndarray,
    y_pred: np.ndarray,
    weights: np.ndarray,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    y_arr = np.asarray(y_true, dtype=np.float64).reshape(-1)
    pred_arr = np.asarray(y_pred, dtype=np.float64).reshape(-1)
    w_arr = np.asarray(weights, dtype=np.float64).reshape(-1)
    if not (len(y_arr) == len(pred_arr) == len(w_arr)):
        raise ValueError(
            f"Metric input length mismatch: y={len(y_arr)}, pred={len(pred_arr)}, weight={len(w_arr)}"
        )
    valid = np.isfinite(y_arr) & np.isfinite(pred_arr) & np.isfinite(w_arr) & (w_arr >= 0)
    if int(valid.sum()) == 0:
        raise ValueError("No valid rows left for metric.")
    if float(w_arr[valid].sum()) <= 0:
        raise ValueError("No positive total sample weight left for metric.")
    return y_arr[valid], pred_arr[valid], w_arr[valid]


def _weighted_mse(y_true: np.ndarray, y_pred: np.ndarray, weights: np.ndarray) -> float:
    return float(np.average((y_true - y_pred) ** 2, weights=weights))


def _weighted_r2(y_true: np.ndarray, y_pred: np.ndarray, weights: np.ndarray) -> float:
    y_bar = float(np.average(y_true, weights=weights))
    ss_res = float(np.sum(weights * (y_true - y_pred) ** 2))
    ss_tot = float(np.sum(weights * (y_true - y_bar) ** 2))
    return 0.0 if ss_tot <= 0 else float(1.0 - ss_res / ss_tot)


def _resolve_tweedie_power(
    cfg: dict,
    model_obj: Any,
    explicit_power: Optional[float],
) -> float:
    if explicit_power is not None:
        return float(explicit_power)
    for getter_name in ("get_xgb_params", "get_params"):
        getter = getattr(model_obj, getter_name, None)
        if not callable(getter):
            continue
        try:
            params = getter() or {}
        except Exception:
            params = {}
        value = params.get("tweedie_variance_power") or params.get("tweedie_power")
        if value is not None:
            return float(value)
    value = cfg.get("tweedie_variance_power") or cfg.get("tweedie_power") or cfg.get("tw_power")
    return float(value) if value is not None else 1.5


def _score(
    y_true: np.ndarray,
    y_pred: np.ndarray,
    weights: np.ndarray,
    metric_name: str,
    *,
    tweedie_power: float,
) -> float:
    y_arr, pred_arr, w_arr = _prepare_metric_arrays(y_true, y_pred, weights)
    metric = str(metric_name or "tweedie_deviance").strip().lower()
    if metric in {"tweedie", "tweedie_deviance", "mean_tweedie_deviance"}:
        return tweedie_deviance(y_arr, pred_arr, sample_weight=w_arr, power=float(tweedie_power))
    if metric == "weighted_mae":
        return float(np.average(np.abs(y_arr - pred_arr), weights=w_arr))
    if metric == "weighted_mse":
        return _weighted_mse(y_arr, pred_arr, w_arr)
    if metric == "rmse":
        return float(np.sqrt(_weighted_mse(y_arr, pred_arr, w_arr)))
    if metric == "r2":
        return _weighted_r2(y_arr, pred_arr, w_arr)
    raise ValueError(f"Unsupported metric_name: {metric_name}")


def _is_higher_better(metric_name: str) -> bool:
    return str(metric_name or "").strip().lower() in {"r2"}


def _plot_importance(
    importance_df: pd.DataFrame,
    *,
    explain_dir: Path,
    model_name: str,
    metric_name: str,
    top_n: int,
    dpi: int,
    save_plots: bool,
    show_plots: bool,
) -> list[str]:
    if not (save_plots or show_plots) or plt is None or importance_df.empty:
        return []
    plot_df = importance_df.copy()
    plot_df["delta_mean"] = pd.to_numeric(plot_df["delta_mean"], errors="coerce")
    if "delta_std" in plot_df.columns:
        plot_df["delta_std"] = pd.to_numeric(plot_df["delta_std"], errors="coerce")
    plot_df = plot_df.replace([np.inf, -np.inf], np.nan).dropna(subset=["feature", "delta_mean"])
    if plot_df.empty:
        return []

    saved: list[str] = []
    top_count = max(1, int(top_n))
    top_df = plot_df.sort_values("delta_mean", ascending=False).head(top_count).iloc[::-1]
    colors = ["#2563eb" if value >= 0 else "#b91c1c" for value in top_df["delta_mean"]]
    height = max(4.0, min(14.0, 0.38 * len(top_df) + 1.6))
    fig, ax = plt.subplots(figsize=(10.5, height))
    xerr = top_df["delta_std"].fillna(0.0).to_numpy(dtype=float) if "delta_std" in top_df else None
    ax.barh(top_df["feature"], top_df["delta_mean"], xerr=xerr, color=colors, alpha=0.9)
    ax.axvline(0.0, color="#444444", linewidth=0.8)
    ax.set_xlabel(f"Permutation delta ({metric_name})")
    ax.set_title(f"{model_name} raw feature importance - top {len(top_df)}")
    ax.grid(True, axis="x", linestyle="--", alpha=0.25)
    fig.tight_layout()
    if save_plots:
        bar_path = explain_dir / f"{model_name}_xgb_e2e_raw_permutation_top{top_count}.png"
        fig.savefig(bar_path, dpi=int(dpi), bbox_inches="tight")
        saved.append(str(bar_path))
        _log(f"[Explain] Saved top-N importance: {bar_path}")
    if show_plots:
        plt.show()
    else:
        plt.close(fig)

    positive_df = plot_df[plot_df["delta_mean"] > 0].sort_values("delta_mean", ascending=False)
    positive_total = float(positive_df["delta_mean"].sum()) if not positive_df.empty else 0.0
    if positive_total <= 0:
        return saved
    cum_df = positive_df.head(top_count).copy()
    cum_df["cumulative_share"] = cum_df["delta_mean"].cumsum() / positive_total
    fig, ax = plt.subplots(figsize=(8.5, 4.8))
    ranks = np.arange(1, len(cum_df) + 1)
    ax.plot(ranks, cum_df["cumulative_share"], marker="o", color="#2563eb", linewidth=1.8)
    ax.set_ylim(0.0, 1.05)
    ax.set_xlim(1, max(1, len(cum_df)))
    ax.set_xlabel("Top raw features included")
    ax.set_ylabel("Cumulative share of positive delta")
    ax.set_title(f"{model_name} cumulative raw-feature contribution")
    ax.grid(True, linestyle="--", alpha=0.25)
    fig.tight_layout()
    if save_plots:
        cum_path = explain_dir / f"{model_name}_xgb_e2e_raw_permutation_cumulative_top{top_count}.png"
        fig.savefig(cum_path, dpi=int(dpi), bbox_inches="tight")
        saved.append(str(cum_path))
        _log(f"[Explain] Saved cumulative importance: {cum_path}")
    if show_plots:
        plt.show()
    else:
        plt.close(fig)
    return saved


def run_e2e_raw_permutation_explain(
    *,
    step1_cfg_path: str,
    step2_xgb_cfg_path: str,
    on_train: bool = False,
    n_repeats: int = 1,
    max_rows: int = 20000,
    random_state: int = 13,
    features_subset: Optional[Sequence[str]] = None,
    metric_name: str = "tweedie_deviance",
    tweedie_power: Optional[float] = None,
    save_result_csv: bool = True,
    save_plots: bool = True,
    show_plots: bool = False,
    plot_top_n: int = 30,
    plot_dpi: int = 150,
    output_dir: Optional[str] = None,
    model_search_dir: Optional[str] = None,
) -> Dict[str, Any]:
    """Explain raw Step-1 features through FT embedding and trained Step-2 XGB."""

    step1_path = Path(step1_cfg_path).expanduser().resolve()
    step2_path = Path(step2_xgb_cfg_path).expanduser().resolve()
    step1_cfg = _read_json(step1_path)
    step2_cfg = _read_json(step2_path)

    model_name = _resolve_model_name(step1_cfg)
    step2_model_name = _resolve_model_name(step2_cfg)
    if model_name != step2_model_name:
        raise ValueError(f"Model name mismatch: step1={model_name}, step2={step2_model_name}")

    raw_all = _load_raw_frame(step1_cfg, step1_path, model_name=model_name)
    train_raw, test_raw = _split_with_cache_fallback(raw_all, step1_cfg, step1_path, model_name)
    eval_raw = train_raw.copy() if bool(on_train) else test_raw.copy()
    if int(max_rows) > 0 and len(eval_raw) > int(max_rows):
        eval_raw = eval_raw.sample(n=int(max_rows), random_state=int(random_state)).copy()

    target_col = str(step1_cfg.get("target") or step2_cfg.get("target") or "").strip()
    weight_col = str(step1_cfg.get("weight") or step2_cfg.get("weight") or "").strip()
    if not target_col or target_col not in eval_raw.columns:
        raise KeyError(f"Target column missing in evaluation frame: {target_col!r}")

    y_true = pd.to_numeric(eval_raw[target_col], errors="coerce").to_numpy(dtype=np.float64)
    if weight_col and weight_col in eval_raw.columns:
        weights = pd.to_numeric(eval_raw[weight_col], errors="coerce").fillna(0.0).to_numpy(dtype=np.float64)
    else:
        weights = np.ones(len(eval_raw), dtype=np.float64)
    valid = np.isfinite(y_true) & np.isfinite(weights) & (weights >= 0)
    if int(valid.sum()) == 0:
        raise ValueError("No rows left after target/weight filtering.")
    if not bool(valid.all()):
        eval_raw = eval_raw.loc[valid].copy()
        y_true = y_true[valid]
        weights = weights[valid]

    step1_features = [str(col) for col in (step1_cfg.get("feature_list") or [])]
    missing_step1 = [col for col in step1_features if col not in eval_raw.columns]
    if missing_step1:
        raise KeyError(f"Missing Step-1 raw features in eval data: {missing_step1[:10]}")

    step2_features = [str(col) for col in (step2_cfg.get("feature_list") or [])]
    step2_categorical = [str(col) for col in (step2_cfg.get("categorical_features") or [])]
    embed_cols = _detect_embedding_columns(step1_cfg, step2_cfg)
    if not embed_cols:
        raise ValueError("Unable to detect embedding columns from Step-2 feature_list.")

    step1_output_root = Path(_resolve_output_dir(step1_cfg, step1_path)).resolve()
    step2_output_root = Path(_resolve_output_dir(step2_cfg, step2_path)).resolve()
    search_roots = _build_search_roots(
        model_search_dir,
        step1_path.parent,
        step2_path.parent,
        Path.cwd(),
    )
    ft_model_path = _discover_model_file(
        model_name=model_name,
        model_key="ft",
        search_roots=search_roots,
        output_roots=[step1_output_root],
    )
    if ft_model_path is None:
        raise FileNotFoundError("FT Step-1 model artifact not found.")
    xgb_model_path = _discover_model_file(
        model_name=model_name,
        model_key="xgb",
        search_roots=search_roots,
        output_roots=[step2_output_root],
    )
    if xgb_model_path is None:
        raise FileNotFoundError("Step-2 XGB model artifact not found.")

    ft_model = _load_ft_embedding_model(
        ft_model_path,
        allow_unsafe_model_load=bool(step1_cfg.get("allow_unsafe_model_load", False)),
    )
    if hasattr(ft_model, "device"):
        ft_model.device = "cpu"
    if hasattr(ft_model, "to"):
        try:
            ft_model.to("cpu")
        except Exception:
            pass
    if hasattr(ft_model, "ft"):
        try:
            ft_model.ft.to("cpu")
        except Exception:
            pass

    payload = _load_pickled_model_payload(xgb_model_path)
    xgb_model = payload.get("model") if isinstance(payload, dict) and "model" in payload else payload
    resolved_power = _resolve_tweedie_power(step2_cfg, xgb_model, tweedie_power)

    def _build_step2_input(raw_df: pd.DataFrame) -> pd.DataFrame:
        input_raw = raw_df[step1_features].copy()
        embeddings = ft_model.predict(input_raw, return_embedding=True)
        emb_arr = np.asarray(embeddings)
        if emb_arr.ndim == 1:
            emb_arr = emb_arr.reshape(-1, 1)
        if emb_arr.shape[1] != len(embed_cols):
            raise ValueError(
                f"Embedding width mismatch: generated={emb_arr.shape[1]}, expected={len(embed_cols)}"
            )
        emb_frame = pd.DataFrame(emb_arr, columns=embed_cols, index=raw_df.index)
        step2_df = pd.concat(
            [raw_df.drop(columns=embed_cols, errors="ignore"), emb_frame],
            axis=1,
            copy=False,
        ).copy()
        X = step2_df[step2_features].copy()
        for col in step2_categorical:
            if col in X.columns:
                X[col] = X[col].astype("category")
        return X

    def _predict(raw_df: pd.DataFrame) -> np.ndarray:
        X = _build_step2_input(raw_df)
        task_type = str(step2_cfg.get("task_type", "regression")).strip().lower()
        if task_type in {"binary", "classification", "binary_classification"} and hasattr(xgb_model, "predict_proba"):
            return np.asarray(xgb_model.predict_proba(X)[:, 1], dtype=np.float64)
        return np.asarray(xgb_model.predict(X), dtype=np.float64)

    baseline_pred = _predict(eval_raw)
    baseline_score = _score(
        y_true,
        baseline_pred,
        weights,
        metric_name,
        tweedie_power=resolved_power,
    )
    perm_features = list(step1_features)
    if features_subset:
        allow = {str(item) for item in features_subset}
        perm_features = [feature for feature in perm_features if feature in allow]
    if not perm_features:
        raise ValueError("No raw features selected for permutation.")

    rng = np.random.default_rng(int(random_state))
    records: List[Dict[str, Any]] = []
    repeats = max(1, int(n_repeats))
    for feature in perm_features:
        deltas: list[float] = []
        for _rep in range(repeats):
            perm_df = eval_raw.copy()
            values = perm_df[feature].to_numpy(copy=True)
            rng.shuffle(values)
            perm_df[feature] = values
            pred_perm = _predict(perm_df)
            score_perm = _score(
                y_true,
                pred_perm,
                weights,
                metric_name,
                tweedie_power=resolved_power,
            )
            delta = baseline_score - score_perm if _is_higher_better(metric_name) else score_perm - baseline_score
            deltas.append(float(delta))
        records.append(
            {
                "feature": feature,
                "delta_mean": float(np.mean(deltas)),
                "delta_std": float(np.std(deltas, ddof=0)),
                "n_repeats": repeats,
                "baseline_score": float(baseline_score),
                "metric": str(metric_name),
                "tweedie_power": float(resolved_power),
            }
        )

    importance_df = (
        pd.DataFrame(records)
        .sort_values("delta_mean", ascending=False)
        .reset_index(drop=True)
    )
    explain_dir = (
        Path(output_dir).expanduser().resolve()
        if output_dir
        else (step2_output_root / "Results" / "explain").resolve()
    )
    explain_dir.mkdir(parents=True, exist_ok=True)

    result_csv: Optional[Path] = None
    if bool(save_result_csv):
        result_csv = explain_dir / f"{model_name}_xgb_e2e_raw_permutation.csv"
        importance_df.to_csv(result_csv, index=False)
        _log(f"[Explain] Saved raw permutation CSV: {result_csv}")

    plot_paths = _plot_importance(
        importance_df,
        explain_dir=explain_dir,
        model_name=model_name,
        metric_name=str(metric_name),
        top_n=int(plot_top_n),
        dpi=int(plot_dpi),
        save_plots=bool(save_plots),
        show_plots=bool(show_plots),
    )

    return {
        "output_dir": str(explain_dir),
        "result_csv": str(result_csv) if result_csv is not None else None,
        "plot_paths": plot_paths,
        "importance": importance_df,
        "baseline_score": float(baseline_score),
        "model_name": model_name,
        "rows": int(len(eval_raw)),
        "features": int(len(perm_features)),
    }
