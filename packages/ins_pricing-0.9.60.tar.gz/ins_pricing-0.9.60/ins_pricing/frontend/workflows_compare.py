"""Model comparison workflows used by the frontend UI."""

from __future__ import annotations

import csv
import hashlib
import json
import math
import os
import tempfile
from itertools import combinations
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple

import numpy as np
import pandas as pd
from ins_pricing.frontend.logging_utils import get_frontend_logger, log_print
from ins_pricing.split_cache import (
    load_split_cache,
    resolve_model_scoped_path,
    validate_split_cache_metadata,
    validate_split_indices,
    write_split_cache,
)

from ins_pricing.modelling.plotting import PlotStyle, plot_double_lift_curve
from ins_pricing.modelling.plotting.common import finalize_figure, plt
from ins_pricing.utils.metrics import mae, tweedie_deviance

from .workflows_common import (
    _build_search_roots,
    _drop_duplicate_columns,
    _resolve_data_path,
    _resolve_double_lift_dir,
    _resolve_output_dir,
    _safe_tag,
)
from .workflows_prediction_utils import (
    DOUBLE_LIFT_FIGSIZE,
    build_ft_embedding_frames,
    load_raw_splits,
    resolve_model_output_override,
)

_logger = get_frontend_logger("ins_pricing.frontend.workflows_compare")

try:  # joblib is only required for artifact_file comparison loaders.
    import joblib
except Exception as exc:  # pragma: no cover - optional dependency guard
    joblib = None  # type: ignore[assignment]
    _JOBLIB_IMPORT_ERROR = exc
else:  # pragma: no cover
    _JOBLIB_IMPORT_ERROR = None


def _log(*args, **kwargs) -> None:
    log_print(_logger, *args, **kwargs)


def _load_predictor_from_cfg(*args, **kwargs):
    from ins_pricing.production.inference import load_predictor_from_config

    return load_predictor_from_config(*args, **kwargs)


def _read_json_config(path: Path) -> dict:
    if not path.exists():
        raise FileNotFoundError(f"Config not found: {path}")
    return json.loads(path.read_text(encoding="utf-8-sig"))


def _split_train_test(*args, **kwargs):
    from ins_pricing.cli.utils.cli_common import split_train_test

    return split_train_test(*args, **kwargs)


def _read_table(path_obj: Path) -> pd.DataFrame:
    suffix = path_obj.suffix.lower()
    if suffix in {".csv"}:
        return pd.read_csv(path_obj, low_memory=False)
    if suffix in {".parquet", ".pq"}:
        return pd.read_parquet(path_obj)
    if suffix in {".feather", ".ft"}:
        return pd.read_feather(path_obj)
    raise ValueError(f"Unsupported prediction cache format: {path_obj}")


def _resolve_prediction_cache_paths(
    *,
    cfg: dict,
    cfg_path: Path,
    model_name: str,
    model_key: str,
) -> tuple[Optional[Path], Optional[Path]]:
    if not bool(cfg.get("cache_predictions", False)):
        return None, None

    output_root = Path(_resolve_output_dir(cfg, cfg_path)).resolve()
    result_root = output_root / "Results"
    pred_cache_dir = cfg.get("prediction_cache_dir")
    if pred_cache_dir:
        pred_dir = Path(str(pred_cache_dir))
        if not pred_dir.is_absolute():
            pred_dir = result_root / pred_dir
    else:
        pred_dir = result_root / "predictions"
    pred_dir = pred_dir.resolve()
    if not pred_dir.exists():
        return None, None

    fmt = str(cfg.get("prediction_cache_format", "parquet") or "parquet").strip().lower()
    preferred_ext = "csv" if fmt == "csv" else "parquet"
    ext_order = [preferred_ext, "csv", "parquet"]
    seen_ext = set()
    ordered_ext = []
    for ext in ext_order:
        if ext in seen_ext:
            continue
        seen_ext.add(ext)
        ordered_ext.append(ext)

    def _pick(split_label: str) -> Optional[Path]:
        for ext in ordered_ext:
            candidate = pred_dir / f"{model_name}_{model_key}_{split_label}.{ext}"
            if candidate.exists():
                return candidate.resolve()
        return None

    return _pick("train"), _pick("test")


def _resolve_prediction_column(frame: pd.DataFrame, *, model_key: str, cache_path: Path) -> str:
    exact = f"pred_{model_key}"
    if exact in frame.columns:
        return exact
    prefix = f"pred_{model_key}_"
    matches = [str(col) for col in frame.columns if str(col).startswith(prefix)]
    if len(matches) == 1:
        return matches[0]
    if len(matches) > 1:
        raise ValueError(
            "Prediction cache contains multi-column outputs; compare workflow expects "
            f"a single prediction column. path={cache_path}, columns={matches[:6]}"
        )
    raise ValueError(
        f"Prediction cache missing prediction column for model_key={model_key!r}: {cache_path}"
    )


def _align_cached_predictions(
    *,
    frame: pd.DataFrame,
    split_raw: pd.DataFrame,
    split_key_col: str,
    model_key: str,
    cache_path: Path,
    split_label: str,
) -> np.ndarray:
    pred_col = _resolve_prediction_column(frame, model_key=model_key, cache_path=cache_path)
    can_fallback_row_order = len(frame) == len(split_raw)
    if split_key_col in frame.columns and split_key_col in split_raw.columns:
        key_index = pd.Index(frame[split_key_col])
        if not key_index.is_unique:
            if not can_fallback_row_order:
                raise ValueError(
                    f"Prediction cache key {split_key_col!r} has duplicate values in {cache_path}"
                )
            _log(
                f"[Warn] Prediction cache key {split_key_col!r} is duplicated in {cache_path}; "
                "fallback to row-order alignment."
            )
            series = frame[pred_col]
        else:
            split_pos = key_index.get_indexer(split_raw[split_key_col])
            if np.any(split_pos < 0):
                if not can_fallback_row_order:
                    raise ValueError(
                        f"Cannot align cached {split_label} predictions by key {split_key_col!r}: {cache_path}"
                    )
                _log(
                    f"[Warn] Cached {split_label} key alignment failed for {cache_path}; "
                    "fallback to row-order alignment."
                )
                series = frame[pred_col]
            else:
                series = frame[pred_col].iloc[split_pos]
    else:
        if len(frame) != len(split_raw):
            raise ValueError(
                f"Cached {split_label} row mismatch: cache={len(frame)}, split={len(split_raw)}, "
                f"path={cache_path}"
            )
        series = frame[pred_col]

    values = pd.to_numeric(series, errors="coerce").to_numpy(dtype=float)
    if np.any(~np.isfinite(values)):
        raise ValueError(
            f"Cached {split_label} predictions contain invalid numeric values: {cache_path}"
        )
    return values.reshape(-1)


def _try_load_cached_predictions(
    *,
    cfg: dict,
    cfg_path: Path,
    model_name: str,
    model_key: str,
    train_raw: pd.DataFrame,
    test_raw: pd.DataFrame,
    split_key_col: str,
    cache_label: str,
) -> tuple[Optional[np.ndarray], Optional[np.ndarray]]:
    train_cache_path, test_cache_path = _resolve_prediction_cache_paths(
        cfg=cfg,
        cfg_path=cfg_path,
        model_name=model_name,
        model_key=model_key,
    )
    if train_cache_path is None or test_cache_path is None:
        return None, None

    try:
        train_frame = _drop_duplicate_columns(_read_table(train_cache_path), f"{cache_label}_train_cache")
        test_frame = _drop_duplicate_columns(_read_table(test_cache_path), f"{cache_label}_test_cache")
        train_pred = _align_cached_predictions(
            frame=train_frame,
            split_raw=train_raw,
            split_key_col=split_key_col,
            model_key=model_key,
            cache_path=train_cache_path,
            split_label="train",
        )
        test_pred = _align_cached_predictions(
            frame=test_frame,
            split_raw=test_raw,
            split_key_col=split_key_col,
            model_key=model_key,
            cache_path=test_cache_path,
            split_label="test",
        )
        _log(
            f"[Compare] Reusing cached predictions for {cache_label}: "
            f"train={train_cache_path.name}, test={test_cache_path.name}"
        )
        return train_pred, test_pred
    except Exception as exc:
        _log(
            f"[Warn] Failed to reuse cached predictions for {cache_label}; "
            f"fallback to model inference. reason={exc}"
        )
        return None, None


def _model_name_from_cfg(cfg: dict) -> str:
    model_list = list(cfg.get("model_list") or [])
    model_categories = list(cfg.get("model_categories") or [])
    if len(model_list) == 1 and len(model_categories) == 1:
        return f"{model_list[0]}_{model_categories[0]}"
    model_name = str(cfg.get("model_name") or "").strip()
    if model_name:
        return model_name
    raise ValueError("Unable to resolve model_name from config.")


def _row_signature(row: dict, value_cols: List[str]) -> bytes:
    hasher = hashlib.blake2b(digest_size=16)
    for col in value_cols:
        value = row.get(col, "")
        hasher.update(str(value).encode("utf-8", errors="ignore"))
        hasher.update(b"\x1f")
    return hasher.digest()


def _check_and_maybe_dedupe_csv(path: Path, key_col: str = "_row_id") -> Dict[str, Any]:
    stats: Dict[str, Any] = {
        "path": str(path),
        "key_col": key_col,
        "rows": 0,
        "duplicate_rows": 0,
        "conflicting_duplicate_keys": [],
        "removed_rows": 0,
        "action": "skipped",
    }

    with path.open("r", encoding="utf-8-sig", newline="") as f:
        reader = csv.DictReader(f)
        fieldnames = list(reader.fieldnames or [])
        if key_col not in fieldnames:
            stats["action"] = "missing_key"
            return stats

        value_cols = [c for c in fieldnames if c != key_col]
        key_signatures: Dict[str, bytes] = {}

        for row in reader:
            stats["rows"] += 1
            key = str(row.get(key_col, ""))
            sig = _row_signature(row, value_cols)

            prev = key_signatures.get(key)
            if prev is None:
                key_signatures[key] = sig
                continue

            stats["duplicate_rows"] += 1
            if prev != sig and len(stats["conflicting_duplicate_keys"]) < 5:
                stats["conflicting_duplicate_keys"].append(key)

    if stats["duplicate_rows"] == 0:
        stats["action"] = "no_duplicates"
        return stats

    if stats["conflicting_duplicate_keys"]:
        stats["action"] = "duplicates_not_identical"
        return stats

    fd, tmp_name = tempfile.mkstemp(
        prefix=path.stem + "_dedupe_",
        suffix=path.suffix,
        dir=str(path.parent),
    )
    os.close(fd)
    tmp_path = Path(tmp_name)

    try:
        seen_keys = set()
        with path.open("r", encoding="utf-8-sig", newline="") as src, tmp_path.open(
            "w",
            encoding="utf-8",
            newline="",
        ) as dst:
            reader = csv.DictReader(src)
            writer = csv.DictWriter(dst, fieldnames=list(reader.fieldnames or []))
            writer.writeheader()

            for row in reader:
                key = str(row.get(key_col, ""))
                if key in seen_keys:
                    stats["removed_rows"] += 1
                    continue
                seen_keys.add(key)
                writer.writerow(row)

        os.replace(tmp_path, path)
        stats["action"] = "deduped_identical"
        return stats
    finally:
        if tmp_path.exists():
            tmp_path.unlink(missing_ok=True)


def precheck_prediction_cache_duplicates(
    *,
    cfg_path: str,
    model_key: str,
    key_col: str = "_row_id",
    label: Optional[str] = None,
) -> List[Dict[str, Any]]:
    """Check prediction-cache CSVs and dedupe identical duplicate key rows."""

    cfg_path_obj = Path(cfg_path).expanduser().resolve()
    cfg = _read_json_config(cfg_path_obj)
    model_name = _model_name_from_cfg(cfg)
    cache_paths = _resolve_prediction_cache_paths(
        cfg=cfg,
        cfg_path=cfg_path_obj,
        model_name=model_name,
        model_key=model_key,
    )
    cache_label = str(label or model_key)
    if cache_paths == (None, None):
        _log(f"[Precheck:{cache_label}] no prediction cache found or cache_predictions=false")
        return []

    results: List[Dict[str, Any]] = []
    for split_label, cache_path in zip(("train", "test"), cache_paths):
        if cache_path is None:
            result = {
                "split": split_label,
                "action": "missing_cache",
                "path": None,
                "key_col": key_col,
            }
            results.append(result)
            _log(f"[Precheck:{cache_label}] missing {split_label} cache file")
            continue

        if cache_path.suffix.lower() != ".csv":
            result = {
                "split": split_label,
                "action": "skipped_non_csv",
                "path": str(cache_path),
                "key_col": key_col,
            }
            results.append(result)
            _log(
                f"[Precheck:{cache_label}] skip {split_label}: "
                f"only csv is handled, file={cache_path.name}"
            )
            continue

        stats = _check_and_maybe_dedupe_csv(cache_path, key_col=key_col)
        stats["split"] = split_label
        results.append(stats)
        action = stats["action"]
        if action == "deduped_identical":
            _log(
                f"[Precheck:{cache_label}] {split_label}: deduped identical {key_col}; "
                f"removed={stats['removed_rows']} file={cache_path}"
            )
        elif action == "duplicates_not_identical":
            _log(
                f"[Precheck:{cache_label}] {split_label}: duplicate {key_col} has "
                "non-identical rows, keep file unchanged; "
                f"sample_keys={stats['conflicting_duplicate_keys']} file={cache_path}"
            )
        elif action == "no_duplicates":
            _log(f"[Precheck:{cache_label}] {split_label}: no duplicate {key_col}; file={cache_path}")
        elif action == "missing_key":
            _log(
                f"[Precheck:{cache_label}] {split_label}: key column {key_col!r} "
                f"not found, skip; file={cache_path}"
            )
        else:
            _log(f"[Precheck:{cache_label}] {split_label}: action={action}; file={cache_path}")

    return results


def _has_valid_cached_predictions(
    *,
    split_df: pd.DataFrame,
    pred_values: Optional[np.ndarray],
) -> bool:
    if len(split_df) == 0:
        return True
    if pred_values is None:
        return False
    return int(len(pred_values)) == int(len(split_df))


def run_compare_ft_embed(
    *,
    direct_cfg_path: str,
    ft_cfg_path: str,
    ft_embed_cfg_path: str,
    model_key: str,
    label_direct: str,
    label_ft: str,
    use_runtime_ft_embedding: bool = False,
    n_bins_override: Optional[int] = 10,
    train_data_path: Optional[str] = None,
    test_data_path: Optional[str] = None,
    direct_model_path: Optional[str] = None,
    ft_embed_model_path: Optional[str] = None,
    ft_model_path: Optional[str] = None,
    model_search_dir: Optional[str] = None,
) -> str:
    direct_cfg_path = Path(direct_cfg_path).resolve()
    ft_cfg_path = Path(ft_cfg_path).resolve()
    ft_embed_cfg_path = Path(ft_embed_cfg_path).resolve()

    direct_cfg = _read_json_config(direct_cfg_path)
    ft_embed_cfg = _read_json_config(ft_embed_cfg_path)
    ft_cfg = _read_json_config(ft_cfg_path)

    model_name = f"{direct_cfg['model_list'][0]}_{direct_cfg['model_categories'][0]}"
    search_roots = _build_search_roots(
        model_search_dir,
        direct_cfg_path.parent,
        ft_cfg_path.parent,
        ft_embed_cfg_path.parent,
        Path.cwd(),
    )

    train_raw, test_raw, raw, use_explicit_split = load_raw_splits(
        split_cfg=direct_cfg,
        data_cfg=direct_cfg,
        data_cfg_path=direct_cfg_path,
        model_name=model_name,
        train_data_path=train_data_path,
        test_data_path=test_data_path,
        data_path_resolver=_resolve_data_path,
    )

    split_key_col = str(
        direct_cfg.get("split_cache_key_col")
        or ft_embed_cfg.get("split_cache_key_col")
        or "_row_id"
    ).strip() or "_row_id"
    cached_direct_train, cached_direct_test = _try_load_cached_predictions(
        cfg=direct_cfg,
        cfg_path=direct_cfg_path,
        model_name=model_name,
        model_key=model_key,
        train_raw=train_raw,
        test_raw=test_raw,
        split_key_col=split_key_col,
        cache_label="direct",
    )
    cached_ft_train, cached_ft_test = _try_load_cached_predictions(
        cfg=ft_embed_cfg,
        cfg_path=ft_embed_cfg_path,
        model_name=model_name,
        model_key=model_key,
        train_raw=train_raw,
        test_raw=test_raw,
        split_key_col=split_key_col,
        cache_label="ft_embed",
    )

    use_cached_direct = _has_valid_cached_predictions(
        split_df=train_raw, pred_values=cached_direct_train
    ) and _has_valid_cached_predictions(split_df=test_raw, pred_values=cached_direct_test)
    use_cached_ft = _has_valid_cached_predictions(
        split_df=train_raw, pred_values=cached_ft_train
    ) and _has_valid_cached_predictions(split_df=test_raw, pred_values=cached_ft_test)

    train_df: Optional[pd.DataFrame] = None
    test_df: Optional[pd.DataFrame] = None
    if not use_cached_ft:
        train_df, test_df = build_ft_embedding_frames(
            use_runtime_ft_embedding=use_runtime_ft_embedding,
            train_raw=train_raw,
            test_raw=test_raw,
            raw=raw,
            use_explicit_split=use_explicit_split,
            model_name=model_name,
            ft_cfg=ft_cfg,
            ft_cfg_path=ft_cfg_path,
            search_roots=search_roots,
            ft_model_path=ft_model_path,
            embed_cfg=ft_embed_cfg,
            embed_cfg_path=ft_embed_cfg_path,
            embed_path_resolver=_resolve_data_path,
        )

    direct_output_root = Path(_resolve_output_dir(direct_cfg, direct_cfg_path)).resolve()
    ft_embed_output_root = Path(_resolve_output_dir(ft_embed_cfg, ft_embed_cfg_path)).resolve()
    direct_output_override = None
    ft_output_override = None
    if not use_cached_direct:
        direct_output_override = resolve_model_output_override(
            model_name=model_name,
            model_key=model_key,
            model_path=direct_model_path,
            search_roots=search_roots,
            output_root=direct_output_root,
            label="direct_model_path",
        )
    if not use_cached_ft:
        ft_output_override = resolve_model_output_override(
            model_name=model_name,
            model_key=model_key,
            model_path=ft_embed_model_path,
            search_roots=search_roots,
            output_root=ft_embed_output_root,
            label="ft_embed_model_path",
        )

    direct_predictor = None
    ft_predictor = None
    if not use_cached_direct:
        direct_predictor = _load_predictor_from_cfg(
            direct_cfg_path,
            model_key,
            model_name=model_name,
            output_dir=direct_output_override,
        )
    if not use_cached_ft:
        ft_predictor = _load_predictor_from_cfg(
            ft_embed_cfg_path,
            model_key,
            model_name=model_name,
            output_dir=ft_output_override,
        )

    if len(train_raw) > 0:
        if use_cached_direct:
            pred_direct_train = np.asarray(cached_direct_train, dtype=float).reshape(-1)
        else:
            assert direct_predictor is not None
            pred_direct_train = np.asarray(direct_predictor.predict(train_raw)).reshape(-1)
        if use_cached_ft:
            pred_ft_train = np.asarray(cached_ft_train, dtype=float).reshape(-1)
        else:
            if ft_predictor is None or train_df is None:
                raise RuntimeError("FT predictor/train embedding frame is not initialized.")
            pred_ft_train = np.asarray(ft_predictor.predict(train_df)).reshape(-1)

        if len(pred_direct_train) != len(train_raw):
            raise ValueError("Train prediction length mismatch for direct model.")
        if len(pred_ft_train) != len(train_raw):
            raise ValueError("Train prediction length mismatch for FT-embed model.")
    else:
        pred_direct_train = np.asarray([], dtype=float)
        pred_ft_train = np.asarray([], dtype=float)

    if len(test_raw) > 0:
        if use_cached_direct:
            pred_direct_test = np.asarray(cached_direct_test, dtype=float).reshape(-1)
        else:
            assert direct_predictor is not None
            pred_direct_test = np.asarray(direct_predictor.predict(test_raw)).reshape(-1)
        if use_cached_ft:
            pred_ft_test = np.asarray(cached_ft_test, dtype=float).reshape(-1)
        else:
            if ft_predictor is None or test_df is None:
                raise RuntimeError("FT predictor/test embedding frame is not initialized.")
            pred_ft_test = np.asarray(ft_predictor.predict(test_df)).reshape(-1)

        if len(pred_direct_test) != len(test_raw):
            raise ValueError("Test prediction length mismatch for direct model.")
        if len(pred_ft_test) != len(test_raw):
            raise ValueError("Test prediction length mismatch for FT-embed model.")
    else:
        pred_direct_test = np.asarray([], dtype=float)
        pred_ft_test = np.asarray([], dtype=float)

    plot_train = train_raw.copy()
    plot_test = test_raw.copy()
    if len(plot_train) > 0:
        plot_train["pred_direct"] = pred_direct_train
        plot_train["pred_ft"] = pred_ft_train
    if len(plot_test) > 0:
        plot_test["pred_direct"] = pred_direct_test
        plot_test["pred_ft"] = pred_ft_test

    weight_col = direct_cfg["weight"]
    target_col = direct_cfg["target"]
    if weight_col not in plot_train.columns:
        plot_train[weight_col] = 1.0
    if weight_col not in plot_test.columns:
        plot_test[weight_col] = 1.0
    if target_col in plot_train.columns:
        plot_train["w_act"] = plot_train[target_col] * plot_train[weight_col]
    if target_col in plot_test.columns:
        plot_test["w_act"] = plot_test[target_col] * plot_test[weight_col]

    train_ready = "w_act" in plot_train.columns and not plot_train["w_act"].isna().all()
    test_ready = "w_act" in plot_test.columns and not plot_test["w_act"].isna().all()
    if not train_ready and not test_ready:
        _log("[Plot] Missing target values in train split; skip plots.")
        return "Skipped plotting due to missing target values."

    n_bins = n_bins_override or direct_cfg.get("plot", {}).get("n_bins", 10)
    datasets = []
    if train_ready:
        datasets.append(("Train Data", plot_train))
    if test_ready:
        datasets.append(("Validation Data", plot_test))

    style = PlotStyle()
    fig, axes = plt.subplots(1, len(datasets), figsize=DOUBLE_LIFT_FIGSIZE)
    if len(datasets) == 1:
        axes = [axes]
    for ax, (title, data) in zip(axes, datasets):
        plot_double_lift_curve(
            data["pred_direct"].values,
            data["pred_ft"].values,
            data["w_act"].values,
            data[weight_col].values,
            n_bins=n_bins,
            title=f"Double Lift Chart on {title}",
            label1=label_direct,
            label2=label_ft,
            pred1_weighted=False,
            pred2_weighted=False,
            actual_weighted=True,
            ax=ax,
            show=False,
            style=style,
        )
    plt.subplots_adjust(wspace=0.3)

    save_root = _resolve_double_lift_dir(model_name=model_name)
    filename = (
        f"double_lift_compare_{_safe_tag(model_key)}_{model_name}_"
        f"{_safe_tag(label_direct)}_vs_{_safe_tag(label_ft)}.png"
    )
    save_path = (save_root / filename).resolve()
    finalize_figure(fig, save_path=str(save_path), show=False, style=style)
    _log(f"Double lift saved to: {save_path}")
    return str(save_path)


def run_double_lift_from_file(
    *,
    data_path: str,
    train_data_path: Optional[str] = None,
    test_data_path: Optional[str] = None,
    pred_col_1: str,
    pred_col_2: str,
    target_col: str,
    weight_col: str = "weights",
    n_bins: int = 10,
    label1: Optional[str] = None,
    label2: Optional[str] = None,
    pred1_weighted: bool = False,
    pred2_weighted: bool = False,
    actual_weighted: bool = False,
    holdout_ratio: Optional[float] = 0.0,
    split_strategy: str = "random",
    split_group_col: Optional[str] = None,
    split_time_col: Optional[str] = None,
    split_time_ascending: bool = True,
    rand_seed: int = 13,
    split_cache_path: Optional[str] = None,
    split_cache_force_rebuild: bool = False,
    output_path: Optional[str] = None,
) -> str:
    explicit_train_path = str(train_data_path or "").strip()
    explicit_test_path = str(test_data_path or "").strip()
    use_explicit_split = bool(explicit_train_path or explicit_test_path)

    data_path_obj: Optional[Path] = None
    if not use_explicit_split:
        data_path_obj = Path(data_path).resolve()
        if not data_path_obj.exists():
            raise FileNotFoundError(f"Data file not found: {data_path_obj}")

    pred_col_1 = str(pred_col_1 or "").strip()
    pred_col_2 = str(pred_col_2 or "").strip()
    target_col = str(target_col or "").strip()
    weight_col = str(weight_col or "").strip() or "weights"
    if not pred_col_1:
        raise ValueError("pred_col_1 is required.")
    if not pred_col_2:
        raise ValueError("pred_col_2 is required.")
    if not target_col:
        raise ValueError("target_col is required.")

    label1 = str(label1 or pred_col_1).strip() or pred_col_1
    label2 = str(label2 or pred_col_2).strip() or pred_col_2

    required_cols = [pred_col_1, pred_col_2, target_col, weight_col]

    def _load_and_validate(path_obj: Path, label: str) -> pd.DataFrame:
        frame = pd.read_csv(path_obj, low_memory=False)
        frame = _drop_duplicate_columns(frame, label).reset_index(drop=True)
        if weight_col not in frame.columns:
            _log(f"[Info] weight_col={weight_col!r} not found in {label}. Using constant 1.0.")
            frame[weight_col] = 1.0
        missing_cols = [c for c in required_cols if c not in frame.columns]
        if missing_cols:
            raise KeyError(f"{label} missing required columns: {missing_cols}")
        target_na_before = int(frame[target_col].isna().sum())
        frame[target_col] = pd.to_numeric(frame[target_col], errors="coerce").fillna(0.0)
        if target_na_before > 0:
            _log(f"[Data] {label}: filled {target_na_before} NA in {target_col} with 0.")
        frame[weight_col] = pd.to_numeric(frame[weight_col], errors="coerce").fillna(1.0)
        for pred_col in (pred_col_1, pred_col_2):
            pred_numeric = pd.to_numeric(frame[pred_col], errors="coerce")
            pred_na = int(pred_numeric.isna().sum())
            if pred_na > 0:
                raise ValueError(
                    f"{label}: {pred_col} contains {pred_na} non-numeric/NA rows; "
                    "please clean prediction columns before plotting."
                )
            frame[pred_col] = pred_numeric
        if frame.empty:
            raise ValueError(f"{label} is empty.")
        return frame

    split_group_col = str(split_group_col or "").strip() or None
    split_time_col = str(split_time_col or "").strip() or None
    split_strategy = str(split_strategy or "random").strip().lower() or "random"
    holdout_ratio_val = 0.0 if holdout_ratio is None else float(holdout_ratio)

    datasets = []
    if use_explicit_split:
        if explicit_train_path:
            train_obj = Path(explicit_train_path).resolve()
            if not train_obj.exists():
                raise FileNotFoundError(f"train_data_path not found: {train_obj}")
            datasets.append(("Train Data", _load_and_validate(train_obj, "double_lift_train")))
        if explicit_test_path:
            test_obj = Path(explicit_test_path).resolve()
            if not test_obj.exists():
                raise FileNotFoundError(f"test_data_path not found: {test_obj}")
            datasets.append(("Validation Data", _load_and_validate(test_obj, "double_lift_test")))
    else:
        assert data_path_obj is not None
        raw = _load_and_validate(data_path_obj, "double_lift_raw")
        if holdout_ratio_val > 0:
            split_cache_obj = resolve_model_scoped_path(
                split_cache_path,
                model_name=_safe_tag(data_path_obj.stem),
                base_dir=data_path_obj.parent,
            )
            strategy_norm = split_strategy.strip().lower() or "random"

            def _split_and_optionally_write_cache() -> tuple[pd.DataFrame, pd.DataFrame]:
                train_local, test_local = _split_train_test(
                    raw,
                    holdout_ratio=holdout_ratio_val,
                    strategy=split_strategy,
                    group_col=split_group_col,
                    stratify_col=target_col,
                    time_col=split_time_col,
                    time_ascending=bool(split_time_ascending),
                    rand_seed=int(rand_seed),
                    reset_index_mode="none",
                    ratio_label="holdout_ratio",
                )
                if split_cache_obj is not None:
                    train_idx_local = np.asarray(
                        train_local.index.to_numpy(), dtype=np.int64
                    ).reshape(-1)
                    test_idx_local = np.asarray(
                        test_local.index.to_numpy(), dtype=np.int64
                    ).reshape(-1)
                    validate_split_indices(
                        train_idx=train_idx_local,
                        test_idx=test_idx_local,
                        row_count=len(raw),
                        cache_path=split_cache_obj,
                    )
                    write_split_cache(
                        split_cache_obj,
                        train_idx=train_idx_local,
                        test_idx=test_idx_local,
                        row_count=len(raw),
                        meta={
                            "split_strategy": strategy_norm,
                            "split_stratify_col": target_col,
                            "holdout_ratio": holdout_ratio_val,
                            "rand_seed": rand_seed,
                            "data_path": str(data_path_obj),
                        },
                    )
                    _log(f"[Split] Created split cache: {split_cache_obj}")
                return train_local, test_local

            if (
                split_cache_obj is not None
                and split_cache_obj.exists()
                and not bool(split_cache_force_rebuild)
            ):
                train_idx, test_idx, cached_row_count, cache_meta = load_split_cache(
                    split_cache_obj
                )
                validate_split_cache_metadata(
                    cache_path=split_cache_obj,
                    cached_row_count=cached_row_count,
                    current_row_count=len(raw),
                    cache_meta=cache_meta,
                    split_strategy=strategy_norm,
                    holdout_ratio=holdout_ratio_val,
                    rand_seed=rand_seed,
                    split_stratify_col=target_col,
                    rebuild_hint=True,
                )
                validate_split_indices(
                    train_idx=train_idx,
                    test_idx=test_idx,
                    row_count=len(raw),
                    cache_path=split_cache_obj,
                )
                train_df = raw.iloc[train_idx].copy()
                test_df = raw.iloc[test_idx].copy()
                _log(f"[Split] Reused split cache: {split_cache_obj}")
            else:
                train_df, test_df = _split_and_optionally_write_cache()

            train_df = _drop_duplicate_columns(train_df, "double_lift_train")
            test_df = _drop_duplicate_columns(test_df, "double_lift_test")
            if len(train_df) > 0:
                datasets.append(("Train Data", train_df))
            if len(test_df) > 0:
                datasets.append(("Validation Data", test_df))
        else:
            datasets.append(("All Data", raw))

    if not datasets:
        raise ValueError("No dataset is available for plotting.")

    style = PlotStyle()
    fig, axes = plt.subplots(1, len(datasets), figsize=(11, 5))
    if len(datasets) == 1:
        axes = [axes]

    for ax, (title, data) in zip(axes, datasets):
        plot_double_lift_curve(
            data[pred_col_1].values,
            data[pred_col_2].values,
            data[target_col].values,
            data[weight_col].values,
            n_bins=int(n_bins),
            title=f"Double Lift Chart on {title}",
            label1=label1,
            label2=label2,
            pred1_weighted=bool(pred1_weighted),
            pred2_weighted=bool(pred2_weighted),
            actual_weighted=bool(actual_weighted),
            ax=ax,
            show=False,
            style=style,
        )
    plt.subplots_adjust(wspace=0.3)

    if output_path:
        save_path = Path(output_path).resolve()
    else:
        if use_explicit_split:
            if explicit_train_path and explicit_test_path:
                source_tag = (
                    f"{_safe_tag(Path(explicit_train_path).stem)}_and_"
                    f"{_safe_tag(Path(explicit_test_path).stem)}"
                )
            elif explicit_train_path:
                source_tag = _safe_tag(Path(explicit_train_path).stem)
            elif explicit_test_path:
                source_tag = _safe_tag(Path(explicit_test_path).stem)
            else:
                source_tag = "explicit_split"
            split_tag = "explicit_split"
            model_dir_tag = source_tag
        else:
            source_tag = _safe_tag(data_path_obj.stem) if data_path_obj is not None else "raw"
            split_tag = "train_valid" if holdout_ratio_val > 0 else "all"
            model_dir_tag = source_tag
        filename = (
            f"double_lift_file_{source_tag}_"
            f"{_safe_tag(label1)}_vs_{_safe_tag(label2)}_{split_tag}.png"
        )
        save_path = (_resolve_double_lift_dir(model_name=model_dir_tag) / filename).resolve()

    save_path.parent.mkdir(parents=True, exist_ok=True)
    finalize_figure(fig, save_path=str(save_path), show=False, style=style)
    _log(f"Double lift saved to: {save_path}")
    return str(save_path)


def run_double_lift_multi_models(
    *,
    data_path: str,
    model_specs: List[Dict[str, Any]],
    target_col: str,
    weight_col: str = "weights",
    n_bins: int = 10,
    holdout_ratio: Optional[float] = 0.25,
    split_strategy: str = "random",
    split_group_col: Optional[str] = None,
    split_time_col: Optional[str] = None,
    split_time_ascending: bool = True,
    rand_seed: int = 13,
    split_scope: str = "both",
    output_dir: Optional[str] = None,
    train_data_path: Optional[str] = None,
    test_data_path: Optional[str] = None,
    actual_weighted: bool = False,
) -> str:
    """Compare all model pairs with double-lift plots on train/validation splits.

    Each model spec supports either:
    1) ``loader='artifact_file'`` with ``path`` to a pickled model artifact.
    2) ``loader='config_predictor'`` with ``config_path`` + ``model_key``.
    """

    target_col = str(target_col or "").strip()
    weight_col = str(weight_col or "").strip() or "weights"
    if not target_col:
        raise ValueError("target_col is required.")
    if len(model_specs) < 2:
        raise ValueError("At least two model_specs are required.")

    def _resolve_path(path_like: Any) -> Path:
        return Path(str(path_like)).expanduser().resolve()

    def _load_and_validate(path_obj: Path, label: str) -> pd.DataFrame:
        if not path_obj.exists():
            raise FileNotFoundError(f"{label} not found: {path_obj}")
        frame = pd.read_csv(path_obj, low_memory=False)
        frame = _drop_duplicate_columns(frame, label).reset_index(drop=True)
        if weight_col not in frame.columns:
            _log(f"[Info] weight_col={weight_col!r} not found in {label}. Using constant 1.0.")
            frame[weight_col] = 1.0
        required_cols = [target_col, weight_col]
        missing_cols = [c for c in required_cols if c not in frame.columns]
        if missing_cols:
            raise KeyError(f"{label} missing required columns: {missing_cols}")
        target_na_before = int(frame[target_col].isna().sum())
        frame[target_col] = pd.to_numeric(frame[target_col], errors="coerce").fillna(0.0)
        if target_na_before > 0:
            _log(f"[Data] {label}: filled {target_na_before} NA in {target_col} with 0.")
        frame[weight_col] = pd.to_numeric(frame[weight_col], errors="coerce").fillna(1.0)
        if frame.empty:
            raise ValueError(f"{label} is empty.")
        return frame

    def _build_predict_fn(spec: Dict[str, Any]) -> Callable[[pd.DataFrame], np.ndarray]:
        loader = str(spec.get("loader", "artifact_file")).strip().lower()
        name = str(spec.get("name", "")).strip() or "<unnamed>"

        if loader == "artifact_file":
            if joblib is None:
                raise ImportError(
                    "artifact_file comparison requires joblib. "
                    "Install with: pip install 'ins_pricing[bayesopt]' "
                    f"(original error: {_JOBLIB_IMPORT_ERROR!r})"
                )
            model_path = _resolve_path(spec.get("path"))
            if not model_path.exists():
                raise FileNotFoundError(f"{name}: model file not found: {model_path}")

            payload = joblib.load(model_path)
            if isinstance(payload, dict) and "model" in payload:
                model = payload.get("model")
                preprocess_artifacts = payload.get("preprocess_artifacts") or {}
                payload_features = list(preprocess_artifacts.get("factor_nmes") or [])
            else:
                model = payload
                payload_features = []

            feature_list = list(spec.get("feature_list") or [])
            if bool(spec.get("feature_list_from_payload", True)) and payload_features:
                feature_list = payload_features

            task_type = str(spec.get("task_type", "regression")).strip().lower()
            use_predict_proba = bool(spec.get("use_predict_proba", False))

            def _predict(df: pd.DataFrame) -> np.ndarray:
                X = df
                if feature_list:
                    missing = [c for c in feature_list if c not in df.columns]
                    if missing:
                        raise KeyError(f"{name}: missing required features: {missing[:10]}")
                    X = df[feature_list]

                if task_type in {"binary", "classification"} and use_predict_proba and hasattr(model, "predict_proba"):
                    pred = model.predict_proba(X)[:, 1]
                else:
                    pred = model.predict(X)
                return np.asarray(pred).reshape(-1)

            return _predict

        if loader == "config_predictor":
            config_path = _resolve_path(spec.get("config_path"))
            model_key = str(spec.get("model_key", "")).strip().lower()
            if not model_key:
                raise ValueError(f"{name}: model_key is required for config_predictor loader.")
            predictor = _load_predictor_from_cfg(
                config_path=config_path,
                model_key=model_key,
                model_name=spec.get("model_name"),
            )

            def _predict(df: pd.DataFrame) -> np.ndarray:
                pred = predictor.predict(df)
                return np.asarray(pred).reshape(-1)

            return _predict

        raise ValueError(f"{name}: unsupported loader={loader!r}.")

    explicit_train_path = str(train_data_path or "").strip()
    explicit_test_path = str(test_data_path or "").strip()
    use_explicit_split = bool(explicit_train_path or explicit_test_path)

    datasets: List[tuple[str, str, pd.DataFrame]] = []
    data_path_obj: Optional[Path] = None
    if use_explicit_split:
        if explicit_train_path:
            train_obj = _resolve_path(explicit_train_path)
            datasets.append(("train", "Train Data", _load_and_validate(train_obj, "multi_compare_train")))
        if explicit_test_path:
            test_obj = _resolve_path(explicit_test_path)
            datasets.append(("valid", "Validation Data", _load_and_validate(test_obj, "multi_compare_valid")))
    else:
        data_path_obj = _resolve_path(data_path)
        raw = _load_and_validate(data_path_obj, "multi_compare_raw")
        holdout_ratio_val = 0.0 if holdout_ratio is None else float(holdout_ratio)
        if holdout_ratio_val > 0:
            train_df, test_df = _split_train_test(
                raw,
                holdout_ratio=holdout_ratio_val,
                strategy=str(split_strategy or "random").strip().lower() or "random",
                group_col=str(split_group_col or "").strip() or None,
                stratify_col=target_col,
                time_col=str(split_time_col or "").strip() or None,
                time_ascending=bool(split_time_ascending),
                rand_seed=int(rand_seed),
                reset_index_mode="none",
                ratio_label="holdout_ratio",
            )
            train_df = _drop_duplicate_columns(train_df, "multi_compare_train")
            test_df = _drop_duplicate_columns(test_df, "multi_compare_valid")
            if len(train_df) > 0:
                datasets.append(("train", "Train Data", train_df.reset_index(drop=True)))
            if len(test_df) > 0:
                datasets.append(("valid", "Validation Data", test_df.reset_index(drop=True)))
        else:
            datasets.append(("all", "All Data", raw.reset_index(drop=True)))

    if not datasets:
        raise ValueError("No dataset is available for multi-model comparison.")

    raw_split_scope = str(split_scope or "both").strip().lower()
    split_scope_aliases = {
        "both": "both",
        "all": "both",
        "train": "train",
        "model": "train",
        "training": "train",
        "valid": "valid",
        "val": "valid",
        "validation": "valid",
        "test": "valid",
    }
    normalized_split_scope = split_scope_aliases.get(raw_split_scope)
    if normalized_split_scope is None:
        raise ValueError(
            f"Unsupported split_scope={raw_split_scope!r}. "
            "Use one of: train, valid, both."
        )
    if normalized_split_scope == "train":
        datasets = [item for item in datasets if item[0] == "train"]
    elif normalized_split_scope == "valid":
        datasets = [item for item in datasets if item[0] == "valid"]
    if not datasets:
        raise ValueError(f"No datasets available after split_scope filtering: {normalized_split_scope}.")
    _log(
        f"[MultiCompare] split_scope={normalized_split_scope}, "
        f"datasets={[title for _tag, title, _df in datasets]}"
    )

    predict_fns: Dict[str, Callable[[pd.DataFrame], np.ndarray]] = {}
    pred_weighted_map: Dict[str, bool] = {}
    for spec in model_specs:
        name = str(spec.get("name", "")).strip()
        if not name:
            raise ValueError("Each model spec must include a non-empty 'name'.")
        if name in predict_fns:
            raise ValueError(f"Duplicate model spec name: {name}")
        predict_fns[name] = _build_predict_fn(spec)
        pred_weighted_map[name] = bool(spec.get("pred_weighted", False))

    model_names = list(predict_fns.keys())
    pairs = list(combinations(model_names, 2))
    if not pairs:
        raise ValueError("No model pairs available for comparison.")

    if output_dir:
        save_root = _resolve_path(output_dir)
    else:
        default_model_tag = (
            _safe_tag(data_path_obj.stem)
            if data_path_obj is not None
            else "multi_model_compare"
        )
        save_root = _resolve_double_lift_dir(model_name=default_model_tag)
    save_root.mkdir(parents=True, exist_ok=True)

    n_pairs = len(pairs)
    n_cols = 2 if n_pairs > 1 else 1
    n_rows = math.ceil(n_pairs / n_cols)
    style = PlotStyle()

    for split_tag, split_title, df in datasets:
        pred_map: Dict[str, np.ndarray] = {}
        for model_name in model_names:
            pred_vals = np.asarray(predict_fns[model_name](df), dtype=float).reshape(-1)
            if len(pred_vals) != len(df):
                raise ValueError(
                    f"{model_name}: prediction length mismatch on {split_tag} "
                    f"({len(pred_vals)} != {len(df)})"
                )
            pred_map[model_name] = pred_vals

        fig, axes = plt.subplots(n_rows, n_cols, figsize=(8 * n_cols, 5 * n_rows), squeeze=False)
        axes_flat = axes.flatten()
        actual = df[target_col].to_numpy()
        weight = df[weight_col].to_numpy()

        for i, (name_1, name_2) in enumerate(pairs):
            ax = axes_flat[i]
            plot_double_lift_curve(
                pred_map[name_1],
                pred_map[name_2],
                actual,
                weight,
                n_bins=int(n_bins),
                title=f"{split_title}: {name_1} vs {name_2}",
                label1=name_1,
                label2=name_2,
                pred1_weighted=pred_weighted_map.get(name_1, False),
                pred2_weighted=pred_weighted_map.get(name_2, False),
                actual_weighted=bool(actual_weighted),
                ax=ax,
                show=False,
                style=style,
            )

        for j in range(n_pairs, len(axes_flat)):
            axes_flat[j].axis("off")

        model_tag = "_vs_".join(_safe_tag(name) for name in model_names)
        save_path = save_root / f"double_lift_multi_{model_tag}_{split_tag}.png"
        finalize_figure(fig, save_path=str(save_path), show=False, style=style)
        _log(f"Saved: {save_path}")

    return str(save_root)


def run_compare_direct_xgb_glm(
    *,
    xgb_cfg_path: str,
    glm_cfg_path: str,
    split_scope: str = "both",
    n_bins: int = 10,
    prefer_prediction_cache: bool = True,
    output_dir: Optional[str] = None,
    show_plots: bool = False,
    save_metric_csv: bool = True,
    actual_weighted: bool = False,
    tweedie_power: float = 1.5,
) -> Dict[str, Any]:
    """Compare direct XGB and direct GLM with aligned splits and double-lift plots.

    The workflow prefers train/test prediction caches generated during training
    and falls back to config-based live predictors when caches are unavailable.
    """

    def _model_name(cfg: dict) -> str:
        model_list = list(cfg.get("model_list") or [])
        model_categories = list(cfg.get("model_categories") or [])
        if len(model_list) != 1 or len(model_categories) != 1:
            raise ValueError(
                "Direct XGB/GLM comparison expects exactly one model_list "
                "and one model_categories entry."
            )
        return f"{model_list[0]}_{model_categories[0]}"

    def _required_columns(*cfgs: dict) -> List[str]:
        cols: List[str] = []
        for cfg in cfgs:
            cols.extend(str(c) for c in (cfg.get("feature_list") or []))
            for key in (
                "target",
                "weight",
                "split_cache_key_col",
                "split_stratify_col",
                "split_group_col",
                "split_time_col",
            ):
                value = cfg.get(key)
                if value is not None and str(value).strip():
                    cols.append(str(value).strip())
        return sorted(dict.fromkeys(cols))

    def _validate_prediction_length(
        name: str,
        split_name: str,
        pred: np.ndarray,
        frame: pd.DataFrame,
    ) -> None:
        if len(pred) != len(frame):
            raise ValueError(
                f"{name} {split_name} prediction length mismatch: "
                f"{len(pred)} != {len(frame)}"
            )
        if np.any(~np.isfinite(pred)):
            bad_count = int(np.sum(~np.isfinite(pred)))
            raise ValueError(
                f"{name} {split_name} predictions contain {bad_count} non-finite values."
            )

    def _metric_rows(
        split_name: str,
        frame: pd.DataFrame,
        pred_map: Dict[str, np.ndarray],
        *,
        target_col: str,
        weight_col: str,
    ) -> List[Dict[str, Any]]:
        y = pd.to_numeric(frame[target_col], errors="coerce").fillna(0.0).to_numpy(dtype=float)
        if weight_col in frame.columns:
            w = pd.to_numeric(frame[weight_col], errors="coerce").fillna(1.0).to_numpy(dtype=float)
        else:
            w = np.ones(len(frame), dtype=float)
        rows: List[Dict[str, Any]] = []
        for model_label, pred in pred_map.items():
            pred_arr = np.asarray(pred, dtype=float).reshape(-1)
            weight_sum = float(np.sum(w))
            rows.append(
                {
                    "split": split_name,
                    "model": model_label,
                    "rows": int(len(frame)),
                    "weight_sum": weight_sum,
                    "weighted_actual_mean": (
                        float(np.average(y, weights=w)) if weight_sum > 0 else np.nan
                    ),
                    "weighted_pred_mean": (
                        float(np.average(pred_arr, weights=w)) if weight_sum > 0 else np.nan
                    ),
                    "weighted_mae": mae(y, pred_arr, sample_weight=w),
                    "tweedie_deviance": tweedie_deviance(
                        y,
                        pred_arr,
                        sample_weight=w,
                        power=float(tweedie_power),
                    ),
                }
            )
        return rows

    def _selected_splits() -> List[Tuple[str, str, pd.DataFrame, np.ndarray, np.ndarray]]:
        normalized = str(split_scope or "both").strip().lower()
        if normalized in {"both", "all"}:
            return [
                ("train", "Train Data", train_raw, pred_xgb_train, pred_glm_train),
                ("valid", "Validation Data", valid_raw, pred_xgb_valid, pred_glm_valid),
            ]
        if normalized in {"train", "training"}:
            return [("train", "Train Data", train_raw, pred_xgb_train, pred_glm_train)]
        if normalized in {"valid", "val", "validation", "test"}:
            return [("valid", "Validation Data", valid_raw, pred_xgb_valid, pred_glm_valid)]
        raise ValueError("split_scope must be one of: train, valid, both")

    xgb_path = Path(xgb_cfg_path).expanduser().resolve()
    glm_path = Path(glm_cfg_path).expanduser().resolve()
    xgb_cfg = _read_json_config(xgb_path)
    glm_cfg = _read_json_config(glm_path)

    model_name = _model_name(xgb_cfg)
    glm_model_name = _model_name(glm_cfg)
    if model_name != glm_model_name:
        raise ValueError(f"Model name mismatch: xgb={model_name}, glm={glm_model_name}")

    for key in ("target", "weight"):
        if str(xgb_cfg.get(key)) != str(glm_cfg.get(key)):
            raise ValueError(
                f"Config mismatch for {key}: "
                f"xgb={xgb_cfg.get(key)!r}, glm={glm_cfg.get(key)!r}"
            )

    target_col = str(xgb_cfg.get("target") or "").strip()
    weight_col = str(xgb_cfg.get("weight") or "weights").strip() or "weights"
    split_key_col = str(
        xgb_cfg.get("split_cache_key_col")
        or glm_cfg.get("split_cache_key_col")
        or "_row_id"
    ).strip()

    xgb_data_path = _resolve_data_path(xgb_cfg, xgb_path, model_name)
    glm_data_path = _resolve_data_path(glm_cfg, glm_path, model_name)
    if xgb_data_path != glm_data_path:
        _log(
            "[Warn] XGB/GLM data paths differ; using XGB config as split source. "
            f"xgb={xgb_data_path}, glm={glm_data_path}"
        )

    train_raw, valid_raw, _raw_all, _ = load_raw_splits(
        split_cfg=xgb_cfg,
        data_cfg=xgb_cfg,
        data_cfg_path=xgb_path,
        model_name=model_name,
        train_data_path=None,
        test_data_path=None,
        required_columns=_required_columns(xgb_cfg, glm_cfg),
        data_path_resolver=_resolve_data_path,
    )
    _log(f"[DirectCompare] train_rows={len(train_raw)}, valid_rows={len(valid_raw)}")

    def _load_cached_pair(
        *,
        cfg: dict,
        cfg_path: Path,
        model_key: str,
        label: str,
    ) -> Tuple[Optional[np.ndarray], Optional[np.ndarray]]:
        if not bool(prefer_prediction_cache):
            return None, None
        return _try_load_cached_predictions(
            cfg=cfg,
            cfg_path=cfg_path,
            model_name=model_name,
            model_key=model_key,
            train_raw=train_raw,
            test_raw=valid_raw,
            split_key_col=split_key_col,
            cache_label=label,
        )

    def _predict_pair(
        *,
        cfg_path: Path,
        model_key: str,
        cached_train: Optional[np.ndarray],
        cached_valid: Optional[np.ndarray],
    ) -> Tuple[np.ndarray, np.ndarray, str]:
        if cached_train is not None and cached_valid is not None:
            return (
                np.asarray(cached_train, dtype=float).reshape(-1),
                np.asarray(cached_valid, dtype=float).reshape(-1),
                "cache",
            )

        predictor = _load_predictor_from_cfg(
            config_path=cfg_path,
            model_key=model_key,
            model_name=model_name,
        )
        pred_train = np.asarray(predictor.predict(train_raw), dtype=float).reshape(-1)
        pred_valid = np.asarray(predictor.predict(valid_raw), dtype=float).reshape(-1)
        return pred_train, pred_valid, "live_predictor"

    cached_xgb_train, cached_xgb_valid = _load_cached_pair(
        cfg=xgb_cfg,
        cfg_path=xgb_path,
        model_key="xgb",
        label="xgb_direct",
    )
    cached_glm_train, cached_glm_valid = _load_cached_pair(
        cfg=glm_cfg,
        cfg_path=glm_path,
        model_key="glm",
        label="glm_direct",
    )

    pred_xgb_train, pred_xgb_valid, xgb_source = _predict_pair(
        cfg_path=xgb_path,
        model_key="xgb",
        cached_train=cached_xgb_train,
        cached_valid=cached_xgb_valid,
    )
    pred_glm_train, pred_glm_valid, glm_source = _predict_pair(
        cfg_path=glm_path,
        model_key="glm",
        cached_train=cached_glm_train,
        cached_valid=cached_glm_valid,
    )
    _log(f"[DirectCompare] XGB source={xgb_source}; GLM source={glm_source}")

    _validate_prediction_length("XGB direct", "train", pred_xgb_train, train_raw)
    _validate_prediction_length("XGB direct", "valid", pred_xgb_valid, valid_raw)
    _validate_prediction_length("GLM direct", "train", pred_glm_train, train_raw)
    _validate_prediction_length("GLM direct", "valid", pred_glm_valid, valid_raw)

    metric_rows: List[Dict[str, Any]] = []
    metric_rows.extend(
        _metric_rows(
            "train",
            train_raw,
            {"XGB direct": pred_xgb_train, "GLM direct": pred_glm_train},
            target_col=target_col,
            weight_col=weight_col,
        )
    )
    metric_rows.extend(
        _metric_rows(
            "valid",
            valid_raw,
            {"XGB direct": pred_xgb_valid, "GLM direct": pred_glm_valid},
            target_col=target_col,
            weight_col=weight_col,
        )
    )
    metrics_df = pd.DataFrame(metric_rows)

    if output_dir:
        save_root = Path(output_dir).expanduser().resolve()
    else:
        save_root = (xgb_path.parent / "Results" / "plot" / model_name / "double_lift").resolve()
    save_root.mkdir(parents=True, exist_ok=True)

    metrics_path: Optional[Path] = None
    if bool(save_metric_csv):
        metrics_path = save_root / f"metrics_xgb_direct_vs_glm_direct_{model_name}.csv"
        metrics_df.to_csv(metrics_path, index=False)
        _log(f"[DirectCompare] Saved metrics: {metrics_path}")

    style = PlotStyle()
    saved_paths: List[Path] = []
    for split_tag, split_title, frame, pred_xgb, pred_glm in _selected_splits():
        if frame.empty:
            _log(f"[DirectCompare] Skip {split_title}; split is empty.")
            continue
        actual = pd.to_numeric(frame[target_col], errors="coerce").fillna(0.0).to_numpy(dtype=float)
        if weight_col in frame.columns:
            weight = pd.to_numeric(frame[weight_col], errors="coerce").fillna(1.0).to_numpy(dtype=float)
        else:
            weight = np.ones(len(frame), dtype=float)
        fig = plot_double_lift_curve(
            pred_xgb,
            pred_glm,
            actual,
            weight,
            n_bins=int(n_bins),
            title=f"{split_title}: XGB direct vs GLM direct",
            label1="XGB direct",
            label2="GLM direct",
            pred1_weighted=False,
            pred2_weighted=False,
            actual_weighted=bool(actual_weighted),
            show=False,
            style=style,
        )
        save_path = save_root / f"double_lift_xgb_direct_vs_glm_direct_{model_name}_{split_tag}.png"
        finalize_figure(fig, save_path=str(save_path), show=bool(show_plots), style=style)
        saved_paths.append(save_path)
        _log(f"[DirectCompare] Saved double lift: {save_path}")

    return {
        "output_dir": str(save_root),
        "metrics": metrics_df,
        "metrics_path": str(metrics_path) if metrics_path is not None else None,
        "plot_paths": [str(path) for path in saved_paths],
        "prediction_sources": {"xgb": xgb_source, "glm": glm_source},
        "model_name": model_name,
    }


def run_compare_current_model_vs_direct_xgb(
    *,
    xgb_cfg_path: str,
    current_model_col: str = "curr_model_result",
    xgb_pred_col: str = "pred_direct_xgb",
    n_bins: int = 10,
    output_dir: Optional[str] = None,
    show_plots: bool = False,
    actual_weighted: bool = False,
    split_cache_force_rebuild: Optional[bool] = None,
) -> Dict[str, Any]:
    """Compare an existing current-model prediction column against direct XGB."""

    cfg_path = Path(xgb_cfg_path).expanduser().resolve()
    cfg = _read_json_config(cfg_path)

    model_list = list(cfg.get("model_list") or [])
    model_categories = list(cfg.get("model_categories") or [])
    if len(model_list) != 1 or len(model_categories) != 1:
        raise ValueError("Current-vs-XGB comparison expects exactly one model and category.")
    model_name = f"{model_list[0]}_{model_categories[0]}"

    data_path = _resolve_data_path(cfg, cfg_path, model_name)
    if not data_path.exists():
        raise FileNotFoundError(f"Data file not found: {data_path}")

    target_col = str(cfg.get("target", "response") or "response").strip()
    weight_col = str(cfg.get("weight", "weights") or "weights").strip()
    current_col = str(current_model_col or "curr_model_result").strip()
    pred_col = str(xgb_pred_col or "pred_direct_xgb").strip()
    if not current_col:
        raise ValueError("current_model_col is required.")

    raw_full = _read_table(data_path)
    raw_full = _drop_duplicate_columns(raw_full, "current_vs_xgb_raw").reset_index(drop=True)
    if weight_col not in raw_full.columns:
        raw_full[weight_col] = 1.0

    missing_cols = [
        col for col in (current_col, target_col, weight_col)
        if col not in raw_full.columns
    ]
    if missing_cols:
        raise KeyError(f"Missing required columns in dataset: {missing_cols}")

    raw_full[target_col] = pd.to_numeric(raw_full[target_col], errors="coerce").fillna(0.0)
    raw_full[weight_col] = pd.to_numeric(raw_full[weight_col], errors="coerce").fillna(1.0)
    if raw_full.empty:
        raise ValueError("Raw dataset is empty.")

    holdout_ratio = float(cfg.get("holdout_ratio", cfg.get("prop_test", 0.25)))
    if holdout_ratio <= 0 or holdout_ratio >= 1:
        raise ValueError("holdout_ratio must be in (0, 1) to produce train/validation splits.")
    split_strategy = str(cfg.get("split_strategy", "random") or "random").strip().lower()
    split_cache_path = resolve_model_scoped_path(
        cfg.get("split_cache_path"),
        model_name=model_name,
        base_dir=cfg_path.parent,
    )
    force_rebuild = (
        bool(cfg.get("split_cache_force_rebuild", False))
        if split_cache_force_rebuild is None
        else bool(split_cache_force_rebuild)
    )

    if split_cache_path is not None and split_cache_path.exists() and not force_rebuild:
        train_idx, valid_idx, cached_row_count, cache_meta = load_split_cache(split_cache_path)
        validate_split_cache_metadata(
            cache_path=split_cache_path,
            cached_row_count=cached_row_count,
            current_row_count=len(raw_full),
            cache_meta=cache_meta,
            split_strategy=split_strategy,
            holdout_ratio=holdout_ratio,
            rand_seed=cfg.get("rand_seed", 13),
            split_stratify_col=target_col,
            rebuild_hint=True,
        )
        validate_split_indices(
            train_idx=train_idx,
            test_idx=valid_idx,
            row_count=len(raw_full),
            cache_path=split_cache_path,
        )
        train_df = raw_full.iloc[train_idx].copy()
        valid_df = raw_full.iloc[valid_idx].copy()
        _log(f"[CurrentVsXGB] Reused split cache: {split_cache_path}")
    else:
        train_df, valid_df = _split_train_test(
            raw_full,
            holdout_ratio=holdout_ratio,
            strategy=split_strategy,
            group_col=cfg.get("split_group_col"),
            stratify_col=target_col,
            time_col=cfg.get("split_time_col"),
            time_ascending=bool(cfg.get("split_time_ascending", True)),
            rand_seed=cfg.get("rand_seed", 13),
            reset_index_mode="none",
            ratio_label="holdout_ratio",
        )
        if split_cache_path is not None:
            train_idx = np.asarray(train_df.index.to_numpy(), dtype=np.int64).reshape(-1)
            valid_idx = np.asarray(valid_df.index.to_numpy(), dtype=np.int64).reshape(-1)
            validate_split_indices(
                train_idx=train_idx,
                test_idx=valid_idx,
                row_count=len(raw_full),
                cache_path=split_cache_path,
            )
            write_split_cache(
                split_cache_path,
                train_idx=train_idx,
                test_idx=valid_idx,
                row_count=len(raw_full),
                meta={
                    "split_strategy": split_strategy,
                    "split_stratify_col": target_col,
                    "holdout_ratio": holdout_ratio,
                    "rand_seed": cfg.get("rand_seed", 13),
                    "data_path": str(data_path),
                },
            )
            _log(f"[CurrentVsXGB] Created split cache: {split_cache_path}")

    train_df = train_df.reset_index(drop=True)
    valid_df = valid_df.reset_index(drop=True)
    if train_df.empty or valid_df.empty:
        raise ValueError("Empty split detected after split/cache load.")

    predictor = _load_predictor_from_cfg(
        config_path=cfg_path,
        model_key="xgb",
        model_name=model_name,
    )
    train_df[pred_col] = np.asarray(predictor.predict(train_df)).reshape(-1)
    valid_df[pred_col] = np.asarray(predictor.predict(valid_df)).reshape(-1)
    all_df = raw_full.reset_index(drop=True).copy()
    all_df[pred_col] = np.asarray(predictor.predict(all_df)).reshape(-1)

    save_root = (
        Path(output_dir).expanduser().resolve()
        if output_dir
        else (cfg_path.parent / "Results" / "plot" / model_name / "double_lift").resolve()
    )
    save_root.mkdir(parents=True, exist_ok=True)

    style = PlotStyle()
    fig, axes = plt.subplots(1, 2, figsize=(12, 5))
    fig.suptitle("Double Lift: Current Model vs Direct XGB (Train + Validation)", fontsize=12)
    for ax, frame, title in (
        (axes[0], train_df, "Train Data: Current Model vs Direct XGB"),
        (axes[1], valid_df, "Validation Data: Current Model vs Direct XGB"),
    ):
        plot_double_lift_curve(
            frame[current_col].values,
            frame[pred_col].values,
            frame[target_col].values,
            frame[weight_col].values,
            n_bins=int(n_bins),
            title=title,
            label1="Current Model",
            label2="Direct XGB",
            pred1_weighted=False,
            pred2_weighted=False,
            actual_weighted=bool(actual_weighted),
            ax=ax,
            show=False,
            style=style,
        )
    plt.subplots_adjust(wspace=0.35, top=0.85)
    train_valid_path = save_root / "double_lift_train_valid_curr_model_vs_direct_xgb.png"
    finalize_figure(fig, save_path=str(train_valid_path), show=bool(show_plots), style=style)

    fig_all, ax_all = plt.subplots(1, 1, figsize=(8, 5))
    plot_double_lift_curve(
        all_df[current_col].values,
        all_df[pred_col].values,
        all_df[target_col].values,
        all_df[weight_col].values,
        n_bins=int(n_bins),
        title="All Data: Current Model vs Direct XGB",
        label1="Current Model",
        label2="Direct XGB",
        pred1_weighted=False,
        pred2_weighted=False,
        actual_weighted=bool(actual_weighted),
        ax=ax_all,
        show=False,
        style=style,
    )
    all_path = save_root / "double_lift_all_data_curr_model_vs_direct_xgb.png"
    finalize_figure(fig_all, save_path=str(all_path), show=bool(show_plots), style=style)

    _log(f"[CurrentVsXGB] Saved: {train_valid_path}")
    _log(f"[CurrentVsXGB] Saved: {all_path}")
    return {
        "output_dir": str(save_root),
        "plot_paths": [str(train_valid_path), str(all_path)],
        "model_name": model_name,
        "train_rows": int(len(train_df)),
        "valid_rows": int(len(valid_df)),
        "all_rows": int(len(all_df)),
    }
