"""Small helpers for keeping model_processing notebooks thin."""

from __future__ import annotations

import gc
import json
from pathlib import Path
from typing import Any, Iterable, Optional


def find_work_dir(*required_files: str, start: Optional[str | Path] = None) -> Path:
    """Find a working directory containing all required files."""

    base = Path(start).resolve() if start is not None else Path.cwd().resolve()
    candidates = [
        base,
        base / "model_processing",
        base.parent,
        base.parent / "model_processing",
    ]
    required = [str(name) for name in required_files if str(name).strip()]
    for candidate in candidates:
        if all((candidate / name).exists() for name in required):
            return candidate.resolve()
    return base


def resolve_relative(work_dir: str | Path, path_like: str | Path) -> Path:
    """Resolve a path relative to a notebook work directory."""

    path_obj = Path(path_like)
    if path_obj.is_absolute():
        return path_obj.resolve()
    return (Path(work_dir).resolve() / path_obj).resolve()


def resolve_cfg_alias(
    work_dir: str | Path,
    explicit_value: Optional[str | Path],
    fallback_names: Iterable[str | Path],
) -> Path:
    """Resolve an explicit config path or the first existing fallback."""

    if explicit_value is not None and str(explicit_value).strip():
        return resolve_relative(work_dir, explicit_value)

    resolved = [resolve_relative(work_dir, name) for name in fallback_names]
    for path_obj in resolved:
        if path_obj.exists():
            return path_obj
    if not resolved:
        raise ValueError("At least one fallback config name is required.")
    return resolved[0]


def read_json(path: str | Path) -> dict:
    path_obj = Path(path).expanduser().resolve()
    if not path_obj.exists():
        raise FileNotFoundError(f"JSON file not found: {path_obj}")
    return json.loads(path_obj.read_text(encoding="utf-8"))


def write_json(path: str | Path, payload: dict) -> None:
    Path(path).expanduser().resolve().write_text(
        json.dumps(payload, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )


def deep_update(base: dict, updates: Optional[dict]) -> dict:
    """Recursively update a dict in place and return it."""

    for key, value in (updates or {}).items():
        if isinstance(value, dict) and isinstance(base.get(key), dict):
            deep_update(base[key], value)
        else:
            base[key] = value
    return base


def release_memory(tag: str = "") -> None:
    """Run Python and optional torch memory cleanup."""

    gc.collect()
    try:
        import torch
    except Exception:
        torch = None
    if torch is not None:
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
            torch.cuda.ipc_collect()
        elif hasattr(torch.backends, "mps") and torch.backends.mps.is_available():
            if hasattr(torch, "mps") and hasattr(torch.mps, "empty_cache"):
                torch.mps.empty_cache()
    if tag:
        print(f"[Memory] Released after {tag}")


def model_name_from_cfg(cfg: dict) -> str:
    model_list = list(cfg.get("model_list") or [])
    model_categories = list(cfg.get("model_categories") or [])
    if len(model_list) == 1 and len(model_categories) == 1:
        return f"{model_list[0]}_{model_categories[0]}"
    model_name = str(cfg.get("model_name") or "").strip()
    if model_name:
        return model_name
    raise ValueError("Unable to resolve model name from config.")
