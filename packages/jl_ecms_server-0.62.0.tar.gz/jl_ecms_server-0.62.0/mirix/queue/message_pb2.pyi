from typing import ClassVar as _ClassVar
from typing import Iterable as _Iterable
from typing import Mapping as _Mapping
from typing import Optional as _Optional
from typing import Union as _Union

from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from google.protobuf import struct_pb2 as _struct_pb2
from google.protobuf import timestamp_pb2 as _timestamp_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper

DESCRIPTOR: _descriptor.FileDescriptor

class QueueMessage(_message.Message):
    __slots__ = (
        "client_id",
        "agent_id",
        "input_messages",
        "chaining",
        "user_id",
        "verbose",
        "filter_tags",
        "use_cache",
        "occurred_at",
        "langfuse_trace_id",
        "langfuse_observation_id",
        "langfuse_session_id",
        "langfuse_user_id",
        "block_filter_tags",
        "block_filter_tags_update_mode",
        "memory_source_id",
        "external_id",
        "external_thread_id",
        "source_type",
        "source_system",
        "source_metadata",
        "summary",
        "summarize",
        "source_messages",
        "direct_writes",
    )
    CLIENT_ID_FIELD_NUMBER: _ClassVar[int]
    AGENT_ID_FIELD_NUMBER: _ClassVar[int]
    INPUT_MESSAGES_FIELD_NUMBER: _ClassVar[int]
    CHAINING_FIELD_NUMBER: _ClassVar[int]
    USER_ID_FIELD_NUMBER: _ClassVar[int]
    VERBOSE_FIELD_NUMBER: _ClassVar[int]
    FILTER_TAGS_FIELD_NUMBER: _ClassVar[int]
    USE_CACHE_FIELD_NUMBER: _ClassVar[int]
    OCCURRED_AT_FIELD_NUMBER: _ClassVar[int]
    LANGFUSE_TRACE_ID_FIELD_NUMBER: _ClassVar[int]
    LANGFUSE_OBSERVATION_ID_FIELD_NUMBER: _ClassVar[int]
    LANGFUSE_SESSION_ID_FIELD_NUMBER: _ClassVar[int]
    LANGFUSE_USER_ID_FIELD_NUMBER: _ClassVar[int]
    BLOCK_FILTER_TAGS_FIELD_NUMBER: _ClassVar[int]
    BLOCK_FILTER_TAGS_UPDATE_MODE_FIELD_NUMBER: _ClassVar[int]
    MEMORY_SOURCE_ID_FIELD_NUMBER: _ClassVar[int]
    EXTERNAL_ID_FIELD_NUMBER: _ClassVar[int]
    EXTERNAL_THREAD_ID_FIELD_NUMBER: _ClassVar[int]
    SOURCE_TYPE_FIELD_NUMBER: _ClassVar[int]
    SOURCE_SYSTEM_FIELD_NUMBER: _ClassVar[int]
    SOURCE_METADATA_FIELD_NUMBER: _ClassVar[int]
    SUMMARY_FIELD_NUMBER: _ClassVar[int]
    SUMMARIZE_FIELD_NUMBER: _ClassVar[int]
    SOURCE_MESSAGES_FIELD_NUMBER: _ClassVar[int]
    DIRECT_WRITES_FIELD_NUMBER: _ClassVar[int]
    client_id: str
    agent_id: str
    input_messages: _containers.RepeatedCompositeFieldContainer[MessageCreate]
    chaining: bool
    user_id: str
    verbose: bool
    filter_tags: _struct_pb2.Struct
    use_cache: bool
    occurred_at: str
    langfuse_trace_id: str
    langfuse_observation_id: str
    langfuse_session_id: str
    langfuse_user_id: str
    block_filter_tags: _struct_pb2.Struct
    block_filter_tags_update_mode: str
    memory_source_id: str
    external_id: str
    external_thread_id: str
    source_type: str
    source_system: str
    source_metadata: _struct_pb2.Struct
    summary: str
    summarize: bool
    source_messages: _containers.RepeatedCompositeFieldContainer[MessageCreate]
    direct_writes: _containers.RepeatedCompositeFieldContainer[DirectMemoryWrite]
    def __init__(
        self,
        client_id: _Optional[str] = ...,
        agent_id: _Optional[str] = ...,
        input_messages: _Optional[_Iterable[_Union[MessageCreate, _Mapping]]] = ...,
        chaining: bool = ...,
        user_id: _Optional[str] = ...,
        verbose: bool = ...,
        filter_tags: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ...,
        use_cache: bool = ...,
        occurred_at: _Optional[str] = ...,
        langfuse_trace_id: _Optional[str] = ...,
        langfuse_observation_id: _Optional[str] = ...,
        langfuse_session_id: _Optional[str] = ...,
        langfuse_user_id: _Optional[str] = ...,
        block_filter_tags: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ...,
        block_filter_tags_update_mode: _Optional[str] = ...,
        memory_source_id: _Optional[str] = ...,
        external_id: _Optional[str] = ...,
        external_thread_id: _Optional[str] = ...,
        source_type: _Optional[str] = ...,
        source_system: _Optional[str] = ...,
        source_metadata: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ...,
        summary: _Optional[str] = ...,
        summarize: bool = ...,
        source_messages: _Optional[_Iterable[_Union[MessageCreate, _Mapping]]] = ...,
        direct_writes: _Optional[_Iterable[_Union[DirectMemoryWrite, _Mapping]]] = ...,
    ) -> None: ...

class User(_message.Message):
    __slots__ = ("id", "organization_id", "name", "status", "timezone", "created_at", "updated_at", "is_deleted")
    ID_FIELD_NUMBER: _ClassVar[int]
    ORGANIZATION_ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    TIMEZONE_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    UPDATED_AT_FIELD_NUMBER: _ClassVar[int]
    IS_DELETED_FIELD_NUMBER: _ClassVar[int]
    id: str
    organization_id: str
    name: str
    status: str
    timezone: str
    created_at: _timestamp_pb2.Timestamp
    updated_at: _timestamp_pb2.Timestamp
    is_deleted: bool
    def __init__(
        self,
        id: _Optional[str] = ...,
        organization_id: _Optional[str] = ...,
        name: _Optional[str] = ...,
        status: _Optional[str] = ...,
        timezone: _Optional[str] = ...,
        created_at: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ...,
        updated_at: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ...,
        is_deleted: bool = ...,
    ) -> None: ...

class MessageCreate(_message.Message):
    __slots__ = (
        "role",
        "text_content",
        "structured_content",
        "name",
        "otid",
        "sender_id",
        "group_id",
        "external_message_id",
        "message_occurred_at",
        "message_metadata",
    )

    class Role(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
        __slots__ = ()
        ROLE_UNSPECIFIED: _ClassVar[MessageCreate.Role]
        ROLE_USER: _ClassVar[MessageCreate.Role]
        ROLE_SYSTEM: _ClassVar[MessageCreate.Role]
        ROLE_ASSISTANT: _ClassVar[MessageCreate.Role]

    ROLE_UNSPECIFIED: MessageCreate.Role
    ROLE_USER: MessageCreate.Role
    ROLE_SYSTEM: MessageCreate.Role
    ROLE_ASSISTANT: MessageCreate.Role
    ROLE_FIELD_NUMBER: _ClassVar[int]
    TEXT_CONTENT_FIELD_NUMBER: _ClassVar[int]
    STRUCTURED_CONTENT_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    OTID_FIELD_NUMBER: _ClassVar[int]
    SENDER_ID_FIELD_NUMBER: _ClassVar[int]
    GROUP_ID_FIELD_NUMBER: _ClassVar[int]
    EXTERNAL_MESSAGE_ID_FIELD_NUMBER: _ClassVar[int]
    MESSAGE_OCCURRED_AT_FIELD_NUMBER: _ClassVar[int]
    MESSAGE_METADATA_FIELD_NUMBER: _ClassVar[int]
    role: MessageCreate.Role
    text_content: str
    structured_content: MessageContentList
    name: str
    otid: str
    sender_id: str
    group_id: str
    external_message_id: str
    message_occurred_at: str
    message_metadata: _struct_pb2.Struct
    def __init__(
        self,
        role: _Optional[_Union[MessageCreate.Role, str]] = ...,
        text_content: _Optional[str] = ...,
        structured_content: _Optional[_Union[MessageContentList, _Mapping]] = ...,
        name: _Optional[str] = ...,
        otid: _Optional[str] = ...,
        sender_id: _Optional[str] = ...,
        group_id: _Optional[str] = ...,
        external_message_id: _Optional[str] = ...,
        message_occurred_at: _Optional[str] = ...,
        message_metadata: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ...,
    ) -> None: ...

class MessageContentList(_message.Message):
    __slots__ = ("parts",)
    PARTS_FIELD_NUMBER: _ClassVar[int]
    parts: _containers.RepeatedCompositeFieldContainer[MessageContentPart]
    def __init__(self, parts: _Optional[_Iterable[_Union[MessageContentPart, _Mapping]]] = ...) -> None: ...

class MessageContentPart(_message.Message):
    __slots__ = ("text", "image", "file", "cloud_file")
    TEXT_FIELD_NUMBER: _ClassVar[int]
    IMAGE_FIELD_NUMBER: _ClassVar[int]
    FILE_FIELD_NUMBER: _ClassVar[int]
    CLOUD_FILE_FIELD_NUMBER: _ClassVar[int]
    text: TextContent
    image: ImageContent
    file: FileContent
    cloud_file: CloudFileContent
    def __init__(
        self,
        text: _Optional[_Union[TextContent, _Mapping]] = ...,
        image: _Optional[_Union[ImageContent, _Mapping]] = ...,
        file: _Optional[_Union[FileContent, _Mapping]] = ...,
        cloud_file: _Optional[_Union[CloudFileContent, _Mapping]] = ...,
    ) -> None: ...

class TextContent(_message.Message):
    __slots__ = ("text",)
    TEXT_FIELD_NUMBER: _ClassVar[int]
    text: str
    def __init__(self, text: _Optional[str] = ...) -> None: ...

class ImageContent(_message.Message):
    __slots__ = ("image_id", "detail")
    IMAGE_ID_FIELD_NUMBER: _ClassVar[int]
    DETAIL_FIELD_NUMBER: _ClassVar[int]
    image_id: str
    detail: str
    def __init__(self, image_id: _Optional[str] = ..., detail: _Optional[str] = ...) -> None: ...

class FileContent(_message.Message):
    __slots__ = ("file_id",)
    FILE_ID_FIELD_NUMBER: _ClassVar[int]
    file_id: str
    def __init__(self, file_id: _Optional[str] = ...) -> None: ...

class CloudFileContent(_message.Message):
    __slots__ = ("cloud_file_uri",)
    CLOUD_FILE_URI_FIELD_NUMBER: _ClassVar[int]
    cloud_file_uri: str
    def __init__(self, cloud_file_uri: _Optional[str] = ...) -> None: ...

class DirectMemoryWrite(_message.Message):
    __slots__ = ("memory_type", "payload_json")
    MEMORY_TYPE_FIELD_NUMBER: _ClassVar[int]
    PAYLOAD_JSON_FIELD_NUMBER: _ClassVar[int]
    memory_type: str
    payload_json: str
    def __init__(self, memory_type: _Optional[str] = ..., payload_json: _Optional[str] = ...) -> None: ...
