# Python Text Embedding Libraries: A Comprehensive Guide

*Last Updated: January 2026*

## Table of Contents
1. [sentence-transformers](#1-sentence-transformers)
2. [Hugging Face transformers](#2-hugging-face-transformers)
3. [FlagEmbedding (BGE)](#3-flagembedding-bge)
4. [Jina AI](#4-jina-ai)
5. [Cloud API Options](#5-cloud-api-options)
6. [Benchmarking and Model Selection](#6-benchmarking-and-model-selection)
7. [Recommendations by Use Case](#7-recommendations-by-use-case)

---

## 1. sentence-transformers

### Overview
sentence-transformers is the most popular and mature framework for sentence embeddings, built on top of PyTorch and Hugging Face transformers. It provides a simple interface for computing dense vector representations of text, with over 15,000 pre-trained models available on Hugging Face.

### Installation

```bash
# Basic installation
pip install -U sentence-transformers

# With conda
conda install -c conda-forge sentence-transformers

# Install from source
git clone https://github.com/huggingface/sentence-transformers.git
cd sentence-transformers
pip install -e .

# Optional extras
pip install -U sentence-transformers[train,onnx,onnx-gpu,openvino,dev]
```

**Dependencies:**
- Python >= 3.10
- PyTorch >= 1.11.0
- transformers >= 4.34.0

For GPU support, install PyTorch with matching CUDA version.

### Basic Usage

```python
from sentence_transformers import SentenceTransformer

# Load a model
model = SentenceTransformer('all-MiniLM-L6-v2')

# Encode sentences
sentences = [
    "The weather is lovely today.",
    "It's so sunny outside!",
    "He drove to the stadium."
]

# Generate embeddings
embeddings = model.encode(sentences)
print(embeddings.shape)  # (3, 384) for MiniLM

# Compute similarities
similarities = model.similarity(embeddings, embeddings)
print(similarities)
```

### Popular Models and Characteristics

| Model | Size | Dimensions | Speed | Quality | Use Case |
|--------|-------|-------------|--------|----------|-----------|
| **all-MiniLM-L6-v2** | 100MB | 384 | Very Fast | Good | General purpose, low resource |
| **all-mpnet-base-v2** | 400MB | 768 | Fast | Excellent | High quality, balanced |
| **e5-small-v2** | 130MB | 384 | Very Fast | Very Good | Modern, retrieval-focused |
| **e5-large-v2** | 1.3GB | 1024 | Medium | Excellent | Best quality, needs GPU |
| **bge-small-en-v1.5** | 130MB | 384 | Very Fast | Excellent | State-of-the-art small model |
| **bge-base-en-v1.5** | 400MB | 768 | Fast | Excellent | Balanced performance |
| **bge-large-en-v1.5** | 1.3GB | 1024 | Medium | Excellent | High-end quality |

### Batch Processing

```python
# Batch processing (automatic for large datasets)
large_text_list = [...]  # thousands of texts
embeddings = model.encode(
    large_text_list,
    batch_size=32,           # Process in batches
    show_progress_bar=True,     # Show progress
    convert_to_numpy=True,      # Return numpy array
    normalize_embeddings=True    # L2 normalize for cosine similarity
)

# Multi-GPU encoding
from sentence_transformers import SentenceTransformer
model = SentenceTransformer('all-mpnet-base-v2', device='cuda')
embeddings = model.encode(sentences, device='cuda:0')  # Specify GPU
```

### Hardware Requirements

**CPU-only:**
- RAM: 4GB minimum, 8GB recommended
- Storage: 500MB - 2GB for models
- Performance: 0.5-2 seconds per embedding (MiniLM)
- Suitable for: Small-scale deployments, prototyping

**GPU-accelerated:**
- GPU: NVIDIA GPU with 4GB+ VRAM (RTX 3060 or better)
- RAM: 8GB minimum, 16GB recommended
- Storage: 500MB - 2GB for models
- Performance: 0.01-0.1 seconds per embedding
- Suitable for: Production, large-scale deployments

### Pros and Cons

**Pros:**
- Mature, well-documented framework
- Largest ecosystem of pre-trained models (15,000+)
- Simple API - just `model.encode()`
- Built-in batch processing and multi-GPU support
- Active community and regular updates
- Supports three model types: Dense, Sparse (SPLADE), and Cross-Encoders
- Easy fine-tuning with 20+ loss functions

**Cons:**
- Requires PyTorch and its dependencies
- Large models need significant RAM/VRAM
- No built-in vector database integration
- CPU-only performance can be slow for large datasets
- Model loading time can be noticeable

### Advanced Features

**Embedding Quantization:**
```python
from sentence_transformers.quantization import quantize_embeddings

# Binary quantization (1-bit)
binary_embeddings = quantize_embeddings(embeddings, precision='binary')

# Scalar quantization (8-bit)
int8_embeddings = quantize_embeddings(embeddings, precision='int8')
```

**Prompt Templates:**
```python
# Some models support instruction prompts
model = SentenceTransformer('BAAI/bge-large-en-v1.5')
query = "Represent this sentence for searching relevant passages: What is machine learning?"
embedding = model.encode(query)
```

**Mean Pooling for Custom Models:**
```python
from sentence_transformers import SentenceTransformer
from sentence_transformers.models import Transformer, Pooling

word_embedding_model = Transformer('bert-base-uncased')
pooling_model = Pooling(word_embedding_model.get_word_embedding_dimension(),
                       pooling_mode_mean_tokens=True)
model = SentenceTransformer(modules=[word_embedding_model, pooling_model])
```

---

## 2. Hugging Face transformers

### Overview
The `transformers` library is the foundational library for accessing thousands of pre-trained models. It provides low-level access to transformer models, making it highly flexible but requiring more boilerplate code compared to sentence-transformers.

### Installation

```bash
# Basic installation
pip install transformers

# With specific framework
pip install transformers[torch]  # or tensorflow, jax

# With optional features
pip install transformers[torch,accelerate,optimum]
```

**Dependencies:**
- Python >= 3.8
- torch >= 1.11, tensorflow >= 2.6, or jax >= 0.3.20
- tokenizers, huggingface-hub, safetensors

### Basic Usage for Embeddings

```python
from transformers import AutoTokenizer, AutoModel
import torch

# Load model and tokenizer
model_name = 'sentence-transformers/all-MiniLM-L6-v2'
tokenizer = AutoTokenizer.from_pretrained(model_name)
model = AutoModel.from_pretrained(model_name)

def mean_pooling(model_output, attention_mask):
    # Mean pooling with attention mask
    token_embeddings = model_output[0]
    input_mask_expanded = attention_mask.unsqueeze(-1).expand(token_embeddings.size()).float()
    return torch.sum(token_embeddings * input_mask_expanded, 1) / torch.clamp(input_mask_expanded.sum(1), min=1e-9)

def get_embedding(text):
    # Tokenize
    encoded_input = tokenizer(text, padding=True, truncation=True, max_length=512, return_tensors='pt')
    
    # Get model output
    with torch.no_grad():
        model_output = model(**encoded_input)
    
    # Apply mean pooling
    embeddings = mean_pooling(model_output, encoded_input['attention_mask'])
    
    return embeddings.numpy()

# Generate embedding
embedding = get_embedding("Your text here")
print(embedding.shape)  # (1, 384)
```

### Popular Embedding Models

**BERT-based Models:**
- `bert-base-uncased` - 110MB, 768 dims (older, general purpose)
- `distilbert-base-uncased` - 260MB, 768 dims (faster, good quality)
- `all-MiniLM-L6-v2` - 100MB, 384 dims (very fast, good quality)

**E5 Series (Microsoft/Intfloat):**
- `intfloat/e5-small-v2` - 130MB, 384 dims
- `intfloat/e5-base-v2` - 420MB, 768 dims
- `intfloat/e5-large-v2` - 1.3GB, 1024 dims
- Note: E5 models require query instruction prefix

**BGE Series (BAAI):**
- `BAAI/bge-small-en-v1.5` - 130MB, 384 dims (SOTA small model)
- `BAAI/bge-base-en-v1.5` - 400MB, 768 dims
- `BAAI/bge-large-en-v1.5` - 1.3GB, 1024 dims

**Multilingual:**
- `sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2` - 470MB, 768 dims
- `intfloat/multilingual-e5-large` - 2.2GB, 1024 dims (100+ languages)

### Mean Pooling Implementation

Mean pooling is essential for converting token-level embeddings to sentence-level embeddings:

```python
import torch
import torch.nn.functional as F

def mean_pooling(model_output, attention_mask):
    """
    Perform mean pooling over token embeddings with attention mask.
    
    Args:
        model_output: Tuple of (last_hidden_state, pooler_output, ...)
        attention_mask: Tensor of shape (batch_size, seq_length)
    
    Returns:
        Pooled embeddings of shape (batch_size, hidden_size)
    """
    token_embeddings = model_output[0]  # (batch, seq_len, hidden)
    attention_mask = attention_mask.unsqueeze(-1)  # (batch, seq_len, 1)
    attention_mask = attention_mask.expand(token_embeddings.size()).float()
    
    # Mean pooling
    pooled = torch.sum(token_embeddings * attention_mask, dim=1) / torch.clamp(attention_mask.sum(dim=1), min=1e-9)
    
    return pooled
```

### Quantization and Optimization

**ONNX Runtime:**
```python
from optimum.onnxruntime import ORTModelForSequenceClassification

# Export to ONNX
model = ORTModelForSequenceClassification.from_pretrained('bert-base-uncased', export=True)

# Run with ONNX Runtime
outputs = model(**inputs)
```

**Dynamic Quantization (8-bit):**
```python
from optimum.bettertransformer import BetterTransformer

model = BetterTransformer.transform('bert-base-uncased')
# Reduces model size by ~4x with minimal quality loss
```

**Flash Attention (requires torch>=2.0):**
```python
model = AutoModel.from_pretrained(
    'bert-base-uncased',
    attn_implementation="flash_attention_2",
    torch_dtype=torch.float16
)
# Faster and more memory-efficient attention
```

### Hardware Requirements

**CPU-only:**
- RAM: 2-4GB minimum
- Storage: 110MB - 2.2GB depending on model
- Performance: Variable (0.1-5 seconds per embedding)
- Suitable for: Small-scale applications, CPU-only environments

**GPU-accelerated:**
- GPU: NVIDIA GPU with 4-8GB VRAM
- RAM: 8GB minimum
- Performance: 0.01-0.1 seconds per embedding with GPU
- Supports: CUDA, ROCm (AMD), Metal (Apple Silicon)

### Pros and Cons

**Pros:**
- Maximum flexibility - access to any transformer architecture
- Works with PyTorch, TensorFlow, and JAX
- Active development and regular updates
- Supports model parallelism for very large models
- Better for research and custom implementations
- Integration with Hugging Face Hub (100,000+ models)

**Cons:**
- More boilerplate code required
- Need to implement pooling manually
- Steeper learning curve
- No built-in batch optimization
- Must manage device placement manually
- Less suitable for quick production deployments

### Best Practices

```python
from transformers import AutoTokenizer, AutoModel
import torch

class EmbeddingModel:
    def __init__(self, model_name, device='cpu'):
        self.tokenizer = AutoTokenizer.from_pretrained(model_name)
        self.model = AutoModel.from_pretrained(model_name)
        self.device = device
        self.model.to(device)
        self.model.eval()
    
    @torch.no_grad()
    def encode_batch(self, texts, batch_size=32):
        """Process texts in batches"""
        all_embeddings = []
        
        for i in range(0, len(texts), batch_size):
            batch = texts[i:i+batch_size]
            
            # Tokenize
            inputs = self.tokenizer(
                batch,
                padding=True,
                truncation=True,
                max_length=512,
                return_tensors='pt'
            )
            inputs = {k: v.to(self.device) for k, v in inputs.items()}
            
            # Forward pass
            outputs = self.model(**inputs)
            
            # Mean pooling
            embeddings = self._mean_pooling(outputs, inputs['attention_mask'])
            
            # L2 normalize
            embeddings = F.normalize(embeddings, p=2, dim=1)
            
            all_embeddings.append(embeddings.cpu().numpy())
        
        return np.vstack(all_embeddings)
    
    def _mean_pooling(self, model_output, attention_mask):
        token_embeddings = model_output[0]
        input_mask_expanded = attention_mask.unsqueeze(-1).expand(token_embeddings.size()).float()
        sum_embeddings = torch.sum(token_embeddings * input_mask_expanded, 1)
        sum_mask = torch.clamp(input_mask_expanded.sum(1), min=1e-9)
        return sum_embeddings / sum_mask
```

---

## 3. FlagEmbedding (BGE)

### Overview
BGE (BAAI General Embedding) is a comprehensive toolkit for retrieval and retrieval-augmented LLMs. It includes state-of-the-art embedding models (BGE) and rerankers, with a focus on Chinese and English tasks.

### Installation

```bash
# Basic installation (for inference only)
pip install -U FlagEmbedding

# For fine-tuning
pip install -U FlagEmbedding[finetune]

# From source
git clone https://github.com/FlagOpen/FlagEmbedding.git
cd FlagEmbedding
pip install -e .
```

### Basic Usage

```python
from FlagEmbedding import FlagAutoModel

# Load model with query instruction for retrieval
model = FlagAutoModel.from_finetuned(
    'BAAI/bge-base-en-v1.5',
    query_instruction_for_retrieval="Represent this sentence for searching relevant passages:",
    use_fp16=True  # Use float16 for memory efficiency
)

# Encode sentences
sentences_1 = ["I love NLP", "I love machine learning"]
sentences_2 = ["I love BGE", "I love text retrieval"]

embeddings_1 = model.encode(sentences_1)
embeddings_2 = model.encode(sentences_2)

# Compute similarity
similarity = embeddings_1 @ embeddings_2.T
print(similarity)
```

### Available Models

| Model | Size | Dimensions | Languages | Quality | Use Case |
|--------|-------|-------------|------------|----------|-----------|
| **bge-small-en-v1.5** | 130MB | 384 | English | Excellent | Fast retrieval, production |
| **bge-base-en-v1.5** | 400MB | 768 | English | Excellent | Balanced retrieval |
| **bge-large-en-v1.5** | 1.3GB | 1024 | English | Excellent | High-quality retrieval |
| **bge-small-zh-v1.5** | 130MB | 384 | Chinese | Excellent | Chinese retrieval |
| **bge-base-zh-v1.5** | 400MB | 768 | Chinese | Excellent | Chinese retrieval |
| **bge-large-zh-v1.5** | 1.3GB | 1024 | Chinese | Excellent | Chinese high-end |
| **bge-m3** | 2.7GB | 1024 | 100+ | Excellent | Multilingual, multi-granularity |
| **bge-en-icl** | 7B | 4096 | English | Very Good | In-context learning |
| **bge-multilingual-gemma2** | 9B | 3584 | 100+ | SOTA | Best multilingual |

### Reranker Models

BGE also provides cross-encoder rerankers for re-ranking top-k results:

```python
from FlagEmbedding import FlagReranker

# Load reranker
reranker = FlagReranker('BAAI/bge-reranker-large')

# Rerank passages for a query
query = "What is machine learning?"
passages = [
    "Machine learning is a subset of AI.",
    "The weather is nice today.",
    "ML uses statistical methods."
]

scores = reranker.compute_score([[query, passage] for passage in passages])
# or use rank method for top-k re-ranking
ranked_results = reranker.rank(query, passages, top_k=3)
```

### Hardware Requirements

**CPU-only:**
- RAM: 4GB minimum, 8GB recommended for base models
- Storage: 130MB - 2.7GB
- Performance: 0.3-1.5 seconds per embedding
- Suitable for: Small to medium deployments

**GPU-accelerated:**
- GPU: NVIDIA RTX 3060 or better (4GB+ VRAM)
- RAM: 8GB minimum, 16GB recommended for large models
- Performance: 0.005-0.05 seconds per embedding
- Suitable for: Production, large-scale retrieval

### Unique Features

**BGE-M3: Multi-Functionality**
```python
from FlagEmbedding import BGEM3FlagModel

model = BGEM3FlagModel('BAAI/bge-m3', use_fp16=True)

# Dense retrieval
dense_embeddings = model.encode(sentences, batch_size=12, max_length=512)['dense_vecs']

# Sparse retrieval (lexical)
sparse_embeddings = model.encode(sentences, batch_size=12, max_length=512)['lexical_weights']

# Multi-vector (ColBERT style)
multi_vec_embeddings = model.encode(sentences, batch_size=12, max_length=512)['colbert_vecs']
```

**BGE-ICL: In-Context Learning**
```python
from FlagEmbedding import FlagICLModel

model = FlagICLModel('BAAI/bge-en-icl')

# Provide task examples for better embeddings
query = "Classify the sentiment: This movie is great!"
task_examples = [
    "This is excellent! -> positive",
    "I hate this. -> negative",
    "It's okay. -> neutral"
]
embedding = model.encode(query, task_examples=task_examples)
```

### Pros and Cons

**Pros:**
- State-of-the-art performance on MTEB benchmark
- Specialized models for retrieval tasks
- Built-in query instruction support
- Excellent multilingual support
- Includes rerankers for two-stage retrieval
- Active development from BAAI research team
- Multi-functionality (dense, sparse, ColBERT) in BGE-M3

**Cons:**
- Primarily optimized for English/Chinese
- Larger models require significant VRAM
- Less mature than sentence-transformers
- Smaller community compared to Hugging Face
- Documentation primarily in English/Chinese

---

## 4. Jina AI

### Overview
Jina AI provides cloud-native infrastructure for building multimodal AI applications, including embedding models. While less focused on pure embeddings, it offers unique deployment capabilities and optimization features.

### Installation

```bash
# Install Jina
pip install jina

# For Apple Silicon (M1/M2)
pip install jina[apple-silicon]

# For Windows
pip install jina[windows]
```

### Basic Usage

Jina's embedding models can be accessed via:

1. **Direct Hugging Face models:**
```python
from jina import Executor, requests
from docarray import DocList, BaseDoc

class EmbeddingDoc(BaseDoc):
    text: str

class EmbeddingExecutor(Executor):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        from sentence_transformers import SentenceTransformer
        self.model = SentenceTransformer('jina-embeddings/jina-embeddings-v2-base-en')
    
    @requests
    def embed(self, docs: DocList[EmbeddingDoc], **kwargs):
        embeddings = self.model.encode(docs.text)
        return embeddings
```

2. **Jina Cloud API:**
```python
from jina import Client

client = Client(port=12345)
response = client.post('/', inputs=[{'text': 'Hello world'}])
```

### Popular Jina Embedding Models

| Model | Size | Dimensions | Speed | Quality | Use Case |
|--------|-------|-------------|--------|----------|-----------|
| **jina-embeddings-v2-base-en** | 330MB | 768 | Fast | Very Good | General English |
| **jina-embeddings-v2-small-en** | 130MB | 512 | Very Fast | Good | Fast retrieval |
| **jina-clip-v1-base-en** | 500MB | 768 | Medium | Good | Image-text |

### Unique Features

**Cloud-Native Deployment:**
```python
from jina import Deployment

# Deploy to cloud
with Deployment(uses=EmbeddingExecutor, timeout_ready=-1, port=12345):
    dep.block()

# Export to Kubernetes
jina export kubernetes flow.yml ./my-k8s
kubectl apply -R -f my-k8s

# One-click cloud deployment
jina cloud deploy jcloud-flow.yml
```

**Dynamic Batching:**
```python
# Automatic batching for efficiency
uses_dynamic_batching:
  /default:
    preferred_batch_size: 10
    timeout: 200
```

**Streaming Support:**
```python
# Stream embeddings for large datasets
async for embedding in client.stream(on='/', inputs=texts):
    process(embedding)
```

### Hardware Requirements

**CPU-only:**
- RAM: 4GB minimum, 8GB recommended
- Storage: 330MB - 500MB
- Performance: Fast (optimized for production)
- Suitable for: Microservices, cloud deployments

**GPU-accelerated:**
- GPU: NVIDIA GPU with 4GB+ VRAM
- RAM: 8GB minimum
- Supports: Docker, Kubernetes, cloud platforms

### Pros and Cons

**Pros:**
- Cloud-native deployment (Docker, Kubernetes, Jina Cloud)
- Built-in batching and streaming
- Scalable microservice architecture
- Supports gRPC, HTTP, and WebSockets
- One-click cloud deployment
- Production-ready infrastructure
- Supports multimodal (text + image) embeddings

**Cons:**
- Not focused purely on embeddings
- Higher complexity for simple use cases
- Requires learning Jina framework
- Less direct model access compared to HF
- Smaller ecosystem of embedding models

---

## 5. Cloud API Options

### OpenAI Embeddings

### Overview
OpenAI provides high-quality embeddings via their API with excellent performance and ease of use. The latest generation (text-embedding-3) offers variable dimensions and improved multilingual support.

### Installation

```bash
pip install openai
```

### Basic Usage

```python
from openai import OpenAI

client = OpenAI(api_key="your-api-key")

# Generate embedding
response = client.embeddings.create(
    input="Your text string goes here",
    model="text-embedding-3-small"
)

embedding = response.data[0].embedding
print(len(embedding))  # 1536
```

### Available Models

| Model | Dimensions | Price (per 1M tokens) | Performance | Max Input |
|--------|-------------|-------------------------|-------------|-------------|
| **text-embedding-3-small** | 1536 (customizable) | $0.02 | 62.3% MTEB | 8192 |
| **text-embedding-3-large** | 3072 (customizable) | $0.13 | 64.6% MTEB | 8192 |
| **text-embedding-ada-002** | 1536 | $0.10 | 61.0% MTEB | 8192 |

### Features

**Variable Dimensions:**
```python
# Reduce dimensions without quality loss
response = client.embeddings.create(
    input="Your text",
    model="text-embedding-3-small",
    dimensions=256  # Reduce from 1536 to 256
)
embedding = response.data[0].embedding
print(len(embedding))  # 256
```

**Batch Processing:**
```python
# Process multiple texts in one request
texts = ["Text 1", "Text 2", "Text 3"]
response = client.embeddings.create(
    input=texts,
    model="text-embedding-3-small"
)
embeddings = [item.embedding for item in response.data]
```

### Usage Patterns and Pricing

**Pricing Calculation:**
```python
import tiktoken

def count_tokens(text, model="text-embedding-3-small"):
    encoding = tiktoken.encoding_for_model(model)
    return len(encoding.encode(text))

# Estimate cost
text = "Your document text here..."
tokens = count_tokens(text)
pages = tokens / 800  # Average 800 tokens/page
cost_per_page = (tokens / 1_000_000) * 0.02  # $0.02 per 1M tokens
```

**Example Costs:**
- 1 page (~800 tokens): $0.000016
- 100 pages: $0.0016
- 1,000 pages: $0.016
- 100,000 pages: $1.60

### Pros and Cons

**Pros:**
- Excellent performance (top of MTEB)
- Simple API - no local infrastructure
- Variable dimensions support
- Multilingual support
- No model management
- Automatic scaling
- Regular updates and improvements

**Cons:**
- Ongoing cost (usage-based)
- Data sent to OpenAI servers
- Requires internet connection
- Rate limits on free tier
- No customization possible
- Vendor lock-in

### Cohere Embeddings

### Installation

```bash
pip install cohere
```

### Basic Usage

```python
import cohere

client = cohere.ClientV2(api_key="your-api-key")

response = client.embed(
    texts=["Your text here"],
    model="embed-english-v3.0",
    input_type="search_document"  # or "search_query"
)

embeddings = response.embeddings.floats
```

### Available Models

| Model | Dimensions | Price | Performance | Use Case |
|--------|-------------|---------|-------------|-----------|
| **embed-english-v3.0** | 1024 | $0.10 per 1M tokens | Excellent | English retrieval |
| **embed-multilingual-v3.0** | 1024 | $0.10 per 1M tokens | Very Good | Multilingual |
| **embed-light-v3.0** | 384 | $0.02 per 1M tokens | Good | Fast, low-resource |

### Unique Features

**Input Type Optimization:**
```python
# Optimize for different use cases
client.embed(
    texts=[query],
    input_type="search_query"  # Better for queries
)

client.embed(
    texts=[document],
    input_type="search_document"  # Better for documents
)
```

### Pros and Cons

**Pros:**
- Competitive performance
- Multiple model sizes
- Input-type optimization
- Simple API
- Good documentation

**Cons:**
- Less popular than OpenAI
- Smaller community
- Requires API key
- Ongoing costs

---

## 6. Benchmarking and Model Selection

### MTEB (Massive Text Embedding Benchmark)

MTEB is the standard benchmark for evaluating embedding models across multiple tasks and languages.

### Installation

```bash
pip install mteb
```

### Usage

```python
import mteb
from sentence_transformers import SentenceTransformer

# Select model
model = SentenceTransformer('all-MiniLM-L6-v2')

# Select tasks
tasks = mteb.get_tasks(tasks=["Banking77Classification.v2"])

# Evaluate
results = mteb.evaluate(model, tasks=tasks)
print(results)
```

### Top Models (MTEB Leaderboard)

As of January 2026, top-performing models include:

**English:**
1. **jina-embeddings-v3-base-en** - MTEB Score: 68.2
2. **BAAI/bge-large-en-v1.5** - MTEB Score: 66.5
3. **intfloat/e5-large-v2** - MTEB Score: 65.8

**Multilingual:**
1. **BAAI/bge-multilingual-gemma2** - SOTA on multilingual benchmarks
2. **intfloat/multilingual-e5-large** - 100+ language support
3. **sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2** - Established multilingual

### Model Selection Criteria

**For General Purpose (English):**
- Budget: `all-MiniLM-L6-v2` (100MB, fast)
- Performance: `BAAI/bge-base-en-v1.5` (400MB, excellent)
- Best: `jina-embeddings-v3-base-en` (SOTA)

**For Multilingual:**
- Lightweight: `sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2`
- Performance: `intfloat/multilingual-e5-large`
- Best: `BAAI/bge-multilingual-gemma2`

**For Resource-Constrained:**
- CPU-only: `all-MiniLM-L6-v2` or `BAAI/bge-small-en-v1.5`
- Edge devices: `BAAI/bge-small-en-v1.5` with quantization

**For Production:**
- Local: `BAAI/bge-base-en-v1.5` (balanced)
- Cloud: OpenAI `text-embedding-3-small` (ease of use)

---

## 7. Recommendations by Use Case

### Vector Database Package Integration

For your **sqloquent-vectordb** package, here are the best embedding options:

### Option 1: Default Provider (Recommended for Most Users)

**Model:** `BAAI/bge-base-en-v1.5`

```python
from sentence_transformers import SentenceTransformer

model = SentenceTransformer('BAAI/bge-base-en-v1.5')
embedding = model.encode("Your text", normalize_embeddings=True)
```

**Characteristics:**
- Size: 400MB
- Dimensions: 768
- Performance: Excellent (66.5 MTEB)
- Hardware: CPU or GPU
- Cost: Free (local)
- Speed: Fast (0.1-0.5s per embedding on CPU)

**Pros:**
- Balanced size and performance
- Query instruction support
- Active development
- Great for RAG and retrieval
- Works well with SQLite + FAISS

**Cons:**
- English-only
- Requires 400MB storage
- Not the fastest available

### Option 2: Lightweight Option

**Model:** `all-MiniLM-L6-v2`

```python
from sentence_transformers import SentenceTransformer

model = SentenceTransformer('all-MiniLM-L6-v2')
embedding = model.encode("Your text", normalize_embeddings=True)
```

**Characteristics:**
- Size: 100MB
- Dimensions: 384
- Performance: Good (60+ MTEB)
- Hardware: CPU or GPU
- Cost: Free (local)
- Speed: Very Fast (0.05-0.2s per embedding on CPU)

**Pros:**
- Very small footprint
- Fast embeddings
- Good general performance
- Mature and stable
- Works on edge devices

**Cons:**
- Lower quality than BGE/Jina
- No instruction support
- 384 dimensions (less expressive)

### Option 3: High-Quality Option

**Model:** `intfloat/e5-large-v2`

```python
from sentence_transformers import SentenceTransformer

model = SentenceTransformer('intfloat/e5-large-v2')
query = "Represent this sentence for searching relevant passages: " + text
embedding = model.encode(query, normalize_embeddings=True)
```

**Characteristics:**
- Size: 1.3GB
- Dimensions: 1024
- Performance: Excellent (65.8 MTEB)
- Hardware: GPU recommended
- Cost: Free (local)
- Speed: Medium (0.2-1s per embedding on GPU)

**Pros:**
- High-quality embeddings
- Large dimensions for semantic nuance
- Good for complex queries

**Cons:**
- Very large model (1.3GB)
- Requires GPU for best performance
- Needs query instruction
- Slower inference

### Option 4: Cloud API Option

**Provider:** OpenAI `text-embedding-3-small`

```python
from openai import OpenAI

client = OpenAI()
response = client.embeddings.create(
    input="Your text",
    model="text-embedding-3-small"
)
embedding = response.data[0].embedding
```

**Characteristics:**
- Dimensions: 1536 (customizable down to 256)
- Performance: Excellent (62.3% MTEB)
- Hardware: None (API)
- Cost: $0.02 per 1M tokens
- Speed: Network-dependent

**Pros:**
- No local infrastructure
- Best-in-class performance
- Variable dimensions
- Automatic scaling
- Multilingual

**Cons:**
- Ongoing cost ($0.02 per 1M tokens = ~$0.016 per 1000 pages)
- Data privacy concerns
- Requires API key
- No customization
- Network latency

### Implementation Example

Here's a pluggable embedding provider implementation for sqloquent-vectordb:

```python
from typing import Protocol, runtime_checkable, Optional, List
import numpy as np

@runtime_checkable
class EmbeddingProvider(Protocol):
    """Protocol for embedding generation."""
    
    def embed_text(self, text: str) -> np.ndarray:
        """Generate embedding for a single text."""
        ...
    
    def embed_texts(self, texts: List[str]) -> np.ndarray:
        """Generate embeddings for multiple texts (batched)."""
        ...
    
    @property
    def embedding_dimension(self) -> int:
        """Return the dimension of generated embeddings."""
        ...

class SentenceTransformersProvider:
    """Default provider using sentence-transformers."""
    
    def __init__(self, model_name: str = 'BAAI/bge-base-en-v1.5', 
                 device: str = 'cpu'):
        from sentence_transformers import SentenceTransformer
        self.model = SentenceTransformer(model_name)
        self.device = device
        self.model.to(device)
        self._dimension = self.model.get_sentence_embedding_dimension()
    
    def embed_text(self, text: str) -> np.ndarray:
        embedding = self.model.encode(
            text, 
            convert_to_numpy=True,
            normalize_embeddings=True,
            show_progress_bar=False
        )
        return embedding
    
    def embed_texts(self, texts: List[str], batch_size: int = 32) -> np.ndarray:
        embeddings = self.model.encode(
            texts,
            batch_size=batch_size,
            convert_to_numpy=True,
            normalize_embeddings=True,
            show_progress_bar=True
        )
        return embeddings
    
    @property
    def embedding_dimension(self) -> int:
        return self._dimension

class OpenAIProvider:
    """Cloud provider using OpenAI API."""
    
    def __init__(self, model: str = 'text-embedding-3-small', 
                 api_key: Optional[str] = None,
                 dimensions: Optional[int] = None):
        from openai import OpenAI
        self.client = OpenAI(api_key=api_key)
        self.model = model
        self._dimension = 1536 if dimensions is None else dimensions
        self.api_dimensions = dimensions
    
    def embed_text(self, text: str) -> np.ndarray:
        response = self.client.embeddings.create(
            input=text,
            model=self.model,
            dimensions=self.api_dimensions
        )
        return np.array(response.data[0].embedding, dtype=np.float32)
    
    def embed_texts(self, texts: List[str]) -> np.ndarray:
        response = self.client.embeddings.create(
            input=texts,
            model=self.model,
            dimensions=self.api_dimensions
        )
        embeddings = [item.embedding for item in response.data]
        return np.array(embeddings, dtype=np.float32)
    
    @property
    def embedding_dimension(self) -> int:
        return self._dimension

# Usage example
def create_provider(provider_type: str = 'local'):
    if provider_type == 'local':
        return SentenceTransformersProvider()
    elif provider_type == 'cloud':
        return OpenAIProvider()
    else:
        raise ValueError(f"Unknown provider: {provider_type}")

provider = create_provider('local')
embedding = provider.embed_text("Hello, world!")
print(f"Embedding shape: {embedding.shape}")
print(f"Embedding norm: {np.linalg.norm(embedding):.4f}")
```

### Performance Comparison (100K vectors)

| Provider | Model | Embedding Time | Memory | Index Build | Search Time | Total Cost |
|----------|--------|----------------|---------|--------------|-------------|------------|
| **Local (BGE-base)** | 100MB | 0.2s/emb | ~250MB | 2s | 1-5ms | $0 |
| **Local (MiniLM)** | 100MB | 0.1s/emb | ~150MB | 1s | 1-2ms | $0 |
| **Cloud (OpenAI)** | 0MB | 0.1-0.5s/API | ~100MB | 0s | <1ms | ~$1.60 |

### Final Recommendations

**For sqloquent-vectordb:**

1. **Default choice:** `BAAI/bge-base-en-v1.5`
   - Best balance of performance and resource usage
   - Excellent for SQLite + FAISS deployments
   - No API costs
   - Good community support

2. **Alternative for low-resources:** `all-MiniLM-L6-v2`
   - Very small (100MB)
   - Fast embeddings
   - Adequate quality for many use cases

3. **Enterprise option:** OpenAI `text-embedding-3-small`
   - Zero infrastructure management
   - Best quality
   - Predictable costs
   - Multilingual support

4. **Advanced option:** `BAAI/bge-multilingual-gemma2`
   - State-of-the-art multilingual
   - 100+ language support
   - Requires significant resources
   - For specialized use cases

---

## Summary Table

| Library | Installation | Models | Ease of Use | Performance | Cost | Best For |
|----------|-------------|---------|--------------|-------------|-------|-----------|
| **sentence-transformers** | `pip install sentence-transformers` | 15,000+ | ⭐⭐⭐⭐⭐⭐ | Excellent | Free | Production, general use |
| **Hugging Face transformers** | `pip install transformers` | 100,000+ | ⭐⭐⭐ | SOTA | Free | Research, customization |
| **FlagEmbedding (BGE)** | `pip install FlagEmbedding` | 20+ | ⭐⭐⭐⭐⭐ | SOTA | Free | Retrieval, RAG |
| **Jina AI** | `pip install jina` | 5+ | ⭐⭐⭐ | Very Good | Free (cloud $) | Microservices |
| **OpenAI** | `pip install openai` | 3 | ⭐⭐⭐⭐⭐⭐ | SOTA | Usage-based | Zero-infra |
| **Cohere** | `pip install cohere` | 3 | ⭐⭐⭐⭐⭐ | Excellent | Usage-based | Multilingual |

---

## Additional Resources

### Documentation
- [Sentence Transformers](https://www.sbert.net)
- [Hugging Face Transformers](https://huggingface.co/docs/transformers)
- [FlagEmbedding](https://github.com/FlagOpen/FlagEmbedding)
- [Jina AI](https://jina.ai)
- [OpenAI Embeddings](https://platform.openai.com/docs/guides/embeddings)
- [MTEB Benchmark](https://huggingface.co/spaces/mteb/leaderboard)

### Model Hubs
- [Hugging Face Models](https://huggingface.co/models)
- [MTEB Leaderboard](https://huggingface.co/spaces/mteb/leaderboard)

### Tools
- [FAISS](https://github.com/facebookresearch/faiss) - Vector similarity search
- [Annoy](https://github.com/spotify/annoy) - Approximate nearest neighbors
- [Milvus](https://milvus.io/) - Vector database

---

*Document Version: 1.0*  
*Author: Generated for sqloquent-vectordb development*  
*Date: January 2026*
