# Vector Database Package for Sqloquent

## Overview

This document summarizes the discussion about adapting the Sqloquent SQL ORM for vector database functionality. The conclusion is to create a separate package that depends on sqloquent, providing vector database capabilities while maintaining clean separation of concerns.

## Key Insights

### 1. Sqloquent Architecture is Already Suitable

The existing Sqloquent architecture provides an excellent foundation for vector database operations without requiring modifications:

- **Protocol-based design** allows easy extension
- **Query builder pattern** can be extended for vector operations  
- **Relation system** (Contains, Within) demonstrates sophisticated relationship handling
- **Event hook system** can be used for vector similarity calculations, caching, and pre-fetching
- **Connection pooling** already implemented via thread-local storage

### 2. SQLite as Persistence Layer is Viable

For small to medium datasets (up to ~100K vectors), using SQLite as the primary backend is highly feasible:

**Advantages:**
- Efficient storage of vector metadata
- Simple deployment and management
- ACID compliance for data integrity
- Handles vector BLOB storage reasonably well

**Challenges:**
- No native vector indexing in SQLite
- Similarity search requires in-memory processing
- Limited scalability for very large vector collections

**Solution:** Hybrid approach with in-memory vector indexing (FAISS, Annoy) + SQLite persistence

## Recommended Package Architecture

### New Package: `sqloquent-vectordb`

Dependencies: `sqloquent` + vector indexing library (FAISS recommended)

### Core Components

#### 1. Vector Document Model

```python
class VectorDocument(SqlModel):
    """Base class for vector documents extending SqlModel."""
    
    connection_info = ''
    table = 'vector_documents'
    columns = ('id', 'content', 'embedding', 'metadata')
    
    # Embedding storage
    embedding: bytes  # Serialized numpy array
    metadata: str    # JSON metadata
    
    # Class-level embedding provider
    _embedding_provider: Optional[EmbeddingProtocol] = None
```

#### 2. Pluggable Embedding Provider System

```python
@runtime_checkable
class EmbeddingProtocol(Protocol):
    """Protocol for embedding generation."""
    
    def embed_text(self, text: str) -> np.ndarray:
        """Generate embedding for a single text."""
        ...
    
    def embed_texts(self, texts: list[str]) -> np.ndarray:
        """Generate embeddings for multiple texts (batched)."""
        ...
    
    @property
    def embedding_dimension(self) -> int:
        """Return the dimension of generated embeddings."""
        ...
```

**Provided Providers:**

- **`DefaultEmbeddingProvider`**: Uses sentence-transformers with sensible defaults
- **`HuggingFaceEmbeddingProvider`**: Flexible Hugging Face model integration
- **`OpenAIEmbeddingProvider`**: Cloud API option (optional)
- **`CustomEmbeddingProvider`**: User brings their own logic

#### 3. Vector Query Builder

```python
class VectorQueryBuilder(SqlQueryBuilder):
    """Extended query builder with vector operations."""
    
    def with_vectors(self, vector_column: str = 'embedding') -> 'VectorQueryBuilder':
        """Enable vector operations on this query."""
    
    def nearest_neighbors(self, query_vector: np.ndarray, k: int = 10) -> list[ModelProtocol]:
        """Find k nearest neighbors using cached index."""
    
    def within_distance(self, vector_column: str, query_vector: np.ndarray, 
                       max_distance: float) -> QueryBuilderProtocol:
        """Find all vectors within specified distance threshold."""
```

#### 4. Vector Cache and Index Management

```python
class VectorCache:
    """Smart caching and indexing for vector operations."""
    
    def __init__(self, model: Type[SqlModel], vector_column: str):
        # Initialize FAISS index or similar
        # Implement lazy loading and incremental building
        pass
    
    def _build_index(self):
        """Build index from SQLite data in batches."""
        # Load vectors in chunks
        # Build incremental index
        # Cache frequently accessed vectors
        pass
```

### User Experience Design

#### Default Usage (Zero Configuration)

```python
from vector_db import VectorDocument

# Use default embedding provider (sentence-transformers, local)
document = VectorDocument.insert_with_embedding(
    content="Your document text here",
    metadata={"category": "example"}
)

# Find similar documents
similar = document.search_similar(k=10)
```

#### Custom Embedding Provider

```python
from vector_db import VectorDocument, CustomEmbeddingProvider

# Option 1: Bring your own embedding function
def my_custom_embedding(text: str) -> list[float]:
    """Custom embedding logic."""
    # User's custom implementation
    return [0.1, 0.2, 0.3, ...]  # 384-dimensional vector

VectorDocument.set_embedding_provider(
    CustomEmbeddingProvider(my_custom_embedding, dimension=384)
)

# Option 2: Use specific model
from vector_db import HuggingFaceEmbeddingProvider
VectorDocument.set_embedding_provider(
    HuggingFaceEmbeddingProvider('e5-large-v2', device='cuda')
)
```

#### Advanced Querying

```python
from vector_db import VectorQueryBuilder

# Complex queries combining vector search with SQL filters
results = (VectorQueryBuilder(VectorDocument)
           .with_vectors('embedding')
           .equal('category', 'science')
           .nearest_neighbors(query_vector, k=10)
           .take(10)
           .get())
```

## Implementation Plan

### Phase 1: Foundation
- Extend SqlModel for vector serialization/deserialization
- Add vector column types to migration system
- Implement DefaultEmbeddingProvider with sentence-transformers

### Phase 2: Indexing and Search
- Implement VectorCache with FAISS integration
- Add nearest_neighbors query method
- Build incremental index updating

### Phase 3: Advanced Features
- Support multiple distance metrics (cosine, euclidean, dot product)
- Add vector dimension reduction (PCA, SVD)
- Implement vector filters and combinations
- Add batch embedding operations

### Phase 4: Optimization
- Implement smart caching strategies
- Add vector clustering support
- Consider sharding for large datasets
- Performance tuning and benchmarking

## Hardware Requirements

### Minimum Viable Setup (CPU-only)
- **Hardware**: Any modern CPU (i5/Ryzen 5+)
- **RAM**: 8GB minimum, 16GB recommended
- **Storage**: 10GB for models + data
- **Performance**: 0.5-2 seconds per embedding
- **Cost**: $0 if using existing hardware

### Recommended Setup (GPU)
- **Hardware**: NVIDIA GPU with 4GB+ VRAM (RTX 3060 or better)
- **RAM**: 16GB minimum, 32GB recommended
- **Storage**: 50GB+ SSD
- **Performance**: 0.01-0.1 seconds per embedding
- **Cost**: $300-1000 for GPU hardware

### Performance Estimates (100K vectors, 384 dimensions)
- **Memory**: ~145 MB for vectors + 200-300 MB for FAISS index
- **Index building**: 1-5 seconds
- **Similarity search**: ~1-10ms with FAISS
- **Metadata retrieval**: <1ms per record from SQLite

## Popular Local Embedding Models

| Model | Size | Dimensions | Quality | Speed | Use Case |
|-------|------|------------|---------|-------|----------|
| all-MiniLM-L6-v2 | 100MB | 384 | Good | Very Fast | General purpose, low resource |
| all-mpnet-base-v2 | 400MB | 768 | Excellent | Fast | High quality, balanced |
| e5-small-v2 | 130MB | 384 | Very Good | Very Fast | Modern, good performance |
| e5-large-v2 | 1.3GB | 1024 | Excellent | Medium | Best quality, needs GPU |
| bge-small-en-v1.5 | 130MB | 384 | Excellent | Very Fast | State-of-the-art small model |

## Benefits of This Approach

1. **Zero Configuration**: Sensible defaults work out of the box for most users
2. **Maximum Flexibility**: Users can choose local vs cloud, custom vs pretrained embeddings
3. **No Forced Dependencies**: Only install what you need
4. **Easy to Extend**: New providers can be added easily
5. **Cost-Effective**: Users choose based on their needs and budget
6. **Maintains Sqloquent Principles**: Clean separation, protocol-based design
7. **Scalable**: Works from small prototypes to medium-scale production

## Conclusion

Creating a separate `sqloquent-vectordb` package that depends on sqloquent is the optimal approach. It:

- Leverages sqloquent's existing strengths without modification
- Provides sensible defaults for quick start
- Offers maximum flexibility for advanced use cases
- Maintains clean package boundaries
- Allows independent evolution and versioning

The hybrid approach of SQLite persistence + in-memory vector indexing provides an excellent balance of simplicity, performance, and cost-effectiveness for most vector database use cases.
