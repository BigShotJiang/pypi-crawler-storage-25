from sqloquent import HashedModel, DeletedModel, contains, within


class DAGItem(HashedModel):
    connection_info: str = 'temp.db'
    table: str = 'd_a_g_items'
    id_column: str = 'id'
    columns: tuple[str] = ('id', 'name', 'parent_ids')
    id: bytes
    name: str
    parent_ids: bytes|None


DAGItem.parents = contains(DAGItem, DAGItem, 'parent_ids')
DAGItem.children = within(DAGItem, DAGItem, 'parent_ids')

DeletedModel.connection_info = 'temp.db'
