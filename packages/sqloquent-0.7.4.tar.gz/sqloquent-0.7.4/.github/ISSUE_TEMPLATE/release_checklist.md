---
name: Release Checklist
about: Create a new release checklist. For maintainer use only.
title: 'Release Checklist: v0.0.0'
labels: task
assignees: k98kurz

---

## Release Checklist

<!-- For maintainer use only. If you are not a maintainer, do not use this template. -->

Once all other issues are complete, prepare to release the next version.

- Review and update docstrings
  - [ ] `classes.py`
  - [ ] `interfaces.py`
  - [ ] `relations.py`
  - [ ] `asyncql/classes.py`
  - [ ] `asyncql/interfaces.py`
  - [ ] `asyncql/relations.py`
  - [ ] `migration.py`
  - [ ] `tools.py`
- Update documentation:
  - [ ] `readme.md`
  - [ ] `changelog.md`
  - [ ] `migrations.md`
  - [ ] `how-to-couple.md`
  - [ ] autodox: `dox.md`, `interfaces.md`, `asyncql_dox.md`, `async_interfaces.md`, `tools.md`
- [ ] Review and finalize documentation
- [ ] Ensure version strings are set to `'M.m.p'`
  - `version.py`
  - `pyproject.toml`
  - `readme.md` links
  - `how-to-couple.md` links
- [ ] Close milestone on GitHub
- [ ] Push tag and make release on GitHub
- [ ] Update PyPI
