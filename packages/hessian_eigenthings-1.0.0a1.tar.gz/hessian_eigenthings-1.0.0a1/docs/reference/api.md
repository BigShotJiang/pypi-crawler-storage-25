# API

::: hessian_eigenthings
