class ToNodeException(Exception):
    def __init__(self, info: str) -> None:
        super().__init__()
        self._info = info

    def __str__(self) -> str:
        return "The type for conversion is not defined: {}".format(self._info)
