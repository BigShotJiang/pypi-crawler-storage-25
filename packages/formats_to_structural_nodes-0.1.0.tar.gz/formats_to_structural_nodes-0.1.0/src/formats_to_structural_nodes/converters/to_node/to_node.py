from typing import Any

from more_structural_nodes import Array
from more_structural_nodes import ObjectNode
from more_structural_nodes import String
from more_structural_nodes import Integer
from more_structural_nodes import Float
from more_structural_nodes import Boolean
from more_structural_nodes import Null

from formats_to_structural_nodes.exceptions.to_node_exception import (
    ToNodeException
    )

from more_structural_nodes import BaseStructuralNode


class ToNode:
    def __init__(self, structure: Any) -> None:
        self._structure = structure
        self._base_node = self._convert(structure)

    def get_base_node(self) -> BaseStructuralNode:
        return self._base_node

    def _convert(self,
                 object: Any,
                 object_name: str = None) -> BaseStructuralNode:
        if isinstance(object, dict):
            node = ObjectNode(object_name)
            for name, value in object.items():
                node.add_child_node(self._convert(value, name))
            return node
        elif isinstance(object, list):
            node = Array(object_name)
            for value in object:
                node.add_child_node(self._convert(value))
            return node
        elif isinstance(object, str):
            node = String(object_name)
            node.set_value(object)
            return node
        elif isinstance(object, bool):
            node = Boolean(object_name)
            node.set_value(object)
            return node
        elif isinstance(object, float):
            node = Float(object_name)
            node.set_value(object)
            return node
        elif isinstance(object, int):
            node = Integer(object_name)
            node.set_value(object)
            return node
        elif object is None:
            return Null(object_name)
        else:
            raise ToNodeException(str(object))
