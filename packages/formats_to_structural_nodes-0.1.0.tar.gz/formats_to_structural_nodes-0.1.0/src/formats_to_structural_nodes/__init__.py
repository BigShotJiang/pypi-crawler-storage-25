# flake8: noqa: F401
from typing import Any
from more_structural_nodes import BaseStructuralNode

from formats_to_structural_nodes.converters.to_node.to_node import (
    ToNode
)


def to_node(object: Any) -> BaseStructuralNode:
    return ToNode(object).get_base_node()
