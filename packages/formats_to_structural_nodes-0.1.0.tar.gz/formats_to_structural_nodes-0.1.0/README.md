# Description
The library is designed to convert various structures into more-structural-nodes library nodes.