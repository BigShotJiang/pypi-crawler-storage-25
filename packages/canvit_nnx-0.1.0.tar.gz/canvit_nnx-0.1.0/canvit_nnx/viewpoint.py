"""Glimpse extraction via viewpoint sampling.

Coordinate convention (shared with canvit_nnx.model):
- Coordinates are in [-1, 1]²
- (0, 0) is image center, (-1, -1) is top-left, (1, 1) is bottom-right
- Axis order is (y, x) — matrix indexing convention, NOT Cartesian
- scales: 1 = full scene, <1 = zoomed in

Matches PyTorch F.grid_sample with align_corners=False.
"""

from __future__ import annotations

import jax
import jax.numpy as jnp

from canvit_nnx.model import Viewpoint

Array = jax.Array


def sample_at_viewpoint(
    spatial: Array,
    viewpoint: Viewpoint,
    glimpse_size_px: int,
) -> Array:
    """Bilinear crop from spatial tensor at viewpoint position.

    Args:
        spatial: [B, H, W, C] image or feature map (NHWC)
        viewpoint: where to look (centers [B, 2], scales [B])
        glimpse_size_px: output spatial size (square)

    Returns:
        [B, glimpse_size_px, glimpse_size_px, C] bilinearly sampled crop
    """
    B, H, W, C = spatial.shape
    g = glimpse_size_px

    # Sampling grid in [-1, 1] — cell centers
    ys = (jnp.arange(g, dtype=jnp.float32) + 0.5) / g * 2 - 1
    xs = (jnp.arange(g, dtype=jnp.float32) + 0.5) / g * 2 - 1
    grid_y, grid_x = jnp.meshgrid(ys, xs, indexing="ij")
    grid = jnp.stack([grid_y, grid_x], axis=-1)  # [g, g, 2]

    # Scene-space positions: center + scale * grid
    center = viewpoint.centers[:, None, None, :]  # [B, 1, 1, 2]
    scale = viewpoint.scales[:, None, None, None]  # [B, 1, 1, 1]
    scene_pos = center + scale * grid[None]  # [B, g, g, 2]

    # [-1, 1] → pixel coords (align_corners=False: pixel = (grid + 1) * N / 2 - 0.5)
    pixel_y = (scene_pos[..., 0] + 1) * H / 2 - 0.5
    pixel_x = (scene_pos[..., 1] + 1) * W / 2 - 0.5

    # Bilinear interpolation
    y0 = jnp.floor(pixel_y).astype(jnp.int32)
    x0 = jnp.floor(pixel_x).astype(jnp.int32)
    y1 = y0 + 1
    x1 = x0 + 1

    y0c = jnp.clip(y0, 0, H - 1)
    y1c = jnp.clip(y1, 0, H - 1)
    x0c = jnp.clip(x0, 0, W - 1)
    x1c = jnp.clip(x1, 0, W - 1)

    wy = pixel_y - y0.astype(jnp.float32)
    wx = pixel_x - x0.astype(jnp.float32)

    b_idx = jnp.arange(B)[:, None, None]
    val00 = spatial[b_idx, y0c, x0c]
    val01 = spatial[b_idx, y0c, x1c]
    val10 = spatial[b_idx, y1c, x0c]
    val11 = spatial[b_idx, y1c, x1c]

    return (val00 * (1 - wy[..., None]) * (1 - wx[..., None]) +
            val01 * (1 - wy[..., None]) * wx[..., None] +
            val10 * wy[..., None] * (1 - wx[..., None]) +
            val11 * wy[..., None] * wx[..., None])
