"""CanViT: dual-stream vision transformer with canvas cross-attention.

Self-contained Flax NNX implementation. No external model dependencies.
Reference: CanViT-PyTorch (authoritative) and CanViT-MLX (compact port).

Conventions:
  - Images are NHWC (channels-last), matching JAX/XLA native layout.
  - Coordinates are (y, x) order in [-1, 1]², matching tensor [H, W] indexing.
  - RoPE is always computed and applied in float32.
  - Canvas layout: [registers | spatial].
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import NamedTuple

import flax.nnx as nnx
import jax
import jax.numpy as jnp

Array = jax.Array


# =============================================================================
# Config
# =============================================================================


@dataclass(frozen=True)
class CanViTConfig:
    embed_dim: int = 768
    num_heads: int = 12
    n_blocks: int = 12
    patch_size: int = 16
    ffn_ratio: float = 4.0
    rope_base: float = 100.0
    layerscale_init: float = 1e-5

    rw_stride: int = 2
    enable_reads: bool = True
    n_backbone_registers: int = 5
    n_canvas_registers: int = 16
    canvas_num_heads: int = 8
    canvas_head_dim: int = 128
    enable_vpe: bool = True

    @property
    def canvas_dim(self) -> int:
        return self.canvas_num_heads * self.canvas_head_dim

    @property
    def head_dim(self) -> int:
        return self.embed_dim // self.num_heads


CANVIT_B16 = CanViTConfig()


# =============================================================================
# Data types
# =============================================================================


@jax.tree_util.register_dataclass
@dataclass
class Viewpoint:
    centers: Array  # [B, 2] in [-1, 1], (y, x) order, float32
    scales: Array   # [B], float32

    @staticmethod
    def full_scene(batch_size: int) -> Viewpoint:
        return Viewpoint(
            centers=jnp.zeros((batch_size, 2), dtype=jnp.float32),
            scales=jnp.ones((batch_size,), dtype=jnp.float32),
        )


@jax.tree_util.register_dataclass
@dataclass
class RecurrentState:
    canvas: Array       # [B, n_canvas_registers + G², canvas_dim]
    recurrent_cls: Array  # [B, 1, local_dim]


class CanViTOutput(NamedTuple):
    state: RecurrentState
    local_patches: Array  # [B, H*W, local_dim]


# =============================================================================
# Coordinates
# =============================================================================


def grid_coords(H: int, W: int) -> Array:
    """Normalized [-1, 1] cell-center coordinates. Returns [H*W, 2] in (y, x) order."""
    y = (jnp.arange(H, dtype=jnp.float32) + 0.5) / H * 2 - 1
    x = (jnp.arange(W, dtype=jnp.float32) + 0.5) / W * 2 - 1
    yy, xx = jnp.meshgrid(y, x, indexing="ij")
    return jnp.stack([yy, xx], axis=-1).reshape(H * W, 2)


def glimpse_positions(center: Array, scale: Array, H: int, W: int) -> Array:
    """Scene-space positions for a glimpse grid. Returns [B, H*W, 2]."""
    retino = grid_coords(H, W)  # [H*W, 2]
    return center[:, None, :] + scale[:, None, None] * retino[None, :, :]


# =============================================================================
# 2D Rotary Position Embeddings
# =============================================================================


def _rope_periods(head_dim: int, base: float) -> Array:
    """Geometric frequency periods for 2D RoPE. Returns [head_dim // 4]."""
    assert head_dim % 4 == 0
    n = head_dim // 4
    return base ** (jnp.arange(n, dtype=jnp.float32) / n)


class RoPE(NamedTuple):
    sin: Array  # [B, N, 1, head_dim]  (BTNH layout for JAX SDPA)
    cos: Array  # [B, N, 1, head_dim]


def compute_rope(positions: Array, head_dim: int, base: float) -> RoPE:
    """Compute 2D RoPE sin/cos from positions [B, N, 2]. Always float32."""
    periods = _rope_periods(head_dim, base)
    # [B, N, 2, 1] / [n_freqs] -> [B, N, 2, n_freqs]
    angles = 2 * math.pi * positions[..., None].astype(jnp.float32) / periods
    B, N = angles.shape[:2]
    angles = jnp.tile(angles.reshape(B, N, -1), (1, 1, 2))  # [B, N, head_dim]
    sin = jnp.sin(angles)[:, :, None, :]  # [B, N, 1, head_dim]
    cos = jnp.cos(angles)[:, :, None, :]
    return RoPE(sin, cos)


def apply_rope(x: Array, rope: RoPE) -> Array:
    """Apply RoPE rotation to spatial tokens, leaving prefix tokens unchanged.

    x: [B, N_total, H, head_dim] (BTNH layout). RoPE covers N_spatial tokens.
    Rotation is in float32; result cast back to x.dtype.
    """
    n_prefix = x.shape[1] - rope.sin.shape[1]
    half = x.shape[3] // 2
    x_s = x[:, n_prefix:].astype(jnp.float32)
    x_rot = jnp.concatenate([-x_s[..., half:], x_s[..., :half]], axis=-1)
    spatial = (x_s * rope.cos + x_rot * rope.sin).astype(x.dtype)
    if n_prefix > 0:
        return jnp.concatenate([x[:, :n_prefix], spatial], axis=1)
    return spatial


# =============================================================================
# Building blocks
# =============================================================================


class PatchEmbed(nnx.Module):
    def __init__(self, patch_size: int, embed_dim: int, rngs: nnx.Rngs):
        self.proj = nnx.Conv(3, embed_dim, kernel_size=(patch_size, patch_size),
                             strides=(patch_size, patch_size), padding="VALID",
                             use_bias=True, rngs=rngs)

    def __call__(self, x: Array) -> tuple[Array, int, int]:
        """x: [B, H, W, 3] -> patches [B, H'*W', D], H', W'."""
        x = self.proj(x)
        B, H, W, D = x.shape
        return x.reshape(B, H * W, D), H, W


class LayerScale(nnx.Module):
    def __init__(self, dim: int, init_value: float = 1e-5):
        self.gamma = nnx.Param(jnp.full((dim,), init_value))

    def __call__(self, x: Array) -> Array:
        return x * self.gamma


class MLP(nnx.Module):
    def __init__(self, dim: int, hidden_dim: int, rngs: nnx.Rngs):
        self.fc1 = nnx.Linear(dim, hidden_dim, rngs=rngs)
        self.fc2 = nnx.Linear(hidden_dim, dim, rngs=rngs)

    def __call__(self, x: Array) -> Array:
        # approximate=False: JAX defaults to tanh approx, PyTorch to exact
        return self.fc2(jax.nn.gelu(self.fc1(x), approximate=False))


class SelfAttention(nnx.Module):
    """Multi-head self-attention with fused QKV and 2D RoPE.

    Matches DINOv3 convention: K bias is zeroed out (Q and V biases active).
    """

    def __init__(self, dim: int, num_heads: int, rngs: nnx.Rngs):
        assert dim % num_heads == 0
        self.num_heads = num_heads
        self.head_dim = dim // num_heads
        self.scale = self.head_dim ** -0.5
        self.qkv = nnx.Linear(dim, dim * 3, rngs=rngs)
        # Mask: Q bias ON, K bias OFF, V bias ON (DINOv3 convention)
        self._bias_mask = nnx.Variable(
            jnp.concatenate([jnp.ones(dim), jnp.zeros(dim), jnp.ones(dim)])
        )
        self.proj = nnx.Linear(dim, dim, rngs=rngs)

    def __call__(self, x: Array, rope: RoPE) -> Array:
        B, N, D = x.shape
        # Manual matmul with masked bias (K bias zeroed, DINOv3 convention)
        qkv = x @ self.qkv.kernel[...]  # NNX kernel is (in, out)
        if self.qkv.bias is not None:
            qkv = qkv + self.qkv.bias[...] * self._bias_mask[...]
        qkv = qkv.reshape(B, N, 3, self.num_heads, self.head_dim)
        q = qkv[:, :, 0]  # [B, N, H, D_h] — BTNH for JAX SDPA
        k = qkv[:, :, 1]
        v = qkv[:, :, 2]
        q = apply_rope(q, rope)
        k = apply_rope(k, rope)
        out = jax.nn.dot_product_attention(q, k, v, scale=self.scale)
        return self.proj(out.reshape(B, N, D))


class ViTBlock(nnx.Module):
    def __init__(self, dim: int, num_heads: int, ffn_ratio: float,
                 layerscale_init: float, rngs: nnx.Rngs):
        self.norm1 = nnx.LayerNorm(dim, epsilon=1e-5, rngs=rngs)
        self.attn = SelfAttention(dim, num_heads, rngs=rngs)
        self.ls1 = LayerScale(dim, layerscale_init)
        self.norm2 = nnx.LayerNorm(dim, epsilon=1e-5, rngs=rngs)
        self.mlp = MLP(dim, int(dim * ffn_ratio), rngs=rngs)
        self.ls2 = LayerScale(dim, layerscale_init)

    def __call__(self, x: Array, rope: RoPE) -> Array:
        x = x + self.ls1(self.attn(self.norm1(x), rope))
        return x + self.ls2(self.mlp(self.norm2(x)))


# =============================================================================
# Canvas attention (asymmetric cross-attention)
# =============================================================================


def _to_multihead(x: Array, num_heads: int) -> Array:
    """[B, N, D] -> [B, N, H, head_dim] (JAX SDPA expects BTNH)."""
    B, N, D = x.shape
    return x.reshape(B, N, num_heads, D // num_heads)


def _from_multihead(x: Array) -> Array:
    """[B, N, H, head_dim] -> [B, N, D]."""
    B, N, H, hd = x.shape
    return x.reshape(B, N, H * hd)


class CanvasReadAttention(nnx.Module):
    """Local queries canvas. Dense projections on local side only (asymmetric)."""

    def __init__(self, local_dim: int, canvas_dim: int, num_heads: int, rngs: nnx.Rngs):
        assert canvas_dim % num_heads == 0
        self.num_heads = num_heads
        self.scale = (canvas_dim // num_heads) ** -0.5
        self.q_norm = nnx.LayerNorm(local_dim, epsilon=1e-5, rngs=rngs)
        self.kv_norm = nnx.LayerNorm(canvas_dim, epsilon=1e-5, rngs=rngs)
        self.q_proj = nnx.Linear(local_dim, canvas_dim, rngs=rngs)
        self.out_proj = nnx.Linear(canvas_dim, local_dim, rngs=rngs)

    def __call__(self, query: Array, kv: Array,
                 q_rope: RoPE, kv_rope: RoPE) -> Array:
        q = _to_multihead(self.q_proj(self.q_norm(query)), self.num_heads)
        kv_n = self.kv_norm(kv)
        k = _to_multihead(kv_n, self.num_heads)  # Identity projection
        v = _to_multihead(kv_n, self.num_heads)
        q = apply_rope(q, q_rope)
        k = apply_rope(k, kv_rope)
        out = jax.nn.dot_product_attention(q, k.astype(q.dtype), v.astype(q.dtype),
                                           scale=self.scale)
        return self.out_proj(_from_multihead(out))


class CanvasWriteAttention(nnx.Module):
    """Canvas queries local. Dense projections on local side only (asymmetric).

    When gate_bias_init is set, uses convex update: lerp(canvas, attn_out, gate).
    """

    def __init__(self, local_dim: int, canvas_dim: int, num_heads: int,
                 rngs: nnx.Rngs, gate_bias_init: float | None = None):
        assert canvas_dim % num_heads == 0
        self.num_heads = num_heads
        self.scale = (canvas_dim // num_heads) ** -0.5
        self.q_norm = nnx.LayerNorm(canvas_dim, epsilon=1e-5, rngs=rngs)
        self.kv_norm = nnx.LayerNorm(local_dim, epsilon=1e-5, rngs=rngs)
        self.k_proj = nnx.Linear(local_dim, canvas_dim, rngs=rngs)
        self.v_proj = nnx.Linear(local_dim, canvas_dim, rngs=rngs)
        self.gate_linear: nnx.Linear | None = None
        if gate_bias_init is not None:
            self.gate_linear = nnx.Linear(canvas_dim, 1, rngs=rngs)
            self.gate_linear.bias = nnx.Param(jnp.full((1,), gate_bias_init))

    @property
    def is_convex(self) -> bool:
        return self.gate_linear is not None

    def __call__(self, query: Array, kv: Array,
                 q_rope: RoPE, kv_rope: RoPE) -> Array:
        q = _to_multihead(self.q_norm(query), self.num_heads)  # Identity projection
        kv_n = self.kv_norm(kv)
        k = _to_multihead(self.k_proj(kv_n), self.num_heads)
        v = _to_multihead(self.v_proj(kv_n), self.num_heads)
        q = apply_rope(q, q_rope)
        k = apply_rope(k, kv_rope)
        attn_out = _from_multihead(
            jax.nn.dot_product_attention(q, k.astype(q.dtype), v.astype(q.dtype),
                                         scale=self.scale)
        )
        if self.gate_linear is None:
            return attn_out
        gate = jax.nn.sigmoid(self.gate_linear(attn_out))
        return (1 - gate) * query + gate * attn_out


# =============================================================================
# VPE: Viewpoint Positional Encoding
# =============================================================================


class VPEEncoder(nnx.Module):
    """Encodes (y, x, scale) viewpoint into a high-dimensional vector via Random Fourier Features."""

    def __init__(self, rff_dim: int, *, rngs: nnx.Rngs, seed: int = 42):
        assert rff_dim > 0 and rff_dim % 2 == 0
        self.rff_dim = rff_dim
        # Frozen RFF projection matrix — deterministic from seed, not from rngs
        key = jax.random.PRNGKey(seed)
        self.B_mat = nnx.Variable(jax.random.normal(key, (rff_dim // 2, 3), dtype=jnp.float32))
        self.norm = nnx.LayerNorm(rff_dim, epsilon=1e-5, rngs=rngs)
        # Match PyTorch init: scale = 1/sqrt(rff_dim)
        self.norm.scale = nnx.Param(jnp.full((rff_dim,), 1.0 / math.sqrt(rff_dim)))

    def __call__(self, y: Array, x: Array, s: Array) -> Array:
        """y, x: [B], s: [B] -> [B, rff_dim]. Always float32."""
        z = jnp.stack([y / s, x / s, jnp.log(s)], axis=-1).astype(jnp.float32)
        proj = z @ self.B_mat[...].T
        enc = jnp.concatenate([jnp.cos(proj), jnp.sin(proj)], axis=-1)
        return self.norm(enc)


# =============================================================================
# CanViT: the full model
# =============================================================================


def _compute_rw_positions(n_blocks: int, rw_stride: int,
                          enable_reads: bool) -> tuple[list[int], list[int]]:
    """Schedule read/write operations across blocks.

    Pattern: [rw_stride blocks] R [rw_stride blocks] W ... Always ends with W.
    """
    read_after: list[int] = []
    write_after: list[int] = []
    for i, pos in enumerate(range(rw_stride - 1, n_blocks, rw_stride)):
        if i % 2 == 0:
            read_after.append(pos)
        else:
            write_after.append(pos)
    if not write_after or write_after[-1] != n_blocks - 1:
        write_after.append(n_blocks - 1)
    if not enable_reads:
        read_after = []
    return read_after, write_after


class CanViT(nnx.Module):
    """Dual-stream vision transformer with canvas cross-attention.

    Processes NHWC glimpses. Canvas and CLS token persist across timesteps.
    Generalizes to any canvas and glimpse grid sizes at runtime via RoPE.
    """

    def __init__(self, cfg: CanViTConfig = CANVIT_B16, *, rngs: nnx.Rngs):
        self.cfg = cfg
        d = cfg.embed_dim
        cd = cfg.canvas_dim

        # Backbone
        self.patch_embed = PatchEmbed(cfg.patch_size, d, rngs)
        self.blocks = nnx.List([
            ViTBlock(d, cfg.num_heads, cfg.ffn_ratio, cfg.layerscale_init, rngs)
            for _ in range(cfg.n_blocks)
        ])

        # Read/write schedule
        read_after, write_after = _compute_rw_positions(
            cfg.n_blocks, cfg.rw_stride, cfg.enable_reads)
        self._read_after = tuple(read_after)
        self._write_after = tuple(write_after)

        # Canvas attention layers
        self.canvas_read = nnx.List([
            CanvasReadAttention(d, cd, cfg.canvas_num_heads, rngs)
            for _ in read_after
        ])
        self.canvas_write = nnx.List([
            CanvasWriteAttention(d, cd, cfg.canvas_num_heads, rngs)
            for _ in write_after
        ])

        # Learnable inits
        canvas_scale = 1.0 / math.sqrt(cd)
        local_scale = 1.0 / math.sqrt(d)
        self.canvas_register_init = nnx.Param(
            jax.random.normal(rngs.params(), (1, cfg.n_canvas_registers, cd)) * canvas_scale
        )
        self.canvas_spatial_init = nnx.Param(
            jax.random.normal(rngs.params(), (1, 1, cd)) * canvas_scale
        )
        self.recurrent_cls_init = nnx.Param(
            jax.random.normal(rngs.params(), (1, 1, d)) * local_scale
        )
        self.backbone_registers = nnx.Param(
            jax.random.normal(rngs.params(), (1, cfg.n_backbone_registers, d)) * 0.02
        )

        # VPE
        if cfg.enable_vpe:
            self.vpe = VPEEncoder(rff_dim=d, rngs=rngs)
        else:
            self.vpe = nnx.data(None)

    def init_state(self, batch_size: int, canvas_grid_size: int) -> RecurrentState:
        cfg = self.cfg
        n_spatial = canvas_grid_size ** 2
        regs = jnp.broadcast_to(self.canvas_register_init[...], (batch_size, cfg.n_canvas_registers, cfg.canvas_dim))
        spatial = jnp.broadcast_to(self.canvas_spatial_init[...], (batch_size, n_spatial, cfg.canvas_dim))
        return RecurrentState(
            canvas=jnp.concatenate([regs, spatial], axis=1),
            recurrent_cls=jnp.broadcast_to(self.recurrent_cls_init[...], (batch_size, 1, cfg.embed_dim)),
        )

    def get_spatial(self, canvas: Array) -> Array:
        return canvas[:, self.cfg.n_canvas_registers:]

    def __call__(self, glimpse: Array, state: RecurrentState,
                 viewpoint: Viewpoint) -> CanViTOutput:
        """Process one glimpse. glimpse: [B, H, W, 3] NHWC."""
        B = glimpse.shape[0]
        cfg = self.cfg
        canvas = state.canvas

        # Patch embed
        patches, H, W = self.patch_embed(glimpse)
        assert H == W
        n_patches = H * W

        # Assemble local tokens: [vpe?, cls, registers, patches]
        parts: list[Array] = []
        has_vpe = self.vpe is not None
        if has_vpe:
            vpe_tok = self.vpe(
                viewpoint.centers[:, 0], viewpoint.centers[:, 1], viewpoint.scales
            )
            parts.append(vpe_tok[:, None, :].astype(patches.dtype))
        parts.extend([
            state.recurrent_cls,
            jnp.broadcast_to(self.backbone_registers[...], (B, cfg.n_backbone_registers, cfg.embed_dim)),
            patches,
        ])
        local = jnp.concatenate(parts, axis=1)

        # RoPE for local and canvas positions
        local_pos = glimpse_positions(viewpoint.centers, viewpoint.scales, H, W)
        bb_rope = compute_rope(local_pos, cfg.head_dim, cfg.rope_base)
        ca_local_rope = compute_rope(local_pos, cfg.canvas_head_dim, cfg.rope_base)

        n_spatial = canvas.shape[1] - cfg.n_canvas_registers
        cg = int(math.sqrt(n_spatial))
        assert cg * cg == n_spatial
        canvas_pos = jnp.broadcast_to(grid_coords(cg, cg)[None], (B, n_spatial, 2))
        ca_canvas_rope = compute_rope(canvas_pos, cfg.canvas_head_dim, cfg.rope_base)

        # Process through blocks with interleaved read/write
        ri, wi = 0, 0
        for bi in range(cfg.n_blocks):
            local = self.blocks[bi](local, bb_rope)

            if ri < len(self._read_after) and bi == self._read_after[ri]:
                local = local + self.canvas_read[ri](local, canvas, ca_local_rope, ca_canvas_rope)
                ri += 1

            if wi < len(self._write_after) and bi == self._write_after[wi]:
                write_out = self.canvas_write[wi](canvas, local, ca_canvas_rope, ca_local_rope)
                canvas = write_out if self.canvas_write[wi].is_convex else canvas + write_out
                wi += 1

        # Unpack
        idx = (1 if has_vpe else 0)
        new_cls = local[:, idx:idx + 1]
        idx += 1 + cfg.n_backbone_registers
        out_patches = local[:, idx:idx + n_patches]

        return CanViTOutput(
            state=RecurrentState(canvas=canvas, recurrent_cls=new_cls),
            local_patches=out_patches,
        )
