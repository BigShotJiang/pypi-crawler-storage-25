"""HuggingFace Hub integration: load and save JAX-native CanViT checkpoints.

No PyTorch dependency — loads directly from safetensors.
"""

from __future__ import annotations

import json
import logging
from pathlib import Path

import flax.nnx as nnx
import jax.numpy as jnp
import numpy as np

from canvit_nnx.model import CanViT, CanViTConfig

log = logging.getLogger(__name__)

PRETRAINED_REPO = "canvit/canvitb16-add-vpe-pretrain-g128px-s512px-in21k-dv3b16-2026-02-02-nnx"
FINETUNED_REPO = "canvit/canvitb16-add-vpe-finetune-g128px-s512px-in1k-2026-04-06-nnx"

def save_state(module: nnx.Module, path: str | Path) -> int:
    """Save all NNX module state to safetensors. Returns number of tensors saved."""
    from safetensors.numpy import save_file

    _, state = nnx.split(module)
    params = {}
    for path_tuple, leaf in state.flat_state():
        key = ".".join(str(p) for p in path_tuple)
        params[key] = np.array(leaf[...])

    save_file(params, str(path))
    log.info("Saved %d tensors to %s", len(params), path)
    return len(params)


def load_state(module: nnx.Module, path: str | Path) -> int:
    """Load safetensors weights into an NNX module. Returns number loaded.

    Every key in the checkpoint must exist in the module (and vice versa).
    """
    from safetensors import safe_open

    _, state = nnx.split(module)

    state_map: dict[str, tuple] = {}
    for path_tuple, leaf in state.flat_state():
        key = ".".join(str(p) for p in path_tuple)
        state_map[key] = leaf

    loaded = 0
    with safe_open(str(path), framework="numpy") as f:
        ckpt_keys = set(f.keys())
        model_keys = set(state_map.keys())

        missing_in_model = ckpt_keys - model_keys
        missing_in_ckpt = model_keys - ckpt_keys
        if missing_in_model:
            raise ValueError(f"Checkpoint has keys not in model: {sorted(missing_in_model)}")
        if missing_in_ckpt:
            raise ValueError(f"Model has keys not in checkpoint: {sorted(missing_in_ckpt)}")

        for key in sorted(f.keys()):
            leaf = state_map[key]
            arr = jnp.array(f.get_tensor(key), dtype=jnp.float32)
            if leaf[...].shape != arr.shape:
                raise ValueError(
                    f"Shape mismatch at {key}: model={leaf[...].shape}, checkpoint={arr.shape}"
                )
            leaf[...] = arr
            loaded += 1

    log.info("Loaded %d tensors from %s", loaded, path)
    return loaded


def from_pretrained(repo_id: str = PRETRAINED_REPO) -> CanViT:
    """Load pretrained CanViT from HuggingFace Hub (JAX-native checkpoint)."""
    from huggingface_hub import hf_hub_download

    config_path = hf_hub_download(repo_id, "config.json")
    weights_path = hf_hub_download(repo_id, "model.safetensors")

    config = json.loads(Path(config_path).read_text())
    mc = config["model_config"]
    valid = set(CanViTConfig.__dataclass_fields__)
    cfg = CanViTConfig(**{k: v for k, v in mc.items() if k in valid})

    model = CanViT(cfg, rngs=nnx.Rngs(0))
    load_state(model, weights_path)
    return model
