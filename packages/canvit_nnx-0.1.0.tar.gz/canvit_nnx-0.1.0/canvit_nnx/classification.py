"""CanViT for image classification: CanViT backbone + LN -> Linear head.

Mirrors the canvit_pytorch.model.classification API.
"""

from __future__ import annotations

import json
import logging
from pathlib import Path

import flax.nnx as nnx
import jax
import jax.numpy as jnp

from canvit_nnx.model import CanViT, CanViTConfig, RecurrentState, Viewpoint, CanViTOutput
from canvit_nnx.hub import load_state, FINETUNED_REPO

log = logging.getLogger(__name__)

Array = jax.Array


class CanViTForImageClassification(nnx.Module):
    """CanViT backbone + LN -> Linear classification head.

    Usage::

        clf = CanViTForImageClassification.from_pretrained()
        state = clf.init_state(batch_size=1, canvas_grid_size=32)
        logits, state = clf(glimpse, state, viewpoint)
    """

    def __init__(self, cfg: CanViTConfig, n_classes: int, *, rngs: nnx.Rngs):
        self.canvit = CanViT(cfg, rngs=rngs)
        self.norm = nnx.LayerNorm(cfg.embed_dim, epsilon=1e-5, rngs=rngs)
        self.head = nnx.Linear(cfg.embed_dim, n_classes, rngs=rngs)

    @property
    def n_classes(self) -> int:
        return self.head.out_features

    @property
    def cfg(self) -> CanViTConfig:
        return self.canvit.cfg

    def init_state(self, batch_size: int, canvas_grid_size: int) -> RecurrentState:
        return self.canvit.init_state(batch_size, canvas_grid_size)

    def __call__(self, glimpse: Array, state: RecurrentState,
                 viewpoint: Viewpoint) -> tuple[Array, RecurrentState]:
        """Returns (logits [B, n_classes], new_state)."""
        out = self.canvit(glimpse, state, viewpoint)
        cls = out.state.recurrent_cls[:, 0].astype(jnp.float32)
        logits = self.head(self.norm(cls))
        return logits, out.state

    def canvit_forward(self, glimpse: Array, state: RecurrentState,
                       viewpoint: Viewpoint) -> CanViTOutput:
        """Run CanViT backbone only (for training with separate head_forward)."""
        return self.canvit(glimpse, state, viewpoint)

    def head_forward(self, cls: Array) -> Array:
        """LN -> Linear on [B, D] CLS token."""
        return self.head(self.norm(cls.astype(jnp.float32)))

    @staticmethod
    def from_pretrained(repo_id: str = FINETUNED_REPO) -> CanViTForImageClassification:
        """Load finetuned CanViT classifier from HuggingFace Hub.

        Uses JAX-native safetensors -- no PyTorch dependency.
        """
        from huggingface_hub import hf_hub_download

        config_path = Path(hf_hub_download(repo_id, "config.json"))
        weights_path = Path(hf_hub_download(repo_id, "model.safetensors"))

        config = json.loads(config_path.read_text())
        mc = config["model_config"]
        valid = set(CanViTConfig.__dataclass_fields__)
        cfg = CanViTConfig(**{k: v for k, v in mc.items() if k in valid})
        n_classes = config["n_classes"]

        clf = CanViTForImageClassification(cfg, n_classes, rngs=nnx.Rngs(0))
        load_state(clf, weights_path)
        return clf
