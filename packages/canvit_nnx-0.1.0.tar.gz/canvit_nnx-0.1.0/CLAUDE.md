# CLAUDE.md

## Project

CanViT-NNX: JAX/Flax NNX port of the Canvas Vision Transformer.
PyPI package: `canvit-nnx`. Import: `canvit_nnx`.
Reference implementation: [CanViT-PyTorch](https://github.com/m2b3/CanViT-PyTorch) (`canvit-pytorch` on PyPI).

## Commands

```bash
uv run pytest tests/ -v                          # unit tests
uv run --extra verify python scripts/verify.py    # cross-framework numerical check
uv run --extra demo python scripts/demo.py --image path/to/img.jpg
PYTHONPATH=. uv run --extra convert python scripts/push_to_hub.py  # re-push HF checkpoints
```

## Flax NNX gotchas (traps for PyTorch porters)

- **LayerNorm epsilon**: Flax NNX defaults to `1e-6`, PyTorch to `1e-5`. Always explicit.
- **GELU**: `jax.nn.gelu` defaults to `approximate=True`, PyTorch to exact. Always explicit.
- **SDPA layout**: `jax.nn.dot_product_attention` expects BTNH, not BHTN.
- **Linear kernel**: NNX is `(in, out)`, PyTorch is `(out, in)`. Conv: NNX `(H,W,I,O)`, PyTorch `(O,I,H,W)`.
- **nnx.List**: plain Python lists on nnx.Module are static. Use `nnx.List([...])`.
- **Optional modules**: `self.x = None` then `self.x = Module()` fails. Use `nnx.data(None)`.
- **Param access**: use `param[...]` not `param.value` (deprecated in Flax 0.12+).
- **FlatState**: iterates as `(path_tuple, leaf)` tuples, not dict. No `.items()`.
- **Optimizer**: `nnx.Optimizer(model, tx, wrt=nnx.Param)` and `optimizer.update(model, grads)`.
- **Pytree registration**: `@jax.tree_util.register_dataclass` for data containers passed through JIT.
- **align_corners**: PyTorch `F.grid_sample(align_corners=False)` maps to `pixel = (grid+1)*N/2 - 0.5`.

## Checkpoint loading

JAX-native safetensors on HuggingFace (no torch dependency):
- Pretrained: `canvit/canvitb16-add-vpe-pretrain-g128px-s512px-in21k-dv3b16-2026-02-02-nnx`
- Finetuned: `canvit/canvitb16-add-vpe-finetune-g128px-s512px-in1k-2026-04-06-nnx`

PyTorch-to-JAX conversion is in `scripts/convert_from_pytorch.py` (not part of the installed package).
The PyTorch pretrained checkpoint key prefix is `backbone.` (the actual ViTBackbone).
The PyTorch finetuned checkpoint wraps CanViT as `canvit.` — strip that, and inner keys match.

## Performance notes (as of 2026-04-07, may be stale)

- On CPU (M4 Pro), JAX forward was ~68ms vs torch.compile ~41ms. Initial investigation
  suggested canvas cross-attention SDPA as the bottleneck (XLA CPU appeared to decompose
  it into separate ops while PyTorch used a fused kernel), but this was not thoroughly
  verified on GPU. Re-benchmark before drawing conclusions.
- Cross-framework backward gradient differences were observed in early blocks (0-3).
  Hypothesis was f32 matmul accumulation order differences, but not definitively proven.
  Run `scripts/verify.py` for current state.
