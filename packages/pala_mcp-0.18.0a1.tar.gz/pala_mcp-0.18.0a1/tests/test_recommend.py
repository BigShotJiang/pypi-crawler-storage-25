from __future__ import annotations

from pathlib import Path

import pytest

from pala_mcp import auth as auth_module
from pala_mcp.auth import authorize_tool_call
from pala_mcp.recommend import recommend
from pala_mcp.server import PalaState, build_server


def test_recommend_returns_top_n_results(registry_path: Path, skills_dir: Path) -> None:
    results = recommend(
        "redis cache stampede",
        limit=5,
        registry_path=registry_path,
        skill_dir=skills_dir,
    )

    assert len(results) == 5
    assert all(result["score"] > 0 for result in results)
    assert "redis-cache-patterns" in {result["name"] for result in results[:3]}


def test_recommend_free_tier_limited_to_one(
    registry_path: Path, skills_dir: Path
) -> None:
    results = recommend(
        "deploy production",
        limit=5,
        tier="free",
        registry_path=registry_path,
        skill_dir=skills_dir,
    )

    assert len(results) == 1


def test_recommend_domain_affinity_boost(
    registry_path: Path, skills_dir: Path
) -> None:
    results = recommend(
        "deploy production vercel rollback",
        limit=5,
        registry_path=registry_path,
        skill_dir=skills_dir,
    )
    top_domains = {result["domain"] for result in results[:3]}
    top_names = {result["name"] for result in results[:5]}

    assert top_domains & {"infra", "universal"}
    assert {"vercel-deploy-pipeline", "release-pipeline-design"} & top_names


def test_recommend_empty_context_returns_random_skills(
    registry_path: Path, skills_dir: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.setenv("PALA_RECOMMEND_SEED", "unit")

    results = recommend(
        "",
        limit=4,
        registry_path=registry_path,
        skill_dir=skills_dir,
    )

    assert len(results) == 4
    assert len({result["name"] for result in results}) == 4
    assert all(result["reason"] == "baseline published skill" for result in results)


def test_recommend_premium_tier_full_results(
    registry_path: Path, skills_dir: Path
) -> None:
    results = recommend(
        "production incident observability",
        limit=6,
        tier="premium",
        registry_path=registry_path,
        skill_dir=skills_dir,
    )

    assert len(results) == 6
    assert any(result["name"] == "incident-response-runbook" for result in results)


def test_server_registers_pala_recommend(
    registry_path: Path, skills_dir: Path
) -> None:
    state = PalaState(skill_dir=skills_dir, registry_path=registry_path)
    server = build_server(state)

    assert server is not None
    assert "pala_recommend" in state.mcp_tool_names
    assert "pala_recommend" in auth_module.FREE_TOOLS
    assert authorize_tool_call("pala_recommend", None).tier == "free"
