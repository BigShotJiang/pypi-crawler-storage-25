"""Health check unit tests."""

from __future__ import annotations

from pathlib import Path

from pala_mcp import health
from pala_mcp.server import PalaState


def test_check_registry_passing(registry_path: Path, skills_dir: Path) -> None:
    state = PalaState(skill_dir=skills_dir, registry_path=registry_path)

    result = health.check_registry(state)

    assert result["status"] == "healthy"
    assert result["skill_count"] > 0
    assert result["published_count"] > 0


def test_check_skills_dir_passing(registry_path: Path, skills_dir: Path) -> None:
    state = PalaState(skill_dir=skills_dir, registry_path=registry_path)

    result = health.check_skills_dir(state)

    assert result["status"] == "healthy"
    assert result["skill_file_count"] > 0


def test_check_mcp_tools_passing(registry_path: Path, skills_dir: Path) -> None:
    state = PalaState(skill_dir=skills_dir, registry_path=registry_path)

    result = health.check_mcp_tools(state)

    assert result["status"] == "healthy"
    assert result["missing_tools"] == []


def test_aggregate_healthy(registry_path: Path, skills_dir: Path) -> None:
    state = PalaState(skill_dir=skills_dir, registry_path=registry_path)

    result = health.aggregate_health(state)

    assert result["status"] == "healthy"
    assert set(result["checks"]) == {"registry", "skills_dir", "mcp_tools"}
    assert result["timestamp"]
    assert result["version"]


def test_aggregate_degraded_when_skills_dir_missing(
    registry_path: Path, tmp_path: Path
) -> None:
    state = PalaState(skill_dir=tmp_path / "missing-skills", registry_path=registry_path)

    result = health.aggregate_health(state)

    assert result["status"] == "degraded"
    assert result["checks"]["skills_dir"]["status"] == "degraded"


def test_aggregate_unhealthy_when_registry_load_fails(
    skills_dir: Path, tmp_path: Path
) -> None:
    state = PalaState(skill_dir=skills_dir, registry_path=tmp_path / "missing.yaml")

    result = health.aggregate_health(state)

    assert result["status"] == "unhealthy"
    assert result["checks"]["registry"]["status"] == "unhealthy"
