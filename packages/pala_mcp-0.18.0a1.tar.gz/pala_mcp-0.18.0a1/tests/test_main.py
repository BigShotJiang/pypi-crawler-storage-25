"""CLI entrypoint tests — parse_args and main() without starting transports."""

from __future__ import annotations

from pathlib import Path
from unittest.mock import MagicMock

import pytest

from pala_mcp import __main__ as cli

# CLI --host value for bind-all; unit tests mock server.run (no real socket bind).
BIND_ALL_HOST = "0.0.0.0"  # noqa: S104


def test_parse_args_defaults(monkeypatch: pytest.MonkeyPatch) -> None:
    """Default invocation selects stdio transport and INFO logging."""
    monkeypatch.delenv("PALA_METRICS_PORT", raising=False)
    args = cli.parse_args([])
    assert args.stdio is False
    assert args.http is False
    assert args.host == "127.0.0.1"
    assert args.port == 8765
    assert args.registry is None
    assert args.skills_dir is None
    assert args.log_level == "INFO"
    assert args.metrics_port == 9090


def test_parse_args_explicit_stdio() -> None:
    args = cli.parse_args(["--stdio"])
    assert args.stdio is True
    assert args.http is False


def test_parse_args_explicit_http() -> None:
    args = cli.parse_args(["--http", "--host", BIND_ALL_HOST, "--port", "9000"])
    assert args.http is True
    assert args.stdio is False
    assert args.host == BIND_ALL_HOST
    assert args.port == 9000


def test_parse_args_registry_and_skills_dir(
    registry_path: Path, skills_dir: Path
) -> None:
    args = cli.parse_args(
        [
            "--registry",
            str(registry_path),
            "--skills-dir",
            str(skills_dir),
        ]
    )
    assert args.registry == str(registry_path)
    assert args.skills_dir == str(skills_dir)


def test_parse_args_log_level() -> None:
    args = cli.parse_args(["--log-level", "DEBUG"])
    assert args.log_level == "DEBUG"


def test_parse_args_metrics_port() -> None:
    args = cli.parse_args(["--http", "--metrics-port", "0"])
    assert args.metrics_port == 0


def test_parse_args_stdio_and_http_mutually_exclusive() -> None:
    with pytest.raises(SystemExit):
        cli.parse_args(["--stdio", "--http"])


def test_main_stdio_warms_registry_and_runs(
    registry_path: Path,
    skills_dir: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """main() loads registry, builds server, runs stdio transport (mocked)."""
    run_mock = MagicMock()
    server_mock = MagicMock()
    server_mock.run = run_mock
    build_mock = MagicMock(return_value=server_mock)
    monkeypatch.setattr(cli, "build_server", build_mock)

    registry_calls: list[Path] = []

    def fake_registry(self: cli.PalaState) -> object:
        registry_calls.append(self.registry_path)
        from pala_mcp.registry import Registry

        return Registry.load(self.registry_path)

    monkeypatch.setattr(cli.PalaState, "registry", fake_registry)

    code = cli.main(
        [
            "--registry",
            str(registry_path),
            "--skills-dir",
            str(skills_dir),
            "--log-level",
            "WARNING",
        ]
    )

    assert code == 0
    build_mock.assert_called_once()
    state = build_mock.call_args[0][0]
    assert state.registry_path == registry_path
    assert state.skill_dir == skills_dir
    assert registry_calls == [registry_path]
    run_mock.assert_called_once_with()


def test_main_http_transport(
    registry_path: Path,
    skills_dir: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """main() passes host/port to server.run for HTTP/SSE mode."""
    run_mock = MagicMock()
    server_mock = MagicMock()
    server_mock.run = run_mock
    monkeypatch.setattr(cli, "build_server", MagicMock(return_value=server_mock))
    metrics_mock = MagicMock()
    monkeypatch.setattr(cli, "start_metrics_http_server", metrics_mock)
    monkeypatch.setattr(
        cli.PalaState,
        "registry",
        lambda self: __import__(
            "pala_mcp.registry", fromlist=["Registry"]
        ).Registry.load(self.registry_path),
    )

    code = cli.main(
        [
            "--http",
            "--host",
            BIND_ALL_HOST,
            "--port",
            "8765",
            "--registry",
            str(registry_path),
            "--skills-dir",
            str(skills_dir),
        ]
    )

    assert code == 0
    metrics_mock.assert_called_once_with(9090, BIND_ALL_HOST)
    run_mock.assert_called_once_with(transport="sse", host=BIND_ALL_HOST, port=8765)


def test_main_uses_default_paths_when_omitted(
    registry_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """main() resolves registry/skills-dir via defaults when flags omitted."""
    monkeypatch.setattr(cli, "default_registry_path", lambda: registry_path)
    monkeypatch.setattr(cli, "default_skill_dir", lambda: registry_path.parent)

    captured: dict[str, Path] = {}

    def capture_build(state: cli.PalaState) -> MagicMock:
        captured["registry"] = state.registry_path
        captured["skills"] = state.skill_dir
        server = MagicMock()
        server.run = MagicMock()
        return server

    monkeypatch.setattr(cli, "build_server", capture_build)
    monkeypatch.setattr(
        cli.PalaState,
        "registry",
        lambda self: __import__(
            "pala_mcp.registry", fromlist=["Registry"]
        ).Registry.load(self.registry_path),
    )

    assert cli.main(["--stdio"]) == 0
    assert captured["registry"] == registry_path
    assert captured["skills"] == registry_path.parent
