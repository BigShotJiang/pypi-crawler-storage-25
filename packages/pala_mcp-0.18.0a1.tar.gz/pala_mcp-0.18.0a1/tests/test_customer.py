from __future__ import annotations

import json
import sqlite3
from pathlib import Path

import bcrypt

from pala_mcp.customer import get_tier, is_token_valid


def _write_store(path: Path, *, status: str, revoked: bool = False) -> None:
    path.write_text(
        json.dumps(
            {
                "customers": [
                    {
                        "id": "cust_local",
                        "email": "buyer@pala-os.com",
                        "stripe_customer_id": "cus_123",
                        "tier": "premium",
                        "subscription": {
                            "stripe_subscription_id": "sub_123",
                            "status": status,
                            "price_id": "price_123",
                            "updated_at": "2026-05-17T00:00:00Z",
                        },
                        "tokens": [
                            {
                                "token": "pala_prod_active",
                                "tier": "premium",
                                "customer_id": "cus_123",
                                "issued_at": "2026-05-17T00:00:00Z",
                                "revoked_at": "2026-05-17T01:00:00Z" if revoked else None,
                            }
                        ],
                    }
                ]
            }
        )
        + "\n",
        encoding="utf-8",
    )


def test_get_tier_premium_active(tmp_path, monkeypatch):
    store_path = tmp_path / "customers.json"
    _write_store(store_path, status="active")
    monkeypatch.setenv("PALA_CUSTOMER_STORE", str(store_path))

    assert get_tier("pala_prod_active") == "premium"
    assert is_token_valid("pala_prod_active") is True


def test_get_tier_subscription_cancelled(tmp_path, monkeypatch):
    store_path = tmp_path / "customers.json"
    _write_store(store_path, status="cancelled")
    monkeypatch.setenv("PALA_CUSTOMER_STORE", str(store_path))

    assert get_tier("pala_prod_active") == "free"


def test_token_revoked_returns_invalid(tmp_path, monkeypatch):
    store_path = tmp_path / "customers.json"
    _write_store(store_path, status="active", revoked=True)
    monkeypatch.setenv("PALA_CUSTOMER_STORE", str(store_path))

    assert is_token_valid("pala_prod_active") is False


def test_unknown_token_defaults_free(tmp_path, monkeypatch):
    store_path = tmp_path / "customers.json"
    _write_store(store_path, status="active")
    monkeypatch.setenv("PALA_CUSTOMER_STORE", str(store_path))

    assert get_tier("pala_prod_missing") == "free"


def test_sqlite_backend_lookup(tmp_path, monkeypatch):
    token = "pala_prod_active_sqlite_token_123456789"
    db_path = tmp_path / "pala.db"
    connection = sqlite3.connect(db_path)
    connection.execute("PRAGMA journal_mode=WAL")
    connection.execute("PRAGMA foreign_keys=ON")
    connection.executescript(
        """
        CREATE TABLE customers (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          stripe_customer_id TEXT UNIQUE NOT NULL,
          email TEXT NOT NULL,
          tier TEXT NOT NULL,
          status TEXT NOT NULL,
          created_at TEXT NOT NULL,
          updated_at TEXT NOT NULL
        );
        CREATE TABLE tokens (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          customer_id INTEGER NOT NULL,
          token_hash TEXT NOT NULL UNIQUE,
          prefix TEXT NOT NULL,
          issued_at TEXT NOT NULL,
          rotated_at TEXT,
          revoked_at TEXT,
          expires_at TEXT,
          FOREIGN KEY (customer_id) REFERENCES customers(id)
        );
        CREATE INDEX idx_tokens_prefix ON tokens(prefix);
        """
    )
    connection.execute(
        """
        INSERT INTO customers(stripe_customer_id, email, tier, status, created_at, updated_at)
        VALUES ('cus_sqlite', 'buyer@pala-os.com', 'premium', 'active', 'now', 'now')
        """
    )
    token_hash = bcrypt.hashpw(token.encode("utf-8"), bcrypt.gensalt()).decode("utf-8")
    connection.execute(
        """
        INSERT INTO tokens(customer_id, token_hash, prefix, issued_at)
        VALUES (1, ?, ?, 'now')
        """,
        (token_hash, token[:24]),
    )
    connection.commit()
    connection.close()
    monkeypatch.setenv("PALA_STORE", "sqlite")
    monkeypatch.setenv("PALA_DB_PATH", str(db_path))

    assert get_tier(token) == "premium"
    assert is_token_valid(token) is True


def test_json_backend_lookup(tmp_path, monkeypatch):
    store_path = tmp_path / "customers.json"
    _write_store(store_path, status="active")
    monkeypatch.setenv("PALA_STORE", "json")
    monkeypatch.setenv("PALA_CUSTOMER_STORE", str(store_path))

    assert get_tier("pala_prod_active") == "premium"
