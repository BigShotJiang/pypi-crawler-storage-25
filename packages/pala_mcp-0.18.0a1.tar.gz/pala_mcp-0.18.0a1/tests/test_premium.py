from __future__ import annotations

from pala_mcp.auth import AuthContext
from pala_mcp.premium import check_license_scope, filter_skills_for_tier
from pala_mcp.registry import Skill


def _skills() -> tuple[Skill, Skill]:
    return (
        Skill(
            name="free-skill",
            domain="universal",
            status="stable",
            path="skills/universal/free-skill",
            access_tier="free",
        ),
        Skill(
            name="premium-skill",
            domain="universal",
            status="stable",
            path="skills/universal/premium-skill",
            access_tier="premium",
        ),
    )


def test_filter_skills_free_user_cannot_see_premium() -> None:
    skills = filter_skills_for_tier(
        _skills(),
        requested_tier=None,
        caller_tier="free",
    )

    assert [skill.name for skill in skills] == ["free-skill"]


def test_filter_skills_premium_request_visible_to_paid_user() -> None:
    skills = filter_skills_for_tier(
        _skills(),
        requested_tier="premium",
        caller_tier="premium",
    )

    assert [skill.name for skill in skills] == ["premium-skill"]


def test_filter_skills_free_user_premium_request_returns_empty() -> None:
    skills = filter_skills_for_tier(
        _skills(),
        requested_tier="premium",
        caller_tier="free",
    )

    assert skills == ()


def test_check_license_scope_missing_token_rejected() -> None:
    result = check_license_scope(raw_token=None, requested_customer_id="cus_123")
    assert result.allowed is False
    assert result.reason == "missing_token"


def test_check_license_scope_accepts_matching_customer(monkeypatch) -> None:
    monkeypatch.setattr(
        "pala_mcp.premium.verify_token",
        lambda token: AuthContext(
            tier="premium",
            rate_limit_override=600,
            customer_id="cus_123",
        ),
    )
    monkeypatch.setattr("pala_mcp.premium.get_customer_id", lambda token: "cus_123")

    result = check_license_scope(
        raw_token="Bearer pala_prod_abc",  # noqa: S106 - test fixture token
        requested_customer_id="cus_123",
    )

    assert result.allowed is True
    assert result.reason == "ok"


def test_check_license_scope_reports_token_customer_mismatch(monkeypatch) -> None:
    monkeypatch.setattr(
        "pala_mcp.premium.verify_token",
        lambda token: AuthContext(
            tier="premium",
            rate_limit_override=600,
            customer_id="cus_123",
        ),
    )
    monkeypatch.setattr("pala_mcp.premium.get_customer_id", lambda token: "cus_123")

    result = check_license_scope(
        raw_token="pala_prod_abc",  # noqa: S106 - test fixture token
        requested_customer_id="cus_999",
    )

    assert result.allowed is False
    assert result.reason == "token_customer_mismatch"


def test_check_license_scope_allows_pending_store_link(monkeypatch) -> None:
    monkeypatch.setattr(
        "pala_mcp.premium.verify_token",
        lambda token: AuthContext(
            tier="premium",
            rate_limit_override=600,
            customer_id="cus_from_token",
        ),
    )
    monkeypatch.setattr("pala_mcp.premium.get_customer_id", lambda token: None)

    result = check_license_scope(
        raw_token="pala_prod_abc",  # noqa: S106 - test fixture token
    )  # noqa: S106 - test fixture token

    assert result.allowed is True
    assert result.reason == "todo_v0_16_customer_link_pending"


# ---------------------------------------------------------------------------
# v0.17.0 (ADR-014): Lemon Squeezy license verification tests
# ---------------------------------------------------------------------------


def test_verify_lemon_license_empty_key() -> None:
    """Empty/whitespace license_key returns lemon_license_key_missing."""
    from pala_mcp.premium import clear_lemon_license_cache, verify_lemon_license

    clear_lemon_license_cache()
    result = verify_lemon_license("")
    assert result.allowed is False
    assert result.reason == "lemon_license_key_missing"


def test_verify_lemon_license_active_returns_allowed(monkeypatch) -> None:
    """Valid active license → allowed True + lemon_customer_id set."""
    from pala_mcp.premium import clear_lemon_license_cache, verify_lemon_license

    clear_lemon_license_cache()

    class _MockLemon:
        def __init__(self) -> None:
            pass

        def validate_license_key(self, key: str) -> dict:
            return {
                "valid": True,
                "license_key": {
                    "customer_id": 67890,
                    "status": "active",
                    "expires_at": None,
                },
                "meta": {"product_id": 12345},
            }

    monkeypatch.setattr("pala_payments.LemonService", _MockLemon)
    result = verify_lemon_license("test_license_key_active")
    assert result.allowed is True
    assert result.reason == "ok"
    assert result.license_key == "test_license_key_active"
    assert result.lemon_customer_id == "67890"
    assert result.lemon_license_status == "active"


def test_verify_lemon_license_invalid_returns_disallowed(monkeypatch) -> None:
    """Invalid license → lemon_license_invalid + caching."""
    from pala_mcp.premium import clear_lemon_license_cache, verify_lemon_license

    clear_lemon_license_cache()

    class _MockLemon:
        def __init__(self) -> None:
            pass

        def validate_license_key(self, key: str) -> dict:
            return {"valid": False}

    monkeypatch.setattr("pala_payments.LemonService", _MockLemon)
    result = verify_lemon_license("bad_key")
    assert result.allowed is False
    assert result.reason == "lemon_license_invalid"


def test_verify_lemon_license_expired_status(monkeypatch) -> None:
    """Status != active → lemon_license_status:<status> reason."""
    from pala_mcp.premium import clear_lemon_license_cache, verify_lemon_license

    clear_lemon_license_cache()

    class _MockLemon:
        def __init__(self) -> None:
            pass

        def validate_license_key(self, key: str) -> dict:
            return {
                "valid": True,
                "license_key": {"customer_id": 1, "status": "expired"},
            }

    monkeypatch.setattr("pala_payments.LemonService", _MockLemon)
    result = verify_lemon_license("expired_key")
    assert result.allowed is False
    assert result.reason == "lemon_license_status:expired"
    assert result.lemon_license_status == "expired"


def test_verify_lemon_license_api_unavailable(monkeypatch) -> None:
    """Lemon API exception → lemon_api_unavailable:<exception>."""
    from pala_mcp.premium import clear_lemon_license_cache, verify_lemon_license

    clear_lemon_license_cache()

    def _raise_import() -> object:
        raise ImportError("pala_payments not installed in this env")

    # Simulate ImportError by overriding sys.modules entry
    import sys

    monkeypatch.setitem(sys.modules, "pala_payments", None)
    result = verify_lemon_license("any_key")
    assert result.allowed is False
    assert result.reason.startswith("lemon_api_unavailable:")


def test_verify_lemon_license_cache_hit(monkeypatch) -> None:
    """Same key called twice → second call returns cached (mock invoked once)."""
    from pala_mcp.premium import clear_lemon_license_cache, verify_lemon_license

    clear_lemon_license_cache()

    call_count = {"count": 0}

    class _CountingMock:
        def __init__(self) -> None:
            pass

        def validate_license_key(self, key: str) -> dict:
            call_count["count"] += 1
            return {
                "valid": True,
                "license_key": {"customer_id": 999, "status": "active"},
            }

    monkeypatch.setattr("pala_payments.LemonService", _CountingMock)
    r1 = verify_lemon_license("cached_key")
    r2 = verify_lemon_license("cached_key")
    assert r1.allowed is True
    assert r2.allowed is True
    assert call_count["count"] == 1  # cache hit on second call


def test_premium_license_check_dataclass_lemon_fields() -> None:
    """PremiumLicenseCheck supports v0.17.0 license_key + lemon_customer_id fields."""
    from pala_mcp.premium import PremiumLicenseCheck

    check = PremiumLicenseCheck(
        allowed=True,
        reason="ok",
        license_key="lk_test",
        lemon_customer_id="123",
        lemon_license_status="active",
    )
    assert check.license_key == "lk_test"
    assert check.lemon_customer_id == "123"
    assert check.lemon_license_status == "active"


# ---- ADR-017 Early access (davetiyeli) tests ----

def test_verify_early_access_valid_format() -> None:
    """pala-early-XXXXXXXX with valid Crockford chars allowed."""
    from pala_mcp.premium import verify_early_access

    check = verify_early_access("pala-early-AB2CDEFG")
    assert check.allowed is True
    assert check.reason == "ok"
    assert check.license_key == "pala-early-AB2CDEFG"
    assert check.lemon_license_status == "early_access"


def test_verify_early_access_missing() -> None:
    from pala_mcp.premium import verify_early_access

    assert verify_early_access("").allowed is False
    assert verify_early_access("").reason == "early_access_key_missing"
    assert verify_early_access("   ").reason == "early_access_key_missing"


def test_verify_early_access_invalid_format() -> None:
    from pala_mcp.premium import verify_early_access

    bad_keys = [
        "pala-early-toolow",            # length wrong
        "pala-early-INVALID0",          # contains '0' (Crockford excludes 0)
        "pala-early-INVALIDI",          # contains 'I' (excluded)
        "wrong-prefix-AB2CDEFG",        # prefix wrong
        "pala-early-ABCDEFGH-extra",    # extra chars
        "PALA-EARLY-AB2CDEFG",          # uppercase prefix
    ]
    for k in bad_keys:
        check = verify_early_access(k)
        assert check.allowed is False, f"expected False for {k}"
        assert check.reason == "early_access_format_invalid"


def test_verify_early_access_strips_whitespace() -> None:
    from pala_mcp.premium import verify_early_access

    check = verify_early_access("  pala-early-AB2CDEFG  ")
    assert check.allowed is True
