"""Rate limiter tests."""

from __future__ import annotations

from pala_mcp.rate_limit import InMemoryTokenBucketLimiter, rate_limit_key


def test_sixty_requests_under_one_minute_allowed() -> None:
    now = 0.0
    limiter = InMemoryTokenBucketLimiter(clock=lambda: now)

    results = [limiter.check("ip:1.2.3.4", 60) for _ in range(60)]

    assert all(result.allowed for result in results)
    assert results[-1].remaining == 0


def test_sixty_first_request_returns_retry_after() -> None:
    now = 0.0
    limiter = InMemoryTokenBucketLimiter(clock=lambda: now)

    for _ in range(60):
        limiter.check("ip:1.2.3.4", 60)
    result = limiter.check("ip:1.2.3.4", 60)

    assert result.allowed is False
    assert result.retry_after == 1
    assert result.remaining == 0


def test_token_bucket_refill() -> None:
    now = [0.0]
    limiter = InMemoryTokenBucketLimiter(clock=lambda: now[0])

    for _ in range(60):
        limiter.check("ip:1.2.3.4", 60)
    assert limiter.check("ip:1.2.3.4", 60).allowed is False

    now[0] = 1.0

    assert limiter.check("ip:1.2.3.4", 60).allowed is True


def test_per_ip_keys_are_isolated() -> None:
    limiter = InMemoryTokenBucketLimiter(clock=lambda: 0.0)

    for _ in range(60):
        limiter.check("ip:1.2.3.4", 60)

    assert limiter.check("ip:1.2.3.4", 60).allowed is False
    assert limiter.check("ip:5.6.7.8", 60).allowed is True


def test_per_token_keys_are_isolated() -> None:
    limiter = InMemoryTokenBucketLimiter(clock=lambda: 0.0)
    key_a = rate_limit_key(token="pala_prod_a")  # noqa: S106
    key_b = rate_limit_key(token="pala_prod_b")  # noqa: S106

    for _ in range(600):
        limiter.check(key_a, 600)

    assert limiter.check(key_a, 600).allowed is False
    assert limiter.check(key_b, 600).allowed is True


def test_token_key_hides_raw_token() -> None:
    key = rate_limit_key(token="pala_prod_secret")  # noqa: S106

    assert key.startswith("token:")
    assert "pala_prod_secret" not in key


def test_ip_key_uses_unknown_fallback() -> None:
    assert rate_limit_key() == "ip:unknown"


def test_zero_limit_denies() -> None:
    limiter = InMemoryTokenBucketLimiter(clock=lambda: 0.0)
    result = limiter.check("ip:1.2.3.4", 0)

    assert result.allowed is False
    assert result.retry_after == 60


def test_reset_clears_buckets() -> None:
    limiter = InMemoryTokenBucketLimiter(clock=lambda: 0.0)

    for _ in range(60):
        limiter.check("ip:1.2.3.4", 60)
    assert limiter.check("ip:1.2.3.4", 60).allowed is False

    limiter.reset()

    assert limiter.check("ip:1.2.3.4", 60).allowed is True
