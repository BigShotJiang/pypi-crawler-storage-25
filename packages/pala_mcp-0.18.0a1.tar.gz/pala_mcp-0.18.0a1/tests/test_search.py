"""Skill index search tests."""

from __future__ import annotations

from pathlib import Path

from pala_mcp.registry import Registry
from pala_mcp.search import SkillIndex


def test_search_finds_redis_cache(registry_path: Path, skills_dir: Path) -> None:
    """A query about redis cache should rank redis-cache-patterns near the top."""
    reg = Registry.load(registry_path)
    index = SkillIndex(reg, skills_dir)
    hits = index.search("redis cache stampede", limit=5)
    assert len(hits) > 0
    names = [h.name for h in hits]
    assert "redis-cache-patterns" in names[:3]


def test_search_empty_query(registry_path: Path, skills_dir: Path) -> None:
    """Empty query returns no results."""
    reg = Registry.load(registry_path)
    index = SkillIndex(reg, skills_dir)
    assert index.search("", limit=5) == []
    assert index.search("   ", limit=5) == []


def test_search_limit_respected(registry_path: Path, skills_dir: Path) -> None:
    """limit caps the result count."""
    reg = Registry.load(registry_path)
    index = SkillIndex(reg, skills_dir)
    hits = index.search("test", limit=3)
    assert len(hits) <= 3


def test_search_limit_capped_minimum(registry_path: Path, skills_dir: Path) -> None:
    """limit=0 returns at least one when matches exist (server enforces max(1, limit))."""
    reg = Registry.load(registry_path)
    index = SkillIndex(reg, skills_dir)
    # The index itself enforces max(1, limit); 0 still returns at least one slot
    hits = index.search("test", limit=0)
    assert len(hits) <= 1


def test_search_finds_universal_skill_by_trigger(
    registry_path: Path, skills_dir: Path
) -> None:
    """Search by a known trigger phrase finds the right skill."""
    reg = Registry.load(registry_path)
    index = SkillIndex(reg, skills_dir)
    hits = index.search("brainstorming session", limit=3)
    names = [h.name for h in hits]
    assert "brainstorming" in names
