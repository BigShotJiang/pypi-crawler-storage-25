"""Prometheus metrics tests."""

from __future__ import annotations

from pathlib import Path

from prometheus_client.parser import text_string_to_metric_families
from starlette.testclient import TestClient

from pala_mcp import metrics
from pala_mcp.server import PalaState, build_server


def _metric_value(metric_name: str, labels: dict[str, str]) -> float:
    rendered = metrics.render_metrics().decode("utf-8")
    for family in text_string_to_metric_families(rendered):
        for sample in family.samples:
            if sample.name != metric_name:
                continue
            if all(sample.labels.get(key) == value for key, value in labels.items()):
                return float(sample.value)
    return 0.0


def test_metrics_render_contains_metric_names() -> None:
    rendered = metrics.render_metrics().decode("utf-8")

    assert "pala_mcp_tool_calls_total" in rendered
    assert "pala_mcp_auth_failures_total" in rendered
    assert "pala_mcp_tool_duration_seconds" in rendered


def test_tool_call_counter_increment() -> None:
    labels = {"tool": "unit_counter", "tier": "premium", "status": "200"}
    before = _metric_value("pala_mcp_tool_calls_total", labels)

    metrics.record_tool_call(
        tool="unit_counter",
        tier="premium",
        status="200",
        duration_seconds=0.02,
    )

    assert _metric_value("pala_mcp_tool_calls_total", labels) == before + 1


def test_histogram_buckets_exist() -> None:
    metrics.record_tool_call(
        tool="unit_histogram",
        tier="free",
        status="200",
        duration_seconds=0.2,
    )
    rendered = metrics.render_metrics().decode("utf-8")

    assert (
        'pala_mcp_tool_duration_seconds_bucket{le="0.1",tier="free",'
        'tool="unit_histogram"}'
    ) in rendered
    assert (
        'pala_mcp_tool_duration_seconds_bucket{le="0.5",tier="free",'
        'tool="unit_histogram"}'
    ) in rendered


def test_auth_failure_counter_increment() -> None:
    labels = {"reason": "unit_invalid"}
    before = _metric_value("pala_mcp_auth_failures_total", labels)

    metrics.record_auth_failure("unit_invalid")

    assert _metric_value("pala_mcp_auth_failures_total", labels) == before + 1


def test_registry_skills_gauge() -> None:
    metrics.set_registry_skills_total(83)

    assert _metric_value("pala_mcp_registry_skills_total", {}) == 83


def test_active_connections_gauge() -> None:
    before = _metric_value("pala_mcp_active_connections", {})

    metrics.inc_active_connections()
    metrics.dec_active_connections()

    assert _metric_value("pala_mcp_active_connections", {}) == before


def test_start_metrics_server_disabled() -> None:
    assert metrics.start_metrics_http_server(0, "127.0.0.1") is None


def test_metrics_endpoint_200(registry_path: Path, skills_dir: Path) -> None:
    state = PalaState(skill_dir=skills_dir, registry_path=registry_path)
    state.registry()
    server = build_server(state)
    client = TestClient(server.http_app(transport="sse"))

    response = client.get("/metrics")

    assert response.status_code == 200
    assert "pala_mcp_tool_calls_total" in response.text


def test_health_endpoint_200(registry_path: Path, skills_dir: Path) -> None:
    state = PalaState(skill_dir=skills_dir, registry_path=registry_path)
    state.registry()
    server = build_server(state)
    client = TestClient(server.http_app(transport="sse"))

    response = client.get("/health")

    assert response.status_code == 200
    assert response.json()["status"] == "healthy"
