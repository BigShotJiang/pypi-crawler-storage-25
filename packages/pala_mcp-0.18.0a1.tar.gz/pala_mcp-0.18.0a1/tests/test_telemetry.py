"""Telemetry stub tests."""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from pala_mcp import telemetry


def test_emit_noop_when_telemetry_off(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    monkeypatch.setattr(telemetry.Path, "home", staticmethod(lambda: tmp_path))
    monkeypatch.delenv("PALA_TELEMETRY", raising=False)

    telemetry.emit("mcp.tool.call", {"tool": "pala_list_skills", "duration_ms": 12.3})

    assert not (tmp_path / ".pala" / "telemetry.log").exists()


def test_emit_writes_sanitized_event_when_telemetry_on(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    monkeypatch.setattr(telemetry.Path, "home", staticmethod(lambda: tmp_path))
    monkeypatch.setenv("PALA_TELEMETRY", "on")

    telemetry.emit(
        "mcp.tool.call",
        {
            "tool": "pala_list_skills",
            "duration_ms": 12.3,
            "user_content": "do not log this",
        },
    )

    log_path = tmp_path / ".pala" / "telemetry.log"
    line = log_path.read_text(encoding="utf-8").strip()
    event = json.loads(line)
    assert event["event"] == "mcp.tool.call"
    assert event["tool"] == "pala_list_skills"
    assert event["duration_ms"] == 12.3
    assert "timestamp" in event
    assert "user_content" not in event
