"""Authentication tests for Pala MCP cloud mode."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import pytest
from fastmcp.exceptions import ToolError

from pala_mcp.auth import AuthError, authorize_tool_call, normalize_token, verify_token
from pala_mcp.server import PalaState, build_server


def _extract_result(call_tool_response: Any) -> Any:
    if hasattr(call_tool_response, "structured_content"):
        structured = call_tool_response.structured_content
        if structured is not None:
            if isinstance(structured, dict) and set(structured) == {"result"}:
                value = structured["result"]
                if isinstance(value, str):
                    try:
                        return json.loads(value)
                    except ValueError:
                        return value
                return value
            return structured
    if hasattr(call_tool_response, "content"):
        content = call_tool_response.content
        if isinstance(content, list) and content and hasattr(content[0], "text"):
            try:
                return json.loads(content[0].text)
            except ValueError:
                return content[0].text
    return call_tool_response


def test_normalize_token_accepts_bearer() -> None:
    assert normalize_token("Bearer pala_prod_abc") == "pala_prod_abc"


def test_verify_token_simple_spec(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("PALA_API_KEYS", "pala_prod_abc")
    context = verify_token("pala_prod_abc")
    assert context is not None
    assert context.tier == "premium"
    assert context.rate_limit_override == 600


def test_verify_token_full_spec(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("PALA_API_KEYS", "pala_ent_xyz:enterprise:acme:5000")
    context = verify_token("Bearer pala_ent_xyz")
    assert context is not None
    assert context.tier == "enterprise"
    assert context.customer_id == "acme"
    assert context.rate_limit_override == 5000


def test_verify_token_reads_env_file(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    env_file = tmp_path / ".env.production"
    env_file.write_text(
        "PALA_API_KEYS='pala_prod_file:premium:file@example.com:700'\n",
        encoding="utf-8",
    )
    monkeypatch.delenv("PALA_API_KEYS", raising=False)
    monkeypatch.setenv("PALA_ENV_FILE", str(env_file))

    context = verify_token("pala_prod_file")

    assert context is not None
    assert context.customer_id == "file@example.com"
    assert context.rate_limit_override == 700


def test_verify_token_invalid_returns_none(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("PALA_API_KEYS", "pala_prod_good:premium:foo:600")
    assert verify_token("pala_prod_bad") is None


def test_authorize_free_list_without_token() -> None:
    context = authorize_tool_call("pala_list_skills", None)
    assert context.tier == "free"
    assert context.rate_limit_override == 60


def test_authorize_free_search_without_token() -> None:
    context = authorize_tool_call("pala_search_skills", None)
    assert context.tier == "free"


def test_authorize_free_get_forbidden() -> None:
    with pytest.raises(AuthError) as exc:
        authorize_tool_call("pala_get_skill", None)
    assert exc.value.status_code == 403
    assert exc.value.reason == "premium_required"


def test_authorize_invalid_token_unauthorized(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("PALA_API_KEYS", "pala_prod_good:premium:foo:600")
    with pytest.raises(AuthError) as exc:
        authorize_tool_call("pala_list_skills", "pala_prod_bad")
    assert exc.value.status_code == 401
    assert exc.value.reason == "invalid_token"


def test_token_rotation(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("PALA_API_KEYS", "pala_prod_old:premium:foo:600")
    assert verify_token("pala_prod_old") is not None

    monkeypatch.setenv("PALA_API_KEYS", "pala_prod_new:premium:foo:600")

    assert verify_token("pala_prod_old") is None
    assert verify_token("pala_prod_new") is not None


@pytest.mark.asyncio
async def test_free_local_auth_list_skills_200(
    registry_path: Path, skills_dir: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.delenv("PALA_LOCAL_AUTH_TOKEN", raising=False)
    state = PalaState(skill_dir=skills_dir, registry_path=registry_path)
    state.registry()
    server = build_server(state, enforce_local_auth=True)

    response = await server.call_tool("pala_list_skills", {})
    result = _extract_result(response)

    assert isinstance(result, list)
    assert result


@pytest.mark.asyncio
async def test_free_local_auth_get_skill_403(
    registry_path: Path, skills_dir: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.delenv("PALA_LOCAL_AUTH_TOKEN", raising=False)
    state = PalaState(skill_dir=skills_dir, registry_path=registry_path)
    state.registry()
    server = build_server(state, enforce_local_auth=True)

    with pytest.raises(ToolError, match="403 premium_required"):
        await server.call_tool("pala_get_skill", {"name": "brainstorming"})


@pytest.mark.asyncio
async def test_premium_local_auth_all_tools_200(
    registry_path: Path, skills_dir: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.setenv("PALA_API_KEYS", "pala_prod_good:premium:foo:600")
    monkeypatch.setenv("PALA_LOCAL_AUTH_TOKEN", "pala_prod_good")
    state = PalaState(skill_dir=skills_dir, registry_path=registry_path)
    state.registry()
    server = build_server(state, enforce_local_auth=True)

    listed = _extract_result(await server.call_tool("pala_list_skills", {}))
    searched = _extract_result(
        await server.call_tool("pala_search_skills", {"query": "redis", "limit": 1})
    )
    skill = _extract_result(
        await server.call_tool("pala_get_skill", {"name": "brainstorming"})
    )
    health = _extract_result(await server.call_tool("pala_health", {}))

    assert listed
    assert searched
    assert skill["name"] == "brainstorming"
    assert health == {"status": "healthy"}


@pytest.mark.asyncio
async def test_invalid_local_auth_token_401(
    registry_path: Path, skills_dir: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.setenv("PALA_API_KEYS", "pala_prod_good:premium:foo:600")
    monkeypatch.setenv("PALA_LOCAL_AUTH_TOKEN", "pala_prod_bad")
    state = PalaState(skill_dir=skills_dir, registry_path=registry_path)
    state.registry()
    server = build_server(state, enforce_local_auth=True)

    with pytest.raises(ToolError, match="401 invalid_token"):
        await server.call_tool("pala_list_skills", {})
