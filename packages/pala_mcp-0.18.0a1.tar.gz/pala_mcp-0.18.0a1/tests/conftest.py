"""Shared test fixtures."""

from __future__ import annotations

from pathlib import Path

import pytest


@pytest.fixture
def repo_root() -> Path:
    """Path to the Pala OS repo root (two levels up from this file)."""
    return Path(__file__).resolve().parent.parent.parent


@pytest.fixture
def registry_path(repo_root: Path) -> Path:
    return repo_root / "skills-registry.yaml"


@pytest.fixture
def skills_dir(repo_root: Path) -> Path:
    return repo_root
