"""Server tool tests — invoke MCP tools through FastMCP's async API.

We test via `server.call_tool(name, arguments)` rather than going through
MCP transport, since transport-layer is integration-tested at runtime via
the Claude Code / Codex / Cursor smoke check.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import pytest

from pala_mcp.server import PalaState, build_server, default_skill_dir


@pytest.fixture
def state(registry_path: Path, skills_dir: Path) -> PalaState:
    s = PalaState(skill_dir=skills_dir, registry_path=registry_path)
    s.registry()  # warm-load
    return s


def _extract_result(call_tool_response: Any) -> Any:
    """Pull the structured/JSON content out of a FastMCP call_tool response."""
    # FastMCP 3.x returns a CallToolResult-like object; check common shapes
    if hasattr(call_tool_response, "structured_content"):
        sc = call_tool_response.structured_content
        if sc is not None:
            # Tools wrapped in a dict with "result" key
            if isinstance(sc, dict) and "result" in sc and len(sc) == 1:
                return sc["result"]
            return sc
    if hasattr(call_tool_response, "data"):
        return call_tool_response.data
    if hasattr(call_tool_response, "content"):
        content = call_tool_response.content
        if isinstance(content, list) and content:
            first = content[0]
            if hasattr(first, "text"):
                try:
                    return json.loads(first.text)
                except (ValueError, TypeError):
                    return first.text
            return first
    return call_tool_response


def _extract_json_result(call_tool_response: Any) -> dict:
    result = _extract_result(call_tool_response)
    if isinstance(result, str):
        return json.loads(result)
    return result


def test_build_server_returns_fastmcp(state: PalaState) -> None:
    """Server builds without error."""
    server = build_server(state)
    assert server is not None
    assert server.name == "pala-mcp"


@pytest.mark.asyncio
async def test_list_skills_returns_published(state: PalaState) -> None:
    """list_skills returns published skills, no planned."""
    server = build_server(state)
    response = await server.call_tool("pala_list_skills", {})
    result = _extract_result(response)
    assert isinstance(result, list)
    assert len(result) > 0
    statuses = {item["status"] for item in result}
    assert statuses.issubset({"stable", "draft"})


@pytest.mark.asyncio
async def test_list_skills_filter_domain(state: PalaState) -> None:
    """Domain filter narrows results."""
    server = build_server(state)
    response = await server.call_tool("pala_list_skills", {"domain": "universal"})
    result = _extract_result(response)
    assert all(item["domain"] == "universal" for item in result)


@pytest.mark.asyncio
async def test_list_skills_filter_status(state: PalaState) -> None:
    """Status filter narrows results."""
    server = build_server(state)
    response = await server.call_tool("pala_list_skills", {"status": "stable"})
    result = _extract_result(response)
    assert all(item["status"] == "stable" for item in result)


@pytest.mark.asyncio
async def test_list_skills_premium_filter_hidden_for_free_user(
    state: PalaState, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.delenv("PALA_LOCAL_AUTH_TOKEN", raising=False)
    server = build_server(state, enforce_local_auth=True)
    response = await server.call_tool("pala_list_skills", {"tier": "premium"})
    result = _extract_result(response)
    assert result == []


@pytest.mark.asyncio
async def test_list_skills_premium_filter_visible_for_paid_user(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    registry = tmp_path / "skills-registry.yaml"
    registry.write_text(
        "\n".join(
            [
                "version: 1",
                "updated: '2026-05-18'",
                "skills:",
                "  - name: free-skill",
                "    domain: universal",
                "    status: stable",
                "    path: skills/universal/free-skill",
                "    tier: free",
                "  - name: premium-skill",
                "    domain: universal",
                "    status: stable",
                "    path: skills/universal/premium-skill",
                "    tier: premium",
            ]
        )
        + "\n",
        encoding="utf-8",
    )

    monkeypatch.setenv("PALA_API_KEYS", "pala_prod_good:premium:cus_123:600")
    monkeypatch.setenv("PALA_LOCAL_AUTH_TOKEN", "pala_prod_good")
    monkeypatch.setattr("pala_mcp.premium.get_customer_id", lambda token: "cus_123")

    state = PalaState(skill_dir=tmp_path, registry_path=registry)
    state.registry()
    server = build_server(state, enforce_local_auth=True)

    response = await server.call_tool(
        "pala_list_skills",
        {"tier": "premium", "customer_id": "cus_123"},
    )
    result = _extract_result(response)

    assert [item["name"] for item in result] == ["premium-skill"]
    assert all(item["tier"] == "premium" for item in result)


@pytest.mark.asyncio
async def test_get_skill_known(state: PalaState) -> None:
    """get_skill returns full content for a known skill."""
    server = build_server(state)
    response = await server.call_tool("pala_get_skill", {"name": "brainstorming"})
    result = _extract_result(response)
    assert "error" not in result
    assert result["name"] == "brainstorming"
    assert "frontmatter" in result
    assert "body" in result
    assert result["body_line_count"] > 0


@pytest.mark.asyncio
async def test_get_skill_unknown(state: PalaState) -> None:
    """get_skill returns error dict for missing skill."""
    server = build_server(state)
    response = await server.call_tool(
        "pala_get_skill", {"name": "this-skill-does-not-exist"}
    )
    result = _extract_result(response)
    assert "error" in result


@pytest.mark.asyncio
async def test_search_skills_finds_relevant(state: PalaState) -> None:
    """search_skills returns hits sorted by score."""
    server = build_server(state)
    response = await server.call_tool(
        "pala_search_skills", {"query": "redis cache stampede", "limit": 5}
    )
    result = _extract_result(response)
    assert isinstance(result, list)
    assert len(result) > 0
    scores = [r["score"] for r in result]
    assert scores == sorted(scores, reverse=True)


@pytest.mark.asyncio
async def test_search_skills_limit_cap(state: PalaState) -> None:
    """search_skills caps limit at 25."""
    server = build_server(state)
    response = await server.call_tool(
        "pala_search_skills", {"query": "test", "limit": 1000}
    )
    result = _extract_result(response)
    assert len(result) <= 25


@pytest.mark.asyncio
async def test_pala_health_tool_returns_json(state: PalaState) -> None:
    server = build_server(state)

    response = await server.call_tool("pala_health", {})
    result = _extract_json_result(response)

    assert result == {"status": "healthy"}


@pytest.mark.asyncio
async def test_pala_health_verbose(state: PalaState) -> None:
    server = build_server(state)

    response = await server.call_tool("pala_health", {"verbose": True})
    result = _extract_json_result(response)

    assert result["status"] == "healthy"
    assert set(result["checks"]) == {"registry", "skills_dir", "mcp_tools"}
    assert result["checks"]["mcp_tools"]["missing_tools"] == []


@pytest.mark.asyncio
async def test_pala_health_when_registry_broken(
    skills_dir: Path, tmp_path: Path
) -> None:
    state = PalaState(skill_dir=skills_dir, registry_path=tmp_path / "missing.yaml")
    server = build_server(state)

    response = await server.call_tool("pala_health", {"verbose": True})
    result = _extract_json_result(response)

    assert result["status"] == "unhealthy"
    assert result["checks"]["registry"]["status"] == "unhealthy"


def test_default_skill_dir_with_env(monkeypatch, tmp_path: Path) -> None:
    """default_skill_dir honours PALA_SKILLS_DIR env."""
    monkeypatch.setenv("PALA_SKILLS_DIR", str(tmp_path))
    assert default_skill_dir() == tmp_path
