"""Registry loader tests."""

from __future__ import annotations

from pathlib import Path

import pytest

from pala_mcp.registry import Registry, Skill


def test_load_registry_smoke(registry_path: Path) -> None:
    """Registry loads without error and produces at least the stable php-modern skill."""
    reg = Registry.load(registry_path)
    assert reg.version >= 1
    assert reg.updated
    assert len(reg.skills) > 0

    by_name = {s.name: s for s in reg.skills}
    assert "php-modern" in by_name
    assert by_name["php-modern"].status == "stable"


def test_published_excludes_planned_and_optional(registry_path: Path) -> None:
    """published() drops planned and optional entries."""
    reg = Registry.load(registry_path)
    for s in reg.published():
        assert s.status in ("stable", "draft")
        assert not s.optional


def test_filter_by_domain(registry_path: Path) -> None:
    """Domain filter narrows results."""
    reg = Registry.load(registry_path)
    universal = reg.filter(domain="universal")
    assert all(s.domain == "universal" for s in universal)
    assert len(universal) >= 20  # we have at least 20 universal skills stable


def test_filter_by_status(registry_path: Path) -> None:
    """Status filter narrows results."""
    reg = Registry.load(registry_path)
    stables = reg.filter(status="stable")
    assert all(s.status == "stable" for s in stables)


def test_filter_by_access_tier(tmp_path: Path) -> None:
    path = tmp_path / "registry.yaml"
    path.write_text(
        "\n".join(
            [
                "version: 1",
                "updated: '2026-05-18'",
                "skills:",
                "  - name: free-skill",
                "    domain: universal",
                "    status: stable",
                "    path: skills/universal/free-skill",
                "  - name: premium-skill",
                "    domain: universal",
                "    status: stable",
                "    path: skills/universal/premium-skill",
                "    tier: premium",
            ]
        )
        + "\n",
        encoding="utf-8",
    )
    reg = Registry.load(path)
    premium = reg.filter(tier="premium")
    free = reg.filter(tier="free")

    assert [skill.name for skill in premium] == ["premium-skill"]
    assert [skill.name for skill in free] == ["free-skill"]


def test_get_by_name(registry_path: Path) -> None:
    """get() returns Skill on hit, None on miss."""
    reg = Registry.load(registry_path)
    assert reg.get("brainstorming") is not None
    assert reg.get("nonexistent-skill-xyz") is None


def test_planned_skill_not_published(registry_path: Path) -> None:
    """Planned skills are loaded but not in published()."""
    reg = Registry.load(registry_path)
    planned = [s for s in reg.skills if s.status == "planned"]
    if planned:
        names = {s.name for s in reg.published()}
        for p in planned:
            assert p.name not in names


def test_stale_detection(tmp_path: Path) -> None:
    """is_stale returns True after the underlying file changes mtime."""
    p = tmp_path / "test-registry.yaml"
    p.write_text(
        "version: 1\nupdated: '2026-01-01'\nskills:\n  - name: foo\n    domain: universal\n"
        "    status: stable\n    path: skills/universal/foo\n",
        encoding="utf-8",
    )
    reg = Registry.load(p)
    assert not reg.is_stale(p)

    # Touch with later mtime
    import os
    import time

    later = time.time() + 10
    os.utime(p, (later, later))
    assert reg.is_stale(p)


def test_skill_is_published_invariants() -> None:
    """Skill.is_published encodes status + optional rule."""
    assert Skill("a", "universal", "stable", "skills/universal/a").is_published
    assert Skill("a", "universal", "draft", "skills/universal/a").is_published
    assert not Skill("a", "universal", "planned", "skills/universal/a").is_published
    assert not Skill("a", "meta", "draft", "meta/a", optional=True).is_published
    assert Skill("a", "universal", "stable", "skills/universal/a").access_tier == "free"


def test_missing_file_raises(tmp_path: Path) -> None:
    """Missing registry path raises FileNotFoundError."""
    with pytest.raises(FileNotFoundError):
        Registry.load(tmp_path / "missing.yaml")
