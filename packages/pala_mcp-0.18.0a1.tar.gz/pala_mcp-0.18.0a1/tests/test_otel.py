from __future__ import annotations

import builtins
import subprocess
from types import SimpleNamespace

import pytest

from pala_mcp import otel


class FakeExporter:
    endpoints: list[str] = []

    def __init__(self, *, endpoint: str) -> None:
        self.endpoint = endpoint
        self.endpoints.append(endpoint)


class FakeProcessor:
    def __init__(self, exporter: FakeExporter) -> None:
        self.exporter = exporter


class FakeProvider:
    providers: list["FakeProvider"] = []

    def __init__(self, *, resource: object) -> None:
        self.resource = resource
        self.processors: list[FakeProcessor] = []
        self.providers.append(self)

    def add_span_processor(self, processor: FakeProcessor) -> None:
        self.processors.append(processor)


def test_tracer_initialized_with_endpoint(monkeypatch: pytest.MonkeyPatch) -> None:
    FakeExporter.endpoints.clear()
    FakeProvider.providers.clear()
    monkeypatch.setenv("OTEL_EXPORTER_OTLP_ENDPOINT", "http://tempo:4318")
    monkeypatch.setattr(otel, "OTLPSpanExporter", FakeExporter)
    monkeypatch.setattr(otel, "BatchSpanProcessor", FakeProcessor)
    monkeypatch.setattr(otel, "TracerProvider", FakeProvider)
    monkeypatch.setattr(otel.trace, "set_tracer_provider", lambda provider: None)
    monkeypatch.setattr(otel, "_instrument_runtime", lambda: None)

    assert otel.init_tracer() is True

    state = otel.tracer_state()
    assert state.enabled is True
    assert state.endpoint == "http://tempo:4318/v1/traces"
    assert FakeExporter.endpoints == ["http://tempo:4318/v1/traces"]
    assert len(FakeProvider.providers[0].processors) == 1


def test_otlp_export_disabled_when_endpoint_unset(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.delenv("OTEL_EXPORTER_OTLP_ENDPOINT", raising=False)

    assert otel.init_tracer("") is False

    state = otel.tracer_state()
    assert state.enabled is False
    assert state.endpoint is None


def test_trace_endpoint_preserves_signal_path() -> None:
    assert (
        otel._trace_endpoint("http://tempo:4318/v1/traces")
        == "http://tempo:4318/v1/traces"
    )


def test_command_name_redacts_to_executable() -> None:
    assert otel._command_name(["python", "-c", "print('secret')"]) == "python"
    assert otel._command_name("npm.cmd run build") == "npm.cmd"
    assert otel._command_name([]) == "unknown"


def test_instrument_runtime_runs_once(monkeypatch: pytest.MonkeyPatch) -> None:
    calls: list[str] = []
    real_import = builtins.__import__

    class SQLite3Instrumentor:
        def instrument(self) -> None:
            calls.append("sqlite")

    def fake_import(name: str, *args: object, **kwargs: object) -> object:
        if name == "opentelemetry.instrumentation.sqlite3":
            return SimpleNamespace(SQLite3Instrumentor=SQLite3Instrumentor)
        return real_import(name, *args, **kwargs)

    monkeypatch.setattr(builtins, "__import__", fake_import)
    monkeypatch.setattr(otel, "_INSTRUMENTED", False)
    monkeypatch.setattr(otel, "_instrument_subprocess", lambda: calls.append("subprocess"))

    otel._instrument_runtime()
    otel._instrument_runtime()

    assert calls == ["sqlite", "subprocess"]


def test_instrument_subprocess_creates_run_and_popen_spans(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    spans: list[SimpleNamespace] = []

    class Span:
        def __init__(self, name: str) -> None:
            self.name = name
            self.attributes: dict[str, object] = {}

        def __enter__(self) -> "Span":
            spans.append(SimpleNamespace(name=self.name, attributes=self.attributes))
            return self

        def __exit__(self, *args: object) -> None:
            return None

        def set_attribute(self, name: str, value: object) -> None:
            self.attributes[name] = value

    class Tracer:
        def start_as_current_span(self, name: str) -> Span:
            return Span(name)

    class Trace:
        def get_tracer(self, name: str) -> Tracer:
            return Tracer()

    class BasePopen:
        def __init__(self, *args: object, **kwargs: object) -> None:
            self.pid = 4321

    def fake_run(*args: object, **kwargs: object) -> SimpleNamespace:
        return SimpleNamespace(returncode=7)

    monkeypatch.setattr(otel, "trace", Trace())
    monkeypatch.setattr(otel, "_ORIGINAL_RUN", None)
    monkeypatch.setattr(otel, "_ORIGINAL_POPEN", None)
    monkeypatch.setattr(subprocess, "run", fake_run)
    monkeypatch.setattr(subprocess, "Popen", BasePopen)

    otel._instrument_subprocess()
    result = subprocess.run(["python", "-V"])
    process = subprocess.Popen(["python"])

    assert result.returncode == 7
    assert process.pid == 4321
    assert [span.name for span in spans] == ["subprocess.run", "subprocess.Popen"]
    assert spans[0].attributes["subprocess.command"] == "python"
    assert spans[0].attributes["subprocess.returncode"] == 7
    assert spans[1].attributes["subprocess.pid"] == 4321


def test_trace_tool_decorator_creates_span(monkeypatch: pytest.MonkeyPatch) -> None:
    spans: list[SimpleNamespace] = []

    class Span:
        def __init__(self, name: str) -> None:
            self.name = name
            self.attributes: dict[str, str] = {}

        def __enter__(self) -> "Span":
            spans.append(SimpleNamespace(name=self.name, attributes=self.attributes))
            return self

        def __exit__(self, *args: object) -> None:
            return None

        def set_attribute(self, name: str, value: str) -> None:
            self.attributes[name] = value

    class Tracer:
        def start_as_current_span(self, name: str) -> Span:
            return Span(name)

    monkeypatch.setattr(otel.trace, "get_tracer", lambda name: Tracer())

    @otel.trace_tool("unit_tool")
    def unit() -> str:
        return "ok"

    assert unit() == "ok"
    assert [span.name for span in spans] == ["mcp.tool.unit_tool"]


def test_trace_tool_noops_without_trace(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(otel, "trace", None)

    @otel.trace_tool("unit_tool")
    def unit() -> str:
        return "ok"

    assert unit() == "ok"


def test_span_attributes_include_tool_name(monkeypatch: pytest.MonkeyPatch) -> None:
    captured: dict[str, str] = {}

    class Span:
        def __enter__(self) -> "Span":
            return self

        def __exit__(self, *args: object) -> None:
            return None

        def set_attribute(self, name: str, value: str) -> None:
            captured[name] = value

    class Tracer:
        def start_as_current_span(self, name: str) -> Span:
            return Span()

    monkeypatch.setattr(otel.trace, "get_tracer", lambda name: Tracer())

    @otel.trace_tool("pala_list_skills")
    def unit() -> str:
        return "ok"

    assert unit() == "ok"
    assert captured["mcp.tool.name"] == "pala_list_skills"


@pytest.mark.asyncio
async def test_trace_tool_decorator_supports_async(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    names: list[str] = []

    class Span:
        def __init__(self, name: str) -> None:
            self.name = name

        def __enter__(self) -> "Span":
            names.append(self.name)
            return self

        def __exit__(self, *args: object) -> None:
            return None

        def set_attribute(self, name: str, value: str) -> None:
            return None

    class Tracer:
        def start_as_current_span(self, name: str) -> Span:
            return Span(name)

    monkeypatch.setattr(otel.trace, "get_tracer", lambda name: Tracer())

    @otel.trace_tool("async_tool")
    async def unit() -> str:
        return "ok"

    assert await unit() == "ok"
    assert names == ["mcp.tool.async_tool"]
