"""SKILL.md reader tests."""

from __future__ import annotations

from pathlib import Path

import pytest

from pala_mcp.reader import (
    SkillReadError,
    cached_parse,
    parse_skill,
    read_skill,
    resolve_skill_path,
)


def test_parse_real_skill(skills_dir: Path) -> None:
    """Parse a known stable skill end-to-end."""
    path = skills_dir / "skills" / "universal" / "brainstorming" / "SKILL.md"
    content = parse_skill(path)
    assert content.name == "brainstorming"
    assert content.description
    assert "metadata" in content.frontmatter
    # body_line_count counts non-blank body lines; real skills have 150+ non-blank
    assert content.body_line_count >= 150


def test_parse_missing_file(tmp_path: Path) -> None:
    """Missing file raises SkillReadError."""
    with pytest.raises(SkillReadError):
        parse_skill(tmp_path / "nope.md")


def test_parse_malformed_no_frontmatter(tmp_path: Path) -> None:
    """File without --- delimiters is rejected."""
    p = tmp_path / "bad.md"
    p.write_text("# Just a heading\nNo frontmatter.\n", encoding="utf-8")
    with pytest.raises(SkillReadError):
        parse_skill(p)


def test_parse_malformed_unterminated_frontmatter(tmp_path: Path) -> None:
    """File with opening but no closing --- is rejected."""
    p = tmp_path / "bad.md"
    p.write_text("---\nname: foo\n# body without close\n", encoding="utf-8")
    with pytest.raises(SkillReadError):
        parse_skill(p)


def test_resolve_skill_path_safe(skills_dir: Path) -> None:
    """Normal registry path resolves to expected SKILL.md."""
    resolved = resolve_skill_path(skills_dir, "skills/universal/brainstorming")
    assert resolved.name == "SKILL.md"
    assert "brainstorming" in str(resolved)


def test_resolve_skill_path_rejects_traversal(skills_dir: Path) -> None:
    """Path traversal is rejected."""
    with pytest.raises(SkillReadError):
        resolve_skill_path(skills_dir, "../../etc/passwd")


def test_resolve_skill_path_rejects_absolute(skills_dir: Path) -> None:
    """Absolute paths are rejected."""
    with pytest.raises(SkillReadError):
        resolve_skill_path(skills_dir, "/etc/passwd")


def test_read_skill_round_trip(skills_dir: Path) -> None:
    """read_skill end-to-end via registry path."""
    content = read_skill(skills_dir, "skills/universal/code-review")
    assert content.name == "code-review"
    # SKILL.md frontmatter status may lag registry status; just verify the field exists
    assert "status" in content.frontmatter.get("metadata", {})


def test_cached_parse_reuses_result(skills_dir: Path) -> None:
    """cached_parse returns the same object on identical key."""
    path = skills_dir / "skills" / "universal" / "brainstorming" / "SKILL.md"
    mtime = path.stat().st_mtime
    a = cached_parse(str(path), mtime)
    b = cached_parse(str(path), mtime)
    assert a is b
