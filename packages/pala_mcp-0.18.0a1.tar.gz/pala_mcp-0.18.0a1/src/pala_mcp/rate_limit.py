"""Rate limiting primitives for Pala MCP cloud runtime."""

from __future__ import annotations

import hashlib
import math
import time
from collections.abc import Callable
from dataclasses import dataclass
from typing import Protocol


@dataclass
class RateLimitResult:
    allowed: bool
    retry_after: int
    remaining: int


@dataclass
class _Bucket:
    tokens: float
    updated_at: float


class RedisRateLimitBackend(Protocol):
    """Interface kept for a production Redis swap.

    NotImplementedError is intentional — this is a Protocol class (PEP 544),
    not a concrete implementation. Production deploys (Hetzner CPX21+) supply
    a real Redis-backed class implementing this interface. Local-first runs
    use InMemoryTokenBucketLimiter below.
    """

    def check(self, key: str, limit_per_minute: int) -> RateLimitResult:  # pragma: no cover
        raise NotImplementedError


class InMemoryTokenBucketLimiter:
    def __init__(self, clock: Callable[[], float] | None = None) -> None:
        self._clock = clock or time.monotonic
        self._buckets: dict[str, _Bucket] = {}

    def check(self, key: str, limit_per_minute: int) -> RateLimitResult:
        if limit_per_minute <= 0:
            return RateLimitResult(allowed=False, retry_after=60, remaining=0)

        now = float(self._clock())
        capacity = float(limit_per_minute)
        refill_per_second = capacity / 60.0
        bucket = self._buckets.get(key)

        if bucket is None:
            bucket = _Bucket(tokens=capacity, updated_at=now)
            self._buckets[key] = bucket
        else:
            elapsed = max(0.0, now - bucket.updated_at)
            bucket.tokens = min(capacity, bucket.tokens + elapsed * refill_per_second)
            bucket.updated_at = now

        if bucket.tokens >= 1.0:
            bucket.tokens -= 1.0
            return RateLimitResult(
                allowed=True,
                retry_after=0,
                remaining=max(0, math.floor(bucket.tokens)),
            )

        retry_after = max(1, math.ceil((1.0 - bucket.tokens) / refill_per_second))
        return RateLimitResult(allowed=False, retry_after=retry_after, remaining=0)

    def reset(self) -> None:
        self._buckets.clear()


def rate_limit_key(*, ip_address: str | None = None, token: str | None = None) -> str:
    if token:
        digest = hashlib.sha256(token.encode("utf-8")).hexdigest()[:24]
        return f"token:{digest}"
    return f"ip:{ip_address or 'unknown'}"
