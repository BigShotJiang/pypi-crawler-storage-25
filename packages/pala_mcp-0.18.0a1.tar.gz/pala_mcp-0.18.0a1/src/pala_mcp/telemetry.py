"""Opt-in telemetry stub for local MCP runtime events."""

from __future__ import annotations

import json
import os
from datetime import UTC, datetime
from pathlib import Path
from typing import Any


def _enabled() -> bool:
    return os.environ.get("PALA_TELEMETRY", "off").lower() == "on"


def _log_path() -> Path:
    return Path.home() / ".pala" / "telemetry.log"


def emit(event_type: str, payload: dict[str, Any] | None = None) -> None:
    if not _enabled():
        return

    safe_payload: dict[str, Any] = {}
    payload = payload or {}
    if "tool" in payload:
        safe_payload["tool"] = str(payload["tool"])
    if "duration_ms" in payload:
        safe_payload["duration_ms"] = float(payload["duration_ms"])

    event = {
        "event": event_type,
        "timestamp": datetime.now(UTC).isoformat(),
        **safe_payload,
    }

    path = _log_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(event, separators=(",", ":"), sort_keys=True) + "\n")
