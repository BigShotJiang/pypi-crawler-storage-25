"""Health checks for the Pala MCP server."""

from __future__ import annotations

from dataclasses import asdict, dataclass
from datetime import UTC, datetime
from importlib.metadata import PackageNotFoundError, version
from typing import Literal

REQUIRED_MCP_TOOLS = (
    "pala_list_skills",
    "pala_get_skill",
    "pala_search_skills",
)


@dataclass
class HealthResult:
    status: Literal["healthy", "degraded", "unhealthy"]
    checks: dict[str, dict]
    timestamp: str
    version: str

    def to_dict(self) -> dict:
        return asdict(self)


def _package_version() -> str:
    """Resolve pala-mcp package version. Prefer installed metadata, fall back to module __version__."""
    try:
        return version("pala-mcp")
    except PackageNotFoundError:
        # Editable install without egg-info or non-installed dev mode — use module fallback
        from . import __version__ as module_version

        return module_version


def check_registry(state) -> dict:
    try:
        registry = state.registry()
    except Exception as exc:
        return {
            "status": "unhealthy",
            "registry_path": str(state.registry_path),
            "error": f"{type(exc).__name__}: {exc}",
        }

    return {
        "status": "healthy",
        "registry_path": str(state.registry_path),
        "skill_count": len(registry.skills),
        "published_count": len(registry.published()),
    }


def check_skills_dir(state) -> dict:
    skills_dir = state.skill_dir
    if not skills_dir.is_dir():
        return {
            "status": "degraded",
            "skills_dir": str(skills_dir),
            "skill_file_count": 0,
            "error": "skills directory not found",
        }

    skill_files = tuple(skills_dir.rglob("SKILL.md"))
    status: Literal["healthy", "degraded"] = "healthy" if skill_files else "degraded"
    result = {
        "status": status,
        "skills_dir": str(skills_dir),
        "skill_file_count": len(skill_files),
    }
    if not skill_files:
        result["error"] = "no SKILL.md files found"
    return result


def check_mcp_tools(state) -> dict:
    tool_names = tuple(getattr(state, "mcp_tool_names", REQUIRED_MCP_TOOLS))
    missing = [name for name in REQUIRED_MCP_TOOLS if name not in tool_names]
    return {
        "status": "healthy" if not missing else "unhealthy",
        "required_tools": list(REQUIRED_MCP_TOOLS),
        "available_tools": list(tool_names),
        "missing_tools": missing,
    }


def aggregate_health(state) -> dict:
    checks = {
        "registry": check_registry(state),
        "skills_dir": check_skills_dir(state),
        "mcp_tools": check_mcp_tools(state),
    }
    statuses = {check["status"] for check in checks.values()}
    if "unhealthy" in statuses:
        status: Literal["healthy", "degraded", "unhealthy"] = "unhealthy"
    elif "degraded" in statuses:
        status = "degraded"
    else:
        status = "healthy"

    result = HealthResult(
        status=status,
        checks=checks,
        timestamp=datetime.now(UTC).isoformat(),
        version=_package_version(),
    )
    return result.to_dict()
