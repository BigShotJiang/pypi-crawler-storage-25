"""Pala MCP server — FastMCP-based skill server.

Exposes five tools to MCP clients (Claude Code, Codex, Cursor, etc.):
  - pala_list_skills(domain?, status?, tier?, customer_id?) -> [SkillSummary]
  - pala_get_skill(name) -> {name, frontmatter, body}
  - pala_search_skills(query, limit?) -> [SearchHit]
  - pala_recommend(context, limit?) -> [SkillSummary]
  - pala_health(verbose?) -> JSON health status

Pala-original. Synthesized for Pala OS.
"""

from __future__ import annotations

import json
import logging
import os
import time
from pathlib import Path

from fastmcp import FastMCP
from fastmcp.server.dependencies import get_http_request
from starlette.requests import Request
from starlette.responses import JSONResponse, Response

from . import auth as auth_module
from . import health, metrics
from .auth import PalaAuthMiddleware, normalize_token, verify_token
from .otel import init_tracer, trace_tool
from .premium import check_license_scope, filter_skills_for_tier
from .reader import SkillReadError, read_skill
from .recommend import recommend
from .registry import Registry, default_registry_path
from .search import SkillIndex
from .telemetry import emit

log = logging.getLogger("pala_mcp.server")


class PalaState:
    """Singleton-ish state holder for the running server."""

    def __init__(self, skill_dir: Path, registry_path: Path):
        self.skill_dir = skill_dir
        self.registry_path = registry_path
        self._registry: Registry | None = None
        self._index: SkillIndex | None = None
        self.mcp_tool_names = (
            "pala_list_skills",
            "pala_get_skill",
            "pala_search_skills",
            "pala_recommend",
            "pala_health",
        )

    def registry(self) -> Registry:
        """Return current registry, reload if file changed on disk."""
        if self._registry is None or self._registry.is_stale(self.registry_path):
            self._registry = Registry.load(self.registry_path)
            self._index = None  # invalidate search index on reload
            metrics.set_registry_skills_total(len(self._registry.skills))
            log.info("Loaded registry: %d skills", len(self._registry.skills))
        return self._registry

    def index(self) -> SkillIndex:
        """Return current search index, rebuilt after registry reload."""
        if self._index is None:
            self._index = SkillIndex(self.registry(), self.skill_dir)
        return self._index


def build_server(
    state: PalaState, *, enforce_local_auth: bool | None = None
) -> FastMCP:
    """Construct a FastMCP server with Pala tools bound to the given state."""
    init_tracer()
    auth_module.FREE_TOOLS.add("pala_recommend")
    auth_module.ALL_TOOLS.add("pala_recommend")
    if enforce_local_auth is None:
        enforce_local_auth = os.environ.get("PALA_ENFORCE_LOCAL_AUTH") == "1"

    mcp: FastMCP = FastMCP(
        name="pala-mcp",
        instructions=(
            "Pala OS skill registry server. Use pala_search_skills to find "
            "skills by topic, pala_list_skills to enumerate, and pala_get_skill "
            "to read full content."
        ),
        middleware=[PalaAuthMiddleware(enforce_without_http=enforce_local_auth)],
    )

    @mcp.custom_route("/health", methods=["GET"])
    async def http_health(_: Request) -> JSONResponse:
        result = health.aggregate_health(state)
        status_code = 200 if result["status"] == "healthy" else 503
        return JSONResponse(result, status_code=status_code)

    @mcp.custom_route("/metrics", methods=["GET"])
    async def http_metrics(_: Request) -> Response:
        return Response(
            metrics.render_metrics(),
            media_type=metrics.CONTENT_TYPE_LATEST,
        )

    @mcp.tool()
    @trace_tool("pala_list_skills")
    def pala_list_skills(
        domain: str | None = None,
        status: str | None = None,
        tier: str | None = None,
        customer_id: str | None = None,
    ) -> list[dict]:
        """List published Pala skills.

        Args:
            domain: Optional filter by domain (universal, web-frontend, ai-ml, etc.).
            status: Optional filter by status (stable, draft).
            tier: Optional access filter (`free` or `premium`).
            customer_id: Optional Stripe customer id for premium entitlement scope.

        Returns:
            List of skill summaries with name, domain, status, path.
        """
        started = time.perf_counter()
        try:
            reg = state.registry()
            skills = reg.filter(domain=domain, status=status)
            caller_tier, raw_token = _request_tier_and_token()
            skills = filter_skills_for_tier(
                skills,
                requested_tier=tier,
                caller_tier=caller_tier,
            )

            if tier and tier.strip().lower() == "premium":
                license_check = check_license_scope(
                    raw_token=raw_token,
                    requested_customer_id=customer_id,
                )
                if not license_check.allowed:
                    return []

            return [
                {
                    "name": s.name,
                    "domain": s.domain,
                    "status": s.status,
                    "path": s.path,
                    "tier": s.access_tier,
                }
                for s in skills
            ]
        finally:
            emit(
                "mcp.tool.call",
                {
                    "tool": "pala_list_skills",
                    "duration_ms": (time.perf_counter() - started) * 1000,
                },
            )

    @mcp.tool()
    @trace_tool("pala_get_skill")
    def pala_get_skill(name: str) -> dict:
        """Read the full content of a Pala skill by name.

        Args:
            name: The skill name as registered (e.g. 'brainstorming').

        Returns:
            Dict with name, description, frontmatter (parsed YAML), body (markdown),
            and body_line_count.
        """
        started = time.perf_counter()
        try:
            reg = state.registry()
            skill = reg.get(name)
            if skill is None:
                return {"error": f"Skill not found or not published: {name}"}
            try:
                content = read_skill(state.skill_dir, skill.path)
            except SkillReadError as exc:
                return {"error": f"Failed to read SKILL.md: {exc}"}
            return {
                "name": content.name,
                "description": content.description,
                "frontmatter": content.frontmatter,
                "body": content.body,
                "body_line_count": content.body_line_count,
                "domain": skill.domain,
                "status": skill.status,
            }
        finally:
            emit(
                "mcp.tool.call",
                {
                    "tool": "pala_get_skill",
                    "duration_ms": (time.perf_counter() - started) * 1000,
                },
            )

    @mcp.tool()
    @trace_tool("pala_search_skills")
    def pala_search_skills(query: str, limit: int = 5) -> list[dict]:
        """Search Pala skills by keyword across name, description, and triggers.

        Args:
            query: Search phrase (e.g. 'redis cache stampede').
            limit: Max number of hits to return (default 5, capped at 25).

        Returns:
            List of hits sorted by score descending.
        """
        started = time.perf_counter()
        try:
            capped = max(1, min(limit, 25))
            hits = state.index().search(query, capped)
            return [
                {
                    "name": h.name,
                    "score": h.score,
                    "description": h.description,
                    "domain": h.domain,
                    "status": h.status,
                    "matched_section": h.matched_section,
                }
                for h in hits
            ]
        finally:
            emit(
                "mcp.tool.call",
                {
                    "tool": "pala_search_skills",
                    "duration_ms": (time.perf_counter() - started) * 1000,
                },
            )

    @mcp.tool()
    @trace_tool("pala_recommend")
    def pala_recommend(context: str, limit: int = 5) -> list[dict]:
        """Recommend Pala skills from the active context."""
        started = time.perf_counter()
        try:
            return recommend(
                context,
                limit,
                tier=_request_tier(),
                registry_path=state.registry_path,
                skill_dir=state.skill_dir,
            )
        finally:
            emit(
                "mcp.tool.call",
                {
                    "tool": "pala_recommend",
                    "duration_ms": (time.perf_counter() - started) * 1000,
                },
            )

    @mcp.tool()
    @trace_tool("pala_health")
    def pala_health(verbose: bool = False) -> str:
        """Return MCP health status as JSON."""
        started = time.perf_counter()
        try:
            result = health.aggregate_health(state)
            payload = result if verbose else {"status": result["status"]}
            return json.dumps(payload, sort_keys=True)
        finally:
            emit(
                "mcp.tool.call",
                {
                    "tool": "pala_health",
                    "duration_ms": (time.perf_counter() - started) * 1000,
                },
            )

    return mcp


def _request_tier() -> str:
    tier, _token = _request_tier_and_token()
    return tier


def _request_tier_and_token() -> tuple[str, str | None]:
    token = _request_token()
    normalized = normalize_token(token)
    context = verify_token(normalized) if normalized else None
    return context.tier if context else "free", normalized


def _request_token() -> str | None:
    try:
        request = get_http_request()
    except RuntimeError:
        return os.environ.get("PALA_LOCAL_AUTH_TOKEN")
    else:
        return (
            request.headers.get("authorization")
            or request.headers.get("x-pala-api-key")
            or request.headers.get("x-api-key")
        )


def default_skill_dir() -> Path:
    """Resolve skills directory from PALA_SKILLS_DIR or default to registry sibling."""
    env_dir = os.environ.get("PALA_SKILLS_DIR")
    if env_dir:
        return Path(env_dir)
    # Default: parent of registry file
    return default_registry_path().parent
