"""Context-aware Pala skill suggestions."""

from __future__ import annotations

import os
import random
import re
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from rapidfuzz import fuzz

from .reader import SkillReadError, read_skill
from .registry import Registry, Skill, default_registry_path

try:  # pragma: no cover - import guard for minimal local installs
    from opentelemetry import trace
except ImportError:  # pragma: no cover
    trace = None


@dataclass(frozen=True)
class SkillSummary:
    name: str
    score: float
    reason: str
    domain: str
    status: str
    path: str

    def to_dict(self) -> dict[str, str | float]:
        return {
            "name": self.name,
            "score": self.score,
            "reason": self.reason,
            "domain": self.domain,
            "status": self.status,
            "path": self.path,
        }


DOMAIN_HINTS: dict[str, tuple[str, ...]] = {
    "infra": (
        "deploy",
        "production",
        "vercel",
        "kubernetes",
        "docker",
        "terraform",
        "grafana",
        "prometheus",
        "tempo",
        "otel",
        "opentelemetry",
    ),
    "universal": (
        "incident",
        "rollback",
        "release",
        "debug",
        "observe",
        "observability",
        "error",
        "trace",
        "test",
    ),
    "security": (
        "secret",
        "token",
        "auth",
        "owasp",
        "threat",
        "sast",
        "dast",
    ),
    "web-backend": (
        "api",
        "redis",
        "postgres",
        "graphql",
        "grpc",
        "websocket",
        "fastapi",
    ),
    "web-frontend": (
        "react",
        "next",
        "astro",
        "vue",
        "svelte",
        "tailwind",
        "accessibility",
    ),
    "ai-ml": (
        "llm",
        "rag",
        "embedding",
        "model",
        "eval",
        "fine tuning",
        "agent",
    ),
    "data": (
        "warehouse",
        "lakehouse",
        "kafka",
        "clickhouse",
        "mongodb",
        "dynamodb",
        "dbt",
    ),
}

ROUTE_HINTS: tuple[tuple[tuple[str, ...], tuple[str, ...]], ...] = (
    (
        ("deploy", "production"),
        (
            "release-pipeline-design",
            "vercel-deploy-pipeline",
            "incident-response-runbook",
        ),
    ),
    (
        ("observability", "production"),
        (
            "observability-instrumentation",
            "observability-as-code",
            "error-tracking-strategy",
        ),
    ),
)


def _normalize(value: str) -> str:
    return re.sub(r"\s+", " ", value.strip().lower())


def _domain_affinity(context: str) -> set[str]:
    if not context:
        return set()
    domains: set[str] = set()
    for domain, hints in DOMAIN_HINTS.items():
        if any(hint in context for hint in hints):
            domains.add(domain)
    if {"deploy", "production", "release", "rollback"} & set(context.split()):
        domains.add("universal")
        domains.add("infra")
    return domains


def _tier_limit(limit: int, tier: str | None) -> int:
    requested = max(1, min(int(limit), 25))
    return 1 if tier != "premium" and tier != "enterprise" else requested


def _skill_entry(skill: Skill, root: Path) -> dict[str, Any] | None:
    try:
        content = read_skill(root, skill.path)
    except SkillReadError:
        return None
    metadata = content.frontmatter.get("metadata", {})
    triggers = metadata.get("triggers", [])
    trigger_text = " ".join(str(item) for item in triggers if item)
    return {
        "skill": skill,
        "description": content.description,
        "triggers": trigger_text,
        "blob": " ".join((skill.name, content.description, trigger_text)).lower(),
    }


def _reason(skill: Skill, matched: str, domains: set[str]) -> str:
    parts = [f"{matched} match"]
    if skill.domain in domains:
        parts.append(f"{skill.domain} affinity")
    return "; ".join(parts)


def _score(context: str, entry: dict[str, Any], domains: set[str]) -> tuple[float, str]:
    skill: Skill = entry["skill"]
    if not context:
        return 10.0, "baseline"
    name_score = fuzz.WRatio(context, skill.name.lower())
    description_score = fuzz.partial_ratio(context, entry["description"].lower())
    trigger_score = fuzz.partial_ratio(context, entry["triggers"].lower()) * 1.2
    blob_score = fuzz.token_set_ratio(context, entry["blob"]) * 0.85
    values = {
        "name": name_score,
        "description": description_score,
        "trigger": trigger_score,
        "content": blob_score,
    }
    matched, score = max(values.items(), key=lambda item: item[1])
    if skill.domain in domains:
        score += 18.0
    if skill.name in context:
        score += 12.0
    if skill.name == "docker-compose-patterns" and not (
        {"docker", "compose"} & set(context.split())
    ):
        score -= 18.0
    for terms, names in ROUTE_HINTS:
        if skill.name in names and all(term in context for term in terms):
            score += 14.0

    # v0.18.0-prep: status quality + Turkish bilingual boost
    # Stable skills outrank draft when content match is close (production-ready signal)
    if skill.status == "stable":
        score += 4.0
    elif skill.status == "draft":
        score -= 2.0
    # Bilingual exact-name token boost (TR queries hit EN skill names)
    context_tokens = set(re.findall(r"[a-z0-9-]+", context))
    skill_tokens = set(skill.name.split("-"))
    if skill_tokens.issubset(context_tokens):
        score += 6.0

    return round(min(score, 100.0), 1), matched


def _published_entries(registry: Registry, root: Path) -> list[dict[str, Any]]:
    entries: list[dict[str, Any]] = []
    for skill in registry.published():
        entry = _skill_entry(skill, root)
        if entry is not None:
            entries.append(entry)
    return entries


def recommend(
    context: str,
    limit: int = 5,
    *,
    tier: str | None = "premium",
    registry_path: Path | None = None,
    skill_dir: Path | None = None,
) -> list[dict[str, str | float]]:
    started = time.perf_counter()
    registry_file = registry_path or default_registry_path()
    root = skill_dir or registry_file.parent
    registry = Registry.load(registry_file)
    entries = _published_entries(registry, root)
    context_norm = _normalize(context)
    domains = _domain_affinity(context_norm)
    capped = _tier_limit(limit, tier)

    if not context_norm:
        seed = os.environ.get("PALA_RECOMMEND_SEED", "pala-recommend")
        rng = random.Random(seed)
        pool = list(entries)
        rng.shuffle(pool)
        selected = [
            SkillSummary(
                name=item["skill"].name,
                score=10.0,
                reason="baseline published skill",
                domain=item["skill"].domain,
                status=item["skill"].status,
                path=item["skill"].path,
            )
            for item in pool[:capped]
        ]
    else:
        ranked: list[SkillSummary] = []
        for entry in entries:
            skill: Skill = entry["skill"]
            score, matched = _score(context_norm, entry, domains)
            ranked.append(
                SkillSummary(
                    name=skill.name,
                    score=score,
                    reason=_reason(skill, matched, domains),
                    domain=skill.domain,
                    status=skill.status,
                    path=skill.path,
                )
            )
        ranked.sort(key=lambda item: (item.score, item.name), reverse=True)
        selected = ranked[:capped]

    duration_ms = (time.perf_counter() - started) * 1000
    if trace is not None:
        span = trace.get_current_span()
        span.set_attribute("mcp.recommend.duration", duration_ms)
        span.set_attribute("mcp.recommend.results_count", len(selected))

    return [item.to_dict() for item in selected]
