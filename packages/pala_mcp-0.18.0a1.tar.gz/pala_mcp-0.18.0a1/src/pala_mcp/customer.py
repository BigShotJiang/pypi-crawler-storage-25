"""Premium customer lookup for payment-issued tokens."""

from __future__ import annotations

import json
import os
import sqlite3
from datetime import UTC, datetime
from hmac import compare_digest
from pathlib import Path
from typing import Any, Literal

import bcrypt

Tier = Literal["free", "premium", "enterprise"]

ACTIVE_STATUSES = {"active", "trialing", "past_due"}
PAID_TIERS = {"premium", "enterprise"}
TOKEN_PREFIX_LENGTH = 24


def customer_store_path() -> Path:
    configured = os.environ.get("PALA_CUSTOMER_STORE")
    if configured:
        return Path(configured).expanduser()
    return Path.home() / ".pala" / "customers.json"


def customer_db_path() -> Path:
    configured = os.environ.get("PALA_DB_PATH")
    if configured:
        return Path(configured).expanduser()
    return Path.home() / ".pala" / "pala.db"


def get_tier(token: str) -> Tier:
    match = _find_token(token)
    if match is None:
        return "free"

    customer, token_record = match
    if not _token_active(token_record):
        return "free"
    if _subscription_status(customer) not in ACTIVE_STATUSES:
        return "free"

    tier = token_record.get("tier") or customer.get("tier")
    return tier if tier in PAID_TIERS else "free"


def is_token_valid(token: str) -> bool:
    return get_tier(token) in PAID_TIERS


def get_customer_id(token: str) -> str | None:
    match = _find_token(token)
    if match is None:
        return None
    customer, _token_record = match
    value = customer.get("stripe_customer_id") or customer.get("id")
    return str(value) if value else None


def _find_token(token: str) -> tuple[dict[str, Any], dict[str, Any]] | None:
    if not token:
        return None
    if os.environ.get("PALA_STORE", "json").lower() == "sqlite":
        return _find_sqlite_token(token)
    for customer in _load_customers():
        for record in _token_records(customer):
            value = str(record.get("token", ""))
            if value and compare_digest(value, token):
                return customer, record
    return None


def _find_sqlite_token(token: str) -> tuple[dict[str, Any], dict[str, Any]] | None:
    path = customer_db_path()
    if not path.exists():
        return None
    prefix = token[:TOKEN_PREFIX_LENGTH]
    now = datetime.now(UTC).isoformat()
    uri = f"file:{path.as_posix()}?mode=ro"
    try:
        connection = sqlite3.connect(uri, uri=True)
    except sqlite3.Error:
        return None
    try:
        connection.row_factory = sqlite3.Row
        rows = connection.execute(
            """
            SELECT
              c.id,
              c.stripe_customer_id,
              c.email,
              c.tier,
              c.status,
              t.token_hash,
              t.revoked_at,
              t.expires_at
            FROM tokens t
            JOIN customers c ON c.id = t.customer_id
            WHERE t.prefix = ?
              AND t.revoked_at IS NULL
              AND (t.expires_at IS NULL OR t.expires_at > ?)
            LIMIT 8
            """,
            (prefix, now),
        ).fetchall()
    except sqlite3.Error:
        return None
    finally:
        connection.close()

    for row in rows:
        token_hash = row["token_hash"]
        if _verify_hash(token, token_hash):
            customer = {
                "id": row["id"],
                "stripe_customer_id": row["stripe_customer_id"],
                "email": row["email"],
                "tier": row["tier"],
                "subscription_status": row["status"],
            }
            token_record = {
                "token": prefix,
                "tier": row["tier"],
                "revoked_at": row["revoked_at"],
                "expires_at": row["expires_at"],
            }
            return customer, token_record
    return None


def _load_customers() -> list[dict[str, Any]]:
    path = customer_store_path()
    if not path.exists():
        return []
    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return []
    if isinstance(raw, list):
        return [item for item in raw if isinstance(item, dict)]
    if isinstance(raw, dict) and isinstance(raw.get("customers"), list):
        return [item for item in raw["customers"] if isinstance(item, dict)]
    return []


def _token_records(customer: dict[str, Any]) -> list[dict[str, Any]]:
    tokens = customer.get("tokens", [])
    if not isinstance(tokens, list):
        return []
    records: list[dict[str, Any]] = []
    for token in tokens:
        if isinstance(token, dict):
            records.append(token)
        elif isinstance(token, str):
            records.append({"token": token, "tier": customer.get("tier", "premium")})
    return records


def _token_active(token_record: dict[str, Any]) -> bool:
    revoked_at = token_record.get("revoked_at")
    if revoked_at:
        return False

    expires_at = token_record.get("expires_at")
    if isinstance(expires_at, str) and expires_at:
        try:
            expires = datetime.fromisoformat(expires_at.replace("Z", "+00:00"))
        except ValueError:
            return False
        return expires > datetime.now(UTC)
    return True


def _subscription_status(customer: dict[str, Any]) -> str:
    subscription = customer.get("subscription")
    if isinstance(subscription, dict):
        status = subscription.get("status")
        if isinstance(status, str):
            return "cancelled" if status == "canceled" else status
    status = customer.get("subscription_status")
    if isinstance(status, str):
        return "cancelled" if status == "canceled" else status
    return "active"


def _verify_hash(token: str, token_hash: str) -> bool:
    try:
        return bcrypt.checkpw(token.encode("utf-8"), token_hash.encode("utf-8"))
    except ValueError:
        return False
