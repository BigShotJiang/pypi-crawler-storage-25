"""Premium-tier scaffolding for entitlement-aware MCP responses.

v0.15.0 scope:
- filter premium-marked skills from `pala_list_skills(tier="premium")`
- keep free users from seeing premium-only skills
- scaffold license checks around bearer token + Stripe customer id

v0.17.0 (ADR-014):
- add Lemon Squeezy license_key verification (via pala_payments.LemonService)
- new `verify_lemon_license` function: real API call with 5min in-memory cache
- PremiumLicenseCheck gets license_key + lemon_customer_id fields
- Stripe scaffold retained (legacy compat)
"""

from __future__ import annotations

import time
from collections.abc import Iterable
from dataclasses import dataclass
from typing import Any

from .auth import normalize_token, verify_token
from .customer import get_customer_id
from .registry import Skill

PAID_TIERS = {"premium", "enterprise"}
VISIBLE_TIERS_FOR_FREE = {"free"}
VISIBLE_TIERS_FOR_PREMIUM = {"free", "premium"}
ALLOWED_LIST_TIERS = {"free", "premium"}
ANONYMOUS_CUSTOMERS = {"anonymous", "unknown"}


def is_paid_tier(tier: str | None) -> bool:
    return tier in PAID_TIERS


def normalize_list_tier(requested_tier: str | None) -> str | None:
    if requested_tier is None:
        return None
    value = requested_tier.strip().lower()
    if not value or value == "all":
        return None
    if value not in ALLOWED_LIST_TIERS:
        return None
    return value


def filter_skills_for_tier(
    skills: Iterable[Skill],
    *,
    requested_tier: str | None,
    caller_tier: str | None,
) -> tuple[Skill, ...]:
    requested = normalize_list_tier(requested_tier)
    visible = (
        set(VISIBLE_TIERS_FOR_PREMIUM)
        if is_paid_tier(caller_tier)
        else set(VISIBLE_TIERS_FOR_FREE)
    )

    if requested is not None:
        if requested not in visible:
            return tuple()
        visible = {requested}

    return tuple(
        skill for skill in skills if (skill.access_tier or "free").lower() in visible
    )


@dataclass(frozen=True)
class PremiumLicenseCheck:
    allowed: bool
    reason: str
    token_customer_id: str | None = None
    stripe_customer_id: str | None = None
    # v0.17.0 (ADR-014): Lemon Squeezy fields
    license_key: str | None = None
    lemon_customer_id: str | None = None
    lemon_license_status: str | None = None


def check_license_scope(
    *,
    raw_token: str | None,
    requested_customer_id: str | None = None,
) -> PremiumLicenseCheck:
    """Scaffold: verify bearer token and compare customer identifiers.

    This check intentionally remains permissive when the Stripe-side customer
    store does not have a matching record yet. v0.16.0 will hard-enforce this.
    """
    token = normalize_token(raw_token)
    if not token:
        return PremiumLicenseCheck(allowed=False, reason="missing_token")

    context = verify_token(token)
    if context is None:
        return PremiumLicenseCheck(allowed=False, reason="invalid_token")
    if not is_paid_tier(context.tier):
        return PremiumLicenseCheck(allowed=False, reason="premium_required")

    token_customer_id = (
        context.customer_id if context.customer_id not in ANONYMOUS_CUSTOMERS else None
    )
    stripe_customer_id = get_customer_id(token)

    if (
        requested_customer_id
        and token_customer_id
        and requested_customer_id != token_customer_id
    ):
        return PremiumLicenseCheck(
            allowed=False,
            reason="token_customer_mismatch",
            token_customer_id=token_customer_id,
            stripe_customer_id=stripe_customer_id,
        )

    expected_customer_id = requested_customer_id or token_customer_id
    if (
        expected_customer_id
        and stripe_customer_id
        and expected_customer_id != stripe_customer_id
    ):
        return PremiumLicenseCheck(
            allowed=False,
            reason="stripe_customer_mismatch",
            token_customer_id=token_customer_id,
            stripe_customer_id=stripe_customer_id,
        )

    if expected_customer_id and not stripe_customer_id:
        # TODO(v0.16.0): turn this into hard failure once Stripe entitlement
        # sync is mandatory and customer_id records are guaranteed.
        return PremiumLicenseCheck(
            allowed=True,
            reason="todo_v0_16_customer_link_pending",
            token_customer_id=token_customer_id,
            stripe_customer_id=stripe_customer_id,
        )

    return PremiumLicenseCheck(
        allowed=True,
        reason="ok",
        token_customer_id=token_customer_id,
        stripe_customer_id=stripe_customer_id,
    )


# ---------------------------------------------------------------------------
# Lemon Squeezy license verification (ADR-014 + ADR-015, v0.17.0)
# ---------------------------------------------------------------------------

# In-memory cache for license verification responses.
# Key: license_key (string), Value: (timestamp, PremiumLicenseCheck).
# TTL 5 minutes — balances Lemon API rate limit (120/min) against staleness window.
_LEMON_LICENSE_CACHE: dict[str, tuple[float, PremiumLicenseCheck]] = {}
_LEMON_CACHE_TTL_S = 300


def verify_lemon_license(license_key: str) -> PremiumLicenseCheck:
    """Verify a Lemon Squeezy license key via the live Lemon API.

    Lazy-imports `pala_payments.LemonService` to avoid hard dep when the
    payments package is not installed (mock-mode CI). Caches successful
    responses for 5 minutes (in-memory).

    Returns PremiumLicenseCheck with:
      - allowed=True/False
      - reason: 'ok' | 'lemon_license_invalid' | 'lemon_license_status:<x>'
                | 'lemon_api_unavailable' | 'lemon_license_key_missing'
      - license_key (echo input)
      - lemon_customer_id (from Lemon response)
      - lemon_license_status (active | expired | disabled | inactive)
    """
    if not license_key or not license_key.strip():
        return PremiumLicenseCheck(allowed=False, reason="lemon_license_key_missing")

    key = license_key.strip()
    now = time.monotonic()

    # Cache hit (TTL valid)
    cached = _LEMON_LICENSE_CACHE.get(key)
    if cached is not None and (now - cached[0]) < _LEMON_CACHE_TTL_S:
        return cached[1]

    try:
        from pala_payments import LemonService  # lazy import (no hard dep)

        service = LemonService()
        result: dict[str, Any] = service.validate_license_key(key)
    except Exception as exc:  # broad — covers LemonConfigError, ImportError, network
        return PremiumLicenseCheck(
            allowed=False,
            reason=f"lemon_api_unavailable:{type(exc).__name__}",
            license_key=key,
        )

    if not result.get("valid"):
        check = PremiumLicenseCheck(
            allowed=False,
            reason="lemon_license_invalid",
            license_key=key,
        )
        # Cache invalid responses too (avoid hammering API on bad keys)
        _LEMON_LICENSE_CACHE[key] = (now, check)
        return check

    license_info: dict[str, Any] = result.get("license_key", {})
    status = str(license_info.get("status", "")).lower()
    if status != "active":
        check = PremiumLicenseCheck(
            allowed=False,
            reason=f"lemon_license_status:{status}",
            license_key=key,
            lemon_license_status=status,
        )
        _LEMON_LICENSE_CACHE[key] = (now, check)
        return check

    customer_id = license_info.get("customer_id")
    check = PremiumLicenseCheck(
        allowed=True,
        reason="ok",
        license_key=key,
        lemon_customer_id=str(customer_id) if customer_id is not None else None,
        lemon_license_status=status,
    )
    _LEMON_LICENSE_CACHE[key] = (now, check)
    return check


def clear_lemon_license_cache() -> None:
    """Clear the in-memory Lemon license cache (test helper)."""
    _LEMON_LICENSE_CACHE.clear()


# ---- ADR-017 Early access (davetiyeli — Lemon iptal sonrası) ----

import re

EARLY_ACCESS_PATTERN = re.compile(r"^pala-early-[A-HJ-NP-Z2-9]{8}$")


def verify_early_access(license_key: str) -> PremiumLicenseCheck:
    """Verify a Pala early-access license key (ADR-017 davetiyeli model).

    Format: ``pala-early-XXXXXXXX`` where ``X`` is one of
    ``[A-HJ-NP-Z2-9]`` (Crockford-style, no ambiguous chars).

    Validation is **structural only** in v0.18.0-prep — the actual key
    registry lives in ``site/src/pages/api/admin/invites.ts`` (in-memory
    on Vercel). Cross-process verification will arrive in v0.19.0 when
    Vercel KV / Upstash adapter lands.

    For now, any well-formed ``pala-early-`` key is treated as valid for
    early-access tier. Reis manually controls issuance via the admin
    panel, so the attack surface is the format check + low volume.

    Returns ``PremiumLicenseCheck`` with:
        - ``allowed=True`` when format matches
        - ``allowed=False`` with reason ``early_access_format_invalid``
          when malformed
        - ``allowed=False`` with reason ``early_access_key_missing``
          when blank
    """
    if not license_key or not license_key.strip():
        return PremiumLicenseCheck(allowed=False, reason="early_access_key_missing")

    key = license_key.strip()

    if not EARLY_ACCESS_PATTERN.fullmatch(key):
        return PremiumLicenseCheck(
            allowed=False,
            reason="early_access_format_invalid",
            license_key=key,
        )

    return PremiumLicenseCheck(
        allowed=True,
        reason="ok",
        license_key=key,
        lemon_license_status="early_access",
    )
