"""Pala skill registry loader.

Reads skills-registry.yaml and exposes typed Skill entries.
Source of truth for what is published — SKILL.md files on disk are content,
registry decides which are visible at which status.

Pala-original. Synthesized for Pala OS.
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

import yaml


@dataclass(frozen=True)
class Skill:
    """A single registry entry."""

    name: str
    domain: str
    status: str  # "stable" | "draft" | "planned"
    path: str
    optional: bool = False
    access_tier: str = "free"

    @property
    def is_published(self) -> bool:
        """Published = stable or draft. Planned skills are not served."""
        return self.status in ("stable", "draft") and not self.optional


@dataclass
class Registry:
    """Loaded registry snapshot."""

    version: int
    updated: str
    skills: tuple[Skill, ...]
    _mtime: float

    @classmethod
    def load(cls, registry_path: Path) -> Registry:
        """Load registry from disk. Raises FileNotFoundError or yaml.YAMLError."""
        if not registry_path.is_file():
            raise FileNotFoundError(f"Registry not found: {registry_path}")

        raw = registry_path.read_text(encoding="utf-8")
        data = yaml.safe_load(raw)

        skills_raw = data.get("skills", [])
        skills = tuple(
            Skill(
                name=s["name"],
                domain=s["domain"],
                status=s["status"],
                path=s["path"],
                optional=bool(s.get("optional", False)),
                access_tier=str(s.get("tier", "free")),
            )
            for s in skills_raw
        )

        return cls(
            version=int(data.get("version", 1)),
            updated=str(data.get("updated", "")),
            skills=skills,
            _mtime=registry_path.stat().st_mtime,
        )

    def is_stale(self, registry_path: Path) -> bool:
        """Check if the file on disk is newer than our snapshot."""
        try:
            return registry_path.stat().st_mtime > self._mtime
        except OSError:
            return False

    def published(self) -> tuple[Skill, ...]:
        """Return only published skills (stable + draft, not optional, not planned)."""
        return tuple(s for s in self.skills if s.is_published)

    def filter(
        self,
        domain: str | None = None,
        status: str | None = None,
        tier: str | None = None,
    ) -> tuple[Skill, ...]:
        """Filter published skills by domain and/or status."""
        result = self.published()
        if domain:
            result = tuple(s for s in result if s.domain == domain)
        if status:
            result = tuple(s for s in result if s.status == status)
        if tier:
            result = tuple(s for s in result if s.access_tier == tier)
        return result

    def get(self, name: str) -> Skill | None:
        """Look up a published skill by name."""
        for s in self.published():
            if s.name == name:
                return s
        return None


def default_registry_path() -> Path:
    """Resolve registry path from PALA_REGISTRY env or sensible default."""
    env_path = os.environ.get("PALA_REGISTRY")
    if env_path:
        return Path(env_path)
    # Walk up from cwd looking for skills-registry.yaml
    cwd = Path.cwd()
    for parent in (cwd, *cwd.parents):
        candidate = parent / "skills-registry.yaml"
        if candidate.is_file():
            return candidate
    raise FileNotFoundError("skills-registry.yaml not found in cwd or any parent")
