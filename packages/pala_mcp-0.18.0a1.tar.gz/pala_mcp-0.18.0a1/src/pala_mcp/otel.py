"""Silent OpenTelemetry setup for Pala MCP."""

from __future__ import annotations

import inspect
import os
import subprocess
import tomllib
from collections.abc import Callable
from dataclasses import dataclass
from functools import wraps
from pathlib import Path
from typing import Any, ParamSpec, TypeVar

try:  # pragma: no cover - import guard for minimal local installs
    from opentelemetry import trace
    from opentelemetry.exporter.otlp.proto.http.trace_exporter import OTLPSpanExporter
    from opentelemetry.sdk.resources import DEPLOYMENT_ENVIRONMENT, SERVICE_NAME, SERVICE_VERSION
    from opentelemetry.sdk.resources import Resource
    from opentelemetry.sdk.trace import TracerProvider
    from opentelemetry.sdk.trace.export import BatchSpanProcessor
except ImportError:  # pragma: no cover - dependency installed by package metadata
    trace = None
    OTLPSpanExporter = None
    Resource = None
    TracerProvider = None
    BatchSpanProcessor = None
    SERVICE_NAME = "service.name"
    SERVICE_VERSION = "service.version"
    DEPLOYMENT_ENVIRONMENT = "deployment.environment"

P = ParamSpec("P")
R = TypeVar("R")


@dataclass
class TracerState:
    enabled: bool = False
    endpoint: str | None = None
    service_name: str = "pala-mcp"
    service_version: str = "0.0.0"
    environment: str = "dev"


_STATE = TracerState()
_PROVIDER: Any | None = None
_INSTRUMENTED = False
_ORIGINAL_RUN: Any | None = None
_ORIGINAL_POPEN: Any | None = None


def _deployment_environment() -> str:
    value = (
        os.environ.get("OTEL_DEPLOYMENT_ENVIRONMENT")
        or os.environ.get("PALA_ENV")
        or os.environ.get("NODE_ENV")
        or "dev"
    )
    return value.strip() or "dev"


def _package_version() -> str:
    pyproject = Path(__file__).resolve().parents[2] / "pyproject.toml"
    try:
        data = tomllib.loads(pyproject.read_text(encoding="utf-8"))
    except (OSError, tomllib.TOMLDecodeError):
        return "0.0.0"
    project = data.get("project", {})
    version = project.get("version")
    return str(version) if version else "0.0.0"


def _trace_endpoint(endpoint: str) -> str:
    cleaned = endpoint.strip().rstrip("/")
    if cleaned.endswith("/v1/traces"):
        return cleaned
    return f"{cleaned}/v1/traces"


def _resource() -> Any:
    if Resource is None:  # pragma: no cover
        return None
    return Resource.create(
        {
            SERVICE_NAME: _STATE.service_name,
            SERVICE_VERSION: _STATE.service_version,
            DEPLOYMENT_ENVIRONMENT: _STATE.environment,
        }
    )


def _instrument_runtime() -> None:
    global _INSTRUMENTED
    if _INSTRUMENTED:
        return
    try:
        module = __import__(
            "opentelemetry.instrumentation.sqlite3",
            fromlist=["SQLite3Instrumentor"],
        )
        module.SQLite3Instrumentor().instrument()
    except Exception:
        pass
    _instrument_subprocess()
    _INSTRUMENTED = True


def _command_name(args: Any) -> str:
    if isinstance(args, (list, tuple)) and args:
        return str(args[0])[:120]
    if isinstance(args, str) and args.strip():
        return args.strip().split()[0][:120]
    return "unknown"


def _instrument_subprocess() -> None:
    global _ORIGINAL_POPEN, _ORIGINAL_RUN
    if _ORIGINAL_RUN is None:
        _ORIGINAL_RUN = subprocess.run

        @wraps(_ORIGINAL_RUN)
        def traced_run(*args: Any, **kwargs: Any) -> Any:
            if trace is None:
                return _ORIGINAL_RUN(*args, **kwargs)
            command = args[0] if args else kwargs.get("args")
            tracer = trace.get_tracer("pala_mcp.subprocess")
            with tracer.start_as_current_span("subprocess.run") as span:
                span.set_attribute("subprocess.command", _command_name(command))
                result = _ORIGINAL_RUN(*args, **kwargs)
                span.set_attribute(
                    "subprocess.returncode",
                    int(getattr(result, "returncode", -1)),
                )
                return result

        subprocess.run = traced_run

    if _ORIGINAL_POPEN is None:
        _ORIGINAL_POPEN = subprocess.Popen

        class TracedPopen(_ORIGINAL_POPEN):  # type: ignore[misc, valid-type]
            def __init__(self, *args: Any, **kwargs: Any) -> None:
                if trace is None:
                    super().__init__(*args, **kwargs)
                    return
                command = args[0] if args else kwargs.get("args")
                tracer = trace.get_tracer("pala_mcp.subprocess")
                with tracer.start_as_current_span("subprocess.Popen") as span:
                    span.set_attribute("subprocess.command", _command_name(command))
                    super().__init__(*args, **kwargs)
                    span.set_attribute("subprocess.pid", int(getattr(self, "pid", -1)))

        subprocess.Popen = TracedPopen


def init_tracer(endpoint: str | None = None) -> bool:
    """Start OTLP tracing when an endpoint exists."""
    global _PROVIDER
    configured = (endpoint or os.environ.get("OTEL_EXPORTER_OTLP_ENDPOINT") or "").strip()
    if not configured:
        _STATE.enabled = False
        _STATE.endpoint = None
        return False
    if trace is None or OTLPSpanExporter is None or TracerProvider is None:
        _STATE.enabled = False
        _STATE.endpoint = None
        return False

    _STATE.endpoint = _trace_endpoint(configured)
    _STATE.service_version = _package_version()
    _STATE.environment = _deployment_environment()
    try:
        provider = TracerProvider(resource=_resource())
        exporter = OTLPSpanExporter(endpoint=_STATE.endpoint)
        provider.add_span_processor(BatchSpanProcessor(exporter))
        trace.set_tracer_provider(provider)
        _instrument_runtime()
    except Exception:
        _STATE.enabled = False
        _STATE.endpoint = None
        return False

    _PROVIDER = provider
    _STATE.enabled = True
    return True


def tracer_state() -> TracerState:
    return TracerState(**_STATE.__dict__)


def trace_tool(tool_name: str) -> Callable[[Callable[P, R]], Callable[P, R]]:
    def decorate(func: Callable[P, R]) -> Callable[P, R]:
        if inspect.iscoroutinefunction(func):

            @wraps(func)
            async def async_wrapper(*args: P.args, **kwargs: P.kwargs) -> R:
                if trace is None:
                    return await func(*args, **kwargs)
                tracer = trace.get_tracer("pala_mcp.tools")
                with tracer.start_as_current_span(f"mcp.tool.{tool_name}") as span:
                    span.set_attribute("mcp.tool.name", tool_name)
                    return await func(*args, **kwargs)

            return async_wrapper

        @wraps(func)
        def wrapper(*args: P.args, **kwargs: P.kwargs) -> R:
            if trace is None:
                return func(*args, **kwargs)
            tracer = trace.get_tracer("pala_mcp.tools")
            with tracer.start_as_current_span(f"mcp.tool.{tool_name}") as span:
                span.set_attribute("mcp.tool.name", tool_name)
                return func(*args, **kwargs)

        return wrapper

    return decorate
