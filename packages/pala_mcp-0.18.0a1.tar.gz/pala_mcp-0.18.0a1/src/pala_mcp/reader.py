"""SKILL.md frontmatter + body reader.

Parses Pala SKILL.md format: YAML frontmatter between `---` delimiters,
then markdown body with 16 H2 sections.

Pala-original. Synthesized for Pala OS.
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path

import yaml


@dataclass(frozen=True)
class SkillContent:
    """Parsed SKILL.md content."""

    name: str
    description: str
    frontmatter: dict
    body: str
    body_line_count: int


class SkillReadError(Exception):
    """Raised when SKILL.md cannot be parsed."""


def _split_frontmatter(text: str) -> tuple[str, str]:
    """Split text into (frontmatter_yaml, body). Raises SkillReadError on malformed."""
    lines = text.splitlines(keepends=True)
    if not lines or lines[0].rstrip() != "---":
        raise SkillReadError("Missing opening '---' frontmatter delimiter")

    close_idx = None
    for i in range(1, len(lines)):
        if lines[i].rstrip() == "---":
            close_idx = i
            break

    if close_idx is None:
        raise SkillReadError("Missing closing '---' frontmatter delimiter")

    frontmatter = "".join(lines[1:close_idx])
    body = "".join(lines[close_idx + 1 :])
    return frontmatter, body


def parse_skill(skill_path: Path) -> SkillContent:
    """Parse a SKILL.md file. Raises SkillReadError on parse failure."""
    if not skill_path.is_file():
        raise SkillReadError(f"SKILL.md not found: {skill_path}")

    text = skill_path.read_text(encoding="utf-8")
    fm_text, body = _split_frontmatter(text)

    try:
        fm = yaml.safe_load(fm_text) or {}
    except yaml.YAMLError as exc:
        raise SkillReadError(f"Invalid YAML in frontmatter: {exc}") from exc

    if not isinstance(fm, dict):
        raise SkillReadError("Frontmatter must be a mapping")

    name = fm.get("name", "")
    description = fm.get("description", "")
    if isinstance(description, str):
        description = " ".join(description.split())

    body_lines = [ln for ln in body.splitlines() if ln.strip()]

    return SkillContent(
        name=str(name),
        description=str(description),
        frontmatter=fm,
        body=body,
        body_line_count=len(body_lines),
    )


def resolve_skill_path(skill_dir: Path, registry_path: str) -> Path:
    """Resolve a registry path to an absolute SKILL.md path.

    skill_dir = root directory containing skills/ tree
    registry_path = e.g. 'skills/universal/brainstorming'
    """
    # Reject absolute paths or traversal — skill content must live inside skills/
    if os.path.isabs(registry_path) or ".." in registry_path.split("/"):
        raise SkillReadError(f"Unsafe skill path rejected: {registry_path}")

    candidate = skill_dir / registry_path / "SKILL.md"
    return candidate.resolve()


@lru_cache(maxsize=64)
def cached_parse(skill_path_str: str, mtime: float) -> SkillContent:
    """Cached parse keyed on path + mtime. mtime invalidates the cache."""
    _ = mtime  # part of cache key
    return parse_skill(Path(skill_path_str))


def read_skill(skill_dir: Path, registry_path: str) -> SkillContent:
    """Read and parse a skill referenced by registry path."""
    path = resolve_skill_path(skill_dir, registry_path)
    if not path.is_file():
        raise SkillReadError(f"SKILL.md not found at resolved path: {path}")
    return cached_parse(str(path), path.stat().st_mtime)
