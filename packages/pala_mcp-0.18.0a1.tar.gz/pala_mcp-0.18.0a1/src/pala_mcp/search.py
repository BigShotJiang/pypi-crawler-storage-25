"""Skill search — keyword + trigger boost using rapidfuzz.

Index is built lazily on first query and invalidated when registry is reloaded.

Pala-original. Synthesized for Pala OS.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from rapidfuzz import fuzz

from .reader import SkillReadError, read_skill
from .registry import Registry


@dataclass(frozen=True)
class SearchHit:
    """A single search result."""

    name: str
    score: float
    description: str
    domain: str
    status: str
    matched_section: str


class SkillIndex:
    """Lazy in-memory search index over published skills."""

    def __init__(self, registry: Registry, skill_dir: Path):
        self._registry = registry
        self._skill_dir = skill_dir
        self._haystack: dict[str, dict[str, str]] = {}
        self._built = False

    def _build(self) -> None:
        """Build the haystack: per-skill blob of name + description + triggers."""
        for skill in self._registry.published():
            try:
                content = read_skill(self._skill_dir, skill.path)
            except SkillReadError:
                # Skip skills with broken content rather than failing the whole index
                continue
            triggers = content.frontmatter.get("metadata", {}).get("triggers", [])
            trigger_blob = " ".join(str(t) for t in triggers if t)
            self._haystack[skill.name] = {
                "name": skill.name,
                "description": content.description,
                "triggers": trigger_blob,
                "domain": skill.domain,
                "status": skill.status,
            }
        self._built = True

    def search(self, query: str, limit: int = 5) -> list[SearchHit]:
        """Run a keyword search. Returns up to `limit` hits sorted by score desc."""
        if not self._built:
            self._build()
        if not query.strip() or not self._haystack:
            return []

        query_norm = query.strip().lower()
        hits: list[SearchHit] = []

        # Score each skill across three fields, take the max field score
        for name, entry in self._haystack.items():
            name_score = fuzz.WRatio(query_norm, entry["name"].lower())
            desc_score = fuzz.partial_ratio(query_norm, entry["description"].lower())
            trig_score = fuzz.partial_ratio(query_norm, entry["triggers"].lower())

            # Trigger matches earn a small boost since triggers are curated routing phrases
            best = max(name_score, desc_score, trig_score * 1.05)
            matched = "name"
            if desc_score >= max(name_score, trig_score):
                matched = "description"
            elif trig_score > name_score:
                matched = "triggers"

            hits.append(
                SearchHit(
                    name=name,
                    score=round(best, 1),
                    description=entry["description"],
                    domain=entry["domain"],
                    status=entry["status"],
                    matched_section=matched,
                )
            )

        hits.sort(key=lambda h: h.score, reverse=True)
        return hits[: max(1, limit)]
