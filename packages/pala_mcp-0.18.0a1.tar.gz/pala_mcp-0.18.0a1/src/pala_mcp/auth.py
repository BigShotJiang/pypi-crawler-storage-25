"""Token authentication for Pala MCP cloud runtime."""

from __future__ import annotations

import hmac
import os
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Literal

from fastmcp.exceptions import ToolError
from fastmcp.server.dependencies import get_http_request
from fastmcp.server.middleware import Middleware, MiddlewareContext

from . import metrics
from .rate_limit import InMemoryTokenBucketLimiter, rate_limit_key

Tier = Literal["free", "premium", "enterprise"]

FREE_TOOLS = {"pala_list_skills", "pala_search_skills"}
ALL_TOOLS = FREE_TOOLS | {"pala_get_skill", "pala_health"}
DEFAULT_LIMITS = {
    "free": 60,
    "premium": 600,
    "enterprise": 1200,
}


@dataclass(frozen=True)
class AuthContext:
    tier: Tier
    rate_limit_override: int
    customer_id: str


class AuthError(Exception):
    def __init__(self, status_code: int, reason: str) -> None:
        super().__init__(reason)
        self.status_code = status_code
        self.reason = reason


def _strip_quotes(value: str) -> str:
    cleaned = value.strip()
    if len(cleaned) >= 2 and cleaned[0] == cleaned[-1] and cleaned[0] in {"'", '"'}:
        return cleaned[1:-1]
    return cleaned


def _read_env_file(path: Path) -> str | None:
    if not path.exists() or not path.is_file():
        return None
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith("PALA_API_KEYS="):
            return _strip_quotes(line.split("=", 1)[1])
    if path.name.endswith(".keys"):
        return _strip_quotes(path.read_text(encoding="utf-8"))
    return None


def _api_key_specs() -> list[str]:
    configured = os.environ.get("PALA_API_KEYS")
    if configured:
        return [part.strip() for part in configured.split(",") if part.strip()]

    candidates = [
        os.environ.get("PALA_API_KEYS_FILE"),
        os.environ.get("PALA_ENV_FILE"),
        ".env.production",
        ".env",
    ]
    for candidate in candidates:
        if not candidate:
            continue
        loaded = _read_env_file(Path(candidate))
        if loaded:
            return [part.strip() for part in loaded.split(",") if part.strip()]
    return []


def _parse_spec(spec: str) -> tuple[str, AuthContext] | None:
    parts = [part.strip() for part in spec.split(":")]
    token = parts[0] if parts else ""
    if not token:
        return None

    tier = parts[1] if len(parts) > 1 and parts[1] else "premium"
    if tier not in DEFAULT_LIMITS:
        return None
    customer_id = parts[2] if len(parts) > 2 and parts[2] else "unknown"
    if len(parts) > 3 and parts[3]:
        try:
            limit = int(parts[3])
        except ValueError:
            return None
    else:
        limit = DEFAULT_LIMITS[tier]

    return token, AuthContext(
        tier=tier, rate_limit_override=limit, customer_id=customer_id
    )


def normalize_token(raw: str | None) -> str | None:
    if not raw:
        return None
    value = raw.strip()
    if value.lower().startswith("bearer "):
        value = value[7:].strip()
    return value or None


def verify_token(token: str) -> AuthContext | None:
    normalized = normalize_token(token)
    if not normalized:
        return None
    for spec in _api_key_specs():
        parsed = _parse_spec(spec)
        if parsed is None:
            continue
        configured_token, context = parsed
        if hmac.compare_digest(configured_token, normalized):
            return context
    return None


def authorize_tool_call(tool_name: str, token: str | None) -> AuthContext:
    normalized = normalize_token(token)
    if normalized:
        context = verify_token(normalized)
        if context is None:
            raise AuthError(401, "invalid_token")
        if tool_name not in ALL_TOOLS:
            raise AuthError(403, "unknown_tool")
        return context

    if tool_name in FREE_TOOLS:
        return AuthContext(
            tier="free",
            rate_limit_override=DEFAULT_LIMITS["free"],
            customer_id="anonymous",
        )
    raise AuthError(403, "premium_required")


def _meta_token(message: Any) -> str | None:
    meta = getattr(message, "meta", None)
    if meta is None:
        return None
    for name in ("authorization", "token", "api_key"):
        value = getattr(meta, name, None)
        if isinstance(value, str) and value:
            return value
    return None


def _header_token(headers: Any) -> str | None:
    for name in ("authorization", "x-pala-api-key", "x-api-key"):
        value = headers.get(name)
        if value:
            return value
    return None


def _client_ip(headers: Any, fallback: str | None) -> str:
    forwarded = headers.get("x-forwarded-for")
    if forwarded:
        return forwarded.split(",", 1)[0].strip()
    real_ip = headers.get("x-real-ip")
    if real_ip:
        return real_ip.strip()
    return fallback or "unknown"


class PalaAuthMiddleware(Middleware):
    def __init__(
        self,
        *,
        rate_limiter: InMemoryTokenBucketLimiter | None = None,
        enforce_without_http: bool = False,
    ) -> None:
        self.rate_limiter = rate_limiter or InMemoryTokenBucketLimiter()
        self.enforce_without_http = enforce_without_http

    def _request_auth(self, context: MiddlewareContext[Any]) -> tuple[str | None, str]:
        token = _meta_token(context.message)
        try:
            request = get_http_request()
        except RuntimeError:
            if self.enforce_without_http:
                local_token = token or os.environ.get("PALA_LOCAL_AUTH_TOKEN")
                return local_token, rate_limit_key(
                    ip_address="local", token=normalize_token(local_token)
                )
            return None, "local:trusted"

        token = token or _header_token(request.headers)
        normalized = normalize_token(token)
        client_host = request.client.host if request.client else None
        ip_address = _client_ip(request.headers, client_host)
        return normalized, rate_limit_key(ip_address=ip_address, token=normalized)

    async def on_call_tool(
        self, context: MiddlewareContext[Any], call_next: Any
    ) -> Any:
        if not self.enforce_without_http:
            try:
                get_http_request()
            except RuntimeError:
                return await call_next(context)

        tool_name = getattr(context.message, "name", "unknown")
        started = time.perf_counter()
        token, limiter_key = self._request_auth(context)

        try:
            auth_context = authorize_tool_call(tool_name, token)
        except AuthError as exc:
            metrics.record_auth_failure(exc.reason)
            metrics.record_tool_call(
                tool=tool_name,
                tier="free",
                status=str(exc.status_code),
                duration_seconds=time.perf_counter() - started,
            )
            raise ToolError(f"{exc.status_code} {exc.reason}") from exc

        limit = self.rate_limiter.check(limiter_key, auth_context.rate_limit_override)
        if not limit.allowed:
            metrics.record_tool_call(
                tool=tool_name,
                tier=auth_context.tier,
                status="429",
                duration_seconds=time.perf_counter() - started,
            )
            raise ToolError(
                f"429 too_many_requests; Retry-After={limit.retry_after}"
            ) from None

        metrics.inc_active_connections()
        status = "200"
        try:
            return await call_next(context)
        except Exception:
            status = "500"
            raise
        finally:
            metrics.dec_active_connections()
            metrics.record_tool_call(
                tool=tool_name,
                tier=auth_context.tier,
                status=status,
                duration_seconds=time.perf_counter() - started,
            )
