"""Pala MCP server entrypoint.

Transports:
  - stdio (default): for Claude Code, Codex, Cursor spawning the server as subprocess
  - http: for remote clients or local HTTP testing

Usage:
  pala-mcp                          # stdio
  pala-mcp --stdio
  pala-mcp --http --port 8765       # HTTP on localhost:8765
  pala-mcp --http --host 0.0.0.0    # HTTP on all interfaces

Pala-original. Synthesized for Pala OS.
"""

from __future__ import annotations

import argparse
import logging
import os
import sys

from .metrics import start_metrics_http_server
from .registry import default_registry_path
from .server import PalaState, build_server, default_skill_dir
from .telemetry import emit


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        prog="pala-mcp",
        description="Pala OS MCP server — local-first skill registry server",
    )
    transport = parser.add_mutually_exclusive_group()
    transport.add_argument(
        "--stdio",
        action="store_true",
        help="Use stdio transport (default). For agent subprocess spawning.",
    )
    transport.add_argument(
        "--http",
        action="store_true",
        help="Use HTTP/SSE transport. For remote or browser clients.",
    )
    parser.add_argument(
        "--host",
        default="127.0.0.1",
        help="HTTP bind host (default: 127.0.0.1, loopback only).",
    )
    parser.add_argument(
        "--port",
        type=int,
        default=8765,
        help="HTTP bind port (default: 8765).",
    )
    parser.add_argument(
        "--registry",
        type=str,
        default=None,
        help="Path to skills-registry.yaml. Defaults to PALA_REGISTRY env or auto-discovery.",
    )
    parser.add_argument(
        "--skills-dir",
        type=str,
        default=None,
        help="Path to skills/ root. Defaults to PALA_SKILLS_DIR env or registry sibling.",
    )
    parser.add_argument(
        "--log-level",
        default="INFO",
        choices=["DEBUG", "INFO", "WARNING", "ERROR"],
        help="Log level (default: INFO).",
    )
    parser.add_argument(
        "--metrics-port",
        type=int,
        default=int(os.environ.get("PALA_METRICS_PORT", "9090")),
        help="Prometheus metrics port in HTTP mode; set 0 to disable.",
    )
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    args = parse_args(argv)

    logging.basicConfig(
        level=getattr(logging, args.log_level),
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
        stream=sys.stderr,
    )
    log = logging.getLogger("pala_mcp")

    # Resolve paths
    from pathlib import Path

    registry_path = Path(args.registry) if args.registry else default_registry_path()
    skill_dir = Path(args.skills_dir) if args.skills_dir else default_skill_dir()

    log.info("Pala MCP starting | registry=%s | skills=%s", registry_path, skill_dir)

    state = PalaState(skill_dir=skill_dir, registry_path=registry_path)
    # Warm-load registry so startup failures surface immediately
    state.registry()

    server = build_server(state)
    emit("mcp.server.start")

    try:
        if args.http:
            log.info("HTTP transport on %s:%d", args.host, args.port)
            if args.metrics_port:
                log.info("Prometheus metrics on %s:%d", args.host, args.metrics_port)
                start_metrics_http_server(args.metrics_port, args.host)
            server.run(transport="sse", host=args.host, port=args.port)
        else:
            log.info("stdio transport")
            server.run()  # FastMCP default is stdio
    finally:
        emit("mcp.server.stop")

    return 0


if __name__ == "__main__":
    sys.exit(main())
