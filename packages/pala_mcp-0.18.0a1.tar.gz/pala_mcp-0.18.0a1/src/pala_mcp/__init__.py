"""Pala OS MCP server — serves the Pala skill registry to the agent ecosystem.

Pala-original. Synthesized for Pala OS.

v0.17.0 (ADR-014): Lemon Squeezy premium tier license check support.
"""

__version__ = "0.17.0"
