"""Prometheus metrics for Pala MCP cloud runtime."""

from __future__ import annotations

from prometheus_client import (
    CONTENT_TYPE_LATEST as PROMETHEUS_CONTENT_TYPE,
)
from prometheus_client import (
    CollectorRegistry,
    Counter,
    Gauge,
    Histogram,
    generate_latest,
    start_http_server,
)

CONTENT_TYPE_LATEST = PROMETHEUS_CONTENT_TYPE
REGISTRY = CollectorRegistry(auto_describe=True)

TOOL_CALLS = Counter(
    "pala_mcp_tool_calls_total",
    "Pala MCP tool calls.",
    ("tool", "tier", "status"),
    registry=REGISTRY,
)

AUTH_FAILURES = Counter(
    "pala_mcp_auth_failures_total",
    "Pala MCP authentication failures.",
    ("reason",),
    registry=REGISTRY,
)

TOOL_DURATION = Histogram(
    "pala_mcp_tool_duration_seconds",
    "Pala MCP tool duration in seconds.",
    ("tool", "tier"),
    buckets=(0.01, 0.05, 0.1, 0.5, 1, 5),
    registry=REGISTRY,
)

REGISTRY_SKILLS = Gauge(
    "pala_mcp_registry_skills_total",
    "Pala MCP registry skill count.",
    registry=REGISTRY,
)

ACTIVE_CONNECTIONS = Gauge(
    "pala_mcp_active_connections",
    "Pala MCP active tool executions.",
    registry=REGISTRY,
)


def record_tool_call(
    *, tool: str, tier: str, status: str, duration_seconds: float
) -> None:
    TOOL_CALLS.labels(tool=tool, tier=tier, status=status).inc()
    TOOL_DURATION.labels(tool=tool, tier=tier).observe(duration_seconds)


def record_auth_failure(reason: str) -> None:
    AUTH_FAILURES.labels(reason=reason).inc()


def set_registry_skills_total(count: int) -> None:
    REGISTRY_SKILLS.set(count)


def inc_active_connections() -> None:
    ACTIVE_CONNECTIONS.inc()


def dec_active_connections() -> None:
    ACTIVE_CONNECTIONS.dec()


def render_metrics() -> bytes:
    return generate_latest(REGISTRY)


def start_metrics_http_server(port: int, host: str) -> object | None:
    if port <= 0:
        return None
    return start_http_server(port, addr=host, registry=REGISTRY)
