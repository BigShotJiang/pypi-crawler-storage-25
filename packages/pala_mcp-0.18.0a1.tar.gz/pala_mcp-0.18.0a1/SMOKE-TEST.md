# Pala MCP Server — Smoke Test Guide

Goal: prove the three MCP tools work end-to-end from Claude Code, Codex, and Cursor.

## Prerequisites

```bash
cd mcp-server
pip install -e ".[dev]"
python -m pytest -q              # 40/40 PASS expected
python -m pytest --cov-fail-under=80 -q   # coverage gate ≥80%
```

## Step 1 — Verify CLI works

```bash
pala-mcp --help

python -c "
from pathlib import Path
from pala_mcp.registry import Registry
reg = Registry.load(Path('../skills-registry.yaml'))
stables = [s.name for s in reg.filter(domain='universal', status='stable')]
print(f'{len(stables)} universal stable skills')
print(stables[:5])
"
```

Expected: 20 universal stable skills.

## Step 2 — Claude Code config

`~/.claude/settings.json` veya proje `.claude/settings.json`:

```json
{
  "mcpServers": {
    "pala": {
      "command": "pala-mcp",
      "args": ["--stdio"],
      "env": {
        "PALA_REGISTRY": "C:\\path\\to\\pala-os\\skills-registry.yaml",
        "PALA_SKILLS_DIR": "C:\\path\\to\\pala-os"
      }
    }
  }
}
```

Restart Claude Code. Test queries:

1. *"List all Pala skills in the `ai-ml` domain."* → `pala_list_skills(domain="ai-ml")`
2. *"Get full content of `redis-cache-patterns`."* → `pala_get_skill`
3. *"Search Pala skills for kubernetes deployment safety."* → `pala_search_skills`

## Step 3 — Cursor config

`~/.cursor/mcp.json` — aynı yapı. Agents sekmesinde üç sorguyu tekrarla.

## Step 4 — Codex CLI

```bash
codex mcp list
codex exec --mcp-server pala "List Pala universal stable skills"
```

Codex MCP desteği sürüme göre değişir; destek yoksa TBD olarak dokümante et.

## Step 5 — Docker (optional)

```bash
cd mcp-server
docker compose config          # validate compose file
docker compose up -d
docker compose ps              # health: registry load check
docker compose logs pala-mcp
docker compose down
```

**Not:** Sunucu `/health` HTTP endpoint sunmaz. `docker-compose.yml` healthcheck registry YAML yüklemesi ile doğrular.

## Success criteria

| Host | list | get | search |
|---|---|---|---|
| Claude Code | ✓ | ✓ | ✓ |
| Cursor | ✓ | ✓ | ✓ |
| Codex | TBD | TBD | TBD |

Unit test + coverage gate geçtikten sonra cross-host smoke tamamlanır. Repo tag: **v0.3.0-alpha** (Sprint 11).

---

Pala-original. Synthesized for Pala OS.
