# Pala MCP Server — Release Notes

## v0.18.0-prep — Davetiyeli Erken Erişim (2026-05-21)

> ADR-017 davetiyeli pivot ile uyumlu MCP server güncellemesi.

### Added

- **`verify_early_access(license_key)`** (`pala_mcp/premium.py`):
  - Crockford alphabet regex validation: `pala-early-[A-HJ-NP-Z2-9]{8}`
  - Whitespace strip + structural format check
  - Returns `PremiumLicenseCheck(allowed, reason, license_key, lemon_license_status='early_access')`
  - 4 yeni pytest PASS (valid format / missing / 6 invalid format variants / whitespace)

### Changed

- **Version bump:** 0.17.0 → 0.18.0-prep
- **License key flow** — Lemon Squeezy bypass yapan early-access katmanı eklendi (Lemon SDK kullanılmaya devam ediyor v0.19.0 monetize fazı için)

### Notes

- v0.17.0 `verify_lemon_license()` aynen korundu (legacy + future monetize için hazır)
- `pala_payments` lazy Stripe import — `stripe>=8.0` core dep KALDIRILDI, opsiyonel `[legacy-stripe]` extra'ya taşındı
- 5 tool kontrat değişmedi: `pala_list_skills`, `pala_get_skill`, `pala_search_skills`, `pala_recommend`, `pala_health`

### Install

```bash
# Local editable (PyPI publish v0.19.0'da)
pip install -e mcp-server

# MCP host bind
pala-mcp --stdio                 # Claude Code, Codex, Cursor (stdio default)
pala-mcp --transport sse         # web hosts (HTTP/SSE)
```

### Test

```bash
cd mcp-server
python -m pytest tests/test_premium.py -k "early_access" --no-cov
# 4 PASS
```

### Sıradaki (v0.19.0 hedefleri)

- PyPI publish (`pala-mcp==0.19.0`)
- Real KV-backed license registry (Vercel KV / Upstash adapter)
- Lemon Squeezy reactivation (monetize fazı, davetiyeli sonrası)
- `pala_recommend()` NLP improvement (fuzzy match + skill ranking)
- 9-host cross-smoke test suite

---

## v0.17.0 (önceki)

Bkz: `CHANGELOG.md` repo root, `[v0.17.0]` section.

- Lemon Squeezy `verify_lemon_license()` real API + 5min cache
- Stripe SDK DeprecationWarning marker
- Version drift fix 0.0.0 → 0.17.0
- 124 pytest PASS, 88.78% coverage
