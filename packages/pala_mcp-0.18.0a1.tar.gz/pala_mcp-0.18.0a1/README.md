# Pala OS MCP Server

Local-first MCP (Model Context Protocol) server that exposes the Pala skill registry to the agent ecosystem (Claude Code, Codex, Cursor, OpenCode, Windsurf, Cline, Gemini CLI, Aider).

**Durum:** Prototip paket mevcut (`mcp-server/`). Sprint 11 sonrası **40/40** unit test PASS; coverage gate **≥80%** (`--cov-fail-under=80`). Cross-host smoke ve production deploy devam ediyor.

## MCP tools (kontrat sabit)

| Tool | Açıklama |
|---|---|
| `pala_list_skills(domain?, status?)` | Yayınlanan skill'leri listele (`stable` / `draft`; `planned` sunulmaz) |
| `pala_get_skill(name)` | Tam `SKILL.md` (frontmatter + body) |
| `pala_search_skills(query, limit?)` | İsim, açıklama ve trigger üzerinde arama |
| `pala_health(verbose?)` | JSON health status; `verbose=true` check detaylarını döker |

## Quick start

### Option A: Docker

```bash
cd mcp-server
docker compose up -d            # HTTP/SSE on localhost:8765
docker compose run pala-mcp     # stdio (interactive)
```

Healthcheck: `pala_health` MCP tool registry, skills dir ve tool kontratını kontrol eder.

### Option B: Local Python

```bash
cd mcp-server
pip install -e ".[dev]"
pala-mcp                        # stdio (default)
pala-mcp --http --port 8765     # HTTP/SSE
```

Smoke checks:

```bash
python scripts/mcp_smoke.py
python scripts/mcp_smoke.py --http --host 127.0.0.1 --port 8765
```

## Connect from Claude Code

```json
{
  "mcpServers": {
    "pala": {
      "command": "pala-mcp",
      "args": ["--stdio"],
      "env": {
        "PALA_REGISTRY": "/path/to/pala-os/skills-registry.yaml",
        "PALA_SKILLS_DIR": "/path/to/pala-os"
      }
    }
  }
}
```

## Connect from Cursor

`~/.cursor/mcp.json` veya workspace `.cursor/mcp.json` — aynı `command` / `args` / `env` yapısı.

## Environment variables

| Variable | Açıklama |
|---|---|
| `PALA_REGISTRY` | `skills-registry.yaml` yolu (auto-discovery varsa atlanır) |
| `PALA_SKILLS_DIR` | `skills/` kökü (varsayılan: registry parent) |
| `PALA_TELEMETRY` | `on` \| `off` (default: off). Opt-in telemetry stub, yalnız event type, timestamp, tool name ve duration_ms yazar; kullanıcı içeriği loglanmaz. Log: `~/.pala/telemetry.log` |
| `PALA_LOG_LEVEL` | `DEBUG` \| `INFO` \| `WARNING` \| `ERROR` |

## Development

```bash
pip install -e ".[dev]"
python -m ruff check src tests
python -m black --check src tests
python -m pytest                              # coverage gate ≥80% dahil
python -m pytest --cov=pala_mcp --cov-fail-under=80
```

## Architecture

- `registry.py` — `skills-registry.yaml` loader
- `reader.py` — `SKILL.md` parse + LRU cache
- `search.py` — rapidfuzz arama + trigger boost
- `health.py` — registry, skills dir ve MCP tool health aggregation
- `telemetry.py` — opt-in local JSONL telemetry stub
- `server.py` — FastMCP + dört tool
- `__main__.py` — CLI (`--stdio`, `--http`, path ve log flags)

## Provenance

Pala-original. Synthesized for Pala OS. License: MIT.
