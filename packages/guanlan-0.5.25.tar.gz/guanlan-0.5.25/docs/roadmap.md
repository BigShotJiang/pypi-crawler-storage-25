# 观澜路线图

观澜的目标不是做一个“平台越多越好”的抓取集合，而是做一个 CLI-first、Agent-first 的中文互联网研究底座：搜索更准，阅读更干净，信源更透明，授权边界更稳。

## 当前定位

观澜当前最适合这些场景：

- 给 AI Agent 提供公开网页搜索、中文信源路由和热榜观察能力。
- 把搜索结果转成可直接放进 prompt 的 Markdown / context。
- 用 `research` 组合搜索、阅读、信源分布和谨慎 advisor 视角。
- 用 `archive` 把读过的网页沉淀为本地知识库或 RAG 输入。

默认原则：只读、低扰、明源。不默认读取 Cookie，不默认触发登录授权，不默认请求钥匙串权限。

## 版本路线

### v0.5.0 研究工作流引擎

> v0.5.0 已发布研究工作流引擎：`workflow/investigate`、`sources`、`eval suite`、Archive 语义 sidecar、页面诊断、研究 recipe 和 release gate 性能护栏已经进入主线。


目标：在不加重基础搜索的前提下，新增显式的上层研究工作流。核心原则是“轻任务不打扰，重任务不偷懒”。

已落地方向：

- 新增基础功能防回退闸门，确保 `search/read/hotnews/research/archive` 的候选池和核心字段不缩水。
- 新增 Agent 升档决策器，区分 `direct / guided / investigate`，避免简单搜索过度规划。
- 新增 `guanlan investigate`，只在用户明确需要深度研究、多实体比较、高风险准确性或复杂证据包时使用。
- 新增 `guanlan sources` 只读信源查询，让 Agent 能解释某类问题为什么优先哪些信源。
- 新增 `guanlan eval suite`，把中文互联网真实任务基准沉淀成可复现评测。
- 新增 `guanlan diagnose page` 和 `guanlan recipe`，降低弱正文误判和垂直任务临场拼流程的风险。

验收标准：

- `guanlan search "query"`、`guanlan read "URL"` 默认行为不变重。
- `investigate` 只复用现有 route/search/read/research/hotnews/feeds/workflow 模块，不另写搜索主链路。
- 简单事实、入口、链接、轻量搜索不被强制升级为深度研究。
- 复杂研究任务能输出执行步骤、证据包、质量边界、来源分布和下一步。
- release gate 增加基础功能防回退检查。

详细施工边界见 [Guanlan 0.5.0 施工方案](guanlan-0.5.0-construction-plan.md)。

### v0.1.8 搜索质量层

目标：让 Agent 不只是“搜到东西”，而是知道搜索结果为什么可信、为什么靠前、哪里还不够。

已纳入方向：

- 查询质量画像：识别政策、电商、财经、技术、口碑、地方等查询意图。
- 意图感知排序：不同意图对应不同信源偏好，例如政策优先政府/党央媒，电商优先垂类/产业媒体。
- 更清楚的 trace：`guanlan search --trace` 输出 query_quality、质量命中数和警告。
- 时效性增强：支持“今年”“近24小时”“近48小时”等时间意图。
- 搜索质量 fixtures：用固定样例回归测试排序是否符合预期。

验收标准：

- 政策类查询不会轻易被社交讨论挤掉官方来源。
- 电商/零售查询能优先识别垂类媒体价值。
- `--trace` 能解释意图、信源偏好、命中和风险。
- 改动可通过 fixtures 回归，而不是只靠人工感觉。

### v0.1.9 阅读质量层

目标：让 `guanlan read` 更像“正文阅读器”，而不是“网页剥标签器”。

计划方向：

- 增强中文新闻、政府网站、公众号转载页和地方媒体的正文抽取。
- 更细分地过滤导航、页脚、登录按钮、相关推荐、版权备案和广告片段。
- Jina Reader 不稳时，自动比较 Jina / direct / search fallback 的质量。
- 增加阅读质量 fixtures，用固定 HTML 样例测试正文占比和噪音占比。

验收标准：

- 随机中文新闻页正文占比明显高于导航和页脚。
- 公众号转载页能尽量保留正文，不能时明确降级为搜索线索。
- `read --trace` 或等价诊断能说明用了哪个 backend、为什么降级。

### v0.2.0 Agent-first 稳定版

目标：把观澜作为 Agent 搜索生产力工具的第一条稳定线。

计划方向：

- 固化 `search / read / hotnews / research / pulse / archive` 的 Agent 用法。
- MCP schema 收口，保证 Claude、Cursor、Codex、Devin 等集成稳定。
- README、Agent 文档、skill 文档和安装文档完全同步。
- 提供“复制给 Agent 就能执行”的场景模板。

验收标准：

- 新用户能通过 README 的 Agent 安装指令完成部署和 smoke test。
- Agent 能用一组稳定命令完成搜索、阅读、热榜、研究证据包和本地归档。
- 高风险平台能力保持 best-effort / opt-in 口径，不暗示稳定可用。

## 长期方向

### 中文信源地图

继续扩充并维护分层信源：

- 党央媒与中央重点媒体。
- 政府/部委网站。
- 核心地方官媒。
- 电商、零售、跨境、财经、科技等垂类媒体。
- 社交和内容平台公开页。

重点不是无限加域名，而是给 Agent 明确“这个来源适合支持什么，不适合支持什么”。

### 本地知识库 / RAG 桥接

方向：让 Agent 搜过、读过的内容能变成自己的中文资料库。

- `archive add/search/export` 继续增强。
- 支持 JSONL / Markdown / chunked context 输出。
- 后续可考虑向常见向量库或本地 RAG 系统导出。

### 趋势与回响分析

方向：在 `pulse` 上继续做安全版趋势观察。

- 关键词共现。
- 来源分布。
- 正负信号和争议点。
- 明确样本偏差和证据边界。

不做武断情绪结论，不把少量公开样本当总体民意。

### 热榜稳定性

方向：`today` 做默认多源快照，NewsNow 做可选增强。

- 原生公开源优先。
- 单源失败不拖垮整体。
- 高风险平台不读 Cookie、不碰登录态。
- NewsNow 继续作为可配置 backend，而不是强依赖。

## 暂不做

- 不把 NewsNow 整仓库 vendoring 进来。
- 不自动读取浏览器 Cookie。
- 不默认请求钥匙串或系统级凭据。
- 不承诺知乎、小红书、微博等登录/风控平台的端到端稳定能力。
- 不把社交平台样本包装成总体结论。
