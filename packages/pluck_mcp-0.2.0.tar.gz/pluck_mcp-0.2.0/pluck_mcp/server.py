"""Pluck MCP Server — exposes Pluck tools via the Model Context Protocol."""

from __future__ import annotations

from mcp.server.fastmcp import FastMCP

from pluck_mcp.client import IntegrationApiClient


mcp = FastMCP("Pluck MCP")
client = IntegrationApiClient()


@mcp.tool()
def ask_pluck(message: str) -> str:
    """Ask Pluck a question and get a researched answer with full knowledge graph context.

    Pluck will plan a research strategy, search the knowledge graph, and craft
    a detailed answer with citations. Use this for open-ended questions about
    your ingested documents and data.

    Args:
        message: The question or request to research.

    Returns:
        A detailed answer with citations from the knowledge graph.
    """
    return client.ask_pluck(message)


@mcp.tool()
def list_document_types() -> str:
    """List all document types discovered in the knowledge graph.

    Returns the names and counts of each document type (e.g. "Invoice",
    "Contract", "Meeting Notes") that Pluck has identified across your
    ingested documents.

    Returns:
        JSON string with document types and their counts.
    """
    return client.call_tool("list_document_types", {})


@mcp.tool()
def get_schema_fields(doc_type: str) -> str:
    """Get the schema fields for a specific document type.

    Returns the field names, types, and descriptions that Pluck has discovered
    for the given document type. Useful for understanding what structured data
    is available before querying.

    Args:
        doc_type: The document type name (e.g. "Invoice", "Contract").

    Returns:
        JSON string with field definitions for the document type.
    """
    return client.call_tool("get_schema_fields", {"doc_type": doc_type})


@mcp.tool()
def vector_search(
    query: str,
    mode: str = "chunks",
    doc_type_filter: str | None = None,
    scope_doc_id: str | None = None,
) -> str:
    """Search the knowledge graph using semantic similarity.

    Finds document chunks or full documents that are semantically similar
    to your query. Supports filtering by document type and scoping to a
    specific document.

    Args:
        query: The search query text.
        mode: Search mode — "chunks" for passage-level results or "documents" for document-level.
        doc_type_filter: Optional document type to filter results (e.g. "Invoice").
        scope_doc_id: Optional document ID to search within a single document.

    Returns:
        JSON string with ranked search results and relevance scores.
    """
    args: dict[str, object] = {"query": query, "mode": mode}
    if doc_type_filter:
        args["doc_type_filter"] = doc_type_filter
    if scope_doc_id:
        args["scope_doc_id"] = scope_doc_id
    return client.call_tool("vector_search", args)


@mcp.tool()
def query_documents(
    doc_type: str | None = None,
    order_by: str | None = None,
    order_direction: str | None = None,
    limit: int = 25,
) -> str:
    """Query documents in the knowledge graph with optional filtering and sorting.

    Returns a list of documents matching the criteria. Use this to browse
    documents by type, find recent additions, or list documents sorted by
    a schema field.

    Args:
        doc_type: Optional document type filter (e.g. "Invoice").
        order_by: Optional field name to sort by.
        order_direction: Sort direction — "asc" or "desc".
        limit: Maximum number of documents to return (1-100, default 25).

    Returns:
        JSON string with matching documents and their metadata.
    """
    args: dict[str, object] = {"limit": limit}
    if doc_type:
        args["doc_type"] = doc_type
    if order_by:
        args["order_by"] = order_by
    if order_direction:
        args["order_direction"] = order_direction
    return client.call_tool("query_documents", args)


@mcp.tool()
def get_entity_neighbors(entity_name: str, hops: int = 2) -> str:
    """Explore the knowledge graph around a specific entity.

    Returns entities and relationships within N hops of the given entity.
    Useful for understanding how concepts, people, organizations, and
    documents are connected.

    Args:
        entity_name: The name of the entity to explore (e.g. "Acme Corp").
        hops: Number of relationship hops to traverse (1-3, default 2).

    Returns:
        JSON string with neighboring entities and their relationships.
    """
    return client.get_resource(
        f"/api/v1/entities/{entity_name}/neighbors",
        params={"hops": hops},
    )


@mcp.tool()
def get_full_text(doc_id: str | None = None, chunk_id: str | None = None) -> str:
    """Retrieve the full text of a document or a specific chunk.

    Use doc_id to get an entire document with all its chunks, or chunk_id
    to get a single passage. At least one of doc_id or chunk_id must be
    provided.

    Args:
        doc_id: The document ID to retrieve.
        chunk_id: The chunk ID to retrieve.

    Returns:
        The full text content of the document or chunk with metadata.
    """
    if chunk_id:
        return client.get_resource(f"/api/v1/chunks/{chunk_id}")
    if doc_id:
        return client.get_resource(f"/api/v1/documents/{doc_id}")
    return "Error: Provide either doc_id or chunk_id."


# --- Ingestion tools ---


@mcp.tool()
def upload_file(file_path: str) -> str:
    """Upload a local file to Pluck for knowledge graph ingestion.

    The file is stored in Pluck's cloud storage and a blob URI is returned.
    Pass the URI to `build_knowledge_graph` to process it.

    Supported formats: PDF, DOCX, PPTX, XLSX, CSV, TXT, Pages, images
    (PNG/JPG), WhatsApp exports (ZIP).

    Args:
        file_path: Absolute path to the file on disk.

    Returns:
        JSON with the blob URI (path), filename, size, and checksum.
    """
    return client.upload_file(file_path)


@mcp.tool()
def build_knowledge_graph(
    files: list[str] | None = None,
    cloud_files: list[dict] | None = None,
    emails: list[dict] | None = None,
    slack_channels: list[dict] | None = None,
    confluence_pages: list[dict] | None = None,
    jira_issues: list[dict] | None = None,
    salesforce_records: list[dict] | None = None,
    incremental: bool = False,
) -> str:
    """Start building a knowledge graph from uploaded files and/or connected sources.

    Workflow:
    1. Upload files with `upload_file` first to get blob URIs
    2. Call this tool with the blob URIs in `files`
    3. Poll `get_ingestion_status` with the returned run_id

    Set `incremental=True` to add documents to an existing graph.
    Set `incremental=False` (default) to build a new graph from scratch.

    Args:
        files: List of blob URIs from `upload_file`.
        cloud_files: List of cloud file objects from `browse_cloud_files`.
        emails: List of email selections (for connected Gmail/Outlook).
        slack_channels: List of Slack channel selections.
        confluence_pages: List of Confluence page selections.
        jira_issues: List of Jira issue selections.
        salesforce_records: List of Salesforce record selections.
        incremental: True to add to existing graph, False to build new.

    Returns:
        JSON with run_id and status. Poll get_ingestion_status with the run_id.
    """
    config: dict = {"incremental": incremental}
    if files:
        config["files"] = files
    if cloud_files:
        config["cloud_files"] = cloud_files
    if emails:
        config["emails"] = emails
    if slack_channels:
        config["slack_channels"] = slack_channels
    if confluence_pages:
        config["confluence_pages"] = confluence_pages
    if jira_issues:
        config["jira_issues"] = jira_issues
    if salesforce_records:
        config["salesforce_records"] = salesforce_records
    return client.start_pipeline(config)


@mcp.tool()
def get_ingestion_status(run_id: str) -> str:
    """Check the progress of a knowledge graph build.

    Poll this every 5-10 seconds after calling `build_knowledge_graph`.
    The response includes:
    - status: "running", "completed", or "failed"
    - neo4j_ready: true when the graph is queryable
    - progress: latest pipeline stage and counts
    - events: recent pipeline events
    - error: error message if failed

    Args:
        run_id: The run_id returned by `build_knowledge_graph`.

    Returns:
        JSON with current pipeline status and progress details.
    """
    return client.get_pipeline_status(run_id)


@mcp.tool()
def connect_source(provider: str) -> str:
    """Get an OAuth URL to connect a data source.

    Returns a URL that a human user must open in their browser to authorize
    Pluck to access the data source. After they complete authorization,
    use `check_source_connection` to verify it worked.

    Supported providers: google_drive, gmail, outlook, sharepoint, slack,
    confluence, jira, salesforce.

    Args:
        provider: The data source provider name.

    Returns:
        JSON with auth_url (the URL to open) and provider name.
    """
    return client.start_oauth(provider)


@mcp.tool()
def check_source_connection(provider: str) -> str:
    """Check if a data source OAuth connection completed.

    Poll this after the user visits the URL from `connect_source`.
    Recommended: poll every 5 seconds, timeout after 10 minutes.

    Args:
        provider: The data source provider name.

    Returns:
        JSON with connected (bool) and provider name.
    """
    return client.check_oauth_callback(provider)


@mcp.tool()
def list_connected_sources() -> str:
    """List all data sources and their connection status.

    Returns which OAuth providers are connected and available for
    ingestion (Google Drive, Gmail, Slack, Confluence, etc.).

    Returns:
        JSON with providers dict mapping provider names to connected status.
    """
    return client.get_oauth_status()


@mcp.tool()
def browse_cloud_files(provider: str, folder: str | None = None) -> str:
    """Browse files and folders in a connected cloud data source.

    Use this to discover files in Google Drive, SharePoint, etc. after
    connecting the source with `connect_source`. The returned file objects
    can be passed to `build_knowledge_graph` as `cloud_files`.

    Args:
        provider: The connected cloud provider (e.g. "google_drive").
        folder: Optional folder ID to browse into. Omit for root.

    Returns:
        JSON with files and folders lists.
    """
    return client.browse_cloud(provider, folder)


def main() -> None:
    """Entry point for the pluck-mcp CLI command."""
    mcp.run()


if __name__ == "__main__":
    main()
