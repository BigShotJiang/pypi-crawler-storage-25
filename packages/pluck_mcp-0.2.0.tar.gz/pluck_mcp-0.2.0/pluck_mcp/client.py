"""HTTP client for the Pluck Integration API v1."""

from __future__ import annotations

import json
import logging
import os
from typing import Any
from urllib.parse import urlparse

import httpx

log = logging.getLogger(__name__)


class IntegrationApiClient:
    """Communicates with the Pluck chatbot Integration API v1."""

    def __init__(self) -> None:
        self.base_url = os.environ.get(
            "PLUCK_INTEGRATION_BASE_URL", "https://www.pluckagent.com"
        ).rstrip("/")
        self.api_key = os.environ.get("PLUCK_INTEGRATION_API_KEY", "")

        if not self.api_key:
            raise RuntimeError(
                "PLUCK_INTEGRATION_API_KEY is required. "
                "Create an API key at Settings > Integrations in Pluck."
            )

        parsed = urlparse(self.base_url)
        if not parsed.scheme or not parsed.netloc:
            raise RuntimeError(
                f"PLUCK_INTEGRATION_BASE_URL is not a valid URL: {self.base_url}"
            )
        if (
            parsed.scheme == "http"
            and parsed.hostname not in ("localhost", "127.0.0.1", "0.0.0.0")
        ):
            log.warning(
                "PLUCK_INTEGRATION_BASE_URL uses http:// for a non-localhost host. "
                "Consider using https:// in production to protect your API key."
            )

    def _headers(self) -> dict[str, str]:
        return {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }

    def _handle_error(self, exc: httpx.HTTPStatusError) -> str:
        """Extract a user-friendly error message from an HTTP error response."""
        status = exc.response.status_code
        try:
            body = exc.response.json()
            detail = body.get("detail", str(body))
        except Exception:
            detail = exc.response.text or str(exc)

        if status == 401:
            return f"Error: Authentication failed. Check your PLUCK_INTEGRATION_API_KEY. ({detail})"
        if status == 403:
            return f"Error: Insufficient permissions. Your API key may lack the required scope. ({detail})"
        if status == 412:
            return f"Error: Knowledge graph not configured for this organization. ({detail})"
        if status == 429:
            return f"Error: Rate limited. {detail}"
        return f"Error: API returned {status}. {detail}"

    def call_tool(self, tool_name: str, arguments: dict[str, Any]) -> str:
        """Call a Pluck tool via the Integration API and return the result string."""
        try:
            with httpx.Client(timeout=60.0) as http:
                resp = http.post(
                    f"{self.base_url}/api/v1/tools/{tool_name}",
                    headers=self._headers(),
                    json={"arguments": arguments},
                )
                resp.raise_for_status()
                return resp.json().get("result", "")
        except httpx.HTTPStatusError as exc:
            return self._handle_error(exc)
        except httpx.ConnectError:
            return f"Error: Cannot connect to Pluck API at {self.base_url}. Is the service running?"
        except httpx.TimeoutException:
            return f"Error: Request to Pluck API timed out after 60s."
        except Exception as exc:
            return f"Error: Unexpected error calling Pluck API: {exc}"

    def get_resource(self, path: str, params: dict[str, Any] | None = None) -> str:
        """Fetch a resource from the Integration API and return it as a string."""
        try:
            with httpx.Client(timeout=60.0) as http:
                resp = http.get(
                    f"{self.base_url}{path}",
                    headers=self._headers(),
                    params=params,
                )
                resp.raise_for_status()
                data = resp.json()
                # Tool call responses have a "result" field; raw resources don't.
                if isinstance(data, dict) and "result" in data:
                    return data["result"]
                return json.dumps(data, indent=2)
        except httpx.HTTPStatusError as exc:
            return self._handle_error(exc)
        except httpx.ConnectError:
            return f"Error: Cannot connect to Pluck API at {self.base_url}. Is the service running?"
        except httpx.TimeoutException:
            return f"Error: Request to Pluck API timed out after 60s."
        except Exception as exc:
            return f"Error: Unexpected error fetching from Pluck API: {exc}"

    def ask_pluck(
        self,
        message: str,
        conversation_history: list[dict[str, Any]] | None = None,
    ) -> str:
        """Stream a chat request and return the assembled response text."""
        payload = {
            "message": message,
            "conversation_history": conversation_history or [],
            "plan_first": True,
        }
        try:
            with httpx.Client(timeout=120.0) as http:
                with http.stream(
                    "POST",
                    f"{self.base_url}/api/v1/chat/stream",
                    headers=self._headers(),
                    json=payload,
                ) as resp:
                    resp.raise_for_status()
                    parts: list[str] = []
                    for line in resp.iter_lines():
                        if not line or not line.startswith("data: "):
                            continue
                        data = line[6:]
                        if data == "[DONE]":
                            break
                        try:
                            event = json.loads(data)
                        except Exception:
                            continue
                        if event.get("type") == "error":
                            return f"Error: {event.get('content', 'Unknown chat error')}"
                        if event.get("type") == "token":
                            parts.append(event.get("content", ""))
                    return "".join(parts).strip() or "No response received."
        except httpx.HTTPStatusError as exc:
            return self._handle_error(exc)
        except httpx.ConnectError:
            return f"Error: Cannot connect to Pluck API at {self.base_url}. Is the service running?"
        except httpx.TimeoutException:
            return "Error: Chat request timed out after 120s."
        except Exception as exc:
            return f"Error: Unexpected error during Pluck chat: {exc}"

    # --- Ingest methods ---

    def upload_file(self, file_path: str) -> str:
        """Upload a local file to Pluck for ingestion."""
        import os as _os
        if not _os.path.isfile(file_path):
            return f"Error: File not found: {file_path}"
        filename = _os.path.basename(file_path)
        try:
            with open(file_path, "rb") as f:
                content = f.read()
            with httpx.Client(timeout=300.0) as http:
                resp = http.post(
                    f"{self.base_url}/api/v1/ingest/upload",
                    headers={"Authorization": f"Bearer {self.api_key}"},
                    files={"file": (filename, content, "application/octet-stream")},
                )
                resp.raise_for_status()
                return json.dumps(resp.json(), indent=2)
        except httpx.HTTPStatusError as exc:
            return self._handle_error(exc)
        except httpx.ConnectError:
            return f"Error: Cannot connect to Pluck API at {self.base_url}."
        except httpx.TimeoutException:
            return f"Error: Upload timed out after 300s."
        except Exception as exc:
            return f"Error: Upload failed: {exc}"

    def start_pipeline(self, config: dict[str, Any]) -> str:
        """Start a pipeline run."""
        try:
            with httpx.Client(timeout=30.0) as http:
                resp = http.post(
                    f"{self.base_url}/api/v1/ingest/start",
                    headers=self._headers(),
                    json=config,
                )
                resp.raise_for_status()
                return json.dumps(resp.json(), indent=2)
        except httpx.HTTPStatusError as exc:
            return self._handle_error(exc)
        except httpx.ConnectError:
            return f"Error: Cannot connect to Pluck API at {self.base_url}."
        except Exception as exc:
            return f"Error: Pipeline start failed: {exc}"

    def get_pipeline_status(self, run_id: str) -> str:
        """Poll pipeline run status."""
        return self.get_resource(f"/api/v1/ingest/status/{run_id}")

    def get_oauth_status(self) -> str:
        """Get OAuth connection status for all providers."""
        return self.get_resource("/api/v1/ingest/oauth/status")

    def start_oauth(self, provider: str) -> str:
        """Get an OAuth authorization URL."""
        return self.get_resource("/api/v1/ingest/oauth/start", params={"provider": provider})

    def check_oauth_callback(self, provider: str) -> str:
        """Check if OAuth flow completed for a provider."""
        return self.get_resource("/api/v1/ingest/oauth/callback-status", params={"provider": provider})

    def browse_cloud(self, provider: str, folder: str | None = None) -> str:
        """Browse files in a connected cloud source."""
        params: dict[str, str] = {"provider": provider}
        if folder:
            params["folder"] = folder
        return self.get_resource("/api/v1/ingest/cloud/browse", params=params)
