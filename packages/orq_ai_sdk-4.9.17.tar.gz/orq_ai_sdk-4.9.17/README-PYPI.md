# orq-ai-sdk

Developer-friendly & type-safe Python SDK specifically catered to leverage *orq-ai-sdk* API.

<div align="left">
    <a href="https://www.speakeasy.com/?utm_source=orq-ai-sdk&utm_campaign=python"><img src="https://custom-icon-badges.demolab.com/badge/-Built%20By%20Speakeasy-212015?style=for-the-badge&logoColor=FBE331&logo=speakeasy&labelColor=545454" /></a>
    <a href="https://opensource.org/licenses/MIT">
        <img src="https://img.shields.io/badge/License-MIT-blue.svg" style="width: 100px; height: 28px;" />
    </a>
</div>

<!-- Start Summary [summary] -->
## Summary

orq.ai API: orq.ai API documentation

For more information about the API: [orq.ai Documentation](https://docs.orq.ai)
<!-- End Summary [summary] -->

<!-- Start Table of Contents [toc] -->
## Table of Contents
<!-- $toc-max-depth=2 -->
* [orq-ai-sdk](https://github.com/orq-ai/orq-python/blob/master/#orq-ai-sdk)
  * [SDK Installation](https://github.com/orq-ai/orq-python/blob/master/#sdk-installation)
  * [IDE Support](https://github.com/orq-ai/orq-python/blob/master/#ide-support)
  * [SDK Example Usage](https://github.com/orq-ai/orq-python/blob/master/#sdk-example-usage)
  * [Authentication](https://github.com/orq-ai/orq-python/blob/master/#authentication)
  * [Available Resources and Operations](https://github.com/orq-ai/orq-python/blob/master/#available-resources-and-operations)
  * [Server-sent event streaming](https://github.com/orq-ai/orq-python/blob/master/#server-sent-event-streaming)
  * [File uploads](https://github.com/orq-ai/orq-python/blob/master/#file-uploads)
  * [Retries](https://github.com/orq-ai/orq-python/blob/master/#retries)
  * [Error Handling](https://github.com/orq-ai/orq-python/blob/master/#error-handling)
  * [Server Selection](https://github.com/orq-ai/orq-python/blob/master/#server-selection)
  * [Custom HTTP Client](https://github.com/orq-ai/orq-python/blob/master/#custom-http-client)
  * [Resource Management](https://github.com/orq-ai/orq-python/blob/master/#resource-management)
  * [Debugging](https://github.com/orq-ai/orq-python/blob/master/#debugging)
* [Development](https://github.com/orq-ai/orq-python/blob/master/#development)
  * [Maturity](https://github.com/orq-ai/orq-python/blob/master/#maturity)
  * [Contributions](https://github.com/orq-ai/orq-python/blob/master/#contributions)

<!-- End Table of Contents [toc] -->

<!-- Start SDK Installation [installation] -->
## SDK Installation

> [!NOTE]
> **Python version upgrade policy**
>
> Once a Python version reaches its [official end of life date](https://devguide.python.org/versions/), a 3-month grace period is provided for users to upgrade. Following this grace period, the minimum python version supported in the SDK will be updated.

The SDK can be installed with *uv*, *pip*, or *poetry* package managers.

### uv

*uv* is a fast Python package installer and resolver, designed as a drop-in replacement for pip and pip-tools. It's recommended for its speed and modern Python tooling capabilities.

```bash
uv add orq-ai-sdk
```

### PIP

*PIP* is the default package installer for Python, enabling easy installation and management of packages from PyPI via the command line.

```bash
pip install orq-ai-sdk
```

### Poetry

*Poetry* is a modern tool that simplifies dependency management and package publishing by using a single `pyproject.toml` file to handle project metadata and dependencies.

```bash
poetry add orq-ai-sdk
```

### Shell and script usage with `uv`

You can use this SDK in a Python shell with [uv](https://docs.astral.sh/uv/) and the `uvx` command that comes with it like so:

```shell
uvx --from orq-ai-sdk python
```

It's also possible to write a standalone Python script without needing to set up a whole project like so:

```python
#!/usr/bin/env -S uv run --script
# /// script
# requires-python = ">=3.10"
# dependencies = [
#     "orq-ai-sdk",
# ]
# ///

from orq_ai_sdk import Orq

sdk = Orq(
  # SDK arguments
)

# Rest of script here...
```

Once that is saved to a file, you can run it with `uv run script.py` where
`script.py` can be replaced with the actual file name.
<!-- End SDK Installation [installation] -->

<!-- Start IDE Support [idesupport] -->
## IDE Support

### PyCharm

Generally, the SDK will work well with most IDEs out of the box. However, when using PyCharm, you can enjoy much better integration with Pydantic by installing an additional plugin.

- [PyCharm Pydantic Plugin](https://docs.pydantic.dev/latest/integrations/pycharm/)
<!-- End IDE Support [idesupport] -->

<!-- Start SDK Example Usage [usage] -->
## SDK Example Usage

### Example

```python
# Synchronous Example
from orq_ai_sdk import Orq
import os


with Orq(
    api_key=os.getenv("ORQ_API_KEY", ""),
) as orq:

    orq.post_v2_feedback_evaluation_remove()

    # Use the SDK ...
```

</br>

The same SDK client can also be used to make asynchronous requests by importing asyncio.

```python
# Asynchronous Example
import asyncio
from orq_ai_sdk import Orq
import os

async def main():

    async with Orq(
        api_key=os.getenv("ORQ_API_KEY", ""),
    ) as orq:

        await orq.post_v2_feedback_evaluation_remove_async()

        # Use the SDK ...

asyncio.run(main())
```
<!-- End SDK Example Usage [usage] -->

<!-- Start Authentication [security] -->
## Authentication

### Per-Client Security Schemes

This SDK supports the following security scheme globally:

| Name      | Type | Scheme      | Environment Variable |
| --------- | ---- | ----------- | -------------------- |
| `api_key` | http | HTTP Bearer | `ORQ_API_KEY`        |

To authenticate with the API the `api_key` parameter must be set when initializing the SDK client instance. For example:
```python
from orq_ai_sdk import Orq
import os


with Orq(
    api_key=os.getenv("ORQ_API_KEY", ""),
) as orq:

    orq.post_v2_feedback_evaluation_remove()

    # Use the SDK ...

```
<!-- End Authentication [security] -->

<!-- Start Available Resources and Operations [operations] -->
## Available Resources and Operations

<details open>
<summary>Available methods</summary>

### [Orq SDK](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/orq/README.md)

* [post_v2_feedback_evaluation_remove](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/orq/README.md#post_v2_feedback_evaluation_remove)
* [post_v2_feedback_evaluation](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/orq/README.md#post_v2_feedback_evaluation)

### [Agents](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/agents/README.md)

* [post_v2_agents_a2a](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/agents/README.md#post_v2_agents_a2a) - Register external A2A agent
* [post_v2_agents_key_card_refresh](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/agents/README.md#post_v2_agents_key_card_refresh) - Refresh A2A agent card
* [create](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/agents/README.md#create) - Create agent
* [list](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/agents/README.md#list) - List agents
* [delete](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/agents/README.md#delete) - Delete agent
* [retrieve](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/agents/README.md#retrieve) - Retrieve agent
* [update](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/agents/README.md#update) - Update agent
* [~~invoke~~](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/agents/README.md#invoke) - Execute an agent task :warning: **Deprecated**
* [~~run~~](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/agents/README.md#run) - Run an agent with configuration :warning: **Deprecated**
* [~~stream_run~~](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/agents/README.md#stream_run) - Run agent with streaming response :warning: **Deprecated**
* [~~stream~~](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/agents/README.md#stream) - Stream agent execution in real-time :warning: **Deprecated**

### [Agents.Responses](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/orqresponses/README.md)

* [create](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/orqresponses/README.md#create) - Create response
* [get](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/orqresponses/README.md#get) - Get response

### [Annotations](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/annotations/README.md)

* [create](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/annotations/README.md#create) - Annotate a span
* [delete](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/annotations/README.md#delete) - Remove an annotation from a span

### [Chunking](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/chunking/README.md)

* [parse](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/chunking/README.md#parse) - Parse text

### [Contacts](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/contacts/README.md)

* [create](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/contacts/README.md#create) - Update user information

### [Datasets](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/datasets/README.md)

* [list](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/datasets/README.md#list) - List datasets
* [create](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/datasets/README.md#create) - Create a dataset
* [retrieve](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/datasets/README.md#retrieve) - Retrieve a dataset
* [update](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/datasets/README.md#update) - Update a dataset
* [delete](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/datasets/README.md#delete) - Delete a dataset
* [list_datapoints](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/datasets/README.md#list_datapoints) - List datapoints
* [create_datapoint](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/datasets/README.md#create_datapoint) - Create a datapoint
* [retrieve_datapoint](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/datasets/README.md#retrieve_datapoint) - Retrieve a datapoint
* [update_datapoint](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/datasets/README.md#update_datapoint) - Update a datapoint
* [delete_datapoint](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/datasets/README.md#delete_datapoint) - Delete a datapoint
* [clear](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/datasets/README.md#clear) - Delete all datapoints

### [Deployments](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/deployments/README.md)

* [invoke](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/deployments/README.md#invoke) - Invoke
* [list](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/deployments/README.md#list) - List all deployments
* [get_config](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/deployments/README.md#get_config) - Get config
* [stream](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/deployments/README.md#stream) - Stream

#### [~~Deployments.Metrics~~](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/metrics/README.md)

* [~~create~~](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/metrics/README.md#create) - Add metrics :warning: **Deprecated**

### [Evals](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/evals/README.md)

* [all](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/evals/README.md#all) - Get all Evaluators
* [create](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/evals/README.md#create) - Create an Evaluator
* [update](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/evals/README.md#update) - Update an Evaluator
* [delete](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/evals/README.md#delete) - Delete an Evaluator
* [invoke](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/evals/README.md#invoke) - Invoke a Custom Evaluator
* [get_v2_evaluators_id_versions](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/evals/README.md#get_v2_evaluators_id_versions) - List evaluator versions

### [Feedback](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/feedback/README.md)

* [post_v2_feedback](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/feedback/README.md#post_v2_feedback)
* [post_v2_feedback_remove](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/feedback/README.md#post_v2_feedback_remove)

### [Files](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/files/README.md)

* [list](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/files/README.md#list) - List all files
* [create](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/files/README.md#create) - Upload a file
* [get_content](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/files/README.md#get_content) - Download file content
* [get](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/files/README.md#get) - Retrieve a file
* [delete](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/files/README.md#delete) - Delete a file
* [update](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/files/README.md#update) - Update a file

### [GuardrailRules](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/guardrailrules/README.md)

* [list](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/guardrailrules/README.md#list) - List guardrail rules
* [create](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/guardrailrules/README.md#create) - Create guardrail rule
* [delete](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/guardrailrules/README.md#delete) - Delete guardrail rule
* [retrieve](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/guardrailrules/README.md#retrieve) - Get guardrail rule
* [update](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/guardrailrules/README.md#update) - Update guardrail rule

### [HumanReviewSets](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/humanreviewsets/README.md)

* [get_v2_human_eval_sets](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/humanreviewsets/README.md#get_v2_human_eval_sets) - Get all human review sets
* [post_v2_human_eval_sets](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/humanreviewsets/README.md#post_v2_human_eval_sets) - Create a human review set
* [get_v2_human_eval_sets_id_](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/humanreviewsets/README.md#get_v2_human_eval_sets_id_) - Get a human review set by ID
* [patch_v2_human_eval_sets_id_](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/humanreviewsets/README.md#patch_v2_human_eval_sets_id_) - Update a human review set
* [delete_v2_human_eval_sets_id_](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/humanreviewsets/README.md#delete_v2_human_eval_sets_id_) - Delete a human review set

### [Identities](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/identities/README.md)

* [list](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/identities/README.md#list) - List identities
* [create](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/identities/README.md#create) - Create an identity
* [retrieve](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/identities/README.md#retrieve) - Retrieve an identity
* [update](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/identities/README.md#update) - Update an identity
* [delete](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/identities/README.md#delete) - Delete an identity

### [Knowledge](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/knowledge/README.md)

* [list](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/knowledge/README.md#list) - List all knowledge bases
* [create](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/knowledge/README.md#create) - Create a knowledge
* [retrieve](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/knowledge/README.md#retrieve) - Retrieves a knowledge base
* [update](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/knowledge/README.md#update) - Updates a knowledge
* [delete](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/knowledge/README.md#delete) - Deletes a knowledge
* [search](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/knowledge/README.md#search) - Search knowledge base
* [list_datasources](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/knowledge/README.md#list_datasources) - List all datasources
* [create_datasource](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/knowledge/README.md#create_datasource) - Create a new datasource
* [retrieve_datasource](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/knowledge/README.md#retrieve_datasource) - Retrieve a datasource
* [delete_datasource](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/knowledge/README.md#delete_datasource) - Deletes a datasource
* [update_datasource](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/knowledge/README.md#update_datasource) - Update a datasource
* [create_chunks](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/knowledge/README.md#create_chunks) - Create chunks for a datasource
* [list_chunks](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/knowledge/README.md#list_chunks) - List all chunks for a datasource
* [delete_chunks](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/knowledge/README.md#delete_chunks) - Delete multiple chunks
* [list_chunks_paginated](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/knowledge/README.md#list_chunks_paginated) - List chunks with offset-based pagination
* [get_chunks_count](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/knowledge/README.md#get_chunks_count) - Get chunks total count
* [update_chunk](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/knowledge/README.md#update_chunk) - Update a chunk
* [delete_chunk](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/knowledge/README.md#delete_chunk) - Delete a chunk
* [retrieve_chunk](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/knowledge/README.md#retrieve_chunk) - Retrieve a chunk

### [MemoryStores](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/memorystores/README.md)

* [list](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/memorystores/README.md#list) - List memory stores
* [create](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/memorystores/README.md#create) - Create memory store
* [retrieve](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/memorystores/README.md#retrieve) - Retrieve memory store
* [update](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/memorystores/README.md#update) - Update memory store
* [delete](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/memorystores/README.md#delete) - Delete memory store
* [list_memories](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/memorystores/README.md#list_memories) - List all memories
* [create_memory](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/memorystores/README.md#create_memory) - Create a new memory
* [retrieve_memory](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/memorystores/README.md#retrieve_memory) - Retrieve a specific memory
* [update_memory](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/memorystores/README.md#update_memory) - Update a specific memory
* [delete_memory](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/memorystores/README.md#delete_memory) - Delete a specific memory
* [list_documents](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/memorystores/README.md#list_documents) - List all documents for a memory
* [create_document](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/memorystores/README.md#create_document) - Create a new memory document
* [retrieve_document](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/memorystores/README.md#retrieve_document) - Retrieve a specific memory document
* [update_document](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/memorystores/README.md#update_document) - Update a specific memory document
* [delete_document](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/memorystores/README.md#delete_document) - Delete a specific memory document

### [Policies](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/policies/README.md)

* [list](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/policies/README.md#list) - List policies
* [create](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/policies/README.md#create) - Create policy
* [delete](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/policies/README.md#delete) - Delete policy
* [retrieve](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/policies/README.md#retrieve) - Get policy
* [update](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/policies/README.md#update) - Update policy

### [Projects](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/projects/README.md)

* [list](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/projects/README.md#list) - List all projects
* [create](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/projects/README.md#create) - Create a new project
* [get](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/projects/README.md#get) - Retrieve a project
* [delete](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/projects/README.md#delete) - Delete a project
* [update](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/projects/README.md#update) - Update a project

### [Prompts](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/prompts/README.md)

* [list](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/prompts/README.md#list) - List all prompts
* [create](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/prompts/README.md#create) - Create a prompt
* [retrieve](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/prompts/README.md#retrieve) - Retrieve a prompt
* [update](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/prompts/README.md#update) - Update a prompt
* [delete](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/prompts/README.md#delete) - Delete a prompt
* [list_versions](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/prompts/README.md#list_versions) - List all prompt versions
* [get_version](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/prompts/README.md#get_version) - Retrieve a prompt version

### [Remoteconfigs](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/remoteconfigs/README.md)

* [retrieve](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/remoteconfigs/README.md#retrieve) - Retrieve a remote config

### [Responses](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/responses/README.md)

* [create](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/responses/README.md#create) - Create response
* [get](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/responses/README.md#get) - Retrieve response

### [Router](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/router/README.md)

* [ocr](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/router/README.md#ocr) - Extracts text content while maintaining document structure and hierarchy

#### [Router.Audio.Speech](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/speech/README.md)

* [create](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/speech/README.md#create) - Create speech

#### [Router.Audio.Transcriptions](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/transcriptions/README.md)

* [create](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/transcriptions/README.md#create) - Create transcription

#### [Router.Audio.Translations](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/translations/README.md)

* [create](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/translations/README.md#create) - Create translation

#### [Router.Chat.Completions](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/orqcompletions/README.md)

* [create](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/orqcompletions/README.md#create) - Create chat completion

#### [Router.Completions](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/completions/README.md)

* [create](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/completions/README.md#create) - Create completion

#### [Router.Embeddings](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/embeddings/README.md)

* [create](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/embeddings/README.md#create) - Create embeddings

#### [Router.Images.Edits](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/edits/README.md)

* [create](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/edits/README.md#create) - Create image edit

#### [Router.Images.Generations](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/generations/README.md)

* [create](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/generations/README.md#create) - Create image

#### [Router.Images.Variations](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/variations/README.md)

* [create](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/variations/README.md#create) - Create image variation

#### [Router.Moderations](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/moderations/README.md)

* [create](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/moderations/README.md#create) - Create moderation

#### [Router.Rerank](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/rerank/README.md)

* [create](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/rerank/README.md#create) - Create rerank

### [RoutingRules](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/routingrules/README.md)

* [list](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/routingrules/README.md#list) - List routing rules
* [create](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/routingrules/README.md#create) - Create routing rule
* [delete](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/routingrules/README.md#delete) - Delete routing rule
* [retrieve](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/routingrules/README.md#retrieve) - Get routing rule
* [update](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/routingrules/README.md#update) - Update routing rule

### [Schedules](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/schedules/README.md)

* [list](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/schedules/README.md#list) - List schedules
* [create](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/schedules/README.md#create) - Create schedule
* [delete](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/schedules/README.md#delete) - Delete schedule
* [retrieve](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/schedules/README.md#retrieve) - Retrieve schedule
* [update](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/schedules/README.md#update) - Update schedule
* [trigger](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/schedules/README.md#trigger) - Trigger schedule execution

### [Skills](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/skills/README.md)

* [list](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/skills/README.md#list) - List all skills
* [create](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/skills/README.md#create) - Create a new skill
* [get](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/skills/README.md#get) - Retrieve a skill
* [delete](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/skills/README.md#delete) - Delete a skill
* [update](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/skills/README.md#update) - Update a skill

### [Tools](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/tools/README.md)

* [list](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/tools/README.md#list) - List tools
* [create](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/tools/README.md#create) - Create tool
* [update](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/tools/README.md#update) - Update tool
* [delete](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/tools/README.md#delete) - Delete tool
* [retrieve](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/tools/README.md#retrieve) - Retrieve tool
* [get_v2_tools_tool_id_versions](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/tools/README.md#get_v2_tools_tool_id_versions) - List tool versions
* [get_v2_tools_tool_id_versions_version_id_](https://github.com/orq-ai/orq-python/blob/master/docs/sdks/tools/README.md#get_v2_tools_tool_id_versions_version_id_) - Get tool version

</details>
<!-- End Available Resources and Operations [operations] -->

<!-- Start Server-sent event streaming [eventstream] -->
## Server-sent event streaming

[Server-sent events][mdn-sse] are used to stream content from certain
operations. These operations will expose the stream as [Generator][generator] that
can be consumed using a simple `for` loop. The loop will
terminate when the server no longer has any events to send and closes the
underlying connection.  

The stream is also a [Context Manager][context-manager] and can be used with the `with` statement and will close the
underlying connection when the context is exited.

```python
from orq_ai_sdk import Orq
import os


with Orq(
    environment="<value>",
    contact_id="<id>",
    api_key=os.getenv("ORQ_API_KEY", ""),
) as orq:

    res = orq.deployments.stream(key="<key>", identity={
        "id": "contact_01ARZ3NDEKTSV4RRFFQ69G5FAV",
        "display_name": "Jane Doe",
        "email": "jane.doe@example.com",
        "metadata": [
            {
                "department": "Engineering",
                "role": "Senior Developer",
            },
        ],
        "logo_url": "https://example.com/avatars/jane-doe.jpg",
        "tags": [
            "hr",
            "engineering",
        ],
    }, documents=[
        {
            "text": "The refund policy allows customers to return items within 30 days of purchase for a full refund.",
            "metadata": {
                "file_name": "refund_policy.pdf",
                "file_type": "application/pdf",
                "page_number": 1,
            },
        },
        {
            "text": "Premium members receive free shipping on all orders over $50.",
            "metadata": {
                "file_name": "membership_benefits.md",
                "file_type": "text/markdown",
            },
        },
    ])

    with res as event_stream:
        for event in event_stream:
            # handle event
            print(event, flush=True)

```

[mdn-sse]: https://developer.mozilla.org/en-US/docs/Web/API/Server-sent_events/Using_server-sent_events
[generator]: https://book.pythontips.com/en/latest/generators.html
[context-manager]: https://book.pythontips.com/en/latest/context_managers.html
<!-- End Server-sent event streaming [eventstream] -->

<!-- Start File uploads [file-upload] -->
## File uploads

Certain SDK methods accept file objects as part of a request body or multi-part request. It is possible and typically recommended to upload files as a stream rather than reading the entire contents into memory. This avoids excessive memory consumption and potentially crashing with out-of-memory errors when working with very large files. The following example demonstrates how to attach a file stream to a request.

> [!TIP]
>
> For endpoints that handle file uploads bytes arrays can also be used. However, using streams is recommended for large files.
>

```python
from orq_ai_sdk import Orq
import os


with Orq(
    api_key=os.getenv("ORQ_API_KEY", ""),
) as orq:

    res = orq.router.audio.transcriptions.create(model="Malibu", enable_logging=True, diarize=False, tag_audio_events=True, timestamps_granularity="word", temperature=0.5, timestamp_granularities=[
        "word",
        "segment",
    ], retry={
        "on_codes": [
            429,
            500,
            502,
            503,
            504,
        ],
    }, load_balancer={
        "type": "weight_based",
        "models": [
            {
                "model": "openai/gpt-4o",
                "weight": 0.7,
            },
        ],
    }, timeout={
        "call_timeout": 30000,
    }, orq={
        "fallbacks": [
            {
                "model": "openai/gpt-4o-mini",
            },
        ],
        "retry": {
            "on_codes": [
                429,
                500,
                502,
                503,
                504,
            ],
        },
        "identity": {
            "id": "contact_01ARZ3NDEKTSV4RRFFQ69G5FAV",
            "display_name": "Jane Doe",
            "email": "jane.doe@example.com",
            "metadata": [
                {
                    "department": "Engineering",
                    "role": "Senior Developer",
                },
            ],
            "logo_url": "https://example.com/avatars/jane-doe.jpg",
            "tags": [
                "hr",
                "engineering",
            ],
        },
        "load_balancer": {
            "type": "weight_based",
            "models": [
                {
                    "model": "openai/gpt-4o",
                    "weight": 0.7,
                },
                {
                    "model": "anthropic/claude-3-5-sonnet",
                    "weight": 0.3,
                },
            ],
        },
        "timeout": {
            "call_timeout": 30000,
        },
    })

    # Handle response
    print(res)

```
<!-- End File uploads [file-upload] -->

<!-- Start Retries [retries] -->
## Retries

Some of the endpoints in this SDK support retries. If you use the SDK without any configuration, it will fall back to the default retry strategy provided by the API. However, the default retry strategy can be overridden on a per-operation basis, or across the entire SDK.

To change the default retry strategy for a single API call, simply provide a `RetryConfig` object to the call:
```python
from orq_ai_sdk import Orq
from orq_ai_sdk.utils import BackoffStrategy, RetryConfig
import os


with Orq(
    api_key=os.getenv("ORQ_API_KEY", ""),
) as orq:

    orq.post_v2_feedback_evaluation_remove(,
        RetryConfig("backoff", BackoffStrategy(1, 50, 1.1, 100), False))

    # Use the SDK ...

```

If you'd like to override the default retry strategy for all operations that support retries, you can use the `retry_config` optional parameter when initializing the SDK:
```python
from orq_ai_sdk import Orq
from orq_ai_sdk.utils import BackoffStrategy, RetryConfig
import os


with Orq(
    retry_config=RetryConfig("backoff", BackoffStrategy(1, 50, 1.1, 100), False),
    api_key=os.getenv("ORQ_API_KEY", ""),
) as orq:

    orq.post_v2_feedback_evaluation_remove()

    # Use the SDK ...

```
<!-- End Retries [retries] -->

<!-- Start Error Handling [errors] -->
## Error Handling

[`OrqError`](https://github.com/orq-ai/orq-python/blob/master/./src/orq_ai_sdk/models/orqerror.py) is the base class for all HTTP error responses. It has the following properties:

| Property           | Type             | Description                                                                             |
| ------------------ | ---------------- | --------------------------------------------------------------------------------------- |
| `err.message`      | `str`            | Error message                                                                           |
| `err.status_code`  | `int`            | HTTP response status code eg `404`                                                      |
| `err.headers`      | `httpx.Headers`  | HTTP response headers                                                                   |
| `err.body`         | `str`            | HTTP body. Can be empty string if no body is returned.                                  |
| `err.raw_response` | `httpx.Response` | Raw HTTP response                                                                       |
| `err.data`         |                  | Optional. Some errors may contain structured data. [See Error Classes](https://github.com/orq-ai/orq-python/blob/master/#error-classes). |

### Example
```python
from orq_ai_sdk import Orq, models
import os


with Orq(
    api_key=os.getenv("ORQ_API_KEY", ""),
) as orq:
    res = None
    try:

        res = orq.feedback.post_v2_feedback()

        # Handle response
        print(res)


    except models.OrqError as e:
        # The base class for HTTP error responses
        print(e.message)
        print(e.status_code)
        print(e.body)
        print(e.headers)
        print(e.raw_response)

        # Depending on the method different errors may be thrown
        if isinstance(e, models.PostV2FeedbackFeedbackResponseBody):
            print(e.data.message)  # str
```

### Error Classes
**Primary error:**
* [`OrqError`](https://github.com/orq-ai/orq-python/blob/master/./src/orq_ai_sdk/models/orqerror.py): The base class for HTTP error responses.

<details><summary>Less common errors (47)</summary>

<br />

**Network errors:**
* [`httpx.RequestError`](https://www.python-httpx.org/exceptions/#httpx.RequestError): Base class for request errors.
    * [`httpx.ConnectError`](https://www.python-httpx.org/exceptions/#httpx.ConnectError): HTTP client was unable to make a request to a server.
    * [`httpx.TimeoutException`](https://www.python-httpx.org/exceptions/#httpx.TimeoutException): HTTP request timed out.


**Inherit from [`OrqError`](https://github.com/orq-ai/orq-python/blob/master/./src/orq_ai_sdk/models/orqerror.py)**:
* [`HonoAPIError`](https://github.com/orq-ai/orq-python/blob/master/./src/orq_ai_sdk/models/honoapierror.py): Applicable to 10 of 153 methods.*
* [`PostV2FeedbackFeedbackResponseBody`](https://github.com/orq-ai/orq-python/blob/master/./src/orq_ai_sdk/models/postv2feedbackfeedbackresponsebody.py): Bad Request. Status code `400`. Applicable to 1 of 153 methods.*
* [`InvokeEvalEvalsResponseBody`](https://github.com/orq-ai/orq-python/blob/master/./src/orq_ai_sdk/models/invokeevalevalsresponsebody.py): Bad request. Status code `400`. Applicable to 1 of 153 methods.*
* [`PostV2AgentsA2aAgentsResponseBody`](https://github.com/orq-ai/orq-python/blob/master/./src/orq_ai_sdk/models/postv2agentsa2aagentsresponsebody.py): Invalid request or agent card fetch failed. Status code `400`. Applicable to 1 of 153 methods.*
* [`PostV2AgentsKeyCardRefreshAgentsResponseBody`](https://github.com/orq-ai/orq-python/blob/master/./src/orq_ai_sdk/models/postv2agentskeycardrefreshagentsresponsebody.py): Invalid request - Agent is not an A2A agent or card fetch failed. Status code `400`. Applicable to 1 of 153 methods.*
* [`CreateAgentScheduleSchedulesResponseBody`](https://github.com/orq-ai/orq-python/blob/master/./src/orq_ai_sdk/models/createagentscheduleschedulesresponsebody.py): Invalid schedule type, expression, or sub-hour cadence. Status code `400`. Applicable to 1 of 153 methods.*
* [`UpdateAgentScheduleSchedulesResponseBody`](https://github.com/orq-ai/orq-python/blob/master/./src/orq_ai_sdk/models/updateagentscheduleschedulesresponsebody.py): Invalid type, expression, or sub-hour cadence. Status code `400`. Applicable to 1 of 153 methods.*
* [`TriggerAgentScheduleSchedulesResponseBody`](https://github.com/orq-ai/orq-python/blob/master/./src/orq_ai_sdk/models/triggeragentscheduleschedulesresponsebody.py): Schedule is inactive. Status code `400`. Applicable to 1 of 153 methods.*
* [`PostV2FeedbackFeedbackResponseResponseBody`](https://github.com/orq-ai/orq-python/blob/master/./src/orq_ai_sdk/models/postv2feedbackfeedbackresponseresponsebody.py): Workspace ID is not found on the request. Status code `404`. Applicable to 1 of 153 methods.*
* [`PostV2FeedbackRemoveFeedbackResponseBody`](https://github.com/orq-ai/orq-python/blob/master/./src/orq_ai_sdk/models/postv2feedbackremovefeedbackresponsebody.py): Workspace ID is not found on the request. Status code `404`. Applicable to 1 of 153 methods.*
* [`GetEvalsEvalsResponseBody`](https://github.com/orq-ai/orq-python/blob/master/./src/orq_ai_sdk/models/getevalsevalsresponsebody.py): Workspace ID is not found on the request. Status code `404`. Applicable to 1 of 153 methods.*
* [`CreateEvalEvalsResponseBody`](https://github.com/orq-ai/orq-python/blob/master/./src/orq_ai_sdk/models/createevalevalsresponsebody.py): Workspace ID is not found on the request. Status code `404`. Applicable to 1 of 153 methods.*
* [`UpdateEvalEvalsResponseBody`](https://github.com/orq-ai/orq-python/blob/master/./src/orq_ai_sdk/models/updateevalevalsresponsebody.py): Workspace ID is not found on the request. Status code `404`. Applicable to 1 of 153 methods.*
* [`DeleteEvalResponseBody`](https://github.com/orq-ai/orq-python/blob/master/./src/orq_ai_sdk/models/deleteevalresponsebody.py): Workspace ID is not found on the request. Status code `404`. Applicable to 1 of 153 methods.*
* [`InvokeEvalEvalsResponseResponseBody`](https://github.com/orq-ai/orq-python/blob/master/./src/orq_ai_sdk/models/invokeevalevalsresponseresponsebody.py): Workspace ID is not found on the request. Status code `404`. Applicable to 1 of 153 methods.*
* [`GetV2EvaluatorsIDVersionsEvalsResponseBody`](https://github.com/orq-ai/orq-python/blob/master/./src/orq_ai_sdk/models/getv2evaluatorsidversionsevalsresponsebody.py): Evaluator not found. Status code `404`. Applicable to 1 of 153 methods.*
* [`RetrieveIdentityIdentitiesResponseBody`](https://github.com/orq-ai/orq-python/blob/master/./src/orq_ai_sdk/models/retrieveidentityidentitiesresponsebody.py): Identity not found. Status code `404`. Applicable to 1 of 153 methods.*
* [`UpdateIdentityIdentitiesResponseBody`](https://github.com/orq-ai/orq-python/blob/master/./src/orq_ai_sdk/models/updateidentityidentitiesresponsebody.py): Identity not found. Status code `404`. Applicable to 1 of 153 methods.*
* [`DeleteIdentityResponseBody`](https://github.com/orq-ai/orq-python/blob/master/./src/orq_ai_sdk/models/deleteidentityresponsebody.py): Identity not found. Status code `404`. Applicable to 1 of 153 methods.*
* [`PostV2AgentsKeyCardRefreshAgentsResponseResponseBody`](https://github.com/orq-ai/orq-python/blob/master/./src/orq_ai_sdk/models/postv2agentskeycardrefreshagentsresponseresponsebody.py): Agent not found. Status code `404`. Applicable to 1 of 153 methods.*
* [`DeleteAgentResponseBody`](https://github.com/orq-ai/orq-python/blob/master/./src/orq_ai_sdk/models/deleteagentresponsebody.py): Agent not found. The specified agent key does not exist in the workspace or has already been deleted. Status code `404`. Applicable to 1 of 153 methods.*
* [`RetrieveAgentRequestAgentsResponseBody`](https://github.com/orq-ai/orq-python/blob/master/./src/orq_ai_sdk/models/retrieveagentrequestagentsresponsebody.py): Agent not found. The specified agent key does not exist in the workspace or you do not have permission to access it. Status code `404`. Applicable to 1 of 153 methods.*
* [`UpdateAgentAgentsResponseBody`](https://github.com/orq-ai/orq-python/blob/master/./src/orq_ai_sdk/models/updateagentagentsresponsebody.py): Agent not found. The specified agent key does not exist in the workspace or you do not have permission to modify it. Status code `404`. Applicable to 1 of 153 methods.*
* [`StreamRunAgentAgentsResponseBody`](https://github.com/orq-ai/orq-python/blob/master/./src/orq_ai_sdk/models/streamrunagentagentsresponsebody.py): Model not found. Status code `404`. Applicable to 1 of 153 methods.*
* [`StreamAgentAgentsResponseBody`](https://github.com/orq-ai/orq-python/blob/master/./src/orq_ai_sdk/models/streamagentagentsresponsebody.py): Agent not found. Status code `404`. Applicable to 1 of 153 methods.*
* [`UpdatePromptResponseBody`](https://github.com/orq-ai/orq-python/blob/master/./src/orq_ai_sdk/models/updatepromptresponsebody.py): Prompt not found. Status code `404`. Applicable to 1 of 153 methods.*
* [`DeletePromptResponseBody`](https://github.com/orq-ai/orq-python/blob/master/./src/orq_ai_sdk/models/deletepromptresponsebody.py): Prompt not found. Status code `404`. Applicable to 1 of 153 methods.*
* [`GetPromptVersionPromptsResponseBody`](https://github.com/orq-ai/orq-python/blob/master/./src/orq_ai_sdk/models/getpromptversionpromptsresponsebody.py): Not Found - The prompt or prompt version does not exist. Status code `404`. Applicable to 1 of 153 methods.*
* [`UpdateToolToolsResponseBody`](https://github.com/orq-ai/orq-python/blob/master/./src/orq_ai_sdk/models/updatetooltoolsresponsebody.py): Tool not found. Status code `404`. Applicable to 1 of 153 methods.*
* [`GetV2ToolsToolIDVersionsToolsResponseBody`](https://github.com/orq-ai/orq-python/blob/master/./src/orq_ai_sdk/models/getv2toolstoolidversionstoolsresponsebody.py): Tool not found. Status code `404`. Applicable to 1 of 153 methods.*
* [`GetV2ToolsToolIDVersionsVersionIDToolsResponseBody`](https://github.com/orq-ai/orq-python/blob/master/./src/orq_ai_sdk/models/getv2toolstoolidversionsversionidtoolsresponsebody.py): Tool or version not found. Status code `404`. Applicable to 1 of 153 methods.*
* [`CreateAgentScheduleSchedulesResponseResponseBody`](https://github.com/orq-ai/orq-python/blob/master/./src/orq_ai_sdk/models/createagentscheduleschedulesresponseresponsebody.py): Agent (or agent version, when agent_tag is set) not found. Status code `404`. Applicable to 1 of 153 methods.*
* [`DeleteAgentScheduleResponseBody`](https://github.com/orq-ai/orq-python/blob/master/./src/orq_ai_sdk/models/deleteagentscheduleresponsebody.py): Schedule not found, or belongs to a different agent. Status code `404`. Applicable to 1 of 153 methods.*
* [`RetrieveAgentScheduleSchedulesResponseBody`](https://github.com/orq-ai/orq-python/blob/master/./src/orq_ai_sdk/models/retrieveagentscheduleschedulesresponsebody.py): Schedule not found, or belongs to a different agent. Status code `404`. Applicable to 1 of 153 methods.*
* [`UpdateAgentScheduleSchedulesResponseResponseBody`](https://github.com/orq-ai/orq-python/blob/master/./src/orq_ai_sdk/models/updateagentscheduleschedulesresponseresponsebody.py): Schedule or agent version not found. Status code `404`. Applicable to 1 of 153 methods.*
* [`TriggerAgentScheduleSchedulesResponseResponseBody`](https://github.com/orq-ai/orq-python/blob/master/./src/orq_ai_sdk/models/triggeragentscheduleschedulesresponseresponsebody.py): Schedule not found, or belongs to a different agent. Status code `404`. Applicable to 1 of 153 methods.*
* [`PostV2AgentsA2aAgentsResponseResponseBody`](https://github.com/orq-ai/orq-python/blob/master/./src/orq_ai_sdk/models/postv2agentsa2aagentsresponseresponsebody.py): Agent with this key already exists. Status code `409`. Applicable to 1 of 153 methods.*
* [`CreateModerationRouterModerationsResponseBody`](https://github.com/orq-ai/orq-python/blob/master/./src/orq_ai_sdk/models/createmoderationroutermoderationsresponsebody.py): Returns validation error. Status code `422`. Applicable to 1 of 153 methods.*
* [`CreateTranscriptionRouterAudioTranscriptionsResponseBody`](https://github.com/orq-ai/orq-python/blob/master/./src/orq_ai_sdk/models/createtranscriptionrouteraudiotranscriptionsresponsebody.py): Returns validation error. Status code `422`. Applicable to 1 of 153 methods.*
* [`CreateTranslationRouterAudioTranslationsResponseBody`](https://github.com/orq-ai/orq-python/blob/master/./src/orq_ai_sdk/models/createtranslationrouteraudiotranslationsresponsebody.py): Returns validation error. Status code `422`. Applicable to 1 of 153 methods.*
* [`InvokeEvalEvalsResponse500ResponseBody`](https://github.com/orq-ai/orq-python/blob/master/./src/orq_ai_sdk/models/invokeevalevalsresponse500responsebody.py): Error running the evaluator. Status code `500`. Applicable to 1 of 153 methods.*
* [`RetrieveIdentityIdentitiesResponseResponseBody`](https://github.com/orq-ai/orq-python/blob/master/./src/orq_ai_sdk/models/retrieveidentityidentitiesresponseresponsebody.py): Failed to fetch metrics. Status code `500`. Applicable to 1 of 153 methods.*
* [`ResponseValidationError`](https://github.com/orq-ai/orq-python/blob/master/./src/orq_ai_sdk/models/responsevalidationerror.py): Type mismatch between the response data and the expected Pydantic model. Provides access to the Pydantic validation error via the `cause` attribute.

</details>

\* Check [the method documentation](https://github.com/orq-ai/orq-python/blob/master/#available-resources-and-operations) to see if the error is applicable.
<!-- End Error Handling [errors] -->

<!-- Start Server Selection [server] -->
## Server Selection

### Override Server URL Per-Client

The default server can be overridden globally by passing a URL to the `server_url: str` optional parameter when initializing the SDK client instance. For example:
```python
from orq_ai_sdk import Orq
import os


with Orq(
    server_url="https://my.orq.ai",
    api_key=os.getenv("ORQ_API_KEY", ""),
) as orq:

    orq.post_v2_feedback_evaluation_remove()

    # Use the SDK ...

```
<!-- End Server Selection [server] -->

<!-- Start Custom HTTP Client [http-client] -->
## Custom HTTP Client

The Python SDK makes API calls using the [httpx](https://www.python-httpx.org/) HTTP library.  In order to provide a convenient way to configure timeouts, cookies, proxies, custom headers, and other low-level configuration, you can initialize the SDK client with your own HTTP client instance.
Depending on whether you are using the sync or async version of the SDK, you can pass an instance of `HttpClient` or `AsyncHttpClient` respectively, which are Protocol's ensuring that the client has the necessary methods to make API calls.
This allows you to wrap the client with your own custom logic, such as adding custom headers, logging, or error handling, or you can just pass an instance of `httpx.Client` or `httpx.AsyncClient` directly.

For example, you could specify a header for every request that this sdk makes as follows:
```python
from orq_ai_sdk import Orq
import httpx

http_client = httpx.Client(headers={"x-custom-header": "someValue"})
s = Orq(client=http_client)
```

or you could wrap the client with your own custom logic:
```python
from orq_ai_sdk import Orq
from orq_ai_sdk.httpclient import AsyncHttpClient
import httpx

class CustomClient(AsyncHttpClient):
    client: AsyncHttpClient

    def __init__(self, client: AsyncHttpClient):
        self.client = client

    async def send(
        self,
        request: httpx.Request,
        *,
        stream: bool = False,
        auth: Union[
            httpx._types.AuthTypes, httpx._client.UseClientDefault, None
        ] = httpx.USE_CLIENT_DEFAULT,
        follow_redirects: Union[
            bool, httpx._client.UseClientDefault
        ] = httpx.USE_CLIENT_DEFAULT,
    ) -> httpx.Response:
        request.headers["Client-Level-Header"] = "added by client"

        return await self.client.send(
            request, stream=stream, auth=auth, follow_redirects=follow_redirects
        )

    def build_request(
        self,
        method: str,
        url: httpx._types.URLTypes,
        *,
        content: Optional[httpx._types.RequestContent] = None,
        data: Optional[httpx._types.RequestData] = None,
        files: Optional[httpx._types.RequestFiles] = None,
        json: Optional[Any] = None,
        params: Optional[httpx._types.QueryParamTypes] = None,
        headers: Optional[httpx._types.HeaderTypes] = None,
        cookies: Optional[httpx._types.CookieTypes] = None,
        timeout: Union[
            httpx._types.TimeoutTypes, httpx._client.UseClientDefault
        ] = httpx.USE_CLIENT_DEFAULT,
        extensions: Optional[httpx._types.RequestExtensions] = None,
    ) -> httpx.Request:
        return self.client.build_request(
            method,
            url,
            content=content,
            data=data,
            files=files,
            json=json,
            params=params,
            headers=headers,
            cookies=cookies,
            timeout=timeout,
            extensions=extensions,
        )

s = Orq(async_client=CustomClient(httpx.AsyncClient()))
```
<!-- End Custom HTTP Client [http-client] -->

<!-- Start Resource Management [resource-management] -->
## Resource Management

The `Orq` class implements the context manager protocol and registers a finalizer function to close the underlying sync and async HTTPX clients it uses under the hood. This will close HTTP connections, release memory and free up other resources held by the SDK. In short-lived Python programs and notebooks that make a few SDK method calls, resource management may not be a concern. However, in longer-lived programs, it is beneficial to create a single SDK instance via a [context manager][context-manager] and reuse it across the application.

[context-manager]: https://docs.python.org/3/reference/datamodel.html#context-managers

```python
from orq_ai_sdk import Orq
import os
def main():

    with Orq(
        api_key=os.getenv("ORQ_API_KEY", ""),
    ) as orq:
        # Rest of application here...


# Or when using async:
async def amain():

    async with Orq(
        api_key=os.getenv("ORQ_API_KEY", ""),
    ) as orq:
        # Rest of application here...
```
<!-- End Resource Management [resource-management] -->

<!-- Start Debugging [debug] -->
## Debugging

You can setup your SDK to emit debug logs for SDK requests and responses.

You can pass your own logger class directly into your SDK.
```python
from orq_ai_sdk import Orq
import logging

logging.basicConfig(level=logging.DEBUG)
s = Orq(debug_logger=logging.getLogger("orq_ai_sdk"))
```

You can also enable a default debug logger by setting an environment variable `ORQ_DEBUG` to true.
<!-- End Debugging [debug] -->

<!-- Placeholder for Future Speakeasy SDK Sections -->

# Development

## Maturity

This SDK is in beta, and there may be breaking changes between versions without a major version update. Therefore, we recommend pinning usage
to a specific package version. This way, you can install the same version each time without breaking changes unless you are intentionally
looking for the latest version.

## Contributions

While we value open-source contributions to this SDK, this library is generated programmatically. Any manual changes added to internal files will be overwritten on the next generation. 
We look forward to hearing your feedback. Feel free to open a PR or an issue with a proof of concept and we'll do our best to include it in a future release. 

### SDK Created by [Speakeasy](https://www.speakeasy.com/?utm_source=orq-ai-sdk&utm_campaign=python)
