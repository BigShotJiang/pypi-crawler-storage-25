"""Public package interface for sc_excel_reader."""

from .sc_excel_reader import ExcelReader

__all__ = ["ExcelReader"]
