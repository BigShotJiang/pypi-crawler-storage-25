# Spello Consulting Excel Reader Library

This library provides functions for reading from Excel worksheets, ranges and tables.

Please see the [GitHub pages](https://nickelseyspelloc.github.io/sc-excel-reader/) for complete documentation.

## Development Environment

Note: If making changes to the sc-excel-reader library, use this command to sync in all the library dependencies including unit test and documentation tools:

```bash
uv sync --extra all
source .venv/bin/activate
```