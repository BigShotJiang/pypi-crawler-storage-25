"""Squirrel - Side Channel Analysis Toolbox."""

from .base import AnalysisResult, Analyzer, TraceDataset

__all__ = [
    "AnalysisResult",
    "Analyzer",
    "TraceDataset",
]
__version__ = "0.1.1-beta.2"
