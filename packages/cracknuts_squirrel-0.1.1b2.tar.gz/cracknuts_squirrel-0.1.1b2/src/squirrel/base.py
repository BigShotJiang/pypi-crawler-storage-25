"""Squirrel - Side Channel Analysis Toolbox."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import numpy as np


@dataclass
class AnalysisResult:
    """Base class for all analysis results."""

    method: str
    input_path: str
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class TraceDataset:
    """Container for trace data."""

    fixed_traces: np.ndarray | None = None
    random_traces: np.ndarray | None = None
    traces: np.ndarray | None = None
    labels: np.ndarray | None = None
    plaintext: np.ndarray | None = None
    key: np.ndarray | None = None
    ciphertext: np.ndarray | None = None


class Analyzer:
    """Base class for all side-channel analysis methods.

    Subclasses must implement:
    - analyze() method
    - detect_leakage_points() method (optional)
    """

    name: str = "base"
    description: str = "Base analyzer"

    def __init__(self, config: dict[str, Any] | None = None):
        self.config = config or {}
        self._validate_config()

    def _validate_config(self) -> None:
        """Validate analyzer configuration. Override in subclasses."""
        pass

    def analyze(
        self,
        traces: np.ndarray,
        labels: np.ndarray | None = None,
        plaintext: np.ndarray | None = None,
        key: np.ndarray | None = None,
        **kwargs,
    ) -> AnalysisResult:
        """Run analysis on traces.

        Args:
            traces: Trace data (num_traces, num_samples)
            labels: Trace labels (num_traces,)
            plaintext: Plaintext data
            key: Key data

        Returns:
            AnalysisResult subclass instance
        """
        raise NotImplementedError("Subclasses must implement analyze()")

    def detect_leakage_points(
        self,
        result: AnalysisResult,
        threshold: float | None = None,
    ) -> np.ndarray:
        """Detect leakage points from analysis result.

        Args:
            result: Analysis result
            threshold: Detection threshold

        Returns:
            Array of leakage point indices
        """
        raise NotImplementedError("Subclasses must implement detect_leakage_points()")

    @staticmethod
    def load_traces(path: str | Path, format: str = "zarr") -> TraceDataset:
        """Load traces from file.

        Args:
            path: Input file path
            format: File format (zarr, npz, ets, h5)

        Returns:
            TraceDataset
        """
        raise NotImplementedError("load_traces not implemented")

    @staticmethod
    def save_traces(
        dataset: TraceDataset,
        path: str | Path,
        format: str = "zarr",
    ) -> Path:
        """Save traces to file.

        Args:
            dataset: TraceDataset to save
            path: Output file path
            format: Output format

        Returns:
            Output path
        """
        raise NotImplementedError("save_traces not implemented")


__all__ = [
    "AnalysisResult",
    "Analyzer",
    "TraceDataset",
]
