from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np
import scipy as sp

from squirrel.base import AnalysisResult, Analyzer


@dataclass
class CrossCorrVerificationResult:
    std_reduction: float = 0.0
    corr_improvement: float = 0.0
    var_reduction: float = 0.0
    passed: bool = False


@dataclass
class ShiftVerificationResult:
    estimated_shifts: np.ndarray | None = None
    ground_truth_shifts: np.ndarray | None = None
    mae: float = 0.0
    passed: bool = False


@dataclass
class CrossCorrResult(AnalysisResult):
    ref_trace_idx: int = 0
    window: tuple[int, int] = (0, 0)
    num_traces: int = 0
    num_aligned: int = 0
    num_rejected: int = 0
    mean_shift: float = 0.0
    metadata: dict = field(default_factory=dict)


class ResyncCrossCorrAligner(Analyzer):
    name: str = "resync_crosscorr"
    description: str = "Resync traces by cross-correlation"

    def __init__(
        self,
        config: dict | None = None,
        ref_trace_idx: int = 0,
        window: tuple[int, int] = (0, 0),
    ):
        config = config or {}
        config.setdefault("ref_trace_idx", ref_trace_idx)
        config.setdefault("window", window)
        super().__init__(config)
        self._ref_window: np.ndarray | None = None
        self._ref_max_loc: int = 0

    @property
    def ref_trace_idx(self) -> int:
        return self.config.get("ref_trace_idx", 0)

    @property
    def window(self) -> tuple[int, int]:
        return self.config.get("window", (0, 0))

    @window.setter
    def window(self, value: tuple[int, int]) -> None:
        self.config["window"] = value

    def _calculate_ref(self, traces: np.ndarray) -> None:
        start, end = self.window
        if end <= start:
            start, end = 450, 550

        ref_trace = traces[self.ref_trace_idx]
        self._ref_window = ref_trace[start:end]
        self._ref_max_loc = np.argmax(self._ref_window)

    def _align_trace(self, trace: np.ndarray) -> tuple[np.ndarray | None, int]:
        if self._ref_window is None:
            return trace, 0

        start, end = self.window
        if end <= start:
            start, end = 450, 550
        trace_segment = trace[start:end]
        trace_max_loc = start + np.argmax(trace_segment)
        ref_max_loc = start + np.argmax(self._ref_window)

        shift = ref_max_loc - trace_max_loc
        shift = np.clip(shift, -50, 50)

        if shift > 0:
            aligned = np.concatenate([np.zeros(shift), trace[:-shift]])
        elif shift < 0:
            aligned = np.concatenate([trace[-shift:], np.zeros(-shift)])
        else:
            aligned = trace

        return aligned, shift

    def analyze(
        self,
        traces: np.ndarray,
        labels: np.ndarray | None = None,
        plaintext: np.ndarray | None = None,
        key: np.ndarray | None = None,
        **kwargs,
    ) -> CrossCorrResult:
        input_path = kwargs.get("input_path", "")

        if not self.window or self.window[1] <= self.window[0]:
            self.window = (0, traces.shape[1])

        self._calculate_ref(traces)

        aligned_traces = np.zeros_like(traces)
        num_aligned = 0
        shifts = []

        for i in range(traces.shape[0]):
            aligned, shift = self._align_trace(traces[i])
            shifts.append(shift)
            aligned_traces[i] = aligned
            num_aligned += 1

        mean_shift = float(np.mean([s for s in shifts if s != 0])) if shifts else 0.0

        return CrossCorrResult(
            method="resync_crosscorr",
            input_path=input_path,
            ref_trace_idx=self.ref_trace_idx,
            window=self.window,
            num_traces=traces.shape[0],
            num_aligned=num_aligned,
            num_rejected=0,
            mean_shift=mean_shift,
            metadata={
                "aligned_traces": aligned_traces,
                "shifts": shifts,
            },
        )

    def detect_leakage_points(
        self,
        result: CrossCorrResult,
        threshold: float | None = None,
    ) -> np.ndarray:
        return np.array([])

    @staticmethod
    def load_traces(path, format="zarr"):
        import zarr

        if format != "zarr":
            raise ValueError(f"Unsupported format: {format}")

        z = zarr.open(str(path), "r")
        return z["/0/0/traces"][:]

    @staticmethod
    def save_traces(traces: np.ndarray, path, format="zarr"):
        import zarr

        if format != "zarr":
            raise ValueError(f"Unsupported format: {format}")

        z = zarr.open(str(path), mode="w")
        z.create_dataset("/0/0/traces", data=traces)
        return path

    def verify(
        self,
        original: np.ndarray,
        aligned: np.ndarray,
        ref_trace_idx: int | None = None,
    ) -> CrossCorrVerificationResult:
        if ref_trace_idx is None:
            ref_trace_idx = self.ref_trace_idx

        ref_trace = aligned[ref_trace_idx]

        orig_std = np.std(original)
        aligned_std = np.std(aligned)
        std_reduction = (orig_std - aligned_std) / orig_std * 100 if orig_std > 0 else 0

        orig_corrs = []
        aligned_corrs = []
        for i in range(original.shape[0]):
            if i != ref_trace_idx:
                orig_corrs.append(np.corrcoef(original[i], original[ref_trace_idx])[0, 1])
                aligned_corrs.append(np.corrcoef(aligned[i], ref_trace)[0, 1])
        orig_corr = np.mean(orig_corrs) if orig_corrs else 0
        aligned_corr = np.mean(aligned_corrs) if aligned_corrs else 0
        corr_improvement = aligned_corr - orig_corr

        orig_var = np.var(original)
        aligned_var = np.var(aligned)
        var_reduction = (orig_var - aligned_var) / orig_var * 100 if orig_var > 0 else 0

        passed = std_reduction > 0 and corr_improvement > 0

        return CrossCorrVerificationResult(
            std_reduction=std_reduction,
            corr_improvement=corr_improvement,
            var_reduction=var_reduction,
            passed=passed,
        )

    def verify_shifts(
        self,
        original: np.ndarray,
        aligned: np.ndarray,
        ground_truth_shifts: np.ndarray,
        ref_trace_idx: int | None = None,
    ) -> ShiftVerificationResult:
        if ref_trace_idx is None:
            ref_trace_idx = self.ref_trace_idx

        start, end = self.window
        if end <= start:
            end = original.shape[1]

        ref_trace_window = original[ref_trace_idx, start:end]
        ref_trace_reversed = ref_trace_window[::-1]

        estimated_shifts = []

        for i in range(original.shape[0]):
            if i == ref_trace_idx:
                estimated_shifts.append(0)
                continue

            cross_orig = sp.signal.correlate(original[i], ref_trace_reversed, mode="valid")
            cross_align = sp.signal.correlate(aligned[i], ref_trace_reversed, mode="valid")

            orig_peak = np.argmax(cross_orig)
            align_peak = np.argmax(cross_align)

            shift = align_peak - orig_peak
            estimated_shifts.append(shift)

        estimated_shifts = np.array(estimated_shifts)
        gt = ground_truth_shifts.copy()
        gt[ref_trace_idx] = 0

        mae = np.mean(np.abs(estimated_shifts - gt))

        return ShiftVerificationResult(
            estimated_shifts=estimated_shifts,
            ground_truth_shifts=ground_truth_shifts,
            mae=mae,
            passed=mae < 5.0,
        )

    def print_verification(self, result: CrossCorrVerificationResult) -> None:
        status = "PASS" if result.passed else "FAIL"
        print(f"  [{status}] Variance Reduction: {result.std_reduction:.2f}%")
        print(f"       Correlation Improvement: {result.corr_improvement:.4f}")
        print(f"       Std Reduction: {result.var_reduction:.2f}%")

    def print_shift_verification(self, result: ShiftVerificationResult) -> None:
        status = "PASS" if result.passed else "FAIL"
        print(f"  [{status}] Shift MAE: {result.mae:.2f} samples")


__all__ = [
    "ResyncCrossCorrAligner",
    "CrossCorrResult",
    "CrossCorrVerificationResult",
    "ShiftVerificationResult",
]