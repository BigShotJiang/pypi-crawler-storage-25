from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

from squirrel.base import AnalysisResult, Analyzer


@dataclass
class ResyncZCVerificationResult:
    std_reduction: float = 0.0
    corr_improvement: float = 0.0
    var_reduction: float = 0.0
    passed: bool = False


@dataclass
class ZCVerificationResult:
    num_zc_points: int = 0
    original_zc_variance: float = 0.0
    aligned_zc_variance: float = 0.0
    variance_reduction_percent: float = 0.0
    passed: bool = False


@dataclass
class ResyncZCResult(AnalysisResult):
    ref_trace_idx: int = 0
    zc_level: float = 0.0
    bin_length: int = 0
    num_traces: int = 0
    num_aligned: int = 0
    num_rejected: int = 0
    num_zc_points: int = 0
    metadata: dict = field(default_factory=dict)


class ResyncZCAligner(Analyzer):
    """Zero-Crossing Based Trace Aligner.

    Resamples traces based on zero-crossing detection. Each segment between
    zero-crossings is resampled to a target bin length for alignment.
    """

    name: str = "resync_zc"
    description: str = "Align traces by zero-crossing detection and resampling"

    def __init__(
        self,
        config: dict | None = None,
        ref_trace_idx: int = 0,
        zc_level: float = 0.0,
        bin_length: int = 0,
    ):
        config = config or {}
        config.setdefault("ref_trace_idx", ref_trace_idx)
        config.setdefault("zc_level", zc_level)
        config.setdefault("bin_length", bin_length)
        super().__init__(config)
        self._ref_zc_indices: np.ndarray = np.array([])
        self._ref_zc_loc: int = 0
        self._ref_bin_length: int = bin_length

    @property
    def ref_trace_idx(self) -> int:
        return self.config.get("ref_trace_idx", 0)

    @property
    def zc_level(self) -> float:
        return self.config.get("zc_level", 0.0)

    @property
    def bin_length(self) -> int:
        return self.config.get("bin_length", 0)

    @bin_length.setter
    def bin_length(self, value: int) -> None:
        self.config["bin_length"] = value

    def _find_zerocrossing(self, a: np.ndarray) -> np.ndarray:
        shifted = a - self.zc_level
        return np.nonzero((shifted[1:] >= 0) & (shifted[:-1] < 0))[0]

    def _find_avg_bin_length(self, indices: np.ndarray) -> int:
        if len(indices) < 2:
            return 100
        diffs = np.diff(indices)
        return int(np.mean(diffs))

    def _resample_segment(self, data: np.ndarray, indices: np.ndarray, targlen: int) -> np.ndarray:
        if len(indices) < 2:
            return data

        targlen = max(1, targlen)
        result = np.zeros(targlen * (len(indices) - 1))

        for i in range(1, len(indices)):
            segment = data[indices[i - 1]:indices[i]]
            if len(segment) > 0:
                resampled = np.interp(
                    np.linspace(0, len(segment) - 1, targlen),
                    np.arange(len(segment)),
                    segment
                )
                result[(i - 1) * targlen:i * targlen] = resampled

        return result

    def _calculate_ref(self, traces: np.ndarray) -> None:
        ref_trace = traces[self.ref_trace_idx] - self.zc_level
        self._ref_zc_indices = self._find_zerocrossing(ref_trace)

        if self.bin_length == 0:
            self._ref_bin_length = self._find_avg_bin_length(self._ref_zc_indices)
        else:
            self._ref_bin_length = self.bin_length

    def _align_trace(self, trace: np.ndarray) -> tuple[np.ndarray | None, int]:
        shifted = trace - self.zc_level
        zc_indices = self._find_zerocrossing(shifted)

        if len(zc_indices) < 2:
            return trace, 0

        if self.bin_length > 0:
            resampled = self._resample_segment(shifted, zc_indices, self._ref_bin_length)
            return resampled, 0
        else:
            if len(zc_indices) == 0:
                return trace, 0
            trace_zc_loc = zc_indices[0]
            ref_zc_loc = self._ref_zc_indices[0] if len(self._ref_zc_indices) > 0 else 0
            shift = ref_zc_loc - trace_zc_loc

            if shift > 0:
                aligned = np.concatenate([np.zeros(shift), trace[:-shift]])
            elif shift < 0:
                aligned = np.concatenate([trace[-shift:], np.zeros(-shift)])
            else:
                aligned = trace

            return aligned, shift

    def analyze(
        self,
        traces: np.ndarray,
        labels: np.ndarray | None = None,
        plaintext: np.ndarray | None = None,
        key: np.ndarray | None = None,
        **kwargs,
    ) -> ResyncZCResult:
        input_path = kwargs.get("input_path", "")

        self._calculate_ref(traces)

        aligned_traces = []
        num_aligned = 0
        shifts = []

        for i in range(traces.shape[0]):
            aligned, shift = self._align_trace(traces[i])
            aligned_traces.append(aligned)
            shifts.append(shift)
            num_aligned += 1

        aligned_traces = np.array(aligned_traces, dtype=np.float32)
        num_zc_points = len(self._ref_zc_indices)

        return ResyncZCResult(
            method="resync_zc",
            input_path=input_path,
            ref_trace_idx=self.ref_trace_idx,
            zc_level=self.zc_level,
            bin_length=self.bin_length,
            num_traces=traces.shape[0],
            num_aligned=num_aligned,
            num_rejected=0,
            num_zc_points=num_zc_points,
            metadata={
                "aligned_traces": aligned_traces,
                "shifts": shifts,
            },
        )

    def detect_leakage_points(
        self,
        result: ResyncZCResult,
        threshold: float | None = None,
    ) -> np.ndarray:
        return np.array([])

    @staticmethod
    def load_traces(path, format="zarr"):
        import zarr

        if format != "zarr":
            raise ValueError(f"Unsupported format: {format}")

        z = zarr.open(str(path), "r")
        return z["/0/0/traces"][:]

    @staticmethod
    def save_traces(traces: np.ndarray, path, format="zarr"):
        import zarr

        if format != "zarr":
            raise ValueError(f"Unsupported format: {format}")

        z = zarr.open(str(path), mode="w")
        z.create_dataset("/0/0/traces", data=traces)
        return path

    def verify(
        self,
        original: np.ndarray,
        aligned: np.ndarray,
        ref_trace_idx: int | None = None,
    ) -> ResyncZCVerificationResult:
        if ref_trace_idx is None:
            ref_trace_idx = self.ref_trace_idx

        ref_trace = aligned[ref_trace_idx]

        orig_std = np.std(original)
        aligned_std = np.std(aligned)
        std_reduction = (orig_std - aligned_std) / orig_std * 100 if orig_std > 0 else 0

        orig_corrs = []
        aligned_corrs = []
        for i in range(original.shape[0]):
            if i != ref_trace_idx:
                orig_corrs.append(np.corrcoef(original[i], original[ref_trace_idx])[0, 1])
                aligned_corrs.append(np.corrcoef(aligned[i], ref_trace)[0, 1])
        orig_corr = np.mean(orig_corrs) if orig_corrs else 0
        aligned_corr = np.mean(aligned_corrs) if aligned_corrs else 0
        corr_improvement = aligned_corr - orig_corr

        orig_var = np.var(original)
        aligned_var = np.var(aligned)
        var_reduction = (orig_var - aligned_var) / orig_var * 100 if orig_var > 0 else 0

        passed = std_reduction > 0 and corr_improvement > 0

        return ResyncZCVerificationResult(
            std_reduction=std_reduction,
            corr_improvement=corr_improvement,
            var_reduction=var_reduction,
            passed=passed,
        )

    def verify_zc_variance(
        self,
        original: np.ndarray,
        aligned: np.ndarray,
        ref_trace_idx: int | None = None,
    ) -> ZCVerificationResult:
        if ref_trace_idx is None:
            ref_trace_idx = self.ref_trace_idx

        ref_trace = original[ref_trace_idx] - self.zc_level
        zc_indices = self._find_zerocrossing(ref_trace)

        if len(zc_indices) == 0:
            return ZCVerificationResult(passed=False)

        window = 5
        orig_variances = []
        align_variances = []

        for idx in zc_indices:
            v_start = max(0, idx - window)
            v_end = min(original.shape[1], idx + window)
            orig_variances.append(np.var(original[:, v_start:v_end]))
            align_variances.append(np.var(aligned[:, v_start:v_end]))

        orig_zc_var = float(np.mean(orig_variances))
        align_zc_var = float(np.mean(align_variances))
        var_reduction = (orig_zc_var - align_zc_var) / orig_zc_var * 100 if orig_zc_var > 0 else 0

        passed = var_reduction > 0

        return ZCVerificationResult(
            num_zc_points=len(zc_indices),
            original_zc_variance=orig_zc_var,
            aligned_zc_variance=align_zc_var,
            variance_reduction_percent=var_reduction,
            passed=passed,
        )

    def print_verification(self, result: ResyncZCVerificationResult) -> None:
        status = "PASS" if result.passed else "FAIL"
        print(f"  [{status}] Variance Reduction: {result.std_reduction:.2f}%")
        print(f"       Correlation Improvement: {result.corr_improvement:.4f}")
        print(f"       Std Reduction: {result.var_reduction:.2f}%")


__all__ = [
    "ResyncZCAligner",
    "ResyncZCResult",
    "ResyncZCVerificationResult",
    "ZCVerificationResult",
]