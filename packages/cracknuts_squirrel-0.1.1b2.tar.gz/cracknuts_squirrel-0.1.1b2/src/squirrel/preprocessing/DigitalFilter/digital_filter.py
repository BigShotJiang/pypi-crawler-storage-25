"""Digital Filter - Frequency-specific filtering for trace preprocessing.

Based on ChipWhisperer's Digital Filter preprocessing module.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Literal

import numpy as np
from scipy import signal

from squirrel.base import AnalysisResult, Analyzer


@dataclass
class FilterResult(AnalysisResult):
    """Result from digital filtering."""

    filter_type: str = "low"
    freq1: float = 0.1
    freq2: float = 0.8
    order: int = 5
    num_traces: int = 0
    metadata: dict = field(default_factory=dict)


@dataclass
class FilterVerificationResult:
    """Verification result for digital filtering."""

    input_std: float = 0.0
    output_std: float = 0.0
    std_reduction_percent: float = 0.0
    input_power: float = 0.0
    output_power: float = 0.0
    power_reduction_percent: float = 0.0
    passed: bool = False


class DigitalFilter(Analyzer):
    """Digital filter using Butterworth filter from SciPy.

    Supports:
    - low: Low-pass filter (pass signals below freq1)
    - high: High-pass filter (pass signals above freq1)
    - bandpass: Band-pass filter (pass signals between freq1 and freq2)
    - bandstop: Band-stop/notch filter (stop signals between freq1 and freq2)

    Frequency values are normalized to [0, 1] where 1 = Nyquist frequency.
    """

    name: str = "digital_filter"
    description: str = "Frequency-specific digital filter using Butterworth design"

    valid_types: list[str] = ["low", "high", "bandpass", "bandstop"]

    def __init__(
        self,
        config: dict[str, Any] | None = None,
        filter_type: str = "low",
        freq1: float = 0.1,
        freq2: float = 0.8,
        order: int = 5,
    ):
        config = config or {}
        config.setdefault("filter_type", filter_type)
        config.setdefault("freq1", freq1)
        config.setdefault("freq2", freq2)
        config.setdefault("order", order)
        super().__init__(config)

        self.b = None
        self.a = None
        self._update_filter_coeffs()

    def _update_filter_coeffs(self) -> None:
        """Design the Butterworth filter based on current parameters."""
        ftype = self.filter_type
        freq1 = self.freq1
        freq2 = self.freq2
        order = self.order

        # Determine frequencies based on filter type
        if ftype in ("bandpass", "bandstop"):
            freqs = (freq1, freq2)
        else:
            freqs = freq1

        # Design Butterworth filter
        self.b, self.a = signal.butter(order, freqs, ftype)

    @property
    def filter_type(self) -> str:
        return self.config.get("filter_type", "low")

    @filter_type.setter
    def filter_type(self, value: str) -> None:
        if value not in self.valid_types:
            raise ValueError(f"filter_type must be one of {self.valid_types}")
        self.config["filter_type"] = value
        self._update_filter_coeffs()

    @property
    def freq1(self) -> float:
        return self.config.get("freq1", 0.1)

    @freq1.setter
    def freq1(self, value: float) -> None:
        if not 0 < value < 1:
            raise ValueError("freq1 must be in range (0, 1)")
        self.config["freq1"] = value
        self._update_filter_coeffs()

    @property
    def freq2(self) -> float:
        return self.config.get("freq2", 0.8)

    @freq2.setter
    def freq2(self, value: float) -> None:
        if not 0 < value < 1:
            raise ValueError("freq2 must be in range (0, 1)")
        self.config["freq2"] = value
        self._update_filter_coeffs()

    @property
    def order(self) -> int:
        return self.config.get("order", 5)

    @order.setter
    def order(self, value: int) -> None:
        if value < 1 or value > 32:
            raise ValueError("order must be in range [1, 32]")
        self.config["order"] = value
        self._update_filter_coeffs()

    def analyze(
        self,
        traces: np.ndarray,
        labels: np.ndarray | None = None,
        **kwargs,
    ) -> FilterResult:
        """Apply digital filter to traces.

        Args:
            traces: Trace data (num_traces, num_samples)
            labels: Not used

        Returns:
            FilterResult
        """
        input_path = kwargs.get("input_path", "")

        filtered_traces = np.zeros_like(traces)

        for i in range(traces.shape[0]):
            filtered_traces[i] = signal.lfilter(self.b, self.a, traces[i])

        return FilterResult(
            method="digital_filter",
            input_path=input_path,
            filter_type=self.filter_type,
            freq1=self.freq1,
            freq2=self.freq2,
            order=self.order,
            num_traces=traces.shape[0],
            metadata={
                "filtered_traces": filtered_traces,
                "b": self.b,
                "a": self.a,
            },
        )

    def verify(
        self,
        original: np.ndarray,
        filtered: np.ndarray,
    ) -> FilterVerificationResult:
        """Verify filtering effectiveness.

        Args:
            original: Original traces before filtering
            filtered: Traces after filtering

        Returns:
            FilterVerificationResult with metrics
        """
        input_std = float(np.std(original))
        output_std = float(np.std(filtered))
        std_reduction = (input_std - output_std) / input_std * 100 if input_std > 0 else 0

        input_power = float(np.mean(original**2))
        output_power = float(np.mean(filtered**2))
        power_reduction = (input_power - output_power) / input_power * 100 if input_power > 0 else 0

        # For low-pass filter, expect reduced std (noise filtering)
        # For high-pass filter, expect some std increase (removing DC)
        # For bandstop, expect reduced power (removing frequency band)
        passed = std_reduction > 0 or power_reduction > 0

        return FilterVerificationResult(
            input_std=input_std,
            output_std=output_std,
            std_reduction_percent=std_reduction,
            input_power=input_power,
            output_power=output_power,
            power_reduction_percent=power_reduction,
            passed=passed,
        )

    def detect_leakage_points(
        self,
        result: FilterResult,
        threshold: float | None = None,
    ) -> np.ndarray:
        """Not applicable for digital filter."""
        return np.array([])

    @staticmethod
    def load_traces(path, format="zarr"):
        """Load traces from zarr."""
        import zarr

        if format != "zarr":
            raise ValueError(f"Unsupported format: {format}")

        z = zarr.open(str(path), "r")
        return z["/0/0/traces"][:]

    @staticmethod
    def save_traces(traces: np.ndarray, path, format="zarr"):
        """Save traces to zarr."""
        import zarr

        if format != "zarr":
            raise ValueError(f"Unsupported format: {format}")

        z = zarr.open(str(path), mode="w")
        z.create_dataset("/0/0/traces", data=traces)
        return path

    def print_verification(self, result: FilterVerificationResult) -> None:
        """Print verification result."""
        status = "PASS" if result.passed else "FAIL"
        print(f"  [{status}] Std Reduction: {result.std_reduction_percent:.2f}%")
        print(f"       Power Reduction: {result.power_reduction_percent:.2f}%")


__all__ = [
    "DigitalFilter",
    "FilterResult",
    "FilterVerificationResult",
]
