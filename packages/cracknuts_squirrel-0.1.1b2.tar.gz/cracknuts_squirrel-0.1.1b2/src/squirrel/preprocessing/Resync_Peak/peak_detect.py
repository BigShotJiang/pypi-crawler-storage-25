"""Resync Peak Detect - Align traces based on peak detection.

Based on ChipWhisperer's ResyncPeakDetect.
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

from squirrel.base import AnalysisResult, Analyzer


@dataclass
class ResyncVerificationResult:
    std_reduction: float = 0.0
    corr_improvement: float = 0.0
    var_reduction: float = 0.0
    passed: bool = False


@dataclass
class ShiftVerificationResult:
    estimated_shifts: np.ndarray | None = None
    ground_truth_shifts: np.ndarray | None = None
    mae: float = 0.0
    passed: bool = False


@dataclass
class PeakVerificationResult:
    ref_peak_idx: int = 0
    ground_truth_shifts: np.ndarray | None = None
    original_peak_offsets: np.ndarray | None = None
    aligned_peak_offsets: np.ndarray | None = None
    original_offset_mean: float = 0.0
    original_offset_std: float = 0.0
    aligned_offset_mean: float = 0.0
    aligned_offset_std: float = 0.0
    alignment_accuracy_percent: float = 0.0
    passed: bool = False


@dataclass
class ResyncResult(AnalysisResult):
    """Result from resync peak detection."""

    ref_trace_idx: int = 0
    peak_type: str = "max"
    peak_range: tuple[int, int] = (0, 0)
    valid_limit: float = 0.0
    num_traces: int = 0
    num_aligned: int = 0
    num_rejected: int = 0
    mean_shift: float = 0.0
    metadata: dict = field(default_factory=dict)


class ResyncPeakDetector(Analyzer):
    """Resync based on peak value.

    Line up traces so peak (either max positive or max negative) within
    some given range of points all aligns. For each trace the following must hold
    or the trace is rejected:
        (1-valid limit) < (peak value from candidate trace) / (peak value from reference) < (1+valid limit)
    If 'valid limit' is 0, this is ignored and all traces are kept.
    """

    name: str = "resync_peak"
    description: str = "Resync traces by peak detection"

    def __init__(
        self,
        config: dict | None = None,
        ref_trace_idx: int = 0,
        peak_type: str = "max",
        peak_range: tuple[int, int] = (0, 0),
        valid_limit: float = 0.0,
    ):
        config = config or {}
        config.setdefault("ref_trace_idx", ref_trace_idx)
        config.setdefault("peak_type", peak_type)
        config.setdefault("peak_range", peak_range)
        config.setdefault("valid_limit", valid_limit)
        super().__init__(config)
        self._ref_peak_loc: int = 0
        self._ref_peak_size: float = 0.0

    @property
    def ref_trace_idx(self) -> int:
        return self.config.get("ref_trace_idx", 0)

    @property
    def peak_type(self) -> str:
        return self.config.get("peak_type", "max")

    @property
    def peak_range(self) -> tuple[int, int]:
        return self.config.get("peak_range", (0, 0))

    @property
    def valid_limit(self) -> float:
        return self.config.get("valid_limit", 0.0)

    @peak_range.setter
    def peak_range(self, value: tuple[int, int]) -> None:
        self.config["peak_range"] = value

    def _validate_config(self) -> None:
        if self.peak_type not in ("max", "min"):
            raise ValueError(f"peak_type must be 'max' or 'min'")

    def _calculate_ref(self, traces: np.ndarray) -> None:
        """Calculate reference peak from reference trace."""
        start, end = self.peak_range
        ref_trace = traces[self.ref_trace_idx, start:end]

        if self.peak_type == "max":
            self._ref_peak_loc = np.argmax(ref_trace)
            self._ref_peak_size = float(max(ref_trace))
        else:
            self._ref_peak_loc = np.argmin(ref_trace)
            self._ref_peak_size = float(min(ref_trace))

    def _align_trace(self, trace: np.ndarray) -> tuple[np.ndarray | None, int]:
        """Align single trace and return (aligned_trace, shift)."""
        start, end = self.peak_range

        if self.peak_type == "max":
            peak_loc = np.argmax(trace[start:end])
            peak_val = float(max(trace[start:end]))
        else:
            peak_loc = np.argmin(trace[start:end])
            peak_val = float(min(trace[start:end]))

        if self.valid_limit > 0:
            if peak_val > self._ref_peak_size * (1.0 + self.valid_limit) or peak_val < self._ref_peak_size * (1.0 - self.valid_limit):
                return None, 0

        shift = self._ref_peak_loc - peak_loc

        if shift > 0:
            aligned = np.concatenate([np.zeros(shift), trace[:-shift]])
        elif shift < 0:
            aligned = np.concatenate([trace[-shift:], np.zeros(-shift)])
        else:
            aligned = trace

        return aligned, shift

    def analyze(
        self,
        traces: np.ndarray,
        labels: np.ndarray | None = None,
        plaintext: np.ndarray | None = None,
        key: np.ndarray | None = None,
        **kwargs,
    ) -> ResyncResult:
        """Align traces based on peak detection.

        Args:
            traces: Trace data (num_traces, num_samples)
            labels: Not used
            plaintext: Not used
            key: Not used
            **kwargs: Additional options

        Returns:
            ResyncResult
        """
        input_path = kwargs.get("input_path", "")

        if not self.peak_range or self.peak_range[1] <= self.peak_range[0]:
            start, end = 0, traces.shape[1]
            self.peak_range = (start, end)
        else:
            start, end = self.peak_range

        self._calculate_ref(traces)

        aligned_traces = np.zeros_like(traces)
        num_aligned = 0
        num_rejected = 0
        shifts = []

        for i in range(traces.shape[0]):
            aligned, shift = self._align_trace(traces[i])
            shifts.append(shift)
            if aligned is not None:
                aligned_traces[i] = aligned
                num_aligned += 1
            else:
                aligned_traces[i] = traces[i]
                num_rejected += 1

        mean_shift = float(np.mean([s for s in shifts if s != 0])) if shifts else 0.0

        return ResyncResult(
            method="resync_peak",
            input_path=input_path,
            ref_trace_idx=self.ref_trace_idx,
            peak_type=self.peak_type,
            peak_range=self.peak_range,
            valid_limit=self.valid_limit,
            num_traces=traces.shape[0],
            num_aligned=num_aligned,
            num_rejected=num_rejected,
            mean_shift=mean_shift,
            metadata={
                "aligned_traces": aligned_traces,
                "shifts": shifts,
            },
        )

    def detect_leakage_points(
        self,
        result: ResyncResult,
        threshold: float | None = None,
    ) -> np.ndarray:
        """Not applicable for resync."""
        return np.array([])

    @staticmethod
    def load_traces(path, format="zarr"):
        """Load traces from zarr."""
        import zarr

        if format != "zarr":
            raise ValueError(f"Unsupported format: {format}")

        z = zarr.open(str(path), "r")
        return z["/0/0/traces"][:]

    @staticmethod
    def save_traces(traces: np.ndarray, path, format="zarr"):
        """Save traces to zarr."""
        import zarr

        if format != "zarr":
            raise ValueError(f"Unsupported format: {format}")

        z = zarr.open(str(path), mode="w")
        z.create_dataset("/0/0/traces", data=traces)
        return path

    def verify(
        self,
        original: np.ndarray,
        aligned: np.ndarray,
        ref_trace_idx: int | None = None,
    ) -> ResyncVerificationResult:
        if ref_trace_idx is None:
            ref_trace_idx = self.ref_trace_idx

        ref_trace = aligned[ref_trace_idx]

        orig_std = np.std(original)
        aligned_std = np.std(aligned)
        std_reduction = (orig_std - aligned_std) / orig_std * 100 if orig_std > 0 else 0

        orig_corrs = []
        aligned_corrs = []
        for i in range(original.shape[0]):
            if i != ref_trace_idx:
                orig_corrs.append(np.corrcoef(original[i], original[ref_trace_idx])[0, 1])
                aligned_corrs.append(np.corrcoef(aligned[i], ref_trace)[0, 1])
        orig_corr = np.mean(orig_corrs) if orig_corrs else 0
        aligned_corr = np.mean(aligned_corrs) if aligned_corrs else 0
        corr_improvement = aligned_corr - orig_corr

        orig_var = np.var(original)
        aligned_var = np.var(aligned)
        var_reduction = (orig_var - aligned_var) / orig_var * 100 if orig_var > 0 else 0

        passed = std_reduction > 0 and corr_improvement > 0

        return ResyncVerificationResult(
            std_reduction=std_reduction,
            corr_improvement=corr_improvement,
            var_reduction=var_reduction,
            passed=passed,
        )

    def verify_shifts(
        self,
        original: np.ndarray,
        aligned: np.ndarray,
        ground_truth_shifts: np.ndarray,
        ref_trace_idx: int | None = None,
    ) -> ShiftVerificationResult:
        if ref_trace_idx is None:
            ref_trace_idx = self.ref_trace_idx

        start, end = self.peak_range
        estimated_shifts = []

        for i in range(original.shape[0]):
            if self.peak_type == "max":
                orig_peak = np.argmax(original[i, start:end])
                align_peak = np.argmax(aligned[i, start:end])
            else:
                orig_peak = np.argmin(original[i, start:end])
                align_peak = np.argmin(aligned[i, start:end])

            shift = align_peak - orig_peak
            estimated_shifts.append(shift)

        estimated_shifts = np.array(estimated_shifts)
        gt = ground_truth_shifts.copy()
        gt[ref_trace_idx] = 0

        mae = np.mean(np.abs(estimated_shifts - gt))

        return ShiftVerificationResult(
            estimated_shifts=estimated_shifts,
            ground_truth_shifts=ground_truth_shifts,
            mae=mae,
            passed=mae < 5.0,
        )

    def verify_peaks(
        self,
        original: np.ndarray,
        aligned: np.ndarray,
        ground_truth_shifts: np.ndarray | None = None,
        ref_trace_idx: int | None = None,
    ) -> PeakVerificationResult:
        if ref_trace_idx is None:
            ref_trace_idx = self.ref_trace_idx

        start, end = self.peak_range

        ref_trace = original[ref_trace_idx]
        if self.peak_type == "max":
            ref_peak_idx = np.argmax(ref_trace[start:end])
        else:
            ref_peak_idx = np.argmin(ref_trace[start:end])

        orig_peaks = []
        align_peaks = []
        for i in range(original.shape[0]):
            if self.peak_type == "max":
                orig_peaks.append(np.argmax(original[i, start:end]))
                align_peaks.append(np.argmax(aligned[i, start:end]))
            else:
                orig_peaks.append(np.argmin(original[i, start:end]))
                align_peaks.append(np.argmin(aligned[i, start:end]))

        orig_peaks = np.array(orig_peaks)
        align_peaks = np.array(align_peaks)

        orig_offsets = orig_peaks - ref_peak_idx
        align_offsets = align_peaks - ref_peak_idx

        orig_offset_mean = float(np.mean(np.abs(orig_offsets)))
        orig_offset_std = float(np.std(orig_offsets))
        align_offset_mean = float(np.mean(np.abs(align_offsets)))
        align_offset_std = float(np.std(align_offsets))

        tolerance = 5
        aligned_count = np.sum(np.abs(align_offsets) <= tolerance)
        alignment_accuracy_percent = aligned_count / len(align_offsets) * 100

        passed = alignment_accuracy_percent > 90.0

        return PeakVerificationResult(
            ref_peak_idx=ref_peak_idx,
            ground_truth_shifts=ground_truth_shifts,
            original_peak_offsets=orig_offsets,
            aligned_peak_offsets=align_offsets,
            original_offset_mean=orig_offset_mean,
            original_offset_std=orig_offset_std,
            aligned_offset_mean=align_offset_mean,
            aligned_offset_std=align_offset_std,
            alignment_accuracy_percent=alignment_accuracy_percent,
            passed=passed,
        )

    def print_verification(self, result: ResyncVerificationResult) -> None:
        """Print verification result."""
        status = "PASS" if result.passed else "FAIL"
        print(f"  [{status}] Variance Reduction: {result.std_reduction:.2f}%")
        print(f"       Correlation Improvement: {result.corr_improvement:.4f}")
        print(f"       Std Reduction: {result.var_reduction:.2f}%")

    def print_shift_verification(self, result: ShiftVerificationResult) -> None:
        """Print shift verification result."""
        status = "PASS" if result.passed else "FAIL"
        print(f"  [{status}] Shift MAE: {result.mae:.2f} samples")

    def print_peak_verification(self, result: PeakVerificationResult, tolerance: int = 5) -> None:
        """Print peak verification result with detailed table."""
        GREEN = "\033[32m"
        RED = "\033[31m"
        RESET = "\033[0m"

        status = f"{GREEN}PASS{RESET}" if result.passed else f"{RED}FAIL{RESET}"

        print("\n=== Peak Position Verification ===\n")
        print(f"Reference peak index: {result.ref_peak_idx}")
        print(f"Peak alignment accuracy (within ±{tolerance}): [{status}]")
        print(f"   {result.alignment_accuracy_percent:.1f}% of traces have peak aligned")
        print()

        if result.ground_truth_shifts is not None:
            print(f"{'Trace':>6} | {'Shift':>8} | {'Peak Off (Orig)':>14} | {'Peak Off (Align)':>14}")
            print(f"{'':>6}   | {'':>8} | {'(→ / ← offset)':>14} | {'(→ / ← offset)':>14}")
            print("-" * 65)

            for i in range(len(result.ground_truth_shifts)):
                gt_shift = result.ground_truth_shifts[i]

                orig_off = result.original_peak_offsets[i]
                align_off = result.aligned_peak_offsets[i]

                shift_str = f"→{gt_shift}" if gt_shift > 0 else f"←{-gt_shift}" if gt_shift < 0 else "0"
                orig_str = f"→{orig_off}" if orig_off > 0 else f"←{-orig_off}" if orig_off < 0 else "0"
                align_str = f"→{align_off}" if align_off > 0 else f"←{-align_off}" if align_off < 0 else "0"

                same_direction = (gt_shift > 0 and orig_off > 0) or (gt_shift < 0 and orig_off < 0) or (gt_shift == 0 and orig_off == 0)
                magnitude_ok = abs(abs(gt_shift) - abs(orig_off)) <= tolerance
                align_ok = same_direction and magnitude_ok and abs(align_off) <= tolerance
                align_mark = f"{GREEN}✓{RESET}" if align_ok else f"{RED}✗{RESET}"

                print(f"{i:>6} | {shift_str:>8} | {orig_str:>14} | {align_str:>14} {align_mark}")

            print()
            print(f"Original Traces (peak offset from reference):")
            print(f"   Mean absolute offset: {result.original_offset_mean:.1f} samples")
            print(f"   Std deviation:       {result.original_offset_std:.1f} samples")
            print()
            print(f"Aligned Traces (peak offset from reference):")
            print(f"   Mean absolute offset: {result.aligned_offset_mean:.1f} samples")
            print(f"   Std deviation:       {result.aligned_offset_std:.1f} samples")
        print()


__all__ = [
    "ResyncPeakDetector",
    "ResyncResult",
    "ResyncVerificationResult",
    "ShiftVerificationResult",
    "PeakVerificationResult",
]