"""SAD - Sum of Absolute Difference trace alignment.

Based on ChipWhisperer's ResyncSAD algorithm.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

import numpy as np

from squirrel.base import AnalysisResult, Analyzer


@dataclass
class SADResult(AnalysisResult):
    """Result from SAD alignment."""

    ref_trace_idx: int = 0
    target_window: tuple[int, int] = (0, 0)
    max_shift: int = 0
    num_traces: int = 0
    num_aligned: int = 0
    num_rejected: int = 0
    mean_sad: float = 0.0
    metadata: dict = field(default_factory=dict)


@dataclass
class SADVerificationResult:
    """Verification result for SAD alignment."""

    std_reduction: float = 0.0
    corr_improvement: float = 0.0
    var_reduction: float = 0.0
    shift_mae: float = 0.0
    passed: bool = False


class SADAligner(Analyzer):
    """Sum of Absolute Difference (SAD) based trace aligner.

    Uses a portion of one trace as a reference window, then slides
    it over each input trace within a search window to find the
    shift that minimizes SAD.

    Args:
        config: Configuration dict
        ref_trace_idx: Index of reference trace
        target_window: (start, end) of reference window in trace
        max_shift: Maximum shift to search in either direction
    """

    name: str = "sad"
    description: str = "Align traces using Sum of Absolute Difference"

    def __init__(
        self,
        config: dict[str, Any] | None = None,
        ref_trace_idx: int = 0,
        target_window: tuple[int, int] = (0, 0),
        max_shift: int = 50,
    ):
        config = config or {}
        config.setdefault("ref_trace_idx", ref_trace_idx)
        config.setdefault("target_window", target_window)
        config.setdefault("max_shift", max_shift)
        super().__init__(config)

        self._ref_window: np.ndarray | None = None
        self._ref_maxloc: int = 0
        self._ref_maxsize: float = 0.0

    @property
    def ref_trace_idx(self) -> int:
        return self.config.get("ref_trace_idx", 0)

    @property
    def target_window(self) -> tuple[int, int]:
        return self.config.get("target_window", (0, 0))

    @property
    def max_shift(self) -> int:
        return self.config.get("max_shift", 50)

    def _calculate_ref_window(self, traces: np.ndarray) -> None:
        """Calculate reference window from reference trace."""
        ref_idx = self.ref_trace_idx
        start, end = self.target_window

        if end <= start:
            end = start + 100

        self._ref_window = traces[ref_idx, start:end]
        self._ref_maxsize = float(np.max(np.abs(self._ref_window)))

    def _find_sad(self, trace: np.ndarray) -> tuple[np.ndarray, int, float]:
        """Find best shift for a trace using SAD.

        Returns:
            (sad_array, best_shift, min_sad)
        """
        start, end = self.target_window
        max_shift = self.max_shift
        window_len = end - start

        sadlen = max_shift * 2
        sad_array = np.ones(sadlen) * 1e6

        minshift = -max_shift
        maxshift = max_shift

        if minshift + start < 0:
            raise ValueError("Invalid: search location < 0")
        if maxshift + end > len(trace):
            raise ValueError("Invalid: search location outside trace")

        for offset in range(minshift, maxshift):
            ptstart = offset + start
            diff = trace[ptstart:ptstart + window_len] - self._ref_window
            sad_array[offset + max_shift] = np.sum(np.abs(diff))

        min_sad_idx = np.argmin(sad_array)
        best_shift = min_sad_idx - max_shift
        min_sad = sad_array[min_sad_idx]

        return sad_array, best_shift, min_sad

    def _apply_shift(self, trace: np.ndarray, shift: int) -> np.ndarray:
        if shift < 0:
            return np.concatenate([np.zeros(-shift), trace[:shift]])
        elif shift > 0:
            return np.concatenate([trace[shift:], np.zeros(shift)])
        else:
            return trace

    def analyze(
        self,
        traces: np.ndarray,
        labels: np.ndarray | None = None,
        **kwargs,
    ) -> SADResult:
        """Align traces using SAD algorithm.

        Args:
            traces: Trace data (num_traces, num_samples)
            labels: Not used

        Returns:
            SADResult
        """
        input_path = kwargs.get("input_path", "")

        if not self.target_window or self.target_window[1] <= self.target_window[0]:
            start, end = 0, min(100, traces.shape[1])
            self.config["target_window"] = (start, end)
        else:
            start, end = self.target_window

        self._calculate_ref_window(traces)

        aligned_traces = np.zeros_like(traces)
        num_aligned = 0
        num_rejected = 0
        shifts = []
        sad_values = []

        for i in range(traces.shape[0]):
            _, shift, min_sad = self._find_sad(traces[i])
            sad_values.append(min_sad)
            shifts.append(shift)

            aligned_traces[i] = self._apply_shift(traces[i], shift)
            num_aligned += 1

        mean_sad = float(np.mean(sad_values)) if sad_values else 0.0

        return SADResult(
            method="sad",
            input_path=input_path,
            ref_trace_idx=self.ref_trace_idx,
            target_window=self.target_window,
            max_shift=self.max_shift,
            num_traces=traces.shape[0],
            num_aligned=num_aligned,
            num_rejected=num_rejected,
            mean_sad=mean_sad,
            metadata={
                "aligned_traces": aligned_traces,
                "shifts": np.array(shifts),
                "sad_values": np.array(sad_values),
            },
        )

    def detect_leakage_points(
        self,
        result: SADResult,
        threshold: float | None = None,
    ) -> np.ndarray:
        """Not applicable for SAD alignment."""
        return np.array([])

    def verify(
        self,
        original: np.ndarray,
        aligned: np.ndarray,
        ref_trace_idx: int | None = None,
    ) -> SADVerificationResult:
        """Verify alignment effectiveness."""
        if ref_trace_idx is None:
            ref_trace_idx = self.ref_trace_idx

        ref_trace = aligned[ref_trace_idx]

        orig_std = np.std(original)
        aligned_std = np.std(aligned)
        std_reduction = (orig_std - aligned_std) / orig_std * 100 if orig_std > 0 else 0

        orig_corrs = []
        aligned_corrs = []
        for i in range(original.shape[0]):
            if i != ref_trace_idx:
                orig_corrs.append(np.corrcoef(original[i], original[ref_trace_idx])[0, 1])
                aligned_corrs.append(np.corrcoef(aligned[i], ref_trace)[0, 1])
        orig_corr = np.mean(orig_corrs) if orig_corrs else 0
        aligned_corr = np.mean(aligned_corrs) if aligned_corrs else 0
        corr_improvement = aligned_corr - orig_corr

        orig_var = np.var(original)
        aligned_var = np.var(aligned)
        var_reduction = (orig_var - aligned_var) / orig_var * 100 if orig_var > 0 else 0

        passed = std_reduction > 0 and corr_improvement > 0

        return SADVerificationResult(
            std_reduction=std_reduction,
            corr_improvement=corr_improvement,
            var_reduction=var_reduction,
            shift_mae=0.0,
            passed=passed,
        )

    def verify_shifts(
        self,
        original: np.ndarray,
        aligned: np.ndarray,
        ground_truth_shifts: np.ndarray,
        ref_trace_idx: int | None = None,
    ) -> tuple[float, bool]:
        """Verify shift estimation accuracy.

        Returns:
            (mae, passed)
        """
        if ref_trace_idx is None:
            ref_trace_idx = self.ref_trace_idx

        self._calculate_ref_window(original)

        start, end = self.target_window
        estimated_shifts = []

        for i in range(original.shape[0]):
            _, shift, _ = self._find_sad(original[i])
            estimated_shifts.append(shift)

        estimated_shifts = np.array(estimated_shifts)
        gt = ground_truth_shifts.copy()
        gt[ref_trace_idx] = 0

        mae = np.mean(np.abs(estimated_shifts - gt))
        passed = mae < 5.0

        return float(mae), passed

    def print_verification(self, result: SADVerificationResult) -> None:
        """Print verification result."""
        status = "PASS" if result.passed else "FAIL"
        print(f"  [{status}] Std Reduction: {result.std_reduction:.2f}%")
        print(f"       Corr Improvement: {result.corr_improvement:.4f}")
        print(f"       Var Reduction: {result.var_reduction:.2f}%")


__all__ = [
    "SADAligner",
    "SADResult",
    "SADVerificationResult",
]
