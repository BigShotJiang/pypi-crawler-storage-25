from typing import Any

import numpy as np

from squirrel.base import Analyzer
from squirrel.preprocessing.Resync_DTW.fasterdtw import fastdtw


class DTWAligner(Analyzer):
    name = "dtw"
    description = "Aligns traces using Fast Dynamic Time Warp algorithm"

    def __init__(self, config: dict[str, Any] | None = None):
        if config is None:
            config = {}
        self.radius = config.get("radius", 3)
        self.ref_trace_idx = config.get("ref_trace_idx", 0)
        super().__init__(config)

    def _align_pair(self, ref: np.ndarray, trace: np.ndarray) -> np.ndarray:
        aref = np.array(ref)
        atrace = np.array(trace)
        dist, path = fastdtw(aref, atrace, radius=self.radius)

        N = len(ref)
        s = np.zeros(N, dtype=np.float64)
        n = np.zeros(N, dtype=np.float64)

        for x, y in path:
            s[x] += trace[y]
            n[x] += 1

        return s / np.where(n > 0, n, 1)

    def align(self, traces: np.ndarray, ref_trace_idx: int | None = None) -> np.ndarray:
        if ref_trace_idx is None:
            ref_trace_idx = self.ref_trace_idx

        ref_trace = traces[ref_trace_idx]
        aligned = np.zeros_like(traces)

        for i in range(len(traces)):
            if i == ref_trace_idx:
                aligned[i] = traces[i]
            else:
                aligned[i] = self._align_pair(ref_trace, traces[i])

        return aligned

    def analyze(self, traces: np.ndarray, labels: np.ndarray | None = None, **kwargs) -> dict:
        aligned = self.align(traces)
        return {"method": "dtw", "aligned_traces": aligned}