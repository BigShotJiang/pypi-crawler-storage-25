"""Normalize - Trace normalization preprocessing."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

import numpy as np

from squirrel.base import AnalysisResult, Analyzer


@dataclass
class NormalizeResult(AnalysisResult):
    """Result from normalization preprocessing."""

    num_traces: int = 0
    mode: str = "mean"
    metadata: dict = field(default_factory=dict)


@dataclass
class NormalizeVerificationResult:
    """Verification result for normalization."""

    input_std: float = 0.0
    output_std: float = 0.0
    input_mean: float = 0.0
    output_mean: float = 0.0
    passed: bool = False


class NormMean:
    """Normalize by mean (e.g. make traces zero-mean)."""

    def process_trace(self, t: np.ndarray, tindex: int) -> np.ndarray:
        return t - np.mean(t)


class NormMeanStd:
    """Normalize by mean & std-dev."""

    def process_trace(self, t: np.ndarray, tindex: int) -> np.ndarray:
        return (t - np.mean(t)) / np.std(t)


class Normalize(Analyzer):
    """Normalize traces by a variety of methods.

    Supports:
    - mean: Subtract the mean from traces (change to 0-mean)
    - mean_stddev: Subtract mean and divide by std (mean=0, stddev=1)
    """

    name: str = "normalize"
    description: str = "Normalize traces by mean and/or standard deviation"

    def __init__(
        self,
        config: dict[str, Any] | None = None,
        mode: str = "mean",
    ):
        config = config or {}
        if "mode" in config:
            mode = config["mode"]
        else:
            config.setdefault("mode", mode)
        super().__init__(config)

        self._set_mode(mode)

    def _set_mode(self, mode: str) -> None:
        if mode == "mean":
            self._norm = NormMean()
        elif mode == "mean_stddev":
            self._norm = NormMeanStd()
        else:
            raise ValueError(f"Unknown mode: {mode}. Expected 'mean' or 'mean_stddev'")

    @property
    def mode(self) -> str:
        return self.config.get("mode", "mean")

    @mode.setter
    def mode(self, value: str) -> None:
        self._set_mode(value)
        self.config["mode"] = value

    def analyze(
        self,
        traces: np.ndarray,
        labels: np.ndarray | None = None,
        **kwargs,
    ) -> NormalizeResult:
        """Normalize traces.

        Args:
            traces: Trace data (num_traces, num_samples)
            labels: Not used

        Returns:
            NormalizeResult with normalized traces
        """
        normalized = np.zeros_like(traces)
        for i in range(traces.shape[0]):
            normalized[i] = self._norm.process_trace(traces[i], i)

        return NormalizeResult(
            method="normalize",
            input_path=kwargs.get("input_path", ""),
            num_traces=traces.shape[0],
            mode=self.mode,
            metadata={
                "normalized_traces": normalized,
            },
        )

    def verify(
        self,
        original: np.ndarray,
        normalized: np.ndarray,
    ) -> NormalizeVerificationResult:
        """Verify normalization effectiveness.

        Args:
            original: Original traces before normalization
            normalized: Traces after normalization

        Returns:
            NormalizeVerificationResult with metrics
        """
        input_mean = float(np.mean(original))
        output_mean = float(np.mean(normalized))
        input_std = float(np.std(original))
        output_std = float(np.std(normalized))

        if self.mode == "mean":
            passed = abs(output_mean) < 1e-6
        else:
            passed = abs(output_mean) < 1e-10 and abs(output_std - 1.0) < 1e-10

        return NormalizeVerificationResult(
            input_std=input_std,
            output_std=output_std,
            input_mean=input_mean,
            output_mean=output_mean,
            passed=passed,
        )

    def detect_leakage_points(
        self,
        result: NormalizeResult,
        threshold: float | None = None,
    ) -> np.ndarray:
        return np.array([])


__all__ = [
    "Normalize",
    "NormalizeResult",
    "NormalizeVerificationResult",
]
