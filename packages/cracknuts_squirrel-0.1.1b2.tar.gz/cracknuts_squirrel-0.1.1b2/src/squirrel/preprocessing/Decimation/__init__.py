"""Decimation preprocessing module."""

from squirrel.preprocessing.Decimation.decimation import (
    Decimation,
    DecimationResult,
    DecimationVerificationResult,
)

__all__ = [
    "Decimation",
    "DecimationResult",
    "DecimationVerificationResult",
]
