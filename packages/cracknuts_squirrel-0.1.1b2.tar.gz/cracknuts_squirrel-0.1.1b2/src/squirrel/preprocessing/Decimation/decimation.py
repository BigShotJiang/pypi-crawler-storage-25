"""Decimation - Reduce sample rate by keeping one in N points."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

import numpy as np

from squirrel.base import AnalysisResult, Analyzer


@dataclass
class DecimationResult(AnalysisResult):
    """Result from decimation preprocessing."""

    dec_factor: int = 2
    input_samples: int = 0
    output_samples: int = 0
    num_traces: int = 0
    metadata: dict = field(default_factory=dict)


@dataclass
class DecimationVerificationResult:
    """Verification result for decimation."""

    input_samples: int = 0
    output_samples: int = 0
    decimation_ratio: float = 0.0
    passed: bool = False


class Decimation(Analyzer):
    """Decimate traces by keeping one in N points.

    Reduces the sample rate by a fixed decimation factor.
    """

    name: str = "decimation"
    description: str = "Decimate traces by a fixed factor"

    def __init__(
        self,
        config: dict[str, Any] | None = None,
        dec_factor: int = 2,
    ):
        config = config or {}
        if "dec_factor" in config:
            dec_factor = config["dec_factor"]
        else:
            config.setdefault("dec_factor", dec_factor)
        super().__init__(config)

    @property
    def dec_factor(self) -> int:
        return self.config.get("dec_factor", 2)

    @dec_factor.setter
    def dec_factor(self, value: int) -> None:
        if not isinstance(value, int):
            raise TypeError(f"Expected int; got {type(value)}")
        if value < 1:
            raise ValueError("dec_factor must be >= 1")
        self.config["dec_factor"] = value

    def analyze(
        self,
        traces: np.ndarray,
        labels: np.ndarray | None = None,
        **kwargs,
    ) -> DecimationResult:
        """Decimate traces.

        Args:
            traces: Trace data (num_traces, num_samples)
            labels: Not used

        Returns:
            DecimationResult with decimated traces
        """
        dec_factor = self.dec_factor
        decimated = traces[:, ::dec_factor]

        return DecimationResult(
            method="decimation",
            input_path=kwargs.get("input_path", ""),
            dec_factor=dec_factor,
            input_samples=traces.shape[1],
            output_samples=decimated.shape[1],
            num_traces=traces.shape[0],
            metadata={
                "decimated_traces": decimated,
            },
        )

    def verify(
        self,
        original: np.ndarray,
        decimated: np.ndarray,
    ) -> DecimationVerificationResult:
        """Verify decimation effectiveness.

        Args:
            original: Original traces before decimation
            decimated: Traces after decimation

        Returns:
            DecimationVerificationResult with metrics
        """
        input_samples = original.shape[1]
        output_samples = decimated.shape[1]
        decimation_ratio = input_samples / output_samples

        passed = abs(decimation_ratio - self.dec_factor) < 0.01

        return DecimationVerificationResult(
            input_samples=input_samples,
            output_samples=output_samples,
            decimation_ratio=decimation_ratio,
            passed=passed,
        )

    def detect_leakage_points(
        self,
        result: DecimationResult,
        threshold: float | None = None,
    ) -> np.ndarray:
        return np.array([])


__all__ = [
    "Decimation",
    "DecimationResult",
    "DecimationVerificationResult",
]
