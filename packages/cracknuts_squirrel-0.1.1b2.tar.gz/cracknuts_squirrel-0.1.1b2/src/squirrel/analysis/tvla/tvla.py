"""TVLA - Test Vector Leakage Assessment."""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import numpy as np
import zarr

from squirrel.base import AnalysisResult, Analyzer, TraceDataset


@dataclass
class TVLAResult(AnalysisResult):
    """TVLA analysis result."""

    threshold: float = 4.5
    total_samples: int = 0
    trace_count_fixed: int = 0
    trace_count_random: int = 0
    ttest_min: float = 0.0
    ttest_max: float = 0.0
    ttest_mean_abs: float = 0.0
    total_leakage_points: int = 0
    leakage_points: list[int] = field(default_factory=list)
    leakage_regions: list[dict[str, float]] = field(default_factory=list)
    first_leakage_point: int | None = None
    first_leakage_tvalue: float | None = None


class TVLAAnalyzer(Analyzer):
    """TVLA (Test Vector Leakage Assessment) Analyzer."""

    name: str = "tvla"
    description: str = "TVLA Test Vector Leakage Assessment"

    def __init__(self, config: dict[str, Any] | None = None):
        super().__init__(config)
        self.threshold = self.config.get("threshold", 4.5)

    def analyze(
        self,
        traces: np.ndarray,
        labels: np.ndarray | None = None,
        plaintext: np.ndarray | None = None,
        key: np.ndarray | None = None,
        **kwargs,
    ) -> TVLAResult:
        """Run TVLA analysis."""
        input_path = kwargs.get("input_path")
        output_dir = kwargs.get("output_dir")

        if input_path and os.path.isdir(input_path):
            return self._analyze_zarr(input_path, output_dir)

        if isinstance(traces, str) and os.path.isdir(traces):
            return self._analyze_zarr(traces, output_dir)

        raise ValueError("TVLA requires zarr dataset path as input")

    def _analyze_zarr(self, zarr_path: str, output_dir: str | None = None) -> TVLAResult:
        """Analyze zarr dataset."""
        tile = "/0/0/"
        z = zarr.open(zarr_path, "r")

        fixed = z[f"{tile}fixed_traces"][:]
        random = z[f"{tile}random_traces"][:]

        return self._compute_ttest(fixed, random, zarr_path, output_dir)

    def _compute_ttest(
        self,
        fixed: np.ndarray,
        random: np.ndarray,
        input_path: str,
        output_dir: str | None = None,
    ) -> TVLAResult:
        """Compute t-test statistics."""
        mean_fixed = np.mean(fixed, axis=0)
        mean_random = np.mean(random, axis=0)
        var_fixed = np.var(fixed, axis=0, ddof=1)
        var_random = np.var(random, axis=0, ddof=1)

        n_fixed = fixed.shape[0]
        n_random = random.shape[0]
        denominator = np.sqrt(var_fixed / n_fixed + var_random / n_random)
        t_values = (mean_fixed - mean_random) / np.where(denominator > 0, denominator, 1)

        leakage_mask = np.abs(t_values) > self.threshold
        leakage_points = np.where(leakage_mask)[0].tolist()

        if output_dir:
            self._save_plot(t_values, fixed.shape[1], output_dir)

        return TVLAResult(
            method="tvla",
            input_path=input_path,
            threshold=self.threshold,
            total_samples=fixed.shape[1],
            trace_count_fixed=n_fixed,
            trace_count_random=n_random,
            ttest_min=float(np.min(t_values)),
            ttest_max=float(np.max(t_values)),
            ttest_mean_abs=float(np.mean(np.abs(t_values))),
            total_leakage_points=len(leakage_points),
            leakage_points=leakage_points,
            first_leakage_point=leakage_points[0] if leakage_points else None,
            first_leakage_tvalue=float(t_values[leakage_points[0]]) if leakage_points else None,
        )

    def _save_plot(self, t_values: np.ndarray, num_samples: int, output_dir: str) -> None:
        """Save t-test plot."""
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt

        x = np.arange(num_samples)

        plt.figure(figsize=(14, 6))
        plt.plot(x, t_values, "b-", linewidth=0.8, alpha=0.9, label="t-value")
        plt.axhline(y=self.threshold, color="red", linestyle="--", linewidth=1.2, label=f"Threshold = ±{self.threshold}")
        plt.axhline(y=-self.threshold, color="red", linestyle="--", linewidth=1.2)
        plt.axhline(y=0, color="gray", linestyle="-", linewidth=0.5, alpha=0.5)

        plt.xlim(0, num_samples)
        plt.xlabel("Sample Point", fontsize=12)
        plt.ylabel("t-value", fontsize=12)
        plt.title("TVLA t-test Analysis Results", fontsize=14, fontweight="bold")
        plt.legend(loc="upper right", fontsize=10)
        plt.grid(True, alpha=0.3, linestyle="-", linewidth=0.5)
        plt.tight_layout()

        plot_path = os.path.join(output_dir, "tvla_plot.png")
        plt.savefig(plot_path, dpi=150, bbox_inches="tight")
        plt.close()
        print(f"Plot saved: {plot_path}")

    def detect_leakage_points(
        self,
        result: TVLAResult,
        threshold: float | None = None,
    ) -> np.ndarray:
        """Detect leakage points from result."""
        threshold = threshold or self.threshold
        return np.array(result.leakage_points)

    @staticmethod
    def load_traces(path: str | Path, format: str = "zarr") -> TraceDataset:
        """Load traces from zarr format."""
        if format != "zarr":
            raise ValueError(f"Unsupported format: {format}")

        tile = "/0/0/"
        z = zarr.open(str(path), "r")

        return TraceDataset(
            fixed_traces=z[f"{tile}fixed_traces"][:],
            random_traces=z[f"{tile}random_traces"][:],
        )

    @staticmethod
    def save_traces(
        dataset: TraceDataset,
        path: str | Path,
        format: str = "zarr",
    ) -> Path:
        """Save traces to zarr format."""
        if format != "zarr":
            raise ValueError(f"Unsupported format: {format}")

        tile = "/0/0/"
        z = zarr.open(str(path), mode="w")

        if dataset.fixed_traces is not None:
            z.create_dataset(f"{tile}fixed_traces", data=dataset.fixed_traces)
        if dataset.random_traces is not None:
            z.create_dataset(f"{tile}random_traces", data=dataset.random_traces)

        return Path(path)


__all__ = ["TVLAResult", "TVLAAnalyzer"]