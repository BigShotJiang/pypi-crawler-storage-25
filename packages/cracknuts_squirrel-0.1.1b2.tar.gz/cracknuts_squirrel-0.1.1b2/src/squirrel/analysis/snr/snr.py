"""SNR - Signal-to-Noise Ratio analysis for leakage detection."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

import numpy as np

from squirrel.base import AnalysisResult, Analyzer


def _hamming_weight(x: int) -> int:
    """Compute Hamming weight of an integer."""
    return bin(x).count("1")


@dataclass
class SNRResult(AnalysisResult):
    """SNR analysis result."""

    snr: np.ndarray | None = None
    snr_db: np.ndarray | None = None
    peak_snr_db: float = 0.0
    peak_sample: int = 0
    num_leakage_groups: int = 0
    best_group_size: int = 0
    threshold: float = 3.0
    metadata: dict[str, Any] = field(default_factory=dict)


class SNRAnalyzer(Analyzer):
    """Signal-to-Noise Ratio (SNR) analyzer.

    Computes SNR = Var(signal) / Var(noise) per sample using leakage model grouping.

    SNR > 3dB indicates detectable leakage at that sample location.
    """

    name: str = "snr"
    description: str = "Signal-to-Noise Ratio analysis for leakage detection"

    def __init__(self, config: dict[str, Any] | None = None):
        super().__init__(config)
        self.threshold = self.config.get("threshold", 3.0)
        self.leakage_model = self.config.get("leakage_model", "HW")

    def analyze(
        self,
        traces: np.ndarray,
        labels: np.ndarray | None = None,
        plaintext: np.ndarray | None = None,
        key: np.ndarray | None = None,
        **kwargs,
    ) -> SNRResult:
        """Compute SNR vs time across all samples.

        Args:
            traces: Trace data (num_traces, num_samples)
            plaintext: Plaintext data (num_traces, 16)
            key: Key data (16,)

        Returns:
            SNRResult with snr_db array and peak metrics
        """
        if plaintext is None:
            raise ValueError("plaintext is required for SNR analysis")

        num_traces, num_samples = traces.shape

        # Compute leakage: HW(plaintext) per trace
        # Use first byte for grouping (byte 0)
        pt = plaintext[:, 0]
        leakage = np.array([_hamming_weight(int(b)) for b in pt], dtype=np.int32)

        # Group traces by leakage value (HW ranges 0-8)
        max_hw = 8
        hwarray: list[list[np.ndarray]] = [[] for _ in range(max_hw + 1)]
        for i in range(num_traces):
            hw = leakage[i]
            if 0 <= hw <= max_hw:
                hwarray[hw].append(traces[i])

        # Compute mean trace per leakage group
        hwmean = np.zeros((max_hw + 1, num_samples), dtype=np.float64)
        group_sizes = []
        for hw in range(max_hw + 1):
            if len(hwarray[hw]) > 0:
                hwmean[hw] = np.mean(hwarray[hw], axis=0)
            group_sizes.append(len(hwarray[hw]))

        # Find groups with traces (valid groups)
        inc_list = [hw for hw in range(max_hw + 1) if len(hwarray[hw]) > 0]
        hwmean_valid = hwmean[inc_list]  # (num_valid_groups, num_samples)

        # Signal variance: variance of group means across leakage groups
        signal_var = np.var(hwmean_valid, axis=0)  # (num_samples,)

        # Noise variance: variance within the largest group
        best_choice = -1
        best_choice_len = 0
        for hw in inc_list:
            if len(hwarray[hw]) > best_choice_len:
                best_choice = hw
                best_choice_len = len(hwarray[hw])

        if best_choice < 0 or best_choice_len == 0:
            snr = np.zeros(num_samples)
            snr_db = np.full(num_samples, -np.inf)
        else:
            noise_var_onehw = np.var(hwarray[best_choice], axis=0)  # (num_samples,)
            # Avoid division by zero
            noise_var_onehw = np.where(noise_var_onehw == 0, 1e-10, noise_var_onehw)
            snr = signal_var / noise_var_onehw
            snr_db = 20 * np.log10(snr)

        peak_idx = int(np.argmax(snr_db))
        peak_snr_db = float(snr_db[peak_idx])

        return SNRResult(
            method="snr",
            input_path=kwargs.get("input_path", ""),
            snr=snr,
            snr_db=snr_db,
            peak_snr_db=peak_snr_db,
            peak_sample=peak_idx,
            num_leakage_groups=len(inc_list),
            best_group_size=best_choice_len,
            threshold=self.threshold,
            metadata={
                "num_traces": num_traces,
                "num_samples": num_samples,
                "group_sizes": group_sizes,
                "leakage_model": self.leakage_model,
            },
        )

    def detect_leakage_points(
        self,
        result: SNRResult,
        threshold: float | None = None,
    ) -> np.ndarray:
        """Detect sample indices where SNR exceeds threshold."""
        thresh = threshold if threshold is not None else self.threshold
        if result.snr_db is None:
            return np.array([], dtype=np.int64)
        return np.where(result.snr_db > thresh)[0]


__all__ = ["SNRAnalyzer", "SNRResult"]
