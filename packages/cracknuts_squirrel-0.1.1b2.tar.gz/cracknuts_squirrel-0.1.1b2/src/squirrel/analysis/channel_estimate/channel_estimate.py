"""Channel Estimate Attack - Linear Regression Side-Channel Attack.

Based on ChipWhisperer's ChannelEstimateAttackOneSubkey algorithm.
Uses linear regression to estimate the power consumption channel and
recover AES subkey bytes.

Reference:
- Colin O'Flynn, "Channel Estimate Attack" - ChipWhisperer
- Uses SVD-based pseudoinverse for fast linear regression
"""

from __future__ import annotations

from dataclasses import dataclass, field
from operator import itemgetter
from typing import Any

import numpy as np

from squirrel.base import AnalysisResult, Analyzer


# Hamming weight lookup table (0-255)
_HW = [
    0,
    1,
    1,
    2,
    1,
    2,
    2,
    3,
    1,
    2,
    2,
    3,
    2,
    3,
    3,
    4,
    1,
    2,
    2,
    3,
    2,
    3,
    3,
    4,
    2,
    3,
    3,
    4,
    3,
    4,
    4,
    5,
    1,
    2,
    2,
    3,
    2,
    3,
    3,
    4,
    2,
    3,
    3,
    4,
    3,
    4,
    4,
    5,
    2,
    3,
    3,
    4,
    3,
    4,
    4,
    5,
    3,
    4,
    4,
    5,
    4,
    5,
    5,
    6,
    1,
    2,
    2,
    3,
    2,
    3,
    3,
    4,
    2,
    3,
    3,
    4,
    3,
    4,
    4,
    5,
    2,
    3,
    3,
    4,
    3,
    4,
    4,
    5,
    3,
    4,
    4,
    5,
    4,
    5,
    5,
    6,
    2,
    3,
    3,
    4,
    3,
    4,
    4,
    5,
    3,
    4,
    4,
    5,
    4,
    5,
    5,
    6,
    3,
    4,
    4,
    5,
    4,
    5,
    5,
    6,
    4,
    5,
    5,
    6,
    5,
    6,
    6,
    7,
    1,
    2,
    2,
    3,
    2,
    3,
    3,
    4,
    2,
    3,
    3,
    4,
    3,
    4,
    4,
    5,
    2,
    3,
    3,
    4,
    3,
    4,
    4,
    5,
    3,
    4,
    4,
    5,
    4,
    5,
    5,
    6,
    2,
    3,
    3,
    4,
    3,
    4,
    4,
    5,
    3,
    4,
    4,
    5,
    4,
    5,
    5,
    6,
    3,
    4,
    4,
    5,
    4,
    5,
    5,
    6,
    4,
    5,
    5,
    6,
    5,
    6,
    6,
    7,
    2,
    3,
    3,
    4,
    3,
    4,
    4,
    5,
    3,
    4,
    4,
    5,
    4,
    5,
    5,
    6,
    3,
    4,
    4,
    5,
    4,
    5,
    5,
    6,
    4,
    5,
    5,
    6,
    5,
    6,
    6,
    7,
    3,
    4,
    4,
    5,
    4,
    5,
    5,
    6,
    4,
    5,
    5,
    6,
    5,
    6,
    6,
    7,
    4,
    5,
    5,
    6,
    5,
    6,
    6,
    7,
    5,
    6,
    6,
    7,
    6,
    7,
    7,
    8,
]


# AES S-box
_SBOX = [
    0x63,
    0x7C,
    0x77,
    0x7B,
    0xF2,
    0x6B,
    0x6F,
    0xC5,
    0x30,
    0x01,
    0x67,
    0x2B,
    0xFE,
    0xD7,
    0xAB,
    0x76,
    0xCA,
    0x82,
    0xC9,
    0x7D,
    0xFA,
    0x59,
    0x47,
    0xF0,
    0xAD,
    0xD4,
    0xA2,
    0xAF,
    0x9C,
    0xA4,
    0x72,
    0xC0,
    0xB7,
    0xFD,
    0x93,
    0x26,
    0x36,
    0x3F,
    0xF7,
    0xCC,
    0x34,
    0xA5,
    0xE5,
    0xF1,
    0x71,
    0xD8,
    0x31,
    0x15,
    0x04,
    0xC7,
    0x23,
    0xC3,
    0x18,
    0x96,
    0x05,
    0x9A,
    0x07,
    0x12,
    0x80,
    0xE2,
    0xEB,
    0x27,
    0xB2,
    0x75,
    0x09,
    0x83,
    0x2C,
    0x1A,
    0x1B,
    0x6E,
    0x5A,
    0xA0,
    0x52,
    0x3B,
    0xD6,
    0xB3,
    0x29,
    0xE3,
    0x2F,
    0x84,
    0x53,
    0xD1,
    0x00,
    0xED,
    0x20,
    0xFC,
    0xB1,
    0x5B,
    0x6A,
    0xCB,
    0xBE,
    0x39,
    0x4A,
    0x4C,
    0x58,
    0xCF,
    0xD0,
    0xEF,
    0xAA,
    0xFB,
    0x43,
    0x4D,
    0x33,
    0x85,
    0x45,
    0xF9,
    0x02,
    0x7F,
    0x50,
    0x3C,
    0x9F,
    0xA8,
    0x51,
    0xA3,
    0x40,
    0x8F,
    0x92,
    0x9D,
    0x38,
    0xF5,
    0xBC,
    0xB6,
    0xDA,
    0x21,
    0x10,
    0xFF,
    0xF3,
    0xD2,
    0xCD,
    0x0C,
    0x13,
    0xEC,
    0x5F,
    0x97,
    0x44,
    0x17,
    0xC4,
    0xA7,
    0x7E,
    0x3D,
    0x64,
    0x5D,
    0x19,
    0x73,
    0x60,
    0x81,
    0x4F,
    0xDC,
    0x22,
    0x2A,
    0x90,
    0x88,
    0x46,
    0xEE,
    0xB8,
    0x14,
    0xDE,
    0x5E,
    0x0B,
    0xDB,
    0xE0,
    0x32,
    0x3A,
    0x0A,
    0x49,
    0x06,
    0x24,
    0x5C,
    0xC2,
    0xD3,
    0xAC,
    0x62,
    0x91,
    0x95,
    0xE4,
    0x79,
    0xE7,
    0xC8,
    0x37,
    0x6D,
    0x8D,
    0xD5,
    0x4E,
    0xA9,
    0x6C,
    0x56,
    0xF4,
    0xEA,
    0x65,
    0x7A,
    0xAE,
    0x08,
    0xBA,
    0x78,
    0x25,
    0x2E,
    0x1C,
    0xA6,
    0xB4,
    0xC6,
    0xE8,
    0xDD,
    0x74,
    0x1F,
    0x4B,
    0xBD,
    0x8B,
    0x8A,
    0x70,
    0x3E,
    0xB5,
    0x66,
    0x48,
    0x03,
    0xF6,
    0x0E,
    0x61,
    0x35,
    0x57,
    0xB9,
    0x86,
    0xC1,
    0x1D,
    0x9E,
    0xE1,
    0xF8,
    0x98,
    0x11,
    0x69,
    0xD9,
    0x8E,
    0x94,
    0x9B,
    0x1E,
    0x87,
    0xE9,
    0xCE,
    0x55,
    0x28,
    0xDF,
    0x8C,
    0xA1,
    0x89,
    0x0D,
    0xBF,
    0xE6,
    0x42,
    0x68,
    0x41,
    0x99,
    0x2D,
    0x0F,
    0xB0,
    0x54,
    0xBB,
    0x16,
]


def hamming_weight(byte_val: int) -> int:
    """Return Hamming weight of a byte value."""
    return _HW[byte_val & 0xFF]


def sbox_output_hw(pt_byte: int, key_byte: int) -> int:
    """Calculate S-box output and return its Hamming weight."""
    return hamming_weight(_SBOX[pt_byte ^ key_byte])


@dataclass
class ChannelEstimateResult(AnalysisResult):
    """Result of Channel Estimate Attack.

    Attributes:
        num_subkeys: Number of subkey bytes attacked (default 16)
        num_guesses: Number of possible key guesses per byte (256)
        num_traces_fit: Number of traces used for fitting
        num_traces_test: Number of traces used for testing
        total_samples: Number of time samples per trace
        best_guesses: List of best key guesses per byte
        key_guess: Most likely key bytes (16 bytes)
        all_sses: Sum of squared errors for all guesses per byte
        pge: Partial guessing entropy per byte
        metadata: Additional attack metadata
    """

    num_subkeys: int = 16
    num_guesses: int = 256
    num_traces_fit: int = 0
    num_traces_test: int = 0
    total_samples: int = 0
    best_guesses: list[dict] = field(default_factory=list)
    key_guess: list[int] = field(default_factory=list)
    all_sses: list[np.ndarray] = field(default_factory=list)
    pge: list[int] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)


class ChannelEstimateAnalyzer(Analyzer):
    """Channel Estimate Attack - Linear Regression Side-Channel Attack.

    This attack treats power consumption as a linear channel and uses
    regression to estimate the relationship between hypothetical power
    (based on key guesses) and actual power measurements.

    The algorithm:
    1. Split traces into fitting and testing sets
    2. For each subkey byte and each guess:
       a. Compute hypothetical power using HW model
       b. Use SVD pseudoinverse to find channel coefficients
       c. Compute prediction error on test traces
    3. Sort guesses by prediction error (SSE)
    4. Return best key candidates

    Reference: ChipWhisperer ChannelEstimateAttack
    """

    name: str = "channel_estimate"
    description: str = "Channel Estimate Attack - Linear Regression"

    def __init__(self, config: dict[str, Any] | None = None):
        """Initialize Channel Estimate Attack analyzer.

        Args:
            config: Configuration dictionary with optional keys:
                - num_subkeys: Number of subkeys (default 16)
                - fit_ratio: Ratio of traces for fitting (default 0.8)
                - use_svd: Use SVD pseudoinverse (default True)
                - leakage_model: HW model type, 'sbox_output' or 'pt_key_xor'
        """
        if config is None:
            config = {}
        self.config = config
        self.num_subkeys = self.config.get("num_subkeys", 16)
        self.fit_ratio = self.config.get("fit_ratio", 0.8)
        self.use_svd = self.config.get("use_svd", True)
        self.leakage_model = self.config.get("leakage_model", "sbox_output")
        self.target_bytes = list(range(self.num_subkeys))

    def _validate_config(self) -> None:
        if self.num_subkeys < 1 or self.num_subkeys > 16:
            raise ValueError("num_subkeys must be between 1 and 16")
        if not 0 < self.fit_ratio <= 1:
            raise ValueError("fit_ratio must be between 0 and 1")
        if self.leakage_model not in ("sbox_output", "pt_key_xor"):
            raise ValueError("leakage_model must be 'sbox_output' or 'pt_key_xor'")

    def _compute_hypothetical(
        self,
        plaintexts: np.ndarray,
        guess: int,
        bnum: int,
    ) -> np.ndarray:
        """Compute hypothetical power for all plaintexts.

        Args:
            plaintexts: Array of plaintexts (num_traces, 16)
            guess: Key byte guess (0-255)
            bnum: Target byte number (0-15)

        Returns:
            Array of hypothetical power values (num_traces,)
        """
        n = plaintexts.shape[0]
        hyp = np.zeros(n, dtype=np.float64)

        for i in range(n):
            pt = plaintexts[i]
            if self.leakage_model == "sbox_output":
                # S-box output HW model
                hyp[i] = hamming_weight(_SBOX[pt[bnum] ^ guess])
            else:
                # PT XOR key HW model
                hyp[i] = hamming_weight(pt[bnum] ^ guess)

        return hyp

    def _estimate_channel(
        self,
        traces_fit: np.ndarray,
        hyp_fit: np.ndarray,
        use_svd: bool = True,
    ) -> np.ndarray:
        """Estimate channel coefficients using regression.

        Solves: traces_fit @ channel ≈ hyp_fit

        Args:
            traces_fit: Fitting traces (num_fit_traces, num_samples)
            hyp_fit: Hypothetical power values (num_fit_traces,)
            use_svd: Use SVD pseudoinverse if True, else lstsq

        Returns:
            Channel coefficients (num_samples,)
        """
        if use_svd:
            # SVD-based pseudoinverse (faster)
            pinv = np.linalg.pinv(traces_fit)
            channel = pinv @ hyp_fit
        else:
            # Least squares (slower but more stable for ill-conditioned)
            channel = np.linalg.lstsq(traces_fit, hyp_fit, rcond=None)[0]

        return channel

    def _attack_byte(
        self,
        bnum: int,
        traces_fit: np.ndarray,
        traces_test: np.ndarray,
        plaintexts_fit: np.ndarray,
        plaintexts_test: np.ndarray,
        known_key: np.ndarray | None = None,
    ) -> tuple[np.ndarray, list[dict], list[int]]:
        """Attack a single subkey byte.

        Args:
            bnum: Target byte number
            traces_fit: Fitting traces
            traces_test: Testing traces
            plaintexts_fit: Fitting plaintexts
            plaintexts_test: Testing plaintexts
            known_key: Known key for PGE calculation (optional)

        Returns:
            Tuple of (all_sses, best_guesses, pge)
        """
        n_fit = traces_fit.shape[0]
        n_test = traces_test.shape[0]

        # Pre-compute pinv of traces_fit if using SVD
        if self.use_svd:
            traces_fit_pinv = np.linalg.pinv(traces_fit)

        all_sses = np.zeros(256, dtype=np.float64)
        results = []

        for guess in range(256):
            # Compute hypothetical power for fitting set
            hyp_fit = self._compute_hypothetical(plaintexts_fit, guess, bnum)

            # Estimate channel
            if self.use_svd:
                channel = traces_fit_pinv @ hyp_fit
            else:
                channel = self._estimate_channel(traces_fit, hyp_fit, use_svd=False)

            # Predict power for test set
            pred_test = traces_test @ channel

            # Compute hypothetical power for test set
            hyp_test = self._compute_hypothetical(plaintexts_test, guess, bnum)

            # Compute SSE
            sse = np.sum((pred_test - hyp_test) ** 2)
            all_sses[guess] = sse

            results.append({"guess": guess, "sse": sse, "channel": channel})

        # Sort by SSE (lower is better)
        results.sort(key=itemgetter("sse"))

        # Extract best guesses
        best_guesses = [
            {"byte": bnum, "guess": r["guess"], "sse": r["sse"]} for r in results[:10]
        ]

        # Calculate PGE if known key provided
        pge = [255]
        if known_key is not None:
            key_rank = next(
                (i for i, r in enumerate(results) if r["guess"] == known_key[bnum]),
                255,
            )
            pge = [key_rank]

        return all_sses, best_guesses, pge

    def analyze(
        self,
        traces: np.ndarray,
        labels: np.ndarray | None = None,
        plaintext: np.ndarray | None = None,
        key: np.ndarray | None = None,
        **kwargs,
    ) -> ChannelEstimateResult:
        """Run Channel Estimate Attack on traces.

        Args:
            traces: Power traces (num_traces, num_samples)
            labels: Optional labels
            plaintext: Plaintext data (num_traces, 16)
            key: Known key for PGE calculation (optional)
            **kwargs: Additional arguments including input_path

        Returns:
            ChannelEstimateResult with attack results
        """
        if plaintext is None:
            raise ValueError("Channel Estimate Attack requires plaintext data")

        input_path = kwargs.get("input_path", "")
        num_traces, num_samples = traces.shape

        # Split into fitting and testing sets
        n_fit = int(num_traces * self.fit_ratio)
        n_test = num_traces - n_fit

        traces_fit = traces[:n_fit]
        traces_test = traces[n_fit:]
        plaintexts_fit = plaintext[:n_fit]
        plaintexts_test = plaintext[n_fit:]

        # Run attack on each target byte
        all_diffs = []
        all_best_guesses = []
        all_pge = []

        for bnum in self.target_bytes:
            sses, best_guesses, pge = self._attack_byte(
                bnum,
                traces_fit,
                traces_test,
                plaintexts_fit,
                plaintexts_test,
                key,
            )
            all_diffs.append(sses)
            all_best_guesses.append(best_guesses)
            all_pge.extend(pge)

        # Extract key guesses
        key_guess = [bg[0]["guess"] for bg in all_best_guesses]

        return ChannelEstimateResult(
            method="channel_estimate",
            input_path=input_path,
            num_subkeys=self.num_subkeys,
            num_traces_fit=n_fit,
            num_traces_test=n_test,
            total_samples=num_samples,
            best_guesses=all_best_guesses,
            key_guess=key_guess,
            all_sses=all_diffs,
            pge=all_pge,
            metadata={
                "leakage_model": self.leakage_model,
                "fit_ratio": self.fit_ratio,
                "use_svd": self.use_svd,
            },
        )

    def detect_leakage_points(
        self,
        result: ChannelEstimateResult,
        threshold: float | None = None,
    ) -> np.ndarray:
        """Detect leakage points based on SSE variation.

        Args:
            result: ChannelEstimateResult
            threshold: Not used for this attack type

        Returns:
            Array of sample indices with significant SSE variation
        """
        if not result.all_sses:
            return np.array([], dtype=int)

        # Compute variance across guesses for each sample point
        # Lower SSE indicates better key fit, variance shows information content
        return np.array([])  # Channel estimate doesn't provide per-sample analysis


__all__ = [
    "ChannelEstimateResult",
    "ChannelEstimateAnalyzer",
    "hamming_weight",
    "sbox_output_hw",
]
