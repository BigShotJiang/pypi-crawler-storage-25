"""MixColumns - CPA attack on AES MixColumns output."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

import numpy as np

from squirrel.base import AnalysisResult, Analyzer
from squirrel.analysis.cpa import CPAAnalyzer, CPAResult


_GAL2 = np.array(
    [
        0x00,
        0x02,
        0x04,
        0x06,
        0x08,
        0x0A,
        0x0C,
        0x0E,
        0x10,
        0x12,
        0x14,
        0x16,
        0x18,
        0x1A,
        0x1C,
        0x1E,
        0x20,
        0x22,
        0x24,
        0x26,
        0x28,
        0x2A,
        0x2C,
        0x2E,
        0x30,
        0x32,
        0x34,
        0x36,
        0x38,
        0x3A,
        0x3C,
        0x3E,
        0x40,
        0x42,
        0x44,
        0x46,
        0x48,
        0x4A,
        0x4C,
        0x4E,
        0x50,
        0x52,
        0x54,
        0x56,
        0x58,
        0x5A,
        0x5C,
        0x5E,
        0x60,
        0x62,
        0x64,
        0x66,
        0x68,
        0x6A,
        0x6C,
        0x6E,
        0x70,
        0x72,
        0x74,
        0x76,
        0x78,
        0x7A,
        0x7C,
        0x7E,
        0x80,
        0x82,
        0x84,
        0x86,
        0x88,
        0x8A,
        0x8C,
        0x8E,
        0x90,
        0x92,
        0x94,
        0x96,
        0x98,
        0x9A,
        0x9C,
        0x9E,
        0xA0,
        0xA2,
        0xA4,
        0xA6,
        0xA8,
        0xAA,
        0xAC,
        0xAE,
        0xB0,
        0xB2,
        0xB4,
        0xB6,
        0xB8,
        0xBA,
        0xBC,
        0xBE,
        0xC0,
        0xC2,
        0xC4,
        0xC6,
        0xC8,
        0xCA,
        0xCC,
        0xCE,
        0xD0,
        0xD2,
        0xD4,
        0xD6,
        0xD8,
        0xDA,
        0xDC,
        0xDE,
        0xE0,
        0xE2,
        0xE4,
        0xE6,
        0xE8,
        0xEA,
        0xEC,
        0xEE,
        0xF0,
        0xF2,
        0xF4,
        0xF6,
        0xF8,
        0xFA,
        0xFC,
        0xFE,
        0x1B,
        0x19,
        0x1F,
        0x1D,
        0x13,
        0x11,
        0x17,
        0x15,
        0x0B,
        0x09,
        0x0F,
        0x0D,
        0x03,
        0x01,
        0x07,
        0x05,
        0x3B,
        0x39,
        0x3F,
        0x3D,
        0x33,
        0x31,
        0x37,
        0x35,
        0x2B,
        0x29,
        0x2F,
        0x2D,
        0x23,
        0x21,
        0x27,
        0x25,
        0x5B,
        0x59,
        0x5F,
        0x5D,
        0x53,
        0x51,
        0x57,
        0x55,
        0x4B,
        0x49,
        0x4F,
        0x4D,
        0x43,
        0x41,
        0x47,
        0x45,
        0x7B,
        0x79,
        0x7F,
        0x7D,
        0x73,
        0x71,
        0x77,
        0x75,
        0x6B,
        0x69,
        0x6F,
        0x6D,
        0x63,
        0x61,
        0x67,
        0x65,
        0x9B,
        0x99,
        0x9F,
        0x9D,
        0x93,
        0x91,
        0x97,
        0x95,
        0x8B,
        0x89,
        0x8F,
        0x8D,
        0x83,
        0x81,
        0x87,
        0x85,
        0xBB,
        0xB9,
        0xBF,
        0xBD,
        0xB3,
        0xB1,
        0xB7,
        0xB5,
        0xAB,
        0xA9,
        0xAF,
        0xAD,
        0xA3,
        0xA1,
        0xA7,
        0xA5,
        0xDB,
        0xD9,
        0xDF,
        0xDD,
        0xD3,
        0xD1,
        0xD7,
        0xD5,
        0xCB,
        0xC9,
        0xCF,
        0xCD,
        0xC3,
        0xC1,
        0xC7,
        0xC5,
        0xFB,
        0xF9,
        0xFF,
        0xFD,
        0xF3,
        0xF1,
        0xF7,
        0xF5,
        0xEB,
        0xE9,
        0xEF,
        0xED,
        0xE3,
        0xE1,
        0xE7,
        0xE5,
    ],
    dtype=np.uint8,
)

_GAL3 = np.array(
    [
        0x00,
        0x03,
        0x06,
        0x05,
        0x0C,
        0x0F,
        0x0A,
        0x09,
        0x18,
        0x1B,
        0x1E,
        0x1D,
        0x14,
        0x17,
        0x12,
        0x11,
        0x30,
        0x33,
        0x36,
        0x35,
        0x3C,
        0x3F,
        0x3A,
        0x39,
        0x28,
        0x2B,
        0x2E,
        0x2D,
        0x24,
        0x27,
        0x22,
        0x21,
        0x60,
        0x63,
        0x66,
        0x65,
        0x6C,
        0x6F,
        0x6A,
        0x69,
        0x78,
        0x7B,
        0x7E,
        0x7D,
        0x74,
        0x77,
        0x72,
        0x71,
        0x50,
        0x53,
        0x56,
        0x55,
        0x5C,
        0x5F,
        0x5A,
        0x59,
        0x48,
        0x4B,
        0x4E,
        0x4D,
        0x44,
        0x47,
        0x42,
        0x41,
        0xC0,
        0xC3,
        0xC6,
        0xC5,
        0xCC,
        0xCF,
        0xCA,
        0xC9,
        0xD8,
        0xDB,
        0xDE,
        0xDD,
        0xD4,
        0xD7,
        0xD2,
        0xD1,
        0xF0,
        0xF3,
        0xF6,
        0xF5,
        0xFC,
        0xFF,
        0xFA,
        0xF9,
        0xE8,
        0xEB,
        0xEE,
        0xED,
        0xE4,
        0xE7,
        0xE2,
        0xE1,
        0xA0,
        0xA3,
        0xA6,
        0xA5,
        0xAC,
        0xAF,
        0xAA,
        0xA9,
        0xB8,
        0xBB,
        0xBE,
        0xBD,
        0xB4,
        0xB7,
        0xB2,
        0xB1,
        0x90,
        0x93,
        0x96,
        0x95,
        0x9C,
        0x9F,
        0x9A,
        0x99,
        0x88,
        0x8B,
        0x8E,
        0x8D,
        0x84,
        0x87,
        0x82,
        0x81,
        0x9B,
        0x98,
        0x9D,
        0x9E,
        0x97,
        0x94,
        0x91,
        0x92,
        0x83,
        0x80,
        0x85,
        0x86,
        0x8F,
        0x8C,
        0x89,
        0x8A,
        0xAB,
        0xA8,
        0xAD,
        0xAE,
        0xA7,
        0xA4,
        0xA1,
        0xA2,
        0xB3,
        0xB0,
        0xB5,
        0xB6,
        0xBF,
        0xBC,
        0xB9,
        0xBA,
        0xFB,
        0xF8,
        0xFD,
        0xFE,
        0xF7,
        0xF4,
        0xF1,
        0xF2,
        0xE3,
        0xE0,
        0xE5,
        0xE6,
        0xEF,
        0xEC,
        0xE9,
        0xEA,
        0xCB,
        0xC8,
        0xCD,
        0xCE,
        0xC7,
        0xC4,
        0xC1,
        0xC2,
        0xD3,
        0xD0,
        0xD5,
        0xD6,
        0xDF,
        0xDC,
        0xD9,
        0xDA,
        0x5B,
        0x58,
        0x5D,
        0x5E,
        0x57,
        0x54,
        0x51,
        0x52,
        0x43,
        0x40,
        0x45,
        0x46,
        0x4F,
        0x4C,
        0x49,
        0x4A,
        0x6B,
        0x68,
        0x6D,
        0x6E,
        0x67,
        0x64,
        0x61,
        0x62,
        0x73,
        0x70,
        0x75,
        0x76,
        0x7F,
        0x7C,
        0x79,
        0x7A,
        0x3B,
        0x38,
        0x3D,
        0x3E,
        0x37,
        0x34,
        0x31,
        0x32,
        0x23,
        0x20,
        0x25,
        0x26,
        0x2F,
        0x2C,
        0x29,
        0x2A,
        0x0B,
        0x08,
        0x0D,
        0x0E,
        0x07,
        0x04,
        0x01,
        0x02,
        0x13,
        0x10,
        0x15,
        0x16,
        0x1F,
        0x1C,
        0x19,
        0x1A,
    ],
    dtype=np.uint8,
)

_SBOX = np.array(
    [
        0x63,
        0x7C,
        0x77,
        0x7B,
        0xF2,
        0x6B,
        0x6F,
        0xC5,
        0x30,
        0x01,
        0x67,
        0x2B,
        0xFE,
        0xD7,
        0xAB,
        0x76,
        0xCA,
        0x82,
        0xC9,
        0x7D,
        0xFA,
        0x59,
        0x47,
        0xF0,
        0xAD,
        0xD4,
        0xA2,
        0xAF,
        0x9C,
        0xA4,
        0x72,
        0xC0,
        0xB7,
        0xFD,
        0x93,
        0x26,
        0x36,
        0x3F,
        0xF7,
        0xCC,
        0x34,
        0xA5,
        0xE5,
        0xF1,
        0x71,
        0xD8,
        0x31,
        0x15,
        0x04,
        0xC7,
        0x23,
        0xC3,
        0x18,
        0x96,
        0x05,
        0x9A,
        0x07,
        0x12,
        0x80,
        0xE2,
        0xEB,
        0x27,
        0xB2,
        0x75,
        0x09,
        0x83,
        0x2C,
        0x1A,
        0x1B,
        0x6E,
        0x5A,
        0xA0,
        0x52,
        0x3B,
        0xD6,
        0xB3,
        0x29,
        0xE3,
        0x2F,
        0x84,
        0x53,
        0xD1,
        0x00,
        0xED,
        0x20,
        0xFC,
        0xB1,
        0x5B,
        0x6A,
        0xCB,
        0xBE,
        0x39,
        0x4A,
        0x4C,
        0x58,
        0xCF,
        0xD0,
        0xEF,
        0xAA,
        0xFB,
        0x43,
        0x4D,
        0x33,
        0x85,
        0x45,
        0xF9,
        0x02,
        0x7F,
        0x50,
        0x3C,
        0x9F,
        0xA8,
        0x51,
        0xA3,
        0x40,
        0x8F,
        0x92,
        0x9D,
        0x38,
        0xF5,
        0xBC,
        0xB6,
        0xDA,
        0x21,
        0x10,
        0xFF,
        0xF3,
        0xD2,
        0xCD,
        0x0C,
        0x13,
        0xEC,
        0x5F,
        0x97,
        0x44,
        0x17,
        0xC4,
        0xA7,
        0x7E,
        0x3D,
        0x64,
        0x5D,
        0x19,
        0x73,
        0x60,
        0x81,
        0x4F,
        0xDC,
        0x22,
        0x2A,
        0x90,
        0x88,
        0x46,
        0xEE,
        0xB8,
        0x14,
        0xDE,
        0x5E,
        0x0B,
        0xDB,
        0xE0,
        0x32,
        0x3A,
        0x0A,
        0x49,
        0x06,
        0x24,
        0x5C,
        0xC2,
        0xD3,
        0xAC,
        0x62,
        0x91,
        0x95,
        0xE4,
        0x79,
        0xE7,
        0xC8,
        0x37,
        0x6D,
        0x8D,
        0xD5,
        0x4E,
        0xA9,
        0x6C,
        0x56,
        0xF4,
        0xEA,
        0x65,
        0x7A,
        0xAE,
        0x08,
        0xBA,
        0x78,
        0x25,
        0x2E,
        0x1C,
        0xA6,
        0xB4,
        0xC6,
        0xE8,
        0xDD,
        0x74,
        0x1F,
        0x4B,
        0xBD,
        0x8B,
        0x8A,
        0x70,
        0x3E,
        0xB5,
        0x66,
        0x48,
        0x03,
        0xF6,
        0x0E,
        0x61,
        0x35,
        0x57,
        0xB9,
        0x86,
        0xC1,
        0x1D,
        0x9E,
        0xE1,
        0xF8,
        0x98,
        0x11,
        0x69,
        0xD9,
        0x8E,
        0x94,
        0x9B,
        0x1E,
        0x87,
        0xE9,
        0xCE,
        0x55,
        0x28,
        0xDF,
        0x8C,
        0xA1,
        0x89,
        0x0D,
        0xBF,
        0xE6,
        0x42,
        0x68,
        0x41,
        0x99,
        0x2D,
        0x0F,
        0xB0,
        0x54,
        0xBB,
        0x16,
    ],
    dtype=np.uint8,
)

_LUT_INPUT_COL = np.array(
    [[0, 1, 2, 3], [4, 5, 6, 7], [8, 9, 10, 11], [12, 13, 14, 15]], dtype=np.int32
)
_LUT_INPUT_ROW = np.transpose(_LUT_INPUT_COL)

_BASE_LUT_MIX_COLUMN = np.array(
    [
        [0, 13, 10, 7],
        [4, 1, 14, 11],
        [8, 5, 2, 15],
        [12, 9, 6, 3],
    ],
    dtype=np.int32,
)


def _inc_vec(x):
    for i in range(4):
        r = range(4 * i, 4 * i + 4)
        if x in r:
            x += 1
            if x not in r:
                x = r[0]
            return x
    return x


def _generate_lut_mix_column():
    lut_mix_col = [_BASE_LUT_MIX_COLUMN.copy()]
    for _ in range(3):
        prev = lut_mix_col[-1].copy()
        new_lut = np.array(
            [[_inc_vec(int(prev[j][k])) for k in range(4)] for j in range(4)],
            dtype=np.int32,
        )
        lut_mix_col.append(new_lut)
    return lut_mix_col


_LUT_MIX_COLUMN_COL = _generate_lut_mix_column()
_LUT_MIX_COLUMN_ROW = [np.transpose(lut) for lut in _LUT_MIX_COLUMN_COL]


_GAL_LUT = [
    _GAL2,
    _GAL3,
    np.arange(256, dtype=np.uint8),
    np.arange(256, dtype=np.uint8),
]


def mix_columns(state):
    result = np.zeros(16, dtype=np.uint8)
    for c in range(4):
        idx = c * 4
        s0, s1, s2, s3 = state[idx], state[idx + 1], state[idx + 2], state[idx + 3]
        result[idx] = _GAL2[s0] ^ _GAL3[s1] ^ s2 ^ s3
        result[idx + 1] = s0 ^ _GAL2[s1] ^ _GAL3[s2] ^ s3
        result[idx + 2] = s0 ^ s1 ^ _GAL2[s2] ^ _GAL3[s3]
        result[idx + 3] = _GAL3[s0] ^ s1 ^ s2 ^ _GAL2[s3]
    return result


def sub_bytes(state):
    return _SBOX[state]


@dataclass
class MixColumnsResult(AnalysisResult):
    num_subkeys: int = 16
    num_campaigns: int = 4
    num_bits: int = 8
    threshold: float = 0.5
    num_traces: int = 0
    total_samples: int = 0
    best_guesses: list[dict] = field(default_factory=list)
    key_guess: list[int] = field(default_factory=list)
    correlations: list[np.ndarray] = field(default_factory=list)
    pge: list[int] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)


class MixColumnsCPAAnalyzer:
    name: str = "mix_columns_cpa"
    description: str = (
        "CPA attack on AES MixColumns output using Monobit leakage models"
    )

    def __init__(self, config: dict[str, Any] | None = None):
        self.config = config or {}
        self.threshold = self.config.get("threshold", 0.5)
        self.vec_type = self.config.get("vec_type", "column")
        self.hamming_distance = self.config.get("hamming_distance", True)
        self.target_bytes = list(range(16))

    def analyze(
        self,
        traces: np.ndarray,
        plaintext: np.ndarray,
        key: np.ndarray | None = None,
        **kwargs,
    ) -> MixColumnsResult:
        num_traces, num_samples = traces.shape
        input_path = kwargs.get("input_path", "")

        all_campaign_correlations = []
        key_guess = [0] * 16

        for campaign in range(4):
            campaign_corr = self._run_campaign_cpa(traces, plaintext, campaign)
            all_campaign_correlations.append(campaign_corr)

            byte_range = self._get_byte_range(campaign)
            for idx, byte_idx in enumerate(byte_range):
                max_corr = np.max(np.abs(campaign_corr[idx]), axis=1)
                best_guess = np.argmax(max_corr)
                key_guess[byte_idx] = int(best_guess)

        combined_corr = self._combine_correlations(all_campaign_correlations)

        best_guesses = []
        pge = []
        for bnum in range(16):
            max_corr = np.max(np.abs(combined_corr[bnum]), axis=1)
            best_idx = np.argmax(max_corr)
            best_corr = max_corr[best_idx]

            guess = {
                "byte": bnum,
                "guess": int(best_idx),
                "correlation": float(best_corr),
            }

            if key is not None and len(key) >= bnum + 1:
                known = key[bnum]
                sorted_guesses = np.argsort(-max_corr)
                match_positions = np.where(sorted_guesses == known)[0]
                if len(match_positions) > 0:
                    rank = match_positions[0]
                    guess["pge"] = int(rank)
                    pge.append(int(rank))
                else:
                    guess["pge"] = None
                    pge.append(255)
            else:
                guess["pge"] = None
                pge.append(255)

            best_guesses.append(guess)

        return MixColumnsResult(
            method="mix_columns_cpa",
            input_path=input_path,
            num_traces=num_traces,
            total_samples=num_samples,
            num_subkeys=16,
            threshold=self.threshold,
            best_guesses=best_guesses,
            key_guess=key_guess,
            correlations=combined_corr,
            pge=pge,
            metadata={
                "vec_type": self.vec_type,
                "hamming_distance": self.hamming_distance,
            },
        )

    def _run_campaign_cpa(
        self,
        traces: np.ndarray,
        plaintext: np.ndarray,
        campaign: int,
    ) -> list[np.ndarray]:
        lut_in = _LUT_INPUT_COL if self.vec_type == "column" else _LUT_INPUT_ROW
        lut_out = _LUT_MIX_COLUMN_COL[campaign]
        gal_idx = campaign

        byte_range = self._get_byte_range(campaign)
        num_bytes = len(byte_range)

        byte_correlations = []
        for b_idx in range(num_bytes):
            byte_corr = np.zeros((256, traces.shape[1]), dtype=np.float64)
            for bit in range(8):
                # Compute MixColumns intermediate for ALL 256 key hypotheses,
                # then correlate the specific bit with traces (reference algorithm)
                bit_corr = self._compute_bit_correlation(
                    traces, plaintext, byte_range[b_idx], lut_in, lut_out, gal_idx, bit
                )
                byte_corr += np.abs(bit_corr)

            byte_correlations.append(byte_corr)

        return byte_correlations

    def _compute_leakage(
        self,
        plaintext: np.ndarray,
        target_byte: int,
        lut_in,
        lut_out,
        gal_idx: int,
    ) -> np.ndarray:
        num_traces = plaintext.shape[0]
        leakage = np.zeros(num_traces, dtype=np.float64)

        for tnum in range(num_traces):
            pt = plaintext[tnum]
            sbox_out = _SBOX[pt[target_byte]]

            mix_col_out = np.zeros(4, dtype=np.uint8)
            for k in range(4):
                in_byte_idx = lut_in[target_byte // 4][k]
                out_byte_idx = lut_out[target_byte // 4][k]
                mix_col_out[k] = pt[in_byte_idx]

            mc_result = np.zeros(4, dtype=np.uint8)
            mc_result[0] = _GAL_LUT[gal_idx][sbox_out] ^ mix_col_out[0]
            mc_result[1] = mix_col_out[1]
            mc_result[2] = mix_col_out[2]
            mc_result[3] = mix_col_out[3]

            mix_col_mixed = mix_columns(
                np.concatenate([mc_result, np.zeros(12, dtype=np.uint8)])
            )

            bit_pos = target_byte % 8
            for k in range(4):
                leakage[tnum] += (mix_col_mixed[k] >> (7 - bit_pos)) & 1

        return leakage

    def _compute_bit_correlation(
        self,
        traces: np.ndarray,
        plaintext: np.ndarray,
        target_byte: int,
        lut_in,
        lut_out,
        gal_idx: int,
        bit: int,
    ) -> np.ndarray:
        num_traces, num_samples = traces.shape
        pt_byte = plaintext[:, target_byte]

        sbox_per_guess = _SBOX[pt_byte[:, np.newaxis] ^ np.arange(256, dtype=np.uint8)]
        gal_per_guess = _GAL_LUT[gal_idx][sbox_per_guess]
        pt_per_trace = plaintext[:, target_byte : target_byte + 1]
        inter = gal_per_guess ^ pt_per_trace

        bit_val = ((inter >> (7 - bit)) & 1).astype(np.float64)

        bit_val = bit_val.T
        hw_mean = bit_val.mean(axis=1, keepdims=True)
        trace_mean = traces.mean(axis=0, keepdims=True)
        bit_centered = bit_val - hw_mean
        trace_centered = traces - trace_mean
        cov = np.dot(bit_centered, trace_centered) / num_traces
        bit_std = np.sqrt(np.sum(bit_centered**2, axis=1, keepdims=True) + 1e-10)
        trace_std = np.sqrt(np.sum(trace_centered**2, axis=0, keepdims=True) + 1e-10)
        corr = cov / (bit_std * trace_std)

        return np.abs(corr)

    def _get_byte_range(self, campaign: int) -> list[int]:
        if self.vec_type == "column":
            return [campaign * 4 + i for i in range(4)]
        else:
            return [campaign + 4 * i for i in range(4)]

    def _combine_correlations(
        self,
        all_campaign_correlations: list[list[np.ndarray]],
    ) -> list[np.ndarray]:
        combined = [np.zeros((256, 0), dtype=np.float64) for _ in range(16)]

        for campaign, byte_corrs in enumerate(all_campaign_correlations):
            byte_range = self._get_byte_range(campaign)
            for idx, byte_idx in enumerate(byte_range):
                combined[byte_idx] = byte_corrs[idx]

        return combined

    def detect_leakage_points(
        self,
        result: MixColumnsResult,
        threshold: float | None = None,
    ) -> np.ndarray:
        if threshold is None:
            threshold = self.threshold

        if not result.correlations:
            return np.array([], dtype=int)

        combined = np.max(np.abs(np.stack(result.correlations)), axis=0)
        return np.where(combined > threshold)[0]


__all__ = [
    "MixColumnsResult",
    "MixColumnsCPAAnalyzer",
]
