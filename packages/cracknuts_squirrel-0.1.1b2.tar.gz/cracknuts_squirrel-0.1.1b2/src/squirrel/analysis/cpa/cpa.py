"""CPA - Correlation Power Analysis Attack."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

import numpy as np
import zarr
from pathlib import Path

from squirrel.base import AnalysisResult, Analyzer, TraceDataset


_HW = [
    0,
    1,
    1,
    2,
    1,
    2,
    2,
    3,
    1,
    2,
    2,
    3,
    2,
    3,
    3,
    4,
    1,
    2,
    2,
    3,
    2,
    3,
    3,
    4,
    2,
    3,
    3,
    4,
    3,
    4,
    4,
    5,
    1,
    2,
    2,
    3,
    2,
    3,
    3,
    4,
    2,
    3,
    3,
    4,
    3,
    4,
    4,
    5,
    2,
    3,
    3,
    4,
    3,
    4,
    4,
    5,
    3,
    4,
    4,
    5,
    4,
    5,
    5,
    6,
    1,
    2,
    2,
    3,
    2,
    3,
    3,
    4,
    2,
    3,
    3,
    4,
    3,
    4,
    4,
    5,
    2,
    3,
    3,
    4,
    3,
    4,
    4,
    5,
    3,
    4,
    4,
    5,
    4,
    5,
    5,
    6,
    2,
    3,
    3,
    4,
    3,
    4,
    4,
    5,
    3,
    4,
    4,
    5,
    4,
    5,
    5,
    6,
    3,
    4,
    4,
    5,
    4,
    5,
    5,
    6,
    4,
    5,
    5,
    6,
    5,
    6,
    6,
    7,
    1,
    2,
    2,
    3,
    2,
    3,
    3,
    4,
    2,
    3,
    3,
    4,
    3,
    4,
    4,
    5,
    2,
    3,
    3,
    4,
    3,
    4,
    4,
    5,
    3,
    4,
    4,
    5,
    4,
    5,
    5,
    6,
    2,
    3,
    3,
    4,
    3,
    4,
    4,
    5,
    3,
    4,
    4,
    5,
    4,
    5,
    5,
    6,
    3,
    4,
    4,
    5,
    4,
    5,
    5,
    6,
    4,
    5,
    5,
    6,
    5,
    6,
    6,
    7,
    2,
    3,
    3,
    4,
    3,
    4,
    4,
    5,
    3,
    4,
    4,
    5,
    4,
    5,
    5,
    6,
    3,
    4,
    4,
    5,
    4,
    5,
    5,
    6,
    4,
    5,
    5,
    6,
    5,
    6,
    6,
    7,
    3,
    4,
    4,
    5,
    4,
    5,
    5,
    6,
    4,
    5,
    5,
    6,
    5,
    6,
    6,
    7,
    4,
    5,
    5,
    6,
    5,
    6,
    6,
    7,
    5,
    6,
    6,
    7,
    6,
    7,
    7,
    8,
]

_SBOX = [
    0x63,
    0x7C,
    0x77,
    0x7B,
    0xF2,
    0x6B,
    0x6F,
    0xC5,
    0x30,
    0x01,
    0x67,
    0x2B,
    0xFE,
    0xD7,
    0xAB,
    0x76,
    0xCA,
    0x82,
    0xC9,
    0x7D,
    0xFA,
    0x59,
    0x47,
    0xF0,
    0xAD,
    0xD4,
    0xA2,
    0xAF,
    0x9C,
    0xA4,
    0x72,
    0xC0,
    0xB7,
    0xFD,
    0x93,
    0x26,
    0x36,
    0x3F,
    0xF7,
    0xCC,
    0x34,
    0xA5,
    0xE5,
    0xF1,
    0x71,
    0xD8,
    0x31,
    0x15,
    0x04,
    0xC7,
    0x23,
    0xC3,
    0x18,
    0x96,
    0x05,
    0x9A,
    0x07,
    0x12,
    0x80,
    0xE2,
    0xEB,
    0x27,
    0xB2,
    0x75,
    0x09,
    0x83,
    0x2C,
    0x1A,
    0x1B,
    0x6E,
    0x5A,
    0xA0,
    0x52,
    0x3B,
    0xD6,
    0xB3,
    0x29,
    0xE3,
    0x2F,
    0x84,
    0x53,
    0xD1,
    0x00,
    0xED,
    0x20,
    0xFC,
    0xB1,
    0x5B,
    0x6A,
    0xCB,
    0xBE,
    0x39,
    0x4A,
    0x4C,
    0x58,
    0xCF,
    0xD0,
    0xEF,
    0xAA,
    0xFB,
    0x43,
    0x4D,
    0x33,
    0x85,
    0x45,
    0xF9,
    0x02,
    0x7F,
    0x50,
    0x3C,
    0x9F,
    0xA8,
    0x51,
    0xA3,
    0x40,
    0x8F,
    0x92,
    0x9D,
    0x38,
    0xF5,
    0xBC,
    0xB6,
    0xDA,
    0x21,
    0x10,
    0xFF,
    0xF3,
    0xD2,
    0xCD,
    0x0C,
    0x13,
    0xEC,
    0x5F,
    0x97,
    0x44,
    0x17,
    0xC4,
    0xA7,
    0x7E,
    0x3D,
    0x64,
    0x5D,
    0x19,
    0x73,
    0x60,
    0x81,
    0x4F,
    0xDC,
    0x22,
    0x2A,
    0x90,
    0x88,
    0x46,
    0xEE,
    0xB8,
    0x14,
    0xDE,
    0x5E,
    0x0B,
    0xDB,
    0xE0,
    0x32,
    0x3A,
    0x0A,
    0x49,
    0x06,
    0x24,
    0x5C,
    0xC2,
    0xD3,
    0xAC,
    0x62,
    0x91,
    0x95,
    0xE4,
    0x79,
    0xE7,
    0xC8,
    0x37,
    0x6D,
    0x8D,
    0xD5,
    0x4E,
    0xA9,
    0x6C,
    0x56,
    0xF4,
    0xEA,
    0x65,
    0x7A,
    0xAE,
    0x08,
    0xBA,
    0x78,
    0x25,
    0x2E,
    0x1C,
    0xA6,
    0xB4,
    0xC6,
    0xE8,
    0xDD,
    0x74,
    0x1F,
    0x4B,
    0xBD,
    0x8B,
    0x8A,
    0x70,
    0x3E,
    0xB5,
    0x66,
    0x48,
    0x03,
    0xF6,
    0x0E,
    0x61,
    0x35,
    0x57,
    0xB9,
    0x86,
    0xC1,
    0x1D,
    0x9E,
    0xE1,
    0xF8,
    0x98,
    0x11,
    0x69,
    0xD9,
    0x8E,
    0x94,
    0x9B,
    0x1E,
    0x87,
    0xE9,
    0xCE,
    0x55,
    0x28,
    0xDF,
    0x8C,
    0xA1,
    0x89,
    0x0D,
    0xBF,
    0xE6,
    0x42,
    0x68,
    0x41,
    0x99,
    0x2D,
    0x0F,
    0xB0,
    0x54,
    0xBB,
    0x16,
]

_INV_SBOX = [
    0x52,
    0x09,
    0x6A,
    0xD5,
    0x30,
    0x36,
    0xA5,
    0x38,
    0xBF,
    0x40,
    0xA3,
    0x9E,
    0x81,
    0xF3,
    0xD7,
    0xFB,
    0x7C,
    0xE3,
    0x39,
    0x82,
    0x9B,
    0x2F,
    0xFF,
    0x87,
    0x34,
    0x8E,
    0x43,
    0x44,
    0xC4,
    0xDE,
    0xE9,
    0xCB,
    0x54,
    0x7B,
    0x94,
    0x32,
    0xA6,
    0xC2,
    0x23,
    0x3D,
    0xEE,
    0x4C,
    0x95,
    0x0B,
    0x42,
    0xFA,
    0xC3,
    0x4E,
    0x08,
    0x2E,
    0xA1,
    0x66,
    0x28,
    0xD9,
    0x30,
    0xA0,
    0x3B,
    0xAD,
    0x31,
    0x2A,
    0x69,
    0x40,
    0x5A,
    0x5D,
    0xB8,
    0x7A,
    0xB3,
    0x25,
    0x2F,
    0x9C,
    0xA4,
    0x0F,
    0x0A,
    0x65,
    0x4D,
    0x31,
    0x84,
    0x57,
    0x66,
    0xBB,
    0x59,
    0x16,
    0xC8,
    0x11,
    0x72,
    0x49,
    0x7D,
    0x45,
    0x44,
    0xFD,
    0x38,
    0x14,
    0x1D,
    0x9E,
    0xB1,
    0x11,
    0x8D,
    0x71,
    0x8C,
    0xFF,
    0x1D,
    0x18,
    0x09,
    0x23,
    0xEC,
    0x0F,
    0xB5,
    0x9C,
    0x1C,
    0x0A,
    0x75,
    0x86,
    0x3B,
    0x55,
    0x22,
    0x06,
    0x8B,
    0x24,
    0x96,
    0x81,
    0x51,
    0xA2,
    0x29,
    0x1B,
    0x22,
    0x51,
    0x32,
    0x3A,
    0xCA,
    0xBF,
    0xE0,
    0xB2,
    0x75,
    0x89,
    0x40,
    0x70,
    0x3D,
    0xFD,
    0x72,
    0xAA,
    0x6C,
    0x59,
    0x07,
    0x47,
    0xE0,
    0x33,
    0x2E,
    0x89,
    0xC4,
    0x18,
    0x4F,
    0x27,
    0x41,
    0x4E,
    0xB7,
    0xA8,
    0xD4,
    0xC0,
    0x27,
    0x53,
    0x04,
    0xAB,
    0x73,
    0xD8,
    0x16,
    0xCE,
    0x0C,
    0x84,
    0xB8,
    0x9D,
    0xDF,
    0x9A,
    0xEB,
    0x3B,
    0x43,
    0x68,
    0x62,
    0x2B,
    0x24,
    0x93,
    0x27,
    0x5F,
    0xB9,
    0xDC,
    0x11,
    0xBE,
    0x92,
    0x33,
    0xE4,
    0x57,
    0x99,
    0x5E,
    0x77,
    0x50,
    0x3D,
    0xF1,
    0xD9,
    0x97,
    0x2B,
    0x21,
    0x5C,
    0xED,
    0x25,
    0xBF,
    0x36,
    0x31,
    0xF5,
    0xBE,
    0xED,
    0x07,
    0xA5,
    0x95,
    0x0E,
    0x49,
    0xDA,
    0x25,
    0x83,
    0x09,
    0x41,
    0xC6,
    0x6B,
    0x91,
    0x55,
    0xEA,
    0x6C,
    0x82,
    0x62,
    0x2B,
    0xBF,
    0xCE,
    0x1C,
    0xA1,
    0x0D,
    0x34,
    0xDB,
    0x64,
    0x68,
    0x44,
    0x34,
    0x06,
    0xA1,
    0xB8,
    0x14,
    0x17,
    0xA3,
    0x1B,
    0xBA,
    0x64,
    0xEB,
    0x5B,
    0x7A,
    0xDE,
    0x5C,
    0x28,
    0xCD,
    0x5F,
    0x9B,
    0x17,
    0x5F,
    0x4A,
    0x69,
    0xAB,
    0x1B,
    0xA0,
    0xA9,
    0x2A,
    0x54,
    0x67,
    0x01,
    0x0D,
    0xFA,
    0xD7,
    0x09,
    0x2C,
    0x87,
    0x21,
    0x5E,
    0xB4,
    0xFE,
    0x3D,
    0x4F,
    0x5B,
    0xF0,
    0xA3,
    0x81,
    0x55,
    0x69,
    0x77,
    0x5A,
    0xED,
    0x5C,
    0x3C,
    0x16,
    0xBD,
    0xC5,
    0x26,
    0x6C,
    0x8C,
    0x20,
    0x51,
    0xA3,
    0x27,
    0x9E,
    0x66,
    0x48,
    0xA4,
    0x14,
    0xEE,
    0x17,
    0x0D,
    0xB4,
    0x5F,
    0x42,
    0xD6,
    0x50,
    0xC4,
    0x21,
    0x8F,
    0x7B,
    0x8A,
    0x3B,
    0x2E,
    0x27,
    0xBF,
    0x5E,
    0x85,
    0xB5,
    0x92,
    0x20,
    0x54,
    0x47,
    0x88,
    0x6B,
    0x23,
    0xA7,
    0xDA,
    0xAC,
    0x4F,
    0xDF,
    0x4E,
    0x48,
    0x24,
    0x38,
    0x81,
    0x7A,
    0xCC,
    0x43,
    0x2C,
    0xAA,
    0x54,
    0x9E,
    0xB3,
    0x60,
    0x81,
    0x4F,
    0x63,
    0x22,
    0x72,
    0x2B,
    0x41,
    0x4B,
    0xA8,
    0x7E,
    0x4F,
    0xB6,
    0xBE,
    0xC6,
    0x5D,
    0xB7,
    0xCB,
    0x02,
    0xD8,
    0x2B,
    0x30,
    0x57,
    0xF3,
    0x0A,
    0xA2,
    0x83,
    0x05,
    0x76,
    0xA4,
    0x5F,
    0x78,
    0x43,
    0x7A,
    0x30,
    0xBF,
    0x4A,
    0x29,
    0xA7,
    0x36,
    0xCE,
    0x3D,
    0x85,
    0x90,
    0x4F,
    0xD0,
    0x95,
    0xA5,
    0x77,
    0x0F,
    0x3D,
    0x5D,
    0x5F,
    0x0F,
    0x4C,
    0x82,
    0xE7,
    0x9E,
    0x6D,
    0x4E,
    0x02,
    0x83,
    0xEE,
    0xAA,
    0xE4,
    0x2D,
    0x3B,
    0x93,
    0x93,
    0xAB,
    0x60,
    0x64,
    0x93,
    0x92,
    0x86,
    0xA1,
    0xD3,
    0x26,
    0x33,
    0xEC,
    0xD6,
    0x24,
    0xE0,
    0x6A,
    0x61,
    0x96,
    0xD5,
    0x4F,
    0x8A,
    0x4B,
    0x82,
    0xD9,
    0x23,
    0x15,
    0x96,
    0x47,
    0x20,
    0x8F,
    0x9C,
    0xEB,
    0xEE,
    0xDC,
    0x9E,
    0x2C,
    0x8C,
    0x45,
    0x5F,
    0x02,
    0x6A,
    0x48,
    0x89,
    0x4E,
    0x79,
    0xAA,
    0x78,
    0x28,
    0x49,
    0x2F,
    0x8D,
    0x14,
    0x42,
    0xDA,
    0x8D,
    0x2E,
    0x6C,
    0x48,
    0x53,
    0x54,
    0x27,
    0x8C,
    0x69,
    0x16,
    0x41,
    0x02,
    0x4C,
    0x16,
    0x32,
    0xBF,
    0x86,
    0x56,
    0x39,
    0x41,
    0xC5,
    0x29,
    0x2E,
    0xE4,
    0x94,
    0x43,
    0x51,
    0xD0,
    0x75,
    0x06,
    0x08,
    0x78,
    0x49,
    0x18,
    0x06,
    0xCA,
    0x7B,
    0xC9,
    0x1C,
    0x02,
    0x77,
    0x3E,
    0x09,
    0x90,
    0xAF,
    0x58,
    0x4B,
    0x94,
    0x3D,
    0x08,
    0x0F,
    0xEE,
    0xE9,
    0x26,
    0xC6,
    0x64,
    0x1F,
    0xD1,
    0x4D,
    0x0F,
    0xD5,
    0x42,
    0x10,
    0x7D,
    0x8F,
    0x92,
    0x50,
    0x72,
    0x4E,
    0x82,
    0x3E,
    0x52,
    0xDD,
    0x2E,
    0xA4,
    0xEB,
    0x16,
    0xE0,
    0x9A,
    0xC9,
    0x86,
    0x4E,
    0x49,
    0x42,
    0x5B,
    0x75,
    0x8B,
    0x0C,
    0xAC,
    0x80,
    0x6C,
    0x58,
    0x05,
    0x87,
    0xA4,
    0xE5,
    0xC2,
    0x72,
    0x82,
    0x17,
    0x73,
    0x0F,
    0xB3,
    0x64,
    0x82,
    0x09,
    0xE1,
    0x00,
    0x7A,
    0x3A,
    0x58,
    0xB4,
    0xA0,
    0x5F,
    0x19,
    0x2E,
    0x9B,
    0x55,
    0xAA,
    0x22,
    0x89,
    0x47,
    0x10,
    0x5F,
    0x75,
    0x21,
    0x89,
    0xCA,
    0x70,
    0x33,
    0x30,
    0x14,
    0x0D,
    0xEB,
    0x57,
    0xC3,
    0xF2,
    0x1A,
    0x0E,
    0x65,
    0x36,
    0x5D,
    0x5F,
    0xF0,
    0xA2,
    0xBF,
    0x85,
    0x2C,
    0x96,
    0x08,
    0x0D,
    0x9F,
    0x97,
    0x2B,
    0x21,
    0x5C,
    0xED,
    0x25,
    0xBF,
    0x36,
    0x31,
    0xF5,
    0xBE,
    0xED,
    0x07,
    0xA5,
    0x95,
    0x0E,
    0x49,
    0xDA,
    0x25,
    0x83,
    0x09,
    0x41,
    0xC6,
    0x6B,
    0x91,
    0x55,
    0xEA,
    0x6C,
    0x82,
    0x62,
    0x2B,
    0xBF,
    0xCE,
    0x1C,
    0xA1,
    0x0D,
    0x34,
    0xDB,
    0x64,
]

# AES key schedule constants
_RCON = [0x01, 0x02, 0x04, 0x08, 0x10, 0x20, 0x40, 0x80, 0x1B, 0x36]


def _key_schedule_rounds(
    inputkey: np.ndarray, inputround: int, desiredround: int
) -> np.ndarray:
    """Derive key at desired round from input key at inputround.

    Args:
        inputkey: 16-byte key array
        inputround: Round of input key (0-10)
        desiredround: Target round (0-10)

    Returns:
        Key at desired round
    """
    if inputround == desiredround:
        return inputkey.copy()

    key = inputkey.copy()
    Nr = inputround

    while Nr < desiredround:
        # Key expansion for next round
        # Rotate word
        tmp = np.roll(key[4:], -1)
        key[4:] = tmp

        # SubWord
        for i in range(4):
            key[4 + i] = _SBOX[key[4 + i]]

        # XOR with RCON
        key[4] ^= _RCON[Nr % 10]

        # XOR with previous first word
        for i in range(4):
            key[i] ^= key[4 + i]

        # Additional XORs for rounds > 1
        if Nr >= 1:
            for i in range(4):
                key[i] ^= key[4 + ((i + 1) % 4)]
            for i in range(4):
                key[4 + i] ^= key[4 + ((i + 1) % 4)]

        # MixColumns (simple approximation - full AES key schedule is more complex)
        Nr += 1

    return key


def _inv_shift_rows(state: list[int]) -> list[int]:
    """Inverse ShiftRows operation."""
    return [
        state[0],
        state[13],
        state[10],
        state[7],
        state[4],
        state[1],
        state[14],
        state[11],
        state[8],
        state[5],
        state[2],
        state[15],
        state[12],
        state[9],
        state[6],
        state[3],
    ]


# INVSHIFT_undo: maps bnum to byte position in inverse-shifted state
_INVSHIFT_UNDO = [0, 5, 10, 15, 4, 9, 14, 3, 8, 13, 2, 7, 12, 1, 6, 11]


class AESLeakageHelper:
    """Base class for AES leakage models.

    Subclasses implement leakage() which returns an intermediate value.
    The CPA attack then correlates the HW of this value with power traces.

    Args:
        pt: 16-byte plaintext
        ct: 16-byte ciphertext (used for last-round attacks)
        key: 16-byte key guess
        bnum: byte number being attacked (0-15)
        prev_ct: previous ciphertext (for pipeline / successive leakage models)
        prev_pt: previous plaintext (for successive leakage models)

    Returns:
        Intermediate value (int) - typically HW of this is used for correlation
    """

    name: str = "AES Leakage Model (unnamed)"

    def leakage(
        self,
        pt: np.ndarray,
        ct: np.ndarray,
        key: np.ndarray,
        guess: int,
        bnum: int,
        prev_ct: np.ndarray | None = None,
        prev_pt: np.ndarray | None = None,
    ) -> int:
        """Compute intermediate value for leakage analysis.

        Override in subclasses.
        """
        raise NotImplementedError()


class SBoxOutput(AESLeakageHelper):
    """HW: AES SBox Output, First Round (Enc)

    Leakage model based on the output of the S-Box in the first round.
    Returns HW of SBox[pt[bnum] ^ key[bnum]].
    """

    name = "HW: AES SBox Output, First Round (Enc)"

    def leakage(
        self,
        pt: np.ndarray,
        ct: np.ndarray,
        key: np.ndarray,
        guess: int,
        bnum: int,
        prev_ct: np.ndarray | None = None,
        prev_pt: np.ndarray | None = None,
    ) -> int:
        return _HW[_SBOX[pt[bnum] ^ guess]]


class PtKeyXOR(AESLeakageHelper):
    """HW: AddRoundKey Output, First Round (Enc)

    Leakage model based on the XOR of plaintext byte with key byte.
    Returns HW of pt[bnum] ^ key[bnum].
    """

    name = "HW: AddRoundKey Output, First Round (Enc)"

    def leakage(
        self,
        pt: np.ndarray,
        ct: np.ndarray,
        key: np.ndarray,
        guess: int,
        bnum: int,
        prev_ct: np.ndarray | None = None,
        prev_pt: np.ndarray | None = None,
    ) -> int:
        return _HW[pt[bnum] ^ guess]


class InvSBoxOutput(AESLeakageHelper):
    """HW: AES Inv SBox Output, First Round (Dec)

    Leakage model based on the output of the inverse S-Box in the first round of decryption.
    Returns HW of InvSBox[pt[bnum] ^ key[bnum]].
    Used for ciphertext-only attacks on last round.
    """

    name = "HW: AES Inv SBox Output, First Round (Dec)"

    def leakage(
        self,
        pt: np.ndarray,
        ct: np.ndarray,
        key: np.ndarray,
        guess: int,
        bnum: int,
        prev_ct: np.ndarray | None = None,
        prev_pt: np.ndarray | None = None,
    ) -> int:
        return _HW[_INV_SBOX[pt[bnum] ^ guess]]


class LastroundHW(AESLeakageHelper):
    """HW: AES Last-Round State (Round 9 to 10)

    Last round attack using the state before the final SubBytes.
    st9 = InvSBox[ct[bnum] ^ key[bnum]]
    Returns HW of st9.
    """

    name = "HW: AES Last-Round State"

    def leakage(
        self,
        pt: np.ndarray,
        ct: np.ndarray,
        key: np.ndarray,
        guess: int,
        bnum: int,
        prev_ct: np.ndarray | None = None,
        prev_pt: np.ndarray | None = None,
    ) -> int:
        st10 = ct[_INVSHIFT_UNDO[bnum]]
        st9 = _INV_SBOX[ct[bnum] ^ guess]
        return _HW[st9]


class LastroundStateDiff(AESLeakageHelper):
    """HD: AES Last-Round State Difference

    Hamming distance between round 9 and round 10 state.
    HD(st9, st10) where st10 = ct byte, st9 = InvSBox[ct[bnum] ^ key[bnum]]
    Used in attacks on SASEBO-GII / SAKURA-G.
    """

    name = "HD: AES Last-Round State"

    def leakage(
        self,
        pt: np.ndarray,
        ct: np.ndarray,
        key: np.ndarray,
        guess: int,
        bnum: int,
        prev_ct: np.ndarray | None = None,
        prev_pt: np.ndarray | None = None,
    ) -> int:
        st10 = ct[_INVSHIFT_UNDO[bnum]]
        st9 = _INV_SBOX[ct[bnum] ^ guess]
        return _HW[st9 ^ st10]


class LastroundStateDiffAlternate(AESLeakageHelper):
    """HD: AES Last-Round State (Alternate formulation)

    Similar to LastroundStateDiff but uses different byte ordering.
    st10 = ct[bnum], st9 = InvSBox[ct[bnum] ^ key[bnum]]
    """

    name = "HD: AES Last-Round State Alternate"

    def leakage(
        self,
        pt: np.ndarray,
        ct: np.ndarray,
        key: np.ndarray,
        guess: int,
        bnum: int,
        prev_ct: np.ndarray | None = None,
        prev_pt: np.ndarray | None = None,
    ) -> int:
        st10 = ct[bnum]
        st9 = _INV_SBOX[ct[bnum] ^ guess]
        return _HW[st9 ^ st10]


class PipelineDiff(AESLeakageHelper):
    """HD: AES Round 9 between previous and current encryptions

    Difference between round 9 states of consecutive encryptions.
    curr = InvSBox[ct[bnum] ^ key[bnum]]
    prev = InvSBox[prev_ct[bnum] ^ key[bnum]]
    Returns HD between current and previous round-9 state.
    """

    name = "HD: AES round 9 between previous and current encryptions"

    def leakage(
        self,
        pt: np.ndarray,
        ct: np.ndarray,
        key: np.ndarray,
        guess: int,
        bnum: int,
        prev_ct: np.ndarray | None = None,
        prev_pt: np.ndarray | None = None,
    ) -> int:
        if prev_ct is None:
            prev_ct = np.zeros(16, dtype=np.uint8)
        curr = _INV_SBOX[ct[bnum] ^ guess]
        prev = _INV_SBOX[prev_ct[bnum] ^ guess]
        return _HW[curr ^ prev]


class HalfPipelineDiff(AESLeakageHelper):
    """HD: AES previous round 10 and current round 9

    HD between current round-9 state and previous round-10 state.
    curr = InvSBox[ct[bnum] ^ key[bnum]]
    prev = prev_ct[INVSHIFT_UNDO[bnum]]
    """

    name = "HD: AES previous round 10 and current round 9"

    def leakage(
        self,
        pt: np.ndarray,
        ct: np.ndarray,
        key: np.ndarray,
        guess: int,
        bnum: int,
        prev_ct: np.ndarray | None = None,
        prev_pt: np.ndarray | None = None,
    ) -> int:
        if prev_ct is None:
            prev_ct = np.zeros(16, dtype=np.uint8)
        curr = _INV_SBOX[ct[bnum] ^ guess]
        prev = prev_ct[_INVSHIFT_UNDO[bnum]]
        return _HW[curr ^ prev]


class SBoxInOutDiff(AESLeakageHelper):
    """HD: AES SBox Input to Output Difference

    Hamming distance between S-Box input (before S-Box) and output (after S-Box).
    st1 = pt[bnum] ^ key[bnum] (S-Box input)
    st2 = SBox[st1] (S-Box output)
    Returns HD(st1, st2).
    """

    name = "HD: AES SBox Input to Output"

    def leakage(
        self,
        pt: np.ndarray,
        ct: np.ndarray,
        key: np.ndarray,
        guess: int,
        bnum: int,
        prev_ct: np.ndarray | None = None,
        prev_pt: np.ndarray | None = None,
    ) -> int:
        st1 = pt[bnum] ^ guess
        st2 = _SBOX[st1]
        return _HW[st1 ^ st2]


class SBoxInputSuccessive(AESLeakageHelper):
    """HD: AES SBox Input i to i+1

    Hamming distance between S-Box inputs of adjacent byte positions.
    st1 = pt[bnum] ^ key[bnum]
    st2 = pt[bnum-1] ^ key[bnum-1]
    Returns HD(st1, st2).
    """

    name = "HD: AES SBox Input i to i+1"

    def leakage(
        self,
        pt: np.ndarray,
        ct: np.ndarray,
        key: np.ndarray,
        guess: int,
        bnum: int,
        prev_ct: np.ndarray | None = None,
        prev_pt: np.ndarray | None = None,
    ) -> int:
        st1 = pt[bnum] ^ guess
        if bnum > 0:
            st2 = pt[bnum - 1] ^ key[bnum - 1]
        else:
            st2 = 0
        return _HW[st1 ^ st2]


class SBoxOutputSuccessive(AESLeakageHelper):
    """HD: AES SBox Output i to i+1

    Hamming distance between S-Box outputs of adjacent byte positions.
    st1 = SBox[pt[bnum] ^ key[bnum]]
    st2 = SBox[pt[bnum-1] ^ key[bnum-1]]
    Returns HD(st1, st2).
    """

    name = "HD: AES SBox Output i to i+1"

    def leakage(
        self,
        pt: np.ndarray,
        ct: np.ndarray,
        key: np.ndarray,
        guess: int,
        bnum: int,
        prev_ct: np.ndarray | None = None,
        prev_pt: np.ndarray | None = None,
    ) -> int:
        st1 = _SBOX[pt[bnum] ^ guess]
        if bnum > 0:
            st2 = _SBOX[pt[bnum - 1] ^ key[bnum - 1]]
        else:
            st2 = 0
        return _HW[st1 ^ st2]


class Monobit(AESLeakageHelper):
    """Single bit leakage model for AES S-Box output.

    Extracts a specific bit (0-7) from the S-Box output.
    Used in MixColumns-style attacks where individual bit leakages are analyzed.
    """

    name = "Bit: AES SBox Output, First Round (Enc)"

    def __init__(self, bit_index: int = 0):
        if not 0 <= bit_index <= 7:
            raise ValueError("bit_index must be between 0 and 7")
        self.bit_index = bit_index
        self.name = f"Bit-{bit_index}: AES SBox Output, First Round (Enc)"

    def leakage(
        self,
        pt: np.ndarray,
        ct: np.ndarray,
        key: np.ndarray,
        guess: int,
        bnum: int,
        prev_ct: np.ndarray | None = None,
        prev_pt: np.ndarray | None = None,
    ) -> int:
        sbox_output = _SBOX[pt[bnum] ^ guess]
        return (sbox_output >> self.bit_index) & 1


class Monobit0(Monobit):
    name = "Bit-0: AES SBox Output, First Round (Enc)"

    def __init__(self):
        super().__init__(bit_index=0)


class Monobit1(Monobit):
    name = "Bit-1: AES SBox Output, First Round (Enc)"

    def __init__(self):
        super().__init__(bit_index=1)


class Monobit2(Monobit):
    name = "Bit-2: AES SBox Output, First Round (Enc)"

    def __init__(self):
        super().__init__(bit_index=2)


class Monobit3(Monobit):
    name = "Bit-3: AES SBox Output, First Round (Enc)"

    def __init__(self):
        super().__init__(bit_index=3)


class Monobit4(Monobit):
    name = "Bit-4: AES SBox Output, First Round (Enc)"

    def __init__(self):
        super().__init__(bit_index=4)


class Monobit5(Monobit):
    name = "Bit-5: AES SBox Output, First Round (Enc)"

    def __init__(self):
        super().__init__(bit_index=5)


class Monobit6(Monobit):
    name = "Bit-6: AES SBox Output, First Round (Enc)"

    def __init__(self):
        super().__init__(bit_index=6)


class Monobit7(Monobit):
    name = "Bit-7: AES SBox Output, First Round (Enc)"

    def __init__(self):
        super().__init__(bit_index=7)


@dataclass
class CPAResult(AnalysisResult):
    num_subkeys: int = 16
    num_perms: int = 256
    threshold: float = 0.5
    num_traces: int = 0
    total_samples: int = 0
    best_guesses: list[dict] = field(default_factory=list)
    key_guess: list[int] = field(default_factory=list)
    correlations: list[np.ndarray] = field(default_factory=list)
    pge: list[int] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)


class CPAProgressiveOneSubkey:
    def __init__(self, num_perms: int = 256, num_samples: int = 1):
        self.num_perms = num_perms
        self.num_samples = num_samples
        self.sumhq = np.zeros(num_perms, dtype=np.longdouble)
        self.sumtq = None
        self.sumt = None
        self.sumh = np.zeros(num_perms, dtype=np.longdouble)
        self.sumht = np.zeros((num_perms, num_samples), dtype=np.longdouble)
        self.total_traces = 0
        self._initialized = False

    def _compute_leakage_matrix(
        self,
        plaintexts: np.ndarray,
        ciphertexts: np.ndarray,
        known_key: np.ndarray,
        bnum: int,
        prev_ct: np.ndarray | None,
        prev_pt: np.ndarray | None,
        model_name: str,
    ) -> np.ndarray:
        """
        Vectorized computation of leakage hypothesis matrix H (num_traces, 256).
        H[n, k] = leakage hypothesis for trace n, key guess k.
        Replaces the 256×N Python loop with pure NumPy broadcasting.
        """
        num_traces = plaintexts.shape[0]
        # Convert tables to numpy for advanced indexing
        _HW_np = np.array(_HW, dtype=np.intp)
        _SBOX_np = np.array(_SBOX, dtype=np.uint8)
        _INV_SBOX_np = np.array(_INV_SBOX, dtype=np.uint8)

        pt_b = plaintexts[:, bnum][:, np.newaxis]  # (N, 1)
        ct_b = ciphertexts[:, bnum][:, np.newaxis]  # (N, 1)
        kg = np.arange(256, dtype=np.uint8)
        kg_grid = kg[np.newaxis, :]  # (1, 256)

        # ----- models that depend only on pt[bnum] -----
        if model_name == "HW: AES SBox Output, First Round (Enc)":
            st = _SBOX_np[pt_b ^ kg_grid]
            return _HW_np[st].astype(np.longdouble)

        if model_name == "HW: AddRoundKey Output, First Round (Enc)":
            return _HW_np[pt_b ^ kg_grid].astype(np.longdouble)

        if model_name == "HW: AES Inv SBox Output, First Round (Dec)":
            st = _INV_SBOX_np[pt_b ^ kg_grid]
            return _HW_np[st].astype(np.longdouble)

        # ----- models that depend on ct[bnum] -----
        if model_name == "HW: AES Last-Round State":
            st = _INV_SBOX_np[ct_b ^ kg_grid]
            return _HW_np[st].astype(np.longdouble)

        if model_name == "HD: AES Last-Round State":
            ct_unshifted = ciphertexts[:, _INVSHIFT_UNDO[bnum]][:, np.newaxis]
            st = _INV_SBOX_np[ct_b ^ kg_grid]
            return _HW_np[st ^ ct_unshifted].astype(np.longdouble)

        if model_name == "HD: AES Last-Round State Alternate":
            st = _INV_SBOX_np[ct_b ^ kg_grid]
            return _HW_np[st ^ ct_b].astype(np.longdouble)

        # ----- models that need prev_ct -----
        if model_name == "HD: AES round 9 between previous and current encryptions":
            if prev_ct is None:
                prev_ct_arr = np.zeros((num_traces, 16), dtype=np.uint8)
            else:
                prev_ct_arr = prev_ct
            prev_b = prev_ct_arr[:, bnum][:, np.newaxis]
            curr = _INV_SBOX_np[ct_b ^ kg_grid]
            prev = _INV_SBOX_np[prev_b ^ kg_grid]
            return _HW_np[curr ^ prev].astype(np.longdouble)

        if model_name == "HD: AES previous round 10 and current round 9":
            if prev_ct is None:
                prev_ct_arr = np.zeros((num_traces, 16), dtype=np.uint8)
            else:
                prev_ct_arr = prev_ct
            prev_unshifted = prev_ct_arr[:, _INVSHIFT_UNDO[bnum]][:, np.newaxis]
            curr = _INV_SBOX_np[ct_b ^ kg_grid]
            return _HW_np[curr ^ prev_unshifted].astype(np.longdouble)

        # ----- SBox transition models -----
        if model_name == "HD: AES SBox Input to Output":
            xored = pt_b ^ kg_grid
            return _HW_np[xored ^ _SBOX_np[xored]].astype(np.longdouble)

        if model_name == "HD: AES SBox Input i to i+1":
            if bnum == 0:
                prev_b = np.zeros((num_traces, 1), dtype=np.uint8)
            else:
                prev_b = plaintexts[:, bnum - 1][:, np.newaxis]
            known_prev = known_key[bnum - 1] if bnum > 0 else 0
            xored_curr = pt_b ^ kg_grid
            xored_prev = prev_b ^ known_prev
            return _HW_np[xored_curr ^ xored_prev].astype(np.longdouble)

        if model_name == "HD: AES SBox Output i to i+1":
            if bnum == 0:
                prev_b = np.zeros((num_traces, 1), dtype=np.uint8)
            else:
                prev_b = plaintexts[:, bnum - 1][:, np.newaxis]
            known_prev = known_key[bnum - 1] if bnum > 0 else 0
            sbox_curr = _SBOX_np[pt_b ^ kg_grid]
            sbox_prev = _SBOX_np[prev_b ^ known_prev]
            return _HW_np[sbox_curr ^ sbox_prev].astype(np.longdouble)

        # Monobit models
        if model_name.startswith("Bit-"):
            bit_index = int(model_name.split("-")[1].split(":")[0])
            st = _SBOX_np[pt_b ^ kg_grid]
            return ((st >> bit_index) & 1).astype(np.longdouble)

        raise ValueError(f"Unknown leakage model: {model_name}")

    def add_traces(
        self,
        traces: np.ndarray,
        plaintexts: np.ndarray,
        ciphertexts: np.ndarray | None,
        leakage_model: AESLeakageHelper,
        bnum: int,
        known_key: np.ndarray | None = None,
        prev_ct: np.ndarray | None = None,
    ) -> np.ndarray:
        num_traces = traces.shape[0]
        num_samples = traces.shape[1]
        T_new = self.total_traces + num_traces

        if ciphertexts is None:
            ciphertexts = np.zeros((num_traces, 16), dtype=np.uint8)

        if known_key is None:
            known_key = np.zeros(16, dtype=np.uint8)

        if not self._initialized:
            self.num_samples = num_samples
            self.sumtq = np.zeros(num_samples, dtype=np.longdouble)
            self.sumt = np.zeros(num_samples, dtype=np.longdouble)
            self.sumht = np.zeros((self.num_perms, num_samples), dtype=np.longdouble)
            self.sumh = np.zeros(self.num_perms, dtype=np.longdouble)
            self.sumhq = np.zeros(self.num_perms, dtype=np.longdouble)
            self._initialized = True

        # Build prev_pt for successive models (SBoxInput/OutputSuccessive need plaintext[t-1])
        # We can reconstruct from plaintexts: prev_pt[n] = plaintext[n-1] for n >= 1
        # For simplicity, use None here — successive models only need prev_ct for pipeline models
        prev_pt = None

        # Vectorized hypothesis matrix: H[n, k] = leakage for trace n, key k
        H = self._compute_leakage_matrix(
            plaintexts,
            ciphertexts,
            known_key,
            bnum,
            prev_ct,
            prev_pt,
            leakage_model.name,
        )

        # Accumulate: sumht = H.T @ traces  →  (256, N) @ (N, S) = (256, S)
        H = H.astype(np.float64)
        self.sumht += np.dot(H.T, traces)
        self.sumh += np.sum(H, axis=0)
        self.sumhq += np.sum(H * H, axis=0)

        traces_sq = np.sum(np.square(traces), axis=0)
        traces_sum = np.sum(traces, axis=0)
        self.sumtq += traces_sq
        self.sumt += traces_sum

        sumden2 = T_new * self.sumtq - np.square(self.sumt)
        sumden1 = T_new * self.sumhq - np.square(self.sumh)
        sumden = sumden1[:, np.newaxis] * sumden2[np.newaxis, :]
        sumden = np.where(sumden > 0, sumden, 1.0)
        sumnum = (
            T_new * self.sumht - self.sumh[:, np.newaxis] * self.sumt[np.newaxis, :]
        )
        diffs = sumnum / np.sqrt(sumden)

        self.total_traces = T_new
        return diffs

    def reset(self):
        self.sumhq = np.zeros(self.num_perms, dtype=np.longdouble)
        self.sumtq = None
        self.sumt = None
        self.sumh = np.zeros(self.num_perms, dtype=np.longdouble)
        if self.num_samples:
            self.sumht = np.zeros(
                (self.num_perms, self.num_samples), dtype=np.longdouble
            )
        self.total_traces = 0
        self._initialized = False


class CPAAnalyzer(Analyzer):
    name: str = "cpa"
    description: str = "CPA - Correlation Power Analysis"

    LEAKAGE_MODELS = {
        "sbox_output": SBoxOutput,
        "pt_key_xor": PtKeyXOR,
        "inv_sbox_output": InvSBoxOutput,
        "lastround_hw": LastroundHW,
        "lastround_state_diff": LastroundStateDiff,
        "lastround_state_diff_alt": LastroundStateDiffAlternate,
        "pipeline_diff": PipelineDiff,
        "half_pipeline_diff": HalfPipelineDiff,
        "sbox_in_out_diff": SBoxInOutDiff,
        "sbox_input_successive": SBoxInputSuccessive,
        "sbox_output_successive": SBoxOutputSuccessive,
        "bit0": Monobit0,
        "bit1": Monobit1,
        "bit2": Monobit2,
        "bit3": Monobit3,
        "bit4": Monobit4,
        "bit5": Monobit5,
        "bit6": Monobit6,
        "bit7": Monobit7,
    }

    def __init__(self, config: dict[str, Any] | None = None):
        if config is None:
            config = {}
        self.config = config
        self.leakage_model_name = self.config.get("leakage_model", "sbox_output")
        self.num_subkeys = self.config.get("num_subkeys", 16)
        self.threshold = self.config.get("threshold", 0.5)
        self.target_bytes = list(range(self.num_subkeys))

        model_cls = self.LEAKAGE_MODELS.get(self.leakage_model_name, SBoxOutput)
        self.leakage_model = model_cls()

        self._cpa_state = [CPAProgressiveOneSubkey() for _ in range(self.num_subkeys)]

    def _validate_config(self) -> None:
        if self.leakage_model_name not in self.LEAKAGE_MODELS:
            raise ValueError(
                f"Unknown leakage model: {self.leakage_model_name}. "
                f"Available: {list(self.LEAKAGE_MODELS.keys())}"
            )
        if self.num_subkeys < 1 or self.num_subkeys > 16:
            raise ValueError("num_subkeys must be between 1 and 16")

    def analyze(
        self,
        traces: np.ndarray,
        labels: np.ndarray | None = None,
        plaintext: np.ndarray | None = None,
        ciphertext: np.ndarray | None = None,
        key: np.ndarray | None = None,
        **kwargs,
    ) -> CPAResult:
        if plaintext is None:
            raise ValueError("CPA requires plaintext data")

        num_traces, num_samples = traces.shape
        input_path = kwargs.get("input_path", "")

        ciphertexts = (
            ciphertext
            if ciphertext is not None
            else np.zeros((num_traces, 16), dtype=np.uint8)
        )

        # Build previous ciphertext array for pipeline/successive models
        prev_cts = np.zeros((num_traces, 16), dtype=np.uint8)
        if num_traces > 0:
            prev_cts[0] = np.zeros(16, dtype=np.uint8)  # First trace has no previous
            prev_cts[1:] = ciphertexts[
                :-1
            ]  # Each trace's prev is the previous ciphertext

        all_diffs = []
        for bnum in self.target_bytes:
            cpa = self._cpa_state[bnum]
            cpa.reset()
            diffs = cpa.add_traces(
                traces,
                plaintext,
                ciphertexts,
                self.leakage_model,
                bnum,
                known_key=key,
                prev_ct=prev_cts,
            )
            all_diffs.append(diffs)

        best_guesses = []
        key_guess = []
        pge = []

        for bnum in self.target_bytes:
            diffs = all_diffs[bnum]

            max_corr = np.max(np.abs(diffs), axis=1)
            best_idx = np.argmax(max_corr)
            best_corr = max_corr[best_idx]

            guess = {
                "byte": bnum,
                "guess": int(best_idx),
                "correlation": float(best_corr),
            }

            if key is not None and len(key) >= bnum + 1:
                known = key[bnum]
                rank = np.where(np.argsort(-max_corr) == known)[0][0]
                guess["pge"] = int(rank)
                pge.append(int(rank))
            else:
                guess["pge"] = None
                pge.append(255)

            best_guesses.append(guess)
            key_guess.append(best_idx)

        return CPAResult(
            method="cpa",
            input_path=input_path,
            num_traces=num_traces,
            total_samples=num_samples,
            num_subkeys=self.num_subkeys,
            threshold=self.threshold,
            best_guesses=best_guesses,
            key_guess=key_guess,
            correlations=all_diffs,
            pge=pge,
            metadata={
                "leakage_model": self.leakage_model.name,
            },
        )

    def detect_leakage_points(
        self,
        result: CPAResult,
        threshold: float | None = None,
    ) -> np.ndarray:
        if threshold is None:
            threshold = self.threshold

        if not result.correlations:
            return np.array([], dtype=int)

        combined = np.max(np.abs(np.stack(result.correlations)), axis=0)
        return np.where(combined > threshold)[0]

    @staticmethod
    def load_traces(path: str | Any, format: str = "zarr") -> TraceDataset:
        if format != "zarr":
            raise ValueError(f"Unsupported format: {format}")

        tile = "/0/0/"
        z = zarr.open(str(path), "r")

        traces = z[f"{tile}traces"][:] if f"{tile}traces" in z else None
        labels = z[f"{tile}labels"][:] if f"{tile}labels" in z else None
        plaintext = z[f"{tile}plaintext"][:] if f"{tile}plaintext" in z else None
        key = z[f"{tile}key"][:] if f"{tile}key" in z else None
        ciphertext = z[f"{tile}ciphertext"][:] if f"{tile}ciphertext" in z else None

        return TraceDataset(
            traces=traces,
            labels=labels,
            plaintext=plaintext,
            key=key,
            ciphertext=ciphertext,
        )

    @staticmethod
    def save_traces(
        dataset: TraceDataset, path: str | Any, format: str = "zarr"
    ) -> Path:
        if format != "zarr":
            raise ValueError(f"Unsupported format: {format}")

        tile = "/0/0/"
        z = zarr.open(str(path), mode="w")

        if dataset.traces is not None:
            z.create_dataset(f"{tile}traces", data=dataset.traces)
        if dataset.labels is not None:
            z.create_dataset(f"{tile}labels", data=dataset.labels)
        if dataset.plaintext is not None:
            z.create_dataset(f"{tile}plaintext", data=dataset.plaintext)
        if dataset.key is not None:
            z.create_dataset(f"{tile}key", data=dataset.key)
        if dataset.ciphertext is not None:
            z.create_dataset(f"{tile}ciphertext", data=dataset.ciphertext)

        return Path(path)


__all__ = [
    "CPAResult",
    "CPAAnalyzer",
    "CPAProgressiveOneSubkey",
    "AESLeakageHelper",
    "SBoxOutput",
    "PtKeyXOR",
    "InvSBoxOutput",
    "LastroundHW",
    "LastroundStateDiff",
    "LastroundStateDiffAlternate",
    "PipelineDiff",
    "HalfPipelineDiff",
    "SBoxInOutDiff",
    "SBoxInputSuccessive",
    "SBoxOutputSuccessive",
    "Monobit",
    "Monobit0",
    "Monobit1",
    "Monobit2",
    "Monobit3",
    "Monobit4",
    "Monobit5",
    "Monobit6",
    "Monobit7",
]
