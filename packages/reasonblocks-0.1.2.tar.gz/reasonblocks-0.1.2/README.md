# ReasonBlocks SDK

Python SDK that integrates ReasonBlocks into LangChain 1.0 agents as middleware. Scores each agent step, injects steering signals and E-traces, and optionally switches models based on difficulty.

## Installation

```bash
pip install reasonblocks
```

## Quick Start

```python
from reasonblocks import ReasonBlocks

rb = ReasonBlocks(api_key="rb_live_...")

agent = create_agent(
    model="anthropic:claude-sonnet-4-20250514",
    tools=[...],
    system_prompt="...",
    middleware=[rb.middleware()],
)
```

One import. One init. One middleware addition.

## Tagging runs for the dashboard

`rb.middleware()` accepts identifying metadata that lands on the dashboard runs row:

```python
agent = create_agent(
    ...,
    middleware=[rb.middleware(
        org_id="6d3f...",         # uuid; "default" if omitted
        project_id="a91b...",     # uuid; "default" if omitted
        run_id="my-run-1",        # auto-generated if omitted
        agent_name="bugfixer",    # free-form filter key
        task="fix the TypeError",
        model="claude-sonnet-4-20250514",
        framework="langchain",
        codebase_id="myrepo@sha:abc123",
    )],
)
```

The dashboard's **Quickstart** page (`/platform/dashboard/quickstart`) shows the user's actual `org_id` / `project_id` next to a copy-pasteable snippet — the easiest way to get the values without hardcoding.

## Configuration

```python
rb = ReasonBlocks(
    api_key="rb-...",
    token_budget=100_000,
    monitor_names=["loop", "confidence", "evidence", "budget", "strategy_exhaustion"],
    fsm_thresholds={
        "fast_threshold": 0.2,
        "slow_threshold": 0.6,
        "skip_threshold": 0.85,
    },
    model_routing={
        "FAST": "anthropic:claude-haiku-4-5-20251001",
        "SLOW": "anthropic:claude-sonnet-4-20250514",
    },
    e_traces_enabled=True,
)
```

## Architecture

The middleware hooks into two points in the LangChain agent loop:

- **before_model** -- scores the agent's last reasoning step, updates the FSM state, runs all monitors, retrieves E-traces, and injects steering signals as a system message.
- **wrap_model_call** -- overrides the model based on FSM state (if routing is configured) and tracks token usage.

## Development

```bash
pip install -e ".[dev]"
pytest
```
