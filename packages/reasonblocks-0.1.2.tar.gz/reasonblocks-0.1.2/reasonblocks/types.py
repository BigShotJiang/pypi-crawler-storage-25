from __future__ import annotations

import enum
from dataclasses import dataclass, field
from typing import Any, Optional


class FSMState(enum.Enum):
    INIT = "INIT"
    FAST = "FAST"
    NORMAL = "NORMAL"
    SLOW = "SLOW"
    SKIP = "SKIP"
    END = "END"


@dataclass
class ETrace:
    """A retrieved pattern from the rb-api / Qdrant pipeline.

    ``fields`` is the raw Qdrant payload (see
    ``reasonblocks/schemas/pattern_schema.json``). The middleware hands
    ``(tier, fields)`` to :func:`reasonblocks.format_routing.render_pattern`
    once the final post-routing model is known.
    """

    tier: str  # "e1" / "e2" / "e3"
    similarity: float = 0.0
    pattern_id: str = ""
    fields: dict[str, Any] = field(default_factory=dict)
    failure_type: Optional[str] = None
    model_family: str = ""
    # Legacy alias kept so older callers that read ``level`` still work.
    level: str = ""
    source_trace_id: Optional[str] = None


@dataclass
class PendingInjection:
    """A queued injection awaiting system-message assembly.

    Either ``text`` is set (already-formatted — e.g. monitor steering) or
    ``tier`` + ``fields`` are set (raw pattern, rendered in wrap_model_call
    once the final model id is pinned).
    """

    source: str = ""
    text: Optional[str] = None
    tier: Optional[str] = None
    fields: Optional[dict[str, Any]] = None
    # Optional monitor metadata (set by MonitorSteeringInjection from the
    # rb-api /monitors/evaluate response). Used by the dashboard to show
    # *why* the SDK intervened on a given step.
    monitors_fired: list[str] = field(default_factory=list)
    failure_type: Optional[str] = None
    intervention_source: Optional[str] = None


@dataclass
class StepRecord:
    """One step in a trace."""

    step_index: int
    thought: str
    action: Optional[str] = None
    action_input: Optional[str] = None
    observation: Optional[str] = None
    difficulty: float = 0.0
    state: FSMState = FSMState.INIT
    tokens_used: int = 0


@dataclass
class StepAssessment:
    """Returned after scoring a step."""

    difficulty: float
    state: FSMState
    loop_detected: bool = False
    loop_count: int = 0
    budget_used: float = 0.0
    e1_match: Optional[ETrace] = None
    e2_matches: list[ETrace] = field(default_factory=list)
    injections: list[str] = field(default_factory=list)


@dataclass
class TraceState:
    """Accumulated state across an agent run."""

    trace_id: str
    steps: list[StepRecord] = field(default_factory=list)
    current_state: FSMState = FSMState.INIT
    difficulty_history: list[float] = field(default_factory=list)
    total_tokens: int = 0
    token_budget: Optional[int] = None
