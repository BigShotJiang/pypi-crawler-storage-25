"""Read-only HTTP server that exposes the local monitor SQLite store.

This is the thin API the Vite+React monitor dashboard talks to. Keep it
read-only: writes happen via :class:`~reasonblocks.monitor_sink.SQLiteMonitorSink`
directly from whatever script is running the agent.

Run it with::

    python -m reasonblocks.monitor_server --db monitor_data.db --port 9100

Three endpoints:

* ``GET /runs``              -- list recent runs + summary metrics
* ``GET /runs/{run_id}``     -- single run metadata + every step
* ``GET /health``            -- liveness ping

CORS is permissive so a Vite dev server on :5173 can fetch directly.
"""

from __future__ import annotations

import argparse
import logging
from typing import Any

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
import uvicorn

from reasonblocks.monitor_sink import SQLiteMonitorSink

logger = logging.getLogger("reasonblocks.monitor_server")


def create_app(db_path: str) -> FastAPI:
    sink = SQLiteMonitorSink(db_path)
    app = FastAPI(title="ReasonBlocks Monitor Server", version="0.1.0")
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_methods=["GET"],
        allow_headers=["*"],
    )

    @app.get("/health")
    def health() -> dict[str, Any]:
        return {"status": "ok", "db": db_path}

    @app.get("/runs")
    def list_runs(limit: int = 100) -> list[dict[str, Any]]:
        return sink.list_runs(limit=limit)

    @app.get("/health-summary")
    def health_summary() -> dict[str, Any]:
        return sink.health_summary()

    @app.get("/runs/{run_id}")
    def run_detail(run_id: str) -> dict[str, Any]:
        run = sink.get_run(run_id)
        if run is None:
            raise HTTPException(404, detail=f"run {run_id!r} not found")
        run["steps"] = sink.get_steps(run_id)
        return run

    return app


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--db", default="monitor_data.db",
                        help="path to the SQLite DB written by SQLiteMonitorSink")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=9100)
    args = parser.parse_args()
    uvicorn.run(create_app(args.db), host=args.host, port=args.port, log_level="info")


if __name__ == "__main__":
    main()
