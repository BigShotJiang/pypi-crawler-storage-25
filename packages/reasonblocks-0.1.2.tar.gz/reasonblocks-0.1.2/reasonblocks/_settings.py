"""Shared runtime settings for the ReasonBlocks SDK HTTP clients.

One source of truth for the backend base URL and request timeout so every
client (``ReasonBlocksAPI``, ``CodebaseMemory``, ``MonitorClient``) talks
to the same host by default. The default points at the hosted production
rb-api so ``pip install reasonblocks`` works out of the box without any
configuration. Override per-deployment with env vars:

- ``REASONBLOCKS_BASE_URL`` — rb-api origin (no trailing slash). Set to
  ``http://localhost:9000`` when running rb-api locally for dev.
- ``REASONBLOCKS_API_TIMEOUT`` — HTTP timeout in seconds.
"""

from __future__ import annotations

import os


DEFAULT_BASE_URL = os.getenv(
    "REASONBLOCKS_BASE_URL", "https://rb-api.reasonblocks.com",
)
DEFAULT_TIMEOUT = float(os.getenv("REASONBLOCKS_API_TIMEOUT", "10.0"))
