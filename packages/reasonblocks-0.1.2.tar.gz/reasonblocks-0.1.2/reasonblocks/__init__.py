"""ReasonBlocks SDK public surface.

Two capability areas:

1. **Middleware / E-traces** — ``ReasonBlocks`` wraps a LangChain /
   LangGraph agent with FSM-based difficulty scoring, server-side monitor
   interventions, and tier-aware E-trace injection.

2. **Codebase memory + blast-radius knowledge graph** — ``CodebaseMemory``
   is the per-repo findings store client; ``ImportGraph`` gives you a
   Python import graph with blast-radius queries. These two plus the
   framework integrations in :mod:`reasonblocks.integrations` let any
   agent cache observations across runs and keep them honest when code
   changes.

``ReasonBlocks`` itself pulls in LangChain middleware lazily so importing
``reasonblocks.codebase_memory`` (which only needs ``httpx``) doesn't
force LangChain on environments that don't use it.
"""

# Eager imports: only modules that depend on httpx + stdlib. Keeping
# these eager so ``from reasonblocks import CodebaseMemory`` is a
# normal import statement and tools (mypy, IDE autocomplete) see
# them without configuration.
from reasonblocks.codebase_memory import CodebaseMemory
from reasonblocks.config import ReasonBlocksConfig, build_middleware
from reasonblocks.import_graph import ImportGraph
from reasonblocks.monitor_sink import SQLiteMonitorSink
from reasonblocks.monitors.suite import (
    DEFAULT_FIRE_THRESHOLD,
    DEFAULT_WEIGHTS,
    evaluate_all,
)
from reasonblocks.policy import should_enable_impact_analysis
from reasonblocks.types import ETrace, FSMState, StepAssessment, StepRecord, TraceState

__all__ = [
    # Middleware / E-traces
    "ReasonBlocks",
    "FSMState",
    "StepAssessment",
    "ETrace",
    "StepRecord",
    "TraceState",
    # Direct rb-api clients (used by tests, benchmarks, and any caller
    # that wants to push telemetry without going through the middleware).
    "MonitorClient",
    "ReasonBlocksAPI",
    # Codebase memory + orchestration
    "CodebaseMemory",
    "ImportGraph",
    "should_enable_impact_analysis",
    # Mid-run monitor telemetry
    "SQLiteMonitorSink",
    "evaluate_all",
    "DEFAULT_WEIGHTS",
    "DEFAULT_FIRE_THRESHOLD",
    # Token-saving middleware
    "TokenSavingMiddleware",
    "TokenSavingStats",
    "compress_tool_output",
    "default_suite_signals",
    # General rule-firing monitor pack (v1) — pairs with TokenSavingMiddleware
    "GeneralMonitor",
    "GeneralMonitorMiddleware",
    "GeneralMonitorStats",
    # Single-config helper to assemble the middleware stack
    "ReasonBlocksConfig",
    "build_middleware",
]


# Lazy imports for symbols whose source module depends on optional
# heavy packages (LangChain in particular). Keeps a bare
# ``import reasonblocks`` working for callers who installed the
# core extra-less ``pip install reasonblocks`` -- e.g. the OpenAI
# Agents user who only needs ``rb.openai_hooks(...)`` and the tool
# factory, or someone using just CodebaseMemory.
#
# These are resolved on first attribute access via PEP 562
# ``__getattr__``. ``from reasonblocks import ReasonBlocks`` works
# because Python falls through to the module-level __getattr__ when
# the symbol isn't found in module dict.
_LAZY = {
    # rb-api HTTP clients (only need httpx, but kept lazy for parity).
    "ReasonBlocks":              ("reasonblocks.client",         "ReasonBlocks"),
    "MonitorClient":             ("reasonblocks.monitor_client", "MonitorClient"),
    "ReasonBlocksAPI":           ("reasonblocks.api",            "ReasonBlocksAPI"),
    # General monitor pack -- imports langchain.agents.middleware.
    "GeneralMonitor":            ("reasonblocks.general_monitor", "GeneralMonitor"),
    "GeneralMonitorMiddleware":  ("reasonblocks.general_monitor", "GeneralMonitorMiddleware"),
    "GeneralMonitorStats":       ("reasonblocks.general_monitor", "GeneralMonitorStats"),
    # Token-saving middleware -- imports langchain core.
    "TokenSavingMiddleware":     ("reasonblocks.token_saving",   "TokenSavingMiddleware"),
    "TokenSavingStats":          ("reasonblocks.token_saving",   "TokenSavingStats"),
    "compress_tool_output":      ("reasonblocks.token_saving",   "compress_tool_output"),
    "default_suite_signals":     ("reasonblocks.token_saving",   "default_suite_signals"),
}


def __getattr__(name: str):
    target = _LAZY.get(name)
    if target is None:
        raise AttributeError(f"module 'reasonblocks' has no attribute {name!r}")
    import importlib
    mod = importlib.import_module(target[0])
    return getattr(mod, target[1])
