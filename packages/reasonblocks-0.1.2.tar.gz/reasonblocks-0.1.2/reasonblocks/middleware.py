from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from typing import Any, Callable, Optional

from langchain.agents.middleware import AgentMiddleware, ModelRequest, ModelResponse
from langchain.chat_models import init_chat_model
from langchain.messages import AIMessage, SystemMessage
from langgraph.runtime import Runtime

from reasonblocks.format_routing import render_pattern
from reasonblocks.fsm import DifficultyFSM
from reasonblocks.injections.base import BaseInjection
from reasonblocks.injections.e1 import E1Injection
from reasonblocks.injections.e2 import E2Injection
from reasonblocks.injections.e3 import E3Injection
from reasonblocks.injections.monitor_steering import MonitorSteeringInjection
from reasonblocks.state import TraceStateManager
from reasonblocks.streaming_emitter import StreamingEmitter
from reasonblocks.types import FSMState, PendingInjection, StepRecord

logger = logging.getLogger("reasonblocks.middleware")

AgentState = dict[str, Any]


@dataclass
class StepLogEntry:
    """One entry in the middleware's step-by-step trace log."""

    step: int
    timestamp: float
    difficulty: float | None = None
    fsm_state: str = ""
    model_id: str = ""                                           # resolved model id used for this call (post FSM routing)
    injections: list[str] = field(default_factory=list)         # short previews
    injection_sources: list[str] = field(default_factory=list)  # source class names
    intervention_texts: list[str] = field(default_factory=list) # FULL intervention text per injection
    monitors_fired: list[str] = field(default_factory=list)     # specific monitor names ("loop_detector", ...)
    failure_type: str | None = None                              # categorical failure label from server
    skipped_reason: str | None = None
    thought_preview: str = ""
    tool_calls: list[str] = field(default_factory=list)
    tokens: int = 0
    latency_ms: float = 0.0

    def as_dict(self) -> dict[str, Any]:
        d: dict[str, Any] = {
            "step": self.step,
            "timestamp": self.timestamp,
            "fsm_state": self.fsm_state,
            "thought_preview": self.thought_preview,
            "injections": self.injections,
            "injection_sources": self.injection_sources,
            "intervention_texts": self.intervention_texts,
            "monitors_fired": self.monitors_fired,
            "tool_calls": self.tool_calls,
            "tokens": self.tokens,
            "latency_ms": round(self.latency_ms, 2),
        }
        if self.difficulty is not None:
            d["difficulty"] = round(self.difficulty, 4)
        if self.model_id:
            d["model_id"] = self.model_id
        if self.skipped_reason:
            d["skipped_reason"] = self.skipped_reason
        if self.failure_type:
            d["failure_type"] = self.failure_type
        return d


class ReasonBlocksMiddleware(AgentMiddleware):
    """LangChain 1.0 middleware that scores steps, runs monitors, and injects steering.

    Steering is injected by appending to the system message inside
    ``wrap_model_call``, not by adding user messages to the conversation.
    This avoids forcing extra response turns and keeps the agent's
    message history clean.
    """

    def __init__(
        self,
        *,
        score_fn: Callable[[str], float],
        fsm: DifficultyFSM,
        state_manager: TraceStateManager,
        injections: list[BaseInjection],
        model_routing: Optional[dict[FSMState, str]] = None,
        emitter: Optional[StreamingEmitter] = None,
        run_id: str = "",
        run_metadata: Optional[dict[str, Any]] = None,
        # Accepted-but-not-driven slot kept so `config.build_middleware`'s
        # passthrough doesn't blow up. The SDK no longer ships a local
        # trace collector (rb-api owns v2 trace ingest now); this hook
        # exists only for an external collector object a customer might
        # someday plug in. The middleware exposes it on ``_collector`` so
        # callers (and tests) can assert what was wired in.
        trace_collector: Optional[Any] = None,
    ) -> None:
        super().__init__()
        self._score_fn = score_fn
        self._fsm = fsm
        self._state = state_manager
        self._injections = injections
        self._model_routing = model_routing or {}
        self._step_index = 0
        self._model_cache: dict[str, Any] = {}
        self._last_model_id: str = ""
        self._pending_injections: list[PendingInjection] = []
        self._current_log_entry: StepLogEntry | None = None
        self.step_log: list[StepLogEntry] = []
        # Live telemetry emitter -- fire-and-forget run_start / step /
        # run_finish events to rb-api as the run progresses. Guarded
        # everywhere so a None emitter is a no-op.
        self._emitter = emitter
        self._run_id = run_id or state_manager.trace_id
        self._run_metadata = dict(run_metadata or {})
        self._run_started_emitted = False
        # Set by ``mark_failure(reason)`` to override the default
        # "success" that after_agent / __exit__ emit on clean returns.
        self._explicit_outcome: Optional[str] = None
        # Monitor steering guardrails to avoid low-value over-injection on easy runs.
        self._monitor_injection_count = 0
        self._monitor_last_step = -999
        self._monitor_last_signature: str | None = None
        self._monitor_max_per_run = 5
        # E1 gating — only query Qdrant when the session shows signs of
        # trouble. Entries: {"step": int, "fired": list[str], "composite": float}
        self._monitor_eval_history: list[dict[str, Any]] = []
        self._e1_gate_composite_threshold: float = 0.15
        self._e1_gate_lookback: int = 2
        # Optional per-stage timing buckets (ms). Populated only when
        # ``enable_stage_timings()`` is called — the bench script flips
        # this on to break down where middleware overhead comes from.
        self._stage_timings: dict[str, list[float]] | None = None
        self._call_overhead_ms: list[float] = []
        self._call_llm_ms: list[float] = []
        self._overhead_t0: float | None = None
        self._collector = trace_collector

    def enable_stage_timings(self) -> None:
        """Start recording per-stage latencies in ms.

        Buckets: ``monitor_scoring``, ``e1_retrieval``, ``e2_retrieval``,
        ``e3_retrieval``, ``format_routing``, ``system_injection``.
        """
        self._stage_timings = {
            "monitor_scoring": [],
            "e1_retrieval": [],
            "e2_retrieval": [],
            "e3_retrieval": [],
            "format_routing": [],
            "system_injection": [],
        }

    def get_stage_timings(self) -> dict[str, list[float]]:
        return dict(self._stage_timings) if self._stage_timings else {}

    def get_call_overhead_ms(self) -> list[float]:
        return list(self._call_overhead_ms)

    def get_call_llm_ms(self) -> list[float]:
        return list(self._call_llm_ms)

    def _record_stage(self, name: str, ms: float) -> None:
        if self._stage_timings is not None:
            self._stage_timings[name].append(ms)

    # ------------------------------------------------------------------
    # before_model: score + FSM + collect injections (but don't emit)
    # ------------------------------------------------------------------

    def before_model(
        self,
        state: AgentState,
        runtime: Runtime,
    ) -> dict[str, Any] | None:
        self._overhead_t0 = time.perf_counter()
        try:
            self._before_model_impl(state)
        except Exception:
            logger.warning("before_model failed, continuing unmodified", exc_info=True)
        return None

    def _before_model_impl(self, state: AgentState) -> None:
        messages = state.get("messages", [])
        thought = _extract_last_thought(messages)

        # Emit run_start exactly once, on the first step we see. The
        # emitter itself is safe to call every step (it drops the
        # duplicate silently), but we'd rather not put useless work on
        # the queue.
        self._maybe_emit_run_start()

        entry = StepLogEntry(step=self._step_index, timestamp=time.time())

        if thought is None:
            entry.fsm_state = "INIT"
            entry.thought_preview = "(first call)"
            self._reset_monitor_runtime()
            injections = self._run_injections_first_call()
        else:
            entry.thought_preview = thought[:120]
            injections = self._score_and_inject(thought, entry, messages)

        if injections:
            entry.injections = [_preview(i) for i in injections]
            entry.injection_sources = [i.source for i in injections]
            # Capture full intervention text (no length cap) for the dashboard.
            entry.intervention_texts = [i.text for i in injections if i.text]
            # Aggregate specific monitor names + failure_type from MonitorSteering items.
            fired_set: list[str] = []
            ftype: str | None = None
            for inj in injections:
                for m in (inj.monitors_fired or []):
                    if m and m not in fired_set:
                        fired_set.append(m)
                if inj.failure_type and ftype is None:
                    ftype = inj.failure_type
            entry.monitors_fired = fired_set
            entry.failure_type = ftype

        self._current_log_entry = entry
        self._pending_injections = injections
        # Exactly one bump per before_model call, regardless of whether
        # we took the first-call or scored-step path. Keeps entry.step
        # monotonic so downstream (step_log, monitor_steps upsert) sees
        # unique step indices.
        self._step_index += 1

    def _score_and_inject(
        self, thought: str, entry: StepLogEntry, messages: list[Any],
    ) -> list[PendingInjection]:
        step_index = self._step_index
        difficulty = self._score_fn(thought)
        entry.difficulty = difficulty

        history = self._state.get_difficulty_history()
        history.append(difficulty)
        new_state = self._fsm.transition(
            self._state.current_state, difficulty, history,
        )
        self._state.current_state = new_state
        entry.fsm_state = new_state.value

        step = StepRecord(
            step_index=step_index,
            thought=thought,
            action=_extract_last_action_name(messages),
            action_input=_extract_last_action_input(messages),
            observation=_extract_last_observation(messages),
            difficulty=difficulty,
            state=new_state,
        )
        # _step_index is bumped once per before_model call in the caller,
        # not here -- otherwise the first-call path (which doesn't invoke
        # _score_and_inject) would leave every subsequent entry.step at
        # the same value and the server's (run_id, step_index) upsert
        # would keep overwriting the first scored step.
        self._state.record_step(step)

        # FAST mode skips the expensive E1/E2/E3 retrieval pipeline (those
        # require Qdrant + embeddings) but still allows monitors to run --
        # loop / trajectory-length detection is most valuable precisely when
        # the agent is sailing through and might miss that it's looping.
        skip_e_traces = new_state == FSMState.FAST
        if skip_e_traces:
            entry.skipped_reason = "FSM=FAST, e-traces skipped"

        trace = self._state.get_trace()
        results: list[PendingInjection] = []

        monitor_inj: Optional[MonitorSteeringInjection] = next(
            (i for i in self._injections if isinstance(i, MonitorSteeringInjection)),
            None,
        )

        # Step 1: always evaluate monitors (when present) so the E1 gate has
        # a current signal, even when we throttle the monitor's *injection
        # text*. Retrieval latency still lands in monitor_scoring bucket.
        current_eval = None
        if monitor_inj is not None:
            monitor_inj.set_current_step(step)
            if self._last_model_id:
                monitor_inj.set_model(self._last_model_id)
            t0 = time.perf_counter()
            monitor_items = monitor_inj.retrieve(trace)
            self._record_stage(
                "monitor_scoring", (time.perf_counter() - t0) * 1000.0,
            )
            current_eval = monitor_inj.last_evaluation()

            allow_monitor = self._should_run_monitor_injection(
                step_index=step_index,
                state=new_state,
                difficulty=difficulty,
            )
            if allow_monitor:
                results.extend(
                    self._filter_monitor_items(
                        items=monitor_items, step_index=step_index,
                    ),
                )

        # Step 2: update gate history and decide whether E1 may retrieve.
        self._record_monitor_eval(step_index, current_eval)
        e1_allowed = self._e1_gate_allows(current_eval)

        # Step 2b: thread the monitor's failure_type into E2's metadata
        # filter so E2 retrieval narrows by failure family. Patch 2 from
        # results/distillation_patches.md.
        if current_eval is not None:
            for inj in self._injections:
                if isinstance(inj, E2Injection):
                    inj.set_failure_type(current_eval.failure_type)

        # Step 3: run the remaining injections (E1/E2/E3). E1 is skipped
        # entirely — no Qdrant query — when the gate denies it.
        for inj in self._injections:
            # Monitor injection was handled in Step 1 above; skip here.
            if isinstance(inj, MonitorSteeringInjection):
                continue
            # FAST-mode skips the full E-trace pipeline (Qdrant + embeddings).
            if skip_e_traces:
                continue
            # E1 is further gated by monitor state from Step 2.
            if isinstance(inj, E1Injection) and not e1_allowed:
                continue
            t0 = time.perf_counter()
            items = inj.retrieve(trace)
            elapsed_ms = (time.perf_counter() - t0) * 1000.0
            self._record_stage(_stage_name_for(inj), elapsed_ms)
            results.extend(items)
        return results

    def _record_monitor_eval(
        self, step_index: int, current_eval: Any,
    ) -> None:
        fired = (
            list(current_eval.fired)
            if current_eval is not None and current_eval.fired
            else []
        )
        composite = float(current_eval.composite) if current_eval is not None else 0.0
        self._monitor_eval_history.append(
            {"step": step_index, "fired": fired, "composite": composite},
        )
        if len(self._monitor_eval_history) > 10:
            self._monitor_eval_history = self._monitor_eval_history[-10:]

    def _e1_gate_allows(self, current_eval: Any) -> bool:
        """E1 retrieval gate.

        Fires when:
        - at least one monitor fired on the current call, OR
        - composite score on the current call > 0.15, OR
        - any monitor fired on either of the previous two calls in this session.

        If no monitor ever ran (no MonitorSteeringInjection configured),
        fall back to allowing E1 so consumers that never use monitors
        keep their prior behavior.
        """
        history = self._monitor_eval_history
        ever_ran = bool(history) or current_eval is not None
        if not ever_ran:
            return True

        if current_eval is not None:
            if current_eval.fired:
                return True
            if float(current_eval.composite or 0.0) > self._e1_gate_composite_threshold:
                return True

        # The last entry in history is the current call we just appended.
        # Look at the two prior entries.
        start = max(0, len(history) - 1 - self._e1_gate_lookback)
        end = len(history) - 1
        for entry in history[start:end]:
            if entry.get("fired"):
                return True

        return False

    def _should_run_monitor_injection(
        self,
        *,
        step_index: int,
        state: FSMState,
        difficulty: float,
    ) -> bool:
        del difficulty  # gate removed -- the heuristic scorer is too
                        # conservative for some agents and was preventing
                        # monitor evaluation from ever firing in normal runs.
        if self._monitor_injection_count >= self._monitor_max_per_run:
            return False

        # Cooldown: more frequent when the agent looks stuck (SLOW/SKIP),
        # less frequent when sailing through (FAST). Removed the hard
        # FAST/NORMAL block entirely -- the cooldown alone is enough to
        # prevent over-injection.
        if state in (FSMState.SLOW, FSMState.SKIP):
            cooldown = 2
        elif state == FSMState.FAST:
            cooldown = 5
        else:
            cooldown = 3
        if step_index - self._monitor_last_step < cooldown:
            return False

        return True

    def _filter_monitor_items(
        self,
        *,
        items: list[PendingInjection],
        step_index: int,
    ) -> list[PendingInjection]:
        if not items:
            return []

        signature = "||".join((i.text or "") for i in items)
        if signature == self._monitor_last_signature:
            return []

        self._monitor_last_signature = signature
        self._monitor_last_step = step_index
        self._monitor_injection_count += 1
        return items

    def _reset_monitor_runtime(self) -> None:
        self._monitor_injection_count = 0
        self._monitor_last_step = -999
        self._monitor_last_signature = None
        for inj in self._injections:
            if isinstance(inj, MonitorSteeringInjection):
                inj.reset()

    def _run_injections_first_call(self) -> list[PendingInjection]:
        """On first call, only fire E3 (universal standing-rule) injections."""
        from reasonblocks.injections.e3 import E3Injection

        trace = self._state.get_trace()
        results: list[PendingInjection] = []
        for inj in self._injections:
            if isinstance(inj, E3Injection):
                t0 = time.perf_counter()
                items = inj.retrieve(trace)
                self._record_stage(
                    "e3_retrieval", (time.perf_counter() - t0) * 1000.0,
                )
                results.extend(items)
        return results

    # ------------------------------------------------------------------
    # Session lifecycle: flushes the live-telemetry run-finish event.
    # ------------------------------------------------------------------

    def flush_session(
        self,
        *,
        outcome_status: str = "success",
        background: bool = True,
    ):
        """Close out the session: emit the run-finish telemetry event.

        Trace collector machinery removed -- this now only fires the live
        run_finish event. ``background`` kept for API compatibility (no-op).
        """
        del background  # legacy compatibility, no collector to background
        self._maybe_emit_run_finish(outcome_status=outcome_status)
        return None

    def close(self, timeout: float = 5.0) -> None:
        """Stop the live telemetry worker and drain pending events.

        Idempotent. Call at the end of a session (test suites rely on
        this) to wait for the emitter's background thread to flush.
        Skipping it is fine in normal use -- the emitter thread is a
        daemon.
        """
        if self._emitter is not None:
            self._emitter.close(timeout=timeout)

    # ------------------------------------------------------------------
    # Lifecycle hooks (LangChain ``after_agent`` + context manager)
    # ------------------------------------------------------------------
    #
    # Without this, a run created via ``agent.invoke()`` never gets a
    # ``run_finish`` event -- the dashboard just shows it as
    # "in progress" forever. Hooking ``after_agent`` lets the middleware
    # auto-fire the finish without the caller having to remember.
    #
    # Outcome detection: we don't have direct access to whether the
    # agent raised. Callers who need an explicit failure status should
    # use ``with rb.middleware(...) as mw`` (the __exit__ catches
    # exceptions) or call ``mw.flush_session(outcome_status=...)``
    # themselves. Default = "success" since LangChain only invokes
    # ``after_agent`` on a clean return.

    def after_agent(self, state: AgentState, runtime: Runtime) -> dict[str, Any] | None:
        del state, runtime  # signal-only hook; we just need the trigger
        # Only emit the run_finish here -- DON'T close the emitter. The
        # context manager's __exit__ may run after this hook (e.g. when
        # the caller catches an exception inside the agent.invoke call
        # and then calls mark_failure(reason=...) to override the
        # outcome). If we closed the emitter here, that subsequent
        # finish event would be silently dropped.
        try:
            outcome = self._explicit_outcome or "success"
            self._maybe_emit_run_finish(outcome_status=outcome)
        except Exception:
            logger.warning("after_agent flush failed", exc_info=True)
        return None

    def mark_failure(self, *, reason: str = "failure") -> None:
        """Explicitly mark this run as failed.

        Use when the agent returns control normally (so ``after_agent``
        will fire) but the caller knows the run didn't actually succeed
        -- e.g. the user caught a GraphRecursionError inside ``agent.
        invoke()`` and continued processing. Setting this before
        ``after_agent`` runs (or before the context manager exits)
        overrides the default "success" outcome with the given reason.

        For exceptions that propagate out of ``with mw:`` you don't
        need to call this -- ``__exit__`` sees the exception type and
        records ``failure`` automatically.
        """
        self._explicit_outcome = reason

    def __enter__(self) -> "ReasonBlocksMiddleware":
        return self

    def __exit__(self, exc_type, exc_value, traceback) -> None:
        # Precedence: caller's mark_failure() > exception > default.
        if self._explicit_outcome is not None:
            outcome = self._explicit_outcome
        elif exc_type is not None:
            outcome = f"failure: {exc_type.__name__}"
        else:
            outcome = "success"
        try:
            self._maybe_emit_run_finish(outcome_status=outcome)
            self.close()
        except Exception:
            logger.warning("__exit__ flush failed", exc_info=True)

    # ------------------------------------------------------------------
    # Live telemetry helpers
    # ------------------------------------------------------------------

    def _maybe_emit_run_start(self) -> None:
        if self._emitter is None or self._run_started_emitted:
            return
        self._run_started_emitted = True
        meta = dict(self._run_metadata or {})
        self._emitter.emit_run_start({
            "run_id": self._run_id,
            "agent_name": meta.pop("agent_name", "") or "",
            "task": meta.pop("task", "") or "",
            "model": meta.pop("model", "") or "",
            "framework": meta.pop("framework", "") or "",
            "codebase_id": meta.pop("codebase_id", "") or "",
            "org_id": meta.pop("org_id", "default") or "default",
            "project_id": meta.pop("project_id", "default") or "default",
            "task_profile": meta.pop("task_profile", "coding") or "coding",
            "metadata": meta,
        })

    def _maybe_emit_step(self, entry: StepLogEntry) -> None:
        if self._emitter is None:
            return
        # Pull the latest StepRecord off the state manager so action /
        # action_input / observation survive into the telemetry payload.
        action: Optional[str] = None
        action_input: Optional[str] = None
        thought: Optional[str] = None
        observation: Optional[str] = None
        is_error = False
        try:
            if self._state._steps:
                last_step = self._state._steps[-1]
                action = last_step.action
                action_input = last_step.action_input
                thought = last_step.thought
                observation = last_step.observation
                obs_lower = (observation or "").lower()
                is_error = any(
                    word in obs_lower
                    for word in ("error", "exception", "traceback", "failed")
                )
        except Exception:  # pragma: no cover — defensive
            pass

        if thought is None:
            thought = entry.thought_preview or ""

        metadata: dict[str, Any] = {
            "fsm_state": entry.fsm_state,
            "difficulty": entry.difficulty,
            "latency_ms": round(entry.latency_ms, 2),
        }
        if entry.model_id:
            metadata["model_id"] = entry.model_id
        if entry.skipped_reason:
            metadata["skipped_reason"] = entry.skipped_reason

        self._emitter.emit_step({
            "run_id": self._run_id,
            "step_index": entry.step,
            "action": action,
            "action_input": action_input,
            "thought": thought,
            "observation": observation,
            "is_error": is_error,
            "tokens": int(entry.tokens or 0),
            "injections": list(entry.injections),
            "injection_sources": list(entry.injection_sources),
            "intervention_texts": list(entry.intervention_texts),
            "monitors_fired": list(entry.monitors_fired),
            "failure_type": entry.failure_type,
            "metadata": metadata,
        })

    def _maybe_emit_run_finish(self, *, outcome_status: str) -> None:
        if self._emitter is None:
            return
        self._emitter.emit_run_finish({
            "run_id": self._run_id,
            "outcome": outcome_status,
        })

    # ------------------------------------------------------------------
    # wrap_model_call: inject steering into system message + model routing
    # ------------------------------------------------------------------

    def wrap_model_call(
        self,
        request: ModelRequest,
        handler: Callable[[ModelRequest], ModelResponse],
    ) -> ModelResponse:
        try:
            return self._wrap_model_call_impl(request, handler)
        except Exception:
            logger.warning("wrap_model_call failed, calling handler directly", exc_info=True)
            return handler(request)

    def _wrap_model_call_impl(
        self,
        request: ModelRequest,
        handler: Callable[[ModelRequest], ModelResponse],
    ) -> ModelResponse:
        # Model routing happens first so pattern rendering can key on the
        # final post-routing model identifier (format_routing dispatches on
        # the haiku/sonnet/opus family, and E3/E1 format choices differ by
        # family — rendering before override would pick the wrong template).
        current = self._state.current_state
        model_id = self._model_routing.get(current)
        if model_id:
            model = self._get_or_create_model(model_id)
            request = request.override(model=model)
        self._last_model_id = model_id or _request_model_id(request)

        # Render any pending injections first so we know whether to
        # append a ReasonBlocks tail. This runs on every step even when
        # nothing fires, because the base-prompt cache_control marker
        # below wants to apply unconditionally under SPLIT mode.
        combined = ""
        if self._pending_injections:
            final_model = model_id or _request_model_id(request)
            t0 = time.perf_counter()
            combined = self._render_pending(self._pending_injections, final_model)
            self._record_stage(
                "format_routing", (time.perf_counter() - t0) * 1000.0,
            )
            self._pending_injections = []

        # Always wrap the caller's base system prompt in a cache_control
        # marker so Anthropic's prompt cache hits across every step. The
        # optional [REASONBLOCKS] trailer rides uncached so its varying
        # content can't bust the cache. ``cache_control`` is ignored by
        # non-Anthropic providers — safe no-op on OpenAI/Gemini.
        #
        # Empirically validated on a 10-PR benchmark: the two-block split
        # took the langchain PR-review benchmark from +32% → +52% savings
        # against the no-cache baseline, with 133k cache_read tokens vs 0
        # under the legacy single-string path.
        existing: Any = ""
        if request.system_message and request.system_message.content:
            existing = request.system_message.content

        t0 = time.perf_counter()
        if isinstance(existing, list):
            # Caller already passed a block list; preserve their markers.
            base_blocks: list[dict[str, Any]] | None = list(existing)
        else:
            base_text = str(existing) if existing else ""
            if not base_text:
                # No system prompt at all — skip the rewrite; the base
                # would just be an empty cache key.
                base_blocks = None
            else:
                base_blocks = [{
                    "type": "text",
                    "text": base_text,
                    "cache_control": {"type": "ephemeral"},
                }]
        if base_blocks is not None:
            new_content = list(base_blocks)
            if combined:
                new_content.append({
                    "type": "text",
                    "text": f"[REASONBLOCKS]\n{combined}",
                })
            request = request.override(
                system_message=SystemMessage(content=new_content),
            )
        self._record_stage(
            "system_injection", (time.perf_counter() - t0) * 1000.0,
        )

        t_pre_handler = time.perf_counter()
        response = handler(request)
        t_post_handler = time.perf_counter()
        llm_ms = (t_post_handler - t_pre_handler) * 1000.0
        self._call_llm_ms.append(llm_ms)
        if self._overhead_t0 is not None:
            pre_overhead = (t_pre_handler - self._overhead_t0) * 1000.0
        else:
            pre_overhead = 0.0
        self._track_tokens(response)

        msg = response if isinstance(response, AIMessage) else None
        if msg is None and hasattr(response, "message"):
            msg = response.message

        call_tokens = 0
        call_tool_calls: list[dict[str, Any]] = []
        if msg:
            usage = getattr(msg, "usage_metadata", None)
            if isinstance(usage, dict):
                call_tokens = int(usage.get("total_tokens", 0) or 0)
            if getattr(msg, "tool_calls", None):
                call_tool_calls = [
                    {
                        "name": tc.get("name"),
                        "args": tc.get("args", {}),
                        "id": tc.get("id"),
                    }
                    for tc in msg.tool_calls
                ]

        if self._current_log_entry is not None:
            if self._last_model_id:
                self._current_log_entry.model_id = self._last_model_id
            if call_tokens:
                self._current_log_entry.tokens = call_tokens
                # Propagate to the latest StepRecord so on-disk traces
                # (StepPayload) include accurate token counts too.
                if self._state._steps:
                    self._state._steps[-1].tokens_used = call_tokens
            if call_tool_calls:
                self._current_log_entry.tool_calls = [
                    tc["name"] for tc in call_tool_calls if tc.get("name")
                ]
            if self.step_log:
                prev_ts = self.step_log[-1].timestamp
                self._current_log_entry.latency_ms = max(
                    0.0,
                    (self._current_log_entry.timestamp - prev_ts) * 1000.0,
                )
            finalized_entry = self._current_log_entry
            self.step_log.append(finalized_entry)
            self._current_log_entry = None
            # Live telemetry after state is consistent.
            self._maybe_emit_step(finalized_entry)

        post_overhead = (time.perf_counter() - t_post_handler) * 1000.0
        self._call_overhead_ms.append(pre_overhead + post_overhead)
        self._overhead_t0 = None
        return response

    def _get_or_create_model(self, model_id: str) -> Any:
        if model_id not in self._model_cache:
            self._model_cache[model_id] = init_chat_model(model_id)
        return self._model_cache[model_id]

    def _render_pending(
        self, items: list[PendingInjection], model_id: str,
    ) -> str:
        rendered: list[str] = []
        for item in items:
            if item.text is not None:
                rendered.append(item.text)
                continue
            if not item.tier or not item.fields:
                continue
            try:
                rendered.append(
                    render_pattern(item.tier, model_id, item.fields),
                )
            except Exception:
                logger.warning(
                    "render_pattern failed tier=%s source=%s",
                    item.tier, item.source, exc_info=True,
                )
        return "\n\n".join(rendered)

    def _track_tokens(self, response: ModelResponse) -> None:
        try:
            message = _extract_ai_message(response)
            if message:
                total = _extract_total_tokens(message)
                if total:
                    self._state.add_tokens(total)
        except Exception:
            pass


def _stage_name_for(inj: BaseInjection) -> str:
    if isinstance(inj, MonitorSteeringInjection):
        return "monitor_scoring"
    if isinstance(inj, E1Injection):
        return "e1_retrieval"
    if isinstance(inj, E2Injection):
        return "e2_retrieval"
    if isinstance(inj, E3Injection):
        return "e3_retrieval"
    return "monitor_scoring"


def _preview(inj: PendingInjection) -> str:
    if inj.text is not None:
        return inj.text[:150]
    if inj.tier and inj.fields:
        pid = inj.fields.get("pattern_id", "")
        return f"[{inj.tier}:{pid}]"[:150]
    return ""


def _extract_ai_message(response: Any) -> Optional[AIMessage]:
    """Pull the AIMessage out of a langchain ModelResponse.

    LangChain 1.0 wraps model output in a ``ModelResponse`` dataclass with
    ``result: list[BaseMessage]``. Older versions exposed a single
    ``.message`` attribute or returned the AIMessage directly. Handle all
    three so token + tool_call extraction works across versions.
    """
    if isinstance(response, AIMessage):
        return response
    # langchain 1.0+: ModelResponse with .result list
    result = getattr(response, "result", None)
    if isinstance(result, list):
        for m in result:
            if isinstance(m, AIMessage):
                return m
    # Older: response.message
    msg = getattr(response, "message", None)
    if isinstance(msg, AIMessage):
        return msg
    return None


def _extract_total_tokens(msg: Any) -> int:
    """Robust total-token extraction from a langchain AIMessage.

    ``usage_metadata`` may be a dict (langchain 0.2+) or an object (older
    versions / typed wrappers). ``total_tokens`` may be missing, in which
    case fall back to ``input_tokens + output_tokens``.
    """
    usage = getattr(msg, "usage_metadata", None)
    if not usage:
        return 0
    if isinstance(usage, dict):
        get = usage.get
    else:
        get = lambda k, d=0: getattr(usage, k, d)  # noqa: E731
    total = get("total_tokens", 0)
    if total:
        try:
            return int(total)
        except (TypeError, ValueError):
            return 0
    try:
        return int(get("input_tokens", 0) or 0) + int(get("output_tokens", 0) or 0)
    except (TypeError, ValueError):
        return 0


def _request_model_id(request: ModelRequest) -> str:
    """Best-effort model identifier extraction from a ModelRequest.

    format_routing.detect_model_family only needs a string containing
    ``haiku``/``sonnet``/``opus``; it falls back to ``sonnet`` otherwise.
    """

    model = getattr(request, "model", None)
    for attr in ("model", "model_name", "name", "model_id"):
        v = getattr(model, attr, None) if model is not None else None
        if isinstance(v, str) and v:
            return v
    return str(model) if model is not None else ""


def _extract_last_thought(messages: list[Any]) -> Optional[str]:
    """Walk backwards to find the last assistant message content."""
    for msg in reversed(messages):
        if isinstance(msg, AIMessage):
            content = msg.content
            if isinstance(content, str) and content.strip():
                return content
            if isinstance(content, list):
                texts = [
                    b.get("text", "") if isinstance(b, dict) else str(b)
                    for b in content
                ]
                joined = " ".join(t for t in texts if t).strip()
                if joined:
                    return joined
    return None


def _extract_last_action_name(messages: list[Any]) -> Optional[str]:
    for msg in reversed(messages):
        if isinstance(msg, AIMessage) and getattr(msg, "tool_calls", None):
            calls = msg.tool_calls or []
            if calls:
                return calls[-1].get("name")
    return None


def _extract_last_action_input(messages: list[Any]) -> Optional[str]:
    for msg in reversed(messages):
        if isinstance(msg, AIMessage) and getattr(msg, "tool_calls", None):
            calls = msg.tool_calls or []
            if calls:
                args = calls[-1].get("args")
                return str(args) if args is not None else None
    return None


def _extract_last_observation(messages: list[Any]) -> Optional[str]:
    for msg in reversed(messages):
        # Tool messages are not imported directly here; use duck typing.
        if getattr(msg, "type", "") == "tool" and getattr(msg, "content", None):
            content = str(msg.content)
            return content[:400]
    return None
