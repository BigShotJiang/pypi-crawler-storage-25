"""Format router for tier-specific pattern injection.

Patterns live in Qdrant as raw fields (observation / intervention / instruction
etc.) with zero formatting markup. At injection time, the proxy calls
``render_pattern(tier, model, fields)``, which looks up a template function by
``(tier, model_family)`` and produces the exact string to append to the system
prompt.

Empirically-tuned defaults from two benches:

1. The 27-run format ablation in ``scripts/format_tier_ablation.py`` (see
   ``format_tier_results/report.md``).
2. The Opus-only E3 bench in ``scripts/opus_e3_bench.py`` (see
   ``opus_e3_bench_results/report.md``) — run because Opus scored 0.20
   citation across every variant in (1). The meta-reasoning framing tested
   in (2) scored citation=0.80, loop_break=1.00, unlock=1.00, clearing the
   0.60 bar with no collateral.

    tier  haiku           sonnet                       opus
    E3    meta-reasoning  ALWAYS/NEVER                 meta-reasoning
    E2    D (situation)   TRAJECTORY/DIAGNOSIS/...     D (situation)
    E1    D (correction)  D (correction)               KNOWN-GOOD APPROACH

Updated E3/haiku to meta-reasoning after the 18-run e3_generalization_bench
(``scripts/e3_generalization_bench.py``) found meta_reasoning wins or ties
on all three rule types (citation / recency / completeness) for haiku, and
the single model that *needs* directive framing is sonnet — it decisively
prefers ALWAYS/NEVER on both citation (+0.20) and recency (+0.75). The
simplified rule: sonnet gets ALWAYS/NEVER, haiku and opus get
meta_reasoning.
"""

from __future__ import annotations

from typing import Callable, Literal

ModelFamily = Literal["haiku", "sonnet", "opus"]
Tier = Literal["E1", "E2", "E3"]

MARKER = "[RB-MONITOR CORRECTION]"


def detect_model_family(model: str) -> ModelFamily:
    """Map a model identifier to one of ``haiku`` / ``sonnet`` / ``opus``.

    Falls back to ``sonnet`` when the string matches none of them — sonnet has
    the broadest safe-default profile across all three tier dimensions.
    """

    if not model:
        return "sonnet"
    m = model.lower()
    if "haiku" in m:
        return "haiku"
    if "opus" in m:
        return "opus"
    if "sonnet" in m:
        return "sonnet"
    return "sonnet"


# ---------------------------------------------------------------------------
# E3 — standing rule ("citation" dimension)
# ---------------------------------------------------------------------------


def _split_always_never(instr: str) -> tuple[str, str | None]:
    """Split an E3 instruction into the positive ALWAYS clause and the
    negative NEVER clause by locating the first standalone 'Never' sentence.
    Returns ``(always_text, never_text_or_none)``.
    """

    lowered = instr.lower()
    idx = lowered.find("never")
    if idx == -1:
        return instr.strip().rstrip(". "), None
    positive = instr[:idx].strip().rstrip(". ,;")
    negative_body = instr[idx + len("never") :].strip().lstrip(" ,:")
    if not negative_body:
        return positive, None
    negative_body = negative_body[0].upper() + negative_body[1:]
    return positive, negative_body.rstrip(". ")


def e3_always_never(fields: dict) -> str:
    instr = fields["instruction"]
    positive, negative = _split_always_never(instr)
    lines = [MARKER, f"ALWAYS: {positive}."]
    if negative:
        lines.append(f"NEVER: {negative}.")
    return "\n".join(lines)


def e3_plain(fields: dict) -> str:
    return f"{MARKER}\nSTANDING RULE: {fields['instruction']}"


def e3_meta_reasoning(fields: dict) -> str:
    """Opus-tuned meta-reasoning frame.

    Opus ignores directive framings (plain / ALWAYS/NEVER / IF-THEN all
    scored 0.20 citation in the 27-run ablation). The meta-reasoning frame
    reframes the rule as a self-question Opus asks itself before finalising
    a conclusion, which Opus actually obeys.

    Two benches inform this template:

    1. ``scripts/opus_e3_bench.py`` cleared Opus's 0.60 citation bar with a
       hard-coded citation self-question (citation=0.80 vs 0.20 baseline).
    2. ``scripts/e3_generalization_bench.py`` then tested meta-reasoning as
       a *framing* across citation / recency / completeness rules. On opus,
       meta-reasoning won or tied on all three rules — but only when the
       self-question wording was *rule-specific*. A citation self-question
       applied to a recency rule does not move opus on recency.

    So: this template prefers a pre-authored ``meta_reasoning_prompt`` raw
    field off the pattern payload (one line, no marker). If absent, it
    falls back to the citation-specific hard-coded wording that cleared
    opus_e3_bench — this preserves the existing citation seed rule's
    behaviour on patterns that pre-date the schema addition.

    Any *non-citation* E3 rule routed to Opus MUST ship a
    ``meta_reasoning_prompt`` authored for that rule. Without it, opus will
    receive citation wording against an unrelated rule and the rule will be
    ignored. See ``reasonblocks/schemas/e3_schema.json`` for the field spec.
    """

    _ = fields["instruction"]  # presence check preserves raw-fields contract
    prompt = fields.get("meta_reasoning_prompt")
    if prompt:
        return f"{MARKER}\n{prompt}"
    return (
        f"{MARKER}\n"
        "Before finalizing any conclusion, ask yourself: can I point to the "
        "exact sentence, section, or clause that supports this? If not, the "
        "conclusion isn't ready yet — you need the quoted passage first."
    )


# ---------------------------------------------------------------------------
# E2 — trajectory intervention ("loop_break" dimension)
# ---------------------------------------------------------------------------


def e2_current(fields: dict) -> str:
    """TRAJECTORY / DIAGNOSIS / INTERVENTION / AVOID — the sonnet winner."""

    trig = fields["trigger_state"]
    return (
        f"{MARKER}\n"
        f"TRAJECTORY: {trig['trajectory_description']}\n"
        f"DIAGNOSIS: {fields['diagnosis']}\n"
        f"INTERVENTION: {fields['intervention']}\n"
        f"AVOID: {fields['anti_pattern']}"
    )


def e2_d_style(fields: dict) -> str:
    """Format D adapted for trajectory state — the haiku / opus winner.

    Situation is the trajectory description; the DEAD END is the anti-pattern
    (the thing the agent is actually doing wrong); the UNLOCK is the
    intervention (stop + reformulate).
    """

    trig = fields["trigger_state"]
    return (
        f"{MARKER}\n"
        f"SITUATION: {trig['trajectory_description']}\n"
        f"DEAD END: {fields['anti_pattern']}\n"
        f"UNLOCK: {fields['intervention']}"
    )


# ---------------------------------------------------------------------------
# E1 — task-specific correction ("unlock" dimension)
# ---------------------------------------------------------------------------


def e1_d_style_correction(fields: dict) -> str:
    """SITUATION / DEAD END / UNLOCK — the haiku / sonnet winner."""

    return (
        f"{MARKER}\n"
        f"SITUATION: {fields['task_context_embedding_text']}\n"
        f"DEAD END: {fields['observation']}\n"
        f"UNLOCK: {fields['recommended_action']}"
    )


def e1_positive_known_good(fields: dict) -> str:
    """KNOWN-GOOD APPROACH positive framing — the opus winner.

    Note: positive framing won opus on the unlock dimension only after the
    collateral check filtered out ``e1_positive`` for dropping citation too
    far; the ``e1_minimal`` variant ended up formal winner on score. We use
    this positive framing here because it represents Opus's best E1 unlock
    score and the collateral drop is tolerable once E3 is working.
    """

    ctx = fields["task_context_embedding_text"]
    act = fields["recommended_action"]
    return (
        f"{MARKER}\n"
        f"KNOWN-GOOD APPROACH: On prior successful runs of tasks like this "
        f"({ctx}), the move that worked was: {act}"
    )


# ---------------------------------------------------------------------------
# Routing table — (tier, model_family) -> template function
# ---------------------------------------------------------------------------


FORMAT_ROUTING: dict[tuple[Tier, ModelFamily], Callable[[dict], str]] = {
    # E3 — sonnet follows directives best (always_never +0.20 citation,
    # +0.75 recency over meta_reasoning in the 18-run e3_generalization
    # bench). Haiku and opus both respond to the self-question framing:
    # haiku wins or ties across all 3 rules on meta_reasoning, opus wins
    # recency +0.65 and ties the others.
    ("E3", "haiku"): e3_meta_reasoning,
    ("E3", "sonnet"): e3_always_never,
    ("E3", "opus"): e3_meta_reasoning,
    # E2 — sonnet prefers the narrative TRAJECTORY/DIAGNOSIS/INTERVENTION/
    # AVOID; haiku and opus prefer the Format D (SITUATION/DEAD END/UNLOCK)
    # reframe of the same fields.
    ("E2", "sonnet"): e2_current,
    ("E2", "haiku"): e2_d_style,
    ("E2", "opus"): e2_d_style,
    # E1 — haiku and sonnet both achieve perfect unlock scores on Format D
    # correction framing. Opus prefers the positive KNOWN-GOOD APPROACH
    # framing (unlock 0.90 vs 0.30 on D-style correction).
    ("E1", "haiku"): e1_d_style_correction,
    ("E1", "sonnet"): e1_d_style_correction,
    ("E1", "opus"): e1_positive_known_good,
}


def render_pattern(tier: str, model: str, fields: dict) -> str:
    """Render a raw pattern payload into an injection string.

    ``tier`` — one of ``E1``, ``E2``, ``E3``.
    ``model`` — the model identifier from the intercepted request. It is
    normalized via :func:`detect_model_family` before lookup.
    ``fields`` — the raw pattern payload straight out of Qdrant. The required
    subkeys depend on tier:

        E1: ``observation``, ``recommended_action``, ``task_context_embedding_text``
        E2: ``diagnosis``, ``intervention``, ``anti_pattern``, ``trigger_state``
        E3: ``instruction``

    Raises ``ValueError`` for unknown tiers and ``KeyError`` for missing raw
    fields — both indicate a storage-side bug and should not be silently
    masked.
    """

    tier_norm = tier.upper()
    if tier_norm not in ("E1", "E2", "E3"):
        raise ValueError(f"unknown tier {tier!r}")
    family = detect_model_family(model)
    renderer = FORMAT_ROUTING[(tier_norm, family)]  # type: ignore[index]
    return renderer(fields)
