"""Runtime orchestration policies for ReasonBlocks.

The SDK ships two complementary capabilities — semantic :class:`CodebaseMemory`
and a structural :class:`ImportGraph` — but they don't always belong together.
The ablation benchmarks show that on well-cached localized PRs the graph's
``impact_analysis`` tool distracts the agent, whereas on sweeping changes it
pays for itself.

This module holds the orchestration heuristics that turn that observation
into a runtime decision: given a PR's changed files and the current memory
coverage, should the agent loop include the import-graph tool?

The typical shape::

    enable, reason = should_enable_impact_analysis(
        changed_files=pr_files,
        memory=memory,
    )
    rb_tools = make_langchain_tools(
        memory=memory,
        graph=graph if enable else None,
        enable_impact=enable,
    )

Both functions live at module-top level so callers don't have to instantiate
a policy class for a simple boolean decision.
"""

from __future__ import annotations

from typing import Optional

from reasonblocks.codebase_memory import CodebaseMemory


# File-extension and path heuristics for what counts as "code that might
# benefit from structural analysis". Dependency manifests, CI configs,
# docs, and release metadata are excluded because impact_analysis has no
# useful signal for them (they're leaves in the import graph, if present
# at all).
_NON_CODE_SUFFIXES = (
    ".md", ".rst", ".txt", ".toml", ".cfg", ".ini",
    ".json", ".yaml", ".yml", ".lock",
)
_NON_CODE_PREFIXES = (
    "docs/", ".github/", ".pre-commit-config",
    "HISTORY", "CHANGELOG", "LICENSE", "README",
)


def _is_code_file(path: str) -> bool:
    if not path:
        return False
    lower = path.lower()
    if any(lower.endswith(s) for s in _NON_CODE_SUFFIXES):
        return False
    if any(path.startswith(p) for p in _NON_CODE_PREFIXES):
        return False
    return True


def should_enable_impact_analysis(
    changed_files: list[str],
    memory: Optional[CodebaseMemory] = None,
    *,
    min_files_threshold: int = 10,
    min_coverage: float = 0.5,
) -> tuple[bool, str]:
    """Decide whether an agent reviewing ``changed_files`` would benefit
    from the impact-analysis graph tool.

    The decision rule, in order:

    1. **No code files** (config / docs / deps only) → ``False``. The graph
       has nothing to analyze.
    2. **Large sweeping change** (``len(code_files) >= min_files_threshold``) →
       ``True``. Memory can't cache-hit across that many files at once;
       structural context adds value.
    3. **Cold cache** (``memory.coverage_for(code_files) < min_coverage``) →
       ``True``. Memory doesn't know enough about these files to short-circuit
       exploration, so graph is a useful fallback.
    4. **Warm cache** → ``False``. Memory already answers "what do we know
       about these files"; adding the graph tool tends to over-explore.

    Returns ``(enable, reason)``. The reason is a short human-readable
    string suitable for logging.
    """
    code_files = [f for f in changed_files if _is_code_file(f)]
    if not code_files:
        return False, "no code files changed (config/docs/deps only)"

    if len(code_files) >= min_files_threshold:
        return True, f"large change ({len(code_files)} code files ≥ {min_files_threshold})"

    if memory is None:
        return False, "no memory provided; cache coverage unknown"

    coverage = memory.coverage_for(code_files)
    if coverage < min_coverage:
        return True, f"cold cache: coverage {coverage:.0%} < {min_coverage:.0%} over {len(code_files)} code files"

    return False, f"warm cache: coverage {coverage:.0%} ≥ {min_coverage:.0%} over {len(code_files)} code files"
