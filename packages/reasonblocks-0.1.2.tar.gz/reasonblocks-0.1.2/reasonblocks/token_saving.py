"""Token-saving middleware — optional, domain-agnostic.

Two independent levers:

1. **Tool-output compression.** Old :class:`ToolMessage` bodies in the
   message history get head+tail truncated once they exceed
   ``compress_threshold_chars``. The most recent
   ``keep_recent_tool_messages`` are left untouched so the agent keeps
   full visibility into the step it's actively reasoning about.

2. **Early-exit nudge.** Once the agent has made at least
   ``early_exit_min_call_index`` model calls, if a user-supplied signals
   function reports loop-like trajectory signals, a single
   :class:`HumanMessage` is injected telling the agent to stop
   investigating and submit its current best answer.

The middleware is a separate :class:`AgentMiddleware` subclass — it
stacks alongside :class:`reasonblocks.ReasonBlocksMiddleware` rather
than being embedded inside it, so either can be used on its own.

Typical wiring::

    from reasonblocks import TokenSavingMiddleware, default_suite_signals

    agent = create_agent(
        model=..., tools=...,
        middleware=[
            TokenSavingMiddleware(signals_fn=default_suite_signals),
            ReasonBlocksMiddleware(...),
        ],
    )

Replace same-id ``ToolMessage`` instances in the returned ``messages``
list — LangGraph's ``add_messages`` reducer treats same-id messages as
in-place replacements, which is how compression actually shrinks the
history rather than appending to it.
"""

from __future__ import annotations

import json
import logging
import re
from dataclasses import dataclass, field
from typing import Any, Callable, Optional

from langchain.agents.middleware import AgentMiddleware
from langchain.messages import AIMessage, HumanMessage, ToolMessage
from langgraph.runtime import Runtime

logger = logging.getLogger("reasonblocks.token_saving")

AgentState = dict[str, Any]

DEFAULT_COMPRESS_THRESHOLD_CHARS = 1800
DEFAULT_HEAD_KEEP_CHARS = 900
DEFAULT_TAIL_KEEP_CHARS = 700
DEFAULT_KEEP_RECENT_TOOL_MESSAGES = 2
DEFAULT_EARLY_EXIT_MIN_CALL_INDEX = 40

DEFAULT_EARLY_EXIT_TEXT = (
    "You appear to be stuck in a loop. Stop investigating and submit "
    "your current best answer now using whatever submission tool your "
    "task expects. Do not start another investigation."
)


# ---------------------------------------------------------------------------
# Perplexity-based stale-message compression (LLMLingua-2 style, no training)
# ---------------------------------------------------------------------------

# Tier defaults: how aggressively to compress as a function of "calls ago".
# 0..2 calls ago = full fidelity; 3..9 = mid; 10+ = aggressive.
DEFAULT_PERPLEXITY_RECENT_CUTOFF = 3
DEFAULT_PERPLEXITY_MID_CUTOFF = 10
DEFAULT_PERPLEXITY_KEEP_RATIO_MID = 0.55
DEFAULT_PERPLEXITY_KEEP_RATIO_OLD = 0.30
DEFAULT_PERPLEXITY_WINDOW_WORDS = 50
DEFAULT_PERPLEXITY_MIN_CONTENT_WORDS = 30


_WORD_RE = re.compile(r"\S+")


WordClassifier = Callable[[list[str]], list[bool]]
"""Pure-function classifier: takes N words, returns N keep/drop booleans.

Implementations are caller-supplied. Common ones:

* :func:`make_anthropic_classifier` — wraps an Anthropic Messages call.
* A heuristic implementation — drop short connectives, keep numbers /
  identifiers / capitalized tokens — useful in tests and as a fallback.
"""


def _heuristic_classifier_factory(
    target_keep_ratio: float = 0.5,
) -> WordClassifier:
    """Built-in fallback that doesn't need an LLM. Used when the
    LLM-based classifier raises or when callers want zero-cost compression
    for tests."""

    _STOPWORDS = frozenset({
        "the", "a", "an", "of", "to", "in", "on", "at", "by", "for", "with",
        "as", "is", "are", "was", "were", "be", "been", "being", "and", "or",
        "but", "so", "if", "then", "than", "this", "that", "these", "those",
        "it", "its", "my", "i", "you", "your", "we", "our", "they", "their",
        "just", "very", "really", "actually", "well", "okay", "ok",
    })

    def classify(words: list[str]) -> list[bool]:
        out: list[bool] = []
        for w in words:
            wl = w.lower().strip("\".,;:!?()[]{}'`")
            if not wl:
                out.append(False)
                continue
            # Always keep tokens with code-like content.
            if any(ch.isdigit() for ch in wl):
                out.append(True)
                continue
            if any(ch in wl for ch in "_/\\=<>"):
                out.append(True)
                continue
            if wl in _STOPWORDS:
                out.append(False)
                continue
            if wl != w.lower():  # contains punctuation that's not edge
                out.append(True)
                continue
            out.append(True)
        # Optional: if the keep ratio is far above target, prune lower-info
        # tokens. Keep this simple — tests just need the contract.
        kept = sum(out)
        target = max(1, int(len(out) * target_keep_ratio))
        if kept > target:
            # Drop stopwords first, then short alphabetic words.
            for i, (w, k) in enumerate(zip(words, out)):
                if not k:
                    continue
                if len(w) <= 3 and w.lower() not in {"yes", "no"}:
                    out[i] = False
                    kept -= 1
                    if kept <= target:
                        break
        return out

    return classify


def make_anthropic_classifier(
    client: Any,
    *,
    model: str = "claude-haiku-4-5-20251001",
    target_keep_ratio: float = 0.5,
) -> WordClassifier:
    """Wrap an :class:`anthropic.Anthropic`-compatible client as a
    :data:`WordClassifier` for stale-message compression.

    The classifier asks the small model to label each word keep/drop;
    Anthropic's Messages API does not return per-token logprobs, so we
    use Haiku-as-classifier rather than a true perplexity readout —
    LLMLingua-2 style classification, prompt-only.

    Falls back to the heuristic classifier on ANY failure (parse,
    timeout, rate limit). The middleware never breaks because of a
    classifier error.
    """

    fallback = _heuristic_classifier_factory(target_keep_ratio)

    system = (
        "You compress agent trajectory text by labeling each numbered "
        "word KEEP or DROP. Aim for roughly "
        f"{int(target_keep_ratio * 100)}% KEEP overall.\n\n"
        "ALWAYS KEEP: numbers, code/path/identifier tokens, error names, "
        "named entities, formula symbols, content the agent will need "
        "to reference later. Words that change the answer if removed.\n\n"
        "DROP: filler ('just', 'so', 'well'), polite framing, restated "
        "opinions, hedges, self-talk.\n\n"
        "Respond with strict JSON only: a single array of integers — "
        "the 1-based indices of the words to KEEP. No prose."
    )

    def classify(words: list[str]) -> list[bool]:
        if not words:
            return []
        numbered = "\n".join(f"{i+1}: {w}" for i, w in enumerate(words))
        user = f"Words:\n{numbered}\n\nReturn the JSON array of KEEP indices:"
        try:
            r = client.messages.create(
                model=model,
                max_tokens=min(1500, max(256, len(words) * 6)),
                system=system,
                messages=[{"role": "user", "content": user}],
            )
            text = "".join(
                b.text for b in r.content
                if getattr(b, "type", None) == "text"
            )
        except Exception as exc:
            logger.warning("perplexity classifier API call failed: %s", exc)
            return fallback(words)

        keep_idx = _parse_keep_array(text, len(words))
        if keep_idx is None:
            return fallback(words)
        keep_set = set(keep_idx)
        return [(i + 1) in keep_set for i in range(len(words))]

    return classify


def _parse_keep_array(text: str, n: int) -> Optional[list[int]]:
    """Extract a JSON array of 1-based ints from the classifier response.

    Tolerant: strips code fences, trims preamble. Returns None if no
    valid array is recoverable.
    """
    s = text.strip()
    if s.startswith("```"):
        s = re.sub(r"^```\w*\s*", "", s)
        s = re.sub(r"\s*```$", "", s)
    # Find the first top-level [ ... ] block.
    m = re.search(r"\[[\s\S]*?\]", s)
    if not m:
        return None
    try:
        arr = json.loads(m.group(0))
    except Exception:
        return None
    if not isinstance(arr, list):
        return None
    out = []
    for v in arr:
        try:
            iv = int(v)
        except Exception:
            continue
        if 1 <= iv <= n:
            out.append(iv)
    return out


def compress_text_perplexity(
    text: str,
    *,
    classifier: WordClassifier,
    target_keep_ratio: float = 0.5,
    window_words: int = DEFAULT_PERPLEXITY_WINDOW_WORDS,
    min_content_words: int = DEFAULT_PERPLEXITY_MIN_CONTENT_WORDS,
) -> str:
    """Drop low-importance words from ``text`` using a word-level classifier.

    Splits the text into ``window_words``-sized windows and asks the
    classifier for keep/drop decisions on each window independently.
    Reconstructs the result by joining only the kept words with single
    spaces. Returns the original text unchanged when:

    * It's shorter than ``min_content_words`` (not worth compressing).
    * The classifier fails (returns wrong-length output) — caller's
      classifier is responsible for its own internal fallback.

    The function is pure: same inputs + classifier ⇒ same output.
    Caching of classifier decisions is the caller's responsibility (the
    middleware does it per-message-id).
    """
    if not text:
        return text
    words = _WORD_RE.findall(text)
    if len(words) < min_content_words:
        return text

    out_parts: list[str] = []
    for i in range(0, len(words), window_words):
        chunk = words[i : i + window_words]
        try:
            keep = classifier(chunk)
        except Exception as exc:
            logger.warning("classifier raised on window %d: %s", i // window_words, exc)
            return text
        if not isinstance(keep, list) or len(keep) != len(chunk):
            return text  # contract broken — fail safe
        out_parts.extend(w for w, k in zip(chunk, keep) if k)

    if not out_parts:
        # Pathological — keep the original rather than emit empty.
        return text
    return " ".join(out_parts)


def compress_tool_output(
    content: str,
    *,
    threshold_chars: int = DEFAULT_COMPRESS_THRESHOLD_CHARS,
    head_chars: int = DEFAULT_HEAD_KEEP_CHARS,
    tail_chars: int = DEFAULT_TAIL_KEEP_CHARS,
) -> str:
    """Head+tail truncate a tool observation once it exceeds threshold.

    Returns ``content`` unchanged if it's within the threshold.
    """
    if not content or len(content) <= threshold_chars:
        return content
    head = content[:head_chars]
    tail = content[-tail_chars:]
    omitted = len(content) - head_chars - tail_chars
    return f"{head}\n\n[... {omitted} chars truncated ...]\n\n{tail}"


def build_steps_from_messages(messages: list[Any]) -> list[dict[str, Any]]:
    """Convert a LangChain message history into ``monitors.suite`` steps.

    Pairs each :class:`AIMessage`'s first tool call with the matching
    :class:`ToolMessage` (via ``tool_call_id``) so the monitor suite can
    evaluate the trajectory. Messages without tool calls are still
    emitted as steps with empty action/observation.
    """
    tool_by_id: dict[str, ToolMessage] = {}
    for m in messages:
        if isinstance(m, ToolMessage):
            tcid = getattr(m, "tool_call_id", None)
            if tcid:
                tool_by_id[tcid] = m

    steps: list[dict[str, Any]] = []
    step_index = 0
    for m in messages:
        if not isinstance(m, AIMessage):
            continue
        thought = ""
        content = getattr(m, "content", "")
        if isinstance(content, str):
            thought = content
        elif isinstance(content, list):
            parts = [
                blk.get("text", "") for blk in content
                if isinstance(blk, dict) and blk.get("type") == "text"
            ]
            thought = "\n".join(p for p in parts if p)

        tool_calls = list(getattr(m, "tool_calls", []) or [])
        if not tool_calls:
            steps.append({
                "step_index": step_index,
                "action": "",
                "action_input": {},
                "thought": thought,
                "observation": "",
                "is_error": False,
            })
            step_index += 1
            continue

        for tc in tool_calls:
            name = tc.get("name") if isinstance(tc, dict) else getattr(tc, "name", "")
            args = tc.get("args") if isinstance(tc, dict) else getattr(tc, "args", {})
            tcid = tc.get("id") if isinstance(tc, dict) else getattr(tc, "id", None)
            tm = tool_by_id.get(tcid) if tcid else None
            observation = ""
            is_error = False
            if tm is not None:
                tm_content = getattr(tm, "content", "")
                observation = tm_content if isinstance(tm_content, str) else str(tm_content)
                is_error = bool(getattr(tm, "status", "") == "error")
            steps.append({
                "step_index": step_index,
                "action": name or "",
                "action_input": args or {},
                "thought": thought,
                "observation": observation,
                "is_error": is_error,
            })
            step_index += 1
    return steps


def default_suite_signals(steps: list[dict[str, Any]]) -> dict[str, float]:
    """Run the shipped 6-monitor suite and return its per-monitor scores.

    Exposed as the default ``signals_fn`` so agents that don't want to
    wire their own detector can just pass this in.
    """
    from reasonblocks.monitors.suite import evaluate_all
    result = evaluate_all(steps)
    scores = result.get("scores", {}) or {}
    return {k: float(v) for k, v in scores.items()}


@dataclass
class TokenSavingStats:
    """Running counters. Handy for tests + trace dumps."""

    compressions: int = 0
    chars_saved: int = 0
    early_exits: int = 0
    replacements_emitted: list[int] = field(default_factory=list)
    perplexity_compressions: int = 0
    perplexity_chars_saved: int = 0
    perplexity_cache_hits: int = 0


class TokenSavingMiddleware(AgentMiddleware):
    """Compress old tool outputs and nudge the agent to stop when stuck.

    Both levers are independently toggleable. Failures inside the hook
    are logged and swallowed — the middleware never breaks the agent
    loop.
    """

    def __init__(
        self,
        *,
        compress_threshold_chars: int = DEFAULT_COMPRESS_THRESHOLD_CHARS,
        head_keep_chars: int = DEFAULT_HEAD_KEEP_CHARS,
        tail_keep_chars: int = DEFAULT_TAIL_KEEP_CHARS,
        keep_recent_tool_messages: int = DEFAULT_KEEP_RECENT_TOOL_MESSAGES,
        early_exit_min_call_index: int = DEFAULT_EARLY_EXIT_MIN_CALL_INDEX,
        early_exit_text: str = DEFAULT_EARLY_EXIT_TEXT,
        signals_fn: Optional[Callable[[list[dict[str, Any]]], dict[str, float]]] = None,
        enable_compression: bool = True,
        enable_early_exit: bool = True,
        # Perplexity compression — opt-in, OFF by default. When enabled,
        # the middleware applies a word-level keep/drop classifier to
        # message content older than ``perplexity_recent_cutoff`` calls.
        # The two tier ratios control how aggressive the compression is
        # for "mid" (cutoff..mid_cutoff) vs "old" (≥mid_cutoff) messages.
        enable_perplexity_compression: bool = False,
        perplexity_classifier: Optional[WordClassifier] = None,
        perplexity_recent_cutoff: int = DEFAULT_PERPLEXITY_RECENT_CUTOFF,
        perplexity_mid_cutoff: int = DEFAULT_PERPLEXITY_MID_CUTOFF,
        perplexity_keep_ratio_mid: float = DEFAULT_PERPLEXITY_KEEP_RATIO_MID,
        perplexity_keep_ratio_old: float = DEFAULT_PERPLEXITY_KEEP_RATIO_OLD,
        perplexity_window_words: int = DEFAULT_PERPLEXITY_WINDOW_WORDS,
        perplexity_min_content_words: int = DEFAULT_PERPLEXITY_MIN_CONTENT_WORDS,
    ) -> None:
        super().__init__()
        self.compress_threshold_chars = compress_threshold_chars
        self.head_keep_chars = head_keep_chars
        self.tail_keep_chars = tail_keep_chars
        self.keep_recent_tool_messages = keep_recent_tool_messages
        self.early_exit_min_call_index = early_exit_min_call_index
        self.early_exit_text = early_exit_text
        self.signals_fn = signals_fn
        self.enable_compression = enable_compression
        self.enable_early_exit = enable_early_exit
        self.enable_perplexity_compression = enable_perplexity_compression
        self.perplexity_classifier = perplexity_classifier
        self.perplexity_recent_cutoff = perplexity_recent_cutoff
        self.perplexity_mid_cutoff = perplexity_mid_cutoff
        self.perplexity_keep_ratio_mid = perplexity_keep_ratio_mid
        self.perplexity_keep_ratio_old = perplexity_keep_ratio_old
        self.perplexity_window_words = perplexity_window_words
        self.perplexity_min_content_words = perplexity_min_content_words
        # Per-message-id cache so we never recompress the same stale
        # content; massive cost saver on long trajectories. Key is
        # (message_id, target_keep_ratio) so the same message can be
        # cached at two ratios as it ages from "mid" to "old".
        self._perplexity_cache: dict[tuple[str, float], str] = {}
        self.stats = TokenSavingStats()

    # ------------------------------------------------------------------
    # AgentMiddleware hook
    # ------------------------------------------------------------------

    def before_model(
        self,
        state: AgentState,
        runtime: Runtime[Any] | None = None,
    ) -> Optional[dict[str, Any]]:
        try:
            return self._before_impl(state)
        except Exception as exc:
            logger.warning("token_saving before_model failed: %s", exc)
            return None

    def _before_impl(self, state: AgentState) -> Optional[dict[str, Any]]:
        messages = list(state.get("messages", []) or [])
        if not messages:
            return None

        out_messages: list[Any] = []

        if self.enable_compression:
            replacements = self._compress(messages)
            if replacements:
                self.stats.replacements_emitted.append(len(replacements))
                out_messages.extend(replacements)

        if self.enable_perplexity_compression and self.perplexity_classifier is not None:
            perp_replacements = self._compress_perplexity(messages)
            if perp_replacements:
                out_messages.extend(perp_replacements)

        if self.enable_early_exit:
            nudge = self._maybe_early_exit(messages)
            if nudge is not None:
                self.stats.early_exits += 1
                out_messages.append(nudge)

        if not out_messages:
            return None
        return {"messages": out_messages}

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------

    def _compress(self, messages: list[Any]) -> list[ToolMessage]:
        tool_msgs = [m for m in messages if isinstance(m, ToolMessage)]
        if not tool_msgs:
            return []

        keep_from = max(0, len(tool_msgs) - self.keep_recent_tool_messages)
        replacements: list[ToolMessage] = []
        for tm in tool_msgs[:keep_from]:
            raw = getattr(tm, "content", "")
            if not isinstance(raw, str):
                continue
            if len(raw) <= self.compress_threshold_chars:
                continue
            tm_id = getattr(tm, "id", None)
            if not tm_id:
                # LangGraph's add_messages reducer needs an id to dedup;
                # skipping silently is correct — we just don't compress
                # this one rather than appending a duplicate.
                continue
            compressed = compress_tool_output(
                raw,
                threshold_chars=self.compress_threshold_chars,
                head_chars=self.head_keep_chars,
                tail_chars=self.tail_keep_chars,
            )
            if compressed == raw:
                continue
            self.stats.compressions += 1
            self.stats.chars_saved += len(raw) - len(compressed)
            replacements.append(ToolMessage(
                content=compressed,
                tool_call_id=getattr(tm, "tool_call_id", None),
                id=tm_id,
            ))
        return replacements

    def _compress_perplexity(self, messages: list[Any]) -> list[Any]:
        """Apply word-level keep/drop compression to STALE message
        content (older than ``perplexity_recent_cutoff`` calls back).

        Two tiers:

        * **mid** (recent_cutoff..mid_cutoff calls back): aggressive but
          not extreme — ``perplexity_keep_ratio_mid`` (default 55%).
        * **old** (≥ mid_cutoff): heavy compression —
          ``perplexity_keep_ratio_old`` (default 30%).

        Compresses the TEXT content of stale ``AIMessage`` and
        ``ToolMessage`` instances; ``tool_use`` blocks on AIMessages are
        left intact (the API's tool-result pairing depends on them).
        Decisions are cached per (message_id, target_keep_ratio); the
        first time a message is seen we pay the classifier call, every
        subsequent call is a dict lookup.
        """
        if self.perplexity_classifier is None:
            return []
        cls = self.perplexity_classifier

        # Index messages by their position-from-end among AIMessages so
        # we can compute "calls back" for the staleness tier. AIMessages
        # mark each model call; ToolMessages are paired with the most
        # recent preceding AIMessage.
        ai_positions: dict[int, int] = {}  # message-list-index -> calls-back
        ai_count = 0
        # Walk in reverse to compute calls-back.
        for i in range(len(messages) - 1, -1, -1):
            if isinstance(messages[i], AIMessage):
                ai_positions[i] = ai_count
                ai_count += 1
        # ToolMessage at index j inherits calls-back from the next
        # AIMessage at index < j (the one that produced it).
        last_ai_calls_back = 0
        tool_calls_back: dict[int, int] = {}
        for i in range(len(messages)):
            if isinstance(messages[i], AIMessage):
                last_ai_calls_back = ai_positions.get(i, 0)
            elif isinstance(messages[i], ToolMessage):
                tool_calls_back[i] = last_ai_calls_back

        replacements: list[Any] = []
        for i, m in enumerate(messages):
            if isinstance(m, AIMessage):
                calls_back = ai_positions.get(i, 0)
            elif isinstance(m, ToolMessage):
                calls_back = tool_calls_back.get(i, 0)
            else:
                continue

            ratio = self._keep_ratio_for(calls_back)
            if ratio is None:
                continue  # too recent — full fidelity

            mid = getattr(m, "id", None)
            if not mid:
                continue  # can't replace without an id

            if isinstance(m, ToolMessage):
                raw = getattr(m, "content", "")
                if not isinstance(raw, str):
                    continue
                new_content = self._compress_with_cache(raw, ratio, mid)
                if new_content is None or new_content == raw:
                    continue
                self.stats.perplexity_compressions += 1
                self.stats.perplexity_chars_saved += len(raw) - len(new_content)
                replacements.append(ToolMessage(
                    content=new_content,
                    tool_call_id=getattr(m, "tool_call_id", None),
                    id=mid,
                ))
            else:  # AIMessage
                content = getattr(m, "content", "")
                if isinstance(content, str):
                    raw = content
                    new_content = self._compress_with_cache(raw, ratio, mid)
                    if new_content is None or new_content == raw:
                        continue
                    self.stats.perplexity_compressions += 1
                    self.stats.perplexity_chars_saved += len(raw) - len(new_content)
                    replacements.append(AIMessage(
                        content=new_content,
                        tool_calls=getattr(m, "tool_calls", None) or [],
                        id=mid,
                    ))
                elif isinstance(content, list):
                    # Anthropic-style content blocks: text + tool_use.
                    # Compress only text blocks; leave tool_use intact.
                    new_blocks = []
                    changed = False
                    saved = 0
                    for blk in content:
                        if isinstance(blk, dict) and blk.get("type") == "text":
                            txt = blk.get("text", "")
                            new_txt = self._compress_with_cache(txt, ratio, f"{mid}::txt::{id(blk)}")
                            if new_txt is not None and new_txt != txt:
                                saved += len(txt) - len(new_txt)
                                changed = True
                                new_blocks.append({**blk, "text": new_txt})
                                continue
                        new_blocks.append(blk)
                    if changed:
                        self.stats.perplexity_compressions += 1
                        self.stats.perplexity_chars_saved += saved
                        replacements.append(AIMessage(
                            content=new_blocks,
                            tool_calls=getattr(m, "tool_calls", None) or [],
                            id=mid,
                        ))
        return replacements

    def _keep_ratio_for(self, calls_back: int) -> Optional[float]:
        """Return the per-tier target_keep_ratio for a message N calls
        back, or None if it's too recent to compress."""
        if calls_back < self.perplexity_recent_cutoff:
            return None
        if calls_back < self.perplexity_mid_cutoff:
            return self.perplexity_keep_ratio_mid
        return self.perplexity_keep_ratio_old

    def _compress_with_cache(
        self, raw: str, ratio: float, key_part: str,
    ) -> Optional[str]:
        """Run perplexity compression with per-(id, ratio) caching."""
        if not raw or self.perplexity_classifier is None:
            return None
        key = (key_part, round(ratio, 3))
        cached = self._perplexity_cache.get(key)
        if cached is not None:
            self.stats.perplexity_cache_hits += 1
            return cached
        try:
            out = compress_text_perplexity(
                raw,
                classifier=self.perplexity_classifier,
                target_keep_ratio=ratio,
                window_words=self.perplexity_window_words,
                min_content_words=self.perplexity_min_content_words,
            )
        except Exception as exc:
            logger.warning("perplexity compression raised: %s", exc)
            return None
        self._perplexity_cache[key] = out
        return out

    def _maybe_early_exit(self, messages: list[Any]) -> Optional[HumanMessage]:
        call_index = sum(1 for m in messages if isinstance(m, AIMessage))
        if call_index < self.early_exit_min_call_index:
            return None
        if self.signals_fn is None:
            return None
        try:
            steps = build_steps_from_messages(messages)
            signals = self.signals_fn(steps) or {}
        except Exception as exc:
            logger.warning("token_saving signals_fn failed: %s", exc)
            return None

        streak = float(signals.get("streak", 0.0) or 0.0)
        hedge = float(signals.get("hedge", 0.0) or 0.0)
        diversity = float(signals.get("diversity", 0.0) or 0.0)

        fire = streak > 0.7 or (hedge > 0.6 and diversity > 0.5)
        if not fire:
            return None
        return HumanMessage(content=self.early_exit_text)


__all__ = [
    "TokenSavingMiddleware",
    "TokenSavingStats",
    "compress_tool_output",
    "compress_text_perplexity",
    "make_anthropic_classifier",
    "WordClassifier",
    "build_steps_from_messages",
    "default_suite_signals",
    "DEFAULT_COMPRESS_THRESHOLD_CHARS",
    "DEFAULT_HEAD_KEEP_CHARS",
    "DEFAULT_TAIL_KEEP_CHARS",
    "DEFAULT_KEEP_RECENT_TOOL_MESSAGES",
    "DEFAULT_EARLY_EXIT_MIN_CALL_INDEX",
    "DEFAULT_EARLY_EXIT_TEXT",
    "DEFAULT_PERPLEXITY_RECENT_CUTOFF",
    "DEFAULT_PERPLEXITY_MID_CUTOFF",
    "DEFAULT_PERPLEXITY_KEEP_RATIO_MID",
    "DEFAULT_PERPLEXITY_KEEP_RATIO_OLD",
    "DEFAULT_PERPLEXITY_WINDOW_WORDS",
]
