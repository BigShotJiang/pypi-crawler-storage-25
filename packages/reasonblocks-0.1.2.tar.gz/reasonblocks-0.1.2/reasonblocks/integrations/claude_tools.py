"""Anthropic / Claude Agent SDK tool factories over CodebaseMemory + ImportGraph.

Supports two surfaces:

1. **Anthropic Messages API (``anthropic`` package):** returns a list of
   JSONSchema tool specs suitable for ``client.messages.create(tools=...)``
   plus a ``dispatch`` callable that executes a tool-use block.

2. **Claude Agent SDK (``claude-agent-sdk`` package):** ``@tool``-decorated
   functions ready to pass into ``ClaudeSDKClient`` / ``query(...)`` as the
   ``tools`` argument, same shape as LangChain's integration.

Pick whichever matches your deployment; the underlying memory contract is
identical.
"""

from __future__ import annotations

import json
from typing import Any, Callable, Optional

from reasonblocks.codebase_memory import CodebaseMemory
from reasonblocks.import_graph import ImportGraph


# ---------------------------------------------------------------------------
# 1. Anthropic Messages API — tool specs + dispatcher
# ---------------------------------------------------------------------------

def make_claude_tools(
    memory: CodebaseMemory,
    graph: Optional[ImportGraph] = None,
    *,
    recall_top_k: int = 5,
    recall_threshold: float = 0.25,
    enable_store: bool = True,
    enable_impact: bool = True,
) -> tuple[list[dict[str, Any]], Callable[[str, dict[str, Any]], str]]:
    """Return ``(tool_specs, dispatch)`` for the Anthropic Messages API.

    ``tool_specs`` is a list of ``{name, description, input_schema}`` dicts
    suitable for ``client.messages.create(tools=tool_specs, ...)``.

    ``dispatch(tool_name, tool_input)`` runs the named tool and returns its
    string result (the ``content`` to send back in a ``tool_result`` block).
    Unknown tool names raise :class:`KeyError` so callers can surface the
    model's error cleanly.

    Example::

        tool_specs, dispatch = make_claude_tools(memory, graph)
        resp = client.messages.create(tools=tool_specs, messages=..., model=...)
        for block in resp.content:
            if block.type == "tool_use":
                result = dispatch(block.name, block.input)
                # ... append tool_result with result ...
    """
    tool_specs: list[dict[str, Any]] = []
    handlers: dict[str, Callable[[dict[str, Any]], str]] = {}

    tool_specs.append({
        "name": "recall_findings",
        "description": (
            "Search the ReasonBlocks memory for prior findings relevant to the "
            "query. Call this BEFORE reading files. If it returns findings about "
            "a file, trust them and skip re-reading that file."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": "Natural-language description of what you're looking for.",
                },
            },
            "required": ["query"],
        },
    })
    handlers["recall_findings"] = lambda inp: memory.format_recall(
        str(inp.get("query", "")),
        top_k=recall_top_k,
        score_threshold=recall_threshold,
    )

    if enable_store:
        tool_specs.append({
            "name": "store_finding",
            "description": (
                "Persist a finding to ReasonBlocks memory so future agent runs "
                "can recall it. Store small, self-contained facts; keep each "
                "entry tight and factual."
            ),
            "input_schema": {
                "type": "object",
                "properties": {
                    "content": {"type": "string", "description": "The finding (<8000 chars)."},
                    "file_path": {"type": "string", "description": "Repo-relative path."},
                    "finding_type": {
                        "type": "string",
                        "description": "Short tag: bug | behavior | pattern | note.",
                    },
                },
                "required": ["content"],
            },
        })
        handlers["store_finding"] = lambda inp: _dispatch_store(memory, inp)

    if graph is not None and enable_impact:
        tool_specs.append({
            "name": "impact_analysis",
            "description": (
                "Use the repo's import graph to see what depends on a file and "
                "what it depends on. Helps judge the blast radius of a change."
            ),
            "input_schema": {
                "type": "object",
                "properties": {
                    "file_path": {
                        "type": "string",
                        "description": "Repo-relative path (e.g. 'pydantic/main.py').",
                    },
                },
                "required": ["file_path"],
            },
        })
        handlers["impact_analysis"] = lambda inp: graph.format_impact(
            str(inp.get("file_path", "")),
        )

    def dispatch(tool_name: str, tool_input: dict[str, Any]) -> str:
        if tool_name not in handlers:
            raise KeyError(f"unknown tool: {tool_name}")
        try:
            return handlers[tool_name](tool_input)
        except Exception as exc:
            return f"(tool '{tool_name}' raised: {type(exc).__name__}: {exc})"

    return tool_specs, dispatch


def _dispatch_store(memory: CodebaseMemory, inp: dict[str, Any]) -> str:
    content = str(inp.get("content", "") or "")
    if not content:
        return "store skipped: empty content"
    fid = memory.store(
        content=content,
        file_path=str(inp.get("file_path", "") or ""),
        finding_type=str(inp.get("finding_type", "note") or "note"),
    )
    return f"stored (id={fid})" if fid else "store failed"


# ---------------------------------------------------------------------------
# 2. claude-agent-sdk — @tool-decorated functions
# ---------------------------------------------------------------------------

def make_claude_agent_sdk_tools(
    memory: CodebaseMemory,
    graph: Optional[ImportGraph] = None,
    *,
    recall_top_k: int = 5,
    recall_threshold: float = 0.25,
    enable_store: bool = True,
    enable_impact: bool = True,
) -> list[Any]:
    """Return a list of ``@tool``-decorated functions for the
    ``claude-agent-sdk`` package.

    The decorator returns SDK-specific tool descriptors, so this import is
    deferred; callers without the package installed never pay for it.
    """
    try:
        from claude_agent_sdk import tool  # type: ignore
    except ImportError as exc:  # pragma: no cover
        raise ImportError(
            "make_claude_agent_sdk_tools requires the claude-agent-sdk "
            "package. Install with: pip install claude-agent-sdk"
        ) from exc

    tools: list[Any] = []

    @tool(
        "recall_findings",
        "Search ReasonBlocks memory for prior findings relevant to a query.",
        {"query": str},
    )
    async def recall_findings(args: dict) -> dict:
        text = memory.format_recall(
            str(args.get("query", "")),
            top_k=recall_top_k,
            score_threshold=recall_threshold,
        )
        return {"content": [{"type": "text", "text": text}]}

    tools.append(recall_findings)

    if enable_store:

        @tool(
            "store_finding",
            "Persist a finding to ReasonBlocks memory.",
            {"content": str, "file_path": str, "finding_type": str},
        )
        async def store_finding(args: dict) -> dict:
            text = _dispatch_store(memory, args)
            return {"content": [{"type": "text", "text": text}]}

        tools.append(store_finding)

    if graph is not None and enable_impact:

        @tool(
            "impact_analysis",
            "Use the repo's import graph to see what depends on a file.",
            {"file_path": str},
        )
        async def impact_analysis(args: dict) -> dict:
            text = graph.format_impact(str(args.get("file_path", "")))
            return {"content": [{"type": "text", "text": text}]}

        tools.append(impact_analysis)

    return tools


# ---------------------------------------------------------------------------
# Helper: run a full Messages API agent loop with these tools
# ---------------------------------------------------------------------------

def run_messages_agent_loop(
    client: Any,
    *,
    model: str,
    messages: list[dict[str, Any]],
    tool_specs: list[dict[str, Any]],
    dispatch: Callable[[str, dict[str, Any]], str],
    system: str = "",
    max_steps: int = 40,
    max_tokens: int = 4096,
) -> dict[str, Any]:
    """Run the Anthropic Messages tool-use loop to completion.

    Useful when you want the batteries-included behavior without wiring
    the tool_use / tool_result turns by hand. Returns::

        {
            "final_text": "<agent's last assistant turn, text only>",
            "messages": [...],       # full message history
            "stop_reason": "end_turn" | "max_steps" | "...",
            "tool_calls": [(name, input, result), ...],
        }

    The ``client`` is expected to be an ``anthropic.Anthropic`` (or
    AsyncAnthropic) instance. This helper uses the synchronous API.
    """
    history = list(messages)
    tool_calls: list[tuple[str, dict[str, Any], str]] = []
    final_text = ""
    stop_reason = "max_steps"

    for _ in range(max_steps):
        kwargs: dict[str, Any] = {
            "model": model,
            "messages": history,
            "tools": tool_specs,
            "max_tokens": max_tokens,
        }
        if system:
            kwargs["system"] = system
        resp = client.messages.create(**kwargs)

        # Persist the assistant turn.
        history.append({"role": "assistant", "content": _content_to_list(resp.content)})

        # Accumulate any text, then collect tool_use blocks.
        text_parts: list[str] = []
        tool_uses: list[tuple[str, str, dict[str, Any]]] = []
        for block in resp.content:
            btype = getattr(block, "type", None)
            if btype == "text":
                text_parts.append(block.text)
            elif btype == "tool_use":
                tool_uses.append((block.id, block.name, dict(block.input or {})))
        if text_parts:
            final_text = "\n".join(text_parts)

        if resp.stop_reason != "tool_use":
            stop_reason = resp.stop_reason
            break

        # Dispatch every tool_use and send back a single user turn with
        # all the tool_result blocks.
        results_blocks: list[dict[str, Any]] = []
        for tool_id, name, inp in tool_uses:
            try:
                result_text = dispatch(name, inp)
            except Exception as exc:
                result_text = f"(dispatch error: {type(exc).__name__}: {exc})"
            tool_calls.append((name, inp, result_text))
            results_blocks.append({
                "type": "tool_result",
                "tool_use_id": tool_id,
                "content": result_text,
            })
        history.append({"role": "user", "content": results_blocks})

    return {
        "final_text": final_text,
        "messages": history,
        "stop_reason": stop_reason,
        "tool_calls": tool_calls,
    }


def _content_to_list(content: Any) -> list[dict[str, Any]]:
    """Normalize an assistant message's ``content`` into the list-of-dicts
    shape the next API call expects."""
    out: list[dict[str, Any]] = []
    for block in content or []:
        btype = getattr(block, "type", None)
        if btype == "text":
            out.append({"type": "text", "text": block.text})
        elif btype == "tool_use":
            out.append({
                "type": "tool_use",
                "id": block.id,
                "name": block.name,
                "input": json.loads(json.dumps(block.input or {})),
            })
    return out
