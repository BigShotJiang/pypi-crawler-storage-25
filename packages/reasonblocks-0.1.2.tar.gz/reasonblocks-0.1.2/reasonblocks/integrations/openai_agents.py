"""OpenAI Agents SDK integration: tool factory + RunHooks.

The ``openai-agents`` package (``from agents import Agent, Runner, ...``)
uses a different lifecycle than LangChain -- there's no middleware
chain, just a ``RunHooks`` callback object passed to ``Runner.run``.
This module provides the equivalent of ``rb.middleware()`` for that
shape: a hooks object that emits the same ``run_start / step /
run_finish`` telemetry the LangChain middleware does, plus a tool
factory for ``CodebaseMemory`` + ``ImportGraph``.

Usage::

    from agents import Agent, Runner
    from reasonblocks import ReasonBlocks
    from reasonblocks.integrations import make_openai_tools

    rb = ReasonBlocks(api_key="rb_live_...")
    hooks = rb.openai_hooks(
        run_id="my-run-1",
        agent_name="bugfixer",
        task="describe what this run is doing",
    )

    agent = Agent(
        name="reviewer",
        instructions="...",
        tools=[*make_openai_tools(memory, graph), *your_tools],
    )

    result = await Runner.run(agent, input="...", hooks=hooks)
    # hooks.on_agent_end auto-fires run_finish; nothing else to call.

The hooks object is also a context manager (``async with hooks:`` /
``with hooks:``) so an exception path still flushes the failure
outcome -- mirrors the ``with mw:`` pattern from the LangChain
middleware.
"""

from __future__ import annotations

import logging
import time
from typing import Any, Optional

from reasonblocks.codebase_memory import CodebaseMemory
from reasonblocks.import_graph import ImportGraph
from reasonblocks.streaming_emitter import StreamingEmitter

logger = logging.getLogger("reasonblocks.openai_agents")


# ---------------------------------------------------------------------------
# 1. Tools -- function_tool wrappers over CodebaseMemory + ImportGraph
# ---------------------------------------------------------------------------

def make_openai_tools(
    memory: Optional[CodebaseMemory] = None,
    graph: Optional[ImportGraph] = None,
    *,
    recall_top_k: int = 5,
    recall_threshold: float = 0.25,
    enable_recall: bool = True,
    enable_store: bool = True,
    enable_impact: bool = True,
) -> list[Any]:
    """Return ``function_tool``-decorated callables ready for
    ``Agent(tools=[...])``.

    Mirrors the langchain_tools / claude_tools factories. The
    underlying CodebaseMemory + ImportGraph contracts are identical;
    only the framework decoration differs.
    """
    try:
        from agents import function_tool
    except ImportError as exc:  # pragma: no cover
        raise ImportError(
            "reasonblocks.integrations.openai_agents requires the "
            "openai-agents package. Install with: pip install openai-agents"
        ) from exc

    tools: list[Any] = []

    if enable_recall and memory is not None:

        @function_tool
        def recall_findings(query: str) -> str:
            """Search ReasonBlocks memory for prior findings.

            Call this BEFORE reading files. If it returns findings
            about a file, trust them and skip re-reading that file.

            Args:
                query: Natural-language description of what you're
                    looking for.
            """
            return memory.format_recall(
                query, top_k=recall_top_k, score_threshold=recall_threshold,
            )

        tools.append(recall_findings)

    if enable_store and memory is not None:

        @function_tool
        def store_finding(
            content: str,
            file_path: str = "",
            finding_type: str = "note",
        ) -> str:
            """Persist a finding for future agent runs.

            Store small, self-contained facts. Don't store long
            paragraphs; keep each finding tight and factual.

            Args:
                content: The finding (<8000 chars).
                file_path: Repo-relative path the finding is about.
                finding_type: Short tag (bug | behavior | pattern | note).
            """
            fid = memory.store(
                content=content,
                file_path=file_path,
                finding_type=finding_type,
            )
            return f"stored (id={fid})" if fid else "store failed"

        tools.append(store_finding)

    if graph is not None and enable_impact:

        @function_tool
        def impact_analysis(file_path: str) -> str:
            """Look up dependents and dependencies for a file via the
            repo's import graph. Helps judge the blast radius of a
            change.

            Args:
                file_path: Repo-relative path (e.g. 'pydantic/main.py').
            """
            return graph.format_impact(file_path)

        tools.append(impact_analysis)

    return tools


# ---------------------------------------------------------------------------
# 2. RunHooks -- telemetry emission via the same StreamingEmitter
# ---------------------------------------------------------------------------

def _make_run_hooks_class():
    """Build the RunHooks subclass lazily so importing this module
    doesn't force the openai-agents dependency on callers who only
    want the tool factory."""
    try:
        from agents import RunHooks
    except ImportError as exc:  # pragma: no cover
        raise ImportError(
            "ReasonBlocksHooks requires the openai-agents package. "
            "Install with: pip install openai-agents"
        ) from exc

    class ReasonBlocksHooks(RunHooks):
        """RunHooks adapter that pushes telemetry through a
        :class:`StreamingEmitter`.

        Fires ``run_start`` on the first ``on_agent_start`` callback,
        a ``step`` event on every ``on_tool_end``, and ``run_finish``
        on ``on_agent_end`` (or via the context manager's __exit__ if
        the run raised).

        Don't construct this directly -- use ``rb.openai_hooks(...)``
        from a configured :class:`~reasonblocks.client.ReasonBlocks`
        instance, which wires the emitter and run metadata.
        """

        def __init__(
            self,
            *,
            emitter: Optional[StreamingEmitter],
            run_id: str,
            run_metadata: dict[str, Any],
        ) -> None:
            super().__init__()
            self._emitter = emitter
            self._run_id = run_id
            self._run_metadata = dict(run_metadata)
            self._step_index = 0
            self._run_started_emitted = False
            self._run_finished_emitted = False
            self._explicit_outcome: Optional[str] = None
            # Track per-tool start times so on_tool_end can emit a
            # latency_ms metadata field.
            self._tool_started_at: dict[int, float] = {}

        # ----- emit helpers (mirror middleware's _maybe_emit_*) ---

        def _maybe_emit_run_start(self) -> None:
            if self._emitter is None or self._run_started_emitted:
                return
            self._run_started_emitted = True
            meta = dict(self._run_metadata)
            self._emitter.emit_run_start({
                "run_id":       self._run_id,
                "agent_name":   meta.pop("agent_name", "") or "",
                "task":         meta.pop("task", "") or "",
                "model":        meta.pop("model", "") or "",
                "framework":    meta.pop("framework", "openai-agents") or "openai-agents",
                "codebase_id":  meta.pop("codebase_id", "") or "",
                "org_id":       meta.pop("org_id", "default") or "default",
                "project_id":   meta.pop("project_id", "default") or "default",
                "task_profile": meta.pop("task_profile", "coding") or "coding",
                "metadata":     meta,
            })

        def _maybe_emit_run_finish(self, *, outcome_status: str) -> None:
            if self._emitter is None:
                return
            self._emitter.emit_run_finish({
                "run_id": self._run_id,
                "outcome": outcome_status,
            })
            self._run_finished_emitted = True

        # ----- public override hook ------------------------------

        def mark_failure(self, *, reason: str = "failure") -> None:
            """Override the default "success" outcome with the given
            reason. Same semantics as
            :meth:`ReasonBlocksMiddleware.mark_failure`."""
            self._explicit_outcome = reason

        def close(self, timeout: float = 5.0) -> None:
            """Drain the emitter queue and stop the worker. Idempotent."""
            if self._emitter is not None:
                self._emitter.close(timeout=timeout)

        # ----- RunHooks lifecycle --------------------------------

        async def on_agent_start(self, context, agent) -> None:
            del context, agent
            try:
                self._maybe_emit_run_start()
            except Exception:
                logger.warning("on_agent_start emit failed", exc_info=True)

        async def on_tool_start(self, context, agent, tool) -> None:
            del context, agent
            tool_id = id(tool)
            self._tool_started_at[tool_id] = time.perf_counter()

        async def on_tool_end(self, context, agent, tool, result) -> None:
            del context, agent
            tool_id = id(tool)
            start = self._tool_started_at.pop(tool_id, None)
            latency_ms = (time.perf_counter() - start) * 1000.0 if start else 0.0
            try:
                action = getattr(tool, "name", None) or getattr(tool, "__name__", None) or "unknown"
                # tool input/args aren't directly exposed on the Tool
                # object across openai-agents versions; we just record
                # the result. Customers can attach extra detail via
                # the metadata kwarg if they need it.
                self._emitter.emit_step({
                    "run_id":     self._run_id,
                    "step_index": self._step_index,
                    "action":     action,
                    "action_input": "",
                    "thought":    None,
                    "observation": str(result)[:8000] if result is not None else None,
                    "is_error":   False,
                    "tokens":     0,
                    "injections": [],
                    "injection_sources": [],
                    "intervention_texts": [],
                    "monitors_fired": [],
                    "failure_type": None,
                    "metadata": {"latency_ms": round(latency_ms, 2)},
                }) if self._emitter else None
                self._step_index += 1
            except Exception:
                logger.warning("on_tool_end emit failed", exc_info=True)

        async def on_agent_end(self, context, agent, output) -> None:
            del context, agent, output
            try:
                outcome = self._explicit_outcome or "success"
                self._maybe_emit_run_finish(outcome_status=outcome)
            except Exception:
                logger.warning("on_agent_end emit failed", exc_info=True)

        # ----- context-manager support (sync + async) ------------

        def __enter__(self):
            return self

        def __exit__(self, exc_type, exc_value, traceback) -> None:
            self._exit_common(exc_type)

        async def __aenter__(self):
            return self

        async def __aexit__(self, exc_type, exc_value, traceback) -> None:
            self._exit_common(exc_type)

        def _exit_common(self, exc_type) -> None:
            if self._explicit_outcome is not None:
                outcome = self._explicit_outcome
            elif exc_type is not None:
                outcome = f"failure: {exc_type.__name__}"
            else:
                outcome = "success"
            try:
                # Emit again to override the on_agent_end default if
                # the caller set mark_failure() after the agent
                # returned, or to record an exception that escaped.
                if not self._run_finished_emitted or outcome != "success":
                    self._maybe_emit_run_finish(outcome_status=outcome)
                self.close()
            except Exception:
                logger.warning("hooks __exit__ flush failed", exc_info=True)

    return ReasonBlocksHooks


def build_hooks(
    *,
    emitter: Optional[StreamingEmitter],
    run_id: str,
    run_metadata: dict[str, Any],
) -> Any:
    """Internal: construct a ReasonBlocksHooks. The class itself is
    built lazily so importing this module doesn't drag the
    openai-agents package in for callers who only want the tools."""
    cls = _make_run_hooks_class()
    return cls(emitter=emitter, run_id=run_id, run_metadata=run_metadata)
