"""LangChain / LangGraph tool factories over CodebaseMemory + ImportGraph.

Call :func:`make_langchain_tools` once per agent run, pass the returned
list straight into ``create_agent(..., tools=rb_tools + your_tools)``.

The tools are thin wrappers around :class:`CodebaseMemory` and
:class:`ImportGraph` -- see those classes for the underlying contract.
"""

from __future__ import annotations

from typing import Any, Optional

from reasonblocks.codebase_memory import CodebaseMemory
from reasonblocks.import_graph import ImportGraph


def make_langchain_tools(
    memory: Optional[CodebaseMemory] = None,
    graph: Optional[ImportGraph] = None,
    *,
    recall_top_k: int = 5,
    recall_threshold: float = 0.25,
    enable_recall: bool = True,
    enable_store: bool = True,
    enable_impact: bool = True,
) -> list[Any]:
    """Return a list of LangChain ``@tool`` functions wired to ``memory``
    and (optionally) ``graph``.

    Parameters
    ----------
    memory:
        The :class:`CodebaseMemory` the tools read from and (optionally)
        write to. Bind one per agent run.
    graph:
        Optional :class:`ImportGraph`. When provided, ``impact_analysis``
        is added to the tool list so the agent can query dependents /
        dependencies for a file.
    enable_store:
        Include a ``store_finding`` tool so the agent can persist new
        observations during a run. Disable in read-only scenarios.
    enable_impact:
        Include the impact-analysis tool when a graph is available.

    Returns
    -------
    list of LangChain Tool objects, safe to concatenate with the caller's
    own tool list and pass to ``create_agent`` or LangGraph.
    """
    try:
        from langchain_core.tools import tool
    except ImportError as exc:  # pragma: no cover
        raise ImportError(
            "reasonblocks.integrations.langchain_tools requires "
            "langchain-core. Install with: pip install langchain-core"
        ) from exc

    tools: list[Any] = []

    if enable_recall and memory is not None:

        @tool
        def recall_findings(query: str) -> str:
            """Search the ReasonBlocks memory for prior findings relevant to the query.

            Call this BEFORE reading files. If it returns findings about a file, trust
            them and skip re-reading that file.

            Args:
                query: Natural-language description of what you're looking for.
            """
            return memory.format_recall(
                query, top_k=recall_top_k, score_threshold=recall_threshold,
            )

        tools.append(recall_findings)

    if enable_store and memory is not None:

        @tool
        def store_finding(content: str, file_path: str = "", finding_type: str = "note") -> str:
            """Persist a finding to ReasonBlocks memory for future agent runs.

            Store small, self-contained facts: "BaseModel.__eq__ ignores
            private attrs", "validators run in field order", etc. Don't
            store long paragraphs; keep each finding tight and factual.

            Args:
                content: The finding itself (<8000 chars).
                file_path: Repo-relative path the finding is about, if any.
                finding_type: short tag (bug | behavior | pattern | note).
            """
            fid = memory.store(
                content=content, file_path=file_path, finding_type=finding_type,
            )
            return f"stored (id={fid})" if fid else "store failed"

        tools.append(store_finding)

    if graph is not None and enable_impact:

        @tool
        def impact_analysis(file_path: str) -> str:
            """Use the repo's import graph to see what depends on a file and
            what it depends on. Helps you judge the blast radius of a change.

            Args:
                file_path: Repo-relative path (e.g. 'pydantic/main.py').
            """
            return graph.format_impact(file_path)

        tools.append(impact_analysis)

    return tools
