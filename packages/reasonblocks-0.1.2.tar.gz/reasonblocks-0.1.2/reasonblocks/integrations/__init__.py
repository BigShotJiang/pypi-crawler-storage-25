"""Framework integrations for ReasonBlocks codebase memory.

Three sibling modules ship tools for the common agent frameworks:

* :mod:`reasonblocks.integrations.langchain_tools` -- factory that returns
  a list of LangChain ``@tool``-decorated functions, ready to pass into
  ``create_agent(... , tools=...)`` / LangGraph.

* :mod:`reasonblocks.integrations.claude_tools` -- factory that returns
  tool definitions for Anthropic's Messages tool-use API and the
  ``claude-agent-sdk`` package.

* :mod:`reasonblocks.integrations.openai_agents` -- factory for the
  ``openai-agents`` package's ``function_tool``, plus a ``RunHooks``
  adapter that mirrors the LangChain middleware's telemetry emission.

All factories accept the same ``CodebaseMemory`` + optional
``ImportGraph`` so the memory layer stays framework-neutral.
"""

from __future__ import annotations

__all__ = [
    "make_langchain_tools",
    "make_claude_tools",
    "make_claude_agent_sdk_tools",
    "make_openai_tools",
]


def __getattr__(name: str):
    if name == "make_langchain_tools":
        from reasonblocks.integrations.langchain_tools import make_langchain_tools
        return make_langchain_tools
    if name == "make_claude_tools":
        from reasonblocks.integrations.claude_tools import make_claude_tools
        return make_claude_tools
    if name == "make_claude_agent_sdk_tools":
        from reasonblocks.integrations.claude_tools import make_claude_agent_sdk_tools
        return make_claude_agent_sdk_tools
    if name == "make_openai_tools":
        from reasonblocks.integrations.openai_agents import make_openai_tools
        return make_openai_tools
    raise AttributeError(f"module 'reasonblocks.integrations' has no attribute {name!r}")
