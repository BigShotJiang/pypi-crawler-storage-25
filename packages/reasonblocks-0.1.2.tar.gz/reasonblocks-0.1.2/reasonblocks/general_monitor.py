"""General cross-domain reactive monitor pack (v1) + LangChain middleware.

Five rule-based detectors, each grounded in a transferable failure shape
surfaced by the post-autolabel re-cluster of 5,282 trajectories from the
trajectory-research corpus (see ``reasonblocks-trajectory-research/`` and
the HLE validation in ``reasonblocks-general-monitors/``).

- **v1 architecture (rule-firing + cooldown)** — boolean detectors,
  priority-ordered dispatch, per-rule cooldown, one firing per LLM call.
  This is the architecture that produced the +10.7pp SWE-bench Pro
  result and the +4.0pp HLE delta (46.0% → 50.0% on Sonnet 4.6, n=150).
- **Observation+pause injection framing** — all rule text names the
  trajectory pattern and invites reflection; no directives, no tool
  names, no task verbs. Rationale: the earlier directive-style
  injections regressed -14.3pp on multi-step-agent clusters because
  they pushed models toward confident commitments that weren't safe.

Typical wiring::

    from reasonblocks import (
        GeneralMonitorMiddleware,
        TokenSavingMiddleware,
    )

    agent = create_agent(
        model=..., tools=...,
        middleware=[
            GeneralMonitorMiddleware(max_tool_calls=30),
            TokenSavingMiddleware(),
        ],
    )

The combination ``GeneralMonitorMiddleware + TokenSavingMiddleware`` is
the stack validated at +2.0pp with −24% input tokens and 5.3% paired
regression rate on HLE (see ``reasonblocks-general-monitors/results/
hle_full_stack.md``).

For rule design rationale and the five trajectory shapes that each rule
targets, see ``reasonblocks-general-monitors/results/general_pack_design.md``.
"""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from typing import Any

from langchain.agents.middleware import AgentMiddleware
from langchain.messages import AIMessage, HumanMessage, ToolMessage

logger = logging.getLogger("reasonblocks.general_monitor")


# ---------------------------------------------------------------------------
# Rule catalog
# ---------------------------------------------------------------------------

RULES: dict[int, tuple[str, str]] = {
    1: (
        "repeated_attempt_same_outcome",
        "The last several actions used very similar inputs, and at least one "
        "returned an error signal. Consider whether continuing in this "
        "direction is producing new information.",
    ),
    2: (
        "error_without_diagnosis",
        "The previous result contained an error signal, and the next step "
        "continues in the same direction without examining what happened. "
        "Consider pausing to review that result before taking another "
        "similar step.",
    ),
    3: (
        "exploration_sprawl",
        "Across the last several actions, each one has opened a new line "
        "of inquiry. Consider whether it is time to synthesize what you "
        "have gathered before continuing to open new threads.",
    ),
    4: (
        "idle_response_early",
        "You prepared a response without requesting another action, but a "
        "substantial portion of your budget remains. Consider whether the "
        "task is truly complete at this point or whether more exploration "
        "would help.",
    ),
    5: (
        "low_novelty_tail",
        "Your recent reasoning turns are very similar to each other. "
        "Consider whether additional reflection is producing new ideas or "
        "rephrasing earlier ones.",
    ),
}

# Priority: higher-urgency / more specific first.
PRIORITY = [2, 1, 4, 3, 5]


# ---------------------------------------------------------------------------
# Shared helpers
# ---------------------------------------------------------------------------

_ERROR_RE = re.compile(
    r"(?i)(\b(error|exception|traceback|failed|failure|not\s+found|denied|"
    r"unauthorized|invalid|cannot|could\s+not|unable|timeout|refused|"
    r"no\s+such)\b|\w+Error\b|\w+Exception\b)"
)
_WORD_RE = re.compile(r"[A-Za-z0-9_]+")


def _tokenize(text: str) -> set[str]:
    return {t.lower() for t in _WORD_RE.findall(text or "")}


def _jaccard(a: set[str], b: set[str]) -> float:
    if not a and not b:
        return 1.0
    if not a or not b:
        return 0.0
    return len(a & b) / len(a | b)


def _has_error_signal(text: str) -> bool:
    return bool(_ERROR_RE.search(text or ""))


def _arg_signature(call: dict) -> str:
    """Stable key for an assistant tool call: name + sorted-arg string.

    Clipped to 200 chars per key so long inline code bodies don't swamp
    the signature. Two calls with the same name and the same leading 200
    chars of stringified args count as the same for loop detection.
    """
    name = str(call.get("name", ""))
    args = call.get("args") or {}
    parts = [f"{k}={str(args[k])[:200]}" for k in sorted(args.keys())]
    return f"{name}::" + "|".join(parts)


# ---------------------------------------------------------------------------
# Firing record
# ---------------------------------------------------------------------------

@dataclass
class Firing:
    step: int
    rule_id: int
    rule_name: str
    trigger: str
    injection_text: str


# ---------------------------------------------------------------------------
# Core engine (framework-agnostic)
# ---------------------------------------------------------------------------

@dataclass
class GeneralMonitor:
    """Pure-Python rule engine. Does not depend on LangChain.

    ``history`` is a list of dicts:

        {"role": "ai" | "tool" | "user",
         "tool_calls": [{"name": str, "args": dict, "id": str}],  # for ai
         "content": str,                                          # tool result / ai text / user text
         "step": int,
         "tool_call_id": str}                                     # for tool

    Use :class:`GeneralMonitorMiddleware` to plug into LangChain.
    """

    max_tool_calls: int = 30
    cooldown: int = 8

    _last_fired: dict[int, int] = field(
        default_factory=lambda: {i: -1000 for i in RULES}
    )
    firings: list[Firing] = field(default_factory=list)
    _opportunity_count: int = 0

    # ---- entry point ------------------------------------------------------

    def check(self, history: list[dict], call_index: int) -> Firing | None:
        tool_calls = self._collect_tool_calls(history)
        tool_results = self._collect_tool_results(history)
        assistant_texts = self._collect_assistant_texts(history)

        if any(call_index - self._last_fired[r] >= self.cooldown for r in RULES):
            self._opportunity_count += 1

        for rule_id in PRIORITY:
            if call_index - self._last_fired[rule_id] < self.cooldown:
                continue
            trig = self._dispatch(
                rule_id, tool_calls, tool_results, assistant_texts, call_index,
            )
            if trig is None:
                continue
            self._last_fired[rule_id] = call_index
            name, text = RULES[rule_id]
            fired = Firing(step=call_index, rule_id=rule_id, rule_name=name,
                           trigger=trig, injection_text=text)
            self.firings.append(fired)
            return fired
        return None

    # ---- dispatch ---------------------------------------------------------

    def _dispatch(
        self, rule_id: int,
        tool_calls: list[dict], tool_results: list[dict],
        assistant_texts: list[dict], call_index: int,
    ) -> str | None:
        if rule_id == 1:
            return self._detect_repeated_attempt_same_outcome(tool_calls, tool_results)
        if rule_id == 2:
            return self._detect_error_without_diagnosis(tool_calls, tool_results)
        if rule_id == 3:
            return self._detect_exploration_sprawl(tool_calls, call_index)
        if rule_id == 4:
            return self._detect_idle_response_early(
                tool_calls, assistant_texts, call_index,
            )
        if rule_id == 5:
            return self._detect_low_novelty_tail(assistant_texts, call_index)
        return None

    # ---- detectors --------------------------------------------------------

    def _detect_repeated_attempt_same_outcome(
        self, tool_calls: list[dict], tool_results: list[dict],
    ) -> str | None:
        if len(tool_calls) < 3:
            return None
        last3 = tool_calls[-3:]
        toks = [_tokenize(_arg_signature(c)) for c in last3]
        j01 = _jaccard(toks[0], toks[1])
        j12 = _jaccard(toks[1], toks[2])
        if min(j01, j12) < 0.7:
            return None
        if len(tool_results) < len(tool_calls) - 1:
            return None
        window_steps = {c["step"] for c in last3}
        window_results = [r for r in tool_results if r["step"] >= min(window_steps)]
        for r in window_results[-4:]:
            if _has_error_signal(r.get("content", "")):
                return (
                    f"3 similar actions (jaccard {j01:.2f}/{j12:.2f}), "
                    f"error signal in window"
                )
        return None

    def _detect_error_without_diagnosis(
        self, tool_calls: list[dict], tool_results: list[dict],
    ) -> str | None:
        if len(tool_results) < 1 or len(tool_calls) < 2:
            return None
        last_result = tool_results[-1]
        if not _has_error_signal(last_result.get("content", "")):
            return None
        prev_call = tool_calls[-2]
        next_call = tool_calls[-1]
        if prev_call.get("name") != next_call.get("name"):
            return None
        prev_toks = _tokenize(_arg_signature(prev_call))
        next_toks = _tokenize(_arg_signature(next_call))
        if _jaccard(prev_toks, next_toks) < 0.3:
            return None
        return f"error result at step {last_result['step']}, same-name follow-up"

    def _detect_exploration_sprawl(
        self, tool_calls: list[dict], call_index: int,
    ) -> str | None:
        if call_index < 0.6 * self.max_tool_calls:
            return None
        if len(tool_calls) < 5:
            return None
        seen: set[str] = set()
        last5_steps = {c["step"] for c in tool_calls[-5:]}
        for c in tool_calls:
            if c["step"] in last5_steps:
                continue
            seen.add(_arg_signature(c))
        novel = 0
        for c in tool_calls[-5:]:
            if _arg_signature(c) not in seen:
                novel += 1
        if novel >= 5:
            return (
                f"call {call_index}/{self.max_tool_calls}, last 5 actions "
                f"all novel signatures"
            )
        return None

    def _detect_idle_response_early(
        self, tool_calls: list[dict], assistant_texts: list[dict],
        call_index: int,
    ) -> str | None:
        if not assistant_texts:
            return None
        if call_index >= 0.4 * self.max_tool_calls:
            return None
        last_ai = assistant_texts[-1]
        if last_ai.get("had_tool_call"):
            return None
        idle_so_far = sum(1 for a in assistant_texts if not a.get("had_tool_call"))
        if idle_so_far > 1:
            return None
        return (
            f"idle assistant turn at call {call_index}/{self.max_tool_calls}"
        )

    def _detect_low_novelty_tail(
        self, assistant_texts: list[dict], call_index: int,
    ) -> str | None:
        if call_index < 0.3 * self.max_tool_calls:
            return None
        if len(assistant_texts) < 3:
            return None
        last3 = assistant_texts[-3:]
        toks = [_tokenize(a.get("content", "")) for a in last3]
        if any(len(t) < 5 for t in toks):
            return None
        j01 = _jaccard(toks[0], toks[1])
        j12 = _jaccard(toks[1], toks[2])
        if min(j01, j12) < 0.6:
            return None
        return f"3 reasoning turns with jaccard {j01:.2f}/{j12:.2f}"

    # ---- history extraction (internal view) ------------------------------

    @staticmethod
    def _collect_tool_calls(history: list[dict]) -> list[dict]:
        out: list[dict] = []
        for entry in history:
            if entry.get("role") != "ai":
                continue
            for tc in entry.get("tool_calls", []) or []:
                out.append({
                    "step": entry.get("step", 0),
                    "name": str(tc.get("name", "")),
                    "args": tc.get("args") or {},
                })
        return out

    @staticmethod
    def _collect_tool_results(history: list[dict]) -> list[dict]:
        out: list[dict] = []
        id_to_name: dict[str, str] = {}
        for entry in history:
            if entry.get("role") == "ai":
                for tc in entry.get("tool_calls", []) or []:
                    if tc.get("id"):
                        id_to_name[tc["id"]] = tc.get("name", "")
            elif entry.get("role") == "tool":
                tcid = entry.get("tool_call_id")
                out.append({
                    "step": entry.get("step", 0),
                    "name": id_to_name.get(tcid or "", entry.get("name", "")),
                    "content": str(entry.get("content", "")),
                })
        return out

    @staticmethod
    def _collect_assistant_texts(history: list[dict]) -> list[dict]:
        out: list[dict] = []
        for entry in history:
            if entry.get("role") != "ai":
                continue
            had_tc = bool(entry.get("tool_calls"))
            out.append({
                "step": entry.get("step", 0),
                "content": str(entry.get("content") or ""),
                "had_tool_call": had_tc,
            })
        return out

    # ---- introspection ----------------------------------------------------

    @property
    def firing_opportunity_count(self) -> int:
        return self._opportunity_count


# ---------------------------------------------------------------------------
# Stats
# ---------------------------------------------------------------------------

@dataclass
class GeneralMonitorStats:
    """Running counters on the middleware."""

    firings: int = 0
    by_rule: dict[str, int] = field(default_factory=dict)
    opportunities: int = 0


# ---------------------------------------------------------------------------
# LangChain middleware wrapper
# ---------------------------------------------------------------------------

def _langchain_messages_to_history(messages: list[Any]) -> list[dict]:
    """Translate a LangChain message list into the monitor's history format."""
    out: list[dict] = []
    id_to_name: dict[str, str] = {}
    step = 0
    for m in messages:
        if isinstance(m, AIMessage):
            text = ""
            content = getattr(m, "content", "")
            if isinstance(content, str):
                text = content
            elif isinstance(content, list):
                text = "\n".join(
                    blk.get("text", "") for blk in content
                    if isinstance(blk, dict) and blk.get("type") == "text"
                )
            tool_calls_raw = getattr(m, "tool_calls", []) or []
            tool_calls = []
            for tc in tool_calls_raw:
                name = tc.get("name") if isinstance(tc, dict) else getattr(tc, "name", "")
                args = tc.get("args") if isinstance(tc, dict) else getattr(tc, "args", {})
                tcid = tc.get("id") if isinstance(tc, dict) else getattr(tc, "id", None)
                tool_calls.append({"name": name, "args": args or {}, "id": tcid})
                if tcid:
                    id_to_name[tcid] = name or ""
            out.append({
                "role": "ai", "step": step, "content": text,
                "tool_calls": tool_calls,
            })
            step += 1
        elif isinstance(m, ToolMessage):
            tcid = getattr(m, "tool_call_id", None)
            content = getattr(m, "content", "")
            if isinstance(content, list):
                content = "".join(
                    (blk.get("text", "") if isinstance(blk, dict) else "")
                    for blk in content
                )
            out.append({
                "role": "tool", "step": step,
                "tool_call_id": tcid,
                "name": id_to_name.get(tcid or "", ""),
                "content": str(content),
            })
            step += 1
        elif isinstance(m, HumanMessage):
            content = getattr(m, "content", "")
            if isinstance(content, list):
                content = "".join(
                    (blk.get("text", "") if isinstance(blk, dict) else "")
                    for blk in content
                )
            out.append({
                "role": "user", "step": step,
                "content": str(content), "tool_calls": [],
            })
            step += 1
    return out


class GeneralMonitorMiddleware(AgentMiddleware):
    """LangChain middleware wrapping :class:`GeneralMonitor`.

    Inspects history before each model call; injects a single
    :class:`HumanMessage` with the firing's text when a rule fires.
    One firing per model call, priority-ordered, per-rule cooldown=8.

    Failures in the hook are logged and swallowed — the middleware
    never breaks the agent loop.
    """

    def __init__(
        self,
        *,
        max_tool_calls: int = 30,
        cooldown: int = 8,
    ) -> None:
        super().__init__()
        self.monitor = GeneralMonitor(
            max_tool_calls=max_tool_calls, cooldown=cooldown,
        )
        self.stats = GeneralMonitorStats()
        self._call_index = 0

    def before_model(self, state, runtime=None):
        try:
            return self._before_impl(state)
        except Exception as exc:
            logger.warning("general_monitor before_model failed: %s", exc)
            return None

    def _before_impl(self, state):
        messages = list(state.get("messages", []) or [])
        if not messages:
            return None
        self._call_index += 1
        history = _langchain_messages_to_history(messages)
        fire = self.monitor.check(history, self._call_index)
        self.stats.opportunities = self.monitor.firing_opportunity_count
        if fire is None:
            return None
        self.stats.firings += 1
        self.stats.by_rule[fire.rule_name] = (
            self.stats.by_rule.get(fire.rule_name, 0) + 1
        )
        return {"messages": [HumanMessage(content=fire.injection_text)]}


__all__ = [
    "GeneralMonitor",
    "GeneralMonitorMiddleware",
    "GeneralMonitorStats",
    "Firing",
    "RULES",
    "PRIORITY",
]
