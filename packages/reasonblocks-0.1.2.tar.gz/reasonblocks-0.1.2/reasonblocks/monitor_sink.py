"""Local SQLite sink for mid-run monitor telemetry.

Writes runs + per-step monitor scores to a single .db file. A tiny HTTP
read server (``reasonblocks.monitor_server``) serves it to the dashboard.

Typical usage::

    from reasonblocks.monitor_sink import SQLiteMonitorSink
    from reasonblocks.monitors.suite import evaluate_all

    sink = SQLiteMonitorSink("monitor_data.db")
    sink.start_run(
        run_id="pr_42_langchain",
        agent_name="pr_review",
        task="Review PR #42",
        model="claude-sonnet-4-20250514",
        framework="langchain",
    )

    for i, step in enumerate(run_steps_so_far()):
        bundle = evaluate_all(step_history_up_to(i))
        sink.log_step(
            run_id="pr_42_langchain",
            step_index=i,
            action=step.get("action"),
            thought=step.get("thought"),
            observation=step.get("observation"),
            tokens=step.get("tokens_used", 0),
            scores=bundle["scores"],
            total_score=bundle["total"],
            fired=bundle["fired"],
        )

    sink.finish_run(run_id="pr_42_langchain", outcome="success")

The sink degrades gracefully: if the DB is locked or the write fails, a
warning is logged and the agent loop continues unharmed.
"""

from __future__ import annotations

import json
import logging
import sqlite3
import threading
from pathlib import Path
from typing import Any, Optional

logger = logging.getLogger("reasonblocks.monitor_sink")

_SCHEMA_PATH = Path(__file__).resolve().parent.parent / "sql" / "monitor_schema.sql"


class SQLiteMonitorSink:
    """Thread-safe SQLite writer for monitor telemetry."""

    def __init__(self, db_path: str | Path = "monitor_data.db") -> None:
        self._db_path = str(db_path)
        self._lock = threading.Lock()
        self._conn = sqlite3.connect(
            self._db_path,
            check_same_thread=False,
            isolation_level=None,      # autocommit
        )
        self._conn.execute("pragma journal_mode=wal")
        self._conn.execute("pragma foreign_keys=on")
        self._apply_schema()

    @property
    def db_path(self) -> str:
        return self._db_path

    def _apply_schema(self) -> None:
        if not _SCHEMA_PATH.exists():
            logger.warning("monitor schema missing at %s", _SCHEMA_PATH)
            return
        sql = _SCHEMA_PATH.read_text(encoding="utf-8")
        with self._lock:
            self._conn.executescript(sql)
            # Idempotent column additions for DBs created before the
            # injection fields were introduced. SQLite lacks
            # ``add column if not exists`` so we inspect pragma_table_info.
            existing = {
                row[1] for row in
                self._conn.execute("pragma table_info(monitor_steps)").fetchall()
            }
            migrations = {
                "injections":         "alter table monitor_steps add column injections text not null default '[]'",
                "injection_sources":  "alter table monitor_steps add column injection_sources text not null default '[]'",
                "intervention_texts": "alter table monitor_steps add column intervention_texts text not null default '[]'",
                "monitors_fired":     "alter table monitor_steps add column monitors_fired text not null default '[]'",
            }
            for col, stmt in migrations.items():
                if col not in existing:
                    try:
                        self._conn.execute(stmt)
                    except sqlite3.OperationalError as exc:
                        logger.warning("schema migration for %s failed: %s", col, exc)

    # ------------------------------------------------------------------
    # Run lifecycle
    # ------------------------------------------------------------------

    def start_run(
        self,
        *,
        run_id: str,
        agent_name: str = "",
        task: str = "",
        model: str = "",
        framework: str = "",
        codebase_id: str = "",
        metadata: Optional[dict[str, Any]] = None,
    ) -> None:
        try:
            with self._lock:
                self._conn.execute(
                    """
                    insert into monitor_runs
                      (run_id, agent_name, task, model, framework, codebase_id, metadata)
                    values
                      (?, ?, ?, ?, ?, ?, ?)
                    on conflict(run_id) do update set
                      agent_name  = excluded.agent_name,
                      task        = excluded.task,
                      model       = excluded.model,
                      framework   = excluded.framework,
                      codebase_id = excluded.codebase_id,
                      metadata    = excluded.metadata
                    """,
                    (
                        run_id, agent_name, task, model,
                        framework, codebase_id,
                        json.dumps(metadata or {}, default=str),
                    ),
                )
        except Exception as exc:
            logger.warning("start_run failed (%s): %s", run_id, exc)

    def finish_run(self, *, run_id: str, outcome: str = "") -> None:
        try:
            with self._lock:
                self._conn.execute(
                    """
                    update monitor_runs
                       set finished_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now'),
                           outcome     = ?
                     where run_id = ?
                    """,
                    (outcome, run_id),
                )
        except Exception as exc:
            logger.warning("finish_run failed (%s): %s", run_id, exc)

    # ------------------------------------------------------------------
    # Per-step write
    # ------------------------------------------------------------------

    def log_step(
        self,
        *,
        run_id: str,
        step_index: int,
        action: Optional[str] = None,
        action_input: Optional[str] = None,
        thought: Optional[str] = None,
        observation: Optional[str] = None,
        tokens: int = 0,
        scores: Optional[dict[str, float]] = None,
        total_score: Optional[float] = None,
        fired: Optional[list[str]] = None,
        failure_type: Optional[str] = None,
        metadata: Optional[dict[str, Any]] = None,
        # ReasonBlocks middleware state (all optional; ``None`` on plain runs)
        injections: Optional[list[str]] = None,
        injection_sources: Optional[list[str]] = None,
        intervention_texts: Optional[list[str]] = None,
        monitors_fired: Optional[list[str]] = None,
    ) -> None:
        scores = scores or {}
        try:
            with self._lock:
                self._conn.execute(
                    """
                    insert into monitor_steps
                      (run_id, step_index, action, action_input, thought, observation,
                       tokens, streak_score, call_count_score, edit_revert_score,
                       test_repeat_score, diversity_score, hedge_score,
                       total_score, fired_monitors,
                       injections, injection_sources, intervention_texts, monitors_fired,
                       failure_type, metadata)
                    values
                      (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    on conflict(run_id, step_index) do update set
                      action             = excluded.action,
                      action_input       = excluded.action_input,
                      thought            = excluded.thought,
                      observation        = excluded.observation,
                      tokens             = excluded.tokens,
                      streak_score       = excluded.streak_score,
                      call_count_score   = excluded.call_count_score,
                      edit_revert_score  = excluded.edit_revert_score,
                      test_repeat_score  = excluded.test_repeat_score,
                      diversity_score    = excluded.diversity_score,
                      hedge_score        = excluded.hedge_score,
                      total_score        = excluded.total_score,
                      fired_monitors     = excluded.fired_monitors,
                      injections         = excluded.injections,
                      injection_sources  = excluded.injection_sources,
                      intervention_texts = excluded.intervention_texts,
                      monitors_fired     = excluded.monitors_fired,
                      failure_type       = excluded.failure_type,
                      metadata           = excluded.metadata
                    """,
                    (
                        run_id, step_index,
                        action, (action_input or "")[:2000],
                        (thought or "")[:4000], (observation or "")[:4000],
                        int(tokens or 0),
                        float(scores.get("streak", 0.0)),
                        float(scores.get("call_count", 0.0)),
                        float(scores.get("edit_revert", 0.0)),
                        float(scores.get("test_repeat", 0.0)),
                        float(scores.get("diversity", 0.0)),
                        float(scores.get("hedge", 0.0)),
                        float(total_score if total_score is not None else 0.0),
                        json.dumps(list(fired or [])),
                        json.dumps(list(injections or [])),
                        json.dumps(list(injection_sources or [])),
                        json.dumps(list(intervention_texts or [])),
                        json.dumps(list(monitors_fired or [])),
                        failure_type,
                        json.dumps(metadata or {}, default=str),
                    ),
                )
        except Exception as exc:
            logger.warning("log_step failed (%s step %d): %s", run_id, step_index, exc)

    # ------------------------------------------------------------------
    # Read helpers (used by the dashboard server)
    # ------------------------------------------------------------------

    def list_runs(self, *, limit: int = 100) -> list[dict[str, Any]]:
        cur = self._conn.execute(
            """
            select r.run_id, r.agent_name, r.task, r.model, r.framework,
                   r.codebase_id, r.started_at, r.finished_at, r.outcome,
                   r.metadata,
                   count(s.id)                 as step_count,
                   coalesce(avg(s.total_score), 0) as avg_score,
                   coalesce(max(s.total_score), 0) as peak_score
              from monitor_runs r
         left join monitor_steps s on s.run_id = r.run_id
          group by r.run_id
          order by r.started_at desc
             limit ?
            """,
            (limit,),
        )
        return [
            {
                "run_id": r[0], "agent_name": r[1], "task": r[2], "model": r[3],
                "framework": r[4], "codebase_id": r[5],
                "started_at": r[6], "finished_at": r[7], "outcome": r[8],
                "metadata": _loads(r[9]),
                "step_count": r[10],
                "avg_score": round(float(r[11]), 4),
                "peak_score": round(float(r[12]), 4),
            }
            for r in cur.fetchall()
        ]

    def get_run(self, run_id: str) -> Optional[dict[str, Any]]:
        cur = self._conn.execute(
            "select run_id, agent_name, task, model, framework, codebase_id, "
            "started_at, finished_at, outcome, metadata from monitor_runs "
            "where run_id = ?",
            (run_id,),
        )
        row = cur.fetchone()
        if not row:
            return None
        return {
            "run_id": row[0], "agent_name": row[1], "task": row[2], "model": row[3],
            "framework": row[4], "codebase_id": row[5],
            "started_at": row[6], "finished_at": row[7], "outcome": row[8],
            "metadata": _loads(row[9]),
        }

    def health_summary(self, *, recent_limit: int = 30) -> dict[str, Any]:
        """Aggregate stats across every run + step in the store.

        Used by the monitor dashboard home page to render an overall
        agent-health overview. All numbers are computed server-side with
        a handful of small queries so the dashboard can stay dumb.
        """
        totals = self._conn.execute(
            """
            select count(distinct r.run_id),
                   count(s.id),
                   coalesce(avg(s.total_score), 0),
                   coalesce(max(s.total_score), 0)
              from monitor_runs r
         left join monitor_steps s on s.run_id = r.run_id
            """
        ).fetchone()
        total_runs, total_steps, avg_score, peak_score = (
            int(totals[0] or 0),
            int(totals[1] or 0),
            float(totals[2] or 0.0),
            float(totals[3] or 0.0),
        )

        success_runs = int(self._conn.execute(
            "select count(*) from monitor_runs where outcome = 'success'"
        ).fetchone()[0] or 0)

        # Run-level distribution: how many runs ever had a step fire anything.
        runs_with_fires = int(self._conn.execute(
            """
            select count(*) from (
              select r.run_id from monitor_runs r
         left join monitor_steps s on s.run_id = r.run_id
              group by r.run_id
              having max(json_array_length(s.fired_monitors)) > 0
            )
            """
        ).fetchone()[0] or 0)

        # Count how many runs stayed below the warn threshold.
        clean_runs = int(self._conn.execute(
            """
            select count(*) from (
              select r.run_id from monitor_runs r
         left join monitor_steps s on s.run_id = r.run_id
              group by r.run_id
              having coalesce(max(s.total_score), 0) < 0.35
            )
            """
        ).fetchone()[0] or 0)
        clean_run_rate = (clean_runs / total_runs) if total_runs else 0.0

        # Fires per monitor (count of steps where each monitor individually fired).
        fires: dict[str, int] = {
            "streak": 0, "call_count": 0, "edit_revert": 0,
            "test_repeat": 0, "diversity": 0, "hedge": 0,
        }
        threshold = 0.6
        counts = self._conn.execute(
            """
            select
              sum(case when streak_score      >= ? then 1 else 0 end),
              sum(case when call_count_score  >= ? then 1 else 0 end),
              sum(case when edit_revert_score >= ? then 1 else 0 end),
              sum(case when test_repeat_score >= ? then 1 else 0 end),
              sum(case when diversity_score   >= ? then 1 else 0 end),
              sum(case when hedge_score       >= ? then 1 else 0 end)
            from monitor_steps
            """,
            (threshold,) * 6,
        ).fetchone()
        if counts:
            fires["streak"]      = int(counts[0] or 0)
            fires["call_count"]  = int(counts[1] or 0)
            fires["edit_revert"] = int(counts[2] or 0)
            fires["test_repeat"] = int(counts[3] or 0)
            fires["diversity"]   = int(counts[4] or 0)
            fires["hedge"]       = int(counts[5] or 0)

        # Step severity buckets.
        sev = self._conn.execute(
            """
            select
              sum(case when total_score < 0.35                       then 1 else 0 end),
              sum(case when total_score >= 0.35 and total_score < 0.6 then 1 else 0 end),
              sum(case when total_score >= 0.6                       then 1 else 0 end)
            from monitor_steps
            """
        ).fetchone() or (0, 0, 0)
        steps_by_severity = {
            "low":    int(sev[0] or 0),
            "warn":   int(sev[1] or 0),
            "danger": int(sev[2] or 0),
        }

        # Per-framework rollup.
        fw_rows = self._conn.execute(
            """
            select coalesce(r.framework, '(none)') as fw,
                   count(distinct r.run_id)       as runs,
                   coalesce(avg(s.total_score), 0) as avg_s,
                   coalesce(max(s.total_score), 0) as peak_s
              from monitor_runs r
         left join monitor_steps s on s.run_id = r.run_id
          group by fw
          order by runs desc
            """
        ).fetchall()
        by_framework: dict[str, dict[str, Any]] = {}
        for fw, runs, avg_s, peak_s in fw_rows:
            by_framework[fw] = {
                "runs": int(runs or 0),
                "avg_score": round(float(avg_s or 0.0), 4),
                "peak_score": round(float(peak_s or 0.0), 4),
            }

        # Recent N runs' peak/avg scores — feeds the trend sparkline.
        recent = self._conn.execute(
            """
            select r.run_id, r.started_at,
                   coalesce(max(s.total_score), 0),
                   coalesce(avg(s.total_score), 0),
                   count(s.id)
              from monitor_runs r
         left join monitor_steps s on s.run_id = r.run_id
          group by r.run_id
          order by r.started_at desc
             limit ?
            """,
            (recent_limit,),
        ).fetchall()
        recent_run_scores = [
            {
                "run_id": r[0],
                "started_at": r[1],
                "peak_score": round(float(r[2] or 0.0), 4),
                "avg_score":  round(float(r[3] or 0.0), 4),
                "step_count": int(r[4] or 0),
            }
            for r in recent
        ]
        # Show oldest -> newest for a left-to-right sparkline.
        recent_run_scores.reverse()

        return {
            "total_runs": total_runs,
            "total_steps": total_steps,
            "success_runs": success_runs,
            "runs_with_fires": runs_with_fires,
            "avg_score":  round(avg_score, 4),
            "peak_score": round(peak_score, 4),
            "clean_run_rate": round(clean_run_rate, 4),
            "fires_by_monitor": fires,
            "steps_by_monitor_severity": steps_by_severity,
            "by_framework": by_framework,
            "recent_run_scores": recent_run_scores,
        }

    def get_steps(self, run_id: str) -> list[dict[str, Any]]:
        cur = self._conn.execute(
            """
            select step_index, occurred_at, action, action_input, thought,
                   observation, tokens,
                   streak_score, call_count_score, edit_revert_score,
                   test_repeat_score, diversity_score, hedge_score,
                   total_score, fired_monitors,
                   injections, injection_sources, intervention_texts, monitors_fired,
                   failure_type, metadata
              from monitor_steps
             where run_id = ?
          order by step_index
            """,
            (run_id,),
        )
        return [
            {
                "step_index": r[0], "occurred_at": r[1],
                "action": r[2], "action_input": r[3],
                "thought": r[4], "observation": r[5],
                "tokens": r[6],
                "scores": {
                    "streak":      float(r[7]),
                    "call_count":  float(r[8]),
                    "edit_revert": float(r[9]),
                    "test_repeat": float(r[10]),
                    "diversity":   float(r[11]),
                    "hedge":       float(r[12]),
                },
                "total_score": float(r[13]),
                "fired": _loads(r[14]) or [],
                "injections":         _loads(r[15]) or [],
                "injection_sources":  _loads(r[16]) or [],
                "intervention_texts": _loads(r[17]) or [],
                "monitors_fired":     _loads(r[18]) or [],
                "failure_type": r[19],
                "metadata": _loads(r[20]),
            }
            for r in cur.fetchall()
        ]

    def close(self) -> None:
        with self._lock:
            try:
                self._conn.close()
            except Exception:
                pass


def _loads(raw: Optional[str]) -> Any:
    if raw is None:
        return None
    try:
        return json.loads(raw)
    except Exception:
        return raw
