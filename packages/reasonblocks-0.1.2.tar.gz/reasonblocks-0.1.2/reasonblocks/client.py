from __future__ import annotations

import math
import re
from typing import Any, Optional

from reasonblocks.api import ReasonBlocksAPI
from reasonblocks.fsm import DifficultyFSM
from reasonblocks.injections import create_injections
from reasonblocks.middleware import ReasonBlocksMiddleware
from reasonblocks.monitor_client import MonitorClient
from reasonblocks.monitors import create_monitors
from reasonblocks.state import TraceStateManager
from reasonblocks.streaming_emitter import StreamingEmitter
from reasonblocks.types import FSMState

_HEDGING_WORDS = frozenset({
    "maybe", "perhaps", "possibly", "might", "could",
    "not sure", "uncertain", "i think", "probably",
    "actually", "wait", "hmm", "reconsider",
})

_ERROR_WORDS = frozenset({
    "error", "exception", "traceback", "fail", "failed",
    "crash", "bug", "broken", "issue", "problem",
})

_ENTITY_RE = re.compile(
    r"(?:[A-Za-z]:)?(?:[/\\][\w.\-]+){2,}"
    r"|\b[a-zA-Z_]\w*(?:\.\w+)+\b"
    r"|[\"'`]([^\"'`]{3,})[\"'`]"
)


class ReasonBlocks:
    """Main SDK entry point. One import, one init, one middleware addition."""

    def __init__(
        self,
        api_key: str,
        *,
        base_url: Optional[str] = None,
        token_budget: Optional[int] = None,
        monitor_names: Optional[list[str]] = None,
        fsm_thresholds: Optional[dict[str, float]] = None,
        model_routing: Optional[dict[str, str]] = None,
        e_traces_enabled: bool = True,
        customer_id: Optional[str] = None,
        live_streaming_enabled: bool = True,
        task_profile: str = "coding",
    ) -> None:
        self._api_key = api_key
        self._base_url = base_url
        self._token_budget = token_budget
        self._monitor_names = monitor_names
        self._fsm_thresholds = fsm_thresholds or {}
        self._e_traces_enabled = e_traces_enabled
        self._customer_id = customer_id
        # Live streaming ships a per-step telemetry event to rb-api as
        # each agent step completes. On by default so the dashboard
        # reflects in-progress runs. Disable for agents that want a
        # purely local / offline mode.
        self._live_streaming_enabled = live_streaming_enabled
        # ``task_profile`` picks the monitor weight vector on the server.
        # See rb-api/app/services/monitor_suite.WEIGHTS_BY_PROFILE for the
        # built-in profiles (``coding`` default; ``pr_review`` drops
        # edit_revert + test_repeat to 0 and redistributes).
        self._task_profile = task_profile

        # model_routing maps FSMState names ("FAST", "SLOW") to model identifiers
        self._model_routing: dict[FSMState, str] = {}
        if model_routing:
            for state_name, model_id in model_routing.items():
                self._model_routing[FSMState(state_name)] = model_id

    def middleware(
        self,
        *,
        run_id: Optional[str] = None,
        agent_name: str = "",
        task: str = "",
        framework: str = "langchain",
        model: str = "",
        codebase_id: str = "",
        org_id: str = "default",
        project_id: str = "default",
        metadata: Optional[dict[str, Any]] = None,
    ) -> ReasonBlocksMiddleware:
        """Create a fresh middleware instance for one agent run.

        Optional parameters set identifying metadata for the live
        telemetry stream -- they land on the ``monitor_runs`` row and
        surface in the dashboard. All default to empty strings if the
        caller doesn't care.

        ``org_id`` and ``project_id`` are the multi-tenant scope; both
        default to ``"default"`` so callers that don't know about
        multi-tenancy land in the seeded default org/project. When the
        api_key is a per-customer ``rb_live_*`` key bound to an org,
        rb-api overrides these with the key's authoritative scope --
        most callers can just leave them at the defaults.

        ``metadata`` is a free-form dict attached to the run row and
        surfaced as JSON in the dashboard. Use it for whatever
        identifying tags don't fit the named fields above (PR number,
        experiment variant, A/B group, ...).
        """
        api_kwargs: dict[str, str] = {"api_key": self._api_key}
        if self._base_url:
            api_kwargs["base_url"] = self._base_url
        api = ReasonBlocksAPI(**api_kwargs)

        fsm = DifficultyFSM(**self._fsm_thresholds)
        state_manager = TraceStateManager(token_budget=self._token_budget)
        monitors = create_monitors(self._monitor_names)
        injections = create_injections(
            api, monitors,
            e_traces_enabled=self._e_traces_enabled,
            task_profile=self._task_profile,
        )

        resolved_run_id = run_id or state_manager.trace_id

        emitter: Optional[StreamingEmitter] = None
        if self._live_streaming_enabled:
            monitor_client = MonitorClient(
                api_key=self._api_key,
                **({"base_url": self._base_url} if self._base_url else {}),
            )
            emitter = StreamingEmitter(monitor_client)

        run_metadata: dict[str, Any] = {
            "agent_name": agent_name,
            "task": task,
            "framework": framework,
            "model": model,
            "codebase_id": codebase_id,
            "org_id": org_id,
            "project_id": project_id,
            "task_profile": self._task_profile,
        }
        # Caller-provided tags ride alongside the named fields. Anything
        # not consumed by emit_run_start's pop()'d slots ends up in the
        # ``metadata`` JSON column on monitor_runs.
        if metadata:
            run_metadata.update(metadata)

        return ReasonBlocksMiddleware(
            score_fn=self.score_step,
            fsm=fsm,
            state_manager=state_manager,
            injections=injections,
            model_routing=self._model_routing or None,
            emitter=emitter,
            run_id=resolved_run_id,
            run_metadata=run_metadata,
        )

    def openai_hooks(
        self,
        *,
        run_id: Optional[str] = None,
        agent_name: str = "",
        task: str = "",
        framework: str = "openai-agents",
        model: str = "",
        codebase_id: str = "",
        org_id: str = "default",
        project_id: str = "default",
        metadata: Optional[dict[str, Any]] = None,
    ) -> Any:
        """Build a ``RunHooks`` adapter for the openai-agents SDK.

        Mirrors :meth:`middleware` but for the ``openai-agents``
        package's ``Runner.run(agent, input, hooks=...)`` shape.
        Drop-in replacement -- same telemetry, same dashboard rows.

        Example::

            from agents import Agent, Runner
            rb = ReasonBlocks(api_key="rb_live_...")
            hooks = rb.openai_hooks(
                run_id="my-run-1",
                agent_name="reviewer",
                task="review PR #42",
            )
            agent = Agent(name="reviewer", instructions="...", tools=[...])

            with hooks:
                result = Runner.run_sync(agent, input="...", hooks=hooks)

        Like ``rb.middleware()``, the returned object is a context
        manager (sync + async). The context manager flushes the
        emitter on exit and records the failure outcome if an
        exception escapes.
        """
        import uuid as _uuid
        from reasonblocks.integrations.openai_agents import build_hooks

        emitter: Optional[StreamingEmitter] = None
        if self._live_streaming_enabled:
            monitor_client = MonitorClient(
                api_key=self._api_key,
                **({"base_url": self._base_url} if self._base_url else {}),
            )
            emitter = StreamingEmitter(monitor_client)

        run_metadata: dict[str, Any] = {
            "agent_name": agent_name,
            "task": task,
            "framework": framework,
            "model": model,
            "codebase_id": codebase_id,
            "org_id": org_id,
            "project_id": project_id,
            "task_profile": self._task_profile,
        }
        if metadata:
            run_metadata.update(metadata)

        return build_hooks(
            emitter=emitter,
            run_id=run_id or _uuid.uuid4().hex,
            run_metadata=run_metadata,
        )

    @staticmethod
    def score_step(text: str) -> float:
        """Heuristic difficulty scoring (0-1). Replaced by Pilot model later."""
        if not text:
            return 0.5

        words = text.lower().split()
        word_count = max(len(words), 1)

        # 1. Hedging density
        hedge_count = sum(1 for w in _HEDGING_WORDS if w in text.lower())
        hedge_score = min(hedge_count / (word_count * 0.05 + 1), 1.0)

        # 2. Length signal -- very long steps tend to indicate harder reasoning
        length_score = min(word_count / 500, 1.0)

        # 3. Error/exception language
        error_count = sum(1 for w in _ERROR_WORDS if w in text.lower())
        error_score = min(error_count / 3, 1.0)

        # 4. Entity density -- more entities = more complex
        entities = _ENTITY_RE.findall(text)
        entity_score = min(len(entities) / 10, 1.0)

        # Weighted combination
        raw = (
            0.30 * hedge_score
            + 0.25 * length_score
            + 0.25 * error_score
            + 0.20 * entity_score
        )

        # Sigmoid-ish squash to keep output in a usable range
        return 1.0 / (1.0 + math.exp(-6 * (raw - 0.5)))
