from __future__ import annotations

from reasonblocks.api import ReasonBlocksAPI
from reasonblocks.injections.base import BaseInjection
from reasonblocks.injections.e1 import E1Injection
from reasonblocks.injections.e2 import E2Injection
from reasonblocks.injections.e3 import E3Injection
from reasonblocks.injections.monitor_steering import MonitorSteeringInjection
from reasonblocks.monitors.base import BaseMonitor


def create_injections(
    api: ReasonBlocksAPI,
    monitors: list[BaseMonitor] | None = None,
    e_traces_enabled: bool = True,
    task_profile: str = "coding",
) -> list[BaseInjection]:
    """Build the standard injection pipeline.

    ``task_profile`` is forwarded to :class:`MonitorSteeringInjection` so
    the server applies the right weight vector when deciding whether to
    fire. See ``rb-api/app/services/monitor_suite.WEIGHTS_BY_PROFILE``.

    The ``monitors`` argument is accepted for API stability — the built-in
    monitor suite runs server-side; custom local monitors here have no
    effect. Register them via your own injection if you need that.
    """

    del monitors  # remote monitor system ignores any local list

    injections: list[BaseInjection] = []

    if e_traces_enabled:
        injections.append(E3Injection(api))
        injections.append(E1Injection(api))
        injections.append(E2Injection(api))

    injections.append(MonitorSteeringInjection(api, task_profile=task_profile))
    return injections
