from __future__ import annotations

import logging
from typing import Optional

from reasonblocks.api import ReasonBlocksAPI
from reasonblocks.injections.base import BaseInjection
from reasonblocks.types import PendingInjection, TraceState

logger = logging.getLogger("reasonblocks.injections.e2")


class E2Injection(BaseInjection):
    """Commons-pattern injection keyed on monitor state description.

    The query string should describe the current failure mode (built from
    recent thoughts). The rb-api enforces the tier gate (0.7) and any
    per-pattern ``gate_threshold``. ``failure_type`` narrows metadata when
    the caller has a monitor-derived classification.
    """

    def __init__(
        self,
        api: ReasonBlocksAPI,
        top_k: int = 2,
        max_calls: int = 1,
    ) -> None:
        self._api = api
        self._top_k = top_k
        self._max_calls = max_calls
        self._call_count = 0
        self._failure_type: Optional[str] = None

    def set_failure_type(self, failure_type: Optional[str]) -> None:
        """Upstream hook for monitor-derived failure classification."""
        self._failure_type = failure_type

    def retrieve(self, state: TraceState) -> list[PendingInjection]:
        if self._call_count >= self._max_calls:
            return []

        context = _build_context(state)
        if not context:
            return []

        self._call_count += 1
        try:
            traces = self._api.retrieve_traces(
                context=context,
                level="e2",
                top_k=self._top_k,
                failure_type=self._failure_type,
            )
            return [
                PendingInjection(
                    source="E2Injection",
                    tier="e2",
                    fields=t.fields,
                )
                for t in traces
                if t.fields
            ]
        except Exception:
            logger.warning("E2 injection failed", exc_info=True)
            return []


def _build_context(state: TraceState) -> str:
    recent = state.steps[-5:]
    return "\n".join(s.thought for s in recent if s.thought)
