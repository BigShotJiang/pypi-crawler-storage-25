from __future__ import annotations

import logging
from typing import Optional

from reasonblocks.api import ReasonBlocksAPI
from reasonblocks.injections.base import BaseInjection
from reasonblocks.types import PendingInjection, TraceState

logger = logging.getLogger("reasonblocks.injections.e1")


class E1Injection(BaseInjection):
    """Instance-level pattern injection -- customer-scoped, gated top-1.

    Query vector is built from the task context. The rb-api enforces the
    tier gate (0.8) and any per-pattern ``gate_threshold``. This class
    simply caps the number of firings per run.
    """

    def __init__(
        self,
        api: ReasonBlocksAPI,
        max_calls: int = 1,
        customer_id: Optional[str] = None,
    ) -> None:
        self._api = api
        self._max_calls = max_calls
        self._customer_id = customer_id
        self._call_count = 0

    def retrieve(self, state: TraceState) -> list[PendingInjection]:
        if self._call_count >= self._max_calls:
            return []

        context = _build_context(state)
        if not context:
            return []

        self._call_count += 1
        try:
            traces = self._api.retrieve_traces(
                context=context,
                level="e1",
                top_k=1,
                customer_id=self._customer_id,
            )
            return [
                PendingInjection(
                    source="E1Injection",
                    tier="e1",
                    fields=t.fields,
                )
                for t in traces
                if t.fields
            ]
        except Exception:
            logger.warning("E1 injection failed", exc_info=True)
            return []


def _build_context(state: TraceState) -> str:
    recent = state.steps[-3:]
    return "\n".join(s.thought for s in recent if s.thought)
