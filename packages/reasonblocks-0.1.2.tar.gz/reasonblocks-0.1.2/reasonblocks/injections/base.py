from __future__ import annotations

import abc

from reasonblocks.types import PendingInjection, TraceState


class BaseInjection(abc.ABC):
    """Abstract base for all injection modules.

    Injections return ``PendingInjection`` objects, which the middleware
    assembles into the system message. Raw pattern injections carry
    ``(tier, fields)`` so rendering can be deferred to ``wrap_model_call``
    once the final post-routing model is known. Pre-formatted injections
    (e.g. monitor steering) set ``text`` directly.
    """

    @abc.abstractmethod
    def retrieve(self, state: TraceState) -> list[PendingInjection]:
        ...
