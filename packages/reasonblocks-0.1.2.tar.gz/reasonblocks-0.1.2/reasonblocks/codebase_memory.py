"""Persistent per-codebase memory — the ReasonBlocks "findings store".

``CodebaseMemory`` is a thin client around the rb-api ``/findings/...``
endpoints. It lets an agent store observations about a repo (bugs found,
file summaries, architectural notes) and recall them on future runs via
semantic search against a per-codebase Qdrant collection.

The contract is intentionally small so this works equally well from a
LangChain ReAct loop, the Anthropic ``messages`` tool-use API, or the
Claude Agent SDK. See ``reasonblocks.integrations.langchain_tools`` and
``reasonblocks.integrations.claude_tools`` for framework wrappers that
turn these methods into tools.

Typical usage::

    memory = CodebaseMemory(
        codebase_id="pydantic_pydantic",
        api_key="rb_live_...",   # paste from dashboard -> API Keys
    )
    # base_url defaults to https://rb-api.reasonblocks.com -- override
    # only for local dev (REASONBLOCKS_BASE_URL=http://localhost:9000).

    # During a review
    results = memory.recall("validator error handling", top_k=5)
    for r in results:
        print(r["file_path"], r["score"], r["content"])

    # After the review
    memory.store(
        content="BaseModel.validate raises ValidationError on extra=forbid",
        file_path="pydantic/main.py",
        finding_type="behavior",
    )

The client never raises on transport errors — it returns empty lists /
``None`` / ``0`` so a missing rb-api doesn't break the agent loop.
"""

from __future__ import annotations

import logging
from typing import Any, Optional

import httpx

from reasonblocks._settings import DEFAULT_BASE_URL, DEFAULT_TIMEOUT

logger = logging.getLogger("reasonblocks.codebase_memory")


class CodebaseMemory:
    """Client for the per-codebase findings store."""

    def __init__(
        self,
        codebase_id: str,
        *,
        api_key: str,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = DEFAULT_TIMEOUT,
    ) -> None:
        if not codebase_id:
            raise ValueError("codebase_id is required")
        self.codebase_id = codebase_id
        self._base_url = base_url.rstrip("/")
        self._headers = {"Authorization": f"Bearer {api_key}"}
        self._timeout = timeout
        # Persistent client keeps TCP connections warm across calls --
        # matters when an agent stores/recalls many findings back-to-back.
        self._client = httpx.Client(headers=self._headers, timeout=timeout)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def store(
        self,
        content: str,
        *,
        file_path: str = "",
        finding_type: str = "note",
        metadata: Optional[dict[str, Any]] = None,
    ) -> Optional[str]:
        """Persist a single finding. Returns the finding id, or ``None`` on
        transport error."""
        if not content or not content.strip():
            return None
        payload: dict[str, Any] = {
            "content": content[:8000],
            "file_path": file_path[:512] if file_path else "",
            "finding_type": finding_type[:64] if finding_type else "note",
        }
        if metadata is not None:
            payload["metadata"] = metadata
        try:
            resp = self._client.post(
                f"{self._base_url}/findings/{self.codebase_id}",
                json=payload,
            )
            resp.raise_for_status()
            return resp.json().get("finding_id")
        except Exception as exc:
            logger.warning("store failed for %s: %s", self.codebase_id, exc)
            return None

    def recall(
        self,
        query: str,
        *,
        top_k: int = 5,
        score_threshold: float = 0.25,
    ) -> list[dict[str, Any]]:
        """Semantic recall. Returns a list of ``{content, file_path,
        finding_type, score, ...}`` dicts, ordered by descending score."""
        if not query or not query.strip():
            return []
        try:
            resp = self._client.post(
                f"{self._base_url}/findings/{self.codebase_id}/search",
                json={
                    "query": query[:2000],
                    "top_k": top_k,
                    "score_threshold": score_threshold,
                },
            )
            resp.raise_for_status()
            return list(resp.json().get("results", []))
        except Exception as exc:
            logger.warning("recall failed for %s: %s", self.codebase_id, exc)
            return []

    def list_all(self) -> list[dict[str, Any]]:
        """Return every finding currently stored for this codebase."""
        try:
            resp = self._client.get(
                f"{self._base_url}/findings/{self.codebase_id}",
            )
            resp.raise_for_status()
            return list(resp.json().get("findings", []))
        except Exception as exc:
            logger.warning("list_all failed for %s: %s", self.codebase_id, exc)
            return []

    def invalidate(self, file_paths: list[str]) -> int:
        """Drop cached findings whose ``file_path`` matches any of
        ``file_paths``. Returns the number deleted.

        Pair this with :class:`~reasonblocks.import_graph.ImportGraph` to
        invalidate a file's blast radius before re-reviewing it -- keeps
        the cache honest when upstream modules change."""
        if not file_paths:
            return 0
        try:
            resp = self._client.post(
                f"{self._base_url}/findings/{self.codebase_id}/invalidate",
                json={"file_paths": list(file_paths)},
            )
            resp.raise_for_status()
            return int(resp.json().get("invalidated", 0))
        except Exception as exc:
            logger.warning("invalidate failed for %s: %s", self.codebase_id, exc)
            return 0

    def clear(self) -> bool:
        """Drop the entire Qdrant collection for this codebase. Irreversible."""
        try:
            resp = self._client.delete(
                f"{self._base_url}/findings/{self.codebase_id}",
            )
            resp.raise_for_status()
            return resp.json().get("status") == "cleared"
        except Exception as exc:
            logger.warning("clear failed for %s: %s", self.codebase_id, exc)
            return False

    def close(self) -> None:
        """Release the underlying HTTP client."""
        self._client.close()

    # ------------------------------------------------------------------
    # Ergonomic helpers
    # ------------------------------------------------------------------

    def store_many(self, findings: list[dict[str, Any]]) -> int:
        """Convenience: store a batch of findings. Each dict must have at
        least ``content``; ``file_path``, ``finding_type``, ``metadata``
        are optional. Returns count stored."""
        stored = 0
        for f in findings:
            if not isinstance(f, dict) or not f.get("content"):
                continue
            fid = self.store(
                content=f["content"],
                file_path=f.get("file_path", ""),
                finding_type=f.get("finding_type", "note"),
                metadata=f.get("metadata"),
            )
            if fid is not None:
                stored += 1
        return stored

    def coverage_for(self, file_paths: list[str]) -> float:
        """Fraction of ``file_paths`` that have at least one finding in memory.

        Used to decide whether the cache is rich enough to answer a query or
        whether the agent needs extra tooling (e.g. an impact-analysis graph)
        to compensate. A soft match is applied so ``pydantic/main.py`` in the
        store covers a query for ``main.py``.
        """
        if not file_paths:
            return 1.0
        findings = self.list_all()
        cached = {
            (f.get("file_path") or "").strip() for f in findings
            if (f.get("file_path") or "").strip()
        }
        if not cached:
            return 0.0

        def _covered(fp: str) -> bool:
            if not fp:
                return False
            if fp in cached:
                return True
            # Soft match: any cached path ending with the target suffix or
            # vice versa. Cheap, avoids false negatives on bare filenames.
            for cp in cached:
                if cp.endswith("/" + fp) or fp.endswith("/" + cp):
                    return True
            return False

        return sum(1 for fp in file_paths if _covered(fp)) / len(file_paths)

    def format_recall(
        self,
        query: str,
        *,
        top_k: int = 5,
        score_threshold: float = 0.25,
        max_len: int = 300,
    ) -> str:
        """Recall + render a human-readable digest. Handy for building the
        string a tool returns to an LLM without reimplementing the
        formatter in every agent."""
        results = self.recall(query, top_k=top_k, score_threshold=score_threshold)
        if not results:
            return "(no relevant findings in cache yet)"
        lines = [f"Found {len(results)} relevant prior findings:"]
        for r in results:
            fp = r.get("file_path") or "?"
            score = r.get("score", 0.0)
            ftype = r.get("finding_type", "?")
            content = (r.get("content") or "")[:max_len]
            lines.append("")
            lines.append(f"--- [{ftype}] {fp}  (relevance {score:.2f}) ---")
            lines.append(content)
        return "\n".join(lines)
