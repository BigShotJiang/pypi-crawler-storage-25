"""Monitor base class.

The SDK no longer ships per-monitor implementations. All monitor logic
(streak / call_count / edit_revert / test_repeat / diversity / hedge),
scoring weights, gate thresholds, and FALLBACK_E2 wording live server-side
in rb-api and are reached via a single ``/monitors/evaluate`` call. This
class is kept as a marker so existing imports (and any user-supplied
custom monitors) still resolve.
"""

from __future__ import annotations

import abc
from typing import Optional

from reasonblocks.types import StepRecord, TraceState


class BaseMonitor(abc.ABC):
    """Abstract base for monitors. Custom monitors are still supported but
    the built-in monitor suite runs on the rb-api server."""

    @abc.abstractmethod
    def evaluate(
        self,
        state: TraceState,
        current_step: StepRecord,
    ) -> Optional[str]:
        """Return a steering string if intervention is needed, else None."""
