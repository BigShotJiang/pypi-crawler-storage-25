"""Pure-Python monitor suite for mid-run agent health tracking.

Six heuristics, each returning a score in ``[0, 1]`` where 1 = maximum
badness. A weighted aggregator combines them into a single health score
the dashboard renders directly.

Weights (as shipped)::

    streak        0.35   # same action called in a row
    call_count    0.15   # total tool-call budget consumed
    edit_revert   0.15   # thrashing -- edits that undo each other
    test_repeat   0.15   # same test failure signature repeating
    diversity     0.10   # collapsed tool exploration
    hedge         0.10   # rising hedging / retraction density

Every function takes a list of step dicts shaped like::

    {
        "step_index": int,
        "action": Optional[str],      # the tool name, if any
        "action_input": Optional[str], # raw input sent to the tool
        "thought": Optional[str],      # the model's text for this turn
        "observation": Optional[str],  # the tool result, if any
        "is_error": Optional[bool],    # observation-level error flag
    }

Missing keys are tolerated -- monitors return 0.0 when they don't have
enough signal to judge.
"""

from __future__ import annotations

import re
from typing import Any, Optional

__all__ = [
    "DEFAULT_WEIGHTS",
    "DEFAULT_FIRE_THRESHOLD",
    "score_streak",
    "score_call_count",
    "score_edit_revert",
    "score_test_repeat",
    "score_diversity",
    "score_hedge",
    "evaluate_all",
]


DEFAULT_WEIGHTS: dict[str, float] = {
    "streak":      0.35,
    "call_count":  0.15,
    "edit_revert": 0.15,
    "test_repeat": 0.15,
    "diversity":   0.10,
    "hedge":       0.10,
}

# Per-monitor threshold above which a monitor is considered "fired".
DEFAULT_FIRE_THRESHOLD = 0.6

# Edit-like tool names across the frameworks we care about. Extend here
# if your agent uses custom names.
_EDIT_TOOLS = frozenset({
    "edit", "write", "str_replace", "str_replace_editor", "patch",
    "apply_patch", "create_file", "overwrite",
})

# Test-like tool names or observation triggers that imply we just ran
# a test or command that produced pass/fail output.
_TEST_HINTS = frozenset({"pytest", "test", "run_tests", "npm test", "cargo test"})

_HEDGE_WORDS = (
    "maybe", "perhaps", "possibly", "might", "could", "not sure",
    "uncertain", "i think", "probably", "actually", "wait", "hmm",
    "reconsider", "let me think", "on second thought",
)

_RETRACTION_PATTERNS = (
    re.compile(r"\b(?:the\s+)?(?:bug|issue|problem|fix)\s+is\s+(?:not|actually)\b", re.I),
    re.compile(r"\bi\s+was\s+wrong\b", re.I),
    re.compile(r"\bnever\s*mind\b", re.I),
    re.compile(r"\bdisregard\s+(?:that|my\s+last)\b", re.I),
)

# Regexes used to strip volatile junk out of error messages so the same
# underlying failure compares equal across reruns.
_NORMALIZERS = (
    re.compile(r"(?:/tmp/|C:\\Users\\|/var/folders/)\S*"),       # tmp paths
    re.compile(r"\b[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}\b", re.I),  # UUIDs
    re.compile(r"\b0x[0-9a-f]+\b", re.I),                         # hex memory addrs
    re.compile(r"\bpid[=: ]\d+\b", re.I),                         # PIDs
    re.compile(r"\b\d{4}-\d{2}-\d{2}[ T]\d{2}:\d{2}:\d{2}\S*"),  # timestamps
    re.compile(r"\b\d{10,}\b"),                                     # big numbers (epoch, addresses)
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _action_of(step: dict[str, Any]) -> Optional[str]:
    return step.get("action") or (step.get("tool_calls") or [None])[0]


def _text(s: Any) -> str:
    return s if isinstance(s, str) else ""


def _looks_like_error(obs: str) -> bool:
    low = obs.lower()
    return any(t in low for t in (
        "error", "exception", "traceback", "failed", "not found",
        "assertion", "invalid",
    ))


def _normalize_error(obs: str) -> str:
    """Strip volatile fragments so repeated failures compare equal."""
    clean = obs
    for pat in _NORMALIZERS:
        clean = pat.sub("∎", clean)
    # Keep only the first ~200 chars of normalized text — that's where
    # the signature lives; stacktraces below that vary line-by-line.
    return clean.strip()[:200]


def _count_hedges(text: str) -> int:
    low = text.lower()
    return sum(low.count(w) for w in _HEDGE_WORDS)


def _has_retraction(text: str) -> bool:
    return any(p.search(text) for p in _RETRACTION_PATTERNS)


# ---------------------------------------------------------------------------
# Individual monitors
# ---------------------------------------------------------------------------

def score_streak(steps: list[dict], *, cap: int = 5) -> float:
    """Consecutive identical actions at the tail of the trace. 1.0 at ``cap``
    repeats, 0.0 if the last two differ. Ignores steps with no action."""
    last = None
    run = 0
    for step in reversed(steps):
        act = _action_of(step)
        if not act:
            continue
        if last is None:
            last = act
            run = 1
            continue
        if act == last:
            run += 1
        else:
            break
    if run <= 1:
        return 0.0
    return min(run / cap, 1.0)


def score_call_count(steps: list[dict], *, budget: int = 20) -> float:
    """Tool-call budget consumption. 0.0 at zero calls, 1.0 at ``budget``."""
    used = sum(1 for s in steps if _action_of(s))
    return min(used / budget, 1.0)


def score_edit_revert(steps: list[dict]) -> float:
    """Thrashing detector: content-similar reverts, or edit-fail-edit on the
    same file.

    Returns 1.0 on a clear revert or two fail-edit cycles on one path,
    falling to 0.0 when the edit history is clean.
    """
    edits: list[tuple[int, str, str]] = []  # (index, path, content)
    error_after: set[int] = set()
    for i, step in enumerate(steps):
        act = (_action_of(step) or "").lower()
        if act in _EDIT_TOOLS:
            inp = _text(step.get("action_input"))
            # Crude path extraction: first token that looks like a path.
            path_m = re.search(r"[\w./\\-]+\.[a-zA-Z]{1,5}", inp)
            path = path_m.group(0) if path_m else ""
            edits.append((i, path, inp))
        # An observation with an error, right after an edit, counts as a
        # broken cycle.
        if step.get("is_error") or _looks_like_error(_text(step.get("observation"))):
            # mark the most recent edit, if there is one
            if edits:
                error_after.add(edits[-1][0])

    if len(edits) < 2:
        return 0.0

    # (a) Revert: last edit's content is closer to the one BEFORE the
    # previous edit than to the previous edit itself.
    revert = 0.0
    if len(edits) >= 3:
        a = edits[-3][2]
        b = edits[-2][2]
        c = edits[-1][2]
        if _char_overlap(c, a) > _char_overlap(c, b) + 0.10:
            revert = 1.0

    # (b) Edit-fail-edit cycles on the same path.
    cycles_by_path: dict[str, int] = {}
    for i, (idx, path, _) in enumerate(edits[:-1]):
        if not path:
            continue
        if idx in error_after and edits[i + 1][1] == path:
            cycles_by_path[path] = cycles_by_path.get(path, 0) + 1
    cycle_score = min(max(cycles_by_path.values(), default=0) / 2, 1.0)

    return max(revert, cycle_score)


def score_test_repeat(steps: list[dict]) -> float:
    """Same test-failure signature seen ≥2 times in a row → 1.0."""
    sigs: list[str] = []
    for step in steps:
        obs = _text(step.get("observation"))
        act = (_action_of(step) or "").lower()
        is_test = (
            any(t in act for t in _TEST_HINTS)
            or "test" in obs.lower()[:60]
            or any(kw in obs.lower() for kw in ("assertionerror", "failed ", "failures="))
        )
        if is_test and (_looks_like_error(obs) or step.get("is_error")):
            sigs.append(_normalize_error(obs))

    # Collapse consecutive identical signatures.
    if len(sigs) < 2:
        return 0.0
    consecutive = 1
    max_streak = 1
    for i in range(1, len(sigs)):
        if sigs[i] and sigs[i] == sigs[i - 1]:
            consecutive += 1
            max_streak = max(max_streak, consecutive)
        else:
            consecutive = 1
    if max_streak < 2:
        return 0.0
    # 2 repeats = 1.0; already maxed out.
    return 1.0


def score_diversity(steps: list[dict], *, window: int = 5, min_total: int = 8) -> float:
    """Collapsed exploration: last ``window`` calls use ≤2 distinct tools
    AND the run has at least ``min_total`` calls AND the pattern isn't a
    healthy alternation (``a-b-a-b-a``)."""
    actions = [a for a in (_action_of(s) for s in steps) if a]
    if len(actions) < min_total:
        return 0.0
    tail = actions[-window:]
    if len(tail) < window:
        return 0.0
    distinct = len(set(tail))
    if distinct > 2:
        return 0.0
    # Healthy alternating a-b-a-b-a: skip.
    if distinct == 2 and _is_alternating(tail):
        return 0.0
    if distinct == 1:
        return 1.0
    # Two tools, non-alternating: 0.7.
    return 0.7


def score_hedge(steps: list[dict]) -> float:
    """Hedge-density rising >2× between early and late halves, OR any
    explicit retraction phrase anywhere in the trace."""
    thoughts = [_text(s.get("thought")) for s in steps]
    thoughts = [t for t in thoughts if t]
    if not thoughts:
        return 0.0

    if any(_has_retraction(t) for t in thoughts):
        return 1.0

    if len(thoughts) < 4:
        # Not enough history to compute a ratio; fall back to raw density.
        total_hedges = sum(_count_hedges(t) for t in thoughts)
        total_words = max(sum(len(t.split()) for t in thoughts), 1)
        return min(total_hedges / (total_words * 0.05 + 1), 1.0)

    mid = len(thoughts) // 2
    early = thoughts[:mid]
    late = thoughts[mid:]

    def _density(ts: list[str]) -> float:
        hedges = sum(_count_hedges(t) for t in ts)
        words = max(sum(len(t.split()) for t in ts), 1)
        return hedges / words

    d_early = _density(early)
    d_late = _density(late)
    if d_early == 0:
        # No early hedging baseline; normalize by late raw density.
        return min(d_late / 0.05, 1.0) if d_late > 0 else 0.0
    ratio = d_late / d_early
    if ratio <= 2:
        return 0.0
    # Ratio 2 -> 0.5, ratio 4 -> 1.0
    return min((ratio - 1) / 3, 1.0)


# ---------------------------------------------------------------------------
# Aggregation
# ---------------------------------------------------------------------------

def evaluate_all(
    steps: list[dict],
    *,
    weights: Optional[dict[str, float]] = None,
    fire_threshold: float = DEFAULT_FIRE_THRESHOLD,
) -> dict[str, Any]:
    """Run every monitor on ``steps`` and return the full score bundle.

    Returns::

        {
            "scores": {
                "streak": 0.x, "call_count": 0.x, "edit_revert": 0.x,
                "test_repeat": 0.x, "diversity": 0.x, "hedge": 0.x,
            },
            "total": 0.x,       # weighted sum in [0, 1]
            "fired": [names],    # monitors >= fire_threshold
            "weights": {...},    # weights actually used
        }
    """
    w = dict(DEFAULT_WEIGHTS)
    if weights:
        w.update(weights)

    scores = {
        "streak":       score_streak(steps),
        "call_count":   score_call_count(steps),
        "edit_revert":  score_edit_revert(steps),
        "test_repeat":  score_test_repeat(steps),
        "diversity":    score_diversity(steps),
        "hedge":        score_hedge(steps),
    }
    total = sum(w.get(k, 0.0) * v for k, v in scores.items())
    fired = [k for k, v in scores.items() if v >= fire_threshold]

    return {
        "scores": scores,
        "total": round(total, 4),
        "fired": fired,
        "weights": w,
    }


# ---------------------------------------------------------------------------
# Low-level helpers
# ---------------------------------------------------------------------------

def _char_overlap(a: str, b: str) -> float:
    """Coarse similarity: char-trigram Jaccard. Cheap and language-agnostic."""
    if not a or not b:
        return 0.0
    tri = lambda s: {s[i:i + 3] for i in range(len(s) - 2)}
    A, B = tri(a), tri(b)
    if not A or not B:
        return 0.0
    return len(A & B) / len(A | B)


def _is_alternating(seq: list[str]) -> bool:
    """True if ``seq`` looks like a-b-a-b-a (length ≥ 3, two tools alternating)."""
    if len(seq) < 3:
        return False
    a, b = seq[0], seq[1]
    if a == b:
        return False
    for i, item in enumerate(seq):
        expected = a if i % 2 == 0 else b
        if item != expected:
            return False
    return True
