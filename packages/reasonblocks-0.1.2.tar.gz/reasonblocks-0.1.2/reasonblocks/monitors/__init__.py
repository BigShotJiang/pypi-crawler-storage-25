"""Monitor registry — server-side evaluation only.

The built-in monitor suite (streak, call_count, edit_revert, test_repeat,
diversity, hedge) runs on the rb-api server. ``create_monitors`` is kept
for API-stability with older SDK callers but returns an empty list — the
remote ``MonitorSteeringInjection`` does not consume local monitor objects.
"""

from __future__ import annotations

from typing import Optional

from reasonblocks.monitors.base import BaseMonitor

MONITOR_REGISTRY: dict[str, type[BaseMonitor]] = {}
ALL_MONITOR_NAMES: list[str] = []


def create_monitors(
    names: Optional[list[str]] = None,
) -> list[BaseMonitor]:
    """Return the user-supplied monitors only.

    The built-in monitor suite is server-side. Pass an empty list (or
    omit the argument) to use only the remote monitors. Pass a list of
    custom-monitor class names registered in ``MONITOR_REGISTRY`` to mix
    them in.
    """

    if not names:
        return []
    monitors: list[BaseMonitor] = []
    for name in names:
        cls = MONITOR_REGISTRY.get(name)
        if cls is None:
            raise ValueError(f"Unknown monitor: {name!r}")
        monitors.append(cls())
    return monitors
