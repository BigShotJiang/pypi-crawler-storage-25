from __future__ import annotations

import uuid
from typing import Optional

from reasonblocks.types import FSMState, StepRecord, TraceState


class TraceStateManager:
    """Per-run state tracker. Created fresh for each agent invocation."""

    def __init__(
        self,
        trace_id: Optional[str] = None,
        token_budget: Optional[int] = None,
    ) -> None:
        self.trace_id = trace_id or str(uuid.uuid4())
        self.token_budget = token_budget
        self._steps: list[StepRecord] = []
        self._difficulty_history: list[float] = []
        self._total_tokens: int = 0
        self._current_state: FSMState = FSMState.INIT

    @property
    def current_state(self) -> FSMState:
        return self._current_state

    @current_state.setter
    def current_state(self, value: FSMState) -> None:
        self._current_state = value

    def record_step(self, step: StepRecord) -> None:
        """Append a step and update running totals."""
        self._steps.append(step)
        self._difficulty_history.append(step.difficulty)
        self._total_tokens += step.tokens_used

    def get_difficulty_history(self, n: Optional[int] = None) -> list[float]:
        """Return the last *n* difficulty scores (all if n is None)."""
        if n is None:
            return list(self._difficulty_history)
        return self._difficulty_history[-n:]

    def get_budget_used(self) -> float:
        """Return fraction of token budget consumed (0.0 if no budget)."""
        if not self.token_budget or self.token_budget <= 0:
            return 0.0
        return min(self._total_tokens / self.token_budget, 1.0)

    def get_recent_actions(self, n: int = 10) -> list[tuple[Optional[str], Optional[str]]]:
        """Return (action, action_input) pairs for the last *n* steps."""
        recent = self._steps[-n:]
        return [(s.action, s.action_input) for s in recent]

    def add_tokens(self, count: int) -> None:
        """Add tokens from a model call to the running total."""
        self._total_tokens += count

    def get_trace(self) -> TraceState:
        """Return a snapshot of the full trace state."""
        return TraceState(
            trace_id=self.trace_id,
            steps=list(self._steps),
            current_state=self._current_state,
            difficulty_history=list(self._difficulty_history),
            total_tokens=self._total_tokens,
            token_budget=self.token_budget,
        )
