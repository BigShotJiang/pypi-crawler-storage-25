"""
FedComp Index - Federal contractor competitive intelligence.

Meta-package that installs the full FedComp Index toolkit:
- fedcomp-index-scoring: posture classification engine
- fedcomp-index-data: pre-classified contractor datasets

FedComp Index classifies every federal contractor in a state into one of
four Posture Classes using two-axis thresholds: total contract dollars ($5M,
base + delivery orders) crossed with base contract count (3).
No composite score, no weighted sum.

Class 1: high volume + high frequency (systematic winners)
Class 2: high volume + low frequency (concentrated risk)
Class 3: low volume + high frequency (growth pipeline)
Class 4: low volume + low frequency (entry level)

Website: https://fedcompindex.org/
Methodology: https://fedcompindex.org/methodology/
"""

__version__ = "2026.4.0"

from fedcomp_index_scoring import (
    classify,
    classify_contractor,
    score_contractor,
    PostureClass,
    FedCompResult,
    compute_velocity,
    build_proximity_map,
    neighborhood_density,
    VOL_THRESHOLD,
    FREQ_THRESHOLD,
)
from fedcomp_index_data import load_state, lookup, list_states

__all__ = [
    "classify",
    "classify_contractor",
    "score_contractor",
    "PostureClass",
    "FedCompResult",
    "compute_velocity",
    "build_proximity_map",
    "neighborhood_density",
    "VOL_THRESHOLD",
    "FREQ_THRESHOLD",
    "load_state",
    "lookup",
    "list_states",
]
