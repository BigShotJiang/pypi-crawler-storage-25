import sys
import importlib
from pathlib import Path
import traceback
import argparse

try:
    from rich.console import Console
    console = Console(force_terminal=True)
    print = console.print
except:
    pass


def config_parser():
    'Return a parser'
    parser = argparse.ArgumentParser(
        description='Check if all the modules in a package can be imported individually.')
    parser.add_argument('package', help='path to the package folder', metavar='PATH')
    parser.add_argument('-v', '--verbose', help='show more information', action='store_true')
    parser.add_argument('-l', '--list', help='list each module when it is imported',
                        action='store_true')
    parser.add_argument('-s', '--setup', help='name of the setup module', metavar='MODULE',
                        dest='module')
    return parser


def remove_frames(stack_summary, filenames):
    '''Remove frames from stack_summary that match one of filenames

    Returns the modified stack_summary'''

    for frame_summary in stack_summary[:]:
        for filename in filenames:
            if filename in frame_summary.filename:
                stack_summary.remove(frame_summary)
                break
    return stack_summary


def remove_modules(package):
    ''
    for m in sys.modules.copy():
        if package in m:
            del sys.modules[m]


def substract(path, base_path):
    '''Return the difference between path and base_path.

    The result is a list of parts that are in path but not
    in base_path.  Both path and base_path must be instances
    of pathlib.Path.

    For example, substract(Path('/dir/package/submodule/module.py',
    Path('/dir'))) returns ['package', 'submodule', 'module.py'].'''
    parts = list(path.parts)
    base_path_parts = list(base_path.parts)
    for part in parts[:]:
        if part in base_path_parts:
            parts.remove(part)
            base_path_parts.remove(part)
    return parts


def print_exception(e_traceback, e_type, e_msg, exclude_filenames):
    '''Display the traceback and exception information.'''
    print('Traceback (most recent call last):')
    stack_summary = traceback.extract_tb(e_traceback)
    stack_summary = remove_frames(stack_summary, exclude_filenames)
    traceback.print_list(stack_summary, file=sys.stdout)
    print(f'{e_type}: {e_msg}')
    print()


if __name__ == '__main__':
    parser = config_parser()
    args = parser.parse_args()
    if args.module:
        importlib.import_module(args.module.replace('.py', ''))
    exclude_filenames = ('importlib', 'mck.py')
    package = args.package
    failed = 0
    n = 0
    p = Path(package)
    sys.path.insert(0, str(p.parent))
    exceptions = {}
    for c in sorted(p.glob('**/*.py')):
        remove_modules(p.stem)
        if '__' not in c.stem and c.stem != 'setup' and c.stem != 'main':
            n += 1
            name = '.'.join(substract(c, p.parent)).replace('.py', '')
            try:
                importlib.import_module(name)
            except:
                failed += 1
                e = sys.exception()
                e_type = type(e).__name__
                e_msg = str(e)
                if args.list:
                    print(failed, name)
                if (e_type, e_msg) not in exceptions:
                    exceptions[(e_type, e_msg)] = []
                exceptions[(e_type, e_msg)].append((name, e))
            else:
                if args.list:
                    print('✓', name)
    print()
    print(failed, 'module(s) failed out of', n)
    print()
    print("Frequency of the errors:")
    for e_type, e_msg in exceptions:
        msg = f"{len(exceptions[(e_type, e_msg)]):2} {e_type}: {e_msg}"
        print(msg)
        if args.verbose:
            print('-'*80)
            for name, e in exceptions[(e_type, e_msg)]:
                print(f'import {name} ❌')
                e_type = type(e).__name__
                e_msg = str(e)
                print_exception(e.__traceback__, e_type, e_msg, exclude_filenames)
            print('-'*80)
            print()
