`mck` is a Python module checker that verifies if one or more modules
can be imported individually.

Some existing Python projects have many modules. In some cases, if you
run pydoc, try to generate a reference with Sphinx or want to create
unit tests, many of the modules will fail to import.

In these cases, `mck` can quickly check every module, helping to
identify the cause of each error and if there are similar errors, in
order to fix them.  The output of `mck` shows all the errors in one
place and the progress in fixing them.

The following is a very simple project, it has a package with only two
modules:

package/module1.py

```python
import package.module2

def f():
    pass
```

package/module2.py

```python
from package.module1 import f

def g():
    f()
```

Will each module import? Instead of manually trying `import
package.module1` and `import package.module2`, we run `mck` and supply
the path to the folder of the package:

```bash
py -m mck path/package
1 package.module1
Traceback (most recent call last):
  File "~/Documents/mck/example/fails/package/module1.py", line 1, in <module>
    import package.module2
  File "~/Documents/mck/example/fails/package/module2.py", line 1, in <module>
    from package.module1 import f
ImportError: cannot import name 'f' from partially initialized module 'package.module1' (most likely due to a circular import) (~/Documents/mck/example/fails/package/module1.py)

✓ package.module2

1 module(s) failed out of 2
```

The output shows that module1 fails and module2 passes.  The first
module fails due to *ImportError: cannot import name 'f' from
partially initialized module*.  We can fix this error by changing the
import and the reference to function *f* in module2 to this:

package/module2.py

```python
import package.module1

def g():
    package.module1.f()
```

The output of `mck` now shows that the error has been fixed and all
modules pass :

```bash
py -m mck path/package
✓ package.module1
✓ package.module2

0 module(s) failed out of 2
```

`mck` is available [here](https://pypi.org/project/mck/) in
the Python Package Index (PyPI) for installation using pip, and
[this](https://gitlab.com/ppaez/mck) is the source code repository in
Gitlab.

The name `mck` is based on the name of other checker programs like
`fsck`, `pvck`, `vgck`, `pwck`.
