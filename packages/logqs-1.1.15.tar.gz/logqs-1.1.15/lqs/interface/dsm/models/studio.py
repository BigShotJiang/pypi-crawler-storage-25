from typing import Optional
from uuid import UUID

from pydantic import BaseModel

from lqs.interface.dsm.models.__common__ import (
    CommonModel,
    DataResponseModel,
    PaginationModel,
    optional_field,
)


class StudioResource(CommonModel):
    type: str
    datastore_id: Optional[UUID]
    payload: Optional[dict]
    context: Optional[dict]


class StudioResourceDataResponse(DataResponseModel[StudioResource]):
    pass


class StudioResourceListResponse(PaginationModel[StudioResource]):
    pass


class StudioResourceCreateRequest(BaseModel):
    type: str
    datastore_id: Optional[UUID] = None
    payload: Optional[dict] = None
    context: Optional[dict] = None


class StudioResourceUpdateRequest(BaseModel):
    type: str = optional_field
    datastore_id: Optional[UUID] = optional_field
    payload: Optional[dict] = optional_field
    context: Optional[dict] = optional_field
