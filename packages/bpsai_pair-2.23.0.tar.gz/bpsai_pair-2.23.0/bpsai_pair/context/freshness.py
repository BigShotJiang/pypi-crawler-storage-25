"""Context freshness auto-refresh on session start.

Checks if context files (project.md, workflow.md, CLAUDE.md) are older
than 7 days and auto-refreshes them when stale. Supports both time-based
and content-based (git) staleness detection.
"""

from __future__ import annotations

import logging
import subprocess
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable, Dict

logger = logging.getLogger(__name__)

STALE_THRESHOLD_DAYS = 7

# Relative paths from project root to refreshable context files
REFRESHABLE_FILES: Dict[str, str] = {
    ".paircoder/context/project.md": "project",
    ".paircoder/context/workflow.md": "workflow",
    "CLAUDE.md": "claude",
}


def _is_stale(file_path: Path) -> bool:
    """Check if a file is older than STALE_THRESHOLD_DAYS.

    Returns True if file is missing or older than threshold.
    A file exactly at the threshold boundary is considered fresh.
    """
    if not file_path.exists():
        return True

    mtime = file_path.stat().st_mtime
    age_seconds = time.time() - mtime
    threshold_seconds = STALE_THRESHOLD_DAYS * 86400
    return age_seconds > threshold_seconds


def _has_git_changes(project_root: Path, rel_path: str) -> bool:
    """Check if git has changes in the file's directory since last modification.

    Uses ``git log --since=<mtime>`` to detect content changes.
    Returns False (no changes) when git is unavailable or errors occur,
    falling back to time-based staleness only.
    """
    file_path = project_root / rel_path
    if not file_path.exists():
        return False

    try:
        mtime = file_path.stat().st_mtime
        since_dt = datetime.fromtimestamp(mtime, tz=timezone.utc)
        since_str = since_dt.strftime("%Y-%m-%dT%H:%M:%S")
        file_rel = str(file_path.relative_to(project_root))

        result = subprocess.run(
            ["git", "log", f"--since={since_str}", "--oneline", "--", file_rel],
            cwd=str(project_root),
            capture_output=True,
            text=True,
            timeout=5,
        )
        return bool(result.stdout.strip())
    except (FileNotFoundError, subprocess.SubprocessError, OSError):
        return False


# --- Type-specific refresh handlers ---


def _refresh_project(project_root: Path, file_path: Path) -> bool:
    """Refresh project.md. Stub: touches file; future: re-runs discovery."""
    logger.debug("Would re-run project discovery for %s", file_path)
    file_path.touch()
    return True


def _refresh_workflow(project_root: Path, file_path: Path) -> bool:
    """Refresh workflow.md. Stub: touches file; future: re-runs detection."""
    logger.debug("Would re-run workflow detection for %s", file_path)
    file_path.touch()
    return True


def _refresh_claude(project_root: Path, file_path: Path) -> bool:
    """Refresh CLAUDE.md metrics. Stub: touches file; future: updates stats."""
    logger.debug("Would refresh CLAUDE.md metrics for %s", file_path)
    file_path.touch()
    return True


_REFRESH_HANDLERS: Dict[str, Callable[[Path, Path], bool]] = {
    "project": _refresh_project,
    "workflow": _refresh_workflow,
    "claude": _refresh_claude,
}


def _refresh_file(project_root: Path, rel_path: str) -> bool:
    """Dispatch to type-specific refresh handler, fall back to touch."""
    file_path = project_root / rel_path
    if not file_path.exists():
        return False

    file_type = REFRESHABLE_FILES.get(rel_path)
    handler = _REFRESH_HANDLERS.get(file_type) if file_type else None

    if handler is not None:
        try:
            return handler(project_root, file_path)
        except Exception:
            logger.debug("Handler for %s failed, falling back to touch", rel_path)

    # Fallback: just touch the file
    file_path.touch()
    return True


def maybe_refresh_context(
    project_root: Path, *, quiet: bool = False
) -> Dict[str, str]:
    """Check context file freshness and auto-refresh stale files.

    Non-blocking: errors never prevent session start.
    Returns dict mapping relative path to "fresh", "refreshed", or "error".
    """
    results: Dict[str, str] = {}

    for rel_path in REFRESHABLE_FILES:
        file_path = project_root / rel_path
        try:
            time_stale = _is_stale(file_path)
            git_stale = (
                not time_stale
                and file_path.exists()
                and _has_git_changes(project_root, rel_path)
            )
            if not time_stale and not git_stale:
                results[rel_path] = "fresh"
                continue

            success = _refresh_file(project_root, rel_path)
            status = "refreshed" if success else "error"
            results[rel_path] = status

            if not quiet and status == "refreshed":
                logger.info("Auto-refreshed stale context file: %s", rel_path)
        except Exception as exc:
            logger.debug("Context refresh failed for %s: %s", rel_path, exc)
            results[rel_path] = "error"

    return results


def _try_calibration_refresh(project_root: Path) -> None:
    """Attempt calibration refresh, importing only if available."""
    try:
        from bpsai_pair.feedback.calibration_refresh import maybe_refresh_calibration

        maybe_refresh_calibration(project_root)
    except ImportError:
        logger.debug("Calibration refresh not available")
    except Exception as exc:
        logger.debug("Calibration refresh failed: %s", exc)


def session_start_checks(
    project_root: Path, *, quiet: bool = False
) -> Dict[str, str]:
    """Run all session-start freshness checks (context + calibration).

    Non-blocking: catches all exceptions to avoid blocking session start.
    """
    results: Dict[str, str] = {}

    try:
        results = maybe_refresh_context(project_root, quiet=quiet)
    except Exception as exc:
        logger.debug("Context refresh failed entirely: %s", exc)

    try:
        _try_calibration_refresh(project_root)
    except Exception as exc:
        logger.debug("Calibration refresh failed entirely: %s", exc)

    return results
