"""PM abstraction layer — provider-agnostic project management types."""

from bpsai_pair.pm.completion_eval import CompletionRuleEvaluator
from bpsai_pair.pm.errors import (
    PMConnectionError,
    PMError,
    PMItemNotFoundError,
    PMSyncConflictError,
    PMTransitionError,
)
from bpsai_pair.pm.compat import load_pm_config, migrate_trello_config
from bpsai_pair.pm.hierarchy import HierarchyManager
from bpsai_pair.pm.lifecycle import PMLifecycleManager
from bpsai_pair.pm.presets import list_presets, load_preset
from bpsai_pair.pm.sync import PMSyncManager, SyncPlan
from bpsai_pair.pm.provider import NullProvider, ProjectManagementProvider
from bpsai_pair.pm.registry import (
    get_active_provider,
    get_provider_class,
    list_providers,
    register_provider,
    reset_provider_cache,
)
from bpsai_pair.pm.types import (
    FieldType,
    PMChecklistItem,
    PMCustomField,
    PMRelationship,
    PMWorkItem,
    RelationshipType,
    SyncAction,
    SyncConflict,
    SyncResult,
    WorkItemStatus,
    WorkItemType,
)
from bpsai_pair.pm.workflow import (
    AutomationRule,
    CompletionRule,
    WorkflowConfig,
    WorkflowEngine,
    WorkItemTypeConfig,
)

__all__ = [
    "AutomationRule",
    "CompletionRuleEvaluator",
    "CompletionRule",
    "FieldType",
    "HierarchyManager",
    "PMConnectionError",
    "PMError",
    "PMItemNotFoundError",
    "PMLifecycleManager",
    "PMSyncConflictError",
    "PMSyncManager",
    "PMTransitionError",
    "NullProvider",
    "PMChecklistItem",
    "PMCustomField",
    "PMRelationship",
    "PMWorkItem",
    "ProjectManagementProvider",
    "RelationshipType",
    "SyncAction",
    "SyncConflict",
    "SyncPlan",
    "SyncResult",
    "WorkItemStatus",
    "WorkItemType",
    "WorkflowConfig",
    "WorkflowEngine",
    "WorkItemTypeConfig",
    "get_active_provider",
    "get_provider_class",
    "list_presets",
    "list_providers",
    "load_pm_config",
    "load_preset",
    "migrate_trello_config",
    "register_provider",
    "reset_provider_cache",
]
