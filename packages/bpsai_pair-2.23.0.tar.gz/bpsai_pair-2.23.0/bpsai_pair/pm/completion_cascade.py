"""CompletionCascade — walk up the parent chain evaluating completion rules.

When a task completes: check if its parent story should auto-complete,
then check if the story's parent epic should auto-complete, etc.
Depth is capped to prevent infinite loops.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import TYPE_CHECKING

from bpsai_pair.pm.completion_eval import CompletionRuleEvaluator
from bpsai_pair.pm.provider import ProjectManagementProvider
from bpsai_pair.pm.types import WorkItemStatus, WorkItemType

if TYPE_CHECKING:
    from bpsai_pair.pm.engine import WorkflowEngine

logger = logging.getLogger(__name__)

_TYPE_TO_COMPLETED_EVENT: dict[WorkItemType, str] = {
    WorkItemType.STORY: "on_story_completed",
    WorkItemType.EPIC: "on_epic_completed",
    WorkItemType.TASK: "on_task_complete",
}


@dataclass
class CascadeResult:
    """Result of evaluating one level in the cascade."""

    item_id: str
    item_type: WorkItemType
    completed: bool

    @property
    def event(self) -> str | None:
        """Return the hook event name if completed, else None."""
        if not self.completed:
            return None
        return _TYPE_TO_COMPLETED_EVENT.get(self.item_type)


class CompletionCascade:
    """Evaluate completion cascade up the work item hierarchy."""

    def __init__(
        self,
        provider: ProjectManagementProvider,
        evaluator: CompletionRuleEvaluator,
        *,
        engine: WorkflowEngine | None = None,
    ) -> None:
        self.provider = provider
        self.evaluator = evaluator
        self._engine = engine

    def evaluate(self, item_id: str, max_depth: int = 3) -> list[CascadeResult]:
        """Walk up from *item_id*, evaluating completion at each parent.

        Returns a list of CascadeResult for each parent visited.
        Stops when: no parent, depth exhausted, or evaluation fails.
        """
        if "hierarchy" not in self.provider.capabilities():
            return []

        try:
            return self._walk_up(item_id, max_depth)
        except Exception as e:
            logger.warning("Cascade evaluation failed: %s", e)
            return []

    def _walk_up(self, item_id: str, remaining: int) -> list[CascadeResult]:
        results: list[CascadeResult] = []
        current_id = item_id

        for _ in range(remaining):
            parent_id = self._get_parent_id(current_id)
            if parent_id is None:
                break

            parent = self.provider.find_item(parent_id)
            if parent is None:
                break

            satisfied = self.evaluator.all_satisfied(
                parent.item_type.value, parent_id,
            )

            if satisfied:
                moved = self._move_completed(parent_id, parent.item_type)
                if not moved:
                    logger.warning(
                        "Cascade: move_item failed for %s (%s)",
                        parent_id, parent.item_type.value,
                    )
                    results.append(CascadeResult(
                        item_id=parent_id,
                        item_type=parent.item_type,
                        completed=False,
                    ))
                    break
                results.append(CascadeResult(
                    item_id=parent_id,
                    item_type=parent.item_type,
                    completed=True,
                ))
                logger.info(
                    "Cascade: %s (%s) → DONE",
                    parent_id, parent.item_type.value,
                )
                current_id = parent_id
            else:
                results.append(CascadeResult(
                    item_id=parent_id,
                    item_type=parent.item_type,
                    completed=False,
                ))
                break

        return results

    def _move_completed(
        self, item_id: str, item_type: WorkItemType,
    ) -> bool:
        """Move a completed item to its completion destination.

        Uses the engine's completion_destination for the item type when
        available; falls back to ``move_item(DONE)``.
        """
        destination = self._resolve_destination(item_type)
        if destination:
            return self.provider.move_to_destination(item_id, destination)
        return self.provider.move_item(item_id, WorkItemStatus.DONE)

    def _resolve_destination(self, item_type: WorkItemType) -> str | None:
        """Look up completion_destination from the engine's completion rules."""
        if self._engine is None:
            return None
        rule = self._engine.get_completion_rule(item_type.value)
        if rule is None or not rule.completion_destination:
            return None
        return rule.completion_destination

    def _get_parent_id(self, item_id: str) -> str | None:
        """Resolve parent_id from the item's data."""
        item = self.provider.find_item(item_id)
        if item is None:
            return None
        parent_id = item.parent_id
        if not isinstance(parent_id, str) or not parent_id:
            return None
        return parent_id
