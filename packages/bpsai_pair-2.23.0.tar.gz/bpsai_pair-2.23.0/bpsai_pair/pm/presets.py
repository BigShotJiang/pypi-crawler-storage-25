"""Preset workflow loader — loads YAML presets from data/workflows/."""

from __future__ import annotations

from pathlib import Path

import yaml

from bpsai_pair.pm.workflow import WorkflowConfig

# Directory containing workflow preset YAML files
_WORKFLOWS_DIR = Path(__file__).resolve().parent.parent / "data" / "workflows"


def load_preset(name: str) -> WorkflowConfig:
    """Load a named workflow preset from YAML.

    Args:
        name: The preset name (without .yaml extension).

    Returns:
        A WorkflowConfig parsed from the preset file.

    Raises:
        FileNotFoundError: If no preset with that name exists.
    """
    path = _WORKFLOWS_DIR / f"{name}.yaml"
    if not path.exists():
        msg = f"Workflow preset not found: {name} (looked in {_WORKFLOWS_DIR})"
        raise FileNotFoundError(msg)
    with open(path, encoding="utf-8") as fh:
        data = yaml.safe_load(fh)
    return WorkflowConfig.from_dict(data)


def list_presets() -> list[str]:
    """Return sorted list of available workflow preset names."""
    if not _WORKFLOWS_DIR.is_dir():
        return []
    return sorted(p.stem for p in _WORKFLOWS_DIR.glob("*.yaml"))
