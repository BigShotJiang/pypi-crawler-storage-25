"""Provider ABC for project management abstraction.

NullProvider lives in ``null_provider.py`` but is re-exported here so
``from bpsai_pair.pm.provider import NullProvider`` keeps working.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any

from bpsai_pair.pm.types import (
    PMChecklistItem,
    PMRelationship,
    PMWorkItem,
    SyncAction,
    SyncResult,
    WorkItemStatus,
)


class ProjectManagementProvider(ABC):
    """Abstract base class for project management providers.

    Subclasses MUST set ``name`` and implement all ``@abstractmethod``
    methods.  Optional methods have safe no-op defaults.
    """

    name: str  # each concrete provider sets this as a class attribute

    # ── Required (abstract) methods ───────────────────────────────────

    @abstractmethod
    def connect(self) -> bool:
        """Establish connection to the provider. Returns True on success."""

    @abstractmethod
    def healthcheck(self) -> bool:
        """Return True if the provider is reachable and healthy."""

    @abstractmethod
    def find_item(self, item_id: str) -> PMWorkItem | None:
        """Look up a work item by ID.  Returns None if not found."""

    @abstractmethod
    def move_item(self, item_id: str, status: WorkItemStatus) -> bool:
        """Transition a work item to *status*.  Returns True on success."""

    @abstractmethod
    def set_fields(self, item_id: str, fields: dict[str, Any]) -> bool:
        """Set custom fields on a work item.  Returns True on success."""

    @abstractmethod
    def add_comment(self, item_id: str, text: str) -> bool:
        """Add a comment to a work item.  Returns True on success."""

    @abstractmethod
    def sync_item(self, item: PMWorkItem) -> SyncResult:
        """Sync a local work item to the provider."""

    # ── Optional methods (safe defaults) ──────────────────────────────

    def get_children(self, item_id: str) -> list[PMWorkItem]:
        """Return child work items.  Empty list if unsupported."""
        return []

    def set_relationship(self, relationship: PMRelationship) -> bool:
        """Create a relationship between items.  False if unsupported."""
        return False

    def remove_relationship(self, relationship: PMRelationship) -> bool:
        """Remove a relationship between items.  False if unsupported."""
        return False

    def check_checklist_item(
        self, item_id: str, checklist_item_id: str, *, checked: bool
    ) -> bool:
        """Check/uncheck a checklist item.  False if unsupported."""
        return False

    def discover_created_item(self, local_id: str) -> PMWorkItem | None:
        """Find a remotely-created item matching *local_id*.  None if unsupported."""
        return None

    def create_item(self, item: PMWorkItem) -> PMWorkItem | None:
        """Create a new work item in the provider.

        Default: delegates to sync_item().  Returns the item with
        ``provider_meta["provider_id"]`` populated on success, None on
        failure or skip.
        """
        result = self.sync_item(item)
        if result.action == SyncAction.CREATED:
            provider_id = (result.changes or {}).get("provider_id")
            if provider_id:
                item.provider_meta["provider_id"] = provider_id
            return item
        return None

    def add_checklist_item(
        self, item_id: str, checklist_name: str, item_name: str,
    ) -> str | None:
        """Add an item to a named checklist on a work item.

        Creates the checklist if it doesn't exist.  Returns the
        checklist-item ID on success, None if unsupported.
        """
        return None

    def get_checklist_items(self, item_id: str) -> list[PMChecklistItem]:
        """Return checklist items for a work item.  Empty if unsupported."""
        return []

    def move_to_destination(self, item_id: str, destination: str) -> bool:
        """Move item to a named destination (e.g. list name).

        Used by the completion cascade to move items to their
        ``completion_destination`` rather than the generic DONE status.
        Default: falls back to ``move_item(item_id, WorkItemStatus.DONE)``.
        """
        return self.move_item(item_id, WorkItemStatus.DONE)

    def capabilities(self) -> set[str]:
        """Return supported capabilities. Base: ``{"basic"}``."""
        return {"basic"}

# Re-export so `from bpsai_pair.pm.provider import NullProvider` works.
from bpsai_pair.pm.null_provider import NullProvider  # noqa: E402, F401

__all__ = ["ProjectManagementProvider", "NullProvider"]
