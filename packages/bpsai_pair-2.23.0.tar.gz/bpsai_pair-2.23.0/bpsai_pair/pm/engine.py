"""Workflow engine — runtime interpreter for WorkflowConfig."""

from __future__ import annotations

from typing import Optional

from bpsai_pair.pm.workflow import (
    AutomationRule,
    ButtonAction,
    CompletionRule,
    WorkflowConfig,
    WorkItemTypeConfig,
)


class WorkflowEngine:
    """Interprets a WorkflowConfig for runtime queries."""

    def __init__(self, config: WorkflowConfig) -> None:
        self._config = config

    def get_destination_for_status(self, status: str) -> str:
        """Return the primary destination name for a workflow status.

        For statuses mapped to a string, returns that string.
        For statuses mapped to a list, returns the first entry.
        Raises KeyError if the status is not defined.
        """
        mapping = self._config.statuses[status]
        if isinstance(mapping, list):
            return mapping[0]
        return str(mapping)

    def get_list_for_status(self, status: str) -> str:
        """Deprecated: use get_destination_for_status() instead."""
        return self.get_destination_for_status(status)

    def can_transition(self, from_status: str, to_status: str) -> bool:
        """Return True if transitioning from_status to to_status is allowed."""
        allowed = self._config.transitions.get(from_status, [])
        return to_status in allowed

    def get_completion_rule(self, item_type: str) -> Optional[CompletionRule]:
        """Return the completion rule for item_type, or None."""
        return self._config.completion_rules.get(item_type)

    def get_work_item_config(
        self, item_type: str,
    ) -> Optional[WorkItemTypeConfig]:
        """Return the WorkItemTypeConfig for item_type, or None."""
        return self._config.work_items.get(item_type)

    def get_automations(self) -> list[AutomationRule]:
        """Return the list of automation rules from the config."""
        return self._config.automations

    def get_button_actions(self) -> dict[str, ButtonAction]:
        """Return the button_actions dict from the config."""
        return self._config.button_actions

    def get_domain_labels(self) -> list[str]:
        """Return the list of domain (propagatable) labels."""
        return self._config.label_categories.get("domain", [])

    def is_domain_label(self, label: str) -> bool:
        """Return True if label is in the domain category."""
        return label in self._config.label_categories.get("domain", [])
