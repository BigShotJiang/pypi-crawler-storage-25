"""PM error hierarchy — shared across all providers."""


class PMError(Exception):
    """Base error for all PM operations."""


class PMConnectionError(PMError):
    """Failed to connect to the PM provider."""


class PMItemNotFoundError(PMError):
    """Requested work item was not found."""


class PMTransitionError(PMError):
    """Invalid status transition on a work item."""


class PMSyncConflictError(PMError):
    """Conflict detected during sync."""
