"""
Data models for plan execution graphs.

Defines the structures used to represent a plan's task dependency graph,
including execution phases, task nodes, and the overall execution graph.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Literal


class ExecutionMode(Enum):
    """How tasks within a phase should be executed."""

    SEQUENTIAL = "sequential"
    PARALLEL = "parallel"


@dataclass
class TaskNode:
    """A task in the execution graph with dependency metadata."""

    task_id: str
    complexity: int = 0
    depends_on: list[str] = field(default_factory=list)
    phase_id: int = 0
    status: Literal["pending", "ready", "running", "done", "blocked", "hook_failed"] = "pending"
    title: str = ""
    requires: str = "autonomous"


@dataclass
class ExecutionPhase:
    """A group of tasks that execute together with a shared mode."""

    phase_id: int
    name: str
    task_ids: list[str] = field(default_factory=list)
    execution: ExecutionMode = ExecutionMode.SEQUENTIAL


@dataclass
class ExecutionGraph:
    """The full execution graph for a plan."""

    plan_id: str
    phases: list[ExecutionPhase] = field(default_factory=list)
    nodes: dict[str, TaskNode] = field(default_factory=dict)
    dependencies: dict[str, list[str]] = field(default_factory=dict)

    def ready_tasks(self) -> list[str]:
        """Return task IDs that are ready to execute (deps satisfied)."""
        ready = []
        for task_id, node in self.nodes.items():
            if node.status != "pending":
                continue
            deps = self.dependencies.get(task_id, [])
            if all(self.nodes[d].status == "done" for d in deps):
                ready.append(task_id)
        return ready

    def parallel_groups(self) -> list[list[str]]:
        """Return groups of tasks that can run in parallel."""
        groups: list[list[str]] = []
        for phase in self.phases:
            if phase.execution == ExecutionMode.PARALLEL:
                groups.append(phase.task_ids)
            else:
                for tid in phase.task_ids:
                    groups.append([tid])
        return groups

    def first_human_gated(self, task_ids: list[str]) -> str | None:
        """Return the first human-gated undone task ID, or None."""
        for tid in task_ids:
            node = self.nodes.get(tid)
            if node and node.requires == "human" and node.status != "done":
                return tid
        return None

    def mark_done(self, task_id: str) -> None:
        """Mark a task as done."""
        if task_id in self.nodes:
            self.nodes[task_id].status = "done"

    def total_complexity(self) -> int:
        """Sum of all task complexities."""
        return sum(n.complexity for n in self.nodes.values())


def phase_label(phase: ExecutionPhase, index: int) -> str:
    """Return a display label for a phase, falling back to index if empty."""
    name = phase.name
    if name and str(name).strip():
        return str(name).strip()
    return str(phase.phase_id or index)
