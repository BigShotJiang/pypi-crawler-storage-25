"""
Workflow execution steps for autonomous orchestration.

Contains:
- WorkflowRunner: Runs full workflow sequences (run_task_workflow, run_session, get_status)
- WorkflowSequencer: Step-by-step phase orchestration with hooks
"""
from __future__ import annotations

import logging
from datetime import datetime, timezone
from typing import Optional, List, Dict, Any, TYPE_CHECKING

from .autonomous_models import WorkflowPhase, WorkflowEvent, WorkflowState, WorkflowConfig, call_hook

if TYPE_CHECKING:
    from .autonomous import AutonomousWorkflow

logger = logging.getLogger(__name__)


def report_test_failure(workflow: "AutonomousWorkflow", reason: str):
    """Report test failure."""
    workflow.state.record_event(WorkflowEvent.TESTS_FAILED, {"reason": reason})
    call_hook(workflow.hooks, "on_tests_completed", False, reason)
    logger.warning(f"Tests failed: {reason}")


class WorkflowRunner:
    """Runs full workflow sequences on an AutonomousWorkflow."""

    def __init__(self, workflow: "AutonomousWorkflow"):
        """Initialize runner.

        Args:
            workflow: The autonomous workflow to run sequences on
        """
        self.workflow = workflow

    def run_task_workflow(
        self,
        task_id: Optional[str] = None,
        plan_id: Optional[str] = None,
    ) -> bool:
        """Run the full workflow for a single task.

        Args:
            task_id: Specific task ID (auto-selects if not provided)
            plan_id: Plan ID for task selection

        Returns:
            True if workflow completed successfully
        """
        wf = self.workflow

        # Select task
        if task_id:
            wf.state.current_task_id = task_id
            wf.state.started_at = datetime.now(timezone.utc)
        elif wf.config.auto_select_tasks:
            if not wf.select_next_task(plan_id):
                return False
        else:
            logger.warning("No task specified and auto-select disabled")
            return False

        # Planning
        wf.start_planning()
        wf.complete_planning()

        # Implementation
        wf.start_implementation()
        wf.complete_implementation()

        # Testing (if enabled)
        if wf.config.run_tests_before_pr:
            if not wf.run_tests():
                return False

        # Review (if required)
        if wf.config.require_review:
            wf.start_review()
            wf.complete_review()

        # PR Creation
        if wf.config.auto_create_pr:
            wf.create_pr()

        # Complete task
        return wf.complete_task()

    def run_session(
        self,
        plan_id: Optional[str] = None,
        max_tasks: Optional[int] = None,
    ) -> List[str]:
        """Run an autonomous session processing multiple tasks.

        Args:
            plan_id: Optional plan ID to filter tasks
            max_tasks: Maximum tasks to process (uses config if not provided)

        Returns:
            List of completed task IDs
        """
        wf = self.workflow
        max_tasks = max_tasks or wf.config.max_tasks_per_session
        completed_tasks = []

        logger.info(f"Starting autonomous session (max {max_tasks} tasks)")

        for i in range(max_tasks):
            logger.info(f"Processing task {i + 1}/{max_tasks}")

            if self.run_task_workflow(plan_id=plan_id):
                # The task_id was already reset, so we need to get it from events
                for event in reversed(wf.state.events):
                    if event["event"] == "task_completed":
                        completed_tasks.append(event["data"]["task_id"])
                        break
            else:
                logger.info("No more tasks or workflow failed, ending session")
                break

        logger.info(f"Session completed: {len(completed_tasks)} tasks done")
        return completed_tasks

    def get_status(self) -> Dict[str, Any]:
        """Get current workflow status.

        Returns:
            Status dictionary
        """
        wf = self.workflow
        return {
            "workflow_state": wf.state.to_dict(),
            "config": {
                "auto_select_tasks": wf.config.auto_select_tasks,
                "auto_create_pr": wf.config.auto_create_pr,
                "auto_update_trello": wf.config.auto_update_trello,
                "run_tests_before_pr": wf.config.run_tests_before_pr,
                "require_review": wf.config.require_review,
            },
        }


class WorkflowSequencer:
    """
    Sequences workflow steps for full autonomy.

    Provides step-by-step orchestration with hooks for each phase.
    """

    PHASE_SEQUENCE = [
        WorkflowPhase.SELECTING_TASK,
        WorkflowPhase.PLANNING,
        WorkflowPhase.IMPLEMENTING,
        WorkflowPhase.TESTING,
        WorkflowPhase.REVIEWING,
        WorkflowPhase.CREATING_PR,
        WorkflowPhase.COMPLETING,
    ]

    def __init__(self, workflow: "AutonomousWorkflow"):
        """Initialize sequencer.

        Args:
            workflow: The autonomous workflow to sequence
        """
        self.workflow = workflow
        self._current_phase_index = 0

    @property
    def current_phase(self) -> WorkflowPhase:
        """Get current phase."""
        return self.workflow.state.phase

    @property
    def next_phase(self) -> Optional[WorkflowPhase]:
        """Get next phase in sequence."""
        try:
            current_idx = self.PHASE_SEQUENCE.index(self.current_phase)
            if current_idx < len(self.PHASE_SEQUENCE) - 1:
                return self.PHASE_SEQUENCE[current_idx + 1]
        except ValueError:
            pass
        return None

    def advance(self) -> WorkflowPhase:
        """Advance to the next phase.

        Returns:
            The new current phase
        """
        next_phase = self.next_phase

        if next_phase == WorkflowPhase.SELECTING_TASK:
            self.workflow.select_next_task()
        elif next_phase == WorkflowPhase.PLANNING:
            self.workflow.start_planning()
        elif next_phase == WorkflowPhase.IMPLEMENTING:
            self.workflow.start_implementation()
        elif next_phase == WorkflowPhase.TESTING:
            self.workflow.run_tests()
        elif next_phase == WorkflowPhase.REVIEWING:
            self.workflow.start_review()
        elif next_phase == WorkflowPhase.CREATING_PR:
            self.workflow.create_pr()
        elif next_phase == WorkflowPhase.COMPLETING:
            self.workflow.complete_task()

        return self.workflow.state.phase

    def run_all(self) -> bool:
        """Run all phases to completion.

        Returns:
            True if all phases completed successfully
        """
        while self.next_phase:
            self.advance()
            if self.workflow.state.phase == WorkflowPhase.ERROR:
                return False
        return True
