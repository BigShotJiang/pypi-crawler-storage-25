"""Task review command orchestration -- reviews a single task's changes.

Lightweight single-agent review for the inner dev loop.  When a
task ID is given, delegates to the existing ``review_task`` function.
When no task ID is given, reviews uncommitted changes.
"""

from __future__ import annotations

import logging
import subprocess
from pathlib import Path
from typing import Any

from bpsai_pair.orchestration.review_common import (
    _DATA_END, _DATA_FENCE, _PROMPTS, _invoke_agent,
    classify_review_action,
)
from bpsai_pair.orchestration.task_review import TaskReviewResult, review_task

logger = logging.getLogger(__name__)


def _get_uncommitted_diff(project_root: Path) -> str:
    """Return the combined staged + unstaged diff."""
    try:
        result = subprocess.run(
            ["git", "diff", "HEAD"],
            cwd=str(project_root),
            capture_output=True, text=True, timeout=30,
        )
        return result.stdout
    except (subprocess.TimeoutExpired, FileNotFoundError, OSError):
        logger.warning("Failed to get uncommitted diff")
        return ""


def _invoke_single_reviewer(project_root: Path, diff: str) -> dict[str, Any]:
    """Invoke the reviewer agent on a diff."""
    prompt = _PROMPTS["nayru"] + _DATA_FENCE + diff + _DATA_END
    return _invoke_agent(project_root, prompt)


def _resolve_task_commit_diff(
    project_root: Path, task_id: str,
) -> str | None:
    """Resolve a task's commit diff from git log.

    Searches for a commit whose message contains the task ID and
    returns the diff for that commit.  Returns ``None`` if no
    matching commit is found.
    """
    try:
        log_result = subprocess.run(
            ["git", "log", "--oneline", "--fixed-strings", f"--grep={task_id}", "-1"],
            cwd=str(project_root),
            capture_output=True, text=True, timeout=30,
        )
        line = log_result.stdout.strip()
        if not line:
            return None
        commit_hash = line.split()[0]
        diff_result = subprocess.run(
            ["git", "diff", f"{commit_hash}~1..{commit_hash}"],
            cwd=str(project_root),
            capture_output=True, text=True, timeout=30,
        )
        return diff_result.stdout or None
    except (subprocess.TimeoutExpired, FileNotFoundError, OSError):
        logger.warning("Failed to resolve commit for task %s", task_id)
        return None


def review_task_changes(
    project_root: Path, task_id: str | None = None,
) -> dict[str, Any]:
    """Review a single task's changes (commit or uncommitted).

    If *task_id* is given, resolves the task's actual commit via
    ``git log --grep`` and delegates to ``review_task`` with that
    diff.  Falls back to HEAD~1 if no commit is found.
    Otherwise, reviews uncommitted changes with a single reviewer.
    """
    if task_id:
        diff_override = _resolve_task_commit_diff(project_root, task_id)
        tr = review_task(project_root, task_id, diff_override=diff_override)
        return {
            "action": tr.action,
            "findings": tr.findings,
            "errors": 1 if tr.error else 0,
            "dispatched": True,
            "agents": ["nayru"],
            "task_id": tr.task_id,
        }

    diff = _get_uncommitted_diff(project_root)
    if not diff:
        return {
            "action": "skipped", "reason": "empty_diff",
            "dispatched": False, "findings": "", "errors": 0,
            "agents": [],
        }

    result = _invoke_single_reviewer(project_root, diff)
    if result.get("error"):
        return {
            "action": "skipped", "reason": "agent_error",
            "dispatched": True, "findings": "", "errors": 1,
            "agents": ["nayru"],
        }

    findings = result.get("output", "")
    action = classify_review_action(findings)
    return {
        "action": action, "findings": findings, "errors": 0,
        "dispatched": True, "agents": ["nayru"],
    }
