"""Git-based targeted test runner for engage tasks.

Maps changed source files to their corresponding test files using
naming conventions, then runs only those tests instead of the full suite.
"""

from __future__ import annotations

import logging
import subprocess
from pathlib import Path, PurePosixPath

logger = logging.getLogger(__name__)

_SOURCE_PREFIX = "bpsai_pair/"


def map_source_to_test(source_path: str) -> str | None:
    """Map a source file path to its conventional test file path.

    Convention: ``bpsai_pair/<path>/<module>.py`` ->
    ``tests/<path>/test_<module>.py``.

    Returns None for non-source files, ``__init__.py``, test files,
    or paths containing traversal components (``..``).
    """
    if not source_path.startswith(_SOURCE_PREFIX):
        return None
    if not source_path.endswith(".py"):
        return None

    p = PurePosixPath(source_path)
    if p.name == "__init__.py":
        return None
    if p.name.startswith("test_"):
        return None

    # Path traversal guard: reject '..' components
    if ".." in p.parts:
        return None

    # Strip the bpsai_pair/ prefix
    relative = str(p.relative_to("bpsai_pair"))
    parent = str(PurePosixPath(relative).parent)
    stem = p.stem

    if parent == ".":
        return f"tests/test_{stem}.py"
    return f"tests/{parent}/test_{stem}.py"


def map_source_to_test_with_fallback(
    source_path: str,
    existing_tests: set[str],
) -> str | None:
    """Map source to test, falling back to directory if no exact match."""
    exact = map_source_to_test(source_path)
    if exact and exact in existing_tests:
        return exact

    # Fallback: tests/<path>/ directory
    if source_path.startswith(_SOURCE_PREFIX) and source_path.endswith(".py"):
        p = PurePosixPath(source_path)
        relative = str(PurePosixPath(str(p.relative_to("bpsai_pair"))).parent)
        if relative == ".":
            return "tests/"
        return f"tests/{relative}/"

    return None


def _git_changed_files(project_root: Path, extra_args: list[str]) -> list[str]:
    """Run a single ``git diff --name-only`` variant and return lines."""
    try:
        result = subprocess.run(
            ["git", "diff", "--name-only", *extra_args],
            cwd=str(project_root),
            capture_output=True, text=True, timeout=10,
        )
        if not result.stdout:
            return []
        return [l.strip() for l in result.stdout.splitlines() if l.strip()]
    except (subprocess.TimeoutExpired, FileNotFoundError, OSError):
        logger.warning("Failed to get changed files from git (%s)", extra_args)
        return []


def resolve_test_targets(project_root: Path) -> list[str]:
    """Resolve test targets from staged and unstaged changes.

    Runs ``git diff --cached --name-only`` (staged) and
    ``git diff --name-only`` (unstaged), then deduplicates.
    """
    staged = _git_changed_files(project_root, ["--cached"])
    unstaged = _git_changed_files(project_root, [])

    seen: set[str] = set()
    targets: list[str] = []
    for line in staged + unstaged:
        test_path = map_source_to_test(line)
        if test_path and test_path not in seen:
            seen.add(test_path)
            targets.append(test_path)

    return targets


def resolve_test_targets_for_task(project_root: Path) -> list[str]:
    """Resolve test targets from staged + unstaged changes (per-task).

    Uses ``git diff --name-only`` (staged + unstaged vs HEAD) to find
    files changed during the current task.
    """
    return resolve_test_targets(project_root)


def build_driver_test_instruction(targets: list[str]) -> str:
    """Build a driver prompt instruction for targeted test paths.

    Returns an instruction string telling the driver which tests to run,
    or an empty string if no targets (skip per-task tests).
    """
    if not targets:
        return ""
    paths = " ".join(targets)
    return f"Run only these tests: pytest {paths} -v --tb=short"
