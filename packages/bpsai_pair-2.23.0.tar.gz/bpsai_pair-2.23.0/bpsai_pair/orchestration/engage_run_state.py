"""Engage run-state persistence for human-gated pause/resume.

Run state is persisted to `.paircoder/engage/runs/<run-id>.state.json`
so that engage can resume across separate shell invocations.

State format:
    run_id           — unique identifier for this engage run
    plan_id          — the plan YAML being executed
    sprint           — sprint number string
    completed_tasks  — task IDs that finished before the pause
    paused_task_id   — the human-gated task that caused the pause
    max_parallel     — parallelism setting for resume
    hooks_advisory   — whether hooks are advisory mode
    created_at       — ISO timestamp when run started
    paused_at        — ISO timestamp when pause occurred
"""

from __future__ import annotations

import json
import os
import re
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path

import yaml

_RUN_ID_RE = re.compile(r"^[A-Za-z0-9._-]+$")


@dataclass
class RunState:
    """Serializable state for a paused engage run."""

    run_id: str
    plan_id: str
    sprint: str
    completed_tasks: list[str] = field(default_factory=list)
    paused_task_id: str = ""
    max_parallel: int = 3
    hooks_advisory: bool = False
    branch_auto_created: bool = False
    parent_branch: str = ""
    backlog_path: str = ""
    active_branch: str = ""
    created_at: str = ""
    paused_at: str = ""

    def __post_init__(self) -> None:
        now = datetime.now(timezone.utc).isoformat()
        if not self.created_at:
            self.created_at = now
        if not self.paused_at:
            self.paused_at = now


def _runs_dir(project_root: Path) -> Path:
    return project_root / ".paircoder" / "engage" / "runs"


def save_run_state(project_root: Path, state: RunState) -> Path:
    """Persist run state to JSON file. Returns the file path."""
    out_dir = _runs_dir(project_root)
    out_dir.mkdir(parents=True, exist_ok=True)
    path = out_dir / f"{state.run_id}.state.json"
    path.write_text(json.dumps(asdict(state), indent=2), encoding="utf-8")
    return path


def _validate_run_id(run_id: str) -> None:
    """Validate run_id against path traversal attacks."""
    if not run_id or not _RUN_ID_RE.match(run_id):
        raise ValueError(
            f"Run ID contains invalid characters: {run_id!r}. "
            "Only A-Z, a-z, 0-9, '.', '_', '-' are allowed.",
        )
    if run_id in (".", ".."):
        raise ValueError(f"Run ID is invalid: {run_id!r}")


def load_run_state(project_root: Path, run_id: str) -> RunState:
    """Load run state from JSON file. Raises FileNotFoundError if missing."""
    _validate_run_id(run_id)
    runs_dir = _runs_dir(project_root)
    path = (runs_dir / f"{run_id}.state.json").resolve()
    if not str(path).startswith(str(runs_dir.resolve())):
        raise ValueError(f"Run ID resolves outside runs directory: {run_id!r}")
    if not path.exists():
        raise FileNotFoundError(f"Run state not found: {path}")
    data = json.loads(path.read_text(encoding="utf-8"))
    return RunState(**data)


def save_pause_state(
    project_root: Path, plan_id: str, sprint: str,
    completed_tasks: list[str], paused_task_id: str,
    max_parallel: int = 3, hooks_advisory: bool = False,
    branch_auto_created: bool = False, parent_branch: str = "",
    backlog_path: str = "", active_branch: str = "",
) -> str:
    """Create and save a pause state, returning the run_id."""
    ts = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S")
    suffix = os.urandom(3).hex()
    run_id = f"engage-sprint-{sprint}-{ts}-{suffix}"
    state = RunState(
        run_id=run_id, plan_id=plan_id, sprint=sprint,
        completed_tasks=list(completed_tasks),
        paused_task_id=paused_task_id,
        max_parallel=max_parallel, hooks_advisory=hooks_advisory,
        branch_auto_created=branch_auto_created,
        parent_branch=parent_branch,
        backlog_path=backlog_path, active_branch=active_branch,
    )
    save_run_state(project_root, state)
    return run_id


def verify_paused_task_done(project_root: Path, state: RunState) -> None:
    """Check that the paused task's on-disk status is 'done'.

    Raises ValueError with a clear message if still pending.
    """
    task_file = (
        project_root / ".paircoder" / "tasks"
        / f"{state.paused_task_id}.task.md"
    )
    if not task_file.exists():
        raise FileNotFoundError(
            f"Task file not found: {task_file}",
        )
    text = task_file.read_text(encoding="utf-8")
    match = re.match(r"^---\s*\n(.*?)\n---", text, re.DOTALL)
    if not match:
        raise ValueError(f"No frontmatter in {task_file}")
    meta = yaml.safe_load(match.group(1)) or {}
    status = meta.get("status", "pending")
    if status != "done":
        raise ValueError(
            f"Task {state.paused_task_id} is still '{status}'. "
            f"Complete it first: bpsai-pair task update "
            f"{state.paused_task_id} --status done",
        )
