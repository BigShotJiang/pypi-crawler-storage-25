"""Parse backlog markdown into structured task data."""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class ParsedTask:
    """A task extracted from a backlog document."""

    id: str
    title: str
    complexity: int
    priority: str
    description: str
    ac_items: list[str] = field(default_factory=list)
    depends_on: list[str] = field(default_factory=list)
    phase: int = 1
    external_tools: list[str] = field(default_factory=list)
    requires: str = "autonomous"


@dataclass
class ParsedBacklog:
    """A fully parsed backlog document."""

    tasks: list[ParsedTask] = field(default_factory=list)


# Flexible task header: accepts em/en dash, --, or spaced hyphen as separator.
# Complexity: | Cx: N |, | Ncx |, (Ncx), (Cx: N), or trailing Ncx.
# Priority: P0-P9, case-insensitive, optional space before digit.
_TASK_HEADER = re.compile(
    r"^###\s+([A-Za-z][\w.]*\d[\w.]*)\s*(?:—|–|--)\s*(.+)",
)
# Fallback: spaced single hyphen  (### T1 - Title ...)
_TASK_HEADER_HYPHEN = re.compile(
    r"^###\s+([A-Za-z][\w.]*\d[\w.]*)\s+-\s+(.+)",
)
_PHASE_HEADER = re.compile(r"^###\s+Phase\s+(\d+):")
_AC_ITEM = re.compile(r"^\s*-\s*\[[ x]\]\s*(.+)$")
_DEPENDS_ON = re.compile(r"\*\*Depends on:\*\*\s*(.+)", re.IGNORECASE)
_EXTERNAL_TOOLS = re.compile(r"\*\*External tools:\*\*\s*(.+)", re.IGNORECASE)
_REQUIRES = re.compile(r"\*\*Requires:\*\*\s*(.+)", re.IGNORECASE)
from bpsai_pair.orchestration.backlog_validation import (  # noqa: F401
    _BOLD_FIELD, _KNOWN_FIELDS, validate_fields as _validate_fields,
)

# Sub-patterns for extracting complexity and priority from the tail of a header.
_CX_PATTERNS = [
    re.compile(r"\|\s*[Cc][Xx]:\s*(\d+)\s*\|"),     # | Cx: 5 |
    re.compile(r"\(\s*[Cc][Xx]:\s*(\d+)\s*\)"),      # (Cx: 5)
    re.compile(r"\|\s*(\d+)\s*[Cc][Xx]\s*\|"),       # | 5cx |
    re.compile(r"\(\s*(\d+)\s*[Cc][Xx]\s*\)"),       # (5cx)
    re.compile(r"(?:^|\s)(\d+)\s*[Cc][Xx](?:\s|$)"), # trailing 5cx
]
_PRIORITY_PATTERN = re.compile(r"[Pp]\s?(\d)", re.IGNORECASE)


def _match_task_header(line: str) -> re.Match | None:
    """Try to match a task header line with flexible separators."""
    m = _TASK_HEADER.match(line)
    if m:
        return m
    return _TASK_HEADER_HYPHEN.match(line)


def _parse_header_tail(tail: str) -> tuple[str, int | None, str | None]:
    """Extract title, complexity, and priority from the text after the separator.

    Returns (title, complexity_or_None, priority_or_None).
    """
    rest = tail.strip()

    # Extract complexity
    complexity: int | None = None
    for pat in _CX_PATTERNS:
        m = pat.search(rest)
        if m:
            complexity = int(m.group(1))
            rest = rest[:m.start()] + rest[m.end():]
            break

    # Extract priority
    priority: str | None = None
    pm = _PRIORITY_PATTERN.search(rest)
    if pm:
        priority = f"P{pm.group(1)}"
        rest = rest[:pm.start()] + rest[pm.end():]

    # Clean up title: strip pipes, whitespace, stray characters
    title = rest.strip().strip("|").strip()

    return title, complexity, priority


class BacklogParser:
    """Parses backlog markdown into structured data."""

    @staticmethod
    def parse(path: Path) -> ParsedBacklog:
        """Parse a backlog markdown file into a ParsedBacklog."""
        content = path.read_text(encoding="utf-8")
        lines = content.split("\n")
        tasks: list[ParsedTask] = []
        current_phase = 1
        i = 0

        while i < len(lines):
            line = lines[i]

            phase_match = _PHASE_HEADER.match(line)
            if phase_match:
                current_phase = int(phase_match.group(1))
                i += 1
                continue

            task_match = _match_task_header(line)
            if task_match:
                task, i = _parse_task_block(lines, i, task_match, current_phase)
                tasks.append(task)
                continue

            i += 1

        return ParsedBacklog(tasks=tasks)


def _parse_task_block(
    lines: list[str], start: int, header_match: re.Match, phase: int
) -> tuple[ParsedTask, int]:
    """Parse a single task block starting from its header line."""
    task_id = header_match.group(1)
    tail = header_match.group(2)
    title, complexity_val, priority_val = _parse_header_tail(tail)
    complexity = complexity_val if complexity_val is not None else 0
    priority = priority_val if priority_val is not None else "P2"

    body_lines = _collect_block_lines(lines, start + 1)
    _validate_fields(body_lines, start + 1)  # from backlog_validation
    description = _extract_description(body_lines)
    ac_items = _extract_ac_items(body_lines)
    depends_on = _extract_depends_on(body_lines)
    external_tools = _extract_external_tools(body_lines)
    requires_val = _extract_requires(body_lines)

    # Implicit rule: non-empty external_tools → requires: human
    if requires_val is None:
        requires_val = "human" if external_tools else "autonomous"

    return ParsedTask(
        id=task_id, title=title, complexity=complexity, priority=priority,
        description=description, ac_items=ac_items, depends_on=depends_on,
        phase=phase, external_tools=external_tools, requires=requires_val,
    ), start + 1 + len(body_lines)


def _collect_block_lines(lines: list[str], start: int) -> list[str]:
    """Collect lines belonging to a task block until the next header."""
    block: list[str] = []
    for i in range(start, len(lines)):
        if _match_task_header(lines[i]) or _PHASE_HEADER.match(lines[i]):
            break
        block.append(lines[i])
    return block


def _extract_description(lines: list[str]) -> str:
    """Extract description text from task block lines."""
    desc_lines: list[str] = []
    capturing = False
    for line in lines:
        if line.strip().startswith("**Description:**"):
            desc_lines.append(line.split("**Description:**", 1)[1].strip())
            capturing = True
            continue
        if capturing:
            if line.strip().startswith("**"):
                break
            if line.strip():
                desc_lines.append(line.strip())
    return " ".join(desc_lines).strip()


def _extract_ac_items(lines: list[str]) -> list[str]:
    """Extract acceptance criteria checkboxes from task block."""
    items: list[str] = []
    in_ac = False
    for line in lines:
        if line.strip().startswith("**AC:**"):
            in_ac = True
            continue
        if in_ac:
            match = _AC_ITEM.match(line)
            if match:
                items.append(match.group(1).strip())
            elif line.strip().startswith("**") or _match_task_header(line) or _PHASE_HEADER.match(line):
                in_ac = False
    return items


def _extract_depends_on(lines: list[str]) -> list[str]:
    """Extract dependency references from task block."""
    for line in lines:
        match = _DEPENDS_ON.search(line)
        if match:
            text = match.group(1).strip()
            if text.lower() not in ("none", "n/a", ""):
                return re.findall(r"[A-Za-z][\w]*\.?\d[\w.]*", text)
    return []


def _extract_external_tools(lines: list[str]) -> list[str]:
    """Extract external tool names from task block."""
    for line in lines:
        match = _EXTERNAL_TOOLS.search(line)
        if match:
            raw = match.group(1).strip()
            return [t.strip() for t in raw.split(",") if t.strip()]
    return []


def _extract_requires(lines: list[str]) -> str | None:
    """Extract requires value from task block.  Returns None if absent."""
    for line in lines:
        match = _REQUIRES.search(line)
        if match:
            return match.group(1).strip().lower()
    return None


