"""Headless runner -- task_runner callback for SprintExecutor."""
from __future__ import annotations

import logging
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable

from bpsai_pair.intent_gate.approval_gate import ApprovalGate
from bpsai_pair.intent_gate.dispatch_guard import check_headless_approval
from bpsai_pair.orchestration.headless import HeadlessResponse, HeadlessSession, PermissionMode
from bpsai_pair.orchestration.model_routing import resolve_model_for_complexity
from bpsai_pair.planning.task_parser import parse_frontmatter
from bpsai_pair.telemetry.schema import (
    Outcome, PrivacyLevel, TelemetryRecord, TokenUsage, classify_fail_detail,
)
from bpsai_pair.telemetry.store import TelemetryStore

logger = logging.getLogger(__name__)


def _build_task_prompt(task_id: str, task_content: str) -> str:
    """Build the prompt that invokes /start-task with the task file content."""
    return f"/start-task {task_id}\n\n## Task File\n\n{task_content}"


def _build_telemetry_record(
    task_id: str,
    response: HeadlessResponse,
    frontmatter: dict[str, Any],
    repo: str,
) -> TelemetryRecord:
    """Build a TelemetryRecord from a HeadlessResponse and task frontmatter."""
    outcome = Outcome.FAIL if response.is_error else Outcome.SUCCESS
    outcome_detail = classify_fail_detail(response.error_message) if response.is_error else None
    return TelemetryRecord(
        task_id=task_id,
        task_type=frontmatter.get("type", "unknown"),
        repo=repo,
        model=response.model,
        tokens=TokenUsage(input=response.input_tokens, output=response.output_tokens),
        duration_seconds=int(response.duration_seconds),
        human_interventions=0,
        compactions=0,
        outcome=outcome,
        timestamp=datetime.now(timezone.utc),
        privacy_level=PrivacyLevel.STANDARD,
        error_context=response.error_message if response.is_error else None,
        session_id=response.session_id,
        sprint=frontmatter.get("sprint"),
        complexity=frontmatter.get("complexity"),
        outcome_detail=outcome_detail,
        features_used=["headless_runner"],
    )


def _emit_sprint_summary(
    store: TelemetryStore,
    sprint: str,
    results: list[dict[str, Any]],
    repo: str,
) -> None:
    """Emit a sprint-level summary telemetry record."""
    total_duration = sum(r["duration"] for r in results)
    passed = sum(1 for r in results if r["success"])
    total = len(results)

    if passed == total:
        outcome = Outcome.SUCCESS
    elif passed == 0:
        outcome = Outcome.FAIL
    else:
        outcome = Outcome.PARTIAL

    record = TelemetryRecord(
        task_id=f"sprint:{sprint}",
        task_type="sprint_summary",
        repo=repo,
        model="headless_runner",
        tokens=TokenUsage(input=0, output=0),
        duration_seconds=int(total_duration),
        human_interventions=0,
        compactions=0,
        outcome=outcome,
        timestamp=datetime.now(timezone.utc),
        privacy_level=PrivacyLevel.STANDARD,
        sprint=sprint,
        features_used=["headless_runner"],
    )
    store.append(record)


def _make_headless_runner(
    project_root: Path,
    permission_mode: "PermissionMode" = "auto",
    allowed_tools: list[str] | None = None,
    routing_config: dict[str, dict] | None = None,
    approved_by: str | None = None,
    sprint_config: Any | None = None,
) -> Callable[[str], bool]:
    """Return a task_runner callback for headless Claude Code execution."""
    # Resolve to absolute path to prevent CWD drift in headless sessions.
    # Without this, agent memory files can land in wrong directories
    # (e.g. .paircoder/context/.claude/ instead of .claude/agent-memory/).
    project_root = project_root.resolve()
    tasks_dir = project_root / ".paircoder" / "tasks"

    # IG-004: Create a single shared ApprovalGate for the runner lifecycle.
    # Previous code created a new gate per task, wasting resources and
    # losing approval state between tasks.
    shared_gate: ApprovalGate | None = None
    if approved_by is not None:
        telemetry_dir = project_root / ".paircoder" / "telemetry"
        shared_gate = ApprovalGate(telemetry_dir=telemetry_dir)

    def _run_task(task_id: str) -> bool:
        import typer

        task_path = tasks_dir / f"{task_id}.task.md"
        if not task_path.exists():
            typer.echo(f"Task {task_id} ERROR: task file not found: {task_path}")
            return False

        # Approval gate — fires before subprocess launch for dispatch paths.
        # Uses the shared gate instance from the factory closure.
        if shared_gate is not None:
            gate_result = check_headless_approval(shared_gate, approved_by=approved_by)
            if gate_result.blocked:
                typer.echo(f"Task {task_id} BLOCKED: {gate_result.reason}")
                return False

        task_content = task_path.read_text(encoding="utf-8")
        frontmatter, _ = parse_frontmatter(task_content)
        prompt = _build_task_prompt(task_id, task_content)

        # Append targeted test instruction from SprintConfig if available
        if sprint_config and getattr(sprint_config, "test_instruction", ""):
            prompt += f"\n\n## Test Instruction\n\n{sprint_config.test_instruction}"

        # Resolve model from routing config based on task complexity
        model: str | None = None
        if routing_config:
            complexity = frontmatter.get("complexity", 0)
            model = resolve_model_for_complexity(complexity, routing_config)

        mode_label = f"allowedTools={','.join(allowed_tools)}" if allowed_tools else permission_mode
        typer.echo(f"Task {task_id} running with {mode_label}")
        session = HeadlessSession(
            permission_mode=permission_mode,
            allowed_tools=allowed_tools,
            working_dir=project_root,
            model=model,
        )
        response = session.invoke(prompt)

        # Emit telemetry for every headless task
        _emit_task_telemetry(project_root, task_id, response, frontmatter)

        if response.is_error:
            typer.echo(f"Task {task_id} FAILED: {response.error_message}")
            return False

        typer.echo(f"Task {task_id} DONE")
        return True

    return _run_task


def _emit_task_telemetry(
    project_root: Path,
    task_id: str,
    response: HeadlessResponse,
    frontmatter: dict[str, Any],
) -> None:
    """Emit a telemetry record for a headless task invocation."""
    try:
        store = TelemetryStore(project_root)
        repo = project_root.name or "unknown"
        record = _build_telemetry_record(task_id, response, frontmatter, repo)
        store.append(record)
        logger.debug("Telemetry emitted for task %s", task_id)
    except Exception as e:
        logger.warning("Telemetry emission failed (non-blocking): %s", e)
