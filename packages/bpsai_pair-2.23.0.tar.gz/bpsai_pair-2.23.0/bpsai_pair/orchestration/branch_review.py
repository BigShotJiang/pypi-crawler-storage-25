"""Branch review -- reviews current branch diff against base.

Pre-PR validation: "is this ready to merge?" Uses the same agent
dispatch rules as PR review but operates on ``git diff <base>...HEAD``.
"""

from __future__ import annotations

import logging
import subprocess
from pathlib import Path
from typing import Any

from bpsai_pair.orchestration.pr_review import calculate_diff_size
from bpsai_pair.orchestration.review_common import (
    _LARGE_DIFF_FILES,
    _LARGE_DIFF_LINES,
    _dispatch_agents,
    classify_review_action,
)
from bpsai_pair.orchestration.review_output import combine_findings

logger = logging.getLogger(__name__)


def detect_base_branch(project_root: Path) -> str:
    """Auto-detect base branch: prefer ``dev``, fall back to ``main``."""
    try:
        result = subprocess.run(
            ["git", "branch", "--list", "--format=%(refname:short)"],
            cwd=str(project_root),
            capture_output=True, text=True, timeout=10,
        )
        branches = result.stdout
        if "dev" in branches.split():
            return "dev"
    except (subprocess.TimeoutExpired, FileNotFoundError, OSError):
        pass
    return "main"


def get_branch_diff(project_root: Path, base: str) -> str:
    """Fetch the diff of current branch against *base* via ``git diff``."""
    try:
        result = subprocess.run(
            ["git", "diff", f"{base}...HEAD"],
            cwd=str(project_root),
            capture_output=True, text=True, timeout=30,
        )
        return result.stdout
    except (subprocess.TimeoutExpired, FileNotFoundError, OSError):
        logger.warning("Failed to get branch diff against %s", base)
        return ""


def review_branch(
    project_root: Path, base: str | None = None,
) -> dict[str, Any]:
    """Review the current branch diff against base branch."""
    base_branch = base or detect_base_branch(project_root)
    diff = get_branch_diff(project_root, base_branch)

    if not diff:
        return {
            "action": "skipped", "reason": "empty_diff", "dispatched": False,
            "findings": "", "errors": 0, "agents": [],
            "lines_changed": 0, "files_changed": 0,
            "base_branch": base_branch,
        }

    lines_changed, files_changed = calculate_diff_size(diff)
    agents = ["nayru", "laverna"]
    if lines_changed > _LARGE_DIFF_LINES or files_changed > _LARGE_DIFF_FILES:
        agents.append("vaivora")

    findings, errors = _dispatch_agents(project_root, diff, agents)
    combined = combine_findings(findings)

    # If every agent failed, treat as error -- never auto-approve.
    all_failed = errors > 0 and errors == len(agents)
    if all_failed:
        return {
            "action": "error", "findings": combined, "errors": errors,
            "dispatched": True, "agents": agents,
            "lines_changed": lines_changed, "files_changed": files_changed,
            "base_branch": base_branch,
        }

    action = classify_review_action(combined)

    return {
        "action": action, "findings": combined, "errors": errors,
        "dispatched": True, "agents": agents,
        "lines_changed": lines_changed, "files_changed": files_changed,
        "base_branch": base_branch,
    }
