"""Agent mythology display names for review dispatch.

Reads ``display_name`` from ``.claude/agents/<role>.md`` frontmatter
and provides formatting helpers for dispatch logging.
"""

from __future__ import annotations

import logging
import re
from pathlib import Path

logger = logging.getLogger(__name__)


def _read_frontmatter_field(file_path: Path, field: str) -> str | None:
    """Read a single YAML frontmatter field from a markdown file."""
    try:
        text = file_path.read_text(encoding="utf-8")
    except (FileNotFoundError, OSError):
        return None

    pattern = re.compile(rf"^{re.escape(field)}:\s*(.+)$", re.MULTILINE)
    match = pattern.search(text)
    return match.group(1).strip() if match else None


def get_agent_display_name(project_root: Path, role: str) -> str:
    """Get the mythology display_name for an agent role.

    Falls back to the role name if no display_name is set or the
    agent file does not exist.
    """
    agent_file = project_root / ".claude" / "agents" / f"{role}.md"
    name = _read_frontmatter_field(agent_file, "display_name")
    return name or role


def get_all_agent_display_names(project_root: Path) -> dict[str, str]:
    """Return a mapping of role -> display_name for all agents."""
    agents_dir = project_root / ".claude" / "agents"
    names: dict[str, str] = {}

    if not agents_dir.is_dir():
        return names

    for f in agents_dir.glob("*.md"):
        if f.is_symlink():
            continue
        role = f.stem
        display = _read_frontmatter_field(f, "display_name")
        names[role] = display or role

    return names


def format_dispatch_message(project_root: Path, role: str) -> str:
    """Format a dispatch log message with mythology name."""
    display = get_agent_display_name(project_root, role)
    if display != role:
        return f"Dispatching {display} ({role})..."
    return f"Dispatching {role}..."
