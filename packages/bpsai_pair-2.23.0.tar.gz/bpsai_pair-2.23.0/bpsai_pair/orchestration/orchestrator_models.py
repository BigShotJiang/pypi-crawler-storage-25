"""
Data models for the orchestrator service.

Contains enums, type aliases, and dataclasses used by the Orchestrator
for task routing and agent assignment decisions.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Literal, Optional


class TaskType(Enum):
    """Types of tasks for routing decisions."""

    DESIGN = "design"
    IMPLEMENT = "implement"
    REVIEW = "review"
    REFACTOR = "refactor"
    FIX = "fix"
    TEST = "test"
    DOCUMENT = "document"


class TaskComplexity(Enum):
    """Complexity levels for task classification."""

    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"


class TaskScope(Enum):
    """Scope of task for routing decisions."""

    SINGLE_FILE = "single-file"
    MULTI_FILE = "multi-file"
    CROSS_MODULE = "cross-module"


AgentName = Literal["claude-code", "cursor"]


@dataclass
class AgentCapabilities:
    """Capabilities of an AI coding agent."""

    name: AgentName
    strengths: list[str] = field(default_factory=list)
    weaknesses: list[str] = field(default_factory=list)
    cost_per_1k_tokens: float = 0.01
    context_limit: int = 100000
    availability: Literal["local", "optional", "cloud"] = "local"


@dataclass
class TaskCharacteristics:
    """Characteristics of a task for routing decisions."""

    task_id: str
    task_type: TaskType = TaskType.IMPLEMENT
    complexity: TaskComplexity = TaskComplexity.MEDIUM
    scope: TaskScope = TaskScope.SINGLE_FILE
    risk: Literal["low", "medium", "high"] = "medium"
    estimated_tokens: int = 5000
    requires_reasoning: bool = False
    requires_iteration: bool = False
    description: str = ""


@dataclass
class Assignment:
    """An assignment of a task to an agent."""

    task_id: str
    agent: AgentName
    permission_mode: str = "auto"
    created_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    status: Literal["pending", "running", "completed", "failed"] = "pending"
    result: Optional[Any] = None
    score: float = 0.0
    reasoning: str = ""


@dataclass
class RoutingDecision:
    """A routing decision with scoring details."""

    agent: AgentName
    score: float
    reasoning: list[str] = field(default_factory=list)
