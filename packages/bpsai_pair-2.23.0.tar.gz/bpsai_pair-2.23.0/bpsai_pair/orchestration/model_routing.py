"""Model routing by task complexity.

Maps a numeric complexity score to a model name using the
``routing.by_complexity`` section of config.yaml.
"""

from __future__ import annotations

from typing import Optional


def resolve_model_for_complexity(
    complexity: int | str | None,
    by_complexity: dict[str, dict],
) -> Optional[str]:
    """Return the model name for a given complexity score.

    Tiers are sorted by ``max_score`` ascending. The first tier whose
    ``max_score`` >= *complexity* wins. Returns ``None`` when no tier
    matches or the config is empty.

    Args:
        complexity: Numeric complexity score (0-100). Non-integer
            values are coerced to 0 with a warning.
        by_complexity: Mapping of tier names to
            ``{"max_score": int, "model": str}``.

    Returns:
        Model identifier string, or None if no tier matches.
    """
    if not by_complexity:
        return None

    # Validate and coerce complexity
    try:
        complexity = int(complexity or 0)
    except (TypeError, ValueError):
        import logging
        logging.getLogger(__name__).warning(
            "Invalid complexity value %r, defaulting to 0", complexity,
        )
        complexity = 0
    complexity = max(0, min(100, complexity))

    sorted_tiers = sorted(
        by_complexity.values(),
        key=lambda t: t.get("max_score", 0),
    )

    for tier in sorted_tiers:
        if complexity <= tier.get("max_score", 0):
            return tier.get("model")

    return None
