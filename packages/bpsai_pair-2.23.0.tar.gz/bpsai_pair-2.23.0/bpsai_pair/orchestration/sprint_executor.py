"""Sprint executor -- runs tasks phase-by-phase with circuit breaker."""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable

import typer

from bpsai_pair.orchestration.dependency_resolver import (
    DependencyBlockedError,
    verify_dependencies_on_disk,
)
from bpsai_pair.orchestration.plan_graph_models import (
    ExecutionGraph,
    ExecutionMode,
    ExecutionPhase,
    phase_label,
)
from bpsai_pair.orchestration.output_verifier import check_and_emit_no_output
from bpsai_pair.orchestration.sprint_commit import commit_task, complete_task_lifecycle, fail_task_lifecycle
from bpsai_pair.orchestration.sprint_signals import make_default_task_hook, record_task_failure
from bpsai_pair.orchestration.targeted_tests import (
    build_driver_test_instruction,
    resolve_test_targets,
)

logger = logging.getLogger(__name__)


@dataclass
class SprintConfig:
    """Configuration for sprint execution."""

    max_parallel: int = 3
    task_timeout_minutes: int = 30
    circuit_breaker_threshold: float = 0.5
    max_review_iterations: int = 3
    permission_mode: str = "auto"
    allowed_tools: list[str] | None = None
    targeted_tests: bool = True
    test_instruction: str = ""
    hooks_advisory: bool = False


@dataclass
class SprintResult:
    """Result of a sprint execution."""

    completed_tasks: list[str] = field(default_factory=list)
    failed_tasks: list[str] = field(default_factory=list)
    hook_failed_tasks: list[str] = field(default_factory=list)
    blocked_tasks: list[str] = field(default_factory=list)
    phases_completed: int = 0
    total_complexity: int = 0
    circuit_breaker_triggered: bool = False
    paused_task: str | None = None
    failure_reasons: dict[str, str] = field(default_factory=dict)
    review_dispatches: list[dict[str, Any]] = field(default_factory=list)
    task_reviews: list[dict[str, Any]] = field(default_factory=list)
    findings_loops: list[dict[str, Any]] = field(default_factory=list)
    unresolved_findings: list[dict[str, Any]] = field(default_factory=list)


class SprintExecutor:
    """Executes an ExecutionGraph phase-by-phase with circuit breaker."""

    def __init__(
        self,
        project_root: Path,
        graph: ExecutionGraph,
        config: SprintConfig | None = None,
        task_runner: Callable[[str], bool] | None = None,
        review_hook: Callable[[Path, list[str]], dict[str, Any]] | None = None,
        task_complete_hook: Callable[[str, str, float], None] | None = None,
        task_review_hook: Callable[[Path, str], dict[str, Any]] | None = None,
    ) -> None:
        # OP-004: resolve symlinks/relative paths
        self._project_root = Path(project_root).resolve()
        self._graph = graph
        self._config = config or SprintConfig()
        if task_runner is None:
            logger.warning("No task runner configured")
        self._task_runner = task_runner or (lambda tid: False)
        self._review_hook = review_hook
        self._task_complete_hook = task_complete_hook
        self._task_review_hook = task_review_hook

    def execute(self) -> SprintResult:
        """Run all phases, returning aggregate result."""
        self._task_review_results: list[dict[str, Any]] = []
        self._findings_loop_results: list[dict[str, Any]] = []
        self._unresolved_findings: list[dict[str, Any]] = []
        self._failure_reasons: dict[str, str] = {}
        self._dep_status_cache: dict[str, str] = {}
        if self._config.targeted_tests:
            targets = resolve_test_targets(self._project_root)
            self._config.test_instruction = build_driver_test_instruction(targets)
        result = SprintResult(total_complexity=self._graph.total_complexity())

        for idx, phase in enumerate(self._graph.phases):
            label = phase_label(phase, idx)
            mode = "parallel" if phase.execution == ExecutionMode.PARALLEL else "sequential"
            typer.echo(f"\n--- Phase {label} ({len(phase.task_ids)} tasks, {mode}) ---")

            # Check for human-gated tasks before dispatching the phase
            paused_id = self._graph.first_human_gated(phase.task_ids)
            if paused_id:
                result.paused_task = paused_id
                typer.echo(f"PAUSED: Task {paused_id} requires human intervention")
                break

            completed, failed, hook_failed = self._execute_phase(phase)
            result.completed_tasks.extend(completed)
            result.failed_tasks.extend(failed)
            result.hook_failed_tasks.extend(hook_failed)
            result.phases_completed += 1
            typer.echo(
                f"Phase {label}: {len(completed)} done, "
                f"{len(failed)} failed, {len(hook_failed)} hook-failed",
            )

            if completed and self._review_hook:
                self._dispatch_phase_review(label, completed, result)

            total = len(completed) + len(failed) + len(hook_failed)
            if total > 0 and self._check_circuit_breaker(
                len(completed), len(failed) + len(hook_failed),
            ):
                result.circuit_breaker_triggered = True
                typer.echo(f"Circuit breaker triggered after phase {label}")
                break

        result.failure_reasons = self._failure_reasons
        result.task_reviews = self._task_review_results
        result.findings_loops = self._findings_loop_results
        result.unresolved_findings = self._unresolved_findings
        return result

    def _execute_phase(
        self, phase: ExecutionPhase,
    ) -> tuple[list[str], list[str], list[str]]:
        """Execute a single phase. Returns (completed, failed, hook_failed)."""
        self._dep_status_cache.clear()
        completed: list[str] = []
        failed: list[str] = []
        hook_failed: list[str] = []

        if phase.execution == ExecutionMode.PARALLEL:
            self._run_parallel(phase.task_ids, completed, failed, hook_failed)
        else:
            self._run_sequential(phase.task_ids, completed, failed, hook_failed)

        return completed, failed, hook_failed

    def _run_sequential(
        self,
        task_ids: list[str],
        completed: list[str],
        failed: list[str],
        hook_failed: list[str],
    ) -> None:
        """Run tasks one at a time in order."""
        for task_id in task_ids:
            self._run_single(task_id, completed, failed, hook_failed)

    def _filter_dispatchable(
        self, task_ids: list[str], failed: list[str],
    ) -> list[str]:
        """Pre-check on-disk deps; return dispatchable IDs, append blocked to failed."""
        dispatchable: list[str] = []
        for tid in task_ids:
            try:
                verify_dependencies_on_disk(
                    self._project_root, tid, self._graph,
                    status_cache=self._dep_status_cache,
                )
                dispatchable.append(tid)
            except DependencyBlockedError as exc:
                logger.error("Dependency blocked: %s", exc)
                typer.echo(f"BLOCKED: {exc}")
                failed.append(tid)
        return dispatchable

    def _run_parallel(
        self,
        task_ids: list[str],
        completed: list[str],
        failed: list[str],
        hook_failed: list[str],
    ) -> None:
        """Run tasks in parallel up to max_parallel."""
        from concurrent.futures import ThreadPoolExecutor, as_completed

        dispatchable = self._filter_dispatchable(task_ids, failed)
        if not dispatchable:
            return
        max_workers = min(self._config.max_parallel, len(dispatchable))

        def _timed_run(tid: str) -> tuple[str, bool, float]:
            t0 = time.monotonic()
            result = self._task_runner(tid)
            return tid, result, time.monotonic() - t0

        with ThreadPoolExecutor(max_workers=max_workers) as pool:
            futures = {
                pool.submit(_timed_run, tid): tid
                for tid in dispatchable
            }
            for future in as_completed(futures):
                tid = futures[future]
                try:
                    _, success, duration = future.result()
                except Exception as exc:
                    logger.error("Task %s raised: %s", tid, exc)
                    record_task_failure(self._project_root, tid, f"exception: {exc}", failed, self._failure_reasons)
                    fail_task_lifecycle(self._project_root, tid, f"exception: {exc}")
                    try:
                        self._fire_task_hook(tid, "failed", 0.0)
                    except Exception:
                        logger.warning("task_complete_hook failed for %s", tid, exc_info=True)
                    continue
                self._handle_task_outcome(
                    tid, success, duration, completed, failed, hook_failed,
                )

    def _handle_task_outcome(
        self,
        task_id: str,
        success: bool,
        duration: float,
        completed: list[str],
        failed: list[str],
        hook_failed: list[str],
    ) -> None:
        """Classify a task outcome and run post-task hooks."""
        if success:
            self._graph.mark_done(task_id)
            completed.append(task_id)
            self._do_commit(task_id)
            if check_and_emit_no_output(self._project_root, task_id):
                completed.remove(task_id)
                record_task_failure(self._project_root, task_id, "no_meaningful_output", failed, self._failure_reasons)
                fail_task_lifecycle(self._project_root, task_id, "no_meaningful_output")
                try:
                    self._fire_task_hook(task_id, "failed", duration)
                except Exception:
                    logger.warning("task_complete_hook failed for %s", task_id, exc_info=True)
                return
            review_failed = self._review_and_fix(task_id)
            if review_failed:
                completed.remove(task_id)
                record_task_failure(self._project_root, task_id, "review_loop_exhausted", failed, self._failure_reasons)
                fail_task_lifecycle(self._project_root, task_id, "review_loop_exhausted")
                try:
                    self._fire_task_hook(task_id, "failed", duration)
                except Exception:
                    logger.warning("task_complete_hook failed for %s", task_id, exc_info=True)
            else:
                hooks_broke = self._run_lifecycle_hooks(task_id, duration)
                if hooks_broke:
                    completed.remove(task_id)
                    hook_failed.append(task_id)
                    node = self._graph.nodes.get(task_id)
                    if node:
                        node.status = "hook_failed"
        else:
            record_task_failure(self._project_root, task_id, "task_runner_returned_false", failed, self._failure_reasons)
            fail_task_lifecycle(self._project_root, task_id, "task_runner_returned_false")
            try:
                self._fire_task_hook(task_id, "failed", duration)
            except Exception:
                logger.warning("task_complete_hook failed for %s", task_id, exc_info=True)


    def _run_single(
        self,
        task_id: str,
        completed: list[str],
        failed: list[str],
        hook_failed: list[str],
    ) -> None:
        """Run a single task and classify result."""
        node = self._graph.nodes.get(task_id)
        if node and node.status == "done":
            return
        try:
            verify_dependencies_on_disk(
                self._project_root, task_id, self._graph,
                status_cache=self._dep_status_cache,
            )
        except DependencyBlockedError as exc:
            logger.error("Dependency blocked: %s", exc)
            typer.echo(f"BLOCKED: {exc}")
            failed.append(task_id)
            return

        logger.info("Running task %s", task_id)
        t0 = time.monotonic()
        success = self._task_runner(task_id)
        duration = time.monotonic() - t0
        self._handle_task_outcome(
            task_id, success, duration, completed, failed, hook_failed,
        )

    def _review_and_fix(self, task_id: str) -> bool:
        """Invoke per-task reviewer; run fix loop if blocking findings.

        Returns True when review loop exhausted without resolving.
        """
        from bpsai_pair.orchestration.sprint_review_helpers import review_and_fix

        return review_and_fix(
            project_root=self._project_root,
            task_id=task_id,
            task_review_hook=self._task_review_hook,
            task_review_results=self._task_review_results,
            findings_loop_results=self._findings_loop_results,
            unresolved_findings=self._unresolved_findings,
            permission_mode=self._config.permission_mode,
            allowed_tools=self._config.allowed_tools,
            max_review_iterations=self._config.max_review_iterations,
        )

    def _dispatch_phase_review(
        self, label: str, completed: list[str], result: SprintResult,
    ) -> None:
        """Dispatch the review hook for a completed phase."""
        try:
            review_meta = self._review_hook(self._project_root, completed)
            result.review_dispatches.append(review_meta)
        except Exception:
            logger.warning("Review hook failed for phase %s", label, exc_info=True)
            result.review_dispatches.append({"dispatched": False, "error": "hook_exception"})

    def _do_commit(self, task_id: str) -> None:
        """Git add + commit after a successful task."""
        node = self._graph.nodes.get(task_id)
        title = node.title if node else ""
        commit_task(self._project_root, task_id, title)

    def _run_lifecycle_hooks(
        self, task_id: str, duration: float,
    ) -> bool:
        """Run lifecycle + task-complete hooks, returning True if task failed.

        When hooks_advisory is False (default), any hook exception causes
        the task to be marked as failed.  When True, exceptions are logged
        but the task remains completed (legacy behavior).
        """
        advisory = self._config.hooks_advisory
        hook_failed = False
        try:
            complete_task_lifecycle(self._project_root, task_id)
        except Exception:
            logger.warning(
                "complete_task_lifecycle failed for %s", task_id,
                exc_info=True,
            )
            if not advisory:
                hook_failed = True
        try:
            self._fire_task_hook(task_id, "failed" if hook_failed else "success", duration)
        except Exception:
            logger.warning("task_complete_hook failed for %s", task_id, exc_info=True)
            if not advisory:
                hook_failed = True
        return hook_failed

    def _fire_task_hook(
        self, task_id: str, outcome: str, duration: float,
    ) -> None:
        """Invoke the task_complete_hook if configured.

        Raises on failure so callers can decide whether to propagate.
        """
        if self._task_complete_hook is None:
            return
        self._task_complete_hook(task_id, outcome, duration)

    def _check_circuit_breaker(self, completed: int, failed: int) -> bool:
        """Return True if breaker should trip (failure ratio >= threshold)."""
        total = completed + failed
        if total == 0:
            return False
        failure_ratio = failed / total
        return failure_ratio >= self._config.circuit_breaker_threshold
