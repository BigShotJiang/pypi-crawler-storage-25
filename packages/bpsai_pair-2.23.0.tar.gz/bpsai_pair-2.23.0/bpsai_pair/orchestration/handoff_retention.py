"""
Handoff retention policy.

Cleans up consumed handoff files older than the retention period.
"""

from __future__ import annotations

import logging
import time
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

DEFAULT_RETENTION_DAYS = 30


def cleanup_old_handoffs(
    handoffs_dir: Path,
    retention_days: int = DEFAULT_RETENTION_DAYS,
) -> int:
    """Delete handoff files older than retention_days.

    Returns the number of files deleted.
    """
    if not handoffs_dir.exists():
        return 0

    cutoff = time.time() - (retention_days * 86400)
    deleted = 0

    for path in handoffs_dir.glob("*.json"):
        if path.stat().st_mtime < cutoff:
            path.unlink()
            deleted += 1
            logger.info("Deleted old handoff: %s", path.name)

    return deleted


def handoff_stats(handoffs_dir: Path) -> dict[str, Any]:
    """Get statistics about handoff files.

    Returns dict with count and oldest_days.
    """
    if not handoffs_dir.exists():
        return {"count": 0, "oldest_days": 0}

    files = list(handoffs_dir.glob("*.json"))
    if not files:
        return {"count": 0, "oldest_days": 0}

    now = time.time()
    oldest_mtime = min(f.stat().st_mtime for f in files)
    oldest_days = int((now - oldest_mtime) / 86400)

    return {"count": len(files), "oldest_days": oldest_days}
