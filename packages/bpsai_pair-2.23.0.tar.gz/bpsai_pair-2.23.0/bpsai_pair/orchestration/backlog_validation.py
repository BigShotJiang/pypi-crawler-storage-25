"""Backlog field validation helpers extracted from backlog_parser.

Contains edit-distance based field name validation for task blocks.
"""
from __future__ import annotations

import re

# Matches a bold-field declaration at the start of a line: **Name:** ...
_BOLD_FIELD = re.compile(r"^\s*\*\*([^*]+):\*\*")

# Known bold-field names (case-insensitive) used in task blocks.
_KNOWN_FIELDS = frozenset({
    "description", "ac", "depends on",
    "external tools", "requires",
})


def validate_fields(lines: list[str], line_offset: int) -> None:
    """Raise if a bold-field name looks like a typo of a known field.

    Uses edit-distance to distinguish genuine typos (``Require`` ->
    ``Requires``) from unrelated bold text (``Default mapping``).
    Only checks lines before the first ``---`` separator.
    """
    for idx, line in enumerate(lines):
        if line.strip() == "---":
            break
        m = _BOLD_FIELD.search(line)
        if m:
            name = m.group(1).strip().lower()
            if name in _KNOWN_FIELDS:
                continue
            nearest, dist = _nearest_field(name)
            if dist <= 2:
                lineno = line_offset + idx + 1  # 1-based
                raise ValueError(
                    f"Unknown field '**{m.group(1).strip()}:**' at "
                    f"line {lineno} (did you mean "
                    f"'**{nearest.title()}:**'?). Known fields: "
                    f"{', '.join(sorted(_KNOWN_FIELDS))}"
                )


def _nearest_field(name: str) -> tuple[str, int]:
    """Return (nearest known field, edit distance)."""
    best = ("", 999)
    for known in _KNOWN_FIELDS:
        d = _edit_distance(name, known)
        if d < best[1]:
            best = (known, d)
    return best


def _edit_distance(a: str, b: str) -> int:
    """Levenshtein distance between two strings."""
    if len(a) < len(b):
        return _edit_distance(b, a)
    if not b:
        return len(a)
    prev = list(range(len(b) + 1))
    for i, ca in enumerate(a):
        curr = [i + 1]
        for j, cb in enumerate(b):
            curr.append(min(
                prev[j + 1] + 1, curr[j] + 1, prev[j] + (ca != cb),
            ))
        prev = curr
    return prev[-1]
