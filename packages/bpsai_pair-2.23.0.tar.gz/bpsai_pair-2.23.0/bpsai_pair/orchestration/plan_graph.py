"""
Plan execution graph builder.

Reads plan YAML files and task markdown files to build a dependency-aware
execution graph for multi-agent dispatch.
"""

from __future__ import annotations

import logging
import re
from pathlib import Path
from typing import Any, Optional

import yaml

from .plan_graph_models import (
    ExecutionGraph,
    ExecutionMode,
    ExecutionPhase,
    TaskNode,
)

logger = logging.getLogger(__name__)


class PlanGraphBuilder:
    """Builds an ExecutionGraph from plan and task files on disk."""

    def __init__(self, project_root: Optional[Path] = None):
        self.project_root = project_root or Path.cwd()

    def build(self, plan_id: str) -> ExecutionGraph:
        """Build an execution graph from a plan file.

        Raises FileNotFoundError if the plan file does not exist.
        """
        plan_data = self._load_plan(plan_id)
        phases_data = plan_data.get("phases", [])
        plan_deps = plan_data.get("dependencies", {})

        phases: list[ExecutionPhase] = []
        nodes: dict[str, TaskNode] = {}
        all_deps: dict[str, list[str]] = {}

        for phase_data in phases_data:
            phase = self._build_phase(phase_data)
            phases.append(phase)

            for task_id in phase.task_ids:
                task_meta = self._load_task_meta(task_id)
                node = TaskNode(
                    task_id=task_id,
                    complexity=task_meta.get("complexity", 0),
                    depends_on=task_meta.get("depends_on", []) or [],
                    phase_id=phase.phase_id,
                    title=task_meta.get("title", ""),
                    requires=task_meta.get("requires", "autonomous"),
                )
                nodes[task_id] = node

                # Merge plan-level and task-level dependencies
                merged = set(plan_deps.get(task_id, []))
                merged.update(node.depends_on)
                if merged:
                    all_deps[task_id] = sorted(merged)

        self._validate_deps(nodes, all_deps)

        return ExecutionGraph(
            plan_id=plan_id,
            phases=phases,
            nodes=nodes,
            dependencies=all_deps,
        )

    def _validate_deps(
        self,
        nodes: dict[str, TaskNode],
        deps: dict[str, list[str]],
    ) -> None:
        """Validate dependency references exist and graph is acyclic.

        Raises ValueError if a dependency references a missing task ID
        or if the graph contains a cycle.
        """
        # Check for missing references
        for task_id, dep_list in deps.items():
            for dep in dep_list:
                if dep not in nodes:
                    raise ValueError(
                        f"Task '{task_id}' depends on '{dep}' "
                        f"which is not in the graph"
                    )

        # Topological sort to detect cycles (Kahn's algorithm)
        in_degree: dict[str, int] = {tid: 0 for tid in nodes}
        for task_id, dep_list in deps.items():
            in_degree[task_id] += len(dep_list)

        queue = [tid for tid, deg in in_degree.items() if deg == 0]
        visited = 0
        while queue:
            current = queue.pop(0)
            visited += 1
            # Find tasks that depend on current
            for task_id, dep_list in deps.items():
                if current in dep_list:
                    in_degree[task_id] -= 1
                    if in_degree[task_id] == 0:
                        queue.append(task_id)

        if visited < len(nodes):
            raise ValueError(
                "Dependency graph contains a cycle — "
                "no valid execution order exists"
            )

    def _load_plan(self, plan_id: str) -> dict[str, Any]:
        """Load a plan YAML file."""
        plans_dir = self.project_root / ".paircoder" / "plans"
        plan_file = plans_dir / f"{plan_id}.plan.yaml"
        if not plan_file.exists():
            raise FileNotFoundError(f"Plan file not found: {plan_file}")

        with open(plan_file, encoding="utf-8") as f:
            return yaml.safe_load(f) or {}

    def _build_phase(self, phase_data: dict[str, Any]) -> ExecutionPhase:
        """Build an ExecutionPhase from plan YAML data."""
        mode_str = phase_data.get("execution", "sequential")
        mode = ExecutionMode(mode_str)
        return ExecutionPhase(
            phase_id=phase_data.get("id", 0),
            name=phase_data.get("name", ""),
            task_ids=phase_data.get("tasks", []),
            execution=mode,
        )

    def _load_task_meta(self, task_id: str) -> dict[str, Any]:
        """Load task metadata from its markdown frontmatter."""
        tasks_dir = self.project_root / ".paircoder" / "tasks"
        task_file = tasks_dir / f"{task_id}.task.md"

        if not task_file.exists():
            logger.warning(f"Task file not found: {task_file}")
            return {}

        return self._parse_frontmatter(task_file)

    def _parse_frontmatter(self, path: Path) -> dict[str, Any]:
        """Parse YAML frontmatter from a markdown file."""
        text = path.read_text(encoding="utf-8")
        match = re.match(r"^---\s*\n(.*?)\n---", text, re.DOTALL)
        if not match:
            return {}

        try:
            return yaml.safe_load(match.group(1)) or {}
        except yaml.YAMLError:
            logger.warning(f"Failed to parse frontmatter: {path}")
            return {}
