"""Telemetry signal emission for sprint execution.

Handles writing structured signals to signals.jsonl for
task completion, review loop exhaustion, and other sprint events.
"""

from __future__ import annotations

import json
import logging
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable

logger = logging.getLogger(__name__)


def emit_signal(signals_path: Path, record: dict[str, Any]) -> None:
    """Append a signal record to signals.jsonl."""
    try:
        signals_path.parent.mkdir(parents=True, exist_ok=True)
        with open(signals_path, "a", encoding="utf-8") as f:
            f.write(json.dumps(record) + "\n")
    except Exception:
        logger.warning("Failed to emit signal: %s", record.get("signal_type", "unknown"))


def emit_review_loop_exhausted(
    project_root: Path, task_id: str, max_iterations: int,
) -> None:
    """Emit review_loop_exhausted telemetry signal."""
    signals_path = project_root / ".paircoder" / "telemetry" / "signals.jsonl"
    record = {
        "signal_type": "review_loop_exhausted",
        "severity": "high",
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "session_id": "",
        "payload": {
            "task_id": task_id,
            "max_iterations": max_iterations,
        },
        "source": "automated",
    }
    emit_signal(signals_path, record)


def emit_security_signal(
    signals_path: Path,
    blocked: bool,
    findings_count: int,
    action: str,
) -> None:
    """Emit sprint_security_blocked or sprint_security_passed signal."""
    signal_type = "sprint_security_blocked" if blocked else "sprint_security_passed"
    severity = "high" if blocked else "info"
    record = {
        "signal_type": signal_type,
        "severity": severity,
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "session_id": "",
        "payload": {
            "findings_count": findings_count,
            "action": action,
            "outcome": signal_type,
        },
        "source": "automated",
    }
    emit_signal(signals_path, record)


def emit_task_no_output(
    signals_path: Path,
    task_id: str,
    metadata_files: list[str],
) -> None:
    """Emit task_no_output signal at critical severity.

    Fired when a task completion produces no meaningful code changes —
    only metadata or an empty diff.
    """
    record = {
        "signal_type": "task_no_output",
        "severity": "critical",
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "session_id": "",
        "payload": {
            "task_id": task_id,
            "reason": "no_meaningful_output",
            "metadata_files": metadata_files,
        },
        "source": "automated",
    }
    emit_signal(signals_path, record)


def make_default_task_hook(project_root: Path) -> Callable[[str, str, float], None]:
    """Create a default task completion hook that writes to signals.jsonl."""
    signals_path = project_root / ".paircoder" / "telemetry" / "signals.jsonl"

    def _hook(task_id: str, outcome: str, duration: float) -> None:
        record = {
            "signal_type": "task_completed",
            "severity": "info",
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "session_id": "",
            "payload": {
                "task_id": task_id,
                "outcome": outcome,
                "duration": duration,
            },
            "source": "automated",
        }
        emit_signal(signals_path, record)

    return _hook


def record_task_failure(
    project_root: Path,
    task_id: str,
    reason: str,
    failed: list[str],
    failure_reasons: dict[str, str],
) -> None:
    """Append to failed list, record reason, emit stop_failure signal."""
    failed.append(task_id)
    failure_reasons[task_id] = reason
    emit_stop_failure(project_root, task_id=task_id, stop_reason=reason)


def emit_stop_failure(
    project_root: Path, task_id: str, stop_reason: str,
) -> None:
    """Emit a critical stop_failure signal when a subagent StopFailure fires.

    Records the stop reason and affected task so the sprint executor
    can surface it in the summary and block progression until recorded.
    """
    signals_path = project_root / ".paircoder" / "telemetry" / "signals.jsonl"
    record = {
        "signal_type": "stop_failure",
        "severity": "critical",
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "session_id": "",
        "payload": {
            "task_id": task_id,
            "stop_reason": stop_reason,
        },
        "source": "automated",
    }
    emit_signal(signals_path, record)
