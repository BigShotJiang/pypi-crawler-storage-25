"""PR review by number — core logic for ``bpsai-pair review pr``.

Fetches the PR diff via ``gh pr diff``, calculates size, dispatches
reviewer + security-auditor agents, and optionally a cross-module
reviewer for large diffs.
"""

from __future__ import annotations

import logging
import subprocess
from pathlib import Path
from typing import Any

from bpsai_pair.orchestration.review_common import (
    _LARGE_DIFF_FILES,
    _LARGE_DIFF_LINES,
    _dispatch_agents,
    classify_review_action,
)
from bpsai_pair.orchestration.review_output import combine_findings

logger = logging.getLogger(__name__)


def get_pr_diff(project_root: Path, pr_number: int) -> str:
    """Fetch the PR diff using ``gh pr diff <number>``."""
    try:
        result = subprocess.run(
            ["gh", "pr", "diff", str(pr_number)],
            cwd=str(project_root),
            capture_output=True, text=True, timeout=30,
        )
        return result.stdout
    except (subprocess.TimeoutExpired, FileNotFoundError, OSError):
        logger.warning("Failed to get PR diff for #%s", pr_number)
        return ""


def calculate_diff_size(diff_text: str) -> tuple[int, int]:
    """Return ``(lines_changed, files_changed)`` from raw diff text."""
    if not diff_text:
        return (0, 0)
    files = lines = 0
    for line in diff_text.splitlines():
        if line.startswith("diff --git "):
            files += 1
        elif line.startswith("---") or line.startswith("+++"):
            continue
        elif line.startswith("+") or line.startswith("-"):
            lines += 1
    return (lines, files)


_POST_HEADER = "**[Automated Review - bpsai-pair]**\n\n"
_POST_MAX_BODY = 60_000


def _post_review(
    project_root: Path, pr_number: int, action: str, body: str,
) -> None:
    """Post a review to the PR via ``gh pr review``."""
    flag_map = {
        "request_changes": "--request-changes",
        "comment": "--comment",
        "approve": "--approve",
    }
    flag = flag_map.get(action, "--comment")
    if action == "approve":
        body = "LGTM - automated review passed"
    body = _POST_HEADER + body
    if len(body) > _POST_MAX_BODY:
        body = body[:_POST_MAX_BODY]
    try:
        subprocess.run(
            ["gh", "pr", "review", str(pr_number), flag, "--body", body],
            cwd=str(project_root),
            capture_output=True, text=True, timeout=30, check=False,
        )
    except (subprocess.TimeoutExpired, FileNotFoundError, OSError):
        logger.warning("Failed to post review for PR #%s", pr_number)


def review_pr(
    project_root: Path, pr_number: int, post: bool = False,
) -> dict[str, Any]:
    """Review a PR by number — fetch diff, dispatch agents, classify."""
    diff = get_pr_diff(project_root, pr_number)
    if not diff:
        return {
            "action": "skipped", "reason": "empty_diff", "dispatched": False,
            "findings": "", "errors": 0, "agents": [],
            "lines_changed": 0, "files_changed": 0,
        }

    lines_changed, files_changed = calculate_diff_size(diff)
    agents = ["nayru", "laverna"]
    if lines_changed > _LARGE_DIFF_LINES or files_changed > _LARGE_DIFF_FILES:
        agents.append("vaivora")

    findings, errors = _dispatch_agents(project_root, diff, agents)
    combined = combine_findings(findings)

    # If every agent failed, treat as error -- never auto-approve.
    all_failed = errors > 0 and errors == len(agents)
    if all_failed:
        return {
            "action": "error", "findings": combined, "errors": errors,
            "dispatched": True, "agents": agents,
            "lines_changed": lines_changed, "files_changed": files_changed,
        }

    action = classify_review_action(combined)

    if post:
        _post_review(project_root, pr_number, action, combined)

    return {
        "action": action, "findings": combined, "errors": errors,
        "dispatched": True, "agents": agents,
        "lines_changed": lines_changed, "files_changed": files_changed,
    }
