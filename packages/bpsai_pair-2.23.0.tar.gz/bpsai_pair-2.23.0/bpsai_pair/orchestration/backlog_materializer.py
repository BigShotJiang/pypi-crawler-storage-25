"""Materialize parsed backlog into plan YAML and task markdown files."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import yaml

from .backlog_parser import ParsedBacklog, ParsedTask


def materialize(
    project_root: Path, backlog: ParsedBacklog, sprint: str
) -> Path:
    """Write plan YAML and task .md files from a parsed backlog."""
    plans_dir = project_root / ".paircoder" / "plans"
    tasks_dir = project_root / ".paircoder" / "tasks"
    plans_dir.mkdir(parents=True, exist_ok=True)
    tasks_dir.mkdir(parents=True, exist_ok=True)

    plan_id = f"plan-sprint-{sprint}-engage"
    plan_data = {
        "id": plan_id,
        "title": f"Sprint {sprint}",
        "type": "feature",
        "status": "planned",
        "phases": _build_phases(backlog),
    }

    plan_path = plans_dir / f"{plan_id}.plan.yaml"
    with open(plan_path, "w", encoding="utf-8") as f:
        yaml.safe_dump(plan_data, f, default_flow_style=False)

    for task in backlog.tasks:
        _write_task_file(tasks_dir, task, plan_id, sprint)

    return plan_path


def _build_phases(backlog: ParsedBacklog) -> list[dict[str, Any]]:
    """Group tasks into phase structures."""
    phases: dict[int, list[str]] = {}
    for task in backlog.tasks:
        phases.setdefault(task.phase, []).append(task.id)
    return [
        {"id": pid, "tasks": tids}
        for pid, tids in sorted(phases.items())
    ]


def _existing_task_is_done(task_path: Path) -> bool:
    """Return True if the task file exists and has status: done."""
    if not task_path.is_file():
        return False
    try:
        text = task_path.read_text(encoding="utf-8")
        parts = text.split("---", 2)
        if len(parts) >= 3:
            fm = yaml.safe_load(parts[1])
            return isinstance(fm, dict) and fm.get("status") == "done"
    except Exception:
        pass
    return False


def _write_task_file(
    tasks_dir: Path, task: ParsedTask, plan_id: str, sprint: str
) -> None:
    """Write a single task .md file with frontmatter and AC.

    Skips overwriting files that already have ``status: done`` so that
    ``--resume`` can read completed statuses from a prior run.
    """
    task_id = task.id
    task_path = tasks_dir / f"{task_id}.task.md"
    if _existing_task_is_done(task_path):
        return
    fm_data: dict[str, Any] = {
        "id": task_id,
        "title": task.title,
        "plan": plan_id,
        "type": "feature",
        "priority": task.priority,
        "complexity": task.complexity,
        "status": "pending",
        "sprint": sprint,
        "depends_on": list(task.depends_on),
    }
    if task.external_tools:
        fm_data["external_tools"] = list(task.external_tools)
    if task.requires != "autonomous":
        fm_data["requires"] = task.requires
    frontmatter = yaml.safe_dump(
        fm_data, default_flow_style=False, sort_keys=False,
    ).strip()

    body_lines = [f"# {task.title}", ""]
    if task.description:
        body_lines.extend([task.description, ""])
    body_lines.append("# Acceptance Criteria")
    body_lines.append("")
    for ac in task.ac_items:
        body_lines.append(f"- [ ] {ac}")
    body_lines.append("")

    content = f"---\n{frontmatter}\n---\n\n" + "\n".join(body_lines)
    (tasks_dir / f"{task_id}.task.md").write_text(content, encoding="utf-8")
