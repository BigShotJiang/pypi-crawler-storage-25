"""Review output formatting with mythology display_names.

Formats agent findings with agent identity headers for both
terminal output and PR review comments.
"""

from __future__ import annotations


def _title_case_role(role: str) -> str:
    """Convert 'security-auditor' to 'Security-Auditor'."""
    return "-".join(part.capitalize() for part in role.split("-"))


def format_agent_findings(
    display_name: str, role: str, findings: str,
) -> str:
    """Format a single agent's findings with a display_name header.

    If display_name differs from role, uses "## DisplayName (Role)".
    Otherwise uses "## Role" (capitalized).
    """
    role_title = _title_case_role(role)
    if display_name != role:
        header = f"## {display_name} ({role_title})"
    else:
        header = f"## {role_title}"

    return f"{header}\n\n{findings}"


def combine_findings(
    agents_findings: list[tuple[str, str, str]],
) -> str:
    """Combine multiple agents' findings into a single output.

    Each entry is (display_name, role, findings_text).
    """
    if not agents_findings:
        return ""

    sections = [
        format_agent_findings(name, role, text)
        for name, role, text in agents_findings
    ]
    return "\n\n---\n\n".join(sections)


def format_pr_comment(
    agents_findings: list[tuple[str, str, str]],
    action: str = "comment",
) -> str:
    """Format findings as a PR review comment body.

    Includes agent attribution headers and action summary.
    """
    body_parts: list[str] = []

    action_label = {
        "request_changes": "Changes Requested",
        "approve": "Approved",
        "comment": "Review Comments",
    }.get(action, action.replace("_", " ").title())

    body_parts.append(f"# {action_label}\n")
    body_parts.append(combine_findings(agents_findings))

    return "\n\n".join(body_parts)
