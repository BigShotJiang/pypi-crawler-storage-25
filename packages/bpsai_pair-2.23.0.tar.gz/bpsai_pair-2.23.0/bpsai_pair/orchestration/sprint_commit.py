"""Git commit helpers for sprint execution (P0-2 split from sprint_executor.py)."""
from __future__ import annotations

import logging
import subprocess
from pathlib import Path

from bpsai_pair.engage.constants import CHURN_EXCLUSIONS
from bpsai_pair.orchestration.commit_verification import verify_commit

logger = logging.getLogger(__name__)

# Unstaged after ``git add -A`` so they stay modified in the working tree
# but are never committed on feature branches.
# Combines the centralized churn exclusions with branch-specific state files
# that cause merge conflicts (state.md, capabilities.yaml, config.yaml, store.db).
_UNSTAGE_PATTERNS = sorted(CHURN_EXCLUSIONS) + [
    ".paircoder/capabilities.yaml",
    ".paircoder/config.yaml",
    ".paircoder/context/state.md",
    ".paircoder/data/store.db",
]


def commit_task(
    project_root: Path, task_id: str, title: str,
) -> None:
    """Git add + commit after a successful task, then verify."""
    suffix = f" \u2014 {title}" if title else ""
    msg = f"task(engage): {task_id}{suffix}"
    commit_rc = 0
    commit_stderr = ""
    try:
        # Note: git add -A stages everything intentionally -- the sprint
        # executor needs to commit all driver output for each task.
        add = subprocess.run(
            ["git", "add", "-A"],
            cwd=project_root,
            capture_output=True, check=False,
            encoding="utf-8", errors="replace",
        )
        if add.returncode != 0:
            logger.error(
                "git add failed for %s (rc=%d): %s",
                task_id, add.returncode, add.stderr.strip(),
            )
            return
        # Unstage paircoder state files that cause merge conflicts
        subprocess.run(
            ["git", "reset", "HEAD", "--"] + _UNSTAGE_PATTERNS,
            cwd=project_root, capture_output=True, check=False,
            encoding="utf-8", errors="replace",
        )
        commit = subprocess.run(
            ["git", "commit", "-m", msg],
            cwd=project_root,
            capture_output=True, check=False,
            encoding="utf-8", errors="replace",
        )
        commit_rc = commit.returncode
        commit_stderr = commit.stderr.strip()
        if commit.returncode != 0:
            stdout = commit.stdout.strip()
            if "nothing to commit" in stdout:
                logger.warning("Nothing to commit for %s", task_id)
            else:
                logger.error(
                    "git commit failed for %s (rc=%d): %s",
                    task_id, commit.returncode, commit_stderr or stdout,
                )
        verify_commit(project_root, task_id, commit_rc, commit_stderr)
    except Exception as exc:
        logger.warning("Commit failed for %s: %s", task_id, exc)


def complete_task_lifecycle(
    project_root: Path, task_id: str,
) -> None:
    """Run PairCoder task completion hooks via CLI.

    Non-blocking: logs warnings on failure but never stops the sprint.
    """
    try:
        result = subprocess.run(
            [
                "bpsai-pair", "task", "update", task_id, "--status", "done",
                "--local-only", "--reason", "engage auto-completion",
            ],
            cwd=project_root,
            capture_output=True, check=False, timeout=60,
            encoding="utf-8", errors="replace",
        )
        if result.returncode != 0:
            stderr = result.stderr.strip()
            logger.warning(
                "Task lifecycle hooks failed for %s (rc=%d): %s",
                task_id, result.returncode, stderr[:200],
            )
    except subprocess.TimeoutExpired:
        logger.warning("Task lifecycle hooks timed out for %s", task_id)
    except Exception as exc:
        logger.warning("Task lifecycle hooks error for %s: %s", task_id, exc)


def fail_task_lifecycle(
    project_root: Path, task_id: str, reason: str,
) -> None:
    """Mark a task file as failed via CLI.

    Non-blocking: logs warnings on failure but never stops the sprint.
    """
    try:
        result = subprocess.run(
            [
                "bpsai-pair", "task", "update", task_id, "--status", "failed",
                "--local-only", "--reason", reason,
            ],
            cwd=project_root,
            capture_output=True, check=False, timeout=60,
            encoding="utf-8", errors="replace",
        )
        if result.returncode != 0:
            stderr = result.stderr.strip()
            logger.warning(
                "fail_task_lifecycle failed for %s (rc=%d): %s",
                task_id, result.returncode, stderr[:200],
            )
    except subprocess.TimeoutExpired:
        logger.warning("fail_task_lifecycle timed out for %s", task_id)
    except Exception as exc:
        logger.warning("fail_task_lifecycle error for %s: %s", task_id, exc)
