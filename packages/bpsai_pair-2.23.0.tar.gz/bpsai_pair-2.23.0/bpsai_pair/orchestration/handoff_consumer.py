"""Handoff consumer for reading and summarizing handoff files.

Reads v1 (HandoffPackage) and v2 (EnhancedHandoffPackage) handoff JSON files
from the handoffs directory and produces a unified summary for session display.

Classes:
    HandoffSummaryItem: Normalized handoff data from either format
    HandoffSummary: Collection of consumed handoffs with error tracking
    HandoffConsumer: Reads handoff files and produces summaries
"""
from __future__ import annotations

import json
import logging
from dataclasses import dataclass, field
from pathlib import Path

logger = logging.getLogger(__name__)


@dataclass
class HandoffSummaryItem:
    """Normalized handoff data from either v1 or v2 format.

    Attributes:
        handoff_id: Unique identifier for this handoff
        task_id: Task being handed off
        source_agent: Agent that created the handoff
        target_agent: Agent receiving the handoff
        work_completed: Summary of completed work
        remaining_work: Summary of remaining work
        token_budget: Estimated token budget
        version: Format version (1.0 or 2.0)
    """

    handoff_id: str
    task_id: str
    source_agent: str
    target_agent: str
    work_completed: str = ""
    remaining_work: str = ""
    token_budget: int = 0
    version: str = "2.0"


@dataclass
class HandoffSummary:
    """Collection of consumed handoffs with error tracking.

    Attributes:
        handoffs: List of successfully parsed handoff items
        errors: List of error messages from failed parses
    """

    handoffs: list[HandoffSummaryItem] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)

    @property
    def total(self) -> int:
        """Number of successfully consumed handoffs."""
        return len(self.handoffs)


def _parse_v1(data: dict, filename: str) -> HandoffSummaryItem:
    """Parse a v1 handoff JSON dict into a summary item."""
    return HandoffSummaryItem(
        handoff_id=filename.removesuffix(".json"),
        task_id=data["task_id"],
        source_agent=data["source_agent"],
        target_agent=data["target_agent"],
        work_completed=data.get("conversation_summary", ""),
        remaining_work="",
        token_budget=data.get("token_estimate", 0),
        version="1.0",
    )


def _parse_v2(data: dict, filename: str) -> HandoffSummaryItem:
    """Parse a v2 handoff JSON dict into a summary item."""
    return HandoffSummaryItem(
        handoff_id=data.get("handoff_id", filename.removesuffix(".json")),
        task_id=data["task_id"],
        source_agent=data["source_agent"],
        target_agent=data["target_agent"],
        work_completed=data.get("work_completed", ""),
        remaining_work=data.get("remaining_work", ""),
        token_budget=data.get("token_budget", 0),
        version="2.0",
    )


class HandoffConsumer:
    """Reads handoff files from a directory and produces summaries.

    Supports both v1 (HandoffPackage) and v2 (EnhancedHandoffPackage) formats.
    Malformed files are skipped with errors recorded in the summary.

    Args:
        handoffs_dir: Path to the handoffs directory
    """

    def __init__(self, handoffs_dir: Path) -> None:
        self.handoffs_dir = handoffs_dir

    def consume_all(self) -> HandoffSummary:
        """Read all handoff files and return a unified summary.

        Returns:
            HandoffSummary with parsed items and any errors
        """
        summary = HandoffSummary()

        if not self.handoffs_dir.exists():
            return summary

        for path in sorted(self.handoffs_dir.glob("*.json")):
            if path.name.startswith("chain-"):
                continue
            self._consume_file(path, summary)

        return summary

    def _consume_file(self, path: Path, summary: HandoffSummary) -> None:
        """Parse a single handoff file into the summary."""
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            version = data.get("version", "1.0")
            if version.startswith("1"):
                item = _parse_v1(data, path.name)
            elif version.startswith("2"):
                item = _parse_v2(data, path.name)
            else:
                msg = f"Unknown handoff version {version} in {path.name}"
                logger.warning(msg)
                summary.errors.append(msg)
                return
            summary.handoffs.append(item)
        except (json.JSONDecodeError, KeyError, TypeError) as exc:
            msg = f"Failed to parse {path.name}: {exc}"
            logger.warning(msg)
            summary.errors.append(msg)
