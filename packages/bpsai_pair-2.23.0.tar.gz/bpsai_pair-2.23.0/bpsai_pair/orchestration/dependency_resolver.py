"""On-disk dependency resolver for dispatch-time verification.

Reads the canonical ``status:`` field from each dependency's task file
on disk, rather than trusting in-memory state.  This prevents dispatching
a task whose dependencies haven't actually completed (e.g. hook failure,
crash, partial restart).
"""

from __future__ import annotations

import logging
import re
from pathlib import Path
from typing import Any

import yaml

from .plan_graph_models import ExecutionGraph

logger = logging.getLogger(__name__)


class DependencyBlockedError(Exception):
    """Raised when a task cannot be dispatched due to unmet dependencies."""


def _read_task_status_from_disk(project_root: Path, task_id: str) -> str:
    """Read the status field from a task file's YAML frontmatter.

    Returns the status string, or "unknown" if the file is missing
    or unparseable.
    """
    task_file = project_root / ".paircoder" / "tasks" / f"{task_id}.task.md"
    if not task_file.exists():
        logger.warning("Task file not found for dependency check: %s", task_file)
        return "unknown"

    text = task_file.read_text(encoding="utf-8")
    match = re.match(r"^---\s*\n(.*?)\n---", text, re.DOTALL)
    if not match:
        return "unknown"

    try:
        meta: dict[str, Any] = yaml.safe_load(match.group(1)) or {}
        return str(meta.get("status", "unknown"))
    except yaml.YAMLError:
        logger.warning("Failed to parse frontmatter: %s", task_file)
        return "unknown"


def verify_dependencies_on_disk(
    project_root: Path,
    task_id: str,
    graph: ExecutionGraph,
    status_cache: dict[str, str] | None = None,
) -> None:
    """Verify all dependencies for *task_id* are ``done`` on disk.

    Args:
        project_root: Project root containing ``.paircoder/tasks/``.
        task_id: The task about to be dispatched.
        graph: The execution graph (used to look up dependency list).
        status_cache: Optional shared cache for on-disk status reads
            within a single dispatch pass to avoid redundant I/O.

    Raises:
        DependencyBlockedError: If any dependency's on-disk status
            is not ``done``.
    """
    deps = graph.dependencies.get(task_id, [])
    if not deps:
        return

    if status_cache is None:
        status_cache = {}

    for dep_id in deps:
        if dep_id not in status_cache:
            status_cache[dep_id] = _read_task_status_from_disk(
                project_root, dep_id,
            )

        disk_status = status_cache[dep_id]
        if disk_status != "done":
            raise DependencyBlockedError(
                f"Cannot dispatch '{task_id}': dependency '{dep_id}' "
                f"has on-disk status '{disk_status}' (expected 'done')"
            )
