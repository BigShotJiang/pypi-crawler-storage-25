"""PR review dispatch for engage pipeline.

After PR creation, dispatches Nayru and Laverna agents
against the PR diff via shared review infrastructure. Posts findings
as PR reviews with mythology display name headers.
"""

from __future__ import annotations

import logging
import re
import subprocess
from pathlib import Path
from typing import Any

from bpsai_pair.orchestration.pr_review import (
    _post_review,
    calculate_diff_size,
)
from bpsai_pair.orchestration.review_common import (
    _LARGE_DIFF_FILES,
    _LARGE_DIFF_LINES,
    _dispatch_agents,
    classify_review_action,
    has_blocking_findings,
)
from bpsai_pair.orchestration.review_output import combine_findings

logger = logging.getLogger(__name__)

# Re-export for backward compatibility — other modules import these from here.
__all__ = ["classify_review_action", "has_blocking_findings"]



def _extract_pr_number(pr_url: str) -> str:
    """Extract the PR number from a GitHub PR URL."""
    match = re.search(r"/pull/(\d+)", pr_url)
    return match.group(1) if match else ""


def _get_pr_diff(project_root: Path, pr_url: str) -> str:
    """Fetch the PR diff using gh CLI."""
    pr_number = _extract_pr_number(pr_url)
    if not pr_number:
        return ""
    try:
        result = subprocess.run(
            ["gh", "pr", "diff", pr_number],
            cwd=str(project_root),
            capture_output=True,
            timeout=30,
            encoding="utf-8", errors="replace",
        )
        return result.stdout
    except (subprocess.TimeoutExpired, FileNotFoundError, OSError):
        logger.warning("Failed to get PR diff for %s", pr_url)
        return ""


def _dispatch_pr_review(
    project_root: Path, pr_url: str,
) -> dict[str, Any]:
    """Dispatch review agents against a PR using shared infrastructure.

    Args:
        project_root: Path to the project root.
        pr_url: Full GitHub PR URL.

    Returns:
        Dict with keys: action, findings, errors, dispatched, agents,
        lines_changed, files_changed.
    """
    diff = _get_pr_diff(project_root, pr_url)
    if not diff:
        return {"action": "skipped", "reason": "empty_diff", "dispatched": False}

    pr_number_str = _extract_pr_number(pr_url)
    if not pr_number_str:
        return {"action": "skipped", "reason": "no_pr_number", "dispatched": False}
    pr_number = int(pr_number_str)
    lines_changed, files_changed = calculate_diff_size(diff)

    agents = ["nayru", "laverna"]
    if lines_changed > _LARGE_DIFF_LINES or files_changed > _LARGE_DIFF_FILES:
        agents.append("vaivora")

    findings, errors = _dispatch_agents(project_root, diff, agents)
    combined = combine_findings(findings)

    # If every agent failed, treat as error — never auto-approve.
    all_failed = errors > 0 and errors == len(agents)
    if all_failed:
        return {
            "action": "error", "findings": combined, "errors": errors,
            "dispatched": True, "agents": agents,
            "lines_changed": lines_changed, "files_changed": files_changed,
        }

    action = classify_review_action(combined)
    _post_review(project_root, pr_number, action, combined)

    return {
        "action": action, "findings": combined, "errors": errors,
        "dispatched": True, "agents": agents,
        "lines_changed": lines_changed, "files_changed": files_changed,
    }
