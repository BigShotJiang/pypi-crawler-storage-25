"""Output verifier — detects empty/metadata-only task output.

After task completion, checks git diff for meaningful changes.
Metadata paths (.paircoder/, .cli_version, signals.jsonl) are excluded.
Empty or metadata-only diffs indicate a task produced no real output.
"""

from __future__ import annotations

import logging
import subprocess
from dataclasses import dataclass, field
from pathlib import Path

logger = logging.getLogger(__name__)

METADATA_PATTERNS: list[str] = [
    ".paircoder/",
    ".cli_version",
    "signals.jsonl",
]


@dataclass
class OutputVerification:
    """Result of verifying task output."""

    has_meaningful_output: bool = False
    changed_files: list[str] = field(default_factory=list)
    metadata_only_files: list[str] = field(default_factory=list)


def _is_metadata(path: str) -> bool:
    """Check if a file path matches a metadata pattern."""
    for pattern in METADATA_PATTERNS:
        if pattern in path:
            return True
    return False


def verify_meaningful_output(project_root: Path) -> OutputVerification:
    """Check git diff for meaningful (non-metadata) changes.

    Runs ``git diff HEAD~1 --name-only`` to get changed files from the
    latest commit, then filters out metadata paths.
    """
    try:
        proc = subprocess.run(
            ["git", "diff", "HEAD~1", "--name-only"],
            cwd=project_root,
            capture_output=True,
            text=True,
            timeout=30,
        )
    except Exception:
        logger.warning("git diff failed", exc_info=True)
        return OutputVerification()

    if proc.returncode != 0:
        logger.warning("git diff returned %d: %s", proc.returncode, proc.stderr)
        return OutputVerification()

    lines = [line.strip() for line in proc.stdout.splitlines() if line.strip()]
    if not lines:
        return OutputVerification()

    meaningful: list[str] = []
    metadata: list[str] = []
    for path in lines:
        if _is_metadata(path):
            metadata.append(path)
        else:
            meaningful.append(path)

    return OutputVerification(
        has_meaningful_output=len(meaningful) > 0,
        changed_files=meaningful,
        metadata_only_files=metadata,
    )


def check_and_emit_no_output(project_root: Path, task_id: str) -> bool:
    """Verify output and emit signal if empty. Returns True if no output.

    Combines verification + signal emission for callers that want a
    simple boolean gate (e.g. sprint executor, orchestration hooks).
    """
    from bpsai_pair.orchestration.sprint_signals import emit_task_no_output

    try:
        result = verify_meaningful_output(project_root)
        if not result.has_meaningful_output:
            signals_path = (
                project_root / ".paircoder" / "telemetry" / "signals.jsonl"
            )
            emit_task_no_output(
                signals_path,
                task_id=task_id,
                metadata_files=result.metadata_only_files,
            )
            logger.warning("Task %s produced no meaningful output", task_id)
            return True
    except Exception:
        logger.debug("Output verification skipped for %s", task_id, exc_info=True)
    return False
