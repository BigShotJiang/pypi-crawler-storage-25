"""
Review data models.

Contains the data classes and enums used by the reviewer agent:
- ReviewSeverity: Severity levels for review findings
- ReviewVerdict: Overall review verdict
- ReviewItem: A single review finding
- ReviewOutput: Structured review output with parsing
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Optional


class ReviewSeverity(Enum):
    """
    Severity levels for review items.

    Ordering: INFO < WARNING < BLOCKER
    """

    INFO = "info"
    WARNING = "warning"
    BLOCKER = "blocker"

    def __lt__(self, other: "ReviewSeverity") -> bool:
        order = [ReviewSeverity.INFO, ReviewSeverity.WARNING, ReviewSeverity.BLOCKER]
        return order.index(self) < order.index(other)

    @classmethod
    def from_string(cls, value: str) -> "ReviewSeverity":
        """
        Create severity from string value.

        Handles various formats:
        - "info", "consider", "optional" -> INFO
        - "warning", "should fix" -> WARNING
        - "blocker", "error", "must fix" -> BLOCKER
        """
        value_lower = value.lower().strip()

        if value_lower in ("info", "consider", "optional", "suggestion"):
            return cls.INFO
        elif value_lower in ("warning", "should fix", "should-fix", "non-blocking"):
            return cls.WARNING
        elif value_lower in ("blocker", "error", "must fix", "must-fix", "blocking", "critical"):
            return cls.BLOCKER

        return cls.INFO  # Default to INFO for unknown


class ReviewVerdict(Enum):
    """
    Overall verdict for a code review.
    """

    APPROVE = "approve"
    APPROVE_WITH_COMMENTS = "approve_with_comments"
    REQUEST_CHANGES = "request_changes"

    @classmethod
    def from_string(cls, value: str) -> "ReviewVerdict":
        """
        Create verdict from string value.

        Handles various formats like:
        - "approve", "approved", "lgtm"
        - "approve with comments"
        - "request changes", "changes requested"
        """
        value_lower = value.lower().strip()

        if "request" in value_lower or "changes" in value_lower and "approve" not in value_lower:
            return cls.REQUEST_CHANGES
        elif "with comments" in value_lower or "with suggestions" in value_lower:
            return cls.APPROVE_WITH_COMMENTS
        elif "approve" in value_lower or "lgtm" in value_lower:
            return cls.APPROVE

        return cls.REQUEST_CHANGES  # Default to safest option


@dataclass
class ReviewItem:
    """
    A single review item/finding.

    Represents a piece of feedback from the code review
    with severity, location, and suggested fix.
    """

    severity: ReviewSeverity
    file_path: str
    message: str
    line_number: Optional[int] = None
    suggestion: Optional[str] = None
    category: Optional[str] = None
    code_snippet: Optional[str] = None

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for serialization."""
        return {
            "severity": self.severity.value,
            "file_path": self.file_path,
            "line_number": self.line_number,
            "message": self.message,
            "suggestion": self.suggestion,
            "category": self.category,
            "code_snippet": self.code_snippet,
        }


@dataclass
class ReviewOutput:
    """
    Structured output from the reviewer agent.

    Contains the review verdict, summary, individual items,
    and positive notes about the code.
    """

    verdict: ReviewVerdict
    summary: str
    items: list[ReviewItem] = field(default_factory=list)
    positive_notes: list[str] = field(default_factory=list)
    raw_output: str = ""

    @property
    def blocker_count(self) -> int:
        """Count of blocker-severity items."""
        return sum(1 for item in self.items if item.severity == ReviewSeverity.BLOCKER)

    @property
    def warning_count(self) -> int:
        """Count of warning-severity items."""
        return sum(1 for item in self.items if item.severity == ReviewSeverity.WARNING)

    @property
    def info_count(self) -> int:
        """Count of info-severity items."""
        return sum(1 for item in self.items if item.severity == ReviewSeverity.INFO)

    @property
    def has_blockers(self) -> bool:
        """Whether review has any blocker-severity items."""
        return self.blocker_count > 0

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for serialization."""
        return {
            "verdict": self.verdict.value,
            "summary": self.summary,
            "items": [item.to_dict() for item in self.items],
            "positive_notes": self.positive_notes,
            "counts": {
                "blocker": self.blocker_count,
                "warning": self.warning_count,
                "info": self.info_count,
            },
        }

    @classmethod
    def from_raw_text(cls, raw_text: str) -> "ReviewOutput":
        """
        Parse review from raw markdown output.

        Attempts to extract structured information from the reviewer's
        markdown-formatted response.

        Args:
            raw_text: Raw markdown text from reviewer output

        Returns:
            ReviewOutput with parsed content
        """
        items: list[ReviewItem] = []
        positive_notes: list[str] = []
        summary = ""
        verdict = ReviewVerdict.APPROVE

        # Extract summary
        summary_match = re.search(
            r"##\s*Review\s*Summary\s*\n(.*?)(?=\n##|\Z)",
            raw_text,
            re.DOTALL | re.IGNORECASE
        )
        if summary_match:
            summary = summary_match.group(1).strip()

        # Extract must-fix (blocker) items
        blocker_match = re.search(
            r"##\s*🔴\s*Must\s*Fix.*?\n(.*?)(?=\n##|\Z)",
            raw_text,
            re.DOTALL | re.IGNORECASE
        )
        if blocker_match:
            items.extend(_parse_review_items(blocker_match.group(1), ReviewSeverity.BLOCKER))

        # Extract should-fix (warning) items
        warning_match = re.search(
            r"##\s*🟡\s*Should\s*Fix.*?\n(.*?)(?=\n##|\Z)",
            raw_text,
            re.DOTALL | re.IGNORECASE
        )
        if warning_match:
            items.extend(_parse_review_items(warning_match.group(1), ReviewSeverity.WARNING))

        # Extract consider (info) items
        info_match = re.search(
            r"##\s*🟢\s*Consider.*?\n(.*?)(?=\n##|\Z)",
            raw_text,
            re.DOTALL | re.IGNORECASE
        )
        if info_match:
            items.extend(_parse_review_items(info_match.group(1), ReviewSeverity.INFO))

        # Extract positive notes
        positive_match = re.search(
            r"##\s*👍\s*Positive\s*Notes?\s*\n(.*?)(?=\n##|\Z)",
            raw_text,
            re.DOTALL | re.IGNORECASE
        )
        if positive_match:
            notes_text = positive_match.group(1)
            for line in notes_text.split("\n"):
                line = line.strip()
                if line.startswith("-") or line.startswith("*"):
                    note = line.lstrip("-*").strip()
                    if note:
                        positive_notes.append(note)

        # Extract verdict
        verdict_match = re.search(
            r"\*\*Status\*\*:\s*(.*?)(?:\n|$)",
            raw_text,
            re.IGNORECASE
        )
        if verdict_match:
            verdict = ReviewVerdict.from_string(verdict_match.group(1))

        return cls(
            verdict=verdict,
            summary=summary,
            items=items,
            positive_notes=positive_notes,
            raw_output=raw_text,
        )


def _parse_review_items(text: str, severity: ReviewSeverity) -> list[ReviewItem]:
    """
    Parse review items from a section of markdown text.

    Looks for patterns like:
    **[file.py:42]** Issue description
    """
    items = []

    # Pattern to match file:line references
    item_pattern = r"\*\*\[([^\]:]+)(?::(\d+))?\]\*\*\s*(.+?)(?=\n\*\*\[|\n\n|$)"

    for match in re.finditer(item_pattern, text, re.DOTALL):
        file_path = match.group(1).strip()
        line_number = int(match.group(2)) if match.group(2) else None
        content = match.group(3).strip()

        # Extract message and suggestion
        message = content.split("\n")[0].strip()
        suggestion = None

        suggestion_match = re.search(r"Suggestion:\s*(.+?)(?:\n|$)", content, re.IGNORECASE)
        if suggestion_match:
            suggestion = suggestion_match.group(1).strip()

        items.append(ReviewItem(
            severity=severity,
            file_path=file_path,
            line_number=line_number,
            message=message,
            suggestion=suggestion,
        ))

    return items
