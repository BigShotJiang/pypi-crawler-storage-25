"""Review and findings loop helpers extracted from sprint_executor.

Keeps sprint_executor.py within file-size limits.
"""
from __future__ import annotations

import logging
from pathlib import Path
from typing import Any, Callable

import typer

from bpsai_pair.orchestration.findings_loop import maybe_run_findings_loop
from bpsai_pair.orchestration.sprint_signals import emit_review_loop_exhausted

logger = logging.getLogger(__name__)


def review_and_fix(
    project_root: Path,
    task_id: str,
    task_review_hook: Callable[[Path, str], dict[str, Any]] | None,
    task_review_results: list[dict[str, Any]],
    findings_loop_results: list[dict[str, Any]],
    unresolved_findings: list[dict[str, Any]],
    permission_mode: str,
    allowed_tools: list[str] | None,
    max_review_iterations: int,
) -> bool:
    """Invoke per-task reviewer; run fix loop if blocking findings.

    Returns True when review loop exhausted without resolving.
    """
    if task_review_hook is None:
        return False
    try:
        review_meta = task_review_hook(project_root, task_id)
        task_review_results.append(review_meta)
    except Exception:
        logger.warning("Task review hook failed for %s", task_id, exc_info=True)
        task_review_results.append({"task_id": task_id, "error": "hook_exception"})
        return False
    try:
        loop_result = maybe_run_findings_loop(
            project_root=project_root, task_id=task_id,
            review_meta=review_meta, permission_mode=permission_mode,
            allowed_tools=allowed_tools,
            max_iterations=max_review_iterations,
        )
        if loop_result is None:
            return False
        findings_loop_results.append(loop_result.to_dict())
        status = "resolved" if loop_result.resolved else "unresolved"
        typer.echo(f"Task {task_id}: findings {status} in {loop_result.iterations} iteration(s)")
        if not loop_result.resolved:
            log = loop_result.iteration_log
            findings = log[-1].get("findings", "") if log else ""
            unresolved_findings.append({
                "task_id": task_id, "reason": "review_loop_exhausted",
                "findings": findings,
            })
            emit_review_loop_exhausted(project_root, task_id, max_review_iterations)
            return True
        return False
    except Exception:
        logger.warning("Findings loop failed for %s", task_id, exc_info=True)
        return False
