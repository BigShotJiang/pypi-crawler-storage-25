"""
Event-based compaction triggers.

Triggers compaction snapshots on meaningful milestones (plan completion,
sprint completion) rather than only on file size thresholds.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)


def on_plan_complete(project_root: Path, plan_id: str) -> Optional[Path]:
    """Trigger a compaction snapshot when a plan completes."""
    return _trigger_snapshot(
        project_root,
        trigger="plan_complete",
        reason=f"Plan completed: {plan_id}",
    )


def on_sprint_complete(project_root: Path, sprint_id: str) -> Optional[Path]:
    """Trigger a compaction snapshot when a sprint completes."""
    return _trigger_snapshot(
        project_root,
        trigger="sprint_complete",
        reason=f"Sprint completed: {sprint_id}",
    )


def _trigger_snapshot(
    project_root: Path, trigger: str, reason: str,
) -> Optional[Path]:
    """Create a compaction snapshot with the given trigger."""
    try:
        from bpsai_pair.compaction import CompactionManager

        paircoder_dir = project_root / ".paircoder"
        if not paircoder_dir.exists():
            return None

        mgr = CompactionManager(paircoder_dir)
        return mgr.save_snapshot(trigger=trigger, reason=reason)
    except Exception as e:
        logger.warning("Event compaction snapshot failed: %s", e)
        return None
