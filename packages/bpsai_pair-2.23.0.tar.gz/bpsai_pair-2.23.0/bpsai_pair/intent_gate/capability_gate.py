"""CapabilityGate — checks whether PairCoder already provides what the user asks.

Matches user requests against capabilities.yaml entries and CLI command
registry using keyword overlap scoring.  Returns a CapabilityMatch when
confidence >= 0.7, or None otherwise.
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path
from typing import Final, List, Optional

import yaml

# Words too common to be useful for matching
_STOP_WORDS: frozenset[str] = frozenset({
    "a", "an", "the", "i", "me", "my", "we", "our", "you", "your",
    "it", "its", "is", "am", "are", "was", "were", "be", "been",
    "do", "does", "did", "have", "has", "had", "will", "would",
    "can", "could", "should", "may", "might", "shall",
    "to", "of", "in", "for", "on", "with", "at", "by", "from",
    "up", "about", "into", "through", "during", "before", "after",
    "and", "but", "or", "nor", "not", "no", "so", "if", "then",
    "that", "this", "these", "those", "there", "here",
    "what", "which", "who", "whom", "how", "when", "where", "why",
    "all", "each", "every", "some", "any", "few", "more", "most",
    "very", "just", "also", "too", "only", "own", "same",
    "need", "want", "like", "get", "make", "let", "please",
})

# Action verbs indicate intent, not domain — remove before scoring
_ACTION_WORDS: frozenset[str] = frozenset({
    "build", "create", "implement", "fix", "add", "remove", "delete",
    "update", "refactor", "write", "deploy", "run", "install",
    "migrate", "set", "configure", "develop", "setup",
})

_WORD_RE = re.compile(r"[a-z][a-z0-9]*(?:-[a-z0-9]+)*")

CONFIDENCE_THRESHOLD: Final[float] = 0.7


@dataclass
class CapabilityMatch:
    """A matched capability with confidence score."""

    name: str
    description: str
    usage_hint: str
    confidence: float


class CapabilityGate:
    """Pre-dispatch gate that detects existing capabilities matching a request."""

    def check(
        self,
        request: str,
        capabilities_path: Path,
        cli_commands: List[dict],
    ) -> Optional[CapabilityMatch]:
        """Check *request* against known capabilities and CLI commands.

        Returns a :class:`CapabilityMatch` if confidence >= 0.7, else None.
        """
        keywords = _extract_keywords(request)
        if not keywords:
            return None

        best: Optional[CapabilityMatch] = None
        best_score = 0.0

        # Score against capabilities.yaml
        for cap in _load_capabilities(capabilities_path):
            score = _score_candidate(keywords, cap["tokens"])
            if score > best_score:
                best_score = score
                best = CapabilityMatch(
                    name=cap["id"],
                    description=cap["description"],
                    usage_hint=cap["usage_hint"],
                    confidence=score,
                )

        # Score against CLI commands
        for cmd in cli_commands:
            tokens = _tokenize(
                cmd.get("name", "") + " " + cmd.get("description", ""),
            )
            score = _score_candidate(keywords, tokens)
            if score > best_score:
                best_score = score
                best = CapabilityMatch(
                    name=cmd["name"],
                    description=cmd.get("description", ""),
                    usage_hint=cmd.get("usage_hint", ""),
                    confidence=score,
                )

        if best is not None and best.confidence >= CONFIDENCE_THRESHOLD:
            return best
        return None


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _extract_keywords(text: str) -> set[str]:
    """Extract meaningful domain keywords from user request text."""
    tokens = _tokenize(text)
    return tokens - _STOP_WORDS - _ACTION_WORDS


def _tokenize(text: str) -> set[str]:
    """Split text into lowercase token set."""
    return set(_WORD_RE.findall(text.lower()))


def _load_capabilities(path: Path) -> list[dict]:
    """Load and normalize capabilities from a YAML file."""
    try:
        data = yaml.safe_load(path.read_text(encoding="utf-8"))
    except (OSError, yaml.YAMLError):
        return []

    entries = data.get("capabilities", []) if data else []
    results = []
    for cap in entries:
        desc = cap.get("description", "")
        name = cap.get("name", "")
        cap_id = cap.get("id", "")
        text = f"{cap_id} {name} {desc}"
        usage_hint = _extract_usage_hint(cap)
        results.append({
            "id": cap_id,
            "description": desc.strip(),
            "usage_hint": usage_hint,
            "tokens": _tokenize(text),
        })
    return results


def _extract_usage_hint(cap: dict) -> str:
    """Pull the first usable invocation string from a capability entry."""
    invoke = cap.get("how_to_invoke", {})
    if isinstance(invoke, dict):
        for val in invoke.values():
            if isinstance(val, str) and val.strip():
                return val.strip().split("\n")[0]
    return ""


def _score_candidate(keywords: set[str], candidate_tokens: set[str]) -> float:
    """Compute overlap-based confidence between keywords and candidate tokens.

    Combines keyword coverage with a length-weighted bonus for domain-specific
    terms.  Longer overlapping words (e.g. "orchestration") contribute more
    than short ones (e.g. "run").
    """
    if not keywords or not candidate_tokens:
        return 0.0

    overlap = keywords & candidate_tokens
    if not overlap:
        return 0.0

    # Coverage: fraction of user keywords that matched
    coverage = len(overlap) / len(keywords)

    # Length bonus: domain-specific terms are typically longer
    avg_len = sum(len(w) for w in overlap) / len(overlap)
    length_bonus = min(avg_len / 10.0, 0.3)  # cap at 0.3

    # Single-token penalty only for short words (< 6 chars)
    if len(overlap) == 1 and avg_len < 6:
        coverage *= 0.5

    return min(coverage + length_bonus, 1.0)
