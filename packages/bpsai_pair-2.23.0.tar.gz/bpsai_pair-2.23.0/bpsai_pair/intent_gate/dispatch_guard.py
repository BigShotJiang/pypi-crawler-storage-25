"""Dispatch guard — wires ApprovalGate into dispatch paths.

Three dispatch paths, each with its own approval strategy:

1. **engage**: CLI command is itself an approval signal (self-approves).
2. **headless/daemon**: ``approved_by`` field from A2A satisfies the gate.
3. **interactive**: User message is checked for approval signals.
"""
from __future__ import annotations

import logging

from bpsai_pair.intent_gate.approval import ApprovalSignal
from bpsai_pair.intent_gate.approval_gate import ApprovalGate
from bpsai_pair.intent_gate.classifier import IntentClassifier, first_substantive_line
from bpsai_pair.intent_gate.schema import GateResult, SessionIntent

logger = logging.getLogger(__name__)

# IG-003: Hardcoded allowlist for approved_by values.
# Only these callers may auto-approve headless dispatch.
ALLOWED_APPROVED_BY: frozenset[str] = frozenset({
    "engage-cli",
    "a2a-daemon",
    "command-center",
})


def check_engage_approval(gate: ApprovalGate) -> GateResult:
    """Check approval for the engage command path.

    ``bpsai-pair engage`` is itself a CLI approval signal, so the gate
    self-approves before dispatch.
    """
    command = "bpsai-pair engage"
    if ApprovalSignal.detect(command):
        gate.grant_approval()
    intent = IntentClassifier.classify(command)
    return gate.check("run_engage", intent)


def check_headless_approval(
    gate: ApprovalGate, *, approved_by: str | None = None,
) -> GateResult:
    """Check approval for headless/daemon dispatch.

    When *approved_by* is set AND is in the allowlist, the gate
    auto-approves. Unknown callers are rejected and logged.
    """
    if approved_by and approved_by in ALLOWED_APPROVED_BY:
        gate.grant_approval()
    elif approved_by and approved_by not in ALLOWED_APPROVED_BY:
        logger.warning("Rejected unknown approved_by: %s", approved_by)
    intent = SessionIntent.APPROVAL if (approved_by and approved_by in ALLOWED_APPROVED_BY) else SessionIntent.TASK
    return gate.check("spawn_agent_session", intent, approved_by=approved_by)


def check_interactive_approval(
    gate: ApprovalGate, user_message: str,
) -> GateResult:
    """Check approval for interactive session dispatch.

    Classifies the user message and grants approval only when an
    explicit approval signal is detected.

    IG-006: Both classification and approval detection operate on the
    first substantive line to ensure consistent scope.
    """
    # Normalize to first substantive line for both classification and detection
    line = first_substantive_line(user_message) or ""
    intent = IntentClassifier.classify(line)
    if ApprovalSignal.detect(line):
        gate.grant_approval()
    return gate.check("spawn_agent_session", intent)
