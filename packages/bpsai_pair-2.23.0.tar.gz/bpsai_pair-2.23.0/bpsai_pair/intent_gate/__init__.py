"""Intent gate system — intent classification and approval enforcement."""
from bpsai_pair.intent_gate.approval import ApprovalSignal
from bpsai_pair.intent_gate.approval_gate import DISPATCH_ACTIONS, ApprovalGate
from bpsai_pair.intent_gate.capability_gate import CapabilityGate, CapabilityMatch
from bpsai_pair.intent_gate.classifier import IntentClassifier, first_substantive_line, route_review
from bpsai_pair.intent_gate.response_injection import (
    InjectionResult,
    ResponseInjector,
    is_override_message,
)
from bpsai_pair.intent_gate.frustration import FrustrationDetector, FrustrationSignal
from bpsai_pair.intent_gate.dispatch_guard import (
    ALLOWED_APPROVED_BY,
    check_engage_approval,
    check_headless_approval,
    check_interactive_approval,
)
from bpsai_pair.intent_gate.schema import GateResult, SessionIntent

__all__ = [
    "ALLOWED_APPROVED_BY",
    "ApprovalGate",
    "ApprovalSignal",
    "CapabilityGate",
    "CapabilityMatch",
    "DISPATCH_ACTIONS",
    "FrustrationDetector",
    "FrustrationSignal",
    "GateResult",
    "InjectionResult",
    "IntentClassifier",
    "first_substantive_line",
    "route_review",
    "ResponseInjector",
    "SessionIntent",
    "is_override_message",
    "check_engage_approval",
    "check_headless_approval",
    "check_interactive_approval",
]
