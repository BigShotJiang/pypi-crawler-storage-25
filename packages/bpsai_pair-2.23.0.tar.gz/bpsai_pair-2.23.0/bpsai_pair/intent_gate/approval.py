"""Deterministic approval signal detector."""
from __future__ import annotations

import re


# Multi-word keywords must come before single-word to avoid partial matches
_APPROVAL_KEYWORDS = [
    "make it so",
    "ship it",
    "go ahead",
    "do it",
    "go for it",
    "launch it",
    "dispatch",
    "engage",
    "execute",
    "approved",
    "proceed",
    "yes",
    "yep",
    "yeah",
]

# REV-001: Keywords that are both approval signals AND common domain vocabulary.
# When action verbs are present alongside these, they are domain references,
# not approval signals.
_DUAL_PURPOSE_KEYWORDS = frozenset({"dispatch", "engage", "execute"})

# REV-001: Action verbs — same set as classifier.py _ACTION_VERBS
_ACTION_VERB_PATTERN = re.compile(
    r"\b(build|create|implement|fix|add|remove|delete|update|refactor"
    r"|write|deploy|run|install|migrate|make|set\s+up|configure|show)\b",
    re.IGNORECASE,
)

_CLI_PATTERNS = [
    r"bpsai-pair\s+engage\b",
    r"bpsai-pair\s+ttask\s+start\b",
    r"/start-task\b",
]

# IG-005: Expanded negation pattern with \bnot\b and \bwon't\b
_NEGATION_PATTERN = re.compile(
    r"\b(don't|do\s+not|never|stop|not|won't)\b",
    re.IGNORECASE,
)

# IG-005: Interrogative openers — questions without trailing ?
_INTERROGATIVE_OPENER = re.compile(
    r"^\s*(should|would|could|can|may|might)\b",
    re.IGNORECASE,
)

# IG-005: Pure CLI command — entire message is a CLI invocation
_PURE_CLI_PATTERN = re.compile(
    r"^\s*(bpsai-pair\s|/\S)",
    re.IGNORECASE,
)

# REV-003: Subordinate clause words — when these appear BEFORE an approval
# keyword the user is deliberating, not approving.
_SUBORDINATE_CLAUSE_PATTERN = re.compile(
    r"\b(if|whether|check|wonder)\b",
    re.IGNORECASE,
)


class ApprovalSignal:
    """Detects explicit dispatch authorization in user messages."""

    @staticmethod
    def detect(message: str) -> bool:
        """Return True only when message contains an explicit approval signal.

        Returns False for:
        - Questions (message ends with ?)
        - Interrogative openers (should, would, could, can) even without ?
        - Messages containing negation words
        - Empty/whitespace messages
        """
        stripped = message.strip()
        if not stripped:
            return False

        # Questions never count as approval
        if stripped.rstrip().endswith("?"):
            return False

        # IG-005: Punctuation-less questions — interrogative openers
        if _INTERROGATIVE_OPENER.search(stripped):
            return False

        # IG-005: Check negation BEFORE CLI patterns. CLI patterns only
        # bypass negation when the ENTIRE message is a CLI command.
        has_negation = bool(_NEGATION_PATTERN.search(stripped))
        is_pure_cli = bool(_PURE_CLI_PATTERN.match(stripped))

        # Pure CLI command (entire message starts with bpsai-pair or /)
        # only bypasses negation when no negation words present
        if is_pure_cli and not has_negation:
            for pattern in _CLI_PATTERNS:
                if re.search(pattern, stripped, re.IGNORECASE):
                    return True

        # Check for negation words anywhere in the message
        if has_negation:
            return False

        # Check CLI patterns for non-pure-CLI messages (no negation)
        for pattern in _CLI_PATTERNS:
            if re.search(pattern, stripped, re.IGNORECASE):
                return True

        # Check approval keywords
        lower = stripped.lower()
        has_action_verbs = bool(_ACTION_VERB_PATTERN.search(lower))
        has_subordinate = bool(_SUBORDINATE_CLAUSE_PATTERN.search(lower))

        for keyword in _APPROVAL_KEYWORDS:
            if not re.search(r"\b" + re.escape(keyword) + r"\b", lower):
                continue
            # REV-001: Dual-purpose keywords suppressed when action verbs present
            if keyword in _DUAL_PURPOSE_KEYWORDS and has_action_verbs:
                continue
            # REV-003: Subordinate clause before keyword suppresses approval
            if has_subordinate:
                match = re.search(r"\b" + re.escape(keyword) + r"\b", lower)
                sub_match = _SUBORDINATE_CLAUSE_PATTERN.search(lower)
                if match and sub_match and sub_match.start() < match.start():
                    continue
            return True

        return False
