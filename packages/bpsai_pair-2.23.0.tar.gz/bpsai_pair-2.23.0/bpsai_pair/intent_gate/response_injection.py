"""Response injection for CapabilityGate matches.

When CapabilityGate finds a match, generates an informative response that
explains the existing capability instead of proceeding with a build request.
"""
from __future__ import annotations

import json
import logging
import re
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

from bpsai_pair.intent_gate.capability_gate import CapabilityMatch

logger = logging.getLogger(__name__)

# IG-011: Constrained to [^.?!]* (single sentence) instead of .*
_OVERRIDE_PATTERNS: list[re.Pattern[str]] = [
    re.compile(r"i\s+know[^.?!]*(?:build|proceed|anyway)", re.IGNORECASE),
    re.compile(r"(?:want|need)\s+something\s+different", re.IGNORECASE),
    re.compile(r"build[^.?!]*(?:new\s+one|anyway)", re.IGNORECASE),
    re.compile(r"already\s+know[^.?!]*(?:proceed|build)", re.IGNORECASE),
    re.compile(r"rebuild\s+from\s+scratch", re.IGNORECASE),
    re.compile(r"build\s+a\s+new\s+version", re.IGNORECASE),
    re.compile(r"start\s+fresh", re.IGNORECASE),
    re.compile(r"different\s+approach", re.IGNORECASE),
    re.compile(r"custom\s+implementation", re.IGNORECASE),
]

# Negation pre-check consistent with approval.py
_OVERRIDE_NEGATION = re.compile(
    r"\b(don't|do\s+not|never|stop|not|won't)\b",
    re.IGNORECASE,
)

_RESPONSE_TEMPLATE = (
    "PairCoder already provides **{name}** — {description}.\n\n"
    "You can use it with: `{usage_hint}`\n\n"
    "If you need something different, just say so and I'll build it."
)


@dataclass
class InjectionResult:
    """Result of a response injection check."""

    matched: bool
    response: str
    capability_name: str


def is_override_message(message: str) -> bool:
    """Check whether *message* is the user restating intent after a gate match."""
    if not message:
        return False
    # IG-011: Negation pre-check — negated overrides must not match
    if _OVERRIDE_NEGATION.search(message):
        return False
    return any(p.search(message) for p in _OVERRIDE_PATTERNS)


class ResponseInjector:
    """Generates informative responses when CapabilityGate matches."""

    def __init__(self, telemetry_dir: Optional[Path] = None) -> None:
        self._telemetry_dir = telemetry_dir

    def inject(
        self,
        match: Optional[CapabilityMatch],
        user_request: str,
    ) -> InjectionResult:
        """Produce an injection result for a capability match.

        Returns an :class:`InjectionResult` with ``matched=True`` and a
        formatted response when *match* is not None, otherwise returns an
        unmatched result.
        """
        if match is None:
            return InjectionResult(matched=False, response="", capability_name="")

        response = _RESPONSE_TEMPLATE.format(
            name=match.name,
            description=match.description,
            usage_hint=match.usage_hint,
        )

        self._emit_telemetry(match, user_request)

        return InjectionResult(
            matched=True,
            response=response,
            capability_name=match.name,
        )

    def _emit_telemetry(
        self, match: CapabilityMatch, user_request: str,
    ) -> None:
        if self._telemetry_dir is None:
            return
        record = {
            "signal_type": "capability_gate_injection",
            "severity": "info",
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "session_id": "",
            "payload": {
                "capability_name": match.name,
                "user_request": user_request,
                "confidence": match.confidence,
            },
            "source": "automated",
        }
        try:
            signals_path = self._telemetry_dir / "signals.jsonl"
            signals_path.parent.mkdir(parents=True, exist_ok=True)
            with open(signals_path, "a", encoding="utf-8") as f:
                f.write(json.dumps(record) + "\n")
        except OSError:
            logger.warning("Failed to write gate injection telemetry", exc_info=True)
