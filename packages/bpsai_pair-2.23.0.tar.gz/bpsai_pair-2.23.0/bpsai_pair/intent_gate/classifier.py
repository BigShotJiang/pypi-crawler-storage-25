"""Heuristic intent classifier — deterministic, no LLM."""
from __future__ import annotations

import re

from bpsai_pair.intent_gate.approval import ApprovalSignal
from bpsai_pair.intent_gate.schema import SessionIntent
from bpsai_pair.planning.review_intent import (
    ReviewSubIntentResult,
    classify_review_subintent,
)

_INTERROGATIVE_OPENERS = re.compile(
    r"^\s*\b(what|how|why|when|where|who|does|is|can|could|would|should)\b",
    re.IGNORECASE,
)

_EXPLANATION_PHRASES = re.compile(
    r"^\s*\b(tell\s+me|explain|describe|show\s+me|help\s+me\s+understand)\b",
    re.IGNORECASE,
)

_DESIGN_KEYWORDS = re.compile(
    r"\b(design|plan|architect|propose|draft|sketch|outline|think\s+through)\b",
    re.IGNORECASE,
)

_NAVIGATION_KEYWORDS = re.compile(
    r"^\s*\b(show|list|find|search|browse|look\s+at|check)\b",
    re.IGNORECASE,
)

_ACTION_VERBS = re.compile(
    r"\b(build|create|implement|fix|add|remove|delete|update|refactor|write|deploy|run|install|migrate|make|set\s+up|configure)\b",
    re.IGNORECASE,
)

# Review: imperative "review"/"audit" at line start
_REVIEW_IMPERATIVE = re.compile(
    r"^\s*\b(review|audit)\b",
    re.IGNORECASE,
)

# Review: review verbs + code/PR/changes context
_REVIEW_CONTEXT = re.compile(
    r"\b(review|audit|check|look\s+at)\b.*\b(code|changes?|PRs?|pull\s+requests?|diff|quality)\b",
    re.IGNORECASE,
)


class IntentClassifier:
    """Classifies user messages into SessionIntent using deterministic heuristics.

    Priority order: APPROVAL > QUESTION > REVIEW > DESIGN > NAVIGATION > TASK
    """

    @staticmethod
    def classify(message: str) -> SessionIntent:
        """Classify a user message into a SessionIntent."""
        line = first_substantive_line(message)
        if line is None:
            return SessionIntent.NAVIGATION

        # 1. Approval — highest priority
        if ApprovalSignal.detect(line):
            return SessionIntent.APPROVAL

        # 2. Question — terminal ?, interrogative openers, explanation phrases
        if line.rstrip().endswith("?"):
            return SessionIntent.QUESTION
        if _INTERROGATIVE_OPENERS.search(line):
            return SessionIntent.QUESTION
        if _EXPLANATION_PHRASES.search(line):
            return SessionIntent.QUESTION

        # 3. Review — imperative or context-based, action verbs override
        if not _ACTION_VERBS.search(line):
            if _REVIEW_IMPERATIVE.search(line) or _REVIEW_CONTEXT.search(line):
                return SessionIntent.REVIEW

        # 4. Design — but action verbs override
        if _DESIGN_KEYWORDS.search(line) and not _ACTION_VERBS.search(line):
            return SessionIntent.DESIGN

        # 5. Navigation
        if _NAVIGATION_KEYWORDS.search(line) and not _ACTION_VERBS.search(line):
            return SessionIntent.NAVIGATION

        # 6. Default
        return SessionIntent.TASK


def route_review(message: str) -> ReviewSubIntentResult:
    """Route a REVIEW-classified message to review sub-intent.

    Delegates to classify_review_subintent() for PR/task/branch routing.
    """
    return classify_review_subintent(message)


def first_substantive_line(message: str) -> str | None:
    """Return first non-blank line, or None if all blank."""
    for line in message.split("\n"):
        stripped = line.strip()
        if stripped:
            return stripped
    return None
