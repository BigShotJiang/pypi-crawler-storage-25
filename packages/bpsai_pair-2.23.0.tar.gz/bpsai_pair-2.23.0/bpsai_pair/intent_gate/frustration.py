"""Frustration heuristic detector — observation-only signal emitter.

Detects frustration patterns in user messages and emits low-confidence
observation signals. Never blocks, gates, or changes behavior.
"""
from __future__ import annotations

import json
import logging
import re
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)

# Strip fenced code blocks before pattern matching (OP-005: DOTALL not [\s\S])
_CODE_BLOCK_PATTERN = re.compile(r"```.*?```", re.DOTALL)

# OP-005: Truncate input to 10KB before pattern matching
_MAX_INPUT_BYTES = 10_240

# Reuse negation pattern from approval.py (IG-005)
_NEGATION_PATTERN = re.compile(
    r"\b(don't|do\s+not|never|not|won't|isn't|aren't|wasn't|weren't)\b",
    re.IGNORECASE,
)

# Positive-context suffixes that suppress frustration detection
_POSITIVE_CONTEXT = re.compile(
    r"\b(awesome|love|great|amazing|nice|record|through|button|feature)\b",
    re.IGNORECASE,
)

# Strong patterns — confidence=0.8
_STRONG_PATTERNS: list[tuple[str, re.Pattern[str]]] = [
    ("wtf", re.compile(r"\bwtf\b", re.IGNORECASE)),
    ("wth", re.compile(r"\bwth\b", re.IGNORECASE)),
    ("you broke", re.compile(r"\byou\s+broke\b", re.IGNORECASE)),
    ("you messed", re.compile(r"\byou\s+messed\b", re.IGNORECASE)),
    ("that's wrong", re.compile(r"\bthat'?s\s+wrong\b", re.IGNORECASE)),
    ("that's broken", re.compile(r"\bthat'?s\s+broken\b", re.IGNORECASE)),
    ("no stop", re.compile(r"\bno\s+stop\b", re.IGNORECASE)),
    ("no not that", re.compile(r"\bno\s+not\s+that\b", re.IGNORECASE)),
]

# Moderate patterns — confidence=0.5
_MODERATE_PATTERNS: list[tuple[str, re.Pattern[str]]] = [
    ("why did you", re.compile(r"\bwhy\s+did\s+you\b", re.IGNORECASE)),
    ("why would you", re.compile(r"\bwhy\s+would\s+you\b", re.IGNORECASE)),
    ("I didn't ask", re.compile(r"\bI\s+didn'?t\s+ask\b", re.IGNORECASE)),
    ("I didn't say", re.compile(r"\bI\s+didn'?t\s+say\b", re.IGNORECASE)),
    ("I didn't want", re.compile(r"\bI\s+didn'?t\s+want\b", re.IGNORECASE)),
    ("that's not what", re.compile(r"\bthat'?s\s+not\s+what\b", re.IGNORECASE)),
    ("still broken", re.compile(r"\bstill\s+broken\b", re.IGNORECASE)),
    ("still wrong", re.compile(r"\bstill\s+wrong\b", re.IGNORECASE)),
    ("still failing", re.compile(r"\bstill\s+failing\b", re.IGNORECASE)),
    ("again?", re.compile(r"\bagain\?\s*$", re.IGNORECASE)),
    ("undo", re.compile(r"\bundo\b", re.IGNORECASE)),
    ("revert", re.compile(r"\brevert\b", re.IGNORECASE)),
    ("roll back", re.compile(r"\broll\s+back\b", re.IGNORECASE)),
]

# Patterns whose negation-aware check looks for "not" before the keyword
_NEGATION_SENSITIVE = frozenset({
    "that's wrong", "that's broken", "still broken", "still wrong",
    "still failing",
})


@dataclass
class FrustrationSignal:
    """Observation signal for detected user frustration."""

    confidence: float
    pattern_tier: str  # "strong" or "moderate"
    matched_pattern: str
    message_excerpt: str  # first 100 chars, no PII


class FrustrationDetector:
    """Detects frustration patterns and emits observation signals.

    Observation-only — never blocks, gates, or changes behavior.
    """

    def __init__(self, telemetry_dir: Optional[Path] = None) -> None:
        # OP-007: resolve symlinks/relative paths
        self._telemetry_dir = telemetry_dir.resolve() if telemetry_dir else None

    def detect(self, message: str) -> FrustrationSignal | None:
        """Check message for frustration patterns.

        Returns FrustrationSignal if detected, None otherwise.
        """
        stripped = message.strip()
        if not stripped:
            return None

        # OP-005: truncate before pattern matching to prevent ReDoS
        if len(stripped) > _MAX_INPUT_BYTES:
            stripped = stripped[:_MAX_INPUT_BYTES]

        # Strip fenced code blocks to avoid matching variable names
        text_only = _CODE_BLOCK_PATTERN.sub("", stripped)
        if not text_only.strip():
            return None

        # Check strong patterns first (higher confidence)
        signal = self._check_patterns(text_only, _STRONG_PATTERNS, "strong", 0.8)
        if signal is None:
            signal = self._check_patterns(
                text_only, _MODERATE_PATTERNS, "moderate", 0.5,
            )

        if signal is not None:
            # OP-003: use code-stripped text for excerpt (no PII from code blocks)
            signal = FrustrationSignal(
                confidence=signal.confidence,
                pattern_tier=signal.pattern_tier,
                matched_pattern=signal.matched_pattern,
                message_excerpt=text_only[:100],
            )
            self._emit_signal(signal)

        return signal

    def _check_patterns(
        self,
        text: str,
        patterns: list[tuple[str, re.Pattern[str]]],
        tier: str,
        confidence: float,
    ) -> FrustrationSignal | None:
        for name, pattern in patterns:
            match = pattern.search(text)
            if not match:
                continue
            # Negation-aware suppression
            if name in _NEGATION_SENSITIVE and self._negated(text, match):
                continue
            # Positive-context suppression (sarcasm, technical terms)
            suffix = text[match.end():]
            if _POSITIVE_CONTEXT.search(suffix):
                continue
            return FrustrationSignal(
                confidence=confidence,
                pattern_tier=tier,
                matched_pattern=name,
                message_excerpt=text[:100],
            )
        return None

    @staticmethod
    def _negated(text: str, match: re.Match[str]) -> bool:
        """Check if a negation word appears in the same sentence, max 50 chars back."""
        prefix = text[:match.start()]
        # Split on sentence boundaries and only check current sentence
        for sep in (".", "!", "?", "\n"):
            last_sep = prefix.rfind(sep)
            if last_sep != -1:
                prefix = prefix[last_sep + 1:]
        # Cap at 50 chars before the match
        prefix = prefix[-50:]
        return bool(_NEGATION_PATTERN.search(prefix))

    def _emit_signal(self, signal: FrustrationSignal) -> None:
        if self._telemetry_dir is None:
            return
        record = {
            "signal_type": "user_frustration",
            "severity": "info",
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "session_id": "",
            "payload": {
                "confidence": signal.confidence,
                "pattern_tier": signal.pattern_tier,
                "matched_pattern": signal.matched_pattern,
                "message_excerpt": signal.message_excerpt,
            },
            "source": "automated",
        }
        try:
            signals_path = self._telemetry_dir / "signals.jsonl"
            signals_path.parent.mkdir(parents=True, exist_ok=True)
            with open(signals_path, "a", encoding="utf-8") as f:
                f.write(json.dumps(record) + "\n")
        except OSError:
            logger.warning("Failed to write frustration signal", exc_info=True)
