"""Core schema types for the intent gate system."""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import List


class SessionIntent(Enum):
    """Classification of what a user message represents."""

    QUESTION = "question"
    DESIGN = "design"
    APPROVAL = "approval"
    REVIEW = "review"
    TASK = "task"
    NAVIGATION = "navigation"


@dataclass
class GateResult:
    """Result of a gate check."""

    blocked: bool
    reason: str
    pending: List[str] = field(default_factory=list)
