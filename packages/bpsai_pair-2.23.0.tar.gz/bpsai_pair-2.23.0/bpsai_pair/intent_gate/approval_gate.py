"""ApprovalGate — pre-dispatch enforcement hook.

Blocks dispatch-category actions until the session receives an explicit
approval signal.  Non-dispatch actions pass through unconditionally.
"""
from __future__ import annotations

import json
import logging
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

from bpsai_pair.intent_gate.schema import GateResult, SessionIntent

logger = logging.getLogger(__name__)

# IG-012: Only action names actually passed to gate.check() are kept.
DISPATCH_ACTIONS: frozenset[str] = frozenset({
    "spawn_agent_session",
    "run_engage",
})

_VALID_APPROVAL_PHRASES = [
    "make it so",
    "go ahead",
    "proceed",
    "approved",
    "ship it",
    "engage",
]

_BLOCKED_REASON = (
    "Dispatch action '{action}' requires explicit approval. "
    "Say one of: {phrases} to proceed."
)


class ApprovalGate:
    """Pre-action hook that enforces approval before dispatch actions."""

    def __init__(self, telemetry_dir: Optional[Path] = None) -> None:
        self._approved = False
        self._telemetry_dir = telemetry_dir

    @property
    def is_approved(self) -> bool:
        return self._approved

    def grant_approval(self) -> None:
        """Record that the session has received an approval signal."""
        self._approved = True

    def check(
        self,
        action: str,
        intent: SessionIntent,
        *,
        approved_by: str | None = None,
    ) -> GateResult:
        """Check whether *action* is allowed given current approval state.

        Non-dispatch actions always return ``blocked=False``.
        Dispatch actions are blocked until :meth:`grant_approval` is called.
        """
        is_dispatch = action in DISPATCH_ACTIONS
        blocked = is_dispatch and not self._approved

        if blocked:
            phrases = ", ".join(f'"{p}"' for p in _VALID_APPROVAL_PHRASES)
            reason = _BLOCKED_REASON.format(action=action, phrases=phrases)
            result = GateResult(blocked=True, reason=reason, pending=["approval"])
        else:
            result = GateResult(blocked=False, reason="")

        self._emit_telemetry(action, intent, result, approved_by=approved_by)
        return result

    # -- telemetry --------------------------------------------------------

    def _emit_telemetry(
        self,
        action: str,
        intent: SessionIntent,
        result: GateResult,
        *,
        approved_by: str | None = None,
    ) -> None:
        if self._telemetry_dir is None:
            return
        payload: dict[str, object] = {
            "action": action,
            "intent": intent.value,
            "blocked": result.blocked,
            "approved_by": approved_by,
        }
        record = {
            "signal_type": "approval_gate_check",
            "severity": "info",
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "session_id": "",
            "payload": payload,
            "source": "automated",
        }
        try:
            signals_path = self._telemetry_dir / "signals.jsonl"
            signals_path.parent.mkdir(parents=True, exist_ok=True)
            with open(signals_path, "a", encoding="utf-8") as f:
                f.write(json.dumps(record) + "\n")
        except OSError:
            logger.warning("Failed to write approval gate telemetry", exc_info=True)
