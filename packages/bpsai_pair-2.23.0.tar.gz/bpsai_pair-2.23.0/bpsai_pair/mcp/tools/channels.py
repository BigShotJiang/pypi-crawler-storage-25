"""Coordination channels — push-based communication between agent sessions.

Provides ChannelMessage model, ChannelStore (local persistence),
SenderPolicy (identity-based gating), and MCP tool registration.
"""

from __future__ import annotations

import json
import logging
import time
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Optional

logger = logging.getLogger(__name__)


class ChannelType(str, Enum):
    """Supported coordination channel types."""

    REVIEW_FEEDBACK = "review-feedback"
    SPRINT_BACKLOG = "sprint-backlog"
    STATUS_UPDATE = "status-update"
    BLOCKER_ALERT = "blocker-alert"
    COORDINATION_ISSUE = "coordination-issue"


@dataclass
class ChannelMessage:
    """A message routed through a coordination channel."""

    channel: ChannelType
    sender: str
    target: str
    payload: dict[str, Any]
    timestamp: float = field(default_factory=time.time)

    def to_dict(self) -> dict[str, Any]:
        """Serialize to dictionary."""
        return {
            "channel": self.channel.value,
            "sender": self.sender,
            "target": self.target,
            "payload": self.payload,
            "timestamp": self.timestamp,
        }


@dataclass
class SenderPolicy:
    """Identity-based gating for channel senders."""

    allowed_senders: Optional[set[str]] = None

    def is_allowed(self, sender: str) -> bool:
        """Check if sender is permitted. None = open policy."""
        if self.allowed_senders is None:
            return True
        return sender in self.allowed_senders


class ChannelStore:
    """Local file-based persistence for channel messages."""

    def __init__(self, store_dir: Path) -> None:
        self._dir = store_dir.resolve()
        self._dir.mkdir(parents=True, exist_ok=True)

    def _safe_target_path(self, target: str) -> Path:
        """Resolve target to a safe path within the store directory."""
        if "/" in target or "\\" in target or ".." in target:
            raise ValueError(f"Invalid target: {target!r}")
        target_file = (self._dir / f"{target}.jsonl").resolve()
        if not str(target_file).startswith(str(self._dir)):
            raise ValueError(f"Target escapes store directory: {target!r}")
        return target_file

    def send(self, message: ChannelMessage) -> None:
        """Persist a message to the store."""
        target_file = self._safe_target_path(message.target)
        with target_file.open("a", encoding="utf-8") as f:
            f.write(json.dumps(message.to_dict()) + "\n")

    def query(
        self,
        target: str,
        channel_type: Optional[ChannelType] = None,
        since: Optional[float] = None,
    ) -> list[dict[str, Any]]:
        """Retrieve messages for a target, with optional filters."""
        target_file = self._safe_target_path(target)
        if not target_file.exists():
            return []

        results = []
        with target_file.open(encoding="utf-8") as fh:
            for line in fh:
                if not line.strip():
                    continue
                msg = json.loads(line)
                if channel_type and msg.get("channel") != channel_type.value:
                    continue
                if since and msg.get("timestamp", 0) <= since:
                    continue
                results.append(msg)
        return results


_DEFAULT_POLICY = SenderPolicy()  # Open policy — override for production


async def handle_send(
    channel: str, target: str, payload: str, sender: str = "unknown",
    policy: SenderPolicy | None = None,
) -> dict:
    """Handle a channel send request with sender policy enforcement."""
    active_policy = policy or _DEFAULT_POLICY
    if not active_policy.is_allowed(sender):
        return {"error": f"Sender not permitted: {sender!r}"}

    try:
        ch_type = ChannelType(channel)
    except ValueError:
        return {"error": f"Unknown channel: {channel}"}

    try:
        parsed_payload = json.loads(payload) if isinstance(payload, str) else payload
    except json.JSONDecodeError:
        return {"error": "Invalid payload JSON"}
    msg = ChannelMessage(
        channel=ch_type,
        sender=sender,
        target=target,
        payload=parsed_payload,
    )
    store = _get_store()
    try:
        store.send(msg)
    except ValueError as e:
        return {"error": str(e)}
    return {"sent": True, "channel": channel, "target": target}


async def handle_query(
    target: str, channel: str = "", since: float = 0.0,
) -> dict:
    """Handle a channel query request."""
    store = _get_store()
    try:
        ch_type = ChannelType(channel) if channel else None
    except ValueError:
        return {"error": f"Unknown channel: {channel}"}
    try:
        results = store.query(
            target=target,
            channel_type=ch_type,
            since=since if since > 0 else None,
        )
    except ValueError as e:
        return {"error": str(e)}
    return {"messages": results, "count": len(results)}


def register_channel_tools(server: Any) -> None:
    """Register coordination channel MCP tools with the server."""

    @server.tool()
    async def paircoder_channel_send(
        channel: str, target: str, payload: str, sender: str = "unknown",
    ) -> dict:
        """Send a message to a coordination channel."""
        return await handle_send(channel, target, payload, sender)

    @server.tool()
    async def paircoder_channel_query(
        target: str, channel: str = "", since: float = 0.0,
    ) -> dict:
        """Query messages from a coordination channel."""
        return await handle_query(target, channel, since)


def _get_store() -> ChannelStore:
    """Get or create the default channel store."""
    from bpsai_pair.core.ops import find_paircoder_dir

    store_dir = find_paircoder_dir() / "channels"
    return ChannelStore(store_dir)
