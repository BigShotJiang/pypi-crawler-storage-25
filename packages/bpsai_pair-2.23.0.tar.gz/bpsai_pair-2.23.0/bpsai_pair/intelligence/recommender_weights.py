"""Weight configuration for the intelligent skill recommender.

Per-source weights control how signals from different mappers
contribute to final recommendation scores.
"""

from __future__ import annotations

# Default weights per signal source (must sum to 1.0).
DEFAULT_WEIGHTS: dict[str, float] = {
    "telemetry": 0.30,
    "gaps": 0.25,
    "scorer": 0.20,
    "sessions": 0.15,
    "gates": 0.10,
}

_REQUIRED_KEYS = frozenset(DEFAULT_WEIGHTS.keys())


def validate_weights(weights: dict[str, float]) -> dict[str, float]:
    """Validate custom weight configuration.

    Args:
        weights: Source-name to weight mapping.

    Returns:
        The validated weights dict (unchanged).

    Raises:
        ValueError: If keys missing, negative values, or sum != 1.0.
    """
    missing = _REQUIRED_KEYS - set(weights.keys())
    if missing:
        raise ValueError(f"Missing weight keys: {sorted(missing)}")

    negatives = [k for k, v in weights.items() if v < 0]
    if negatives:
        raise ValueError(f"Weights cannot be negative: {negatives}")

    total = sum(weights.values())
    if abs(total - 1.0) > 1e-6:
        raise ValueError(f"Weights must sum to 1.0, got {total:.6f}")

    return weights
