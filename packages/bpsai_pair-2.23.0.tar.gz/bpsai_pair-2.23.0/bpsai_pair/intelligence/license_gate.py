"""License tier gating for intelligence features.

Intelligence features require Pro tier or higher.
Fail-closed: if licensing system errors, access is denied.
"""

from __future__ import annotations

import logging

from bpsai_pair.licensing import get_tier

logger = logging.getLogger(__name__)

_ALLOWED_TIERS = frozenset({"pro", "enterprise"})


def check_license_tier() -> bool:
    """Check if the current license tier allows intelligence features.

    Returns:
        True if tier is Pro or higher, False otherwise.
        Fail-closed: returns False on any error.
    """
    try:
        tier = get_tier()
    except Exception:
        logger.debug("License check failed, denying intelligence access", exc_info=True)
        return False
    return tier in _ALLOWED_TIERS
