"""TelemetryMapper — converts telemetry store records to skill_usage signals.

Reads from TelemetryStore and emits frequency-based signals per task type.
"""

from __future__ import annotations

from collections import Counter

from bpsai_pair.intelligence.mapper_base import SignalMapper
from bpsai_pair.intelligence.signal_model import IntelligenceSignal

# Maximum records to query when no limit specified.
_DEFAULT_LIMIT = 100


class TelemetryMapper(SignalMapper):
    """Maps telemetry records to skill_usage frequency signals."""

    def __init__(self, store: object) -> None:
        self._store = store

    def map(self, context: dict) -> list[IntelligenceSignal]:
        """Extract skill_usage signals from telemetry records.

        Args:
            context: Optional keys: 'limit' (int) for query limit.

        Returns:
            One signal per task_type, value = normalized frequency.
        """
        limit = context.get("limit", _DEFAULT_LIMIT) if context else _DEFAULT_LIMIT
        records = self._store.query(limit=limit)
        if not records:
            return []
        return self._build_signals(records)

    def _build_signals(
        self, records: list,
    ) -> list[IntelligenceSignal]:
        """Build frequency signals from telemetry records."""
        counts = Counter(r.task_type for r in records)
        max_count = max(counts.values())
        total = len(records)
        signals = []
        for task_type, count in counts.items():
            value = count / max_count  # normalize to [0, 1]
            confidence = min(total / _DEFAULT_LIMIT, 1.0)
            signals.append(IntelligenceSignal(
                source="telemetry",
                category="skill_usage",
                key=task_type,
                value=value,
                confidence=confidence,
                metadata={"count": count, "total_records": total},
            ))
        return signals
