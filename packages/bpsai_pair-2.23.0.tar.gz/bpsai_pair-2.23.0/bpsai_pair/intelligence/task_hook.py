"""Task hook integration for the intelligence subsystem.

Provides a post-task-start hook that runs skill recommendations
and displays them as non-blocking informational tips.
"""

from __future__ import annotations

import logging
from pathlib import Path

from bpsai_pair.core.hook_types import HookContext
from bpsai_pair.intelligence.config import IntelligenceConfig, load_intelligence_config
from bpsai_pair.intelligence.license_gate import check_license_tier
from bpsai_pair.intelligence.pipeline import IntelligencePipeline
from bpsai_pair.intelligence.recommender_models import RecommendationSet

logger = logging.getLogger(__name__)

# Module-level cache for pipeline instances, keyed by paircoder_dir.
# Session-scoped: cleared via clear_pipeline_cache() on config changes.
# Bounded to prevent memory leaks in long-running processes.
_PIPELINE_CACHE_MAX_SIZE: int = 8
_pipeline_cache: dict[str, IntelligencePipeline] = {}


def clear_pipeline_cache() -> None:
    """Clear all cached pipeline instances.

    Call when config.yaml changes mid-session or on session end.
    """
    _pipeline_cache.clear()


def _get_pipeline(paircoder_dir: Path) -> IntelligencePipeline:
    """Get or create a cached IntelligencePipeline for this project.

    Args:
        paircoder_dir: Path to the .paircoder directory.

    Returns:
        Cached or newly created IntelligencePipeline.
    """
    key = str(paircoder_dir)
    if key not in _pipeline_cache:
        # Evict oldest entry if cache is full
        if len(_pipeline_cache) >= _PIPELINE_CACHE_MAX_SIZE:
            oldest_key = next(iter(_pipeline_cache))
            del _pipeline_cache[oldest_key]
        config = _load_config(paircoder_dir)
        _pipeline_cache[key] = IntelligencePipeline(config=config)
    return _pipeline_cache[key]


def _load_config(paircoder_dir: Path) -> IntelligenceConfig:
    """Load intelligence config from the project config file.

    Args:
        paircoder_dir: Path to the .paircoder directory.

    Returns:
        IntelligenceConfig parsed from config.yaml or defaults.
    """
    config_path = paircoder_dir / "config.yaml"
    if config_path.exists():
        import yaml

        raw = yaml.safe_load(config_path.read_text(encoding="utf-8")) or {}
        return load_intelligence_config(raw)
    return IntelligenceConfig()


def recommend_on_task_start(
    ctx: HookContext,
    paircoder_dir: Path,
) -> dict | None:
    """Post-task-start hook that runs skill recommendations.

    Returns dict with recommendations or None if disabled/quiet.
    Non-blocking, under 100ms target after first call.

    Args:
        ctx: Hook context with task info.
        paircoder_dir: Path to the .paircoder directory.

    Returns:
        Dict with recommendations and formatted text, or None.
    """
    if ctx.extra.get("quiet", False):
        return None

    if not check_license_tier():
        logger.debug("Intelligence features require Pro+ license, skipping")
        return None

    try:
        pipeline = _get_pipeline(paircoder_dir)
        context = {"task_id": ctx.task_id, "event": ctx.event}
        recs = pipeline.run(context=context)
    except Exception:
        logger.debug("Intelligence pipeline failed, skipping", exc_info=True)
        return None

    if not recs.recommendations:
        return None

    formatted = _format_recommendations(recs)
    return {
        "recommendations": [r.skill_name for r in recs.recommendations[:3]],
        "count": len(recs.recommendations),
        "display": formatted,
    }


def _format_recommendations(
    recs: RecommendationSet, max_display: int = 3,
) -> str:
    """Format recommendations as terminal-friendly text.

    Args:
        recs: RecommendationSet to format.
        max_display: Maximum number of recommendations to show.

    Returns:
        Formatted string, or empty string if no recommendations.
    """
    if not recs.recommendations:
        return ""
    lines = []
    for rec in recs.recommendations[:max_display]:
        reason = rec.reasons[0] if rec.reasons else "suggested"
        lines.append(f"  - {rec.skill_name} ({reason})")
    return "\n".join(lines)
