"""Configuration and privacy gating for the intelligence subsystem.

Controls which signal sources are active, minimum confidence thresholds,
and privacy-aware mapper filtering.
"""

from __future__ import annotations

from dataclasses import dataclass, field

_DEFAULT_SOURCES = ["calibration", "anomaly", "overhead", "accuracy", "success"]
_VALID_PRIVACY_LEVELS = {"full", "minimal"}


@dataclass
class IntelligenceConfig:
    """Configuration for the intelligence subsystem."""

    skill_recommendations: bool = True
    min_recommendation_confidence: float = 0.5
    recommendation_sources: list[str] = field(
        default_factory=lambda: list(_DEFAULT_SOURCES)
    )
    privacy_level: str = "full"

    def __post_init__(self) -> None:
        self.privacy_level = self.privacy_level.lower()
        if self.privacy_level not in _VALID_PRIVACY_LEVELS:
            raise ValueError(
                f"Invalid privacy_level '{self.privacy_level}', "
                f"must be one of {sorted(_VALID_PRIVACY_LEVELS)}"
            )


def load_intelligence_config(config: dict) -> IntelligenceConfig:
    """Load intelligence config from project config dict.

    Args:
        config: Full project configuration dictionary.
            Reads from the 'intelligence' section.

    Returns:
        IntelligenceConfig with values from config or defaults.
    """
    section = config.get("intelligence", {})
    kwargs: dict = {}
    if "skill_recommendations" in section:
        kwargs["skill_recommendations"] = section["skill_recommendations"]
    if "min_recommendation_confidence" in section:
        kwargs["min_recommendation_confidence"] = section["min_recommendation_confidence"]
    if "recommendation_sources" in section:
        kwargs["recommendation_sources"] = section["recommendation_sources"]
    if "privacy_level" in section:
        kwargs["privacy_level"] = section["privacy_level"]
    return IntelligenceConfig(**kwargs)


def should_include_telemetry(config: IntelligenceConfig) -> bool:
    """Check if TelemetryMapper should be included based on privacy level.

    Args:
        config: Intelligence configuration.

    Returns:
        True if telemetry mapping is allowed, False for minimal privacy.
    """
    return config.privacy_level != "minimal"


def filter_sources(config: IntelligenceConfig) -> list[str]:
    """Return enabled signal source names based on config.

    Args:
        config: Intelligence configuration.

    Returns:
        List of source names that should be active.
    """
    return list(config.recommendation_sources)
