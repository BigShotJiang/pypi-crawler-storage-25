"""GateMapper — converts gate evaluation results to gate_result signals.

Reads QualityGateResult objects and emits pass/fail/warn signals.
"""

from __future__ import annotations

from bpsai_pair.intelligence.mapper_base import SignalMapper
from bpsai_pair.intelligence.signal_model import IntelligenceSignal

# Status to value mapping for overall gate outcome.
_STATUS_VALUES = {
    "pass": 0.9,
    "warn": 0.5,
    "block": 0.1,
}


class GateMapper(SignalMapper):
    """Maps QualityGateResult objects to gate_result signals."""

    def map(self, context: dict) -> list[IntelligenceSignal]:
        """Extract gate_result signals from quality gate evaluations.

        Args:
            context: Must contain 'gate_results' key with QualityGateResult list.

        Returns:
            One signal per gate evaluation result.
        """
        results = context.get("gate_results") if context else None
        if not results:
            return []
        return [self._result_to_signal(r) for r in results]

    def _result_to_signal(self, result: object) -> IntelligenceSignal:
        """Convert a single QualityGateResult to an IntelligenceSignal."""
        status = result.overall_status.value
        gates = getattr(result, "gate_results", [])
        avg_score = self._avg_gate_score(gates)
        value = _STATUS_VALUES.get(status, 0.5) * 0.5 + avg_score * 0.5
        return IntelligenceSignal(
            source="gate",
            category="gate_result",
            key=result.gap_name,
            value=value,
            confidence=0.95,
            metadata={
                "overall_status": status,
                "gate_count": len(gates),
                "can_generate": getattr(result, "can_generate", False),
            },
        )

    def _avg_gate_score(self, gates: list) -> float:
        """Average score across individual gate results."""
        if not gates:
            return 0.5
        return sum(g.score for g in gates) / len(gates)
