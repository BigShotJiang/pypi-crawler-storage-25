"""IntelligenceSignal data model — universal currency for the recommender pipeline.

Signals are produced by mappers and consumed by the recommender.
"""

from __future__ import annotations

import enum
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Iterator


class SignalType(enum.Enum):
    """Categories of intelligence signals flowing through the pipeline."""

    SKILL_USAGE = "skill_usage"
    SKILL_GAP = "skill_gap"
    QUALITY_SCORE = "quality_score"
    SESSION_PATTERN = "session_pattern"
    GATE_RESULT = "gate_result"
    DURATION_ANOMALY = "duration_anomaly"
    BUDGET_BREACH = "budget_breach"
    ENFORCEMENT_FAILURE = "enforcement_failure"


def _clamp(v: float) -> float:
    return max(0.0, min(1.0, v))


def _default_timestamp() -> str:
    return datetime.now(timezone.utc).isoformat()


@dataclass
class IntelligenceSignal:
    """A single intelligence signal — the universal unit for all pipeline data."""

    source: str
    category: str
    key: str
    value: float
    confidence: float
    timestamp: str = field(default_factory=_default_timestamp)
    metadata: dict = field(default_factory=dict)

    def __post_init__(self) -> None:
        self.value = _clamp(self.value)
        self.confidence = _clamp(self.confidence)

    def to_dict(self) -> dict:
        return {
            "source": self.source,
            "category": self.category,
            "key": self.key,
            "value": self.value,
            "confidence": self.confidence,
            "timestamp": self.timestamp,
            "metadata": self.metadata,
        }

    @classmethod
    def from_dict(cls, d: dict) -> IntelligenceSignal:
        return cls(
            source=d["source"],
            category=d["category"],
            key=d["key"],
            value=d["value"],
            confidence=d["confidence"],
            timestamp=d.get("timestamp", _default_timestamp()),
            metadata=d.get("metadata", {}),
        )


class SignalBatch:
    """Container for grouped signals with filtering and summary stats."""

    def __init__(self, signals: list[IntelligenceSignal] | None = None) -> None:
        self._signals: list[IntelligenceSignal] = list(signals) if signals else []

    def __len__(self) -> int:
        return len(self._signals)

    def __iter__(self) -> Iterator[IntelligenceSignal]:
        return iter(self._signals)

    def __getitem__(self, index: int) -> IntelligenceSignal:
        return self._signals[index]

    def add(self, signal: IntelligenceSignal) -> None:
        self._signals.append(signal)

    def filter(
        self, *, source: str | None = None, category: str | None = None
    ) -> SignalBatch:
        result = self._signals
        if source is not None:
            result = [s for s in result if s.source == source]
        if category is not None:
            result = [s for s in result if s.category == category]
        return SignalBatch(result)

    def to_dicts(self) -> list[dict]:
        return [s.to_dict() for s in self._signals]

    @classmethod
    def from_dicts(cls, dicts: list[dict]) -> SignalBatch:
        return cls([IntelligenceSignal.from_dict(d) for d in dicts])

    def summary(self) -> dict:
        count = len(self._signals)
        if count == 0:
            return {
                "count": 0,
                "sources": set(),
                "categories": set(),
                "avg_value": 0.0,
                "avg_confidence": 0.0,
            }
        return {
            "count": count,
            "sources": {s.source for s in self._signals},
            "categories": {s.category for s in self._signals},
            "avg_value": sum(s.value for s in self._signals) / count,
            "avg_confidence": sum(s.confidence for s in self._signals) / count,
        }


# Maps signal categories to the skills that produce or consume them.
SIGNAL_SKILL_MAP: dict[str, list[str]] = {
    "skill_usage": ["implementing-with-tdd", "designing-and-implementing", "reviewing-code"],
    "skill_gap": ["implementing-with-tdd", "designing-and-implementing"],
    "quality_score": ["reviewing-code", "running-qc"],
    "session_pattern": ["managing-task-lifecycle"],
    "gate_result": ["running-qc", "releasing-versions"],
    "duration_anomaly": ["managing-task-lifecycle"],
    "budget_breach": ["planning-with-pm"],
    "enforcement_failure": ["managing-task-lifecycle"],
}
