"""SignalMapper ABC — contract for all signal mappers.

Each mapper reads from one data source and produces IntelligenceSignal instances.
"""

from __future__ import annotations

from abc import ABC, abstractmethod

from bpsai_pair.intelligence.signal_model import IntelligenceSignal


class SignalMapper(ABC):
    """Abstract base class for signal mappers.

    Subclasses implement map() to convert a data source into signals.
    """

    @abstractmethod
    def map(self, context: dict) -> list[IntelligenceSignal]:
        """Extract signals from a data source.

        Args:
            context: Source-specific data to map from.

        Returns:
            List of normalized IntelligenceSignal instances.
            Returns empty list when source data is missing or empty.
        """
