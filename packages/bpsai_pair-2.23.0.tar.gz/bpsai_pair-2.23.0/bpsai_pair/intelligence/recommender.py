"""IntelligentSkillRecommender — aggregates signals and produces ranked recommendations.

Collects signals from all registered mappers, groups by skill,
applies weighted scoring, and returns ranked recommendations with explanations.
"""

from __future__ import annotations

import logging
from collections import defaultdict

from bpsai_pair.intelligence.mapper_base import SignalMapper
from bpsai_pair.intelligence.recommender_models import Recommendation, RecommendationSet
from bpsai_pair.intelligence.recommender_weights import DEFAULT_WEIGHTS, validate_weights
from bpsai_pair.intelligence.signal_model import IntelligenceSignal, SignalBatch

logger = logging.getLogger(__name__)


class IntelligentSkillRecommender:
    """Core recommendation engine: mappers -> signals -> ranked skills."""

    def __init__(
        self,
        mappers: list[SignalMapper],
        weights: dict[str, float] | None = None,
    ) -> None:
        self._mappers = mappers
        self._weights = validate_weights(weights) if weights else DEFAULT_WEIGHTS

    def recommend(
        self, context: dict, top_k: int = 5,
    ) -> RecommendationSet:
        """Produce ranked skill recommendations from all mappers.

        Args:
            context: Shared context passed to each mapper.
            top_k: Maximum number of recommendations to return.

        Returns:
            RecommendationSet with ranked recommendations.
        """
        batch = self._collect_signals(context)
        grouped = self._group_by_skill(batch)
        recs = self._score_and_rank(grouped)
        return RecommendationSet(
            recommendations=recs[:top_k],
            signal_count=len(batch),
            mapper_count=len(self._mappers),
        )

    def _collect_signals(self, context: dict) -> SignalBatch:
        """Collect signals from all mappers, skipping failures."""
        batch = SignalBatch()
        for mapper in self._mappers:
            try:
                signals = mapper.map(context)
                for sig in signals:
                    batch.add(sig)
            except Exception:
                logger.warning("Mapper %s failed, skipping", type(mapper).__name__)
        return batch

    def _group_by_skill(
        self, batch: SignalBatch,
    ) -> dict[str, list[IntelligenceSignal]]:
        """Group signals by their key (skill name)."""
        groups: dict[str, list[IntelligenceSignal]] = defaultdict(list)
        for signal in batch:
            groups[signal.key].append(signal)
        return dict(groups)

    def _score_and_rank(
        self, grouped: dict[str, list[IntelligenceSignal]],
    ) -> list[Recommendation]:
        """Score each skill and return sorted recommendations."""
        recs = []
        for skill_name, signals in grouped.items():
            score = self._compute_score(signals)
            confidence = self._compute_confidence(signals)
            reasons = self._build_reasons(signals)
            recs.append(Recommendation(
                skill_name=skill_name,
                score=score,
                confidence=confidence,
                reasons=reasons,
                signals=signals,
            ))
        recs.sort(key=lambda r: r.score, reverse=True)
        return recs

    def _compute_score(self, signals: list[IntelligenceSignal]) -> float:
        """Weighted sum of signal values x confidence."""
        total = 0.0
        for sig in signals:
            weight = self._weights.get(sig.source, 0.0)
            total += sig.value * sig.confidence * weight
        return round(total, 6)

    def _compute_confidence(self, signals: list[IntelligenceSignal]) -> float:
        """Average confidence across contributing signals."""
        if not signals:
            return 0.0
        return round(sum(s.confidence for s in signals) / len(signals), 4)

    def _build_reasons(self, signals: list[IntelligenceSignal]) -> list[str]:
        """Generate human-readable reason strings from signals."""
        reasons = []
        for sig in signals:
            reason = f"{sig.source} {sig.category}: value={sig.value:.2f}, confidence={sig.confidence:.2f}"
            reasons.append(reason)
        return reasons
