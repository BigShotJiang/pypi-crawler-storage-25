"""Recommendation data models for the intelligent skill recommender.

Recommendation represents a single skill suggestion with score, confidence,
and human-readable reasons. RecommendationSet is a ranked collection.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone

from bpsai_pair.intelligence.signal_model import IntelligenceSignal


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


@dataclass
class Recommendation:
    """A single skill recommendation with supporting evidence."""

    skill_name: str
    score: float
    confidence: float
    reasons: list[str] = field(default_factory=list)
    signals: list[IntelligenceSignal] = field(default_factory=list)

    def to_dict(self) -> dict:
        """Serialize to dictionary."""
        return {
            "skill_name": self.skill_name,
            "score": self.score,
            "confidence": self.confidence,
            "reasons": self.reasons,
            "signals": [s.to_dict() for s in self.signals],
        }


@dataclass
class RecommendationSet:
    """Ranked collection of recommendations with pipeline metadata."""

    recommendations: list[Recommendation]
    signal_count: int
    mapper_count: int
    timestamp: str = field(default_factory=_now_iso)

    def to_dict(self) -> dict:
        """Serialize to dictionary."""
        return {
            "recommendations": [r.to_dict() for r in self.recommendations],
            "signal_count": self.signal_count,
            "mapper_count": self.mapper_count,
            "timestamp": self.timestamp,
        }
