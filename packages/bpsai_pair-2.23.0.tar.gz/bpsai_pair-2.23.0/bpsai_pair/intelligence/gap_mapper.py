"""GapMapper — converts SkillGapDetector output to skill_gap signals.

Reads detected skill gaps and emits signals with severity as value.
"""

from __future__ import annotations

from bpsai_pair.intelligence.mapper_base import SignalMapper
from bpsai_pair.intelligence.signal_model import IntelligenceSignal

# Frequency at which confidence saturates to 1.0.
_FREQ_SATURATION = 20


class GapMapper(SignalMapper):
    """Maps SkillGap instances to skill_gap signals."""

    def map(self, context: dict) -> list[IntelligenceSignal]:
        """Extract skill_gap signals from detected gaps.

        Args:
            context: Must contain 'gaps' key with list of SkillGap objects.

        Returns:
            One signal per gap, value = gap confidence, confidence = frequency.
        """
        gaps = context.get("gaps") if context else None
        if not gaps:
            return []
        return [self._gap_to_signal(gap) for gap in gaps]

    def _gap_to_signal(self, gap: object) -> IntelligenceSignal:
        """Convert a single SkillGap to an IntelligenceSignal."""
        frequency = getattr(gap, "frequency", 0)
        confidence = min(frequency / _FREQ_SATURATION, 1.0)
        pattern = getattr(gap, "pattern", [])
        return IntelligenceSignal(
            source="gap_detector",
            category="skill_gap",
            key=gap.suggested_name,
            value=gap.confidence,
            confidence=confidence,
            metadata={
                "frequency": frequency,
                "pattern_length": len(pattern),
            },
        )
