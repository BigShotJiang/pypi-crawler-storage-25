"""SessionMapper — converts session outcomes to session_pattern signals.

Reads SessionOutcome records and emits aggregate pattern signals
(success rate, failure rate, duration anomaly).
"""

from __future__ import annotations

import statistics

from bpsai_pair.intelligence.mapper_base import SignalMapper
from bpsai_pair.intelligence.signal_model import IntelligenceSignal

# Coefficient of variation threshold for duration anomaly detection.
_CV_THRESHOLD = 0.5
# Minimum sessions for reasonable confidence.
_MIN_SESSIONS = 5


class SessionMapper(SignalMapper):
    """Maps SessionOutcome lists to session_pattern signals."""

    def map(self, context: dict) -> list[IntelligenceSignal]:
        """Extract session_pattern signals from outcomes.

        Args:
            context: Must contain 'outcomes' key with list of SessionOutcome.

        Returns:
            Aggregate signals: success_rate, failure_rate, duration_anomaly.
        """
        outcomes = context.get("outcomes") if context else None
        if not outcomes:
            return []
        signals: list[IntelligenceSignal] = []
        count = len(outcomes)
        confidence = min(count / _MIN_SESSIONS, 1.0)
        meta = {"session_count": count}

        signals.append(self._success_rate(outcomes, confidence, meta))
        signals.append(self._failure_rate(outcomes, confidence, meta))

        dur_signal = self._duration_anomaly(outcomes, confidence, meta)
        if dur_signal:
            signals.append(dur_signal)
        return signals

    def _success_rate(
        self, outcomes: list, confidence: float, meta: dict,
    ) -> IntelligenceSignal:
        ok = sum(1 for o in outcomes if o.outcome == "success")
        return IntelligenceSignal(
            source="session", category="session_pattern",
            key="success_rate", value=ok / len(outcomes),
            confidence=confidence, metadata=dict(meta),
        )

    def _failure_rate(
        self, outcomes: list, confidence: float, meta: dict,
    ) -> IntelligenceSignal:
        fail = sum(1 for o in outcomes if o.outcome != "success")
        return IntelligenceSignal(
            source="session", category="session_pattern",
            key="failure_rate", value=fail / len(outcomes),
            confidence=confidence, metadata=dict(meta),
        )

    def _duration_anomaly(
        self, outcomes: list, confidence: float, meta: dict,
    ) -> IntelligenceSignal | None:
        durations = [o.duration_s for o in outcomes if o.duration_s > 0]
        if len(durations) < 2:
            return None
        mean = statistics.mean(durations)
        if mean == 0:
            return None
        stdev = statistics.stdev(durations)
        cv = stdev / mean  # coefficient of variation
        value = min(cv / (_CV_THRESHOLD * 2), 1.0)
        return IntelligenceSignal(
            source="session", category="session_pattern",
            key="duration_anomaly", value=value,
            confidence=confidence, metadata=dict(meta),
        )
