"""IntelligencePipeline — single entry point for the intelligence subsystem.

Instantiates all mappers and the recommender lazily on first call.
Caches results within a session to avoid redundant computation.
"""

from __future__ import annotations

import hashlib
import json
import logging

from bpsai_pair.intelligence.config import IntelligenceConfig, should_include_telemetry
from bpsai_pair.intelligence.recommender import IntelligentSkillRecommender
from bpsai_pair.intelligence.recommender_models import RecommendationSet
from bpsai_pair.intelligence.recommender_weights import DEFAULT_WEIGHTS

logger = logging.getLogger(__name__)

# Maps actual mapper source names to weight keys.
# Mappers emit sources like "gate", "session", "gap_detector"
# but DEFAULT_WEIGHTS uses "gates", "sessions", "gaps".
_SOURCE_WEIGHT_MAP: dict[str, float] = {
    "telemetry": DEFAULT_WEIGHTS["telemetry"],
    "gap_detector": DEFAULT_WEIGHTS["gaps"],
    "scorer": DEFAULT_WEIGHTS["scorer"],
    "session": DEFAULT_WEIGHTS["sessions"],
    "gate": DEFAULT_WEIGHTS["gates"],
}


def _context_key(context: dict) -> str:
    """Produce a stable cache key from a context dict."""
    serialized = json.dumps(_simplify(context), sort_keys=True, default=str)
    return hashlib.sha256(serialized.encode()).hexdigest()


def _simplify(obj: object) -> object:
    """Convert objects to serializable form for cache keying."""
    if isinstance(obj, dict):
        return {k: _simplify(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [_simplify(item) for item in obj]
    if hasattr(obj, "to_dict"):
        return obj.to_dict()
    if hasattr(obj, "__dict__"):
        return str(type(obj).__name__) + str(id(obj))
    return obj


class IntelligencePipeline:
    """Orchestrates mappers + recommender with lazy init and session caching."""

    def __init__(
        self,
        telemetry_store: object | None = None,
        config: IntelligenceConfig | None = None,
    ) -> None:
        self._telemetry_store = telemetry_store
        self._config = config or IntelligenceConfig()
        self._recommender: IntelligentSkillRecommender | None = None
        self._cache: dict[str, RecommendationSet] = {}

    def _ensure_initialized(self) -> IntelligentSkillRecommender:
        """Lazily create mappers and recommender on first use."""
        if self._recommender is None:
            mappers = self._build_mappers()
            self._recommender = IntelligentSkillRecommender(mappers=mappers)
            # Override weights to use actual mapper source names
            self._recommender._weights = _SOURCE_WEIGHT_MAP
        return self._recommender

    def _build_mappers(self) -> list:
        """Create all 5 signal mappers, skipping those with missing deps."""
        from bpsai_pair.intelligence.gap_mapper import GapMapper
        from bpsai_pair.intelligence.gate_mapper import GateMapper
        from bpsai_pair.intelligence.scorer_mapper import ScorerMapper
        from bpsai_pair.intelligence.session_mapper import SessionMapper
        from bpsai_pair.intelligence.telemetry_mapper import TelemetryMapper

        mappers: list = []
        if (
            self._telemetry_store is not None
            and should_include_telemetry(self._config)
        ):
            mappers.append(TelemetryMapper(store=self._telemetry_store))
        mappers.extend([
            GapMapper(),
            ScorerMapper(),
            SessionMapper(),
            GateMapper(),
        ])
        return mappers

    def run(self, context: dict) -> RecommendationSet:
        """Run the full intelligence pipeline and return recommendations.

        Results are cached by context content. Same context returns the
        cached RecommendationSet without re-running mappers.

        Args:
            context: Shared context passed to all mappers.

        Returns:
            RecommendationSet with ranked skill recommendations.
        """
        if not self._config.skill_recommendations:
            return RecommendationSet(
                recommendations=[], signal_count=0, mapper_count=0,
            )
        key = _context_key(context)
        if key in self._cache:
            return self._cache[key]
        recommender = self._ensure_initialized()
        result = recommender.recommend(context)
        result = self._apply_confidence_filter(result)
        self._cache[key] = result
        return result

    def _apply_confidence_filter(
        self, result: RecommendationSet,
    ) -> RecommendationSet:
        """Remove recommendations below min_recommendation_confidence."""
        threshold = self._config.min_recommendation_confidence
        filtered = [
            r for r in result.recommendations if r.confidence >= threshold
        ]
        return RecommendationSet(
            recommendations=filtered,
            signal_count=result.signal_count,
            mapper_count=result.mapper_count,
            timestamp=result.timestamp,
        )

    def clear_cache(self) -> None:
        """Clear the session cache, forcing recomputation on next run."""
        self._cache.clear()
