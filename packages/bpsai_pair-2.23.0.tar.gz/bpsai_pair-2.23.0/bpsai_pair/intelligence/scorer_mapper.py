"""ScorerMapper — converts SkillScorer dimension scores to quality_score signals.

Reads SkillScore objects and emits normalized quality signals per skill.
"""

from __future__ import annotations

from bpsai_pair.intelligence.mapper_base import SignalMapper
from bpsai_pair.intelligence.signal_model import IntelligenceSignal


class ScorerMapper(SignalMapper):
    """Maps SkillScore objects to quality_score signals."""

    def map(self, context: dict) -> list[IntelligenceSignal]:
        """Extract quality_score signals from skill scores.

        Args:
            context: Must contain 'scores' key with list of SkillScore objects.

        Returns:
            One signal per skill, value = normalized overall score (0-1).
        """
        scores = context.get("scores") if context else None
        if not scores:
            return []
        return [self._score_to_signal(s) for s in scores]

    def _score_to_signal(self, score: object) -> IntelligenceSignal:
        """Convert a single SkillScore to an IntelligenceSignal."""
        overall = getattr(score, "overall_score", 0)
        dims = getattr(score, "dimensions", [])
        grade = getattr(score, "grade", "?")
        return IntelligenceSignal(
            source="scorer",
            category="quality_score",
            key=score.skill_name,
            value=overall / 100.0,
            confidence=0.9,
            metadata={
                "grade": grade,
                "dimension_count": len(dims),
            },
        )
