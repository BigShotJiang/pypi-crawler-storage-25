"""Support portal CLI commands.

Commands:
- support open: Authenticate and open support portal in browser
- support create: Create a support ticket from the terminal
- support list: List your support tickets
- support show: Show a specific ticket with comments
"""

from __future__ import annotations

import json as json_mod
import webbrowser

import typer
from rich.console import Console
from rich.table import Table

from ..support import auth as auth_mod
from ..support import client as client_mod
from ..support.auth import get_auth_code, get_portal_url, get_support_jwt
from ..support.client import SupportClient
from ..support.system_info import collect_system_info

console = Console()

app = typer.Typer(
    help="Support portal commands",
    context_settings={"help_option_names": ["-h", "--help"]},
)


@app.callback(invoke_without_command=True)
def _callback(ctx: typer.Context):
    """Support portal commands."""
    if ctx.invoked_subcommand is None:
        ctx.get_help()
        raise typer.Exit(0)


def _print_auth_error_hint(verbose: bool = False) -> None:
    """Print a contextual hint based on the last auth error."""
    err = auth_mod.last_error
    if err is None:
        console.print("[red]Failed to generate auth code. Try again later.[/red]")
        return

    status = err.get("status")
    body = err.get("body", "")

    if status is None:
        console.print(
            f"[red]Cannot reach api.paircoder.ai. "
            f"Check your internet connection.[/red]"
        )
    elif status == 503:
        console.print(
            f"[red]Auth failed (HTTP 503): API service unavailable. "
            f"The SUPPORT_JWT_SECRET may not be configured.[/red]"
        )
    elif status == 500:
        console.print(
            "[red]Auth failed (HTTP 500): The API returned an internal error. "
            "Contact support or try again later.[/red]"
        )
    elif status == 401:
        console.print(
            f"[red]Auth failed (HTTP 401): Machine not activated. "
            f"Run: bpsai-pair license activate[/red]"
        )
    elif status == 404:
        console.print(
            f"[red]Auth failed (HTTP 404): Endpoint not found. "
            f"The API may need updating.[/red]"
        )
    else:
        console.print(
            f"[red]Auth failed (HTTP {status}): {body[:200]}[/red]"
        )

    if verbose and body:
        console.print(f"[dim]Response body: {body}[/dim]")


@app.command("open")
def open_portal(
    no_browser: bool = typer.Option(
        False, "--no-browser", help="Print URL instead of opening browser"
    ),
    verbose: bool = typer.Option(
        False, "--verbose", help="Show full error details on failure"
    ),
):
    """Open support portal with auto-login."""
    jwt_result = get_support_jwt()
    if jwt_result is None:
        if auth_mod.last_error is not None:
            _print_auth_error_hint(verbose=verbose)
        else:
            console.print("[red]No license found. Install a license first:[/red]")
            console.print("  bpsai-pair license install <file>")
        raise typer.Exit(1)

    code_result = get_auth_code(jwt_result["token"])
    if code_result is None:
        _print_auth_error_hint(verbose=verbose)
        raise typer.Exit(1)

    url = get_portal_url(code_result["code"])

    if no_browser:
        console.print(f"[green]Support portal URL:[/green]\n{url}")
    else:
        console.print("[green]Opening support portal in your browser...[/green]")
        try:
            webbrowser.open(url)
        except Exception:
            pass
        console.print(f"\n[dim]If browser didn't open, visit:[/dim]\n{url}")


def _auth_or_exit() -> dict:
    """Get support JWT or exit with error."""
    jwt_result = get_support_jwt()
    if jwt_result is None:
        if auth_mod.last_error is not None:
            _print_auth_error_hint()
        else:
            console.print("[red]No license found. Install a license first:[/red]")
            console.print("  bpsai-pair license install <file>")
        raise typer.Exit(1)
    return jwt_result


def _print_client_error_hint() -> None:
    """Print a contextual hint based on the last client error."""
    err = client_mod.last_error
    if err is None:
        console.print("[red]Failed to create ticket. Try again later.[/red]")
        return

    status = err.get("status")
    body = err.get("body", "")

    if status is None:
        console.print(
            "[red]Cannot reach support API. "
            "Check your internet connection.[/red]"
        )
    else:
        console.print(
            f"[red]Failed to create ticket (HTTP {status}): {body[:200]}[/red]"
        )


@app.command("create")
def create_ticket(
    ticket_type: str = typer.Option(..., "--type", help="Ticket type (bug, feature, question)"),
    title: str = typer.Option(..., "--title", help="Ticket title"),
    description: str = typer.Option("", "--description", help="Ticket description"),
    json_out: bool = typer.Option(False, "--json", help="Output as JSON"),
):
    """Create a support ticket with auto-attached system info."""
    jwt_result = _auth_or_exit()

    sys_info = collect_system_info()
    client = SupportClient(jwt_result["token"])
    ticket = client.create_ticket(
        title=title,
        ticket_type=ticket_type,
        description=description,
        system_info=sys_info,
    )

    if ticket is None:
        _print_client_error_hint()
        raise typer.Exit(1)

    if json_out:
        console.print(json_mod.dumps(ticket))
    else:
        console.print(f"[green]Ticket created:[/green] {ticket.get('title', title)}")
        console.print("  Use [cyan]bpsai-pair support list[/cyan] to see your ticket ID.")


@app.command("list")
def list_tickets(
    status: str = typer.Option(None, "--status", help="Filter by status (open, closed)"),
    json_out: bool = typer.Option(False, "--json", help="Output as JSON"),
):
    """List your support tickets."""
    jwt_result = _auth_or_exit()

    client = SupportClient(jwt_result["token"])
    tickets = client.list_tickets(status=status)

    if tickets is None:
        console.print("[red]Failed to fetch tickets. Try again later.[/red]")
        raise typer.Exit(1)

    if json_out:
        console.print(json_mod.dumps(tickets))
        return

    if not tickets:
        console.print("[dim]No tickets found.[/dim]")
        return

    table = Table(title="Support Tickets")
    table.add_column("ID", style="cyan")
    table.add_column("Type")
    table.add_column("Title")
    table.add_column("Status")
    table.add_column("Created")

    for t in tickets:
        table.add_row(
            str(t.get("id", "")),
            t.get("ticket_type", ""),
            t.get("title", ""),
            t.get("status", ""),
            t.get("opened_at", ""),
        )

    console.print(table)


@app.command("show")
def show_ticket(
    ticket_id: str = typer.Argument(..., help="Ticket ID to display"),
    json_out: bool = typer.Option(False, "--json", help="Output as JSON"),
):
    """Show a specific support ticket with comments."""
    jwt_result = _auth_or_exit()

    client = SupportClient(jwt_result["token"])
    ticket = client.get_ticket(ticket_id)

    if ticket is None:
        console.print(f"[red]Ticket not found: {ticket_id}[/red]")
        raise typer.Exit(1)

    if json_out:
        console.print(json_mod.dumps(ticket))
        return

    console.print(f"[bold cyan]{ticket.get('id', '')}[/bold cyan] — {ticket.get('title', '')}")
    console.print(f"  Status: {ticket.get('status', '')}")
    if ticket.get("ticket_type"):
        console.print(f"  Type: {ticket['ticket_type']}")
    if ticket.get("opened_at"):
        console.print(f"  Created: {ticket['opened_at']}")
    if ticket.get("description"):
        console.print(f"\n{ticket['description']}")

    comments = ticket.get("comments", [])
    if comments:
        console.print(f"\n[bold]Comments ({len(comments)}):[/bold]")
        for c in comments:
            sender = c.get("sender", "unknown")
            message = c.get("message", "")
            timestamp = c.get("timestamp", "")
            console.print(f"\n  [dim]{sender} — {timestamp}[/dim]")
            console.print(f"  {message}")
