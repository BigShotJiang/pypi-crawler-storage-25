"""Task-edit enforcement logic.

Extracted from enforce.py for arch compliance. Contains the core
verification logic for blocking task file edits that would set
status to done without proper AC verification.
"""

import sys
from typing import Optional

from .enforce import (
    extract_task_id_from_path,
    extract_status_from_content,
    is_strict_ac_enabled,
    is_trello_enabled,
    get_trello_card_for_task,
    is_card_in_done_list,
    log_fail_open,
    output_block_message,
)


def run_task_edit_enforcement(
    file_path: str, new_content: str, old_content: str,
) -> None:
    """Execute task-edit enforcement logic.

    Exits with 0 (allow) or 2 (block).
    """
    task_id = extract_task_id_from_path(file_path)
    if not task_id:
        sys.exit(0)

    if not is_strict_ac_enabled():
        sys.exit(0)

    new_status = extract_status_from_content(new_content)
    if new_status != "done":
        sys.exit(0)

    if old_content:
        old_status = extract_status_from_content(old_content)
        if old_status == "done":
            sys.exit(0)

    if not is_trello_enabled():
        _verify_local_ac(task_id, new_content)
        return

    _verify_trello_ac(task_id)


def _verify_local_ac(task_id: str, new_content: str) -> None:
    """Verify AC from file content (local-only mode)."""
    from ..core.task_state import verify_ac_from_content

    ac_result = verify_ac_from_content(new_content)

    if not ac_result["verified"]:
        unchecked = ac_result["unchecked_items"]
        unchecked_list = "\n".join(f"  - {item}" for item in unchecked[:5])
        if len(unchecked) > 5:
            unchecked_list += f"\n  ... and {len(unchecked) - 5} more"

        output_block_message(
            f"Task {task_id} has {ac_result['checked']}/{ac_result['total']} AC items checked.\n\n"
            f"Unchecked items:\n{unchecked_list}\n\n"
            "To complete this task:\n"
            f"  bpsai-pair task update {task_id} --status done\n\n"
            "This will:\n"
            "  - Verify all acceptance criteria are checked\n"
            "  - Update the task status properly\n\n"
            "Do NOT edit the task file directly to set status: done"
        )
        sys.exit(2)

    sys.exit(0)


def _verify_trello_ac(task_id: str) -> None:
    """Verify AC via Trello card status (Trello mode)."""
    card_info = get_trello_card_for_task(task_id)

    if card_info and card_info.get("error"):
        log_fail_open(task_id, "trello_api_error", card_info["error"])
        sys.exit(0)

    if not card_info:
        log_fail_open(task_id, "no_trello_card")
        sys.exit(0)

    if not is_card_in_done_list(card_info):
        card_id = card_info.get("card_id", "???")
        current_list = card_info.get("list_name", "Unknown")

        output_block_message(
            f"Task {task_id} Trello card is in '{current_list}', not Done.\n\n"
            "To complete this task:\n"
            f"  bpsai-pair ttask done TRELLO-{card_id} --summary \"...\"\n\n"
            "This will:\n"
            "  - Verify acceptance criteria\n"
            "  - Move card to Done list\n"
            "  - Update local task file automatically\n\n"
            "Do NOT edit the task file directly to set status: done"
        )
        sys.exit(2)

    ac_total = card_info.get("ac_total", 0)
    ac_checked = card_info.get("ac_checked", 0)

    if ac_total > 0 and ac_checked < ac_total:
        card_id = card_info.get("card_id", "???")
        output_block_message(
            f"Task {task_id} has {ac_checked}/{ac_total} AC items checked.\n\n"
            "All acceptance criteria must be verified before completion.\n\n"
            "To check AC items:\n"
            f"  bpsai-pair ttask check TRELLO-{card_id} \"<item text>\"\n\n"
            "Then complete:\n"
            f"  bpsai-pair ttask done TRELLO-{card_id} --summary \"...\""
        )
        sys.exit(2)

    sys.exit(0)
