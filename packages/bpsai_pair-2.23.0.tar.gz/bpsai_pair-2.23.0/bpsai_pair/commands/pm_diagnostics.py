"""PM diagnostics, config subcommands, and shared config helpers.

Extracted from pm.py to keep file sizes under architecture limits.
"""

from __future__ import annotations

import logging
from pathlib import Path

import yaml
from rich.console import Console

from ..core.ops import find_paircoder_dir
from ..licensing.core import has_feature_api
from ..pm.compat import load_pm_config
from ..pm.registry import list_providers
from ..pm.workflow import WorkflowConfig

logger = logging.getLogger(__name__)
console = Console()

_PM_FEATURES = ("pm_basic", "pm_hierarchy", "pm_automations", "pm_custom_workflow")


def _load_raw_config() -> dict:
    """Load raw config.yaml as dict. Returns empty dict on failure."""
    try:
        paircoder_dir = find_paircoder_dir()
    except (FileNotFoundError, OSError):
        return {}
    config_path = Path(paircoder_dir) / "config.yaml"
    try:
        return yaml.safe_load(config_path.read_text()) or {}
    except FileNotFoundError:
        return {}


def _load_workflow_config(raw_config: dict) -> WorkflowConfig:
    """Load workflow config from project config, falling back to simple."""
    try:
        _, workflow = load_pm_config(raw_config)
        return workflow
    except (FileNotFoundError, ValueError, KeyError) as e:
        logger.debug("Config-aware workflow loading failed, using simple: %s", e)
        return WorkflowConfig.simple()


def _get_feature_gates() -> dict[str, bool]:
    """Return dict of PM feature names to their availability."""
    return {f: has_feature_api(f) for f in _PM_FEATURES}


def run_diagnostics(provider) -> None:
    """Run PM diagnostics: connectivity, providers, feature gates."""
    # Connectivity
    if provider is not None:
        healthy = provider.healthcheck()
        health_str = "[green]pass[/green]" if healthy else "[red]fail[/red]"
        console.print(f"Connectivity: {provider.name} ({health_str})")
    else:
        console.print("[yellow]Connectivity: no provider configured[/yellow]")

    # Registered providers
    registered = list_providers()
    console.print(f"Registered providers: {', '.join(registered)}")

    # Feature gates
    gates = _get_feature_gates()
    console.print("Feature gates:")
    for feature, available in sorted(gates.items()):
        icon = "[green]\u2713[/green]" if available else "[red]\u2717[/red]"
        console.print(f"  {icon} {feature}")


def show_config() -> None:
    """Show resolved PM workflow configuration."""
    raw_config = _load_raw_config()
    try:
        provider_name, workflow = load_pm_config(raw_config)
    except (FileNotFoundError, ValueError, KeyError) as e:
        logger.debug("Config load error: %s", e)
        console.print("[yellow]Could not load config — check config.yaml syntax[/yellow]")
        return

    console.print(f"Provider: {provider_name}")
    console.print(f"Workflow mode: {workflow.mode}")

    if workflow.work_items:
        console.print("Work item types:")
        for name, wit in workflow.work_items.items():
            console.print(f"  {name}: {wit.label or name}")

    if workflow.completion_rules:
        console.print("Completion rules:")
        for item_type, rule in workflow.completion_rules.items():
            dest = rule.completion_destination or "(none)"
            console.print(f"  {item_type} -> {dest}")
            if rule.requires:
                console.print(f"    requires: {', '.join(rule.requires)}")

    if workflow.automations:
        console.print(f"Automations: {len(workflow.automations)} rule(s)")
        for auto in workflow.automations:
            console.print(f"  trigger: {auto.trigger}")
