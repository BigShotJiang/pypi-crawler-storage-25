"""PM CRUD subcommands — create, move, comment, check, set-field.

Commands are defined on ``crud_app`` and registered on the main pm app
via ``app.add_typer(crud_app)`` with no prefix, so they appear as
``pm create``, ``pm move``, etc.

Hierarchy commands (link, unlink, action) live in ``pm_hierarchy_cmd.py``.
"""

from __future__ import annotations

import logging
from typing import Optional

import typer
from rich.console import Console
from rich.markup import escape as rich_escape

from ..licensing import require_feature
from ..pm.provider import ProjectManagementProvider
from ..pm.types import (
    PMRelationship,
    PMWorkItem,
    RelationshipType,
    WorkItemStatus,
    WorkItemType,
)

logger = logging.getLogger(__name__)
console = Console()

crud_app = typer.Typer()


def _get_provider() -> Optional[ProjectManagementProvider]:
    """Get the active PM provider (delegated from pm_helpers)."""
    from .pm_helpers import _get_provider as _pm_get_provider
    return _pm_get_provider()


def _require_provider() -> ProjectManagementProvider:
    """Get provider or exit with error."""
    provider = _get_provider()
    if provider is None:
        console.print("[red]No PM provider configured[/red]")
        raise typer.Exit(1)
    return provider


@crud_app.command("create")
@require_feature("pm_basic")
def pm_create(
    item_type: str = typer.Option(..., "--type", help="Type: task, story, epic"),
    title: str = typer.Option(..., "--title", help="Item title"),
    parent: Optional[str] = typer.Option(None, "--parent", help="Parent item ID"),
) -> None:
    """Create a new work item via the PM provider."""
    provider = _require_provider()
    try:
        wtype = WorkItemType(item_type)
    except ValueError:
        valid = ", ".join(t.value for t in WorkItemType)
        console.print(f"[red]Invalid type: {item_type}. Valid: {valid}[/red]")
        raise typer.Exit(1)
    item = PMWorkItem(
        id="", title=title, status=WorkItemStatus.PENDING, item_type=wtype,
    )
    created = provider.create_item(item)
    if created is None:
        console.print("[red]Failed to create item[/red]")
        raise typer.Exit(1)

    pid = created.provider_meta.get("provider_id", "")
    console.print(f"[green]Created:[/green] {created.title} ({pid})")

    if parent and "hierarchy" in provider.capabilities():
        rel = PMRelationship(
            source_id=parent, target_id=pid or created.id,
            relationship_type=RelationshipType.PARENT_CHILD,
        )
        provider.set_relationship(rel)


@crud_app.command("move")
@require_feature("pm_basic")
def pm_move(
    item_id: str = typer.Argument(..., help="Work item ID"),
    status: str = typer.Option(..., "--status", help="Target status"),
) -> None:
    """Move a work item to a new status."""
    provider = _require_provider()
    try:
        target = WorkItemStatus(status)
    except ValueError:
        valid = ", ".join(s.value for s in WorkItemStatus)
        console.print(f"[red]Invalid status: {status}. Valid: {valid}[/red]")
        raise typer.Exit(1)

    ok = provider.move_item(item_id, target)
    if not ok:
        console.print(f"[red]Failed to move {item_id} to {status}[/red]")
        raise typer.Exit(1)
    console.print(f"[green]Moved {item_id} to {status}[/green]")


@crud_app.command("comment")
@require_feature("pm_basic")
def pm_comment(
    item_id: str = typer.Argument(..., help="Work item ID"),
    message: str = typer.Argument(..., help="Comment text (max 16000 chars)"),
) -> None:
    """Add a comment to a work item."""
    if len(message) > 16_000:
        console.print("[red]Comment too long (max 16000 characters)[/red]")
        raise typer.Exit(1)
    provider = _require_provider()
    ok = provider.add_comment(item_id, message)
    if not ok:
        console.print(f"[red]Failed to add comment to {item_id}[/red]")
        raise typer.Exit(1)
    console.print(f"[green]Comment added to {item_id}[/green]")


@crud_app.command("check")
@require_feature("pm_basic")
def pm_check(
    item_id: str = typer.Argument(..., help="Work item ID"),
    checklist_item_id: str = typer.Argument(..., help="Checklist item ID"),
    uncheck: bool = typer.Option(False, "--uncheck", help="Uncheck instead"),
) -> None:
    """Check or uncheck a checklist item."""
    provider = _require_provider()
    ok = provider.check_checklist_item(
        item_id, checklist_item_id, checked=not uncheck,
    )
    if not ok:
        action = "uncheck" if uncheck else "check"
        console.print(f"[red]Failed to {action} {rich_escape(checklist_item_id)}[/red]")
        raise typer.Exit(1)
    action = "Unchecked" if uncheck else "Checked"
    console.print(f"[green]{action} {rich_escape(checklist_item_id)} on {item_id}[/green]")


@crud_app.command("set-field")
@require_feature("pm_basic")
def pm_set_field(
    item_id: str = typer.Argument(..., help="Work item ID"),
    field_name: str = typer.Option(..., "--field", help="Field name"),
    value: str = typer.Option(..., "--value", help="Field value"),
) -> None:
    """Set a custom field on a work item."""
    if len(field_name) > 256 or len(value) > 4096:
        console.print("[red]Field name (max 256) or value (max 4096) too long[/red]")
        raise typer.Exit(1)
    provider = _require_provider()
    ok = provider.set_fields(item_id, {field_name: value})
    if not ok:
        console.print(f"[red]Failed to set {field_name} on {item_id}[/red]")
        raise typer.Exit(1)
    console.print(f"[green]Set {field_name}={value} on {item_id}[/green]")


