"""Handoff display helpers for the status command.

Provides functions to fetch and render handoff summaries in the
bpsai-pair status output. Gracefully returns empty results when
no handoff files exist or the consumer is unavailable.
"""
from __future__ import annotations

import logging
from pathlib import Path

from rich.console import Console

logger = logging.getLogger(__name__)


def _get_handoff_summary(paircoder_dir: Path):
    """Load handoff summary from the handoffs directory.

    Returns a HandoffSummary (possibly empty). Never raises.
    """
    try:
        from ..orchestration.handoff_consumer import (
            HandoffConsumer,
            HandoffSummary,
        )
    except ImportError:
        from bpsai_pair.orchestration.handoff_consumer import (
            HandoffConsumer,
            HandoffSummary,
        )

    try:
        handoffs_dir = paircoder_dir / "handoffs"
        consumer = HandoffConsumer(handoffs_dir)
        return consumer.consume_all()
    except Exception:
        logger.debug("Failed to consume handoffs", exc_info=True)
        return HandoffSummary()


def display_handoff_section(console: Console, paircoder_dir: Path) -> None:
    """Render handoff context in the status output.

    Shows nothing when no handoffs are pending. Displays task IDs,
    remaining work, and error counts when handoffs are present.

    Args:
        console: Rich console for output
        paircoder_dir: Path to the .paircoder directory
    """
    try:
        summary = _get_handoff_summary(paircoder_dir)
    except Exception:
        return

    if summary.total == 0:
        return

    console.print()
    console.print(f"[bold cyan]Pending Handoffs ({summary.total}):[/bold cyan]")
    for h in summary.handoffs:
        label = f"  {h.task_id} ({h.source_agent} -> {h.target_agent})"
        console.print(label)
        if h.remaining_work:
            console.print(f"    Remaining: {h.remaining_work}")

    if summary.errors:
        console.print(
            f"  [yellow]{len(summary.errors)} malformed handoff(s) skipped[/yellow]"
        )
