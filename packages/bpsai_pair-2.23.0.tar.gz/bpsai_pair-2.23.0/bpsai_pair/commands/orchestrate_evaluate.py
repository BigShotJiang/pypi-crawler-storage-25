"""Orchestration evaluate logic for CC TeammateIdle/TaskCompleted hooks.

EXPERIMENTAL: Outputs JSON for CC hook response. CC reads stdout to decide
whether to stop or continue a teammate agent.

Separated from orchestrate.py to stay under architecture line limits.
"""

from __future__ import annotations

import json
import logging
import sys
from typing import Optional

from ..core import ops
from ..engage.a2a_push import push_teammate_idle

logger = logging.getLogger(__name__)


def run_evaluate(
    event: str,
    agent_id: Optional[str] = None,
    agent_type: Optional[str] = None,
) -> None:
    """Evaluate stop conditions and output JSON to stdout."""
    from ..core.orchestration_hooks import evaluate_stop_conditions

    try:
        root = ops.find_project_root()
    except Exception:
        _output({"continue": True})
        return

    if event == "teammate_idle":
        try:
            push_teammate_idle({
                "agent_id": agent_id or "unknown",
                "agent_type": agent_type or "unknown",
            })
        except Exception as exc:
            logger.debug("Idle heartbeat push failed: %s", exc)

    result = evaluate_stop_conditions(
        event=event,
        agent_id=agent_id,
        agent_type=agent_type,
        project_root=root,
    )
    _output(result)


def _output(data: dict) -> None:
    """Write JSON to stdout without Rich formatting."""
    sys.stdout.write(json.dumps(data))
    sys.stdout.write("\n")
    sys.stdout.flush()
