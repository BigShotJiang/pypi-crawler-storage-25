"""Containment session entry: contained-auto and claude666 commands.

Handles starting contained autonomy sessions with checkpoint creation,
access control display, and Claude Code invocation.
"""
from __future__ import annotations

import atexit
import os
import subprocess
import sys
import shutil
from pathlib import Path
from typing import Optional

import typer
from rich.console import Console
from ..core import ops

console = Console()

_active_containment_manager = None


def repo_root() -> Path:
    """Get repo root with better error message."""
    p = ops.find_project_root()
    if not ops.GitOps.is_repo(p):
        console.print(
            "[red]x Not in a git repository.[/red]\n"
            "Please run from your project root directory (where .git exists).\n"
            "[dim]Hint: cd to your project directory first[/dim]"
        )
        raise typer.Exit(1)
    return p


def _cleanup_containment():
    """Cleanup handler for containment on exit."""
    from . import containment_commands as _cmds

    if _cmds._active_containment_manager is None:
        return

    _cmds._active_containment_manager.deactivate()
    _cmds._active_containment_manager = None

    stash_ref = os.environ.get("PAIRCODER_CONTAINMENT_STASH")
    if stash_ref:
        _restore_stashed_changes(stash_ref)

    os.environ.pop("PAIRCODER_CONTAINMENT", None)
    os.environ.pop("PAIRCODER_CONTAINMENT_CHECKPOINT", None)
    os.environ.pop("PAIRCODER_CONTAINMENT_STASH", None)


def _restore_stashed_changes(stash_ref: str) -> None:
    """Attempt to restore stashed changes after containment cleanup."""
    try:
        result = subprocess.run(
            ["git", "status", "--porcelain"],
            capture_output=True, text=True, check=False,
        )
        if result.stdout.strip():
            console.print()
            console.print("[yellow]\u26a0 Your stashed changes were NOT restored[/yellow]")
            console.print("[dim]  The container session left uncommitted changes.[/dim]")
            console.print("[dim]  To restore after resolving: git stash pop[/dim]")
            return

        project_root = os.getcwd()
        list_result = subprocess.run(
            ["git", "stash", "list"],
            capture_output=True, text=True, check=False, cwd=project_root,
        )
        stash_idx = None
        for line in list_result.stdout.strip().split("\n"):
            if stash_ref in line:
                stash_idx = line.split(":")[0]
                break

        if not stash_idx:
            console.print()
            console.print("[yellow]\u26a0 Could not find stashed changes[/yellow]")
            console.print(f"[dim]  Stash message: {stash_ref}[/dim]")
            return

        pop_result = subprocess.run(
            ["git", "stash", "pop", stash_idx],
            capture_output=True, text=True, check=False, cwd=project_root,
        )
        console.print()
        if pop_result.returncode == 0:
            console.print("[green]\u2713 Restored your stashed changes[/green]")
        else:
            console.print("[yellow]\u26a0 Could not restore stashed changes[/yellow]")
            console.print(f"[dim]  {pop_result.stderr.strip()}[/dim]")
    except Exception as e:
        console.print(f"\n[yellow]\u26a0 Error restoring stashed changes: {e}[/yellow]")
        console.print("[dim]  Your changes may still be in the stash. Try: git stash list[/dim]")


ROBOT_DEVIL_ART = """
[red]
    \u2554\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2557
    \u2551         .---.                            \u2551
    \u2551        /  6 6\\    CLAUDE 666             \u2551
    \u2551        \\  ^  /    Beast Mode Activated   \u2551
    \u2551         '-.-'                            \u2551
    \u2551        /|   |\\    Powerful but Contained \u2551
    \u2551       (_|   |_)                          \u2551
    \u255a\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u255d
[/red]
"""


def _setup_checkpoint(config, project_root, skip_checkpoint):
    """Create git checkpoint if enabled. Returns (checkpoint_id, stash_ref)."""
    if skip_checkpoint:
        console.print("[dim]Checkpoint skipped (--skip-checkpoint)[/dim]")
        return None, None

    if not config.containment.auto_checkpoint:
        return None, None

    from ..security.checkpoint import GitCheckpoint

    try:
        checkpoint = GitCheckpoint(project_root)
        if checkpoint.is_dirty():
            console.print("[yellow]Warning: Uncommitted changes detected[/yellow]")
            console.print("[dim]Changes will be stashed before checkpoint[/dim]")

        checkpoint_id, stash_ref = checkpoint.create_containment_checkpoint(auto_stash=True)
        console.print(f"[green]\u2713 Checkpoint created:[/green] {checkpoint_id}")
        if stash_ref:
            console.print(f"[dim]  Stashed changes: {stash_ref}[/dim]")
        return checkpoint_id, stash_ref
    except Exception as e:
        console.print(f"[yellow]Warning: Could not create checkpoint: {e}[/yellow]")
        if not typer.confirm("Continue without checkpoint?"):
            raise typer.Abort()
        return None, None


def _display_access_controls(config, task, checkpoint_id):
    """Display blocked and read-only paths to the user."""
    console.print()
    console.print("[bold green]\u2713 Contained autonomy mode active[/bold green]")
    console.print()

    if config.containment.blocked_directories or config.containment.blocked_files:
        console.print("[red]Blocked paths (no read/write):[/red]")
        for d in config.containment.blocked_directories:
            console.print(f"  [dim]\U0001f6ab[/dim] {d}")
        for f in config.containment.blocked_files:
            console.print(f"  [dim]\U0001f6ab[/dim] {f}")
        console.print()

    if config.containment.readonly_directories or config.containment.readonly_files:
        console.print("[yellow]Read-only paths (can read, no write):[/yellow]")
        for d in config.containment.readonly_directories:
            console.print(f"  [dim]\U0001f4c1[/dim] {d}")
        for f in config.containment.readonly_files:
            console.print(f"  [dim]\U0001f4c4[/dim] {f}")
        console.print()

    if task:
        console.print(f"[cyan]Task:[/cyan] {task}")
        console.print()

    console.print("[dim]Blocked paths cannot be accessed. Read-only paths can be read but not modified.[/dim]")
    if checkpoint_id:
        console.print(f"[dim]Rollback available: git reset --hard {checkpoint_id}[/dim]")
    console.print()


def _run_claude_strict(config, project_root, claude_cmd, checkpoint_id):
    """Run Claude in strict (Docker) containment mode. Returns True if fallback needed."""
    from ..security.sandbox import SandboxRunner, SandboxConfig, containment_config_to_mounts

    sandbox_config = SandboxConfig(
        enabled=True,
        image=os.environ.get("PAIRCODER_SANDBOX_IMAGE", "paircoder/sandbox:latest"),
        network="none",
    )
    mounts, excluded = containment_config_to_mounts(config.containment, project_root)
    sandbox_config.mounts = mounts[1:]

    network_allowlist = None
    if hasattr(config.containment, 'allow_network') and config.containment.allow_network:
        network_allowlist = config.containment.allow_network

    runner = SandboxRunner(project_root, sandbox_config)
    try:
        env = {"PAIRCODER_CONTAINMENT": "1", "PAIRCODER_CONTAINMENT_MODE": "strict"}
        if checkpoint_id:
            env["PAIRCODER_CONTAINMENT_CHECKPOINT"] = checkpoint_id
        exit_code = runner.run_interactive(claude_cmd, env=env, network_allowlist=network_allowlist)
        sys.exit(exit_code)
    except RuntimeError as e:
        console.print(f"[red]Docker error: {e}[/red]")
        console.print("[dim]Falling back to advisory mode[/dim]")
        return True
    except KeyboardInterrupt:
        console.print("\n[yellow]Session interrupted.[/yellow]")
        raise typer.Exit(130)
    return False


def _run_claude_advisory(project_root, claude_cmd):
    """Run Claude in advisory mode (local, no Docker)."""
    claude_exe = shutil.which("claude")
    if claude_exe is None:
        console.print("[red]Error: 'claude' command not found.[/red]")
        console.print("[dim]Install Claude Code: https://docs.anthropic.com/claude-code[/dim]")
        raise typer.Exit(1)

    host_cmd = [claude_exe] + claude_cmd[1:]
    try:
        result = subprocess.run(host_cmd, cwd=project_root)
        sys.exit(result.returncode)
    except FileNotFoundError:
        console.print("[red]Error: 'claude' command not found.[/red]")
        raise typer.Exit(1)
    except KeyboardInterrupt:
        console.print("\n[yellow]Session interrupted.[/yellow]")
        raise typer.Exit(130)


def _load_project_config(project_root):
    """Load and validate project config. Exits on error."""
    from ..core.config import Config

    if not (project_root / ".paircoder").exists():
        console.print("[red]No .paircoder directory found[/red]")
        raise typer.Exit(1)
    try:
        return Config.load(project_root)
    except Exception as e:
        console.print(f"[red]Error loading config: {e}[/red]")
        raise typer.Exit(1)


def _activate_containment(_cmds, config, project_root, checkpoint_id, stash_ref):
    """Activate containment manager and set environment variables."""
    from ..security.containment import ContainmentManager

    containment = ContainmentManager(config.containment, project_root)
    containment.activate()
    _cmds._active_containment_manager = containment
    atexit.register(_cleanup_containment)

    os.environ["PAIRCODER_CONTAINMENT"] = "1"
    if checkpoint_id:
        os.environ["PAIRCODER_CONTAINMENT_CHECKPOINT"] = checkpoint_id
    if stash_ref:
        os.environ["PAIRCODER_CONTAINMENT_STASH"] = stash_ref


def _resolve_mode(config):
    """Resolve containment mode, falling back to advisory if Docker unavailable."""
    mode = config.containment.mode
    if mode == "strict":
        from ..security.sandbox import SandboxRunner
        if not SandboxRunner.is_docker_available():
            console.print("[yellow]Warning: Docker not available for strict containment[/yellow]")
            return "advisory"
        console.print("[bold cyan]Mode: STRICT[/bold cyan] (Docker-enforced containment)")
    return mode


def contained_auto(
    task: Optional[str] = typer.Argument(None, help="Task to work on"),
    skip_checkpoint: bool = typer.Option(False, "--skip-checkpoint", help="Skip git checkpoint creation"),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation prompt"),
    channels: bool = typer.Option(False, "--channels", help="Enable coordination channels plugin"),
):
    """Start a contained autonomous session."""
    # Lazy import so mocks on containment_commands.repo_root work
    from . import containment_commands as _cmds

    project_root = _cmds.repo_root()
    config = _load_project_config(project_root)

    if not config.containment.enabled:
        console.print("[yellow]Warning: Containment not enabled in config[/yellow]")
        if not typer.confirm("Enable containment for this session?"):
            raise typer.Abort()

    checkpoint_id, stash_ref = _setup_checkpoint(config, project_root, skip_checkpoint)
    _activate_containment(_cmds, config, project_root, checkpoint_id, stash_ref)
    _display_access_controls(config, task, checkpoint_id)

    if not yes:
        if not typer.confirm("Proceed with these access controls?", default=True):
            console.print("[yellow]Aborted.[/yellow]")
            _cleanup_containment()
            raise typer.Abort()

    mode = _resolve_mode(config)
    if mode != "strict":
        console.print("[bold yellow]Mode: ADVISORY[/bold yellow] (path checks only)")

    console.print()
    console.print("[bold]Launching Claude Code with autonomous permissions...[/bold]")
    console.print()

    claude_cmd = ["claude", "--dangerously-skip-permissions"]
    if channels:
        claude_cmd.extend(["--mcp", "bpsai-coordination-channels"])
    if task:
        claude_cmd.extend(["--prompt", f"Work on task {task}. Remember: containment mode is active."])

    if mode == "strict":
        if not _run_claude_strict(config, project_root, claude_cmd, checkpoint_id):
            return

    _run_claude_advisory(project_root, claude_cmd)


def claude666(
    task: Optional[str] = typer.Argument(None, help="Task to work on"),
    skip_checkpoint: bool = typer.Option(False, "--skip-checkpoint", help="Skip git checkpoint creation"),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation prompt"),
    channels: bool = typer.Option(False, "--channels", help="Enable coordination channels plugin"),
):
    """Claude's beast mode - If you know, you know."""
    console.print(ROBOT_DEVIL_ART)
    return contained_auto(task=task, skip_checkpoint=skip_checkpoint, yes=yes, channels=channels)
