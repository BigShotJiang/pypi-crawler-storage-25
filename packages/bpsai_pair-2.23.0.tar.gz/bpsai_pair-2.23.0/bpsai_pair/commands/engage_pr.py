"""PR creation and display helpers extracted from engage_guards.py (P0-2 split)."""
from __future__ import annotations

import json
import logging
import re
import subprocess
from pathlib import Path
from typing import Any

import typer

logger = logging.getLogger(__name__)


def _is_human_gated(task: Any) -> bool:
    """Return True if task requires human intervention."""
    return (
        getattr(task, "requires", "autonomous") == "human"
        or bool(getattr(task, "external_tools", []))
    )


def show_dry_run(parsed: Any, json_out: bool) -> None:
    """Display dry run plan without executing."""
    total_cx = sum(t.complexity for t in parsed.tasks)
    phases = {t.phase for t in parsed.tasks}
    human_count = sum(1 for t in parsed.tasks if _is_human_gated(t))
    if json_out:
        typer.echo(json.dumps({
            "dry_run": True, "tasks": len(parsed.tasks),
            "total_complexity": total_cx, "phases": len(phases),
            "human_gated_tasks": human_count,
        }, indent=2))
    else:
        typer.echo(f"Dry run -- {len(parsed.tasks)} tasks, {total_cx} cx, "
                   f"{len(phases)} phase(s)")
        for task in parsed.tasks:
            prefix = "[HUMAN] " if _is_human_gated(task) else ""
            typer.echo(f"  {prefix}Phase {task.phase}: {task.id} -- {task.title} "
                       f"(Cx: {task.complexity}, {task.priority})")
        if human_count:
            typer.echo(f"{human_count} human-gated task(s) — "
                       "engage will pause before each")


def infer_sprint(parsed: Any) -> str:
    """Infer sprint number from first task ID."""
    if parsed.tasks:
        match = re.match(r"[A-Za-z]+(\d+)", parsed.tasks[0].id)
        if match:
            return match.group(1)
    return "0"


def _extract_backlog_title(project_root: Path) -> str | None:
    """Extract the H1 title from the engage backlog on the current branch."""
    try:
        branch_result = subprocess.run(
            ["git", "branch", "--show-current"],
            cwd=project_root, capture_output=True, check=False,
            encoding="utf-8", errors="replace",
        )
        branch = branch_result.stdout.strip()
        if not branch.startswith("engage/"):
            return None
        backlog_stem = branch.removeprefix("engage/")
        for candidate in [
            project_root / "plans" / "backlogs" / f"{backlog_stem}.md",
            project_root / f"{backlog_stem}.md",
        ]:
            if candidate.exists():
                for line in candidate.read_text(encoding="utf-8").splitlines():
                    if line.startswith("# "):
                        title = line.removeprefix("# ").strip()
                        return title[:70] if title else None
    except Exception:
        pass
    return None


def _build_pr_title(
    project_root: Path, sprint_id: str, done: int, failed: int,
) -> str:
    """Build a descriptive PR title from backlog theme, falling back to counts."""
    theme = _extract_backlog_title(project_root)
    if theme:
        return f"{theme} ({done} done, {failed} failed)"
    return f"Sprint {sprint_id}: {done} done, {failed} failed"


def _build_pr_body(result: Any) -> str:
    """Build markdown body for the sprint PR."""
    sections: list[str] = []
    if result.completed_tasks:
        items = "\n".join(f"- {t}" for t in result.completed_tasks)
        sections.append(f"## Completed\n{items}")
    if result.failed_tasks:
        items = "\n".join(f"- {t}" for t in result.failed_tasks)
        sections.append(f"## Failed\n{items}")
    hook_failed = getattr(result, "hook_failed_tasks", [])
    if hook_failed:
        items = "\n".join(f"- {t}" for t in hook_failed)
        sections.append(f"## Hook-Failed\n{items}")
    if result.blocked_tasks:
        items = "\n".join(f"- {t}" for t in result.blocked_tasks)
        sections.append(f"## Blocked\n{items}")
    return "\n\n".join(sections)


def _detect_pr_base(project_root: Path) -> str:
    """Detect the correct PR base branch: prefer dev, fall back to main."""
    try:
        result = subprocess.run(
            ["git", "branch", "--list", "--format=%(refname:short)"],
            cwd=str(project_root),
            capture_output=True, timeout=10,
            encoding="utf-8", errors="replace",
        )
        if "dev" in result.stdout.split():
            return "dev"
    except (subprocess.TimeoutExpired, FileNotFoundError, OSError):
        pass
    return "main"


def _check_pr_exists(project_root: Path, branch: str) -> bool:
    """Return True if an open PR already exists for the given branch."""
    try:
        result = subprocess.run(
            ["gh", "pr", "list", "--head", branch, "--state", "open",
             "--limit", "1", "--json", "url", "-q", ".[0].url"],
            cwd=project_root, capture_output=True, check=False,
            encoding="utf-8", errors="replace", timeout=15,
        )
        return result.returncode == 0 and bool(result.stdout.strip())
    except (subprocess.TimeoutExpired, FileNotFoundError, OSError):
        return False


def _create_pull_request(
    project_root: Path, branch: str, result: Any, sprint_id: str,
    skip_if_exists: bool = False,
) -> str | None:
    """Push branch and create a PR after sprint completes."""
    if not result.completed_tasks:
        return None
    push = subprocess.run(
        ["git", "push", "-u", "origin", branch],
        cwd=project_root, capture_output=True, check=False,
        encoding="utf-8", errors="replace",
    )
    if push.returncode != 0:
        logger.warning("Push failed: %s", push.stderr)
        return None
    if skip_if_exists and _check_pr_exists(project_root, branch):
        logger.info("PR already exists for %s, skipping creation", branch)
        return None
    done, failed = len(result.completed_tasks), len(result.failed_tasks)
    title = _build_pr_title(project_root, sprint_id, done, failed)
    base = _detect_pr_base(project_root)
    pr = subprocess.run(
        ["gh", "pr", "create", "--base", base,
         "--title", title, "--body", _build_pr_body(result)],
        cwd=project_root, capture_output=True, check=False,
        encoding="utf-8", errors="replace",
    )
    if pr.returncode != 0:
        logger.warning("PR creation failed: %s", pr.stderr)
        return None
    return pr.stdout.strip()
