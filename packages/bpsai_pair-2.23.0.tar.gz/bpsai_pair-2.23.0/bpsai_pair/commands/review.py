"""bpsai-pair review -- code review commands (PR, branch, task)."""
from __future__ import annotations

import json
from typing import Any, Callable, Optional

import typer

from bpsai_pair.orchestration.branch_review import review_branch
from bpsai_pair.orchestration.pr_review import review_pr
from bpsai_pair.orchestration.task_review_command import review_task_changes

app = typer.Typer(
    help="Code review commands",
    context_settings={"help_option_names": ["-h", "--help"]},
)


def _handle_result(
    result: dict[str, Any],
    json_out: bool,
    show_fn: Callable[[dict[str, Any]], None],
) -> None:
    """Emit output and raise Exit(1) when action is request_changes or error."""
    if json_out:
        typer.echo(json.dumps(result, indent=2))
    else:
        show_fn(result)
    if result["action"] in ("request_changes", "error"):
        raise typer.Exit(1)


@app.command("pr")
def pr_command(
    number: int = typer.Argument(..., help="GitHub PR number to review"),
    post: bool = typer.Option(
        False, "--post", help="Post review to PR via gh pr review",
    ),
    json_out: bool = typer.Option(
        False, "--json", help="Structured JSON output for CI",
    ),
) -> None:
    """Review a GitHub PR by number."""
    from bpsai_pair.core.utils import repo_root

    project_root = repo_root()
    result = review_pr(project_root, number, post=post)
    _handle_result(result, json_out, lambda r: _show_result(r, number))


def _show_result(result: dict, pr_number: int) -> None:
    """Display review result to terminal."""
    action = result["action"]
    if action == "skipped":
        reason = result.get("reason", "unknown")
        typer.echo(f"Review skipped for PR #{pr_number}: {reason}")
        return

    agents = ", ".join(result.get("agents", []))
    lines = result.get("lines_changed", 0)
    files = result.get("files_changed", 0)

    typer.echo(f"PR #{pr_number}: {lines} lines, {files} files")
    typer.echo(f"Agents: {agents}")
    typer.echo(f"Action: {action}")

    if result.get("errors"):
        typer.echo(f"Errors: {result['errors']}")

    findings = result.get("findings", "")
    if findings:
        typer.echo("\n--- Findings ---")
        typer.echo(findings)


@app.command("task")
def task_command(
    task_id: Optional[str] = typer.Argument(
        None, help="Task ID to review (reviews uncommitted changes if omitted)",
    ),
    json_out: bool = typer.Option(
        False, "--json", help="Structured JSON output for CI",
    ),
) -> None:
    """Review a single task's changes."""
    from bpsai_pair.core.utils import repo_root

    project_root = repo_root()
    result = review_task_changes(project_root, task_id=task_id)
    _handle_result(result, json_out, lambda r: _show_task_result(r, task_id))


def _show_task_result(result: dict, task_id: str | None) -> None:
    """Display task review result to terminal."""
    action = result["action"]
    label = f"Task {task_id}" if task_id else "Uncommitted changes"
    if action == "skipped":
        reason = result.get("reason", "unknown")
        typer.echo(f"Review skipped for {label}: {reason}")
        return

    typer.echo(f"{label}: {action}")
    findings = result.get("findings", "")
    if findings:
        typer.echo("\n--- Findings ---")
        typer.echo(findings)


@app.command("auto")
def auto_command(
    query: Optional[str] = typer.Argument(
        None, help="Freeform review request (e.g. '146', 'T18.3', or empty for branch)",
    ),
    json_out: bool = typer.Option(
        False, "--json", help="Structured JSON output for CI",
    ),
) -> None:
    """Auto-route a review request to the correct subcommand."""
    from bpsai_pair.core.utils import repo_root
    from bpsai_pair.planning.review_intent import (
        ReviewSubIntent, classify_review_subintent,
    )

    project_root = repo_root()
    text = query or ""
    intent = classify_review_subintent(f"review {text}".strip())

    if intent.sub_intent == ReviewSubIntent.PR_REVIEW and intent.pr_number:
        result = review_pr(project_root, intent.pr_number)
        _handle_result(result, json_out, lambda r: _show_result(r, intent.pr_number))
        return

    if intent.sub_intent == ReviewSubIntent.TASK_REVIEW and intent.task_id:
        result = review_task_changes(project_root, task_id=intent.task_id)
        _handle_result(result, json_out, lambda r: _show_task_result(r, intent.task_id))
        return

    # Default: branch review (PRE_PR or ambiguous with no args)
    result = review_branch(project_root)
    _handle_result(result, json_out, _show_branch_result)


@app.command("branch")
def branch_command(
    base: Optional[str] = typer.Option(
        None, "--base", help="Base branch to diff against (auto-detects if omitted)",
    ),
    json_out: bool = typer.Option(
        False, "--json", help="Structured JSON output for CI",
    ),
) -> None:
    """Review the current branch diff against base (pre-PR validation)."""
    from bpsai_pair.core.utils import repo_root

    project_root = repo_root()
    result = review_branch(project_root, base=base)
    _handle_result(result, json_out, _show_branch_result)


def _show_branch_result(result: dict) -> None:
    """Display branch review result to terminal."""
    action = result["action"]
    base = result.get("base_branch", "?")
    if action == "skipped":
        reason = result.get("reason", "unknown")
        typer.echo(f"Review skipped (base={base}): {reason}")
        return

    agents = ", ".join(result.get("agents", []))
    lines = result.get("lines_changed", 0)
    files = result.get("files_changed", 0)

    typer.echo(f"Branch vs {base}: {lines} lines, {files} files")
    typer.echo(f"Agents: {agents}")
    typer.echo(f"Action: {action}")

    if result.get("errors"):
        typer.echo(f"Errors: {result['errors']}")

    findings = result.get("findings", "")
    if findings:
        typer.echo("\n--- Findings ---")
        typer.echo(findings)
