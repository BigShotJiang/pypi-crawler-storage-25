"""Wizard CLI command.

Provides the `bpsai-pair wizard` command to start the web-based setup wizard.
"""

from __future__ import annotations

import signal
import sys
import threading
from pathlib import Path

import typer
from rich.console import Console

console = Console()

# Create wizard command group
wizard_app = typer.Typer(
    help="Setup wizard commands",
    context_settings={"help_option_names": ["-h", "--help"]},
)


def _check_dependencies() -> bool:
    """Check if wizard dependencies are installed."""
    try:
        import fastapi  # noqa: F401
        import jinja2  # noqa: F401
        import uvicorn  # noqa: F401
        return True
    except ImportError:
        return False


def _open_browser_delayed(url: str, delay: float = 1.0) -> None:
    """Open browser after a short delay to let server start."""
    import time
    from bpsai_pair.wizard.app import open_browser

    time.sleep(delay)
    open_browser(url)


def _check_optional_deps() -> list[str]:
    """Check for optional dependencies and return warnings for missing ones."""
    warnings: list[str] = []
    try:
        import trello  # noqa: F401
    except ImportError:
        warnings.append(
            "py-trello not installed — Trello integration unavailable. "
            "Install: [cyan]pip install py-trello[/cyan]",
        )
    try:
        import github  # noqa: F401
    except ImportError:
        warnings.append(
            "PyGithub not installed — GitHub integration unavailable. "
            "Install: [cyan]pip install PyGithub[/cyan]",
        )
    return warnings


def _check_api_key() -> bool:
    """Check if ANTHROPIC_API_KEY is available."""
    import os
    return bool(os.environ.get("ANTHROPIC_API_KEY"))


def _print_api_key_warning() -> None:
    """Print API key warning with developer key guidance."""
    console.print()
    console.print("[yellow]Note:[/yellow] ANTHROPIC_API_KEY not found.")
    console.print(
        "This is a [bold]developer API key[/bold] (not your claude.ai login).",
    )
    console.print("The [bold]Guided Setup[/bold] chat feature requires it.")
    console.print("You can still use [bold]Quick Setup[/bold] without it.")
    console.print()
    console.print(
        "Get your key at: [cyan]https://console.anthropic.com/settings/keys[/cyan]",
    )
    console.print("  [cyan]export ANTHROPIC_API_KEY='sk-ant-...'[/cyan]")


def _print_dep_warnings(dep_warnings: list[str]) -> None:
    """Print optional dependency warnings."""
    console.print()
    console.print("[yellow]Optional dependencies missing:[/yellow]")
    for warning in dep_warnings:
        console.print(f"  {warning}")


def run_server(port: int, no_browser: bool = False, demo: bool = False) -> None:
    """Run the wizard server."""
    import uvicorn
    from bpsai_pair.wizard.app import create_app

    app = create_app()
    url = f"http://localhost:{port}"
    if demo:
        url += "?demo=1"

    if not no_browser:
        browser_thread = threading.Thread(
            target=_open_browser_delayed, args=(url,), daemon=True,
        )
        browser_thread.start()

    console.print()
    console.print("[bold blue]PairCoder Setup Wizard[/bold blue]")
    if demo:
        console.print("[yellow]Demo mode:[/yellow] Files will be written to a temp directory")
    console.print(f"Running at: [cyan]{url}[/cyan]")

    if not _check_api_key():
        _print_api_key_warning()

    dep_warnings = _check_optional_deps()
    if dep_warnings:
        _print_dep_warnings(dep_warnings)

    console.print()
    console.print("[dim]Press Ctrl+C to stop[/dim]")
    console.print()

    uvicorn.run(app, host="localhost", port=port, log_level="warning")


def _has_existing_config() -> bool:
    """Check if an existing .paircoder/config.yaml exists in the CWD."""
    return (Path.cwd() / ".paircoder" / "config.yaml").exists()


def _abort_missing_deps() -> None:
    """Print error message and raise exit for missing dependencies."""
    console.print("[red]Error:[/red] Wizard dependencies not installed.")
    console.print()
    console.print("Install with:")
    console.print("  [cyan]pip install bpsai-pair[wizard][/cyan]")
    console.print()
    raise typer.Exit(1)


def _abort_existing_config() -> None:
    """Print warning and raise exit when existing config is found."""
    console.print("[yellow]Warning:[/yellow] Existing .paircoder/config.yaml found.")
    console.print("The wizard may overwrite your existing configuration.")
    console.print()
    console.print("Options:")
    console.print("  [cyan]--demo[/cyan]   Run in demo mode (writes to temp directory)")
    console.print("  [cyan]--force[/cyan]  Overwrite existing config")
    console.print()
    raise typer.Exit(1)


@wizard_app.callback(invoke_without_command=True)
def wizard_main(
    ctx: typer.Context,
    port: int = typer.Option(8765, "--port", "-p", help="Port to run the wizard on"),
    no_browser: bool = typer.Option(False, "--no-browser", help="Don't open browser automatically"),
    demo: bool = typer.Option(False, "--demo", help="Run in demo mode (writes to temp directory)"),
    force: bool = typer.Option(False, "--force", help="Overwrite existing config without prompting"),
) -> None:
    """Start the PairCoder setup wizard.

    Launches a web-based setup wizard at http://localhost:8765 (default).
    The wizard guides you through configuring PairCoder for your project.
    """
    if ctx.invoked_subcommand is not None:
        return

    if not _check_dependencies():
        _abort_missing_deps()

    if not demo and not force and _has_existing_config():
        _abort_existing_config()

    def signal_handler(sig, frame):
        console.print("\n[dim]Shutting down...[/dim]")
        sys.exit(0)

    signal.signal(signal.SIGINT, signal_handler)
    run_server(port=port, no_browser=no_browser, demo=demo)
