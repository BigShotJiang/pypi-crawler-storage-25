"""PM sprint subcommands — start and complete sprints."""

from __future__ import annotations

import logging

import typer
from rich.console import Console

from ..core.ops import find_paircoder_dir
from ..licensing import require_feature
from ..pm.sprint_lifecycle import (
    CarryForwardResult, SprintSummary,
    carry_forward, complete_sprint, start_sprint,
)

logger = logging.getLogger(__name__)
console = Console()

sprint_app = typer.Typer(name="sprint", help="Sprint lifecycle operations")


def _get_parsers():
    """Load PlanParser and TaskParser from the project directory."""
    paircoder_dir = find_paircoder_dir()
    from ..planning.plan_parser import PlanParser
    from ..planning.task_parser import TaskParser
    return PlanParser(paircoder_dir / "plans"), TaskParser(paircoder_dir / "tasks")


def _fire_sprint_hook(event: str, plan_id: str, *, extra: dict | None = None):
    """Fire a sprint lifecycle hook event."""
    try:
        from ..core.hooks import HookRunner, HookContext, load_config
        paircoder_dir = find_paircoder_dir()
        config = load_config(paircoder_dir)
        runner = HookRunner(config, paircoder_dir)
        if not runner.enabled:
            return
        hook_extra = {"sprint_id": plan_id}
        if extra:
            hook_extra.update(extra)
        ctx = HookContext(
            task_id=plan_id, event=event,
            agent="cli", extra=hook_extra,
        )
        runner.run_hooks(event, ctx)
    except ImportError:
        logger.debug("Could not import hooks for %s: module not found", event)
    except Exception as exc:
        logger.debug("%s hook failed: %s", event, exc)


@sprint_app.command("start")
@require_feature("pm_basic")
def sprint_start(
    plan_id: str = typer.Argument(..., help="Plan ID to start as sprint"),
) -> None:
    """Start a sprint (mark plan as in-progress)."""
    plan_parser, _ = _get_parsers()
    ok = start_sprint(plan_id, plan_parser)
    if not ok:
        console.print(f"[red]Plan not found: {plan_id}[/red]")
        raise typer.Exit(1)

    console.print(f"[green]Sprint started:[/green] {plan_id}")
    _fire_sprint_hook("on_sprint_planned", plan_id)


@sprint_app.command("complete")
@require_feature("pm_basic")
def sprint_complete(
    plan_id: str = typer.Argument(..., help="Plan ID to complete"),
    carry_forward_to: str | None = typer.Option(
        None, "--carry-forward", help="Plan ID to carry incomplete tasks to",
    ),
) -> None:
    """Complete a sprint — evaluate tasks and produce summary."""
    plan_parser, task_parser = _get_parsers()
    summary = complete_sprint(plan_id, plan_parser, task_parser)
    if summary is None:
        console.print(f"[red]Plan not found: {plan_id}[/red]")
        raise typer.Exit(1)

    _display_summary(plan_id, summary)

    if carry_forward_to and summary.carry_forward_ids:
        result = carry_forward(plan_id, carry_forward_to, plan_parser, task_parser)
        if result is None:
            console.print(f"[red]Carry-forward failed: target plan not found[/red]")
        elif result.moved_count > 0:
            console.print(f"\n[green]Carried {result.moved_count} task(s) to {carry_forward_to}[/green]")
    elif not carry_forward_to and summary.carry_forward_ids:
        console.print(
            f"\n[dim]Tip: Use --carry-forward <plan-id> to move "
            f"{len(summary.carry_forward_ids)} incomplete task(s) to a new plan[/dim]"
        )

    _fire_sprint_hook("on_sprint_completed", plan_id, extra={
        "completed": summary.completed,
        "carry_forward": summary.carry_forward_ids,
    })


def _display_summary(plan_id: str, summary: SprintSummary) -> None:
    """Print sprint completion summary."""
    console.print(f"\n[bold]Sprint Summary:[/bold] {plan_id}")
    console.print(f"  Completed:   {summary.completed}")
    console.print(f"  In Progress: {summary.in_progress}")
    console.print(f"  Blocked:     {summary.blocked}")
    console.print(f"  Pending:     {summary.pending}")

    if summary.all_done:
        console.print("\n[green]All tasks complete — sprint finished.[/green]")
    elif summary.carry_forward_ids:
        console.print(f"\n[yellow]Carry-forward ({len(summary.carry_forward_ids)}):[/yellow]")
        for tid in summary.carry_forward_ids:
            console.print(f"  - {tid}")
