"""Containment enforcement for PreToolUse hooks.

Adds a 'containment' subcommand to the enforce Typer app that checks
file access against containment tier configuration (blocked/readonly/readwrite).

Exit codes: 0 = allowed, 2 = blocked.
"""

import logging
import sys
from pathlib import Path

import typer
import yaml

from .enforce import app, find_paircoder_dir, output_block_message
from ..security.containment_check import ContainmentChecker, log_rejection

logger = logging.getLogger(__name__)


def _load_containment_config(paircoder_dir: Path) -> dict | None:
    """Load the containment section from config.yaml.

    Returns None if config file or containment key is missing.
    """
    config_path = paircoder_dir / "config.yaml"
    if not config_path.exists():
        return None
    try:
        with open(config_path, encoding="utf-8") as f:
            config = yaml.safe_load(f) or {}
        return config.get("containment")
    except Exception as exc:
        logger.warning("Failed to load containment config: %s", exc)
        return None


@app.command("containment")
def enforce_containment(
    file_path: str = typer.Option(
        ..., "--file", "-f", help="Path to file being accessed"
    ),
    operation: str = typer.Option(
        "write", "--operation", "-o", help="Operation type: read or write"
    ),
) -> None:
    """Enforce containment tiers for PreToolUse hook.

    Exit codes: 0 = allowed, 2 = blocked.
    """
    paircoder_dir = find_paircoder_dir()
    if paircoder_dir is None:
        sys.exit(0)

    containment_cfg = _load_containment_config(paircoder_dir)
    if containment_cfg is None:
        sys.exit(0)

    project_root = paircoder_dir.parent
    checker = ContainmentChecker(project_root, containment_cfg)
    result = checker.check_access(Path(file_path), operation)

    if not result.allowed:
        log_rejection(paircoder_dir / "bypass_log.jsonl", result)
        output_block_message(
            f"Containment: {result.reason}\n"
            f"Tier: {result.tier} | Operation: {result.operation}"
        )
        sys.exit(2)

    sys.exit(0)


def enforce_containment_check(ctx, paircoder_dir: Path) -> dict:
    """Hook-callable function for containment enforcement.

    Called by the HookRunner delegate system. Returns a dict
    with 'blocked' and 'reason' keys.
    """
    containment_cfg = _load_containment_config(paircoder_dir)
    if containment_cfg is None:
        return {"blocked": False, "reason": "No containment config"}

    project_root = paircoder_dir.parent
    checker = ContainmentChecker(project_root, containment_cfg)

    file_path = getattr(ctx, "file_path", None)
    operation = getattr(ctx, "operation", "write")

    if file_path is None:
        return {"blocked": False, "reason": "No file_path in context"}

    result = checker.check_access(Path(file_path), operation)
    if not result.allowed:
        log_rejection(paircoder_dir / "bypass_log.jsonl", result)
        return {"blocked": True, "reason": result.reason or "Containment violation"}

    return {"blocked": False, "reason": "Access allowed"}