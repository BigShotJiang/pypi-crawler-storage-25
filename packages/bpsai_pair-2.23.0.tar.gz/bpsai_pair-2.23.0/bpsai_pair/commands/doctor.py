"""Doctor command -- holistic health check for PairCoder (S44.8).

Validates everything a developer needs to work with PairCoder.
One command, green/yellow/red per check.
"""
from __future__ import annotations

import subprocess
import sys
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Optional

import typer
from rich.console import Console
from rich.table import Table

from ..json_envelope import print_envelope, wrap_error, wrap_ok

console = Console()

_REQUIRED_PAIRCODER = ("config.yaml", "capabilities.yaml", "context")
_REQUIRED_CLAUDE = ("agents", "skills", "commands")


@dataclass
class HealthCheck:
    """Result of a single health check."""

    name: str
    status: str  # "green" | "yellow" | "red"
    message: str
    fix_hint: Optional[str] = None


# ---------------------------------------------------------------------------
# Individual checks
# ---------------------------------------------------------------------------


def check_python_version() -> HealthCheck:
    """Check Python >= 3.9."""
    vi = sys.version_info
    version_str = f"{vi[0]}.{vi[1]}.{vi[2]}"
    if vi[:2] >= (3, 9):
        return HealthCheck("Python version", "green", f"Python {version_str}")
    return HealthCheck(
        "Python version", "red", f"Python {version_str} (need >= 3.9)",
        fix_hint="Install Python 3.9+ from python.org",
    )


def check_paircoder_version() -> HealthCheck:
    """Report installed PairCoder version."""
    try:
        from bpsai_pair import __version__
        return HealthCheck("PairCoder version", "green", f"v{__version__}")
    except Exception:
        return HealthCheck(
            "PairCoder version", "yellow", "Could not determine version",
        )


def check_claude_code() -> HealthCheck:
    """Check if Claude Code CLI is installed."""
    return _check_tool_installed(
        "Claude Code", ["claude", "--version"],
        missing_status="red",
        fix_hint="Install Claude Code: https://claude.ai/code",
    )


def check_git_repo(root: Path) -> HealthCheck:
    """Check .git directory exists."""
    if (root / ".git").is_dir():
        return HealthCheck("Git repository", "green", "Initialized")
    return HealthCheck(
        "Git repository", "red", ".git not found",
        fix_hint="Run: git init",
    )


def check_paircoder_dir(root: Path) -> HealthCheck:
    """Check .paircoder/ directory and required files."""
    pc = root / ".paircoder"
    if not pc.is_dir():
        return HealthCheck(
            ".paircoder directory", "red", "Not found",
            fix_hint="Run: bpsai-pair init",
        )
    missing = [f for f in _REQUIRED_PAIRCODER if not (pc / f).exists()]
    if missing:
        return HealthCheck(
            ".paircoder directory", "yellow",
            f"Missing: {', '.join(missing)}",
            fix_hint="Run: bpsai-pair init",
        )
    return HealthCheck(".paircoder directory", "green", "Complete")


def check_claude_dir(root: Path) -> HealthCheck:
    """Check .claude/ directory and required subdirs."""
    cd = root / ".claude"
    if not cd.is_dir():
        return HealthCheck(
            ".claude directory", "red", "Not found",
            fix_hint="Run: bpsai-pair init",
        )
    missing = [d for d in _REQUIRED_CLAUDE if not (cd / d).is_dir()]
    if missing:
        return HealthCheck(
            ".claude directory", "yellow",
            f"Missing: {', '.join(missing)}",
            fix_hint="Run: bpsai-pair init",
        )
    return HealthCheck(".claude directory", "green", "Complete")


def check_ruff() -> HealthCheck:
    """Check if ruff linter is installed (optional)."""
    return _check_tool_installed(
        "Ruff linter", ["ruff", "--version"],
        missing_status="yellow",
        fix_hint="Install: pip install ruff",
    )


def check_pytest() -> HealthCheck:
    """Check if pytest is installed (optional)."""
    return _check_tool_installed(
        "pytest", ["pytest", "--version"],
        missing_status="yellow",
        fix_hint="Install: pip install pytest",
    )


def check_telemetry_dir(root: Path) -> HealthCheck:
    """Check .paircoder/telemetry/ is writable."""
    td = root / ".paircoder" / "telemetry"
    if td.is_dir():
        return HealthCheck("Telemetry directory", "green", "Writable")
    return HealthCheck(
        "Telemetry directory", "yellow", "Not found (will be created)",
        fix_hint="Run: mkdir -p .paircoder/telemetry",
    )


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _check_tool_installed(
    name: str,
    cmd: list[str],
    missing_status: str = "red",
    fix_hint: str | None = None,
) -> HealthCheck:
    """Run a version command and return a HealthCheck."""
    try:
        proc = subprocess.run(
            cmd, capture_output=True, text=True, timeout=10,
        )
        if proc.returncode == 0:
            ver = proc.stdout.strip().split("\n")[0]
            return HealthCheck(name, "green", ver or "Installed")
        return HealthCheck(name, missing_status, "Command failed", fix_hint)
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return HealthCheck(name, missing_status, "Not installed", fix_hint)


def _resolve_project_root() -> Path:
    """Resolve the project root directory."""
    return Path.cwd()


def run_all_checks(root: Path) -> list[HealthCheck]:
    """Run all health checks and return results."""
    return [
        check_python_version(),
        check_paircoder_version(),
        check_claude_code(),
        check_git_repo(root),
        check_paircoder_dir(root),
        check_claude_dir(root),
        check_ruff(),
        check_pytest(),
        check_telemetry_dir(root),
    ]


# ---------------------------------------------------------------------------
# Auto-fix support
# ---------------------------------------------------------------------------

# Checks that can be auto-fixed by creating directories.
# Maps check name -> list of dirs (relative to root) to create.
_FIXABLE_DIR_CHECKS: dict[str, list[str]] = {
    ".paircoder directory": [
        ".paircoder",
        ".paircoder/context",
    ],
    ".claude directory": [
        ".claude/agents",
        ".claude/skills",
        ".claude/commands",
    ],
    "Telemetry directory": [
        ".paircoder/telemetry",
    ],
}

# Checks that are NOT auto-fixable (report only).
_UNFIXABLE_CHECKS = frozenset({
    "Python version",
    "Claude Code",
    "Git repository",
    "PairCoder version",
    "Ruff linter",
    "pytest",
})


def attempt_fixes(
    checks: list[HealthCheck], root: Path,
) -> list[HealthCheck]:
    """Attempt auto-fixes for fixable checks, return updated results.

    For each non-green check that has a known directory fix, create the
    missing directories and re-run the check.  Unfixable checks are
    returned unchanged.  Idempotent -- safe to call repeatedly.
    """
    results: list[HealthCheck] = []
    for check in checks:
        if check.status == "green" or check.name in _UNFIXABLE_CHECKS:
            results.append(check)
            continue

        dirs = _FIXABLE_DIR_CHECKS.get(check.name)
        if dirs is None:
            results.append(check)
            continue

        # Create missing directories
        for d in dirs:
            (root / d).mkdir(parents=True, exist_ok=True)

        # Re-run the check to verify
        updated = _recheck(check.name, root)
        results.append(updated if updated is not None else check)

    return results


def _recheck(name: str, root: Path) -> HealthCheck | None:
    """Re-run a single check by name after a fix attempt."""
    dispatch: dict[str, object] = {
        ".paircoder directory": lambda: check_paircoder_dir(root),
        ".claude directory": lambda: check_claude_dir(root),
        "Telemetry directory": lambda: check_telemetry_dir(root),
    }
    fn = dispatch.get(name)
    return fn() if fn else None


# ---------------------------------------------------------------------------
# CLI command
# ---------------------------------------------------------------------------

_STATUS_COLORS = {"green": "green", "yellow": "yellow", "red": "red"}
_STATUS_ICONS = {"green": "[green]OK[/green]", "yellow": "[yellow]WARN[/yellow]", "red": "[red]FAIL[/red]"}


def doctor_command(
    json_out: bool = typer.Option(False, "--json", help="Output as JSON"),
    fix: bool = typer.Option(False, "--fix", help="Auto-fix fixable issues"),
) -> None:
    """Run holistic health check on your PairCoder environment."""
    root = _resolve_project_root()
    checks = run_all_checks(root)

    if fix:
        checks = attempt_fixes(checks, root)

    has_red = any(c.status == "red" for c in checks)

    if json_out:
        payload = {
            "checks": [asdict(c) for c in checks],
            "summary": {
                "green": sum(1 for c in checks if c.status == "green"),
                "yellow": sum(1 for c in checks if c.status == "yellow"),
                "red": sum(1 for c in checks if c.status == "red"),
            },
        }
        envelope = wrap_error("One or more checks failed", payload) if has_red else wrap_ok(payload)
        print_envelope(envelope)
        if has_red:
            raise typer.Exit(1)
        return

    _print_table(checks)
    if has_red:
        console.print("\n[red]Some checks failed. See fix hints above.[/red]")
        raise typer.Exit(1)
    console.print("\n[green]All checks passed.[/green]")


def _print_table(checks: list[HealthCheck]) -> None:
    """Print a Rich table of health check results."""
    table = Table(title="PairCoder Doctor", show_lines=False)
    table.add_column("Check", style="bold")
    table.add_column("Status")
    table.add_column("Details")
    table.add_column("Fix", style="dim")

    for c in checks:
        icon = _STATUS_ICONS.get(c.status, c.status)
        table.add_row(c.name, icon, c.message, c.fix_hint or "")

    console.print(table)
