"""Managed .gitignore fence for paircoder churn paths.

Ensures ephemeral CLI state paths are never accidentally committed.
The managed block is fenced by sentinel comments so re-runs are
idempotent and user-managed lines are never touched.
"""

from __future__ import annotations

from pathlib import Path

from ..engage.constants import CHURN_EXCLUSIONS

MANAGED_FENCE_START = "# >>> paircoder managed"
MANAGED_FENCE_END = "# <<< paircoder managed"


def _build_managed_block() -> str:
    """Build the managed .gitignore block from CHURN_EXCLUSIONS."""
    lines = [MANAGED_FENCE_START]
    for pattern in sorted(CHURN_EXCLUSIONS):
        lines.append(pattern)
    lines.append(MANAGED_FENCE_END)
    return "\n".join(lines) + "\n"


def ensure_managed_gitignore(root: Path) -> None:
    """Create or update .gitignore with a managed fence of churn paths.

    - If no .gitignore exists, creates one with just the managed block.
    - If .gitignore exists without a managed block, appends it.
    - If .gitignore already has a managed block, replaces it in-place.
    """
    gitignore = root / ".gitignore"
    block = _build_managed_block()

    if not gitignore.exists():
        gitignore.write_text(block)
        return

    content = gitignore.read_text()

    if MANAGED_FENCE_START in content and MANAGED_FENCE_END in content:
        # Replace existing managed block
        start_idx = content.index(MANAGED_FENCE_START)
        end_idx = content.index(MANAGED_FENCE_END) + len(MANAGED_FENCE_END)
        # Consume trailing newline if present
        if end_idx < len(content) and content[end_idx] == "\n":
            end_idx += 1
        content = content[:start_idx] + block + content[end_idx:]
        gitignore.write_text(content)
    else:
        # Append managed block
        if not content.endswith("\n"):
            content += "\n"
        content += "\n" + block
        gitignore.write_text(content)
