"""Upgrade command for updating existing v2.x projects.

Extracted from T-upgrade-command-spec.md as part of Sprint 23 Critical Fixes.
Helpers extracted to upgrade_helpers.py for architecture compliance.

Commands:
- upgrade: Upgrade existing v2.x project with latest skills, agents, and docs
"""

from __future__ import annotations

from dataclasses import dataclass, field

import typer
from rich.console import Console

# Try relative imports first, fall back to absolute
try:
    from ..core import ops
except ImportError:
    from bpsai_pair.core import ops

# Re-export key functions for backward compatibility with existing imports
from .upgrade_helpers import (
    get_template_dir,
    get_bundled_skills,
    get_bundled_agents,
    get_bundled_commands,
    plan_upgrade,
    execute_upgrade,
    print_upgrade_plan,
    print_upgrade_summary,
)
from .upgrade_execute import (
    _execute_runtime_dirs,
    _execute_telemetry_bootstrap,
    _execute_fleet_calibration,
    _execute_fleet_demand,
    _execute_statusline,
)

console = Console()


@dataclass
class UpgradePlan:
    """What will be upgraded."""
    skills_to_update: list = field(default_factory=list)
    skills_to_add: list = field(default_factory=list)
    agents_to_update: list = field(default_factory=list)
    agents_to_add: list = field(default_factory=list)
    commands_to_update: list = field(default_factory=list)
    commands_to_add: list = field(default_factory=list)
    docs_to_update: list = field(default_factory=list)
    config_sections_to_add: list = field(default_factory=list)
    config_version_stale: bool = False
    hooks_stale: bool = False
    dirs_to_create: list = field(default_factory=list)
    warnings: list = field(default_factory=list)


# Typer app for upgrade command
upgrade_app = typer.Typer(
    help="Upgrade existing v2.x project with latest content",
    context_settings={"help_option_names": ["-h", "--help"]}
)


def _validate_project():
    """Validate project structure and return (project_root, template)."""
    from pathlib import Path

    project_root = ops.find_project_root()

    paircoder_dir = project_root / ".paircoder"
    if not paircoder_dir.exists():
        console.print(
            "[red]No .paircoder/ directory found. Run 'bpsai-pair init' first.[/red]"
        )
        raise typer.Exit(1)

    config_path = paircoder_dir / "config.yaml"
    if not config_path.exists():
        console.print(
            "[red]No config.yaml found. Run 'bpsai-pair init' first.[/red]"
        )
        raise typer.Exit(1)

    template = get_template_dir()
    if not template:
        console.print(
            "[red]Could not find bundled template. "
            "Is bpsai-pair installed correctly?[/red]"
        )
        raise typer.Exit(1)

    return project_root, template


def _resolve_flags(only_skills, only_agents, only_commands, only_docs, only_config):
    """Resolve --only-* flags into a tuple of booleans."""
    upgrade_all = not any([
        only_skills, only_agents, only_commands, only_docs, only_config
    ])
    return (
        upgrade_all or only_skills,
        upgrade_all or only_agents,
        upgrade_all or only_commands,
        upgrade_all or only_docs,
        upgrade_all or only_config,
    )


def _has_updates(plan: UpgradePlan) -> bool:
    """Return True if the plan contains any pending changes."""
    return any([
        plan.skills_to_add, plan.skills_to_update,
        plan.agents_to_add, plan.agents_to_update,
        plan.commands_to_add, plan.commands_to_update,
        plan.docs_to_update, plan.config_sections_to_add,
        plan.config_version_stale, plan.hooks_stale,
        plan.dirs_to_create,
    ])


def _run_background_tasks(project_root):
    """Run always-on tasks: fleet fetch, telemetry bootstrap, statusline."""
    results: dict = {}
    _execute_runtime_dirs(results, project_root)
    _execute_telemetry_bootstrap(results, project_root)
    _execute_fleet_calibration(results, project_root)
    _execute_fleet_demand(results, project_root)
    _execute_statusline(results, project_root)


def _run_upgrade(plan, project_root, template, flags, force):
    """Execute the upgrade after validation and confirmation."""
    do_skills, do_agents, do_commands, do_docs, do_config = flags

    if not force:
        console.print("")
        if not typer.confirm("Proceed with upgrade?"):
            console.print("[dim]Aborted.[/dim]")
            raise typer.Exit(0)

    console.print("\n[bold]Upgrading...[/bold]")
    results = execute_upgrade(
        project_root, template, plan,
        skills=do_skills, agents=do_agents, commands=do_commands,
        docs=do_docs, config=do_config, console=console,
    )

    console.print("\n[green]Upgrade complete![/green]")
    print_upgrade_summary(
        results, do_skills, do_agents, do_commands, do_docs, do_config, console
    )


@upgrade_app.callback(invoke_without_command=True)
def upgrade_command(
    ctx: typer.Context,
    dry_run: bool = typer.Option(
        False, "--dry-run", help="Show what would change without making changes"
    ),
    only_skills: bool = typer.Option(False, "--skills", help="Only update skills"),
    only_agents: bool = typer.Option(False, "--agents", help="Only update agents"),
    only_commands: bool = typer.Option(
        False, "--commands", help="Only update slash commands"
    ),
    only_docs: bool = typer.Option(
        False, "--docs", help="Only update safe doc files"
    ),
    only_config: bool = typer.Option(
        False, "--config", help="Only add missing config sections"
    ),
    force: bool = typer.Option(
        False, "--force", "-f", help="Skip confirmation prompt"
    ),
    auto: bool = typer.Option(
        False, "--auto", help="Non-interactive upgrade (implies --force)"
    ),
):
    """Upgrade existing v2.x project with latest skills, agents, commands, and docs."""
    if ctx.invoked_subcommand is not None:
        return

    project_root, template = _validate_project()
    plan = plan_upgrade(project_root, template)

    if not _has_updates(plan):
        console.print("[green]Project is up to date. Nothing to upgrade.[/green]")
        _run_background_tasks(project_root)
        return

    print_upgrade_plan(plan, console)

    if dry_run:
        console.print("\n[dim]--dry-run specified. No changes made.[/dim]")
        return

    if auto:
        force = True

    flags = _resolve_flags(
        only_skills, only_agents, only_commands, only_docs, only_config
    )
    _run_upgrade(plan, project_root, template, flags, force)


def register_upgrade_command(app: typer.Typer):
    """Register upgrade command with the main app."""
    app.add_typer(upgrade_app, name="upgrade")
