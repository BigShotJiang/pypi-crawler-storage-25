"""Task state CLI commands.

Validation helpers live in state_validation.py. Re-exported here
for backward compatibility.
"""
import typer
from typing import Optional

from .state_validation import (
    find_paircoder_dir,
    extract_done_tasks_from_state_md,
    is_trello_enabled,
    get_trello_card_status,
    parse_acceptance_criteria_from_body,
    validate_task_completion_local,
    validate_task_completion_full,
    validate_task_completion,
)

__all__ = [
    "app",
    "find_paircoder_dir",
    "extract_done_tasks_from_state_md",
    "is_trello_enabled",
    "get_trello_card_status",
    "parse_acceptance_criteria_from_body",
    "validate_task_completion_local",
    "validate_task_completion_full",
    "validate_task_completion",
]

app = typer.Typer(help="Task execution state management")


def _state_color(state: str) -> str:
    """Return Rich color for a state value."""
    return {"completed": "green", "blocked": "red", "in_progress": "cyan"}.get(state, "dim")


def _print_validation_errors(console, validation_errors: list) -> None:
    """Print validation error details to console."""
    console.print(f"\n[red]\u274c VALIDATION FAILED: {len(validation_errors)} task(s) have issues[/red]\n")
    for error in validation_errors:
        console.print(f"[yellow]{error['task_id']}:[/yellow]")
        for err in error["errors"]:
            console.print(f"  [red]\u2022 {err}[/red]")
        console.print()
    console.print("[dim]Tasks marked as done in state.md must be properly completed:[/dim]")
    console.print("[dim]  \u2022 Trello: 'bpsai-pair ttask done TRELLO-XX --summary \"...\"'[/dim]")
    console.print("[dim]  \u2022 Local: 'bpsai-pair task update TASK-XX --status done'[/dim]")
    console.print()


@app.command("show")
def show_state(
    task_id: str = typer.Argument(..., help="Task ID (e.g., T28.1)"),
):
    """Show current execution state for a task."""
    from rich.console import Console
    from rich.panel import Panel
    from ..core.task_state import (
        get_state_manager, VALID_TRANSITIONS, TRANSITION_TRIGGERS, is_state_machine_enabled,
    )

    console = Console()
    if not is_state_machine_enabled():
        console.print("[yellow]\u26a0\ufe0f State machine is disabled in config[/yellow]")
        console.print("[dim]Enable with: enforcement.state_machine: true in config.yaml[/dim]\n")

    mgr = get_state_manager()
    current = mgr.get_state(task_id)
    valid_next = VALID_TRANSITIONS.get(current, [])
    lines = [f"[bold]State:[/bold] {current.value}"]

    if valid_next:
        lines.append("")
        lines.append("[bold]Next valid states:[/bold]")
        for next_state in valid_next:
            trigger = TRANSITION_TRIGGERS.get((current, next_state), "")
            lines.append(f"  \u2022 {next_state.value}")
            if trigger:
                lines.append(f"    [dim]\u2192 {trigger}[/dim]")
    else:
        lines.append("")
        lines.append("[green]\u2713 Complete (terminal state)[/green]")

    console.print(Panel("\n".join(lines), title=f"Task {task_id}"))


@app.command("history")
def show_history(
    task_id: Optional[str] = typer.Argument(None, help="Task ID (optional, shows all if omitted)"),
    limit: int = typer.Option(20, "--limit", "-n", help="Number of entries to show"),
):
    """Show state transition history."""
    from rich.console import Console
    from rich.table import Table
    from ..core.task_state import get_state_manager

    console = Console()
    history = get_state_manager().get_history(task_id=task_id, limit=limit)

    if not history:
        console.print("[dim]No state transitions recorded.[/dim]")
        return

    table = Table(title="State Transition History")
    table.add_column("Time", style="dim", width=16)
    table.add_column("Task", width=10)
    table.add_column("From", width=14)
    table.add_column("To", width=14)
    table.add_column("Trigger", width=30)

    for entry in history:
        ts = entry["timestamp"][:16].replace("T", " ")
        to_state = entry["to_state"]
        style = _state_color(to_state)
        styled = f"[{style}]{to_state}[/{style}]" if style != "dim" else to_state
        table.add_row(ts, entry["task_id"], entry["from_state"], styled, entry.get("trigger", "")[:30])

    console.print(table)


@app.command("list")
def list_states(
    status: Optional[str] = typer.Option(None, "--status", "-s", help="Filter by state"),
):
    """List all tracked task states."""
    from rich.console import Console
    from rich.table import Table
    from ..core.task_state import get_state_manager

    console = Console()
    all_states = get_state_manager().get_all_states()

    if not all_states:
        console.print("[dim]No tasks being tracked.[/dim]")
        return

    if status:
        all_states = {k: v for k, v in all_states.items() if v == status}
        if not all_states:
            console.print(f"[dim]No tasks in state '{status}'[/dim]")
            return

    table = Table(title="Tracked Task States")
    table.add_column("Task ID", width=12)
    table.add_column("State", width=14)

    for tid, state in sorted(all_states.items()):
        style = _state_color(state)
        table.add_row(tid, f"[{style}]{state}[/{style}]")

    console.print(table)


@app.command("reset")
def reset_state(
    task_id: str = typer.Argument(..., help="Task ID to reset"),
    confirm: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation"),
):
    """Reset a task to NOT_STARTED state."""
    from ..core.task_state import get_state_manager

    mgr = get_state_manager()
    current = mgr.get_state(task_id)

    if current.value == "not_started":
        typer.echo(f"Task {task_id} is already in not_started state.")
        return

    if not confirm:
        typer.confirm(f"Reset task {task_id} from '{current.value}' to 'not_started'?", abort=True)

    mgr.reset_task(task_id)


@app.command("advance")
def advance_state(
    task_id: str = typer.Argument(..., help="Task ID"),
    to_state: str = typer.Argument(..., help="Target state"),
    reason: str = typer.Option("manual", "--reason", "-r", help="Reason for transition"),
):
    """Manually advance task to a new state. Only valid transitions are allowed."""
    from ..core.task_state import get_state_manager, TaskState

    try:
        target = TaskState(to_state)
    except ValueError:
        valid = [s.value for s in TaskState]
        typer.echo(f"Invalid state '{to_state}'. Valid states: {', '.join(valid)}", err=True)
        raise typer.Exit(1)

    get_state_manager().transition(task_id, target, trigger=reason)


@app.command("validate")
def validate_state(
    quiet: bool = typer.Option(False, "--quiet", "-q", help="Only output on errors"),
    task_id: Optional[str] = typer.Option(None, "--task", "-t", help="Validate specific task only"),
    full: bool = typer.Option(False, "--full", "-f", help="Full validation including Trello (slow)"),
):
    """Validate that tasks marked done in state.md are actually complete."""
    from rich.console import Console

    console = Console()

    try:
        paircoder_dir = find_paircoder_dir()
    except Exception as e:
        if not quiet:
            console.print(f"[red]Could not find .paircoder directory: {e}[/red]")
        raise typer.Exit(1)

    state_path = paircoder_dir / "context" / "state.md"
    if not state_path.exists():
        if not quiet:
            console.print("[yellow]No state.md found[/yellow]")
        return

    done_tasks = extract_done_tasks_from_state_md(state_path.read_text(encoding='utf-8'))
    if not done_tasks:
        if not quiet:
            console.print("[green]\u2713 No tasks marked as done in state.md[/green]")
        return
    if task_id:
        if task_id not in done_tasks:
            if not quiet:
                console.print(f"[yellow]Task {task_id} is not marked as done in state.md[/yellow]")
            return
        done_tasks = {task_id}

    validation_errors = [
        {"task_id": tid, "errors": r["errors"]}
        for tid in sorted(done_tasks)
        for r in [validate_task_completion(tid, paircoder_dir, include_trello=full)]
        if not r["valid"]
    ]

    if not validation_errors:
        if not quiet:
            mode = "full (with Trello)" if full else "local"
            console.print(f"[green]\u2713 All {len(done_tasks)} done tasks validated ({mode})[/green]")
        return

    _print_validation_errors(console, validation_errors)
    raise typer.Exit(1)
