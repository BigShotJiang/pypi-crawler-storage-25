"""Init repo command and helpers.

Contains init_command and all supporting functions extracted from init_commands.py.
"""
from __future__ import annotations

from pathlib import Path
from typing import Optional

import typer
import yaml
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn
from ..core import ops
from ..core.config import Config

console = Console()


def get_tier() -> str:
    """Get the current license tier."""
    try:
        from ..licensing import get_tier as _get_tier
        return _get_tier()
    except Exception:
        return "solo"


def get_current_tier_display_name() -> str:
    """Get the display name for the current tier."""
    try:
        from ..licensing import get_current_tier_display_name as _get_display
        return _get_display()
    except Exception:
        return "Solo"


def _check_wizard_dependencies() -> bool:
    """Check if wizard dependencies are installed."""
    try:
        import fastapi  # noqa: F401
        import jinja2  # noqa: F401
        import uvicorn  # noqa: F401
        return True
    except ImportError:
        return False


def _launch_wizard(root: Path) -> None:
    """Launch the setup wizard."""
    import os
    original_cwd = os.getcwd()
    try:
        os.chdir(root)
        from bpsai_pair.commands.wizard import run_server
        console.print()
        console.print("[bold]Launching Setup Wizard...[/bold]")
        console.print("[dim]The wizard will open in your browser.[/dim]")
        console.print("[dim]Complete the wizard, then press Ctrl+C to continue.[/dim]")
        console.print()
        run_server(port=8765, no_browser=False, demo=False)
    finally:
        os.chdir(original_cwd)


def repo_root() -> Path:
    """Get repo root with better error message."""
    try:
        p = ops.find_project_root()
    except ops.ProjectRootNotFoundError:
        console.print(
            "[red]x Not in a git repository.[/red]\n"
            "Please run from your project root directory (where .git exists).\n"
            "[dim]Hint: cd to your project directory first[/dim]"
        )
        raise typer.Exit(1)
    if not ops.GitOps.is_repo(p):
        console.print(
            "[red]x Not in a git repository.[/red]\n"
            "Please run from your project root directory (where .git exists).\n"
            "[dim]Hint: cd to your project directory first[/dim]"
        )
        raise typer.Exit(1)
    return p


def _select_ci_workflow(root: Path, ci_type: str) -> None:
    """Select the appropriate CI workflow based on preset ci_type.

    Renames the preset-specific workflow to ci.yml and removes the others.
    """
    workflows_dir = root / ".github" / "workflows"
    if not workflows_dir.exists():
        return
    ci_yml = workflows_dir / "ci.yml"
    ci_node = workflows_dir / "ci-node.yml"
    ci_python = workflows_dir / "ci-python.yml"
    if ci_type == "node" and ci_node.exists():
        if ci_yml.exists():
            ci_yml.unlink()
        ci_node.rename(ci_yml)
        if ci_python.exists():
            ci_python.unlink()
    elif ci_type == "python" and ci_python.exists():
        if ci_yml.exists():
            ci_yml.unlink()
        ci_python.rename(ci_yml)
        if ci_node.exists():
            ci_node.unlink()
    else:
        if ci_node.exists():
            ci_node.unlink()
        if ci_python.exists():
            ci_python.unlink()


def _has_unrendered_cookiecutter_template(path: Path) -> bool:
    """Check if a file contains unrendered cookiecutter template variables."""
    try:
        content = path.read_text(encoding="utf-8")
        return "{{" in content and "cookiecutter" in content
    except Exception:
        return False


def ensure_v2_config(root: Path) -> Path:
    """Ensure v2 config exists at .paircoder/config.yaml.

    - Detects and regenerates configs with unrendered cookiecutter templates.
    - If only legacy .paircoder.yml exists, it will be read and re-saved into v2 format.
    - If nothing exists, a default config will be written in v2 format.
    """
    v2_path = root / ".paircoder" / "config.yaml"
    if v2_path.exists():
        if _has_unrendered_cookiecutter_template(v2_path):
            console.print(
                "[yellow]⚠ Detected unrendered cookiecutter template in config.yaml, regenerating...[/yellow]"
            )
            v2_path.unlink()
        else:
            return v2_path
    v2_yml_path = root / ".paircoder" / "config.yml"
    if v2_yml_path.exists():
        if _has_unrendered_cookiecutter_template(v2_yml_path):
            console.print(
                "[yellow]⚠ Detected unrendered cookiecutter template in config.yml, regenerating...[/yellow]"
            )
            v2_yml_path.unlink()
        else:
            return v2_yml_path
    # Lazy import for mock compatibility — tests patch init_commands.Config
    from bpsai_pair.commands import init_commands as _cmds
    cfg = _cmds.Config.load(root)
    cfg.save(root, use_v2=True)
    return v2_path


def _display_tier_info(_cmds) -> str:
    """Display tier info and return current tier."""
    tier = _cmds.get_tier()
    tier_display = _cmds.get_current_tier_display_name()
    console.print(f"[dim]License tier: {tier_display}[/dim]")
    if tier == "solo":
        console.print("[yellow]Tip:[/yellow] Activate a license for access to the Setup Wizard")
        console.print("[dim]Run: bpsai-pair license install <path-to-license.json>[/dim]")
    return tier


def _should_launch_wizard(root, tier, preset, interactive, _cmds) -> bool:
    """Check if wizard should be launched; launch it if user confirms."""
    if tier == "solo" or preset or interactive:
        return False
    if _cmds._check_wizard_dependencies():
        use_wizard = typer.confirm("Would you like to use the Setup Wizard?", default=True)
        if use_wizard:
            _cmds._launch_wizard(root)
            return True
    else:
        console.print("[dim]Tip: Install wizard dependencies for web-based setup:[/dim]")
        console.print("[dim]  pip install bpsai-pair[wizard][/dim]")
    return False


def _handle_preset(root, preset, project_name, goal, _cmds):
    """Handle preset-based initialization. Returns the preset object."""
    preset_obj = _cmds.get_preset(preset)
    if not preset_obj:
        console.print(f"[red]x Unknown preset: {preset}[/red]")
        console.print(f"[dim]Available presets: {', '.join(_cmds.get_preset_names())}[/dim]")
        raise typer.Exit(1)
    p_name = project_name or typer.prompt("Project name", default="My Project")
    p_goal = goal or typer.prompt("Primary goal", default="Build awesome software")
    config_dict = preset_obj.to_config_dict(p_name, p_goal)
    paircoder_dir = root / ".paircoder"
    paircoder_dir.mkdir(exist_ok=True)
    config_file = paircoder_dir / "config.yaml"
    with open(config_file, 'w', encoding="utf-8") as f:
        yaml.dump(config_dict, f, default_flow_style=False, sort_keys=False)
    console.print(f"[green]![/green] Applied preset: {preset}")
    console.print(f"  Project: {p_name}")
    console.print(f"  Goal: {p_goal}")
    console.print(f"  Coverage target: {preset_obj.coverage_target}%")
    console.print(f"  Flows: {', '.join(preset_obj.enabled_flows)}")
    return preset_obj


def _handle_interactive(root, _cmds):
    """Handle interactive mode initialization."""
    pname = typer.prompt("Project name", default="My Project")
    primary_goal = typer.prompt("Primary goal", default="Build awesome software")
    coverage = typer.prompt("Coverage target (%)", default="80")
    console.print("\n[bold]Available presets:[/bold]")
    for p in _cmds.list_presets():
        console.print(f"  {p.name}: {p.description}")
    use_preset = typer.confirm("\nWould you like to use a preset?", default=False)
    if use_preset:
        preset_choice = typer.prompt("Select preset", default="python-cli")
        preset_obj = _cmds.get_preset(preset_choice)
        if preset_obj:
            config_dict = preset_obj.to_config_dict(pname, primary_goal)
            config_dict["project"]["coverage_target"] = int(coverage)
            paircoder_dir = root / ".paircoder"
            paircoder_dir.mkdir(exist_ok=True)
            config_file = paircoder_dir / "config.yaml"
            with open(config_file, 'w', encoding="utf-8") as f:
                yaml.dump(config_dict, f, default_flow_style=False, sort_keys=False)
            console.print(f"[green]![/green] Applied preset: {preset_choice}")
        else:
            console.print("[yellow]! Unknown preset, using defaults[/yellow]")
            config = Config(
                project_name=pname, primary_goal=primary_goal,
                coverage_target=int(coverage),
            )
            config.save(root, use_v2=True)
    else:
        config = Config(
            project_name=pname, primary_goal=primary_goal,
            coverage_target=int(coverage),
        )
        config.save(root, use_v2=True)


def _handle_bundled_init(root, preset, preset_obj, preexisting_config, _cmds):
    """Handle initialization with bundled template."""
    from .. import init_bundled_cli
    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
    ) as progress:
        task = progress.add_task("Initializing scaffolding...", total=None)
        result = init_bundled_cli.main()
        progress.update(task, completed=True)
    if result != 0:
        console.print("[red]x Failed to initialize bundled scaffolding[/red]")
        console.print("[dim]The packaged template may be missing or corrupted.[/dim]")
        raise typer.Exit(1)
    if preset:
        _select_ci_workflow(root, preset_obj.ci_type)
    console.print("[green]![/green] Initialized repo with pair-coding scaffolding")
    if not preset:
        _cmds.ensure_v2_config(root)
    from bpsai_pair.statusline_install import install_statusline
    install_statusline(root)
    _cmds.ensure_managed_gitignore(root)
    console.print("[dim]Review diffs and commit changes[/dim]")
    console.print("\n[bold]Next steps:[/bold]")
    console.print("  1. Review and commit the generated files")
    console.print("  2. Read .paircoder/context/state.md to understand the workflow")
    console.print("\n[bold]Optional - Connect to Trello:[/bold]")
    console.print("  1. Get API key from [link=https://trello.com/power-ups/admin]trello.com/power-ups/admin[/link]")
    console.print("  2. Set environment variables:")
    console.print("     [dim]export TRELLO_API_KEY=your_key[/dim]")
    console.print("     [dim]export TRELLO_TOKEN=your_token[/dim]")
    console.print("  3. Run: [bold]bpsai-pair trello connect[/bold]")
    console.print("  4. Run: [bold]bpsai-pair trello use-board <board-id>[/bold]")
    console.print("\n[dim]See .paircoder/docs/USER_GUIDE.md for full documentation[/dim]")


def init_command(
    template: Optional[str] = typer.Argument(
        None, help="Path to template (optional, uses bundled template if not provided)"
    ),
    interactive: bool = typer.Option(
        False, "--interactive", "-i", help="Interactive mode to gather project info"
    ),
    preset: Optional[str] = typer.Option(
        None, "--preset", "-p",
        help="Use a preset configuration (python-cli, python-api, react, fullstack, library, minimal, autonomous)"
    ),
    project_name: Optional[str] = typer.Option(
        None, "--name", "-n", help="Project name (used with --preset)"
    ),
    goal: Optional[str] = typer.Option(
        None, "--goal", "-g", help="Primary goal (used with --preset)"
    ),
):
    """Initialize repo with governance, context, prompts, scripts, and workflows.

    Use --preset for quick setup with project-type-specific defaults:

        bpsai-pair init --preset python-cli --name "My CLI" --goal "Build awesome CLI"

    Available presets: python-cli, python-api, react, fullstack, library, minimal, autonomous

    Use --interactive for guided setup, or no flags for minimal scaffolding.
    """
    from bpsai_pair.commands import init_commands as _cmds
    root = _cmds.repo_root()
    tier = _display_tier_info(_cmds)
    if _should_launch_wizard(root, tier, preset, interactive, _cmds):
        return
    preexisting_config = Config.find_config_file(root)
    preset_obj = None
    if preset:
        preset_obj = _handle_preset(root, preset, project_name, goal, _cmds)
    elif interactive:
        _handle_interactive(root, _cmds)
    if template is None:
        _handle_bundled_init(root, preset, preset_obj, preexisting_config, _cmds)
    else:
        console.print(f"[yellow]Using template: {template}[/yellow]")
        if not preset:
            _cmds.ensure_v2_config(root)
        if preexisting_config is None and not preset:
            v2_config = root / ".paircoder" / "config.yaml"
            v2_config_yml = root / ".paircoder" / "config.yml"
            if not v2_config.exists() and not v2_config_yml.exists():
                Config.load(root).save(root, use_v2=True)
