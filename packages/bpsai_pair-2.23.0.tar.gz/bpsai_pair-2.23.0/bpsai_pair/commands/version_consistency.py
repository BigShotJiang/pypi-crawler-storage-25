"""Version file consistency check on startup.

Compares 5 version sources (pyproject.toml, pip, .cli_version,
config.yaml, capabilities.yaml) and emits a diagnostic warning
if any are mismatched. Warning-only — does not block the CLI.

Only runs when pyproject.toml is accessible (i.e., in the CLI repo).
"""

from __future__ import annotations

from collections import Counter
from pathlib import Path
from typing import Dict, Optional


def _get_pip_version() -> Optional[str]:
    """Get installed pip version of bpsai-pair."""
    try:
        from importlib.metadata import version, PackageNotFoundError

        return version("bpsai-pair")
    except (PackageNotFoundError, Exception):
        return None


def _read_pyproject_version(project_root: Path) -> Optional[str]:
    """Read version from tools/cli/pyproject.toml."""
    toml_path = project_root / "tools" / "cli" / "pyproject.toml"
    if not toml_path.exists():
        return None
    try:
        text = toml_path.read_text(encoding="utf-8")
        for line in text.splitlines():
            stripped = line.strip()
            if stripped.startswith("version"):
                # Parse: version = "X.Y.Z"
                _, _, val = stripped.partition("=")
                return val.strip().strip('"').strip("'")
    except Exception:
        pass
    return None


def _read_yaml_version(path: Path) -> Optional[str]:
    """Read version field from a YAML file."""
    if not path.exists():
        return None
    try:
        import yaml

        data = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
        val = data.get("version")
        return str(val) if val is not None else None
    except Exception:
        return None


def collect_version_sources(project_root: Path) -> Dict[str, Optional[str]]:
    """Collect versions from all 5 sources.

    Returns dict mapping source name to version string (or None if missing).
    """
    paircoder_dir = project_root / ".paircoder"
    cli_version_file = paircoder_dir / ".cli_version"

    cli_version = None
    if cli_version_file.exists():
        try:
            cli_version = cli_version_file.read_text(encoding="utf-8").strip() or None
        except Exception:
            pass

    return {
        "pyproject.toml": _read_pyproject_version(project_root),
        "pip (installed)": _get_pip_version(),
        ".cli_version": cli_version,
        "config.yaml": _read_yaml_version(paircoder_dir / "config.yaml"),
        "capabilities.yaml": _read_yaml_version(paircoder_dir / "capabilities.yaml"),
    }


def format_version_table(
    sources: Dict[str, Optional[str]], *, majority: str
) -> str:
    """Format a diagnostic table showing versions and which are stale.

    Args:
        sources: Map of source name → version (None = missing/skipped).
        majority: The version considered "current" (most common).

    Returns:
        Formatted string with table + fix suggestion.
    """
    lines = ["Version mismatch detected:", ""]
    lines.append(f"  {'Source':<20} {'Version':<12} {'Status'}")
    lines.append(f"  {'─' * 20} {'─' * 12} {'─' * 8}")

    for name, ver in sources.items():
        if ver is None:
            continue
        status = "ok" if ver == majority else "STALE"
        lines.append(f"  {name:<20} {ver:<12} {status}")

    lines.append("")
    lines.append("  Fix: pip install -e tools/cli/ && bpsai-pair upgrade")
    return "\n".join(lines)


def check_version_consistency(project_root: Path) -> Optional[str]:
    """Check version consistency across all sources.

    Returns None if all consistent, or a diagnostic string if mismatched.
    Only runs when pyproject.toml is accessible (in the CLI repo).
    """
    sources = collect_version_sources(project_root)

    # AC: Only runs when pyproject.toml is accessible
    if sources["pyproject.toml"] is None:
        return None

    # Filter to present sources only
    present = {k: v for k, v in sources.items() if v is not None}
    if len(present) <= 1:
        return None

    versions = list(present.values())
    if len(set(versions)) == 1:
        return None  # All match

    # Find majority version
    counts = Counter(versions)
    majority = counts.most_common(1)[0][0]

    return format_version_table(sources, majority=majority)
