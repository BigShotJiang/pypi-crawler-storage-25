"""Workspace setup-permissions command.

Generates .claude/settings.local.json from workspace config
for cross-project agent dispatch permissions.
"""
from __future__ import annotations

import json
import logging
import re
from pathlib import Path
from typing import Any

import typer
from rich.console import Console

from ..core import ops
from ..licensing import require_feature
from ..workspace.parser import WorkspaceParser

logger = logging.getLogger(__name__)
console = Console()

_SAFE_PATH_RE = re.compile(r'^[\w/\\:\-.@+~]+$')


def _validate_path(path_str: str) -> bool:
    """Check path contains only safe characters for permission patterns."""
    if not _SAFE_PATH_RE.match(path_str):
        logger.warning(
            "Skipping project path with unsupported characters: %s", path_str,
        )
        return False
    return True

# Paths that are safe to read/write in sibling projects
_ALLOW_PATTERNS = [
    "Bash(cd {path} && *)",
    "Read({path}/src/**)",
    "Read({path}/tests/**)",
    "Read({path}/lib/**)",
    "Read({path}/.paircoder/tasks/**)",
    "Read({path}/.paircoder/context/state.md)",
]

# Paths that must NEVER be accessed in any sibling
_DENY_PATTERNS = [
    "Read({path}/.env*)",
    "Read({path}/credentials.*)",
    "Read({path}/secrets.*)",
    "Edit({path}/.env*)",
    "Edit({path}/credentials.*)",
    "Edit({path}/secrets.*)",
]


def generate_permissions(project_root: Path) -> dict[str, Any]:
    """Generate permissions config from workspace yaml.

    Args:
        project_root: Root directory containing .paircoder-workspace.yaml.

    Returns:
        Dict with additionalDirectories, permissions, and _managed_by keys.

    Raises:
        typer.BadParameter: If no workspace config is found.
    """
    parser = WorkspaceParser()
    ws_config_path = parser.find_workspace_config(project_root)
    if not ws_config_path:
        raise typer.BadParameter("No .paircoder-workspace.yaml found")

    ws_config = parser.parse(ws_config_path)

    additional_dirs: list[str] = []
    allow: list[str] = []
    deny: list[str] = []

    for name, proj in ws_config.projects.items():
        proj_path = (ws_config_path.parent / proj.path).resolve()
        if not proj_path.exists():
            logger.warning(
                "Project %s path does not exist: %s", name, proj_path,
            )
            continue

        abs_path = str(proj_path)
        if not _validate_path(abs_path):
            logger.warning(
                "Skipping project %s: path contains unsafe characters: %s",
                name, abs_path,
            )
            continue

        additional_dirs.append(abs_path)

        for pattern in _ALLOW_PATTERNS:
            allow.append(pattern.format(path=abs_path))
        for pattern in _DENY_PATTERNS:
            deny.append(pattern.format(path=abs_path))

    return {
        "additionalDirectories": additional_dirs,
        "permissions": {
            "allow": allow,
            "deny": deny,
        },
        "_managed_by": "bpsai-pair workspace setup-permissions",
    }


def _deep_merge_settings(existing: dict, generated: dict) -> dict:
    """Merge generated settings into existing, preserving user entries.

    Lists (additionalDirectories, permissions.allow, permissions.deny)
    are unioned, not replaced. Scalar values use generated.
    """
    merged = dict(existing)
    for key, value in generated.items():
        if key in merged and isinstance(merged[key], list) and isinstance(value, list):
            # Union lists, preserving order (existing first, then new)
            seen = set(merged[key])
            merged[key] = merged[key] + [v for v in value if v not in seen]
        elif key in merged and isinstance(merged[key], dict) and isinstance(value, dict):
            merged[key] = _deep_merge_settings(merged[key], value)
        else:
            merged[key] = value
    return merged


def setup_permissions(
    project_root: Path,
    dry_run: bool = False,
    force: bool = False,
) -> dict[str, Any]:
    """Generate and optionally write permissions.

    Args:
        project_root: Root directory of the project.
        dry_run: If True, return config without writing.
        force: If True, overwrite even if existing file has errors.

    Returns:
        The generated (or merged) settings dict.
    """
    generated = generate_permissions(project_root)

    if dry_run:
        return generated

    settings_path = project_root / ".claude" / "settings.local.json"
    settings_path.parent.mkdir(parents=True, exist_ok=True)

    existing: dict[str, Any] = {}
    if settings_path.exists():
        try:
            existing = json.loads(settings_path.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            if not force:
                raise

    merged = _deep_merge_settings(existing, generated)

    settings_path.write_text(
        json.dumps(merged, indent=2) + "\n",
        encoding="utf-8",
    )

    return merged


def register_setup_permissions(app: typer.Typer) -> None:
    """Register setup-permissions command on workspace app."""

    @app.command("setup-permissions")
    @require_feature("workspace")
    def cmd_setup_permissions(
        dry_run: bool = typer.Option(
            False, "--dry-run", help="Preview without writing",
        ),
        force: bool = typer.Option(
            False, "--force", help="Overwrite existing managed section",
        ),
        json_out: bool = typer.Option(
            False, "--json", help="Output as JSON",
        ),
    ) -> None:
        """Generate .claude/settings.local.json from workspace config."""
        root = ops.find_project_root()
        result = setup_permissions(root, dry_run=dry_run, force=force)

        if json_out:
            import sys

            sys.stdout.write(json.dumps(result, indent=2) + "\n")
            sys.stdout.flush()
            return

        if dry_run:
            console.print("[yellow]Dry run[/yellow] -- would generate:")
            console.print(json.dumps(result, indent=2))
            return

        n_dirs = len(result.get("additionalDirectories", []))
        console.print(
            f"[green]Generated[/green] .claude/settings.local.json "
            f"({n_dirs} sibling project(s))",
        )
