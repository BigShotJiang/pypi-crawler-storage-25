"""Session status command: display current session info and token budget.

Extracted from session_check.py to keep files under architecture limits.
"""
from __future__ import annotations

from pathlib import Path
from typing import Optional

import typer
from rich.console import Console

# Try relative imports first, fall back to absolute
try:
    from ..core import ops
except ImportError:
    from bpsai_pair.core import ops

console = Console()

_DEFAULT_MODEL = "claude-sonnet-4-6"


def _load_default_model() -> str:
    """Load default model from config.yaml if available."""
    try:
        import yaml
        root = ops.find_project_root()
        config_file = root / ".paircoder" / "config.yaml"
        if config_file.exists():
            with open(config_file, encoding="utf-8") as f:
                config = yaml.safe_load(f) or {}
            return config.get("models", {}).get("driver", _DEFAULT_MODEL)
    except Exception:
        pass
    return _DEFAULT_MODEL


def _get_progress_bar(percent: float, width: int = 20) -> str:
    """Create a text-based progress bar."""
    filled = int(percent / 100 * width)
    empty = width - filled

    if percent >= 90:
        color = "red"
    elif percent >= 75:
        color = "yellow"
    elif percent >= 50:
        color = "blue"
    else:
        color = "green"

    bar = "\u2588" * filled + "\u2591" * empty
    return f"[{color}]{bar}[/{color}]"


def _get_current_task_id(paircoder_dir: Path) -> Optional[str]:
    """Get the current in-progress task ID."""
    tasks_dir = paircoder_dir / "tasks"
    if not tasks_dir.exists():
        return None

    for task_file in tasks_dir.glob("*.task.md"):
        try:
            content = task_file.read_text(encoding="utf-8")
            if "status: in_progress" in content:
                for line in content.split('\n'):
                    if line.startswith('id:'):
                        return line.split(':', 1)[1].strip()
        except Exception:
            pass
    return None


def _display_budget(paircoder_dir: Path, current_task_id: str) -> None:
    """Display token budget info for a specific task."""
    try:
        from ..tokens import estimate_from_task_file, get_budget_status
    except ImportError:
        from bpsai_pair.tokens import estimate_from_task_file, get_budget_status

    task_file = None
    for pattern in [f"tasks/{current_task_id}.task.md", f"tasks/TASK-{current_task_id}.task.md"]:
        path = paircoder_dir / pattern
        if path.exists():
            task_file = path
            break

    if not task_file:
        console.print(f"  [dim]Task file not found for {current_task_id}[/dim]")
        return

    estimate = estimate_from_task_file(task_file)
    if not estimate:
        console.print("  [dim]Could not estimate tokens for current task[/dim]")
        return

    status = get_budget_status(estimate.total)
    bar = _get_progress_bar(estimate.budget_percent)
    console.print(f"  {bar} {estimate.budget_percent}% ({estimate.total:,} / {status.limit:,})")

    status_colors = {"ok": "green", "info": "blue", "warning": "yellow", "critical": "red"}
    color = status_colors.get(status.status, "white")
    console.print(f"  Status: [{color}]{status.status.upper()}[/{color}] - {status.message}")
    console.print(f"  [dim]Task: {current_task_id}[/dim]")


def _display_session_info(state, manager) -> None:
    """Display session timing information."""
    from datetime import datetime

    now = datetime.now()
    gap = now - state.last_activity
    gap_minutes = int(gap.total_seconds() / 60)

    console.print(f"[cyan]Session ID:[/cyan] {state.session_id}")
    console.print(f"[cyan]Last activity:[/cyan] {state.last_activity.isoformat()}")
    console.print(f"[cyan]Gap:[/cyan] {gap_minutes} minutes")
    console.print(f"[cyan]Timeout:[/cyan] {manager.timeout_minutes} minutes")

    if gap_minutes > manager.timeout_minutes:
        console.print("[yellow]Session expired - next check will start new session[/yellow]")
    else:
        remaining = manager.timeout_minutes - gap_minutes
        console.print(f"[green]Session active ({remaining} min until timeout)[/green]")


def _display_budget_section(paircoder_dir: Path) -> None:
    """Display token budget section."""
    console.print()
    console.print("[bold]Token Budget:[/bold]")

    current_task_id = _get_current_task_id(paircoder_dir)
    if current_task_id:
        _display_budget(paircoder_dir, current_task_id)
    else:
        try:
            from ..tokens import MODEL_LIMITS
        except ImportError:
            from bpsai_pair.tokens import MODEL_LIMITS

        default_model = _load_default_model()
        limit = MODEL_LIMITS.get(default_model, 200000)
        console.print(f"  [dim]No active task. Budget limit: {limit:,} tokens[/dim]")


def session_status(
    show_budget: bool = typer.Option(True, "--budget/--no-budget", help="Show token budget section"),
) -> None:
    """Show current session status including token budget."""
    try:
        from ..session import SessionManager, SessionState
    except ImportError:
        from bpsai_pair.session import SessionManager, SessionState

    from .session_check import repo_root

    root = repo_root()
    paircoder_dir = root / ".paircoder"

    if not paircoder_dir.exists():
        console.print("[yellow]No .paircoder directory found[/yellow]")
        raise typer.Exit(1)

    manager = SessionManager(paircoder_dir)
    session_file = manager.session_file

    if not session_file.exists():
        console.print("[dim]No active session[/dim]")
        return

    try:
        import json
        with open(session_file, encoding='utf-8') as f:
            data = json.load(f)
        state = SessionState.from_dict(data)

        _display_session_info(state, manager)

        if show_budget:
            _display_budget_section(paircoder_dir)

    except Exception as e:
        console.print(f"[red]Error reading session: {e}[/red]")
