"""Summary and query metrics commands: summary, task, breakdown, export."""
from __future__ import annotations

from pathlib import Path

import typer
from rich.table import Table
from .helpers import app, console


@app.command("summary")
def metrics_summary(
    json_out: bool = typer.Option(False, "--json", help="Output in JSON format"),
):
    """Show metrics summary from telemetry data."""
    from bpsai_pair.commands import metrics as _m
    queries = _m._get_telemetry_queries()
    summary = queries.get_cost_summary()

    if json_out:
        _m.print_json(summary)
    else:
        console.print("[bold]Metrics Summary[/bold]")
        console.print(f"Tasks: {summary['task_count']}")
        console.print(f"Total Cost: ${summary['total_cost']:.2f}")
        console.print(f"Input Tokens: {summary['total_input_tokens']:,}")
        console.print(f"Output Tokens: {summary['total_output_tokens']:,}")


@app.command("task")
def metrics_task(
    task_id: str = typer.Argument(..., help="Task ID"),
    json_out: bool = typer.Option(False, "--json", help="Output in JSON format"),
):
    """Show metrics for a specific task."""
    from bpsai_pair.commands import metrics as _m
    queries = _m._get_telemetry_queries()
    metrics = queries.get_task_metrics(task_id)

    if metrics is None:
        console.print(f"[red]No telemetry found for task: {task_id}[/red]")
        raise typer.Exit(1)

    if json_out:
        _m.print_json(metrics)
    else:
        console.print(f"[bold]Task Metrics: {task_id}[/bold]")
        console.print(f"Type: {metrics['task_type']}")
        console.print(f"Model: {metrics['model']}")
        console.print(f"Tokens: {metrics['input_tokens']:,} in / {metrics['output_tokens']:,} out")
        console.print(f"Cost: ${metrics['cost']:.2f}")
        console.print(f"Duration: {metrics['duration_seconds']}s")
        if metrics.get("sprint"):
            console.print(f"Sprint: {metrics['sprint']}")
        console.print(f"Outcome: {metrics['outcome']}")


@app.command("breakdown")
def metrics_breakdown(
    by: str = typer.Option("model", "--by", "-b", help="Breakdown by: model, task_type"),
    json_out: bool = typer.Option(False, "--json", help="Output in JSON format"),
):
    """Show cost breakdown by dimension."""
    from bpsai_pair.commands import metrics as _m
    queries = _m._get_telemetry_queries()
    breakdown = queries.get_cost_breakdown(by)

    if json_out:
        _m.print_json(breakdown)
    else:
        total_cost = sum(v["cost"] for v in breakdown.values())
        table = Table(title=f"Cost Breakdown by {by.title()}")
        table.add_column(by.title(), style="cyan")
        table.add_column("Tasks", justify="right")
        table.add_column("Tokens", justify="right")
        table.add_column("Cost", justify="right")
        table.add_column("%", justify="right")

        for key, stats in sorted(breakdown.items(), key=lambda x: x[1]["cost"], reverse=True):
            pct = (stats["cost"] / total_cost * 100) if total_cost > 0 else 0
            total_tokens = stats["input_tokens"] + stats["output_tokens"]
            table.add_row(
                key,
                str(stats["tasks"]),
                f"{total_tokens:,}",
                f"${stats['cost']:.4f}",
                f"{pct:.1f}%",
            )

        console.print(table)


@app.command("export")
def metrics_export(
    output: str = typer.Option("metrics.csv", "--output", "-o", help="Output file path"),
    format_type: str = typer.Option("csv", "--format", "-f", help="Export format: csv"),
):
    """Export metrics to file."""
    from bpsai_pair.commands import metrics as _m
    collector = _m._get_metrics_collector()
    reporter = _m.MetricsReporter(collector)

    if format_type.lower() == "csv":
        csv_content = reporter.export_csv()
        Path(output).write_text(csv_content, encoding="utf-8")
        console.print(f"[green]\u2713[/green] Exported metrics to {output}")
    else:
        console.print(f"[red]Unsupported format: {format_type}[/red]")
        raise typer.Exit(1)
