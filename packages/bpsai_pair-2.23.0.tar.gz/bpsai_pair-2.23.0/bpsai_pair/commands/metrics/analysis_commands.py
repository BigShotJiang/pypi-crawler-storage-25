"""Analysis metrics commands: velocity, accuracy, tokens, budget."""
from __future__ import annotations

import typer
from rich.table import Table
from .helpers import app, console


def _display_velocity(stats, queries, weeks, current_sprint):
    """Display velocity metrics in rich format."""
    console.print("[bold]Velocity Metrics[/bold]")
    console.print("")

    if current_sprint:
        console.print(f"Points this sprint:   {stats['points_this_sprint']} ({current_sprint})")
    else:
        console.print(f"Points this sprint:   {stats['points_this_sprint']}")
    console.print("")

    console.print(f"Average weekly velocity ({weeks} weeks): {stats['avg_weekly_velocity']:.1f}")
    console.print(f"Average sprint velocity: {stats['avg_sprint_velocity']:.1f}")
    console.print("")

    breakdown = queries.get_weekly_breakdown(weeks=weeks)
    if breakdown and any(b["points"] > 0 for b in breakdown):
        console.print("[bold]Weekly Breakdown:[/bold]")
        table = Table()
        table.add_column("Week Start", style="cyan")
        table.add_column("Points", justify="right")
        for entry in breakdown:
            table.add_row(entry["week_start"], str(entry["points"]))
        console.print(table)
        console.print("")

    sprint_breakdown = queries.get_sprint_breakdown()
    if sprint_breakdown:
        console.print("[bold]Sprint Breakdown:[/bold]")
        table = Table()
        table.add_column("Sprint", style="cyan")
        table.add_column("Points", justify="right")
        for sprint_id in sorted(sprint_breakdown.keys(), reverse=True):
            table.add_row(sprint_id, str(sprint_breakdown[sprint_id]))
        console.print(table)

    if stats['sprints_tracked'] == 0:
        console.print("[dim]No velocity data recorded yet.[/dim]")
        console.print("[dim]Velocity is tracked when tasks are completed.[/dim]")


def _display_tokens(report, stats):
    """Display token estimation accuracy in rich format."""
    console.print("[bold]Token Estimation Accuracy Report[/bold]")
    console.print("=" * 34)
    console.print("")

    if stats["total_tasks"] == 0:
        console.print("[dim]No token usage data available.[/dim]")
        console.print("[dim]Token accuracy is tracked when tasks are completed with metrics recording.[/dim]")
        return

    console.print(f"Tasks Analyzed: {stats['total_tasks']}")
    console.print(f"Avg Ratio (actual/estimated): {stats['avg_ratio']:.2f}x")

    if stats["avg_ratio"] > 1.1:
        console.print(f"[yellow]Bias: Underestimating by ~{int((stats['avg_ratio'] - 1) * 100)}%[/yellow]")
    elif stats["avg_ratio"] < 0.9:
        console.print(f"[yellow]Bias: Overestimating by ~{int((1 - stats['avg_ratio']) * 100)}%[/yellow]")
    else:
        console.print("[green]Bias: Estimates are well-calibrated[/green]")
    console.print("")

    by_type = report["by_task_type"]
    if by_type:
        console.print("[bold]By Task Type:[/bold]")
        for task_type, type_stats in by_type.items():
            ratio = type_stats["avg_ratio"]
            ratio_str = f"{ratio:.2f}x"
            if ratio > 1.1:
                ratio_str = f"[yellow]{ratio:.2f}x (underestimate)[/yellow]"
            elif ratio < 0.9:
                ratio_str = f"[cyan]{ratio:.2f}x (overestimate)[/cyan]"
            console.print(f"- {task_type.title()}: {ratio_str} ({type_stats['count']} tasks)")
        console.print("")

    recommendations = report.get("recommendations", [])
    if recommendations:
        console.print("[bold]Recommendations:[/bold]")
        for rec in recommendations:
            console.print(f"- {rec}")
    else:
        console.print("[dim]No coefficient adjustments recommended yet.[/dim]")

@app.command("budget")
def metrics_budget(
    json_out: bool = typer.Option(False, "--json", help="Output in JSON format"),
):
    """Show budget status."""
    from bpsai_pair.commands import metrics as _m
    collector = _m._get_metrics_collector()
    enforcer = _m.BudgetEnforcer(collector)
    status = enforcer.check_budget()

    if json_out:
        _m.print_json({
            "daily": {
                "spent": status.daily_spent,
                "limit": status.daily_limit,
                "remaining": status.daily_remaining,
                "percent": status.daily_percent,
            },
            "monthly": {
                "spent": status.monthly_spent,
                "limit": status.monthly_limit,
                "remaining": status.monthly_remaining,
                "percent": status.monthly_percent,
            },
            "alert": {
                "triggered": status.alert_triggered,
                "message": status.alert_message,
            },
        })
        return

    console.print("[bold]Budget Status[/bold]")
    console.print("")
    console.print(f"Daily:   ${status.daily_spent:.2f} / ${status.daily_limit:.2f} ({status.daily_percent:.1f}%)")
    console.print(f"         Remaining: ${status.daily_remaining:.2f}")
    console.print("")
    console.print(f"Monthly: ${status.monthly_spent:.2f} / ${status.monthly_limit:.2f} ({status.monthly_percent:.1f}%)")
    console.print(f"         Remaining: ${status.monthly_remaining:.2f}")

    if status.alert_triggered:
        console.print("")
        console.print(f"[yellow]\u26a0 {status.alert_message}[/yellow]")


@app.command("velocity")
def metrics_velocity(
    weeks: int = typer.Option(4, "--weeks", "-w", help="Number of weeks for rolling average"),
    json_out: bool = typer.Option(False, "--json", help="Output in JSON format"),
):
    """Show velocity metrics for project planning."""
    from bpsai_pair.commands import metrics as _m
    from ...planning.state import StateManager

    root = _m.repo_root()
    queries = _m._get_telemetry_queries()
    state_manager = StateManager(root / ".paircoder")
    current_sprint = state_manager.state.active_sprint_id or ""
    stats = queries.get_velocity_stats(current_sprint, weeks=weeks)

    if json_out:
        _m.print_json(stats)
        return

    _display_velocity(stats, queries, weeks, current_sprint)


@app.command("accuracy")
def metrics_accuracy(
    json_out: bool = typer.Option(False, "--json", help="Output in JSON format"),
):
    """Show estimation accuracy report."""
    from bpsai_pair.commands import metrics as _m
    queries = _m._get_telemetry_queries()
    stats = queries.get_accuracy_stats()

    if json_out:
        _m.print_json(stats)
        return

    console.print("[bold]Estimation Accuracy Report[/bold]")
    console.print("=" * 26)
    console.print("")

    if stats["total_tasks"] == 0:
        console.print("[dim]No historical data available.[/dim]")
        console.print("[dim]Accuracy is tracked when tasks are completed with time tracking.[/dim]")
        return

    console.print(f"Tasks analyzed: {stats['total_tasks']}")
    console.print(f"Overall Accuracy: {stats['avg_accuracy']:.0f}%")
    bias_str = f"Bias: {stats['bias'].title()}"
    if stats["bias"] != "neutral":
        bias_str += f" ({stats.get('avg_variance_percent', 0):.0f}% variance)"
    console.print(bias_str)


@app.command("tokens")
def metrics_tokens(
    json_out: bool = typer.Option(False, "--json", help="Output in JSON format"),
):
    """Show token estimation accuracy report."""
    from bpsai_pair.commands import metrics as _m
    tracker = _m._get_token_tracker()
    report = tracker.generate_report()
    stats = report["stats"]

    if json_out:
        _m.print_json(report)
        return

    _display_tokens(report, stats)