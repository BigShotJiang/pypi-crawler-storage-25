"""License management CLI commands.

Provides commands for checking license status, viewing available features,
and installing license files.
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Optional

import typer

from bpsai_pair.licensing import (
    get_all_features_api,
    get_tier,
    get_tier_display_name,
    load_license,
)
from bpsai_pair.licensing.keys import (
    DEFAULT_API_URL,
    verify_key_alignment,
)
from bpsai_pair.licensing.machine import (
    get_machine_id,
    mask_machine_id,
)
from bpsai_pair.licensing.activation import (
    ActivationError,
    activate_machine,
    deactivate_machine,
    list_machines,
)
from bpsai_pair.commands.license_helpers import (
    print_json,
    get_license_file_path,
    build_status_json,
    print_status_rich,
    print_features_rich,
    validate_license_file,
    install_license_file,
    build_machines_json,
    print_machines_table,
    should_prompt_activation,
    handle_activation_error,
    handle_activation_prompt,
    console,
)

# License command group
app = typer.Typer(
    help="License management commands",
    context_settings={"help_option_names": ["-h", "--help"]},
)


@app.command("status")
def license_status(
    json_out: bool = typer.Option(False, "--json", help="Output in JSON format"),
):
    """Show current license status."""
    license_data = load_license()
    tier = get_tier()
    tier_display = get_tier_display_name(tier)
    features = get_all_features_api()

    if json_out:
        print_json(build_status_json(license_data, tier, tier_display, features))
    else:
        print_status_rich(license_data, tier_display, features)
@app.command("path")
def license_path(
    json_out: bool = typer.Option(False, "--json", help="Output in JSON format"),
):
    """Show license file location."""
    current_path = get_license_file_path()

    if json_out:
        search_paths = [
            os.environ.get("PAIRCODER_LICENSE", "(not set)"),
            str(Path.home() / ".paircoder" / "license.json"),
            str(Path.cwd() / ".paircoder" / "license.json"),
        ]
        print_json({"current_path": str(current_path) if current_path else None, "search_paths": search_paths})
        return

    console.print()
    if current_path:
        console.print(f"[bold green]License file:[/bold green] {current_path}")
    else:
        console.print("[yellow]No license file found.[/yellow]")
        console.print()
        console.print("[bold]Search locations (in order):[/bold]")
        env_path = os.environ.get("PAIRCODER_LICENSE")
        if env_path:
            console.print(f"  1. PAIRCODER_LICENSE: {env_path}")
        else:
            console.print("  1. PAIRCODER_LICENSE: [dim](not set)[/dim]")
        console.print(f"  2. {Path.home() / '.paircoder' / 'license.json'}")
        console.print(f"  3. {Path.cwd() / '.paircoder' / 'license.json'}")
    console.print()
@app.command("features")
def license_features(
    json_out: bool = typer.Option(False, "--json", help="Output in JSON format"),
):
    """List available features for current tier."""
    license_data = load_license()
    tier = get_tier()
    tier_display = get_tier_display_name(tier)
    available_features = get_all_features_api()

    if json_out:
        print_json({
            "tier": tier,
            "tier_display": tier_display,
            "feature_count": len(available_features),
            "features": sorted(available_features),
        })
    else:
        print_features_rich(tier, tier_display, license_data)
@app.command("install")
def license_install(
    license_file: Path = typer.Argument(
        ...,
        help="Path to license file. WSL users: Windows files are at /mnt/c/Users/<name>/Downloads/",
        exists=False,
    ),
    force: bool = typer.Option(False, "--force", "-f", help="Overwrite existing license"),
    activate: bool = typer.Option(False, "--activate", help="Auto-activate this machine (non-interactive)"),
    no_activate: bool = typer.Option(False, "--no-activate", help="Skip activation prompt"),
):
    """Install a license file to ~/.paircoder/license.json."""
    validate_license_file(license_file)

    dest_file = Path.home() / ".paircoder" / "license.json"
    if dest_file.exists() and not force:
        console.print(f"[yellow]Warning:[/yellow] License already exists at {dest_file}")
        console.print("Use --force to overwrite.")
        raise typer.Exit(1)

    install_license_file(license_file, dest_file)

    console.print()
    console.print(f"[green]✓[/green] Copied: {license_file} → {dest_file}")

    new_license = load_license()
    if new_license:
        tier_display = get_tier_display_name(new_license.payload.tier)
        console.print(f"[green]✓[/green] Signature verified")
        console.print()
        console.print(f"  [bold]Tier:[/bold]  {tier_display}")
        console.print(f"  [bold]Email:[/bold] {new_license.payload.email}")
    else:
        console.print()
        console.print("[yellow]⚠ Signature verification failed[/yellow]")
        console.print("  License may be invalid or signed with wrong key.")
        console.print("  The file was copied but may not work correctly.")
        console.print()
        return

    # Handle auto-activation
    if no_activate:
        console.print()
        return

    machine_id = get_machine_id()
    if not should_prompt_activation(new_license, machine_id):
        console.print()
        return

    handle_activation_prompt(new_license, machine_id, mask_machine_id, activate)
@app.command("machine-id")
def license_machine_id(
    full: bool = typer.Option(False, "--full", "-f", help="Show full ID (not masked)"),
    json_out: bool = typer.Option(False, "--json", help="Output in JSON format"),
):
    """Display this machine's unique identifier.

    The machine ID is used for license binding. By default, the ID is
    partially masked for privacy. Use --full to see the complete ID.
    """
    machine_id = get_machine_id()

    if json_out:
        display_id = machine_id if full else mask_machine_id(machine_id)
        print_json({
            "machine_id": display_id,
            "masked": not full,
        })
        return

    console.print()
    if full:
        console.print(f"[bold]Machine ID:[/bold] {machine_id}")
    else:
        console.print(f"[bold]Machine ID:[/bold] {mask_machine_id(machine_id)}")
        console.print()
        console.print("[dim]Use --full to see complete ID[/dim]")
    console.print()
@app.command("verify-key")
def license_verify_key(
    api_url: str = typer.Option(DEFAULT_API_URL, "--api-url", help="API URL"),
    json_out: bool = typer.Option(False, "--json", help="Output in JSON format"),
):
    """Verify CLI public key matches API's keypair."""
    result = verify_key_alignment(api_url)

    if result["error"]:
        if json_out:
            print_json(result)
        else:
            console.print(f"[red]Error:[/red] {result['error']}")
        raise typer.Exit(1)

    if json_out:
        print_json(result)
        if not result["matching"]:
            raise typer.Exit(1)
        return

    # Rich output
    console.print()
    cli_fp = result["cli_fingerprint"]
    api_fp = result.get("api_fingerprint")
    console.print(f"[bold]CLI Fingerprint:[/bold]  {cli_fp[:16]}...{cli_fp[-8:]}")
    if api_fp:
        console.print(f"[bold]API Fingerprint:[/bold]  {api_fp[:16]}...{api_fp[-8:]}")
    console.print()
    if result["matching"]:
        console.print("[green]✓[/green] Keys match - CLI and API use the same keypair")
    else:
        console.print("[red]✗[/red] Key mismatch - CLI and API use different keypairs!")
        console.print()
        console.print("[yellow]Warning:[/yellow] Licenses from the API will not verify correctly.")
        console.print("         Please update the CLI or contact support.")
    console.print()
    if not result["matching"]:
        raise typer.Exit(1)
@app.command("activate")
def license_activate(
    name: str = typer.Option(None, "--name", "-n", help="Friendly name for this machine"),
    json_out: bool = typer.Option(False, "--json", help="Output in JSON format"),
):
    """Activate this machine on your license."""
    license_data = load_license()
    if license_data is None:
        console.print("[red]Error:[/red] No license installed.")
        console.print("Install a license with: bpsai-pair license install <file>")
        raise typer.Exit(1)

    machine_id = get_machine_id()
    license_id = license_data.payload.license_id

    try:
        result = activate_machine(license_id, machine_id, name)
    except ActivationError as e:
        if json_out:
            print_json({"success": False, "error": str(e)})
        else:
            console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1)

    if json_out:
        print_json({
            "success": result.success,
            "machine_id": mask_machine_id(result.machine_id),
            "machine_name": result.machine_name,
            "machines_used": result.machines_used,
            "machines_allowed": result.machines_allowed,
        })
        return

    console.print()
    console.print(f"[green]✓[/green] Activated successfully!")
    console.print(f"  [bold]Machine ID:[/bold] {mask_machine_id(result.machine_id)}")
    if result.machine_name:
        console.print(f"  [bold]Name:[/bold] {result.machine_name}")
    console.print(f"  [bold]Machines:[/bold] {result.machines_used}/{result.machines_allowed} used")
    console.print()
@app.command("deactivate")
def license_deactivate(
    machine_id_arg: Optional[str] = typer.Option(
        None, "--machine-id", "-m",
        help="Machine ID to deactivate (use 'license machines' to list). Defaults to current machine."
    ),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation"),
    json_out: bool = typer.Option(False, "--json", help="Output in JSON format"),
):
    """Deactivate a machine from your license.

    By default, deactivates the current machine. Use --machine-id to deactivate
    a different machine (useful when the old device is inaccessible).

    Examples:
        bpsai-pair license deactivate              # Deactivate current machine
        bpsai-pair license deactivate -m abc123    # Deactivate specific machine
    """
    license_data = load_license()
    if license_data is None:
        console.print("[red]Error:[/red] No license installed.")
        raise typer.Exit(1)

    # Use provided machine ID or current machine
    target_machine_id = machine_id_arg if machine_id_arg else get_machine_id()
    is_current_machine = machine_id_arg is None
    license_id = license_data.payload.license_id

    if not yes and not json_out:
        console.print()
        console.print(f"[bold]Machine ID:[/bold] {mask_machine_id(target_machine_id)}")
        if is_current_machine:
            confirm = typer.confirm("Deactivate this machine?")
        else:
            confirm = typer.confirm("Deactivate this remote machine?")
        if not confirm:
            raise typer.Abort()

    try:
        result = deactivate_machine(license_id, target_machine_id)
    except ActivationError as e:
        if json_out:
            print_json({"success": False, "error": str(e)})
        else:
            console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1)

    if json_out:
        print_json({
            "success": result.success,
            "machine_id": mask_machine_id(result.machine_id),
            "machines_used": result.machines_used,
            "machines_allowed": result.machines_allowed,
        })
        return

    console.print()
    console.print(f"[green]✓[/green] Deactivated successfully!")
    console.print(f"  [bold]Machines:[/bold] {result.machines_used}/{result.machines_allowed} used")
    console.print()
@app.command("machines")
def license_machines(
    json_out: bool = typer.Option(False, "--json", help="Output in JSON format"),
    full_ids: bool = typer.Option(
        False, "--full", "-f",
        help="Show full machine IDs (required for remote deactivation)"
    ),
):
    """List all machines activated on your license.

    Use --full with --json to get full machine IDs for remote deactivation:
        bpsai-pair license machines --json --full
        bpsai-pair license deactivate --machine-id <full-id>
    """
    license_data = load_license()
    if license_data is None:
        console.print("[red]Error:[/red] No license installed.")
        raise typer.Exit(1)

    license_id = license_data.payload.license_id
    current_machine_id = get_machine_id()

    try:
        result = list_machines(license_id)
    except ActivationError as e:
        if json_out:
            print_json({"success": False, "error": str(e)})
        else:
            console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1)

    if json_out:
        print_json(build_machines_json(
            result, current_machine_id, mask_machine_id, show_full_ids=full_ids
        ))
        return

    console.print()
    if not result.machines:
        console.print("[yellow]No machines activated.[/yellow]")
        console.print(f"  [bold]Slots:[/bold] {result.machines_used}/{result.machines_allowed} used")
        console.print()
        return

    # Show full IDs in table if requested
    id_fn = (lambda x: x) if full_ids else mask_machine_id
    print_machines_table(result, current_machine_id, id_fn)


@app.command("clear-cache")
def license_clear_cache(
    json_out: bool = typer.Option(False, "--json", help="Output in JSON format"),
):
    """Clear cached license validation data.

    Removes:
    - Validation cache (used for offline mode)
    - Rate limit state (used for backoff)
    """
    from bpsai_pair.licensing.security import clear_license_cache

    cleared = clear_license_cache()

    if json_out:
        print_json({"cleared": cleared})
        return

    console.print()
    if cleared:
        console.print("[green]✓[/green] License cache cleared.")
    else:
        console.print("[yellow]No cache to clear.[/yellow]")
    console.print()