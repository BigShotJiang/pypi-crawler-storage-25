"""Guard, validation, and lifecycle functions extracted from engage.py (REV-004).

PR creation: see engage_pr.py
Security gate: see engage_security.py
"""
from __future__ import annotations

import json
import logging
import re
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import typer

from bpsai_pair.orchestration.headless import HeadlessSession

# Re-export from split modules for backward compatibility
from bpsai_pair.commands.engage_pr import (  # noqa: F401
    _build_pr_body,
    _build_pr_title,
    _create_pull_request,
    _extract_backlog_title,
)
from bpsai_pair.commands.engage_security import (  # noqa: F401
    _SECURITY_AUDIT_PREFIX,
    _SECURITY_AUDIT_PROMPT,
    _SECURITY_AUDIT_SUFFIX,
    _check_diff_size,
    _dispatch_cross_module_review,
    _get_branch_diff,
    _invoke_security_agent,
    _is_large_diff,
    _parse_diff_stat,
    _pre_pr_security_check,
)

logger = logging.getLogger(__name__)

_TASK_ID_RE = re.compile(r"^[A-Za-z0-9._-]+$")
_SHELL_METACHAR_RE = re.compile(r"[$()`|;&<>{}\\!]")
_CONTROL_CHAR_RE = re.compile(r"[\x00-\x1f\x7f]")
_DEFAULT_PROTECTED_BRANCHES = ["main", "dev", "master"]
_SPRINT_PREFIX_RE = re.compile(r"^sprint-\d+-", re.IGNORECASE)


def _validate_task_id(task_id: str) -> str:
    """Sanitize a task ID for safe embedding in telemetry JSON."""
    cleaned = _CONTROL_CHAR_RE.sub("", task_id)
    return "".join(c for c in cleaned if re.match(r"[A-Za-z0-9._-]", c))


def _sanitize_pr_url(url: str) -> str:
    """Strip control characters from a PR URL."""
    return _CONTROL_CHAR_RE.sub("", url)


def _validate_backlog_path(path: Path) -> Path:
    """Canonicalize and validate a backlog path."""
    path_str = str(path)
    if _CONTROL_CHAR_RE.search(path_str):
        raise ValueError(f"Backlog path contains invalid characters: {path_str!r}")
    # Normalize backslashes on Windows only so Windows paths (docs\\foo.md)
    # aren't rejected as shell metacharacters
    if sys.platform == "win32":
        normalized = path_str.replace("\\", "/")
    else:
        normalized = path_str
    if _SHELL_METACHAR_RE.search(normalized):
        raise ValueError(f"Backlog path contains invalid shell metacharacters: {path_str!r}")
    resolved = path.resolve()
    if not resolved.exists():
        raise ValueError(f"Backlog path does not exist: {resolved}")
    if resolved.suffix != ".md":
        raise ValueError(f"Backlog path must have .md extension, got: {resolved.suffix}")
    return resolved


def _get_protected_branches(config: dict[str, Any] | None) -> list[str]:
    """Return the list of protected branch names."""
    if config and "engage" in config:
        branches = config["engage"].get("protected_branches")
        if branches is not None:
            return branches
    return list(_DEFAULT_PROTECTED_BRANCHES)


def _check_protected_branch(
    project_root: Path, config: dict[str, Any] | None = None,
) -> None:
    """Block engage if the current branch is protected."""
    result = subprocess.run(
        ["git", "branch", "--show-current"],
        cwd=project_root, capture_output=True, check=False,
        encoding="utf-8", errors="replace",
    )
    current = result.stdout.strip()
    protected = _get_protected_branches(config)
    if current in protected:
        typer.echo(
            f"Error: Cannot run engage on protected branch '{current}'. "
            "Options:\n"
            "  1. git checkout -b <branch>   — switch manually\n"
            "  2. --branch <name>            — use an explicit branch name\n"
            "  3. --create-branch            — derive a name from the backlog",
            err=True,
        )
        raise typer.Exit(1)


def _derive_branch_slug(backlog_name: str) -> str:
    """Derive an engage branch name from a backlog filename.

    Strip .md extension and any leading ``sprint-N-`` prefix, lowercase,
    replace whitespace with dashes.
    """
    stem = Path(backlog_name).stem
    slug = _SPRINT_PREFIX_RE.sub("", stem).lower()
    slug = re.sub(r"\s+", "-", slug)
    return f"engage/{slug}"


def _cleanup_stale_stashes(project_root: Path) -> None:
    """Drop stale containment auto-stash entries older than 7 days.

    Containment checkpoints create auto-stash entries that accumulate
    over time. This cleans up entries with "Auto-stash before containment"
    in their message that are older than 7 days.
    """
    try:
        result = subprocess.run(
            ["git", "stash", "list"],
            cwd=str(project_root),
            capture_output=True, timeout=5, check=False,
            encoding="utf-8", errors="replace",
        )
        if not result.stdout.strip():
            return
        # Collect matching stash refs, then drop from highest index first
        # to avoid index shifts invalidating subsequent drops.
        stale_refs: list[str] = []
        for line in result.stdout.strip().splitlines():
            if "Auto-stash before containment" in line:
                ref = line.split(":")[0].strip()
                stale_refs.append(ref)
        for ref in reversed(stale_refs):
            subprocess.run(
                ["git", "stash", "drop", ref],
                cwd=str(project_root),
                capture_output=True, timeout=5, check=False,
                encoding="utf-8", errors="replace",
            )
            logger.info("Dropped stale containment stash: %s", ref)
    except Exception:
        pass  # Best-effort cleanup, never block engage


def _enforce_engage_gate(project_root: Path) -> None:
    """Run the approval gate and pre-flight cleanup for engage."""
    _cleanup_stale_stashes(project_root)

    from bpsai_pair.intent_gate.approval_gate import ApprovalGate
    from bpsai_pair.intent_gate.dispatch_guard import check_engage_approval

    telemetry_dir = project_root / ".paircoder" / "telemetry"
    gate = ApprovalGate(telemetry_dir=telemetry_dir)
    gate_result = check_engage_approval(gate)
    if gate_result.blocked:
        raise typer.Exit(1)


def _dispatch_review_agents(
    project_root: Path, pr_url: str,
) -> dict[str, Any] | None:
    """Dispatch reviewer + security-auditor agents against the PR diff."""
    try:
        from bpsai_pair.orchestration.engage_review import _dispatch_pr_review
        return _dispatch_pr_review(project_root, pr_url)
    except Exception:
        logger.warning("Review dispatch failed", exc_info=True)
        return None


def _emit_sprint_observation(
    project_root: Path, result: Any, pr_url: str | None,
) -> None:
    """Write a sprint observation signal to signals.jsonl."""
    is_failure = result.circuit_breaker_triggered
    signal_type = "sprint_failed" if is_failure else "sprint_completed"
    severity = "high" if is_failure else "info"
    safe_completed = [_validate_task_id(t) for t in result.completed_tasks]
    safe_failed = [_validate_task_id(t) for t in result.failed_tasks]
    safe_hook_failed = [_validate_task_id(t) for t in result.hook_failed_tasks]
    safe_blocked = [_validate_task_id(t) for t in result.blocked_tasks]
    safe_pr_url = _sanitize_pr_url(pr_url) if pr_url else None
    record = {
        "signal_type": signal_type, "severity": severity,
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "session_id": "",
        "payload": {
            "completed": safe_completed, "failed": safe_failed,
            "hook_failed": safe_hook_failed,
            "blocked": safe_blocked, "pr_url": safe_pr_url,
            "total_cx": result.total_complexity,
        },
        "source": "automated",
    }
    signals_path = project_root / ".paircoder" / "telemetry" / "signals.jsonl"
    signals_path.parent.mkdir(parents=True, exist_ok=True)
    with open(signals_path, "a", encoding="utf-8") as f:
        f.write(json.dumps(record) + "\n")


def _run_containment_audit_display(
    tasks: list, project_root: Path | None = None,
) -> None:
    """Run containment audit and display warnings (non-blocking)."""
    from bpsai_pair.engage.containment_audit import (
        format_warnings, run_containment_preflight,
    )
    from bpsai_pair.core.utils import repo_root
    root = project_root or repo_root()
    warnings = run_containment_preflight(root, tasks)
    if warnings:
        for line in format_warnings(warnings):
            typer.echo(line, err=True)
        typer.echo("", err=True)
