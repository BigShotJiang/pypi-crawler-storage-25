"""Post-install upgrade detection and prompting.

Detects when the CLI package version has changed (e.g. after pip upgrade)
and prompts the user to run `bpsai-pair upgrade` if the project config
is stale.
"""

from __future__ import annotations

from pathlib import Path
from typing import Optional

from packaging.version import InvalidVersion, Version

from ..core.config_defaults import is_config_stale


def get_last_run_version(project_root: Path) -> Optional[str]:
    """Read the last-run CLI version from .paircoder/.cli_version."""
    version_file = project_root / ".paircoder" / ".cli_version"
    if not version_file.exists():
        return None
    try:
        return version_file.read_text(encoding="utf-8").strip()
    except Exception:
        return None


def save_last_run_version(project_root: Path, version: str) -> None:
    """Save the current CLI version to .paircoder/.cli_version."""
    paircoder_dir = project_root / ".paircoder"
    if not paircoder_dir.exists():
        return
    try:
        (paircoder_dir / ".cli_version").write_text(version, encoding="utf-8")
    except Exception:
        pass


def check_upgrade_needed(project_root: Path, current_version: str) -> bool:
    """Check if an upgrade prompt should be shown.

    Returns True when:
    1. The CLI version has changed since last run (or first run), AND
    2. The project config version is behind the current schema version.
    """
    last_version = get_last_run_version(project_root)
    if last_version == current_version:
        return False

    stale, _, _ = is_config_stale(project_root)
    return stale


def _get_config_version(project_root: Path) -> Optional[str]:
    """Read the version field from .paircoder/config.yaml."""
    config_path = project_root / ".paircoder" / "config.yaml"
    if not config_path.exists():
        config_path = project_root / ".paircoder" / "config.yml"
    if not config_path.exists():
        return None
    try:
        import yaml

        data = yaml.safe_load(config_path.read_text(encoding="utf-8")) or {}
        v = data.get("version")
        return str(v) if v is not None else None
    except Exception:
        return None


def _is_downgrade(installed: str, config_version: Optional[str]) -> bool:
    """Return True if installed version is strictly older than config version.

    Uses semver comparison via packaging.version.Version.
    Returns False if either version can't be parsed (fail-open).
    """
    if config_version is None:
        return False
    try:
        return Version(installed) < Version(config_version)
    except InvalidVersion:
        return False


def _prompt_user() -> bool:
    """Ask the user whether to run upgrade now. Returns True if accepted."""
    import sys
    sys.stderr.write(
        "\033[33mProject config is outdated after upgrade. "
        "Run 'bpsai-pair upgrade' now? [Y/n] \033[0m"
    )
    sys.stderr.flush()
    try:
        answer = input().strip().lower()
        return answer in ("", "y", "yes")
    except (EOFError, KeyboardInterrupt):
        return False


def _run_upgrade_inline(project_root: Path) -> None:
    """Run upgrade programmatically (no interactive prompts)."""
    try:
        from .upgrade_helpers import (
            get_template_dir, plan_upgrade, execute_upgrade,
        )

        template = get_template_dir()
        if not template:
            return

        plan = plan_upgrade(project_root, template)
        execute_upgrade(project_root, template, plan)
    except Exception:
        import sys
        sys.stderr.write(
            "\033[33mAuto-upgrade failed. Run 'bpsai-pair upgrade' manually.\033[0m\n"
        )


def maybe_prompt_upgrade(project_root: Path, current_version: str) -> None:
    """Auto-upgrade project on CLI version change.

    Called during CLI startup. When the installed CLI version differs from
    the last-run version AND the project config is stale, runs upgrade
    automatically (no prompt). This ensures `pip install --upgrade bpsai-pair`
    is sufficient — users don't need to remember a second command.
    """
    import sys

    try:
        if not check_upgrade_needed(project_root, current_version):
            save_last_run_version(project_root, current_version)
            return

        # Guard: never downgrade config to a lower version
        config_ver = _get_config_version(project_root)
        if _is_downgrade(current_version, config_ver):
            sys.stderr.write(
                f"\033[33mInstalled bpsai-pair ({current_version}) is older "
                f"than project config ({config_ver}). "
                f"Run: pip install --upgrade bpsai-pair\033[0m\n"
            )
            return

        # Auto-run upgrade — no prompt, works on TTY and non-TTY
        sys.stderr.write(
            f"\033[36mPairCoder upgraded to {current_version} — "
            f"updating project...\033[0m\n"
        )
        _run_upgrade_inline(project_root)
        save_last_run_version(project_root, current_version)
        _stage_upgrade_artifacts(project_root)
    except Exception:
        save_last_run_version(project_root, current_version)


def _stage_upgrade_artifacts(project_root: Path) -> None:
    """Stage .paircoder/ files modified by auto-upgrade so the tree is clean.

    Without this, automated pipelines (engage, task update) see a dirty
    working tree and block. Interactive users are unaffected -- staged files
    just appear in their next commit.
    """
    import subprocess

    patterns = [
        ".paircoder/.cli_version",
        ".paircoder/config.yaml",
        ".paircoder/capabilities.yaml",
    ]
    try:
        subprocess.run(
            ["git", "add", "--"] + patterns,
            cwd=str(project_root),
            capture_output=True, check=False, timeout=5,
        )
    except Exception:
        pass  # Best-effort; don't block CLI startup
