"""PM hierarchy and action subcommands — link, unlink, action.

Extracted from pm_crud.py to keep file sizes under architecture limits.
Commands are registered on the main pm app via ``app.add_typer(hierarchy_app)``.
"""

from __future__ import annotations

import logging
from typing import Optional

import typer
from rich.console import Console
from rich.markup import escape as rich_escape

from ..licensing import require_feature
from ..pm.provider import ProjectManagementProvider
from ..pm.types import PMRelationship, RelationshipType

logger = logging.getLogger(__name__)
console = Console()

hierarchy_app = typer.Typer()


def _get_provider() -> Optional[ProjectManagementProvider]:
    """Get the active PM provider (delegated from pm_helpers)."""
    from .pm_helpers import _get_provider as _pm_get_provider
    return _pm_get_provider()


def _require_provider() -> ProjectManagementProvider:
    """Get provider or exit with error."""
    provider = _get_provider()
    if provider is None:
        console.print("[red]No PM provider configured[/red]")
        raise typer.Exit(1)
    return provider


@hierarchy_app.command("link")
@require_feature("pm_basic")
def pm_link(
    parent_id: str = typer.Argument(..., help="Parent item ID"),
    child_ids: list[str] = typer.Argument(..., help="Child item IDs"),
) -> None:
    """Link child items to a parent (set parent-child relationship)."""
    provider = _require_provider()
    if "hierarchy" not in provider.capabilities():
        console.print("[red]Provider does not support hierarchy[/red]")
        raise typer.Exit(1)
    linked = 0
    failed = 0
    for cid in child_ids:
        rel = PMRelationship(
            source_id=parent_id, target_id=cid,
            relationship_type=RelationshipType.PARENT_CHILD,
        )
        if provider.set_relationship(rel):
            linked += 1
        else:
            failed += 1

    console.print(f"[green]Linked {linked} item(s) to {parent_id}[/green]")
    if failed:
        console.print(f"[yellow]{failed} failed[/yellow]")


@hierarchy_app.command("unlink")
@require_feature("pm_basic")
def pm_unlink(
    child_id: str = typer.Argument(..., help="Child item ID to unlink"),
) -> None:
    """Remove parent relationship from an item."""
    provider = _require_provider()
    if "hierarchy" not in provider.capabilities():
        console.print("[red]Provider does not support hierarchy[/red]")
        raise typer.Exit(1)

    item = provider.find_item(child_id)
    if item is None:
        console.print(f"[red]Item not found: {child_id}[/red]")
        raise typer.Exit(1)

    if not item.parent_id:
        console.print(f"[yellow]{child_id} has no parent[/yellow]")
        return

    rel = PMRelationship(
        source_id=item.parent_id, target_id=child_id,
        relationship_type=RelationshipType.PARENT_CHILD,
    )
    ok = provider.remove_relationship(rel)
    if not ok:
        console.print(f"[red]Failed to unlink {child_id} from {item.parent_id}[/red]")
        raise typer.Exit(1)
    console.print(f"[green]Unlinked {child_id} from {item.parent_id}[/green]")


@hierarchy_app.command("action")
@require_feature("pm_basic")
def pm_action(
    action_name: str = typer.Argument(..., help="Button action name from workflow config"),
    item_id: str = typer.Argument(..., help="Work item ID"),
) -> None:
    """Execute a button action on a work item."""
    from .pm_helpers import _load_raw_config
    from .pm_diagnostics import _load_workflow_config
    from ..pm.actions import ButtonActionExecutor
    from ..pm.engine import WorkflowEngine

    provider = _require_provider()
    raw_config = _load_raw_config()
    workflow = _load_workflow_config(raw_config)
    engine = WorkflowEngine(workflow)

    executor = ButtonActionExecutor(provider, engine)
    actions = engine.get_button_actions()
    if action_name not in actions:
        available = ", ".join(sorted(actions.keys())) or "(none)"
        console.print(f"[red]Unknown action: {rich_escape(action_name)}. Available: {available}[/red]")
        raise typer.Exit(1)

    ok = executor.execute(action_name, item_id)
    if not ok:
        console.print(f"[red]Action '{rich_escape(action_name)}' failed on {item_id}[/red]")
        raise typer.Exit(1)
    console.print(f"[green]Action '{rich_escape(action_name)}' executed on {item_id}[/green]")
