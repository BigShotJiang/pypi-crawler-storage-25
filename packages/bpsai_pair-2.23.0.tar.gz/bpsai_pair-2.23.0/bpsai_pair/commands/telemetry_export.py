"""Helper functions for telemetry export command.

This module contains export formatters and anonymization logic
to maintain architecture compliance (max 15 functions per file).
"""

from __future__ import annotations

import csv
import hashlib
import io
import json
from datetime import datetime
from typing import Any

from ..telemetry.schema import TelemetryRecord


def anonymize_record(record: dict[str, Any], repo_map: dict[str, str]) -> dict[str, Any]:
    """Anonymize a telemetry record by replacing identifying information.

    Args:
        record: Record dictionary to anonymize
        repo_map: Mapping of real repo names to anonymous identifiers

    Returns:
        Anonymized record dictionary
    """
    anon = record.copy()

    # Hash the task_id
    if "task_id" in anon:
        task_hash = hashlib.sha256(anon["task_id"].encode()).hexdigest()[:8]
        anon["task_id"] = f"task_{task_hash}"

    # Replace repo with anonymous identifier
    if "repo" in anon:
        repo_name = anon["repo"]
        if repo_name not in repo_map:
            repo_map[repo_name] = f"repo_{len(repo_map) + 1}"
        anon["repo"] = repo_map[repo_name]

    return anon


def format_records_json(records: list[TelemetryRecord], anonymize: bool = False) -> str:
    """Format records as pretty-printed JSON array.

    Args:
        records: List of telemetry records
        anonymize: Whether to anonymize identifying information

    Returns:
        JSON string
    """
    repo_map: dict[str, str] = {}
    data = []
    for record in records:
        record_dict = json.loads(record.to_json())
        if anonymize:
            record_dict = anonymize_record(record_dict, repo_map)
        data.append(record_dict)
    return json.dumps(data, indent=2)


def format_records_jsonl(records: list[TelemetryRecord], anonymize: bool = False) -> str:
    """Format records as JSONL (one JSON object per line).

    Args:
        records: List of telemetry records
        anonymize: Whether to anonymize identifying information

    Returns:
        JSONL string
    """
    repo_map: dict[str, str] = {}
    lines = []
    for record in records:
        record_dict = json.loads(record.to_json())
        if anonymize:
            record_dict = anonymize_record(record_dict, repo_map)
        lines.append(json.dumps(record_dict))
    return "\n".join(lines)


def format_records_csv(records: list[TelemetryRecord], anonymize: bool = False) -> str:
    """Format records as CSV with headers.

    Args:
        records: List of telemetry records
        anonymize: Whether to anonymize identifying information

    Returns:
        CSV string with headers
    """
    if not records:
        return ""

    repo_map: dict[str, str] = {}
    output = io.StringIO()

    # Get all fields from first record
    first_dict = json.loads(records[0].to_json())

    # Flatten tokens into separate columns
    fieldnames = []
    for key in first_dict:
        if key == "tokens":
            fieldnames.extend(["tokens_input", "tokens_output", "tokens_total"])
        else:
            fieldnames.append(key)

    writer = csv.DictWriter(output, fieldnames=fieldnames)
    writer.writeheader()

    for record in records:
        record_dict = json.loads(record.to_json())
        if anonymize:
            record_dict = anonymize_record(record_dict, repo_map)

        # Flatten tokens
        row = {}
        for key, value in record_dict.items():
            if key == "tokens":
                row["tokens_input"] = value.get("input", 0)
                row["tokens_output"] = value.get("output", 0)
                row["tokens_total"] = value.get("input", 0) + value.get("output", 0)
            else:
                row[key] = value
        writer.writerow(row)

    return output.getvalue()


def parse_date(date_str: str) -> datetime:
    """Parse a date string in YYYY-MM-DD format.

    Args:
        date_str: Date string to parse

    Returns:
        datetime object with UTC timezone for comparison
    """
    from datetime import timezone
    dt = datetime.strptime(date_str, "%Y-%m-%d")
    return dt.replace(tzinfo=timezone.utc)
