"""Resume helpers for engage --resume flag (EI.1).

Reads task file statuses from disk to determine which tasks
are already completed and can be skipped on a resumed run.
"""

from __future__ import annotations

import logging
import re
from pathlib import Path

import typer
import yaml

logger = logging.getLogger(__name__)


def _read_task_status(project_root: Path, task_id: str) -> str:
    """Read a task's status from its .task.md frontmatter.

    Returns the status string, or 'pending' if the file is missing
    or has no parseable frontmatter.
    """
    task_file = project_root / ".paircoder" / "tasks" / f"{task_id}.task.md"
    if not task_file.exists():
        return "pending"
    text = task_file.read_text(encoding="utf-8")
    match = re.match(r"^---\s*\n(.*?)\n---", text, re.DOTALL)
    if not match:
        return "pending"
    try:
        meta = yaml.safe_load(match.group(1)) or {}
    except yaml.YAMLError:
        return "pending"
    return meta.get("status", "pending")


def read_task_statuses(
    project_root: Path, task_ids: list[str],
) -> tuple[list[str], list[str]]:
    """Partition tasks into done vs remaining based on disk status.

    Returns (done_ids, remaining_ids) preserving input order.
    """
    done: list[str] = []
    remaining: list[str] = []
    for tid in task_ids:
        status = _read_task_status(project_root, tid)
        if status == "done":
            done.append(tid)
        else:
            remaining.append(tid)
    return done, remaining


def show_resume_summary(skip_count: int, run_count: int) -> None:
    """Print the resume pre-execution summary."""
    typer.echo(
        f"Skipping {skip_count} completed, running {run_count} remaining",
    )
