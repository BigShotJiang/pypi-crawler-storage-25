"""bpsai-pair engage -- autonomous sprint execution command."""
from __future__ import annotations

import json
import logging
import subprocess
from pathlib import Path
from typing import Any

import typer

from bpsai_pair.commands.engage_branch import (  # noqa: F401
    _checkout_branch,
    _cleanup_orphan_branch,
    _create_feature_branch,
    _validate_branch_name,
)
from bpsai_pair.commands.engage_guards import (  # noqa: F401
    _check_protected_branch,
    _derive_branch_slug,
    _dispatch_review_agents,
    _emit_sprint_observation,
    _enforce_engage_gate,
    _get_protected_branches,
    _run_containment_audit_display,
    _sanitize_pr_url,
    _validate_backlog_path,
    _validate_task_id,
)
from bpsai_pair.commands.engage_pr import (  # noqa: F401
    _build_pr_body,
    _create_pull_request,
    infer_sprint as _infer_sprint,
    show_dry_run as _show_dry_run,
)
from bpsai_pair.commands.engage_security import (  # noqa: F401
    _pre_pr_security_check,
    emit_security_telemetry as _emit_security_telemetry,
    maybe_cross_module_review,
)
from bpsai_pair.core.utils import repo_root
from bpsai_pair.orchestration.backlog_parser import BacklogParser
from bpsai_pair.orchestration.backlog_materializer import materialize
from bpsai_pair.orchestration.engage_run_state import (
    load_run_state, save_pause_state, verify_paused_task_done,
)
from bpsai_pair.orchestration.headless import (
    HeadlessSession, HEADLESS_ALLOWED_TOOLS, NAVIGATOR_ALLOWED_TOOLS,
)

logger = logging.getLogger(__name__)


def _validate_engage_args(
    backlog: str, create_branch: bool, branch: str,
) -> Path:
    """Validate engage CLI arguments and return the backlog Path."""
    if create_branch and branch:
        typer.echo(
            "Error: --create-branch and --branch are mutually exclusive.",
            err=True,
        )
        raise typer.Exit(1)
    if not backlog:
        typer.echo("Error: BACKLOG argument is required (or use --resume).", err=True)
        raise typer.Exit(1)
    backlog_path = Path(backlog)
    if not backlog_path.exists():
        typer.echo(f"Error: Backlog file not found: {backlog}", err=True)
        raise typer.Exit(1)
    return backlog_path


def engage(
    backlog: str = typer.Argument("", help="Path to backlog markdown file"),
    sprint: str = typer.Option("", "--sprint", "-s", help="Sprint number"),
    dry_run: bool = typer.Option(False, "--dry-run", help="Show plan without executing"),
    json_out: bool = typer.Option(False, "--json", help="JSON output"),
    max_parallel: int = typer.Option(3, "--max-parallel", help="Max parallel tasks"),
    skip_planning: bool = typer.Option(False, "--skip-planning", help="Skip /pc-plan"),
    hooks_advisory: bool = typer.Option(False, "--hooks-advisory", help="Hook failures as warnings"),
    resume: bool = typer.Option(False, "--resume", help="Skip done tasks, re-run rest"),
    resume_run: str = typer.Option("", "--resume-run", help="Resume paused run by run-id"),
    create_branch: bool = typer.Option(False, "--create-branch", help="Branch from slug"),
    branch: str = typer.Option("", "--branch", help="Explicit branch name"),
) -> None:
    """Parse a backlog and autonomously execute the sprint."""
    if resume_run:
        return _output_result(_resume_engage(resume_run), json_out)
    backlog_path = _validate_engage_args(backlog, create_branch, branch)
    parsed = BacklogParser.parse(backlog_path)
    if not parsed.tasks:
        typer.echo("No tasks found in backlog.")
        raise typer.Exit(1)
    if dry_run:
        project_root = repo_root()
        _run_containment_audit_display(parsed.tasks, project_root)
        return _show_dry_run(parsed, json_out)
    if not sprint:
        sprint = _infer_sprint(parsed)
    result = _run_engage(
        backlog_path, parsed, sprint, max_parallel, skip_planning,
        hooks_advisory=hooks_advisory, create_branch=create_branch,
        branch=branch or "", resume=resume,
    )
    _output_result(result, json_out)


def _output_result(result: dict[str, Any], json_out: bool) -> None:
    """Render result as JSON or human-readable text."""
    if json_out:
        typer.echo(json.dumps(result, indent=2))
    else:
        _show_result(result)


def _dispatch_navigator(backlog_path: Path, project_root: Path) -> bool:
    """Dispatch a Navigator session running /pc-plan with the backlog."""
    try:
        safe_path = _validate_backlog_path(backlog_path)
        session = HeadlessSession(
            permission_mode="auto", allowed_tools=NAVIGATOR_ALLOWED_TOOLS,
            working_dir=project_root,
        )
        response = session.invoke(f"/pc-plan {safe_path}")
        if response.is_error:
            logger.warning("Navigator /pc-plan failed: %s", response.error_message)
            return False
        return True
    except Exception:
        logger.warning("Navigator dispatch raised exception", exc_info=True)
        return False


def _execute_sprint(
    project_root: Path, plan_id: str, max_parallel: int,
    hooks_advisory: bool = False,
    completed_tasks: list[str] | None = None,
) -> Any:
    """Build plan graph and execute tasks via headless runner."""
    from bpsai_pair.orchestration.sprint_executor import (
        SprintConfig, SprintExecutor, make_default_task_hook,
    )
    from bpsai_pair.orchestration.plan_graph import PlanGraphBuilder
    from bpsai_pair.orchestration.headless_runner import _make_headless_runner

    graph = PlanGraphBuilder(project_root).build(plan_id)
    for tid in completed_tasks or []:
        graph.mark_done(tid)
    config = SprintConfig(max_parallel=max_parallel, hooks_advisory=hooks_advisory)
    task_runner = _make_headless_runner(
        project_root, permission_mode="auto",
        allowed_tools=HEADLESS_ALLOWED_TOOLS, approved_by="engage-cli",
        sprint_config=config,
    )
    task_hook = make_default_task_hook(project_root)
    return SprintExecutor(
        project_root, graph, config,
        task_runner=task_runner, task_complete_hook=task_hook,
    ).execute()


def _result_dict(result: Any, **extra: Any) -> dict[str, Any]:
    """Build a standard result dict from a SprintResult."""
    out: dict[str, Any] = {
        "completed": result.completed_tasks, "failed": result.failed_tasks,
        "hook_failed": result.hook_failed_tasks,
        "blocked": result.blocked_tasks, "phases_completed": result.phases_completed,
        "pr_url": None, "review": None,
    }
    out.update(extra)
    return out


def _setup_branch(
    project_root: Path, backlog_path: Path,
    create_branch: bool, branch: str,
) -> tuple[str, bool, str]:
    """Resolve the working branch. Returns (active_branch, auto_created, parent)."""
    if create_branch or branch:
        if branch:
            _validate_branch_name(branch)
        cur = subprocess.run(
            ["git", "branch", "--show-current"],
            cwd=project_root, capture_output=True, text=True, check=False,
        )
        parent = cur.stdout.strip()
        if branch:
            return _checkout_branch(project_root, branch), True, parent
        slug = _derive_branch_slug(str(backlog_path))
        return _checkout_branch(project_root, slug), True, parent
    _check_protected_branch(project_root)
    return _create_feature_branch(project_root, str(backlog_path)), False, ""


def _resolve_completed_tasks(
    project_root: Path, parsed: Any, resume: bool,
) -> list[str] | None:
    """When resume=True, read disk status and return done task IDs."""
    if not resume:
        return None
    from bpsai_pair.commands.engage_resume import read_task_statuses, show_resume_summary
    task_ids = [t.id for t in parsed.tasks]
    done, remaining = read_task_statuses(project_root, task_ids)
    show_resume_summary(len(done), len(remaining))
    return done


def _run_engage(
    backlog_path: Path, parsed: Any, sprint: str,
    max_parallel: int, skip_planning: bool = False,
    hooks_advisory: bool = False,
    create_branch: bool = False,
    branch: str = "",
    resume: bool = False,
) -> dict[str, Any]:
    """Execute the full engage pipeline."""
    project_root = repo_root()
    _enforce_engage_gate(project_root)
    _run_containment_audit_display(parsed.tasks, project_root)
    active_branch, auto_created, parent = _setup_branch(
        project_root, backlog_path, create_branch, branch,
    )

    try:
        if not skip_planning:
            if not _dispatch_navigator(backlog_path, project_root):
                logger.info("Navigator failed, falling back to materialize()")

        plan_path = materialize(project_root, parsed, sprint)
        plan_id = plan_path.stem.replace(".plan", "")
        completed = _resolve_completed_tasks(project_root, parsed, resume)
        result = _execute_sprint(
            project_root, plan_id, max_parallel, hooks_advisory,
            completed_tasks=completed,
        )

        if result.paused_task:
            return _handle_pause(
                project_root, plan_id, sprint, result,
                max_parallel, hooks_advisory, auto_created,
                parent, backlog_path, active_branch,
            )

        return _finalize_sprint(
            project_root, backlog_path, result, sprint, active_branch,
            skip_pr_if_exists=resume,
        )
    except Exception:
        if auto_created:
            _cleanup_orphan_branch(project_root, active_branch, parent)
        raise


def _handle_pause(
    project_root: Path, plan_id: str, sprint: str,
    result: Any, max_parallel: int, hooks_advisory: bool,
    auto_created: bool, parent: str,
    backlog_path: Path, active_branch: str,
) -> dict[str, Any]:
    """Save pause state and return result dict."""
    run_id = save_pause_state(
        project_root, plan_id, sprint,
        result.completed_tasks, result.paused_task,
        max_parallel, hooks_advisory,
        branch_auto_created=auto_created, parent_branch=parent,
        backlog_path=str(backlog_path), active_branch=active_branch,
    )
    return _result_dict(result, paused_task=result.paused_task, run_id=run_id)


def _finalize_sprint(
    project_root: Path, backlog_path: Path,
    result: Any, sprint: str,
    active_branch: str = "",
    skip_pr_if_exists: bool = False,
) -> dict[str, Any]:
    """Post-sprint: security check, PR, review, observation."""
    security_result = _pre_pr_security_check(project_root)
    _emit_security_telemetry(project_root, security_result)
    if security_result.get("blocked"):
        _emit_sprint_observation(project_root, result, None)
        return _result_dict(
            result, security_blocked=True,
            security_findings=security_result.get("findings", ""),
        )

    cross_module_result = maybe_cross_module_review(project_root)
    branch = active_branch or f"engage/{backlog_path.stem}"
    pr_url = _create_pull_request(
        project_root, branch, result, sprint,
        skip_if_exists=skip_pr_if_exists,
    )
    _emit_sprint_observation(project_root, result, pr_url)
    review_result = _dispatch_review_agents(project_root, pr_url) if pr_url else None
    out = _result_dict(result, pr_url=pr_url, review=review_result)
    if cross_module_result is not None:
        out["cross_module_review"] = cross_module_result
    return out


def _resume_engage(run_id: str) -> dict[str, Any]:
    """Resume a paused engage run."""
    project_root = repo_root()
    state = load_run_state(project_root, run_id)
    verify_paused_task_done(project_root, state)

    result = _execute_sprint(
        project_root, state.plan_id, state.max_parallel,
        hooks_advisory=state.hooks_advisory,
        completed_tasks=state.completed_tasks + [state.paused_task_id],
    )

    if result.paused_task:
        new_run_id = save_pause_state(
            project_root, state.plan_id, state.sprint,
            result.completed_tasks, result.paused_task,
            state.max_parallel, state.hooks_advisory,
            branch_auto_created=state.branch_auto_created,
            parent_branch=state.parent_branch,
            backlog_path=state.backlog_path,
            active_branch=state.active_branch,
        )
        return _result_dict(
            result, paused_task=result.paused_task, run_id=new_run_id,
        )

    backlog_path = Path(state.backlog_path) if state.backlog_path else None
    active_branch = state.active_branch or ""
    if backlog_path:
        return _finalize_sprint(
            project_root, backlog_path, result, state.sprint, active_branch,
        )
    return _result_dict(result)


def _show_result(result: dict[str, Any]) -> None:
    """Display engage result to terminal."""
    if result.get("paused_task"):
        _show_pause_prompt(result)
        return

    done, failed = len(result["completed"]), len(result["failed"])
    hook_failed = len(result.get("hook_failed", []))
    blocked = len(result["blocked"])
    typer.echo(
        f"Sprint complete: {done} done, {failed} failed, "
        f"{hook_failed} hook-failed, {blocked} blocked",
    )
    if result.get("security_blocked"):
        typer.echo("PR blocked by security audit -- see findings above")
    if result.get("pr_url"):
        typer.echo(f"PR: {result['pr_url']}")


def _show_pause_prompt(result: dict[str, Any]) -> None:
    """Display the human-gate pause prompt."""
    task_id = result["paused_task"]
    run_id = result.get("run_id", "")
    done = len(result.get("completed", []))
    typer.echo(f"\nPAUSED: Task {task_id} requires human intervention")
    typer.echo(f"Completed so far: {done} task(s)")
    typer.echo("")
    typer.echo("To resume after completing the task:")
    typer.echo(f"  1. Complete the work described in the task file")
    typer.echo(f"  2. bpsai-pair task update {task_id} --status done")
    typer.echo(f"  3. bpsai-pair engage --resume-run {run_id}")
