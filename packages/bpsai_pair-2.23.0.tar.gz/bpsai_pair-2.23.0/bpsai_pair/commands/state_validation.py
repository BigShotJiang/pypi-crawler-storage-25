"""Task state validation helpers.

Extracted from state.py for arch compliance. Contains validation logic
used by enforcement hooks and the validate CLI command.
"""
import re
from pathlib import Path
from typing import Any, Dict, List, Set


def find_paircoder_dir() -> Path:
    """Find .paircoder directory."""
    from ..core.ops import find_paircoder_dir as _find
    return _find()


def extract_done_tasks_from_state_md(content: str) -> Set[str]:
    """Extract task IDs that are marked as done in state.md content.

    Uses a two-pass strategy to be format-agnostic while avoiding
    false positives on plain English words:

    1. Legacy pattern matches known formats (TASK-\d+, T\d+.\d+, etc.)
    2. Positional heuristics match identifiers in structured positions
       (table cells, before ``:``, bold markers, after ``~~``)
    """
    done_tasks: Set[str] = set()

    from ..core.constants import TASK_ID_PATTERN_LEGACY
    legacy_pattern = r'\b' + TASK_ID_PATTERN_LEGACY + r'\b'

    for line in content.split('\n'):
        if not _line_is_done(line):
            continue

        # Pass 1: legacy pattern (high-confidence, known formats)
        task_ids = re.findall(legacy_pattern, line, re.IGNORECASE)

        # Pass 2: positional heuristics for arbitrary IDs
        task_ids.extend(_extract_positional_ids(line))

        if task_ids:
            done_tasks.update(task_ids)

    return done_tasks


def _line_is_done(line: str) -> bool:
    """Check if a line indicates a done/completed task."""
    line_lower = line.lower()
    return any([
        '\u2713' in line and ('done' in line_lower or 'complete' in line_lower),
        '~~' in line and ('done' in line_lower or '\u2713' in line),
        re.search(r'\|\s*\u2713\s*done\s*\|', line_lower),
        re.search(r'\|\s*done\s*\|', line_lower),
        re.search(r'\[done\]', line_lower),
        re.search(r'\[completed\]', line_lower),
        re.search(r'\|\s*\u2713\s*done', line_lower),
    ])


# Identifier characters allowed in task IDs (permissive)
_ID_CHARS = r'[A-Za-z0-9#][A-Za-z0-9._#-]*'

# Positional patterns where a task ID is likely to appear
_POSITIONAL_PATTERNS = [
    # Table cell first column: | ID | ...
    # NOTE: could match table headers (e.g. "| Status |") if the line
    # also passes _line_is_done().  The done-check guard mitigates most
    # cases; a minimum-length or header-row filter could be added later.
    re.compile(rf'^\|\s*({_ID_CHARS})\s*\|'),
    # Before colon: ID: description (with optional bullet and strikethrough)
    re.compile(rf'^\s*[-*]?\s*(?:~~)?\s*\**({_ID_CHARS})\**\s*:'),
    # Bold task ID: **ID** ...
    re.compile(rf'\*\*({_ID_CHARS})\*\*'),
]


def _extract_positional_ids(line: str) -> List[str]:
    """Extract task IDs from structured positions in a line.

    Filters through is_valid_task_id to reject plain words like
    table headers (Status, Task, ID).
    """
    from ..core.constants import is_valid_task_id

    ids: List[str] = []
    for pattern in _POSITIONAL_PATTERNS:
        match = pattern.search(line)
        if match and is_valid_task_id(match.group(1)):
            ids.append(match.group(1))
    return ids


def is_trello_enabled(paircoder_dir: Path) -> bool:
    """Check if Trello integration is enabled."""
    import yaml
    config_path = paircoder_dir / "config.yaml"
    if not config_path.exists():
        return False
    try:
        with open(config_path, encoding='utf-8') as f:
            config = yaml.safe_load(f) or {}
        return config.get("trello", {}).get("enabled", False)
    except Exception:
        return False


def get_trello_card_status(task_id: str) -> Dict[str, Any]:
    """Get Trello card status for a task.

    Returns:
        Dict with: found, list_name, ac_total, ac_checked, card_id
    """
    try:
        from ..trello.task_commands import get_board_client

        client, config = get_board_client()
        card, lst = client.find_card_with_prefix(task_id)

        if not card:
            return {"found": False}

        ac_total = 0
        ac_checked = 0

        try:
            checklists = client.get_card_checklists(card)
            for checklist in checklists:
                if "acceptance" in checklist.get("name", "").lower():
                    items = checklist.get("checkItems", [])
                    ac_total += len(items)
                    ac_checked += sum(1 for item in items if item.get("state") == "complete")
        except Exception:
            pass

        return {
            "found": True,
            "list_name": lst.name if lst else "",
            "ac_total": ac_total,
            "ac_checked": ac_checked,
            "card_id": getattr(card, 'short_id', getattr(card, 'id', '')),
        }
    except Exception as e:
        return {"found": False, "error": str(e)}


def parse_acceptance_criteria_from_body(body: str) -> List[Dict[str, Any]]:
    """Parse acceptance criteria checkboxes from task markdown body.

    Looks for checkbox patterns like:
    - [ ] Unchecked item
    - [x] Checked item
    """
    ac_items = []

    for line in body.split('\n'):
        stripped = line.strip()

        if stripped.startswith('- [x]') or stripped.startswith('- [X]'):
            item_text = re.sub(r'^- \[[xX]\]\s*', '', stripped)
            ac_items.append({'text': item_text, 'checked': True})
        elif stripped.startswith('- [ ]'):
            item_text = re.sub(r'^- \[ \]\s*', '', stripped)
            ac_items.append({'text': item_text, 'checked': False})

    return ac_items


def validate_task_completion_local(task_id: str, paircoder_dir: Path) -> Dict[str, Any]:
    """Fast local-only validation for hooks. Must complete in <100ms.

    NO network calls. NO Trello API. Just local file checks.
    """
    from ..planning.parser import TaskParser

    errors = []
    local_status = None
    has_source = False

    try:
        task_parser = TaskParser(paircoder_dir / "tasks")
        task = task_parser.get_task_by_id(task_id)

        if task:
            has_source = True
            local_status = task.status.value if hasattr(task.status, 'value') else str(task.status)

            if local_status != "done":
                errors.append(f"Local task file shows status: {local_status} (expected: done)")

            body = getattr(task, 'body', '') or ''
            ac_items = parse_acceptance_criteria_from_body(body)
            if ac_items:
                unchecked = [item for item in ac_items if not item.get('checked', False)]
                if unchecked:
                    errors.append(f"Local task has {len(unchecked)} unchecked AC items")
    except Exception:
        pass

    return {
        "valid": len(errors) == 0,
        "errors": errors,
        "local_status": local_status,
        "has_source": has_source,
    }


def validate_task_completion_full(task_id: str, paircoder_dir: Path) -> Dict[str, Any]:
    """Full validation including Trello. Can be slow (network calls)."""
    # Lazy import so test mocks on bpsai_pair.commands.state.* work
    from . import state as _state_mod

    local_result = validate_task_completion_local(task_id, paircoder_dir)
    errors = list(local_result["errors"])
    local_status = local_result["local_status"]
    has_source = local_result["has_source"]
    trello_status = None

    if _state_mod.is_trello_enabled(paircoder_dir):
        trello_result = _state_mod.get_trello_card_status(task_id)
        trello_status = trello_result

        if trello_result.get("found"):
            has_source = True
            list_name = trello_result.get("list_name", "")

            done_lists = ["done", "deployed", "complete", "deployed/done"]
            is_in_done = any(done in list_name.lower() for done in done_lists)

            if not is_in_done:
                errors.append(f"Trello card is in '{list_name}' (expected: Done list)")

            ac_total = trello_result.get("ac_total", 0)
            ac_checked = trello_result.get("ac_checked", 0)

            if ac_total > 0 and ac_checked < ac_total:
                errors.append(f"Trello card has {ac_checked}/{ac_total} AC items checked")

    if not has_source:
        errors.append(f"No source of truth found for {task_id} (no local task file, no Trello card)")

    return {
        "valid": len(errors) == 0,
        "errors": errors,
        "local_status": local_status,
        "trello_status": trello_status,
    }


def validate_task_completion(
    task_id: str, paircoder_dir: Path, include_trello: bool = False
) -> Dict[str, Any]:
    """Validate that a task marked as done in state.md is actually complete.

    By default, only performs fast local validation (no network calls).
    Use include_trello=True for full validation including Trello API calls.
    """
    if include_trello:
        return validate_task_completion_full(task_id, paircoder_dir)
    else:
        result = validate_task_completion_local(task_id, paircoder_dir)
        result["trello_status"] = None
        return result
