"""Branch management helpers for engage command.

Extracted from engage.py to keep file size within limits.
"""
from __future__ import annotations

import logging
import re
import subprocess
from pathlib import Path

import typer

from bpsai_pair.commands.engage_guards import (
    _check_protected_branch,
    _derive_branch_slug,
)

logger = logging.getLogger(__name__)

_BRANCH_NAME_RE = re.compile(r"^[A-Za-z0-9/_.-]+$")


def _validate_branch_name(name: str) -> None:
    """Validate a branch name for safe use in git commands."""
    if not name or not _BRANCH_NAME_RE.match(name) or name.startswith("-"):
        raise ValueError(
            f"Branch name contains invalid characters: {name!r}. "
            "Only A-Z, a-z, 0-9, '/', '_', '.', '-' are allowed "
            "and it must not start with '-'.",
        )


def _checkout_branch(project_root: Path, branch: str) -> str:
    """Create and checkout *branch*, falling back to plain checkout."""
    result = subprocess.run(
        ["git", "checkout", "-b", branch],
        cwd=project_root, capture_output=True, check=False,
        encoding="utf-8", errors="replace",
    )
    if result.returncode != 0:
        fallback = subprocess.run(
            ["git", "checkout", branch],
            cwd=project_root, capture_output=True, check=False,
            encoding="utf-8", errors="replace",
        )
        if fallback.returncode != 0:
            typer.echo(f"Error: Failed to checkout branch '{branch}'.", err=True)
            raise typer.Exit(1)
    return branch


def _create_feature_branch(project_root: Path, backlog_name: str) -> str:
    """Create an engage feature branch from the backlog filename."""
    stem = Path(backlog_name).stem
    branch = f"engage/{stem}"
    return _checkout_branch(project_root, branch)


def _cleanup_orphan_branch(
    project_root: Path, branch: str, parent_branch: str,
) -> None:
    """Delete an engage-created branch if it has zero commits ahead of parent.

    Safe: if checkout back to parent fails, the branch is left in place
    and a warning is logged rather than creating a dangling state.
    """
    ahead = subprocess.run(
        ["git", "rev-list", "--count", f"{parent_branch}..{branch}"],
        cwd=project_root, capture_output=True, text=True, check=False,
    )
    if ahead.returncode != 0 or int(ahead.stdout.strip() or "1") > 0:
        return

    checkout = subprocess.run(
        ["git", "checkout", parent_branch],
        cwd=project_root, capture_output=True, check=False,
    )
    if checkout.returncode != 0:
        logger.warning(
            "Cannot checkout parent branch '%s' — leaving '%s' in place",
            parent_branch, branch,
        )
        return

    subprocess.run(
        ["git", "branch", "-d", branch],
        cwd=project_root, capture_output=True, check=False,
    )
    logger.info("Deleted orphan engage branch '%s'", branch)
