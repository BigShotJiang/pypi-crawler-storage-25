"""Session check command: detect new sessions and display context."""
from __future__ import annotations

from pathlib import Path
from typing import Optional

import typer
from rich.console import Console

try:
    from ..core import ops
except ImportError:
    from bpsai_pair.core import ops

console = Console()

app = typer.Typer(
    help="Session management and context reload",
    context_settings={"help_option_names": ["-h", "--help"]}
)


def repo_root() -> Path:
    """Get repo root with better error message."""
    p = ops.find_project_root()
    if not ops.GitOps.is_repo(p):
        console.print(
            "[red]x Not in a git repository.[/red]\n"
            "Please run from your project root directory (where .git exists).\n"
            "[dim]Hint: cd to your project directory first[/dim]"
        )
        raise typer.Exit(1)
    return p


def _get_current_task_id(paircoder_dir: Path) -> Optional[str]:
    """Get the current in-progress task ID (most recently modified)."""
    tasks_dir = paircoder_dir / "tasks"
    if not tasks_dir.exists():
        return None

    active: list[tuple[float, str]] = []
    for task_file in sorted(
        tasks_dir.glob("*.task.md"),
        key=lambda p: p.stat().st_mtime,
        reverse=True,
    ):
        try:
            content = task_file.read_text(encoding="utf-8")
            if "status: in_progress" in content:
                for line in content.split('\n'):
                    if line.startswith('id:'):
                        tid = line.split(':', 1)[1].strip()
                        active.append((task_file.stat().st_mtime, tid))
                        break
        except Exception:
            pass

    if not active:
        return None
    newest_id = active[0][1]
    extra = len(active) - 1
    return f"{newest_id} +{extra}" if extra else newest_id


VALID_ROLES = ("nav", "drv", "rev")


@app.command("set-role")
def session_set_role(
    role: str = typer.Argument(..., help="Role: nav (navigator), drv (driver), rev (reviewer)"),
):
    """Set the active agent role for status line display."""
    if role not in VALID_ROLES:
        console.print(f"[red]Invalid role: {role}. Must be one of: {', '.join(VALID_ROLES)}[/red]")
        raise typer.Exit(1)

    try:
        root = repo_root()
    except (SystemExit, typer.Exit):
        raise
    except ops.ProjectRootNotFoundError:
        console.print("[red]Not in a PairCoder project. Run from a directory with .paircoder/[/red]")
        raise typer.Exit(1)

    try:
        from ..statusline import write_active_role
    except ImportError:
        from bpsai_pair.statusline import write_active_role

    write_active_role(root, role)
    role_names = {"nav": "Navigator", "drv": "Driver", "rev": "Reviewer"}
    console.print(f"[green]\u2713[/green] Role set to {role_names[role]}")


def _display_handoff_context(paircoder_dir: Path) -> None:
    """Display handoff context from prior agent sessions."""
    try:
        from ..session_handoff import receive_handoffs, format_handoff_summary
    except ImportError:
        from bpsai_pair.session_handoff import receive_handoffs, format_handoff_summary

    handoffs_dir = paircoder_dir / "history" / "handoffs"
    summaries = receive_handoffs(handoffs_dir)
    handoff_output = format_handoff_summary(summaries)
    if handoff_output:
        console.print(f"\n{handoff_output}")


def _show_new_session_context(
    root: Path, paircoder_dir: Path, session_mgr: object
) -> None:
    """Handle new-session display: context, handoffs, state size, auto-compaction."""
    # Trigger auto-compaction on new session (non-blocking)
    try:
        from ..telemetry.auto_compaction import maybe_auto_compact
        maybe_auto_compact(root)
    except Exception:
        pass  # Never block session start

    # Show context
    context = session_mgr.get_context()
    output = session_mgr.format_context_output(context)
    console.print(output)

    # Display handoff context from prior agent sessions
    try:
        _display_handoff_context(paircoder_dir)
    except Exception:
        pass  # Never block session start for handoff errors

    # Check state.md size and emit advisory if bloated
    from ..core.cache_paths import check_state_size
    advisory = check_state_size(paircoder_dir)
    if advisory:
        console.print(f"\n[yellow]\u26a0 {advisory}[/yellow]")

    # Check cache health and emit signal if degraded
    try:
        from ..telemetry.cache_health import find_active_session, run_cache_health_check
        session_file = find_active_session(str(root))
        if session_file:
            run_cache_health_check(root, session_file)
    except Exception:
        pass  # Never block session start for cache health errors


def _run_session_check(root: Path, paircoder_dir: Path, force: bool) -> None:
    """Core logic: compaction recovery or new-session context display."""
    try:
        from ..session import SessionManager
        from ..compaction import CompactionManager
    except ImportError:
        from bpsai_pair.session import SessionManager
        from bpsai_pair.compaction import CompactionManager

    compaction_mgr = CompactionManager(paircoder_dir)
    compaction_marker = compaction_mgr.check_compaction()

    if compaction_marker:
        output = compaction_mgr.recover_context()
        console.print(output)
        return

    session_mgr = SessionManager(paircoder_dir)
    session = session_mgr.check_session()

    if session.is_new or force:
        _show_new_session_context(root, paircoder_dir, session_mgr)


@app.command("check")
def session_check(
    force: bool = typer.Option(False, "--force", "-f", help="Force context display even if continuing session"),
    quiet: bool = typer.Option(False, "--quiet", "-q", help="Suppress errors and always exit 0 (for hooks)"),
):
    """Check session state and display context if new session.

    Detects new sessions (>30 min gap), displays context from state.md,
    and checks for compaction recovery. Use --quiet for hook compatibility.
    """
    if quiet:
        # Quiet mode: suppress all output and always exit 0 (for hooks)
        return

    try:
        root = repo_root()
    except (SystemExit, typer.Exit, ops.ProjectRootNotFoundError):
        raise

    paircoder_dir = root / ".paircoder"
    if not paircoder_dir.exists():
        return

    _run_session_check(root, paircoder_dir, force)
