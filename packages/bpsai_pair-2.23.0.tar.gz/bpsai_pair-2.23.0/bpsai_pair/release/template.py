"""Template CLI commands for PairCoder.

Provides commands for cookiecutter template management including
drift detection, listing, and auto-sync.

Extracted from planning/cli_commands.py as part of EPIC-003 Phase 2.
"""

from __future__ import annotations

import re
from pathlib import Path
from typing import Literal

import typer
from rich.console import Console

# Import shared helper from release commands
from .commands import get_template_path, find_paircoder_dir
from ..core.ops import ProjectRootNotFoundError

console = Console()

app = typer.Typer(
    help="Cookiecutter template management commands",
    context_settings={"help_option_names": ["-h", "--help"]}
)

# Minimal required template files with their check modes
# Mode: "content" = full content comparison (with cookiecutter var normalization)
#       "exists" = just check file exists in both locations
#       "version" = check only version field matches (for yaml files)
REQUIRED_TEMPLATE_FILES: list[tuple[str, Literal["content", "exists", "version"]]] = [
    # Core project files - existence check (project will customize)
    (".gitignore", "exists"),
    (".agentpackignore", "exists"),
    # NOTE: README.md excluded — repo README differs from generated project README.
    # NOTE: .paircoder/config.yaml excluded — generated dynamically by presets/wizard.
    # CLAUDE.md - existence check (projects customize with specific rules)
    ("CLAUDE.md", "exists"),
    # Config files - exists only (template uses __VERSION__ placeholder for init injection)
    (".paircoder/capabilities.yaml", "exists"),
    # PairCoder context files - existence check (project-specific content)
    (".paircoder/context/state.md", "exists"),
    (".paircoder/context/project.md", "exists"),
    (".paircoder/context/workflow.md", "exists"),  # Source has dogfood paths
    # Claude settings
    (".claude/settings.json", "content"),
    # Skills - existence check only (project may customize)
    (".claude/skills/designing-and-implementing/SKILL.md", "exists"),
    (".claude/skills/implementing-with-tdd/SKILL.md", "exists"),
    (".claude/skills/reviewing-code/SKILL.md", "exists"),
    (".claude/skills/finishing-branches/SKILL.md", "exists"),
    (".claude/skills/creating-skills/SKILL.md", "exists"),
    (".claude/skills/architecting-modules/SKILL.md", "exists"),
    (".claude/skills/managing-task-lifecycle/SKILL.md", "exists"),
    (".claude/skills/planning-with-trello/SKILL.md", "exists"),
    (".claude/skills/auditing-sibling-projects/SKILL.md", "exists"),
    (".claude/skills/releasing-versions/SKILL.md", "exists"),
    # Skill auxiliary files - existence check
    (".claude/skills/managing-task-lifecycle/reference/all-cli-commands.md", "exists"),
    (".claude/skills/managing-task-lifecycle/reference/bps-trello-conventions.md", "exists"),
    (".claude/skills/managing-task-lifecycle/scripts/check_completion.py", "exists"),
    (".claude/skills/managing-task-lifecycle/scripts/validate_task_status.py", "exists"),
    # Agents - existence check (upgraded by upgrade command)
    (".claude/agents/driver.md", "exists"),
    (".claude/agents/navigator.md", "exists"),
    (".claude/agents/reviewer.md", "exists"),
    (".claude/agents/security-auditor.md", "exists"),
    (".claude/agents/security.md", "exists"),
    # Commands - content check (should be consistent)
    # NOTE: prep-release.md excluded — BPS-internal, not shipped to users.
    (".claude/commands/pc-plan.md", "exists"),  # Source has dogfood defaults
    (".claude/commands/start-task.md", "exists"),  # Source has dogfood task IDs
    (".claude/commands/update-skills.md", "content"),
    (".claude/commands/pc-audit-sibling.md", "content"),
    # Rules - existence check (projects may customize thresholds)
    (".claude/rules/architecture.md", "exists"),
    # Agent memory - existence check (projects customize with their own learnings)
    (".claude/agent-memory/driver/MEMORY.md", "exists"),
    (".claude/agent-memory/navigator/MEMORY.md", "exists"),
    (".claude/agent-memory/reviewer/MEMORY.md", "exists"),
    (".claude/agent-memory/security/MEMORY.md", "exists"),
    (".claude/agent-memory/security-auditor/MEMORY.md", "exists"),
]


def extract_version_field(content: str, file_path: str) -> str | None:
    """Extract version field from YAML content.

    Uses regex instead of YAML parsing because template files may have
    unquoted cookiecutter variables that break YAML parsing.
    """
    # Look for version: "X.Y.Z" or version: 'X.Y.Z' at start of line
    match = re.search(r'^version:\s*["\']?([^"\'\n]+)["\']?\s*$', content, re.MULTILINE)
    if match:
        return match.group(1).strip()
    return None


def compute_line_diff(source_content: str, template_content: str) -> int:
    """Compute the number of different lines between source and template."""
    import difflib

    source_lines = source_content.splitlines()
    template_lines = template_content.splitlines()

    diff = list(difflib.unified_diff(template_lines, source_lines, lineterm=""))
    # Count lines that are actually different (starting with + or -)
    # but not the header lines
    changed_lines = 0
    for line in diff:
        if line.startswith("+") or line.startswith("-"):
            if not line.startswith("+++") and not line.startswith("---"):
                changed_lines += 1

    return changed_lines


def _sync_file(
    source_path: Path,
    template_file: Path,
    rel_path: str,
    console: Console,
) -> None:
    """Sync a single file from source to template.

    For version-mode files (YAML with version field), only updates the
    version line to avoid overwriting template-specific content.
    For content-mode files, copies the full file.
    """
    # Check if this is a version-mode file by looking up its check mode
    check_mode = dict(REQUIRED_TEMPLATE_FILES).get(rel_path)

    if check_mode == "version" and template_file.exists():
        # Only update the version field, preserve rest of template
        source_content = source_path.read_text(encoding="utf-8")
        template_content = template_file.read_text(encoding="utf-8")
        source_version = extract_version_field(source_content, rel_path)
        if source_version:
            updated = re.sub(
                r'^(version:\s*)["\']?[^"\'\n]+["\']?\s*$',
                rf'\g<1>"{source_version}"',
                template_content,
                count=1,
                flags=re.MULTILINE,
            )
            template_file.write_text(updated, encoding="utf-8")
            console.print(f"  [green]✓[/green] Updated version in {rel_path}")
        else:
            console.print(f"  [yellow]![/yellow] Could not extract version from {rel_path}")
    else:
        # Content-mode: full file copy
        content = source_path.read_text(encoding="utf-8")
        template_file.write_text(content, encoding="utf-8")
        console.print(f"  [green]✓[/green] Updated {rel_path}")


def _normalize_for_compare(content: str) -> str:
    """Normalize content for comparison, ignoring cookiecutter variables."""
    return re.sub(r'\{\{[\s]*cookiecutter\.[^}]+\}\}', '{{COOKIECUTTER_VAR}}', content)


def _check_single_file(
    file_rel: str,
    check_mode: str,
    project_root: Path,
    template_project_dir: Path,
) -> tuple[tuple[str, str, str], bool, tuple | None]:
    """Check a single file for drift. Returns (result, has_drift, sync_info)."""
    source_path = project_root / file_rel
    template_file = template_project_dir / file_rel

    if not source_path.exists():
        return (file_rel, "⚠️", "Source file not found"), False, None

    if not template_file.exists():
        return (file_rel, "⚠️", "Not in template"), True, None

    if check_mode == "exists":
        return (file_rel, "✅", "Exists"), False, None

    if check_mode == "version":
        return _check_version(file_rel, source_path, template_file)

    return _check_content(file_rel, source_path, template_file)


def _check_version(file_rel, source_path, template_file):
    """Compare version fields only."""
    src = source_path.read_text(encoding="utf-8")
    tpl = template_file.read_text(encoding="utf-8")
    sv = extract_version_field(src, file_rel)
    tv = extract_version_field(tpl, file_rel)
    if sv == tv:
        return (file_rel, "✅", f"Version match ({sv})"), False, None
    return (
        (file_rel, "⚠️", f"Version mismatch ({sv} vs {tv})"),
        True,
        (source_path, template_file, file_rel),
    )


def _check_content(file_rel, source_path, template_file):
    """Compare full file content (with cookiecutter normalization)."""
    src = _normalize_for_compare(source_path.read_text(encoding="utf-8"))
    tpl = _normalize_for_compare(template_file.read_text(encoding="utf-8"))
    if src == tpl:
        return (file_rel, "✅", "In sync"), False, None
    diff = compute_line_diff(src, tpl)
    return (
        (file_rel, "⚠️", f"Drift detected ({diff} lines changed)"),
        True,
        (source_path, template_file, file_rel),
    )


def _display_results(results, files_to_sync, has_drift, fix):
    """Display check results table and optionally fix drift."""
    from rich.table import Table as RichTable

    table = RichTable(title=None, show_header=True, header_style="bold")
    table.add_column("File", style="cyan")
    table.add_column("Status")
    table.add_column("Details")
    for fp, status, details in results:
        table.add_row(fp, status, details)
    console.print(table)

    in_sync = sum(1 for _, s, _ in results if s == "✅")
    console.print()

    if not has_drift:
        console.print(f"[green]✓ All {in_sync} checked files are in sync[/green]")
        return

    console.print(f"[yellow]⚠️  {len(files_to_sync)} file(s) have drifted from template[/yellow]")
    if fix:
        console.print("\n[bold]Syncing template from source...[/bold]")
        for source_path, template_file, rel_path in files_to_sync:
            _sync_file(source_path, template_file, rel_path, console)
        console.print(f"\n[green]Synced {len(files_to_sync)} file(s) to template[/green]")
    else:
        console.print("\n[dim]Run with --fix to sync template from source files[/dim]")


def _resolve_template_dir(paircoder_dir):
    """Resolve the template project directory, printing errors as needed."""
    template_path = get_template_path(paircoder_dir)
    console.print("\n[bold]Cookie Cutter Template Status[/bold]\n")

    if not template_path:
        console.print("[yellow]⚠️  Template not found[/yellow]")
        console.print("Expected at: tools/cli/bpsai_pair/data/cookiecutter-paircoder")
        return None

    tpd = template_path / "{{cookiecutter.project_slug}}"
    if not tpd.exists():
        console.print("[yellow]⚠️  Template project directory not found[/yellow]")
        return None

    return tpd


@app.command("check")
def template_check(
    fail_on_drift: bool = typer.Option(False, "--fail-on-drift", help="Exit with code 1 if drift detected"),
    fix: bool = typer.Option(False, "--fix", help="Auto-sync template from source files"),
    verbose: bool = typer.Option(False, "--verbose", "-v", help="Show detailed diff information"),
):
    """Check for drift between source files and cookie cutter template."""
    try:
        paircoder_dir = find_paircoder_dir()
    except ProjectRootNotFoundError:
        console.print("[red]❌ Not in a PairCoder project[/red]")
        console.print("   Run 'bpsai-pair init' to initialize a project, or run from a git repository.")
        raise typer.Exit(1)

    project_root = paircoder_dir.parent
    template_project_dir = _resolve_template_dir(paircoder_dir)
    if not template_project_dir:
        if fail_on_drift:
            raise typer.Exit(1)
        return

    results = []
    has_drift = False
    files_to_sync = []

    for file_rel, check_mode in REQUIRED_TEMPLATE_FILES:
        result, drifted, sync_info = _check_single_file(
            file_rel, check_mode, project_root, template_project_dir,
        )
        results.append(result)
        if drifted:
            has_drift = True
        if sync_info:
            files_to_sync.append(sync_info)

    _display_results(results, files_to_sync, has_drift, fix)

    if has_drift and fail_on_drift and not fix:
        raise typer.Exit(1)


@app.command("list")
def template_list():
    """List files tracked for template sync."""
    from rich.table import Table as RichTable

    try:
        paircoder_dir = find_paircoder_dir()
    except ProjectRootNotFoundError:
        console.print("[red]❌ Not in a PairCoder project[/red]")
        console.print("   Run 'bpsai-pair init' to initialize a project, or run from a git repository.")
        raise typer.Exit(1)

    template_path = get_template_path(paircoder_dir)

    console.print("\n[bold]Required Template Files[/bold]\n")

    if not template_path:
        console.print("[yellow]⚠️  Template not found[/yellow]")
        return

    template_project_dir = template_path / "{{cookiecutter.project_slug}}"
    if not template_project_dir.exists():
        console.print("[yellow]⚠️  Template project directory not found[/yellow]")
        return

    console.print(f"Template: {template_path.name}")
    console.print()

    # Show required files with their check modes
    table = RichTable(title=None, show_header=True, header_style="bold")
    table.add_column("File", style="cyan")
    table.add_column("Check Mode")
    table.add_column("Description")

    mode_descriptions = {
        "content": "Full content comparison",
        "exists": "Existence check only",
        "version": "Version field match",
    }

    for file_path, check_mode in REQUIRED_TEMPLATE_FILES:
        description = mode_descriptions.get(check_mode, check_mode)
        table.add_row(file_path, check_mode, description)

    console.print(table)
    console.print()
    console.print(f"[dim]Total: {len(REQUIRED_TEMPLATE_FILES)} required files[/dim]")
