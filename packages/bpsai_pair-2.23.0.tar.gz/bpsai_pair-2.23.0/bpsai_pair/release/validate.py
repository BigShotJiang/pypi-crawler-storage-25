"""Release version validation helpers (P0-2 split from release/commands.py)."""
from __future__ import annotations

import re
from pathlib import Path
from typing import Optional

import yaml


def _collect_versions(paircoder_dir: Path) -> dict[str, Optional[str]]:
    """Collect version strings from the four canonical files."""
    from ..commands.version_consistency import (
        _read_pyproject_version,
        _read_yaml_version,
    )

    project_root = paircoder_dir.parent
    cli_version_file = paircoder_dir / ".cli_version"
    cli_version = None
    if cli_version_file.exists():
        try:
            cli_version = cli_version_file.read_text(encoding="utf-8").strip() or None
        except Exception:
            pass

    return {
        "pyproject.toml": _read_pyproject_version(project_root),
        "capabilities.yaml": _read_yaml_version(paircoder_dir / "capabilities.yaml"),
        "config.yaml": _read_yaml_version(paircoder_dir / "config.yaml"),
        ".cli_version": cli_version,
    }


def _fix_yaml_version(path: Path, new_version: str) -> None:
    """Update the version field in a YAML file, preserving structure.

    Uses line-level replacement to avoid rewriting the entire file with
    yaml.dump (which reorders keys and strips comments).
    """
    if not path.exists():
        # Create minimal file if missing
        path.write_text(
            yaml.dump({"version": new_version}, default_flow_style=False),
            encoding="utf-8",
        )
        return

    text = path.read_text(encoding="utf-8")
    # Replace existing version line, preserving quoting style
    new_text = re.sub(
        r'^(version:\s*).*$',
        rf'\g<1>{new_version}',
        text,
        count=1,
        flags=re.MULTILINE,
    )
    if new_text == text:
        # No version line found -- append it
        new_text = f"version: {new_version}\n" + text
    path.write_text(new_text, encoding="utf-8")


def _fix_stale_files(
    paircoder_dir: Path, versions: dict[str, Optional[str]], canonical: str,
) -> list[str]:
    """Update stale or missing files to match the canonical (pyproject) version.

    Returns list of file names that were updated.
    """
    updated: list[str] = []

    if versions.get("capabilities.yaml") != canonical:
        _fix_yaml_version(paircoder_dir / "capabilities.yaml", canonical)
        updated.append("capabilities.yaml")

    if versions.get("config.yaml") != canonical:
        _fix_yaml_version(paircoder_dir / "config.yaml", canonical)
        updated.append("config.yaml")

    if versions.get(".cli_version") != canonical:
        (paircoder_dir / ".cli_version").write_text(canonical + "\n", encoding="utf-8")
        updated.append(".cli_version")

    return updated


def check_pypi_readme(project_root: Path, version: str) -> str | None:
    """Check that tools/cli/README.md mentions the release version.

    Returns None if OK, or an error message if the version is missing.
    The PyPI README (tools/cli/README.md) is baked into the wheel at build
    time. If it doesn't mention the current version, the PyPI page will
    show stale content that CANNOT be fixed until the next release.
    This has happened twice (v2.21.2, v2.21.3).
    """
    readme = project_root / "tools" / "cli" / "README.md"
    if not readme.exists():
        return None  # Not in CLI repo, skip

    text = readme.read_text(encoding="utf-8")
    if version in text:
        return None

    return (
        f"tools/cli/README.md does not mention v{version}. "
        f"Update the 'What's New' section before building the wheel. "
        f"This file is the PyPI long_description -- stale content ships "
        f"to PyPI and cannot be fixed until the next release."
    )
