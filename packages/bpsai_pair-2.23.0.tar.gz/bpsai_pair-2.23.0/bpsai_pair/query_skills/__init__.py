"""Query skills package --- auto-discovers and registers all skill modules.

Each skill reads from SQLite stores and returns structured dicts.
"""

from __future__ import annotations

import importlib
import pkgutil
from pathlib import Path
from typing import Protocol


class QuerySkill(Protocol):
    """Protocol for query skills."""

    def execute(self, request: dict) -> dict: ...


_REGISTRY: dict[str, type] = {}


def register_skill(name: str, cls: type) -> None:
    """Register a query skill class by name."""
    _REGISTRY[name] = cls


def get_skill(name: str) -> type | None:
    """Look up a skill class by name."""
    return _REGISTRY.get(name)


def list_skills() -> list[str]:
    """Return sorted list of registered skill names."""
    return sorted(_REGISTRY.keys())


def discover_skills() -> None:
    """Import all skill modules in this package to trigger registration."""
    package_dir = Path(__file__).parent
    for info in pkgutil.iter_modules([str(package_dir)]):
        if not info.name.startswith("_"):
            importlib.import_module(f".{info.name}", __package__)


def safe_limit(request: dict | None, default: int = 10, maximum: int = 1000) -> int:
    """Extract and clamp limit from request dict."""
    try:
        raw = (request or {}).get("limit", default)
        return max(1, min(int(raw), maximum))
    except (TypeError, ValueError):
        return default