"""Schema conformance validator for A2A query results.

Validates that adapted dicts can construct framework Result dataclasses,
proving the CLI output matches the framework's A2A query contracts.
"""

from __future__ import annotations

from typing import Any

_VALID_CATEGORIES = frozenset({
    "sprint_status", "driver_activity", "review_findings",
    "quality_metrics", "session_outcomes",
})

# Framework result types loaded lazily to avoid hard dependency
_RESULT_CLASSES: dict[str, type] | None = None


def _load_result_classes() -> dict[str, type]:
    """Import framework result types. Returns empty dict if unavailable."""
    global _RESULT_CLASSES
    if _RESULT_CLASSES is not None:
        return _RESULT_CLASSES
    try:
        from a2a.query_results import (
            DriverActivityResult,
            QualityMetricsResult,
            ReviewFindingsResult,
            SessionOutcomesResult,
            SprintStatusResult,
        )
        _RESULT_CLASSES = {
            "sprint_status": SprintStatusResult,
            "driver_activity": DriverActivityResult,
            "review_findings": ReviewFindingsResult,
            "quality_metrics": QualityMetricsResult,
            "session_outcomes": SessionOutcomesResult,
        }
    except ImportError:
        _RESULT_CLASSES = {}
    return _RESULT_CLASSES


def validate_against_framework(
    category: str, adapted: dict[str, Any],
) -> list[str]:
    """Validate adapted dict conforms to framework result schema.

    Returns list of error strings. Empty list means conformant.
    """
    if category not in _VALID_CATEGORIES:
        return [f"Unknown category: {category}"]
    classes = _load_result_classes()
    if category not in classes:
        return [f"Framework types unavailable for: {category}"]
    cls = classes[category]
    try:
        cls.from_dict(adapted)
    except (KeyError, TypeError) as exc:
        return [f"Schema conformance error: {exc}"]
    return []
