"""RemoteQueryClient — client wrapper for querying remote agents via A2A.

Dispatches queries by category, handles HandlerResult envelope,
and provides timeout + retry logic for transient failures.
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from typing import Any, Optional, Protocol

logger = logging.getLogger(__name__)

_TRANSIENT_ERRORS = (ConnectionError, TimeoutError, OSError)


class QueryError(Exception):
    """Raised when a remote query fails after retries."""


class QueryTransport(Protocol):
    """Protocol for A2A transport backends."""

    def query(self, category: str, timeout: int = 30) -> dict[str, Any]: ...


@dataclass
class HandlerResult:
    """Parsed envelope from an A2A handler response."""

    data: Any = None
    confidence: float = 0.0
    freshness: Optional[str] = None
    error: Optional[str] = None

    @classmethod
    def from_dict(cls, raw: dict[str, Any]) -> "HandlerResult":
        """Parse a HandlerResult from a raw dict."""
        return cls(
            data=raw.get("data"),
            confidence=raw.get("confidence", 0.0),
            freshness=raw.get("freshness"),
            error=raw.get("error"),
        )

    def is_stale(self, threshold: float = 0.5) -> bool:
        """Check if result confidence is below threshold."""
        return self.confidence < threshold


class RemoteQueryClient:
    """Client for querying remote agents via A2A protocol."""

    def __init__(
        self,
        transport: QueryTransport,
        timeout: int = 30,
        retries: int = 2,
    ) -> None:
        self._transport = transport
        self._timeout = timeout
        self._retries = retries

    def sprint_status(self) -> HandlerResult:
        """Query sprint status from remote agent."""
        return self._query("sprint_status")

    def driver_activity(self) -> HandlerResult:
        """Query driver activity from remote agent."""
        return self._query("driver_activity")

    def review_findings(self) -> HandlerResult:
        """Query review findings from remote agent."""
        return self._query("review_findings")

    def quality_metrics(self) -> HandlerResult:
        """Query quality metrics from remote agent."""
        return self._query("quality_metrics")

    def session_outcomes(self) -> HandlerResult:
        """Query session outcomes from remote agent."""
        return self._query("session_outcomes")

    def _query(self, category: str) -> HandlerResult:
        """Execute a query with retry logic."""
        last_error: Exception | None = None

        for attempt in range(self._retries + 1):
            try:
                raw = self._transport.query(category, timeout=self._timeout)
                return HandlerResult.from_dict(raw)
            except _TRANSIENT_ERRORS as e:
                last_error = e
                if attempt < self._retries:
                    wait = 0.1 * (2 ** attempt)
                    logger.warning(
                        "Query %s failed (attempt %d/%d): %s, retrying in %.1fs",
                        category, attempt + 1, self._retries + 1, e, wait,
                    )
                    time.sleep(wait)

        raise QueryError(str(last_error)) from last_error
