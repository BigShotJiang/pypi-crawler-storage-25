"""QC trends query skill — historical pass rates and flaky detection."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from ..qc.telemetry_store import QCTelemetryStore
from . import register_skill


class QCTrendsSkill:
    """Query QC historical trends from SQLite."""

    def __init__(self, db_path: Path | None = None, **kwargs: Any) -> None:
        self._db_path = db_path

    def execute(self, request: dict | None = None) -> dict[str, Any]:
        if not self._db_path or not self._db_path.exists():
            return {
                "runs": [],
                "total_runs": 0,
                "flaky_scenarios": [],
                "flaky_count": 0,
                "message": "No QC telemetry data",
            }

        req = request or {}
        store = QCTelemetryStore(self._db_path)

        suite = req.get("suite")
        environment = req.get("environment")
        # Skill layer caps at 200 (user-facing), store layer at 1000 (internal).
        limit = min(req.get("limit", 50), 200)

        runs = store.query_trends(suite=suite, environment=environment, limit=limit)
        flaky = store.detect_flaky(suite=suite)

        return {
            "runs": runs,
            "total_runs": len(runs),
            "flaky_scenarios": flaky,
            "flaky_count": len(flaky),
        }


register_skill("qc_trends", QCTrendsSkill)
