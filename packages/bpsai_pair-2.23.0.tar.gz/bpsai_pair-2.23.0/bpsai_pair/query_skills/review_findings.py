"""ReviewFindings query skill — review session summaries."""

from __future__ import annotations

from pathlib import Path

from bpsai_pair.query_skills import register_skill, safe_limit


class ReviewFindingsSkill:
    """Summarizes findings from recent reviewer sessions."""

    def __init__(
        self, db_path: Path | None = None, fallback_dir: Path | None = None,
        **_kw,
    ) -> None:
        self._db_path = db_path
        self._fallback_dir = fallback_dir

    def execute(self, request: dict | None = None) -> dict:
        empty = {
            "reviews": 0, "total_errors": 0,
            "error_categories": {}, "enforcement_overrides": 0,
        }
        sessions = self._load_sessions(request)
        reviewers = [s for s in sessions if s.agent_role in ("reviewer", "nayru")]
        if not reviewers:
            return empty
        total_errors = 0
        categories: dict[str, int] = {}
        total_overrides = 0
        for s in reviewers:
            total_errors += len(s.errors)
            for err in s.errors:
                cat = err.split(":")[0] if ":" in err else "general"
                categories[cat] = categories.get(cat, 0) + 1
            total_overrides += len(s.enforcement_overrides)
        return {
            "reviews": len(reviewers),
            "total_errors": total_errors,
            "error_categories": categories,
            "enforcement_overrides": total_overrides,
        }

    def _load_sessions(self, request: dict | None = None):
        limit = safe_limit(request)
        try:
            from bpsai_pair.telemetry.session_store import SessionStore
            if self._db_path and self._db_path.exists():
                return SessionStore(self._db_path, self._fallback_dir).query_recent(limit)
        except ImportError:
            pass
        return []


register_skill("review_findings", ReviewFindingsSkill)