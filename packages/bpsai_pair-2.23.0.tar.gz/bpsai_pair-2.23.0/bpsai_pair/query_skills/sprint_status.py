"""SprintStatus query skill — task counts by status."""

from __future__ import annotations

import re
from pathlib import Path

from bpsai_pair.query_skills import register_skill

_FIELD_RE = re.compile(r"^(\w+):\s*['\"]?([^'\"\n]+?)['\"]?\s*$", re.MULTILINE)


def _extract(content: str, field: str) -> str | None:
    for m in _FIELD_RE.finditer(content):
        if m.group(1) == field:
            return m.group(2).strip()
    return None


class SprintStatusSkill:
    """Counts tasks by status from task files."""

    def __init__(self, paircoder_dir: Path | None = None, **_kw) -> None:
        self._dir = paircoder_dir

    def execute(self, request: dict | None = None) -> dict:
        empty = {
            "sprint": "unknown", "tasks_done": 0,
            "tasks_in_progress": 0, "tasks_blocked": 0,
            "tasks_pending": 0, "total_complexity": 0,
        }
        if not self._dir:
            return empty
        tasks_dir = self._dir / "tasks"
        if not tasks_dir.exists():
            return empty
        sprint = "unknown"
        done = ip = blocked = pending = cx = 0
        for f in tasks_dir.glob("*.task.md"):
            content = f.read_text(encoding="utf-8")
            status = _extract(content, "status")
            s = _extract(content, "sprint")
            c = _extract(content, "complexity")
            if s:
                sprint = s
            if c and c.isdigit():
                cx += int(c)
            if status == "done":
                done += 1
            elif status == "in_progress":
                ip += 1
            elif status == "blocked":
                blocked += 1
            else:
                pending += 1
        return {
            "sprint": sprint, "tasks_done": done,
            "tasks_in_progress": ip, "tasks_blocked": blocked,
            "tasks_pending": pending, "total_complexity": cx,
        }


register_skill("sprint_status", SprintStatusSkill)