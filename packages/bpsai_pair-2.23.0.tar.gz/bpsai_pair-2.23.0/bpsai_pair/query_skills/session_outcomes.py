"""SessionOutcomes query skill — session outcome distribution."""

from __future__ import annotations

from pathlib import Path

from bpsai_pair.query_skills import register_skill, safe_limit


class SessionOutcomesSkill:
    """Summarizes recent session outcomes by type."""

    def __init__(
        self, db_path: Path | None = None, fallback_dir: Path | None = None,
        **_kw,
    ) -> None:
        self._db_path = db_path
        self._fallback_dir = fallback_dir

    def execute(self, request: dict | None = None) -> dict:
        empty = {
            "total_sessions": 0,
            "outcomes": {"success": 0, "partial": 0, "abandoned": 0},
            "avg_duration_s": 0.0,
        }
        sessions = self._load_sessions(request)
        if not sessions:
            return empty
        outcomes: dict[str, int] = {"success": 0, "partial": 0, "abandoned": 0}
        for s in sessions:
            key = s.outcome if s.outcome in outcomes else "abandoned"
            outcomes[key] += 1
        avg_dur = sum(s.duration_s for s in sessions) / len(sessions)
        return {
            "total_sessions": len(sessions),
            "outcomes": outcomes,
            "avg_duration_s": round(avg_dur, 1),
        }

    def _load_sessions(self, request: dict | None = None):
        limit = safe_limit(request)
        try:
            from bpsai_pair.telemetry.session_store import SessionStore
            if self._db_path and self._db_path.exists():
                return SessionStore(self._db_path, self._fallback_dir).query_recent(limit)
        except ImportError:
            pass
        return []


register_skill("session_outcomes", SessionOutcomesSkill)