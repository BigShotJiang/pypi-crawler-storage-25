"""Consistent JSON envelope for --json CLI output (S44.6).

All --json output uses the schema:
    {"status": "ok"|"error", "data": <payload>, "errors": [<strings>]}
"""
from __future__ import annotations

import json
import sys
from typing import Any


def wrap_ok(data: Any) -> dict:
    """Wrap a successful payload in the standard envelope."""
    return {"status": "ok", "data": data, "errors": []}


def wrap_error(message: str, data: Any = None) -> dict:
    """Wrap an error message in the standard envelope."""
    return {"status": "error", "data": data, "errors": [message]}


def print_envelope(envelope: dict) -> None:
    """Print a JSON envelope to stdout without Rich formatting."""
    sys.stdout.write(json.dumps(envelope, indent=2, default=str))
    sys.stdout.write("\n")
    sys.stdout.flush()
