"""Plan CLI commands — registration shim.

This module creates the plan_app Typer instance and registers
all plan commands from sub-modules.

Note: find_paircoder_dir, console, get_state_manager, PlanParser, and
TaskParser are re-exported here so existing test mocks that patch
'bpsai_pair.planning.plan_commands.<name>' continue to work.
Sub-modules use late imports from this module for these names.
"""

import typer

from .helpers import find_paircoder_dir, console, get_state_manager  # noqa: F401
from .parser import PlanParser, TaskParser  # noqa: F401
from .models import Plan, Task, TaskStatus, PlanStatus, PlanType  # noqa: F401
from .plan_intelligence import display_task_intelligence, display_plan_intelligence  # noqa: F401
from .plan_workspace import display_scope_analysis  # noqa: F401
from .plan_task_push import display_push_results  # noqa: F401
from .plan_crud_commands import plan_new, plan_add_task
from .plan_query_commands import plan_list, plan_show, plan_tasks
from .plan_status_commands import plan_status_cmd
from .plan_trello_sync import plan_sync_trello
from .plan_estimation import plan_estimate, planning_status
from .plan_complete_command import plan_complete_cmd

plan_app = typer.Typer(
    help="Manage plans (goals, tasks, sprints)",
    context_settings={"help_option_names": ["-h", "--help"]}
)

# Register CRUD commands
plan_app.command("new")(plan_new)
plan_app.command("add-task")(plan_add_task)

# Register query commands
plan_app.command("list")(plan_list)
plan_app.command("show")(plan_show)
plan_app.command("tasks")(plan_tasks)

# Register status command
plan_app.command("status")(plan_status_cmd)

# Register extracted module commands
# sync-trello is deprecated; sync-pm is the canonical name
plan_app.command("sync-trello", deprecated=True)(plan_sync_trello)
plan_app.command("sync-pm")(plan_sync_trello)
plan_app.command("estimate")(plan_estimate)
plan_app.command("complete")(plan_complete_cmd)
