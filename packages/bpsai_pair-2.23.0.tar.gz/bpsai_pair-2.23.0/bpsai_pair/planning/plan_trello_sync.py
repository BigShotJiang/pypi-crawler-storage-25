"""Plan sync command — routes through PM abstraction or legacy Trello.

When a PM provider is active (not "none"), tasks are converted to
PMWorkItems and synced via PMSyncManager (see plan_pm_sync.py).
Falls back to legacy TrelloService path when no provider is configured.
"""

from typing import Optional
import json

import typer

from .parser import PlanParser, TaskParser
from .helpers import console, find_paircoder_dir
from ..pm.registry import get_active_provider

plan_sync_trello_app = typer.Typer(
    help="Sync plan to Trello",
    context_settings={"help_option_names": ["-h", "--help"]}
)


def _load_plan_and_tasks(plan_id, paircoder_dir):
    """Load plan, tasks, and config. Returns (plan, tasks, config, parsers)."""
    import yaml

    plan_parser = PlanParser(paircoder_dir / "plans")
    task_parser = TaskParser(paircoder_dir / "tasks")

    plan = plan_parser.get_plan_by_id(plan_id)
    if not plan:
        console.print(f"[red]Plan not found: {plan_id}[/red]")
        raise typer.Exit(1)

    tasks = task_parser.get_tasks_for_plan(plan_id)
    if not tasks:
        console.print(f"[yellow]No tasks found for plan: {plan_id}[/yellow]")
        raise typer.Exit(1)

    config_file = paircoder_dir / "config.yaml"
    full_config = {}
    if config_file.exists():
        with open(config_file, encoding='utf-8') as f:
            full_config = yaml.safe_load(f) or {}

    return plan, tasks, full_config, plan_parser, task_parser


def _group_by_sprint(tasks):
    """Group tasks by sprint name."""
    sprints = {}
    for task in tasks:
        name = task.sprint or "Backlog"
        sprints.setdefault(name, []).append(task)
    return sprints


def _make_results(plan_id, board_id, dry_run, only_new):
    """Create empty results dict."""
    return {
        "plan_id": plan_id, "board_id": board_id,
        "lists_created": [], "cards_created": [], "cards_updated": [],
        "cards_skipped": [], "errors": [],
        "dry_run": dry_run, "only_new": only_new,
    }


def _require_board_id(effective_board_id):
    """Raise typer.Exit(1) if no board_id is available."""
    if not effective_board_id:
        console.print("[red]Board ID required. Either:[/red]")
        console.print("  1. Use --board <board-id>")
        console.print("  2. Set trello.board_id in .paircoder/config.yaml")
        console.print("\n[dim]Run 'bpsai-pair trello boards --json' to see available boards.[/dim]")
        raise typer.Exit(1)


def _show_dry_run(plan_id, sprints_tasks, results, effective_board_id, json_out):
    """Preview mode — show tasks without making changes."""
    console.print(f"\n[bold]Would sync plan:[/bold] {plan_id}")
    if effective_board_id:
        console.print(f"[bold]Target board:[/bold] {effective_board_id}")
    else:
        console.print("[bold]Target board:[/bold] [yellow](not specified)[/yellow]")
    console.print("\n[bold]Tasks to sync:[/bold]")

    total = 0
    for sprint_name, sprint_tasks in sorted(sprints_tasks.items()):
        console.print(f"\n  [cyan]{sprint_name}[/cyan]:")
        for task in sprint_tasks:
            console.print(f"    [{task.id}] {task.title}")
            results["cards_created"].append({
                "task_id": task.id, "title": task.title, "sprint": sprint_name,
            })
            total += 1

    console.print(f"\n[dim]Total: {total} tasks in {len(sprints_tasks)} lists[/dim]")
    if json_out:
        console.print(json.dumps(results, indent=2))


@plan_sync_trello_app.command("sync")
def plan_sync_trello(
    plan_id: str = typer.Argument(..., help="Plan ID to sync"),
    board_id: Optional[str] = typer.Option(None, "--board", "-b", help="Target Trello board ID (uses config default if not specified)"),
    target_list: Optional[str] = typer.Option(None, "--target-list", "-t", help="Target list for cards (default: Intake/Backlog, use 'Planned/Ready' for sprint planning)"),
    create_lists: bool = typer.Option(False, "--create-lists/--no-create-lists", help="Create sprint lists if missing"),
    link_cards: bool = typer.Option(True, "--link/--no-link", help="Store card IDs in task files"),
    apply_defaults: bool = typer.Option(False, "--apply-defaults", "-d", help="Apply project defaults from config to new cards"),
    only_new: bool = typer.Option(False, "--only-new", help="Only sync tasks without existing Trello cards (skip linked tasks)"),
    fire_ready: bool = typer.Option(True, "--fire-ready/--no-fire-ready", help="Fire on_task_ready hooks for ready tasks (moves to Planned/Ready)"),
    dry_run: bool = typer.Option(False, "--dry-run", help="Preview without making changes"),
    json_out: bool = typer.Option(False, "--json", help="Output as JSON"),
):
    """Sync plan tasks to PM provider (or Trello directly)."""
    paircoder_dir = find_paircoder_dir()
    plan, tasks, full_config, plan_parser, task_parser = _load_plan_and_tasks(
        plan_id, paircoder_dir,
    )
    effective_board_id = board_id or full_config.get("trello", {}).get("board_id")
    results = _make_results(plan_id, effective_board_id, dry_run, only_new)
    sprints_tasks = _group_by_sprint(tasks)

    if dry_run:
        _show_dry_run(plan_id, sprints_tasks, results, effective_board_id, json_out)
        return

    provider = get_active_provider(full_config)
    if provider.name != "none":
        from .plan_pm_sync import sync_plan_via_pm
        meta = plan.metadata if hasattr(plan, "metadata") else {}
        sync_plan_via_pm(
            plan_id, sprints_tasks, results, full_config,
            task_parser, link_cards, json_out, provider=provider,
            only_new=only_new,
            epic_provider_id=meta.get("epic_provider_id") or meta.get("parent_epic_id"),
            pm_scope=meta.get("pm_scope", "epic"),
            story_provider_id=meta.get("story_provider_id"),
            plan_title=plan.title,
        )
        return

    _require_board_id(effective_board_id)
    from .plan_legacy_sync import sync_plan_via_trello
    sync_plan_via_trello(
        plan_id, plan, sprints_tasks, results, full_config,
        effective_board_id, target_list, create_lists, link_cards,
        apply_defaults, only_new, fire_ready, json_out,
        task_parser, paircoder_dir,
    )
