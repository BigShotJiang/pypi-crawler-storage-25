"""Complexity-based scope auto-detection.

T40.3: Determines whether work should be scoped as Epic or Story
based on total complexity estimate and sprint budget.
"""

from __future__ import annotations

from dataclasses import dataclass

DEFAULT_SPRINT_CX_BUDGET = 300


@dataclass
class ScopeResult:
    """Result of scope auto-detection."""

    scope: str  # "epic" or "story"
    reason: str
    suggested_sprints: int


def detect_scope(
    total_cx: int,
    sprint_budget: int = DEFAULT_SPRINT_CX_BUDGET,
    num_sprint_targets: int = 1,
) -> ScopeResult:
    """Detect whether work should be scoped as Epic or Story.

    Rules:
    - If num_sprint_targets > 1 -> Epic (spans multiple sprints)
    - If total_cx > sprint_budget -> Epic (exceeds single sprint)
    - Else -> Story (fits within one sprint)
    """
    if num_sprint_targets > 1:
        return ScopeResult(
            scope="epic",
            reason=f"Spans {num_sprint_targets} sprints",
            suggested_sprints=num_sprint_targets,
        )
    if total_cx > sprint_budget:
        sprints = -(-total_cx // sprint_budget)  # ceiling division
        return ScopeResult(
            scope="epic",
            reason=f"Total cx {total_cx} exceeds sprint budget {sprint_budget}",
            suggested_sprints=sprints,
        )
    return ScopeResult(
        scope="story",
        reason=f"Total cx {total_cx} fits within sprint budget {sprint_budget}",
        suggested_sprints=1,
    )
