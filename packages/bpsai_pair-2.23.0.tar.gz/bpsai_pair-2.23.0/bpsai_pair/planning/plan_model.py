"""Plan and Sprint data models.

This module provides the Plan and Sprint dataclasses used
across the planning system.
"""

from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Optional

from .plan_enums import PlanType, PlanStatus


@dataclass
class Sprint:
    """Represents a sprint containing multiple tasks."""
    id: str
    title: str
    goal: str = ""
    task_ids: list[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        """Convert to dictionary for YAML serialization."""
        return {
            "id": self.id,
            "title": self.title,
            "goal": self.goal,
            "tasks": self.task_ids,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "Sprint":
        """Create Sprint from dictionary."""
        return cls(
            id=data.get("id", ""),
            title=data.get("title", ""),
            goal=data.get("goal", ""),
            task_ids=data.get("tasks", []),
        )


@dataclass
class Plan:
    """Represents a plan with goals, tasks, and sprints.

    Plans are stored as .plan.yaml files.
    """
    id: str
    title: str
    type: PlanType = PlanType.FEATURE
    status: PlanStatus = PlanStatus.PLANNED
    owner: str = ""
    created_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    skills: list[str] = field(default_factory=list)
    flows: list[str] = field(default_factory=list)  # DEPRECATED: Use skills
    goals: list[str] = field(default_factory=list)
    sprints: list[Sprint] = field(default_factory=list)
    tasks: list[dict] = field(default_factory=list)
    acceptance_criteria: dict = field(default_factory=dict)
    metadata: dict = field(default_factory=dict)
    source_path: Optional[Path] = None

    @property
    def status_emoji(self) -> str:
        """Return emoji for current status."""
        return {
            PlanStatus.PLANNED: "\U0001f4cb",
            PlanStatus.IN_PROGRESS: "\U0001f504",
            PlanStatus.COMPLETE: "\u2705",
            PlanStatus.ARCHIVED: "\U0001f4e6",
        }.get(self.status, "\u2753")

    @property
    def task_ids(self) -> list[str]:
        """Get all task IDs from the plan."""
        return [t.get("id", "") for t in self.tasks if t.get("id")]

    @property
    def slug(self) -> str:
        """Get plan slug from ID."""
        parts = self.id.split("-")
        if len(parts) > 3:
            return "-".join(parts[3:])
        return self.id

    def get_sprint_by_id(self, sprint_id: str) -> Optional[Sprint]:
        """Get a sprint by ID."""
        for sprint in self.sprints:
            if sprint.id == sprint_id:
                return sprint
        return None

    def get_tasks_for_sprint(self, sprint_id: str) -> list[dict]:
        """Get task summaries for a specific sprint."""
        sprint = self.get_sprint_by_id(sprint_id)
        if not sprint:
            return []
        return [t for t in self.tasks if t.get("id") in sprint.task_ids]

    def to_dict(self) -> dict:
        """Convert to dictionary for YAML serialization."""
        result = {
            "id": self.id,
            "title": self.title,
            "type": self.type.value,
            "status": self.status.value,
        }

        if self.owner:
            result["owner"] = self.owner
        if self.created_at:
            result["created_at"] = self.created_at.isoformat()
        if self.completed_at:
            result["completed_at"] = self.completed_at.isoformat()

        if self.skills:
            result["skills"] = self.skills

        # DEPRECATED: Only write flows for backward compat if no skills
        if self.flows and not self.skills:
            result["flows"] = self.flows

        if self.goals:
            result["goals"] = self.goals
        if self.acceptance_criteria:
            result["acceptance_criteria"] = self.acceptance_criteria
        if self.sprints:
            result["sprints"] = [s.to_dict() for s in self.sprints]
        if self.tasks:
            result["tasks"] = self.tasks
        if self.metadata:
            result["metadata"] = self.metadata

        return result

    @classmethod
    def from_dict(cls, data: dict, source_path: Optional[Path] = None) -> "Plan":
        """Create Plan from dictionary (parsed YAML)."""
        plan_type = _parse_enum(data.get("type", "feature"), PlanType, PlanType.FEATURE)
        status = _parse_enum(data.get("status", "planned"), PlanStatus, PlanStatus.PLANNED)
        sprints = [
            Sprint.from_dict(s) if isinstance(s, dict) else s
            for s in data.get("sprints", [])
        ]
        skills = data.get("skills", [])
        flows = data.get("flows", [])
        if not skills and flows:
            skills = flows

        return cls(
            id=data.get("id", ""),
            title=data.get("title", "Untitled Plan"),
            type=plan_type, status=status,
            owner=data.get("owner", ""),
            created_at=_parse_datetime(data.get("created_at")),
            completed_at=_parse_datetime(data.get("completed_at")),
            skills=skills,
            flows=flows if not skills else [],
            goals=data.get("goals", []),
            sprints=sprints,
            tasks=data.get("tasks", []),
            acceptance_criteria=data.get("acceptance_criteria", {}),
            metadata=data.get("metadata", {}),
            source_path=source_path,
        )


def _parse_datetime(value) -> Optional[datetime]:
    """Parse an ISO datetime string, returning None on failure."""
    if isinstance(value, str):
        try:
            return datetime.fromisoformat(value.replace("Z", "+00:00"))
        except ValueError:
            return None
    return value if isinstance(value, datetime) else None


def _parse_enum(value, enum_cls, default):
    """Parse a string into an enum, returning default on failure."""
    if isinstance(value, str):
        try:
            return enum_cls(value)
        except ValueError:
            return default
    return value
