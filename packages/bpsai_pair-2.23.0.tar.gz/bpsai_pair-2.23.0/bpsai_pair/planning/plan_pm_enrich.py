"""Enrichment helpers for PM hierarchy sync.

Builds the enrich_fn callback used by HierarchyOrchestrator and
provides field/label resolution from project config.
"""

import logging
import re

from ..pm.provider import ProjectManagementProvider
from ..pm.types import PMWorkItem
from ..pm.workflow import AutomationRule, WorkflowEngine

logger = logging.getLogger(__name__)


def _resolve_field_value(field_name: str, enrich_fields, trello_defaults, trello_cf):
    """Resolve a custom field value from enrich_fields, trello defaults, or CF defaults."""
    if field_name in enrich_fields:
        return enrich_fields[field_name]
    if field_name in trello_defaults:
        return trello_defaults[field_name]
    cf_def = trello_cf.get(field_name, {})
    if "default" in cf_def:
        return cf_def["default"]
    return None


def _stack_to_label(stack_value: str, trello_labels: list) -> str | None:
    """Map a stack value to a Trello label using trello.labels[].matches.

    Tries exact match first, then splits compound values like
    "Worker/Function" into parts and checks each part.
    """
    needle = stack_value.lower().strip()
    for lbl_def in trello_labels:
        matches = [m.lower() for m in lbl_def.get("matches", [])]
        name = lbl_def.get("name", "")
        if needle in matches or name.lower() == needle:
            return name
    # Split compound values (e.g. "Worker/Function" → ["worker", "function"])
    parts = [p.strip().lower() for p in re.split(r"[/\s]+", needle) if p.strip()]
    for lbl_def in trello_labels:
        matches = [m.lower() for m in lbl_def.get("matches", [])]
        if any(part in matches for part in parts):
            return lbl_def["name"]
    return None


def _build_enrich_labels(
    auto: AutomationRule | None,
    inherited_labels: list[str] | None,
    resolve_fn,
    trello_labels: list,
) -> list[str]:
    """Build the full labels list for enrichment."""
    domain_labels = [lbl for lbl in (inherited_labels or []) if lbl]
    # If no domain labels inherited, fall back to stack → label mapping
    if not domain_labels:
        stack_val = resolve_fn("stack")
        if stack_val:
            mapped = _stack_to_label(stack_val, trello_labels)
            if mapped:
                domain_labels.append(mapped)
            else:
                logger.warning(
                    "Stack '%s' has no matching board label — skipping domain label",
                    stack_val,
                )

    labels = list(domain_labels)
    # Apply the automation's created_label (e.g. "Story", "Task")
    if auto and auto.created_label:
        labels.append(auto.created_label)
    if auto and auto.enrich_after:
        labels.extend(lbl for lbl in auto.enrich_after.labels if lbl)
    return labels


def build_enrich_fn(
    provider: ProjectManagementProvider,
    engine: WorkflowEngine,
    config: dict,
):
    """Build an enrichment callback for the HierarchyOrchestrator.

    Applies labels (from automation policy + inherited) and custom fields
    via the provider's abstract API in a single ``set_fields`` call.
    """
    enrich_fields = config.get("pm", {}).get("enrich_fields", {})
    trello_defaults = config.get("trello", {}).get("defaults", {})
    trello_cf = config.get("trello", {}).get("custom_fields", {})
    trello_labels = config.get("trello", {}).get("labels", [])

    def _resolve(field_name: str):
        return _resolve_field_value(field_name, enrich_fields, trello_defaults, trello_cf)

    def _enrich(
        child: PMWorkItem,
        auto: AutomationRule | None,
        *,
        inherited_labels: list[str] | None = None,
    ) -> None:
        fields: dict = {}

        labels = _build_enrich_labels(auto, inherited_labels, _resolve, trello_labels)
        if labels:
            fields["labels"] = labels

        if auto and auto.enrich_after and auto.enrich_after.custom_fields:
            for k in auto.enrich_after.custom_fields:
                val = _resolve(k)
                if val is not None:
                    fields[k] = val

        if fields:
            item_id = child.provider_meta.get("provider_id", child.id)
            provider.set_fields(item_id, fields)

    return _enrich


def _build_story_fields(
    auto, *, enrich_fields: dict, inherited_labels: list[str] | None,
    trello_defaults: dict | None = None, trello_cf: dict | None = None,
) -> dict:
    """Build fields dict for direct Story enrichment."""
    fields: dict = {}
    labels: list[str] = []

    label = auto.created_label if auto and auto.created_label else "Story"
    labels.append(label)

    if inherited_labels:
        labels.extend(lbl for lbl in inherited_labels if lbl)
    if auto and auto.enrich_after and auto.enrich_after.labels:
        labels.extend(lbl for lbl in auto.enrich_after.labels if lbl)
    if labels:
        fields["labels"] = labels

    if auto and auto.enrich_after and auto.enrich_after.custom_fields:
        for k in auto.enrich_after.custom_fields:
            val = _resolve_field_value(
                k, enrich_fields, trello_defaults or {}, trello_cf or {},
            )
            if val is not None:
                fields[k] = val
    return fields


def enrich_story_card(
    provider: ProjectManagementProvider,
    story_id: str,
    auto=None,
    *,
    config: dict | None = None,
    inherited_labels: list[str] | None = None,
) -> None:
    """Apply enrichment to a directly-created Story card.

    Replicates what Butler would do: Story label, inherited labels,
    custom fields, and Tasks checklist.
    """
    config = config or {}
    enrich_fields = config.get("pm", {}).get("enrich_fields", {})
    trello_defaults = config.get("trello", {}).get("defaults", {})
    trello_cf = config.get("trello", {}).get("custom_fields", {})
    fields = _build_story_fields(
        auto, enrich_fields=enrich_fields, inherited_labels=inherited_labels,
        trello_defaults=trello_defaults, trello_cf=trello_cf,
    )

    try:
        if fields:
            provider.set_fields(story_id, fields)
    except Exception as exc:
        logger.debug("Story set_fields failed: %s", exc)

    checklist = auto.created_checklist if auto and auto.created_checklist else None
    if checklist:
        try:
            provider.add_checklist_item(story_id, checklist, "")
        except Exception as exc:
            logger.debug("Story checklist creation failed: %s", exc)
