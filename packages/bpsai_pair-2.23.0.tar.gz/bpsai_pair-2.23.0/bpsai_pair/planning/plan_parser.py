"""Plan file parser (.plan.yaml).

Handles parsing, saving, and status management for plan YAML files.
"""
from pathlib import Path
from typing import Optional

import yaml

from .models import Plan, PlanStatus, TaskStatus


class PlanParser:
    """Parser for plan files (.plan.yaml)."""

    def __init__(self, plans_dir: Path):
        """Initialize parser with plans directory path."""
        self.plans_dir = Path(plans_dir)

    def list_plans(self) -> list[Path]:
        """List all plan files in the plans directory."""
        if not self.plans_dir.exists():
            return []
        return sorted(self.plans_dir.glob("*.plan.yaml"))

    def parse(self, plan_path: Path) -> Optional[Plan]:
        """Parse a single plan file. Returns Plan or None on failure."""
        try:
            with open(plan_path, "r", encoding="utf-8") as f:
                data = yaml.safe_load(f)
            if not data:
                return None
            return Plan.from_dict(data, source_path=plan_path)
        except (yaml.YAMLError, OSError) as e:
            print(f"Error parsing plan {plan_path}: {e}")
            return None

    def parse_all(self) -> list[Plan]:
        """Parse all plans in the directory."""
        plans = []
        for plan_path in self.list_plans():
            plan = self.parse(plan_path)
            if plan:
                plans.append(plan)
        return plans

    def get_plan_by_id(self, plan_id: str) -> Optional[Plan]:
        """Find and parse a plan by its ID (exact match, then partial slug)."""
        exact_path = self.plans_dir / f"{plan_id}.plan.yaml"
        if exact_path.exists():
            return self.parse(exact_path)

        for plan in self.parse_all():
            if plan.id == plan_id:
                return plan

        for plan_path in self.list_plans():
            if plan_id in plan_path.stem:
                return self.parse(plan_path)

        return None

    def save(self, plan: Plan, filename: Optional[str] = None) -> Path:
        """Save a plan to a YAML file. Returns path to saved file."""
        self.plans_dir.mkdir(parents=True, exist_ok=True)

        if filename is None:
            filename = f"{plan.id}.plan.yaml"

        plan_path = self.plans_dir / filename

        with open(plan_path, "w", encoding="utf-8") as f:
            yaml.dump(
                plan.to_dict(),
                f,
                default_flow_style=False,
                allow_unicode=True,
                sort_keys=False,
            )

        plan.source_path = plan_path
        return plan_path

    def update_plan_status(self, plan_id: str, new_status: PlanStatus) -> bool:
        """Update a plan's status in its YAML file. Returns True on success."""
        plan = self.get_plan_by_id(plan_id)
        if not plan or not plan.source_path:
            return False

        with open(plan.source_path, "r", encoding="utf-8") as f:
            data = yaml.safe_load(f)

        if not data:
            return False

        data["status"] = new_status.value

        with open(plan.source_path, "w", encoding="utf-8") as f:
            yaml.dump(
                data,
                f,
                default_flow_style=False,
                allow_unicode=True,
                sort_keys=False,
            )

        return True

    def check_and_update_plan_status(self, plan_id: str, tasks_dir: Path) -> bool:
        """Check task statuses and update plan status accordingly.

        Transitions: planned → in_progress (any task active),
        in_progress → complete (all tasks done/cancelled).
        """
        plan = self.get_plan_by_id(plan_id)
        if not plan:
            return False

        # Import here to avoid circular dependency
        from .task_parser import TaskParser
        task_parser = TaskParser(tasks_dir)
        tasks = task_parser.get_tasks_for_plan(plan_id)

        if not tasks:
            return False

        done_statuses = {TaskStatus.DONE, TaskStatus.CANCELLED}
        active_statuses = {TaskStatus.IN_PROGRESS, TaskStatus.REVIEW, TaskStatus.BLOCKED}

        total_tasks = len(tasks)
        done_count = sum(1 for t in tasks if t.status in done_statuses)
        active_count = sum(1 for t in tasks if t.status in active_statuses)

        if done_count == total_tasks:
            target_status = PlanStatus.COMPLETE
        elif done_count > 0 or active_count > 0:
            target_status = PlanStatus.IN_PROGRESS
        else:
            return False

        if plan.status != target_status:
            return self.update_plan_status(plan_id, target_status)

        return False


def parse_plan(plan_path: Path) -> Optional[Plan]:
    """Parse a single plan file (convenience function)."""
    parser = PlanParser(plan_path.parent)
    return parser.parse(plan_path)
