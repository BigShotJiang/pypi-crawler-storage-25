"""Workspace integration for plan creation.

Connects WorkspaceOrchestrator scope analysis to planning workflows
for cross-repo awareness during plan creation.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

from rich.console import Console

from bpsai_pair.licensing.core import has_feature_api

logger = logging.getLogger(__name__)
console = Console()


def get_workspace_orchestrator(project_root: Path) -> Any:
    """Initialize WorkspaceOrchestrator, returning None on failure.

    Searches up directory tree for .paircoder-workspace.yaml,
    parses it, and creates a WorkspaceOrchestrator with FeedbackService.
    """
    try:
        from bpsai_pair.workspace.parser import WorkspaceParser

        parser = WorkspaceParser()
        config_path = parser.find_workspace_config(project_root)
        if config_path is None:
            return None

        workspace = parser.parse(config_path)

        from bpsai_pair.planning.plan_intelligence import get_feedback_service
        from bpsai_pair.workspace.orchestrator import WorkspaceOrchestrator

        feedback = get_feedback_service(project_root)
        return WorkspaceOrchestrator(workspace, feedback)
    except Exception as e:
        logger.warning("WorkspaceOrchestrator unavailable: %s", e)
        return None


def get_scope_analysis(
    orchestrator: Any,
    description: str,
) -> dict[str, list[str]]:
    """Run scope analysis on a plan description.

    Returns dict mapping repo name to change descriptions.
    Returns empty dict when orchestrator is None or on failure.
    """
    if orchestrator is None:
        return {}

    try:
        return orchestrator.analyze_scope(description)
    except Exception as e:
        logger.warning("Scope analysis failed: %s", e)
        return {}


def format_scope_analysis(scope: dict[str, list[str]]) -> str:
    """Format scope analysis results for display.

    Returns a human-readable string showing impacted repos
    and whether this is a cross-repo or single-repo plan.
    """
    if not scope:
        return "No cross-repo impact detected"

    repo_names = sorted(scope.keys())

    if len(repo_names) == 1:
        name = repo_names[0]
        changes = scope[name]
        detail = changes[0] if changes else "changes"
        return f"Single-repo ({name.upper()} only): {detail}"

    parts = []
    for name in repo_names:
        changes = scope[name]
        detail = changes[0] if changes else "changes"
        parts.append(f"  {name.upper()}: {detail}")

    header = f"Cross-repo impact detected ({len(repo_names)} repos):"
    return header + "\n" + "\n".join(parts)


def suggest_task_id_format(
    scope: dict[str, list[str]],
    sprint: str,
) -> str:
    """Suggest task ID format based on scope analysis.

    For cross-repo (>1 repo): CLI-T{sprint}.X, API-T{sprint}.X
    For single-repo or empty: T{sprint}.X
    """
    if len(scope) <= 1:
        return f"Standard task IDs: T{sprint}.1, T{sprint}.2, ..."

    parts = []
    for name in sorted(scope.keys()):
        prefix = name.upper()
        parts.append(f"{prefix}-T{sprint}.X")
    return f"Cross-repo task IDs: {', '.join(parts)}"


def display_scope_analysis(
    paircoder_dir: Path,
    description: str,
    *,
    sprint: str = "",
) -> None:
    """Display scope analysis after plan creation.

    Detects workspace, runs analyze_scope, prints results.
    Includes task ID format suggestion when sprint is provided.
    Skips silently when no workspace or empty description.
    """
    if not has_feature_api("cross_repo_tasks"):
        return
    if not description:
        return

    project_root = paircoder_dir.parent
    orch = get_workspace_orchestrator(project_root)
    if orch is None:
        return

    scope = get_scope_analysis(orch, description)
    if not scope:
        return

    text = format_scope_analysis(scope)
    console.print(f"\n[cyan]Scope Analysis:[/cyan]")
    for line in text.split("\n"):
        console.print(f"  {line}")

    if sprint:
        id_suggestion = suggest_task_id_format(scope, sprint)
        console.print(f"  [dim]{id_suggestion}[/dim]")
