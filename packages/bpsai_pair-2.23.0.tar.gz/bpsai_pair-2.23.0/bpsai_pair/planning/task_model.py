"""Task data model.

This module provides the Task dataclass used across the planning system.
"""

import re
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Optional, TYPE_CHECKING, List

from .plan_enums import TaskStatus, AcceptanceCriteriaItem, AC_ITEM_PATTERN

if TYPE_CHECKING:
    from ..metrics.estimation import HoursEstimate, TokenEstimate


@dataclass
class Task:
    """Represents a single task within a plan.

    Tasks are stored as .task.md files with YAML frontmatter.
    """
    id: str
    title: str
    plan_id: str
    type: str = "feature"
    priority: str = "P1"
    complexity: int = 50
    status: TaskStatus = TaskStatus.PENDING
    sprint: Optional[str] = None
    tags: list[str] = field(default_factory=list)
    description: str = ""
    body: str = ""
    files_touched: list[str] = field(default_factory=list)
    verification: list[str] = field(default_factory=list)
    depends_on: list[str] = field(default_factory=list)
    source_path: Optional[Path] = None
    due_date: Optional[datetime] = None
    completed_at: Optional[datetime] = None

    @property
    def status_emoji(self) -> str:
        """Return emoji for current status."""
        return {
            TaskStatus.PENDING: "\u23f3",
            TaskStatus.IN_PROGRESS: "\U0001f504",
            TaskStatus.REVIEW: "\U0001f4dd",
            TaskStatus.DONE: "\u2705",
            TaskStatus.BLOCKED: "\U0001f6ab",
            TaskStatus.CANCELLED: "\u274c",
        }.get(self.status, "\u2753")

    @property
    def estimated_hours(self) -> "HoursEstimate":
        """Get estimated hours based on complexity."""
        from ..metrics.estimation import EstimationService
        service = EstimationService()
        return service.estimate_hours(self.complexity)

    @property
    def estimated_hours_str(self) -> str:
        """Get formatted estimated hours string."""
        estimate = self.estimated_hours
        return f"{estimate.expected_hours:.1f}h ({estimate.size_band.upper()})"

    @property
    def estimated_tokens(self) -> "TokenEstimate":
        """Get estimated token usage based on complexity, type, and files."""
        from ..metrics.estimation import TokenEstimator

        project_root = None
        try:
            from ..core.ops import find_project_root
            project_root = find_project_root()
        except Exception:
            pass

        estimator = TokenEstimator(project_root=project_root)
        return estimator.estimate_for_task(self)

    @property
    def estimated_tokens_str(self) -> str:
        """Get formatted estimated tokens string."""
        return str(self.estimated_tokens)

    @property
    def acceptance_criteria(self) -> List[AcceptanceCriteriaItem]:
        """Parse acceptance criteria from the markdown body."""
        if not self.body:
            return []

        ac_section_match = re.search(
            r'#\s*Acceptance\s+Criteria\s*\n(.*?)(?=\n#|\Z)',
            self.body,
            re.IGNORECASE | re.DOTALL
        )
        if not ac_section_match:
            return []

        ac_section = ac_section_match.group(1)
        items = []

        for match in AC_ITEM_PATTERN.finditer(ac_section):
            checked = match.group(1).lower() == 'x'
            text = match.group(2).strip()
            items.append(AcceptanceCriteriaItem(text=text, checked=checked))

        return items

    @property
    def unchecked_ac(self) -> List[AcceptanceCriteriaItem]:
        """Get all unchecked acceptance criteria items."""
        return [ac for ac in self.acceptance_criteria if not ac.checked]

    @property
    def actual_hours(self) -> Optional[float]:
        """Get actual hours from time tracking entries.

        Note: Returns None; use get_actual_hours(paircoder_dir) for values.
        """
        return None

    def get_actual_hours(self, paircoder_dir: Path) -> Optional[float]:
        """Get actual hours spent from time tracking cache."""
        try:
            from ..integrations.time_tracking import LocalTimeCache

            cache_path = paircoder_dir / "time-tracking-cache.json"
            if not cache_path.exists():
                cache_path = paircoder_dir / "time-cache.json"
                if not cache_path.exists():
                    return None

            cache = LocalTimeCache(cache_path)
            total = cache.get_total(self.id)

            if total.total_seconds() == 0:
                return None

            return total.total_seconds() / 3600

        except Exception:
            return None

    def to_dict(self) -> dict:
        """Convert to dictionary for YAML serialization."""
        result = {
            "id": self.id,
            "title": self.title,
            "plan": self.plan_id,
            "type": self.type,
            "priority": self.priority,
            "complexity": self.complexity,
            "status": self.status.value,
            "sprint": self.sprint,
            "tags": self.tags,
            "depends_on": self.depends_on,
        }
        if self.due_date is not None:
            result["due_date"] = self.due_date.isoformat()
        if self.completed_at is not None:
            result["completed_at"] = self.completed_at.isoformat()
        return result

    @classmethod
    def from_dict(cls, data: dict, body: str = "", source_path: Optional[Path] = None) -> "Task":
        """Create Task from dictionary (parsed YAML frontmatter)."""
        status = data.get("status", "pending")
        if isinstance(status, str):
            try:
                status = TaskStatus(status)
            except ValueError:
                status = TaskStatus.PENDING

        due_date = data.get("due_date")
        if isinstance(due_date, str):
            try:
                due_date = datetime.fromisoformat(due_date.replace("Z", "+00:00"))
            except ValueError:
                due_date = None

        completed_at = data.get("completed_at")
        if isinstance(completed_at, str):
            try:
                completed_at = datetime.fromisoformat(completed_at.replace("Z", "+00:00"))
            except ValueError:
                completed_at = None

        return cls(
            id=data.get("id", "UNKNOWN"),
            title=data.get("title", "Untitled Task"),
            plan_id=data.get("plan", ""),
            type=data.get("type", "feature"),
            priority=data.get("priority", "P1"),
            complexity=data.get("complexity", data.get("complexity_hint", 50)),
            status=status,
            sprint=data.get("sprint"),
            tags=data.get("tags", []),
            description=data.get("description", ""),
            body=body,
            files_touched=data.get("files_touched", []),
            verification=data.get("verification", []),
            depends_on=data.get("depends_on", []),
            source_path=source_path,
            due_date=due_date,
            completed_at=completed_at,
        )
