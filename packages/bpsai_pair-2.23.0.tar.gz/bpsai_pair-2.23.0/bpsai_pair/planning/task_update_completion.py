"""Completion logic for task update --status done.

Handles state.md checks, acceptance criteria verification,
status application, hooks, and state machine transitions.
"""
import logging
from pathlib import Path
from typing import Optional

import typer

logger = logging.getLogger(__name__)

from .helpers import console, log_bypass
from .completion_helpers import (
    check_state_md_updated,
    sync_local_ac_for_completion,
    complete_task_with_state_machine,
)
from .status_hooks import run_status_hooks


def check_state_md_gate(
    paircoder_dir: Path, task_id: str, skip_state_check: bool
) -> None:
    """Verify state.md was updated or warn if skipped."""
    if skip_state_check:
        console.print("[yellow]Warning: Skipping state.md check - task completion not documented[/yellow]")
        return

    check_result = check_state_md_updated(paircoder_dir, task_id)
    if not check_result["updated"]:
        console.print("\n[red]Cannot complete task: state.md not updated since task started.[/red]\n")
        console.print("Please update [cyan].paircoder/context/state.md[/cyan] with:")
        console.print(f"  - Mark [yellow]{task_id}[/yellow] as done in task list")
        console.print("  - Add session entry under [yellow]\"What Was Just Done\"[/yellow]")
        console.print("  - Update [yellow]\"What's Next\"[/yellow] section\n")
        console.print(f"Then retry: [cyan]bpsai-pair task update {task_id} --status done[/cyan]")
        console.print("\n[dim]Use --skip-state-check to bypass (not recommended)[/dim]")
        raise typer.Exit(1)


def verify_acceptance_criteria(
    task, task_parser, task_id: str, plan_slug: Optional[str],
    strict: bool, auto_check: bool, paircoder_dir: Path,
) -> Optional[str]:
    """Verify AC items. Returns task_outcome ('partial' or None)."""
    if auto_check:
        checked_count = task_parser.check_all_ac_items(task_id, plan_slug)
        if checked_count > 0:
            console.print(f"[green]✓ Auto-checked {checked_count} acceptance criteria item(s)[/green]")
            task = task_parser.get_task_by_id(task_id, plan_slug)

    if strict:
        return _verify_strict_ac(task, task_id, plan_slug, auto_check, paircoder_dir)
    return _verify_non_strict_ac(task, task_id)


def _verify_strict_ac(task, task_id, plan_slug, auto_check, paircoder_dir):
    """Strict AC verification — blocks on unchecked items."""
    unchecked_ac = task.unchecked_ac if task else []
    if unchecked_ac:
        _report_unchecked_ac(unchecked_ac, task_id, auto_check)
        _record_ac_failure_telemetry(task_id, task, paircoder_dir, len(unchecked_ac))
        raise typer.Exit(1)

    console.print("[green]✓ All acceptance criteria verified[/green]")
    local_ac_ok, local_ac_msg = sync_local_ac_for_completion(task_id, is_trello=False)
    if not local_ac_ok:
        console.print(f"[red]❌ BLOCKED: {local_ac_msg}[/red]")
        _record_ac_failure_telemetry(task_id, task, paircoder_dir, 0, f"Local AC: {local_ac_msg}")
        raise typer.Exit(1)
    return None


def _verify_non_strict_ac(task, task_id):
    """Non-strict AC — warns but proceeds."""
    unchecked_ac = task.unchecked_ac if task else []
    if unchecked_ac:
        console.print(f"[yellow]⚠ Completing with {len(unchecked_ac)} unchecked AC item(s)[/yellow]")
        log_bypass("task update --no-strict", task_id, f"{len(unchecked_ac)} unchecked AC items")
        return "partial"
    return None


def _report_unchecked_ac(unchecked_ac, task_id, auto_check):
    """Print unchecked AC items and remediation options."""
    console.print(f"\n[red]❌ Cannot complete: {len(unchecked_ac)} acceptance criteria item(s) unchecked[/red]")
    console.print("\n[dim]Unchecked items:[/dim]")
    for ac in unchecked_ac:
        console.print(f"  ○ {ac.text}")
    console.print("\n[dim]Options:[/dim]")
    console.print(f"  1. Check items: [cyan]bpsai-pair task check {task_id} \"<item text>\"[/cyan]")
    console.print(f"  2. Check all:   [cyan]bpsai-pair task update {task_id} --status done --auto-check[/cyan]")
    console.print("  3. Edit task file directly")
    if auto_check:
        console.print("\n[yellow]Note: --auto-check ran but some items could not be matched.[/yellow]")


def _record_ac_failure_telemetry(task_id, task, paircoder_dir, unchecked_count, context=None):
    """Record AC failure to telemetry (best-effort)."""
    try:
        from .status_hooks import _collect_task_telemetry
        from ..telemetry.schema import Outcome as _O
        error_msg = context or f"AC verification failed: {unchecked_count} unchecked items"
        _collect_task_telemetry(task_id, task, paircoder_dir, outcome=_O.FAIL, error_context=error_msg)
    except Exception as e:
        logger.debug("Failed to record AC failure telemetry: %s", e)


def apply_status_update(
    task_parser, plan_parser, task_id: str, status: str,
    old_status: str, plan_slug, task, paircoder_dir: Path,
    no_hooks: bool, task_outcome: Optional[str],
) -> None:
    """Write status, fire hooks, update state machine and plan."""
    success = task_parser.update_status(task_id, status, plan_slug)
    if not success:
        console.print(f"[red]Failed to update task: {task_id}[/red]")
        raise typer.Exit(1)

    # Log state transition to SQLite (best-effort, non-blocking)
    if old_status != status:
        _log_transition(paircoder_dir, task_id, old_status, status, task)

    emoji_map = {
        "pending": "\u23f3", "in_progress": "\U0001f504",
        "review": "\U0001f50d", "done": "\u2705",
        "blocked": "\U0001f6ab", "cancelled": "\u274c",
    }
    check = "\u2713"
    console.print(f"{emoji_map.get(status, check)} Updated {task_id} -> {status}")

    _record_cli_cache(paircoder_dir, task_id, status)

    if not no_hooks and old_status != status:
        from ..telemetry.schema import Outcome as _Outcome
        _outcome = _Outcome.PARTIAL if task_outcome == "partial" else None
        run_status_hooks(paircoder_dir, task_id, status, task, outcome=_outcome)

    if status == "done":
        # Fresh license validation at task completion boundary (issue #106)
        try:
            logger.info("Running task boundary validation for %s", task_id)
            from ..licensing.startup import run_task_boundary_validation
            run_task_boundary_validation()
        except Exception as e:
            logger.warning("Task boundary validation failed for %s (non-blocking): %s", task_id, e)

        complete_ok, complete_msg = complete_task_with_state_machine(task_id, trigger="task_update")
        if not complete_ok:
            console.print(f"[yellow]⚠ State machine: {complete_msg}[/yellow]")

    if task.plan_id and old_status != status:
        plan_updated = plan_parser.check_and_update_plan_status(task.plan_id, paircoder_dir / "tasks")
        if plan_updated:
            plan = plan_parser.get_plan_by_id(task.plan_id)
            if plan:
                console.print(f"  → Plan {plan.id} is now {plan.status.value}")


def _log_transition(paircoder_dir, task_id, old_status, status, task):
    """Log task state transition to SQLite (best-effort)."""
    try:
        from ..telemetry.task_state_log import log_task_state_transition

        log_task_state_transition(
            paircoder_dir, task_id, old_status, status,
            plan_id=task.plan_id if task else None,
            metadata={"trigger": "task_update"},
        )
    except Exception as e:
        logger.debug("Failed to log task state transition: %s", e)


def _record_cli_cache(paircoder_dir, task_id, status):
    """Record CLI update to cache for manual edit detection."""
    from .cli_update_cache import get_cli_update_cache
    cli_cache = get_cli_update_cache(paircoder_dir)
    cli_cache.record_update(task_id, status)
