"""Task file parser (.task.md).

Handles parsing, saving, and status management for task markdown files
with YAML frontmatter.
"""
import re
from datetime import datetime
from pathlib import Path
from typing import List, Optional, Tuple

import yaml

from .models import Task

# Regex to match YAML frontmatter (content between --- delimiters)
FRONTMATTER_PATTERN = re.compile(
    r"^---\s*\n(.*?)\n---\s*\n?(.*)$",
    re.DOTALL
)


def parse_frontmatter(content: str) -> Tuple[dict, str]:
    """Parse YAML frontmatter from a document.

    Returns (frontmatter_dict, body_content). If no frontmatter, returns ({}, full_content).
    """
    match = FRONTMATTER_PATTERN.match(content)
    if match:
        frontmatter_str = match.group(1)
        body = match.group(2).strip()
        try:
            frontmatter = yaml.safe_load(frontmatter_str) or {}
        except yaml.YAMLError:
            frontmatter = {}
        return frontmatter, body
    return {}, content


class TaskParser:
    """Parser for task files (.task.md) with YAML frontmatter + Markdown body."""

    def __init__(self, tasks_dir: Path):
        """Initialize parser with tasks directory path."""
        self.tasks_dir = Path(tasks_dir)

    def list_tasks(self, plan_slug: Optional[str] = None) -> List[Path]:
        """List task files, optionally filtered by plan slug."""
        if not self.tasks_dir.exists():
            return []

        # Flat storage + subdirectories for backwards compatibility
        all_tasks = list(self.tasks_dir.glob("*.task.md"))
        for subdir in self.tasks_dir.iterdir():
            if subdir.is_dir():
                all_tasks.extend(subdir.glob("*.task.md"))

        all_tasks = sorted(set(all_tasks))

        if plan_slug:
            filtered = []
            for task_path in all_tasks:
                task = self.parse(task_path)
                if task and task.plan_id and plan_slug in task.plan_id:
                    filtered.append(task_path)
            return filtered

        return all_tasks

    def parse(self, task_path: Path) -> Optional[Task]:
        """Parse a single task file. Returns Task or None on failure."""
        try:
            with open(task_path, "r", encoding="utf-8") as f:
                content = f.read()
            frontmatter, body = parse_frontmatter(content)
            if not frontmatter:
                return None
            return Task.from_dict(frontmatter, body=body, source_path=task_path)
        except OSError as e:
            print(f"Error parsing task {task_path}: {e}")
            return None

    def parse_all(self, plan_slug: Optional[str] = None) -> list[Task]:
        """Parse all tasks, optionally filtered by plan slug."""
        tasks = []
        for task_path in self.list_tasks(plan_slug):
            task = self.parse(task_path)
            if task:
                tasks.append(task)
        return tasks

    def get_task_by_id(self, task_id: str, plan_slug: Optional[str] = None) -> Optional[Task]:
        """Find and parse a task by its ID."""
        for task in self.parse_all(plan_slug):
            if task.id == task_id:
                return task
        return None

    def get_tasks_for_plan(self, plan_id: str) -> list[Task]:
        """Get all tasks belonging to a specific plan (by plan_id field)."""
        return [t for t in self.parse_all() if t.plan_id == plan_id]

    def save(self, task: Task, _plan_slug: Optional[str] = None) -> Path:
        """Save a task to a Markdown file with YAML frontmatter."""
        self.tasks_dir.mkdir(parents=True, exist_ok=True)
        task_path = self.tasks_dir / f"{task.id}.task.md"

        frontmatter = task.to_dict()

        content = "---\n"
        content += yaml.dump(
            frontmatter,
            default_flow_style=False,
            allow_unicode=True,
            sort_keys=False,
        )
        content += "---\n\n"
        content += task.body if task.body else self._generate_default_body(task)

        with open(task_path, "w", encoding="utf-8") as f:
            f.write(content)

        task.source_path = task_path
        return task_path

    def _generate_default_body(self, task: Task) -> str:
        """Generate default Markdown body for a new task."""
        body = f"# Objective\n\n{task.description or task.title}\n\n"
        body += "# Implementation Plan\n\n- TODO: Add implementation steps\n\n"
        body += "# Acceptance Criteria\n\n- [ ] TODO: Add acceptance criteria\n\n"
        body += "# Verification\n\n- TODO: Add verification steps\n"
        return body

    def update_status(self, task_id: str, status: str, plan_slug: Optional[str] = None) -> bool:
        """Update a task's status. Sets completed_at when status is 'done'."""
        task = self.get_task_by_id(task_id, plan_slug)
        if not task or not task.source_path:
            return False

        with open(task.source_path, "r", encoding="utf-8") as f:
            content = f.read()

        frontmatter, body = parse_frontmatter(content)
        frontmatter["status"] = status

        if status == "done" and "completed_at" not in frontmatter:
            frontmatter["completed_at"] = datetime.now().isoformat()

        new_content = "---\n"
        new_content += yaml.dump(
            frontmatter,
            default_flow_style=False,
            allow_unicode=True,
            sort_keys=False,
        )
        new_content += "---\n\n"
        new_content += body

        with open(task.source_path, "w", encoding="utf-8") as f:
            f.write(new_content)

        return True

    def update_ac_item(
        self, task_id: str, item_text: str, checked: bool,
        plan_slug: Optional[str] = None,
    ) -> bool:
        """Update a specific acceptance criteria item's checked state."""
        task = self.get_task_by_id(task_id, plan_slug)
        if not task or not task.source_path:
            return False

        with open(task.source_path, "r", encoding="utf-8") as f:
            content = f.read()

        pattern = re.compile(
            rf'^([-*]\s+\[)[ xX](\]\s+.*{re.escape(item_text)}.*?)$',
            re.MULTILINE | re.IGNORECASE
        )

        new_check = "x" if checked else " "
        new_content, count = pattern.subn(rf'\g<1>{new_check}\2', content, count=1)

        if count == 0:
            return False

        with open(task.source_path, "w", encoding="utf-8") as f:
            f.write(new_content)

        return True

    def check_all_ac_items(self, task_id: str, plan_slug: Optional[str] = None) -> int:
        """Check all acceptance criteria items for a task. Returns count checked."""
        task = self.get_task_by_id(task_id, plan_slug)
        if not task or not task.source_path:
            return 0

        with open(task.source_path, "r", encoding="utf-8") as f:
            content = f.read()

        pattern = re.compile(r'^([-*]\s+\[) (\].+)$', re.MULTILINE)
        new_content, count = pattern.subn(r'\1x\2', content)

        if count > 0:
            with open(task.source_path, "w", encoding="utf-8") as f:
                f.write(new_content)

        return count


def parse_task(task_path: Path) -> Optional[Task]:
    """Parse a single task file (convenience function)."""
    parent = task_path.parent
    if parent.name == "tasks":
        tasks_dir = parent
    elif parent.parent.name == "tasks":
        tasks_dir = parent.parent
    else:
        tasks_dir = parent

    parser = TaskParser(tasks_dir)
    return parser.parse(task_path)
