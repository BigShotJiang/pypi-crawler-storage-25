"""Task CLI commands.

Commands for managing tasks (list, show, update, archive, etc.).
"""

from typing import Optional
import json

import typer
from rich.table import Table

from .models import Task, TaskStatus
from .parser import PlanParser, TaskParser
from .helpers import (
    console,
    find_paircoder_dir,
    get_state_manager,
    is_trello_enabled,
    get_linked_trello_card,
    log_bypass,
    check_for_manual_edits,
    show_time_tracking,
)
from .completion_helpers import (
    check_state_md_updated,
    sync_local_ac_for_completion,
    complete_task_with_state_machine,
)
from .status_hooks import run_status_hooks

# Enforcement gates (extracted for arch compliance)
from .task_update_enforcement import (
    enforce_clean_git_tree,
    enforce_local_only_block,
    enforce_no_hooks_block,
    enforce_trello_card_redirect,
    enforce_skip_state_check_block,
    enforce_local_only_reason,
)

# Completion logic (extracted for arch compliance)
from .task_update_completion import (
    check_state_md_gate,
    verify_acceptance_criteria,
    apply_status_update,
)

# Import archive commands from extracted module
from .task_archive_commands import (
    task_archive,
    task_restore,
    task_list_archived,
    task_cleanup,
    task_changelog_preview,
)

# Import check commands from extracted module
from .task_check_commands import task_check, task_ac

task_app = typer.Typer(
    help="Manage tasks",
    context_settings={"help_option_names": ["-h", "--help"]}
)


@task_app.command("list")
def task_list(
    plan_id: Optional[str] = typer.Option(None, "--plan", "-p", help="Filter by plan ID"),
    status: Optional[str] = typer.Option(
        None, "--status", "-s",
        help="Filter: pending|in_progress|review|done|blocked"
    ),
    json_out: bool = typer.Option(False, "--json", help="Output as JSON"),
):
    """List tasks."""
    paircoder_dir = find_paircoder_dir()
    task_parser = TaskParser(paircoder_dir / "tasks")
    plan_parser = PlanParser(paircoder_dir / "plans")
    plan_slug = None
    if plan_id:
        plan = plan_parser.get_plan_by_id(plan_id)
        if plan:
            plan_slug = plan.slug
    tasks = task_parser.parse_all(plan_slug)
    if status:
        tasks = [t for t in tasks if t.status.value == status]
    if json_out:
        from ..json_envelope import wrap_ok, print_envelope
        print_envelope(wrap_ok([t.to_dict() for t in tasks]))
        return
    if not tasks:
        console.print("[dim]No tasks found.[/dim]")
        return
    _show_manual_edit_warnings(paircoder_dir, tasks)
    _print_task_table(tasks)


def _show_manual_edit_warnings(paircoder_dir, tasks):
    """Display warnings for tasks edited outside CLI."""
    manual_edits = check_for_manual_edits(paircoder_dir, tasks)
    if manual_edits:
        console.print()
        for edit in manual_edits:
            console.print(f"[yellow]⚠️  Warning: {edit['task_id']} status changed outside CLI (hooks may not have fired)[/yellow]")
            console.print(f"   [dim]File status: {edit['current_status']} | Last CLI status: {edit['last_cli_status']}[/dim]")
            console.print(f"   [dim]To sync: bpsai-pair task update {edit['task_id']} --resync[/dim]")
        console.print()


def _print_task_table(tasks):
    """Render task list as a Rich table."""
    table = Table(title=f"Tasks ({len(tasks)})")
    table.add_column("Status", width=3)
    table.add_column("ID", style="cyan")
    table.add_column("Title")
    table.add_column("Plan")
    table.add_column("Priority")
    table.add_column("Complexity", justify="right")
    for task in tasks:
        table.add_row(
            task.status_emoji, task.id,
            task.title[:40] + "..." if len(task.title) > 40 else task.title,
            task.plan_id or "-", task.priority, str(task.complexity),
        )
    console.print(table)


@task_app.command("show")
def task_show(
    task_id: str = typer.Argument(..., help="Task ID"),
    plan_id: Optional[str] = typer.Option(None, "--plan", "-p", help="Plan ID to narrow search"),
):
    """Show details of a specific task."""
    paircoder_dir = find_paircoder_dir()
    task_parser = TaskParser(paircoder_dir / "tasks")
    plan_parser = PlanParser(paircoder_dir / "plans")

    plan_slug = None
    if plan_id:
        plan = plan_parser.get_plan_by_id(plan_id)
        if plan:
            plan_slug = plan.slug

    task = task_parser.get_task_by_id(task_id, plan_slug)

    if not task:
        console.print(f"[red]Task not found: {task_id}[/red]")
        raise typer.Exit(1)

    console.print(f"[bold]{task.status_emoji} {task.id}[/bold]")
    console.print(f"{'=' * 60}")
    console.print(f"[cyan]Title:[/cyan] {task.title}")
    console.print(f"[cyan]Plan:[/cyan] {task.plan_id}")
    console.print(f"[cyan]Type:[/cyan] {task.type}")
    console.print(f"[cyan]Priority:[/cyan] {task.priority}")
    console.print(f"[cyan]Complexity:[/cyan] {task.complexity}")
    console.print(f"[cyan]Status:[/cyan] {task.status.value}")
    console.print(f"[cyan]Est. Tokens:[/cyan] {task.estimated_tokens_str}")

    if task.sprint:
        console.print(f"[cyan]Sprint:[/cyan] {task.sprint}")

    if task.tags:
        console.print(f"[cyan]Tags:[/cyan] {', '.join(task.tags)}")

    # Show estimated vs actual hours
    show_time_tracking(task, paircoder_dir)

    if task.body:
        console.print(f"\n{'-' * 60}")
        console.print(task.body)


@task_app.command("update")
def task_update(
    task_id: str = typer.Argument(..., help="Task ID"),
    status: str = typer.Option(
        None, "--status", "-s",
        help="New status: pending|in_progress|review|done|blocked|cancelled"
    ),
    plan_id: Optional[str] = typer.Option(None, "--plan", "-p", help="Plan ID to narrow search"),
    no_hooks: bool = typer.Option(False, "--no-hooks", help="Skip running hooks"),
    skip_state_check: bool = typer.Option(
        False, "--skip-state-check",
        help="Skip checking if state.md was updated (not recommended)"
    ),
    resync: bool = typer.Option(
        False, "--resync",
        help="Re-trigger hooks for current status (use after manual file edits)"
    ),
    local_only: bool = typer.Option(
        False, "--local-only",
        help="Update local file only, skip Trello sync check (requires --reason)"
    ),
    reason: str = typer.Option(
        "", "--reason",
        help="Reason for local-only update (required with --local-only)"
    ),
    strict: bool = typer.Option(
        True, "--strict/--no-strict",
        help="Block if acceptance criteria unchecked (default: strict)"
    ),
    force_local: bool = typer.Option(
        False, "--force-local",
        help="Bypass Trello card redirect and complete locally (logged for audit)"
    ),
    auto_check: bool = typer.Option(
        False, "--auto-check",
        help="Auto-check all acceptance criteria items before completion"
    ),
    allow_dirty: bool = typer.Option(
        False, "--allow-dirty",
        help="Allow completion with uncommitted changes (logged for audit)"
    ),
):
    """Update a task's status."""
    _run_task_update(
        task_id, status, plan_id, no_hooks, skip_state_check,
        resync, local_only, reason, strict, force_local, auto_check, allow_dirty)


def _run_task_update(
    task_id, status, plan_id, no_hooks, skip_state_check,
    resync, local_only, reason, strict, force_local, auto_check,
    allow_dirty=False,
):
    """Execute task update logic (extracted for arch compliance)."""
    paircoder_dir = find_paircoder_dir()
    is_done = status and status.lower() == "done"
    # Pre-flight enforcement gates (each raises typer.Exit(1) on block)
    if is_done:
        enforce_clean_git_tree(paircoder_dir, allow_dirty=allow_dirty, task_id=task_id)
    if is_done and local_only:
        enforce_local_only_block(paircoder_dir, task_id)
    if is_done and no_hooks:
        enforce_no_hooks_block(paircoder_dir)
    if is_done and not local_only:
        enforce_trello_card_redirect(task_id, force_local)
    if local_only:
        enforce_local_only_reason(task_id, reason)
    task_parser, plan_parser, plan_slug = _resolve_parsers(paircoder_dir, plan_id)
    task = task_parser.get_task_by_id(task_id, plan_slug)
    if not task:
        console.print(f"[red]Task not found: {task_id}[/red]")
        raise typer.Exit(1)
    old_status = task.status.value
    if resync:
        _handle_resync(paircoder_dir, task_id, task, status, old_status, no_hooks)
        return
    if not status:
        console.print("[red]--status is required (or use --resync to re-trigger hooks)[/red]")
        raise typer.Exit(1)
    _task_outcome = None
    if is_done:
        if skip_state_check:
            enforce_skip_state_check_block(paircoder_dir, task_id)
        check_state_md_gate(paircoder_dir, task_id, skip_state_check)
        _task_outcome = verify_acceptance_criteria(
            task, task_parser, task_id, plan_slug, strict, auto_check, paircoder_dir)
    apply_status_update(
        task_parser, plan_parser, task_id, status, old_status,
        plan_slug, task, paircoder_dir, no_hooks, _task_outcome)


def _resolve_parsers(paircoder_dir, plan_id):
    """Create parsers and resolve plan slug."""
    task_parser = TaskParser(paircoder_dir / "tasks")
    plan_parser = PlanParser(paircoder_dir / "plans")
    plan_slug = None
    if plan_id:
        plan = plan_parser.get_plan_by_id(plan_id)
        if plan:
            plan_slug = plan.slug
    return task_parser, plan_parser, plan_slug


def _handle_resync(paircoder_dir, task_id, task, status, old_status, no_hooks):
    """Handle --resync: re-trigger hooks for current file status."""
    if status:
        console.print("[yellow]Warning: --status ignored when using --resync[/yellow]")
    current_status = old_status

    from .cli_update_cache import get_cli_update_cache
    cli_cache = get_cli_update_cache(paircoder_dir)
    cli_cache.record_update(task_id, current_status)

    console.print(f"[cyan]Resyncing {task_id} (status: {current_status})[/cyan]")
    if not no_hooks:
        run_status_hooks(paircoder_dir, task_id, current_status, task)
    console.print(f"[green]✓ Resync complete for {task_id}[/green]")


@task_app.command("next")
def task_next(
    start: bool = typer.Option(False, "--start", "-s", help="Automatically start the next task"),
):
    """Show the next task to work on.

    Use --start to automatically set the task to in_progress.
    """
    state_manager = get_state_manager()
    task = state_manager.get_next_task()

    if not task:
        console.print("[dim]No tasks available. Create a plan first![/dim]")
        return

    # If --start flag, auto-assign the task
    if start and task.status != TaskStatus.IN_PROGRESS:
        from .auto_assign import auto_assign_next

        paircoder_dir = find_paircoder_dir()
        task = auto_assign_next(paircoder_dir, plan_id=task.plan_id)

        if task:
            console.print(f"[green]✓ Auto-started task:[/green] {task.id}")
        else:
            console.print("[red]Failed to auto-start task[/red]")
            return

    console.print(f"[bold]Next task:[/bold] {task.status_emoji} {task.id}")
    console.print(f"[cyan]Title:[/cyan] {task.title}")
    console.print(f"[cyan]Priority:[/cyan] {task.priority} | Complexity: {task.complexity}")

    if task.body:
        # Show first section of body
        lines = task.body.split("\n")
        preview = "\n".join(lines[:10])
        console.print(f"\n{preview}")
        if len(lines) > 10:
            console.print(f"\n[dim]... ({len(lines) - 10} more lines)[/dim]")

    if task.status != TaskStatus.IN_PROGRESS:
        console.print("\n[dim]To start: bpsai-pair task next --start[/dim]")
        console.print(f"[dim]Or: bpsai-pair task update {task.id} --status in_progress[/dim]")


@task_app.command("auto-next")
def task_auto_next(
    plan_id: Optional[str] = typer.Option(None, "--plan", "-p", help="Plan ID to filter tasks"),
):
    """Automatically assign and start the next pending task.

    This command finds the highest-priority pending task and sets it to in_progress.
    Tasks are prioritized by: priority (P0 > P1 > P2), then complexity (lower first).
    """
    from .auto_assign import auto_assign_next

    paircoder_dir = find_paircoder_dir()
    task = auto_assign_next(paircoder_dir, plan_id=plan_id)

    if not task:
        console.print("[yellow]No pending tasks available[/yellow]")
        return

    console.print(f"[green]✓ Auto-assigned:[/green] {task.id}")
    console.print(f"[cyan]Title:[/cyan] {task.title}")
    console.print(f"[cyan]Priority:[/cyan] {task.priority} | Complexity: {task.complexity}")
    console.print(f"[cyan]Status:[/cyan] {task.status_emoji} {task.status.value}")


@task_app.command("done")
def task_done_cmd(
    task_id: str = typer.Argument(..., help="Task ID to mark as done"),
    plan_id: Optional[str] = typer.Option(None, "--plan", "-p", help="Plan ID to narrow search"),
    no_hooks: bool = typer.Option(False, "--no-hooks", help="Skip running hooks"),
):
    """Mark a task as done (updates task file + runs consistency check).

    This is the local-only equivalent of `ttask done`.
    Atomically updates the task file and runs completion hooks.
    """
    from .task_done import execute_task_done

    paircoder_dir = find_paircoder_dir()
    result = execute_task_done(task_id, paircoder_dir, plan_id=plan_id, no_hooks=no_hooks)
    if not result["success"]:
        console.print(f"[red]{result['error']}[/red]")
        raise typer.Exit(1)


# Register check and archive commands from extracted modules
task_app.command("check")(task_check)
task_app.command("ac")(task_ac)
task_app.command("archive")(task_archive)
task_app.command("restore")(task_restore)
task_app.command("list-archived")(task_list_archived)
task_app.command("cleanup")(task_cleanup)
task_app.command("changelog-preview")(task_changelog_preview)
