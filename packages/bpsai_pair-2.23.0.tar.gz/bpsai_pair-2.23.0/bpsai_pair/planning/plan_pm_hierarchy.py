"""Hierarchy-mode sync for PM plan sync.

Extracted from plan_pm_sync.py: handles Epic→child orchestration
via HierarchyOrchestrator with enrichment callbacks.
"""

import logging

from .helpers import console, update_task_with_card_id
from .parser import TaskParser
from .plan_pm_enrich import build_enrich_fn  # noqa: F401 — re-export for callers
from ..pm.orchestration import HierarchyOrchestrator
from ..pm.provider import ProjectManagementProvider
from ..pm.types import PMWorkItem, WorkItemStatus
from ..pm.workflow import WorkflowEngine

logger = logging.getLogger(__name__)

_MAX_TITLE_LEN = 256

_DEFAULT_CHECKLIST = {"epic": "Stories", "story": "Tasks"}


def _resolve_checklist_name(engine: WorkflowEngine, scope: str) -> str:
    """Get checklist name from workflow config, with sensible defaults."""
    try:
        wit_config = engine.config.work_items.get(scope)
        if wit_config and isinstance(wit_config.checklist_name, str):
            return wit_config.checklist_name
    except (AttributeError, KeyError):
        pass
    return _DEFAULT_CHECKLIST.get(scope, "Stories")


def _discover_story_from_epic(
    orchestrator: HierarchyOrchestrator,
    epic_provider_id: str,
    story_title: str,
    fallback_title: str | None = None,
) -> str | None:
    """Discover a Story card from an Epic's checklist via Butler automation.

    Returns the discovered Story's provider_id, or None on failure.
    Falls back to direct creation if discovery fails and fallback_title given.
    """
    result = orchestrator.create_child_via_automation(epic_provider_id, story_title)
    if result.item is not None:
        return result.item.provider_meta.get("provider_id")

    if fallback_title:
        logger.debug("Story discovery failed, falling back to direct creation")
        fb_item = PMWorkItem(
            id="story-fallback", title=fallback_title,
            status=WorkItemStatus.PENDING,
        )
        result = orchestrator.create_child_directly(epic_provider_id, fb_item)
        if result.item is not None:
            return result.item.provider_meta.get("provider_id")

    logger.warning("Story discovery from Epic %s failed: %s", epic_provider_id, result.error)
    return None


def _backfill_story_provider_id(
    plan_id: str, story_provider_id: str, plans_dir,
) -> None:
    """Persist story_provider_id to plan metadata after discovery.

    Non-fatal: if write fails, next sync will re-discover.
    """
    try:
        from .parser import PlanParser
        from pathlib import Path

        if plans_dir is None:
            logger.debug("No plans_dir for backfill — skipping")
            return
        parser = PlanParser(Path(plans_dir))
        plan = parser.get_plan_by_id(plan_id)
        if plan is None:
            logger.debug("Plan %s not found for backfill", plan_id)
            return
        plan.metadata["story_provider_id"] = story_provider_id
        parser.save(plan)
        logger.debug("Backfilled story_provider_id=%s for %s", story_provider_id, plan_id)
    except Exception as exc:
        logger.warning("Story backfill failed for %s: %s", plan_id, exc)


def _checklist_title(task) -> str:
    """Build checklist item title with [ID] prefix."""
    title = task.title[:_MAX_TITLE_LEN] if len(task.title) > _MAX_TITLE_LEN else task.title
    return f"[{task.id}] {title}"


def _collect_tasks_to_sync(
    sprints_tasks: dict, results: dict,
    only_new: bool, check_link,
) -> list:
    """Filter tasks, skipping already-linked ones."""
    tasks_to_sync: list = []
    for sprint_name, sprint_tasks in sorted(sprints_tasks.items()):
        console.print(f"\n  [cyan]{sprint_name}[/cyan]:")
        for task in sprint_tasks:
            if only_new and check_link(task):
                results["cards_skipped"].append({
                    "task_id": task.id, "reason": "already_linked",
                })
                console.print(f"    [dim]⊘[/dim] {task.id}: Already linked (skipped)")
                continue
            tasks_to_sync.append(task)
    return tasks_to_sync


def _populate_checklist(
    tasks: list,
    provider: ProjectManagementProvider,
    parent_id: str,
    checklist_name: str = "Stories",
) -> None:
    """Phase 1: Add all task titles to parent card's checklist."""
    console.print(f"\n  [bold]Phase 1:[/bold] Populating {checklist_name} checklist...")
    for task in tasks:
        title = _checklist_title(task)
        ci_id = provider.add_checklist_item(parent_id, checklist_name, title)
        if ci_id:
            console.print(f"    [dim]+[/dim] {title}")
        else:
            console.print(f"    [red]✗[/red] Failed to add: {title}")


def _move_card_to_ready(
    provider: ProjectManagementProvider, parent_id: str,
) -> None:
    """Phase 2: Move parent card to Planned/Ready so Butler can trigger."""
    console.print(f"\n  [bold]Phase 2:[/bold] Moving card to Planned/Ready...")
    moved = provider.move_item(parent_id, WorkItemStatus.ENQUEUED)
    if not moved:
        moved = provider.move_to_destination(parent_id, "Planned/Ready")
    if moved:
        console.print(f"    [green]✓[/green] Card moved to Planned/Ready")
    else:
        console.print(f"    [yellow]⚠[/yellow] Could not move card — Butler may not trigger")


def _resolve_ac_checklist_name(engine: WorkflowEngine, pm_scope: str) -> str | None:
    """Resolve the AC checklist name for child cards of a given scope."""
    try:
        parent_config = engine.get_work_item_config(pm_scope)
        if parent_config and parent_config.children_type:
            child_config = engine.get_work_item_config(parent_config.children_type)
            if child_config:
                return child_config.ac_checklist_name
    except (AttributeError, KeyError):
        pass
    return None


def sync_via_hierarchy(
    sprints_tasks: dict,
    results: dict,
    task_parser: TaskParser,
    link_cards: bool,
    *,
    orchestrator: HierarchyOrchestrator,
    epic_provider_id: str,
    provider: ProjectManagementProvider,
    only_new: bool = False,
    task_has_provider_link=None,
    pm_scope: str = "epic",
    checklist_name: str = "Stories",
) -> None:
    """Sync tasks via hierarchy orchestration.

    Flow:
      1. Populate the parent card's checklist with all task titles
      2. Move parent card to Planned/Ready
      3. For each task: check → discover → enrich → link → populate AC
    """
    from .plan_pm_sync import _task_has_provider_link as _default_link_check
    check_link = task_has_provider_link or _default_link_check

    tasks_to_sync = _collect_tasks_to_sync(sprints_tasks, results, only_new, check_link)
    if not tasks_to_sync:
        return

    parent_id = epic_provider_id
    _populate_checklist(tasks_to_sync, provider, parent_id, checklist_name)
    _move_card_to_ready(provider, parent_id)

    ac_cl_name = _resolve_ac_checklist_name(orchestrator._engine, pm_scope)

    console.print(f"\n  [bold]Phase 3:[/bold] Creating child cards via automation...")
    for task in tasks_to_sync:
        title = _checklist_title(task)
        _sync_single_task_hierarchy(
            task, title, orchestrator, results, task_parser, link_cards,
            epic_provider_id=parent_id, provider=provider,
            ac_checklist_name=ac_cl_name,
        )


def _populate_ac_checklist(
    provider: ProjectManagementProvider,
    card_id: str,
    task,
    ac_checklist_name: str,
) -> None:
    """Populate a task card's Acceptance Criteria checklist from task markdown."""
    ac_items = task.acceptance_criteria
    if not ac_items:
        return
    # Skip placeholder AC
    if len(ac_items) == 1 and "TODO" in ac_items[0].text:
        return
    for ac in ac_items:
        try:
            provider.add_checklist_item(card_id, ac_checklist_name, ac.text)
        except Exception as exc:
            logger.debug("Failed to add AC item '%s': %s", ac.text, exc)


def _sync_single_task_hierarchy(
    task, checklist_title: str,
    orchestrator: HierarchyOrchestrator, results: dict,
    task_parser: TaskParser, link_cards: bool,
    *, epic_provider_id: str, provider: ProjectManagementProvider,
    ac_checklist_name: str | None = None,
) -> None:
    """Sync one task: check checklist item -> discover -> enrich -> link -> populate AC."""
    try:
        result = orchestrator.create_child_via_automation(
            epic_provider_id, checklist_title,
        )

        if result.error:
            logger.debug(
                "Automation failed for %s: %s — falling back to direct creation",
                task.id, result.error,
            )
            work_item = PMWorkItem.from_task(task)
            result = orchestrator.create_child_directly(
                epic_provider_id, work_item,
            )

        if result.item is not None:
            card_id = result.item.provider_meta.get("provider_id", "")
            results["cards_created"].append({
                "task_id": task.id, "card_id": card_id,
            })
            console.print(f"    [green]+[/green] {task.id}: {task.title}")
            if link_cards and card_id:
                update_task_with_card_id(task, card_id, task_parser)
            if card_id and ac_checklist_name:
                _populate_ac_checklist(provider, card_id, task, ac_checklist_name)
        else:
            error_msg = result.error or "Unknown error"
            results["errors"].append(f"{task.id}: {error_msg}")
            console.print(f"    [red]✗[/red] {task.id}: {error_msg}")

    except Exception as e:
        logger.debug("Failed to sync task %s via hierarchy: %s", task.id, e)
        results["errors"].append(f"{task.id}: sync failed")
        console.print(f"    [red]✗[/red] {task.id}: sync failed")
