"""Intelligence integration for plan creation."""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

from rich.console import Console

from bpsai_pair.licensing.core import has_feature_api
from bpsai_pair.planning.intelligence_helpers import _complexity_to_label, _compute_confidence

logger = logging.getLogger(__name__)
console = Console()


def get_feedback_service(project_root: Path) -> Any:
    """Initialize FeedbackService, returning None on failure."""
    try:
        from bpsai_pair.feedback.service import FeedbackService

        return FeedbackService(project_root)
    except Exception as e:
        logger.warning("FeedbackService unavailable: %s", e)
        return None


def get_task_intelligence(
    feedback_service: Any,
    task_type: str,
    complexity: int,
) -> dict[str, Any]:
    """Get intelligence estimates for a task.

    Returns dict with token_estimate, model_recommendation, effort_level,
    confidence info. Returns defaults on failure.
    """
    defaults: dict[str, Any] = {
        "available": False,
        "token_estimate": None,
        "model_recommendation": "sonnet",
        "effort_level": "medium",
        "confidence": "none",
        "based_on": 0,
    }

    if feedback_service is None:
        return defaults

    try:
        token_data = feedback_service.estimate_tokens(task_type)
        label = _complexity_to_label(complexity)
        model_rec = feedback_service.get_model_recommendation(task_type, label)
        effort_rec = feedback_service.get_effort_recommendation(task_type, complexity)
        status = feedback_service.get_calibration_status()
        total_records = status.get("total_records", 0)

        return {
            "available": True,
            "token_estimate": token_data,
            "model_recommendation": model_rec,
            "effort_level": effort_rec,
            "confidence": _compute_confidence(total_records),
            "based_on": total_records,
        }
    except Exception as e:
        logger.warning("Failed to get task intelligence: %s", e)
        return defaults


def format_task_intelligence(intel: dict[str, Any]) -> str:
    """Format intelligence data for display."""
    if not intel.get("available"):
        return "No historical data available, using defaults"

    parts = []

    token_data = intel.get("token_estimate") or {}
    avg = token_data.get("avg", 0)
    if avg:
        parts.append(f"~{avg:,} tokens")

    model = intel.get("model_recommendation", "sonnet")
    parts.append(model.capitalize())

    effort = intel.get("effort_level", "medium")
    parts.append(f"{effort.capitalize()} effort")

    line = ", ".join(parts)

    confidence = intel.get("confidence", "none")
    based_on = intel.get("based_on", 0)
    if confidence != "none":
        line += f" ({confidence} confidence, based on {based_on} tasks)"

    return line


def format_plan_intelligence_summary(
    feedback_service: Any,
    tasks: list[dict[str, Any]],
) -> list[str]:
    """Generate intelligence summary lines for a plan."""
    if feedback_service is None:
        return ["No historical data available, using default estimates"]

    try:
        total_tokens = 0
        models_used: set[str] = set()
        efforts: list[str] = []

        for task_info in tasks:
            intel = get_task_intelligence(
                feedback_service,
                task_info.get("task_type", "feature"),
                task_info.get("complexity", 50),
            )
            if intel["available"]:
                token_data = intel.get("token_estimate") or {}
                total_tokens += token_data.get("avg", 0)
                models_used.add(intel["model_recommendation"])
                efforts.append(intel["effort_level"])

        if total_tokens == 0:
            return ["No historical data available, using default estimates"]

        status = feedback_service.get_calibration_status()
        total_records = status.get("total_records", 0)
        confidence = _compute_confidence(total_records)

        lines = [
            f"Estimated tokens: ~{total_tokens:,} (based on {len(tasks)} tasks)",
            f"Recommended model(s): {', '.join(sorted(m.capitalize() for m in models_used))}",
            f"Confidence: {confidence.capitalize()} (based on {total_records} historical tasks)",
        ]
        return lines
    except Exception as e:
        logger.warning("Failed to generate plan intelligence summary: %s", e)
        return ["Intelligence summary unavailable"]


def is_intelligence_enabled(paircoder_dir: Path) -> bool:
    """Check if intelligence estimates are enabled in config."""
    config_path = paircoder_dir / "config.yaml"
    if not config_path.exists():
        return True

    try:
        import yaml

        config = yaml.safe_load(config_path.read_text(encoding="utf-8")) or {}
        feedback_config = config.get("feedback", {})
        return feedback_config.get("enabled", True)
    except Exception:
        return True


def display_task_intelligence(
    paircoder_dir: Path,
    task_type: str,
    complexity: int,
) -> None:
    """Display intelligence estimate after adding a task."""
    if not has_feature_api("feedback"):
        return
    if not is_intelligence_enabled(paircoder_dir):
        return

    project_root = paircoder_dir.parent
    svc = get_feedback_service(project_root)
    intel = get_task_intelligence(svc, task_type, complexity)
    line = format_task_intelligence(intel)
    console.print(f"  [dim]Intelligence: {line}[/dim]")


def display_plan_intelligence(
    paircoder_dir: Path,
    tasks: list[Any],
) -> None:
    """Display intelligence summary for a plan's tasks."""
    if not has_feature_api("feedback"):
        return
    if not is_intelligence_enabled(paircoder_dir):
        return
    if not tasks:
        return

    project_root = paircoder_dir.parent
    svc = get_feedback_service(project_root)
    task_dicts = [
        {"task_type": getattr(t, "type", "feature"), "complexity": getattr(t, "complexity", 50)}
        for t in tasks
    ]
    lines = format_plan_intelligence_summary(svc, task_dicts)

    console.print("\n[cyan]Intelligence Summary:[/cyan]")
    for line in lines:
        console.print(f"  {line}")
