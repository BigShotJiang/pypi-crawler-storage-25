"""Review intent sub-classification.

Extends the intent engine's ``WorkIntent.REVIEW`` to distinguish
between task review, pre-PR review, PR review, and ambiguous.

This module is standalone: it has no dependencies on the broader
intent-gate pipeline and can be imported independently by the
``review auto`` CLI command for lightweight sub-routing.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from enum import Enum
from typing import Optional


class ReviewSubIntent(Enum):
    """Sub-classification of a REVIEW intent."""

    PR_REVIEW = "pr_review"
    TASK_REVIEW = "task_review"
    PRE_PR_REVIEW = "pre_pr_review"
    REVIEW_AMBIGUOUS = "review_ambiguous"


@dataclass
class ReviewSubIntentResult:
    """Result of review sub-intent classification."""

    sub_intent: ReviewSubIntent
    pr_number: int | None = None
    task_id: str | None = None


# Task ID pattern: T{sprint}.{seq} or TASK-{num}
_TASK_ID_RE = re.compile(r"\b(T\d+\.\d+|TASK-\d+)\b", re.IGNORECASE)

# PR number patterns: bare number, #number, PR number
_PR_NUMBER_RE = re.compile(
    r"(?:(?:PR|pr)\s*#?\s*(\d+))|(?:#(\d+))|(?:review\s+(\d+))",
)

# Pre-PR keywords
_PRE_PR_KEYWORDS = re.compile(
    r"\b(branch|ready\s+to\s+merge|before\s+merge|pre[- ]?pr)\b",
    re.IGNORECASE,
)


def classify_review_subintent(text: str) -> ReviewSubIntentResult:
    """Classify review-related text into a sub-intent.

    Priority: PR number > task ID > pre-PR keywords > ambiguous.
    """
    # Check for PR number
    pr_match = _PR_NUMBER_RE.search(text)
    if pr_match:
        number = int(next(g for g in pr_match.groups() if g is not None))
        return ReviewSubIntentResult(
            sub_intent=ReviewSubIntent.PR_REVIEW,
            pr_number=number,
        )

    # Check for task ID
    task_match = _TASK_ID_RE.search(text)
    if task_match:
        return ReviewSubIntentResult(
            sub_intent=ReviewSubIntent.TASK_REVIEW,
            task_id=task_match.group(1),
        )

    # Check for pre-PR keywords
    if _PRE_PR_KEYWORDS.search(text):
        return ReviewSubIntentResult(
            sub_intent=ReviewSubIntent.PRE_PR_REVIEW,
        )

    return ReviewSubIntentResult(sub_intent=ReviewSubIntent.REVIEW_AMBIGUOUS)


def route_review_subintent(
    result: ReviewSubIntentResult,
) -> list[str] | None:
    """Map a sub-intent result to a CLI command list.

    Returns None for ambiguous (caller should ask the user).
    """
    if result.sub_intent == ReviewSubIntent.PR_REVIEW and result.pr_number:
        return ["review", "pr", str(result.pr_number)]

    if result.sub_intent == ReviewSubIntent.TASK_REVIEW and result.task_id:
        return ["review", "task", result.task_id]

    if result.sub_intent == ReviewSubIntent.PRE_PR_REVIEW:
        return ["review", "branch"]

    return None
