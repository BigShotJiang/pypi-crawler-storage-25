"""PM-routed plan sync — delegates to PMSyncManager or HierarchyOrchestrator."""

import json
import logging

from typing import TYPE_CHECKING

from .helpers import console, update_task_with_card_id
from .parser import TaskParser
from ..pm.compat import load_pm_config
from ..pm.orchestration import HierarchyOrchestrator
from ..pm.provider import ProjectManagementProvider
from ..pm.sync import PMSyncManager
from ..pm.types import PMRelationship, PMWorkItem, RelationshipType, SyncAction, WorkItemStatus, WorkItemType
from ..pm.workflow import WorkflowEngine

if TYPE_CHECKING:
    from .plan_model import Plan

logger = logging.getLogger(__name__)


def create_plan_pm_card(
    plan: "Plan",
    provider: ProjectManagementProvider,
    scope: str = "epic",
    parent_epic_id: str | None = None,
) -> str | None:
    """Create an Epic or Story work item based on scope.

    When scope is "story" and parent_epic_id is set, skip card creation —
    Butler will create the Story when the checklist item is checked.

    Returns the card's provider_id on success, None otherwise.
    """
    if provider.name == "none":
        return None
    if "hierarchy" not in provider.capabilities():
        return None

    if scope == "story" and parent_epic_id:
        return None  # Butler creates the Story card during sync

    item_type = WorkItemType.STORY if scope == "story" else WorkItemType.EPIC
    work_item = PMWorkItem(
        id=plan.id,
        title=plan.title,
        item_type=item_type,
        status=WorkItemStatus.PENDING,
    )
    result = provider.create_item(work_item)
    if result is None:
        return None
    card_id = result.provider_meta.get("provider_id") or None
    if card_id and scope == "story":
        try:
            enrich_story_card(provider, card_id)
        except Exception as exc:
            logger.debug("Story enrichment failed: %s", exc)
    return card_id


from .plan_pm_enrich import enrich_story_card  # noqa: F401 — re-export


def link_story_to_parent_epic(
    provider: ProjectManagementProvider,
    parent_epic_id: str,
    story_card_id: str | None,
    plan_title: str,
    sprint_id: str | None = None,
) -> None:
    """Add a Story to the parent Epic's Stories checklist and move Epic.

    When story_card_id is present, also sets the parent-child relationship.
    When None (Butler will create the card), defers relationship to sync.
    Non-fatal: failures are logged but do not raise.
    """
    title = f"[{sprint_id}] {plan_title}" if sprint_id else plan_title
    try:
        provider.add_checklist_item(parent_epic_id, "Stories", title)
    except Exception as exc:
        logger.warning("Failed to add Story to Epic checklist: %s", exc)

    if story_card_id:
        try:
            provider.set_relationship(PMRelationship(
                source_id=parent_epic_id,
                target_id=story_card_id,
                relationship_type=RelationshipType.PARENT_CHILD,
            ))
        except Exception as exc:
            logger.warning("Failed to set Epic-Story relationship: %s", exc)

    try:
        moved = provider.move_item(parent_epic_id, WorkItemStatus.ENQUEUED)
        if not moved:
            moved = provider.move_to_destination(parent_epic_id, "Planned/Ready")
        if moved:
            logger.debug("Epic %s moved to Planned/Ready", parent_epic_id)
    except Exception as exc:
        logger.warning("Failed to move Epic to Planned/Ready: %s", exc)


def create_plan_epic(
    plan: "Plan",
    provider: ProjectManagementProvider,
) -> str | None:
    """Backward-compat alias for create_plan_pm_card with scope=epic."""
    return create_plan_pm_card(plan, provider, scope="epic")


def _resolve_parent_id(
    pm_scope: str, epic_provider_id: str | None, story_provider_id: str | None,
) -> str | None:
    """Select parent card ID based on scope."""
    if pm_scope == "story" and story_provider_id:
        return story_provider_id
    return epic_provider_id


def _needs_two_level(pm_scope, story_provider_id, epic_provider_id, has_hierarchy):
    """Detect two-level orchestration case."""
    return (
        pm_scope == "story" and not story_provider_id
        and epic_provider_id and has_hierarchy
    )


def sync_plan_via_pm(
    plan_id: str,
    sprints_tasks: dict,
    results: dict,
    full_config: dict,
    task_parser: TaskParser,
    link_cards: bool,
    json_out: bool,
    provider: ProjectManagementProvider | None = None,
    only_new: bool = False,
    epic_provider_id: str | None = None,
    pm_scope: str = "epic",
    story_provider_id: str | None = None,
    plan_title: str | None = None,
) -> None:
    """Sync tasks through the PM abstraction layer."""
    if provider is None:
        from ..pm.registry import get_active_provider
        provider = get_active_provider(full_config)
    _, wf_config = load_pm_config(full_config)
    engine = WorkflowEngine(wf_config)

    console.print(f"\n[bold]Syncing plan:[/bold] {plan_id}")
    console.print(f"[bold]Provider:[/bold] {provider.name}")

    has_hierarchy = "hierarchy" in provider.capabilities()

    if _needs_two_level(pm_scope, story_provider_id, epic_provider_id, has_hierarchy):
        _sync_via_two_level(
            sprints_tasks, results, task_parser, link_cards,
            provider=provider, engine=engine, full_config=full_config,
            epic_provider_id=epic_provider_id, only_new=only_new,
            plan_id=plan_id, plans_dir=None, plan_title=plan_title,
        )
    elif _resolve_parent_id(pm_scope, epic_provider_id, story_provider_id) and has_hierarchy:
        parent_id = _resolve_parent_id(pm_scope, epic_provider_id, story_provider_id)
        _sync_via_hierarchy_path(
            sprints_tasks, results, task_parser, link_cards,
            provider=provider, engine=engine, full_config=full_config,
            parent_id=parent_id, pm_scope=pm_scope, only_new=only_new,
        )
    else:
        _sync_via_manager(
            sprints_tasks, results, task_parser, link_cards,
            sync_mgr=PMSyncManager(provider, engine),
            epic_provider_id=epic_provider_id,
            provider=provider, only_new=only_new,
        )

    _print_summary(results, json_out)


def _sync_via_two_level(
    sprints_tasks, results, task_parser, link_cards,
    *, provider, engine, full_config, epic_provider_id, only_new,
    plan_id=None, plans_dir=None, plan_title=None,
) -> None:
    """Two-level orchestration: Epic→Story→Tasks.

    1. Discover Story from Epic's checklist (Butler creates it)
    2. Backfill story_provider_id to plan metadata
    3. Sync tasks to discovered Story's Tasks checklist
    """
    from .plan_pm_hierarchy import (
        _backfill_story_provider_id, _discover_story_from_epic,
        _resolve_checklist_name, build_enrich_fn, sync_via_hierarchy,
    )

    if not plan_title:
        plan_title = "Story"
    console.print(f"\n  [bold]Level 1:[/bold] Discovering Story from Epic...")
    enrich_fn = build_enrich_fn(provider, engine, full_config)
    orchestrator = HierarchyOrchestrator(provider, engine, enrich_fn=enrich_fn)
    story_id = _discover_story_from_epic(orchestrator, epic_provider_id, plan_title)

    if not story_id:
        console.print("    [red]✗[/red] Story discovery failed — cannot sync tasks")
        results["errors"].append("Story discovery from Epic failed")
        return

    console.print(f"    [green]✓[/green] Story discovered: {story_id}")
    _backfill_story_provider_id(plan_id, story_id, plans_dir)

    console.print(f"\n  [bold]Level 2:[/bold] Syncing tasks to Story...")
    checklist_name = _resolve_checklist_name(engine, "story")
    sync_via_hierarchy(
        sprints_tasks, results, task_parser, link_cards,
        orchestrator=orchestrator, epic_provider_id=story_id,
        provider=provider, only_new=only_new,
        pm_scope="story", checklist_name=checklist_name,
    )


def _sync_via_hierarchy_path(
    sprints_tasks, results, task_parser, link_cards,
    *, provider, engine, full_config, parent_id, pm_scope, only_new,
) -> None:
    """Route sync through HierarchyOrchestrator."""
    from .plan_pm_hierarchy import build_enrich_fn, sync_via_hierarchy, _resolve_checklist_name

    enrich_fn = build_enrich_fn(provider, engine, full_config)
    orchestrator = HierarchyOrchestrator(provider, engine, enrich_fn=enrich_fn)
    checklist_name = _resolve_checklist_name(engine, pm_scope)
    sync_via_hierarchy(
        sprints_tasks, results, task_parser, link_cards,
        orchestrator=orchestrator, epic_provider_id=parent_id,
        provider=provider, only_new=only_new,
        pm_scope=pm_scope, checklist_name=checklist_name,
    )


def _task_has_provider_link(task) -> bool:
    """Check if a task already has a provider card ID linked."""
    from .helpers import get_linked_trello_card
    return bool(get_linked_trello_card(task.id))


def _sync_single_task(
    task, sync_mgr, results, task_parser, link_cards,
    *, epic_provider_id=None, provider=None,
):
    """Sync one task through PMSyncManager."""
    try:
        work_item = PMWorkItem.from_task(task)
        result = sync_mgr.sync_item(work_item)

        if result.action == SyncAction.CREATED:
            card_id = result.changes.get("provider_id", "")
            results["cards_created"].append({
                "task_id": task.id, "card_id": card_id,
            })
            console.print(f"    [green]+[/green] {task.id}: {task.title}")
            if link_cards and card_id:
                update_task_with_card_id(task, card_id, task_parser)
            if epic_provider_id and card_id and provider:
                _link_task_to_epic(provider, epic_provider_id, card_id)

        elif result.action == SyncAction.UPDATED:
            results["cards_updated"].append({"task_id": task.id})
            console.print(f"    [yellow]↻[/yellow] {task.id}: {task.title}")

        elif result.action == SyncAction.SKIPPED:
            results["cards_skipped"].append({
                "task_id": task.id, "reason": "no_changes",
            })
            console.print(f"    [dim]⊘[/dim] {task.id}: No changes (skipped)")

        elif result.action == SyncAction.ERROR:
            results["errors"].append(f"{task.id}: {result.error}")
            console.print(f"    [red]✗[/red] {task.id}: {result.error}")

    except Exception as e:
        logger.debug("Failed to sync task %s: %s", task.id, e)
        results["errors"].append(f"{task.id}: sync failed")
        console.print(f"    [red]✗[/red] {task.id}: sync failed")


def _link_task_to_epic(
    provider: ProjectManagementProvider, epic_id: str, task_id: str,
) -> None:
    """Link a synced task to its parent Epic."""
    try:
        provider.set_relationship(PMRelationship(
            source_id=epic_id,
            target_id=task_id,
            relationship_type=RelationshipType.PARENT_CHILD,
        ))
    except Exception as exc:
        logger.warning("Failed to link %s to epic %s: %s", task_id, epic_id, exc)


def _sync_via_manager(
    sprints_tasks: dict,
    results: dict,
    task_parser: TaskParser,
    link_cards: bool,
    *,
    sync_mgr: PMSyncManager,
    epic_provider_id: str | None = None,
    provider: ProjectManagementProvider | None = None,
    only_new: bool = False,
) -> None:
    """Sync tasks through PMSyncManager (non-hierarchy path)."""
    for sprint_name, sprint_tasks in sorted(sprints_tasks.items()):
        console.print(f"\n  [cyan]{sprint_name}[/cyan]:")
        for task in sprint_tasks:
            if only_new and _task_has_provider_link(task):
                results["cards_skipped"].append({
                    "task_id": task.id, "reason": "already_linked",
                })
                console.print(f"    [dim]⊘[/dim] {task.id}: Already linked (skipped)")
                continue
            _sync_single_task(
                task, sync_mgr, results, task_parser, link_cards,
                epic_provider_id=epic_provider_id, provider=provider,
            )


def _print_summary(results: dict, json_out: bool) -> None:
    """Print sync summary."""
    console.print("\n[bold]Summary:[/bold]")
    console.print(f"  Cards created: {len(results['cards_created'])}")
    console.print(f"  Cards updated: {len(results['cards_updated'])}")
    if results["cards_skipped"]:
        console.print(f"  Cards skipped: {len(results['cards_skipped'])}")
    if results["errors"]:
        console.print(f"  [red]Errors: {len(results['errors'])}[/red]")
    if json_out:
        console.print(json.dumps(results, indent=2))
