"""Legacy Trello sync — direct TrelloService path for unconfigured PM."""

import json
import logging
from typing import Optional

import typer

logger = logging.getLogger(__name__)

from .helpers import (
    console,
    get_linked_trello_card,
    update_task_with_card_id,
)
from .plan_legacy_helpers import handle_synced_card
from .parser import TaskParser


def _connect_trello(board_id):
    """Connect to Trello and return the TrelloService instance."""
    from ..trello.auth import load_token
    from ..trello.client import TrelloService
    from ..trello.sync import TrelloSyncManager, TaskSyncConfig

    token_data = load_token()
    if not token_data:
        console.print("[red]Not connected to Trello. Run 'bpsai-pair trello connect' first.[/red]")
        raise typer.Exit(1)

    service = TrelloService(api_key=token_data["api_key"], token=token_data["token"])
    service.set_board(board_id)
    return service


def sync_plan_via_trello(
    plan_id, plan, sprints_tasks, results, full_config,
    board_id, target_list, create_lists, link_cards,
    apply_defaults, only_new, fire_ready, json_out,
    task_parser, paircoder_dir,
) -> None:
    """Sync tasks through legacy direct-Trello path."""
    try:
        from ..trello.sync import TrelloSyncManager, TaskSyncConfig

        service = _connect_trello(board_id)
        results["board_id"] = board_id
        trello_config = full_config.get("trello", {})
        sync_config = TaskSyncConfig.from_config(trello_config)
        sync_manager = TrelloSyncManager(service, sync_config)

        _print_header(plan_id, service, target_list, sync_config)
        _ensure_labels(sync_manager)
        _sync_all_sprints(
            sprints_tasks, plan, plan_id, service, sync_manager,
            results, target_list, sync_config, create_lists,
            only_new, link_cards, apply_defaults, fire_ready,
            trello_config, task_parser, paircoder_dir,
        )
        _print_summary(results, json_out)

    except ImportError:
        console.print("[red]py-trello not installed. Install with: pip install 'bpsai-pair[trello]'[/red]")
        raise typer.Exit(1)
    except typer.Exit:
        raise
    except Exception as e:
        logger.debug("Trello sync error: %s", e)
        console.print("[red]Sync failed — check logs for details[/red]")
        raise typer.Exit(1)


def _sync_all_sprints(
    sprints_tasks, plan, plan_id, service, sync_manager,
    results, target_list, sync_config, create_lists,
    only_new, link_cards, apply_defaults, fire_ready,
    trello_config, task_parser, paircoder_dir,
) -> None:
    """Iterate over sprints and sync each task."""
    for sprint_name, sprint_tasks in sorted(sprints_tasks.items()):
        console.print(f"\n  [cyan]{sprint_name}[/cyan]:")
        effective_list = target_list or sync_config.default_list
        board_lists = service.get_board_lists()
        if effective_list not in board_lists:
            if not _handle_missing_list(service, effective_list, create_lists, results):
                continue
        for task in sprint_tasks:
            _sync_single_task(
                task, plan, plan_id, service, sync_manager,
                results, effective_list, only_new, link_cards,
                apply_defaults, fire_ready, trello_config,
                task_parser, paircoder_dir,
            )


def _print_header(plan_id, service, target_list, sync_config):
    """Print sync header."""
    console.print(f"\n[bold]Syncing plan:[/bold] {plan_id}")
    console.print(f"[bold]Target board:[/bold] {service.board.name}")
    if target_list:
        console.print(f"[bold]Target list:[/bold] {target_list}")
    else:
        console.print(f"[dim]Target list:[/dim] {sync_config.default_list} (default)")


def _ensure_labels(sync_manager):
    """Ensure BPS labels exist on the board."""
    console.print("\n[dim]Ensuring BPS labels exist...[/dim]")
    label_results = sync_manager.ensure_bps_labels()
    labels_created = sum(1 for v in label_results.values() if v)
    if labels_created:
        console.print(f"  [green]+ Created {labels_created} BPS labels[/green]")


def _handle_missing_list(service, effective_list, create_lists, results) -> bool:
    """Handle missing list. Returns True if list was created, False to skip."""
    if create_lists:
        service.board.add_list(effective_list)
        service.lists = {lst.name: lst for lst in service.board.all_lists()}
        results["lists_created"].append(effective_list)
        console.print(f"    [green]+ Created list: {effective_list}[/green]")
        return True
    results["errors"].append(f"List not found: {effective_list}")
    console.print(f"    [red]✗ List not found: {effective_list}[/red]")
    return False


def _sync_single_task(
    task, plan, plan_id, service, sync_manager,
    results, effective_list, only_new, link_cards,
    apply_defaults, fire_ready, trello_config,
    task_parser, paircoder_dir,
) -> None:
    """Sync a single task via legacy Trello path."""
    from ..trello.sync import TaskData

    try:
        if only_new:
            linked_card = get_linked_trello_card(task.id)
            if linked_card:
                results["cards_skipped"].append({
                    "task_id": task.id, "reason": "already_linked",
                })
                console.print(f"    [dim]⊘[/dim] {task.id}: Already linked (skipped)")
                return

        task_data = TaskData.from_task(task)
        task_data.plan_title = plan.title if plan else plan_id
        existing_card, _ = service.find_card_with_prefix(task.id)

        if only_new and existing_card:
            results["cards_skipped"].append({
                "task_id": task.id, "reason": "card_exists",
            })
            console.print(f"    [dim]⊘[/dim] {task.id}: Card exists on board (skipped)")
            return

        card_target_list = None if existing_card else effective_list
        card = sync_manager.sync_task_to_card(
            task=task_data, list_name=card_target_list, update_existing=True,
        )

        if card:
            handle_synced_card(
                task, task_data, card, existing_card, service, sync_manager,
                results, link_cards, apply_defaults, fire_ready,
                trello_config, task_parser, paircoder_dir,
            )
        else:
            results["errors"].append(f"Failed to sync card for {task.id}")
            console.print(f"    [red]✗[/red] {task.id}: Failed to sync")

    except Exception as e:
        logger.debug("Failed to sync task %s: %s", task.id, e)
        results["errors"].append(f"Failed to create card for {task.id}")
        console.print(f"    [red]✗[/red] {task.id}: sync failed")


def _print_summary(results: dict, json_out: bool) -> None:
    """Print sync summary."""
    console.print("\n[bold]Summary:[/bold]")
    console.print(f"  Lists created: {len(results['lists_created'])}")
    console.print(f"  Cards created: {len(results['cards_created'])}")
    console.print(f"  Cards updated: {len(results['cards_updated'])}")
    if results["cards_skipped"]:
        console.print(f"  Cards skipped: {len(results['cards_skipped'])}")
    if results["errors"]:
        console.print(f"  [red]Errors: {len(results['errors'])}[/red]")
    if json_out:
        console.print(json.dumps(results, indent=2))
