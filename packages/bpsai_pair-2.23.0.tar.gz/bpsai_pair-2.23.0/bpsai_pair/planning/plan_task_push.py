"""Cross-repo task push integration for plan workflow.

Wires WorkspaceOrchestrator task pushing into plan creation,
distributing task files to sibling repositories automatically.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

from rich.console import Console

from bpsai_pair.licensing.core import has_feature_api

logger = logging.getLogger(__name__)
console = Console()


def is_auto_push_enabled(paircoder_dir: Path) -> bool:
    """Check if auto task push is enabled in config."""
    config_path = paircoder_dir / "config.yaml"
    if not config_path.exists():
        return True

    try:
        import yaml

        config = yaml.safe_load(config_path.read_text(encoding="utf-8")) or {}
        ws_config = config.get("workspace", {})
        return ws_config.get("auto_push_tasks", True)
    except Exception:
        return True


def push_cross_repo_tasks(
    orchestrator: Any,
    scope: dict[str, list[str]],
    *,
    dry_run: bool = False,
    sprint_id: str | None = None,
) -> dict[str, Any]:
    """Execute cross-repo task push via orchestrator pipeline.

    Runs plan_tasks → assign_models → assign_effort → push_tasks.
    Skips when orchestrator is None, scope is empty, or single-repo.
    Returns empty dict on skip or failure (best-effort).
    """
    if orchestrator is None or not scope or len(scope) <= 1:
        return {}

    try:
        tasks = orchestrator.plan_tasks(scope, sprint_id=sprint_id)
        if not tasks:
            return {}

        orchestrator.assign_models(tasks)
        orchestrator.assign_effort(tasks)
        return orchestrator.push_tasks(tasks, dry_run=dry_run)
    except Exception as e:
        logger.warning("Cross-repo task push failed: %s", e)
        return {}


def format_push_summary(result: dict[str, Any]) -> str:
    """Format push results for display.

    Returns human-readable summary of pushed/skipped tasks.
    Returns empty string for empty results.
    """
    if not result:
        return ""

    if result.get("dry_run"):
        count = result.get("would_push", 0)
        return f"Dry run: would push {count} task(s) to sibling repos"

    pushed = result.get("pushed", 0)
    skipped = result.get("skipped", 0)

    parts = [f"Pushed {pushed} task(s) to sibling repos"]
    if skipped:
        parts.append(f"{skipped} skipped")
    return ", ".join(parts)


def display_push_results(
    paircoder_dir: Path,
    description: str,
    *,
    dry_run: bool = False,
) -> None:
    """Display cross-repo task push results after plan creation.

    Detects workspace, runs scope analysis, executes push, prints summary.
    Skips when disabled, no workspace, or single-repo scope.
    """
    if not has_feature_api("cross_repo_tasks"):
        return
    if not is_auto_push_enabled(paircoder_dir):
        return

    from bpsai_pair.planning.plan_workspace import (
        get_workspace_orchestrator,
        get_scope_analysis,
    )

    project_root = paircoder_dir.parent
    orch = get_workspace_orchestrator(project_root)
    if orch is None:
        return

    scope = get_scope_analysis(orch, description)
    result = push_cross_repo_tasks(orch, scope, dry_run=dry_run)
    if not result:
        return

    summary = format_push_summary(result)
    if summary:
        console.print(f"\n[cyan]Task Distribution:[/cyan]")
        console.print(f"  {summary}")
