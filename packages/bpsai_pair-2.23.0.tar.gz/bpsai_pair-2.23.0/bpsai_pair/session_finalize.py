"""
Session finalization module.

Runs on session termination to flush pending state, generate handoffs,
and create reconciliation markers for incomplete tasks.
"""

from __future__ import annotations

import json
import logging
import re
import subprocess
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path

logger = logging.getLogger(__name__)

_FIELD_RE = re.compile(r"^(\w+):\s*(.+)$", re.MULTILINE)


def _extract_field(content: str, field_name: str) -> str | None:
    """Extract a YAML frontmatter field value from task file content."""
    for match in _FIELD_RE.finditer(content):
        if match.group(1) == field_name:
            return match.group(2).strip()
    return None


@dataclass
class FinalizeResult:
    """Result of a session finalization run."""

    telemetry_flushed: bool = False
    handoff_created: bool = False
    reconciliation_marker: bool = False
    tasks_incomplete: list[str] = field(default_factory=list)


class SessionFinalizer:
    """Finalizes a PairCoder session on termination."""

    def __init__(self, project_root: Path) -> None:
        self._root = project_root
        self._paircoder = project_root / ".paircoder"

    def finalize(self) -> FinalizeResult:
        """Run all finalization steps. Safe to call even if nothing to do."""
        result = FinalizeResult()
        result.telemetry_flushed = self._flush_telemetry()
        result.handoff_created = self._maybe_create_handoff()
        incomplete = self._detect_incomplete_tasks()
        if incomplete:
            result.tasks_incomplete = incomplete
            result.reconciliation_marker = self._create_reconciliation_marker(
                incomplete
            )
        return result

    def _flush_telemetry(self) -> bool:
        """Flush any pending telemetry records to telemetry.jsonl."""
        pending_path = self._paircoder / "cache" / "pending_telemetry.json"
        if not pending_path.exists():
            return False

        try:
            records = json.loads(pending_path.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            logger.warning("Failed to read pending telemetry")
            return False

        if not isinstance(records, list):
            logger.warning("Unexpected pending telemetry format: expected list")
            return False

        telemetry_file = self._paircoder / "telemetry" / "telemetry.jsonl"
        telemetry_file.parent.mkdir(parents=True, exist_ok=True)

        with telemetry_file.open("a", encoding="utf-8") as f:
            for record in records:
                f.write(json.dumps(record) + "\n")

        pending_path.unlink(missing_ok=True)
        logger.info("Flushed %d pending telemetry records", len(records))
        return True

    def _maybe_create_handoff(self) -> bool:
        """Create handoff file if work was done (git diff shows changes)."""
        try:
            result = subprocess.run(
                ["git", "diff", "--stat", "HEAD"],
                capture_output=True,
                text=True,
                cwd=self._root,
                timeout=10,
            )
        except (OSError, subprocess.TimeoutExpired):
            logger.warning("Failed to run git diff")
            return False

        diff_summary = result.stdout.strip()
        if not diff_summary:
            return False

        handoffs_dir = self._paircoder / "handoffs"
        handoffs_dir.mkdir(parents=True, exist_ok=True)

        now = datetime.now(timezone.utc)
        filename = f"session-handoff-{now.strftime('%Y%m%dT%H%M%S')}.json"
        handoff_data = {
            "timestamp": now.isoformat(),
            "diff_summary": diff_summary,
        }
        (handoffs_dir / filename).write_text(
            json.dumps(handoff_data, indent=2), encoding="utf-8"
        )
        logger.info("Created session handoff: %s", filename)
        return True

    def _detect_incomplete_tasks(self) -> list[str]:
        """Find tasks that are in_progress but session is ending."""
        tasks_dir = self._paircoder / "tasks"
        if not tasks_dir.exists():
            return []

        incomplete: list[str] = []
        for path in tasks_dir.glob("*.task.md"):
            content = path.read_text(encoding="utf-8")
            task_id = _extract_field(content, "id")
            status = _extract_field(content, "status")
            if task_id and status == "in_progress":
                incomplete.append(task_id)
        return incomplete

    def _create_reconciliation_marker(self, task_ids: list[str]) -> bool:
        """Create marker file for next session to handle incomplete tasks."""
        if not task_ids:
            return False

        cache_dir = self._paircoder / "cache"
        cache_dir.mkdir(parents=True, exist_ok=True)

        marker_path = cache_dir / "reconciliation_marker.json"
        marker_data = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "incomplete_tasks": task_ids,
        }
        marker_path.write_text(
            json.dumps(marker_data, indent=2), encoding="utf-8"
        )
        logger.info("Created reconciliation marker for %d tasks", len(task_ids))
        return True
