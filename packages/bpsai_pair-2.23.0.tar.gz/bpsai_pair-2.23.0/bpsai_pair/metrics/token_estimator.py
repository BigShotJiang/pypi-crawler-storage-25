"""Token estimation for tasks based on complexity, type, and file count.

Extracted from estimation.py for modular architecture.
"""

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, Optional
import logging
import yaml

logger = logging.getLogger(__name__)


# Default token estimation coefficients (fallback when config not available)
DEFAULT_TOKEN_ESTIMATES = {
    "base_context": 15000,  # Skills, state, project context
    "per_complexity_point": 500,  # Rough: 50 complexity = 25k tokens
    "by_task_type": {
        "feature": 1.2,  # More back-and-forth
        "bugfix": 0.8,   # Usually focused
        "docs": 0.6,     # Less code generation
        "refactor": 1.5,  # Lots of reading existing code
        "chore": 0.9,    # Moderate complexity
    },
    "per_file_touched": 2000,  # Each file adds context
}


def load_token_estimates_from_config() -> dict:
    """Load token estimation parameters from config.yaml.

    Returns parameters from config.yaml token_estimates section,
    falling back to DEFAULT_TOKEN_ESTIMATES for any missing values.
    """
    estimates = dict(DEFAULT_TOKEN_ESTIMATES)

    try:
        from ..core.ops import find_project_root

        root = find_project_root()
        config_file = root / ".paircoder" / "config.yaml"
        if config_file.exists():
            with open(config_file, encoding="utf-8") as f:
                config = yaml.safe_load(f) or {}
            token_estimates = config.get("token_estimates", {})

            # Override with config values if present
            if "base_context" in token_estimates:
                estimates["base_context"] = token_estimates["base_context"]
            if "per_complexity_point" in token_estimates:
                estimates["per_complexity_point"] = token_estimates["per_complexity_point"]
            if "per_file_touched" in token_estimates:
                estimates["per_file_touched"] = token_estimates["per_file_touched"]
            if "by_task_type" in token_estimates:
                # Merge task type multipliers
                estimates["by_task_type"] = {
                    **estimates["by_task_type"],
                    **token_estimates["by_task_type"]
                }
    except Exception:
        pass

    return estimates


@dataclass
class TokenEstimate:
    """Estimated token usage for a task."""

    base_tokens: int
    complexity_tokens: int
    type_multiplier: float
    file_tokens: int
    total_tokens: int
    task_type: str
    calibrated: bool = False

    def __str__(self) -> str:
        """Return formatted string like '~45K tokens'."""
        if self.total_tokens >= 1000:
            return f"~{self.total_tokens // 1000}K tokens"
        return f"~{self.total_tokens} tokens"

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "base_tokens": self.base_tokens,
            "complexity_tokens": self.complexity_tokens,
            "type_multiplier": self.type_multiplier,
            "file_tokens": self.file_tokens,
            "total_tokens": self.total_tokens,
            "task_type": self.task_type,
        }


@dataclass
class TokenEstimationConfig:
    """Configuration for token estimation."""

    base_context: int = DEFAULT_TOKEN_ESTIMATES["base_context"]
    per_complexity_point: int = DEFAULT_TOKEN_ESTIMATES["per_complexity_point"]
    by_task_type: Dict[str, float] = field(
        default_factory=lambda: DEFAULT_TOKEN_ESTIMATES["by_task_type"].copy()
    )
    per_file_touched: int = DEFAULT_TOKEN_ESTIMATES["per_file_touched"]

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "TokenEstimationConfig":
        """Create from dictionary (e.g., from config.yaml)."""
        defaults = DEFAULT_TOKEN_ESTIMATES.copy()

        return cls(
            base_context=data.get("base_context", defaults["base_context"]),
            per_complexity_point=data.get("per_complexity_point", defaults["per_complexity_point"]),
            by_task_type={
                **defaults["by_task_type"],
                **data.get("by_task_type", {}),
            },
            per_file_touched=data.get("per_file_touched", defaults["per_file_touched"]),
        )


_MIN_CALIBRATION_SAMPLES = 3


class TokenEstimator:
    """Estimates token usage for tasks based on complexity, type, and file count.

    When calibration data is available (>= 3 samples for a task type),
    uses the calibrated avg_tokens. Otherwise falls back to the formula:

        tokens = base_context +
                 (complexity * per_complexity_point) * type_multiplier +
                 (file_count * per_file_touched)
    """

    def __init__(
        self,
        config: Optional[TokenEstimationConfig] = None,
        project_root: Optional[Path] = None,
    ):
        """Initialize token estimator."""
        if config is not None:
            self.config = config
        else:
            self.config = self._load_config_from_project()
        self._project_root = project_root
        self._calibration = None  # lazy-loaded

    @staticmethod
    def _load_config_from_project() -> TokenEstimationConfig:
        """Load token estimation config from project config.yaml."""
        try:
            from ..core.ops import find_project_root

            root = find_project_root()
            config_file = root / ".paircoder" / "config.yaml"
            if config_file.exists():
                with open(config_file, encoding="utf-8") as f:
                    data = yaml.safe_load(f) or {}
                token_data = data.get("token_estimates", {})
                if token_data:
                    return TokenEstimationConfig.from_dict(token_data)
        except Exception:
            pass
        return TokenEstimationConfig()

    @classmethod
    def from_config_file(cls, config_path: Path) -> "TokenEstimator":
        """Load token estimation config from a YAML file."""
        if not config_path.exists():
            return cls()

        try:
            with open(config_path, encoding='utf-8') as f:
                data = yaml.safe_load(f) or {}

            token_data = data.get("token_estimates", {})
            config = TokenEstimationConfig.from_dict(token_data)
            return cls(config)
        except Exception as e:
            logger.warning(f"Failed to load token estimation config: {e}")
            return cls()

    def _get_calibrated_avg(self, task_type: str) -> Optional[float]:
        """Query calibration for avg_tokens if sufficient samples exist."""
        if self._project_root is None:
            return None
        try:
            if self._calibration is None:
                from ..feedback.calibration import CalibrationEngine
                engine = CalibrationEngine(self._project_root)
                self._calibration = engine.get_calibration()
            stats = self._calibration.task_types.get(task_type)
            if stats is not None and stats.sample_count >= _MIN_CALIBRATION_SAMPLES:
                return stats.avg_tokens
        except Exception:
            pass
        return None

    def estimate_tokens(
        self,
        complexity: int,
        task_type: str,
        file_count: int,
    ) -> TokenEstimate:
        """Estimate token usage for a task.

        Uses calibrated avg_tokens when available (>= 3 samples),
        otherwise falls back to the static formula.
        """
        calibrated_avg = self._get_calibrated_avg(task_type)
        if calibrated_avg is not None:
            return TokenEstimate(
                base_tokens=0,
                complexity_tokens=0,
                type_multiplier=0.0,
                file_tokens=0,
                total_tokens=int(calibrated_avg),
                task_type=task_type,
                calibrated=True,
            )

        type_multiplier = self.config.by_task_type.get(task_type.lower(), 1.0)

        base_tokens = self.config.base_context
        raw_complexity_tokens = complexity * self.config.per_complexity_point
        complexity_tokens = int(raw_complexity_tokens * type_multiplier)
        file_tokens = file_count * self.config.per_file_touched

        total_tokens = base_tokens + complexity_tokens + file_tokens

        return TokenEstimate(
            base_tokens=base_tokens,
            complexity_tokens=complexity_tokens,
            type_multiplier=type_multiplier,
            file_tokens=file_tokens,
            total_tokens=total_tokens,
            task_type=task_type,
            calibrated=False,
        )

    def estimate_for_task(self, task: Any) -> TokenEstimate:
        """Estimate tokens from a Task object."""
        complexity = getattr(task, "complexity", 50)
        task_type = getattr(task, "type", "feature")
        files_touched = getattr(task, "files_touched", [])
        file_count = len(files_touched) if files_touched else 0

        return self.estimate_tokens(complexity, task_type, file_count)
