"""Hours estimation comparison — estimated vs actual hours.

Extracted from estimation.py for modular architecture.
"""

from dataclasses import dataclass
from datetime import datetime
from typing import Any, Dict, Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from ..planning.models import Task


@dataclass
class TaskComparison:
    """Comparison of estimated vs actual hours for a task."""

    task_id: str
    estimated_hours: float
    actual_hours: float
    completed_at: Optional[datetime] = None

    @property
    def variance_hours(self) -> float:
        """Calculate variance (actual - estimated). Negative means under estimate."""
        return self.actual_hours - self.estimated_hours

    @property
    def variance_percent(self) -> float:
        """Calculate variance as percentage of estimated hours."""
        if self.estimated_hours == 0:
            return 0.0
        return (self.variance_hours / self.estimated_hours) * 100

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for metrics JSONL storage."""
        return {
            "task_id": self.task_id,
            "estimated_hours": self.estimated_hours,
            "actual_hours": self.actual_hours,
            "variance_hours": self.variance_hours,
            "variance_percent": self.variance_percent,
            "completed_at": self.completed_at.isoformat() if self.completed_at else None,
        }

    @classmethod
    def from_task(
        cls, task: "Task", actual_hours: float, completed_at: Optional[datetime] = None
    ) -> "TaskComparison":
        """Create comparison from task object and actual hours."""
        return cls(
            task_id=task.id,
            estimated_hours=task.estimated_hours.expected_hours,
            actual_hours=actual_hours,
            completed_at=completed_at or datetime.now(),
        )
