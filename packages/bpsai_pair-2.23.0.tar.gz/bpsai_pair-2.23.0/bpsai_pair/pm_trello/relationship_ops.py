"""Relationship operations for TrelloProvider — extracted to stay within arch limits."""

from __future__ import annotations

from typing import Any

from bpsai_pair.pm.types import (
    PMRelationship,
    PMWorkItem,
    RelationshipType,
)
from bpsai_pair.pm_trello.config import find_card as _find_card
from bpsai_pair.pm_trello.relationships import (
    add_relationship_to_card,
    get_children_ids_from_card,
    remove_relationship_from_card,
    set_parent_on_card,
)

_REL_TYPE_MAP = {
    RelationshipType.PARENT_CHILD: "children",
    RelationshipType.BLOCKS: "blocks",
    RelationshipType.RELATES_TO: "relates_to",
}


def set_relationship_on_trello(
    service: Any, relationship: PMRelationship,
) -> bool:
    """Create a relationship between two Trello cards."""
    source_card, _ = _find_card(service, relationship.source_id)
    if source_card is None:
        return False

    rel_key = _REL_TYPE_MAP[relationship.relationship_type]
    add_relationship_to_card(source_card, relationship.target_id, rel_key)

    if relationship.relationship_type == RelationshipType.PARENT_CHILD:
        target_card, _ = _find_card(service, relationship.target_id)
        if target_card is not None:
            set_parent_on_card(target_card, relationship.source_id)

    return True


def remove_relationship_on_trello(
    service: Any, relationship: PMRelationship,
) -> bool:
    """Remove a relationship between two Trello cards."""
    source_card, _ = _find_card(service, relationship.source_id)
    if source_card is None:
        return False

    rel_key = _REL_TYPE_MAP[relationship.relationship_type]
    result = remove_relationship_from_card(source_card, relationship.target_id, rel_key)

    if relationship.relationship_type == RelationshipType.PARENT_CHILD:
        target_card, _ = _find_card(service, relationship.target_id)
        if target_card is not None:
            remove_relationship_from_card(target_card, relationship.source_id, "parent")

    return result


def get_children_from_trello(
    service: Any, item_id: str, find_item_fn: Any,
) -> list[PMWorkItem]:
    """Return child work items for a Trello card."""
    card, _ = _find_card(service, item_id)
    if card is None:
        return []

    children: list[PMWorkItem] = []
    for child_id in get_children_ids_from_card(card):
        item = find_item_fn(child_id)
        if item is not None:
            children.append(item)
    return children
