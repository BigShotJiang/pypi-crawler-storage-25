"""Butler automation discovery — poll for cards created by Trello automations."""

from __future__ import annotations

import logging
import time
from typing import TYPE_CHECKING, Any, Callable

from bpsai_pair.trello.client import TrelloService

if TYPE_CHECKING:
    from bpsai_pair.pm.types import PMWorkItem
    from bpsai_pair.pm.workflow import WorkflowEngine

logger = logging.getLogger(__name__)


def discover_card_in_list(
    service: TrelloService,
    list_name: str,
    expected_title: str,
    *,
    max_attempts: int = 5,
    delay_seconds: float = 1.0,
    sleep_fn: Callable[[float], Any] = time.sleep,
) -> Any | None:
    """Poll for a card matching *expected_title* in the given list.

    Calls ``service.get_cards_in_list(list_name)`` up to *max_attempts* times
    with *delay_seconds* between attempts. Maximum blocking time is
    ``max_attempts * delay_seconds`` (default: 5s). Uses case-insensitive
    substring matching on ``card.name``. Returns the first matching card,
    or ``None`` after exhausting attempts.
    """
    needle = expected_title.lower()
    for attempt in range(max_attempts):
        cards = service.get_cards_in_list(list_name)
        for card in cards:
            if needle in getattr(card, "name", "").lower():
                logger.debug("Found card matching '%s' on attempt %d", expected_title, attempt + 1)
                return card
        if attempt < max_attempts - 1:
            logger.debug(
                "Card '%s' not found in '%s', attempt %d/%d — retrying",
                expected_title, list_name, attempt + 1, max_attempts,
            )
            sleep_fn(delay_seconds)
    logger.debug("Card '%s' not found after %d attempts", expected_title, max_attempts)
    return None


def discover_created_item(
    service: TrelloService,
    engine: WorkflowEngine,
    local_id: str,
) -> PMWorkItem | None:
    """Search automation-created lists for a card matching *local_id*."""
    from bpsai_pair.pm_trello.adapter import TrelloAdapter

    for auto in engine.get_automations():
        if not auto.creates_in:
            continue
        card = discover_card_in_list(
            service, auto.creates_in, local_id,
            max_attempts=10, delay_seconds=2.0,
        )
        if card is not None:
            return TrelloAdapter.card_to_work_item(card)
    return None
