"""TrelloAdapter — bidirectional card <-> PMWorkItem conversion."""

from __future__ import annotations

import re
from typing import Any, Optional

from bpsai_pair.pm.types import (
    PMChecklistItem,
    PMWorkItem,
    WorkItemStatus,
    WorkItemType,
)
from bpsai_pair.pm_trello.relationships import parse_relationships

# Bracket prefix pattern: [ANYTHING] at start of card name
_BRACKET_ID_RE = re.compile(r"^\[([^\]]+)\]")

# WorkItemStatus → Trello Status custom field dropdown value
_STATUS_TO_TRELLO: dict[str, str] = {
    WorkItemStatus.PENDING.value: "Planning",
    WorkItemStatus.PLANNING.value: "Planning",
    WorkItemStatus.ENQUEUED.value: "Enqueued",
    WorkItemStatus.IN_PROGRESS.value: "In progress",
    WorkItemStatus.REVIEW.value: "Testing",
    WorkItemStatus.TESTING.value: "Testing",
    WorkItemStatus.DONE.value: "Done",
    WorkItemStatus.BLOCKED.value: "Blocked",
    WorkItemStatus.CANCELLED.value: "Issues/Tech Debt",
}

# Exact list name → WorkItemStatus
_LIST_TO_STATUS: dict[str, WorkItemStatus] = {
    "Intake/Backlog": WorkItemStatus.PENDING,
    "Planned/Ready": WorkItemStatus.ENQUEUED,
    "In Progress": WorkItemStatus.IN_PROGRESS,
    "Review/Testing": WorkItemStatus.REVIEW,
    "Deployed/Done": WorkItemStatus.DONE,
    "Issues/Tech Debt": WorkItemStatus.BLOCKED,
}

# Substring patterns for fuzzy list matching (checked in order)
_LIST_PATTERNS: list[tuple[str, WorkItemStatus]] = [
    ("done", WorkItemStatus.DONE),
    ("deployed", WorkItemStatus.DONE),
    ("progress", WorkItemStatus.IN_PROGRESS),
    ("review", WorkItemStatus.REVIEW),
    ("testing", WorkItemStatus.REVIEW),
    ("blocked", WorkItemStatus.BLOCKED),
    ("issue", WorkItemStatus.BLOCKED),
    ("backlog", WorkItemStatus.PENDING),
    ("intake", WorkItemStatus.PENDING),
    ("ready", WorkItemStatus.ENQUEUED),
    ("planned", WorkItemStatus.ENQUEUED),
]


def _extract_checklist_items(card: Any) -> list[PMChecklistItem]:
    """Extract PMChecklistItems from a Trello card's checklists."""
    items: list[PMChecklistItem] = []
    for cl in getattr(card, "checklists", []):
        cl_id = getattr(cl, "id", "")
        for ci in getattr(cl, "items", []):
            ci_id = ci.get("id", "")
            items.append(
                PMChecklistItem(
                    id=f"{cl_id}:{ci_id}" if cl_id else ci_id,
                    name=ci.get("name", ""),
                    checked=ci.get("checked", False),
                )
            )
    return items


def parse_api_checklists(checklists: list[dict]) -> list[PMChecklistItem]:
    """Parse Trello API checklist response into PMChecklistItems."""
    items: list[PMChecklistItem] = []
    for cl in checklists:
        for ci in cl.get("items", []):
            items.append(
                PMChecklistItem(
                    id=f"{cl['id']}:{ci['id']}",
                    name=ci["name"],
                    checked=ci.get("checked", False),
                )
            )
    return items


class TrelloAdapter:
    """Bidirectional conversion between Trello cards and PMWorkItem."""

    @staticmethod
    def card_to_work_item(
        card: Any, lst: Optional[Any] = None,
    ) -> PMWorkItem:
        """Convert a Trello card (py-trello) to a PMWorkItem."""
        name: str = getattr(card, "name", "") or ""
        desc: str = getattr(card, "description", "") or ""
        card_id: str = card.id

        # Extract task ID from [ID] prefix or fall back to card.id
        # Strip prefix from title so it matches the local task title
        task_id = card_id
        m = _BRACKET_ID_RE.match(name)
        if m:
            task_id = m.group(1)
            name = name[m.end():].lstrip()

        list_name = getattr(lst, "name", "") if lst else ""
        status = TrelloAdapter.list_name_to_status(list_name)
        checklist_items = _extract_checklist_items(card)
        parent_id = parse_relationships(desc).parent_id

        # Provider metadata
        provider_meta: dict[str, Any] = {"provider_id": card_id, "trello_card_id": card_id}
        url = getattr(card, "url", None)
        if url is not None:
            provider_meta["trello_url"] = url

        # Extract labels as tags
        tags: list[str] = []
        card_labels = getattr(card, "labels", None)
        if card_labels:
            tags = [lbl.name for lbl in card_labels if getattr(lbl, "name", None)]

        return PMWorkItem(
            id=task_id,
            title=name,
            status=status,
            item_type=WorkItemType.TASK,
            description=desc,
            checklist_items=checklist_items,
            provider_meta=provider_meta,
            parent_id=parent_id,
            tags=tags,
        )

    # WorkItemType → Trello label name
    _TYPE_LABELS: dict[WorkItemType, str] = {
        WorkItemType.EPIC: "Epic",
        WorkItemType.STORY: "Story",
        WorkItemType.TASK: "Task",
    }

    @staticmethod
    def work_item_to_card_data(item: PMWorkItem) -> dict[str, Any]:
        """Convert a PMWorkItem to a dict suitable for card creation."""
        # Prefix title with [ID] if not already present (skip when id is empty)
        name = item.title
        if item.id and not name.startswith(f"[{item.id}]"):
            name = f"[{item.id}] {name}"

        data: dict[str, Any] = {
            "name": name,
            "description": item.description,
            "status": TrelloAdapter.status_to_trello(item.status),
        }

        # Type label
        labels: list[str] = []
        type_label = TrelloAdapter._TYPE_LABELS.get(item.item_type)
        if type_label:
            labels.append(type_label)
        if labels:
            data["labels"] = labels

        # AC checklist items for card creation
        if item.checklist_items:
            data["ac_checklist"] = [ci.name for ci in item.checklist_items]

        custom_fields: dict[str, Any] = {}
        if item.priority is not None:
            custom_fields["Priority"] = item.priority
        if item.complexity is not None:
            custom_fields["Complexity"] = item.complexity
        if custom_fields:
            data["custom_fields"] = custom_fields

        return data

    @staticmethod
    def status_to_trello(status: WorkItemStatus) -> str:
        """Map a WorkItemStatus to a Trello Status dropdown value."""
        return _STATUS_TO_TRELLO.get(status.value, "Planning")

    @staticmethod
    def list_name_to_status(list_name: str) -> WorkItemStatus:
        """Map a Trello list name to WorkItemStatus.

        Tries exact match first, then fuzzy substring matching.
        Defaults to PENDING for unknown lists.
        """
        if list_name in _LIST_TO_STATUS:
            return _LIST_TO_STATUS[list_name]

        lower = list_name.lower()
        for pattern, status in _LIST_PATTERNS:
            if pattern in lower:
                return status

        return WorkItemStatus.PENDING
