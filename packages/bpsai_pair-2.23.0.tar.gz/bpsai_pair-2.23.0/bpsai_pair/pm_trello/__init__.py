"""Trello provider for PM abstraction layer.

Calling ``register()`` adds the ``"trello"`` provider to the PM registry.
The registry's ``_discover_providers()`` calls this automatically on import.
"""

from __future__ import annotations


def register() -> None:
    """Register TrelloProvider with the PM registry."""
    from bpsai_pair.pm.registry import register_provider
    from bpsai_pair.pm_trello.provider import TrelloProvider

    register_provider("trello", TrelloProvider)
