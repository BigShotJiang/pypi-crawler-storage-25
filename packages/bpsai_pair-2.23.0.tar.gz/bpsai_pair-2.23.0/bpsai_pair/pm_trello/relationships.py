"""Trello card relationship tracking via description metadata blocks."""

from __future__ import annotations

from dataclasses import dataclass, field
import re
from typing import Any

_BLOCK_RE = re.compile(
    r"---pm-relationships---\n(.*?)---end-pm-relationships---",
    re.DOTALL,
)

_LINE_RE = re.compile(r"^([\w-]+):\s*(.+)$")


@dataclass
class CardRelationships:
    """Parsed relationship data from a Trello card description."""

    parent_id: str | None = None
    children_ids: list[str] = field(default_factory=list)
    blocks_ids: list[str] = field(default_factory=list)
    relates_to_ids: list[str] = field(default_factory=list)


def parse_relationships(description: str) -> CardRelationships:
    """Parse the ---pm-relationships--- block from a card description.

    Returns empty CardRelationships if no block found.
    """
    match = _BLOCK_RE.search(description)
    if not match:
        return CardRelationships()

    rels = CardRelationships()
    for line in match.group(1).splitlines():
        m = _LINE_RE.match(line.strip())
        if not m:
            continue
        key, value = m.group(1), m.group(2)
        if key == "parent":
            rels.parent_id = value.strip()
        elif key == "children":
            rels.children_ids = _split_ids(value)
        elif key == "blocks":
            rels.blocks_ids = _split_ids(value)
        elif key == "relates_to":
            rels.relates_to_ids = _split_ids(value)
    return rels


def render_relationships(rels: CardRelationships) -> str:
    """Render a CardRelationships into the ---pm-relationships--- block.

    Only includes lines for non-empty fields.
    """
    lines: list[str] = ["---pm-relationships---"]
    if rels.parent_id:
        lines.append(f"parent: {rels.parent_id}")
    if rels.children_ids:
        lines.append(f"children: {', '.join(rels.children_ids)}")
    if rels.blocks_ids:
        lines.append(f"blocks: {', '.join(rels.blocks_ids)}")
    if rels.relates_to_ids:
        lines.append(f"relates_to: {', '.join(rels.relates_to_ids)}")
    lines.append("---end-pm-relationships---")
    return "\n".join(lines)


def _is_empty(rels: CardRelationships) -> bool:
    return (
        not rels.parent_id
        and not rels.children_ids
        and not rels.blocks_ids
        and not rels.relates_to_ids
    )


def update_description_relationships(
    description: str, rels: CardRelationships,
) -> str:
    """Replace or append the relationships block in a description.

    If block exists, replace it (or remove it if all fields are empty).
    If not, append with blank line separator (unless empty).
    """
    if _is_empty(rels):
        if _BLOCK_RE.search(description):
            return _BLOCK_RE.sub("", description).rstrip()
        return description

    rendered = render_relationships(rels)
    if _BLOCK_RE.search(description):
        return _BLOCK_RE.sub(rendered, description)
    return description + "\n\n" + rendered


_VALID_REL_TYPES = {"children", "blocks", "relates_to"}


def add_relationship_to_card(
    card: Any,
    target_id: str,
    rel_type: str,
) -> bool:
    """Add a relationship entry to a card's description block.

    rel_type is one of: "children", "blocks", "relates_to".
    Raises ValueError if rel_type is not valid.
    Returns False if the API call to update the description fails.
    """
    if rel_type not in _VALID_REL_TYPES:
        raise ValueError(
            f"Invalid rel_type '{rel_type}'; must be one of {sorted(_VALID_REL_TYPES)}"
        )
    rels = parse_relationships(card.description or "")
    id_list = getattr(rels, f"{rel_type}_ids")
    if target_id not in id_list:
        id_list.append(target_id)
    new_desc = update_description_relationships(card.description or "", rels)
    try:
        card.set_description(new_desc)
    except Exception:
        return False
    return True


def remove_relationship_from_card(
    card: Any,
    target_id: str,
    rel_type: str,
) -> bool:
    """Remove a relationship entry from a card's description block.

    rel_type is "parent" or one of: "children", "blocks", "relates_to".
    Returns True if removed, False if not found or API error.
    """
    if rel_type != "parent" and rel_type not in _VALID_REL_TYPES:
        raise ValueError(
            f"Invalid rel_type '{rel_type}'; must be 'parent' or one of {sorted(_VALID_REL_TYPES)}"
        )
    desc = card.description or ""
    rels = parse_relationships(desc)
    if not _BLOCK_RE.search(desc):
        return False

    if rel_type == "parent":
        if rels.parent_id != target_id:
            return False
        rels.parent_id = None
    else:
        id_list = getattr(rels, f"{rel_type}_ids")
        if target_id not in id_list:
            return False
        id_list.remove(target_id)

    new_desc = update_description_relationships(desc, rels)
    try:
        card.set_description(new_desc)
    except Exception:
        return False
    return True


def set_parent_on_card(card: Any, parent_id: str) -> None:
    """Set the parent_id in a card's relationship block."""
    rels = parse_relationships(card.description or "")
    rels.parent_id = parent_id
    new_desc = update_description_relationships(card.description or "", rels)
    card.set_description(new_desc)


def get_children_ids_from_card(card: Any) -> list[str]:
    """Return the list of children IDs from a card's relationship block."""
    return parse_relationships(card.description or "").children_ids


def _split_ids(value: str) -> list[str]:
    """Split a comma-separated list of IDs, stripping whitespace."""
    return [v.strip() for v in value.split(",") if v.strip()]
