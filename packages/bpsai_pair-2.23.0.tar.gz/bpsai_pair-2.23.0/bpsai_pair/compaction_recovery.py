"""Recovery and parsing helpers for compaction snapshots."""

import json
import logging
from pathlib import Path
from typing import Any, Dict, List, Optional

from .compaction_models import CompactionSnapshot

logger = logging.getLogger(__name__)


def parse_state_for_snapshot(
    content: str,
    timestamp: "datetime",
    trigger: str,
) -> CompactionSnapshot:
    """Parse state.md content into a CompactionSnapshot."""
    snapshot = CompactionSnapshot(timestamp=timestamp, trigger=trigger)
    lines = content.split("\n")
    current_section: Optional[str] = None

    for line in lines:
        stripped = line.strip()
        if stripped.startswith("## "):
            current_section = stripped[3:].lower()
            continue
        _apply_line_to_snapshot(snapshot, stripped, current_section)

    return snapshot


def _apply_line_to_snapshot(
    snapshot: CompactionSnapshot,
    stripped: str,
    current_section: Optional[str],
) -> None:
    """Apply a single parsed line to a snapshot object."""
    if current_section == "active plan":
        if stripped.startswith("**Plan:**"):
            snapshot.active_plan = stripped.replace("**Plan:**", "").strip()

    if current_section and "sprint" in current_section and "task" in current_section:
        if "|" in stripped and "in_progress" in stripped.lower():
            parts = [p.strip() for p in stripped.split("|") if p.strip()]
            if len(parts) >= 2:
                snapshot.current_task_id = parts[0] if parts[0] != "ID" else None
                snapshot.current_task_title = parts[1] if len(parts) > 1 else None

    if stripped.startswith("**Progress:**"):
        snapshot.progress = stripped.replace("**Progress:**", "").strip()

    if current_section == "what was just done":
        if stripped.startswith("- ") and not snapshot.last_done:
            snapshot.last_done = stripped[2:]

    if current_section == "what's next":
        if (stripped.startswith("1. ") or stripped.startswith("- ")) and not snapshot.whats_next:
            snapshot.whats_next = stripped.lstrip("1.- ")


def read_containment_config(paircoder_dir: Path) -> Optional[Dict[str, Any]]:
    """Read containment config from config.yaml if present."""
    config_path = paircoder_dir / "config.yaml"
    if not config_path.exists():
        return None
    try:
        import yaml

        data = yaml.safe_load(config_path.read_text(encoding="utf-8"))
        if isinstance(data, dict) and "containment" in data:
            containment = data["containment"]
            if isinstance(containment, dict) and containment.get("enabled"):
                return containment
    except Exception as e:
        logger.warning(f"Failed to read containment config: {e}")
    return None


def restore_containment_config(
    paircoder_dir: Path, containment: Dict[str, Any]
) -> None:
    """Write containment config back to config.yaml."""
    config_path = paircoder_dir / "config.yaml"
    try:
        import yaml

        data: Dict[str, Any] = {}
        if config_path.exists():
            data = yaml.safe_load(config_path.read_text(encoding="utf-8")) or {}
        data["containment"] = containment
        config_path.write_text(
            yaml.dump(data, default_flow_style=False), encoding="utf-8"
        )
    except Exception as e:
        logger.warning(f"Failed to restore containment config: {e}")


def recover_state_context(
    context_dir: Path, paircoder_dir: Path
) -> List[str]:
    """Build recovery lines from state.md."""
    from datetime import datetime

    lines: List[str] = []
    state_path = context_dir / "state.md"
    if not state_path.exists():
        return lines

    try:
        content = state_path.read_text(encoding="utf-8")
        snapshot = parse_state_for_snapshot(content, datetime.now(), "recovery")
    except IOError:
        return lines

    lines.append("Recovered context:")
    if snapshot.active_plan:
        lines.append(f"  - Active plan: {snapshot.active_plan}")
    if snapshot.current_task_id:
        task_info = snapshot.current_task_id
        if snapshot.current_task_title:
            task_info += f" ({snapshot.current_task_title})"
        lines.append(f"  - Current task: {task_info}")
    if snapshot.progress:
        lines.append(f"  - Progress: {snapshot.progress}")
    if snapshot.last_done:
        lines.append(f"  - Last done: {snapshot.last_done}")
    if snapshot.whats_next:
        lines.append(f"  - Next: {snapshot.whats_next}")
    return lines


def recover_from_snapshot(
    cache_dir: Path, paircoder_dir: Path, snapshot_file: str
) -> List[str]:
    """Recover recent files and containment from a snapshot file."""
    lines: List[str] = []
    # SEC-002: Prevent path traversal — only allow basenames
    safe_name = Path(snapshot_file).name
    snapshot_path = (cache_dir / safe_name).resolve()
    if not snapshot_path.is_relative_to(cache_dir.resolve()):
        return lines
    if not snapshot_path.exists():
        return lines

    try:
        with open(snapshot_path, encoding="utf-8") as f:
            snap_data = json.load(f)
        snapshot = CompactionSnapshot.from_dict(snap_data)
        if snapshot.recent_files:
            lines.append("")
            lines.append("Recent files from pre-compaction snapshot:")
            for filepath in snapshot.recent_files[:5]:
                lines.append(f"  - {filepath}")
        if snapshot.containment:
            restore_containment_config(paircoder_dir, snapshot.containment)
            mode = snapshot.containment.get("mode", "unknown")
            lines.append("")
            lines.append(f"Containment mode restored ({mode})")
    except (json.JSONDecodeError, KeyError):
        pass

    return lines
