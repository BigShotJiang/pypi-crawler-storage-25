"""
Compaction helper functions extracted from CompactionManager.

Contains snapshot I/O, logging, and cleanup utilities.
"""

from __future__ import annotations

import json
import logging
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

from .compaction_models import CompactionMarker, CompactionSnapshot

logger = logging.getLogger(__name__)


def get_recent_files(history_dir: Path) -> List[str]:
    """Get list of recently changed files from changes.log."""
    changes_log = history_dir / "changes.log"
    if not changes_log.exists():
        return []
    try:
        lines = changes_log.read_text(encoding="utf-8").strip().split("\n")
        files: List[str] = []
        seen: set[str] = set()
        for line in reversed(lines[-20:]):
            parts = line.split(" ", 1)
            if len(parts) == 2:
                filepath = parts[1].strip()
                if filepath not in seen:
                    seen.add(filepath)
                    files.append(filepath)
                    if len(files) >= 10:
                        break
        return files
    except IOError:
        return []


def save_marker(marker_file: Path, marker: CompactionMarker) -> None:
    """Save compaction marker to file."""
    try:
        with open(marker_file, "w", encoding="utf-8") as f:
            json.dump(marker.to_dict(), f, indent=2)
    except IOError as e:
        logger.warning(f"Failed to save compaction marker: {e}")


def log_compaction(
    compaction_log: Path, trigger: str, reason: Optional[str], snapshot_path: Path,
) -> None:
    """Log compaction event to history."""
    try:
        timestamp = datetime.now().isoformat()
        log_entry = f"{timestamp} compaction trigger={trigger}"
        if reason:
            log_entry += f' reason="{reason}"'
        log_entry += f" snapshot={snapshot_path.name}\n"
        with open(compaction_log, "a", encoding="utf-8") as f:
            f.write(log_entry)
    except IOError as e:
        logger.warning(f"Failed to log compaction: {e}")


def list_snapshots(cache_dir: Path) -> List[CompactionSnapshot]:
    """List all available compaction snapshots."""
    snapshots = []
    for path in sorted(cache_dir.glob("compaction_snapshot_*.json"), reverse=True):
        try:
            with open(path, encoding="utf-8") as f:
                data = json.load(f)
            snapshots.append(CompactionSnapshot.from_dict(data))
        except (json.JSONDecodeError, KeyError):
            continue
    return snapshots


def cleanup_old_snapshots(cache_dir: Path, keep: int = 5) -> int:
    """Remove old snapshots, keeping the most recent."""
    snapshot_files = sorted(
        cache_dir.glob("compaction_snapshot_*.json"), reverse=True,
    )
    removed = 0
    for path in snapshot_files[keep:]:
        try:
            path.unlink()
            removed += 1
        except IOError:
            pass
    return removed
