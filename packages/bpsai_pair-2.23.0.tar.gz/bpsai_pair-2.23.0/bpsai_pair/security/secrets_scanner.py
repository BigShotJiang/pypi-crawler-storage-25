"""Secret scanner engine for PairCoder.

This module provides the SecretScanner class for scanning files,
diffs, and directories for leaked credentials.
"""

import re
import subprocess
from pathlib import Path
from typing import Optional

from .secrets_types import AllowlistConfig, SecretMatch
from .secrets_patterns import SECRET_PATTERNS, IGNORE_PATTERNS


class SecretScanner:
    """Scans files and git diffs for leaked credentials.

    Attributes:
        allowlist: Configuration for false positive suppression
        patterns: Compiled regex patterns for secret detection
        ignore_patterns: Compiled patterns for false positive detection
    """

    def __init__(self, allowlist: Optional[AllowlistConfig] = None):
        """Initialize the secret scanner.

        Args:
            allowlist: Optional allowlist configuration
        """
        self.allowlist = allowlist or AllowlistConfig()
        self.patterns = [
            (re.compile(pattern), secret_type, confidence)
            for pattern, secret_type, confidence in SECRET_PATTERNS
        ]
        self.ignore_patterns = [
            re.compile(pattern, re.IGNORECASE)
            for pattern in IGNORE_PATTERNS
        ]

    def _should_ignore_line(self, line: str) -> bool:
        """Check if a line should be ignored as a false positive.

        Args:
            line: The line to check

        Returns:
            True if the line should be ignored
        """
        for pattern in self.ignore_patterns:
            if pattern.search(line):
                return True
        return False

    def _should_ignore_match(self, match: str) -> bool:
        """Check if a match should be ignored.

        Args:
            match: The matched value

        Returns:
            True if the match should be ignored
        """
        # Check allowlist patterns
        if self.allowlist.is_allowed_pattern(match):
            return True

        # Ignore very short matches (likely false positives)
        if len(match) < 8:
            return True

        # Ignore matches that are all the same character
        if len(set(match)) <= 2:
            return True

        return False

    def scan_file(self, path: Path) -> list[SecretMatch]:
        """Scan a file for potential secrets.

        Args:
            path: Path to the file to scan

        Returns:
            List of SecretMatch objects for detected secrets
        """
        matches = []

        # Check if file should be skipped
        if self.allowlist.is_allowed_file(str(path)):
            return matches

        # Skip binary files
        try:
            content = path.read_text(encoding='utf-8', errors='ignore')
        except Exception:
            return matches

        lines = content.split('\n')

        for line_num, line in enumerate(lines, 1):
            # Skip lines matching ignore patterns
            if self._should_ignore_line(line):
                continue

            # Check each secret pattern
            for pattern, secret_type, confidence in self.patterns:
                for match in pattern.finditer(line):
                    # Get the actual matched value
                    matched_value = match.group(1) if match.lastindex else match.group(0)

                    # Skip if match should be ignored
                    if self._should_ignore_match(matched_value):
                        continue

                    matches.append(SecretMatch(
                        secret_type=secret_type,
                        file_path=str(path),
                        line_number=line_num,
                        line_content=line,
                        match=matched_value,
                        confidence=confidence,
                    ))

        return matches

    def scan_diff(self, diff: str) -> list[SecretMatch]:
        """Scan a git diff for secrets in newly added lines.

        Args:
            diff: The git diff output

        Returns:
            List of SecretMatch objects for detected secrets
        """
        matches = []
        current_file = ""
        line_num = 0

        for line in diff.split('\n'):
            # Track current file
            if line.startswith('+++ b/'):
                current_file = line[6:]
                continue

            # Track line numbers from hunk headers
            if line.startswith('@@'):
                # Parse @@ -old,count +new,count @@
                hunk_match = re.search(r'\+(\d+)', line)
                if hunk_match:
                    line_num = int(hunk_match.group(1)) - 1
                continue

            # Only check added lines
            if line.startswith('+') and not line.startswith('+++'):
                line_num += 1
                content = line[1:]  # Remove the + prefix

                # Skip if file should be ignored
                if self.allowlist.is_allowed_file(current_file):
                    continue

                # Skip lines matching ignore patterns
                if self._should_ignore_line(content):
                    continue

                # Check each pattern
                for pattern, secret_type, confidence in self.patterns:
                    for match in pattern.finditer(content):
                        matched_value = match.group(1) if match.lastindex else match.group(0)

                        if self._should_ignore_match(matched_value):
                            continue

                        matches.append(SecretMatch(
                            secret_type=secret_type,
                            file_path=current_file,
                            line_number=line_num,
                            line_content=content,
                            match=matched_value,
                            confidence=confidence,
                        ))
            elif not line.startswith('-'):
                # Context line (unchanged), increment line number
                line_num += 1

        return matches

    def scan_staged(self, repo_root: Optional[Path] = None) -> list[SecretMatch]:
        """Scan all staged changes for secrets.

        Args:
            repo_root: Optional repository root path

        Returns:
            List of SecretMatch objects for detected secrets
        """
        cwd = repo_root or Path.cwd()

        # Get staged diff
        result = subprocess.run(
            ['git', 'diff', '--cached', '--unified=0'],
            cwd=cwd,
            capture_output=True,
            text=True,
        )

        if result.returncode != 0:
            return []

        return self.scan_diff(result.stdout)

    def scan_commit_range(
        self,
        base_ref: str = "HEAD",
        repo_root: Optional[Path] = None
    ) -> list[SecretMatch]:
        """Scan commits since a reference for secrets.

        Args:
            base_ref: Git reference to compare against
            repo_root: Optional repository root path

        Returns:
            List of SecretMatch objects for detected secrets
        """
        cwd = repo_root or Path.cwd()

        # Get diff since base_ref
        result = subprocess.run(
            ['git', 'diff', base_ref, '--unified=0'],
            cwd=cwd,
            capture_output=True,
            text=True,
        )

        if result.returncode != 0:
            return []

        return self.scan_diff(result.stdout)

    def scan_directory(
        self,
        directory: Path,
        extensions: Optional[list[str]] = None
    ) -> list[SecretMatch]:
        """Scan all files in a directory for secrets.

        Args:
            directory: Directory to scan
            extensions: Optional list of file extensions to scan

        Returns:
            List of SecretMatch objects for detected secrets
        """
        matches = []

        # Default extensions to scan
        if extensions is None:
            extensions = [
                '.py', '.js', '.ts', '.jsx', '.tsx',
                '.json', '.yaml', '.yml', '.toml',
                '.env', '.conf', '.config', '.cfg',
                '.sh', '.bash', '.zsh',
                '.rb', '.go', '.rs', '.java',
                '.php', '.cs', '.cpp', '.c', '.h',
            ]

        for path in directory.rglob('*'):
            # Skip directories
            if path.is_dir():
                continue

            # Skip files without matching extensions
            if extensions and path.suffix.lower() not in extensions:
                continue

            # Skip common non-code directories
            if any(part.startswith('.') or part in ['node_modules', '__pycache__', 'venv', '.venv', 'dist', 'build']
                   for part in path.parts):
                continue

            matches.extend(self.scan_file(path))

        return matches
