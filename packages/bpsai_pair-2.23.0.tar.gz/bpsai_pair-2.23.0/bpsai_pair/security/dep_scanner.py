"""Dependency vulnerability scanner.

Scans Python (pip-audit) and Node.js (npm audit) dependencies for known CVEs.
"""
import hashlib
import json
import subprocess
from datetime import datetime
from pathlib import Path
from typing import Optional

from .dep_models import ScanReport, Severity, Vulnerability


class DependencyScanner:
    """Scans project dependencies for known vulnerabilities."""

    def __init__(self, cache_dir: Optional[Path] = None, cache_ttl: int = 3600):
        """Initialize with optional cache_dir and cache_ttl (seconds)."""
        self.cache_dir = cache_dir or Path.home() / ".cache" / "paircoder" / "vuln-scans"
        self.cache_ttl = cache_ttl

    def _get_cache_key(self, file_path: Path) -> str:
        """Generate cache key for a dependency file."""
        content = file_path.read_bytes()
        return hashlib.sha256(content).hexdigest()[:16]

    def _get_cached_result(self, file_path: Path) -> Optional[list[Vulnerability]]:
        """Get cached scan result if still valid."""
        if not self.cache_dir.exists():
            return None

        cache_key = self._get_cache_key(file_path)
        cache_file = self.cache_dir / f"{cache_key}.json"

        if not cache_file.exists():
            return None

        cache_age = datetime.now().timestamp() - cache_file.stat().st_mtime
        if cache_age > self.cache_ttl:
            cache_file.unlink()
            return None

        try:
            with open(cache_file, encoding='utf-8') as f:
                data = json.load(f)
            return [
                Vulnerability(
                    package=v["package"],
                    version=v["version"],
                    cve_id=v["cve_id"],
                    severity=Severity.from_string(v["severity"]),
                    description=v["description"],
                    fixed_version=v.get("fixed_version"),
                    source=v.get("source", "cache"),
                )
                for v in data
            ]
        except (json.JSONDecodeError, KeyError):
            return None

    def _save_to_cache(self, file_path: Path, vulnerabilities: list[Vulnerability]):
        """Save scan result to cache."""
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        cache_key = self._get_cache_key(file_path)
        cache_file = self.cache_dir / f"{cache_key}.json"

        with open(cache_file, "w", encoding="utf-8") as f:
            json.dump([v.to_dict() for v in vulnerabilities], f)

    def scan_python(
        self, requirements: Path, use_cache: bool = True,
    ) -> tuple[list[Vulnerability], list[str]]:
        """Scan Python dependencies using pip-audit. Returns (vulns, errors)."""
        vulnerabilities: list[Vulnerability] = []
        errors: list[str] = []

        if use_cache:
            cached = self._get_cached_result(requirements)
            if cached is not None:
                return cached, []

        try:
            subprocess.run(["pip-audit", "--version"], capture_output=True, check=True)
        except (subprocess.CalledProcessError, FileNotFoundError):
            errors.append("pip-audit not installed. Install with: pip install pip-audit")
            return vulnerabilities, errors

        if requirements.suffix == ".toml":
            cmd = ["pip-audit", "--format", "json", "--progress-spinner", "off"]
        else:
            cmd = ["pip-audit", "-r", str(requirements), "--format", "json", "--progress-spinner", "off"]

        try:
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=300)
            if result.stdout:
                data = json.loads(result.stdout)
                vulnerabilities = self._parse_pip_audit(data)
            if result.stderr and "error" in result.stderr.lower():
                errors.append(result.stderr.strip())
        except subprocess.TimeoutExpired:
            errors.append("pip-audit scan timed out")
        except json.JSONDecodeError:
            errors.append("Failed to parse pip-audit output")
        except Exception as e:
            errors.append(f"pip-audit error: {str(e)}")

        if use_cache and not errors:
            self._save_to_cache(requirements, vulnerabilities)

        return vulnerabilities, errors

    def _parse_pip_audit(self, data: dict | list) -> list[Vulnerability]:
        """Parse pip-audit JSON output into Vulnerability list."""
        vulnerabilities = []

        if isinstance(data, dict):
            deps = data.get("dependencies", [])
        else:
            deps = data

        for dep in deps:
            package = dep.get("name", "")
            version = dep.get("version", "")
            vulns = dep.get("vulns", [])

            for vuln in vulns:
                vuln_id = vuln.get("id", "")
                if not vuln_id.startswith("CVE"):
                    aliases = vuln.get("aliases", [])
                    cve_id = next((a for a in aliases if a.startswith("CVE")), vuln_id)
                else:
                    cve_id = vuln_id

                fix_versions = vuln.get("fix_versions", [])
                fixed_version = fix_versions[0] if fix_versions else None
                severity_str = vuln.get("severity", "high")
                severity = Severity.from_string(severity_str)

                vulnerabilities.append(Vulnerability(
                    package=package, version=version, cve_id=cve_id,
                    severity=severity,
                    description=vuln.get("description", "No description available"),
                    fixed_version=fixed_version, source="pip-audit",
                ))

        return vulnerabilities

    def scan_npm(
        self, package_json: Path, use_cache: bool = True,
    ) -> tuple[list[Vulnerability], list[str]]:
        """Scan npm dependencies using npm audit. Returns (vulns, errors)."""
        vulnerabilities: list[Vulnerability] = []
        errors: list[str] = []

        if use_cache:
            cached = self._get_cached_result(package_json)
            if cached is not None:
                return cached, []

        try:
            subprocess.run(["npm", "--version"], capture_output=True, check=True)
        except (subprocess.CalledProcessError, FileNotFoundError):
            errors.append("npm not installed or not in PATH")
            return vulnerabilities, errors

        node_modules = package_json.parent / "node_modules"
        if not node_modules.exists():
            errors.append("node_modules not found. Run 'npm install' first.")
            return vulnerabilities, errors

        try:
            result = subprocess.run(
                ["npm", "audit", "--json"],
                cwd=package_json.parent, capture_output=True, text=True, timeout=300,
            )
            if result.stdout:
                data = json.loads(result.stdout)
                vulnerabilities = self._parse_npm_audit(data)
        except subprocess.TimeoutExpired:
            errors.append("npm audit scan timed out")
        except json.JSONDecodeError:
            errors.append("Failed to parse npm audit output")
        except Exception as e:
            errors.append(f"npm audit error: {str(e)}")

        if use_cache and not errors:
            self._save_to_cache(package_json, vulnerabilities)

        return vulnerabilities, errors

    def _parse_npm_audit(self, data: dict) -> list[Vulnerability]:
        """Parse npm audit JSON output into Vulnerability list."""
        vulnerabilities = []
        vulns_dict = data.get("vulnerabilities", {})

        for package_name, vuln_info in vulns_dict.items():
            severity_str = vuln_info.get("severity", "unknown")
            severity = Severity.from_string(severity_str)
            via = vuln_info.get("via", [])

            for via_item in via:
                if isinstance(via_item, dict):
                    cve_id = via_item.get("url", "").split("/")[-1] if via_item.get("url") else "N/A"
                    if not cve_id.startswith(("CVE", "GHSA")):
                        cve_id = f"NPM:{via_item.get('source', 'unknown')}"

                    vulnerabilities.append(Vulnerability(
                        package=package_name,
                        version=vuln_info.get("range", "unknown"),
                        cve_id=cve_id, severity=severity,
                        description=via_item.get("title", "No description available"),
                        fixed_version=vuln_info.get("fixAvailable", {}).get("version") if isinstance(vuln_info.get("fixAvailable"), dict) else None,
                        source="npm-audit",
                    ))

        return vulnerabilities

    def scan_all(
        self, root_dir: Optional[Path] = None, use_cache: bool = True,
    ) -> ScanReport:
        """Scan all detected dependency files. Returns aggregated ScanReport."""
        import time

        start_time = time.time()
        root_dir = root_dir or Path.cwd()

        all_vulns: list[Vulnerability] = []
        all_errors: list[str] = []
        packages_scanned = 0

        for req_file in self._find_python_deps(root_dir):
            vulns, errors = self.scan_python(req_file, use_cache=use_cache)
            all_vulns.extend(vulns)
            all_errors.extend(errors)
            packages_scanned += self._count_python_packages(req_file)

        for pkg_file in self._find_npm_deps(root_dir):
            vulns, errors = self.scan_npm(pkg_file, use_cache=use_cache)
            all_vulns.extend(vulns)
            all_errors.extend(errors)
            packages_scanned += self._count_npm_packages(pkg_file)

        return ScanReport(
            vulnerabilities=all_vulns, scanned_at=datetime.now(),
            packages_scanned=packages_scanned,
            scan_duration=time.time() - start_time, errors=all_errors,
        )

    def _find_python_deps(self, root_dir: Path) -> list[Path]:
        """Find Python dependency files."""
        files = []
        for pattern in ["requirements*.txt", "requirements/*.txt"]:
            files.extend(root_dir.glob(pattern))
        pyproject = root_dir / "pyproject.toml"
        if pyproject.exists():
            files.append(pyproject)
        return files

    def _find_npm_deps(self, root_dir: Path) -> list[Path]:
        """Find npm dependency files (excluding node_modules)."""
        return [p for p in root_dir.glob("**/package.json") if "node_modules" not in str(p)]

    def _count_python_packages(self, req_file: Path) -> int:
        """Count packages in Python requirements file."""
        try:
            content = req_file.read_text(encoding="utf-8")
            if req_file.suffix == ".toml":
                return len([l for l in content.split("\n") if "=" in l and not l.strip().startswith("#")])
            return len([l for l in content.split("\n") if l.strip() and not l.strip().startswith("#")])
        except Exception:
            return 0

    def _count_npm_packages(self, pkg_file: Path) -> int:
        """Count packages in package.json."""
        try:
            data = json.loads(pkg_file.read_text(encoding="utf-8"))
            return len(data.get("dependencies", {})) + len(data.get("devDependencies", {}))
        except Exception:
            return 0
