"""Security review pattern definitions.

Contains compiled pattern lists for detecting secrets,
injection vulnerabilities, and false-positive exclusions.
"""

# Secret detection patterns
SECRET_PATTERNS = [
    # API Keys
    (r'api[_-]?key\s*[=:]\s*["\']([^"\']{10,})["\']', "Hardcoded API key detected"),
    (r'apikey\s*[=:]\s*["\']([^"\']{10,})["\']', "Hardcoded API key detected"),

    # Passwords
    (r'password\s*[=:]\s*["\']([^"\']+)["\']', "Hardcoded password detected"),
    (r'passwd\s*[=:]\s*["\']([^"\']+)["\']', "Hardcoded password detected"),
    (r'db_password\s*[=:]\s*["\']([^"\']+)["\']', "Hardcoded database password detected"),

    # AWS Credentials
    (r'AKIA[0-9A-Z]{16}', "AWS Access Key ID detected"),
    (r'aws_secret_access_key\s*[=:]\s*["\']([^"\']{20,})["\']', "AWS Secret Access Key detected"),
    (r'AWS_SECRET_ACCESS_KEY\s*[=:]\s*["\']([^"\']{20,})["\']', "AWS Secret Access Key detected"),

    # Private Keys
    (r'-----BEGIN\s+(RSA\s+)?PRIVATE\s+KEY-----', "Private key detected"),
    (r'-----BEGIN\s+OPENSSH\s+PRIVATE\s+KEY-----', "SSH private key detected"),

    # Tokens
    (r'ghp_[A-Za-z0-9]{36}', "GitHub Personal Access Token detected"),
    (r'github_pat_[A-Za-z0-9]{22}_[A-Za-z0-9]{59}', "GitHub PAT (fine-grained) detected"),
    (r'gho_[A-Za-z0-9]{36}', "GitHub OAuth Token detected"),

    # JWT Tokens
    (r'eyJ[A-Za-z0-9_-]{10,}\.eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}', "JWT token detected"),

    # Database Connection Strings
    (r'(postgresql|mysql|mongodb)://[^:]+:[^@]+@', "Database connection string with credentials detected"),

    # Slack Webhooks
    (r'https://hooks\.slack\.com/services/T[A-Z0-9]+/B[A-Z0-9]+/[A-Za-z0-9]+', "Slack webhook URL detected"),

    # Generic Secrets
    (r'secret\s*[=:]\s*["\']([^"\']{8,})["\']', "Hardcoded secret detected"),
    (r'token\s*[=:]\s*["\']([^"\']{20,})["\']', "Hardcoded token detected"),
]

# Injection vulnerability patterns
INJECTION_PATTERNS = [
    # SQL Injection
    (r'f["\']SELECT\s+.*\{', "Potential SQL injection: f-string in SELECT query"),
    (r'f["\']INSERT\s+.*\{', "Potential SQL injection: f-string in INSERT query"),
    (r'f["\']UPDATE\s+.*\{', "Potential SQL injection: f-string in UPDATE query"),
    (r'f["\']DELETE\s+.*\{', "Potential SQL injection: f-string in DELETE query"),
    (r'\.format\(.*\).*execute', "Potential SQL injection: string format in query"),

    # Command Injection
    (r'os\.system\s*\(\s*f["\']', "Command injection: os.system with f-string"),
    (r'os\.popen\s*\(\s*f["\']', "Command injection: os.popen with f-string"),
    (r'subprocess\..*shell\s*=\s*True', "Potential command injection: shell=True"),
    (r'subprocess\.call\s*\(\s*[^,\[\]]+,\s*shell\s*=\s*True', "Command injection: subprocess.call with shell=True"),

    # Path Traversal
    (r'\.\./', "Potential path traversal: '../' detected"),
]

# Patterns to ignore (false positives)
IGNORE_PATTERNS = [
    r'os\.environ\.get\s*\(["\']',  # Reading from env vars
    r'os\.getenv\s*\(["\']',  # Reading from env vars
    r'environ\[["\']',  # Accessing environ dict
    r'#.*password',  # Comments about passwords
    r'#.*secret',  # Comments about secrets
]
