"""Command matching logic for the allowlist system.

Extracted from AllowlistManager to keep modules under size limits.
Provides pure functions for command normalization and pattern matching.
"""

import re
from typing import Optional


def normalize_command(command: str) -> str:
    """Normalize command string for matching.

    Collapses whitespace and strips leading/trailing spaces.
    """
    return " ".join(command.split())


def matches_list(command: str, patterns: list[str]) -> Optional[str]:
    """Check if command matches any pattern in the list.

    Supports exact match, prefix match, glob-style wildcards,
    and substring match for multi-word patterns.

    Returns the matched pattern or None.
    """
    cmd_normalized = normalize_command(command)
    cmd_lower = cmd_normalized.lower()

    for pattern in patterns:
        pattern_lower = pattern.lower()

        # Exact match
        if cmd_lower == pattern_lower:
            return pattern

        # Prefix match (command starts with pattern)
        if cmd_lower.startswith(pattern_lower + " ") or cmd_lower.startswith(
            pattern_lower
        ):
            if pattern_lower.endswith("*"):
                prefix = pattern_lower.rstrip("*").rstrip()
                if cmd_lower.startswith(prefix):
                    return pattern
            elif cmd_lower == pattern_lower or cmd_lower.startswith(
                pattern_lower + " "
            ):
                return pattern

        # Glob-style matching
        if "*" in pattern:
            glob_pattern = pattern.replace("*", ".*")
            if re.match(glob_pattern, cmd_normalized, re.IGNORECASE):
                return pattern

        # Substring match for multi-word patterns (e.g., "curl | bash")
        # Single-word patterns use prefix matching only to avoid
        # false positives (e.g., "comm" matching "git commit")
        if " " in pattern_lower or "|" in pattern_lower:
            if pattern_lower in cmd_lower:
                return pattern

    return None


def matches_regex_patterns(
    command: str, patterns: list[str]
) -> Optional[str]:
    """Check if command matches any regex pattern.

    Returns the matched pattern or None. Invalid regex patterns
    are silently skipped.
    """
    cmd_normalized = normalize_command(command)

    for pattern in patterns:
        try:
            if re.search(pattern, cmd_normalized, re.IGNORECASE):
                return pattern
        except re.error:
            continue

    return None
