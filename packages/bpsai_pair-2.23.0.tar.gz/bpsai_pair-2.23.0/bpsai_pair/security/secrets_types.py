"""Secret detection data types for PairCoder.

This module provides data models for secret detection:
- SecretType: Enum of detectable secret types
- SecretMatch: Data class for detected secrets
- AllowlistConfig: Configuration for false positive suppression
"""

import fnmatch
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Optional

import yaml


class SecretType(Enum):
    """Types of secrets that can be detected."""
    AWS_ACCESS_KEY = "aws_access_key"
    AWS_SECRET_KEY = "aws_secret_key"
    GITHUB_TOKEN = "github_token"
    GITHUB_PAT = "github_pat"
    GITHUB_OAUTH = "github_oauth"
    SLACK_TOKEN = "slack_token"
    SLACK_WEBHOOK = "slack_webhook"
    PRIVATE_KEY = "private_key"
    SSH_PRIVATE_KEY = "ssh_private_key"
    JWT_TOKEN = "jwt_token"
    GENERIC_API_KEY = "generic_api_key"
    GENERIC_PASSWORD = "generic_password"
    GENERIC_SECRET = "generic_secret"
    GENERIC_TOKEN = "generic_token"
    DATABASE_URL = "database_url"
    STRIPE_KEY = "stripe_key"
    SENDGRID_KEY = "sendgrid_key"
    TWILIO_KEY = "twilio_key"
    GOOGLE_API_KEY = "google_api_key"


@dataclass
class SecretMatch:
    """A detected secret in code.

    Attributes:
        secret_type: The type of secret detected
        file_path: Path to the file containing the secret
        line_number: Line number where secret was found
        line_content: The line containing the secret (redacted)
        match: The matched pattern (redacted for display)
        confidence: Confidence score (0-1) for the detection
    """
    secret_type: SecretType
    file_path: str
    line_number: int
    line_content: str
    match: str
    confidence: float = 1.0

    def __post_init__(self):
        """Redact sensitive content after initialization."""
        self.match_redacted = self._redact(self.match)
        self.line_redacted = self._redact_line(self.line_content, self.match)

    def _redact(self, value: str) -> str:
        """Redact a secret value for safe display."""
        if len(value) <= 8:
            return "*" * len(value)
        return value[:4] + "*" * (len(value) - 8) + value[-4:]

    def _redact_line(self, line: str, match: str) -> str:
        """Redact the secret in the line content."""
        return line.replace(match, self._redact(match))

    def format(self) -> str:
        """Format the match for display."""
        return (
            f"{self.file_path}:{self.line_number}: "
            f"[{self.secret_type.value}] {self.line_redacted.strip()}"
        )

    def to_dict(self) -> dict:
        """Convert to dictionary for JSON output."""
        return {
            "type": self.secret_type.value,
            "file": self.file_path,
            "line": self.line_number,
            "content": self.line_redacted,
            "confidence": self.confidence,
        }


@dataclass
class AllowlistConfig:
    """Configuration for secret detection allowlist.

    Attributes:
        allowed_patterns: Patterns that are allowed (e.g., example keys)
        allowed_files: File patterns to skip scanning
        allowed_hashes: SHA256 hashes of allowed secret values
    """
    allowed_patterns: list[str] = field(default_factory=list)
    allowed_files: list[str] = field(default_factory=list)
    allowed_hashes: list[str] = field(default_factory=list)

    @classmethod
    def load(cls, path: Path) -> "AllowlistConfig":
        """Load allowlist configuration from YAML file.

        Args:
            path: Path to the allowlist YAML file

        Returns:
            AllowlistConfig instance
        """
        if not path.exists():
            return cls()

        with open(path, encoding='utf-8') as f:
            data = yaml.safe_load(f) or {}

        return cls(
            allowed_patterns=data.get("allowed_patterns", []),
            allowed_files=data.get("allowed_files", []),
            allowed_hashes=data.get("allowed_hashes", []),
        )

    def is_allowed_file(self, file_path: str) -> bool:
        """Check if a file should be skipped.

        Args:
            file_path: Path to check

        Returns:
            True if the file should be skipped
        """
        for pattern in self.allowed_files:
            if fnmatch.fnmatch(file_path, pattern):
                return True
        return False

    def is_allowed_pattern(self, match: str) -> bool:
        """Check if a matched value is in the allowlist.

        Args:
            match: The matched secret value

        Returns:
            True if the match is allowed
        """
        for pattern in self.allowed_patterns:
            if fnmatch.fnmatch(match, pattern):
                return True
        return False
