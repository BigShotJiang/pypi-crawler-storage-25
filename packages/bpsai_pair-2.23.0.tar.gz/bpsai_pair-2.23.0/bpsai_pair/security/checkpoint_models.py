"""Checkpoint data models and exceptions.

This module provides exception classes, constants, and data models
for the git checkpoint system.
"""

import subprocess
from dataclasses import dataclass


class CheckpointError(Exception):
    """Base exception for checkpoint errors."""
    pass


class NotAGitRepoError(CheckpointError):
    """Raised when path is not a git repository."""
    pass


class CheckpointNotFoundError(CheckpointError):
    """Raised when checkpoint tag doesn't exist."""
    pass


class NoCheckpointsError(CheckpointError):
    """Raised when no checkpoints exist."""
    pass


CHECKPOINT_PREFIX = "paircoder-checkpoint-"
CONTAINMENT_CHECKPOINT_PREFIX = "containment-"


@dataclass
class CheckpointInfo:
    """Information about a checkpoint."""
    tag: str
    commit: str
    timestamp: str
    message: str = ""
