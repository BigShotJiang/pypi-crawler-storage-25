"""Core git checkpoint infrastructure.

This module provides GitCheckpointBase with core git operations,
stash management, and basic checkpoint CRUD.
"""

import subprocess
from datetime import datetime
from pathlib import Path
from typing import Optional

from .checkpoint_models import (
    NotAGitRepoError,
    CHECKPOINT_PREFIX,
)


class GitCheckpointBase:
    """Base class for git checkpoint operations.

    Provides core infrastructure: git command execution, stash management,
    and basic checkpoint create/delete.

    Attributes:
        repo_path: Path to the git repository
        max_checkpoints: Maximum checkpoints to retain
        auto_cleanup: Whether to auto-cleanup on create
        checkpoints: List of checkpoint tags created in this session
    """

    def __init__(
        self,
        repo_path: Path,
        max_checkpoints: int = 10,
        auto_cleanup: bool = False
    ):
        """Initialize GitCheckpointBase.

        Args:
            repo_path: Path to git repository
            max_checkpoints: Maximum checkpoints to keep
            auto_cleanup: Auto-cleanup old checkpoints on create

        Raises:
            NotAGitRepoError: If path is not a git repository
        """
        self.repo_path = Path(repo_path)
        self.max_checkpoints = max_checkpoints
        self.auto_cleanup = auto_cleanup
        self.checkpoints: list[str] = []

        # Verify it's a git repo
        if not self._is_git_repo():
            raise NotAGitRepoError(f"{repo_path} is not a git repository")

    def _run_git(self, *args: str, check: bool = True) -> subprocess.CompletedProcess:
        """Run a git command.

        Args:
            *args: Git command arguments
            check: Whether to raise on non-zero exit

        Returns:
            CompletedProcess result
        """
        return subprocess.run(
            ["git"] + list(args),
            cwd=self.repo_path,
            capture_output=True,
            text=True,
            check=check
        )

    def _is_git_repo(self) -> bool:
        """Check if path is a git repository."""
        result = self._run_git("rev-parse", "--git-dir", check=False)
        return result.returncode == 0

    def _get_current_commit(self) -> str:
        """Get current HEAD commit hash."""
        result = self._run_git("rev-parse", "HEAD")
        return result.stdout.strip()

    def _generate_tag_name(self, prefix: str = CHECKPOINT_PREFIX) -> str:
        """Generate unique checkpoint tag name.

        Args:
            prefix: Tag prefix to use (default: paircoder-checkpoint-)

        Returns:
            Generated tag name
        """
        timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
        # Add microseconds only for default prefix to ensure uniqueness
        if prefix == CHECKPOINT_PREFIX:
            timestamp = datetime.now().strftime("%Y%m%d-%H%M%S-%f")
        return f"{prefix}{timestamp}"

    def is_dirty(self) -> bool:
        """Check if working directory has uncommitted changes.

        Returns:
            True if there are staged or unstaged changes
        """
        result = self._run_git("status", "--porcelain")
        return len(result.stdout.strip()) > 0

    def stash_if_dirty(self, message: str = "") -> Optional[str]:
        """Stash uncommitted changes if working directory is dirty.

        Args:
            message: Stash message (auto-generated if not provided)

        Returns:
            Stash reference if changes were stashed, None otherwise
        """
        if not self.is_dirty():
            return None

        stash_msg = message or f"Auto-stash for checkpoint at {datetime.now().isoformat()}"
        result = self._run_git("stash", "push", "-m", stash_msg, check=False)

        if result.returncode == 0 and "Saved working directory" in result.stdout:
            return stash_msg
        return None

    def pop_stash(self, stash_ref: Optional[str] = None) -> bool:
        """Pop the most recent stash or a specific stash.

        Args:
            stash_ref: Stash message to find and pop (if None, pops most recent)

        Returns:
            True if stash was popped successfully
        """
        if stash_ref:
            # Find the stash index with this message
            result = self._run_git("stash", "list", check=False)
            for line in result.stdout.strip().split("\n"):
                if stash_ref in line:
                    stash_idx = line.split(":")[0]
                    pop_result = self._run_git("stash", "pop", stash_idx, check=False)
                    return pop_result.returncode == 0

        # Pop most recent stash
        result = self._run_git("stash", "pop", check=False)
        return result.returncode == 0

    def create_checkpoint(self, message: str = "") -> str:
        """Create a checkpoint at current HEAD.

        Args:
            message: Optional message describing the checkpoint

        Returns:
            Tag name of the created checkpoint
        """
        tag_name = self._generate_tag_name()

        # Create annotated tag
        tag_message = message or f"Checkpoint at {datetime.now().isoformat()}"
        self._run_git("tag", "-a", tag_name, "-m", tag_message)

        self.checkpoints.append(tag_name)

        # Auto-cleanup if enabled
        if self.auto_cleanup:
            self.cleanup_old_checkpoints()

        return tag_name

    def delete_checkpoint(self, checkpoint: str) -> None:
        """Delete a specific checkpoint.

        Args:
            checkpoint: Tag name to delete

        Raises:
            CheckpointNotFoundError: If checkpoint doesn't exist
        """
        from .checkpoint_models import CheckpointNotFoundError

        result = self._run_git("tag", "-l", checkpoint, check=False)
        if checkpoint not in result.stdout:
            raise CheckpointNotFoundError(f"Checkpoint '{checkpoint}' not found")

        self._run_git("tag", "-d", checkpoint)
