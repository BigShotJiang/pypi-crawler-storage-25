"""Default allowlist configuration and block reasons.

Separated from allowlist.py to keep module sizes manageable.
"""

# Default allowlist configuration
DEFAULT_ALLOWLIST = {
    "commands": {
        "always_allowed": [
            # Git read operations
            "git status",
            "git diff",
            "git log",
            "git branch",
            "git show",
            "git remote",
            "git fetch",
            # Testing
            "pytest",
            "python -m pytest",
            # PairCoder
            "bpsai-pair",
            # Read-only utilities
            "ls",
            "cat",
            "head",
            "tail",
            "grep",
            "find",
            "wc",
            "which",
            "pwd",
            "echo",
            "env",
            "printenv",
            # Python read operations
            "python --version",
            "python -c",
            "pip list",
            "pip show",
            "pip freeze",
            # Text processing & system info (CC 2.1.71, GitHub #79)
            "fmt",
            "comm",
            "cmp",
            "numfmt",
            "expr",
            "test",
            "printf",
            "getconf",
            "seq",
            "tsort",
            "pr",
        ],
        "require_review": [
            # Git write operations
            "git push",
            "git commit",
            "git merge",
            "git rebase",
            "git reset",
            "git checkout",
            "git stash",
            # Package management
            "pip install",
            "pip uninstall",
            "npm install",
            "npm uninstall",
            "yarn add",
            "cargo add",
            # Docker
            "docker",
            # File operations
            "mv",
            "cp",
            "mkdir",
            "touch",
            # Network
            "curl",
            "wget",
        ],
        "always_blocked": [
            # Destructive operations
            "rm -rf /",
            "rm -rf /*",
            "rm -rf ~",
            "rm -rf $HOME",
            # Privileged operations
            "sudo rm",
            "sudo chmod",
            "sudo chown",
            # Remote code execution
            "curl | bash",
            "curl | sh",
            "wget | bash",
            "wget | sh",
            # System modification
            "mkfs",
            "dd if=",
            ":(){ :|:& };:",  # Fork bomb
        ],
        "patterns": {
            "blocked": [
                r"rm\s+-rf\s+/[^.]",  # rm -rf on absolute paths (not ./)
                r"curl.*\|\s*(ba)?sh",  # curl piped to shell
                r"wget.*\|\s*(ba)?sh",  # wget piped to shell
                r"sudo\s+rm",  # sudo rm anything
                r"docker.*--privileged",  # privileged docker
                r"chmod\s+777",  # overly permissive chmod
                r">\s*/etc/",  # writing to /etc
                r">\s*/usr/",  # writing to /usr
            ],
            "review": [
                r"rm\s+-rf",  # any rm -rf needs review
                r"git\s+push.*--force",  # force push
                r"git\s+reset.*--hard",  # hard reset
            ],
        },
    }
}

# Reasons for blocking specific patterns
BLOCK_REASONS = {
    r"rm\s+-rf\s+/": (
        "Recursive deletion of system directories could destroy the entire system."
    ),
    r"rm\s+-rf": (
        "Recursive forced deletion is dangerous and could cause data loss."
    ),
    r"sudo\s+rm": (
        "Privileged file deletion bypasses safety checks and could damage the system."
    ),
    r"curl.*\|\s*(ba)?sh": (
        "Piping remote content directly to shell allows arbitrary code execution."
    ),
    r"wget.*\|\s*(ba)?sh": (
        "Piping remote content directly to shell allows arbitrary code execution."
    ),
    r"docker.*--privileged": (
        "Privileged Docker containers can escape isolation and access the host system."
    ),
    r"chmod\s+777": (
        "Setting world-writable permissions creates security vulnerabilities."
    ),
    r">\s*/etc/": "Writing to system configuration could break the system.",
    r">\s*/usr/": "Writing to system directories could break installed software.",
    "rm -rf /": "This would delete the entire filesystem.",
    "sudo rm": "Privileged deletion operations are blocked for safety.",
    "curl | bash": "Remote code execution via piped shell is dangerous.",
    "curl | sh": "Remote code execution via piped shell is dangerous.",
    "wget | bash": "Remote code execution via piped shell is dangerous.",
    "wget | sh": "Remote code execution via piped shell is dangerous.",
}
