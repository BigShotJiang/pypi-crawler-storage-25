"""Command allowlist system: ALLOW, REVIEW, or BLOCK classification."""

from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Optional

import yaml

from .allowlist_data import BLOCK_REASONS, DEFAULT_ALLOWLIST
from .allowlist_matching import matches_list, matches_regex_patterns, normalize_command


class CommandDecision(Enum):
    """Decision for a command check."""

    ALLOW = "allow"
    REVIEW = "review"
    BLOCK = "block"


@dataclass
class CheckResult:
    """Full result of a command check."""

    decision: CommandDecision
    reason: Optional[str] = None
    matched_rule: Optional[str] = None
    command: str = ""


@dataclass
class AllowlistManager:
    """Manages command allowlist for security checks.

    Attributes:
        always_allowed: Commands that execute without prompts
        always_blocked: Commands that are always rejected
        require_review: Commands that need confirmation
        blocked_patterns: Regex patterns for blocked commands
        review_patterns: Regex patterns for commands needing review
    """

    config_path: Optional[Path] = None
    always_allowed: list[str] = field(default_factory=list)
    always_blocked: list[str] = field(default_factory=list)
    require_review: list[str] = field(default_factory=list)
    blocked_patterns: list[str] = field(default_factory=list)
    review_patterns: list[str] = field(default_factory=list)

    def __post_init__(self):
        """Load configuration after initialization."""
        config = self._load_config()
        commands = config.get("commands", {})

        self.always_allowed = commands.get("always_allowed", [])
        self.always_blocked = commands.get("always_blocked", [])
        self.require_review = commands.get("require_review", [])

        patterns = commands.get("patterns", {})
        self.blocked_patterns = patterns.get("blocked", [])
        self.review_patterns = patterns.get("review", [])

    def _load_config(self) -> dict:
        """Load configuration from file or use defaults."""
        if self.config_path and self.config_path.exists():
            try:
                with open(self.config_path, encoding='utf-8') as f:
                    return yaml.safe_load(f) or DEFAULT_ALLOWLIST
            except Exception:
                return DEFAULT_ALLOWLIST
        return DEFAULT_ALLOWLIST

    def _check_blocked(self, cmd: str) -> Optional[CheckResult]:
        """Check if command matches blocked patterns or list."""
        matched = matches_regex_patterns(cmd, self.blocked_patterns)
        if matched:
            return CheckResult(
                decision=CommandDecision.BLOCK,
                reason=BLOCK_REASONS.get(matched, f"Matches blocked pattern: {matched}"),
                matched_rule=f"pattern:{matched}",
                command=cmd,
            )
        matched = matches_list(cmd, self.always_blocked)
        if matched:
            return CheckResult(
                decision=CommandDecision.BLOCK,
                reason=BLOCK_REASONS.get(
                    matched, f"Command is in blocked list: {matched}"
                ),
                matched_rule=f"blocked:{matched}",
                command=cmd,
            )
        return None

    def _check_allowed(self, cmd: str) -> Optional[CheckResult]:
        """Check if command matches allowed list."""
        matched = matches_list(cmd, self.always_allowed)
        if matched:
            return CheckResult(
                decision=CommandDecision.ALLOW,
                reason=None,
                matched_rule=f"allowed:{matched}",
                command=cmd,
            )
        return None

    def _check_review(self, cmd: str) -> Optional[CheckResult]:
        """Check if command matches review patterns or list."""
        matched = matches_regex_patterns(cmd, self.review_patterns)
        if matched:
            return CheckResult(
                decision=CommandDecision.REVIEW,
                reason=f"Matches review pattern: {matched}",
                matched_rule=f"pattern:{matched}",
                command=cmd,
            )
        matched = matches_list(cmd, self.require_review)
        if matched:
            return CheckResult(
                decision=CommandDecision.REVIEW,
                reason=f"Command requires review: {matched}",
                matched_rule=f"review:{matched}",
                command=cmd,
            )
        return None

    def check_command(self, command: str) -> CommandDecision:
        """Check a command and return ALLOW, REVIEW, or BLOCK."""
        return self.check_command_full(command).decision

    def check_command_full(self, command: str) -> CheckResult:
        """Check a command and return full details.

        Priority: blocked > allowed > review > default(review).
        """
        cmd = normalize_command(command)

        for checker in (self._check_blocked, self._check_allowed, self._check_review):
            result = checker(cmd)
            if result:
                return result

        return CheckResult(
            decision=CommandDecision.REVIEW,
            reason="Unknown command - requires review",
            matched_rule="default:unknown",
            command=cmd,
        )

    def get_blocked_reason(self, command: str) -> Optional[str]:
        """Get the reason a command is blocked.

        Returns reason string if blocked, None if not blocked.
        """
        result = self.check_command_full(command)
        if result.decision == CommandDecision.BLOCK:
            return result.reason
        return None

    def add_to_allowlist(self, command_or_pattern: str) -> None:
        """Add a command or pattern to the always_allowed list."""
        if command_or_pattern not in self.always_allowed:
            self.always_allowed.append(command_or_pattern)

    def add_to_blocklist(self, command_or_pattern: str, reason: str = "") -> None:
        """Add a command or pattern to the always_blocked list."""
        if command_or_pattern not in self.always_blocked:
            self.always_blocked.append(command_or_pattern)
            if reason:
                BLOCK_REASONS[command_or_pattern] = reason

    def save_config(self, path: Optional[Path] = None) -> None:
        """Save current configuration to file."""
        save_path = path or self.config_path
        if not save_path:
            raise ValueError("No path specified for saving config")

        config = {
            "commands": {
                "always_allowed": self.always_allowed,
                "always_blocked": self.always_blocked,
                "require_review": self.require_review,
                "patterns": {
                    "blocked": self.blocked_patterns,
                    "review": self.review_patterns,
                },
            }
        }

        save_path.parent.mkdir(parents=True, exist_ok=True)
        with open(save_path, "w", encoding="utf-8") as f:
            yaml.dump(config, f, default_flow_style=False, sort_keys=False)
