"""Secret scan result formatting for PairCoder.

This module provides display formatting for secret scan results.
"""

from .secrets_types import SecretMatch


def format_scan_results(matches: list[SecretMatch], verbose: bool = False) -> str:
    """Format scan results for display.

    Args:
        matches: List of SecretMatch objects
        verbose: Whether to show detailed output

    Returns:
        Formatted string for display
    """
    if not matches:
        return "No secrets detected."

    lines = [f"Found {len(matches)} potential secret(s):\n"]

    # Group by file
    by_file: dict[str, list[SecretMatch]] = {}
    for match in matches:
        by_file.setdefault(match.file_path, []).append(match)

    for file_path, file_matches in sorted(by_file.items()):
        lines.append(f"\n{file_path}:")
        for match in sorted(file_matches, key=lambda m: m.line_number):
            if verbose:
                lines.append(f"  Line {match.line_number}: [{match.secret_type.value}]")
                lines.append(f"    {match.line_redacted.strip()}")
                lines.append(f"    Confidence: {match.confidence:.0%}")
            else:
                lines.append(f"  :{match.line_number}: {match.secret_type.value}")

    return '\n'.join(lines)
