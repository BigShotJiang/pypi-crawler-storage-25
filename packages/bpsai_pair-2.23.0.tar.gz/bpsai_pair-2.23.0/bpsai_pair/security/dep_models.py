"""Data models for dependency vulnerability scanning.

Severity enum, Vulnerability dataclass, and ScanReport dataclass.
"""
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Optional


class Severity(Enum):
    """Vulnerability severity levels."""
    UNKNOWN = "unknown"
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"

    @classmethod
    def from_string(cls, value: str) -> "Severity":
        """Convert string to Severity enum."""
        value_lower = value.lower()
        for severity in cls:
            if severity.value == value_lower:
                return severity
        return cls.UNKNOWN

    def __lt__(self, other: "Severity") -> bool:
        order = [self.UNKNOWN, self.LOW, self.MEDIUM, self.HIGH, self.CRITICAL]
        return order.index(self) < order.index(other)

    def __le__(self, other: "Severity") -> bool:
        return self == other or self < other


@dataclass
class Vulnerability:
    """A detected vulnerability in a dependency."""
    package: str
    version: str
    cve_id: str
    severity: Severity
    description: str
    fixed_version: Optional[str] = None
    source: str = "unknown"

    def format(self) -> str:
        """Format vulnerability for display."""
        fix_info = f" (fix: {self.fixed_version})" if self.fixed_version else ""
        return (
            f"[{self.severity.value.upper()}] {self.package}@{self.version}: "
            f"{self.cve_id}{fix_info}"
        )

    def to_dict(self) -> dict:
        """Convert to dictionary for JSON output."""
        return {
            "package": self.package,
            "version": self.version,
            "cve_id": self.cve_id,
            "severity": self.severity.value,
            "description": self.description,
            "fixed_version": self.fixed_version,
            "source": self.source,
        }


@dataclass
class ScanReport:
    """Aggregated vulnerability scan results."""
    vulnerabilities: list[Vulnerability] = field(default_factory=list)
    scanned_at: datetime = field(default_factory=datetime.now)
    packages_scanned: int = 0
    scan_duration: float = 0.0
    errors: list[str] = field(default_factory=list)

    def has_critical(self) -> bool:
        """Check if any critical vulnerabilities were found."""
        return any(v.severity == Severity.CRITICAL for v in self.vulnerabilities)

    def has_high_or_above(self) -> bool:
        """Check if any high or critical vulnerabilities were found."""
        return any(v.severity >= Severity.HIGH for v in self.vulnerabilities)

    def has_severity(self, min_severity: Severity) -> bool:
        """Check if any vulnerabilities meet or exceed the given severity."""
        return any(v.severity >= min_severity for v in self.vulnerabilities)

    def count_by_severity(self) -> dict[str, int]:
        """Count vulnerabilities by severity level."""
        counts: dict[str, int] = {}
        for vuln in self.vulnerabilities:
            key = vuln.severity.value
            counts[key] = counts.get(key, 0) + 1
        return counts

    def to_dict(self) -> dict:
        """Convert to dictionary for JSON output."""
        return {
            "vulnerabilities": [v.to_dict() for v in self.vulnerabilities],
            "scanned_at": self.scanned_at.isoformat(),
            "packages_scanned": self.packages_scanned,
            "scan_duration": self.scan_duration,
            "errors": self.errors,
            "summary": {
                "total": len(self.vulnerabilities),
                "by_severity": self.count_by_severity(),
                "has_critical": self.has_critical(),
                "has_high": self.has_high_or_above(),
            }
        }

    def format(self, verbose: bool = False) -> str:
        """Format report for display."""
        lines = []

        if not self.vulnerabilities:
            lines.append("No vulnerabilities found.")
            lines.append(f"Scanned {self.packages_scanned} packages in {self.scan_duration:.2f}s")
            return "\n".join(lines)

        lines.append(f"Found {len(self.vulnerabilities)} vulnerabilities:")
        lines.append("")

        by_severity: dict[Severity, list[Vulnerability]] = {}
        for vuln in self.vulnerabilities:
            by_severity.setdefault(vuln.severity, []).append(vuln)

        for severity in [Severity.CRITICAL, Severity.HIGH, Severity.MEDIUM, Severity.LOW]:
            if severity not in by_severity:
                continue
            vulns = by_severity[severity]
            lines.append(f"### {severity.value.upper()} ({len(vulns)})")
            for vuln in vulns:
                if verbose:
                    lines.append(f"  {vuln.package}@{vuln.version}")
                    lines.append(f"    CVE: {vuln.cve_id}")
                    lines.append(f"    {vuln.description[:100]}...")
                    if vuln.fixed_version:
                        lines.append(f"    Fix: upgrade to {vuln.fixed_version}")
                else:
                    lines.append(f"  {vuln.format()}")
            lines.append("")

        lines.append(f"Scanned {self.packages_scanned} packages in {self.scan_duration:.2f}s")

        if self.errors:
            lines.append("")
            lines.append("Errors:")
            for error in self.errors:
                lines.append(f"  - {error}")

        return "\n".join(lines)


def format_scan_report(report: ScanReport, verbose: bool = False) -> str:
    """Format scan report for display (convenience wrapper)."""
    return report.format(verbose=verbose)
