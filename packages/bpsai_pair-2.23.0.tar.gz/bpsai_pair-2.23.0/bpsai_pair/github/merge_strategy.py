"""Intent-driven merge strategy mapping.

Maps work intent and branch patterns to merge strategies (squash, merge, rebase).
Follows the signal -> route -> dispatch -> compose pattern.
"""
from __future__ import annotations

import fnmatch
import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, Optional, Tuple, Union

from ..planning.intent_detection import WorkIntent
from ..telemetry.signal_emitter import EmittedSignal, SignalEmitter

logger = logging.getLogger(__name__)

VALID_STRATEGIES = ("squash", "merge", "rebase")

DEFAULT_INTENT_STRATEGIES: Dict[str, str] = {
    "feature": "squash",
    "bug_fix": "merge",
    "refactor": "squash",
    "trivial": "merge",
    "documentation": "squash",
    "testing": "squash",
    "review": "squash",
    "question": "squash",
}

DEFAULT_BRANCH_PATTERNS: Dict[str, str] = {
    "hotfix/*": "merge",
    "engage/*": "squash",
    "feature/*": "squash",
    "refactor/*": "squash",
    "docs/*": "squash",
}


@dataclass
class MergeStrategyConfig:
    """Configuration for merge strategy selection."""

    intent_strategies: Dict[str, str] = field(
        default_factory=lambda: dict(DEFAULT_INTENT_STRATEGIES)
    )
    branch_patterns: Dict[str, str] = field(
        default_factory=lambda: dict(DEFAULT_BRANCH_PATTERNS)
    )
    default: str = "squash"

    @classmethod
    def from_dict(cls, data: Dict) -> MergeStrategyConfig:
        """Build config from a raw dictionary (config.yaml section)."""
        return cls(
            intent_strategies=data.get(
                "intent_strategies", dict(DEFAULT_INTENT_STRATEGIES)
            ),
            branch_patterns=data.get(
                "branch_patterns", dict(DEFAULT_BRANCH_PATTERNS)
            ),
            default=data.get("default", "squash"),
        )


def _match_branch_pattern(
    branch: str, patterns: Dict[str, str]
) -> Optional[str]:
    """Match a branch name against configured patterns."""
    for pattern, strategy in patterns.items():
        if fnmatch.fnmatch(branch, pattern):
            return strategy
    return None


def get_merge_strategy(
    intent: WorkIntent,
    branch: str,
    config: Optional[MergeStrategyConfig] = None,
    *,
    return_source: bool = False,
) -> Union[str, Tuple[str, str]]:
    """Determine merge strategy from work intent and branch name.

    Resolution order:
    1. Intent-based lookup (if intent is known)
    2. Branch pattern matching (fallback)
    3. Config default (last resort)

    Args:
        intent: The detected work intent.
        branch: The branch name being merged.
        config: Optional config override; uses defaults if None.
        return_source: If True, return (strategy, source) tuple.

    Returns:
        Strategy string, or (strategy, source) tuple when return_source=True.
        Source is one of: "intent", "branch_pattern", "default"
    """
    cfg = config or MergeStrategyConfig()

    # 1. Intent-based lookup
    if intent != WorkIntent.UNKNOWN:
        intent_key = intent.value
        strategy = cfg.intent_strategies.get(intent_key)
        if strategy and strategy in VALID_STRATEGIES:
            return (strategy, "intent") if return_source else strategy

    # 2. Branch pattern fallback
    pattern_strategy = _match_branch_pattern(branch, cfg.branch_patterns)
    if pattern_strategy and pattern_strategy in VALID_STRATEGIES:
        return (pattern_strategy, "branch_pattern") if return_source else pattern_strategy

    # 3. Config default
    strategy = cfg.default if cfg.default in VALID_STRATEGIES else "squash"
    return (strategy, "default") if return_source else strategy


def resolve_strategy_for_branch(
    branch: str,
    config: Optional[MergeStrategyConfig] = None,
) -> str:
    """Resolve merge strategy from branch name only (no intent context).

    Convenience wrapper for cases where no WorkIntent is available,
    e.g. PRs created outside PairCoder or manual git workflows.

    Args:
        branch: The branch name.
        config: Optional config override.

    Returns:
        One of: "squash", "merge", "rebase"
    """
    return get_merge_strategy(
        WorkIntent.UNKNOWN, branch, config=config
    )


def emit_merge_strategy_signal(
    project_root: Path,
    pr_number: int,
    strategy: str,
    source: str,
    branch: str,
) -> EmittedSignal:
    """Log a merge strategy decision to signals.jsonl.

    Args:
        project_root: Project root for telemetry path.
        pr_number: PR number being merged.
        strategy: Resolved strategy (squash, merge, rebase).
        source: How it was resolved (intent, label, branch_pattern, default, override).
        branch: Branch name being merged.

    Returns:
        The emitted signal.
    """
    emitter = SignalEmitter(project_root)
    return emitter._emit(
        signal_type="merge_strategy_decision",
        severity="info",
        payload={
            "pr_number": pr_number,
            "strategy": strategy,
            "source": source,
            "branch": branch,
        },
    )
