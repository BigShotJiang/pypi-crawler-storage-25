"""Pull Request management — re-export shim.

All implementation has moved to focused modules:
- pr_models.py: PRInfo dataclass
- pr_manager.py: PRManager class
- pr_workflow.py: PRWorkflow, auto_create_pr_for_branch, archive_task_on_merge
"""

from .pr_models import PRInfo  # noqa: F401
from .pr_manager import PRManager  # noqa: F401
from .pr_workflow import (  # noqa: F401
    PRWorkflow,
    auto_create_pr_for_branch,
    archive_task_on_merge,
    check_and_archive_merged_prs,
)

__all__ = [
    "PRInfo",
    "PRManager",
    "PRWorkflow",
    "auto_create_pr_for_branch",
    "archive_task_on_merge",
    "check_and_archive_merged_prs",
]
