"""Skill gap data models and constants.

This module provides data types and constants for the skill gap
detection system.
"""

import re
from collections import Counter
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Dict, List

# Trivial patterns that should never become skills
TRIVIAL_PATTERNS = [
    ("pytest", "fix"),
    ("npm test", "fix"),
    ("yarn test", "fix"),
    ("make test", "fix"),
    ("git add", "git commit"),
    ("git commit", "git push"),
    ("pip install", "python"),
    ("npm install", "npm run"),
    ("cargo build", "cargo run"),
]

# Mapping of command keywords to gerund verbs for name generation
COMMAND_VERBS = {
    "pytest": "testing",
    "test": "testing",
    "git": "managing-git",
    "commit": "committing",
    "diff": "reviewing",
    "review": "reviewing",
    "read": "reading",
    "edit": "editing",
    "debug": "debugging",
    "fix": "fixing",
    "build": "building",
    "deploy": "deploying",
    "lint": "linting",
    "format": "formatting",
    "search": "searching",
    "grep": "searching",
    "find": "finding",
    "create": "creating",
    "delete": "deleting",
    "update": "updating",
    "install": "installing",
    "run": "running",
}


@dataclass
class SkillGap:
    """Represents a detected skill gap."""

    pattern: List[str]
    suggested_name: str
    confidence: float  # 0.0 to 1.0
    frequency: int
    time_saved_estimate: str
    detected_at: str = field(default_factory=lambda: datetime.now().isoformat())

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        return {
            "pattern": self.pattern,
            "suggested_name": self.suggested_name,
            "confidence": self.confidence,
            "frequency": self.frequency,
            "time_saved_estimate": self.time_saved_estimate,
            "detected_at": self.detected_at,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "SkillGap":
        """Create SkillGap from dictionary."""
        return cls(
            pattern=data.get("pattern", []),
            suggested_name=data.get("suggested_name", ""),
            confidence=data.get("confidence", 0.0),
            frequency=data.get("frequency", 0),
            time_saved_estimate=data.get("time_saved_estimate", ""),
            detected_at=data.get("detected_at", datetime.now().isoformat()),
        )
