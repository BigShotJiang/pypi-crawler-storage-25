"""
Gap classification engine.

Contains the GapClassifier class that scores and classifies gaps
as skills, subagents, or ambiguous based on multiple factors.
"""

from typing import Dict, List, Optional, Union

from .gap_detector import SkillGap
from .subagent_detector import SubagentGap
from .classifier_models import (
    AllGaps,
    ClassificationScores,
    ClassifiedGap,
    GapType,
    SkillRecommendation,
    SubagentRecommendation,
)


class GapClassifier:
    """Classifies gaps as skills, subagents, or ambiguous."""

    # Thresholds for classification
    SKILL_THRESHOLD = 0.6  # Above this = likely skill
    SUBAGENT_THRESHOLD = 0.6  # Above this = likely subagent
    AMBIGUOUS_MARGIN = 0.2  # If within margin, mark ambiguous

    # Keywords indicating portability value
    PORTABLE_KEYWORDS = [
        "format",
        "lint",
        "test",
        "build",
        "deploy",
        "commit",
        "review",
        "document",
    ]

    def __init__(
        self,
        existing_skills: Optional[List[str]] = None,
        existing_subagents: Optional[List[str]] = None,
    ):
        """Initialize classifier.

        Args:
            existing_skills: List of existing skill names
            existing_subagents: List of existing subagent names
        """
        self.existing_skills = [s.lower() for s in (existing_skills or [])]
        self.existing_subagents = [s.lower() for s in (existing_subagents or [])]

    def classify(self, gap: Union[SkillGap, SubagentGap]) -> ClassifiedGap:
        """Classify a single gap.

        Args:
            gap: Either a SkillGap or SubagentGap

        Returns:
            ClassifiedGap with type determination and recommendations
        """
        scores = self._calculate_scores(gap)
        gap_type = self._determine_type(scores)
        confidence = self._calculate_confidence(scores, gap_type)
        reasoning = self._generate_reasoning(gap, scores, gap_type)
        gap_id, description, source_commands, occurrence_count = (
            self._extract_gap_fields(gap)
        )
        skill_rec, subagent_rec = self._build_recommendations(
            gap, scores, gap_type
        )

        return ClassifiedGap(
            id=gap_id,
            gap_type=gap_type,
            confidence=confidence,
            reasoning=reasoning,
            suggested_name=gap.suggested_name,
            description=description,
            source_commands=source_commands,
            occurrence_count=occurrence_count,
            portability_score=scores.portability,
            isolation_score=scores.isolation,
            persona_score=scores.persona,
            resumability_score=scores.resumability,
            simplicity_score=scores.simplicity,
            skill_recommendation=skill_rec,
            subagent_recommendation=subagent_rec,
        )

    def _extract_gap_fields(self, gap: Union[SkillGap, SubagentGap]):
        """Extract common fields from a gap for ClassifiedGap construction."""
        if isinstance(gap, SkillGap):
            return (
                f"skill-{gap.suggested_name}",
                f"Pattern: {' → '.join(gap.pattern[:3])}",
                gap.pattern,
                gap.frequency,
            )
        return gap.id, gap.description, gap.source_commands, gap.occurrence_count

    def _build_recommendations(self, gap, scores, gap_type):
        """Build skill and subagent recommendations based on gap type."""
        skill_rec = None
        subagent_rec = None
        if gap_type in [GapType.SKILL, GapType.AMBIGUOUS]:
            skill_rec = self._build_skill_recommendation(gap, scores)
        if gap_type in [GapType.SUBAGENT, GapType.AMBIGUOUS]:
            subagent_rec = self._build_subagent_recommendation(gap, scores)
        return skill_rec, subagent_rec

    def classify_all(self, gaps: AllGaps) -> List[ClassifiedGap]:
        """Classify all detected gaps, deduplicating overlaps.

        Args:
            gaps: Container with skill and subagent gaps

        Returns:
            List of classified gaps
        """
        # Merge overlapping gaps
        merged = self._merge_overlapping_gaps(gaps)

        # Classify each
        classified = [self.classify(g) for g in merged]

        # Sort by confidence descending
        classified.sort(key=lambda g: g.confidence, reverse=True)

        return classified

    def _calculate_scores(
        self, gap: Union[SkillGap, SubagentGap]
    ) -> ClassificationScores:
        """Calculate factor scores for classification.

        Args:
            gap: The gap to score

        Returns:
            ClassificationScores with all factors
        """
        scores = ClassificationScores()
        if isinstance(gap, SkillGap):
            self._score_skill_gap(gap, scores)
        else:
            self._score_subagent_gap(gap, scores)
        return scores

    def _score_skill_gap(self, gap: SkillGap, scores: ClassificationScores):
        """Apply scoring factors for a SkillGap."""
        scores.portability = 0.7
        scores.simplicity = 0.6

        pattern_str = " ".join(gap.pattern).lower()
        for keyword in self.PORTABLE_KEYWORDS:
            if keyword in pattern_str:
                scores.portability = min(scores.portability + 0.1, 0.95)

        if len(gap.pattern) <= 2:
            scores.simplicity = 0.8
        elif len(gap.pattern) >= 5:
            scores.simplicity = 0.4

    def _score_subagent_gap(self, gap: SubagentGap, scores: ClassificationScores):
        """Apply scoring factors for a SubagentGap."""
        if gap.needs_context_isolation:
            scores.isolation = 0.8
        if gap.needs_resumability:
            scores.resumability = 0.8
        if gap.suggested_persona:
            scores.persona = 0.8

        if "persona_request" in gap.indicators:
            scores.persona = max(scores.persona, 0.7)
        if "context_isolation" in gap.indicators:
            scores.isolation = max(scores.isolation, 0.7)
        if "resumability" in gap.indicators:
            scores.resumability = max(scores.resumability, 0.7)

        if gap.suggested_tools:
            if len(gap.suggested_tools) <= 3:
                scores.portability = 0.5
            else:
                scores.isolation = 0.5

    def _determine_type(self, scores: ClassificationScores) -> GapType:
        """Determine gap type from scores.

        Args:
            scores: Classification scores

        Returns:
            GapType classification
        """
        # Calculate aggregate scores
        skill_score = (scores.portability + scores.simplicity) / 2
        subagent_score = (scores.isolation + scores.persona + scores.resumability) / 3

        # Handle edge case where both are near zero
        if skill_score < 0.2 and subagent_score < 0.2:
            return GapType.SKILL  # Default to skill

        # Check for ambiguity
        if abs(skill_score - subagent_score) < self.AMBIGUOUS_MARGIN:
            return GapType.AMBIGUOUS
        elif skill_score > subagent_score:
            return GapType.SKILL
        else:
            return GapType.SUBAGENT

    def _calculate_confidence(
        self, scores: ClassificationScores, gap_type: GapType
    ) -> float:
        """Calculate confidence in the classification.

        Args:
            scores: Classification scores
            gap_type: Determined type

        Returns:
            Confidence score (0.0 to 1.0)
        """
        skill_score = (scores.portability + scores.simplicity) / 2
        subagent_score = (scores.isolation + scores.persona + scores.resumability) / 3

        if gap_type == GapType.SKILL:
            return min(skill_score + 0.2, 0.95)
        elif gap_type == GapType.SUBAGENT:
            return min(subagent_score + 0.2, 0.95)
        else:
            # Ambiguous - lower confidence
            return max(skill_score, subagent_score) * 0.7

    def _generate_reasoning(
        self,
        gap: Union[SkillGap, SubagentGap],
        scores: ClassificationScores,
        gap_type: GapType,
    ) -> str:
        """Generate human-readable reasoning for classification.

        Args:
            gap: The gap being classified
            scores: Classification scores
            gap_type: Determined type

        Returns:
            Human-readable explanation
        """
        reasons = []

        if scores.portability > 0.5:
            reasons.append("Pattern would be useful across different AI tools")

        if scores.isolation > 0.5:
            reasons.append("Pattern benefits from separate context window")

        if scores.persona > 0.5:
            reasons.append("Pattern involves specialized persona or role")

        if scores.resumability > 0.5:
            reasons.append("Pattern needs state preservation across sessions")

        if scores.simplicity > 0.7:
            reasons.append("Pattern is a simple, repeatable command sequence")

        if not reasons:
            reasons.append("Default classification based on pattern structure")

        type_label = gap_type.value.upper()
        return f"Classified as {type_label}: " + "; ".join(reasons)

    def _build_skill_recommendation(
        self, gap: Union[SkillGap, SubagentGap], scores: ClassificationScores
    ) -> SkillRecommendation:
        """Build skill recommendation.

        Args:
            gap: The gap
            scores: Classification scores

        Returns:
            SkillRecommendation
        """
        # Convert to gerund form if needed
        name = gap.suggested_name
        if not any(name.startswith(v) for v in ["managing", "testing", "reviewing"]):
            # Already in gerund form or close enough
            pass

        # Determine allowed tools if applicable
        allowed_tools = None
        if isinstance(gap, SubagentGap) and gap.suggested_tools:
            allowed_tools = gap.suggested_tools

        # Estimate portability
        portability = ["claude-code"]
        if scores.portability > 0.6:
            portability.extend(["cursor", "continue", "windsurf"])

        return SkillRecommendation(
            suggested_name=name,
            allowed_tools=allowed_tools,
            estimated_portability=portability,
        )

    def _build_subagent_recommendation(
        self, gap: Union[SkillGap, SubagentGap], scores: ClassificationScores
    ) -> SubagentRecommendation:
        """Build subagent recommendation.

        Args:
            gap: The gap
            scores: Classification scores

        Returns:
            SubagentRecommendation
        """
        suggested_model = None
        suggested_tools = None
        persona_hint = None

        if isinstance(gap, SubagentGap):
            suggested_model = gap.suggested_model
            suggested_tools = gap.suggested_tools
            persona_hint = gap.suggested_persona

        # Default model based on complexity
        if not suggested_model:
            if scores.persona > 0.7 or scores.isolation > 0.7:
                suggested_model = "sonnet"  # Good balance

        return SubagentRecommendation(
            suggested_name=gap.suggested_name,
            suggested_model=suggested_model,
            suggested_tools=suggested_tools,
            persona_hint=persona_hint,
        )

    def _merge_overlapping_gaps(
        self, gaps: AllGaps
    ) -> List[Union[SkillGap, SubagentGap]]:
        """Merge overlapping skill and subagent gaps.

        Args:
            gaps: Container with both gap types

        Returns:
            Deduplicated list
        """
        merged: Dict[str, Union[SkillGap, SubagentGap]] = {}

        # Add skill gaps
        for gap in gaps.skills:
            key = gap.suggested_name.lower()
            if key not in merged:
                merged[key] = gap
            elif gap.confidence > merged[key].confidence:
                merged[key] = gap

        # Add subagent gaps, preferring them over skills for overlaps
        for gap in gaps.subagents:
            key = gap.suggested_name.lower()
            if key not in merged:
                merged[key] = gap
            elif isinstance(merged[key], SkillGap):
                # SubagentGap has more specific info, prefer it
                merged[key] = gap
            elif gap.confidence > merged[key].confidence:
                merged[key] = gap

        return list(merged.values())
