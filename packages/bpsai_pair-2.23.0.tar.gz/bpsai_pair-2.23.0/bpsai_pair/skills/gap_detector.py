"""Skill Gap Detector - Detects when users need skills that don't exist.

This module re-exports all public names from the gap sub-modules
for backwards compatibility. Import from here or from the sub-modules directly.
"""

from .gap_models import SkillGap, TRIVIAL_PATTERNS, COMMAND_VERBS
from .gap_engine import SkillGapDetector
from .gap_persistence import (
    GapPersistence,
    format_gap_notification,
    detect_gaps_from_history,
)

__all__ = [
    "SkillGap",
    "TRIVIAL_PATTERNS",
    "COMMAND_VERBS",
    "SkillGapDetector",
    "GapPersistence",
    "format_gap_notification",
    "detect_gaps_from_history",
]
