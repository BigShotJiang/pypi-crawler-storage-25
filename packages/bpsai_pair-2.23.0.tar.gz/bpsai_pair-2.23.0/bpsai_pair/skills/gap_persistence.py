"""Skill gap persistence and utility functions.

This module provides gap history persistence, notification formatting,
and the high-level detect_gaps_from_history convenience function.
"""

import json
import logging
from pathlib import Path
from typing import List, Optional

from .gap_models import SkillGap
from .gap_engine import SkillGapDetector

logger = logging.getLogger(__name__)


class GapPersistence:
    """Handles persisting detected gaps to history."""

    def __init__(self, history_dir: Path):
        """Initialize persistence.

        Args:
            history_dir: Path to history directory
        """
        self.history_dir = history_dir
        self.gap_file = history_dir / "skill-gaps.jsonl" if history_dir else None

    def save_gap(self, gap: SkillGap) -> None:
        """Save a gap to history.

        Args:
            gap: Gap to save
        """
        if not self.gap_file:
            return

        self.history_dir.mkdir(parents=True, exist_ok=True)

        existing_gaps = self.load_gaps()

        updated = False
        for i, existing in enumerate(existing_gaps):
            if existing.pattern == gap.pattern:
                if gap.confidence > existing.confidence:
                    existing_gaps[i] = gap
                updated = True
                break

        if not updated:
            existing_gaps.append(gap)

        with open(self.gap_file, "w", encoding="utf-8") as f:
            for g in existing_gaps:
                f.write(json.dumps(g.to_dict()) + "\n")

    def load_gaps(self) -> List[SkillGap]:
        """Load gaps from history.

        Returns:
            List of skill gaps
        """
        if not self.gap_file or not self.gap_file.exists():
            return []

        gaps = []
        try:
            content = self.gap_file.read_text(encoding="utf-8")
            for line in content.strip().split("\n"):
                if line:
                    try:
                        data = json.loads(line)
                        gaps.append(SkillGap.from_dict(data))
                    except json.JSONDecodeError:
                        continue
        except Exception as e:
            logger.warning(f"Error loading gaps: {e}")

        return gaps

    def clear_gaps(self) -> None:
        """Clear all gaps from history."""
        if self.gap_file and self.gap_file.exists():
            self.gap_file.write_text("", encoding="utf-8")


def format_gap_notification(gap: SkillGap) -> str:
    """Format a gap notification message.

    Args:
        gap: The skill gap

    Returns:
        Formatted notification string
    """
    lines = [
        "Skill Gap Detected",
        "",
        f"You've performed this workflow {gap.frequency} times this session:",
    ]

    for i, cmd in enumerate(gap.pattern, 1):
        lines.append(f"  {i}. {cmd}")

    lines.extend([
        "",
        f"Would you like to create a \"{gap.suggested_name}\" skill?",
        f"Confidence: {gap.confidence:.0%}",
        f"Estimated savings: {gap.time_saved_estimate}",
    ])

    return "\n".join(lines)


def detect_gaps_from_history(
    history_dir: Path,
    skills_dir: Optional[Path] = None,
    pattern_threshold: int = 5,
) -> List[SkillGap]:
    """High-level function to detect gaps from history files.

    Args:
        history_dir: Path to history directory
        skills_dir: Path to skills directory for overlap detection
        pattern_threshold: Minimum pattern occurrences

    Returns:
        List of detected skill gaps
    """
    existing_skills = []
    if skills_dir and skills_dir.exists():
        for skill_dir in skills_dir.iterdir():
            if skill_dir.is_dir() and (skill_dir / "SKILL.md").exists():
                existing_skills.append(skill_dir.name)

    session_log = []
    changes_log = history_dir / "changes.log" if history_dir else None

    if changes_log and changes_log.exists():
        try:
            content = changes_log.read_text(encoding="utf-8")
            for line in content.strip().split("\n")[-100:]:
                if line:
                    session_log.append({
                        "type": "command",
                        "content": line.split(" ", 1)[-1] if " " in line else line,
                    })
        except Exception as e:
            logger.warning(f"Error reading changes log: {e}")

    detector = SkillGapDetector(
        existing_skills=existing_skills,
        pattern_threshold=pattern_threshold,
    )

    return detector.analyze_session(session_log)
