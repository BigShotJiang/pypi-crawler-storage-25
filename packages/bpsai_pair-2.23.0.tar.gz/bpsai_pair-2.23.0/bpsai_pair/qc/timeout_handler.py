"""Document idle timeout resilience for QC Chrome tool calls."""
from __future__ import annotations

import builtins
import logging
import time
from dataclasses import dataclass
from typing import Any, Callable

logger = logging.getLogger(__name__)
_TIMEOUT_PATTERNS = ("timeout", "document_idle", "timed out", "idle")


class QCTimeoutError(Exception):
    """Raised when retries are exhausted due to timeout."""


@dataclass
class RetryConfig:
    """Configuration for retry behavior."""
    max_retries: int = 2
    retry_delay: float = 0.5


def _is_timeout_error(error: Exception) -> bool:
    """Check if an exception is a timeout/idle related error."""
    if isinstance(error, (QCTimeoutError, builtins.TimeoutError)):
        return True
    return any(p in str(error).lower() for p in _TIMEOUT_PATTERNS)


def with_retry(fn: Callable[[], Any], config: RetryConfig | None = None) -> Any:
    """Call fn with retries on timeout errors.

    Non-timeout errors are raised immediately.
    Raises TimeoutError if all retries exhausted.
    """
    cfg = config or RetryConfig()
    last_error: Exception | None = None
    for attempt in range(1 + cfg.max_retries):
        try:
            return fn()
        except Exception as e:
            if not _is_timeout_error(e):
                raise
            last_error = e
            if attempt < cfg.max_retries:
                logger.debug("Timeout attempt %d/%d: %s", attempt + 1, 1 + cfg.max_retries, e)
                time.sleep(cfg.retry_delay)
    raise QCTimeoutError(f"Exhausted {1 + cfg.max_retries} attempts: {last_error}") from last_error


def with_fallback(primary: Callable[[], Any], fallback: Callable[[], Any]) -> Any:
    """Try primary, fall back on any exception. If both fail, fallback's error is raised."""
    try:
        return primary()
    except Exception as e:
        logger.debug("Primary failed (%s), trying fallback", e)
        return fallback()
