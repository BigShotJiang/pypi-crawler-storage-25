"""QC step handler functions.

Each handler executes a specific QCStepType against a ChromeToolProvider
and returns a QCStepResult. Extracted from the executor to keep module
sizes within architecture limits.
"""

from __future__ import annotations

import logging
import time
from typing import TYPE_CHECKING, Any, Protocol

from .results import QCStepResult, QCVerdict
from .timeout_handler import RetryConfig, QCTimeoutError, with_fallback, with_retry

logger = logging.getLogger(__name__)

if TYPE_CHECKING:
    from .config import QCEnvironment
    from .models import QCStep


class ChromeToolProvider(Protocol):
    """Protocol for Chrome MCP tool access."""

    def navigate(self, url: str) -> dict[str, Any]: ...
    def find(self, query: str, **kwargs: Any) -> dict[str, Any]: ...
    def click(self, ref: str | None = None, x: int | None = None, y: int | None = None) -> dict[str, Any]: ...
    def form_input(self, ref: str, value: str) -> dict[str, Any]: ...
    def read_page(self) -> dict[str, Any]: ...
    def screenshot(self) -> dict[str, Any]: ...


def execute_navigate(chrome: ChromeToolProvider, step: QCStep, delay: float) -> QCStepResult:
    """Execute a navigate step."""
    chrome.navigate(step.target)
    time.sleep(delay)
    return QCStepResult(
        step_description=f"navigate: {step.target}",
        verdict=QCVerdict.PASSED,
        observation=f"Navigated to {step.target}",
    )


def execute_verify(
    chrome: ChromeToolProvider,
    step: QCStep,
    retry_config: RetryConfig | None = None,
) -> QCStepResult:
    """Execute a verify step with retry + screenshot fallback.

    Retries read_page on timeout errors (document_idle), then falls
    back to screenshot if retries are exhausted or any error occurs.
    """
    description = f"verify: {step.target}"
    cfg = retry_config or RetryConfig()

    try:
        result = with_fallback(
            lambda: with_retry(lambda: chrome.read_page(), cfg),
            lambda: {**chrome.screenshot(), "_fallback": True},
        )
        fallback_used = isinstance(result, dict) and result.get("_fallback")
        obs = (
            f"Screenshot taken for verification: {step.target}"
            if fallback_used
            else f"Page read for verification: {step.target}"
        )
        return QCStepResult(
            step_description=description,
            verdict=QCVerdict.PASSED,
            observation=obs,
        )
    except Exception as e:
        return QCStepResult(
            step_description=description,
            verdict=QCVerdict.ERROR,
            observation=f"Could not verify (document_idle): {e}",
        )


def execute_click(chrome: ChromeToolProvider, step: QCStep) -> QCStepResult:
    """Execute a click step using element discovery."""
    description = f"click: {step.target}"

    try:
        found = chrome.find(step.target)
        ref = found.get("ref")
        if ref:
            chrome.click(ref=ref)
            return QCStepResult(
                step_description=description,
                verdict=QCVerdict.PASSED,
                observation=f"Clicked element via find: {step.target}",
            )
    except Exception as e:
        logger.warning("find/click failed for '%s': %s", step.target, e)

    # Fallback: screenshot for diagnostic, but verdict is FAILED
    try:
        chrome.screenshot()
        return QCStepResult(
            step_description=description,
            verdict=QCVerdict.FAILED,
            observation=f"Element not found or click failed: {step.target}. Screenshot taken for diagnosis.",
        )
    except Exception as e:
        return QCStepResult(
            step_description=description,
            verdict=QCVerdict.ERROR,
            observation=f"Could not click or screenshot: {e}",
        )


def execute_fill(chrome: ChromeToolProvider, step: QCStep, env: QCEnvironment) -> QCStepResult:
    """Execute a fill step via fill_validator -- blocked in read_only environments."""
    from .fill_validator import validate_fill_step

    description = f"fill: {step.field or step.target}"

    result = validate_fill_step(step, chrome, read_only=env.restrictions.read_only)

    return QCStepResult(
        step_description=description,
        verdict=result.verdict,
        observation=result.observation,
        duration_s=result.duration_s,
    )


def execute_check_console(chrome: ChromeToolProvider, step: QCStep) -> QCStepResult:
    """Execute a check_console step."""
    try:
        chrome.read_page()
        return QCStepResult(
            step_description=f"check_console: {step.target}",
            verdict=QCVerdict.PASSED,
            observation="Console checked via read_page",
        )
    except Exception as e:
        return QCStepResult(
            step_description=f"check_console: {step.target}",
            verdict=QCVerdict.ERROR,
            observation=f"Could not check console: {e}",
        )


_MAX_WAIT_SECONDS = 60.0


def execute_wait(step: QCStep) -> QCStepResult:
    """Execute a wait step."""
    try:
        seconds = min(float(step.target), _MAX_WAIT_SECONDS)
    except (ValueError, TypeError):
        seconds = 1.0
    if seconds < 0:
        seconds = 0
    time.sleep(seconds)
    return QCStepResult(
        step_description=f"wait: {seconds}s",
        verdict=QCVerdict.PASSED,
        observation=f"Waited {seconds}s",
    )
