"""QC environment configuration.

Loads per-project QC config from .paircoder/qc/config.yaml with
named environment profiles (dev, staging, prod). Supports OS env
var resolution for secrets and per-environment restrictions.
"""

from __future__ import annotations

import os
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml

from .models import VAR_PATTERN

_VAR_RE = VAR_PATTERN


class QCConfigError(Exception):
    """Raised when QC config is invalid or env vars are missing."""


@dataclass
class QCRestrictions:
    """Execution restrictions for an environment."""

    read_only: bool = False
    skip_tags: list[str] = field(default_factory=list)


@dataclass
class QCEnvironment:
    """A named environment profile with variables and settings."""

    variables: dict[str, str] = field(default_factory=dict)
    chrome: dict[str, Any] = field(default_factory=dict)
    restrictions: QCRestrictions = field(default_factory=QCRestrictions)


@dataclass
class QCConfig:
    """Top-level QC configuration with multiple environments."""

    environments: dict[str, QCEnvironment] = field(default_factory=dict)
    default_environment: str = "dev"

    def get_environment(self, name: str) -> QCEnvironment:
        """Get an environment by name. Raises on unknown."""
        if name not in self.environments:
            raise QCConfigError(
                f"Unknown environment '{name}'. "
                f"Available: {', '.join(sorted(self.environments))}"
            )
        return self.environments[name]

    def resolve_environment(self, name: str) -> QCEnvironment:
        """Get environment with OS env vars resolved in variables."""
        env = self.get_environment(name)
        resolved_vars: dict[str, str] = {}
        for key, value in env.variables.items():
            resolved_vars[key] = _resolve_os_vars(value)
        return QCEnvironment(
            variables=resolved_vars,
            chrome=env.chrome,
            restrictions=env.restrictions,
        )


def load_qc_config(project_root: Path) -> QCConfig:
    """Load QC config from .paircoder/qc/config.yaml."""
    config_path = project_root / ".paircoder" / "qc" / "config.yaml"
    if not config_path.exists():
        return QCConfig()

    with open(config_path, encoding="utf-8") as f:
        data = yaml.safe_load(f) or {}

    environments: dict[str, QCEnvironment] = {}
    for name, env_data in (data.get("environments") or {}).items():
        environments[name] = _build_environment(env_data or {})

    return QCConfig(
        environments=environments,
        default_environment=data.get("default_environment", "dev"),
    )


def _build_environment(data: dict) -> QCEnvironment:
    """Build a QCEnvironment from config dict."""
    restrictions_data = data.get("restrictions") or {}
    return QCEnvironment(
        variables=data.get("variables") or {},
        chrome=data.get("chrome") or {},
        restrictions=QCRestrictions(
            read_only=restrictions_data.get("read_only", False),
            skip_tags=restrictions_data.get("skip_tags") or [],
        ),
    )


def _resolve_os_vars(value: str) -> str:
    """Replace ${VAR} with os.environ values. Raises on missing."""
    def _replace(match: re.Match) -> str:
        var_name = match.group(1)
        env_value = os.environ.get(var_name)
        if env_value is None:
            raise QCConfigError(
                f"Environment variable ${{{var_name}}} not set. "
                f"Set it before running QC: export {var_name}=<value>"
            )
        return env_value

    return _VAR_RE.sub(_replace, value)
