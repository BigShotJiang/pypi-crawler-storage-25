"""QC result models.

Structured results for QC runs — the contract between the QC agent
and the enforcement gate. Supports JSON serialization for persistence
and deserialization for reporting/gate evaluation.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Optional


class QCVerdict(Enum):
    """Outcome of a QC step or scenario."""

    PASSED = "passed"
    FAILED = "failed"
    SKIPPED = "skipped"
    ERROR = "error"


@dataclass
class QCStepResult:
    """Result of a single QC step execution."""

    step_description: str
    verdict: QCVerdict
    observation: str = ""
    duration_s: float = 0.0


@dataclass
class QCScenarioResult:
    """Result of a scenario (sequence of steps)."""

    name: str
    verdict: QCVerdict
    steps: list[QCStepResult] = field(default_factory=list)
    failure_reason: str = ""


@dataclass
class QCRunResult:
    """Result of running a full QC suite."""

    suite_name: str
    environment: str
    scenarios: list[QCScenarioResult] = field(default_factory=list)
    timestamp: str = field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat()
    )

    def summary(self) -> dict[str, Any]:
        """Compute summary statistics."""
        total = len(self.scenarios)
        passed = sum(1 for s in self.scenarios if s.verdict == QCVerdict.PASSED)
        failed = sum(1 for s in self.scenarios if s.verdict == QCVerdict.FAILED)
        skipped = sum(1 for s in self.scenarios if s.verdict == QCVerdict.SKIPPED)
        error = sum(1 for s in self.scenarios if s.verdict == QCVerdict.ERROR)
        rate = (passed / total * 100) if total > 0 else 0.0
        return {
            "total": total,
            "passed": passed,
            "failed": failed,
            "skipped": skipped,
            "error": error,
            "pass_rate": round(rate, 1),
        }

    def summary_line(self) -> str:
        """One-line summary: X passed, Y failed, Z skipped (XX% pass rate)."""
        s = self.summary()
        return (
            f"{s['passed']} passed, {s['failed']} failed, "
            f"{s['skipped']} skipped ({s['pass_rate']}% pass rate)"
        )

    def to_dict(self) -> dict[str, Any]:
        """Serialize to JSON-compatible dict."""
        return {
            "suite_name": self.suite_name,
            "environment": self.environment,
            "timestamp": self.timestamp,
            "scenarios": [
                {
                    "name": sc.name,
                    "verdict": sc.verdict.value,
                    "failure_reason": sc.failure_reason,
                    "steps": [
                        {
                            "step_description": st.step_description,
                            "verdict": st.verdict.value,
                            "observation": st.observation,
                            "duration_s": st.duration_s,
                        }
                        for st in sc.steps
                    ],
                }
                for sc in self.scenarios
            ],
            "summary": self.summary(),
        }

    @classmethod
    def from_dict(cls, data: dict) -> QCRunResult:
        """Deserialize from a dict. Raises ValueError on malformed data."""
        try:
            scenarios = []
            for sc_data in data.get("scenarios", []):
                steps = [
                    QCStepResult(
                        step_description=st.get("step_description", ""),
                        verdict=_safe_verdict(st.get("verdict", "error")),
                        observation=st.get("observation", ""),
                        duration_s=st.get("duration_s", 0.0),
                    )
                    for st in sc_data.get("steps", [])
                ]
                scenarios.append(
                    QCScenarioResult(
                        name=sc_data.get("name", "unknown"),
                        verdict=_safe_verdict(sc_data.get("verdict", "error")),
                        steps=steps,
                        failure_reason=sc_data.get("failure_reason", ""),
                    )
                )
            return cls(
                suite_name=data.get("suite_name", "unknown"),
                environment=data.get("environment", ""),
                scenarios=scenarios,
                timestamp=data.get("timestamp", ""),
            )
        except (TypeError, AttributeError) as e:
            raise ValueError(f"Malformed QC result data: {e}") from e


def _safe_verdict(value: str) -> QCVerdict:
    """Convert string to QCVerdict, defaulting to ERROR on invalid."""
    try:
        return QCVerdict(value)
    except ValueError:
        return QCVerdict.ERROR
