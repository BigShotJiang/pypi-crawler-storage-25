"""QC spec format models.

Defines the YAML schema for QC test suites: suites, scenarios, steps.
Steps use natural language descriptions (not CSS selectors) to leverage
the Chrome extension's AI vision capabilities.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from enum import Enum
from typing import Optional

VAR_PATTERN = re.compile(r"\$\{(\w+)\}")


class QCStepType(Enum):
    """Types of QC test steps."""

    NAVIGATE = "navigate"
    VERIFY = "verify"
    CLICK = "click"
    FILL = "fill"
    CHECK_CONSOLE = "check_console"
    WAIT = "wait"


class QCValidationError(Exception):
    """Raised when a QC spec is invalid."""


class QCUnresolvedVariableError(QCValidationError):
    """Raised when ${VAR} references remain unresolved after interpolation."""


@dataclass
class QCStep:
    """A single step in a QC scenario."""

    type: QCStepType
    target: str = ""
    field: Optional[str] = None
    value: Optional[str] = None


@dataclass
class QCScenario:
    """A named sequence of steps to test a user flow."""

    name: str
    steps: list[QCStep] = field(default_factory=list)
    tags: list[str] = field(default_factory=list)


@dataclass
class QCSuite:
    """A collection of scenarios for a feature or flow."""

    name: str
    scenarios: list[QCScenario] = field(default_factory=list)
    description: str = ""
    tags: list[str] = field(default_factory=list)
    preconditions: list[str] = field(default_factory=list)
