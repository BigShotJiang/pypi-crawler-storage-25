"""QC scaffold templates for init command.

Extracted from qc_commands.py to keep command file under 200 lines.
"""

from __future__ import annotations

DEFAULT_CONFIG = """\
environments:
  dev:
    variables:
      QC_BASE_URL: "http://localhost:3000"
      QC_TEST_EMAIL: "test@localhost"
      QC_TEST_PASSWORD: "${QC_TEST_PASSWORD}"
    chrome:
      require_login: false

  staging:
    variables:
      QC_BASE_URL: "https://staging.example.com"
      QC_TEST_EMAIL: "qc-bot@example.com"
      QC_TEST_PASSWORD: "${STAGING_QC_PASSWORD}"
    chrome:
      require_login: true
      login_url: "https://staging.example.com/login"

  prod:
    variables:
      QC_BASE_URL: "https://example.com"
      QC_TEST_EMAIL: "qc-readonly@example.com"
      QC_TEST_PASSWORD: "${PROD_QC_PASSWORD}"
    chrome:
      require_login: true
      login_url: "https://example.com/login"
    restrictions:
      read_only: true
      skip_tags:
        - destructive
        - write

default_environment: dev
"""

EXAMPLE_SUITE = """\
name: Example QC Suite
description: Demonstrates all QC step types --- customize for your app
tags: [smoke, example]
preconditions:
  - "App running at ${QC_BASE_URL}"

scenarios:
  - name: "Homepage loads"
    steps:
      - navigate: "${QC_BASE_URL}/"
      - verify: "Main page loads with navigation and content"
      - check_console: "No errors in console"

  - name: "Login flow"
    steps:
      - navigate: "${QC_BASE_URL}/login"
      - verify: "Login form with email and password fields"
      - fill:
          field: "Email"
          value: "${QC_TEST_EMAIL}"
      - fill:
          field: "Password"
          value: "${QC_TEST_PASSWORD}"
      - click: "Sign in / Submit button"
      - wait: "2"
      - verify: "Redirected to dashboard or home page"

  - name: "Navigation works"
    steps:
      - navigate: "${QC_BASE_URL}/"
      - click: "First navigation link"
      - verify: "Page changes to new content"
"""
