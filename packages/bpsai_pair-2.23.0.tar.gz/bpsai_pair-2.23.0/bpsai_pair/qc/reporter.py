"""QC result reporter.

Formats QC results for CLI display and persists them as JSON
for gate evaluation and historical tracking.
"""

from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Optional

from .results import QCRunResult, QCVerdict


class QCReporter:
    """Formats and persists QC run results."""

    def __init__(self, reports_dir: Path | None = None) -> None:
        self._reports_dir = reports_dir

    def persist(self, result: QCRunResult) -> Path:
        """Save result as JSON. Returns the written file path."""
        if self._reports_dir is None:
            raise ValueError("reports_dir not configured")

        self._reports_dir.mkdir(parents=True, exist_ok=True)
        slug = re.sub(r"[^\w\-]", "-", result.suite_name.lower()).strip("-")[:80] or "unnamed"
        # Explicitly guarantee no path separators survive (defense in depth with C3 guard)
        slug = slug.replace("/", "-").replace("\\", "-")
        ts = result.timestamp[:19].replace(":", "-")
        filename = f"{ts}-{slug}.json"
        path = self._reports_dir / filename
        # Guard against path traversal via crafted timestamp or suite name
        if not path.resolve().is_relative_to(self._reports_dir.resolve()):
            raise ValueError(f"Path escapes reports directory: {filename}")

        with open(path, "w", encoding="utf-8") as f:
            json.dump(result.to_dict(), f, indent=2)
        return path

    def load_latest(self) -> Optional[QCRunResult]:
        """Load the most recent report from the reports directory."""
        if not self._reports_dir or not self._reports_dir.exists():
            return None

        resolved_dir = self._reports_dir.resolve()
        reports = sorted(self._reports_dir.glob("*.json"), reverse=True)

        for report in reports:
            try:
                resolved = report.resolve()
                resolved.relative_to(resolved_dir)  # reject symlinks escaping dir
            except (ValueError, OSError):
                continue
            if resolved.stat().st_size > 10 * 1024 * 1024:  # 10 MB guard
                continue
            data = json.loads(resolved.read_text(encoding="utf-8"))
            try:
                return QCRunResult.from_dict(data)
            except (ValueError, TypeError):
                continue

        return None

    def format_summary(self, result: QCRunResult) -> str:
        """Format results as a readable text summary."""
        lines = [f"QC Results: {result.suite_name} ({result.environment})"]
        lines.append("=" * 60)

        for sc in result.scenarios:
            icon = _verdict_icon(sc.verdict)
            line = f"  {icon} {sc.name}"
            if sc.failure_reason:
                line += f" --- {sc.failure_reason}"
            lines.append(line)

        lines.append("")
        lines.append(result.summary_line())
        return "\n".join(lines)


def _verdict_icon(verdict: QCVerdict) -> str:
    """Map verdict to display icon."""
    return {
        QCVerdict.PASSED: "PASSED",
        QCVerdict.FAILED: "FAILED",
        QCVerdict.SKIPPED: "SKIPPED",
        QCVerdict.ERROR: "ERROR",
    }.get(verdict, "?")
