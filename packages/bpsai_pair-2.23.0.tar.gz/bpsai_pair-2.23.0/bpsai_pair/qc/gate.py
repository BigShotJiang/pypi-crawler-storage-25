"""QC gate hook — evaluates QC results for enforcement.

Reads the latest QC report and blocks or warns based on
the enforcement.qc_gate config setting.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

import yaml

from .reporter import QCReporter

logger = logging.getLogger(__name__)

_VALID_ENFORCEMENT = {"block", "warn", "off"}


def qc_check_hook(
    ctx: Any,
    paircoder_dir: Path,
) -> dict[str, Any]:
    """Hook-compatible wrapper for qc_check. Called by HookRunner."""
    return qc_check(paircoder_dir.parent)


def qc_check(
    project_root: Path,
    enforcement: str | None = None,
) -> dict[str, Any]:
    """Evaluate QC results against enforcement policy.

    Args:
        project_root: Project root directory
        enforcement: Override enforcement level (block/warn/off).
                     If None, reads from config.yaml.

    Returns:
        Dict with blocked, pass_rate, warning, skipped keys.
    """
    if enforcement is None:
        enforcement = _read_enforcement(project_root)

    if enforcement == "off":
        return {"blocked": False, "skipped": True, "reason": "QC gate disabled"}

    reports_dir = project_root / ".paircoder" / "qc" / "reports"
    reporter = QCReporter(reports_dir=reports_dir)
    latest = reporter.load_latest()

    if latest is None:
        return {"blocked": False, "skipped": True, "reason": "No QC reports found"}

    summary = latest.summary()
    pass_rate = summary["pass_rate"]
    has_failures = summary["failed"] > 0 or summary.get("error", 0) > 0
    failure_count = summary["failed"] + summary.get("error", 0)

    if has_failures and enforcement == "block":
        return {
            "blocked": True,
            "pass_rate": pass_rate,
            "suite": latest.suite_name,
            "failed": summary["failed"],
            "error": summary.get("error", 0),
            "reason": f"QC gate: {failure_count} scenario(s) failed/errored ({pass_rate}% pass rate)",
        }

    if has_failures and enforcement == "warn":
        return {
            "blocked": False,
            "warning": True,
            "pass_rate": pass_rate,
            "suite": latest.suite_name,
            "failed": summary["failed"],
            "error": summary.get("error", 0),
            "reason": f"QC warning: {failure_count} scenario(s) failed/errored ({pass_rate}% pass rate)",
        }

    return {
        "blocked": False,
        "pass_rate": pass_rate,
        "suite": latest.suite_name,
    }


def _read_enforcement(project_root: Path) -> str:
    """Read qc_gate enforcement level from config.yaml."""
    config_path = project_root / ".paircoder" / "config.yaml"
    if not config_path.exists():
        return "warn"
    try:
        with open(config_path, encoding="utf-8") as f:
            config = yaml.safe_load(f) or {}
        value = config.get("enforcement", {}).get("qc_gate", "warn")
        if value not in _VALID_ENFORCEMENT:
            logger.warning(
                "Unknown qc_gate enforcement value '%s'; defaulting to 'warn'. "
                "Valid values: %s",
                value,
                sorted(_VALID_ENFORCEMENT),
            )
            return "warn"
        return value
    except Exception as e:
        logger.debug("Could not read qc_gate config: %s", e)
        return "warn"
