"""Stack detection for project language identification.

Scans source files to determine whether a project is Python,
TypeScript, mixed, or unknown.
"""

from __future__ import annotations

from pathlib import Path

_SKIP_DIRS = {"node_modules", ".venv", "venv", "__pycache__", ".git", "dist", "build"}

_PYTHON_EXTS = {".py"}
_TYPESCRIPT_EXTS = {".ts", ".tsx"}


def detect_stack(project_root: Path) -> str:
    """Detect project stack from source file extensions.

    Returns:
        "python", "typescript", "mixed", or "unknown".
    """
    has_python = False
    has_typescript = False

    for path in project_root.rglob("*"):
        if any(part in _SKIP_DIRS for part in path.parts):
            continue
        if not path.is_file():
            continue
        ext = path.suffix.lower()
        if ext in _PYTHON_EXTS:
            has_python = True
        elif ext in _TYPESCRIPT_EXTS:
            has_typescript = True
        if has_python and has_typescript:
            return "mixed"

    if has_python:
        return "python"
    if has_typescript:
        return "typescript"
    return "unknown"
