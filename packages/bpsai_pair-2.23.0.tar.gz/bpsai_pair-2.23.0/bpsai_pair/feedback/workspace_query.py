"""Cross-repo workspace task state queries.

Scans sibling directories for .paircoder/data/store.db files and
merges TaskStateIndex results with repo attribution.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

_MAX_SIBLING_REPOS = 20


def query_workspace_task_state(
    project_root: Path,
    task_id: str | None = None,
    plan_id: str | None = None,
    new_state: str | None = None,
) -> list[dict[str, Any]]:
    """Query task state transitions across all repos in the workspace.

    Discovers sibling repos by scanning the parent directory for
    directories containing .paircoder/data/store.db.
    """
    workspace_root = project_root.parent
    all_transitions: list[dict[str, Any]] = []

    for repo_dir in _discover_repos(workspace_root):
        repo_name = repo_dir.name
        db_path = repo_dir / ".paircoder" / "data" / "store.db"

        try:
            from bpsai_pair.telemetry.task_state_index import TaskStateIndex

            idx = TaskStateIndex(db_path, read_only=True)
            transitions = idx.query_transitions(
                task_id=task_id,
                plan_id=plan_id,
                new_state=new_state,
            )

            for t in transitions:
                t["repo"] = repo_name
            all_transitions.extend(transitions)

        except Exception as e:
            logger.debug("Skipping repo %s: %s", repo_name, e)

    # Sort by timestamp descending and cap total results
    all_transitions.sort(key=lambda t: t.get("timestamp", ""), reverse=True)
    all_transitions = all_transitions[:500]
    return all_transitions


def _discover_repos(workspace_root: Path) -> list[Path]:
    """Find directories with .paircoder/data/store.db under workspace root."""
    repos: list[Path] = []

    if not workspace_root.is_dir():
        return repos

    resolved_root = workspace_root.resolve()
    for child in sorted(workspace_root.iterdir()):
        try:
            resolved = child.resolve()
            resolved.relative_to(resolved_root)  # reject symlinks escaping workspace
        except (ValueError, OSError):
            logger.debug("Skipping %s: resolves outside workspace", child.name)
            continue
        if not resolved.is_dir():
            continue
        db_path = resolved / ".paircoder" / "data" / "store.db"
        if db_path.exists():
            repos.append(child)
            if len(repos) >= _MAX_SIBLING_REPOS:
                break

    return repos
