"""High-level query interface for the feedback system.

FeedbackService provides a unified facade for Navigator and other
components to retrieve intelligence from calibration, classification,
and telemetry data.
"""

from __future__ import annotations

from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

from bpsai_pair.feedback.calibration import CalibrationEngine
from bpsai_pair.feedback.classifier import TaskTypeClassifier
from bpsai_pair.feedback.fleet import load_demand_signals
from bpsai_pair.telemetry.schema import Outcome
from bpsai_pair.telemetry.store import TelemetryStore


class FeedbackService:
    """Unified query interface for the feedback system.

    Usage:
        svc = FeedbackService(project_root)
        estimate = svc.estimate_tokens("api_endpoint")
        history = svc.get_task_history("feature", limit=10)
        status = svc.get_calibration_status()
    """

    def __init__(self, project_root: Path) -> None:
        self.project_root = project_root
        self.engine = CalibrationEngine(project_root)
        self.classifier = TaskTypeClassifier()
        self.store = TelemetryStore(project_root)

    # -- Estimation methods --

    def estimate_tokens(
        self, task_type: str, model: str | None = None,
    ) -> dict[str, Any]:
        """Get token estimates for a task type, optionally filtered by model.

        Returns:
            Dict with avg, p80, std_dev, recommended_model.
        """
        self._ensure_calibrated()
        return self.engine.estimate_tokens(task_type, model=model)

    def estimate_duration(self, task_type: str) -> dict[str, Any]:
        """Get duration estimates for a task type.

        Returns:
            Dict with avg_minutes and p80_minutes.
        """
        self._ensure_calibrated()
        return self.engine.estimate_duration(task_type)

    def get_model_recommendation(
        self, task_type: str, complexity: str = "medium"
    ) -> str:
        """Get recommended model for a task type.

        Returns:
            Model name: "haiku", "sonnet", or "opus".
        """
        self._ensure_calibrated()
        return self.engine.get_model_recommendation(task_type, complexity)

    def get_effort_recommendation(
        self, task_type: str, complexity: int | None = None
    ) -> str:
        """Get recommended effort level for a task type.

        Args:
            task_type: The type of task.
            complexity: Optional complexity score (0-100).

        Returns:
            Effort string: "low", "medium", or "high".
        """
        self._ensure_calibrated()
        return self.engine.estimate_effort(task_type, complexity)

    # -- Budget methods --

    def check_budget_fit(
        self, estimated_tokens: int, target_utilization: float = 0.8
    ) -> dict[str, Any]:
        """Check if estimated tokens fit within budget.

        Returns:
            Dict with fits_budget, utilization, budget, effective_budget.
        """
        self._ensure_calibrated()
        return self.engine.check_budget_fit(estimated_tokens, target_utilization)

    # -- History methods --

    def get_task_history(
        self, task_type: str | None = None, limit: int = 10
    ) -> list[dict[str, Any]]:
        """Get formatted task history from telemetry.

        Args:
            task_type: Optional filter by task type.
            limit: Maximum records to return.

        Returns:
            List of dicts with task_id, task_type, tokens, duration,
            outcome, timestamp.
        """
        records = self.store.query(task_type=task_type, limit=limit)
        return [
            {
                "task_id": r.task_id,
                "task_type": r.task_type,
                "tokens": r.tokens.total,
                "duration_seconds": r.duration_seconds,
                "outcome": r.outcome.value,
                "model": r.model,
                "timestamp": r.timestamp.isoformat(),
            }
            for r in records
        ]

    def get_recent_performance(self, days: int = 7) -> dict[str, Any]:
        """Summarize recent performance over given period.

        Args:
            days: Number of days to look back.

        Returns:
            Dict with total_tasks, total_tokens, success_rate,
            avg_tokens_per_task, tasks_by_type.
        """
        since = datetime.now(timezone.utc) - timedelta(days=days)
        records = self.store.query(since=since, limit=10_000)

        if not records:
            return {
                "total_tasks": 0,
                "total_tokens": 0,
                "success_rate": 0.0,
                "avg_tokens_per_task": 0.0,
                "tasks_by_type": {},
                "period_days": days,
            }

        total_tokens = sum(r.tokens.total for r in records)
        successes = sum(1 for r in records if r.outcome == Outcome.SUCCESS)

        type_counts: dict[str, int] = {}
        for r in records:
            type_counts[r.task_type] = type_counts.get(r.task_type, 0) + 1

        return {
            "total_tasks": len(records),
            "total_tokens": total_tokens,
            "success_rate": successes / len(records),
            "avg_tokens_per_task": total_tokens / len(records),
            "tasks_by_type": type_counts,
            "period_days": days,
        }

    # -- Status methods --

    def get_calibration_status(self) -> dict[str, Any]:
        """Get calibration engine health status.

        Returns:
            Dict with calibrated, total_records, task_types,
            last_calibrated, stale.
        """
        self._ensure_calibrated()
        cal = self.engine.get_calibration()
        stale = self.engine.is_cache_stale()

        return {
            "calibrated": cal.total_records > 0,
            "total_records": cal.total_records,
            "task_types": list(cal.task_types.keys()),
            "last_calibrated": cal.last_calibrated.isoformat(),
            "stale": stale,
        }

    def needs_recalibration(self) -> bool:
        """Check if the calibration cache is stale.

        Returns:
            True if cache is missing or older than 24 hours.
        """
        return self.engine.is_cache_stale()

    # -- Demand signals --

    def get_demand_signals(self) -> dict[str, Any] | None:
        """Load cached fleet demand signals.

        Returns:
            Dict with features and total_active_licenses, or None.
        """
        return load_demand_signals(self.project_root)

    # -- Internal --

    def _ensure_calibrated(self) -> None:
        """Ensure calibration has been performed."""
        if not self.engine.is_calibrated:
            self.engine.calibrate()
