"""Real-time query interface for execution-time intelligence.

StateQuery provides a high-level API that delegates to CalibrationEngine
and TelemetryStore, returning sensible defaults when no telemetry data
exists. All methods are pure queries with no side effects.
"""

from __future__ import annotations

from pathlib import Path

from typing import Any

from bpsai_pair.feedback.calibration import CalibrationEngine
from bpsai_pair.feedback.schema import MAX_TELEMETRY_QUERY_LIMIT
from bpsai_pair.telemetry.schema import Outcome
from bpsai_pair.telemetry.store import TelemetryStore


class StateQuery:
    """Real-time intelligence state query interface.

    Usage:
        sq = StateQuery(project_root)
        rate = sq.success_rate_for("feature")
    """

    def __init__(self, project_root: Path) -> None:
        self.engine = CalibrationEngine(project_root)
        self.store = TelemetryStore(project_root)

    def success_rate_for(self, task_type: str) -> float:
        """Get success rate for a task type.

        Args:
            task_type: The type of task to query.

        Returns:
            Success rate as a float (0.0 to 1.0), or 0.0 if no data.
        """
        cal = self.engine.get_calibration()
        if task_type not in cal.task_types:
            return 0.0
        return cal.task_types[task_type].success_rate

    def agent_performance_by_role(self) -> dict[str, Any]:
        """Get performance metrics grouped by model.

        Returns:
            Dict mapping model name to {task_count, success_rate, avg_tokens}.
            Returns empty dict if no telemetry data exists.
        """
        records = self.store.query(limit=MAX_TELEMETRY_QUERY_LIMIT)
        if not records:
            return {}

        groups: dict[str, list] = {}
        for r in records:
            groups.setdefault(r.model, []).append(r)

        result: dict[str, Any] = {}
        for model, group in groups.items():
            successes = sum(1 for r in group if r.outcome == Outcome.SUCCESS)
            total_tokens = sum(r.tokens.total for r in group)
            result[model] = {
                "task_count": len(group),
                "success_rate": successes / len(group),
                "avg_tokens": total_tokens / len(group),
            }
        return result

    def should_escalate_model(
        self, task_type: str, current_model: str
    ) -> bool:
        """Determine if model should be escalated for a task type.

        Returns True when success_rate < 0.5 for the task type AND the
        current model is not already opus. Returns False when no data
        exists (safe default — no evidence of failure).

        Args:
            task_type: The task type to check.
            current_model: The current model being used.

        Returns:
            True if model should be escalated, False otherwise.
        """
        if current_model == "opus":
            return False
        cal = self.engine.get_calibration()
        if task_type not in cal.task_types:
            return False
        return cal.task_types[task_type].success_rate < 0.5

    def estimation_accuracy(self, task_type: str | None = None) -> dict:
        """How accurate are our estimates for a task type?

        Queries telemetry records with estimated_tokens set and computes
        MAPE (mean absolute percentage error), bias direction, and sample count.

        Args:
            task_type: Optional filter by task type.

        Returns:
            Dict with mape, bias, and sample_count.
        """
        records = self.store.query(limit=MAX_TELEMETRY_QUERY_LIMIT)
        if task_type is not None:
            records = [r for r in records if r.task_type == task_type]

        with_estimates = [
            r for r in records if r.estimated_tokens is not None and r.tokens.total > 0
        ]

        if not with_estimates:
            return {"mape": None, "bias": "unknown", "sample_count": 0}

        pct_errors = []
        signed_errors = []
        for r in with_estimates:
            actual = r.tokens.total
            pct_errors.append(abs(r.estimated_tokens - actual) / actual * 100)
            signed_errors.append((r.estimated_tokens - actual) / actual * 100)

        mape = sum(pct_errors) / len(pct_errors)
        mean_signed = sum(signed_errors) / len(signed_errors)
        bias = "over" if mean_signed > 0 else "under" if mean_signed < 0 else "neutral"

        return {"mape": mape, "bias": bias, "sample_count": len(with_estimates)}

    def plan_token_budget_remaining(self, plan_id: str, budget: int) -> int:
        """Calculate remaining token budget for a plan.

        Sums tokens from telemetry records whose task_id starts with the
        plan prefix and subtracts from the total budget.

        Args:
            plan_id: Plan prefix to match task IDs against.
            budget: Total token budget for the plan.

        Returns:
            Remaining tokens (clamped to 0 minimum).
        """
        records = self.store.query(limit=MAX_TELEMETRY_QUERY_LIMIT)
        consumed = sum(
            r.tokens.total for r in records if r.task_id.startswith(plan_id)
        )
        return max(0, budget - consumed)
