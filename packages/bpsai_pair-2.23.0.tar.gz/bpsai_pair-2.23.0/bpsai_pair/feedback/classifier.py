"""Task type classification for calibration and estimation.

Categorizes tasks into types based on title, description, and file paths,
enabling the feedback system to group similar work and provide
type-specific recommendations.
"""

from __future__ import annotations

from collections import Counter

# Task type taxonomy
TASK_TYPES: dict[str, str] = {
    # Core types (from plan types)
    "feature": "New functionality",
    "bugfix": "Bug fixes",
    "refactor": "Code improvements",
    "chore": "Maintenance, cleanup",
    # Specialized types (inferred from content)
    "api_endpoint": "API route/endpoint work",
    "cli_command": "CLI command implementation",
    "docs_page": "Documentation",
    "test_suite": "Test writing",
    "config": "Configuration changes",
    "schema": "Data model/schema changes",
}

# Keyword rules: (keywords_tuple, task_type)
# Ordered by specificity — more specific types first
_KEYWORD_RULES: list[tuple[tuple[str, ...], str]] = [
    (("endpoint", "route", "api route", "rest api", "api endpoint"), "api_endpoint"),
    (("cli command", "command line", "cli:", "add command"), "cli_command"),
    (("documentation", "docs", "readme", "docstring"), "docs_page"),
    (("unit test", "test suite", "write test", "add test", "integration test"), "test_suite"),
    (("config", "configuration", "settings", "yaml config"), "config"),
    (("schema", "data model", "model", "dataclass", "migration"), "schema"),
    (("refactor", "restructure", "decompose", "extract", "simplify"), "refactor"),
    (("fix", "bug", "crash", "broken", "error", "issue"), "bugfix"),
    (("cleanup", "clean up", "unused", "deprecat", "maintenance", "chore"), "chore"),
]

# File path pattern rules: (path_patterns, task_type)
_FILE_RULES: list[tuple[tuple[str, ...], str]] = [
    (("commands/", "cli/commands/"), "cli_command"),
    (("api/", "routes/", "endpoints/"), "api_endpoint"),
    (("schema", "models/", "model.py"), "schema"),
    (("config", "settings"), "config"),
]


class TaskTypeClassifier:
    """Classifies tasks into types based on content and file paths."""

    def classify(
        self, task_id: str, title: str, description: str = ""
    ) -> str:
        """Classify a task into a type based on content.

        Args:
            task_id: Task identifier (unused but available for future rules).
            title: Task title text.
            description: Optional task description text.

        Returns:
            Task type string from TASK_TYPES.
        """
        text = f"{title} {description}".lower()

        for keywords, task_type in _KEYWORD_RULES:
            if any(kw in text for kw in keywords):
                return task_type

        return "feature"

    def classify_from_files(self, files_changed: list[str]) -> str:
        """Infer task type from files modified.

        Args:
            files_changed: List of file paths that were changed.

        Returns:
            Task type string from TASK_TYPES.
        """
        if not files_changed:
            return "feature"

        classifications: list[str] = []
        for filepath in files_changed:
            classified = self._classify_single_file(filepath)
            classifications.append(classified)

        # Return the most common classification
        counts = Counter(classifications)
        most_common = counts.most_common(1)[0][0]
        return most_common

    def get_type_hierarchy(self) -> dict[str, str]:
        """Return type taxonomy with descriptions.

        Returns:
            Dict mapping task type names to descriptions.
        """
        return dict(TASK_TYPES)

    def _classify_single_file(self, filepath: str) -> str:
        """Classify a single file path into a task type."""
        path_lower = filepath.lower()

        # Check file rules (directory-based patterns)
        for patterns, task_type in _FILE_RULES:
            if any(pat in path_lower for pat in patterns):
                return task_type

        # Check if it's a documentation file
        if path_lower.endswith((".md", ".rst", ".txt")):
            return "docs_page"

        # Check if it's only a test file
        if "test" in path_lower and path_lower.endswith(".py"):
            return "test_suite"

        return "feature"
