"""Helpers for calibration aggregate seeding.

Extracted from calibration.py to maintain architecture compliance.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from bpsai_pair.feedback.schema import TaskTypeStats
from bpsai_pair.feedback.stats import effort_for_type, recommend_model

if TYPE_CHECKING:
    from bpsai_pair.telemetry.aggregates import AggregateRecord, TaskTypeAggregate


def stats_from_aggregate(agg: TaskTypeAggregate) -> TaskTypeStats:
    """Build TaskTypeStats seeded from a TaskTypeAggregate.

    Reconstructs Welford M2 accumulator from std_dev so that
    future incremental updates remain numerically correct.
    """
    n = agg.record_count
    avg_tok = agg.avg_tokens
    tok_sd = agg.std_dev_tokens
    m2_tok = (tok_sd ** 2) * n if n > 1 else 0.0
    success_rate = agg.success_count / n if n > 0 else 0.0

    return TaskTypeStats(
        task_type=agg.task_type,
        sample_count=n,
        avg_tokens=avg_tok,
        std_dev=tok_sd,
        p80_tokens=agg.p80_tokens,
        avg_duration_seconds=agg.avg_duration_seconds,
        success_rate=success_rate,
        recommended_model=recommend_model(avg_tok),
        recommended_effort=effort_for_type(agg.task_type),
        _m2_tokens=m2_tok,
    )


def seed_from_aggregates(
    task_types: dict[str, TaskTypeStats],
    aggregates: list[AggregateRecord],
) -> int:
    """Seed task_types dict from aggregate records.

    For task types NOT in raw data: seeds TaskTypeStats from aggregate.
    For task types already in raw data: raw stats take precedence.
    Returns total aggregate record count since compaction removes
    raw records before saving aggregates (no double-counting).
    """
    from bpsai_pair.telemetry.aggregates import AggregateRecord

    total_agg_count = 0
    for agg_rec in aggregates:
        if not isinstance(agg_rec, AggregateRecord):
            continue
        total_agg_count += agg_rec.record_count
        for task_type, type_agg in agg_rec.task_type_stats.items():
            if task_type not in task_types:
                task_types[task_type] = stats_from_aggregate(type_agg)
    return total_agg_count
