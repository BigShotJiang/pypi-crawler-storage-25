"""
Calibration auto-refresh on session start.

Checks if calibration.json is older than 7 days and auto-refreshes
from the fleet calibration endpoint when online.
"""

from __future__ import annotations

import json
import logging
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Literal

logger = logging.getLogger(__name__)

STALE_THRESHOLD_DAYS = 7
CALIBRATION_FILE = "feedback/calibration.json"

try:
    import requests
except ImportError:
    requests = None  # type: ignore[assignment]


def maybe_refresh_calibration(
    project_root: Path,
) -> Literal["fresh", "refreshed", "offline", "error"]:
    """Check calibration freshness and auto-refresh if stale.

    Returns:
        "fresh" if calibration is recent enough.
        "refreshed" if calibration was successfully updated.
        "offline" if CLI cannot reach the API.
        "error" if something went wrong.
    """
    cal_path = project_root / ".paircoder" / CALIBRATION_FILE

    if _is_fresh(cal_path):
        return "fresh"

    if not _is_online():
        return "offline"

    try:
        success = _fetch_calibration(project_root)
        return "refreshed" if success else "error"
    except Exception as e:
        logger.debug("Calibration refresh failed: %s", e)
        return "error"


def _is_fresh(cal_path: Path) -> bool:
    """Check if calibration file exists and is less than STALE_THRESHOLD_DAYS old."""
    if not cal_path.exists():
        return False

    try:
        data = json.loads(cal_path.read_text(encoding="utf-8"))
        updated_str = data.get("updated_at")
        if not updated_str:
            return False
        updated = datetime.fromisoformat(updated_str)
        age = datetime.now(timezone.utc) - updated
        return age < timedelta(days=STALE_THRESHOLD_DAYS)
    except (json.JSONDecodeError, ValueError, KeyError):
        return False


def _is_online() -> bool:
    """Quick connectivity check."""
    if requests is None:
        return False
    try:
        resp = requests.head("https://api.paircoder.ai/health", timeout=3)
        return resp.status_code < 500
    except Exception:
        return False


def _fetch_calibration(project_root: Path) -> bool:
    """Fetch fresh calibration data from the fleet endpoint."""
    try:
        from bpsai_pair.feedback.calibration import CalibrationEngine

        engine = CalibrationEngine(project_root)
        engine.calibrate()
        return True
    except Exception as e:
        logger.warning("Failed to refresh calibration: %s", e)
        return False
