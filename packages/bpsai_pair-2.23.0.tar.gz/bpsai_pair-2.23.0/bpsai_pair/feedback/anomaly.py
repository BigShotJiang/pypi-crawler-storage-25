"""Anomaly detection for task execution metrics.

Detects unusual patterns in telemetry data that indicate problems
requiring investigation, such as token spikes, repeated failures,
or excessive compactions.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from enum import Enum
from pathlib import Path
from typing import Any

from bpsai_pair.feedback.calibration import CalibrationEngine
from bpsai_pair.telemetry.schema import Outcome, TelemetryRecord
from bpsai_pair.telemetry.store import TelemetryStore

# Detection thresholds
_TOKEN_SPIKE_FACTOR = 2.0
_DURATION_SPIKE_FACTOR = 3.0
_COMPACTION_THRESHOLD = 2
_OVERHEAD_SPIKE_FACTOR = 5.0
_CONSECUTIVE_FAILURES = 3
_FRICTION_THRESHOLD = 5
_FRICTION_CRITICAL_THRESHOLD = 10
# Overhead estimation factors (same as overhead.py)
_INTERVENTION_FACTOR = 0.15
_COMPACTION_FACTOR = 0.25


class AnomalyType(Enum):
    """Types of detectable anomalies."""

    TOKEN_SPIKE = "token_spike"
    DURATION_SPIKE = "duration_spike"
    REPEATED_FAILURE = "repeated_failure"
    COMPACTION_HEAVY = "compaction_heavy"
    OVERHEAD_SPIKE = "overhead_spike"
    FRICTION_HIGH = "friction_high"


@dataclass
class Anomaly:
    """A detected anomaly in task execution."""

    type: AnomalyType
    task_id: str
    severity: str  # "warning" or "critical"
    expected_value: float
    actual_value: float
    message: str
    recommendation: str

    def to_dict(self) -> dict[str, Any]:
        """Serialize to dictionary."""
        return {
            "type": self.type.value,
            "task_id": self.task_id,
            "severity": self.severity,
            "expected_value": self.expected_value,
            "actual_value": self.actual_value,
            "message": self.message,
            "recommendation": self.recommendation,
        }


class AnomalyDetector:
    """Detects anomalies in task execution telemetry."""

    def __init__(self, project_root: Path) -> None:
        self.engine = CalibrationEngine(project_root)
        self.store = TelemetryStore(project_root)

    def check_record(self, record: TelemetryRecord) -> list[Anomaly]:
        """Check a single record for anomalies against calibrated baselines."""
        self._ensure_calibrated()
        estimate = self.engine.estimate_tokens(record.task_type)
        avg_tokens = estimate["avg"]
        anomalies: list[Anomaly] = []

        anomalies.extend(_check_token_spike(record, avg_tokens))
        anomalies.extend(_check_duration_spike(record, self.engine))
        anomalies.extend(_check_compaction(record))
        anomalies.extend(_check_overhead(record))
        anomalies.extend(_check_friction(record))

        return anomalies

    def scan_recent(self, days: int = 7) -> list[Anomaly]:
        """Scan recent records for anomalies."""
        self._ensure_calibrated()
        since = datetime.now(timezone.utc) - timedelta(days=days)
        records = self.store.query(since=since, limit=10_000)
        if not records:
            return []

        anomalies: list[Anomaly] = []
        for r in records:
            anomalies.extend(self.check_record(r))

        # Check for repeated failures (pattern across records)
        anomalies.extend(_check_repeated_failures(records))

        return anomalies

    def get_anomaly_summary(self) -> dict[str, Any]:
        """Summarize anomalies by type and severity."""
        anomalies = self.scan_recent(days=30)
        by_type: dict[str, int] = {}
        by_severity: dict[str, int] = {}
        for a in anomalies:
            by_type[a.type.value] = by_type.get(a.type.value, 0) + 1
            by_severity[a.severity] = by_severity.get(a.severity, 0) + 1

        return {
            "total_anomalies": len(anomalies),
            "by_type": by_type,
            "by_severity": by_severity,
        }

    def suggest_calibration_adjustments(self) -> list[dict[str, str]]:
        """Suggest calibration changes based on detected anomalies."""
        anomalies = self.scan_recent(days=30)
        if not anomalies:
            return []

        suggestions: list[dict[str, str]] = []
        seen: set[str] = set()

        for a in anomalies:
            key = a.type.value
            if key in seen:
                continue
            seen.add(key)
            suggestions.append({
                "adjustment": f"Review {key} thresholds",
                "reason": a.recommendation,
            })

        return suggestions

    def _ensure_calibrated(self) -> None:
        if not self.engine.is_calibrated:
            self.engine.calibrate()


def _check_token_spike(
    record: TelemetryRecord, avg_tokens: float
) -> list[Anomaly]:
    """Check for token usage significantly above average."""
    actual = record.tokens.total
    if avg_tokens <= 0 or actual <= avg_tokens * _TOKEN_SPIKE_FACTOR:
        return []
    ratio = actual / avg_tokens
    severity = "critical" if ratio > 3.0 else "warning"
    return [Anomaly(
        type=AnomalyType.TOKEN_SPIKE,
        task_id=record.task_id,
        severity=severity,
        expected_value=avg_tokens,
        actual_value=float(actual),
        message=f"Token usage {ratio:.1f}x above average",
        recommendation="Consider splitting this task type into smaller units.",
    )]


def _check_duration_spike(
    record: TelemetryRecord, engine: CalibrationEngine
) -> list[Anomaly]:
    """Check for duration significantly above average."""
    stats = engine._get_stats(record.task_type)
    avg_dur = stats.avg_duration_seconds
    if avg_dur <= 0 or record.duration_seconds <= avg_dur * _DURATION_SPIKE_FACTOR:
        return []
    ratio = record.duration_seconds / avg_dur
    severity = "critical" if ratio > 5.0 else "warning"
    return [Anomaly(
        type=AnomalyType.DURATION_SPIKE,
        task_id=record.task_id,
        severity=severity,
        expected_value=avg_dur,
        actual_value=float(record.duration_seconds),
        message=f"Duration {ratio:.1f}x above average",
        recommendation="Check for scope creep or unclear requirements.",
    )]


def _check_compaction(record: TelemetryRecord) -> list[Anomaly]:
    """Check for excessive compactions."""
    if record.compactions <= _COMPACTION_THRESHOLD:
        return []
    return [Anomaly(
        type=AnomalyType.COMPACTION_HEAVY,
        task_id=record.task_id,
        severity="warning" if record.compactions <= 4 else "critical",
        expected_value=float(_COMPACTION_THRESHOLD),
        actual_value=float(record.compactions),
        message=f"{record.compactions} compactions detected",
        recommendation="Task may be too large for context window. Reduce scope.",
    )]


def _check_overhead(record: TelemetryRecord) -> list[Anomaly]:
    """Check for excessive human overhead."""
    if record.duration_seconds <= 0:
        return []
    overhead = 1.0 + (
        record.human_interventions * _INTERVENTION_FACTOR
        + record.compactions * _COMPACTION_FACTOR
    )
    if overhead <= _OVERHEAD_SPIKE_FACTOR:
        return []
    return [Anomaly(
        type=AnomalyType.OVERHEAD_SPIKE,
        task_id=record.task_id,
        severity="critical",
        expected_value=1.5,
        actual_value=overhead,
        message=f"Overhead ratio {overhead:.1f}x",
        recommendation="High human overhead. Review workflow and task clarity.",
    )]


def _check_friction(record: TelemetryRecord) -> list[Anomaly]:
    """Check for high UX friction signals."""
    signals = getattr(record, "friction_signals", {})
    if not signals:
        return []
    total = sum(signals.values())
    if total < _FRICTION_THRESHOLD:
        return []
    severity = "critical" if total >= _FRICTION_CRITICAL_THRESHOLD else "warning"
    return [Anomaly(
        type=AnomalyType.FRICTION_HIGH,
        task_id=record.task_id,
        severity=severity,
        expected_value=float(_FRICTION_THRESHOLD),
        actual_value=float(total),
        message=f"High UX friction: {total} total signals",
        recommendation="Review command UX — user hit failures, retries, or help calls.",
    )]


def _check_repeated_failures(
    records: list[TelemetryRecord],
) -> list[Anomaly]:
    """Check for consecutive failures in recent records."""
    # Records are sorted recent-first
    consecutive = 0
    for r in records:
        if r.outcome == Outcome.FAIL:
            consecutive += 1
        else:
            break

    if consecutive < _CONSECUTIVE_FAILURES:
        return []

    return [Anomaly(
        type=AnomalyType.REPEATED_FAILURE,
        task_id=records[0].task_id,
        severity="critical",
        expected_value=0.0,
        actual_value=float(consecutive),
        message=f"{consecutive} consecutive failures detected",
        recommendation="Review task requirements and acceptance criteria.",
    )]
