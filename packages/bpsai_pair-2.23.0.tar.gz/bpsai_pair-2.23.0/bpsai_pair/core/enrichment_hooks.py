"""Enrichment hook handlers (fire-and-forget, never block).

Enrichment hooks run during task lifecycle events to capture
telemetry, run calibration, and scan workspace impact. They
never set blocked=True — failures are logged and swallowed.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

from bpsai_pair.core.enrichment_helpers import (
    build_snapshot as _build_snapshot,
    detect_default_branch as _detect_default_branch,
    find_project_root as _find_project_root,
    gather_workspace_changes as _gather_workspace_changes,
    get_calibration_engine as _get_calibration_engine,
    get_merge_base as _get_merge_base,
    load_workspace as _load_workspace,
)
from bpsai_pair.core.hooks import HookContext
from bpsai_pair.feedback.anomaly import AnomalyDetector

logger = logging.getLogger(__name__)


def workspace_impact_scan(
    ctx: HookContext,
    *,
    project_root: Path | None = None,
) -> dict[str, Any]:
    """Scan workspace for cross-repo impact of recent changes.

    Non-blocking: logs results but never blocks completion.
    """
    root = project_root or _find_project_root()
    workspace = _load_workspace(root) if root else None
    if workspace is None:
        logger.debug("No workspace config, running in single-repo mode")
        return {"scanned": False, "reason": "No workspace configured"}

    logger.info("Found workspace config at %s", workspace.config_path)

    merge_base = _get_merge_base(root)
    if merge_base is None:
        return {"scanned": False, "reason": "Could not determine merge base"}

    try:
        all_changes = _gather_workspace_changes(workspace, merge_base)
        if not all_changes:
            return {"scanned": True, "changes": 0}

        from bpsai_pair.workspace.impact import ImpactAnalyzer

        report = ImpactAnalyzer(workspace).analyze(all_changes)
        logger.info(
            "Workspace impact scan: %d change(s), severity=%s, affected=%s",
            len(all_changes), report.severity, report.affected_repos,
        )
        return {
            "scanned": True,
            "changes": len(all_changes),
            "severity": report.severity,
            "affected_repos": report.affected_repos,
        }
    except Exception as e:
        logger.warning("Workspace impact scan failed: %s", e)
        return {"scanned": False, "reason": str(e)}


def telemetry_snapshot(
    ctx: HookContext,
    *,
    project_root: Path | None = None,
) -> dict[str, Any]:
    """Capture a telemetry usage snapshot on task completion.

    Non-blocking: logs results but never blocks completion.
    """
    root = project_root or _find_project_root()
    snapshot = _build_snapshot(root) if root else None

    if snapshot is None:
        return {"captured": False, "reason": "No telemetry data available"}

    workspace = _load_workspace(root) if root else None

    try:
        data = snapshot.to_dict()
        result: dict[str, Any] = {
            "captured": True,
            "total_tokens": data.get("total_tokens", 0),
            "sessions": data.get("sessions", 0),
        }
        if workspace is not None:
            logger.info("Found workspace config at %s", workspace.config_path)
            result["workspace_projects"] = workspace.get_project_names()
        logger.info(
            "Telemetry snapshot: %d tokens, %d sessions",
            result["total_tokens"], result["sessions"],
        )
        return result
    except Exception as e:
        logger.warning("Telemetry snapshot failed: %s", e)
        return {"captured": False, "reason": str(e)}


def feedback_calibrate(
    ctx: HookContext,
    *,
    project_root: Path | None = None,
) -> dict[str, Any]:
    """Run feedback calibration check on task completion.

    Non-blocking: logs accuracy metrics but never blocks.
    """
    root = project_root or _find_project_root()
    engine = _get_calibration_engine(root) if root else None

    if engine is None:
        return {"calibrated": False, "reason": "Calibration engine not available"}

    workspace = _load_workspace(root) if root else None

    try:
        if not engine.is_calibrated:
            calibration = engine.calibrate()
        else:
            calibration = engine.get_calibration()

        result: dict[str, Any] = {
            "calibrated": True,
            "token_accuracy": getattr(calibration, "token_accuracy", None),
            "duration_accuracy": getattr(calibration, "duration_accuracy", None),
        }
        if workspace is not None:
            logger.info("Found workspace config at %s", workspace.config_path)
            result["workspace_projects"] = workspace.get_project_names()
        logger.info(
            "Feedback calibration: token_accuracy=%.2f, duration_accuracy=%.2f",
            getattr(calibration, "token_accuracy", 0),
            getattr(calibration, "duration_accuracy", 0),
        )
        result["anomalies_detected"] = _scan_anomalies(root)
        return result
    except Exception as e:
        logger.warning("Feedback calibration failed: %s", e)
        return {"calibrated": False, "reason": str(e)}


def agent_team_telemetry(
    ctx: HookContext,
    *,
    project_root: Path | None = None,
) -> dict[str, Any]:
    """Collect agent team SubagentStop events as telemetry.

    Reads subagent_events from ctx.extra and feeds them to
    HookCollector for storage. CalibrationEngine can then
    query records with task_type="agent_hook:*".

    Non-blocking: logs results but never blocks completion.
    """
    events = (ctx.extra or {}).get("subagent_events", [])
    if not events:
        return {"collected": 0, "reason": "No subagent events in context"}

    root = project_root or _find_project_root()
    collector = _get_hook_collector(root) if root else None

    if collector is None:
        return {"collected": 0, "reason": "HookCollector unavailable"}

    collected = 0
    for event in events:
        try:
            record = collector.collect_subagent_stop(event)
            if record is not None:
                collected += 1
        except Exception as e:
            logger.warning("Failed to collect subagent event: %s", e)

    logger.info("Agent team telemetry: collected %d event(s)", collected)
    return {"collected": collected, "source": "agent_hook"}


def calibration_update_incremental(
    ctx: HookContext,
    *,
    project_root: Path | None = None,
) -> dict[str, Any]:
    """Incrementally update calibration with a single telemetry record.

    Non-blocking: logs results but never blocks completion.
    """
    raw = (ctx.extra or {}).get("telemetry_record")
    if raw is None:
        return {"updated": False, "reason": "No telemetry_record in context"}

    root = project_root or _find_project_root()
    engine = _get_calibration_engine(root) if root else None
    if engine is None:
        return {"updated": False, "reason": "Calibration engine not available"}

    try:
        if isinstance(raw, dict):
            from bpsai_pair.telemetry.schema import TelemetryRecord

            record = TelemetryRecord.from_dict(raw)
        else:
            record = raw

        stats = engine.update_incremental(record)
        logger.info("Incremental calibration: task_type=%s", stats.task_type)
        return {"updated": True, "task_type": stats.task_type}
    except Exception as e:
        logger.warning("Incremental calibration failed: %s", e)
        return {"updated": False, "reason": str(e)}


def _scan_anomalies(project_root: Path) -> int:
    """Scan recent records for anomalies. Returns count; never raises."""
    try:
        detector = AnomalyDetector(project_root)
        anomalies = detector.scan_recent(days=7)
        for a in anomalies:
            logger.warning("Anomaly: %s — %s", a.type.value, a.message)
        return len(anomalies)
    except Exception:
        logger.debug("Anomaly detection skipped")
        return 0


def _get_hook_collector(project_root: Path) -> Any:
    """Get a HookCollector, returning None on failure."""
    try:
        from bpsai_pair.telemetry.hook_collector import HookCollector

        return HookCollector(project_root)
    except Exception:
        return None
