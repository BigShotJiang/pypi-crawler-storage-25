"""Hook system for task state changes."""

import logging
from pathlib import Path
from typing import Callable, Dict, List

from bpsai_pair.core.hook_handlers import (  # noqa: F401 re-export
    DELEGATE_MAP as _DELEGATE_MAP,
    build_handlers as _build_handlers,
)
from bpsai_pair.core.hook_types import HookContext, HookResult  # noqa: F401 re-export

logger = logging.getLogger(__name__)


class HookRunner:
    """Runs configured hooks on events."""

    # Maps gate hook names to their enforcement config keys
    _GATE_ENFORCEMENT_KEYS: Dict[str, str] = {
        "arch_check_modified": "arch_gate",
        "contract_break_check": "contract_gate",
        "check_token_budget": "budget_gate",
        "enforce_containment": "containment_gate",
        "qc_check": "qc_gate",
    }

    def __init__(self, config: dict, paircoder_dir: Path):
        self.config = config
        self.paircoder_dir = Path(paircoder_dir)
        self._gate_hooks: set[str] = {"arch_check_modified", "contract_break_check", "check_token_budget", "enforce_containment", "qc_check"}
        self._cleanup_hooks: set[str] = {
            "stop_timer", "record_metrics", "sync_pm",
            "update_state", "check_unblocked",
            "on_plan_created", "on_sprint_planned", "on_sprint_completed",
            "on_epic_completed", "on_story_completed",
        }
        self._enforcement = config.get("enforcement", {})
        self._handlers: Dict[str, Callable] = _build_handlers(self)
        self._register_external_hooks()
        self._gate_executor = self._init_gate_executor()

    def __getattr__(self, name: str):
        """Delegate _hook_name calls to extracted modules (test compat)."""
        if name not in _DELEGATE_MAP:
            raise AttributeError(f"'{type(self).__name__}' has no attribute '{name}'")
        import importlib
        mod_path, func_name, style = _DELEGATE_MAP[name]
        fn = getattr(importlib.import_module(mod_path), func_name)
        args = {"cfg_pd": (self.config, self.paircoder_dir),
                "cfg": (self.config,), "pd": (self.paircoder_dir,)}[style]
        delegate = lambda ctx, f=fn, a=args: f(ctx, *a)
        self.__dict__[name] = delegate  # cache for subsequent access
        return delegate

    def _check_token_budget(self, ctx: HookContext) -> dict:
        from bpsai_pair.core.hook_budget import check_token_budget
        return check_token_budget(ctx, self.config, self.paircoder_dir)

    def _register_external_hooks(self) -> None:
        """Register gate and enrichment hooks from external modules."""
        try:
            from bpsai_pair.core.gate_hooks import (
                arch_check_modified, contract_break_check,
            )
            pd = self.paircoder_dir
            self._handlers["arch_check_modified"] = (
                lambda ctx: arch_check_modified(ctx, project_root=pd.parent)
            )
            self._handlers["contract_break_check"] = (
                lambda ctx: contract_break_check(ctx, project_root=pd.parent)
            )
        except ImportError:
            logger.debug("Gate hooks module not available")

        try:
            from bpsai_pair.core.hook_routing import select_model
            pd = self.paircoder_dir
            self._handlers["select_model"] = (
                lambda ctx: select_model(ctx, self.config, pd)
            )
        except ImportError:
            logger.debug("Routing hook module not available")

        try:
            from bpsai_pair.core.enrichment_hooks import (
                agent_team_telemetry, calibration_update_incremental,
                feedback_calibrate, telemetry_snapshot, workspace_impact_scan,
            )
            pd = self.paircoder_dir
            self._handlers.update({
                "workspace_impact_scan": lambda ctx: workspace_impact_scan(ctx, project_root=pd.parent),
                "telemetry_snapshot": lambda ctx: telemetry_snapshot(ctx, project_root=pd.parent),
                "feedback_calibrate": lambda ctx: feedback_calibrate(ctx, project_root=pd.parent),
                "agent_team_telemetry": lambda ctx: agent_team_telemetry(ctx, project_root=pd.parent),
                "calibration_update_incremental": lambda ctx: calibration_update_incremental(ctx, project_root=pd.parent),
            })
        except ImportError:
            logger.debug("Enrichment hooks module not available")

        self._register_budget_heuristic()

    def _register_budget_heuristic(self) -> None:
        """Register the pre-task budget heuristic hook."""
        try:
            from bpsai_pair.core.budget_heuristic import budget_heuristic
            pd = self.paircoder_dir
            budget_cfg = self.config.get("session_budget", {})
            session_budget = budget_cfg.get("limit", 200_000)
            self._handlers["budget_heuristic"] = (
                lambda ctx, sb=session_budget: budget_heuristic(
                    ctx, project_root=pd.parent, session_budget=sb,
                )
            )
        except ImportError:
            logger.debug("Budget heuristic module not available")

    @property
    def enabled(self) -> bool:
        """Check if hooks are enabled."""
        return self.config.get("hooks", {}).get("enabled", True)

    def get_hooks_for_event(self, event: str) -> List[str]:
        """Get list of hooks configured for an event."""
        return self.config.get("hooks", {}).get(event, [])

    def run_hooks(self, event: str, context: HookContext) -> List[HookResult]:
        """Run all hooks for an event."""
        if not self.enabled:
            logger.debug("Hooks disabled, skipping")
            return []

        hooks = self.get_hooks_for_event(event)
        if not hooks:
            logger.debug(f"No hooks configured for {event}")
            return []

        # Dedup: hooks declared as aliases should only execute once.
        # Keyed by alias group name — hooks in the same group are skipped
        # after the first one runs.
        _HOOK_ALIAS_GROUPS: dict[str, str] = {
            "sync_pm": "pm_sync",
        }
        seen_groups: set[str] = set()
        results = []
        gate_blocked = False

        for hook_name in hooks:
            group = _HOOK_ALIAS_GROUPS.get(hook_name)
            if group is not None:
                if group in seen_groups:
                    continue
                seen_groups.add(group)
            if gate_blocked and hook_name not in self._cleanup_hooks:
                continue
            result = self._run_single_hook(hook_name, context)
            results.append(result)
            if result.blocked and hook_name in self._gate_hooks:
                effective_blocked = self._apply_enforcement_mode(
                    hook_name, result,
                )
                if effective_blocked:
                    gate_blocked = True
                    logger.warning(
                        "Gate hook %s blocked task %s: %s",
                        hook_name, context.task_id, result.result,
                    )
                else:
                    # Downgrade: result recorded but doesn't block
                    result.blocked = False

        return results

    def _apply_enforcement_mode(
        self, hook_name: str, result: "HookResult",
    ) -> bool:
        """Check enforcement mode and return whether gate should actually block.

        Returns True if the gate should block, False to downgrade.
        A7 fail-closed always blocks regardless of mode.
        """
        # fail_closed always blocks (A7 — broken gate, not policy)
        if isinstance(result.result, dict) and result.result.get("fail_closed"):
            return True

        key = self._GATE_ENFORCEMENT_KEYS.get(hook_name)
        if not key:
            return True  # Unknown gate → block (safe default)

        mode = self._enforcement.get(key, "enforce")

        if mode == "enforce":
            return True
        if mode == "warn":
            logger.warning(
                "Gate %s would block (mode=warn): %s",
                hook_name, result.result,
            )
            return False
        if mode == "observe":
            logger.debug(
                "Gate %s would block (mode=observe): %s",
                hook_name, result.result,
            )
            return False

        return True  # Unknown mode → enforce (safe default)

    def _init_gate_executor(self):
        """Create GateHookExecutor with optional signal emitter."""
        from bpsai_pair.core.gate_executor import GateHookExecutor

        emitter = None
        try:
            from bpsai_pair.telemetry.signal_emitter import SignalEmitter
            emitter = SignalEmitter(self.paircoder_dir.parent)
        except Exception:
            logger.debug("SignalEmitter not available for gate executor")
        timeout = self.config.get("hooks", {}).get("gate_timeout_s", 30.0)
        return GateHookExecutor(timeout_s=timeout, signal_emitter=emitter)

    def _run_single_hook(self, hook_name: str, context: HookContext) -> HookResult:
        """Run a single hook. Gate hooks use fail-closed executor."""
        if hook_name in self._gate_hooks:
            handler = self._handlers.get(hook_name)
            per_gate_timeout = (
                self.config.get("hooks", {})
                .get("gate_timeouts", {})
                .get(hook_name)
            )
            return self._gate_executor.execute(
                hook_name, handler, context, timeout_s=per_gate_timeout,
            )

        handler = self._handlers.get(hook_name)
        if not handler:
            logger.warning(f"Unknown hook: {hook_name}")
            return HookResult(
                hook=hook_name,
                success=False,
                error=f"Unknown hook: {hook_name}",
            )

        try:
            result = handler(context)
            logger.info(f"Hook {hook_name} completed for {context.task_id}")
            return HookResult(
                hook=hook_name, success=True, result=result,
            )
        except Exception as e:
            logger.error(f"Hook {hook_name} failed: {e}")
            return HookResult(hook=hook_name, success=False, error=str(e))


def load_config(paircoder_dir: Path) -> dict:
    """Load configuration from config.yaml."""
    import yaml

    config_path = paircoder_dir / "config.yaml"
    if config_path.exists():
        return yaml.safe_load(config_path.read_text(encoding="utf-8")) or {}
    return {}


def get_hook_runner(paircoder_dir: Path) -> HookRunner:
    """Get a HookRunner instance for the project."""
    config = load_config(paircoder_dir)
    return HookRunner(config, paircoder_dir)
