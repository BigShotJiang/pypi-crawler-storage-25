"""Timer, metrics, velocity, token tracking, and learning hook handlers.

Extracted from hooks.py to keep each module under architecture limits.
All functions accept config/paircoder_dir params instead of self.
"""

from __future__ import annotations

import logging
import warnings
from pathlib import Path
from typing import Any

from bpsai_pair.core.hook_types import HookContext

logger = logging.getLogger(__name__)


def start_timer(ctx: HookContext, config: dict, paircoder_dir: Path) -> dict:
    """Start time tracking for task."""
    try:
        from bpsai_pair.integrations.time_tracking import (
            TimeTrackingManager,
            TimeTrackingConfig,
        )

        task_title = getattr(ctx.task, "title", ctx.task_id) if ctx.task else ctx.task_id
        time_config = config.get("time_tracking", {})
        tt_config = TimeTrackingConfig(
            provider=time_config.get("provider", "none"),
            auto_start=time_config.get("auto_start", True),
            auto_stop=time_config.get("auto_stop", True),
            task_pattern=time_config.get("task_pattern", "{task_id}: {task_title}"),
        )

        from bpsai_pair.core.cache_paths import time_tracking_cache_path
        cache_path = time_tracking_cache_path(paircoder_dir)
        manager = TimeTrackingManager(tt_config, cache_path)
        timer_id = manager.start_task(ctx.task_id, task_title)

        if timer_id:
            return {"timer_started": True, "timer_id": timer_id}
        return {"timer_started": False, "reason": "auto_start disabled"}
    except Exception as e:
        logger.warning("Timer start failed: %s", e)
        return {"timer_started": False, "error": str(e)}


def stop_timer(ctx: HookContext, config: dict, paircoder_dir: Path) -> dict:
    """Stop time tracking and get duration."""
    try:
        from bpsai_pair.integrations.time_tracking import (
            TimeTrackingManager,
            TimeTrackingConfig,
            LocalTimeCache,
        )

        from bpsai_pair.core.cache_paths import time_tracking_cache_path
        cache_path = time_tracking_cache_path(paircoder_dir)
        cache = LocalTimeCache(cache_path)
        active = cache.get_active_timer()

        if not active:
            return {"timer_stopped": False, "reason": "No active timer"}

        if active.get("task_id") != ctx.task_id:
            return {
                "timer_stopped": False,
                "reason": f"Active timer is for {active.get('task_id')}, not {ctx.task_id}",
            }

        time_config = config.get("time_tracking", {})
        tt_config = TimeTrackingConfig(
            provider=time_config.get("provider", "none"),
            auto_start=time_config.get("auto_start", True),
            auto_stop=time_config.get("auto_stop", True),
            task_pattern=time_config.get("task_pattern", "{task_id}: {task_title}"),
        )

        manager = TimeTrackingManager(tt_config, cache_path)
        entry = manager.stop_task(active["timer_id"])

        if entry:
            return _format_stop_result(manager, entry, ctx.task_id)
        return {"timer_stopped": False, "reason": "Failed to stop timer"}
    except Exception as e:
        logger.warning("Timer stop failed: %s", e)
        return {"timer_stopped": False, "error": str(e)}


def _format_stop_result(manager: Any, entry: Any, task_id: str) -> dict:
    """Format timer stop result dict."""
    duration_seconds = entry.duration.total_seconds() if entry.duration else 0
    total = manager.get_task_time(task_id)
    return {
        "timer_stopped": True,
        "duration_seconds": duration_seconds,
        "total_seconds": total.total_seconds(),
        "formatted_duration": manager.format_duration(entry.duration) if entry.duration else "0m",
        "formatted_total": manager.format_duration(total),
    }


def record_metrics(ctx: HookContext, paircoder_dir: Path) -> dict:
    """Record metrics from context.extra.

    .. deprecated:: 2.15.7
        Use TelemetryStore via ``collect_for_task()`` instead.
    """
    warnings.warn(
        "record_metrics is deprecated; use TelemetryStore via collect_for_task()",
        DeprecationWarning, stacklevel=2,
    )
    try:
        from bpsai_pair.metrics import MetricsCollector

        history_dir = paircoder_dir / "history"
        history_dir.mkdir(exist_ok=True)

        collector = MetricsCollector(history_dir)
        extra = ctx.extra or {}
        event = collector.record_invocation(
            agent=ctx.agent or "unknown",
            model=extra.get("model", "unknown"),
            input_tokens=extra.get("input_tokens", 0),
            output_tokens=extra.get("output_tokens", 0),
            duration_ms=int(extra.get("duration_seconds", 0) * 1000),
            success=True,
            task_id=ctx.task_id,
            operation=extra.get("action_type", "coding"),
        )
        return {"metrics_recorded": True, "cost": f"${event.cost_usd:.4f}"}
    except Exception as e:
        logger.warning("Metrics recording failed: %s", e)
        return {"metrics_recorded": False, "error": str(e)}


def record_task_completion(ctx: HookContext, paircoder_dir: Path) -> dict:
    """Record task completion with estimated vs actual hours comparison.

    .. deprecated:: 2.15.7
        Use TelemetryStore via ``collect_for_task()`` instead.
    """
    warnings.warn(
        "record_task_completion is deprecated; use TelemetryStore via collect_for_task()",
        DeprecationWarning, stacklevel=2,
    )
    try:
        from bpsai_pair.metrics import MetricsCollector
        from bpsai_pair.integrations.time_tracking import LocalTimeCache

        from bpsai_pair.core.cache_paths import time_tracking_cache_path
        cache_path = time_tracking_cache_path(paircoder_dir)
        if not cache_path.exists():
            return {"comparison_recorded": False, "reason": "No time tracking cache found"}

        cache = LocalTimeCache(cache_path)
        total_time = cache.get_total(ctx.task_id)
        actual_hours = total_time.total_seconds() / 3600

        if actual_hours == 0:
            return {"comparison_recorded": False, "reason": "No time tracked for task"}

        if not ctx.task:
            return {"comparison_recorded": False, "reason": "No task object in context"}

        estimated_hours = ctx.task.estimated_hours.expected_hours
        history_dir = paircoder_dir / "history"
        history_dir.mkdir(exist_ok=True)

        collector = MetricsCollector(history_dir)
        data = collector.record_task_completion(
            task_id=ctx.task_id,
            estimated_hours=estimated_hours,
            actual_hours=actual_hours,
        )

        return {
            "comparison_recorded": True,
            "estimated_hours": data["estimated_hours"],
            "actual_hours": data["actual_hours"],
            "variance_hours": data["variance_hours"],
            "variance_percent": data["variance_percent"],
        }
    except Exception as e:
        logger.warning("Task completion recording failed: %s", e)
        return {"comparison_recorded": False, "error": str(e)}


def record_velocity(ctx: HookContext, paircoder_dir: Path) -> dict:
    """Record task completion for velocity tracking.

    .. deprecated:: 2.15.7
        Use TelemetryStore via ``collect_for_task()`` instead.
    """
    warnings.warn(
        "record_velocity is deprecated; use TelemetryStore via collect_for_task()",
        DeprecationWarning, stacklevel=2,
    )
    try:
        from bpsai_pair.metrics import VelocityTracker

        if not ctx.task:
            return {"velocity_recorded": False, "reason": "No task object in context"}

        complexity = ctx.task.complexity
        sprint = ctx.task.sprint or ""

        history_dir = paircoder_dir / "history"
        history_dir.mkdir(exist_ok=True)

        tracker = VelocityTracker(history_dir)
        record = tracker.record_completion(
            task_id=ctx.task_id,
            complexity=complexity,
            sprint=sprint,
        )

        return {
            "velocity_recorded": True,
            "task_id": record.task_id,
            "complexity": record.complexity,
            "sprint": record.sprint,
        }
    except Exception as e:
        logger.warning("Velocity recording failed: %s", e)
        return {"velocity_recorded": False, "error": str(e)}


def record_token_usage(ctx: HookContext, paircoder_dir: Path) -> dict:
    """Record token usage comparison for feedback loop.

    .. deprecated:: 2.15.11
        Dead code — ctx.extra never contains actual_tokens.
    """
    warnings.warn(
        "record_token_usage is deprecated; use TelemetryStore via collect_for_task()",
        DeprecationWarning, stacklevel=2,
    )
    try:
        from bpsai_pair.metrics import TokenFeedbackTracker

        if not ctx.task:
            return {"token_usage_recorded": False, "reason": "No task object in context"}

        extra = ctx.extra or {}
        actual_tokens = extra.get("actual_tokens")
        if actual_tokens is None:
            actual_tokens = extra.get("total_tokens")
        if actual_tokens is None:
            return {"token_usage_recorded": False, "reason": "No actual_tokens in context"}

        estimated = ctx.task.estimated_tokens.total_tokens
        task_type = ctx.task.type
        complexity = ctx.task.complexity

        history_dir = paircoder_dir / "history"
        history_dir.mkdir(exist_ok=True)

        tracker = TokenFeedbackTracker(history_dir)
        data = tracker.record_usage(
            task_id=ctx.task_id,
            estimated_tokens=estimated,
            actual_tokens=actual_tokens,
            task_type=task_type,
            complexity=complexity,
        )

        return {
            "token_usage_recorded": True,
            "task_id": ctx.task_id,
            "estimated_tokens": estimated,
            "actual_tokens": actual_tokens,
            "ratio": data.get("ratio", 1.0),
        }
    except Exception as e:
        logger.warning("Token usage recording failed: %s", e)
        return {"token_usage_recorded": False, "error": str(e)}


# Default: apply learning every 5 completed tasks
_DEFAULT_LEARNING_THRESHOLD = 5


def apply_token_learning(
    ctx: HookContext, config: dict, paircoder_dir: Path
) -> dict:
    """Apply token feedback learning when enough data has accumulated.

    .. deprecated:: 2.15.11
        Depends on record_token_usage which never records data.
    """
    warnings.warn(
        "apply_token_learning is deprecated; use TelemetryStore via collect_for_task()",
        DeprecationWarning, stacklevel=2,
    )
    try:
        from bpsai_pair.metrics import TokenFeedbackTracker
        from bpsai_pair.metrics.token_estimator import TokenEstimationConfig

        tf_config = config.get("token_feedback", {})
        threshold = tf_config.get("learning_threshold", _DEFAULT_LEARNING_THRESHOLD)
        history_dir = paircoder_dir / "history"
        history_dir.mkdir(exist_ok=True)
        tracker = TokenFeedbackTracker(history_dir)
        comparisons = tracker.load_comparisons()
        count = len(comparisons)
        if count < threshold or count % threshold != 0:
            return {"learning_applied": False, "reason": "below_threshold",
                    "comparison_count": count, "threshold": threshold}

        config_path = paircoder_dir / "config.yaml"
        est_config = TokenEstimationConfig.from_dict(config.get("token_estimates", {}))
        new_config = tracker.apply_learning(est_config)
        tracker.persist_coefficients(config_path, new_config)
        return {"learning_applied": True, "comparison_count": count, "threshold": threshold}
    except Exception as e:
        logger.warning("Token learning failed: %s", e)
        return {"learning_applied": False, "error": str(e)}
