"""Trello sync and activity logging hook handlers.

Extracted from hooks.py to keep each module under architecture limits.
All functions accept config/paircoder_dir params instead of self.
"""

from __future__ import annotations

import logging
from typing import Any

from bpsai_pair.core.hook_types import HookContext

logger = logging.getLogger(__name__)


def sync_trello(ctx: HookContext, config: dict) -> dict:
    """Sync task state to Trello card."""
    try:
        from bpsai_pair.trello.auth import load_token
        from bpsai_pair.trello.client import TrelloService

        token_data = load_token()
        if not token_data:
            return {"trello_synced": False, "reason": "Not connected to Trello"}
        trello_config = config.get("trello", {})
        board_id = trello_config.get("board_id")
        if not board_id:
            return {"trello_synced": False, "reason": "No board_id configured"}

        service = TrelloService(api_key=token_data["api_key"], token=token_data["token"])
        service.set_board(board_id)
        target_list, comment_template = _get_event_config(trello_config, ctx.event)
        if not target_list:
            return {"trello_synced": False, "reason": f"No target list for {ctx.event}"}
        card = _find_card(service, ctx)
        if not card:
            return {"trello_synced": False, "reason": f"Card not found for {ctx.task_id}"}

        service.move_card(card, target_list)
        if comment_template:
            _add_comment(service, card, comment_template, ctx)

        logger.info(f"Moved card for {ctx.task_id} to '{target_list}'")
        return {
            "trello_synced": True, "action": ctx.event,
            "target_list": target_list, "card_name": card.name,
        }
    except ImportError:
        return {"trello_synced": False, "reason": "py-trello not installed"}
    except Exception as e:
        logger.warning(f"Trello sync failed: {e}")
        return {"trello_synced": False, "error": str(e)}


def _add_comment(service: Any, card: Any, template: str, ctx: HookContext) -> None:
    """Format and add a comment to a Trello card."""
    comment = template.format(
        agent=ctx.agent or "Agent",
        summary=ctx.extra.get("summary", "Task updated"),
        reason=ctx.extra.get("reason", "No reason provided"),
    )
    service.add_comment(card, comment)


def _get_event_config(
    trello_config: dict, event: str,
) -> tuple[str | None, str | None]:
    """Get target list and comment template for an event."""
    automation = trello_config.get("automation", {})
    if not automation:
        automation = trello_config.get("card_format", {}).get("automation", {})

    event_config = {
        "on_task_ready": automation.get("on_task_ready", {}),
        "on_task_start": automation.get("on_task_start", {}),
        "on_task_complete": automation.get("on_task_complete", {}),
        "on_task_block": automation.get("on_task_block", {}),
    }
    cfg = event_config.get(event, {})
    return cfg.get("move_to_list"), cfg.get("add_comment")


def _find_card(service: Any, ctx: HookContext) -> Any:
    """Find a Trello card by task ID or trello_card_id."""
    card = None
    for lst in service.board.all_lists():
        for c in lst.list_cards():
            if f"[{ctx.task_id}]" in c.name:
                card = c
                break
        if card:
            break

    if not card:
        trello_card_id = getattr(ctx.task, "trello_card_id", None)
        if trello_card_id:
            card, _ = service.find_card(trello_card_id)

    return card


def log_trello_activity(ctx: HookContext, config: dict) -> dict:
    """Log activity to Trello card as a comment."""
    try:
        from bpsai_pair.trello.auth import load_token
        from bpsai_pair.trello.activity import TrelloActivityLogger, ActivityEvent
        from bpsai_pair.trello.client import TrelloService

        token_data = load_token()
        if not token_data:
            return {"activity_logged": False, "reason": "Not connected to Trello"}

        trello_config = config.get("trello", {})
        board_id = trello_config.get("board_id")
        if not board_id:
            return {"activity_logged": False, "reason": "No board_id configured"}

        service = TrelloService(
            api_key=token_data["api_key"], token=token_data["token"]
        )
        service.set_board(board_id)
        activity_logger = TrelloActivityLogger(service)

        event_mapping = {
            "on_task_start": ActivityEvent.TASK_STARTED,
            "on_task_complete": ActivityEvent.TASK_COMPLETED,
            "on_task_block": ActivityEvent.TASK_BLOCKED,
        }

        activity_event = event_mapping.get(ctx.event)
        if not activity_event:
            return {"activity_logged": False, "reason": f"Unknown event: {ctx.event}"}

        success = _dispatch_activity(activity_logger, activity_event, ctx)

        if success:
            logger.info(f"Logged activity for {ctx.task_id}: {activity_event.value}")
            return {"activity_logged": True, "event": activity_event.value}
        else:
            return {"activity_logged": False, "reason": "Card not found"}

    except ImportError as e:
        return {"activity_logged": False, "reason": f"Import error: {e}"}
    except Exception as e:
        logger.warning(f"Activity logging failed: {e}")
        return {"activity_logged": False, "error": str(e)}


def _dispatch_activity(
    activity_logger: Any, activity_event: Any, ctx: HookContext,
) -> bool:
    """Dispatch the appropriate activity log method."""
    extra = ctx.extra or {}

    if activity_event.value == "task_started":
        return activity_logger.log_task_started(
            ctx.task_id, agent=ctx.agent or "Agent"
        )
    elif activity_event.value == "task_completed":
        return activity_logger.log_task_completed(
            ctx.task_id, summary=extra.get("summary", "Task completed")
        )
    elif activity_event.value == "task_blocked":
        return activity_logger.log_task_blocked(
            ctx.task_id, reason=extra.get("reason", "No reason provided")
        )
    return False
