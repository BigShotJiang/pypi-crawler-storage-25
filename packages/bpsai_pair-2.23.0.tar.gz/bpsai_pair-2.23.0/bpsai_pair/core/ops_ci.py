"""Local CI runner operations."""
from __future__ import annotations

import subprocess
from pathlib import Path


class LocalCI:
    """Cross-platform local CI runner."""

    @staticmethod
    def run_python_checks(root: Path) -> dict:
        """Run Python linting, formatting, and tests."""
        results = {}

        # Check if Python project
        if not ((root / "pyproject.toml").exists() or (root / "requirements.txt").exists()):
            return results

        # Try to run ruff
        try:
            subprocess.run(["ruff", "format", "--check", "."], cwd=root, check=True)
            subprocess.run(["ruff", "check", "."], cwd=root, check=True)
            results["ruff"] = "passed"
        except:
            results["ruff"] = "failed or not installed"

        # Try to run mypy
        try:
            subprocess.run(["mypy", "."], cwd=root, check=True)
            results["mypy"] = "passed"
        except:
            results["mypy"] = "failed or not installed"

        # Try to run pytest
        try:
            subprocess.run(["pytest", "-q"], cwd=root, check=True)
            results["pytest"] = "passed"
        except:
            results["pytest"] = "failed or not installed"

        return results

    @staticmethod
    def run_node_checks(root: Path) -> dict:
        """Run Node.js linting, formatting, and tests."""
        results = {}

        if not (root / "package.json").exists():
            return results

        # Try npm commands
        try:
            subprocess.run(["npm", "run", "lint"], cwd=root, check=True)
            results["eslint"] = "passed"
        except:
            results["eslint"] = "failed or not configured"

        try:
            subprocess.run(["npm", "test"], cwd=root, check=True)
            results["npm test"] = "passed"
        except:
            results["npm test"] = "failed or not configured"

        return results

    @staticmethod
    def run_all(root: Path) -> dict:
        """Run all applicable CI checks."""
        results = {
            "python": LocalCI.run_python_checks(root),
            "node": LocalCI.run_node_checks(root)
        }
        return results
