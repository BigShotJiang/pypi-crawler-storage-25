"""Architecture checker for enforcement.

Main ArchitectureEnforcer class that checks files against constraints.

Location: tools/cli/bpsai_pair/core/enforcement_checker.py
"""
from __future__ import annotations

import ast
import fnmatch
import subprocess
from pathlib import Path
from typing import TYPE_CHECKING, Optional

import yaml

from .enforcement_analyzer import SplitAnalyzer
from .enforcement_models import (
    ArchitectureViolation,
    SplitSuggestion,
    ViolationType,
)
from .enforcement_utils import get_ast_end_line
from .file_role_detector import FileRole, FileRoleDetector

if TYPE_CHECKING:
    from .config_validator import ArchitectureConfig


class ArchitectureEnforcer:
    """Enforce modular architecture constraints on Python files.

    Checks file length, function length, function count, and import count
    against configurable thresholds. Test files get relaxed limits.
    """

    DEFAULT_THRESHOLDS = {
        "max_file_lines": 400,
        "warning_file_lines": 200,
        "max_function_lines": 50,
        "max_functions_per_file": 15,
        "max_imports": 20,
    }

    DEFAULT_TEST_THRESHOLDS = {
        "max_file_lines": 600,
        "warning_file_lines": 400,
        "max_function_lines": 50,
        "max_functions_per_file": 40,
        "max_imports": 30,
    }

    DEFAULT_EXCLUDE_PATTERNS = [
        "__pycache__",
        ".git",
        ".venv",
        "venv",
        "node_modules",
        ".tox",
        ".eggs",
        "*.egg-info",
        "dist",
        "build",
        ".pytest_cache",
        ".mypy_cache",
    ]

    def __init__(
        self,
        max_file_lines: int = DEFAULT_THRESHOLDS["max_file_lines"],
        warning_file_lines: int = DEFAULT_THRESHOLDS["warning_file_lines"],
        max_function_lines: int = DEFAULT_THRESHOLDS["max_function_lines"],
        max_functions_per_file: int = DEFAULT_THRESHOLDS["max_functions_per_file"],
        max_imports: int = DEFAULT_THRESHOLDS["max_imports"],
        exclude_patterns: Optional[list[str]] = None,
        enabled: bool = True,
        test_max_file_lines: int = DEFAULT_TEST_THRESHOLDS["max_file_lines"],
        test_warning_file_lines: int = DEFAULT_TEST_THRESHOLDS["warning_file_lines"],
        test_max_function_lines: int = DEFAULT_TEST_THRESHOLDS["max_function_lines"],
        test_max_functions_per_file: int = DEFAULT_TEST_THRESHOLDS["max_functions_per_file"],
        test_max_imports: int = DEFAULT_TEST_THRESHOLDS["max_imports"],
        role_detector: Optional[FileRoleDetector] = None,
        arch_config: Optional["ArchitectureConfig"] = None,
    ):
        """Initialize the enforcer with production and test thresholds."""
        self.enabled = enabled
        self.max_file_lines = max_file_lines
        self.warning_file_lines = warning_file_lines
        self.max_function_lines = max_function_lines
        self.max_functions_per_file = max_functions_per_file
        self.max_imports = max_imports

        # Test file overrides
        self.test_max_file_lines = test_max_file_lines
        self.test_warning_file_lines = test_warning_file_lines
        self.test_max_function_lines = test_max_function_lines
        self.test_max_functions_per_file = test_max_functions_per_file
        self.test_max_imports = test_max_imports

        # Role-based detection (A6)
        self._role_detector = role_detector or FileRoleDetector()
        self._arch_config = arch_config

        if exclude_patterns is not None:
            self.exclude_patterns = list(exclude_patterns)
        else:
            self.exclude_patterns = list(self.DEFAULT_EXCLUDE_PATTERNS)

    @classmethod
    def from_architecture_config(
        cls, config: "ArchitectureConfig"
    ) -> "ArchitectureEnforcer":
        """Create an enforcer from an ArchitectureConfig dataclass."""
        exclude_patterns = list(cls.DEFAULT_EXCLUDE_PATTERNS)
        if config.exclude_patterns:
            exclude_patterns.extend(config.exclude_patterns)

        role_detector = FileRoleDetector(
            role_overrides=getattr(config, "role_overrides", None) or {},
        )

        return cls(
            max_file_lines=config.max_file_lines,
            warning_file_lines=config.warning_file_lines,
            max_function_lines=config.max_function_lines,
            max_functions_per_file=config.max_functions_per_file,
            max_imports=config.max_imports,
            exclude_patterns=exclude_patterns,
            enabled=config.enabled,
            test_max_file_lines=config.test_max_file_lines,
            test_warning_file_lines=config.test_warning_file_lines,
            test_max_function_lines=config.test_max_function_lines,
            test_max_functions_per_file=config.test_max_functions_per_file,
            test_max_imports=config.test_max_imports,
            role_detector=role_detector,
            arch_config=config,
        )

    @classmethod
    def from_config(cls, root: Path) -> "ArchitectureEnforcer":
        """Create an enforcer from .paircoder/config.yaml."""
        from .config_validator import ArchitectureConfig

        config_file = root / ".paircoder" / "config.yaml"
        if not config_file.exists():
            config_file = root / ".paircoder" / "config.yml"

        if not config_file.exists():
            return cls()

        try:
            with open(config_file, encoding="utf-8") as f:
                data = yaml.safe_load(f) or {}
        except (yaml.YAMLError, OSError):
            return cls()

        arch_data = data.get("architecture", {})

        # If no architecture section, return default
        if not arch_data:
            return cls()

        # Create ArchitectureConfig and use it
        try:
            arch_config = ArchitectureConfig.from_dict(arch_data)
            return cls.from_architecture_config(arch_config)
        except (ValueError, TypeError):
            # Invalid config, return defaults
            return cls()

    def _is_test_file(self, path: Path) -> bool:
        """Check if path is a test file (test_*, *_test.py, conftest.py, tests/)."""
        name = path.name
        if name.startswith("test_") or name.endswith("_test.py"):
            return True
        if name == "conftest.py":
            return True
        if "tests" in path.parts:
            return True
        return False

    def _get_limits(self, path_or_is_test: Path | bool) -> dict[str, int]:
        """Return applicable limits for a file path or test boolean.

        Accepts Path (role-based lookup) or bool (legacy test/non-test).
        """
        if isinstance(path_or_is_test, Path) and self._arch_config:
            role = self._role_detector.detect(path_or_is_test)
            role_limits = self._arch_config.get_role_limits(role)
            return {
                "max_file": role_limits["max_file_lines"],
                "warn_file": role_limits["warning_file_lines"],
                "max_func": role_limits["max_function_lines"],
                "max_funcs": role_limits["max_functions_per_file"],
                "max_imp": role_limits["max_imports"],
            }

        # Legacy path: bool or Path without arch_config
        is_test = (
            path_or_is_test
            if isinstance(path_or_is_test, bool)
            else self._is_test_file(path_or_is_test)
        )
        if is_test:
            return {
                "max_file": self.test_max_file_lines,
                "warn_file": self.test_warning_file_lines,
                "max_func": self.test_max_function_lines,
                "max_funcs": self.test_max_functions_per_file,
                "max_imp": self.test_max_imports,
            }
        return {
            "max_file": self.max_file_lines,
            "warn_file": self.warning_file_lines,
            "max_func": self.max_function_lines,
            "max_funcs": self.max_functions_per_file,
            "max_imp": self.max_imports,
        }

    def check_file(self, path: Path) -> list[ArchitectureViolation]:
        """Check a single Python file for architecture violations."""
        if path.suffix != ".py" or not path.exists():
            return []

        try:
            content = path.read_text(encoding="utf-8")
        except (OSError, UnicodeDecodeError):
            return []

        limits = self._get_limits(path)
        violations: list[ArchitectureViolation] = []
        line_count = len(content.splitlines())

        # Detect role for violation details (only when role-aware)
        role_details: dict | None = None
        if self._arch_config:
            role = self._role_detector.detect(path)
            role_details = {"file_role": role.value}

        if line_count > limits["max_file"]:
            violations.append(ArchitectureViolation(
                file=path, violation_type=ViolationType.FILE_TOO_LARGE,
                current_value=line_count, threshold=limits["max_file"],
                severity="error", details=role_details,
            ))
        elif line_count > limits["warn_file"]:
            violations.append(ArchitectureViolation(
                file=path, violation_type=ViolationType.FILE_TOO_LARGE,
                current_value=line_count, threshold=limits["warn_file"],
                severity="warning", details=role_details,
            ))

        try:
            tree = ast.parse(content)
        except SyntaxError:
            return violations

        violations.extend(self._check_ast(path, tree, limits))
        return violations

    def _check_ast(
        self,
        path: Path,
        tree: ast.AST,
        limits: dict[str, int],
    ) -> list[ArchitectureViolation]:
        """Check AST-level constraints (imports, functions, function lengths)."""
        violations: list[ArchitectureViolation] = []

        import_count = self._count_imports(tree)
        if import_count > limits["max_imp"]:
            violations.append(ArchitectureViolation(
                file=path, violation_type=ViolationType.TOO_MANY_IMPORTS,
                current_value=import_count, threshold=limits["max_imp"],
                severity="error",
            ))

        functions = self._find_functions(tree)
        if len(functions) > limits["max_funcs"]:
            violations.append(ArchitectureViolation(
                file=path, violation_type=ViolationType.TOO_MANY_FUNCTIONS,
                current_value=len(functions), threshold=limits["max_funcs"],
                severity="error",
            ))

        for func_name, start_line, end_line in functions:
            func_length = end_line - start_line + 1
            if func_length > limits["max_func"]:
                violations.append(ArchitectureViolation(
                    file=path, violation_type=ViolationType.FUNCTION_TOO_LONG,
                    current_value=func_length, threshold=limits["max_func"],
                    severity="error",
                    line_numbers=[start_line, end_line],
                    details={"function_name": func_name},
                ))

        return violations

    def _count_imports(self, tree: ast.AST) -> int:
        """Count import statements in AST."""
        count = 0
        for node in ast.walk(tree):
            if isinstance(node, (ast.Import, ast.ImportFrom)):
                count += 1
        return count

    def _find_functions(self, tree: ast.AST) -> list[tuple[str, int, int]]:
        """Find all functions in AST with their (name, start, end) tuples."""
        functions = []

        for node in ast.walk(tree):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                start_line = node.lineno
                end_line = get_ast_end_line(node)
                functions.append((node.name, start_line, end_line))

        return functions

    def check_directory(self, path: Path) -> list[ArchitectureViolation]:
        """Check all Python files in a directory recursively."""
        violations: list[ArchitectureViolation] = []

        if not path.exists() or not path.is_dir():
            return violations

        for file_path in path.rglob("*.py"):
            # Check if file matches any exclude pattern
            if self._should_exclude(file_path):
                continue

            violations.extend(self.check_file(file_path))

        return violations

    def _should_exclude(self, path: Path) -> bool:
        """Check if a path should be excluded."""
        path_str = str(path)
        for pattern in self.exclude_patterns:
            # Check if pattern matches any part of the path (simple substring)
            if pattern in path_str:
                return True
            # Use Path.match for glob patterns with directory components
            if path.match(pattern):
                return True
            # Also check fnmatch style patterns against basename
            if fnmatch.fnmatch(path.name, pattern):
                return True
            # Check fnmatch against individual path components
            for part in path.parts:
                if fnmatch.fnmatch(part, pattern):
                    return True
        return False

    def check_staged_files(self) -> list[ArchitectureViolation]:
        """Check git staged Python files for violations."""
        violations: list[ArchitectureViolation] = []

        try:
            result = subprocess.run(
                ["git", "diff", "--cached", "--name-only", "--diff-filter=ACM"],
                capture_output=True,
                text=True,
                check=False,
            )
        except FileNotFoundError:
            # Git not installed
            return violations

        if result.returncode != 0:
            # Not in a git repo or other error
            return violations

        staged_files = result.stdout.strip().splitlines()

        for file_name in staged_files:
            file_path = Path(file_name)
            if file_path.suffix == ".py" and file_path.exists():
                violations.extend(self.check_file(file_path))

        return violations

    def suggest_split(self, violation: ArchitectureViolation) -> SplitSuggestion:
        """Generate split suggestions for a file via SplitAnalyzer."""
        analyzer = SplitAnalyzer()
        return analyzer.suggest_split(violation)
