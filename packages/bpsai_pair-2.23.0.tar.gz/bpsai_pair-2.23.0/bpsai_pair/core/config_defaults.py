"""Default configuration values and constants for PairCoder.

This module contains all default values, constants, and configuration
presets used throughout the config system.
"""
from __future__ import annotations

import importlib.metadata
from pathlib import Path
from typing import Dict, List, Optional, Tuple

# Config schema version — derived from installed package version.
# Falls back to a hardcoded value during development before install.
_FALLBACK_SCHEMA_VERSION = "2.16.1"

try:
    CONFIG_SCHEMA_VERSION = importlib.metadata.version("bpsai-pair")
except importlib.metadata.PackageNotFoundError:
    CONFIG_SCHEMA_VERSION = _FALLBACK_SCHEMA_VERSION

# Backwards compatibility alias (deprecated, use CONFIG_SCHEMA_VERSION)
CURRENT_CONFIG_VERSION = CONFIG_SCHEMA_VERSION

# Required top-level sections for a complete config
# Note: 'flows' was removed - deprecated in favor of skills
# Note: 'security' is optional - not all projects need it
REQUIRED_SECTIONS: List[str] = [
    "version",
    "project",
    "workflow",
    "pack",
    "routing",
    "trello",
    "estimation",
    "metrics",
    "hooks",
    "pm",
]

# Hooks that are dead code and should be removed during upgrade.
# These read from ctx.extra / ctx.task attributes that are never populated.
DEPRECATED_HOOKS: frozenset = frozenset({
    "record_task_completion",
    "record_metrics",
    "record_velocity",
    "record_token_usage",
    "apply_token_learning",
})

# Default network domains allowed in containment mode
DEFAULT_CONTAINMENT_NETWORK_ALLOWLIST: List[str] = [
    "api.anthropic.com",
    "api.trello.com",
    "github.com",
    "pypi.org",
]

# Default project settings
DEFAULT_PROJECT_NAME = "My Project"
DEFAULT_PRIMARY_GOAL = "Build awesome software"
DEFAULT_COVERAGE_TARGET = 80

# Default branch settings
DEFAULT_BRANCH_TYPE = "feature"
DEFAULT_MAIN_BRANCH = "main"

# Default context settings
DEFAULT_CONTEXT_DIR = "context"

# Default pack settings
DEFAULT_PACK_NAME = "agent_pack.tgz"
DEFAULT_PACK_EXCLUDES: List[str] = [
    ".git",
    ".venv",
    "__pycache__",
    "node_modules",
    "dist",
    "build",
    "*.log",
    "*.bak",
]

# Default CI settings
DEFAULT_PYTHON_FORMATTER = "ruff"
DEFAULT_NODE_FORMATTER = "prettier"

# Environment variable mappings
# Maps environment variable names to config field names
ENV_MAPPINGS: Dict[str, str] = {
    "PAIRCODER_MAIN_BRANCH": "main_branch",
    "PAIRCODER_CONTEXT_DIR": "context_dir",
    "PAIRCODER_DEFAULT_BRANCH": "default_branch_type",
    "PAIRCODER_PROJECT_NAME": "project_name",
}


def is_config_stale(
    root: Path,
) -> Tuple[bool, Optional[str], str]:
    """Check if project config version is behind the current schema version.

    Fast check (no network, just reads version field from YAML).

    Returns:
        (is_stale, current_version, expected_version)
    """
    config_path = root / ".paircoder" / "config.yaml"
    if not config_path.exists():
        config_path = root / ".paircoder" / "config.yml"
    if not config_path.exists():
        return False, None, CONFIG_SCHEMA_VERSION

    try:
        import yaml

        data = yaml.safe_load(config_path.read_text(encoding="utf-8")) or {}
        current = data.get("version")
        if current is None:
            return True, None, CONFIG_SCHEMA_VERSION
        return str(current) != CONFIG_SCHEMA_VERSION, str(current), CONFIG_SCHEMA_VERSION
    except Exception:
        return False, None, CONFIG_SCHEMA_VERSION
