"""Task execution state machine.

Enforces valid state transitions for tasks.
Prevents skipping steps in the workflow.
"""
import json
from datetime import datetime, UTC
from enum import Enum
from pathlib import Path
from typing import Optional

import typer
from rich.console import Console

console = Console()


class TaskState(Enum):
    """Valid states for task execution.

    State flow for PM provider users:
        NOT_STARTED → BUDGET_CHECKED → IN_PROGRESS → EXTERNAL_AC_VERIFIED → LOCAL_AC_VERIFIED → COMPLETED

    State flow for local-only users:
        NOT_STARTED → BUDGET_CHECKED → IN_PROGRESS → LOCAL_AC_VERIFIED → COMPLETED

    Optional review path:
        IN_PROGRESS → IN_REVIEW → LOCAL_AC_VERIFIED → COMPLETED
    """
    NOT_STARTED = "not_started"
    BUDGET_CHECKED = "budget_checked"
    IN_PROGRESS = "in_progress"
    EXTERNAL_AC_VERIFIED = "external_ac_verified"  # PM provider AC verified
    AC_VERIFIED = "external_ac_verified"  # Compat alias
    IN_REVIEW = "in_review"
    LOCAL_AC_VERIFIED = "local_ac_verified"  # Local task file AC verified (all users)
    COMPLETED = "completed"
    BLOCKED = "blocked"
    CANCELLED = "cancelled"


# Valid state transitions
# Key = current state, Value = list of valid target states
# IMPORTANT: Completion MUST go through LOCAL_AC_VERIFIED to ensure local AC is checked
VALID_TRANSITIONS: dict[TaskState, list[TaskState]] = {
    TaskState.NOT_STARTED: [TaskState.BUDGET_CHECKED, TaskState.BLOCKED, TaskState.CANCELLED],
    TaskState.BUDGET_CHECKED: [TaskState.IN_PROGRESS, TaskState.NOT_STARTED, TaskState.BLOCKED, TaskState.CANCELLED],
    # IN_PROGRESS can go to:
    # - EXTERNAL_AC_VERIFIED (PM path: provider AC checked)
    # - IN_REVIEW (review path)
    # - LOCAL_AC_VERIFIED (local-only path: skip provider, verify local AC)
    # - BLOCKED / CANCELLED
    TaskState.IN_PROGRESS: [
        TaskState.EXTERNAL_AC_VERIFIED, TaskState.IN_REVIEW,
        TaskState.LOCAL_AC_VERIFIED, TaskState.BLOCKED, TaskState.CANCELLED,
    ],
    # IN_REVIEW transitions — must go through LOCAL_AC_VERIFIED before COMPLETED
    TaskState.IN_REVIEW: [TaskState.LOCAL_AC_VERIFIED, TaskState.IN_PROGRESS, TaskState.BLOCKED],
    # EXTERNAL_AC_VERIFIED (PM AC done) MUST go to LOCAL_AC_VERIFIED before completion
    TaskState.EXTERNAL_AC_VERIFIED: [TaskState.LOCAL_AC_VERIFIED, TaskState.IN_PROGRESS],
    # LOCAL_AC_VERIFIED is the gate before completion
    TaskState.LOCAL_AC_VERIFIED: [TaskState.COMPLETED, TaskState.IN_PROGRESS],
    TaskState.COMPLETED: [],  # Terminal state
    TaskState.BLOCKED: [TaskState.NOT_STARTED, TaskState.IN_PROGRESS, TaskState.BUDGET_CHECKED, TaskState.CANCELLED],
    TaskState.CANCELLED: [],  # Terminal state
}

# Human-readable descriptions for each transition
TRANSITION_TRIGGERS: dict[tuple[TaskState, TaskState], str] = {
    (TaskState.NOT_STARTED, TaskState.BUDGET_CHECKED): "bpsai-pair budget check <task-id>",
    (TaskState.BUDGET_CHECKED, TaskState.IN_PROGRESS): "bpsai-pair task update <id> --status in_progress (or pm start / ttask start)",
    # PM provider path
    (TaskState.IN_PROGRESS, TaskState.EXTERNAL_AC_VERIFIED): "Verify AC on PM provider (pm done --strict or ttask done --strict)",
    (TaskState.EXTERNAL_AC_VERIFIED, TaskState.LOCAL_AC_VERIFIED): "Sync remote AC to local: bpsai-pair task ac <id> --sync",
    (TaskState.EXTERNAL_AC_VERIFIED, TaskState.IN_PROGRESS): "Uncheck AC item (work incomplete)",
    # Review path
    (TaskState.IN_PROGRESS, TaskState.IN_REVIEW): "Submit for review",
    (TaskState.IN_REVIEW, TaskState.LOCAL_AC_VERIFIED): "Review approved, verify local AC",
    (TaskState.IN_REVIEW, TaskState.IN_PROGRESS): "Review rejected, rework needed",
    # Local-only path
    (TaskState.IN_PROGRESS, TaskState.LOCAL_AC_VERIFIED): "Check local AC: bpsai-pair task ac <id> --auto-check",
    # Final completion (all paths)
    (TaskState.LOCAL_AC_VERIFIED, TaskState.COMPLETED): "bpsai-pair task update <id> --status done (or pm done / ttask done)",
    (TaskState.LOCAL_AC_VERIFIED, TaskState.IN_PROGRESS): "Uncheck local AC item (work incomplete)",
    # Blocked transitions
    (TaskState.BLOCKED, TaskState.NOT_STARTED): "Resolve blocker and reset",
    (TaskState.BLOCKED, TaskState.IN_PROGRESS): "bpsai-pair pm start <id> (or ttask unblock <card-id>)",
}

# Descriptions for skip attempts
SKIP_EXPLANATIONS: dict[tuple[TaskState, TaskState], str] = {
    (TaskState.NOT_STARTED, TaskState.IN_PROGRESS): "Must check budget first",
    (TaskState.NOT_STARTED, TaskState.COMPLETED): "Cannot skip to completion",
    (TaskState.BUDGET_CHECKED, TaskState.COMPLETED): "Must start and verify AC first",
    (TaskState.BUDGET_CHECKED, TaskState.EXTERNAL_AC_VERIFIED): "Must start task first",
    (TaskState.BUDGET_CHECKED, TaskState.LOCAL_AC_VERIFIED): "Must start task first",
    (TaskState.IN_PROGRESS, TaskState.COMPLETED): "Must verify local AC first (bpsai-pair task ac <id> --auto-check)",
    (TaskState.EXTERNAL_AC_VERIFIED, TaskState.COMPLETED): "Must sync/verify local AC first (bpsai-pair task ac <id> --sync)",
    (TaskState.IN_REVIEW, TaskState.COMPLETED): "Must verify local AC first after review approval",
}


class TaskStateManager:
    """Manages task execution states.

    Persists state to .paircoder/task_state.json and enforces valid transitions.
    """

    def __init__(self, state_file: Optional[Path] = None):
        """Initialize with optional state_file (defaults to .paircoder/task_state.json)."""
        if state_file is None:
            from .ops import find_paircoder_dir
            paircoder_dir = find_paircoder_dir()
            state_file = paircoder_dir / "task_state.json"

        self.state_file = state_file
        self._states: dict[str, str] = {}
        self._history: list[dict] = []
        self._load()

    def _load(self) -> None:
        """Load state from file, migrating old values."""
        if self.state_file.exists():
            try:
                data = json.loads(self.state_file.read_text(encoding="utf-8"))
                self._states = data.get("states", {})
                self._history = data.get("history", [])
                # Migrate old "ac_verified" → "external_ac_verified"
                for task_id, state_val in self._states.items():
                    if state_val == "ac_verified":
                        self._states[task_id] = "external_ac_verified"
            except (json.JSONDecodeError, KeyError):
                self._states = {}
                self._history = []

    def _save(self) -> None:
        """Save state to file."""
        self.state_file.parent.mkdir(parents=True, exist_ok=True)
        data = {
            "states": self._states,
            "history": self._history[-100:],  # Keep last 100 transitions
            "updated": datetime.now(UTC).isoformat() + "Z",
        }
        self.state_file.write_text(json.dumps(data, indent=2), encoding="utf-8")

    def get_state(self, task_id: str) -> TaskState:
        """Get current state of a task.

        Returns NOT_STARTED for unknown tasks.
        """
        state_str = self._states.get(task_id, "not_started")
        try:
            return TaskState(state_str)
        except ValueError:
            return TaskState.NOT_STARTED

    def can_transition(self, task_id: str, target: TaskState) -> tuple[bool, str]:
        """Check if transition is valid. Returns (allowed, reason)."""
        current = self.get_state(task_id)
        valid_targets = VALID_TRANSITIONS.get(current, [])

        if target in valid_targets:
            trigger = TRANSITION_TRIGGERS.get((current, target), "")
            return True, f"Valid: {current.value} → {target.value}"

        if not valid_targets:
            return False, f"Task is in terminal state '{current.value}'"

        # Check for skip attempt explanation
        skip_reason = SKIP_EXPLANATIONS.get((current, target))
        if skip_reason:
            next_state = valid_targets[0]
            trigger = TRANSITION_TRIGGERS.get((current, next_state), "unknown")
            return False, (
                f"{skip_reason}. "
                f"Current: '{current.value}' → Next: '{next_state.value}'. "
                f"Run: {trigger}"
            )

        # Generic invalid transition
        next_state = valid_targets[0]
        trigger = TRANSITION_TRIGGERS.get((current, next_state), "unknown")
        return False, (
            f"Invalid transition: '{current.value}' → '{target.value}'. "
            f"Next valid state: '{next_state.value}'. "
            f"Run: {trigger}"
        )

    def can_transition_with_ac_check(
        self, task_id: str, target: TaskState, tasks_dir: Optional[Path] = None
    ) -> tuple[bool, str]:
        """Like can_transition() but also verifies local AC for LOCAL_AC_VERIFIED."""
        # First check basic transition validity
        allowed, reason = self.can_transition(task_id, target)
        if not allowed:
            return allowed, reason

        # If transitioning to LOCAL_AC_VERIFIED, verify local AC items
        if target == TaskState.LOCAL_AC_VERIFIED:
            # Import here to avoid circular dependency
            ac_result = verify_local_ac(task_id, tasks_dir)

            if ac_result.get("error"):
                return False, f"AC verification error: {ac_result['error']}"

            if not ac_result["verified"]:
                unchecked = ac_result["unchecked_items"]
                unchecked_list = "\n".join(f"  - {item}" for item in unchecked[:5])
                if len(unchecked) > 5:
                    unchecked_list += f"\n  ... and {len(unchecked) - 5} more"
                return False, (
                    f"Cannot transition to LOCAL_AC_VERIFIED: {len(unchecked)} "
                    f"unchecked AC item(s):\n{unchecked_list}\n\n"
                    f"Check items: bpsai-pair task ac {task_id} --auto-check"
                )

        return True, reason

    def transition(self, task_id: str, target: TaskState, trigger: str = "") -> None:
        """Transition task to new state. Raises typer.Exit if invalid."""
        allowed, reason = self.can_transition(task_id, target)

        if not allowed:
            console.print(f"[red]\u274c BLOCKED:[/red] {reason}")
            raise typer.Exit(1)

        current = self.get_state(task_id)

        # Record transition in history
        self._history.append({
            "task_id": task_id,
            "from_state": current.value,
            "to_state": target.value,
            "timestamp": datetime.now(UTC).isoformat() + "Z",
            "trigger": trigger,
        })

        self._states[task_id] = target.value
        self._save()

        console.print(f"[green]\u2713[/green] Task {task_id}: {current.value} \u2192 {target.value}")

    def require_state(self, task_id: str, required: TaskState) -> None:
        """Verify task is in required state. Raises typer.Exit if not."""
        current = self.get_state(task_id)
        if current == required:
            return

        console.print(
            f"[red]\u274c BLOCKED:[/red] Task {task_id} must be in state "
            f"'{required.value}' but is in '{current.value}'"
        )

        # Show how to get to required state
        valid_next = VALID_TRANSITIONS.get(current, [])
        if valid_next:
            next_state = valid_next[0]
            trigger = TRANSITION_TRIGGERS.get((current, next_state), "unknown command")
            console.print(f"[dim]   \u2192 Next step: {trigger}[/dim]")

        raise typer.Exit(1)

    def reset_task(self, task_id: str) -> None:
        """Reset task to NOT_STARTED state (for re-doing work or fixing state)."""
        current = self.get_state(task_id)

        self._history.append({
            "task_id": task_id,
            "from_state": current.value,
            "to_state": TaskState.NOT_STARTED.value,
            "timestamp": datetime.now(UTC).isoformat() + "Z",
            "trigger": "manual_reset",
        })

        self._states[task_id] = TaskState.NOT_STARTED.value
        self._save()

        console.print(f"[yellow]\u21ba[/yellow] Task {task_id} reset to not_started")

    def get_history(self, task_id: Optional[str] = None, limit: int = 20) -> list[dict]:
        """Get transition history, newest first. Optionally filter by task_id."""
        history = self._history.copy()
        if task_id:
            history = [h for h in history if h["task_id"] == task_id]

        history.reverse()
        return history[:limit]

    def get_all_states(self) -> dict[str, str]:
        """Get all tracked task states as {task_id: state_value}."""
        return self._states.copy()


_state_manager: Optional[TaskStateManager] = None


def get_state_manager() -> TaskStateManager:
    """Get global state manager instance."""
    global _state_manager
    if _state_manager is None:
        _state_manager = TaskStateManager()
    return _state_manager


def reset_state_manager() -> None:
    """Reset global state manager (for testing)."""
    global _state_manager
    _state_manager = None


def is_state_machine_enabled() -> bool:
    """Check if state machine enforcement is enabled in config."""
    from .config import load_raw_config
    from .ops import find_paircoder_dir

    try:
        paircoder_dir = find_paircoder_dir()
        if not paircoder_dir:
            return False
        config, _ = load_raw_config(paircoder_dir.parent)
        if not config:
            return False
        enforcement = config.get("enforcement", {})
        return enforcement.get("state_machine", False)
    except Exception:
        return False


def ensure_task_state(task_id: str, required: TaskState) -> bool:
    """Check task state, but only if state machine is enabled.

    Returns:
        True if state is correct or enforcement disabled
    """
    if not is_state_machine_enabled():
        return True

    manager = get_state_manager()
    current = manager.get_state(task_id)
    return current == required

# Re-exported from task_acceptance.py for backward compatibility
from .task_acceptance import (  # noqa: F401
    verify_ac_from_content,
    verify_local_ac,
    sync_trello_ac_to_local,
    sync_trello_ac_to_local as sync_remote_ac_to_local,
    is_trello_task,
)
