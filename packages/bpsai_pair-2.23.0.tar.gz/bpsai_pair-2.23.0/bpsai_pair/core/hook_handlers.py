"""Delegate map and handler builder for the hook system.

Extracted from hooks.py to keep file sizes under the 200-line warning.
"""

import importlib
import logging
from typing import Callable, Dict

logger = logging.getLogger(__name__)

# Maps private method names to (module_path, function_name, arg_style).
# arg_style: "cfg_pd" = (ctx, config, paircoder_dir),
#             "pd" = (ctx, paircoder_dir), "cfg" = (ctx, config)
DELEGATE_MAP: Dict[str, tuple[str, str, str]] = {
    "_start_timer": ("bpsai_pair.core.hook_metrics", "start_timer", "cfg_pd"),
    "_stop_timer": ("bpsai_pair.core.hook_metrics", "stop_timer", "cfg_pd"),
    "_record_metrics": ("bpsai_pair.core.hook_metrics", "record_metrics", "pd"),
    "_sync_pm": ("bpsai_pair.core.hook_pm", "sync_pm", "cfg"),
    "_update_state": ("bpsai_pair.core.hook_state", "update_state", "pd"),
    "_check_unblocked": ("bpsai_pair.core.hook_state", "check_unblocked", "pd"),
    "_log_trello_activity": ("bpsai_pair.core.hook_trello", "log_trello_activity", "cfg"),
    "_on_plan_created": ("bpsai_pair.pm.project_hooks", "on_plan_created", "cfg"),
    "_on_sprint_planned": ("bpsai_pair.pm.project_hooks", "on_sprint_planned", "cfg"),
    "_on_sprint_completed": ("bpsai_pair.pm.project_hooks", "on_sprint_completed", "cfg"),
    "_on_epic_completed": ("bpsai_pair.pm.project_hooks", "on_epic_completed", "cfg"),
    "_on_story_completed": ("bpsai_pair.pm.project_hooks", "on_story_completed", "cfg"),
    "_record_task_completion": ("bpsai_pair.core.hook_metrics", "record_task_completion", "pd"),
    "_record_velocity": ("bpsai_pair.core.hook_metrics", "record_velocity", "pd"),
    "_record_token_usage": ("bpsai_pair.core.hook_metrics", "record_token_usage", "pd"),
    "_apply_token_learning": ("bpsai_pair.core.hook_metrics", "apply_token_learning", "cfg_pd"),
    "_check_token_budget": ("bpsai_pair.core.hook_budget", "check_token_budget", "cfg_pd"),
    "_enforce_containment": ("bpsai_pair.commands.enforce_containment", "enforce_containment_check", "pd"),
    "_qc_check": ("bpsai_pair.qc.gate", "qc_check_hook", "pd"),
    "_recommend_skills": ("bpsai_pair.intelligence.task_hook", "recommend_on_task_start", "pd"),
}


def build_handlers(runner) -> Dict[str, Callable]:
    """Build handler dict from delegate map.

    Args:
        runner: HookRunner instance with .config and .paircoder_dir attrs.

    Returns:
        Dict mapping hook names (without underscore prefix) to callables.
    """
    handlers: Dict[str, Callable] = {}
    for attr_name, (mod_path, func_name, style) in DELEGATE_MAP.items():
        hook_name = attr_name.lstrip("_")
        mod = importlib.import_module(mod_path)
        fn = getattr(mod, func_name)
        if style == "cfg_pd":
            handlers[hook_name] = (
                lambda ctx, f=fn, r=runner: f(ctx, r.config, r.paircoder_dir)
            )
        elif style == "cfg":
            handlers[hook_name] = (
                lambda ctx, f=fn, r=runner: f(ctx, r.config)
            )
        else:
            handlers[hook_name] = (
                lambda ctx, f=fn, r=runner: f(ctx, r.paircoder_dir)
            )
    return handlers
