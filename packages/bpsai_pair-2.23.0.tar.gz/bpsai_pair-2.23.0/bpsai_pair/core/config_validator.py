"""Configuration validation — re-export shim.

All public names re-exported from submodules for backward compatibility.
"""

from .config_containment import ContainmentConfig, SandboxConfig
from .config_architecture import ArchitectureConfig
from .config_validation import (
    ConfigValidationResult,
    validate_config,
    update_config,
)

__all__ = [
    "ContainmentConfig",
    "SandboxConfig",
    "ArchitectureConfig",
    "ConfigValidationResult",
    "validate_config",
    "update_config",
]
