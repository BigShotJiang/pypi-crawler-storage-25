"""File role detector — classifies Python files by architectural role.

Supports 7 roles: test, cli_entry, api_client, state_machine, config, script, service.
Detection uses path patterns (cheap, first match wins). AST fallback reserved for Phase 2.
"""

from __future__ import annotations

import re
from enum import Enum
from pathlib import Path
from typing import Callable, Optional


class FileRole(str, Enum):
    """Architectural role of a Python file."""

    TEST = "test"
    CLI_ENTRY = "cli_entry"
    API_CLIENT = "api_client"
    STATE_MACHINE = "state_machine"
    CONFIG = "config"
    SCRIPT = "script"
    SERVICE = "service"


# Path-based detection rules, evaluated in order (first match wins).


def _match_test(path: Path) -> bool:
    name = path.name
    return (
        name.startswith("test_")
        or name.endswith("_test.py")
        or name == "conftest.py"
        or "tests" in path.parts
    )


def _match_cli_entry(path: Path) -> bool:
    return path.name in ("cli.py", "__main__.py")


def _match_api_client(path: Path) -> bool:
    return path.name.endswith("_client.py")


def _match_state_machine(path: Path) -> bool:
    name = path.stem
    return bool(re.search(r"_state", name) or re.search(r"_machine", name))


def _match_config(path: Path) -> bool:
    name = path.stem
    return (
        name.startswith("config")
        or name.startswith("settings")
        or name.startswith("constants")
    )


def _match_script(path: Path) -> bool:
    return "scripts" in path.parts


_RULES: list[tuple[FileRole, Callable[[Path], bool]]] = [
    (FileRole.TEST, _match_test),
    (FileRole.CLI_ENTRY, _match_cli_entry),
    (FileRole.API_CLIENT, _match_api_client),
    (FileRole.STATE_MACHINE, _match_state_machine),
    (FileRole.CONFIG, _match_config),
    (FileRole.SCRIPT, _match_script),
]


class FileRoleDetector:
    """Classifies Python files into architectural roles."""

    def __init__(
        self,
        role_overrides: Optional[dict[str, str]] = None,
        project_root: Optional[Path] = None,
    ) -> None:
        self._overrides = role_overrides or {}
        self._project_root = project_root

    def detect(self, path: Path) -> FileRole:
        """Classify a file by its architectural role.

        Resolution order:
        1. Manual override from config (role_overrides)
        2. Path-based rules (cheap, no file read)
        3. Default: FileRole.SERVICE
        """
        # Check overrides: try relative path first, then bare filename
        for key in self._override_keys(path):
            if key in self._overrides:
                return FileRole(self._overrides[key])

        for role, matcher in _RULES:
            if matcher(path):
                return role

        return FileRole.SERVICE

    def detect_batch(self, paths: list[Path]) -> dict[Path, FileRole]:
        """Classify multiple files."""
        return {p: self.detect(p) for p in paths}

    def _override_keys(self, path: Path) -> list[str]:
        """Get candidate keys for role_overrides lookup (most specific first)."""
        keys = []
        if self._project_root and path.is_absolute():
            try:
                keys.append(str(path.relative_to(self._project_root)))
            except ValueError:
                pass
        keys.append(str(path))
        keys.append(path.name)
        return keys
