"""UserPromptSubmit pre-task budget heuristic.

Warning-only hook that estimates whether remaining session budget
can handle the task's complexity. Uses calibration data for
tokens-per-complexity estimates. Never blocks execution.

HK1.6: Provides early warning before sprints get killed mid-execution.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

from bpsai_pair.core.hook_types import HookContext

logger = logging.getLogger(__name__)

# Default session budget (tokens). Configurable via session_budget param.
DEFAULT_SESSION_BUDGET = 200_000

# Default complexity when neither ctx nor task file provides one.
DEFAULT_COMPLEXITY = 5

# Tokens per complexity unit when no calibration data exists.
DEFAULT_TOKENS_PER_CX = 5_000

# Max records to query from telemetry store.
_QUERY_LIMIT = 10_000


def budget_heuristic(
    ctx: HookContext,
    *,
    project_root: Path | None = None,
    session_budget: int = DEFAULT_SESSION_BUDGET,
) -> dict[str, Any]:
    """Estimate whether session budget can handle the next task.

    Returns a dict with warning status and budget details.
    Never sets blocked=True — this is advisory only.
    """
    try:
        root = project_root or Path(".")
        consumed, complexity, estimated_task = _gather_budget_inputs(
            ctx, root,
        )
        remaining = session_budget - consumed
        return _build_result(
            ctx, remaining, session_budget, consumed,
            complexity, estimated_task,
        )
    except Exception as e:
        logger.warning("Budget heuristic failed: %s", e)
        return {"warning": False, "blocked": False, "error": str(e)}


def _gather_budget_inputs(
    ctx: HookContext, root: Path,
) -> tuple[int, int, int]:
    """Collect session consumption, task complexity, and token estimate."""
    session_id = (ctx.extra or {}).get("session_id")
    consumed = (
        _get_session_tokens_consumed(_get_store(root), session_id)
        if session_id else 0
    )
    complexity = _resolve_task_complexity(ctx, root)
    task_type = (ctx.extra or {}).get("task_type", "feature")
    estimated_task = _estimate_task_tokens(root, complexity, task_type)
    return consumed, complexity, estimated_task


def _build_result(
    ctx: HookContext,
    remaining: int, session_budget: int, consumed: int,
    complexity: int, estimated_task: int,
) -> dict[str, Any]:
    """Build the heuristic result dict with optional warning."""
    needs_warning = remaining < estimated_task
    result: dict[str, Any] = {
        "warning": needs_warning,
        "blocked": False,
        "estimated_remaining": remaining,
        "session_consumed": consumed,
        "session_budget": session_budget,
        "task_complexity": complexity,
        "estimated_task_tokens": estimated_task,
    }
    if needs_warning:
        result["suggestion"] = (
            f"Estimated {estimated_task:,} tokens needed but only "
            f"{remaining:,} remaining. Consider splitting the task "
            f"into smaller subtasks."
        )
        logger.warning(
            "Budget heuristic: task %s (cx=%d) needs ~%d tokens, "
            "only %d remaining in session",
            ctx.task_id, complexity, estimated_task, remaining,
        )
    return result


def _get_session_tokens_consumed(store: Any, session_id: str) -> int:
    """Sum tokens consumed in the current session from telemetry."""
    records = store.query(session_id=session_id, limit=_QUERY_LIMIT)
    return sum(r.tokens.total for r in records)


def _resolve_task_complexity(ctx: HookContext, project_root: Path) -> int:
    """Get task complexity from ctx.extra, task file, or default.

    Result is always clamped to 1-50.
    """
    cx = (ctx.extra or {}).get("complexity")
    if cx is not None:
        return max(1, min(50, int(cx)))

    task_file = _find_task_file(ctx.task_id, project_root)
    if task_file is not None:
        cx = _read_complexity_from_file(task_file)
        if cx is not None:
            return max(1, min(50, cx))

    return DEFAULT_COMPLEXITY


try:
    from bpsai_pair.feedback.calibration import CalibrationEngine as _CalibrationEngine
except Exception:
    _CalibrationEngine = None  # type: ignore[assignment,misc]


def _estimate_task_tokens(
    project_root: Path, complexity: int, task_type: str,
) -> int:
    """Estimate tokens needed using calibration data or defaults."""
    try:
        if _CalibrationEngine is None:
            raise ImportError("CalibrationEngine not available")
        engine = _CalibrationEngine(project_root)
        estimate = engine.estimate_tokens(task_type)
        avg = estimate.get("avg", DEFAULT_TOKENS_PER_CX * DEFAULT_COMPLEXITY)
        # Scale by complexity relative to a median-complexity task (cx=5)
        return int(avg * complexity / DEFAULT_COMPLEXITY)
    except Exception:
        return complexity * DEFAULT_TOKENS_PER_CX


def _get_store(project_root: Path) -> Any:
    """Get TelemetryStore instance."""
    from bpsai_pair.telemetry.store import TelemetryStore

    return TelemetryStore(project_root)


def _find_task_file(task_id: str, project_root: Path) -> Path | None:
    """Find the task file for a given task ID.

    Rejects task IDs containing path traversal characters (``/``, ``\\``,
    ``..``) and verifies the resolved path stays within the tasks directory.
    """
    if "/" in task_id or "\\" in task_id or ".." in task_id:
        logger.debug("Rejected task ID with traversal chars: %s", task_id)
        return None
    tasks_dir = project_root / ".paircoder" / "tasks"
    for pattern in [f"{task_id}.task.md", f"TASK-{task_id}.task.md"]:
        path = tasks_dir / pattern
        if path.exists() and path.resolve().is_relative_to(tasks_dir.resolve()):
            return path
    return None


def _read_complexity_from_file(task_file: Path) -> int | None:
    """Read complexity from task file YAML frontmatter."""
    try:
        import yaml

        content = task_file.read_text(encoding="utf-8")
        if not content.startswith("---"):
            return None
        parts = content.split("---", 2)
        if len(parts) < 3:
            return None
        frontmatter = yaml.safe_load(parts[1])
        if isinstance(frontmatter, dict):
            cx = frontmatter.get("complexity")
            return int(cx) if cx is not None else None
    except Exception:
        return None
    return None
