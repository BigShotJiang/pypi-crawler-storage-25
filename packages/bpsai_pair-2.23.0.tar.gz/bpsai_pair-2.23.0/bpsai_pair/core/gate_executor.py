"""Fail-closed gate hook executor.

Wraps gate hook execution with fail-closed semantics: any gate hook
that fails, times out, or returns malformed results defaults to
blocking (blocked=True). Implements A7 spec decisions D2-D9.
"""

from __future__ import annotations

import logging
import traceback
from concurrent.futures import ThreadPoolExecutor, TimeoutError
from typing import Any, Callable

from bpsai_pair.core.hook_types import HookContext, HookResult

logger = logging.getLogger(__name__)

_DEFAULT_TIMEOUT_S = 30.0


class GateHookExecutor:
    """Executes gate hooks with fail-closed guarantees.

    Any failure (exception, timeout, malformed return, unknown hook)
    produces blocked=True. Only KeyboardInterrupt and SystemExit
    are re-raised.
    """

    def __init__(
        self,
        timeout_s: float = _DEFAULT_TIMEOUT_S,
        signal_emitter: Any | None = None,
    ) -> None:
        self._timeout_s = timeout_s
        self._emitter = signal_emitter

    def execute(
        self,
        hook_name: str,
        handler: Callable[[HookContext], dict[str, Any]] | None,
        context: HookContext,
        timeout_s: float | None = None,
    ) -> HookResult:
        """Execute a gate hook with fail-closed guarantees."""
        if handler is None:
            return self._handle_unknown(hook_name, context)

        timeout = timeout_s if timeout_s is not None else self._timeout_s
        try:
            result = self._run_with_timeout(handler, context, timeout)
        except (KeyboardInterrupt, SystemExit):
            raise
        except TimeoutError:
            return self._handle_timeout(hook_name, timeout, context)
        except Exception as exc:
            return self._handle_exception(hook_name, exc, context)

        valid, reason = self.validate_result(result)
        if not valid:
            return self._handle_malformed(hook_name, reason, context)

        return HookResult(
            hook=hook_name,
            success=True,
            result=result,
            blocked=result["blocked"],
        )

    def validate_result(self, result: Any) -> tuple[bool, str]:
        """Check if a gate hook result is well-formed."""
        if not isinstance(result, dict):
            type_name = type(result).__name__
            return False, f"expected dict, got {type_name}"
        if "blocked" not in result:
            return False, "missing 'blocked' key"
        if not isinstance(result["blocked"], bool):
            return False, "'blocked' must be bool"
        return True, ""

    def _run_with_timeout(
        self,
        handler: Callable[[HookContext], dict[str, Any]],
        context: HookContext,
        timeout: float,
    ) -> dict[str, Any]:
        """Run handler in a thread with timeout."""
        pool = ThreadPoolExecutor(max_workers=1)
        future = pool.submit(handler, context)
        try:
            return future.result(timeout=timeout)
        finally:
            pool.shutdown(wait=False, cancel_futures=True)

    def _handle_unknown(
        self, hook_name: str, context: HookContext,
    ) -> HookResult:
        """Handle unknown (None) gate hook handler."""
        error_msg = f"Unknown gate hook: {hook_name}"
        self._emit_fail_closed(
            hook_name, "unknown_hook", error_msg, None, context,
        )
        return self._build_fail_closed_result(hook_name, "unknown_hook", error_msg)

    def _handle_timeout(
        self, hook_name: str, timeout: float, context: HookContext,
    ) -> HookResult:
        """Handle gate hook timeout."""
        error_msg = f"Timeout after {timeout}s"
        self._emit_fail_closed(
            hook_name, "timeout", error_msg, None, context,
        )
        return self._build_fail_closed_result(hook_name, "timeout", error_msg)

    def _handle_exception(
        self, hook_name: str, exc: Exception, context: HookContext,
    ) -> HookResult:
        """Handle gate hook exception."""
        error_msg = f"{type(exc).__name__}: {exc}"
        tb_str = traceback.format_exc()
        self._emit_fail_closed(
            hook_name, "exception", error_msg, tb_str, context,
        )
        return self._build_fail_closed_result(hook_name, "exception", error_msg)

    def _handle_malformed(
        self, hook_name: str, reason: str, context: HookContext,
    ) -> HookResult:
        """Handle malformed gate hook return value."""
        error_msg = f"Malformed return: {reason}"
        self._emit_fail_closed(
            hook_name, "malformed_return", error_msg, None, context,
        )
        return self._build_fail_closed_result(hook_name, "malformed_return", error_msg)

    def _emit_fail_closed(
        self,
        hook_name: str,
        failure_type: str,
        error_message: str,
        traceback_str: str | None,
        context: HookContext,
    ) -> None:
        """Emit gate_failed_closed signal if emitter is available."""
        if self._emitter is None:
            return
        try:
            self._emitter.emit_gate_failed_closed(
                gate_name=hook_name,
                failure_type=failure_type,
                error_message=error_message,
                traceback_str=traceback_str,
                task_id=context.task_id,
            )
        except Exception:
            logger.debug("Failed to emit gate_failed_closed signal", exc_info=True)

    def _build_fail_closed_result(
        self, hook_name: str, reason: str, error_msg: str,
    ) -> HookResult:
        """Build a fail-closed HookResult."""
        return HookResult(
            hook=hook_name,
            success=False,
            blocked=True,
            error=error_msg,
            result={"fail_closed": True, "reason": reason},
        )
