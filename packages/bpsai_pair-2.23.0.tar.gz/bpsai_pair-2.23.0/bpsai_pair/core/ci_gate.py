"""CI verification gate for task completion.

Non-blocking gate that checks CI status on the PR for the current branch
before allowing task completion. Repos without a PR or CI are handled
gracefully with warnings.
"""

from __future__ import annotations

import logging
import subprocess
from pathlib import Path
from typing import Any

from bpsai_pair.core.hooks import HookContext

logger = logging.getLogger(__name__)


def ci_verification_gate(
    ctx: HookContext,
    *,
    project_root: Path | None = None,
) -> dict[str, Any]:
    """Check CI status on the PR for the current branch.

    Non-blocking gate: warns when CI is failing or pending but does not
    block task completion. Repos without a PR or CI are skipped gracefully.
    """
    root = project_root or _find_project_root()
    if root is None:
        return {"blocked": False, "reason": "Skipped: no project root"}

    pr_number = _find_pr_for_branch(root)
    if pr_number is None:
        return {"blocked": False, "reason": "Skipped: no PR found for current branch"}

    ci_status = _get_ci_status(root, pr_number)
    if ci_status is None:
        return {"blocked": False, "reason": "No CI checks configured", "pr": pr_number}

    result: dict[str, Any] = {
        "blocked": False,
        "pr": pr_number,
        "ci_status": ci_status,
    }
    if ci_status != "success":
        result["warning"] = True
        logger.warning(
            "CI gate warning for task %s: CI status is '%s' on PR #%s",
            ctx.task_id, ci_status, pr_number,
        )
    return result


def _find_pr_for_branch(project_root: Path) -> str | None:
    """Find the PR number for the current branch using gh CLI."""
    try:
        result = subprocess.run(
            ["gh", "pr", "view", "--json", "number", "-q", ".number"],
            cwd=str(project_root),
            capture_output=True, text=True, timeout=15,
        )
    except (subprocess.TimeoutExpired, FileNotFoundError):
        return None
    if result.returncode != 0:
        return None
    pr = result.stdout.strip()
    return pr if pr else None


def _get_ci_status(project_root: Path, pr_number: str) -> str | None:
    """Get the aggregated CI status for a PR using gh CLI.

    Returns "success" only if ALL checks pass. Returns "failure" if any
    check failed. Returns "pending" if any check is pending (and none failed).
    """
    try:
        result = subprocess.run(
            ["gh", "pr", "checks", pr_number, "--json", "state", "-q", ".[].state"],
            cwd=str(project_root),
            capture_output=True, text=True, timeout=15,
        )
    except (subprocess.TimeoutExpired, FileNotFoundError):
        return None
    if result.returncode != 0:
        return None
    raw = result.stdout.strip()
    if not raw:
        return None
    states = {line.strip().lower() for line in raw.splitlines() if line.strip()}
    if not states:
        return None
    return _aggregate_check_states(states)


def _aggregate_check_states(states: set[str]) -> str:
    """Aggregate multiple CI check states into a single status."""
    if "failure" in states:
        return "failure"
    if "pending" in states:
        return "pending"
    if states == {"success"}:
        return "success"
    # Unknown states treated as pending
    return "pending"


def _find_project_root() -> Path | None:
    """Find the project root by searching for .paircoder directory."""
    cwd = Path.cwd()
    for parent in [cwd, *cwd.parents]:
        if (parent / ".paircoder").is_dir():
            return parent
    return None
