"""Online license validation against the API.

This module handles calling the API for license validation,
caching results, and managing offline grace periods.
"""

import json
import logging
import os
import urllib.error
import urllib.request
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Optional
from uuid import UUID

from .machine import get_machine_id
from .snapshot_bridge import _build_snapshot_safe, _get_project_root

logger = logging.getLogger(__name__)

# Module-level error state for callers to inspect after a failed call.
# Set to {"status": int|None, "body": str} on failure, None on success.
last_error: Optional[dict] = None

# Default API URL for license operations
# Can be overridden with PAIRCODER_API_URL environment variable
DEFAULT_API_URL = os.environ.get("PAIRCODER_API_URL", "https://api.paircoder.ai")

# Default timeout for API requests (seconds)
DEFAULT_TIMEOUT = 5

# Offline grace period (days) - how long cached validation is valid
OFFLINE_GRACE_DAYS = 7

# CLI version for API requests
try:
    from bpsai_pair import __version__ as CLI_VERSION
except ImportError:
    CLI_VERSION = "unknown"


class NetworkError(Exception):
    """Raised when API is unreachable."""

    pass


class LicenseNotFoundError(Exception):
    """Raised when license is not found on API."""

    pass


class OfflineValidationExpired(Exception):
    """Raised when offline grace period has expired."""

    def __init__(self, last_validated: datetime, grace_days: int = OFFLINE_GRACE_DAYS):
        self.last_validated = last_validated
        self.grace_days = grace_days
        days_ago = (datetime.now(timezone.utc) - last_validated).days
        super().__init__(
            f"Offline validation expired. Last validated {days_ago} days ago "
            f"(grace period: {grace_days} days). Please connect to the internet "
            f"to revalidate your license."
        )


class LicenseRevoked(Exception):
    """Raised when license has been revoked."""

    def __init__(self, reason: str | None = None, revoked_at: datetime | None = None):
        self.reason = reason
        self.revoked_at = revoked_at
        msg = "License has been revoked"
        if reason:
            msg += f": {reason}"
        super().__init__(msg)


def _parse_iso_datetime(value: str | None) -> datetime | None:
    """Parse ISO datetime string, handling Z suffix."""
    if not value:
        return None
    try:
        return datetime.fromisoformat(value.replace("Z", "+00:00"))
    except (ValueError, AttributeError):
        return None


@dataclass
class ValidationResult:
    """Result of license validation."""

    valid: bool
    revoked: bool
    revoked_at: datetime | None = None
    revoked_reason: str | None = None
    expires_at: datetime | None = None
    machine_activated: bool = False
    machines_used: int = 0
    machines_allowed: int | None = None
    tier: str | None = None
    message: str | None = None
    from_cache: bool = False

    @classmethod
    def from_api_response(
        cls, response: dict[str, Any], from_cache: bool = False
    ) -> "ValidationResult":
        """Create ValidationResult from API response dict."""
        return cls(
            valid=response.get("valid", False),
            revoked=response.get("revoked", False),
            revoked_at=_parse_iso_datetime(response.get("revoked_at")),
            revoked_reason=response.get("revoked_reason"),
            expires_at=_parse_iso_datetime(response.get("expires_at")),
            machine_activated=response.get("machine_activated", False),
            machines_used=response.get("machines_used", 0),
            machines_allowed=response.get("machines_allowed"),
            tier=response.get("tier"),
            message=response.get("message"),
            from_cache=from_cache,
        )


def _get_paircoder_dir() -> Path:
    """Get the .paircoder directory path."""
    return Path.home() / ".paircoder"


def is_online_validation_enabled() -> bool:
    """Check if online validation is enabled.

    Checks PAIRCODER_OFFLINE environment variable.
    Returns False if PAIRCODER_OFFLINE=1 (offline mode).
    Returns True otherwise (default: online validation enabled).
    """
    offline_env = os.environ.get("PAIRCODER_OFFLINE", "0")
    return offline_env != "1"


def _build_validation_request(
    license_id: UUID, api_url: str
) -> urllib.request.Request:
    """Build the HTTP request for validation, including usage snapshot."""
    machine_id = get_machine_id()
    url = f"{api_url.rstrip('/')}/licenses/validate"
    data: dict[str, Any] = {
        "license_id": str(license_id),
        "machine_id": machine_id,
        "cli_version": CLI_VERSION,
    }

    snapshot = _build_snapshot_safe()
    if snapshot is not None:
        # Cap snapshot size to avoid oversized HTTP payloads
        snapshot_json = json.dumps(snapshot)
        if len(snapshot_json.encode("utf-8")) <= 512_000:  # 500KB
            data["usage_snapshot"] = snapshot
        else:
            logger.warning("Usage snapshot exceeds 500KB, omitting from validation")


    return urllib.request.Request(
        url,
        data=json.dumps(data).encode("utf-8"),
        headers={"Content-Type": "application/json"},
        method="POST",
    )


def validate_license_online(
    license_id: UUID,
    api_url: str = DEFAULT_API_URL,
    timeout: int = DEFAULT_TIMEOUT,
) -> ValidationResult:
    """Validate a license against the API.

    Args:
        license_id: The license UUID to validate.
        api_url: Base URL of the API.
        timeout: Request timeout in seconds.

    Returns:
        ValidationResult with license status.

    Raises:
        NetworkError: If API is unreachable.
        LicenseNotFoundError: If license is not found.
    """
    global last_error
    request = _build_validation_request(license_id, api_url)

    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            response_data = json.loads(response.read().decode("utf-8"))
            last_error = None
            return ValidationResult.from_api_response(response_data)
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", errors="replace")[:200] if e.fp else ""
        last_error = {"status": e.code, "body": body}
        logger.warning("License validation failed (HTTP %d): %s", e.code, body)
        if e.code == 404:
            raise LicenseNotFoundError(f"License not found: {license_id}") from e
        raise NetworkError(f"API error: {e.code} {e.reason}") from e
    except urllib.error.URLError as e:
        last_error = {"status": None, "body": str(e)}
        logger.warning("License validation request failed: %s", e)
        raise NetworkError(f"Cannot reach API: {e}") from e
    except json.JSONDecodeError as e:
        last_error = {"status": None, "body": str(e)}
        raise NetworkError(f"Invalid API response: {e}") from e


def save_validation_cache(license_id: UUID, api_response: dict[str, Any]) -> None:
    """Save validation result to cache file with secure permissions."""
    from .security import set_cache_file_permissions

    paircoder_dir = _get_paircoder_dir()
    paircoder_dir.mkdir(parents=True, exist_ok=True)

    cache_file = paircoder_dir / "license_cache.json"
    cache_data = {
        "license_id": str(license_id),
        "last_validated_at": datetime.now(timezone.utc).isoformat(),
        "api_response": api_response,
    }
    cache_file.write_text(json.dumps(cache_data, indent=2), encoding="utf-8")
    set_cache_file_permissions(cache_file)


def load_validation_cache(license_id: UUID) -> dict[str, Any] | None:
    """Load validation result from cache file."""
    cache_file = _get_paircoder_dir() / "license_cache.json"

    if not cache_file.exists():
        return None

    try:
        data = json.loads(cache_file.read_text(encoding="utf-8"))
        if data.get("license_id") != str(license_id):
            return None
        return data
    except (json.JSONDecodeError, OSError):
        return None


def is_cache_valid(license_id: UUID, grace_days: int = OFFLINE_GRACE_DAYS) -> bool:
    """Check if cached validation is still within grace period."""
    cache = load_validation_cache(license_id)
    if cache is None:
        return False

    try:
        last_validated = datetime.fromisoformat(cache["last_validated_at"])
        grace_end = last_validated + timedelta(days=grace_days)
        return datetime.now(timezone.utc) < grace_end
    except (KeyError, ValueError):
        return False


def _result_to_cache_dict(result: ValidationResult) -> dict[str, Any]:
    """Convert ValidationResult to cacheable dict."""
    return {
        "valid": result.valid,
        "revoked": result.revoked,
        "revoked_at": result.revoked_at.isoformat() if result.revoked_at else None,
        "revoked_reason": result.revoked_reason,
        "expires_at": result.expires_at.isoformat() if result.expires_at else None,
        "machine_activated": result.machine_activated,
        "machines_used": result.machines_used,
        "machines_allowed": result.machines_allowed,
        "tier": result.tier,
        "message": result.message,
    }


def _get_cached_result(
    license_id: UUID, grace_days: int
) -> ValidationResult:
    """Get cached validation result or raise appropriate error."""
    cache = load_validation_cache(license_id)

    if cache is None:
        raise NetworkError(
            "Cannot reach API and no cached validation exists. "
            "Please connect to the internet to validate your license."
        )

    try:
        last_validated = datetime.fromisoformat(cache["last_validated_at"])
    except (KeyError, ValueError):
        raise NetworkError(
            "Cannot reach API and cached validation is invalid. "
            "Please connect to the internet to validate your license."
        )

    # Check for revoked license - no grace period for revoked licenses
    api_response = cache.get("api_response", {})
    if api_response.get("revoked", False):
        revoked_at = _parse_iso_datetime(api_response.get("revoked_at"))
        reason = api_response.get("revoked_reason")
        raise LicenseRevoked(reason, revoked_at)

    grace_end = last_validated + timedelta(days=grace_days)
    if datetime.now(timezone.utc) >= grace_end:
        raise OfflineValidationExpired(last_validated, grace_days)

    logger.info(
        f"Using cached validation from {last_validated.date()} "
        f"(offline mode, {grace_days} day grace period)"
    )
    return ValidationResult.from_api_response(cache["api_response"], from_cache=True)


def validate_with_fallback(
    license_id: UUID,
    api_url: str = DEFAULT_API_URL,
    timeout: int = DEFAULT_TIMEOUT,
    grace_days: int = OFFLINE_GRACE_DAYS,
) -> ValidationResult:
    """Validate license with offline fallback.

    Attempts online validation first. If API is unreachable, falls back
    to cached validation if within grace period.

    Args:
        license_id: The license UUID to validate.
        api_url: Base URL of the API.
        timeout: Request timeout in seconds.
        grace_days: Number of days cached validation is valid.

    Returns:
        ValidationResult with license status.

    Raises:
        OfflineValidationExpired: If offline and cache is beyond grace period.
        LicenseNotFoundError: If license is not found on API.
        NetworkError: If offline and no valid cache exists.
    """
    try:
        result = validate_license_online(license_id, api_url, timeout)
        save_validation_cache(license_id, _result_to_cache_dict(result))
        return result
    except NetworkError:
        logger.warning("Using cached license data -- API unreachable")
        return _get_cached_result(license_id, grace_days)
