"""File-based validation cache for cross-process license checks.

Each CLI invocation is a separate process, so the session-level cache
in startup.py doesn't survive between commands. This module provides a
file-based cache at .paircoder/telemetry/.validation_cache that persists
across invocations with a configurable TTL (default: 1 hour).

This fixes the P0 bug where validation fires on EVERY CLI command,
generating ~7,000 API calls/day from 8 subscribers.
"""

import json
import logging
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

# Default cache time-to-live: 1 hour
DEFAULT_CACHE_TTL_SECONDS = 3600

CACHE_FILENAME = ".validation_cache"

_REQUIRED_FIELDS = {"valid", "timestamp", "expires_at"}


def write_validation_cache(
    cache_dir: Path, *, valid: bool, ttl_seconds: int = DEFAULT_CACHE_TTL_SECONDS
) -> None:
    """Write a validation result to the file-based cache.

    Args:
        cache_dir: Directory to store the cache file (e.g. .paircoder/telemetry/).
        valid: Whether the license validated successfully.
        ttl_seconds: How long the cache entry is valid, in seconds.
    """
    now = datetime.now(timezone.utc)
    expires = now + timedelta(seconds=ttl_seconds)

    data = {
        "valid": valid,
        "timestamp": now.isoformat(),
        "expires_at": expires.isoformat(),
    }

    cache_file = cache_dir / CACHE_FILENAME
    try:
        cache_dir.mkdir(parents=True, exist_ok=True)
        cache_file.write_text(json.dumps(data), encoding="utf-8")
    except OSError as e:
        logger.debug("Failed to write validation cache: %s", e)


def read_validation_cache(cache_dir: Path) -> dict[str, Any] | None:
    """Read and validate the file-based cache.

    Returns:
        Cache data dict if valid and not expired, None otherwise.
    """
    cache_file = cache_dir / CACHE_FILENAME
    if not cache_file.exists():
        return None

    try:
        data = json.loads(cache_file.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return None

    # Validate required fields
    if not _REQUIRED_FIELDS.issubset(data.keys()):
        return None

    # Check expiry
    try:
        expires_at = datetime.fromisoformat(data["expires_at"])
        if datetime.now(timezone.utc) >= expires_at:
            return None
    except (ValueError, TypeError):
        return None

    return data


def invalidate_validation_cache(cache_dir: Path) -> None:
    """Remove the validation cache file.

    Args:
        cache_dir: Directory containing the cache file.
    """
    cache_file = cache_dir / CACHE_FILENAME
    try:
        cache_file.unlink(missing_ok=True)
    except OSError as e:
        logger.debug("Failed to remove validation cache: %s", e)
