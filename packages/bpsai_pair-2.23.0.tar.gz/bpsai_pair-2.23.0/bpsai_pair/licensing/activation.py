"""Machine activation API client.

This module provides functions for machine activation operations:
- activate_machine: Activate current machine on a license
- deactivate_machine: Deactivate a machine from a license
- list_machines: List all activated machines for a license
"""

import json
import logging
import urllib.error
import urllib.request
from dataclasses import dataclass
from datetime import datetime
from typing import Optional
from uuid import UUID

from .online import DEFAULT_API_URL, DEFAULT_TIMEOUT

logger = logging.getLogger(__name__)

# Module-level error state for callers to inspect after a failed call.
# Set to {"status": int|None, "body": str} on failure, None on success.
last_error: Optional[dict] = None


class ActivationError(Exception):
    """Raised when activation/deactivation fails."""

    pass


@dataclass
class ActivationResult:
    """Result of machine activation."""

    success: bool
    machine_id: str
    machine_name: Optional[str]
    activated_at: Optional[str]
    machines_used: int
    machines_allowed: int
    message: Optional[str] = None

    @classmethod
    def from_api_response(cls, response: dict) -> "ActivationResult":
        """Create ActivationResult from API response."""
        return cls(
            success=response.get("success", False),
            machine_id=response.get("machine_id", ""),
            machine_name=response.get("machine_name"),
            activated_at=response.get("activated_at"),
            machines_used=response.get("machines_used", 0),
            machines_allowed=response.get("machines_allowed", 0),
            message=response.get("message"),
        )


@dataclass
class DeactivationResult:
    """Result of machine deactivation."""

    success: bool
    machine_id: str
    deactivated_at: Optional[str]
    machines_used: int
    machines_allowed: int
    message: Optional[str] = None

    @classmethod
    def from_api_response(cls, response: dict) -> "DeactivationResult":
        """Create DeactivationResult from API response."""
        return cls(
            success=response.get("success", False),
            machine_id=response.get("machine_id", ""),
            deactivated_at=response.get("deactivated_at"),
            machines_used=response.get("machines_used", 0),
            machines_allowed=response.get("machines_allowed", 0),
            message=response.get("message"),
        )


@dataclass
class MachineInfo:
    """Information about an activated machine."""

    machine_id: str
    machine_name: Optional[str]
    activated_at: str


@dataclass
class MachinesListResult:
    """Result of listing activated machines."""

    machines: list[MachineInfo]
    machines_used: int
    machines_allowed: int


def _build_activate_url(license_id: UUID, api_url: str = DEFAULT_API_URL) -> str:
    """Build the activation endpoint URL."""
    return f"{api_url.rstrip('/')}/licenses/{license_id}/activate"


def _build_deactivate_url(license_id: UUID, api_url: str = DEFAULT_API_URL) -> str:
    """Build the deactivation endpoint URL."""
    return f"{api_url.rstrip('/')}/licenses/{license_id}/deactivate"


def _build_machines_url(license_id: UUID, api_url: str = DEFAULT_API_URL) -> str:
    """Build the machines list endpoint URL."""
    return f"{api_url.rstrip('/')}/licenses/{license_id}/machines"


def _make_request(
    url: str,
    data: Optional[dict] = None,
    method: str = "POST",
    license_key: Optional[str] = None,
) -> dict:
    """Make HTTP request and return JSON response."""
    headers = {"Content-Type": "application/json"}
    if license_key:
        headers["X-License-Key"] = license_key
    body = json.dumps(data).encode() if data else None

    request = urllib.request.Request(url, data=body, headers=headers, method=method)

    with urllib.request.urlopen(request, timeout=DEFAULT_TIMEOUT) as response:
        return json.loads(response.read().decode())


def activate_machine(
    license_id: UUID,
    machine_id: str,
    machine_name: Optional[str] = None,
    api_url: str = DEFAULT_API_URL,
) -> ActivationResult:
    """Activate a machine on a license.

    Args:
        license_id: The license UUID.
        machine_id: The machine identifier to activate.
        machine_name: Optional friendly name for the machine.
        api_url: API base URL.

    Returns:
        ActivationResult with activation details.

    Raises:
        ActivationError: If activation fails.
    """
    url = _build_activate_url(license_id, api_url)
    data = {"machine_id": machine_id}
    if machine_name:
        data["machine_name"] = machine_name

    global last_error
    try:
        response = _make_request(url, data, license_key=str(license_id))
        last_error = None
        return ActivationResult.from_api_response(response)
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", errors="replace")[:200] if e.fp else ""
        last_error = {"status": e.code, "body": body}
        logger.warning("Activation failed (HTTP %d): %s", e.code, body)
        if e.code == 403:
            raise ActivationError("No activation slots available") from e
        elif e.code == 404:
            raise ActivationError("License not found") from e
        else:
            raise ActivationError(f"Server error: {e.code} {e.reason}") from e
    except urllib.error.URLError as e:
        last_error = {"status": None, "body": str(e.reason)}
        logger.warning("Activation request failed: %s", e.reason)
        raise ActivationError(f"Cannot reach API: {e.reason}") from e
    except json.JSONDecodeError as e:
        last_error = {"status": None, "body": str(e)}
        raise ActivationError("Invalid response from API") from e


def deactivate_machine(
    license_id: UUID,
    machine_id: str,
    api_url: str = DEFAULT_API_URL,
) -> DeactivationResult:
    """Deactivate a machine from a license.

    Args:
        license_id: The license UUID.
        machine_id: The machine identifier to deactivate.
        api_url: API base URL.

    Returns:
        DeactivationResult with deactivation details.

    Raises:
        ActivationError: If deactivation fails.
    """
    url = _build_deactivate_url(license_id, api_url)
    data = {"machine_id": machine_id}

    global last_error
    try:
        response = _make_request(url, data, license_key=str(license_id))
        last_error = None
        return DeactivationResult.from_api_response(response)
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", errors="replace")[:200] if e.fp else ""
        last_error = {"status": e.code, "body": body}
        logger.warning("Deactivation failed (HTTP %d): %s", e.code, body)
        if e.code == 400:
            raise ActivationError("Machine not activated on this license") from e
        elif e.code == 404:
            raise ActivationError("License not found") from e
        else:
            raise ActivationError(f"Server error: {e.code} {e.reason}") from e
    except urllib.error.URLError as e:
        last_error = {"status": None, "body": str(e.reason)}
        logger.warning("Deactivation request failed: %s", e.reason)
        raise ActivationError(f"Cannot reach API: {e.reason}") from e
    except json.JSONDecodeError as e:
        last_error = {"status": None, "body": str(e)}
        raise ActivationError("Invalid response from API") from e


def list_machines(
    license_id: UUID,
    api_url: str = DEFAULT_API_URL,
) -> MachinesListResult:
    """List all activated machines for a license.

    Args:
        license_id: The license UUID.
        api_url: API base URL.

    Returns:
        MachinesListResult with list of activated machines.

    Raises:
        ActivationError: If the request fails.
    """
    url = _build_machines_url(license_id, api_url)

    global last_error
    try:
        # Build GET request with license key auth
        request = urllib.request.Request(url, method="GET")
        request.add_header("X-License-Key", str(license_id))
        with urllib.request.urlopen(request, timeout=DEFAULT_TIMEOUT) as response:
            data = json.loads(response.read().decode())

        last_error = None
        machines = [
            MachineInfo(
                machine_id=m["machine_id"],
                machine_name=m.get("machine_name"),
                activated_at=m["activated_at"],
            )
            for m in data.get("machines", [])
        ]

        return MachinesListResult(
            machines=machines,
            machines_used=data.get("machines_used", 0),
            machines_allowed=data.get("machines_allowed", 0),
        )
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", errors="replace")[:200] if e.fp else ""
        last_error = {"status": e.code, "body": body}
        logger.warning("List machines failed (HTTP %d): %s", e.code, body)
        if e.code == 404:
            raise ActivationError("License not found") from e
        else:
            raise ActivationError(f"Server error: {e.code} {e.reason}") from e
    except urllib.error.URLError as e:
        last_error = {"status": None, "body": str(e.reason)}
        logger.warning("List machines request failed: %s", e.reason)
        raise ActivationError(f"Cannot reach API: {e.reason}") from e
    except json.JSONDecodeError as e:
        last_error = {"status": None, "body": str(e)}
        raise ActivationError("Invalid response from API") from e
