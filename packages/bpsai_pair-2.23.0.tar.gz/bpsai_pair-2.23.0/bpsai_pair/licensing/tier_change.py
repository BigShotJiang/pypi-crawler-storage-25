"""Tier change detection and license refresh.

This module handles detecting tier changes between the local license
and the API response, and automatically refreshing the license file
when a tier change is detected (upgrade or downgrade).
"""

import json
import logging
import urllib.error
import urllib.request
from dataclasses import dataclass
from pathlib import Path
from typing import Any
from uuid import UUID

from .online import DEFAULT_API_URL, DEFAULT_TIMEOUT
from .schema import get_tier_display_name

logger = logging.getLogger(__name__)

# Tier ranking for comparison (higher = better tier)
TIER_RANKS: dict[str, int] = {
    "solo": 1,
    "pro": 2,
    "enterprise": 3,
}


@dataclass
class TierChangeResult:
    """Result of tier change detection and handling."""

    changed: bool
    previous_tier: str
    new_tier: str
    is_upgrade: bool
    license_updated: bool = False
    error: str | None = None


def _get_tier_rank(tier: str) -> int:
    """Get numeric rank for a tier."""
    return TIER_RANKS.get(tier.lower(), 0)


def detect_tier_change(
    local_tier: str,
    api_tier: str | None,
) -> TierChangeResult | None:
    """Detect if tier has changed between local license and API.

    Args:
        local_tier: The tier from the local license file.
        api_tier: The tier from the API validation response.

    Returns:
        TierChangeResult if tier changed, None if no change or api_tier is None.
    """
    if api_tier is None:
        return None

    if local_tier.lower() == api_tier.lower():
        return None

    local_rank = _get_tier_rank(local_tier)
    api_rank = _get_tier_rank(api_tier)
    is_upgrade = api_rank > local_rank

    return TierChangeResult(
        changed=True,
        previous_tier=local_tier,
        new_tier=api_tier,
        is_upgrade=is_upgrade,
    )


def _build_license_refresh_url(license_id: UUID, api_url: str) -> str:
    """Build the URL for fetching an updated license file."""
    return f"{api_url.rstrip('/')}/licenses/{license_id}/refresh"


def fetch_updated_license(
    license_id: UUID,
    api_url: str = DEFAULT_API_URL,
    timeout: int = DEFAULT_TIMEOUT,
) -> dict[str, Any] | None:
    """Fetch an updated license file from the API.

    Args:
        license_id: The license UUID.
        api_url: Base URL of the API.
        timeout: Request timeout in seconds.

    Returns:
        License file data as dict, or None if fetch failed.
    """
    url = _build_license_refresh_url(license_id, api_url)

    try:
        request = urllib.request.Request(
            url,
            method="GET",
            headers={"Accept": "application/json"},
        )
        with urllib.request.urlopen(request, timeout=timeout) as response:
            data = json.loads(response.read().decode("utf-8"))
            return data.get("license_file")
    except urllib.error.HTTPError as e:
        logger.warning(f"Failed to fetch updated license: HTTP {e.code}")
        return None
    except urllib.error.URLError as e:
        logger.warning(f"Failed to fetch updated license: {e}")
        return None
    except json.JSONDecodeError as e:
        logger.warning(f"Invalid response when fetching license: {e}")
        return None


def save_updated_license(license_data: dict[str, Any], license_path: Path) -> None:
    """Save updated license data to file with secure permissions.

    Args:
        license_data: The license file data to save.
        license_path: Path where to save the license file.
    """
    from .security import set_cache_file_permissions

    license_path.parent.mkdir(parents=True, exist_ok=True)
    license_path.write_text(json.dumps(license_data, indent=2), encoding="utf-8")
    set_cache_file_permissions(license_path)  # 0o600 - owner read/write only


def get_license_file_path() -> Path | None:
    """Get the path to the current license file."""
    from .paths import get_license_paths

    for path in get_license_paths():
        if path.exists():
            return path
    return None


def _get_license_save_path() -> Path:
    """Get the path where to save the updated license."""
    license_path = get_license_file_path()
    if license_path is None:
        license_path = Path.home() / ".paircoder" / "license.json"
    return license_path


def _verify_fetched_license(license_data: dict[str, Any]) -> bool:
    """Verify the signature of a fetched license before saving.

    SECURITY: Prevents saving compromised/MITM'd license data.
    """
    from .core import verify_signature
    from .schema import SignedLicense

    try:
        signed_license = SignedLicense(**license_data)
        return verify_signature(signed_license)
    except Exception as e:
        logger.warning(f"License verification failed: {e}")
        return False


def _fetch_and_save_license(
    license_id: UUID, api_url: str, change: TierChangeResult
) -> None:
    """Fetch updated license, verify signature, and save to disk."""
    updated_license = fetch_updated_license(license_id, api_url)
    if updated_license is None:
        change.license_updated = False
        change.error = "Could not fetch updated license from API"
        return

    # SECURITY: Verify signature before saving to prevent MITM attacks
    if not _verify_fetched_license(updated_license):
        change.license_updated = False
        change.error = "Fetched license failed signature verification"
        logger.error("Refusing to save license with invalid signature")
        return

    license_path = _get_license_save_path()
    try:
        save_updated_license(updated_license, license_path)
        change.license_updated = True
        logger.info(f"Updated license saved to {license_path}")
    except OSError as e:
        change.license_updated = False
        change.error = f"Failed to save license: {e}"
        logger.error(change.error)


def handle_tier_change(
    license_id: UUID,
    local_tier: str,
    api_tier: str | None,
    api_url: str = DEFAULT_API_URL,
) -> TierChangeResult | None:
    """Handle a potential tier change.

    Detects if tier changed, fetches updated license if so, and saves it.

    Args:
        license_id: The license UUID.
        local_tier: The tier from the local license file.
        api_tier: The tier from the API validation response.
        api_url: Base URL of the API.

    Returns:
        TierChangeResult if tier changed, None if no change.
    """
    change = detect_tier_change(local_tier, api_tier)
    if change is None:
        return None

    logger.info(
        f"Tier change detected: {change.previous_tier} -> {change.new_tier} "
        f"({'upgrade' if change.is_upgrade else 'downgrade'})"
    )

    _fetch_and_save_license(license_id, api_url, change)
    return change


def get_tier_change_message(result: TierChangeResult) -> str:
    """Generate a user-friendly message for a tier change.

    Args:
        result: The tier change result.

    Returns:
        Message string for display to user.
    """
    action = "upgraded" if result.is_upgrade else "downgraded"
    new_tier_display = get_tier_display_name(result.new_tier)

    if result.license_updated:
        return f"License {action} to {new_tier_display}. License file updated."
    else:
        return (
            f"License {action} to {new_tier_display}. "
            f"Could not update local license file: {result.error or 'unknown error'}"
        )
