"""Centralized churn-path exclusion set.

Single source of truth for CLI-produced paths that change frequently
but are NOT meaningful task output.  Every engage subsystem that needs
to filter "noise" diffs should reference ``CHURN_EXCLUSIONS`` rather
than maintaining its own list.
"""

from __future__ import annotations

# fmt: off
CHURN_EXCLUSIONS: frozenset[str] = frozenset({
    # Transient resolver / snapshot caches — rebuilt on every CLI invocation
    ".paircoder/cache/**",
    # Telemetry JSONL and session snapshots — append-only operational logs
    ".paircoder/telemetry/**",
    # Feedback calibration weights — auto-updated by the calibration engine
    ".paircoder/feedback/calibration.json",
    # CLI version stamp — written on every `bpsai-pair` invocation
    ".paircoder/.cli_version",
})
# fmt: on
