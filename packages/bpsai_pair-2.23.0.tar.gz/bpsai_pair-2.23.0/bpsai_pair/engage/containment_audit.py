"""Pre-engage containment audit.

Scans backlog task descriptions and acceptance criteria for file path
references, then checks each path against the containment tier
configuration. Emits warnings for readonly or blocked paths so the
operator can adjust permissions or restructure the backlog before
drivers hit silent containment failures.
"""

from __future__ import annotations

import fnmatch
import logging
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

_PATH_RE = re.compile(
    r"(?:^|[\s`\"'(])"
    r"((?:\.?[A-Za-z_][\w.-]*/)+[\w.*-]+"
    r"|\.[A-Za-z_][\w.-]*/[\w.*/-]+"
    r"|\.[A-Za-z_][\w.-]*(?:\.[A-Za-z]+))"
)
_DOTFILE_RE = re.compile(
    r"(?:^|[\s`\"'(])(\.[A-Za-z_][\w]*(?:\.[A-Za-z]+)*)"
)


@dataclass
class ContainmentWarning:
    """A warning about a task targeting a restricted path."""

    task_id: str
    path: str
    tier: str  # "readonly" or "blocked"
    suggested_action: str


def extract_paths_from_text(text: str) -> list[str]:
    """Extract plausible file/directory paths from free-form text."""
    found: list[str] = []
    for m in _PATH_RE.finditer(text):
        candidate = m.group(1).rstrip(".,;:)\"'`")
        if candidate and candidate not in found:
            found.append(candidate)
    for m in _DOTFILE_RE.finditer(text):
        candidate = m.group(1).rstrip(".,;:)\"'`")
        if "/" not in candidate and candidate not in found:
            found.append(candidate)
    return found


def _match_dir(path: str, dirs: list[str]) -> str | None:
    """Return the first matching directory prefix, or None."""
    for d in dirs:
        d_norm = d.replace("\\", "/").rstrip("/")
        if path.startswith(d_norm + "/") or path == d_norm:
            return d
    return None


def _glob_match(name: str, patterns: set[str]) -> bool:
    """Check if name matches any glob pattern in patterns."""
    for pat in patterns:
        if "*" in pat or "?" in pat:
            if fnmatch.fnmatchcase(name, pat):
                return True
    return False


def _check_path(
    task_id: str, path: str,
    readonly_dirs: list[str], readonly_files: set[str],
    blocked_dirs: list[str], blocked_files: set[str],
) -> ContainmentWarning | None:
    """Check a single path against containment tiers."""
    normalized = path.replace("\\", "/").rstrip("/")
    basename = normalized.rsplit("/", 1)[-1] if "/" in normalized else normalized

    if (basename in blocked_files or normalized in blocked_files
            or _glob_match(basename, blocked_files)
            or _glob_match(normalized, blocked_files)):
        return ContainmentWarning(
            task_id, normalized, "blocked",
            f"Remove '{normalized}' from blocked_files, or restructure task",
        )
    bd = _match_dir(normalized, blocked_dirs)
    if bd:
        return ContainmentWarning(
            task_id, normalized, "blocked",
            f"Remove '{bd}' from blocked_directories, or restructure task",
        )
    if (basename in readonly_files or normalized in readonly_files
            or _glob_match(basename, readonly_files)
            or _glob_match(normalized, readonly_files)):
        return ContainmentWarning(
            task_id, normalized, "readonly",
            f"Temporarily remove '{normalized}' from readonly_files",
        )
    rd = _match_dir(normalized, readonly_dirs)
    if rd:
        return ContainmentWarning(
            task_id, normalized, "readonly",
            f"Temporarily remove '{rd}' from readonly_directories",
        )
    return None


def _word_boundary_match(name: str, text: str) -> bool:
    """Check if *name* appears in *text* as a whole word/token.

    Uses word-boundary regex so that e.g. ``.env`` does not match
    ``environment``.
    """
    pattern = r"(?:^|(?<=[\s`\"'(])){}(?=$|[\s`\"'),.:;])".format(
        re.escape(name),
    )
    return bool(re.search(pattern, text, re.MULTILINE))


def _normalize_containment_config(cfg: dict[str, Any]) -> dict[str, Any]:
    """Normalize legacy key names to current names.

    Maps ``locked_directories`` to ``readonly_directories`` and
    ``locked_files`` to ``readonly_files`` when the old keys are present.
    New keys take precedence; legacy values are merged in.
    """
    out = dict(cfg)
    for old, new in (
        ("locked_directories", "readonly_directories"),
        ("locked_files", "readonly_files"),
    ):
        if old in out:
            legacy = out.pop(old)
            existing = out.get(new, [])
            merged = list(existing) + [v for v in legacy if v not in existing]
            out[new] = merged
    return out


def audit_tasks_against_containment(
    tasks: list[Any], containment_cfg: dict[str, Any] | None,
) -> list[ContainmentWarning]:
    """Check task paths against containment config, return warnings.

    **Limitations (advisory only):**

    - Path extraction is heuristic — it parses free-form text, not ASTs.
    - Does not catch Unicode encoding tricks or homoglyph attacks.
    - Absolute paths (e.g. ``/etc/passwd``) are not currently detected.
    - This is an advisory pre-flight check; it does not enforce containment.
    """
    if not containment_cfg or not containment_cfg.get("enabled", False):
        return []
    cfg = _normalize_containment_config(containment_cfg)
    readonly_dirs = cfg.get("readonly_directories", [])
    readonly_files = set(cfg.get("readonly_files", []))
    blocked_dirs = cfg.get("blocked_directories", [])
    blocked_files = set(cfg.get("blocked_files", []))
    known_names = blocked_files | readonly_files

    warnings: list[ContainmentWarning] = []
    for task in tasks:
        desc = getattr(task, "description", None)
        title = getattr(task, "title", None)
        ac = getattr(task, "ac_items", None)
        parts = [desc if isinstance(desc, str) else "",
                 title if isinstance(title, str) else ""]
        parts.extend(ac if isinstance(ac, list) else [])
        combined = "\n".join(parts)
        paths = extract_paths_from_text(combined)
        for name in known_names:
            if name not in paths and _word_boundary_match(name, combined):
                paths.append(name)
        for p in paths:
            w = _check_path(
                task.id, p, readonly_dirs, readonly_files,
                blocked_dirs, blocked_files,
            )
            if w:
                warnings.append(w)
    return warnings


def load_containment_config(project_root: Path) -> dict[str, Any] | None:
    """Load containment config from .paircoder/config.yaml."""
    import yaml

    config_path = project_root / ".paircoder" / "config.yaml"
    if not config_path.exists():
        return None
    try:
        data = yaml.safe_load(config_path.read_text(encoding="utf-8")) or {}
        cfg = data.get("containment")
        if cfg and isinstance(cfg, dict):
            return _normalize_containment_config(cfg)
        return cfg
    except Exception:
        logger.warning("Failed to load containment config", exc_info=True)
        return None


def format_warnings(warnings: list[ContainmentWarning]) -> list[str]:
    """Format containment warnings as human-readable lines."""
    if not warnings:
        return []
    lines = ["CONTAINMENT AUDIT — restricted paths detected:"]
    for w in warnings:
        tier_label = "BLOCKED" if w.tier == "blocked" else "READ-ONLY"
        lines.append(f"  [{tier_label}] {w.task_id}: {w.path}")
        lines.append(f"    → {w.suggested_action}")
    return lines


def run_containment_preflight(
    project_root: Path, tasks: list[Any],
) -> list[ContainmentWarning]:
    """Load config and audit tasks. Logs warnings but does not block."""
    cfg = load_containment_config(project_root)
    warnings = audit_tasks_against_containment(tasks, cfg)
    if warnings:
        for line in format_warnings(warnings):
            logger.warning(line)
    return warnings
