"""Push agent lifecycle events to A2A channel.

Posts SubagentStop outcomes and TeammateIdle heartbeats to the A2A
/messages endpoint so the Lounge live activity view and Computer Prime
can track agent lifecycle. Auth uses bearer token from environment
(TokenManager pattern).

Non-blocking: push failures are logged but never raise.
"""

from __future__ import annotations

import json
import logging
import os
import re
import time
import urllib.request
import urllib.error
from datetime import datetime, timezone
from typing import Any
from urllib.parse import urlparse

logger = logging.getLogger(__name__)

# Simple circuit breaker: skip pushes for 30s after a failure.
_BACKOFF_SECONDS = 30
_last_failure_time: float = 0.0

# RFC 1918 / link-local patterns for SSRF rejection.
_PRIVATE_IP_RE = re.compile(
    r"^(?:10\.\d{1,3}\.\d{1,3}\.\d{1,3}"
    r"|172\.(?:1[6-9]|2\d|3[01])\.\d{1,3}\.\d{1,3}"
    r"|192\.168\.\d{1,3}\.\d{1,3}"
    r"|169\.254\.\d{1,3}\.\d{1,3})$"
)


def _validate_url(url: str) -> bool:
    """Validate a base URL is safe (no SSRF risk).

    Allows https:// to any host and http:// only for localhost/127.0.0.1.
    Rejects file://, RFC 1918 addresses, and link-local addresses.
    """
    try:
        parsed = urlparse(url)
    except Exception:
        return False

    scheme = parsed.scheme.lower()
    hostname = (parsed.hostname or "").lower()

    if scheme not in ("http", "https"):
        return False

    if scheme == "http":
        # Allow only localhost / 127.0.0.1 for development
        if hostname not in ("localhost", "127.0.0.1"):
            return False

    if _PRIVATE_IP_RE.match(hostname):
        return False

    return True


def _is_backoff_active() -> bool:
    """Return True if circuit breaker backoff is active."""
    if _last_failure_time == 0.0:
        return False
    return (time.monotonic() - _last_failure_time) < _BACKOFF_SECONDS


def push_subagent_stop(
    event: dict[str, Any],
    *,
    base_url: str | None = None,
    token: str | None = None,
) -> bool:
    """Push a SubagentStop event to the A2A /messages endpoint.

    Args:
        event: Dict with agent_id, agent_type, outcome,
               duration_seconds, task_id.
        base_url: A2A base URL. Falls back to A2A_BASE_URL env var.
        token: Bearer token. Falls back to A2A_TOKEN env var.

    Returns:
        True on success, False on any failure.
    """
    if base_url is None or token is None:
        env_url, env_token = _resolve_config()
        base_url = base_url or env_url
        token = token or env_token

    if not base_url or not token:
        logger.debug("A2A push skipped: no base_url or token configured")
        return False

    if not _validate_url(base_url):
        logger.warning("A2A push rejected: unsafe URL %s", base_url)
        return False

    if _is_backoff_active():
        logger.debug("A2A push skipped: backoff active after recent failure")
        return False

    global _last_failure_time
    try:
        message = _build_message(event)
        url = f"{base_url}/messages"
        headers = {"Authorization": f"Bearer {token}"}
        _post_message(url, message, headers)
        return True
    except Exception as exc:
        _last_failure_time = time.monotonic()
        logger.warning("A2A push failed for agent %s: %s", event.get("agent_id", "?"), exc)
        return False


def push_teammate_idle(
    event: dict[str, Any],
    *,
    base_url: str | None = None,
    token: str | None = None,
) -> bool:
    """Push a TeammateIdle heartbeat to the A2A /messages endpoint.

    Args:
        event: Dict with agent_id, agent_type.
        base_url: A2A base URL. Falls back to A2A_BASE_URL env var.
        token: Bearer token. Falls back to A2A_TOKEN env var.

    Returns:
        True on success, False on any failure.
    """
    if base_url is None or token is None:
        env_url, env_token = _resolve_config()
        base_url = base_url or env_url
        token = token or env_token

    if not base_url or not token:
        logger.debug("A2A push skipped: no base_url or token configured")
        return False

    if not _validate_url(base_url):
        logger.warning("A2A idle push rejected: unsafe URL %s", base_url)
        return False

    if _is_backoff_active():
        logger.debug("A2A idle push skipped: backoff active after recent failure")
        return False

    global _last_failure_time
    try:
        message = _build_idle_heartbeat(event)
        url = f"{base_url}/messages"
        headers = {"Authorization": f"Bearer {token}"}
        _post_message(url, message, headers)
        return True
    except Exception as exc:
        _last_failure_time = time.monotonic()
        logger.warning("A2A idle push failed for agent %s: %s", event.get("agent_id", "?"), exc)
        return False


def _build_message(event: dict[str, Any]) -> dict[str, Any]:
    """Build an A2A message payload from a SubagentStop event."""
    return {
        "event_type": "subagent_stop",
        "agent_id": event.get("agent_id", "unknown"),
        "agent_type": event.get("agent_type", "unknown"),
        "outcome": event.get("outcome", "unknown"),
        "duration_seconds": event.get("duration_seconds", 0),
        "task_id": event.get("task_id", ""),
        "timestamp": datetime.now(timezone.utc).isoformat(),
    }


def _build_idle_heartbeat(event: dict[str, Any]) -> dict[str, Any]:
    """Build an A2A message payload from a TeammateIdle event."""
    return {
        "event_type": "teammate_idle",
        "agent_id": event.get("agent_id", "unknown"),
        "agent_type": event.get("agent_type", "unknown"),
        "status": "idle",
        "timestamp": datetime.now(timezone.utc).isoformat(),
    }


def _resolve_config() -> tuple[str | None, str | None]:
    """Resolve A2A config from environment variables."""
    return (
        os.environ.get("A2A_BASE_URL"),
        os.environ.get("A2A_TOKEN"),
    )


def _post_message(
    url: str,
    payload: dict[str, Any],
    headers: dict[str, str],
) -> None:
    """POST JSON payload to URL. Raises on failure."""
    data = json.dumps(payload).encode("utf-8")
    headers = {**headers, "Content-Type": "application/json"}
    req = urllib.request.Request(url, data=data, headers=headers, method="POST")
    urllib.request.urlopen(req, timeout=5)
