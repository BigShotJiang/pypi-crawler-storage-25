import asyncio
import base64
import json
import os
import re
import time
from contextlib import asynccontextmanager
from datetime import datetime
from pathlib import Path
from uuid import uuid4

import yaml
from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi import Request
from fastapi.responses import HTMLResponse, JSONResponse

from agentkit.core.context import ContextAssembler
from agentkit.core.pipeline import PipelineConfig, VoicePipeline
from agentkit.core.proactive import ProactiveConfig, ProactiveTriggerManager
from agentkit.core.reminders import ReminderManager
from agentkit.core.tools import ToolRegistry
from agentkit.core.wake_word import WakeWordConfig, WakeWordDetector
from agentkit.learning.correction import CorrectionDetector, CorrectionStore
from agentkit.memory.base import ConversationTurn
from agentkit.providers import registry


# Module-level state
pipeline = None
memory = None
context_assembler = None
correction_detector = None
correction_store = None
agent_config = None
wake_word_detector = None
proactive_manager = None
reminder_manager = None
server_api_key = None
stt_provider = None


def _resolve_env_vars(config: dict) -> dict:
    """Recursively resolve ${VAR} references in config values."""
    if isinstance(config, dict):
        return {k: _resolve_env_vars(v) for k, v in config.items()}
    if isinstance(config, list):
        return [_resolve_env_vars(v) for v in config]
    if isinstance(config, str):
        return re.sub(r'\$\{(\w+)\}', lambda m: os.environ.get(m.group(1), ""), config)
    return config


def load_config() -> dict:
    config_path = os.environ.get("AGENTKIT_CONFIG_PATH", "agent.config.yaml")
    with open(config_path) as f:
        raw = yaml.safe_load(f)
    return _resolve_env_vars(raw)


async def initialize_services():
    global pipeline, memory, context_assembler, correction_detector, correction_store
    global agent_config, server_api_key, wake_word_detector, proactive_manager
    global reminder_manager, stt_provider

    config = load_config()
    agent_config = config

    # Create providers via registry — works for built-in and custom providers
    voice_config = config.get("voice", {})
    stt = registry.create_stt(voice_config.get("stt", {}))
    llm = registry.create_llm(config.get("llm", {}))
    tts = registry.create_tts(voice_config.get("tts", {}))
    stt_provider = stt  # Keep reference for ambient wake word checks

    # Pipeline
    agent_cfg = config.get("agent", {})
    
    # Load tools from tools.py if it exists
    tools = ToolRegistry()
    tools_path = Path("tools.py")
    if tools_path.exists():
        import importlib.util
        spec = importlib.util.spec_from_file_location("user_tools", tools_path)
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        # Auto-register functions decorated with @tools.register
        if hasattr(mod, "tools") and isinstance(mod.tools, ToolRegistry):
            tools = mod.tools

    # Built-in reminder tools — always available
    reminder_manager = ReminderManager()

    @tools.register(name="set_reminder", description="Set a reminder for the user. Use when they say 'remind me to...'")
    async def set_reminder(text: str, minutes_from_now: float) -> str:
        r = await reminder_manager.add("default", text, minutes_from_now=minutes_from_now)
        return f"Reminder set: '{text}' in {r.time_until()} (ID: {r.id})"

    @tools.register(name="list_reminders", description="List all active reminders for the user.")
    async def list_reminders() -> str:
        reminders = await reminder_manager.get_all("default")
        if not reminders:
            return "No active reminders."
        lines = []
        for r in reminders:
            lines.append(f"- [{r.id}] '{r.text}' — in {r.time_until()}")
        return "Active reminders:\n" + "\n".join(lines)

    @tools.register(name="cancel_reminder", description="Cancel a reminder by its ID.")
    async def cancel_reminder(reminder_id: str) -> str:
        ok = await reminder_manager.cancel("default", reminder_id)
        return f"Reminder {reminder_id} cancelled." if ok else f"Reminder {reminder_id} not found."

    pipeline_config = PipelineConfig(
        persona=agent_cfg.get("persona", "You are a helpful assistant."),
        language=agent_cfg.get("language", "hinglish"),
        tools=tools if tools.list_tools() else None,
    )

    pipeline = VoicePipeline(stt, llm, tts, pipeline_config)

    # Memory — also via registry
    memory = registry.create_memory(config.get("memory", {}))

    context_assembler = ContextAssembler(memory)
    correction_detector = CorrectionDetector()
    correction_store = CorrectionStore(memory)

    # Wake word detection
    ww_cfg = config.get("wake_word", {})
    wake_word_detector = WakeWordDetector(WakeWordConfig(
        enabled=ww_cfg.get("enabled", False),
        words=ww_cfg.get("words", ["hey agent"]),
        required=ww_cfg.get("required", True),
        listen_window=ww_cfg.get("listen_window", 30.0),
    ))

    # Proactive agent triggers
    pa_cfg = config.get("proactive", {})
    proactive_manager = ProactiveTriggerManager(ProactiveConfig(
        enabled=pa_cfg.get("enabled", False),
        idle_timeout=pa_cfg.get("idle_timeout", 0),
        idle_message=pa_cfg.get("idle_message", "Hey! I'm here if you need anything. Just ask!"),
        idle_repeat=pa_cfg.get("idle_repeat", False),
        scheduled_triggers=pa_cfg.get("scheduled_triggers", []),
    ))

    # API key auth — if configured, all connections must provide it
    deploy_cfg = config.get("deployment", {})
    key = deploy_cfg.get("api_key", "")
    server_api_key = key if key else None


@asynccontextmanager
async def lifespan(app: FastAPI):
    await initialize_services()
    yield
    if pipeline:
        await pipeline.close()


app = FastAPI(title="AgentKit Server", lifespan=lifespan)


def _check_api_key(provided_key: str | None) -> bool:
    """Return True if the key is valid or auth is disabled."""
    if server_api_key is None:
        return True
    return provided_key == server_api_key


@app.get("/health")
async def health():
    return {
        "status": "ok",
        "agent": agent_config.get("agent", {}).get("name", "Unknown") if agent_config else "not initialized",
        "providers": {
            "stt": agent_config.get("voice", {}).get("stt", {}).get("provider") if agent_config else None,
            "llm": agent_config.get("llm", {}).get("provider") if agent_config else None,
            "tts": agent_config.get("voice", {}).get("tts", {}).get("provider") if agent_config else None,
        } if agent_config else {},
    }


@app.get("/api/config")
async def get_agent_config(request: Request):
    """Return agent config for mobile app (wake word settings, agent name, etc.)."""
    if not _check_api_key(request.headers.get("x-api-key") or request.query_params.get("api_key")):
        return JSONResponse({"error": "Invalid or missing API key"}, status_code=403)

    ww_cfg = agent_config.get("wake_word", {}) if agent_config else {}
    agent_cfg = agent_config.get("agent", {}) if agent_config else {}
    return {
        "agent_name": agent_cfg.get("name", "Assistant"),
        "wake_words": ww_cfg.get("words", ["hey agent"]),
        "wake_word_enabled": ww_cfg.get("enabled", False),
        "listen_window": ww_cfg.get("listen_window", 30.0),
        "hands_free_supported": True,
    }


@app.websocket("/ws/voice")
async def websocket_voice(websocket: WebSocket):
    # API key auth gate
    if not _check_api_key(websocket.query_params.get("api_key")):
        await websocket.close(code=4003, reason="Invalid or missing API key")
        return

    await websocket.accept()
    user_id = websocket.query_params.get("user_id", "default")
    processing_task: asyncio.Task | None = None

    async def cancel_current():
        """Cancel any in-progress pipeline processing."""
        nonlocal processing_task
        if processing_task and not processing_task.done():
            pipeline.cancel()
            processing_task.cancel()
            try:
                await processing_task
            except (asyncio.CancelledError, Exception):
                pass
            processing_task = None
            await websocket.send_json({"type": "interrupted"})

    # Proactive agent: push messages to client
    async def on_proactive_message(message: str):
        try:
            await websocket.send_json({"type": "proactive", "text": message})
        except Exception:
            pass

    if proactive_manager and proactive_manager.config.enabled:
        await proactive_manager.start(on_proactive_message)

    # Reminder check loop — runs every 30s alongside the main WS loop
    async def reminder_loop():
        while True:
            await asyncio.sleep(30)
            try:
                due = await reminder_manager.check_due(user_id)
                for r in due:
                    await websocket.send_json({
                        "type": "reminder",
                        "text": r.text,
                        "reminder_id": r.id,
                    })
            except Exception:
                pass

    reminder_task = asyncio.create_task(reminder_loop())

    try:
        while True:
            data = await websocket.receive_json()
            msg_type = data.get("type")

            # Record activity for proactive triggers
            if proactive_manager:
                proactive_manager.record_activity()

            if msg_type == "interrupt":
                await cancel_current()
                continue

            if msg_type == "ambient_check":
                # Quick STT check for wake word in ambient audio
                try:
                    audio_bytes = bytes(data.get("data", []))
                    if not audio_bytes or len(audio_bytes) < 100:
                        await websocket.send_json({"type": "wake_silent"})
                        continue

                    async def ambient_stream():
                        yield audio_bytes

                    transcript = ""
                    async for chunk in stt_provider.transcribe_stream(ambient_stream()):
                        transcript += chunk

                    transcript = transcript.strip()
                    if not transcript:
                        await websocket.send_json({"type": "wake_silent"})
                        continue

                    if wake_word_detector and wake_word_detector.detect(transcript):
                        cleaned = wake_word_detector.strip_wake_word(transcript)
                        wake_word_detector.activate(time.time())
                        await websocket.send_json({
                            "type": "wake_detected",
                            "transcript": cleaned,
                        })
                        # If there's content after the wake word, process it as text
                        if cleaned.strip():
                            mem_ctx = await context_assembler.assemble(cleaned, user_id)
                            context_str = mem_ctx.assemble()
                            try:
                                async def on_text_delta(token):
                                    await websocket.send_json({"type": "text_delta", "delta": token})
                                async for audio_chunk in pipeline.process_text(cleaned, context_str, on_text_delta=on_text_delta):
                                    encoded = base64.b64encode(audio_chunk).decode("ascii")
                                    await websocket.send_json({"type": "audio", "data": encoded})
                                text_response = pipeline.get_last_response()
                                await websocket.send_json({"type": "text", "text": text_response})
                                await websocket.send_json({"type": "done"})
                            except Exception as e:
                                await websocket.send_json({"type": "error", "message": str(e)})
                                await websocket.send_json({"type": "done"})
                    elif wake_word_detector and wake_word_detector.is_in_listen_window(time.time()):
                        # In listen window — process speech without wake word
                        if transcript:
                            await websocket.send_json({"type": "wake_detected", "transcript": transcript})
                            mem_ctx = await context_assembler.assemble(transcript, user_id)
                            context_str = mem_ctx.assemble()
                            try:
                                async def on_text_delta_lw(token):
                                    await websocket.send_json({"type": "text_delta", "delta": token})
                                async for audio_chunk in pipeline.process_text(transcript, context_str, on_text_delta=on_text_delta_lw):
                                    encoded = base64.b64encode(audio_chunk).decode("ascii")
                                    await websocket.send_json({"type": "audio", "data": encoded})
                                text_response = pipeline.get_last_response()
                                await websocket.send_json({"type": "text", "text": text_response})
                                await websocket.send_json({"type": "done"})
                            except Exception as e:
                                await websocket.send_json({"type": "error", "message": str(e)})
                                await websocket.send_json({"type": "done"})
                        else:
                            await websocket.send_json({"type": "wake_silent"})
                    else:
                        await websocket.send_json({"type": "wake_silent"})
                except Exception as e:
                    await websocket.send_json({"type": "wake_silent"})
                continue

            if msg_type == "audio":
                # Interrupt any ongoing response before processing new input
                await cancel_current()

                audio_bytes = bytes(data.get("data", []))
                mem_ctx = await context_assembler.assemble("", user_id)
                context_str = mem_ctx.assemble()

                async def audio_stream():
                    yield audio_bytes

                try:
                    async def on_voice_delta(token):
                        await websocket.send_json({"type": "text_delta", "delta": token})

                    async for audio_chunk in pipeline.process_voice_stream(
                        audio_stream(), context_str, on_text_delta=on_voice_delta
                    ):
                        encoded = base64.b64encode(audio_chunk).decode("ascii")
                        await websocket.send_json({
                            "type": "audio",
                            "data": encoded,
                        })
                except Exception as proc_err:
                    err_msg = str(proc_err)
                    if "API key" in err_msg or "API_KEY_INVALID" in err_msg:
                        err_msg = "Invalid API key. Check your .env file and ensure your API keys are correct."
                    await websocket.send_json({"type": "error", "message": err_msg})
                    await websocket.send_json({"type": "done"})
                    continue

                # Send text response alongside audio
                text_response = pipeline.get_last_response()
                await websocket.send_json({
                    "type": "text",
                    "text": text_response,
                })
                await websocket.send_json({"type": "done"})

                # Store conversation turn
                if pipeline.turns:
                    last_turn = pipeline.turns[-1]
                    turn = ConversationTurn(
                        turn_id=str(uuid4()),
                        user_id=user_id,
                        user_message=last_turn.user_message,
                        assistant_message=last_turn.assistant_message,
                        timestamp=datetime.now(),
                        metadata={},
                    )
                    await memory.store(turn)

            elif msg_type == "text":
                # Interrupt any ongoing response before processing new input
                await cancel_current()

                text = data.get("text", "")
                if not text.strip():
                    await websocket.send_json({"type": "error", "message": "Empty message"})
                    continue

                # Strip wake word if present in the message
                if wake_word_detector and wake_word_detector.config.enabled:
                    text = wake_word_detector.strip_wake_word(text)

                mem_ctx = await context_assembler.assemble(text, user_id)
                context_str = mem_ctx.assemble()

                try:
                    async def on_text_delta(token):
                        await websocket.send_json({"type": "text_delta", "delta": token})

                    async for audio_chunk in pipeline.process_text(text, context_str, on_text_delta=on_text_delta):
                        encoded = base64.b64encode(audio_chunk).decode("ascii")
                        await websocket.send_json({
                            "type": "audio",
                            "data": encoded,
                        })

                    text_response = pipeline.get_last_response()
                    await websocket.send_json({
                        "type": "text",
                        "text": text_response,
                    })
                    await websocket.send_json({"type": "done"})
                except Exception as proc_err:
                    err_msg = str(proc_err)
                    if "API key" in err_msg or "API_KEY_INVALID" in err_msg:
                        err_msg = "Invalid API key. Check your .env file and ensure your API keys are correct."
                    await websocket.send_json({"type": "error", "message": err_msg})
                    await websocket.send_json({"type": "done"})
                    continue

                # Detect corrections
                correction = correction_detector.detect_explicit(text)
                if not correction:
                    correction = correction_detector.detect_implicit(text, 2.0)
                if correction:
                    await correction_store.store_correction(correction, user_id)

                correction_detector.update_context(text)

                # Store conversation turn
                if pipeline.turns:
                    last_turn = pipeline.turns[-1]
                    turn = ConversationTurn(
                        turn_id=str(uuid4()),
                        user_id=user_id,
                        user_message=last_turn.user_message,
                        assistant_message=last_turn.assistant_message,
                        timestamp=datetime.now(),
                        metadata={},
                    )
                    await memory.store(turn)

    except WebSocketDisconnect:
        reminder_task.cancel()
        if proactive_manager:
            await proactive_manager.stop()
    except Exception as e:
        reminder_task.cancel()
        if proactive_manager:
            await proactive_manager.stop()
        try:
            await websocket.send_json({"type": "error", "message": str(e)})
        except Exception:
            pass


@app.post("/api/chat")
async def chat(request: Request, message: dict):
    # API key auth gate
    if not _check_api_key(request.headers.get("x-api-key") or request.query_params.get("api_key")):
        return JSONResponse({"error": "Invalid or missing API key"}, status_code=403)

    text = message.get("text", "")
    user_id = message.get("user_id", "default")

    if not text.strip():
        return JSONResponse({"error": "Empty message"}, status_code=400)

    mem_ctx = await context_assembler.assemble(text, user_id)
    context_str = mem_ctx.assemble()

    # Collect audio chunks
    audio_chunks = []
    async for audio_chunk in pipeline.process_text(text, context_str):
        audio_chunks.append(audio_chunk)

    text_response = pipeline.get_last_response()
    audio_b64 = base64.b64encode(b"".join(audio_chunks)).decode("ascii") if audio_chunks else None

    return {
        "response": text_response,
        "audio": audio_b64,
    }


@app.get("/playground")
async def playground():
    agent_name = agent_config.get("agent", {}).get("name", "AgentKit") if agent_config else "AgentKit"
    html = PLAYGROUND_HTML.replace("{{AGENT_NAME}}", agent_name)
    return HTMLResponse(html)


PLAYGROUND_HTML = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{AGENT_NAME}} - Playground</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; background: #0f172a; color: #e2e8f0; min-height: 100vh; display: flex; flex-direction: column; align-items: center; }
        .header { padding: 20px; text-align: center; }
        .header h1 { font-size: 1.5rem; color: #818cf8; }
        .header p { font-size: 0.85rem; color: #64748b; margin-top: 4px; }
        .status { font-size: 0.75rem; padding: 4px 12px; border-radius: 12px; display: inline-block; margin-top: 8px; }
        .status.connected { background: #064e3b; color: #34d399; }
        .status.disconnected { background: #450a0a; color: #f87171; }
        .orb-container { display: flex; justify-content: center; padding: 30px 0; }
        .orb { width: 120px; height: 120px; border-radius: 50%; background: linear-gradient(135deg, #667eea, #764ba2); cursor: pointer; display: flex; align-items: center; justify-content: center; transition: all 0.3s ease; box-shadow: 0 0 30px rgba(102, 126, 234, 0.3); }
        .orb:hover { transform: scale(1.05); box-shadow: 0 0 50px rgba(102, 126, 234, 0.5); }
        .orb.listening { background: linear-gradient(135deg, #ef4444, #dc2626); animation: pulse 1.5s infinite; box-shadow: 0 0 50px rgba(239, 68, 68, 0.5); }
        .orb.speaking { background: linear-gradient(135deg, #f97316, #ea580c); animation: pulse 1s infinite; box-shadow: 0 0 50px rgba(249, 115, 22, 0.5); }
        .orb-icon { font-size: 2rem; }
        @keyframes pulse { 0%, 100% { transform: scale(1); } 50% { transform: scale(1.08); } }
        .chat-container { width: 100%; max-width: 640px; flex: 1; display: flex; flex-direction: column; padding: 0 20px 20px; }
        .messages { flex: 1; overflow-y: auto; padding: 10px 0; max-height: 350px; }
        .message { margin: 8px 0; padding: 10px 14px; border-radius: 12px; max-width: 80%; word-wrap: break-word; font-size: 0.9rem; line-height: 1.5; }
        .message.user { background: #1e3a5f; margin-left: auto; border-bottom-right-radius: 4px; }
        .message.assistant { background: #1e293b; border-bottom-left-radius: 4px; }
        .input-row { display: flex; gap: 8px; padding-top: 10px; }
        .input-row input { flex: 1; padding: 12px 16px; border-radius: 12px; border: 1px solid #334155; background: #1e293b; color: #e2e8f0; font-size: 0.9rem; outline: none; }
        .input-row input:focus { border-color: #667eea; }
        .input-row button { padding: 12px 20px; border-radius: 12px; border: none; background: #667eea; color: white; cursor: pointer; font-size: 0.9rem; font-weight: 500; }
        .input-row button:hover { background: #5b6fe6; }
    </style>
</head>
<body>
    <div class="header">
        <h1>{{AGENT_NAME}}</h1>
        <p>AgentKit Playground</p>
        <span class="status disconnected" id="status">Connecting...</span>
    </div>

    <div class="orb-container">
        <div class="orb" id="orb" title="Click to speak">
            <span class="orb-icon">🎙️</span>
        </div>
    </div>

    <div class="chat-container">
        <div class="messages" id="messages"></div>
        <div class="input-row">
            <input type="text" id="input" placeholder="Type a message..." autocomplete="off" />
            <button id="sendBtn">Send</button>
        </div>
    </div>

    <script>
        const messagesEl = document.getElementById('messages');
        const inputEl = document.getElementById('input');
        const statusEl = document.getElementById('status');
        const orbEl = document.getElementById('orb');
        let ws = null;
        let currentAssistantEl = null;
        let currentAudio = null;

        // Audio queue to prevent overlapping playback
        const audioQueue = [];
        let isPlaying = false;

        function flushAudio() {
            audioQueue.length = 0;
            if (currentAudio) {
                currentAudio.pause();
                currentAudio = null;
            }
            isPlaying = false;
            orbEl.className = 'orb';
        }

        function interrupt() {
            flushAudio();
            currentAssistantEl = null;
            if (ws && ws.readyState === WebSocket.OPEN) {
                ws.send(JSON.stringify({ type: 'interrupt' }));
            }
        }

        function enqueueAudio(base64Data) {
            audioQueue.push(base64Data);
            if (!isPlaying) playNext();
        }

        function playNext() {
            if (audioQueue.length === 0) {
                isPlaying = false;
                orbEl.className = 'orb';
                return;
            }
            isPlaying = true;
            orbEl.className = 'orb speaking';
            const data = audioQueue.shift();
            try {
                const audio = new Audio('data:audio/wav;base64,' + data);
                currentAudio = audio;
                audio.onended = () => { currentAudio = null; playNext(); };
                audio.onerror = () => { currentAudio = null; playNext(); };
                audio.play().catch(() => { currentAudio = null; playNext(); });
            } catch(err) { currentAudio = null; playNext(); }
        }

        function connect() {
            const wsUrl = 'ws://' + location.host + '/ws/voice';
            ws = new WebSocket(wsUrl);

            ws.onopen = () => {
                statusEl.textContent = 'Connected';
                statusEl.className = 'status connected';
            };

            ws.onclose = () => {
                statusEl.textContent = 'Disconnected';
                statusEl.className = 'status disconnected';
                setTimeout(connect, 3000);
            };

            ws.onerror = () => {
                statusEl.textContent = 'Error';
                statusEl.className = 'status disconnected';
            };

            ws.onmessage = (e) => {
                const data = JSON.parse(e.data);

                if (data.type === 'audio') {
                    enqueueAudio(data.data);
                } else if (data.type === 'text_delta') {
                    if (!currentAssistantEl) {
                        currentAssistantEl = document.createElement('div');
                        currentAssistantEl.className = 'message assistant';
                        messagesEl.appendChild(currentAssistantEl);
                    }
                    currentAssistantEl.textContent += data.delta;
                    messagesEl.scrollTop = messagesEl.scrollHeight;
                } else if (data.type === 'text' && data.text) {
                    // Final text — replace streamed content with complete response
                    if (currentAssistantEl) {
                        currentAssistantEl.textContent = data.text;
                    } else {
                        addMessage('assistant', data.text);
                    }
                    currentAssistantEl = null;
                } else if (data.type === 'done') {
                    currentAssistantEl = null;
                    if (!isPlaying) orbEl.className = 'orb';
                } else if (data.type === 'interrupted') {
                    flushAudio();
                    currentAssistantEl = null;
                } else if (data.type === 'proactive') {
                    addMessage('assistant', '💡 ' + data.text);
                } else if (data.type === 'wake_word_required') {
                    addMessage('assistant', '💤 Say the wake word to activate me!');
                } else if (data.type === 'error') {
                    currentAssistantEl = null;
                    addMessage('assistant', '⚠️ ' + data.message);
                }
            };
        }

        function addMessage(role, text) {
            const div = document.createElement('div');
            div.className = 'message ' + role;
            div.textContent = text;
            messagesEl.appendChild(div);
            messagesEl.scrollTop = messagesEl.scrollHeight;
        }

        function sendMessage() {
            const text = inputEl.value.trim();
            if (!text || !ws || ws.readyState !== WebSocket.OPEN) return;

            // Interrupt any ongoing response
            if (isPlaying || currentAssistantEl) interrupt();

            addMessage('user', text);
            ws.send(JSON.stringify({ type: 'text', text: text }));
            inputEl.value = '';
        }

        inputEl.addEventListener('keydown', (e) => {
            if (e.key === 'Enter') sendMessage();
        });
        document.getElementById('sendBtn').addEventListener('click', sendMessage);

        connect();
    </script>
</body>
</html>
"""