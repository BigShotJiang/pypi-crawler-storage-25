import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  View, Text, TextInput, TouchableOpacity, StyleSheet,
  ScrollView, KeyboardAvoidingView, Platform, Animated, Dimensions,
} from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { LinearGradient } from 'expo-linear-gradient';
import { Audio } from 'expo-av';
import * as Haptics from 'expo-haptics';
import * as FileSystem from 'expo-file-system';
import config from './config';

const { width: SW } = Dimensions.get('window');

// ─── Color Palette (light lavender / purple) ───
const C = {
  bg: '#f0eeff',
  card: '#ffffff',
  cardAlt: '#f7f5ff',
  primary: '#7c5cfc',
  primaryDark: '#5b3de6',
  primaryLight: '#b8a9ff',
  accent: '#a78bfa',
  text: '#1e1b4b',
  textSec: '#6b6394',
  textMuted: '#a19bc2',
  border: '#e4e0f5',
  userBubble: '#7c5cfc',
  asstBubble: '#ffffff',
  shadow: '#7c5cfc20',
  success: '#34d399',
  warning: '#fbbf24',
  danger: '#f87171',
};

// ─── WebSocket (inline, no separate module) ───
let ws = null;
let wsUrl = '';
let wsApiKey = '';
let wsCallback = null;
let reconnectTimer = null;
let reconnectAttempts = 0;

function wsConnect(onMessage, url, key) {
  wsCallback = onMessage;
  if (url) {
    let u = url.trim();
    u = u.replace(/^http:/, 'ws:').replace(/^https:/, 'wss:');
    if (!u.includes('/ws/voice')) u = u.replace(/\/+$/, '') + '/ws/voice';
    wsUrl = u;
  }
  if (key) wsApiKey = key;
  _doConnect();
}

function _doConnect() {
  if (ws && (ws.readyState === WebSocket.OPEN || ws.readyState === WebSocket.CONNECTING)) return;
  let fullUrl = wsUrl;
  if (wsApiKey) fullUrl += (fullUrl.includes('?') ? '&' : '?') + 'api_key=' + encodeURIComponent(wsApiKey);

  try { ws = new WebSocket(fullUrl); } catch (e) {
    if (wsCallback) wsCallback({ type: 'connection', status: 'disconnected' });
    _scheduleReconnect(); return;
  }

  ws.onopen = () => {
    reconnectAttempts = 0;
    if (wsCallback) wsCallback({ type: 'connection', status: 'connected' });
  };
  ws.onmessage = (e) => {
    try { if (wsCallback) wsCallback(JSON.parse(e.data)); } catch (err) { /* ignore */ }
  };
  ws.onerror = () => {};
  ws.onclose = (e) => {
    if (wsCallback) wsCallback({ type: 'connection', status: 'disconnected' });
    if (e.code === 4003) {
      if (wsCallback) wsCallback({ type: 'error', message: 'Auth failed. Check API key.' });
      return;
    }
    _scheduleReconnect();
  };
}

function _scheduleReconnect() {
  if (reconnectTimer) return;
  const delay = Math.min(1000 * Math.pow(2, reconnectAttempts), 30000);
  reconnectAttempts++;
  if (wsCallback) wsCallback({ type: 'connection', status: 'connecting' });
  reconnectTimer = setTimeout(() => { reconnectTimer = null; _doConnect(); }, delay);
}

function wsSend(obj) { if (ws && ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(obj)); }
function wsClose() {
  if (reconnectTimer) { clearTimeout(reconnectTimer); reconnectTimer = null; }
  if (ws) { ws.close(); ws = null; }
}
function wsIsOpen() { return ws && ws.readyState === WebSocket.OPEN; }

// ─── Audio helpers (inline) ───
let recording = null;

async function startMic() {
  try {
    const perm = await Audio.requestPermissionsAsync();
    if (!perm.granted) return false;
    await Audio.setAudioModeAsync({ allowsRecordingIOS: true, playsInSilentModeIOS: true });
    const { recording: rec } = await Audio.Recording.createAsync(Audio.RecordingOptionsPresets.HIGH_QUALITY);
    recording = rec;
    return true;
  } catch (e) { recording = null; return false; }
}

async function stopMic() {
  if (!recording) return null;
  try {
    await recording.stopAndUnloadAsync();
    await Audio.setAudioModeAsync({ allowsRecordingIOS: false });
    const uri = recording.getURI();
    recording = null;
    return uri;
  } catch (e) { recording = null; return null; }
}

async function getMicBytes() {
  const uri = await stopMic();
  if (!uri) return null;
  try {
    const b64 = await FileSystem.readAsStringAsync(uri, { encoding: FileSystem.EncodingType.Base64 });
    // Pure JS base64 → byte array (Hermes safe, no atob)
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
    const lookup = new Uint8Array(256);
    for (let i = 0; i < chars.length; i++) lookup[chars.charCodeAt(i)] = i;
    const clean = b64.replace(/[^A-Za-z0-9+/]/g, '');
    const len = (clean.length * 3) >>> 2;
    const bytes = new Uint8Array(len);
    let p = 0;
    for (let i = 0; i < clean.length; i += 4) {
      const a = lookup[clean.charCodeAt(i)], b = lookup[clean.charCodeAt(i + 1)];
      const c = lookup[clean.charCodeAt(i + 2)], d = lookup[clean.charCodeAt(i + 3)];
      bytes[p++] = (a << 2) | (b >> 4);
      if (p < len) bytes[p++] = ((b & 15) << 4) | (c >> 2);
      if (p < len) bytes[p++] = ((c & 3) << 6) | d;
    }
    return Array.from(bytes);
  } catch (e) { return null; }
}

// ─── Wake Word Config (fetched from server) ───
const DEFAULT_WAKE_WORDS = ['hey agent', 'hey aria'];

function detectWakeWord(text, wakeWords) {
  const t = text.toLowerCase().trim();
  return wakeWords.some(w => t.includes(w.toLowerCase()));
}

function stripWakeWord(text, wakeWords) {
  let result = text;
  for (const w of wakeWords) {
    const idx = result.toLowerCase().indexOf(w.toLowerCase());
    if (idx !== -1) {
      result = result.slice(idx + w.length).replace(/^[\s,.:!?]+/, '');
      break;
    }
  }
  return result.trim() || text.trim();
}

// ─── Main App ───
export default function App() {
  const [messages, setMessages] = useState([]);
  const [inputText, setInputText] = useState('');
  const [isListening, setIsListening] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [connectionStatus, setConnectionStatus] = useState('connecting');
  const [streamingText, setStreamingText] = useState('');
  const [activeTab, setActiveTab] = useState('chat');
  // Hands-free / wake word
  const [handsFreeEnabled, setHandsFreeEnabled] = useState(false);
  const [ambientState, setAmbientState] = useState('idle'); // idle|listening|active
  const [wakeWords, setWakeWords] = useState(DEFAULT_WAKE_WORDS);
  const [listenWindow, setListenWindow] = useState(30);
  const [inListenWindow, setInListenWindow] = useState(false);
  // Reminders
  const [activeReminder, setActiveReminder] = useState(null);

  const scrollRef = useRef(null);
  const soundRef = useRef(null);
  const audioQ = useRef([]);
  const playing = useRef(false);
  const pulseAnim = useRef(new Animated.Value(1)).current;
  const ringAnim = useRef(new Animated.Value(0.3)).current;
  const orbFloat = useRef(new Animated.Value(0)).current;
  const ambientRef = useRef(null); // ambient loop timer
  const listenWindowTimer = useRef(null); // listen window timeout
  const handsFreeRef = useRef(false); // ref for use inside closures
  useEffect(() => { handsFreeRef.current = handsFreeEnabled; }, [handsFreeEnabled]);

  // ─── Orb Animations ───
  useEffect(() => {
    Animated.loop(Animated.sequence([
      Animated.timing(orbFloat, { toValue: -8, duration: 2000, useNativeDriver: true }),
      Animated.timing(orbFloat, { toValue: 0, duration: 2000, useNativeDriver: true }),
    ])).start();
  }, []);

  useEffect(() => {
    if (isListening || isSpeaking || isProcessing) {
      const p = Animated.loop(Animated.sequence([
        Animated.timing(pulseAnim, { toValue: 1.18, duration: 700, useNativeDriver: true }),
        Animated.timing(pulseAnim, { toValue: 1, duration: 700, useNativeDriver: true }),
      ]));
      const r = Animated.loop(Animated.sequence([
        Animated.timing(ringAnim, { toValue: 0.8, duration: 900, useNativeDriver: true }),
        Animated.timing(ringAnim, { toValue: 0.3, duration: 900, useNativeDriver: true }),
      ]));
      p.start(); r.start();
      return () => { p.stop(); r.stop(); };
    } else {
      pulseAnim.setValue(1);
      ringAnim.setValue(0.3);
    }
  }, [isListening, isSpeaking, isProcessing]);

  // ─── Audio Queue ───
  const playNext = useCallback(async () => {
    if (!audioQ.current.length) { playing.current = false; setIsSpeaking(false); return; }
    playing.current = true; setIsSpeaking(true);
    const b64 = audioQ.current.shift();
    try {
      const { sound } = await Audio.Sound.createAsync(
        { uri: 'data:audio/wav;base64,' + b64 }, { shouldPlay: true }
      );
      soundRef.current = sound;
      sound.setOnPlaybackStatusUpdate(s => {
        if (s.didJustFinish) { sound.unloadAsync(); soundRef.current = null; playNext(); }
      });
    } catch (e) { soundRef.current = null; playNext(); }
  }, []);

  const flush = useCallback(() => {
    audioQ.current = [];
    if (soundRef.current) {
      soundRef.current.stopAsync().catch(() => {});
      soundRef.current.unloadAsync().catch(() => {});
      soundRef.current = null;
    }
    playing.current = false; setIsSpeaking(false);
  }, []);

  const enqueue = useCallback((b64) => {
    audioQ.current.push(b64);
    if (!playing.current) playNext();
  }, [playNext]);

  // ─── Listen Window helpers ───
  const startListenWindow = useCallback((seconds) => {
    setInListenWindow(true);
    if (listenWindowTimer.current) clearTimeout(listenWindowTimer.current);
    listenWindowTimer.current = setTimeout(() => {
      setInListenWindow(false);
    }, seconds * 1000);
  }, []);

  // ─── WebSocket Handler ───
  const onMsg = useCallback((data) => {
    switch (data.type) {
      case 'connection': setConnectionStatus(data.status); break;
      case 'audio': enqueue(data.data); break;
      case 'text_delta': setStreamingText(p => p + data.delta); break;
      case 'text':
        if (data.text) { setStreamingText(''); setMessages(p => [...p, { role: 'assistant', text: data.text }]); }
        break;
      case 'done':
        setIsProcessing(false); setStreamingText('');
        // After agent speaks, re-enter listen window for follow-ups
        if (handsFreeRef.current) startListenWindow(listenWindow);
        break;
      case 'interrupted': flush(); setIsProcessing(false); setStreamingText(''); break;
      case 'wake_detected':
        // Server confirmed wake word in ambient audio
        setAmbientState('active');
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
        if (data.transcript) {
          setMessages(p => [...p, { role: 'user', text: data.transcript }]);
          setIsProcessing(true);
        }
        break;
      case 'wake_silent':
        // No wake word in ambient clip, continue ambient loop
        break;
      case 'reminder':
        setActiveReminder({ text: data.text, id: data.reminder_id });
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning);
        setMessages(p => [...p, { role: 'system', text: '\uD83D\uDD14 Reminder: ' + data.text }]);
        break;
      case 'proactive':
        setMessages(p => [...p, { role: 'assistant', text: '\uD83D\uDCA1 ' + data.text }]);
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success); break;
      case 'error':
        setMessages(p => [...p, { role: 'system', text: '\u26A0\uFE0F ' + data.message }]);
        setIsProcessing(false); setStreamingText(''); break;
    }
  }, [enqueue, flush, startListenWindow, listenWindow]);

  useEffect(() => {
    wsConnect(onMsg, config.BACKEND_URL, config.API_KEY);
    return () => wsClose();
  }, [onMsg]);

  // Fetch agent config (wake words) from server
  useEffect(() => {
    const base = config.BACKEND_URL
      .replace(/^wss?:/, s => s === 'wss:' ? 'https:' : 'http:')
      .replace('/ws/voice', '');
    const url = base + '/api/config' + (config.API_KEY ? '?api_key=' + encodeURIComponent(config.API_KEY) : '');
    fetch(url)
      .then(r => r.json())
      .then(d => {
        if (d.wake_words) setWakeWords(d.wake_words);
        if (d.listen_window) setListenWindow(d.listen_window);
      })
      .catch(() => {});
  }, []);

  // ─── Ambient listening loop ───
  const runAmbientLoop = useCallback(async () => {
    if (!handsFreeRef.current || !wsIsOpen()) return;
    if (isListening || isProcessing || isSpeaking) return;
    setAmbientState('listening');
    const started = await startMic();
    if (!started) { setAmbientState('idle'); return; }
    // Record 3 second clip
    await new Promise(r => setTimeout(r, 3000));
    if (!handsFreeRef.current) { await stopMic(); setAmbientState('idle'); return; }
    const bytes = await getMicBytes();
    setAmbientState('idle');
    if (bytes && bytes.length > 100) {
      wsSend({ type: 'ambient_check', data: bytes });
    }
  }, [isListening, isProcessing, isSpeaking]);

  useEffect(() => {
    if (!handsFreeEnabled) {
      if (ambientRef.current) clearInterval(ambientRef.current);
      setAmbientState('idle');
      return;
    }
    // Run ambient check every 4 seconds (3s record + 1s gap)
    ambientRef.current = setInterval(() => {
      if (!isListening && !isProcessing && !isSpeaking) runAmbientLoop();
    }, 4000);
    return () => { if (ambientRef.current) clearInterval(ambientRef.current); };
  }, [handsFreeEnabled, isListening, isProcessing, isSpeaking, runAmbientLoop]);

  useEffect(() => {
    setTimeout(() => scrollRef.current && scrollRef.current.scrollToEnd({ animated: true }), 100);
  }, [messages, streamingText]);

  // ─── Actions ───
  const handleOrb = async () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    if (isListening) {
      setIsListening(false); setIsProcessing(true);
      const bytes = await getMicBytes();
      if (bytes) wsSend({ type: 'audio', data: bytes }); else setIsProcessing(false);
    } else {
      if (isSpeaking || isProcessing) { flush(); wsSend({ type: 'interrupt' }); setIsProcessing(false); }
      const ok = await startMic();
      if (ok) setIsListening(true);
    }
  };

  const handleSend = () => {
    const t = inputText.trim(); if (!t) return;
    if (!wsIsOpen()) {
      setMessages(p => [...p, { role: 'system', text: '\u26A0\uFE0F Not connected to server. Status: ' + connectionStatus }]);
      return;
    }
    if (isSpeaking || isProcessing) { flush(); wsSend({ type: 'interrupt' }); }
    setMessages(p => [...p, { role: 'user', text: t }]);
    setInputText(''); setIsProcessing(true);
    wsSend({ type: 'text', text: t });
  };

  // ─── Helpers ───
  const statusColor = connectionStatus === 'connected' ? C.success : connectionStatus === 'connecting' ? C.warning : C.danger;
  const statusLabel = connectionStatus === 'connected' ? 'Online' : connectionStatus === 'connecting' ? 'Connecting...' : 'Offline';
  const orbIcon = isListening ? '\u23F9' : isProcessing ? '\u23F3' : isSpeaking ? '\uD83D\uDD0A' : '\uD83C\uDFA4';
  const orbHint = isListening ? 'Tap to stop' : isProcessing ? 'Thinking...' : isSpeaking ? 'Speaking...' : 'Tap to speak';

  const getGreeting = () => {
    const h = new Date().getHours();
    if (h < 12) return 'Good Morning';
    if (h < 17) return 'Good Afternoon';
    return 'Good Evening';
  };

  // ─── Render ───
  return (
    <View style={s.root}>
      <StatusBar style="dark" />
      <LinearGradient colors={['#ece9ff', '#f5f3ff', C.bg]} style={s.bgGrad} />

      {/* Header */}
      <View style={s.header}>
        <View>
          <Text style={s.greeting}>Hi There {'\uD83D\uDC4B'}</Text>
          <Text style={s.greetSub}>{getGreeting()}</Text>
        </View>
        <View style={s.headerRight}>
          <View style={[s.statusPill, { backgroundColor: statusColor + '20' }]}>
            <View style={[s.statusDot, { backgroundColor: statusColor }]} />
            <Text style={[s.statusLabel, { color: statusColor }]}>{statusLabel}</Text>
          </View>
        </View>
      </View>

      {activeTab === 'home' ? (
        /* ─── Home Tab ─── */
        <ScrollView style={s.homeScroll} showsVerticalScrollIndicator={false}>
          {/* Agent Card */}
          <View style={s.agentCard}>
            <LinearGradient colors={['#7c5cfc', '#a78bfa', '#c4b5fd']} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={s.agentCardGrad}>
              <Text style={s.agentCardName}>{config.AGENT_NAME}</Text>
              <Text style={s.agentCardSub}>Your AI Voice Assistant</Text>
              <TouchableOpacity style={s.agentCardBtn} onPress={() => setActiveTab('chat')}>
                <Text style={s.agentCardBtnText}>Start Chat {'\u2192'}</Text>
              </TouchableOpacity>
            </LinearGradient>
          </View>

          {/* Quick Actions */}
          <Text style={s.sectionTitle}>Quick Actions</Text>
          <View style={s.qActions}>
            {[
              { icon: '\uD83C\uDFA4', label: 'Voice Chat', action: () => { setActiveTab('chat'); } },
              { icon: '\uD83D\uDCAC', label: 'Text Chat', action: () => setActiveTab('chat') },
            ].map((a, i) => (
              <TouchableOpacity key={i} style={s.qAction} onPress={a.action} activeOpacity={0.7}>
                <View style={s.qActionIcon}><Text style={{ fontSize: 24 }}>{a.icon}</Text></View>
                <Text style={s.qActionLabel}>{a.label}</Text>
              </TouchableOpacity>
            ))}
          </View>

          {/* Features */}
          <Text style={s.sectionTitle}>Features</Text>
          {[
            { icon: '\uD83E\uDDE0', title: 'Smart Memory', desc: 'Remembers your preferences and past conversations' },
            { icon: '\uD83D\uDDE3\uFE0F', title: 'Voice Powered', desc: 'Natural voice interaction with real-time response' },
            { icon: '\uD83D\uDD27', title: 'Tool Calling', desc: 'Can perform actions like search, calculate, and more' },
          ].map((f, i) => (
            <View key={i} style={s.featureCard}>
              <View style={s.featureIcon}><Text style={{ fontSize: 22 }}>{f.icon}</Text></View>
              <View style={{ flex: 1 }}>
                <Text style={s.featureTitle}>{f.title}</Text>
                <Text style={s.featureDesc}>{f.desc}</Text>
              </View>
            </View>
          ))}
          {/* Hands-Free Mode */}
          <Text style={s.sectionTitle}>Hands-Free Mode</Text>
          <View style={s.featureCard}>
            <View style={s.featureIcon}><Text style={{ fontSize: 22 }}>{handsFreeEnabled ? '\uD83C\uDFA7' : '\uD83D\uDD07'}</Text></View>
            <View style={{ flex: 1 }}>
              <Text style={s.featureTitle}>Wake Word Detection</Text>
              <Text style={s.featureDesc}>
                {handsFreeEnabled
                  ? 'Say "' + wakeWords[0] + '" to start'
                  : 'Tap to enable always-on listening'}
              </Text>
            </View>
            <TouchableOpacity
              onPress={() => setHandsFreeEnabled(p => !p)}
              style={[s.toggleBtn, handsFreeEnabled && s.toggleBtnOn]}
            >
              <Text style={s.toggleBtnText}>{handsFreeEnabled ? 'ON' : 'OFF'}</Text>
            </TouchableOpacity>
          </View>
          <View style={{ height: 100 }} />
        </ScrollView>
      ) : (
        /* ─── Chat Tab ─── */
        <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined} keyboardVerticalOffset={20}>
          {/* Orb */}
          <View style={s.orbWrap}>
            <Animated.View style={[s.orbRing3, { opacity: ringAnim, transform: [{ scale: pulseAnim }, { translateY: orbFloat }] }]} />
            <Animated.View style={[s.orbRing2, { opacity: ringAnim, transform: [{ scale: pulseAnim }, { translateY: orbFloat }] }]} />
            <Animated.View style={[s.orbRing1, { transform: [{ scale: pulseAnim }, { translateY: orbFloat }] }]}>
              <TouchableOpacity onPress={handleOrb} activeOpacity={0.8} style={s.orbTouch}>
                <LinearGradient
                  colors={isListening ? ['#ef4444', '#dc2626'] : isSpeaking ? ['#f97316', '#ea580c'] : isProcessing ? ['#a78bfa', '#7c3aed'] : ['#7c5cfc', '#a78bfa']}
                  style={s.orbGrad}
                >
                  <Text style={s.orbIcon}>{orbIcon}</Text>
                </LinearGradient>
              </TouchableOpacity>
            </Animated.View>
            <Text style={s.orbHint}>{orbHint}</Text>
            {handsFreeEnabled && !isListening && !isProcessing && !isSpeaking && (
              <View style={s.ambientPill}>
                <View style={[s.ambientDot, { backgroundColor: ambientState === 'listening' ? C.warning : C.primaryLight }]} />
                <Text style={s.ambientText}>
                  {ambientState === 'listening' ? 'Listening...' :
                   inListenWindow ? 'Listening for follow-up...' :
                   'Say "' + (wakeWords[0] || 'hey agent') + '"'}
                </Text>
              </View>
            )}
          </View>

          {/* Reminder Banner */}
          {activeReminder && (
            <TouchableOpacity
              style={s.reminderBanner}
              onPress={() => setActiveReminder(null)}
              activeOpacity={0.8}
            >
              <Text style={s.reminderIcon}>🔔</Text>
              <Text style={s.reminderText} numberOfLines={2}>{activeReminder.text}</Text>
              <Text style={s.reminderDismiss}>✕</Text>
            </TouchableOpacity>
          )}

          {/* Messages */}
          <ScrollView ref={scrollRef} style={s.msgs} contentContainerStyle={s.msgsContent} showsVerticalScrollIndicator={false}>
            {messages.length === 0 && !streamingText && (
              <View style={s.empty}>
                <Text style={s.emptyIcon}>{'\uD83D\uDCAC'}</Text>
                <Text style={s.emptyTitle}>Start a conversation</Text>
                <Text style={s.emptySub}>Tap the mic or type below</Text>
              </View>
            )}
            {messages.map((m, i) => (
              <View key={i} style={[s.bubble, m.role === 'user' ? s.userBbl : m.role === 'system' ? s.sysBbl : s.asstBbl]}>
                <Text style={[s.bubbleText, m.role === 'user' ? s.userTxt : m.role === 'system' ? s.sysTxt : s.asstTxt]}>{m.text}</Text>
              </View>
            ))}
            {streamingText ? (
              <View style={[s.bubble, s.asstBbl]}>
                <Text style={[s.bubbleText, s.asstTxt]}>{streamingText}<Text style={{ color: C.primary }}>{'\u258D'}</Text></Text>
              </View>
            ) : null}
          </ScrollView>

          {/* Input */}
          <View style={s.inputWrap}>
            <View style={s.inputRow}>
              <TextInput
                style={s.input}
                value={inputText}
                onChangeText={setInputText}
                placeholder={connectionStatus === 'connected' ? 'Type a message...' : 'Connecting to server...'}
                placeholderTextColor={C.textMuted}
                returnKeyType="send"
                onSubmitEditing={handleSend}
              />
              <TouchableOpacity style={s.sendBtn} onPress={handleSend} disabled={!inputText.trim()}>
                <LinearGradient colors={inputText.trim() ? [C.primary, C.accent] : [C.border, C.border]} style={s.sendGrad}>
                  <Text style={s.sendIcon}>{'\u2191'}</Text>
                </LinearGradient>
              </TouchableOpacity>
            </View>
          </View>
        </KeyboardAvoidingView>
      )}

      {/* Bottom Nav */}
      <View style={s.nav}>
        {[
          { id: 'home', icon: '\uD83C\uDFE0', label: 'Home' },
          { id: 'chat', icon: '\uD83D\uDCAC', label: 'Chat' },
        ].map(tab => (
          <TouchableOpacity key={tab.id} style={s.navItem} onPress={() => setActiveTab(tab.id)} activeOpacity={0.7}>
            <Text style={{ fontSize: 22 }}>{tab.icon}</Text>
            <Text style={[s.navLabel, activeTab === tab.id && s.navLabelActive]}>{tab.label}</Text>
            {activeTab === tab.id && <View style={s.navDot} />}
          </TouchableOpacity>
        ))}
      </View>
    </View>
  );
}

// ─── Styles ───
const SHADOW = { shadowColor: C.shadow, shadowOffset: { width: 0, height: 4 }, shadowOpacity: 1, shadowRadius: 16, elevation: 6 };

const s = StyleSheet.create({
  root: { flex: 1, backgroundColor: C.bg },
  bgGrad: { position: 'absolute', top: 0, left: 0, right: 0, height: 300 },

  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingTop: 60, paddingHorizontal: 24, paddingBottom: 8 },
  greeting: { fontSize: 24, fontWeight: '700', color: C.text },
  greetSub: { fontSize: 14, color: C.textSec, marginTop: 2 },
  headerRight: { alignItems: 'flex-end' },
  statusPill: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 10, paddingVertical: 5, borderRadius: 20 },
  statusDot: { width: 7, height: 7, borderRadius: 4, marginRight: 5 },
  statusLabel: { fontSize: 11, fontWeight: '600' },

  homeScroll: { flex: 1, paddingHorizontal: 24 },
  agentCard: { marginTop: 20, borderRadius: 20, overflow: 'hidden', ...SHADOW },
  agentCardGrad: { padding: 28, borderRadius: 20 },
  agentCardName: { fontSize: 22, fontWeight: '800', color: '#fff' },
  agentCardSub: { fontSize: 14, color: '#ffffffcc', marginTop: 4 },
  agentCardBtn: { marginTop: 18, backgroundColor: '#ffffff30', alignSelf: 'flex-start', paddingHorizontal: 20, paddingVertical: 10, borderRadius: 24 },
  agentCardBtnText: { color: '#fff', fontWeight: '700', fontSize: 14 },
  sectionTitle: { fontSize: 17, fontWeight: '700', color: C.text, marginTop: 28, marginBottom: 14 },
  qActions: { flexDirection: 'row', gap: 16 },
  qAction: { alignItems: 'center', width: (SW - 72) / 4 },
  qActionIcon: { width: 56, height: 56, borderRadius: 18, backgroundColor: C.card, justifyContent: 'center', alignItems: 'center', ...SHADOW },
  qActionLabel: { fontSize: 11, color: C.textSec, marginTop: 8, fontWeight: '500' },
  featureCard: { flexDirection: 'row', backgroundColor: C.card, padding: 16, borderRadius: 16, marginBottom: 12, alignItems: 'center', ...SHADOW },
  featureIcon: { width: 44, height: 44, borderRadius: 14, backgroundColor: C.cardAlt, justifyContent: 'center', alignItems: 'center', marginRight: 14 },
  featureTitle: { fontSize: 15, fontWeight: '700', color: C.text },
  featureDesc: { fontSize: 12, color: C.textSec, marginTop: 2 },

  orbWrap: { alignItems: 'center', paddingTop: 16, paddingBottom: 4 },
  orbRing3: { position: 'absolute', top: 0, width: 150, height: 150, borderRadius: 75, backgroundColor: '#c4b5fd30' },
  orbRing2: { position: 'absolute', top: 12, width: 126, height: 126, borderRadius: 63, backgroundColor: '#c4b5fd50' },
  orbRing1: { width: 100, height: 100, borderRadius: 50, justifyContent: 'center', alignItems: 'center' },
  orbTouch: { width: 100, height: 100, borderRadius: 50 },
  orbGrad: { width: 100, height: 100, borderRadius: 50, justifyContent: 'center', alignItems: 'center', ...SHADOW },
  orbIcon: { fontSize: 32 },
  orbHint: { marginTop: 10, fontSize: 13, color: C.textMuted, fontWeight: '500' },

  msgs: { flex: 1, paddingHorizontal: 20 },
  msgsContent: { paddingBottom: 8 },
  empty: { alignItems: 'center', paddingTop: 30, opacity: 0.5 },
  emptyIcon: { fontSize: 36, marginBottom: 10 },
  emptyTitle: { fontSize: 17, fontWeight: '600', color: C.text },
  emptySub: { fontSize: 13, color: C.textSec, marginTop: 2 },

  bubble: { maxWidth: '82%', paddingHorizontal: 16, paddingVertical: 11, borderRadius: 20, marginVertical: 4 },
  userBbl: { alignSelf: 'flex-end', backgroundColor: C.userBubble, borderBottomRightRadius: 6 },
  asstBbl: { alignSelf: 'flex-start', backgroundColor: C.asstBubble, borderBottomLeftRadius: 6, ...SHADOW },
  sysBbl: { alignSelf: 'center', backgroundColor: C.cardAlt, borderRadius: 14 },
  bubbleText: { fontSize: 15, lineHeight: 22 },
  userTxt: { color: '#fff' },
  asstTxt: { color: C.text },
  sysTxt: { color: C.textSec, fontSize: 13, textAlign: 'center' },

  inputWrap: { paddingHorizontal: 20, paddingBottom: 4 },
  inputRow: { flexDirection: 'row', alignItems: 'center', backgroundColor: C.card, borderRadius: 28, paddingLeft: 20, paddingRight: 4, paddingVertical: 4, borderWidth: 1, borderColor: C.border, ...SHADOW },
  input: { flex: 1, height: 42, fontSize: 15, color: C.text },
  sendBtn: { marginLeft: 6 },
  sendGrad: { width: 42, height: 42, borderRadius: 21, justifyContent: 'center', alignItems: 'center' },
  sendIcon: { fontSize: 18, fontWeight: '800', color: '#fff' },

  nav: { flexDirection: 'row', justifyContent: 'space-around', paddingTop: 10, paddingBottom: Platform.OS === 'ios' ? 30 : 14, backgroundColor: C.card, borderTopWidth: 1, borderTopColor: C.border },
  navItem: { alignItems: 'center', paddingHorizontal: 20 },
  navLabel: { fontSize: 11, color: C.textMuted, marginTop: 2, fontWeight: '500' },
  navLabelActive: { color: C.primary, fontWeight: '700' },
  navDot: { width: 5, height: 5, borderRadius: 3, backgroundColor: C.primary, marginTop: 4 },

  toggleBtn: { paddingHorizontal: 14, paddingVertical: 7, borderRadius: 20, backgroundColor: C.border },
  toggleBtnOn: { backgroundColor: C.primary },
  toggleBtnText: { fontSize: 12, fontWeight: '700', color: '#fff' },

  ambientPill: { flexDirection: 'row', alignItems: 'center', marginTop: 8, backgroundColor: C.cardAlt, paddingHorizontal: 12, paddingVertical: 6, borderRadius: 20 },
  ambientDot: { width: 6, height: 6, borderRadius: 3, marginRight: 6 },
  ambientText: { fontSize: 12, color: C.textSec, fontWeight: '500' },

  reminderBanner: { flexDirection: 'row', alignItems: 'center', marginHorizontal: 20, marginBottom: 8, backgroundColor: '#fff7ed', borderRadius: 16, padding: 14, borderWidth: 1, borderColor: '#fed7aa', ...SHADOW },
  reminderIcon: { fontSize: 20, marginRight: 10 },
  reminderText: { flex: 1, fontSize: 14, color: '#92400e', fontWeight: '600' },
  reminderDismiss: { fontSize: 16, color: '#92400e', marginLeft: 8 },
});
