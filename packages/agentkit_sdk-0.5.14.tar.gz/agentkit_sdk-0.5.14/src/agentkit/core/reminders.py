"""
Reminder system for AgentKit.

Stores user reminders with trigger times and checks for due reminders.
Integrates with the proactive message system to notify users.

Usage:
    manager = ReminderManager()
    
    # Add a reminder
    reminder = await manager.add("user1", "Call Mom", minutes_from_now=30)
    
    # Check for due reminders
    due = await manager.check_due("user1")
    for r in due:
        print(f"🔔 {r.text}")
    
    # List all active reminders
    active = await manager.list("user1")
    
    # Cancel a reminder
    await manager.cancel("user1", reminder.id)
"""

from __future__ import annotations

import asyncio
import json
import os
from dataclasses import dataclass, field, asdict
from datetime import datetime, timedelta
from pathlib import Path
from typing import Callable, Dict, List, Optional
from uuid import uuid4


@dataclass
class Reminder:
    """A single reminder."""
    id: str
    user_id: str
    text: str
    trigger_at: str  # ISO format string for JSON serialization
    created_at: str  # ISO format string
    fired: bool = False
    cancelled: bool = False

    @property
    def trigger_datetime(self) -> datetime:
        return datetime.fromisoformat(self.trigger_at)

    @property
    def is_due(self) -> bool:
        return not self.fired and not self.cancelled and datetime.now() >= self.trigger_datetime

    @property
    def is_active(self) -> bool:
        return not self.fired and not self.cancelled

    def time_until(self) -> str:
        """Human-readable time until reminder fires."""
        delta = self.trigger_datetime - datetime.now()
        if delta.total_seconds() <= 0:
            return "now"
        minutes = int(delta.total_seconds() / 60)
        if minutes < 60:
            return f"{minutes}m"
        hours = minutes // 60
        mins = minutes % 60
        if hours < 24:
            return f"{hours}h {mins}m" if mins else f"{hours}h"
        days = hours // 24
        return f"{days}d {hours % 24}h"


class ReminderManager:
    """Manages user reminders with JSON file persistence."""

    def __init__(self, storage_dir: str = "memory"):
        self._storage_path = Path(storage_dir) / "reminders.json"
        self._reminders: Dict[str, List[Reminder]] = {}  # user_id -> reminders
        self._lock = asyncio.Lock()
        self._load()

    def _load(self):
        """Load reminders from disk."""
        if self._storage_path.exists():
            try:
                with open(self._storage_path) as f:
                    data = json.load(f)
                for user_id, items in data.items():
                    self._reminders[user_id] = [
                        Reminder(**item) for item in items
                    ]
            except (json.JSONDecodeError, Exception):
                self._reminders = {}

    async def _save(self):
        """Persist reminders to disk."""
        self._storage_path.parent.mkdir(parents=True, exist_ok=True)
        data = {}
        for user_id, reminders in self._reminders.items():
            data[user_id] = [asdict(r) for r in reminders]
        with open(self._storage_path, "w") as f:
            json.dump(data, f, indent=2)

    async def add(self, user_id: str, text: str, minutes_from_now: float = 0,
                  trigger_at: Optional[datetime] = None) -> Reminder:
        """Add a new reminder.
        
        Args:
            user_id: The user who set the reminder
            text: What to remind about
            minutes_from_now: Minutes from now to trigger (if trigger_at not set)
            trigger_at: Exact datetime to trigger (overrides minutes_from_now)
        """
        async with self._lock:
            if trigger_at is None:
                trigger_at = datetime.now() + timedelta(minutes=max(minutes_from_now, 0.5))

            reminder = Reminder(
                id=str(uuid4())[:8],
                user_id=user_id,
                text=text,
                trigger_at=trigger_at.isoformat(),
                created_at=datetime.now().isoformat(),
            )

            if user_id not in self._reminders:
                self._reminders[user_id] = []
            self._reminders[user_id].append(reminder)
            await self._save()
            return reminder

    async def get_all(self, user_id: str) -> List[Reminder]:
        """List all active (unfired, uncancelled) reminders for a user."""
        reminders = self._reminders.get(user_id, [])
        return [r for r in reminders if r.is_active]

    async def cancel(self, user_id: str, reminder_id: str) -> bool:
        """Cancel a reminder by ID. Returns True if found and cancelled."""
        async with self._lock:
            for r in self._reminders.get(user_id, []):
                if r.id == reminder_id and r.is_active:
                    r.cancelled = True
                    await self._save()
                    return True
            return False

    async def check_due(self, user_id: str) -> List[Reminder]:
        """Check for and return due reminders, marking them as fired."""
        async with self._lock:
            due = []
            for r in self._reminders.get(user_id, []):
                if r.is_due:
                    r.fired = True
                    due.append(r)
            if due:
                await self._save()
            return due

    async def check_all_users(self) -> Dict[str, List[Reminder]]:
        """Check due reminders for all users. Returns {user_id: [due_reminders]}."""
        async with self._lock:
            result = {}
            changed = False
            for user_id, reminders in self._reminders.items():
                due = []
                for r in reminders:
                    if r.is_due:
                        r.fired = True
                        due.append(r)
                        changed = True
                if due:
                    result[user_id] = due
            if changed:
                await self._save()
            return result

    async def cleanup(self, max_age_days: int = 30):
        """Remove old fired/cancelled reminders."""
        async with self._lock:
            cutoff = datetime.now() - timedelta(days=max_age_days)
            for user_id in list(self._reminders.keys()):
                self._reminders[user_id] = [
                    r for r in self._reminders[user_id]
                    if r.is_active or datetime.fromisoformat(r.created_at) > cutoff
                ]
                if not self._reminders[user_id]:
                    del self._reminders[user_id]
            await self._save()
