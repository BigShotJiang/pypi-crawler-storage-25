"""AgentKit — Developer SDK for building personalized voice AI assistants.

Quick start::

    from agentkit import Agent

    agent = Agent(
        persona="You are a helpful assistant",
        llm_provider="gemini",
        llm_api_key="your-key",
    )
    response = await agent.chat("Hello!")
    print(response.text)

Full docs: https://github.com/your-org/agentkit
"""

__version__ = "0.5.6"

# ------------------------------------------------------------------
# Primary API — what most users will import
# ------------------------------------------------------------------
from agentkit.agent import Agent, AgentResponse

# ------------------------------------------------------------------
# Core building blocks (for advanced / custom usage)
# ------------------------------------------------------------------
from agentkit.core.pipeline import VoicePipeline, PipelineConfig, Turn
from agentkit.core.tools import ToolRegistry, ToolDef
from agentkit.core.context import ContextAssembler, MemoryContext

# ------------------------------------------------------------------
# Provider system
# ------------------------------------------------------------------
from agentkit.providers import registry
from agentkit.providers.llm.base import BaseLLM, Message
from agentkit.providers.stt.base import BaseSTT
from agentkit.providers.tts.base import BaseTTS
from agentkit.memory.base import BaseMemory

# ------------------------------------------------------------------
# Convenience re-exports for type hints and custom providers
# ------------------------------------------------------------------
__all__ = [
    # Primary
    "Agent",
    "AgentResponse",
    # Core
    "VoicePipeline",
    "PipelineConfig",
    "Turn",
    "ToolRegistry",
    "ToolDef",
    "ContextAssembler",
    "MemoryContext",
    # Providers
    "registry",
    "BaseLLM",
    "BaseSTT",
    "BaseTTS",
    "BaseMemory",
    "Message",
]