###### tcwhk

安全、简单、零依赖的随机密钥生成器。

安装

```bash
pip install tcwhk
```

使用

```bash
# 生成默认 20 位密钥
ra

# 指定长度
ra 32

# 32 位，不含符号
ra 32 3

# 纯数字 + 字母，关符号
ra 24 3

# 纯数字，关字母、关符号
ra 16 2 3

# 纯字母，关数字、关符号
ra 16 1 3

# 兼容旧格式
ra generate 32
```

模式说明

· 1 关闭数字
· 2 关闭字母
· 3 关闭符号

可多模式组合，例如 1 3 表示关闭数字和符号

与 text_discoloration 的关系

tcwhk 的核心功能也集成在 text_discoloration 中：

```python
from text_discoloration import ra_key

ra_key()                    # 默认 20 位
ra_key(length=32)           # 32 位
ra_key(no_symbol=True)      # 不含符号
```

协议

MIT