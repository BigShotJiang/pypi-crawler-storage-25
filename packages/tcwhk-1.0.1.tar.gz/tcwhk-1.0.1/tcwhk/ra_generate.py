import secrets
import sys

letter_pool = 'qwertyuiopasdfghjklzxcvbnm'
num_pool    = '0123456789'
symbol_pool = '!@#$%^&*_+-=[]{}|;:,.<>?'

def build_pool(close_list):
    use_letter = True
    use_num    = True
    use_symbol = True

    if 1 in close_list:
        use_num = False
    if 2 in close_list:
        use_letter = False
    if 3 in close_list:
        use_symbol = False

    if not use_letter and not use_num and not use_symbol:
        return None

    pool = ""
    if use_letter:
        pool += letter_pool
    if use_num:
        pool += num_pool
    if use_symbol:
        pool += symbol_pool
    return pool

def create_key(length=20, close_list=None):
    if close_list is None:
        close_list = []
    pool = build_pool(close_list)
    if pool is None:
        return "错误：不能同时关闭字母、数字、符号全部三项"
    return ''.join(secrets.choice(pool) for _ in range(length))

def show_help():
    print("===== tcwhk 密钥生成器 =====")
    print("用法：ra [长度] [模式...]")
    print("      ra generate [长度] [模式...]  （兼容旧格式）")
    print("默认长度：20位")
    print("模式说明：")
    print("  1 关闭数字")
    print("  2 关闭字母")
    print("  3 关闭符号")
    print("示例：")
    print("  ra               生成默认20位")
    print("  ra 32            指定32位")
    print("  ra 32 3          32位，关闭符号")
    print("  ra generate 32   兼容旧格式")

def main():
    args = sys.argv[1:]

    if args and args[0] == "generate":
        args = args[1:]

    if not args:
        show_help()
        return

    length = 20
    close_list = []

    for arg in args:
        if arg.isdigit():
            length = int(arg)
        elif arg in ('1', '2', '3'):
            close_list.append(int(arg))

    print(create_key(length, close_list))

if __name__ == "__main__":
    main()