
# DeepFuel-kit: AI-Guided Formulation of Next-Generation Sustainable Fuels

**DeepFuel-kit** is an open-source Python library for AI-guided formulation of next-generation sustainable fuels.

[![License](https://img.shields.io/github/license/RodolfosmFreitas/deepfuel)](https://github.com/RodolfosmFreitas/deepfuel/blob/main/LICENSE)
![Python](https://img.shields.io/badge/python-3.11%2B-blue)
![PyPI](https://img.shields.io/pypi/v/deepfuel)
![Downloads](https://img.shields.io/pypi/dm/deepfuel)
![DOI](https://zenodo.org/badge/DOI/10.5281/zenodo.20045282.svg)](https://doi.org/10.5281/zenodo.20045282)

## Features

## Installation

```bash
pip install deepfuel
```

## Requirements

## Quick start

## Contributing

## Citation


