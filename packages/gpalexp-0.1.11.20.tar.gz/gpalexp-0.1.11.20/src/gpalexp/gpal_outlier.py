from sklearn.gaussian_process import GaussianProcessRegressor
import numpy as np
from scipy.stats import norm
import numpy.typing as npt
import warnings
warnings.filterwarnings('ignore')

def gpal_outlier(gpr: GaussianProcessRegressor, 
                   fit_data_X: npt.NDArray, 
                   obs_data_Y: npt.NDArray,
                   predict_candidate_X: npt.NDArray,
                   num_trials: int, 
                   burn_in: int, 
                   alpha: float,
                   return_std: bool = True):
    
    in_data_X=fit_data_X[:burn_in+1]  # Initialization
    in_data_Y=obs_data_Y[:burn_in+1]  # Initialization : 0-th data to burn_in-th data
    

    ## The fitting is conducted with 0-th data to tIdx-th data
    for tIdx in range(num_trials-1): # 0 - 18
        
        if tIdx<burn_in:
            gpr.fit(fit_data_X[:tIdx+1], obs_data_Y[:tIdx+1])
            continue

        ## Outlier detection branch
        ## every iteration as long as tIdx >= burn_in
        if tIdx%1==0:
            ## fit_data_X[num_data]: The data point newly added
            gpr.fit(in_data_X, in_data_Y)
            post_mean_per_data, post_std_per_data=gpr.predict(fit_data_X[:tIdx+1], return_std=True)
            exclude_index=[]
            ## Check the posterior mean and std at each data point
            for i, in_x in enumerate(fit_data_X[:tIdx+1]):
                #idx_in_x = in_x//5-1
                pm = post_mean_per_data[i]
                pstd = post_std_per_data[i]
                post_prob=norm.cdf(obs_data_Y[i], loc=pm, scale=pstd)
                #print(f"Post_probability: {post_prob}")
                if (post_prob<alpha/2 or post_prob>1-alpha/2):
                    exclude_index.append(i)

            ## tIdx is always in include_index
            ## This is to prevent the newly added point (fit_data_X[tIdx]) being classified as an outlier
            include_index=np.array([i for i in range(tIdx+1) if not i in exclude_index], dtype=int)
            in_data_X=fit_data_X[include_index]
            in_data_Y=obs_data_Y[include_index]
            
    gpr.fit(in_data_X, in_data_Y)
    kernel_params = np.exp(gpr.kernel_.theta)
    if return_std:
        post_mean, post_std=gpr.predict(predict_candidate_X.reshape(-1,1), return_std=return_std)
        return post_mean, post_std
    else:
        post_mean = gpr.predict(predict_candidate_X.reshape(-1,1), return_std=return_std)
        return post_mean