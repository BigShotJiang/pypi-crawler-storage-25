from __future__ import annotations
import traceback
from dataclasses import dataclass
from types import SimpleNamespace
from typing import Any, Callable, Dict, Iterable, List, Mapping, MutableMapping, Optional, Sequence, Tuple, Union
import os
import matplotlib.pyplot as plt
import pickle

import numpy as np
import numpy.typing as npt
from scipy.stats import norm
from scipy.special import log_ndtr
from scipy.optimize import minimize
from scipy.linalg import cho_factor, cho_solve
from sklearn.gaussian_process import GaussianProcessRegressor
import pandas as pd
import pickle

from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import RBF, ConstantKernel, WhiteKernel

from copy import deepcopy
try:
    from scipy.cluster.vq import kmeans2
except Exception:  # pragma: no cover
    kmeans2 = None


#ArrayLike = Union[np.ndarray, Sequence[float], Sequence[Sequence[float]]]
ArrayLike = npt.NDArray[np.float64]

@dataclass
class MonotonicHooks:
    """
    Backend hooks that replace gpstuff-specific MATLAB functions.

    You should supply Python equivalents for the original gpstuff routines:
      - lik_probit
      - lik_liks
      - gp_set
      - gp_optim
      - gp_pred
      - gpep_e('clearcache', gp)

    Example:
        hooks = MonotonicHooks(
            lik_probit=lik_probit_py,
            lik_liks=lik_liks_py,
            gp_set=gp_set_py,
            gp_optim=gp_optim_py,
            gp_pred=gp_pred_py,
            clear_cache=clear_cache_py,
        )
    """
    lik_gaussian: Callable[..., Any]
    lik_probit: Callable[..., Any]
    lik_liks: Callable[..., Any]
    gp_set: Callable[..., MutableMapping[str, Any]]
    gp_optim: Callable[..., MutableMapping[str, Any]]
    gp_pred: Callable[..., np.ndarray]
    clear_cache: Callable[[MutableMapping[str, Any]], None]
    optimf: Optional[Callable[..., Any]] = None


def _as_2d_numeric(arr: ArrayLike) -> Optional[np.ndarray]:
    if arr is None:
        return None
    out = np.asarray(arr, dtype=float)
    if out.ndim == 1:
        out = out[:, None]
    if not np.isfinite(out).all():
        raise ValueError(f"{arr} must contain only finite real values.")
    return out


def _default_opt() -> Dict[str, Any]:
    return {"ftol": 1e-4, "gtol": 1e-4, "maxiter": 50, "Display": "iter"}


def _cvit(n: int, nblocks: int) -> List[np.ndarray]:
    """
    Rough Python equivalent of the MATLAB cvit helper used in gpstuff here.
    It splits indices into approximately equal contiguous blocks.
    """
    indices = np.arange(n, dtype=int)
    return [block for block in np.array_split(indices, nblocks)]


def _sign_from_nvd(nvd: np.ndarray) -> np.ndarray:
    if np.any(nvd == 0):
        raise ValueError("nvd cannot contain zero; use positive for increasing and negative for decreasing.")
    return np.sign(nvd).astype(float)


def set_up_data_for_monotonic(
    gp: MutableMapping[str, Any],
    x: ArrayLike,
    y: ArrayLike,
    z: Optional[ArrayLike] = None,
    xtt: Optional[ArrayLike] = None,
    ztt: Optional[ArrayLike] = None,
) -> Tuple[MutableMapping[str, Any], np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """
    Python translation of MATLAB subfunction `setUpDataForMonotonic`.

    Returns
    -------
    gp, x_out, y_out, z_out, xtt_out, ztt_out
    """
    x = _as_2d_numeric(x)
    y = _as_2d_numeric(y)
    z = _as_2d_numeric(z)
    xtt = _as_2d_numeric(xtt)
    ztt = _as_2d_numeric(ztt)

    xv = _as_2d_numeric(gp.get("xv"))
    if xv is None:
        raise ValueError("gp['xv'] must be set before calling set_up_data_for_monotonic().")

    gp_nvd = np.asarray(gp["nvd"], dtype=float).ravel()
    nvd_len = len(gp_nvd)
    xt = np.concatenate([x, np.zeros((x.shape[0], 1))], axis=1)
    yt = y.copy()

    for i in range(nvd_len):
        dim_code = abs(gp_nvd[i]) * np.ones((xv.shape[0], 1))
        xt = np.concatenate([xt, np.concatenate([xv, dim_code], axis=1)], axis=0)
        yi = np.sign(gp_nvd[i]) * np.ones((xv.shape[0], 1))
        yt = np.concatenate([yt, yi], axis=0)
    

    ## xt: (N+M, d+1), where xt[:N,:d] = x, xt[N:,:d] = xv, xt[:N,d] = 0 and xt[N:,d]=1
    ## yt: (N+M, 1), where yt[:N] = y and yt[N:] = +-1 depending on np.sign(gp_nvd[i])

    if z is not None:
        class_col_obs = np.ones((x.shape[0], 1))
        class_col_virtual = 2 * np.ones((nvd_len * xv.shape[0], 1))
        zt = np.concatenate(
            [
                np.concatenate([z, class_col_obs], axis=1),
                np.concatenate([np.zeros((nvd_len * xv.shape[0], z.shape[1])), class_col_virtual], axis=1),
            ],
            axis=0,
        )
    else:
        zt = np.concatenate(
            [
                np.zeros((x.shape[0], 1)),
                np.ones((nvd_len * xv.shape[0], 1)),
            ],
            axis=0,
        )

    ## zt: (N + nvd_len*M, 1) where zt[:N] = 0 and zt[N:] = 1
    ## This encodes whether the k-th observation is an ordinary one or a virtual one
    ## 0 represents the ordinary; 1 represents the virtual one.
    ## In gpstuff zt[:N] = 1 and zt[N:] = 2 since MATLAB indices start from 1.

    gp["monotonic"] = False

    if xtt is None:
        xtt_out = np.empty((0, x.shape[1] + 1), dtype=float)
    else:
        xtt_out = xtt.copy()
        if xtt_out.shape[1] != xt.shape[1]:
            xtt_out = np.concatenate([xtt_out, np.zeros((xtt_out.shape[0], 1))], axis=1)

    ## xtt_out: An uninitialized array of shape (0, d+1) - assuming that we do not provide xtt

    class_variables = gp["lik"].class_variables
    if ztt is None:
        ztt_out = np.empty((0, class_variables), dtype=float)
    else:
        ztt_out = ztt.copy()
        if ztt_out.shape[1] < class_variables:
            ztt_out = np.concatenate([ztt_out, np.ones((ztt_out.shape[0], 1))], axis=1)

    ## ztt_out: An uninitialized array of shape (0, d+1) - assuming that we do not provide ztt

    return gp, xt, yt, zt, xtt_out, ztt_out


#####################################################
################# EP-related funcs ##################
#####################################################

@dataclass
class EPState:
    tau_tilde: npt.NDArray[np.float64]
    nu_tilde: npt.NDArray[np.float64]
    mu: npt.NDArray[np.float64]
    Sigma: npt.NDArray[np.float64]
    logZ: float
    logZ_terms: np.ndarray
    m_cav: np.ndarray
    v_cav: np.ndarray

## probit likelihood: to be applied to latent values from virtual observations.
## y should have +1 or -1 depending on the g_latent:
## if g_latent is positive, then y = +1 should be likely
## if g_latent is negative, then y = -1 should be likely
## lik[k] = The likelihood of g_latent[k] having derivative of +1.

class probit_likelihood:
    def __init__(self, nu:float = 1e-6):
        self.nu = nu
    
    def log_prob(self, g_latent:npt.NDArray[np.float64], y:npt.NDArray[np.float64]):
        
        return log_ndtr(y*g_latent / self.nu)
    
    def moments(self, m_cav: float, v_cav: float, y: float):
        if y not in (-1.0, 1.0):
            raise ValueError("Probit labels must be -1 or +1.")

        s = np.sqrt(v_cav + self.nu ** 2)
        z = y * m_cav / s

        Z = norm.cdf(z)
        Z = max(Z, 1e-16)
        logZ = np.log(Z)

        ratio = norm.pdf(z) / Z

        # first derivative of log Z wrt m_cav
        alpha = y * ratio / s

        # second derivative relation
        beta = -(ratio * (z + ratio)) / (s ** 2)

        mean_tilt = m_cav + v_cav * alpha
        var_tilt = v_cav - (v_cav ** 2) * (alpha ** 2 - 2.0 * beta)

        var_tilt = max(var_tilt, 1e-12)

        return logZ, mean_tilt, var_tilt


## Gaussian likelihood: to be applied to latent values from ordinary observations.

class gaussian_likelihood:
    def __init__(self, sigma: float):
        self.sigma = sigma

    def log_prob(self, f_latent:npt.NDArray[np.float64], y:npt.NDArray[np.float64]):
        f_latent = f_latent.reshape(-1,1)
        y = y.reshape(-1,1)
        if f_latent.shape != y.shape:
            raise ValueError(f"f_latent and y should have the same shape")
        
        log_lik = (-1/2)*np.log(2*np.pi)-np.log(self.sigma+1e-10) - (y-f_latent)**2/(2*self.sigma**2)
        return log_lik

    def moments(self, m_cav: float, v_cav: float, y: float):
        sigma2 = self.sigma ** 2

        # tilted variance and mean from product of Gaussians
        prec = 1.0 / v_cav + 1.0 / sigma2
        var_tilt = 1.0 / prec
        mean_tilt = var_tilt * (m_cav / v_cav + y / sigma2)

        # normalization constant Z = N(y | m_cav, v_cav + sigma^2)
        logZ = norm.logpdf(y, loc=m_cav, scale=np.sqrt(v_cav + sigma2))

        return logZ, mean_tilt, var_tilt



## z_t should be fed as an argument corresponding to the 'labels' parameter.
## For ordinary data: z_t = 0 -> Gaussian likelihood
## For virtual data: z_t = 1 -> Probit likelihood
class combined_likelihood:
    def __init__(self, likelihoods, class_variables, sigma = 1.0, nu = 1e-6):

        self.likelihoods = likelihoods
        self.class_variables = class_variables
        self.g_lik = gaussian_likelihood(sigma)
        self.p_lik = probit_likelihood(nu)

    def log_likelihood_terms(self, latent: npt.NDArray[np.float64], y_latent:npt.NDArray[np.float64], labels:npt.NDArray[np.int32]):
        
        if latent.ndim!=2:
            raise ValueError(f"latent should be a 2-dimensional array, got {latent.ndim} dimension(s)")
        if y_latent.ndim!=2:
            raise ValueError(f"y_latent should be a 2-dimensioanl array, got {y_latent.ndim} dimension(s)")
        if labels.ndim!=1:
            raise ValueError(f"labels should be a 1-dimensional array, got {labels.ndim} dimension(s)")
        
        latent = latent.reshape(-1)
        y_latent = y_latent.reshape(-1)
        
        K = latent.shape[0]
        if y_latent.shape[0] != K:
            raise ValueError(f"X_latent and y_latent should contain equal number of vectors; got {K} and {y_latent.shape[0]}")
        if labels.shape[0] != K:
            raise ValueError(f"labels should have the length of {K}, got {labels.shape[0]}")
        if not np.all(np.isin(labels, [0,1])):
            raise ValueError(f"labels should contain only 0 and 1.")

        likelihood = np.empty_like(latent, dtype=float)

        mask_g = (labels == 0)
        mask_p = (labels == 1)

        if np.any(mask_g):
            likelihood[mask_g] = self.likelihoods[0].log_prob(latent[mask_g], y_latent[mask_g])
        if np.any(mask_p):
            likelihood[mask_p] = self.likelihoods[1].log_prob(latent[mask_p], y_latent[mask_p])

        return likelihood

    def moments(self, m_cav: float, v_cav: float, y: float, label: int):
        #if label == 0:
        #    return self.g_lik.moments(m_cav, v_cav, y)
        #elif label == 1:
        #    return self.p_lik.moments(m_cav, v_cav, y)
        #else:
        #    raise ValueError(f"Unknown label {label}. Expected 0 or 1.")
        lik = self.likelihoods[label]
        return lik.moments(m_cav, v_cav, y)


def recompute_posterior(
    K: npt.NDArray[np.float64],
    tau_tilde: npt.NDArray[np.float64],
    nu_tilde: npt.NDArray[np.float64],
):
    n = K.shape[0]
    S_half = np.sqrt(np.maximum(tau_tilde, 0.0))

    # B = I + S^{1/2} K S^{1/2}
    B = np.eye(n) + (S_half[:, None] * K) * S_half[None, :]
    cB, low = cho_factor(B, lower=True, check_finite=False)

    # Sigma = K - K S^{1/2} B^{-1} S^{1/2} K
    KS = K * S_half[None, :]
    tmp = cho_solve((cB, low), (S_half[:, None] * K), check_finite=False)
    Sigma = K - KS @ tmp

    mu = Sigma @ nu_tilde
    return mu, Sigma



def cavity_params(mu_i: float, var_i: float, tau_tilde_i: float, nu_tilde_i: float):
    tau_post = 1.0 / max(var_i, 1e-12)
    nu_post = mu_i / max(var_i, 1e-12)

    tau_cav = tau_post - tau_tilde_i
    if tau_cav <= 0:
        tau_cav = 1e-12

    nu_cav = nu_post - nu_tilde_i

    v_cav = 1.0 / tau_cav
    m_cav = nu_cav / tau_cav
    return m_cav, v_cav



def update_site(
    m_cav: float,
    v_cav: float,
    m_tilt: float,
    v_tilt: float,
    tau_old: float,
    nu_old: float,
    damping: float = 0.5,
):
    tau_new = 1.0 / max(v_tilt, 1e-12) - 1.0 / max(v_cav, 1e-12)
    nu_new = m_tilt / max(v_tilt, 1e-12) - m_cav / max(v_cav, 1e-12)

    # stabilize
    tau_new = max(tau_new, 0.0) 

    tau_upd = (1.0 - damping) * tau_old + damping * tau_new
    nu_upd = (1.0 - damping) * nu_old + damping * nu_new

    tau_cap = 1e6
    tau_upd = np.clip(tau_upd, 0.0, tau_cap)
    nu_cap = 1e3   # or smaller, tune this
    nu_upd = np.clip(nu_upd, -nu_cap, nu_cap)

    return tau_upd, nu_upd


def ep_log_marginal_likelihood(K, ep_state):
    tau = ep_state.tau_tilde
    nu = ep_state.nu_tilde
    mu = ep_state.mu
    logZ_terms = ep_state.logZ_terms
    v_cav = ep_state.v_cav

    S_half = np.sqrt(np.maximum(tau, 0.0))
    B = np.eye(K.shape[0]) + (S_half[:, None] * K) * S_half[None, :]
    signB, logdetB = np.linalg.slogdet(B)
    if signB <= 0:
        return -np.inf

    corr_arg = np.maximum(tau * v_cav, -1.0 + 1e-12)


    val = (
        -0.5 * logdetB
        + 0.5 * (nu @ mu)
        + np.sum(logZ_terms)
        - 0.5 * np.sum(np.log1p(corr_arg))
    )
    return float(val)

def ep_inference(
    K: npt.NDArray[np.float64],
    y: npt.NDArray[np.float64],
    labels: npt.NDArray[np.int32],
    likelihood: combined_likelihood,
    max_iter: int = 100,
    tol: float = 1e-6,
    damping: float = 0.5,
    verbose: bool = False,
) -> EPState:
    K = np.asarray(K, dtype=float)
    y = np.asarray(y, dtype=float).reshape(-1)
    labels = np.asarray(labels, dtype=int).reshape(-1)

    n = len(y)
    tau_tilde = np.zeros(n, dtype=float)
    nu_tilde = np.zeros(n, dtype=float)

    logZ_terms = np.zeros(n, dtype=float)
    m_cav_terms = np.zeros(n, dtype=float)
    v_cav_terms = np.zeros(n, dtype=float)

    mu = np.zeros(n, dtype=float)
    Sigma = K.copy()

    prev_mu = mu.copy()

    for it in range(max_iter):
        for i in range(n):
            var_i = Sigma[i, i]
            mu_i = mu[i]

            m_cav, v_cav = cavity_params(mu_i, var_i, tau_tilde[i], nu_tilde[i])

            logZ_i, m_tilt, v_tilt = likelihood.moments(
                m_cav=m_cav,
                v_cav=v_cav,
                y=y[i],
                label=labels[i],
            )

            logZ_terms[i] = logZ_i
            m_cav_terms[i] = m_cav
            v_cav_terms[i] = v_cav

            tau_tilde[i], nu_tilde[i] = update_site(
                m_cav, v_cav, m_tilt, v_tilt,
                tau_tilde[i], nu_tilde[i],
                damping=damping,
            )

            mu, Sigma = recompute_posterior(K, tau_tilde, nu_tilde)

        delta = np.max(np.abs(mu - prev_mu))
        prev_mu = mu.copy()

        if verbose:
            print(f"EP iter {it+1}: max |Δmu| = {delta:.3e}")

        if delta < tol:
            break

    # symmetrize / stabilize a bit
    Sigma = 0.5 * (Sigma + Sigma.T)
    Sigma = Sigma + 1e-12 * np.eye(Sigma.shape[0])

    ep_state = EPState(
        tau_tilde=tau_tilde,
        nu_tilde=nu_tilde,
        mu=mu,
        Sigma=Sigma,
        logZ=np.nan,  # temporary
        logZ_terms=logZ_terms,
        m_cav=m_cav_terms,
        v_cav=v_cav_terms,
    )

    ep_state.logZ = ep_log_marginal_likelihood(K, ep_state)
    return ep_state


def posterior_latent_summary(ep_state):
    mean = ep_state.mu
    var = np.clip(np.diag(ep_state.Sigma), 0.0, None)
    std = np.sqrt(var)
    return mean, var, std



def ep_predict(
    K_train: np.ndarray,
    K_cross: np.ndarray,
    K_test: np.ndarray,
    ep_state,
):
    """
    Predictive mean and covariance under Gaussian EP approximation.

    Parameters
    ----------
    K_train : (N, N)
        Prior covariance of training latent vector u.
    K_cross : (N, M)
        Prior cross-covariance between training latents u and query latents u_*.
    K_test : (M, M)
        Prior covariance of query latents u_*.
    ep_state :
        Must contain:
          - mu: (N,)
          - Sigma: (N, N)

    Returns
    -------
    pred_mean : (M,)
    pred_cov  : (M, M)
    pred_std  : (M,)
    """
    cK, low = cho_factor(K_train, lower=True, check_finite=False)

    Kinv_mu = cho_solve((cK, low), ep_state.mu, check_finite=False)
    pred_mean = K_cross.T @ Kinv_mu

    Kinv_Kcross = cho_solve((cK, low), K_cross, check_finite=False)

    pred_cov = (
        K_test
        - K_cross.T @ Kinv_Kcross
        + K_cross.T @ cho_solve((cK, low), ep_state.Sigma @ Kinv_Kcross, check_finite=False)
    )

    pred_var = np.clip(np.diag(pred_cov), 0.0, None)
    pred_std = np.sqrt(pred_var)

    return pred_mean, pred_cov, pred_std


def make_function_queries(X: npt.NDArray[np.float64]) -> np.ndarray:
    """
    Convert ordinary input points X of shape (N, D) into augmented
    function-value queries of shape (N, D+1).
    """
    X = np.asarray(X, dtype=float)
    return np.column_stack([X, np.zeros(X.shape[0], dtype=float)])


def make_derivative_queries(X: npt.NDArray[np.float64], deriv_dim: int) -> np.ndarray:
    """
    Convert input points X of shape (N, D) into augmented derivative queries.

    Parameters
    ----------
    deriv_dim : int
        Zero-based Python dimension index.
        Stored in augmented column as deriv_dim + 1.
    """
    X = np.asarray(X, dtype=float)
    return np.column_stack([X, np.full(X.shape[0], deriv_dim + 1, dtype=float)])


def predict_augmented(
    gp: MutableMapping[str, Any],
    X_train_aug: npt.NDArray[np.float64],
    X_query_aug: npt.NDArray[np.float64],
    ep_state,
    *,
    jitter: float | None = None,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """
    Predict latent mean/cov/std at arbitrary augmented query points.

    Parameters
    ----------
    gp : dict
        GP model dictionary. Expected fields:
          gp["kernel"]["variance"]
          gp["kernel"]["length_scale"]
          gp["kernel"].get("white", ...)
    X_train_aug : (N, D+1)
        Augmented inputs used in the EP latent system.
    X_query_aug : (M, D+1)
        Augmented query inputs.
    ep_state : object
        EP posterior state with fields:
          mu    : (N,)
          Sigma : (N, N)
    jitter : optional float
        Extra diagonal stabilization added to K_train and K_test.

    Returns
    -------
    pred_mean : (M,)
    pred_cov  : (M, M)
    pred_std  : (M,)
    """
    X_train_aug = np.asarray(X_train_aug, dtype=float)
    X_query_aug = np.asarray(X_query_aug, dtype=float)

    K_train = build_augmented_kernel(gp, X_train_aug, X_train_aug)
    K_cross = build_augmented_kernel(gp, X_train_aug, X_query_aug)
    K_test = build_augmented_kernel(gp, X_query_aug, X_query_aug)

    #if jitter is None:
    #    jitter = float(gp["kernel"].get("white", 1e-8))
    jitter = 1e-6
    white_noise = np.exp(gp["kernel"].get("log_white", np.log(1e-2)))
    K_train = K_train + (jitter + white_noise) * np.eye(K_train.shape[0], dtype=float)
    K_test = K_test + (jitter + white_noise) * np.eye(K_test.shape[0], dtype=float)

    return ep_predict(K_train, K_cross, K_test, ep_state)

############################################################
################# End of EP-related funcs ##################
############################################################




# gp = hooks.gp_set(gp, lik=lik, deriv=x.shape[1] + 1)
# gp = hooks.gp_set(gp, latent_method="EP", jitterSigma2=1e-6)
def gp_set(gp: MutableMapping[str, Any], **kwargs: Any) -> MutableMapping[str, Any]:
    """
    Return an updated GP dictionary.

    This mimics gpstuff's 'gp_set' role:
    update model configuration fields like likelihood, deriv,
    latent_method, jitterSigma2, etc.
    """
    gp_new = deepcopy(gp)

    for key, value in kwargs.items():
        gp_new[key] = value

    # optional: ensure some nested defaults exist
    gp_new.setdefault("cache", {})
    gp_new.setdefault("latent_opt", {})
    gp_new.setdefault("fh", {})

    return gp_new


def clear_cache(gp: MutableMapping[str, Any]) -> None:
    gp["cache"] = {}
    return None


def gp_pack(gp: MutableMapping[str, Any]) -> np.ndarray:
    """
    Pack optimizable hyperparameters into a 1D vector.
    Use log-parameters for positivity constraints.
    """
    kernel = gp["kernel"]
    theta = []

    theta.append(kernel["log_variance"])
    theta.append(kernel["log_length_scale"])
    theta.append(kernel["log_white"])

    ## The sigma of the Gaussian likelihood will be treated as constant
    
    #lik = gp["lik"]
    #if hasattr(lik, "g_lik") and hasattr(lik.g_lik, "sigma"):
    #    theta.append(np.log(lik.g_lik.sigma))
    #elif hasattr(lik, "sigma"):
    #    theta.append(np.log(lik.sigma))

    return np.asarray(theta, dtype=float)


def gp_unpack(gp: MutableMapping[str, Any], theta: np.ndarray) -> MutableMapping[str, Any]:
    """
    Return a copy of gp with hyperparameters overwritten by theta.
    """
    gp_new = gp_set(gp)  # deep copy
    kernel = gp_new["kernel"]

    idx = 0
    kernel["log_variance"] = float(theta[idx]); idx += 1

    kernel["log_length_scale"] = float(theta[idx])
    idx += 1

    kernel["log_white"] = float(theta[idx]); idx += 1


    #lik = gp_new["lik"]
    #if hasattr(lik, "g_lik") and hasattr(lik.g_lik, "sigma"):
    #    lik.g_lik.sigma = float(np.exp(theta[idx])); idx += 1
    #elif hasattr(lik, "sigma"):
    #    lik.sigma = float(np.exp(theta[idx])); idx += 1

    return gp_new


## X1: The first input matrix with a shape of (N,d)
## X2: The second input matrix with a shape of (M,d)  
## length_scale: Length scale parameter. Set to anisotropic by default. Should be of shape (d,).
## Return: The anistropic kernel matrix for given X1 and X2
def rbf_anisotropic(X1:npt.NDArray[np.float64], X2:npt.NDArray[np.float64], 
                   log_length_scale:npt.NDArray[np.float64]|float):
    
    if isinstance(log_length_scale, float):
        length_scale = np.exp(np.array([log_length_scale], dtype=np.float64))
    else:
        length_scale = np.exp(log_length_scale)
    d = length_scale.shape[0]

    if X1.ndim!=2:
        raise ValueError
    if X2.ndim!=2:
        raise ValueError
    if length_scale.ndim!=1:
        raise ValueError
    
    if isinstance(length_scale, float):
        length_scale = np.array([length_scale for _ in range(d)])

    if X1.shape[1]!=d:
        raise ValueError
    if X2.shape[1]!=d:
        raise ValueError
    
    ## Goal: (N, M, d)
    X1_broad = np.expand_dims(X1, 1)
    X2_broad = np.expand_dims(X2, 0)
    X_diff = X1_broad - X2_broad
    distance_matrix= np.sum(X_diff**2/np.expand_dims(length_scale**2, (0,1)), axis=-1)

    kernel_matrix = np.exp(-0.5*distance_matrix)

    return kernel_matrix
    


## X1: Array of function values, of shape (N,d)
## X2: Array of derivative values, of shape (M,d)
def function_derivative_kernel_RBF(X1:npt.NDArray[np.float64], X2:npt.NDArray[np.float64], 
                                   log_length_scale:npt.NDArray[np.float64]|float,
                                   monotonic_dim:int):
    N = X1.shape[0]
    M = X2.shape[0]
    d = X1.shape[1]
    if isinstance(log_length_scale, float):
        length_scale = np.exp(np.array([log_length_scale], dtype=np.float64))
    else:
        length_scale = np.exp(log_length_scale)

    kernel = rbf_anisotropic(X1, X2, log_length_scale) # (N,M)
    
    X1_broad = np.expand_dims(X1, 1)
    X2_broad = np.expand_dims(X2, 0)
    X_diff = (X1_broad - X2_broad)[:,:,monotonic_dim] # (N, M)
    
    fd_kernel = kernel*X_diff/(length_scale[monotonic_dim]**2)
    return fd_kernel


def derivative_kernel_RBF(X1:npt.NDArray[np.float64], X2:npt.NDArray[np.float64],
                          log_length_scale:npt.NDArray[np.float64]|float,
                          monotonic_dim:int):
    
    d = X1.shape[1]
    if isinstance(log_length_scale, float):
        length_scale = np.exp(np.array([log_length_scale], dtype=np.float64))
    else:
        length_scale = np.exp(log_length_scale)

    kernel = rbf_anisotropic(X1, X2, log_length_scale) # (N,M)

    X1_broad = np.expand_dims(X1, 1)
    X2_broad = np.expand_dims(X2, 0)
    X_diff = (X1_broad - X2_broad)[:,:,monotonic_dim] # (N, M)
    
    monotonic_scale = length_scale[monotonic_dim]
    dd_kernel = kernel*(1/(monotonic_scale**2) - (X_diff**2)/(monotonic_scale**4))

    return dd_kernel


def build_kernel_ff(gp: MutableMapping[str, Any], X1: np.ndarray, X2: np.ndarray) -> np.ndarray:
    ker = gp["kernel"]
    return np.exp(ker["log_variance"]+1e-6) * rbf_anisotropic(X1, X2, log_length_scale = ker["log_length_scale"])


def build_kernel_fg(gp: MutableMapping[str, Any], Xf: np.ndarray, Xg: np.ndarray, dim: int) -> np.ndarray:
    ker = gp["kernel"]
    return np.exp(ker["log_variance"]+1e-6) * function_derivative_kernel_RBF(
        Xf, Xg, log_length_scale=ker["log_length_scale"], monotonic_dim=dim
    )


def build_kernel_gg(gp: MutableMapping[str, Any], Xg1: np.ndarray, Xg2: np.ndarray, dim: int) -> np.ndarray:
    ker = gp["kernel"]
    return np.exp(ker["log_variance"]+1e-6) * derivative_kernel_RBF(
        Xg1, Xg2, log_length_scale=ker["log_length_scale"], monotonic_dim=dim
    )



def split_augmented_input(X_aug: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    """
    X_aug: (N, D+1)
    First D columns are spatial input.
    Last column is query type:
      0 -> function value
      1..D -> derivative wrt that dimension (1-based style)
    """
    X_aug = np.asarray(X_aug, dtype=float)
    X_base = X_aug[:, :-1]
    qtype = X_aug[:, -1].astype(int)
    return X_base, qtype


## It supposed monotonicity across 0-th dimension
## refer to qj-1 and qi-1 branch

def build_augmented_kernel(gp: MutableMapping[str, Any], X_aug_1: np.ndarray, X_aug_2: np.ndarray) -> np.ndarray:
    """
    Build covariance between arbitrary augmented latent queries.
    Supports:
      function-function
      function-derivative
      derivative-function
      derivative-derivative
    """
    X1, q1 = split_augmented_input(X_aug_1)
    X2, q2 = split_augmented_input(X_aug_2)

    N1 = X1.shape[0]
    N2 = X2.shape[0]
    K = np.zeros((N1, N2), dtype=float)

    for i in range(N1):
        for j in range(N2):
            qi = q1[i]
            qj = q2[j]

            xi = X1[i:i+1]
            xj = X2[j:j+1]

            if qi == 0 and qj == 0:
                K[i, j] = build_kernel_ff(gp, xi, xj)[0, 0]
            elif qi == 0 and qj > 0:
                K[i, j] = build_kernel_fg(gp, xi, xj, dim=qj - 1)[0, 0]
            elif qi > 0 and qj == 0:
                # Cov(g_qi(xi), f(xj)) = transpose relation
                K[i, j] = build_kernel_fg(gp, xj, xi, dim=qi - 1)[0, 0]
            else:
                # both derivative queries
                if qi != qj:
                    raise NotImplementedError(
                        "Cross-dimension derivative covariance not implemented yet."
                    )
                K[i, j] = build_kernel_gg(gp, xi, xj, dim=qi - 1)[0, 0]

    return K

def gp_pred(
    gp: MutableMapping[str, Any],
    x_train: np.ndarray,
    y_train: np.ndarray,
    x_test: np.ndarray,
    *,
    z: np.ndarray | None = None,
) -> np.ndarray:
    """
    Return posterior mean of latent quantities at x_test.

    Parameters
    ----------
    gp : dict
        GP model
    x_train : (N, D_aug)
        Augmented training inputs
    y_train : (N, 1) or (N,)
        Training targets / pseudo-labels
    x_test : (M, D_aug)
        Augmented test inputs
    z : optional metadata / labels

    Returns
    -------
    mean_test : (M,)
        Posterior mean for the requested latent quantity.
    """
    x_train = np.asarray(x_train, dtype=float)
    x_test = np.asarray(x_test, dtype=float)
    y_train = np.asarray(y_train, dtype=float).reshape(-1)

    K = build_augmented_kernel(gp, x_train, x_train)
    Ks = build_augmented_kernel(gp, x_train, x_test)

    #jitter = gp["kernel"].get("white", 1e-6) + gp.get("jitterSigma2", 0.0)
    jitter = 1e-6
    white_noise = np.exp(gp["kernel"].get("log_white", np.log(1e-2)))
    K = K + (jitter + white_noise) * np.eye(K.shape[0])

    L = np.linalg.cholesky(K)
    alpha = np.linalg.solve(L.T, np.linalg.solve(L, y_train))

    mean_test = Ks.T @ alpha
    return mean_test


def gp_pred_ep(
    gp: MutableMapping[str, Any],
    x_train: np.ndarray,
    y_train: np.ndarray,
    x_test: np.ndarray,
    *,
    z: np.ndarray | None = None,
):
    if "ep_state" not in gp:
        raise ValueError("gp['ep_state'] is missing. Run EP first and store it in gp.")

    ep_state = gp["ep_state"]

    x_train = np.asarray(x_train, dtype=float)
    x_test = np.asarray(x_test, dtype=float)

    mu = np.asarray(ep_state.mu, dtype=float).reshape(-1)
    Sigma = np.asarray(ep_state.Sigma, dtype=float)

    K = build_augmented_kernel(gp, x_train, x_train)
    Ks = build_augmented_kernel(gp, x_train, x_test)
    Kss = build_augmented_kernel(gp, x_test, x_test)

    jitter = np.exp(gp["kernel"].get("log_white", np.log(1e-2))) + gp.get("jitterSigma2", 1e-6)
    K = K + jitter * np.eye(K.shape[0])

    L = np.linalg.cholesky(K)

    Kinv_mu = np.linalg.solve(L.T, np.linalg.solve(L, mu))
    Kinv_Ks = np.linalg.solve(L.T, np.linalg.solve(L, Ks))

    mean_test = Ks.T @ Kinv_mu

    Sigma_Kinv_Ks = Sigma @ Kinv_Ks
    Kinv_Sigma_Kinv_Ks = np.linalg.solve(L.T, np.linalg.solve(L, Sigma_Kinv_Ks))

    pred_cov = Kss - Ks.T @ Kinv_Ks + Ks.T @ Kinv_Sigma_Kinv_Ks

    pred_var = np.maximum(np.diag(pred_cov), 0.0)
    std_test = np.sqrt(pred_var)

    return mean_test, std_test

def gp_objective(
    theta: np.ndarray,
    gp: MutableMapping[str, Any],
    x_train: np.ndarray,
    y_train: np.ndarray,
    *,
    z: np.ndarray | None = None,
) -> float:
    LARGE_PENALTY = 1e12

    try:
        gp_cur = gp_unpack(gp, theta)
        clear_cache(gp_cur)

        x_train = np.asarray(x_train, dtype=float)
        y_vec = np.asarray(y_train, dtype=float).reshape(-1)

        if z is None:
            raise ValueError("z must be provided for the combined likelihood objective.")
        labels = np.asarray(z, dtype=int).reshape(-1)

        if x_train.shape[0] != y_vec.shape[0]:
            return LARGE_PENALTY
        if labels.shape[0] != y_vec.shape[0]:
            return LARGE_PENALTY

        K = build_augmented_kernel(gp_cur, x_train, x_train)
        diag_noise = np.zeros(K.shape[0], dtype=float)
        diag_noise[labels == 0] = np.exp(gp_cur['kernel']['log_white'])
        K = K + np.diag(diag_noise) + 1e-6 * np.eye(K.shape[0])
        #K = K + (white_noise + 1e-6) * np.eye(K.shape[0])
        K = 0.5 * (K + K.T)

        try:
            np.linalg.cholesky(K)
        except np.linalg.LinAlgError:
            return LARGE_PENALTY

        ep_state = ep_inference(
            K=K,
            y=y_vec,
            labels=labels,
            likelihood=gp_cur["lik"],
        )

        obj = -ep_state.logZ

        if not np.isfinite(obj):
            return LARGE_PENALTY

        return float(obj)

    except Exception:
        traceback.print_exc()
        return LARGE_PENALTY


def gp_optim(
    gp: MutableMapping[str, Any],
    x_train: np.ndarray,
    y_train: np.ndarray,
    *,
    opt: MutableMapping[str, Any] | None = None,
    z: np.ndarray | None = None,
    optimf=None,
) -> MutableMapping[str, Any]:
    """
    Optimize GP hyperparameters and return updated gp.
    """
    theta0 = gp_pack(gp)



    # If caller provided a custom optimizer, let it handle things.
    if optimf is not None:
        result_theta = optimf(
            theta0,
            lambda th: gp_objective(th, gp, x_train, y_train, z=z),
        )
        gp_new = gp_unpack(gp, np.asarray(result_theta, dtype=float))
        clear_cache(gp_new)
        return gp_new
    else:
        options = {}
        if opt is not None:
            if "MaxIter" in opt:
                options["maxiter"] = opt["MaxIter"]
            if "TolFun" in opt:
                options["ftol"] = opt["TolFun"]
        # Default scipy optimizer
        res = minimize(
            fun=lambda th: gp_objective(th, gp, x_train, y_train, z=z),
            x0=theta0,
            #method="L-BFGS-B",
            method = "Powell",
            ## log_variance, log_length_scale, log_white
            bounds = [(np.log(1e-3), np.log(1e3)),
                    (np.log(1e1), np.log(1e3)),
                    (np.log(1e-3), np.log(1e-1))],
            options = {

            }
        )
        print("gp_optim result x:", np.exp(res.x))
        print("gp_optim delta:", res.x - theta0)
        print("gp_optim success:", res.success)
        print("gp_optim message:", res.message)
        print("gp_optim objective:", res.fun)
        print("gp_optim nit:", res.nit)

        gp_new = gp_unpack(gp, res.x)
        clear_cache(gp_new)
        gp_new["optim_result"] = res

    x_train = np.asarray(x_train, dtype=float)
    y_vec = np.asarray(y_train, dtype=float).reshape(-1)

    labels = np.asarray(z, dtype=int)
    if labels.ndim == 2:
        labels = labels[:, 0]
    labels = labels.reshape(-1)

    K = build_augmented_kernel(gp_new, x_train, x_train)
    white_noise = np.exp(gp_new["kernel"].get("log_white", np.log(1e-2)))
    K = K + (white_noise + 1e-6) * np.eye(K.shape[0])
    K = 0.5 * (K + K.T)

    gp_new["ep_state"] = ep_inference(
        K=K,
        y=y_vec,
        labels=labels,
        likelihood=gp_new["lik"],
    )

    clear_cache(gp_new)
    return gp_new


def monotonicity_probability(mean_deriv: np.ndarray, std_deriv: np.ndarray, mono_sign: float, nu: float = 1e-6):
    var = std_deriv ** 2
    return norm.cdf(mono_sign*mean_deriv / np.sqrt(var + nu ** 2))


def gp_monotonic(
    gp: MutableMapping[str, Any],
    x: ArrayLike,
    y: ArrayLike,
    pred_cand_X: ArrayLike,
    *,
    hooks: MonotonicHooks,
    freq: int = 1,
    max_new_points: int = 40,
    z: Optional[ArrayLike] = None,
    sigma_gaussian: float = 1.0,
    nu_probit: float = 1e-6,
    nv: Optional[int] = None,
    init: str = "sample",
    xv: Optional[ArrayLike] = None,
    force: bool = True,
    display: bool = True,
    optimf: Optional[Callable[..., Any]] = None,
    opt: Optional[Mapping[str, Any]] = None,
    optimize: str = "off",
    nvd: Optional[Sequence[float]] = None,
    p_threshold: float = 0.95,
    random_state: Optional[int] = None,
) -> MutableMapping[str, Any]:
    """
    Python translation of gpstuff's gp_monotonic.m.

    This function preserves the MATLAB logic as closely as practical, but the
    original gpstuff-specific internals are injected through `hooks`.

    Parameters
    ----------
    gp
        GP structure represented as a mutable dictionary-like object.
    x, y
        Training inputs and targets.
    hooks
        Python replacements for gpstuff-specific functions.
    z
        Optional auxiliary observed quantity.
    nu
        Strictness of monotonicity information. Smaller means stricter.
    nv
        Number of virtual observations at initialization.
    init
        'sample' or 'kmeans' for the initialization of virtual observation locations.
    xv
        Optional initial virtual observation locations. If given, these are used.
    force
        If True, keep adding virtual observations until monotonicity holds at the training points.
    display
        If True, print progress messages.
    optimf
        Optimizer handle forwarded to the backend `gp_optim`.
    opt
        Optimizer options dictionary.
    optimize
        'on' or 'off'.
    nvd
        Monotonic dimensions. Positive means increasing, negative means decreasing.
        Example: [1, -2] means increasing wrt dim 1 and decreasing wrt dim 2.
    random_state
        Seed for reproducible sampling.

    Returns
    -------
    gp
        Modified GP structure.
    """
    if not isinstance(gp, MutableMapping):
        raise TypeError("gp must be a mutable mapping, e.g. a dict.")

    x = _as_2d_numeric(x)
    y = _as_2d_numeric(y)
    z = _as_2d_numeric(z)
    pred_cand_X = _as_2d_numeric(pred_cand_X)
    xv = _as_2d_numeric(xv)



    if nu_probit <= 0:
        raise ValueError("nu must be positive.")
    if init not in {"sample", "kmeans"}:
        raise ValueError("init must be either 'sample' or 'kmeans'.")
    if optimize not in {"on", "off"}:
        raise ValueError("optimize must be 'on' or 'off'.")
    if x is None or y is None:
        raise ValueError("x and y are required.")
    if x.shape[0] != y.shape[0]:
        raise ValueError("x and y must have the same number of rows.")

    rng = np.random.default_rng(random_state)

    
    if xv is not None:
        gp["xv"] = xv
    

    #base_lik = gp["lik"]
    lik = hooks.lik_liks(
        likelihoods=[hooks.lik_gaussian(sigma = sigma_gaussian), hooks.lik_probit(nu=nu_probit)],
        class_variables=1,
    )
           
    #lik = gp['lik']
    gp = hooks.gp_set(gp, lik=lik, deriv=x.shape[1] + 1)
    gp["monotonic"] = True
    gp.setdefault("fh", {})
    gp["fh"]["setUpDataForMonotonic"] = set_up_data_for_monotonic

    y_mean = np.mean(y)
    y_std = np.std(y)
    y = (y - y_mean)/(y_std+1e-6)
    gp["y_mean"] = y_mean
    gp["y_std"] = y_std

    # Set the virtual observations
    if nv is None:
        nv = int(np.floor(0.25 * x.shape[0]))

    if nvd is not None:
        gp["nvd"] = np.asarray(nvd, dtype=float).ravel()
    else:
        if "nvd" not in gp:
            gp["nvd"] = np.arange(1, x.shape[1] + 1, dtype=float)

    gp_nvd = np.asarray(gp["nvd"], dtype=float).ravel()
    nvd_len = len(gp_nvd)


    if opt is None or "TolX" not in opt:
        opt = _default_opt()
    else:
        opt = dict(opt)

    if gp.get("latent_method", "").upper() != "EP":
        if display:
            print("Switching the latent method to EP.")
        gp = hooks.gp_set(gp, latent_method="EP")

    gp.setdefault("latent_opt", {})
    gp["latent_opt"]["init_prev"] = "off"
    gp["latent_opt"]["maxiter"] = 100

    hooks.clear_cache(gp)

    optimizer_handle = optimf if optimf is not None else hooks.optimf
    #if optimize == "on":
    
    outer_iter = 0
    if force:
        ## Initial testing failed: Initial optimization
        #print(f"Initial optimization")
        
        if display:
            print(f"Initializing xv with {nv} seed data points, with init={init}.")
        if xv is None:
            if init == "sample":
                if nv > x.shape[0]:
                    raise ValueError("nv cannot exceed the number of observations when init='sample'.")
                perm = rng.permutation(x.shape[0])
                gp["xv"] = x[perm[:nv]].copy()
            else:
                if kmeans2 is None:
                    raise ImportError("scipy is required for init='kmeans'.")
                # Similar in spirit to MATLAB kmeans(..., 'Start','uniform', 'EmptyAction','singleton')
                centroids, _ = kmeans2(x, nv, minit="points")
                gp["xv"] = np.asarray(centroids, dtype=float)

        xv = _as_2d_numeric(gp["xv"])
        #xv = make_derivative_queries(gp["xv"], 0)

        if display:
            print(f"xv has been initialized.")
            print(f"xv: {xv}")

        gp, x_aug, y_aug, z_aug, _, _ = set_up_data_for_monotonic(
                                                                    gp=gp,
                                                                    x=x,
                                                                    y=y,
                                                                    z=z,
                                                                    xtt=None,
                                                                    ztt=None,
                                                                    )


        if optimize == "on" and outer_iter%freq==0:
            print(f"Optimizing the GP")
            gp = hooks.gp_optim(gp, x_aug, y_aug, opt=opt, z=z_aug, optimf=optimizer_handle)

        K_train = build_augmented_kernel(gp, x_aug, x_aug)
        noise = np.exp(gp["kernel"].get("log_white", np.log(1e-2)))
        K_train = K_train + (1e-6 + noise) * np.eye(K_train.shape[0])

        gp["ep_state"] = ep_inference(
            K=K_train,
            y=y_aug.reshape(-1),
            labels=z_aug.reshape(-1),
            likelihood=gp["lik"],
        )

        print(f"Testing the monotonicity of the optimized output")


        yv = _sign_from_nvd(gp_nvd)

        eps_count = 1
        while True: 
            x_check = x
            x_test_check = make_derivative_queries(x_check, 0)
            mean_check, std_check = gp_pred_ep(gp, x_aug, y_aug, x_test_check, z=z_aug)

            prob_check = monotonicity_probability(
                mean_check,
                std_check,
                mono_sign=float(yv[0]),
                nu = nu_probit
            )

            min_prob_check = np.min(prob_check)
            #print(f"Minimum check probability: {min_prob_check}")

            if outer_iter%freq==0:
                print(f"Check probabilities: {prob_check}")


            if min_prob_check > p_threshold:
                if display:
                    print("Stopping criterion satisfied on x and sparse check grid.")
                break

           
            x_cand = np.linspace(5.0, 500.0, 100, dtype=np.float64).reshape(-1, 1)
            batch_size = 4

            
            # --------------------------------------------------
            # 2. Candidate pool for adding new virtual points
            # --------------------------------------------------
            #x_cand = np.linspace(5.0, 500.0, 100, dtype=np.float64).reshape(-1, 1)
            #x_cand = np.concatenate([x, x_cand], axis=0).reshape(-1,1)

            x_test_cand = make_derivative_queries(x_cand, 0)

            mean_cand, std_cand = gp_pred_ep(gp, x_aug, y_aug, x_test_cand, z=z_aug)

            prob_cand = monotonicity_probability(
                mean_cand,
                std_cand,
                mono_sign=float(yv[0]),
                nu = nu_probit
            )

            violating_cand = prob_cand < p_threshold

            if not np.any(violating_cand):
                if display:
                    print("No violating candidate points found, although check set still failed.")
                break

            candidate_points = x_cand
            candidate_probs = prob_cand

            ## exclude points already used as virtual observations
            is_old = np.any(
                np.isclose(candidate_points[:, 0][:, None], xv[:, 0][None, :], atol=1e-10),
                axis=1,
            )
            is_new = ~is_old
            new_points = candidate_points[is_new]
            new_probs = candidate_probs[is_new]
            
            ## remove duplicates inside candidate set
            new_points, unique_idx = np.unique(new_points, axis=0, return_index=True)
            new_probs = new_probs[unique_idx]

            if len(new_points) == 0:
                print(f"No more virtual data points to add")
                break

            else:
                new_order = np.argsort(new_probs)
                print(f"new order: {new_order}")
                chosen_points = new_points[new_order[:min(batch_size, len(new_points))]]

            print(f"Chosen points: {chosen_points}")
            xv = np.unique(np.concatenate([xv, chosen_points], axis=0), axis=0)

            if display:
                print(f"Added {len(chosen_points)} new virtual observations.")
                print(f"Total virtual observations: {len(xv)}")

            if xv.shape[0] >= max_new_points:
                print(f"The length of xv is larger than {max_new_points}.")
                print(f"Monotonicity Optimization ended.")
                break

            outer_iter += 1
            
            xv = _as_2d_numeric(xv)
            gp["xv"] = xv
            gp, x_aug, y_aug, z_aug, _, _ = set_up_data_for_monotonic(
                                                                    gp=gp,
                                                                    x=x,
                                                                    y=y,
                                                                    z=z,
                                                                    xtt=None,
                                                                    ztt=None,
                                                                    )



            hooks.clear_cache(gp)
            print(f"Optimizing the GP")
            if optimize == "on" and outer_iter%freq==0:
                gp = hooks.gp_optim(gp, x_aug, y_aug, opt=opt, z=z_aug, optimf=optimizer_handle)
                print(f"Optimization operation conducted.")

            print(f"Conducting EP update")

            K_train = build_augmented_kernel(gp, x_aug, x_aug)
            noise = np.exp(gp["kernel"].get("log_white", np.log(1e-2)))
            K_train = K_train + (1e-6 + noise) * np.eye(K_train.shape[0])

            gp["ep_state"] = ep_inference(
                K=K_train,
                y=y_aug.reshape(-1),
                labels=z_aug.reshape(-1),
                likelihood=gp["lik"],
            )

            
            
        
        K_train = build_augmented_kernel(gp, x_aug, x_aug)
        noise = np.exp(gp["kernel"].get("log_white", np.log(1e-2)))
        K_train = K_train + (1e-6+noise)* np.eye(K_train.shape[0])

        ep_state = ep_inference(K=K_train, 
                                y=y_aug.reshape(-1), 
                                labels=z_aug.reshape(-1), 
                                likelihood = gp['lik'])
        gp['ep_state'] = ep_state

        x_pred = make_function_queries(pred_cand_X.reshape(-1,1))
        mean_test, std_test = gp_pred_ep(gp = gp,
                                        x_train = x_aug,
                                        y_train = y_aug.reshape(-1),
                                        x_test = x_pred)
        gp["pred_mean"] = mean_test * gp["y_std"] + gp["y_mean"]
        gp["pred_std"] = std_test * gp["y_std"]
        gp["pred_X"] = x_pred

    return gp




def _find_kernel(kernel, cls):
    """Recursively find the first sub-kernel of type cls."""
    if isinstance(kernel, cls):
        return kernel
    if hasattr(kernel, "k1"):
        out = _find_kernel(kernel.k1, cls)
        if out is not None:
            return out
    if hasattr(kernel, "k2"):
        out = _find_kernel(kernel.k2, cls)
        if out is not None:
            return out
    return None


def _sklearn_gpr_to_gp_dict(gpr: GaussianProcessRegressor) -> dict:
    """
    Convert a fitted sklearn GaussianProcessRegressor into the GP-like
    dictionary expected by your gp_monotonic().
    """
    if not hasattr(gpr, "kernel_"):
        raise ValueError("gpr must be fitted before conversion. Call gpr.fit(X, y) first.")

    kernel = gpr.kernel_

    rbf = _find_kernel(kernel, RBF)
    if rbf is None:
        raise ValueError("Currently gpal_monotonic() expects an RBF kernel in gpr.kernel_.")

    const = _find_kernel(kernel, ConstantKernel)
    white = _find_kernel(kernel, WhiteKernel)

    variance = const.constant_value if const is not None else 1.0
    length_scale = np.asarray(rbf.length_scale, dtype=float)

    if length_scale.ndim == 0:
        length_scale = np.array([float(length_scale)])

    if white is not None:
        noise = float(white.noise_level)
    else:
        alpha = np.asarray(gpr.alpha, dtype=float)
        noise = float(alpha.mean()) if alpha.ndim > 0 else float(alpha)

    gp = {
        "kernel": {
            "log_variance": float(np.log(variance)),
            "log_length_scale": np.log(length_scale).astype(float),
            "log_white": float(np.log(noise + 1e-12)),
        },
        "cache": {},
        "latent_opt": {},
        "fh": {},
    }

    return gp


class MonotonicGaussianProcessRegressor(GaussianProcessRegressor):
    """
    A sklearn-compatible object whose predict() method uses the monotonic
    EP posterior stored in mono_gp_.
    """

    def __init__(self, base_gpr: GaussianProcessRegressor, mono_gp: dict, X_train_raw, y_train_raw):
        self.base_gpr = deepcopy(base_gpr)
        self.__dict__.update(deepcopy(base_gpr.__dict__))

        self.mono_gp_ = mono_gp
        self.X_train_raw_ = np.asarray(X_train_raw, dtype=float)
        self.y_train_raw_ = np.asarray(y_train_raw, dtype=float).reshape(-1, 1)

    def predict(self, X, return_std=False, return_cov=False):
        if return_cov:
            raise NotImplementedError("return_cov=True is not implemented for the EP monotonic wrapper.")

        X = np.asarray(X, dtype=float)
        if X.ndim == 1:
            X = X[:, None]

        gp = self.mono_gp_

        y_norm = (self.y_train_raw_ - gp["y_mean"]) / (gp["y_std"] + 1e-6)

        gp_tmp, x_aug, y_aug, z_aug, _, _ = set_up_data_for_monotonic(
            gp=gp,
            x=self.X_train_raw_,
            y=y_norm,
            z=None,
            xtt=None,
            ztt=None,
        )

        x_test_aug = make_function_queries(X)

        mean_norm, std_norm = gp_pred_ep(
            gp=gp_tmp,
            x_train=x_aug,
            y_train=y_aug.reshape(-1),
            x_test=x_test_aug,
            z=z_aug,
        )

        mean = mean_norm * gp["y_std"] + gp["y_mean"]
        std = std_norm * gp["y_std"]

        if return_std:
            return mean.reshape(-1), std.reshape(-1)
        return mean.reshape(-1)


def gpal_monotonic(
    gpr: GaussianProcessRegressor,
    X: ArrayLike,
    y: ArrayLike,
    pred_cand_X=None,
    *,
    freq:int=1,
    max_new_points:int=40,
    nvd=[1],
    nv=None,
    xv=None,
    init="sample",
    force=True,
    optimize="off",
    p_threshold=0.95,
    sigma_gaussian=None,
    nu_probit=1e-6,
    random_state=None,
    display=True,
):
    """
    Convert an sklearn GaussianProcessRegressor into a monotonic EP-based
    GaussianProcessRegressor-like object.

    Notes
    -----
    - Positive nvd means increasing monotonicity.
    - Negative nvd means decreasing monotonicity.
    - Your current gp_monotonic() implementation is effectively written for
      monotonicity along the 0-th input dimension.
    """
    X = np.asarray(X, dtype=float)
    y = np.asarray(y, dtype=float).reshape(-1, 1)

    if X.ndim == 1:
        X = X[:, None]

    if not hasattr(gpr, "kernel_"):
        gpr = deepcopy(gpr)
        gpr.fit(X, y.reshape(-1))

    if pred_cand_X is None:
        pred_cand_X = X.copy()
    else:
        pred_cand_X = np.asarray(pred_cand_X, dtype=float)
        if pred_cand_X.ndim == 1:
            pred_cand_X = pred_cand_X[:, None]

    gp = _sklearn_gpr_to_gp_dict(gpr)

    if sigma_gaussian is None:
        sigma_gaussian = np.sqrt(np.exp(gp["kernel"]["log_white"]))

    hooks = MonotonicHooks(
        lik_gaussian=gaussian_likelihood,
        lik_probit=probit_likelihood,
        lik_liks=combined_likelihood,
        gp_set=gp_set,
        gp_optim=gp_optim,
        gp_pred=gp_pred_ep,
        clear_cache=clear_cache,
        optimf=None,
    )

    mono_gp = gp_monotonic(
        gp=gp,
        x=X,
        y=y,
        pred_cand_X=pred_cand_X,
        hooks=hooks,
        freq=freq,
        max_new_points=max_new_points,
        sigma_gaussian=sigma_gaussian,
        nu_probit=nu_probit,
        nv=nv,
        xv=xv,
        init=init,
        force=force,
        display=display,
        optimize=optimize,
        nvd=nvd,
        p_threshold=p_threshold,
        random_state=random_state,
    )

    return MonotonicGaussianProcessRegressor(
        base_gpr=gpr,
        mono_gp=mono_gp,
        X_train_raw=X,
        y_train_raw=y,
    )