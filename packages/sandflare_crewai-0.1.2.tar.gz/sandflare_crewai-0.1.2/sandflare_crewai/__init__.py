"""
sandflare-crewai
~~~~~~~~~~~~~~~~
CrewAI tool for Sandflare Firecracker microVM sandboxes.

Usage:
    from sandflare_crewai import SandflareTool
    from crewai import Agent, Task, Crew

    tool = SandflareTool(api_key="pa_live_...")

    coder = Agent(
        role="Python Developer",
        goal="Write and run Python code to answer questions",
        tools=[tool],
        llm="gpt-4o",
    )
    task = Task(
        description="Calculate the 50th Fibonacci number",
        agent=coder,
    )
    Crew(agents=[coder], tasks=[task]).kickoff()
"""
from __future__ import annotations

from typing import Optional, Type

from crewai.tools import BaseTool
from pydantic import BaseModel, Field

try:
    from sandflare import Sandbox
except ImportError as e:
    raise ImportError(
        "sandflare package is required. Install with: pip install sandflare"
    ) from e


class _CodeInput(BaseModel):
    code: str = Field(description="Python code to execute in the Sandflare sandbox")


class SandflareTool(BaseTool):
    """CrewAI tool that executes Python code inside an isolated Sandflare microVM.

    Each call spins up a fresh Firecracker VM, runs the code, returns output,
    then immediately deletes the VM. Safe for running LLM-generated or user-provided code.
    """

    name: str = "Sandflare Code Executor"
    description: str = (
        "Execute Python code safely in an isolated Firecracker microVM. "
        "Returns stdout and stderr. Use for calculations, data analysis, "
        "installing packages, cloning repos, or any code execution task."
    )
    args_schema: Type[BaseModel] = _CodeInput

    api_key: Optional[str] = None
    template_id: str = ""

    def _run(self, code: str) -> str:
        sb = Sandbox.create(
            api_key=self.api_key,
            template_id=self.template_id,
        )
        try:
            sb.write_file("/tmp/_sf_code.py", code)
            result = sb.exec("python3 /tmp/_sf_code.py")
            parts = []
            if result.stdout:
                parts.append(result.stdout)
            if result.stderr:
                parts.append(f"[stderr] {result.stderr}")
            if result.exit_code != 0:
                parts.append(f"[exit code: {result.exit_code}]")
            return "\n".join(parts) or "(no output)"
        finally:
            sb.delete()


class SandflareExecTool(BaseTool):
    """CrewAI tool that runs arbitrary shell commands in a Sandflare microVM."""

    name: str = "Sandflare Shell Executor"
    description: str = (
        "Run a shell command in an isolated Sandflare microVM. "
        "Returns stdout, stderr, and exit code. "
        "Use for git operations, npm/pip installs, or any system command."
    )

    class _Input(BaseModel):
        command: str = Field(description="Shell command to run")
        sandbox_name: Optional[str] = Field(
            default=None,
            description="Reuse an existing sandbox by name, or leave empty to create a new one",
        )

    args_schema: Type[BaseModel] = _Input  # type: ignore[assignment]

    api_key: Optional[str] = None
    template_id: str = ""
    _sandbox: Optional[object] = None
    _sandbox_name: Optional[str] = None

    def _run(self, command: str, sandbox_name: Optional[str] = None) -> str:
        if sandbox_name:
            from sandflare import Sandbox as _S
            sb = _S(name=sandbox_name, api_key=self.api_key)
            result = sb.exec(command)
        else:
            sb = Sandbox.create(
                api_key=self.api_key,
                template_id=self.template_id,
            )
            try:
                result = sb.exec(command)
            finally:
                sb.delete()

        parts = []
        if result.stdout:
            parts.append(result.stdout)
        if result.stderr:
            parts.append(f"[stderr] {result.stderr}")
        parts.append(f"[exit: {result.exit_code}]")
        return "\n".join(parts)


__all__ = ["SandflareTool", "SandflareExecTool"]
