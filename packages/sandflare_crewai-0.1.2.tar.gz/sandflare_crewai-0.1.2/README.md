# sandflare-crewai

[CrewAI](https://docs.crewai.com/) tool integration for [Sandflare](https://sandflare.io) — run agent-generated code in isolated Firecracker microVM sandboxes.

## Installation

```bash
pip install sandflare-crewai
```

## Usage

```python
from crewai import Agent, Task, Crew
from sandflare_crewai import SandflareCodeTool

code_tool = SandflareCodeTool(api_key="sf-...")

coder = Agent(
    role="Python Developer",
    goal="Write and execute Python code to solve tasks",
    tools=[code_tool],
    llm="gpt-4o",
)

task = Task(
    description="Fetch the top 5 HN stories and print their titles",
    agent=coder,
)

Crew(agents=[coder], tasks=[task]).kickoff()
```

## How it works

Each `SandflareCodeTool` call creates a fresh Sandflare microVM sandbox, executes the code safely, and returns the output to the CrewAI agent.

## Links

- [Sandflare docs](https://docs.sandflare.io)
- [sandflare Python SDK](https://pypi.org/project/sandflare/)
