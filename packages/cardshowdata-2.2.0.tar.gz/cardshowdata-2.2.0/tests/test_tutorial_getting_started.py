"""Test that every code example in the 'Getting Started with an SDK' tutorial works.

Runs against the live API to catch broken tutorial examples before users do.
Each test maps to a tutorial step.

Run with: pytest tests/test_tutorial_getting_started.py -v
"""

import os

import pytest

# Load .env
_env_path = os.path.join(os.path.dirname(__file__), "..", "..", "..", ".env")
if os.path.exists(_env_path):
    for line in open(_env_path):
        line = line.strip()
        if line and not line.startswith("#") and "=" in line:
            k, v = line.split("=", 1)
            os.environ.setdefault(k.strip(), v.strip())

API_KEY = os.environ.get("CSD_TEST_API_KEY")
if not API_KEY:
    pytest.skip("CSD_TEST_API_KEY not set", allow_module_level=True)

from cardshowdata import (
    AsyncCardShowData,
    AuthenticationError,
    CardShowData,
    NotFoundError,
    PermissionError,
    RateLimitError,
)


@pytest.fixture(scope="module")
def client():
    c = CardShowData(api_key=API_KEY)
    yield c
    c.close()


# ── Step 2: Create a client ─────────────────────────────────────

class TestStep2CreateClient:
    def test_client_creates_with_api_key(self):
        c = CardShowData(api_key=API_KEY)
        c.close()

    def test_client_creates_from_env(self, monkeypatch):
        monkeypatch.setenv("CSD_API_KEY", API_KEY)
        c = CardShowData()
        c.close()


# ── Step 3: Browse the catalog ───────────────────────────────────

class TestStep3BrowseCatalog:
    def test_list_tcgs(self, client):
        tcgs = client.catalog.list_tcgs()
        assert len(tcgs) >= 16
        # Tutorial prints: tcg.tcg_name, tcg.product_count
        for tcg in tcgs:
            assert tcg.tcg_name is not None
            assert isinstance(tcg.product_count, int)

    def test_list_sets(self, client):
        sets = client.catalog.list_sets("pokemon")
        assert len(sets) > 0
        # Tutorial prints: s.set_name, s.set_code, s.product_count
        for s in sets[:3]:
            assert s.set_name is not None
            assert s.set_code is not None
            assert isinstance(s.product_count, int)


# ── Step 4: Search for a card ────────────────────────────────────

class TestStep4SearchCard:
    def test_search_charizard(self, client):
        page = client.cards.search(tcg="pk", q="name:charizard", page_size=5)
        assert page.pagination.total_count > 0
        assert len(page.data) > 0
        for card in page.data:
            # Tutorial accesses: card.name, card.expansion.name, card.image
            assert card.name is not None
            assert card.expansion is not None
            assert card.expansion.name is not None
            # card.image can be None, that's OK
            # Tutorial accesses: card.variants[0].recommended_sell.price_cents
            for v in card.variants:
                if v.recommended_sell:
                    assert isinstance(v.recommended_sell.price_cents, (int, type(None)))


# ── Step 5: Get detailed pricing ─────────────────────────────────

class TestStep5Pricing:
    def test_single_pricing(self, client):
        card = client.cards.get("pk_bs_004")
        assert card.csd_product_id is not None

        price = client.pricing.get(card.csd_product_id)
        # Tutorial iterates variants[] and prints: subtype, market_price_cents,
        # fair_value_cents, confidence, lifecycle_state per variant.
        assert price.product_id == card.csd_product_id
        assert isinstance(price.variants, list)
        for v in price.variants:
            assert isinstance(v.subtype, str)
            assert isinstance(v.market_price_cents, (int, type(None)))
            assert isinstance(v.fair_value_cents, (int, type(None)))
            assert isinstance(v.confidence, (float, type(None)))
            assert isinstance(v.lifecycle_state, (str, type(None)))

    def test_bulk_pricing(self, client):
        card = client.cards.get("pk_bs_004")
        prices = client.pricing.bulk([card.csd_product_id])
        assert len(prices) == 1


# ── Step 6: Auto-paginate ────────────────────────────────────────

class TestStep6AutoPaginate:
    def test_catalog_products_all(self, client):
        # Tutorial: for product in client.catalog.list_products_all("pokemon")
        count = 0
        for product in client.catalog.list_products_all("pokemon", limit=5):
            assert product.pretty_id is not None or product.product_name is not None
            count += 1
            if count >= 10:
                break
        assert count >= 5

    def test_cards_search_all(self, client):
        # Tutorial: for card in client.cards.search_all(tcg="pk", q="name:pikachu")
        count = 0
        for card in client.cards.search_all(tcg="pk", q="name:pikachu", page_size=5):
            assert card.name is not None
            count += 1
            if count >= 5:
                break
        assert count >= 1


# ── Step 7: Handle errors ────────────────────────────────────────

class TestStep7Errors:
    def test_not_found_error(self, client):
        # Tutorial: except NotFoundError
        with pytest.raises(NotFoundError):
            client.cards.get("nonexistent_id")

    def test_authentication_error(self):
        # Tutorial: except AuthenticationError
        bad = CardShowData(api_key="csd_invalid_key", max_retries=0)
        with pytest.raises(AuthenticationError):
            bad.cards.get("pk_bs_004")
        bad.close()


# ── Step 8: Check usage ──────────────────────────────────────────

class TestStep8Usage:
    def test_get_usage(self, client):
        usage = client.usage.get()
        # Tutorial accesses: usage.account['account_tier'], usage.daily['calls_today'],
        # usage.rate_limit['remaining_this_minute']
        assert "account_tier" in usage.account or "account_type" in usage.account
        assert "calls_today" in usage.daily

    def test_rate_limit_info(self, client):
        # Tutorial: client.rate_limit.remaining
        client.catalog.list_tcgs()  # trigger a request
        assert client.rate_limit.remaining is not None


# ── Async variant ─────────────────────────────────────────────────

class TestAsyncTutorial:
    @pytest.mark.asyncio
    async def test_async_walkthrough(self):
        """Verify the async code from Step 2 works end-to-end."""
        async with AsyncCardShowData(api_key=API_KEY) as client:
            # Step 3: browse catalog
            tcgs = await client.catalog.list_tcgs()
            assert len(tcgs) >= 16

            # Step 4: search
            page = await client.cards.search(tcg="pk", q="name:charizard", page_size=3)
            assert len(page.data) > 0

            # Step 5: pricing
            card = await client.cards.get("pk_bs_004")
            price = await client.pricing.get(card.csd_product_id)
            assert price.product_id is not None
