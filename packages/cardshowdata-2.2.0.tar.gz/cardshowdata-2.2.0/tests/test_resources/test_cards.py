"""Tests for the Cards resource."""

import httpx
import pytest

from cardshowdata import AsyncCardShowData


CARD_RESPONSE = {
    "id": "pk_bs_004",
    "csd_product_id": "aaaa-bbbb-cccc",
    "tcg": "pk",
    "name": "Charizard",
    "number": "4/102",
    "printed_number": "4",
    "rarity": "Rare Holo",
    "rarity_code": "RH",
    "artist": "Mitsuhiro Arita",
    "language": "English",
    "language_code": "en",
    "image": "https://images.cardshowdata.com/aaaa-bbbb-cccc.jpg",
    "tcgplayer_url": "https://tcgplayer.com/...",
    "cardmarket_url": None,
    "expansion": {
        "id": "pk_bs",
        "name": "Base Set",
        "series": "Base",
        "code": "bs",
        "release_date": "1999-01-09",
    },
    "variants": [
        {
            "name": "Holofoil",
            "image": None,
            "raw": [{"price_cents": 50000}],
            "graded": [],
            "recommended_sell": {
                "price_cents": 45000,
                "approach": "retail_blend",
                "confidence": 0.85,
                "show_sales_count": 3,
                "lifecycle_state": "declining",
                "adjustment_pct": -5.0,
            },
            "trends": {
                "7d": {"change_cents": 149, "pct": 0.3},
                "30d": {"change_cents": -2851, "pct": -5.42},
            },
            "population": None,
        }
    ],
    "population": {
        "psa": {"10": 1524, "9": 892, "total": 2416, "as_of": "2026-04-16T09:30:00Z"},
    },
}

EBAY_RESPONSE = {
    "sales": [
        {
            "price_cents": 120000,
            "shipping_price_cents": 500,
            "currency": "USD",
            "format": "auction",
            "sold_at": "2026-04-10T12:00:00Z",
            "ebay_url": "https://ebay.com/...",
            "title": "PSA 10 Charizard Base Set",
        }
    ],
    "source": "db",
    "cached": True,
}


class TestCards:
    def test_get_by_pretty_id(self, mock_api, client):
        route = mock_api.get("/v1/cards/pk_bs_004").mock(
            return_value=httpx.Response(200, json=CARD_RESPONSE)
        )
        card = client.cards.get("pk_bs_004")
        assert card.name == "Charizard"
        assert card.csd_product_id == "aaaa-bbbb-cccc"
        assert card.image == "https://images.cardshowdata.com/aaaa-bbbb-cccc.jpg"
        assert card.expansion.name == "Base Set"
        assert card.expansion.release_date == "1999-01-09"
        assert len(card.variants) == 1
        assert card.variants[0].name == "Holofoil"
        assert card.variants[0].recommended_sell.price_cents == 45000
        assert card.variants[0].recommended_sell.approach == "retail_blend"
        # v2.2.0: trends per variant; card-level population as rollup.
        assert card.variants[0].trends["7d"]["change_cents"] == 149
        assert card.variants[0].image is None       # stub in 2.2.0
        assert card.variants[0].population is None  # stub in 2.2.0
        assert card.population["psa"]["10"] == 1524

    def test_get_with_include(self, mock_api, client):
        route = mock_api.get("/v1/cards/pk_bs_004").mock(
            return_value=httpx.Response(200, json={**CARD_RESPONSE, "details": {"supertype": "Pokemon"}})
        )
        card = client.cards.get("pk_bs_004", include=["details", "trends"])
        assert "include" in str(route.calls[0].request.url)
        assert card.details["supertype"] == "Pokemon"

    def test_search(self, mock_api, client):
        route = mock_api.get("/v1/cards").mock(
            return_value=httpx.Response(200, json={
                "data": [CARD_RESPONSE],
                "pagination": {"page": 1, "page_size": 50, "total_count": 1, "total_pages": 1, "next_href": None, "prev_href": None},
            })
        )
        page = client.cards.search(tcg="pk", q="name:charizard")
        assert len(page.data) == 1
        assert page.data[0].name == "Charizard"
        url = str(route.calls[0].request.url)
        assert "tcg=pk" in url
        assert "name%3Acharizard" in url or "name:charizard" in url

    def test_list_by_expansion(self, mock_api, client):
        route = mock_api.get("/v1/expansions/pk_bs/cards").mock(
            return_value=httpx.Response(200, json={
                "data": [CARD_RESPONSE],
                "pagination": {"page": 1, "page_size": 50, "total_count": 1, "total_pages": 1, "next_href": None, "prev_href": None},
            })
        )
        page = client.cards.list_by_expansion("pk_bs")
        assert len(page.data) == 1

    def test_get_ebay_sales(self, mock_api, client):
        route = mock_api.get("/v1/cards/pk_bs_004/ebay-sales").mock(
            return_value=httpx.Response(200, json=EBAY_RESPONSE)
        )
        result = client.cards.get_ebay_sales("pk_bs_004", company="PSA", grade="10")
        assert len(result.sales) == 1
        assert result.sales[0].price_cents == 120000
        assert result.source == "db"
        assert result.cached is True
        url = str(route.calls[0].request.url)
        assert "company=PSA" in url
        assert "grade=10" in url

    @pytest.mark.asyncio
    async def test_async_get(self, mock_api):
        mock_api.get("/v1/cards/pk_bs_004").mock(
            return_value=httpx.Response(200, json=CARD_RESPONSE)
        )
        async with AsyncCardShowData(api_key="test_key_123") as c:
            card = await c.cards.get("pk_bs_004")
            assert card.name == "Charizard"
