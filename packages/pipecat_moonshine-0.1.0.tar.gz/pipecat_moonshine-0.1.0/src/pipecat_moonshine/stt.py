#
# Copyright (c) 2026, pipecat-moonshine contributors
#
# SPDX-License-Identifier: BSD-2-Clause
#

"""Moonshine speech-to-text service for Pipecat.

This module integrates the Moonshine ASR family of models (via the
``useful-moonshine-onnx`` package) with Pipecat's ``SegmentedSTTService``
interface, allowing fast, on-device transcription of audio segments produced
by VAD-driven pipelines.
"""

import asyncio
from collections.abc import AsyncGenerator
from dataclasses import dataclass
from enum import Enum
from typing import TYPE_CHECKING

import numpy as np
from loguru import logger
from pipecat.frames.frames import ErrorFrame, Frame, TranscriptionFrame
from pipecat.services.settings import STTSettings, assert_given
from pipecat.services.stt_service import SegmentedSTTService
from pipecat.transcriptions.language import Language, resolve_language
from pipecat.utils.time import time_now_iso8601
from pipecat.utils.tracing.service_decorators import traced_stt

if TYPE_CHECKING:
    try:
        from moonshine_onnx import MoonshineOnnxModel
    except ModuleNotFoundError as e:
        logger.error(f"Exception: {e}")
        logger.error(
            "In order to use Moonshine STT, you need to `pip install useful-moonshine-onnx`."
        )
        raise Exception(f"Missing module: {e}") from e


# Moonshine's input contract: 16 kHz, mono, float32 in [-1, 1].
MOONSHINE_SAMPLE_RATE = 16000

# Per moonshine_onnx.transcribe.assert_audio_size: 0.1s < duration < 64s.
_MIN_AUDIO_SECONDS = 0.1
_MAX_AUDIO_SECONDS = 64.0


class Model(Enum):
    """Moonshine model selection options.

    Parameters:
        TINY_EN: 26 M-parameter English-only model, fastest inference.
        BASE_EN: 58 M-parameter English-only model, better accuracy.

    Note:
        Only the English models are enumerated here because their weights are
        released under the permissive MIT license. Multilingual Moonshine
        weights (Spanish, Japanese, Arabic, Korean, Mandarin, etc.) are
        released under the non-commercial **Moonshine Community License** and
        must be opted into explicitly by passing the model-name string
        directly. By doing so you accept the upstream license terms.
    """

    TINY_EN = "moonshine/tiny"
    BASE_EN = "moonshine/base"


def language_to_moonshine_language(language: Language) -> str | None:
    """Map a pipecat ``Language`` enum to a Moonshine language code.

    The ONNX models bundled with ``useful-moonshine-onnx`` are currently
    English-only; this helper returns ``"en"`` for any English variant and
    ``None`` for anything else (logging a warning via ``resolve_language``).

    Args:
        language: A ``Language`` enum value.

    Returns:
        The Moonshine language code, or ``None`` if not supported.
    """
    return resolve_language(language, {Language.EN: "en"}, use_base_code=True)


@dataclass
class MoonshineSTTSettings(STTSettings):
    """Runtime-updatable settings for ``MoonshineSTTService``.

    Inherits the standard ``model`` and ``language`` fields from
    ``STTSettings``. The Moonshine ONNX inference path currently exposes no
    additional runtime knobs; add new fields here as the upstream API grows.
    """


class MoonshineSTTService(SegmentedSTTService):
    """Transcribe audio with a locally-downloaded Moonshine ONNX model.

    Moonshine is a family of small, fast ASR models optimized for on-device
    inference. This service wraps :func:`moonshine_onnx.transcribe` and is
    designed to plug directly into Pipecat pipelines that perform VAD
    upstream: each speech segment yielded by VAD is fed to ``run_stt`` as
    16-bit PCM, converted to float32 in ``[-1, 1]``, and decoded into a
    single final ``TranscriptionFrame``.

    The first time a given model is requested it is downloaded from
    ``huggingface.co/UsefulSensors/moonshine``. Subsequent runs read from the
    local Hugging Face cache.

    Audio format: 16 kHz, mono, 16-bit signed PCM. Pipecat's default
    audio-in sample rate matches this; other rates will trigger a warning
    and may degrade accuracy.

    Example::

        from pipecat_moonshine import MoonshineSTTService, Model

        stt = MoonshineSTTService(model=Model.TINY_EN)
        pipeline = Pipeline([transport.input(), vad_processor, stt, llm, ...])
    """

    Settings = MoonshineSTTSettings
    _settings: Settings

    def __init__(
        self,
        *,
        model: str | Model | None = None,
        settings: Settings | None = None,
        **kwargs,
    ):
        """Initialize the Moonshine STT service.

        Args:
            model: Convenience shortcut for setting the model. Accepts a
                ``Model`` enum value or a model-name string (e.g.
                ``"moonshine/tiny"``). Equivalent to passing
                ``settings=MoonshineSTTService.Settings(model=...)``.
            settings: Runtime-updatable settings. When both ``settings`` and
                ``model`` are provided, fields in ``settings`` win.
            **kwargs: Additional arguments passed to ``SegmentedSTTService``.
        """
        # 1. Hardcoded defaults.
        default_settings = self.Settings(
            model=Model.TINY_EN.value,
            language=Language.EN,
        )

        # 2. Convenience kwarg overrides.
        if model is not None:
            default_settings.model = model.value if isinstance(model, Model) else model

        # 3. Settings delta (canonical API, always wins).
        if settings is not None:
            default_settings.apply_update(settings)

        super().__init__(settings=default_settings, **kwargs)

        self._model_obj: MoonshineOnnxModel | None = None
        self._sample_rate_warned = False
        self._load()

    def can_generate_metrics(self) -> bool:
        """Indicate whether this service emits processing metrics.

        Returns:
            ``True`` — Moonshine STT records per-segment processing time.
        """
        return True

    def language_to_service_language(self, language: Language) -> str | None:
        """Map a pipecat ``Language`` to a Moonshine language code.

        Args:
            language: The ``Language`` enum value to convert.

        Returns:
            The Moonshine code, or ``None`` if unsupported.
        """
        return language_to_moonshine_language(language)

    def _load(self):
        """Load the configured Moonshine ONNX model.

        Note:
            The first invocation for a given model downloads weights from the
            Hugging Face Hub (``UsefulSensors/moonshine``); subsequent calls
            reuse the local cache.
        """
        try:
            from moonshine_onnx import MoonshineOnnxModel

            model_name = assert_given(self._settings.model)
            if model_name is None:
                raise ValueError("Moonshine model must be specified")
            logger.debug(f"Loading Moonshine model {model_name}...")
            self._model_obj = MoonshineOnnxModel(model_name=model_name)
            logger.debug(f"Loaded Moonshine model {model_name}")
        except ModuleNotFoundError as e:
            logger.error(f"Exception: {e}")
            logger.error(
                "In order to use Moonshine STT, you need to `pip install useful-moonshine-onnx`."
            )
            self._model_obj = None

    @traced_stt
    async def _handle_transcription(
        self, transcript: str, is_final: bool, language: Language | None = None
    ):
        """Handle a transcription result with tracing.

        Decorated with ``@traced_stt`` so OpenTelemetry spans are emitted
        when Pipecat tracing is enabled. The body is intentionally empty;
        the decorator does the work.
        """
        pass

    async def run_stt(self, audio: bytes) -> AsyncGenerator[Frame, None]:
        """Transcribe a single VAD-delimited speech segment.

        Args:
            audio: Raw 16-bit signed PCM audio bytes for one speech segment.

        Yields:
            Either a single ``TranscriptionFrame`` containing the decoded
            text, or an ``ErrorFrame`` on failure. Out-of-range segments
            (too short or too long for Moonshine) are silently dropped.
        """
        if self._model_obj is None:
            yield ErrorFrame("Moonshine model not available")
            return

        if not self._sample_rate_warned and self.sample_rate != MOONSHINE_SAMPLE_RATE:
            logger.warning(
                f"Moonshine expects {MOONSHINE_SAMPLE_RATE} Hz audio; pipeline is "
                f"providing {self.sample_rate} Hz. Transcription quality may degrade."
            )
            self._sample_rate_warned = True

        await self.start_processing_metrics()

        # Signed 16-bit PCM -> float32 in [-1, 1].
        audio_float = np.frombuffer(audio, dtype=np.int16).astype(np.float32) / 32768.0

        duration = audio_float.size / max(self.sample_rate, 1)
        if duration <= _MIN_AUDIO_SECONDS or duration >= _MAX_AUDIO_SECONDS:
            logger.debug(
                f"Skipping Moonshine transcription: segment duration {duration:.2f}s "
                f"is outside the supported ({_MIN_AUDIO_SECONDS}, {_MAX_AUDIO_SECONDS}) range."
            )
            await self.stop_processing_metrics()
            return

        try:
            import moonshine_onnx

            results = await asyncio.to_thread(
                moonshine_onnx.transcribe, audio_float, self._model_obj
            )
        except Exception as e:
            await self.stop_processing_metrics()
            logger.exception(f"{self} Moonshine transcription error")
            yield ErrorFrame(error=f"Moonshine transcription error: {e}")
            return

        await self.stop_processing_metrics()

        text = (results[0] if results else "").strip()
        if not text:
            return

        # STTSettings normalises ``language`` to a service-code string during
        # init, so ``self._settings.language`` is e.g. ``"en"`` rather than
        # ``Language.EN``. Map common codes back to the enum for the frame;
        # anything we don't recognise (e.g. a user-overridden code) falls
        # through as None — runtime callers can still read it from the frame.
        language_setting = assert_given(self._settings.language)
        language: Language | None
        if isinstance(language_setting, Language):
            language = language_setting
        elif language_setting == "en":
            language = Language.EN
        else:
            language = None

        await self._handle_transcription(text, True, language)
        logger.debug(f"Transcription: [{text}]")
        yield TranscriptionFrame(text, self._user_id, time_now_iso8601(), language)
