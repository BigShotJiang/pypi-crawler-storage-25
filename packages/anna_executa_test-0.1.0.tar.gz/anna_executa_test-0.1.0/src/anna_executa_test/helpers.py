"""Assertion helpers for tests."""

from __future__ import annotations

from typing import Any

from anna_executa_test.client import ExecutaClient, JsonRpcError


def describe_plugin(client: ExecutaClient) -> dict[str, Any]:
    """Return a normalized MANIFEST dict from ``describe``.

    Validates the bare minimum: ``name``, ``version``, and a non-empty
    ``tools`` list. Use :mod:`anna_executa_test.contract` for richer
    inspection.
    """
    info = client.describe()
    if not isinstance(info, dict):
        msg = f"describe() must return a dict, got {type(info).__name__}"
        raise AssertionError(msg)
    for key in ("name", "version", "tools"):
        if key not in info:
            msg = f"describe() missing required field: {key!r}"
            raise AssertionError(msg)
    if not isinstance(info["tools"], list) or not info["tools"]:
        msg = "describe().tools must be a non-empty list"
        raise AssertionError(msg)
    return info


def assert_jsonrpc_ok(resp: Any) -> None:
    """Asserts that ``resp`` is an Anna ``invoke``-style success payload."""
    if not isinstance(resp, dict):
        msg = f"expected dict, got {type(resp).__name__}"
        raise AssertionError(msg)
    if resp.get("success") is not True:
        msg = f"expected success=True, got {resp!r}"
        raise AssertionError(msg)
    if "data" not in resp:
        msg = f"expected 'data' field in success response, got {resp!r}"
        raise AssertionError(msg)


def assert_jsonrpc_error(
    exc_or_resp: Any,
    *,
    code: int | None = None,
    message_contains: str | None = None,
) -> None:
    """Asserts a JSON-RPC error.

    Accepts either:
      - a ``JsonRpcError`` raised by ``client.call``
      - an ``invoke``-style error payload ``{success: false, error: {...}}``
    """
    if isinstance(exc_or_resp, JsonRpcError):
        if code is not None and exc_or_resp.code != code:
            msg = f"expected error code {code}, got {exc_or_resp.code}"
            raise AssertionError(msg)
        if message_contains and message_contains not in exc_or_resp.message:
            msg = f"expected error message to contain {message_contains!r}, got {exc_or_resp.message!r}"
            raise AssertionError(msg)
        return
    if isinstance(exc_or_resp, dict):
        if exc_or_resp.get("success") is not False:
            msg = f"expected success=False, got {exc_or_resp!r}"
            raise AssertionError(msg)
        err = exc_or_resp.get("error") or {}
        if code is not None:
            err_code = err.get("code") if isinstance(err, dict) else None
            if err_code != code:
                msg = f"expected error code {code}, got {err_code!r}"
                raise AssertionError(msg)
        if message_contains:
            err_msg = err.get("message", "") if isinstance(err, dict) else str(err)
            if message_contains not in err_msg:
                msg = f"expected error message to contain {message_contains!r}, got {err_msg!r}"
                raise AssertionError(msg)
        return
    msg = f"assert_jsonrpc_error: unsupported value type {type(exc_or_resp).__name__}"
    raise TypeError(msg)


__all__ = ["assert_jsonrpc_error", "assert_jsonrpc_ok", "describe_plugin"]
