"""Pytest plugin entry — exposes shared fixtures.

Auto-loaded via the ``pytest11`` entry point declared in ``pyproject.toml``.
Users can also load it explicitly with::

    pytest_plugins = ["anna_executa_test.plugin"]
"""

from __future__ import annotations

import os
from collections.abc import Iterator
from pathlib import Path

import pytest

from anna_executa_test.client import ExecutaClient, spawn


@pytest.fixture
def mock_state_dir(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Path:
    """Redirect ``XDG_STATE_HOME`` (and related dirs) at a tmp path.

    Use this in any test that touches a plugin storing state on disk —
    the focus-session example writes to ``~/.anna/focus-flow/state.json``,
    so isolating ``$HOME`` per test prevents flakes.
    """
    state = tmp_path / "state"
    home = tmp_path / "home"
    cache = tmp_path / "cache"
    config = tmp_path / "config"
    for d in (state, home, cache, config):
        d.mkdir(parents=True, exist_ok=True)
    monkeypatch.setenv("HOME", str(home))
    monkeypatch.setenv("XDG_STATE_HOME", str(state))
    monkeypatch.setenv("XDG_CACHE_HOME", str(cache))
    monkeypatch.setenv("XDG_CONFIG_HOME", str(config))
    # Some plugins write to ANNA_HOME; honor that too.
    monkeypatch.setenv("ANNA_HOME", str(home / ".anna"))
    return tmp_path


@pytest.fixture
def executa_spawn():
    """Expose :func:`anna_executa_test.client.spawn` as a fixture for ergonomics.

    Example::

        def test_x(executa_spawn):
            with executa_spawn("path/to/plugin") as plugin:
                ...
    """
    return spawn
