"""Subprocess client for an Executa stdio JSON-RPC plugin.

The plugin is launched via the user's choice of command (defaults to
``uv run --project <dir> <tool_id>`` after reading ``[project.scripts]``
from ``pyproject.toml``). The wire format is one JSON envelope per line,
mirroring ``nexus.executa_wire``::

    --> {"jsonrpc": "2.0", "id": 1, "method": "describe"}
    <-- {"jsonrpc": "2.0", "id": 1, "result": {...MANIFEST...}}

The client is intentionally synchronous — pytest is single-threaded and
plugins always return one response per request.
"""

from __future__ import annotations

import contextlib
import io
import json
import os
import subprocess
import sys
import threading
import time
from collections.abc import Iterator
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

try:
    import tomllib  # type: ignore[attr-defined]
except ImportError:  # Python < 3.11
    import tomli as tomllib  # type: ignore[no-redef]


class ExecutaError(RuntimeError):
    """Raised when the subprocess misbehaves (crash, timeout, bad JSON)."""


@dataclass
class JsonRpcError(Exception):
    """Raised when the plugin returns a JSON-RPC error envelope."""

    code: int
    message: str
    data: Any = None

    def __str__(self) -> str:  # pragma: no cover - trivial
        return f"[{self.code}] {self.message}"


def _detect_command(project_dir: Path) -> list[str]:
    """Read ``pyproject.toml`` and produce ``uv run --project <dir> <script>``.

    Falls back to ``python -m <module>`` if no script is declared. Raises
    ``ExecutaError`` if neither can be inferred.
    """
    pyproject = project_dir / "pyproject.toml"
    if not pyproject.is_file():
        msg = f"no pyproject.toml in {project_dir}"
        raise ExecutaError(msg)
    data = tomllib.loads(pyproject.read_text("utf-8"))
    scripts = data.get("project", {}).get("scripts", {}) or {}
    if scripts:
        # Use the first script entry. Plugins normally declare exactly one,
        # named after the minted tool_id.
        name = next(iter(scripts))
        return ["uv", "run", "--project", str(project_dir), name]
    py_modules = data.get("tool", {}).get("setuptools", {}).get("py-modules") or []
    if py_modules:
        return [
            "uv",
            "run",
            "--project",
            str(project_dir),
            "python",
            "-m",
            py_modules[0],
        ]
    msg = (
        f"could not infer launch command from {pyproject}: "
        "declare [project.scripts] or [tool.setuptools].py-modules"
    )
    raise ExecutaError(msg)


@dataclass
class ExecutaClient:
    """JSON-RPC client over an Executa stdio subprocess."""

    proc: subprocess.Popen[str]
    project_dir: Path
    stderr_lines: list[str] = field(default_factory=list)
    _next_id: int = 1
    _lock: threading.Lock = field(default_factory=threading.Lock)
    _stderr_thread: threading.Thread | None = None

    def call(
        self,
        method: str,
        params: dict[str, Any] | None = None,
        *,
        timeout: float = 10.0,
    ) -> Any:
        """Send one JSON-RPC request and return ``result`` (raises on error)."""
        env = self._send(method, params)
        deadline = time.monotonic() + timeout
        while True:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                msg = (
                    f"executa: no response to {method!r} (id={env['id']}) "
                    f"within {timeout}s"
                )
                raise ExecutaError(msg)
            line = self._readline(remaining)
            if line is None:
                msg = f"executa: subprocess closed stdout while awaiting {method!r}"
                raise ExecutaError(msg)
            try:
                resp = json.loads(line)
            except json.JSONDecodeError as exc:
                msg = f"executa: non-JSON line on stdout: {line!r}"
                raise ExecutaError(msg) from exc
            if resp.get("id") != env["id"]:
                # Notification or out-of-order — keep reading.
                continue
            if "error" in resp:
                err = resp["error"] or {}
                raise JsonRpcError(
                    code=int(err.get("code", -32000)),
                    message=str(err.get("message", "unknown")),
                    data=err.get("data"),
                )
            return resp.get("result")

    # --- Sugar over `call` -------------------------------------------------

    def describe(self, *, timeout: float = 10.0) -> dict[str, Any]:
        return self.call("describe", timeout=timeout)

    def health(self, *, timeout: float = 5.0) -> dict[str, Any]:
        return self.call("health", timeout=timeout)

    def invoke(
        self,
        tool: str,
        arguments: dict[str, Any] | None = None,
        *,
        timeout: float = 10.0,
    ) -> dict[str, Any]:
        return self.call(
            "invoke",
            {"tool": tool, "arguments": arguments or {}},
            timeout=timeout,
        )

    # --- Lifecycle ---------------------------------------------------------

    def close(self) -> None:
        if self.proc.poll() is None:
            with contextlib.suppress(Exception):
                self.proc.stdin.close()  # type: ignore[union-attr]
            try:
                self.proc.wait(timeout=2.0)
            except subprocess.TimeoutExpired:
                self.proc.kill()
                self.proc.wait(timeout=2.0)
        if self._stderr_thread and self._stderr_thread.is_alive():
            self._stderr_thread.join(timeout=1.0)

    # --- Internals ---------------------------------------------------------

    def _send(self, method: str, params: dict[str, Any] | None) -> dict[str, Any]:
        with self._lock:
            env: dict[str, Any] = {"jsonrpc": "2.0", "id": self._next_id, "method": method}
            self._next_id += 1
            if params is not None:
                env["params"] = params
            payload = json.dumps(env, ensure_ascii=False) + "\n"
            assert self.proc.stdin is not None
            self.proc.stdin.write(payload)
            self.proc.stdin.flush()
            return env

    def _readline(self, timeout: float) -> str | None:
        # Synchronous readline; timeout enforced by the calling loop's wall clock.
        # On posix, .stdout.readline() blocks; we rely on the caller's deadline
        # check above to bail out (small extra latency only on hung plugins).
        assert self.proc.stdout is not None
        line = self.proc.stdout.readline()
        if not line:
            return None
        return line.rstrip("\n")


@contextlib.contextmanager
def spawn(
    project_dir: str | os.PathLike[str],
    *,
    command: list[str] | None = None,
    env: dict[str, str] | None = None,
    extra_env: dict[str, str] | None = None,
    cwd: str | os.PathLike[str] | None = None,
) -> Iterator[ExecutaClient]:
    """Context manager that launches an Executa plugin via ``uv run``.

    Yields an ``ExecutaClient``. The subprocess is terminated on exit.

    Args:
        project_dir: directory containing ``pyproject.toml``.
        command:     override the launch command entirely.
        env:         replace the environment (defaults to ``os.environ`` plus extras).
        extra_env:   shallow-merge extra entries on top of the inherited env.
        cwd:         working directory (defaults to ``project_dir``).
    """
    project = Path(project_dir).resolve()
    cmd = command if command is not None else _detect_command(project)
    base_env = dict(env if env is not None else os.environ)
    if extra_env:
        base_env.update(extra_env)
    proc = subprocess.Popen(
        cmd,
        cwd=str(cwd or project),
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        bufsize=1,  # line-buffered
        env=base_env,
    )
    if proc.stdin is None or proc.stdout is None or proc.stderr is None:
        proc.kill()
        msg = "failed to obtain pipes for executa subprocess"
        raise ExecutaError(msg)

    client = ExecutaClient(proc=proc, project_dir=project)

    # Drain stderr in a daemon thread so a noisy plugin can't deadlock.
    def _drain() -> None:
        assert proc.stderr is not None
        for line in iter(proc.stderr.readline, ""):
            client.stderr_lines.append(line.rstrip("\n"))

    t = threading.Thread(target=_drain, daemon=True, name="executa-stderr")
    t.start()
    client._stderr_thread = t  # noqa: SLF001 - intentional internal hook

    try:
        yield client
    finally:
        client.close()


# Module-level facade so callers can `from anna_executa_test import executa`
# and write `executa.spawn(...)` (matches the README).
class _ExecutaModule:
    spawn = staticmethod(spawn)


executa = _ExecutaModule()
