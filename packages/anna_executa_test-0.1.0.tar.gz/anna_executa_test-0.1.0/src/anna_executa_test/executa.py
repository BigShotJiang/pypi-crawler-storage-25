"""Re-export :mod:`anna_executa_test.client` as ``executa.*`` namespace."""

from __future__ import annotations

from anna_executa_test.client import spawn

__all__ = ["spawn"]
