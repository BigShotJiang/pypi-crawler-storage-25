"""Static + dynamic contract for an Executa plugin.

A :class:`Contract` is built by spawning the plugin once, calling
``describe``, and combining the result with a few facts read from
``pyproject.toml``. It exposes helpers for parametrizing tests over
declared tools / actions without re-spawning the subprocess for each
case.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable

import pytest

from anna_executa_test.client import ExecutaClient, _detect_command, spawn

try:
    import tomllib  # type: ignore[attr-defined]
except ImportError:  # Python < 3.11
    import tomli as tomllib  # type: ignore[no-redef]


@dataclass
class ToolSpec:
    name: str
    description: str = ""
    parameters: list[dict[str, Any]] = field(default_factory=list)


@dataclass
class Contract:
    project_dir: Path
    tool_id: str
    version: str
    manifest: dict[str, Any]
    tools: list[ToolSpec]
    launch_command: list[str]

    def parametrize_invoke(
        self,
        cases: dict[str, Any] | list[tuple[str, dict[str, Any]]],
    ) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
        """Return a ``pytest.mark.parametrize`` decorator over ``(tool, args)``.

        ``cases`` may be either a dict ``{label: (tool, arguments)}`` or a
        list of ``(tool, arguments)`` tuples. Tools are validated against
        the plugin's declared tool list.
        """
        declared = {t.name for t in self.tools}
        items: list[tuple[str, str, dict[str, Any]]] = []
        if isinstance(cases, dict):
            for label, value in cases.items():
                tool, args = value
                items.append((label, tool, args))
        else:
            for tool, args in cases:
                items.append((f"{tool}-{len(items)}", tool, args))
        for _label, tool, _args in items:
            if tool not in declared:
                msg = (
                    f"contract_for({self.project_dir.name}): tool {tool!r} not declared "
                    f"in MANIFEST.tools (declared: {sorted(declared)})"
                )
                raise AssertionError(msg)
        return pytest.mark.parametrize(
            ("tool", "arguments"),
            [pytest.param(tool, args, id=label) for label, tool, args in items],
        )

    def tool(self, name: str) -> ToolSpec:
        for t in self.tools:
            if t.name == name:
                return t
        msg = f"tool {name!r} not declared in MANIFEST.tools"
        raise KeyError(msg)


def _read_tool_id(project_dir: Path) -> str:
    pyproject = project_dir / "pyproject.toml"
    data = tomllib.loads(pyproject.read_text("utf-8"))
    return str(data.get("project", {}).get("name", ""))


def contract_for(
    project_dir: str | Path,
    *,
    command: list[str] | None = None,
    env: dict[str, str] | None = None,
) -> Contract:
    """Spawn the plugin briefly, capture its MANIFEST, and return a Contract."""
    project = Path(project_dir).resolve()
    launch = command if command is not None else _detect_command(project)
    with spawn(project, command=launch, env=env) as client:
        manifest = client.describe()
    tools_raw = manifest.get("tools") or []
    tools = [
        ToolSpec(
            name=str(t.get("name", "")),
            description=str(t.get("description", "")),
            parameters=list(t.get("parameters") or []),
        )
        for t in tools_raw
        if isinstance(t, dict) and t.get("name")
    ]
    tool_id = str(manifest.get("name") or _read_tool_id(project))
    return Contract(
        project_dir=project,
        tool_id=tool_id,
        version=str(manifest.get("version", "0.0.0")),
        manifest=manifest,
        tools=tools,
        launch_command=launch,
    )


__all__ = ["Contract", "ToolSpec", "contract_for"]
