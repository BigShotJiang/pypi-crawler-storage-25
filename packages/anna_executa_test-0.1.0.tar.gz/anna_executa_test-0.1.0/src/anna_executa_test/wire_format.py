"""Strict JSON-RPC 2.0 envelope shape checks.

Mirrors the validation in ``src/services/executa_wire.py`` (production
nexus). Use :func:`validate_response` and :func:`validate_request` in
tests to make sure the plugin emits envelopes the dispatcher will accept.
"""

from __future__ import annotations

from typing import Any


class WireFormatError(AssertionError):
    """Raised when an envelope violates JSON-RPC 2.0 + Anna conventions."""


def _require(cond: bool, msg: str) -> None:
    if not cond:
        raise WireFormatError(msg)


def validate_request(env: Any) -> None:
    """Validate a request envelope (``jsonrpc``, ``id``, ``method``)."""
    _require(isinstance(env, dict), f"request must be a dict, got {type(env).__name__}")
    _require(env.get("jsonrpc") == "2.0", f"request.jsonrpc must be '2.0', got {env.get('jsonrpc')!r}")
    _require("id" in env, "request must include 'id'")
    rid = env["id"]
    _require(isinstance(rid, (int, str)) or rid is None, f"request.id must be int|str|null, got {type(rid).__name__}")
    method = env.get("method")
    _require(isinstance(method, str) and method, "request.method must be a non-empty string")
    if "params" in env:
        _require(isinstance(env["params"], (dict, list)), "request.params must be dict or list")


def validate_response(env: Any) -> None:
    """Validate a response envelope (``jsonrpc``, ``id``, ``result`` xor ``error``)."""
    _require(isinstance(env, dict), f"response must be a dict, got {type(env).__name__}")
    _require(env.get("jsonrpc") == "2.0", f"response.jsonrpc must be '2.0', got {env.get('jsonrpc')!r}")
    _require("id" in env, "response must include 'id'")
    has_result = "result" in env
    has_error = "error" in env
    _require(has_result ^ has_error, "response must contain exactly one of 'result' or 'error'")
    if has_error:
        err = env["error"]
        _require(isinstance(err, dict), "response.error must be a dict")
        _require(isinstance(err.get("code"), int), "response.error.code must be int")
        _require(isinstance(err.get("message"), str), "response.error.message must be str")


def validate_invoke_result(result: Any) -> None:
    """Validate the conventional ``invoke`` payload shape ``{success, data|error}``."""
    _require(isinstance(result, dict), f"invoke result must be a dict, got {type(result).__name__}")
    _require("success" in result, "invoke result must include 'success'")
    _require(isinstance(result["success"], bool), "invoke result.success must be bool")
    if result["success"]:
        _require("data" in result, "invoke result.success=true must include 'data'")
    else:
        _require("error" in result, "invoke result.success=false must include 'error'")


__all__ = [
    "WireFormatError",
    "validate_invoke_result",
    "validate_request",
    "validate_response",
]
