"""anna-executa-test — pytest helpers for Anna Executa plugins.

See ``README.md`` for usage. Phase 5 MVP — see
``matrix-nexus/docs/design/anna-app-local-dev-and-test.md``.
"""

from __future__ import annotations

from anna_executa_test import executa, wire_format
from anna_executa_test.client import ExecutaClient, ExecutaError, JsonRpcError
from anna_executa_test.contract import Contract, contract_for
from anna_executa_test.helpers import (
    assert_jsonrpc_error,
    assert_jsonrpc_ok,
    describe_plugin,
)

__all__ = [
    "Contract",
    "ExecutaClient",
    "ExecutaError",
    "JsonRpcError",
    "assert_jsonrpc_error",
    "assert_jsonrpc_ok",
    "contract_for",
    "describe_plugin",
    "executa",
    "wire_format",
]

__version__ = "0.1.0"
