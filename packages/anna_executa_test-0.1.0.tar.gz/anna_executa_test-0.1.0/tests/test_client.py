"""Smoke test for ExecutaClient against an in-tree fake plugin.

Runs without ``uv`` by invoking the fake via the current Python interpreter.
This exercises the JSON-RPC roundtrip, error mapping, and stderr drain.
"""

from __future__ import annotations

import sys
from pathlib import Path

import pytest

from anna_executa_test import (
    Contract,
    ExecutaClient,
    JsonRpcError,
    assert_jsonrpc_error,
    assert_jsonrpc_ok,
    contract_for,
    describe_plugin,
    executa,
)

FIXTURES = Path(__file__).parent / "fixtures"
FAKE = FIXTURES / "fake_plugin"


@pytest.fixture
def fake_command() -> list[str]:
    # Bypass `uv run` for hermetic CI — execute the fake module directly with
    # the current interpreter, against a pyproject that the contract reader
    # can still parse.
    return [sys.executable, str(FAKE / "fake_plugin.py")]


def test_describe_invoke_health(fake_command):
    with executa.spawn(FAKE, command=fake_command) as plugin:
        info = describe_plugin(plugin)
        assert info["name"] == "tool-fake-plugin-test0001"
        assert any(t["name"] == "echo" for t in info["tools"])

        ok = plugin.invoke("echo", {"text": "hi"})
        assert_jsonrpc_ok(ok)
        assert ok["data"]["echoed"] == "hi"

        bad = plugin.invoke("echo", {"text": "FAIL"})
        assert_jsonrpc_error(bad, code="BAD")

        with pytest.raises(JsonRpcError) as excinfo:
            plugin.call("nonexistent")
        assert excinfo.value.code == -32601


def test_contract_for(fake_command):
    contract = contract_for(FAKE, command=fake_command)
    assert isinstance(contract, Contract)
    assert contract.tool_id == "tool-fake-plugin-test0001"
    assert {t.name for t in contract.tools} == {"echo"}
    decorator = contract.parametrize_invoke({"echo-hi": ("echo", {"text": "hi"})})
    assert decorator is not None  # smoke: parametrize callable returned
