"""Hermetic tests for assertion helpers."""

from __future__ import annotations

import pytest

from anna_executa_test.client import JsonRpcError
from anna_executa_test.helpers import assert_jsonrpc_error, assert_jsonrpc_ok


def test_assert_ok():
    assert_jsonrpc_ok({"success": True, "data": {"x": 1}})
    with pytest.raises(AssertionError):
        assert_jsonrpc_ok({"success": False, "error": {}})
    with pytest.raises(AssertionError):
        assert_jsonrpc_ok({"success": True})  # missing data


def test_assert_error_from_exception():
    err = JsonRpcError(code=-32601, message="method not found: foo")
    assert_jsonrpc_error(err)
    assert_jsonrpc_error(err, code=-32601)
    assert_jsonrpc_error(err, message_contains="method not found")
    with pytest.raises(AssertionError):
        assert_jsonrpc_error(err, code=-32000)
    with pytest.raises(AssertionError):
        assert_jsonrpc_error(err, message_contains="banana")


def test_assert_error_from_payload():
    payload = {"success": False, "error": {"code": "DENIED", "message": "no perm"}}
    assert_jsonrpc_error(payload)
    assert_jsonrpc_error(payload, code="DENIED", message_contains="perm")
    with pytest.raises(AssertionError):
        assert_jsonrpc_error({"success": True, "data": {}})
