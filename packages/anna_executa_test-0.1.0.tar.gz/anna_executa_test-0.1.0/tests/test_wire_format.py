"""Hermetic tests for the wire-format validators."""

from __future__ import annotations

import pytest

from anna_executa_test.wire_format import (
    WireFormatError,
    validate_invoke_result,
    validate_request,
    validate_response,
)


def test_validate_request_ok():
    validate_request({"jsonrpc": "2.0", "id": 1, "method": "describe"})
    validate_request({"jsonrpc": "2.0", "id": "abc", "method": "invoke", "params": {"tool": "x"}})


@pytest.mark.parametrize(
    "env",
    [
        {"id": 1, "method": "x"},  # missing jsonrpc
        {"jsonrpc": "1.0", "id": 1, "method": "x"},  # bad version
        {"jsonrpc": "2.0", "method": "x"},  # missing id
        {"jsonrpc": "2.0", "id": 1},  # missing method
        {"jsonrpc": "2.0", "id": 1, "method": ""},  # empty method
        {"jsonrpc": "2.0", "id": 1, "method": "x", "params": "bad"},  # bad params
    ],
)
def test_validate_request_rejects(env):
    with pytest.raises(WireFormatError):
        validate_request(env)


def test_validate_response_ok():
    validate_response({"jsonrpc": "2.0", "id": 1, "result": {}})
    validate_response({"jsonrpc": "2.0", "id": 1, "error": {"code": -32000, "message": "x"}})


@pytest.mark.parametrize(
    "env",
    [
        {"jsonrpc": "2.0", "id": 1},  # neither result nor error
        {"jsonrpc": "2.0", "id": 1, "result": {}, "error": {"code": 0, "message": ""}},  # both
        {"jsonrpc": "2.0", "id": 1, "error": {"code": "x", "message": ""}},  # bad code
        {"jsonrpc": "2.0", "id": 1, "error": {"code": 0}},  # missing message
    ],
)
def test_validate_response_rejects(env):
    with pytest.raises(WireFormatError):
        validate_response(env)


def test_validate_invoke_result():
    validate_invoke_result({"success": True, "data": {"x": 1}})
    validate_invoke_result({"success": False, "error": {"code": "BAD", "message": "no"}})
    with pytest.raises(WireFormatError):
        validate_invoke_result({"success": True})  # missing data
    with pytest.raises(WireFormatError):
        validate_invoke_result({"success": False})  # missing error
    with pytest.raises(WireFormatError):
        validate_invoke_result({"data": {}})  # missing success
