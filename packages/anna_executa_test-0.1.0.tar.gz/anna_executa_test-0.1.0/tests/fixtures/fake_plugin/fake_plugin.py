#!/usr/bin/env python3
"""Minimal fake Executa plugin used by anna-executa-test's own tests."""

from __future__ import annotations

import json
import sys
from typing import Any

MANIFEST: dict[str, Any] = {
    "name": "tool-fake-plugin-test0001",
    "display_name": "Fake Plugin",
    "version": "0.0.1",
    "description": "echoes back; raises BAD on text='FAIL'.",
    "tools": [
        {
            "name": "echo",
            "description": "Echoes back its 'text' argument.",
            "parameters": [{"name": "text", "type": "string", "required": True}],
        }
    ],
}


def _send(env: dict[str, Any]) -> None:
    sys.stdout.write(json.dumps(env, ensure_ascii=False) + "\n")
    sys.stdout.flush()


def _handle_invoke(params: dict[str, Any]) -> dict[str, Any]:
    tool = params.get("tool")
    args = params.get("arguments") or {}
    if tool != "echo":
        return {"success": False, "error": {"code": "UNKNOWN_TOOL", "message": tool}}
    text = args.get("text", "")
    if text == "FAIL":
        return {"success": False, "error": {"code": "BAD", "message": "user requested failure"}}
    return {"success": True, "data": {"echoed": text}}


def main() -> None:
    print("[fake-plugin] ready", file=sys.stderr)
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        try:
            req = json.loads(line)
        except json.JSONDecodeError as exc:
            _send({"jsonrpc": "2.0", "id": None, "error": {"code": -32700, "message": str(exc)}})
            continue
        rid = req.get("id")
        method = req.get("method")
        params = req.get("params") or {}
        if method == "describe":
            _send({"jsonrpc": "2.0", "id": rid, "result": MANIFEST})
        elif method == "health":
            _send({"jsonrpc": "2.0", "id": rid, "result": {"status": "ok"}})
        elif method == "invoke":
            _send({"jsonrpc": "2.0", "id": rid, "result": _handle_invoke(params)})
        else:
            _send({"jsonrpc": "2.0", "id": rid, "error": {"code": -32601, "message": f"method not found: {method}"}})


if __name__ == "__main__":
    main()
