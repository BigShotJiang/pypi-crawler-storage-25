from pathlib import Path
from types import SimpleNamespace

import numpy as np
import torch
from PIL import Image

import pytest

from JwzTumor.nnunet.cache_prepare import (
    V2PriorCacheError,
    prepare_v2_artifacts,
    should_prepare_v2_artifacts,
    validate_v2_prior_cache,
)


def test_should_prepare_v2_artifacts_only_for_train_v2():
    cfg = SimpleNamespace(
        meta=SimpleNamespace(config_type="train_v2"),
        training=SimpleNamespace(stage="train_cls_nnunet_prior"),
    )

    assert should_prepare_v2_artifacts(cfg) is True


def test_validate_v2_prior_cache_reports_missing_ids(tmp_path):
    prob_dir = tmp_path / "prob"
    mask_dir = tmp_path / "mask"
    prob_dir.mkdir()
    mask_dir.mkdir()
    (prob_dir / "case001.npz").write_bytes(b"data")
    (mask_dir / "case001.png").write_bytes(b"data")
    cfg = SimpleNamespace(
        nnunet=SimpleNamespace(prob_dir=str(tmp_path / "prob"), mask_dir=str(tmp_path / "mask")),
    )

    with pytest.raises(V2PriorCacheError) as exc:
        validate_v2_prior_cache(cfg, ["case001", "case002"])

    assert "case002" in str(exc.value)
    assert "jwzt nnunet export" in str(exc.value)


def test_prepare_v2_artifacts_raises_when_prob_cache_missing(tmp_path, monkeypatch):
    monkeypatch.setattr("JwzTumor.nnunet.cache_prepare.expected_train_prior_ids", lambda cfg: ["case001"])
    cfg = SimpleNamespace(
        meta=SimpleNamespace(config_type="train_v2"),
        training=SimpleNamespace(stage="train_cls_nnunet_prior"),
        nnunet=SimpleNamespace(prob_dir=str(tmp_path / "prob"), mask_dir=str(tmp_path / "mask")),
        contour=SimpleNamespace(cache_dir=str(tmp_path / "contour")),
    )

    with pytest.raises(V2PriorCacheError):
        prepare_v2_artifacts(cfg)


def test_prepare_v2_artifacts_skips_existing_prob_and_mask_cache(tmp_path, monkeypatch):
    calls = []
    prob_dir = tmp_path / "prob"
    mask_dir = tmp_path / "mask"
    contour_dir = tmp_path / "contour"
    prob_dir.mkdir()
    mask_dir.mkdir()
    contour_dir.mkdir()
    (prob_dir / "case001.npz").write_bytes(b"data")
    (mask_dir / "case001.png").write_bytes(b"data")
    (contour_dir / "case001.npz").write_bytes(b"data")
    monkeypatch.setattr("JwzTumor.nnunet.cache_prepare.expected_train_prior_ids", lambda cfg: ["case001"])
    monkeypatch.setattr("JwzTumor.nnunet.cache_prepare.run_nnunet_predict_export", lambda cfg: calls.append("predict"))
    monkeypatch.setattr("JwzTumor.nnunet.cache_prepare.build_missing_contours", lambda cfg: calls.append("contour"))
    cfg = SimpleNamespace(
        meta=SimpleNamespace(config_type="train_v2"),
        training=SimpleNamespace(stage="train_cls_nnunet_prior"),
        nnunet=SimpleNamespace(prob_dir=str(prob_dir), mask_dir=str(mask_dir)),
        contour=SimpleNamespace(cache_dir=str(contour_dir)),
    )

    prepare_v2_artifacts(cfg)

    assert calls == []


def test_build_missing_contours_materializes_cache(tmp_path, monkeypatch):
    from JwzTumor.nnunet.cache_prepare import build_missing_contours

    prob_dir = tmp_path / "prob"
    mask_dir = tmp_path / "mask"
    contour_dir = tmp_path / "contour"
    prob_dir.mkdir()
    mask_dir.mkdir()
    np.savez_compressed(prob_dir / "case001.npz", seg_prob=np.ones((16, 16), dtype=np.float32))
    Image.fromarray(np.ones((16, 16), dtype=np.uint8) * 255).save(mask_dir / "case001.png")

    base_dataset = [
        {
            "image": torch.ones(1, 16, 16),
            "image_id": "case001",
            "label": torch.tensor(1),
        }
    ]
    monkeypatch.setattr("JwzTumor.nnunet.cache_prepare.build_contour_source_datasets", lambda cfg: [base_dataset])
    cfg = SimpleNamespace(
        nnunet=SimpleNamespace(prob_dir=str(prob_dir), mask_dir=str(mask_dir)),
        contour=SimpleNamespace(cache_dir=str(contour_dir), outer_height=8, inner_height=8, degrees=360),
    )

    build_missing_contours(cfg)

    assert (contour_dir / "case001.npz").exists()
