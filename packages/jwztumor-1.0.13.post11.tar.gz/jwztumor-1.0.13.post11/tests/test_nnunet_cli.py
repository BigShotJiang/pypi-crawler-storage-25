from typer.testing import CliRunner
import numpy as np
from PIL import Image
import subprocess

from JwzTumor.cli.main import app


def _write_busbra_prior_config(tmp_path, *, prior_source="dataset", dataset_prob_mode="binary", prob_mode=None):
    data_root = tmp_path / "BUSBRA"
    image_dir = data_root / "Images"
    mask_dir = data_root / "Masks"
    image_dir.mkdir(parents=True)
    mask_dir.mkdir()
    Image.fromarray(np.ones((8, 8), dtype=np.uint8) * 120).save(image_dir / "bus_0001-l.png")
    mask = np.zeros((8, 8), dtype=np.uint8)
    mask[2:6, 2:6] = 255
    Image.fromarray(mask).save(mask_dir / "mask_0001-l.png")
    (data_root / "bus_data.csv").write_text(
        "ID,Case,Pathology\nbus_0001-l,1,benign\n",
        encoding="utf-8",
    )
    prob_mode_line = f"  prob_mode: {prob_mode}\n" if prob_mode is not None else ""
    config = tmp_path / "train_v2.yaml"
    config.write_text(
        f"config_type: train_v2\n"
        f"training:\n"
        f"  stage: train_cls_nnunet_prior\n"
        f"nnunet:\n"
        f"  enabled: true\n"
        f"  prior_source: {prior_source}\n"
        f"  prior_dataset: train\n"
        f"  dataset_prob_mode: {dataset_prob_mode}\n"
        f"{prob_mode_line}"
        f"  predict_input_dir: /tmp/should-not-run-nnunet\n"
        f"  predict_output_dir: /tmp/should-not-run-nnunet-out\n"
        f"  model_dir: /tmp/should-not-run-nnunet-model\n"
        f"  prob_dir: {tmp_path / 'prob'}\n"
        f"  mask_dir: {tmp_path / 'seg_mask'}\n"
        f"contour:\n"
        f"  enabled: true\n"
        f"dataset:\n"
        f"  train_root: {data_root}\n"
        f"  train_image_dir: Images\n"
        f"  train_mask_dir: Masks\n"
        f"  train_csv: bus_data.csv\n"
        f"  model_input_size: 16\n",
        encoding="utf-8",
    )
    return config


def test_nnunet_command_group_is_registered():
    runner = CliRunner()

    result = runner.invoke(app, ["nnunet", "--help"])

    assert result.exit_code == 0
    assert "prepare" in result.stdout
    assert "preprocess" in result.stdout
    assert "train" in result.stdout
    assert "predict" in result.stdout
    assert "export" in result.stdout
    assert "pipeline" in result.stdout


def test_nnunet_preprocess_dry_run_prints_command():
    runner = CliRunner()

    result = runner.invoke(
        app,
        [
            "nnunet",
            "preprocess",
            "--dataset-id",
            "201",
            "--raw-dir",
            "/tmp/raw",
            "--preprocessed-dir",
            "/tmp/pre",
            "--results-dir",
            "/tmp/results",
            "--dry-run",
        ],
    )

    assert result.exit_code == 0
    assert "nnUNetv2_plan_and_preprocess" in result.stdout
    assert "nnUNet_raw=/tmp/raw" in result.stdout


def test_nnunet_train_dry_run_prints_command():
    runner = CliRunner()

    result = runner.invoke(
        app,
        [
            "nnunet",
            "train",
            "--dataset-id",
            "201",
            "--configuration",
            "2d",
            "--fold",
            "0",
            "--raw-dir",
            "/tmp/raw",
            "--preprocessed-dir",
            "/tmp/pre",
            "--results-dir",
            "/tmp/results",
            "--dry-run",
        ],
    )

    assert result.exit_code == 0
    assert "nnUNetv2_train 201 2d 0" in result.stdout


def test_nnunet_pipeline_dry_run_prints_preprocess_and_train():
    runner = CliRunner()

    result = runner.invoke(
        app,
        [
            "nnunet",
            "pipeline",
            "--dataset-id",
            "201",
            "--raw-dir",
            "/tmp/raw",
            "--preprocessed-dir",
            "/tmp/pre",
            "--results-dir",
            "/tmp/results",
            "--dry-run",
        ],
    )

    assert result.exit_code == 0
    assert "nnUNetv2_plan_and_preprocess" in result.stdout
    assert "nnUNetv2_train 201 2d 0" in result.stdout


def test_nnunet_pipeline_dry_run_can_include_predict_and_export():
    runner = CliRunner()

    result = runner.invoke(
        app,
        [
            "nnunet",
            "pipeline",
            "--dataset-id",
            "201",
            "--raw-dir",
            "/tmp/raw",
            "--preprocessed-dir",
            "/tmp/pre",
            "--results-dir",
            "/tmp/results",
            "--predict-input-dir",
            "/tmp/in",
            "--predict-output-dir",
            "/tmp/pred",
            "--model-dir",
            "/tmp/model",
            "--prob-dir",
            "/tmp/prob",
            "--mask-dir",
            "/tmp/mask",
            "--dry-run",
        ],
    )

    assert result.exit_code == 0
    assert "nnUNetv2_predict_from_modelfolder" in result.stdout
    assert "export predictions: /tmp/pred -> /tmp/prob, /tmp/mask" in result.stdout


def test_nnunet_predict_uses_train_v2_config_and_save_probabilities(tmp_path):
    config = tmp_path / "train_v2.yaml"
    config.write_text(
        "config_type: train_v2\n"
        "training:\n"
        "  stage: train_cls_nnunet_prior\n"
        "nnunet:\n"
        "  enabled: true\n"
        "  predict_input_dir: /tmp/v2-in\n"
        "  predict_output_dir: /tmp/v2-out\n"
        "  model_dir: /tmp/v2-model\n"
        "  folds: ['0']\n"
        "  checkpoint: checkpoint_best.pth\n"
        "  save_probabilities: true\n"
        "contour:\n"
        "  enabled: true\n",
        encoding="utf-8",
    )
    runner = CliRunner()

    result = runner.invoke(app, ["nnunet", "predict", "-c", str(config), "--dry-run"])

    assert result.exit_code == 0
    assert "-i /tmp/v2-in" in result.stdout
    assert "-o /tmp/v2-out" in result.stdout
    assert "-m /tmp/v2-model" in result.stdout
    assert "--save_probabilities" in result.stdout


def test_nnunet_predict_accepts_save_probabilities_typo_alias(tmp_path):
    config = tmp_path / "train_v2.yaml"
    config.write_text(
        "config_type: train_v2\n"
        "training:\n"
        "  stage: train_cls_nnunet_prior\n"
        "nnunet:\n"
        "  enabled: true\n"
        "  predict_input_dir: /tmp/v2-in\n"
        "  predict_output_dir: /tmp/v2-out\n"
        "  model_dir: /tmp/v2-model\n"
        "  folds: ['0']\n"
        "  save_probabilities: false\n"
        "contour:\n"
        "  enabled: true\n",
        encoding="utf-8",
    )
    runner = CliRunner()

    result = runner.invoke(app, ["nnunet", "predict", "-c", str(config), "--save-probabilitiesd", "--dry-run"])

    assert result.exit_code == 0
    assert "--save_probabilities" in result.stdout


def test_nnunet_preprocess_help_exposes_verbose_option():
    runner = CliRunner()

    result = runner.invoke(app, ["nnunet", "preprocess", "--help"])

    assert result.exit_code == 0
    assert "--verbose" in result.stdout


def test_nnunet_prepare_help_exposes_verbose_option():
    runner = CliRunner()

    result = runner.invoke(app, ["nnunet", "prepare", "--help"])

    assert result.exit_code == 0
    assert "--verbose" in result.stdout


def test_nnunet_export_help_exposes_verbose_option():
    runner = CliRunner()

    result = runner.invoke(app, ["nnunet", "export", "--help"])

    assert result.exit_code == 0
    assert "--verbose" in result.stdout


def test_nnunet_preprocess_passes_verbose_to_runner(monkeypatch):
    calls = []

    def fake_run_command(command, env=None, verbose=False, description="nnUNet"):
        calls.append(
            {
                "command": command,
                "env": env,
                "verbose": verbose,
                "description": description,
            }
        )
        return subprocess.CompletedProcess(command, 0)

    monkeypatch.setattr("JwzTumor.cli.nnunet_cmd.run_command", fake_run_command)
    runner = CliRunner()

    result = runner.invoke(
        app,
        [
            "nnunet",
            "preprocess",
            "--dataset-id",
            "201",
            "--raw-dir",
            "/tmp/raw",
            "--preprocessed-dir",
            "/tmp/pre",
            "--results-dir",
            "/tmp/results",
            "--verbose",
        ],
    )

    assert result.exit_code == 0
    assert calls[0]["verbose"] is True
    assert calls[0]["description"] == "nnUNet preprocess"


def test_nnunet_predict_passes_verbose_to_runner(monkeypatch, tmp_path):
    config = tmp_path / "train_v2.yaml"
    config.write_text(
        "config_type: train_v2\n"
        "training:\n"
        "  stage: train_cls_nnunet_prior\n"
        "nnunet:\n"
        "  enabled: true\n"
        "  prior_source: nnunet\n"
        "  predict_input_dir: /tmp/v2-in\n"
        "  predict_output_dir: /tmp/v2-out\n"
        "  model_dir: /tmp/v2-model\n"
        "  folds: ['0']\n"
        "contour:\n"
        "  enabled: true\n",
        encoding="utf-8",
    )
    calls = []

    def fake_run_command(command, env=None, verbose=False, description="nnUNet"):
        calls.append(
            {
                "command": command,
                "env": env,
                "verbose": verbose,
                "description": description,
            }
        )
        return subprocess.CompletedProcess(command, 0)

    monkeypatch.setattr("JwzTumor.cli.nnunet_cmd.run_command", fake_run_command)
    runner = CliRunner()

    result = runner.invoke(app, ["nnunet", "predict", "-c", str(config), "--verbose"])

    assert result.exit_code == 0
    assert calls[0]["verbose"] is True
    assert calls[0]["description"] == "nnUNet predict"


def test_nnunet_prepare_uses_local_progress_runner(monkeypatch, tmp_path):
    image_dir = tmp_path / "images"
    mask_dir = tmp_path / "masks"
    raw_dir = tmp_path / "raw"
    image_dir.mkdir()
    mask_dir.mkdir()
    Image.fromarray(np.ones((8, 8), dtype=np.uint8) * 127).save(image_dir / "bus_0001-l.png")
    Image.fromarray(np.ones((8, 8), dtype=np.uint8) * 255).save(mask_dir / "mask_0001-l.png")
    calls = []

    def fake_local_task(description, verbose, fn, **kwargs):
        call_kwargs = dict(kwargs)
        calls.append(
            {
                "description": description,
                "verbose": verbose,
                "kwargs": call_kwargs,
            }
        )
        kwargs.pop("total", None)
        return fn(**kwargs)

    monkeypatch.setattr("JwzTumor.cli.nnunet_cmd._run_local_task", fake_local_task)
    runner = CliRunner()

    result = runner.invoke(
        app,
        [
            "nnunet",
            "prepare",
            "--image-dir",
            str(image_dir),
            "--mask-dir",
            str(mask_dir),
            "--raw-dir",
            str(raw_dir),
            "--dataset-id",
            "201",
            "--dataset-name",
            "BUS",
            "--verbose",
        ],
    )

    assert result.exit_code == 0
    assert calls[0]["description"] == "nnUNet prepare"
    assert calls[0]["verbose"] is True


def test_nnunet_export_uses_local_progress_runner_for_dataset_source(monkeypatch, tmp_path):
    config = _write_busbra_prior_config(tmp_path, prior_source="dataset", dataset_prob_mode="binary")
    calls = []

    def fake_local_task(description, verbose, fn, **kwargs):
        call_kwargs = dict(kwargs)
        calls.append(
            {
                "description": description,
                "verbose": verbose,
                "kwargs": call_kwargs,
            }
        )
        kwargs.pop("total", None)
        return fn(**kwargs)

    monkeypatch.setattr("JwzTumor.cli.nnunet_cmd._run_local_task", fake_local_task)
    runner = CliRunner()

    result = runner.invoke(app, ["nnunet", "export", "-c", str(config), "--verbose"])

    assert result.exit_code == 0
    assert calls[0]["description"] == "nnUNet export"
    assert calls[0]["verbose"] is True


class _FakePipelineDisplay:
    def start(self):
        return None

    def update(self, *args, **kwargs):
        return None

    def mark_failed(self, *args, **kwargs):
        return None

    def mark_interrupted(self, *args, **kwargs):
        return None

    def stop(self):
        return None


def test_nnunet_pipeline_uses_stage_runner_for_multiple_commands(monkeypatch):
    calls = []

    monkeypatch.setattr("JwzTumor.cli.nnunet_cmd.NnunetDisplay", lambda *args, **kwargs: _FakePipelineDisplay())

    def fake_stage(display, description, stage_fn):
        calls.append(description)

    monkeypatch.setattr("JwzTumor.cli.nnunet_cmd._run_pipeline_stage", fake_stage)
    runner = CliRunner()

    result = runner.invoke(
        app,
        [
            "nnunet",
            "pipeline",
            "--dataset-id",
            "201",
            "--raw-dir",
            "/tmp/raw",
            "--preprocessed-dir",
            "/tmp/pre",
            "--results-dir",
            "/tmp/results",
            "--predict-input-dir",
            "/tmp/in",
            "--predict-output-dir",
            "/tmp/pred",
            "--model-dir",
            "/tmp/model",
            "--prob-dir",
            "/tmp/prob",
            "--mask-dir",
            "/tmp/mask",
        ],
    )

    assert result.exit_code == 0
    assert calls == [
        "nnUNet preprocess",
        "nnUNet train",
        "nnUNet predict",
        "nnUNet export",
    ]


def test_nnunet_pipeline_stops_after_keyboard_interrupt(monkeypatch):
    calls = []

    monkeypatch.setattr("JwzTumor.cli.nnunet_cmd.NnunetDisplay", lambda *args, **kwargs: _FakePipelineDisplay())

    def fake_stage(display, description, stage_fn):
        calls.append(description)
        if description == "nnUNet train":
            raise KeyboardInterrupt()

    monkeypatch.setattr("JwzTumor.cli.nnunet_cmd._run_pipeline_stage", fake_stage)
    runner = CliRunner()

    result = runner.invoke(
        app,
        [
            "nnunet",
            "pipeline",
            "--dataset-id",
            "201",
            "--raw-dir",
            "/tmp/raw",
            "--preprocessed-dir",
            "/tmp/pre",
            "--results-dir",
            "/tmp/results",
        ],
        catch_exceptions=True,
    )

    assert result.exit_code == 130
    assert calls == ["nnUNet preprocess", "nnUNet train"]


def test_nnunet_predict_generates_dataset_prior_cache_without_running_nnunet(tmp_path):
    config = _write_busbra_prior_config(tmp_path, prior_source="dataset", dataset_prob_mode="binary")
    runner = CliRunner()

    result = runner.invoke(app, ["nnunet", "predict", "-c", str(config)])

    assert result.exit_code == 0
    assert "dataset" in result.stdout
    assert "Exported V2 prior cache: 1 samples" in result.stdout
    prob_path = tmp_path / "prob" / "bus_0001-l.npz"
    mask_path = tmp_path / "seg_mask" / "bus_0001-l.png"
    assert prob_path.exists()
    assert mask_path.exists()
    prob = np.load(prob_path)["seg_prob"]
    mask = np.array(Image.open(mask_path))
    assert set(np.unique(prob).tolist()) <= {0.0, 1.0}
    assert set(np.unique(mask).tolist()) <= {0, 255}


def test_nnunet_predict_accepts_dataset_mask_legacy_prior_source(tmp_path):
    config = _write_busbra_prior_config(tmp_path, prior_source="dataset_mask", dataset_prob_mode="distance")
    runner = CliRunner()

    result = runner.invoke(app, ["nnunet", "predict", "-c", str(config)])

    assert result.exit_code == 0
    prob = np.load(tmp_path / "prob" / "bus_0001-l.npz")["seg_prob"]
    assert set(np.unique(prob).tolist()) <= {0.0, 1.0}


def test_nnunet_predict_generated_prob_legacy_uses_dataset_prob_mode(tmp_path):
    config = _write_busbra_prior_config(
        tmp_path,
        prior_source="generated_prob",
        dataset_prob_mode="distance",
        prob_mode="binary",
    )
    runner = CliRunner()

    result = runner.invoke(app, ["nnunet", "predict", "-c", str(config)])

    assert result.exit_code == 0
    prob = np.load(tmp_path / "prob" / "bus_0001-l.npz")["seg_prob"]
    unique_count = len(np.unique(prob))
    assert unique_count > 2


def test_nnunet_export_generated_prob_from_config(tmp_path):
    data_root = tmp_path / "BUSBRA"
    image_dir = data_root / "Images"
    mask_dir = data_root / "Masks"
    image_dir.mkdir(parents=True)
    mask_dir.mkdir()
    Image.fromarray(np.ones((8, 8), dtype=np.uint8) * 120).save(image_dir / "bus_0001-l.png")
    Image.fromarray(np.ones((8, 8), dtype=np.uint8) * 255).save(mask_dir / "mask_0001-l.png")
    (data_root / "bus_data.csv").write_text(
        "ID,Case,Pathology\nbus_0001-l,1,benign\n",
        encoding="utf-8",
    )
    config = tmp_path / "train_v2.yaml"
    config.write_text(
        f"config_type: train_v2\n"
        f"training:\n"
        f"  stage: train_cls_nnunet_prior\n"
        f"nnunet:\n"
        f"  enabled: true\n"
        f"  prior_source: generated_prob\n"
        f"  prior_dataset: train\n"
        f"  prob_mode: binary\n"
        f"  prob_dir: {tmp_path / 'prob'}\n"
        f"  mask_dir: {tmp_path / 'seg_mask'}\n"
        f"contour:\n"
        f"  enabled: true\n"
        f"dataset:\n"
        f"  train_root: {data_root}\n"
        f"  train_image_dir: Images\n"
        f"  train_mask_dir: Masks\n"
        f"  train_csv: bus_data.csv\n"
        f"  model_input_size: 16\n",
        encoding="utf-8",
    )
    runner = CliRunner()

    result = runner.invoke(app, ["nnunet", "export", "-c", str(config)])

    assert result.exit_code == 0
    assert (tmp_path / "prob" / "bus_0001-l.npz").exists()
    assert (tmp_path / "seg_mask" / "bus_0001-l.png").exists()


def test_nnunet_prepare_exports_png_pairs(tmp_path):
    image_dir = tmp_path / "images"
    mask_dir = tmp_path / "masks"
    raw_dir = tmp_path / "raw"
    image_dir.mkdir()
    mask_dir.mkdir()
    Image.fromarray(np.ones((8, 8), dtype=np.uint8) * 127).save(image_dir / "bus_0001-l.png")
    Image.fromarray(np.ones((8, 8), dtype=np.uint8) * 255).save(mask_dir / "mask_0001-l.png")

    runner = CliRunner()
    result = runner.invoke(
        app,
        [
            "nnunet",
            "prepare",
            "--image-dir",
            str(image_dir),
            "--mask-dir",
            str(mask_dir),
            "--raw-dir",
            str(raw_dir),
            "--dataset-id",
            "201",
            "--dataset-name",
            "BUS",
        ],
    )

    assert result.exit_code == 0
    assert (raw_dir / "Dataset201_BUS" / "imagesTr" / "bus_0001-l_0000.png").exists()
