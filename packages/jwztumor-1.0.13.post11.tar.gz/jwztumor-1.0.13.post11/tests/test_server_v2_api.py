import io

import numpy as np
from fastapi.testclient import TestClient
from PIL import Image

from JwzTumor.server.app import create_app
from JwzTumor.server.queue import PredictQueue


class DummyEngine:
    is_loaded = True
    device = "cpu"

    def run_inference(self, image, progress_callback=None):
        return {
            "label": "benign",
            "label_index": 0,
            "prob_malignant": 0.1,
            "prob_benign": 0.9,
            "seg_mask": "mask",
            "edge_map": "edge",
            "uncertainty_map": None,
            "contour_map": "contour",
            "inference_mode": "v2",
            "segmentation_source": "nnunetv2",
            "timings": {"nnunet_ms": 1},
            "processing_time_ms": 2,
        }


def png_bytes():
    buf = io.BytesIO()
    Image.fromarray(np.ones((8, 8), dtype=np.uint8) * 128).save(buf, format="PNG")
    return buf.getvalue()


def test_predict_sync_returns_v2_optional_fields():
    app = create_app(engine=DummyEngine(), queue=PredictQueue())

    with TestClient(app) as client:
        response = client.post(
            "/api/predict",
            files={"file": ("x.png", png_bytes(), "image/png")},
        )

    assert response.status_code == 200
    data = response.json()
    assert data["contour_map"] == "contour"
    assert data["inference_mode"] == "v2"
    assert data["segmentation_source"] == "nnunetv2"
