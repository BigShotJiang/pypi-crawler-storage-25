from JwzTumor.server.schemas import PredictResponse
from JwzTumor.utils.config import Config


def test_server_config_defaults_to_v1():
    cfg = Config()

    assert cfg.server.inference_mode == "v1"


def test_predict_response_accepts_v2_optional_fields():
    response = PredictResponse(
        label="benign",
        label_index=0,
        prob_malignant=0.2,
        prob_benign=0.8,
        seg_mask="mask",
        edge_map="edge",
        uncertainty_map=None,
        contour_map="contour",
        inference_mode="v2",
        segmentation_source="nnunetv2",
        timings={"nnunet_ms": 12, "contour_ms": 3},
        processing_time_ms=20,
    )

    assert response.contour_map == "contour"
    assert response.inference_mode == "v2"
    assert response.segmentation_source == "nnunetv2"
    assert response.timings["nnunet_ms"] == 12
