from pathlib import Path

import numpy as np
import torch
from PIL import Image

from JwzTumor.data.v2_prior_dataset import load_external_seg_prob


def test_load_external_seg_prob_reads_npz(tmp_path: Path):
    path = tmp_path / "case001.npz"
    np.savez_compressed(path, seg_prob=np.ones((32, 32), dtype=np.float32))

    tensor = load_external_seg_prob(path)

    assert tuple(tensor.shape) == (1, 32, 32)
    assert tensor.dtype == torch.float32


def test_multitask_collate_fn_stacks_v2_fields():
    from JwzTumor.data.collate import multitask_collate_fn

    batch = [
        {
            "image": torch.zeros(1, 8, 8),
            "label": torch.tensor(0),
            "external_seg_prob": torch.zeros(1, 8, 8),
            "polar_contour": torch.zeros(1, 16, 360),
        },
        {
            "image": torch.zeros(1, 8, 8),
            "label": torch.tensor(1),
            "external_seg_prob": torch.zeros(1, 8, 8),
            "polar_contour": torch.zeros(1, 16, 360),
        },
    ]

    out = multitask_collate_fn(batch)

    assert out["external_seg_prob"].shape == (2, 1, 8, 8)
    assert out["polar_contour"].shape == (2, 1, 16, 360)


def test_v2_prior_dataset_writes_missing_contour_cache(tmp_path: Path):
    from types import SimpleNamespace

    from JwzTumor.data.v2_prior_dataset import V2PriorDataset

    image = torch.ones(1, 32, 32)
    base_dataset = [
        {
            "image": image,
            "image_id": "case001",
            "label": torch.tensor(1),
        }
    ]
    prob_dir = tmp_path / "prob"
    mask_dir = tmp_path / "mask"
    contour_dir = tmp_path / "contour"
    prob_dir.mkdir()
    mask_dir.mkdir()
    np.savez_compressed(prob_dir / "case001.npz", seg_prob=np.ones((32, 32), dtype=np.float32))
    Image.fromarray(np.ones((32, 32), dtype=np.uint8) * 255).save(mask_dir / "case001.png")

    cfg = SimpleNamespace(
        nnunet=SimpleNamespace(prob_dir=str(prob_dir), mask_dir=str(mask_dir)),
        contour=SimpleNamespace(cache_dir=str(contour_dir), outer_height=8, inner_height=8, degrees=360),
    )

    dataset = V2PriorDataset(base_dataset, cfg)
    sample = dataset[0]

    cache_path = contour_dir / "case001.npz"
    assert cache_path.exists()
    cached = np.load(cache_path)
    assert "polar_contour" in cached
    assert "polar_reentry_mask" in cached
    assert sample["polar_contour"].shape == (1, 16, 360)
