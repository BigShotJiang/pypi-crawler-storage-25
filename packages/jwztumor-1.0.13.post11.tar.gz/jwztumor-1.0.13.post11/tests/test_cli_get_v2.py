from typer.testing import CliRunner

from JwzTumor.cli.main import app


def test_get_train_v2_template_contains_metadata():
    runner = CliRunner()

    result = runner.invoke(app, ["get", "-t", "train_v2"])

    assert result.exit_code == 0
    assert "config_type: train_v2" in result.stdout
    assert "config_version: '2.0'" in result.stdout
    assert "stage: train_cls_nnunet_prior" in result.stdout
    assert "prior_source:" in result.stdout
    assert "generated_prob" in result.stdout
    assert "save_probabilities:" in result.stdout
    assert "prepare/export/predict/pipeline" in result.stdout
