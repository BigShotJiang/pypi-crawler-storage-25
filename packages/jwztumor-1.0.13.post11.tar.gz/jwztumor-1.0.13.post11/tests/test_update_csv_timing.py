"""Tests for CSV re-read timing fix in jwzt update."""
from __future__ import annotations

import os
import subprocess
from unittest.mock import patch

import pytest


_MOCK_CSV_ROWS = [
    {
        "version": "1.0.13.post7",
        "date": "2026-05-09",
        "type": "fix",
        "title": "UPDATE.md 内容修复",
        "description": "修复 jwzt update 生成的 UPDATE.md 内容为空的问题",
        "migration_steps": "无需额外操作。重新运行 jwzt update 即可。",
    },
    {
        "version": "1.0.13.post6",
        "date": "2026-05-09",
        "type": "fix",
        "title": "update.log 日志补全",
        "description": "修复 update.log 未在部分路径写入的问题",
        "migration_steps": "无需额外操作。",
    },
    {
        "version": "1.0.13.post5",
        "date": "2026-05-09",
        "type": "fix",
        "title": "版本自动检测修复",
        "description": "修复版本自动检测死代码问题",
        "migration_steps": "无需额外操作。",
    },
]


class TestCSVReReadAfterInstall:
    """Verify CSV is re-read after pip install succeeds."""

    def test_csv_read_after_pip_install_linux(self, tmp_path):
        """On Linux, load_update_log should be called AFTER pip install."""
        from JwzTumor.cli.update_cmd import update

        call_order: list[str] = []

        def mock_pip_install(args, timeout=120):
            call_order.append("pip_install")
            return subprocess.CompletedProcess(
                args=args, returncode=0, stdout="ok", stderr=""
            )

        def mock_load_csv():
            call_order.append("load_csv")
            return _MOCK_CSV_ROWS

        with (
            patch("JwzTumor.cli.update_cmd._is_windows", return_value=False),
            patch("JwzTumor.cli.update_cmd._run_pip_install", side_effect=mock_pip_install),
            patch("JwzTumor.cli.update_cmd.load_update_log", side_effect=mock_load_csv),
            patch("JwzTumor.cli.update_cmd.check_for_update", return_value=("1.0.13.post7", True)),
            patch("JwzTumor.cli.update_cmd.filter_updates", return_value=_MOCK_CSV_ROWS[:1]),
            patch("JwzTumor.cli.update_cmd.log_update"),
            patch("JwzTumor.cli.update_cmd.render_update_md", return_value="# UPDATE"),
            patch("JwzTumor.cli.update_cmd.importlib.invalidate_caches"),
            patch("os.getcwd", return_value=str(tmp_path)),
        ):
            update()

        assert "pip_install" in call_order, f"pip_install not called: {call_order}"
        assert "load_csv" in call_order, f"load_csv not called: {call_order}"
        pip_idx = call_order.index("pip_install")
        csv_idx = call_order.index("load_csv")
        assert csv_idx > pip_idx, (
            f"load_csv (index {csv_idx}) should be after pip_install (index {pip_idx})"
        )

    def test_update_md_generated_with_content(self, tmp_path):
        """UPDATE.md should contain content rendered by real render_update_md."""
        from JwzTumor.cli.update_cmd import update

        with (
            patch("JwzTumor.cli.update_cmd._is_windows", return_value=False),
            patch("JwzTumor.cli.update_cmd.__version__", "1.0.13.post5"),
            patch("JwzTumor.cli.update_cmd._run_pip_install", return_value=subprocess.CompletedProcess(args=[], returncode=0, stdout="ok", stderr="")),
            patch("JwzTumor.cli.update_cmd.load_update_log", return_value=_MOCK_CSV_ROWS),
            patch("JwzTumor.cli.update_cmd.check_for_update", return_value=("1.0.13.post7", True)),
            patch("JwzTumor.cli.update_cmd.log_update"),
            patch("JwzTumor.cli.update_cmd.importlib.invalidate_caches"),
            patch("os.getcwd", return_value=str(tmp_path)),
        ):
            update()

        update_md = tmp_path / "UPDATE.md"
        assert update_md.exists(), "UPDATE.md was not created"
        content = update_md.read_text(encoding="utf-8")
        # Verify real render_update_md output contains expected data
        assert "V1.0.13.post7" in content, f"UPDATE.md missing version: {content}"
        assert "UPDATE.md 内容修复" in content, f"UPDATE.md missing title: {content}"
        assert "迁移步骤" in content, f"UPDATE.md missing migration section: {content}"

    def test_info_panel_has_no_version_gap(self, tmp_path):
        """Info panel should NOT contain the '版本差距' text."""
        from JwzTumor.cli.update_cmd import update
        from io import StringIO

        from rich.console import Console

        output = StringIO()

        with (
            patch("JwzTumor.cli.update_cmd._is_windows", return_value=False),
            patch("JwzTumor.cli.update_cmd._run_pip_install", return_value=subprocess.CompletedProcess(args=[], returncode=0, stdout="ok", stderr="")),
            patch("JwzTumor.cli.update_cmd.load_update_log", return_value=_MOCK_CSV_ROWS),
            patch("JwzTumor.cli.update_cmd.check_for_update", return_value=("1.0.13.post7", True)),
            patch("JwzTumor.cli.update_cmd.filter_updates", return_value=_MOCK_CSV_ROWS[:1]),
            patch("JwzTumor.cli.update_cmd.log_update"),
            patch("JwzTumor.cli.update_cmd.render_update_md", return_value="# UPDATE"),
            patch("JwzTumor.cli.update_cmd.importlib.invalidate_caches"),
            patch("os.getcwd", return_value=str(tmp_path)),
            patch("rich.console.Console", return_value=Console(file=output, width=120, force_terminal=True)),
        ):
            update()

        captured = output.getvalue()
        assert "版本差距" not in captured, f"'版本差距' still in output:\n{captured}"

    def test_csv_read_failure_does_not_crash(self, tmp_path):
        """If CSV read fails after install, update should not crash."""
        from JwzTumor.cli.update_cmd import update

        with (
            patch("JwzTumor.cli.update_cmd._is_windows", return_value=False),
            patch("JwzTumor.cli.update_cmd._run_pip_install", return_value=subprocess.CompletedProcess(args=[], returncode=0, stdout="ok", stderr="")),
            patch("JwzTumor.cli.update_cmd.load_update_log", side_effect=FileNotFoundError("CSV missing")),
            patch("JwzTumor.cli.update_cmd.check_for_update", return_value=("1.0.13.post7", True)),
            patch("JwzTumor.cli.update_cmd.log_update"),
            patch("JwzTumor.cli.update_cmd.importlib.invalidate_caches"),
            patch("os.getcwd", return_value=str(tmp_path)),
        ):
            # Should NOT raise -- graceful fallback
            update()


class TestFilterUpdatesWorks:
    """Verify filter_updates correctly selects rows between versions."""

    def test_filters_rows_between_versions(self):
        from JwzTumor.cli.update_log import filter_updates

        result = filter_updates(_MOCK_CSV_ROWS, "1.0.13.post5", "1.0.13.post7")
        versions = [r["version"] for r in result]
        assert "1.0.13.post7" in versions
        assert "1.0.13.post6" in versions
        assert "1.0.13.post5" not in versions

    def test_returns_empty_when_current_equals_latest(self):
        from JwzTumor.cli.update_log import filter_updates

        result = filter_updates(_MOCK_CSV_ROWS, "1.0.13.post7", "1.0.13.post7")
        assert result == []
