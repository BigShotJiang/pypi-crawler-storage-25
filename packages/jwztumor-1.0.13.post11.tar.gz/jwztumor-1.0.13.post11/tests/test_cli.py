"""Tests for CLI commands."""
from pathlib import Path
import tomllib

import pytest


def test_cli_import():
    from JwzTumor.cli.main import app
    assert app is not None


def test_version_import():
    from JwzTumor.cli.version_cmd import version_cmd
    assert version_cmd is not None


def test_train_cmd_import():
    from JwzTumor.cli.train_cmd import train_app
    assert train_app is not None


def test_pred_cmd_import():
    from JwzTumor.cli.pred_cmd import predict_app
    assert predict_app is not None


def test_eval_cmd_import():
    from JwzTumor.cli.eval_cmd import eval_app
    assert eval_app is not None


def test_get_cmd_import():
    from JwzTumor.cli.get_cmd import get_app
    assert get_app is not None


def test_audit_cmd_import():
    from JwzTumor.cli.audit_cmd import audit_app
    assert audit_app is not None


def test_cli_exposes_nnunet_group_and_train_v2_template():
    from typer.testing import CliRunner

    from JwzTumor.cli.main import app

    runner = CliRunner()
    assert runner.invoke(app, ["nnunet", "--help"]).exit_code == 0
    assert runner.invoke(app, ["get", "-t", "train_v2"]).exit_code == 0


def test_server_extra_installs_httpx_socks_support():
    pyproject = tomllib.loads(Path("pyproject.toml").read_text(encoding="utf-8"))
    server_deps = pyproject["project"]["optional-dependencies"]["server"]
    assert any(dep.startswith("httpx[socks]") for dep in server_deps)
