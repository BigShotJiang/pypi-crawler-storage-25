import types

import torch


def make_v2_config():
    cfg = types.SimpleNamespace()
    cfg.meta = types.SimpleNamespace(config_type="train_v2")
    cfg.model = types.SimpleNamespace(
        name="LABDG_DGBC_MTLNet_MPTC_V2",
        raw_input_channels=1,
        pre_channels=16,
        encoder_input_channels=16,
        encoder_channels=[64, 128, 256, 512],
        prompt_dim=128,
        challenge_dim=8,
        use_mamba=True,
        use_mpp=True,
        peritumoral_strategy="polar_contour",
        dropout=0.2,
    )
    cfg.dataset = types.SimpleNamespace(num_classes=2, model_input_size=64)
    return cfg


def test_v2_model_forward_uses_external_seg_prob():
    from JwzTumor.models.model_factory import create_model

    model = create_model(make_v2_config())
    image = torch.randn(2, 1, 64, 64)
    external_seg_prob = torch.rand(2, 1, 64, 64)
    polar_contour = torch.rand(2, 1, 16, 360)

    with torch.no_grad():
        outputs = model(
            image,
            external_seg_prob=external_seg_prob,
            polar_contour=polar_contour,
        )

    assert "cls_prob" in outputs
    assert outputs["cls_prob"].shape == (2, 2)
    assert torch.equal(outputs["seg_prob"], external_seg_prob)
