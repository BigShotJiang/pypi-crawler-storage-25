from types import SimpleNamespace

from JwzTumor.cli.server_cmd import _select_engine_class
from JwzTumor.server.engine import InferenceEngine
from JwzTumor.server.engine_v2 import InferenceEngineV2


def test_select_engine_defaults_to_v1():
    cfg = SimpleNamespace(server=SimpleNamespace(inference_mode="v1"))

    assert _select_engine_class(cfg) is InferenceEngine


def test_select_engine_uses_v2_when_configured():
    cfg = SimpleNamespace(server=SimpleNamespace(inference_mode="v2"))

    assert _select_engine_class(cfg) is InferenceEngineV2


def test_select_engine_rejects_unknown_mode():
    cfg = SimpleNamespace(server=SimpleNamespace(inference_mode="bad"))

    try:
        _select_engine_class(cfg)
    except ValueError as exc:
        assert "server.inference_mode" in str(exc)
    else:
        raise AssertionError("expected ValueError")
