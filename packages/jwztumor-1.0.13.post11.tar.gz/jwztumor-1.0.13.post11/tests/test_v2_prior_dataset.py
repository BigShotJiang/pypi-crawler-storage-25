"""Tests for V2PriorDataset resize-to-match behavior."""
from __future__ import annotations

from pathlib import Path
from types import SimpleNamespace

import numpy as np
import pytest
import torch
from PIL import Image


def _make_sample(image_id: str = "test_001", h: int = 512, w: int = 512):
    """Create a mock base dataset sample with preprocessed image."""
    return {
        "image_id": image_id,
        "image": torch.rand(1, h, w),
    }


def _make_circular_mask(h: int, w: int, cy: int, cx: int, radius: int = 50):
    """Create a circular binary mask."""
    yy, xx = np.ogrid[:h, :w]
    mask = ((yy - cy) ** 2 + (xx - cx) ** 2 < radius ** 2).astype(np.uint8) * 255
    return mask


class TestResizeToMatch:
    """Verify _resize_to_match correctly resizes tensors."""

    def test_no_resize_when_same_size(self):
        from JwzTumor.data.v2_prior_dataset import _resize_to_match

        t = torch.rand(1, 512, 512)
        result = _resize_to_match(t, 512, 512)
        assert result is t  # Same object, no copy

    def test_resize_bilinear(self):
        from JwzTumor.data.v2_prior_dataset import _resize_to_match

        t = torch.rand(1, 274, 353)
        result = _resize_to_match(t, 512, 512, mode="bilinear")
        assert result.shape == (1, 512, 512)

    def test_resize_nearest(self):
        from JwzTumor.data.v2_prior_dataset import _resize_to_match

        t = torch.rand(1, 274, 353)
        result = _resize_to_match(t, 512, 512, mode="nearest")
        assert result.shape == (1, 512, 512)


class TestV2PriorDatasetResize:
    """Verify V2PriorDataset resizes external artifacts at runtime."""

    def test_external_mask_resized_to_image_shape(self, tmp_path: Path):
        """External mask at original resolution should be resized to match image."""
        from JwzTumor.data.v2_prior_dataset import V2PriorDataset

        prob_dir = tmp_path / "seg_prob"
        mask_dir = tmp_path / "seg_mask"
        contour_dir = tmp_path / "polar_contour"
        prob_dir.mkdir()
        mask_dir.mkdir()
        contour_dir.mkdir()

        # Save seg_prob at original resolution (353x274, HxW)
        seg_prob = np.random.rand(353, 274).astype(np.float32)
        np.savez_compressed(prob_dir / "test_001.npz", seg_prob=seg_prob)

        # Save mask at original resolution (353x274)
        mask_arr = (np.random.rand(353, 274) > 0.5).astype(np.uint8) * 255
        Image.fromarray(mask_arr).save(mask_dir / "test_001.png")

        cfg = SimpleNamespace(
            nnunet=SimpleNamespace(prob_dir=str(prob_dir), mask_dir=str(mask_dir)),
            contour=SimpleNamespace(
                cache_dir=str(contour_dir),
                outer_height=4,
                inner_height=4,
                degrees=90,
            ),
        )

        base_dataset = [_make_sample("test_001", 512, 512)]

        dataset = V2PriorDataset(base_dataset, cfg)
        sample = dataset[0]

        assert sample["external_seg_prob"].shape[-2:] == (512, 512), (
            f"seg_prob shape: {sample['external_seg_prob'].shape}"
        )
        assert sample["external_mask"].shape[-2:] == (512, 512), (
            f"mask shape: {sample['external_mask'].shape}"
        )

    def test_polar_contour_built_with_matched_shapes(self, tmp_path: Path):
        """build_polar_contour should receive same-shape image and mask."""
        from JwzTumor.data.v2_prior_dataset import V2PriorDataset

        prob_dir = tmp_path / "seg_prob"
        mask_dir = tmp_path / "seg_mask"
        contour_dir = tmp_path / "polar_contour"
        prob_dir.mkdir()
        mask_dir.mkdir()
        # contour_dir intentionally NOT created -- triggers build path

        # Create a circular mask at 353x274
        mask_arr = _make_circular_mask(353, 274, cy=176, cx=137, radius=50)
        Image.fromarray(mask_arr).save(mask_dir / "test_001.png")

        seg_prob = np.random.rand(353, 274).astype(np.float32)
        np.savez_compressed(prob_dir / "test_001.npz", seg_prob=seg_prob)

        cfg = SimpleNamespace(
            nnunet=SimpleNamespace(prob_dir=str(prob_dir), mask_dir=str(mask_dir)),
            contour=SimpleNamespace(
                cache_dir=str(contour_dir),
                outer_height=4,
                inner_height=4,
                degrees=90,
            ),
        )

        base_dataset = [_make_sample("test_001", 512, 512)]

        # Should NOT raise ValueError about shape mismatch
        dataset = V2PriorDataset(base_dataset, cfg)
        sample = dataset[0]

        assert "polar_contour" in sample
        assert sample["polar_contour"].shape[0] == 1  # channel dim
        assert sample["polar_contour"].shape[1] == 8  # outer+inner=4+4
        assert sample["polar_contour"].shape[2] == 90  # degrees


class TestBuildPolarContourShapeValidation:
    """Verify build_polar_contour rejects mismatched shapes."""

    def test_raises_on_shape_mismatch(self):
        from JwzTumor.contour.polar import build_polar_contour

        image = np.random.rand(512, 512).astype(np.float32)
        mask = np.zeros((274, 353), dtype=np.uint8)
        mask[100:200, 100:200] = 1

        with pytest.raises(ValueError, match="same shape"):
            build_polar_contour(image, mask)
