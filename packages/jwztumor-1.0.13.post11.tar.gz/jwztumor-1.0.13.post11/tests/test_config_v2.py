import pytest

from JwzTumor.utils.config import Config


def test_config_loads_train_v2_metadata(tmp_path):
    path = tmp_path / "train_v2.yaml"
    path.write_text(
        "config_type: train_v2\n"
        "config_version: '2.0'\n"
        "training:\n"
        "  stage: train_cls_nnunet_prior\n"
        "nnunet:\n"
        "  enabled: true\n"
        "contour:\n"
        "  enabled: true\n",
        encoding="utf-8",
    )

    cfg = Config(str(path))

    assert cfg.meta.config_type == "train_v2"
    assert cfg.meta.config_version == "2.0"
    assert cfg.training.stage == "train_cls_nnunet_prior"
    assert cfg.nnunet.enabled is True
    assert cfg.contour.enabled is True
    assert cfg.nnunet.prior_source == "nnunet"
    assert cfg.nnunet.prior_dataset == "train"
    assert cfg.nnunet.prob_mode == "binary"
    assert cfg.nnunet.save_probabilities is True


def test_config_loads_v2_prior_cache_fields(tmp_path):
    path = tmp_path / "train_v2.yaml"
    path.write_text(
        "config_type: train_v2\n"
        "config_version: '2.0'\n"
        "training:\n"
        "  stage: train_cls_nnunet_prior\n"
        "nnunet:\n"
        "  enabled: true\n"
        "  configuration: 2d\n"
        "  fold: '1'\n"
        "  prior_source: generated_prob\n"
        "  prior_dataset: test\n"
        "  prob_mode: distance\n"
        "  prob_sigma: 2.5\n"
        "  foreground_channel: 1\n"
        "  threshold: 0.4\n"
        "  save_probabilities: false\n"
        "  predict_input_dir: dataset/v2/in\n"
        "  predict_output_dir: dataset/v2/out\n"
        "contour:\n"
        "  enabled: true\n",
        encoding="utf-8",
    )

    cfg = Config(str(path))

    assert cfg.nnunet.configuration == "2d"
    assert cfg.nnunet.fold == "1"
    assert cfg.nnunet.prior_source == "generated_prob"
    assert cfg.nnunet.prior_dataset == "test"
    assert cfg.nnunet.prob_mode == "distance"
    assert cfg.nnunet.prob_sigma == 2.5
    assert cfg.nnunet.foreground_channel == 1
    assert cfg.nnunet.threshold == 0.4
    assert cfg.nnunet.save_probabilities is False
    assert cfg.nnunet.predict_input_dir == "dataset/v2/in"
    assert cfg.nnunet.predict_output_dir == "dataset/v2/out"


def test_train_v2_requires_nnunet_and_contour_sections(tmp_path):
    path = tmp_path / "bad_train_v2.yaml"
    path.write_text(
        "config_type: train_v2\n"
        "config_version: '2.0'\n"
        "training:\n"
        "  stage: train_cls_nnunet_prior\n",
        encoding="utf-8",
    )

    with pytest.raises(ValueError, match="nnunet"):
        Config(str(path))
