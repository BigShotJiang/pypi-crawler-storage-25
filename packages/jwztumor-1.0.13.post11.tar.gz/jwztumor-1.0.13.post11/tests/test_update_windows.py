"""Tests for Windows self-update .bat script generation."""

from __future__ import annotations

import os
import sys
from unittest.mock import patch

import pytest


class TestPlatformCheck:
    """Test _is_windows helper."""

    def test_is_windows_on_win32(self):
        from JwzTumor.cli.update_cmd import _is_windows

        with patch.object(sys, "platform", "win32"):
            assert _is_windows() is True

    def test_is_windows_on_linux(self):
        from JwzTumor.cli.update_cmd import _is_windows

        with patch.object(sys, "platform", "linux"):
            assert _is_windows() is False

    def test_is_windows_on_darwin(self):
        from JwzTumor.cli.update_cmd import _is_windows

        with patch.object(sys, "platform", "darwin"):
            assert _is_windows() is False


class TestBatScriptGeneration:
    """Test _generate_bat_script output."""

    def test_bat_contains_timeout_wait(self):
        from JwzTumor.cli.update_cmd import _generate_bat_script

        script = _generate_bat_script(
            latest="1.0.14",
            python_exe=r"C:\Python312\python.exe",
            log_dir=r"C:\Users\test\.jwztumor",
        )
        assert "timeout /t 3 /nobreak >nul" in script

    def test_bat_contains_exact_version_install(self):
        from JwzTumor.cli.update_cmd import _generate_bat_script

        script = _generate_bat_script(
            latest="1.0.14",
            python_exe=r"C:\Python312\python.exe",
            log_dir=r"C:\Users\test\.jwztumor",
        )
        assert r'"C:\Python312\python.exe" -m pip install --no-cache-dir JwzTumor==1.0.14' in script

    def test_bat_contains_fallback_upgrade(self):
        from JwzTumor.cli.update_cmd import _generate_bat_script

        script = _generate_bat_script(
            latest="1.0.14",
            python_exe=r"C:\Python312\python.exe",
            log_dir=r"C:\Users\test\.jwztumor",
        )
        assert r'"C:\Python312\python.exe" -m pip install --no-cache-dir --upgrade JwzTumor' in script

    def test_bat_contains_log_write(self):
        from JwzTumor.cli.update_cmd import _generate_bat_script

        script = _generate_bat_script(
            latest="1.0.14",
            python_exe=r"C:\Python312\python.exe",
            log_dir=r"C:\Users\test\.jwztumor",
        )
        assert r"C:\Users\test\.jwztumor\update.log" in script
        assert "SUCCESS" in script
        assert "FAILED" in script

    def test_bat_contains_self_delete(self):
        from JwzTumor.cli.update_cmd import _generate_bat_script

        script = _generate_bat_script(
            latest="1.0.14",
            python_exe=r"C:\Python312\python.exe",
            log_dir=r"C:\Users\test\.jwztumor",
        )
        assert 'del /f "%~f0"' in script

    def test_bat_creates_log_dir(self):
        from JwzTumor.cli.update_cmd import _generate_bat_script

        script = _generate_bat_script(
            latest="1.0.14",
            python_exe=r"C:\Python312\python.exe",
            log_dir=r"C:\Users\test\.jwztumor",
        )
        assert r'if not exist "C:\Users\test\.jwztumor" mkdir "C:\Users\test\.jwztumor"' in script


class TestWindowsDetachedUpdate:
    """Test _windows_detached_update logic."""

    def test_generates_bat_and_exits(self, tmp_path):
        """On Windows, should create .bat file, launch Popen, and exit."""
        import typer as typer_mod

        from JwzTumor.cli.update_cmd import _windows_detached_update

        bat_path = str(tmp_path / "jwzt_update.bat")

        with (
            patch("JwzTumor.cli.update_cmd._generate_bat_script", return_value="@echo off\necho test"),
            patch("tempfile.gettempdir", return_value=str(tmp_path)),
            patch("subprocess.Popen") as mock_popen,
            patch("JwzTumor.cli.update_cmd.log_update"),
        ):
            from rich.console import Console

            console = Console(width=120)
            with pytest.raises(typer_mod.Exit) as exc_info:
                _windows_detached_update("1.0.14", console)

            assert exc_info.value.exit_code == 0

            # Should have written the .bat file
            assert os.path.exists(bat_path)

            # Should have launched Popen
            mock_popen.assert_called_once()

    def test_fallback_on_bat_write_failure(self):
        """If .bat generation fails, should show manual command and exit."""
        import typer as typer_mod

        from JwzTumor.cli.update_cmd import _windows_detached_update

        with (
            patch("JwzTumor.cli.update_cmd._generate_bat_script", side_effect=OSError("disk full")),
            patch("JwzTumor.cli.update_cmd.log_update"),
        ):
            from rich.console import Console

            console = Console(width=120, force_terminal=True)
            with pytest.raises(typer_mod.Exit) as exc_info:
                _windows_detached_update("1.0.14", console)

            assert exc_info.value.exit_code == 1
