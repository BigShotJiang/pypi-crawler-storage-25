import numpy as np

from JwzTumor.contour.polar import compute_tumor_mask_centroid, build_polar_contour


def test_compute_tumor_mask_centroid_uses_foreground_pixels():
    mask = np.zeros((8, 8), dtype=np.uint8)
    mask[5:7, 1:3] = 1

    cy, cx = compute_tumor_mask_centroid(mask)

    assert (cy, cx) == (6, 2)


def test_build_polar_contour_returns_16x360_matrix():
    image = np.linspace(0, 1, 64 * 64, dtype=np.float32).reshape(64, 64)
    mask = np.zeros((64, 64), dtype=np.uint8)
    mask[20:44, 24:40] = 1

    contour, reentry = build_polar_contour(image, mask, outer_height=8, inner_height=8, degrees=360)

    assert contour.shape == (16, 360)
    assert reentry.shape == (8, 360)


def test_reentry_repair_uses_same_height_global_mean_when_window_has_no_valid_neighbors():
    image = np.ones((32, 32), dtype=np.float32)
    mask = np.zeros((32, 32), dtype=np.uint8)
    mask[8:24, 12:20] = 1

    contour, reentry = build_polar_contour(image, mask, outer_height=8, inner_height=8, degrees=360)

    assert contour.shape == (16, 360)
    assert reentry.shape == (8, 360)
