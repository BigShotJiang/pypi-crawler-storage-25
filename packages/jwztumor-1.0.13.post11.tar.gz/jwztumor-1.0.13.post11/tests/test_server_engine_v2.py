import numpy as np
import torch
from types import SimpleNamespace

from JwzTumor.server.engine_v2 import (
    InferenceEngineV2,
    contour_to_base64_png,
    derive_edge_map,
    ensure_chw_tensor,
)


def test_contour_to_base64_png_encodes_matrix():
    contour = np.linspace(0, 1, 16 * 360, dtype=np.float32).reshape(16, 360)

    encoded = contour_to_base64_png(contour)

    assert isinstance(encoded, str)
    assert len(encoded) > 20


def test_ensure_chw_tensor_normalizes_shapes():
    tensor = ensure_chw_tensor(np.ones((8, 9), dtype=np.float32))

    assert tensor.shape == (1, 8, 9)
    assert tensor.dtype == torch.float32


def test_derive_edge_map_returns_same_spatial_shape():
    mask = torch.zeros(1, 8, 8)
    mask[:, 2:6, 2:6] = 1

    edge = derive_edge_map(mask)

    assert edge.shape == mask.shape
    assert edge.max().item() > 0


class DummyV2Model(torch.nn.Module):
    def forward(self, image, external_seg_prob=None, polar_contour=None, **kwargs):
        assert external_seg_prob is not None
        assert polar_contour is not None
        batch = image.shape[0]
        return {
            "cls_prob": torch.tensor([[0.25, 0.75]], dtype=torch.float32).repeat(batch, 1),
            "seg_prob": external_seg_prob,
        }


def make_v2_config(tmp_path):
    return SimpleNamespace(
        dataset=SimpleNamespace(model_input_size=32, pad_mode="constant"),
        training=SimpleNamespace(device="cpu"),
        inference=SimpleNamespace(threshold=0.5, use_tta=False),
        postprocess=SimpleNamespace(use_largest_component=False, min_region_size=1),
        nnunet=SimpleNamespace(model_dir=str(tmp_path / "model"), folds=["0"], checkpoint="checkpoint_best.pth"),
        contour=SimpleNamespace(outer_height=8, inner_height=8, degrees=360),
    )


def test_v2_engine_returns_contour_map_with_mocked_nnunet(tmp_path, monkeypatch):
    cfg = make_v2_config(tmp_path)
    engine = InferenceEngineV2(cfg)
    engine.model = DummyV2Model()

    def fake_predict(image, work_dir):
        prob = np.zeros((40, 40), dtype=np.float32)
        prob[10:22, 10:22] = 0.9
        mask = prob >= 0.5
        return prob, mask.astype(np.uint8)

    monkeypatch.setattr(engine, "_run_nnunet_predict", fake_predict)

    result = engine.run_inference(np.ones((40, 40), dtype=np.float32) * 128)

    assert result["label"] == "malignant"
    assert result["inference_mode"] == "v2"
    assert result["segmentation_source"] == "nnunetv2"
    assert result["contour_map"]
    assert result["timings"]["contour_ms"] >= 0
