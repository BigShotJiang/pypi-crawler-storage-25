import signal

import pytest
from rich.console import Group

from JwzTumor.nnunet import runner
from JwzTumor.nnunet.runner import build_predict_from_modelfolder_command
from JwzTumor.nnunet.runner import (
    build_nnunet_env,
    build_plan_and_preprocess_command,
    build_train_command,
)
from JwzTumor.utils.rich_nnunet import NnunetDisplay


class FakeConsole:
    def __init__(self, *args, **kwargs):
        self.print_calls = []

    def print(self, *args, **kwargs):
        self.print_calls.append((args, kwargs))


class FakeRunnerDisplay:
    def __init__(self, *, verbose, total, description):
        self.verbose = verbose
        self.total = total
        self.description = description
        self.updates = []
        self.logs = []
        self.terminal = []
        self.started = False
        self.stopped = False
        self.console = FakeConsole()

    def start(self):
        self.started = True

    def update(self, **kwargs):
        self.updates.append(kwargs)

    def add_log(self, line):
        self.logs.append(line)

    def mark_failed(self, status):
        self.terminal.append(("failed", status))

    def mark_interrupted(self, status):
        self.terminal.append(("interrupted", status))

    def stop(self):
        self.stopped = True


class FakeStdout:
    def __init__(self, events):
        self.events = events

    def __iter__(self):
        for event in self.events:
            if isinstance(event, BaseException):
                raise event
            yield event


class FakeProcess:
    def __init__(self, events, return_code=0, wait_side_effects=None):
        self.stdout = FakeStdout(events)
        self.return_code = return_code
        self.wait_calls = []
        self.pid = 4321
        self.wait_side_effects = list(wait_side_effects or [])

    def wait(self, timeout=None):
        self.wait_calls.append(timeout)
        if self.wait_side_effects:
            effect = self.wait_side_effects.pop(0)
            if isinstance(effect, BaseException):
                raise effect
            return effect
        return self.return_code


def _patch_runner_ui(monkeypatch):
    monkeypatch.setattr(runner, "NnunetDisplay", FakeRunnerDisplay)


def test_build_predict_from_modelfolder_command():
    cmd = build_predict_from_modelfolder_command(
        input_dir="/tmp/in",
        output_dir="/tmp/out",
        model_dir="/tmp/model",
        folds=["0", "1"],
        checkpoint="checkpoint_best.pth",
    )

    assert cmd[0].endswith("nnUNetv2_predict_from_modelfolder")
    assert "-i" in cmd
    assert "/tmp/in" in cmd
    assert "-o" in cmd
    assert "/tmp/out" in cmd
    assert "-m" in cmd
    assert "/tmp/model" in cmd
    assert "-chk" in cmd
    assert "checkpoint_best.pth" in cmd


def test_build_predict_from_modelfolder_can_save_probabilities():
    cmd = build_predict_from_modelfolder_command(
        input_dir="/tmp/in",
        output_dir="/tmp/out",
        model_dir="/tmp/model",
        save_probabilities=True,
    )

    assert "--save_probabilities" in cmd


def test_build_plan_and_preprocess_command():
    cmd = build_plan_and_preprocess_command(dataset_id="201", verify_dataset_integrity=True)

    assert cmd[0].endswith("nnUNetv2_plan_and_preprocess")
    assert "-d" in cmd
    assert "201" in cmd
    assert "--verify_dataset_integrity" in cmd


def test_build_train_command():
    cmd = build_train_command(dataset_id="201", configuration="2d", fold="0")

    assert cmd[0].endswith("nnUNetv2_train")
    assert cmd[-3:] == ["201", "2d", "0"]


def test_build_nnunet_env_sets_required_paths():
    env = build_nnunet_env(
        raw_dir="/tmp/raw",
        preprocessed_dir="/tmp/preprocessed",
        results_dir="/tmp/results",
        base_env={"KEEP": "1"},
    )

    assert env["nnUNet_raw"] == "/tmp/raw"
    assert env["nnUNet_preprocessed"] == "/tmp/preprocessed"
    assert env["nnUNet_results"] == "/tmp/results"
    assert env["KEEP"] == "1"


def test_nnunet_display_progress_only_mode_tracks_status():
    display = NnunetDisplay(verbose=False, total=3, description="nnUNet export")

    display.update(completed=1, status="copying")

    assert display.status == "copying"
    assert display.completed == 1
    assert display.recent_logs == []
    assert display.renderable is display.progress


def test_nnunet_display_tracks_status_and_recent_logs():
    display = NnunetDisplay(verbose=True, total=3, description="nnUNet export")

    display.add_log("line 1")
    display.update(completed=1, status="copying")

    assert display.recent_logs[-1] == "line 1"
    assert display.status == "copying"
    assert display.completed == 1
    assert isinstance(display.renderable, Group)


def test_nnunet_display_preserves_detail_when_update_omits_it():
    display = NnunetDisplay(verbose=False, total=3, description="nnUNet export")

    display.update(status="copying", detail="case_001.nii.gz")
    display.update(completed=1, status="segmenting")

    assert display.status == "segmenting"
    assert display.detail == "case_001.nii.gz"


def test_nnunet_display_trims_log_buffer_to_max_lines():
    display = NnunetDisplay(verbose=True, total=3, description="nnUNet export")

    for index in range(display.max_log_lines + 3):
        display.add_log(f"line {index}")

    assert len(display.recent_logs) == display.max_log_lines
    assert display.recent_logs[0] == "line 3"
    assert display.recent_logs[-1] == f"line {display.max_log_lines + 2}"


def test_nnunet_display_marks_terminal_states():
    done = NnunetDisplay(verbose=False, total=3, description="nnUNet export")
    failed = NnunetDisplay(verbose=True, total=3, description="nnUNet export")
    interrupted = NnunetDisplay(verbose=True, total=3, description="nnUNet export")

    done.stop()
    failed.mark_failed("failed")
    interrupted.mark_interrupted("interrupted")

    assert done.status == "done"
    assert failed.status == "failed"
    assert interrupted.status == "interrupted"


def test_nnunet_display_preserves_failed_terminal_state_after_stop():
    display = NnunetDisplay(verbose=True, total=3, description="nnUNet export")

    display.mark_failed("export failed")
    display.stop()

    assert display.status == "failed"
    assert display.detail == "export failed"


def test_nnunet_display_preserves_interrupted_terminal_state_after_stop():
    display = NnunetDisplay(verbose=True, total=3, description="nnUNet export")

    display.mark_interrupted("cancelled by user")
    display.stop()

    assert display.status == "interrupted"
    assert display.detail == "cancelled by user"


def test_run_command_captures_streamed_output_and_returns_completed_process(monkeypatch):
    _patch_runner_ui(monkeypatch)
    process = FakeProcess(["first line\n", "second line\n"], return_code=0)
    popen_calls = []

    def fake_popen(*args, **kwargs):
        popen_calls.append((args, kwargs))
        return process

    monkeypatch.setattr(runner.subprocess, "Popen", fake_popen)

    completed = runner.run_command(["nnUNetv2_train", "201", "2d", "0"])

    assert completed.args == ["nnUNetv2_train", "201", "2d", "0"]
    assert completed.returncode == 0
    assert completed.stdout == "first line\nsecond line\n"
    assert popen_calls[0][1]["start_new_session"] is True


def test_run_command_raises_called_process_error_with_combined_output(monkeypatch):
    _patch_runner_ui(monkeypatch)
    process = FakeProcess(["line one\n", "line two\n"], return_code=3)

    monkeypatch.setattr(runner.subprocess, "Popen", lambda *args, **kwargs: process)

    with pytest.raises(runner.subprocess.CalledProcessError) as exc_info:
        runner.run_command(["nnUNetv2_train", "201", "2d", "0"])

    assert exc_info.value.returncode == 3
    assert exc_info.value.output == "line one\nline two\n"


def test_run_command_interrupts_process_group_on_keyboard_interrupt(monkeypatch):
    _patch_runner_ui(monkeypatch)
    process = FakeProcess(["starting\n", KeyboardInterrupt()], return_code=0)
    terminated = []

    monkeypatch.setattr(runner.subprocess, "Popen", lambda *args, **kwargs: process)
    monkeypatch.setattr(
        runner,
        "_terminate_process_tree",
        lambda proc, timeout=3.0: terminated.append((proc, timeout)),
        raising=False,
    )

    with pytest.raises(KeyboardInterrupt):
        runner.run_command(["nnUNetv2_train", "201", "2d", "0"])

    assert terminated == [(process, 3.0)]


def test_run_command_interrupts_process_group_on_keyboard_interrupt_during_wait(monkeypatch):
    _patch_runner_ui(monkeypatch)
    process = FakeProcess(["starting\n"], wait_side_effects=[KeyboardInterrupt()])
    terminated = []

    monkeypatch.setattr(runner.subprocess, "Popen", lambda *args, **kwargs: process)
    monkeypatch.setattr(
        runner,
        "_terminate_process_tree",
        lambda proc, timeout=3.0: terminated.append((proc, timeout)),
    )

    with pytest.raises(KeyboardInterrupt):
        runner.run_command(["nnUNetv2_train", "201", "2d", "0"])

    assert terminated == [(process, 3.0)]


def test_terminate_process_tree_escalates_when_graceful_termination_times_out(monkeypatch):
    process = FakeProcess(
        [],
        wait_side_effects=[
            runner.subprocess.TimeoutExpired(cmd=["nnUNetv2_train"], timeout=3.0),
            0,
        ],
    )
    killpg_calls = []

    monkeypatch.setattr(runner.os, "name", "posix", raising=False)
    monkeypatch.setattr(runner.os, "getpgid", lambda pid: 9876)
    monkeypatch.setattr(runner.os, "killpg", lambda pgid, sig: killpg_calls.append((pgid, sig)))

    runner._terminate_process_tree(process)

    assert killpg_calls == [(9876, signal.SIGTERM), (9876, signal.SIGKILL)]
    assert process.wait_calls == [3.0, None]
