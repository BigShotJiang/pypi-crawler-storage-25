import torch

from JwzTumor.training.stage_trainer import StageTrainer


def test_train_cls_nnunet_prior_skips_segmentation_loss():
    trainer = object.__new__(StageTrainer)
    trainer.device = torch.device("cpu")
    trainer.stage = "train_cls_nnunet_prior"
    trainer.loss_factory = None
    outputs = {
        "cls_logits": torch.randn(2, 2, requires_grad=True),
        "seg_logits": torch.randn(2, 1, 8, 8, requires_grad=True),
    }
    batch = {"label": torch.tensor([0, 1]), "mask": torch.ones(2, 1, 8, 8)}

    loss = StageTrainer._compute_loss(trainer, outputs, batch)
    loss.backward()

    assert outputs["cls_logits"].grad is not None
    assert outputs["seg_logits"].grad is None
