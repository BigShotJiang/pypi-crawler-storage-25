from JwzTumor.server.report.prompt import build_report_messages
from JwzTumor.server.report.schemas import ReportImages, ReportRequest


def test_report_prompt_includes_single_v2_contour_map_image():
    req = ReportRequest(
        mode="single",
        case_info={"exam_id": "E1"},
        images=ReportImages(
            original="data:image/png;base64,original",
            contour_map="data:image/png;base64,contour",
        ),
        inference_result={},
    )

    messages = build_report_messages(req)
    user_content = messages[1]["content"]
    image_urls = [
        item["image_url"]["url"]
        for item in user_content
        if item.get("type") == "image_url"
    ]

    assert "data:image/png;base64,original" in image_urls
    assert "data:image/png;base64,contour" in image_urls
