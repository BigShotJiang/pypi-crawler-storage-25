from pathlib import Path
from types import SimpleNamespace

from JwzTumor.inference.predictor_v2 import should_use_v2_predictor


def test_should_use_v2_predictor_for_train_v2_configs():
    cfg = SimpleNamespace(meta=SimpleNamespace(config_type="train_v2"))

    assert should_use_v2_predictor(cfg) is True


def test_v2_predict_output_includes_contour_preview(tmp_path: Path):
    pred = {
        "image_id": "case001",
        "pred_label": 1,
        "prob_malignant": 0.9,
        "seg_mask": None,
        "contour_preview": "dummy",
    }

    assert "contour_preview" in pred
