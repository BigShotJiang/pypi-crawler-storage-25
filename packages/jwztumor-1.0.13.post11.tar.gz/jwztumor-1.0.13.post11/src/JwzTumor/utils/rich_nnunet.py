"""Rich display helper for nnUNet command progress and logs."""

from __future__ import annotations

from rich.console import Console, Group, RenderableType
from rich.live import Live
from rich.panel import Panel
from rich.progress import (
    BarColumn,
    Progress,
    SpinnerColumn,
    TextColumn,
    TimeElapsedColumn,
    TimeRemainingColumn,
)
from rich.text import Text


class NnunetDisplay:
    """Small Rich display wrapper for nnUNet CLI tasks."""

    def __init__(self, *, verbose: bool, total: int | None, description: str):
        self.verbose = verbose
        self.total = total
        self.description = description
        self.status = ""
        self.detail = ""
        self.completed = 0
        self.recent_logs: list[str] = []
        self.max_log_lines = 12
        self._terminal_state: str | None = None
        self.console = Console(stderr=True)
        self.live: Live | None = None

        self.progress = Progress(
            *self._build_columns(),
            console=self.console,
        )
        self.task_id = self.progress.add_task(
            self.description,
            total=self.total,
            completed=self.completed,
            status=self.status_text,
        )

    @property
    def status_text(self) -> str:
        return " | ".join(part for part in (self.status, self.detail) if part)

    @property
    def renderable(self) -> RenderableType:
        if not self.verbose:
            return self.progress
        return Group(self.progress, self._build_log_panel())

    def start(self) -> None:
        if self.live is not None:
            return
        self.live = Live(
            self.renderable,
            console=self.console,
            refresh_per_second=4,
            vertical_overflow="visible",
        )
        self.live.start()

    def update(
        self,
        *,
        advance: int = 0,
        completed: int | None = None,
        status: str = "",
        detail: str | None = None,
    ) -> None:
        if completed is not None:
            self.completed = completed
        elif advance:
            self.completed += advance

        if status:
            self.status = status
        if detail is not None:
            self.detail = detail

        update_kwargs: dict[str, int | str] = {"status": self.status_text}
        if completed is not None:
            update_kwargs["completed"] = completed
        elif advance:
            update_kwargs["advance"] = advance
        self.progress.update(self.task_id, **update_kwargs)
        self._refresh()

    def add_log(self, line: str) -> None:
        self.recent_logs.append(line)
        if len(self.recent_logs) > self.max_log_lines:
            self.recent_logs = self.recent_logs[-self.max_log_lines :]
        self._refresh()

    def mark_failed(self, status: str) -> None:
        self._set_terminal_state("failed", status)

    def mark_interrupted(self, status: str) -> None:
        self._set_terminal_state("interrupted", status)

    def stop(self) -> None:
        if self._terminal_state is None:
            self.status = "done"
            self.detail = ""
            self._terminal_state = "done"
            self.progress.update(self.task_id, status=self.status_text)
            self._refresh()
        if self.live is not None:
            self.live.stop()
            self.live = None

    def _build_columns(self):
        if self.total is None:
            return (
                SpinnerColumn(),
                TextColumn("[bold blue]{task.description}"),
                TextColumn("{task.fields[status]}", style="cyan"),
                TimeElapsedColumn(),
            )
        return (
            TextColumn("[bold blue]{task.description}"),
            BarColumn(bar_width=None),
            TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
            TextColumn("({task.completed}/{task.total})"),
            TextColumn("{task.fields[status]}", style="cyan"),
            TimeElapsedColumn(),
            TimeRemainingColumn(),
        )

    def _build_log_panel(self) -> Panel:
        pad = [""] * max(0, self.max_log_lines - len(self.recent_logs))
        content = Text("\n".join(pad + self.recent_logs), style="white")
        return Panel(
            content,
            title="[bold]nnUNet Log[/]",
            border_style="blue",
            height=self.max_log_lines + 2,
            padding=(0, 1),
        )

    def _refresh(self) -> None:
        if self.live is not None:
            self.live.update(self.renderable)

    def _set_terminal_state(self, state: str, detail: str = "") -> None:
        self._terminal_state = state
        self.status = state
        self.detail = detail
        self.progress.update(self.task_id, status=self.status_text)
        self._refresh()
