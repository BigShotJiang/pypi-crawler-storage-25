"""Learning rate scheduler utilities for JwzTumor."""
import logging
from typing import Optional

import torch
import torch.nn as nn
from torch.optim import Optimizer

logger = logging.getLogger(__name__)


def create_optimizer(
    model: nn.Module,
    config,
    stage: Optional[str] = None,
) -> Optimizer:
    """Create optimizer based on config and training stage.

    Args:
        model: The model to optimize.
        config: Config object with training.optimizer, training.learning_rate, training.weight_decay.
        stage: Training stage name for per-stage LR adjustment.

    Returns:
        Optimizer instance.
    """
    tr_cfg = config.training

    lr = tr_cfg.learning_rate
    wd = tr_cfg.weight_decay
    name = tr_cfg.optimizer.lower()

    # Per-stage learning rate adjustment
    if stage == "finetune_all":
        lr = lr * 0.1  # Small LR for fine-tuning
    elif stage == "pretrain_pre":
        lr = lr * 2.0  # Larger LR for pretraining

    if name == "adamw":
        optimizer = torch.optim.AdamW(
            model.parameters(), lr=lr, weight_decay=wd
        )
    elif name == "adam":
        optimizer = torch.optim.Adam(
            model.parameters(), lr=lr, weight_decay=wd
        )
    elif name == "sgd":
        optimizer = torch.optim.SGD(
            model.parameters(), lr=lr, weight_decay=wd, momentum=0.9
        )
    else:
        raise ValueError(f"Unknown optimizer: {name}")

    logger.info("Optimizer: %s, lr=%.6f, wd=%.6f, stage=%s", name, lr, wd, stage)
    return optimizer


def create_scheduler(
    optimizer: Optimizer,
    config,
    steps_per_epoch: int = 0,
) -> Optional[torch.optim.lr_scheduler.LRScheduler]:
    """Create learning rate scheduler.

    All scheduler-specific parameters are read from config.training.*.

    Args:
        optimizer: The optimizer to schedule.
        config: Config with training.scheduler and scheduler-specific fields.
        steps_per_epoch: Number of training steps per epoch.

    Returns:
        Scheduler instance or None.
    """
    tr_cfg = config.training
    name = getattr(tr_cfg, "scheduler", "").lower()

    if not name:
        return None

    epochs = tr_cfg.epochs
    min_lr = tr_cfg.min_lr

    if name in ("cosine", "cosineannealinglr"):
        t_max = getattr(tr_cfg, "cosine_t_max", 0) or epochs
        eta_min = getattr(tr_cfg, "cosine_eta_min", 0.0) or min_lr
        scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(
            optimizer, T_max=t_max, eta_min=eta_min
        )
    elif name == "cosineannealingwarmrestarts":
        t0 = getattr(tr_cfg, "warmrestart_t0", 10)
        t_mult = getattr(tr_cfg, "warmrestart_t_mult", 2)
        scheduler = torch.optim.lr_scheduler.CosineAnnealingWarmRestarts(
            optimizer, T_0=t0, T_mult=t_mult, eta_min=min_lr
        )
    elif name == "steplr":
        step_size = getattr(tr_cfg, "step_size", 0) or max(1, epochs // 3)
        gamma = getattr(tr_cfg, "step_gamma", 0.1)
        scheduler = torch.optim.lr_scheduler.StepLR(
            optimizer, step_size=step_size, gamma=gamma
        )
    elif name == "reducelronplateau":
        factor = getattr(tr_cfg, "plateau_factor", 0.5)
        patience = getattr(tr_cfg, "plateau_patience", 5)
        mode = getattr(tr_cfg, "plateau_mode", "max")
        scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
            optimizer, mode=mode, factor=factor, patience=patience
        )
    elif name == "onecyclelr":
        total_steps = epochs * steps_per_epoch
        scheduler = torch.optim.lr_scheduler.OneCycleLR(
            optimizer, max_lr=tr_cfg.learning_rate, total_steps=total_steps
        )
    else:
        logger.warning("Unknown scheduler: %s, no scheduler used.", name)
        return None

    logger.info("Scheduler: %s", name)
    return scheduler


def apply_freeze(
    model: nn.Module,
    stage: str,
    config,
) -> None:
    """Freeze/unfreeze model parameters based on training stage.

    Stages:
        - pretrain_pre: Freeze DGBC-MTLNet + MPTC-Head, train LABDG-Pre only
        - pretrain_seg: Freeze LABDG-Pre + MPTC-Head, train DGBC-MTLNet only
        - train_cls: Freeze LABDG-Pre + DGBC-MTLNet, train MPTC-Head only
        - finetune_all: Unfreeze all
    """
    # First unfreeze everything
    for param in model.parameters():
        param.requires_grad = True

    if stage == "pretrain_pre":
        # Freeze encoder, decoder, classification head
        for name, param in model.named_parameters():
            if any(k in name for k in ["encoder", "decoder", "mptc", "mpp"]):
                param.requires_grad = False

    elif stage == "pretrain_seg":
        # Freeze preprocessing and classification head
        for name, param in model.named_parameters():
            if any(k in name for k in ["labdg_pre", "mptc"]):
                param.requires_grad = False

    elif stage in ("train_cls", "train_cls_nnunet_prior"):
        # Freeze preprocessing and segmentation
        for name, param in model.named_parameters():
            if any(k in name for k in ["labdg_pre", "encoder", "decoder", "mpp"]):
                param.requires_grad = False

    # finetune_all: everything stays unfrozen

    trainable = sum(p.numel() for p in model.parameters() if p.requires_grad)
    total = sum(p.numel() for p in model.parameters())
    logger.info(
        "Stage %s: %d/%d parameters trainable (%.1f%%)",
        stage, trainable, total, 100 * trainable / max(total, 1),
    )
