"""Export V2 segmentation-prior caches from dataset masks."""
from __future__ import annotations

from pathlib import Path
from typing import Any, Callable, Mapping

import numpy as np
from scipy import ndimage

from ..data.busi_dataset import BUSIDataset
from ..data.busbra_dataset import BUSBRADataset
from ..data.preprocessing import BreastUSPreprocessor
from .prediction_export import export_prediction_arrays


def generate_probability_from_mask(mask: np.ndarray, mode: str = "binary", sigma: float = 3.0) -> np.ndarray:
    """Generate a deterministic soft probability map from a binary mask."""
    binary = (np.asarray(mask) > 0).astype(np.float32)
    mode = (mode or "binary").lower()
    sigma = max(float(sigma or 1.0), 1e-6)

    if mode == "binary":
        prob = binary
    elif mode == "gaussian":
        prob = ndimage.gaussian_filter(binary, sigma=sigma)
        max_val = float(prob.max())
        prob = prob / max_val if max_val > 1e-6 else prob
    elif mode == "distance":
        if binary.max() <= 0:
            prob = binary
        elif binary.min() >= 1:
            prob = binary
        else:
            inside = ndimage.distance_transform_edt(binary)
            outside = ndimage.distance_transform_edt(1.0 - binary)
            signed = inside - outside
            prob = 1.0 / (1.0 + np.exp(-signed / sigma))
    elif mode == "hybrid":
        smooth = ndimage.gaussian_filter(binary, sigma=sigma)
        max_val = float(smooth.max())
        smooth = smooth / max_val if max_val > 1e-6 else smooth
        prob = np.maximum(smooth * 0.85, binary * 0.95)
    else:
        raise ValueError("prob_mode must be one of: binary, gaussian, distance, hybrid")

    return np.clip(prob, 0.0, 1.0).astype(np.float32)


def export_dataset_prior_cache(
    config: Any,
    prior_dataset: str | None = None,
    prob_mode: str | None = None,
    prob_sigma: float | None = None,
    prob_dir: str | Path | None = None,
    mask_dir: str | Path | None = None,
    progress_callback: Callable[[Mapping[str, object]], None] | None = None,
) -> int:
    """Export V2 prior caches from BUSBRA or BUSI dataset masks."""
    nn_cfg = config.nnunet
    prior_dataset = (prior_dataset or getattr(nn_cfg, "prior_dataset", "train")).lower()
    prob_mode = prob_mode or getattr(nn_cfg, "dataset_prob_mode", "") or getattr(nn_cfg, "prob_mode", "binary")
    prob_sigma = float(prob_sigma if prob_sigma is not None else getattr(nn_cfg, "prob_sigma", 3.0))
    prob_dir = Path(prob_dir or getattr(nn_cfg, "prob_dir", "dataset/v2_cache/seg_prob"))
    mask_dir = Path(mask_dir or getattr(nn_cfg, "mask_dir", "dataset/v2_cache/seg_mask"))

    dataset = _build_prior_dataset(config, prior_dataset)
    total = len(dataset)
    count = 0
    for idx in range(total):
        sample = dataset[idx]
        mask = sample["mask"].squeeze(0).detach().cpu().numpy()
        prob = generate_probability_from_mask(mask, mode=prob_mode, sigma=prob_sigma)
        image_id = str(sample["image_id"])
        export_prediction_arrays(
            image_id=image_id,
            prob=prob,
            mask=(mask > 0).astype(np.uint8),
            prob_dir=prob_dir,
            mask_dir=mask_dir,
        )
        count += 1
        if progress_callback is not None:
            progress_callback(
                {
                    "total": total,
                    "completed": count,
                    "image_id": image_id,
                    "status": "exported",
                }
            )
    return count


def _build_prior_dataset(config: Any, prior_dataset: str):
    ds_cfg = config.dataset
    preprocessor = BreastUSPreprocessor(
        model_input_size=ds_cfg.model_input_size,
        pad_mode=ds_cfg.pad_mode,
        image_interpolation=getattr(ds_cfg, "image_interpolation", "bilinear"),
        mask_interpolation=getattr(ds_cfg, "mask_interpolation", "nearest"),
    )
    if prior_dataset == "train":
        return BUSBRADataset(
            data_root=str(ds_cfg.train_root),
            csv_path=str(Path(ds_cfg.train_root) / ds_cfg.train_csv),
            image_dir=ds_cfg.train_image_dir,
            mask_dir=ds_cfg.train_mask_dir,
            preprocessor=preprocessor,
            augmentation=None,
            cache=None,
            label_mapping=ds_cfg.label_mapping,
            is_train=False,
        )
    if prior_dataset == "test":
        return BUSIDataset(
            data_root=str(ds_cfg.test_root),
            classes=ds_cfg.test_classes,
            ignore_classes=ds_cfg.ignore_classes,
            preprocessor=preprocessor,
            augmentation=None,
            cache=None,
            label_mapping=ds_cfg.label_mapping,
            is_train=False,
        )
    raise ValueError("prior_dataset must be 'train' or 'test'")
