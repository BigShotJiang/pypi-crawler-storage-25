"""Export nnUNetv2 prediction arrays into JwzTumor V2 cache format."""
from __future__ import annotations

from pathlib import Path
from typing import Callable, Mapping

import numpy as np
from PIL import Image


def export_prediction_arrays(
    image_id: str,
    prob: np.ndarray,
    mask: np.ndarray,
    prob_dir: Path,
    mask_dir: Path,
) -> tuple[Path, Path]:
    """Write `seg_prob` as compressed NPZ and binary mask as PNG."""
    prob_dir = Path(prob_dir)
    mask_dir = Path(mask_dir)
    prob_dir.mkdir(parents=True, exist_ok=True)
    mask_dir.mkdir(parents=True, exist_ok=True)

    prob_path = prob_dir / f"{image_id}.npz"
    mask_path = mask_dir / f"{image_id}.png"
    np.savez_compressed(prob_path, seg_prob=np.asarray(prob, dtype=np.float32))
    Image.fromarray((np.asarray(mask) > 0).astype(np.uint8) * 255).save(mask_path)
    return prob_path, mask_path


def load_prediction_array(path: Path, key: str = "seg_prob") -> np.ndarray:
    """Load a prediction array from `.npy` or `.npz` input."""
    path = Path(path)
    if path.suffix == ".npz":
        data = np.load(path)
        if key in data:
            return data[key]
        for candidate in ("seg_prob", "probabilities", "softmax", "prob"):
            if candidate in data:
                return data[candidate]
        return data[data.files[0]]
    return np.load(path)


def extract_probability_map(array: np.ndarray, foreground_channel: int = -1) -> np.ndarray:
    """Return a single foreground probability map from nnUNet-style output."""
    prob = np.asarray(array, dtype=np.float32).squeeze()
    if prob.ndim == 3:
        if prob.shape[0] <= 8:
            prob = prob[int(foreground_channel)]
        elif prob.shape[-1] <= 8:
            prob = prob[..., int(foreground_channel)]
        else:
            prob = prob.squeeze()
    if prob.ndim != 2:
        raise ValueError(f"Expected a 2D probability map after channel selection, got shape {prob.shape}")
    if prob.size == 0:
        return prob.astype(np.float32)
    if float(np.nanmax(prob)) > 1.0 and float(np.nanmax(prob)) <= 255.0:
        prob = prob / 255.0
    return np.clip(prob, 0.0, 1.0).astype(np.float32)


def export_prediction_directory(
    source_dir: Path,
    prob_dir: Path,
    mask_dir: Path,
    threshold: float = 0.5,
    foreground_channel: int = -1,
    progress_callback: Callable[[Mapping[str, object]], None] | None = None,
) -> int:
    """Export every `.npz`/`.npy` probability file from a prediction directory."""
    source_dir = Path(source_dir)
    prediction_paths = sorted(list(source_dir.glob("*.npz")) + list(source_dir.glob("*.npy")))
    total = len(prediction_paths)
    count = 0
    for path in prediction_paths:
        prob = load_prediction_array(path, key="seg_prob")
        prob = extract_probability_map(prob, foreground_channel=foreground_channel)
        mask = (prob >= threshold).astype(np.uint8)
        export_prediction_arrays(path.stem, prob, mask, prob_dir, mask_dir)
        count += 1
        if progress_callback is not None:
            progress_callback(
                {
                    "total": total,
                    "completed": count,
                    "image_id": path.stem,
                    "status": "exported",
                }
            )
    if count == 0:
        raise FileNotFoundError(
            f"No probability .npz/.npy files found in {source_dir}. "
            "Run nnUNet prediction with --save-probabilities first."
        )
    return count
