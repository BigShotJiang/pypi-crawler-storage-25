"""Command builders and runners for nnUNetv2 CLI integration."""
from __future__ import annotations

import subprocess
import shutil
import os
import signal
from collections.abc import Sequence

from ..utils.rich_nnunet import NnunetDisplay


def build_predict_from_modelfolder_command(
    input_dir: str,
    output_dir: str,
    model_dir: str,
    folds: Sequence[str] | None = None,
    checkpoint: str = "",
    save_probabilities: bool = False,
) -> list[str]:
    """Build an nnUNetv2 prediction command without executing it."""
    executable = shutil.which("nnUNetv2_predict_from_modelfolder") or "nnUNetv2_predict_from_modelfolder"
    command = [executable, "-i", input_dir, "-o", output_dir, "-m", model_dir]
    if folds:
        command.extend(["-f", *[str(fold) for fold in folds]])
    if checkpoint:
        command.extend(["-chk", checkpoint])
    if save_probabilities:
        command.append("--save_probabilities")
    return command


def build_plan_and_preprocess_command(
    dataset_id: str,
    verify_dataset_integrity: bool = False,
) -> list[str]:
    """Build an nnUNetv2 plan/preprocess command without executing it."""
    executable = shutil.which("nnUNetv2_plan_and_preprocess") or "nnUNetv2_plan_and_preprocess"
    command = [executable, "-d", str(dataset_id)]
    if verify_dataset_integrity:
        command.append("--verify_dataset_integrity")
    return command


def build_train_command(
    dataset_id: str,
    configuration: str = "2d",
    fold: str = "0",
    trainer: str = "",
    plans: str = "",
    pretrained_weights: str = "",
) -> list[str]:
    """Build an nnUNetv2 train command without executing it."""
    executable = shutil.which("nnUNetv2_train") or "nnUNetv2_train"
    command = [executable, str(dataset_id), configuration, str(fold)]
    if trainer:
        command.extend(["-tr", trainer])
    if plans:
        command.extend(["-p", plans])
    if pretrained_weights:
        command.extend(["-pretrained_weights", pretrained_weights])
    return command


def build_nnunet_env(
    raw_dir: str,
    preprocessed_dir: str,
    results_dir: str,
    base_env: dict[str, str] | None = None,
) -> dict[str, str]:
    """Return an environment mapping with nnUNetv2 path variables set."""
    env = dict(base_env if base_env is not None else os.environ)
    env["nnUNet_raw"] = raw_dir
    env["nnUNet_preprocessed"] = preprocessed_dir
    env["nnUNet_results"] = results_dir
    return env


def _launch_process(
    command: Sequence[str],
    env: dict[str, str] | None = None,
) -> subprocess.Popen[str]:
    return subprocess.Popen(
        list(command),
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        bufsize=1,
        env=env,
        start_new_session=True,
    )


def _terminate_process_tree(process: subprocess.Popen, timeout: float = 3.0) -> None:
    try:
        os.killpg(os.getpgid(process.pid), signal.SIGTERM)
    except ProcessLookupError:
        return

    try:
        process.wait(timeout=timeout)
    except subprocess.TimeoutExpired:
        try:
            os.killpg(os.getpgid(process.pid), signal.SIGKILL)
        except ProcessLookupError:
            return
        process.wait()


def run_command(
    command: Sequence[str],
    env: dict[str, str] | None = None,
    verbose: bool = False,
    description: str = "nnUNet",
    display: NnunetDisplay | None = None,
) -> subprocess.CompletedProcess:
    """Run an external command with concise or verbose Rich output."""
    command_list = list(command)
    command_text = " ".join(command_list)
    output_lines: list[str] = []
    own_display = display is None
    active_display = display or NnunetDisplay(verbose=verbose, total=None, description=description)

    if own_display:
        active_display.start()

    process = _launch_process(command_list, env=env)
    assert process.stdout is not None
    try:
        active_display.update(status=description, detail="running")
        for line in process.stdout:
            clean = line.rstrip()
            output_lines.append(line)
            if clean:
                active_display.add_log(clean)
                active_display.update(status=description, detail=clean[:80])
        return_code = process.wait()
    except KeyboardInterrupt:
        active_display.mark_interrupted("interrupted")
        _terminate_process_tree(process)
        raise

    output = "".join(output_lines)
    if return_code != 0:
        active_display.mark_failed("failed")
        if own_display:
            active_display.stop()
        raise subprocess.CalledProcessError(return_code, command_list, output=output)
    if own_display:
        active_display.stop()
        if not verbose:
            active_display.console.print(f"[green]Completed[/green] {description}: {command_text}")
    return subprocess.CompletedProcess(command_list, return_code, stdout=output)
