"""V2 artifact cache preparation orchestration."""
from __future__ import annotations

import logging
from pathlib import Path

from ..data.v2_prior_dataset import V2PriorDataset
from .runner import build_predict_from_modelfolder_command, run_command

logger = logging.getLogger(__name__)


class V2PriorCacheError(RuntimeError):
    """Raised when V2 segmentation-prior caches are incomplete."""


def should_prepare_v2_artifacts(config) -> bool:
    """Return True when training needs nnUNet-prior V2 artifacts."""
    return (
        getattr(getattr(config, "meta", None), "config_type", "") == "train_v2"
        and getattr(getattr(config, "training", None), "stage", "") == "train_cls_nnunet_prior"
    )


def prepare_v2_artifacts(config) -> None:
    """Prepare missing V2 caches before DataLoader creation."""
    if not should_prepare_v2_artifacts(config):
        return
    validate_v2_prior_cache(config, expected_train_prior_ids(config))
    if not contour_cache_exists(config):
        logger.info("V2 polar contour cache missing; building contours")
        build_missing_contours(config)


def validate_v2_prior_cache(
    config,
    image_ids,
    repair_command: str = "jwzt nnunet export -c configs/train_v2.yaml",
    max_examples: int = 10,
) -> None:
    """Validate that every image id has V2 probability and mask cache files."""
    prob_dir = Path(getattr(config.nnunet, "prob_dir", ""))
    mask_dir = Path(getattr(config.nnunet, "mask_dir", ""))
    missing_prob = []
    missing_mask = []
    for image_id in image_ids:
        if not (prob_dir / f"{image_id}.npz").exists():
            missing_prob.append(str(image_id))
        if not (mask_dir / f"{image_id}.png").exists():
            missing_mask.append(str(image_id))

    if not missing_prob and not missing_mask:
        return

    parts = [
        "V2 prior cache is incomplete.",
        f"prob_dir: {prob_dir}",
        f"mask_dir: {mask_dir}",
    ]
    if missing_prob:
        parts.append(
            f"missing seg_prob npz ({len(missing_prob)}): "
            + ", ".join(missing_prob[:max_examples])
        )
    if missing_mask:
        parts.append(
            f"missing mask png ({len(missing_mask)}): "
            + ", ".join(missing_mask[:max_examples])
        )
    parts.append(f"Repair command: {repair_command}")
    raise V2PriorCacheError("\n".join(parts))


def expected_train_prior_ids(config) -> list[str]:
    """Return BUSBRA image ids expected by the configured train/val fold."""
    try:
        from ..data.busbra_dataset import BUSBRADataset
        from ..data.preprocessing import BreastUSPreprocessor
        from ..data.split_utils import load_cv_splits

        ds_cfg = config.dataset
        preprocessor = BreastUSPreprocessor(
            model_input_size=ds_cfg.model_input_size,
            pad_mode=ds_cfg.pad_mode,
            image_interpolation=ds_cfg.image_interpolation,
            mask_interpolation=ds_cfg.mask_interpolation,
        )
        cv_file = str(Path(ds_cfg.train_root) / ds_cfg.cv_file)
        train_ids, val_ids = load_cv_splits(
            cv_file,
            fold=ds_cfg.fold,
            case_level=ds_cfg.use_case_level_split,
        )
        expected = []
        for ids, is_train in ((train_ids, True), (val_ids, False)):
            dataset = BUSBRADataset(
                data_root=str(ds_cfg.train_root),
                csv_path=str(Path(ds_cfg.train_root) / ds_cfg.train_csv),
                image_dir=ds_cfg.train_image_dir,
                mask_dir=ds_cfg.train_mask_dir,
                case_ids=ids if ds_cfg.use_case_level_split else None,
                sample_ids=None if ds_cfg.use_case_level_split else ids,
                preprocessor=preprocessor,
                augmentation=None,
                cache=None,
                label_mapping=ds_cfg.label_mapping,
                is_train=is_train,
            )
            expected.extend(sample["image_id"] for sample in dataset.samples)
        return sorted(set(expected))
    except Exception as exc:
        logger.debug("Could not derive fold-specific V2 prior ids: %s", exc)
        return []


def prob_and_mask_cache_exists(config) -> bool:
    prob_dir = Path(getattr(config.nnunet, "prob_dir", ""))
    mask_dir = Path(getattr(config.nnunet, "mask_dir", ""))
    return prob_dir.is_dir() and mask_dir.is_dir() and any(prob_dir.glob("*.npz")) and any(mask_dir.glob("*.png"))


def contour_cache_exists(config) -> bool:
    contour_dir = Path(getattr(config.contour, "cache_dir", "dataset/v2_cache/polar_contour"))
    return contour_dir.is_dir() and any(contour_dir.glob("*.npz"))


def run_nnunet_predict_export(config) -> None:
    """Run configured nnUNetv2 model-folder prediction.

    The full prediction-to-cache export is exposed by `jwzt nnunet export`; this
    hook intentionally keeps the external call isolated and testable.
    """
    nn_cfg = config.nnunet
    input_dir = getattr(nn_cfg, "input_dir", "") or getattr(nn_cfg, "raw_dir", "")
    output_dir = getattr(nn_cfg, "output_dir", "") or getattr(nn_cfg, "results_dir", "")
    command = build_predict_from_modelfolder_command(
        input_dir=input_dir,
        output_dir=output_dir,
        model_dir=getattr(nn_cfg, "model_dir", ""),
        folds=getattr(nn_cfg, "folds", []),
        checkpoint=getattr(nn_cfg, "checkpoint", ""),
    )
    run_command(command)


def build_missing_contours(config) -> None:
    """Materialize missing contour caches by iterating configured source datasets."""
    contour_dir = Path(getattr(config.contour, "cache_dir", "dataset/v2_cache/polar_contour"))
    contour_dir.mkdir(parents=True, exist_ok=True)
    for base_dataset in build_contour_source_datasets(config):
        dataset = V2PriorDataset(base_dataset, config)
        for idx in range(len(dataset)):
            dataset[idx]


def build_contour_source_datasets(config):
    """Build source datasets used only for contour cache materialization."""
    from ..data.busbra_dataset import BUSBRADataset
    from ..data.preprocessing import BreastUSPreprocessor

    ds_cfg = config.dataset
    preprocessor = BreastUSPreprocessor(
        model_input_size=ds_cfg.model_input_size,
        pad_mode=ds_cfg.pad_mode,
        image_interpolation=ds_cfg.image_interpolation,
        mask_interpolation=ds_cfg.mask_interpolation,
    )
    csv_path = str(Path(ds_cfg.train_root) / ds_cfg.train_csv)
    yield BUSBRADataset(
        data_root=str(ds_cfg.train_root),
        csv_path=csv_path,
        image_dir=ds_cfg.train_image_dir,
        mask_dir=ds_cfg.train_mask_dir,
        preprocessor=preprocessor,
        augmentation=None,
        cache=None,
        label_mapping=ds_cfg.label_mapping,
        is_train=False,
    )
