"""Dataset wrapper and loaders for V2 nnUNet-prior artifacts."""
from __future__ import annotations

from pathlib import Path
from typing import Any

import numpy as np
import torch
from PIL import Image
from torch.utils.data import Dataset

from ..contour.polar import build_polar_contour


def load_external_seg_prob(path: Path) -> torch.Tensor:
    """Load cached nnUNetv2 probability map as `[1, H, W]` float tensor."""
    data = np.load(path)
    array = data["seg_prob"] if "seg_prob" in data else data[data.files[0]]
    return _to_chw_float_tensor(array)


def load_external_mask(path: Path) -> torch.Tensor:
    """Load cached binary mask as `[1, H, W]` float tensor."""
    if Path(path).suffix == ".npz":
        data = np.load(path)
        array = data["mask"] if "mask" in data else data[data.files[0]]
    else:
        array = np.asarray(Image.open(path))
    return _to_chw_float_tensor((array > 0).astype(np.float32))


def load_polar_cache(path: Path) -> tuple[torch.Tensor, torch.Tensor]:
    """Load cached polar contour and reentry mask tensors."""
    data = np.load(path)
    contour = data["polar_contour"] if "polar_contour" in data else data[data.files[0]]
    if "polar_reentry_mask" in data:
        reentry = data["polar_reentry_mask"]
    elif "reentry" in data:
        reentry = data["reentry"]
    else:
        reentry = np.zeros((0, contour.shape[-1]), dtype=np.float32)
    return _to_chw_float_tensor(contour), _to_chw_float_tensor(reentry)


def save_polar_cache(path: Path, contour: np.ndarray, reentry: np.ndarray) -> None:
    """Persist polar contour artifacts in the V2 cache format."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(
        path,
        polar_contour=np.asarray(contour, dtype=np.float32),
        polar_reentry_mask=np.asarray(reentry, dtype=np.float32),
    )


class V2PriorDataset(Dataset):
    """Wrap a V1 dataset and append V2 prior fields to every sample."""

    def __init__(self, base_dataset: Dataset, config: Any):
        self.base_dataset = base_dataset
        self.config = config
        self.prob_dir = Path(config.nnunet.prob_dir)
        self.mask_dir = Path(config.nnunet.mask_dir)
        self.contour_dir = Path(getattr(config.contour, "cache_dir", "dataset/v2_cache/polar_contour"))
        self.outer_height = int(getattr(config.contour, "outer_height", 8))
        self.inner_height = int(getattr(config.contour, "inner_height", 8))
        self.degrees = int(getattr(config.contour, "degrees", 360))

    def __len__(self) -> int:
        return len(self.base_dataset)

    def __getitem__(self, idx: int) -> dict[str, Any]:
        sample = self.base_dataset[idx]
        image_id = sample["image_id"]
        prob_path = self.prob_dir / f"{image_id}.npz"
        mask_path = self.mask_dir / f"{image_id}.png"
        contour_path = self.contour_dir / f"{image_id}.npz"

        external_seg_prob = load_external_seg_prob(prob_path)
        if mask_path.exists():
            external_mask = load_external_mask(mask_path)
        else:
            external_mask = (external_seg_prob >= 0.5).to(torch.float32)

        # Resize external artifacts to match base dataset image dimensions
        target_h, target_w = sample["image"].shape[-2:]
        external_seg_prob = _resize_to_match(external_seg_prob, target_h, target_w, mode="bilinear")
        external_mask = _resize_to_match(external_mask, target_h, target_w, mode="nearest")

        if contour_path.exists():
            polar_contour, polar_reentry_mask = load_polar_cache(contour_path)
        else:
            image_np = sample["image"].squeeze(0).detach().cpu().numpy()
            mask_np = external_mask.squeeze(0).detach().cpu().numpy()
            contour, reentry = build_polar_contour(
                image_np,
                mask_np,
                outer_height=self.outer_height,
                inner_height=self.inner_height,
                degrees=self.degrees,
            )
            save_polar_cache(contour_path, contour, reentry)
            polar_contour = torch.from_numpy(contour).unsqueeze(0)
            polar_reentry_mask = torch.from_numpy(reentry.astype(np.float32)).unsqueeze(0)

        sample["external_seg_prob"] = external_seg_prob
        sample["external_mask"] = external_mask
        sample["polar_contour"] = polar_contour
        sample["polar_reentry_mask"] = polar_reentry_mask
        return sample


def _to_chw_float_tensor(array: np.ndarray) -> torch.Tensor:
    arr = np.asarray(array, dtype=np.float32)
    if arr.ndim == 2:
        arr = arr[None, ...]
    return torch.from_numpy(arr)


def _resize_to_match(tensor: torch.Tensor, target_h: int, target_w: int, mode: str = "bilinear") -> torch.Tensor:
    """Resize a [1, H, W] tensor to [1, target_h, target_w]."""
    if tensor.shape[-2:] == (target_h, target_w):
        return tensor
    kwargs = {"size": (target_h, target_w), "mode": mode}
    if mode in ("linear", "bilinear", "bicubic", "trilinear"):
        kwargs["align_corners"] = False
    return torch.nn.functional.interpolate(
        tensor.unsqueeze(0), **kwargs,
    ).squeeze(0)
