"""Dataset factory for creating train/val/test datasets."""
import logging
from typing import Any, Dict, Optional, Tuple

import numpy as np
from torch.utils.data import DataLoader

from .busbra_dataset import BUSBRADataset
from .busi_dataset import BUSIDataset
from .preprocessing import BreastUSPreprocessor
from .augmentation import BreastUSAugmentation
from .cache import DatasetCache
from .collate import multitask_collate_fn
from .split_utils import load_cv_splits
from .v2_prior_dataset import V2PriorDataset

logger = logging.getLogger(__name__)


def create_dataloaders(
    config,
    preprocessor: Optional[BreastUSPreprocessor] = None,
    augmentation: Optional[BreastUSAugmentation] = None,
    cache: Optional[DatasetCache] = None,
) -> Tuple[DataLoader, DataLoader, Optional[DataLoader]]:
    """Create train/val/test DataLoaders from config.

    Args:
        config: Config object with dataset and training settings.
        preprocessor: Optional preprocessor instance.
        augmentation: Optional augmentation pipeline.
        cache: Optional dataset cache.

    Returns:
        (train_loader, val_loader, test_loader)
    """
    ds_cfg = config.dataset
    tr_cfg = config.training

    preprocessor = preprocessor or BreastUSPreprocessor(
        model_input_size=ds_cfg.model_input_size,
        pad_mode=ds_cfg.pad_mode,
        image_interpolation=ds_cfg.image_interpolation,
        mask_interpolation=ds_cfg.mask_interpolation,
    )

    augmentation = augmentation or (
        BreastUSAugmentation(config.augmentation) if augmentation is None and tr_cfg.stage in ("pretrain_pre", "pretrain_seg", "train_cls", "finetune_all") else None
    )

    cache = cache or DatasetCache(mode=ds_cfg.cache_mode)

    # Use split_seed for reproducible data splitting and DataLoader shuffling
    split_seed = ds_cfg.split_seed
    import torch
    g = torch.Generator()
    g.manual_seed(split_seed)

    def _worker_init_fn(worker_id):
        """Seed each worker deterministically from split_seed."""
        import random
        worker_seed = split_seed + worker_id
        random.seed(worker_seed)
        np.random.seed(worker_seed)

    # Load CV splits for BUSBRA
    cv_file = str(ds_cfg.train_root) + "/" + ds_cfg.cv_file
    train_ids, val_ids = load_cv_splits(
        cv_file,
        fold=ds_cfg.fold,
        case_level=ds_cfg.use_case_level_split,
    )

    # Create BUSBRA datasets
    csv_path = str(ds_cfg.train_root) + "/" + ds_cfg.train_csv

    train_dataset = BUSBRADataset(
        data_root=str(ds_cfg.train_root),
        csv_path=csv_path,
        image_dir=ds_cfg.train_image_dir,
        mask_dir=ds_cfg.train_mask_dir,
        case_ids=train_ids if ds_cfg.use_case_level_split else train_ids,
        preprocessor=preprocessor,
        augmentation=augmentation,
        cache=cache,
        label_mapping=ds_cfg.label_mapping,
        is_train=True,
    )

    val_dataset = BUSBRADataset(
        data_root=str(ds_cfg.train_root),
        csv_path=csv_path,
        image_dir=ds_cfg.train_image_dir,
        mask_dir=ds_cfg.train_mask_dir,
        case_ids=val_ids if ds_cfg.use_case_level_split else val_ids,
        preprocessor=preprocessor,
        augmentation=None,
        cache=cache,
        label_mapping=ds_cfg.label_mapping,
        is_train=False,
    )

    # Create test dataset (BUSI)
    test_dataset = None
    test_root = ds_cfg.test_root
    if test_root:
        test_dataset = BUSIDataset(
            data_root=str(test_root),
            classes=ds_cfg.test_classes,
            ignore_classes=ds_cfg.ignore_classes,
            preprocessor=preprocessor,
            cache=cache,
            label_mapping=ds_cfg.label_mapping,
            is_train=False,
        )

    if getattr(getattr(config, "meta", None), "config_type", "") == "train_v2":
        train_dataset = V2PriorDataset(train_dataset, config)
        val_dataset = V2PriorDataset(val_dataset, config)
        if test_dataset is not None:
            test_dataset = V2PriorDataset(test_dataset, config)

    # Create DataLoaders
    effective_workers = tr_cfg.num_workers if ds_cfg.cache_mode == "none" else 0

    train_loader = DataLoader(
        train_dataset,
        batch_size=tr_cfg.batch_size,
        shuffle=True,
        num_workers=effective_workers,
        pin_memory=True,
        persistent_workers=effective_workers > 0,
        collate_fn=multitask_collate_fn,
        drop_last=True,
        generator=g,
        worker_init_fn=_worker_init_fn,
    )

    val_loader = DataLoader(
        val_dataset,
        batch_size=tr_cfg.batch_size,
        shuffle=False,
        num_workers=effective_workers,
        pin_memory=True,
        persistent_workers=effective_workers > 0,
        collate_fn=multitask_collate_fn,
    )

    test_loader = None
    if test_dataset is not None:
        test_loader = DataLoader(
            test_dataset,
            batch_size=tr_cfg.batch_size,
            shuffle=False,
            num_workers=effective_workers,
            pin_memory=True,
            persistent_workers=effective_workers > 0,
            collate_fn=multitask_collate_fn,
        )

    logger.info(
        "DataLoaders created: train=%d, val=%d, test=%s",
        len(train_dataset),
        len(val_dataset),
        len(test_dataset) if test_dataset else "N/A",
    )

    return train_loader, val_loader, test_loader
