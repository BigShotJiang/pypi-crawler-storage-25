"""Polar contour feature stream for V2 classification."""
from __future__ import annotations

import torch
import torch.nn as nn


class PolarContourStream(nn.Module):
    """Encode `[B, 1, H, 360]` polar contour matrices into embeddings."""

    def __init__(self, embed_dim: int = 64, dropout: float = 0.2):
        super().__init__()
        self.net = nn.Sequential(
            nn.Conv2d(1, 16, kernel_size=(3, 7), padding=(1, 3), bias=False),
            nn.BatchNorm2d(16),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=(2, 2)),
            nn.Conv2d(16, 32, kernel_size=(3, 7), padding=(1, 3), bias=False),
            nn.BatchNorm2d(32),
            nn.ReLU(inplace=True),
            nn.AdaptiveAvgPool2d(1),
            nn.Flatten(),
            nn.Dropout(p=dropout),
        )
        self.proj = nn.Linear(32, embed_dim)

    def forward(self, polar_contour: torch.Tensor) -> torch.Tensor:
        return self.proj(self.net(polar_contour))
