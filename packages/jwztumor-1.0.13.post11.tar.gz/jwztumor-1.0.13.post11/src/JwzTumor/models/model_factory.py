"""Model factory for creating the multi-task diagnosis network.

Creates the complete LABDG_DGBC_MTLNet_MPTC model which contains all
sub-modules: encoder, decoder, segmentation heads, classification head,
and auxiliary task heads (edge, SDM, uncertainty, etc.).
"""
import torch.nn as nn

from ..utils.config import Config

__all__ = ["create_model"]


def create_model(config: Config) -> nn.Module:
    """Create model from configuration.

    Args:
        config: A Config object whose ``model`` attribute holds a
            :class:`ModelConfig` describing the network architecture.

    Returns:
        A :class:`DGBC_MTLNet` instance which contains all sub-modules
        (encoder, decoder, segmentation heads, classification head, and
        auxiliary task heads).

    Raises:
        ImportError: If ``dgbc_mtl_net`` has not been implemented yet.
    """
    if getattr(getattr(config, "meta", None), "config_type", "train_v1") == "train_v2":
        from .dgbc_mtl_net_v2 import DGBC_MTLNetV2

        return DGBC_MTLNetV2(config)

    from .dgbc_mtl_net import DGBC_MTLNet
    return DGBC_MTLNet(config)
