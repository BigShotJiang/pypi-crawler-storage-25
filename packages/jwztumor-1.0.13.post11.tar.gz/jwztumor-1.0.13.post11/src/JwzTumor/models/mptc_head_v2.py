"""V2 classification head using nnUNet priors and polar contour features."""
from __future__ import annotations

from typing import List, Optional

import torch
import torch.nn as nn
import torch.nn.functional as F

from .polar_contour_stream import PolarContourStream


class MPTCHeadV2(nn.Module):
    """Classification head for the V2 external-segmentation-prior path."""

    def __init__(self, config):
        super().__init__()
        model_cfg = config.model
        dataset_cfg = config.dataset
        self.stream_embed_dim = 64
        self.prompt_dim = getattr(model_cfg, "prompt_dim", 128)
        self.num_classes = getattr(dataset_cfg, "num_classes", 2)
        z_pre_channels = getattr(model_cfg, "pre_channels", 16)
        encoder_channels = list(getattr(model_cfg, "encoder_channels", [64, 128, 256, 512]))
        dropout = getattr(model_cfg, "dropout", 0.2)

        self.lesion_pool = nn.AdaptiveAvgPool2d(1)
        self.lesion_proj = nn.Linear(z_pre_channels, self.stream_embed_dim)
        self.prior_pool = nn.AdaptiveAvgPool2d(1)
        self.prior_proj = nn.Linear(1, self.stream_embed_dim)
        self.contour_stream = PolarContourStream(embed_dim=self.stream_embed_dim, dropout=dropout)
        self.global_pool = nn.AdaptiveAvgPool2d(1)
        self.global_proj = nn.Linear(encoder_channels[-1], self.stream_embed_dim)

        fusion_in = 4 * self.stream_embed_dim + self.prompt_dim
        self.fusion = nn.Sequential(
            nn.Linear(fusion_in, fusion_in // 2),
            nn.ReLU(inplace=True),
            nn.Dropout(p=dropout),
            nn.Linear(fusion_in // 2, self.num_classes),
        )

    def forward(
        self,
        encoder_features: List[torch.Tensor],
        external_seg_prob: torch.Tensor,
        polar_contour: torch.Tensor,
        morph_prompt: torch.Tensor,
        z_pre: torch.Tensor,
    ) -> tuple[torch.Tensor, torch.Tensor]:
        seg_prob = F.interpolate(external_seg_prob, size=z_pre.shape[2:], mode="bilinear", align_corners=False)
        lesion_feat = _masked_pool(z_pre, seg_prob, self.lesion_pool)
        lesion_feat = self.lesion_proj(lesion_feat)

        prior_feat = self.prior_pool(external_seg_prob).flatten(1)
        prior_feat = self.prior_proj(prior_feat)
        contour_feat = self.contour_stream(polar_contour)
        global_feat = self.global_pool(encoder_features[-1]).flatten(1)
        global_feat = self.global_proj(global_feat)

        fused = torch.cat([lesion_feat, prior_feat, contour_feat, global_feat, morph_prompt], dim=1)
        cls_logits = self.fusion(fused)
        cls_prob = F.softmax(cls_logits, dim=-1)
        return cls_logits, cls_prob


def _masked_pool(features: torch.Tensor, mask: torch.Tensor, pool: nn.Module) -> torch.Tensor:
    masked = features * mask
    pooled = pool(masked).flatten(1)
    empty = mask.sum(dim=(1, 2, 3)) < 1e-6
    if empty.any():
        unmasked = pool(features).flatten(1)
        pooled = torch.where(empty.unsqueeze(1), unmasked, pooled)
    return pooled
