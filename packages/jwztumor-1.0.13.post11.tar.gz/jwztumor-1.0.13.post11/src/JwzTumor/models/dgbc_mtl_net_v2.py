"""V2 JwzTumor model path using external nnUNet segmentation priors."""
from __future__ import annotations

from typing import Any, Dict, Optional

import torch
import torch.nn as nn
from torch import Tensor

from .dgbc_encoder import DGBCEncoder
from .dgbc_mtl_net import LABDGPre, MorphologyProxyPrompt
from .mptc_head_v2 import MPTCHeadV2


class DGBC_MTLNetV2(nn.Module):
    """Classification-focused V2 network with external segmentation priors."""

    def __init__(self, config):
        super().__init__()
        model_cfg = config.model
        self.raw_input_channels = getattr(model_cfg, "raw_input_channels", 1)
        self.pre_channels = getattr(model_cfg, "pre_channels", 16)
        self.prompt_dim = getattr(model_cfg, "prompt_dim", 128)
        self.challenge_dim = getattr(model_cfg, "challenge_dim", 8)
        self.use_mpp = getattr(model_cfg, "use_mpp", True)
        self.dropout = getattr(model_cfg, "dropout", 0.2)

        self.labdg_pre = LABDGPre(
            raw_input_channels=self.raw_input_channels,
            pre_channels=self.pre_channels,
            dropout=self.dropout,
        )
        self.encoder = DGBCEncoder(config)
        self.mpp = MorphologyProxyPrompt(
            pre_channels=self.pre_channels,
            stage_channels=self.encoder.stage_out_channels,
            prompt_dim=self.prompt_dim,
            challenge_dim=self.challenge_dim,
            dropout=self.dropout,
        ) if self.use_mpp else None
        self.mptc_head = MPTCHeadV2(config)

    def forward(
        self,
        image: Tensor,
        mask: Optional[Tensor] = None,
        edge: Optional[Tensor] = None,
        sdm: Optional[Tensor] = None,
        label: Optional[Tensor] = None,
        meta: Optional[Dict[str, Any]] = None,
        external_seg_prob: Optional[Tensor] = None,
        polar_contour: Optional[Tensor] = None,
        **_: Any,
    ) -> Dict[str, Any]:
        if external_seg_prob is None:
            raise ValueError("DGBC_MTLNetV2 requires external_seg_prob")
        if polar_contour is None:
            raise ValueError("DGBC_MTLNetV2 requires polar_contour")

        batch_size = image.shape[0]
        z_pre, pre_aux_maps = self.labdg_pre(image, meta=meta)
        _, stage_feats = self.encoder(z_pre)

        if self.mpp is not None:
            morph_prompt, challenge_vec = self.mpp(pre_aux_maps, stage_feats)
        else:
            morph_prompt = torch.zeros(batch_size, self.prompt_dim, device=image.device)
            challenge_vec = torch.zeros(batch_size, self.challenge_dim, device=image.device)

        cls_logits, cls_prob = self.mptc_head(
            encoder_features=stage_feats,
            external_seg_prob=external_seg_prob,
            polar_contour=polar_contour,
            morph_prompt=morph_prompt,
            z_pre=z_pre,
        )

        outputs: Dict[str, Any] = {
            "cls_logits": cls_logits,
            "cls_prob": cls_prob,
            "seg_prob": external_seg_prob,
            "external_seg_prob": external_seg_prob,
            "polar_contour": polar_contour,
            "morph_prompt": morph_prompt,
            "challenge_vector": challenge_vec,
            "aux_maps": pre_aux_maps,
        }
        if label is not None:
            outputs["label"] = label
        return outputs
