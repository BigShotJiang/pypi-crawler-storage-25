"""V2 server inference engine using external nnUNetv2 segmentation priors."""
from __future__ import annotations

import base64
import io
import logging
import tempfile
import time
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from PIL import Image

from ..contour.polar import build_polar_contour
from ..data.preprocessing import BreastUSPreprocessor
from ..inference.postprocessing import postprocess_classification
from ..nnunet.runner import build_predict_from_modelfolder_command, run_command
from .engine import tensor_to_base64_png
from .progress import ProgressCallback

logger = logging.getLogger(__name__)


def ensure_chw_tensor(array: np.ndarray | torch.Tensor) -> torch.Tensor:
    """Convert a 2D or CHW array into a float32 `[C, H, W]` tensor."""
    if isinstance(array, torch.Tensor):
        tensor = array.detach().clone().to(dtype=torch.float32)
    else:
        tensor = torch.from_numpy(np.asarray(array, dtype=np.float32))
    if tensor.dim() == 2:
        tensor = tensor.unsqueeze(0)
    if tensor.dim() != 3:
        raise ValueError(f"Expected 2D or CHW array, got shape {tuple(tensor.shape)}")
    return tensor


def contour_to_base64_png(contour: np.ndarray | torch.Tensor) -> str:
    """Encode a polar contour matrix as a base64 grayscale PNG."""
    if isinstance(contour, torch.Tensor):
        arr = contour.detach().cpu().numpy()
    else:
        arr = np.asarray(contour)
    if arr.ndim == 3:
        arr = arr.squeeze(0)
    arr = np.asarray(arr, dtype=np.float32)
    arr_min = float(np.min(arr))
    arr_max = float(np.max(arr))
    if arr_max - arr_min > 1e-6:
        arr = (arr - arr_min) / (arr_max - arr_min) * 255.0
    else:
        arr = np.zeros_like(arr)
    image = Image.fromarray(arr.astype(np.uint8), mode="L")
    buf = io.BytesIO()
    image.save(buf, format="PNG")
    return base64.b64encode(buf.getvalue()).decode("ascii")


def derive_edge_map(mask: torch.Tensor) -> torch.Tensor:
    """Derive a binary boundary map from a `[1,H,W]` or `[B,1,H,W]` mask."""
    tensor = ensure_chw_tensor(mask) if mask.dim() <= 3 else mask.to(dtype=torch.float32)
    squeeze_batch = False
    if tensor.dim() == 3:
        tensor = tensor.unsqueeze(0)
        squeeze_batch = True
    binary = (tensor > 0.5).to(dtype=torch.float32)
    dilated = F.max_pool2d(binary, kernel_size=3, stride=1, padding=1)
    eroded = -F.max_pool2d(-binary, kernel_size=3, stride=1, padding=1)
    edge = (dilated - eroded).clamp(0.0, 1.0)
    return edge.squeeze(0) if squeeze_batch else edge


def write_nnunet_input_png(image: np.ndarray, input_dir: Path, image_id: str) -> Path:
    """Write one grayscale upload into a temporary nnUNet input directory."""
    input_dir = Path(input_dir)
    input_dir.mkdir(parents=True, exist_ok=True)
    arr = np.asarray(image, dtype=np.float32)
    arr = np.clip(arr, 0, 255).astype(np.uint8)
    path = input_dir / f"{image_id}_0000.png"
    Image.fromarray(arr, mode="L").save(path)
    return path


def load_first_prediction(output_dir: Path, threshold: float = 0.5) -> Tuple[np.ndarray, np.ndarray]:
    """Load the first probability or mask prediction produced by nnUNetv2."""
    output_dir = Path(output_dir)
    prob_candidates = sorted(list(output_dir.glob("*.npz")) + list(output_dir.glob("*.npy")))
    if prob_candidates:
        path = prob_candidates[0]
        if path.suffix == ".npz":
            data = np.load(path)
            prob = data["seg_prob"] if "seg_prob" in data else data[data.files[0]]
        else:
            prob = np.load(path)
        prob = np.asarray(prob, dtype=np.float32).squeeze()
        if prob.ndim == 3:
            prob = prob[-1]
        mask = (prob >= threshold).astype(np.uint8)
        return prob, mask

    image_candidates = sorted(
        p for p in output_dir.iterdir()
        if p.suffix.lower() in {".png", ".jpg", ".jpeg", ".bmp", ".tif", ".tiff"}
    )
    if image_candidates:
        mask = (np.asarray(Image.open(image_candidates[0]).convert("L")) > 0).astype(np.uint8)
        return mask.astype(np.float32), mask

    raise FileNotFoundError(f"No nnUNet prediction output found in {output_dir}")


class InferenceEngineV2:
    """Server inference engine for V2 nnUNet-prior classification."""

    def __init__(self, config):
        self.config = config
        self.model: Optional[nn.Module] = None
        self.preprocessor = BreastUSPreprocessor(
            model_input_size=config.dataset.model_input_size,
            pad_mode=config.dataset.pad_mode,
        )
        configured_device = config.training.device
        self.device = torch.device(
            configured_device
            if configured_device != "auto"
            else ("cuda" if torch.cuda.is_available() else "cpu")
        )

    @property
    def is_loaded(self) -> bool:
        return self.model is not None

    def load_checkpoint(self, checkpoint_path: str) -> None:
        """Load the V2 classifier checkpoint."""
        if not Path(checkpoint_path).exists():
            raise FileNotFoundError(f"Checkpoint not found: {checkpoint_path}")
        from ..models.model_factory import create_model

        self.model = create_model(self.config)
        ckpt = torch.load(checkpoint_path, map_location="cpu", weights_only=False)
        self.model.load_state_dict(ckpt["model_state_dict"])
        self.model.to(self.device)
        self.model.eval()
        logger.info("Loaded V2 checkpoint from %s (epoch=%d)", checkpoint_path, ckpt.get("epoch", -1))

    def run_inference(
        self,
        image: np.ndarray,
        progress_callback: Optional[ProgressCallback] = None,
    ) -> Dict[str, Any]:
        """Run V2 server inference on one grayscale ultrasound image."""
        if self.model is None:
            raise RuntimeError("V2 inference model is not loaded")

        timings: Dict[str, int] = {}
        t_start = time.perf_counter()

        if progress_callback:
            progress_callback.emit("preprocessing", 0.15, "Preprocessing image...")
        t0 = time.perf_counter()
        processed = self.preprocessor.process_infer(image)
        image_tensor = processed["image"].unsqueeze(0).to(self.device)
        timings["preprocess_ms"] = _elapsed_ms(t0)

        if progress_callback:
            progress_callback.emit("inference", 0.45, "Running nnUNetv2 segmentation...")
        t0 = time.perf_counter()
        with tempfile.TemporaryDirectory(prefix="jwzt_v2_nnunet_") as tmp:
            raw_prob, raw_mask = self._run_nnunet_predict(image, Path(tmp))
        timings["nnunet_ms"] = _elapsed_ms(t0)

        if progress_callback:
            progress_callback.emit("postprocessing", 0.65, "Building polar contour...")
        t0 = time.perf_counter()
        classifier_prob, classifier_mask = self._transform_prior_to_classifier_size(
            raw_prob=raw_prob,
            raw_mask=raw_mask,
            target_size=tuple(processed["image"].shape[-2:]),
        )
        contour, _ = build_polar_contour(
            processed["image"].squeeze(0).detach().cpu().numpy(),
            classifier_mask,
            outer_height=int(getattr(self.config.contour, "outer_height", 8)),
            inner_height=int(getattr(self.config.contour, "inner_height", 8)),
            degrees=int(getattr(self.config.contour, "degrees", 360)),
        )
        timings["contour_ms"] = _elapsed_ms(t0)

        if progress_callback:
            progress_callback.emit("inference", 0.8, "Running V2 classifier...")
        t0 = time.perf_counter()
        external_seg_prob = ensure_chw_tensor(classifier_prob).unsqueeze(0).to(self.device)
        polar_contour = ensure_chw_tensor(contour).unsqueeze(0).to(self.device)
        with torch.no_grad():
            outputs = self.model(
                image_tensor,
                external_seg_prob=external_seg_prob,
                polar_contour=polar_contour,
            )
        outputs = {k: v.cpu() if isinstance(v, torch.Tensor) else v for k, v in outputs.items()}
        timings["classifier_ms"] = _elapsed_ms(t0)

        if progress_callback:
            progress_callback.emit("postprocessing", 0.92, "Postprocessing V2 results...")
        t0 = time.perf_counter()
        cls_result = postprocess_classification(outputs.get("cls_prob", torch.zeros(1, 2)))
        raw_mask_tensor = ensure_chw_tensor(raw_mask)
        edge_map = derive_edge_map(raw_mask_tensor)
        timings["postprocess_ms"] = _elapsed_ms(t0)

        elapsed_ms = int((time.perf_counter() - t_start) * 1000)
        result = {
            "label": "malignant" if cls_result["pred_label"] == 1 else "benign",
            "label_index": cls_result["pred_label"],
            "prob_malignant": round(cls_result["prob_malignant"], 4),
            "prob_benign": round(cls_result["prob_benign"], 4),
            "seg_mask": tensor_to_base64_png(raw_mask_tensor),
            "edge_map": tensor_to_base64_png(edge_map),
            "uncertainty_map": None,
            "contour_map": contour_to_base64_png(contour),
            "inference_mode": "v2",
            "segmentation_source": "nnunetv2",
            "timings": timings,
            "processing_time_ms": elapsed_ms,
        }
        return result

    def run_batch_inference(
        self,
        images: List[np.ndarray],
        task_ids: List[str],
        on_progress=None,
    ) -> Dict[str, Dict[str, Any]]:
        """Run V2 queued batch requests sequentially.

        V2 online nnUNet prediction is process-backed and expensive, so the
        first server version keeps batch semantics compatible without trying to
        coalesce multiple nnUNet calls.
        """
        results: Dict[str, Dict[str, Any]] = {}
        for task_id, image in zip(task_ids, images):
            callback = None
            if on_progress is not None:
                callback = ProgressCallback(
                    stages=["preprocessing", "inference", "postprocessing"],
                    on_event=lambda event, tid=task_id: on_progress(tid, event),
                )
            results[task_id] = self.run_inference(image, callback)
        return results

    def _run_nnunet_predict(self, image: np.ndarray, work_dir: Path) -> Tuple[np.ndarray, np.ndarray]:
        input_dir = Path(work_dir) / "input"
        output_dir = Path(work_dir) / "output"
        output_dir.mkdir(parents=True, exist_ok=True)
        write_nnunet_input_png(image, input_dir=input_dir, image_id="case")
        command = build_predict_from_modelfolder_command(
            input_dir=str(input_dir),
            output_dir=str(output_dir),
            model_dir=str(getattr(self.config.nnunet, "model_dir", "")),
            folds=getattr(self.config.nnunet, "folds", []),
            checkpoint=str(getattr(self.config.nnunet, "checkpoint", "")),
            save_probabilities=True,
        )
        run_command(command)
        return load_first_prediction(output_dir, threshold=float(getattr(self.config.inference, "threshold", 0.5)))

    @staticmethod
    def _transform_prior_to_classifier_size(
        raw_prob: np.ndarray,
        raw_mask: np.ndarray,
        target_size: Tuple[int, int],
    ) -> Tuple[np.ndarray, np.ndarray]:
        target_h, target_w = target_size
        prob_arr = np.asarray(raw_prob, dtype=np.float32).squeeze()
        mask_arr = (np.asarray(raw_mask).squeeze() > 0).astype(np.uint8)
        prob_img = Image.fromarray(prob_arr.astype(np.float32), mode="F")
        mask_img = Image.fromarray(mask_arr * 255, mode="L")
        prob = np.asarray(prob_img.resize((target_w, target_h), resample=Image.BILINEAR), dtype=np.float32)
        mask = (np.asarray(mask_img.resize((target_w, target_h), resample=Image.NEAREST)) > 0).astype(np.float32)
        if prob.max() > 1.0:
            prob = prob / 255.0
        return np.clip(prob, 0.0, 1.0), mask


def _elapsed_ms(start: float) -> int:
    return int((time.perf_counter() - start) * 1000)
