# JwzTumor CLI 使用指南

> **版本**: 1.0.13.post11 | **命令行工具**: `jwzt` | **Python 包**: `JwzTumor`

---

## 目录

1. [项目简介](#1-项目简介)
2. [安装与环境配置](#2-安装与环境配置)
3. [快速上手](#3-快速上手)
4. [完整命令参考](#4-完整命令参考)
5. [V1/V2 推理模式](#5-v1v2-推理模式)
6. [Server 部署与前端工作台](#6-server-部署与前端工作台)
7. [配置文件参考](#7-配置文件参考)
8. [目录结构说明](#8-目录结构说明)
9. [常见问题](#9-常见问题)

---

## 1. 项目简介

JwzTumor 实现了 **LABDG-Pre + DGBC-MTLNet + MPTC-Head** 架构，用于乳腺超声图像的良恶性诊断：

```
超声图像
       │
       ▼
┌──────────────────────────────────┐
│ LABDG-Pre 预处理模块              │  病灶感知 + 边界保持的域泛化预处理
│ 输出: 结构图 × 4                  │
└──────────┬───────────────────────┘
           │
           ▼
┌──────────────────────────────────┐
│ DGBC-MTLNet 编码器-解码器          │  域泛化边界上下文协作多任务网络 (CNN-Mamba)
│ 输出: 分割掩码 + 边缘图 + SDM      │
└──────────┬───────────────────────┘
           │
           ▼
┌──────────────────────────────────┐
│ MPTC-Head 分类头                  │  形态学提示拓扑一致分类头 (4-stream)
│ 输出: 良恶性概率 + 不确定性图       │
└──────────────────────────────────┘
```

**模型组件说明：**

| 组件 | 功能 | 输出 |
|------|------|------|
| LABDG-Pre | 病灶感知域泛化预处理 | 4 通道结构图 |
| DGBC-MTLNet | CNN-Mamba 混合多任务网络 | 分割掩码、边缘图、SDM |
| MPTC-Head | 4-stream 形态学分类头 | 分类概率、不确定性图、可解释性可视化 |

### V1.0.13.post11 新特性

- **nnUNet 全流程进度显示**: `jwzt nnunet prepare/preprocess/train/predict/export/pipeline` 现在都支持统一的进度条输出
- **`--verbose` 范围补全**: `prepare` 与 `export` 也支持 `--verbose/-v`，verbose 模式显示日志面板和实时信息，默认模式只显示简洁进度
- **pipeline 阶段进度**: `jwzt nnunet pipeline` 显示 preprocess / train / predict / export 顶层阶段进度，避免多层终端输出相互覆盖
- **Ctrl+C 安全退出**: 外部 nnUNet 子进程在流式输出阶段和 `wait()` 阻塞阶段都走统一清理路径，减少中断后残留进程
- **nnUNet 原始 PNG 说明**: 文档补充 nnUNet 原始预测 PNG 是 0/1 标签图，肉眼查看可能近似全黑；V2 使用的 `seg_mask/*.png` 会导出为 0/255

### V1.0.13.post11 新特性

- **V2 训练尺寸修复**: 修复 `build_polar_contour` 因 image (512x512) 和 mask (原始分辨率) 尺寸不匹配而崩溃的问题，在 `V2PriorDataset` 中添加运行时 resize
- **V2 配置模板更新**: `jwzt get train-v2` 生成的配置文件现在包含调度器详细参数（cosine/warmrestart/step/plateau）
- **experiment 节置顶**: `train_v2.yaml` 模板中 `experiment` 节移至配置文件顶部，方便用户快速修改实验信息
- **默认值同步**: V2 模板默认值与 `configs/train_v2.yaml` 完全一致

### V1.0.13.post8 新特性

- **V2 CLI 配置驱动工作流**: `jwzt nnunet prepare/preprocess/train/predict/export/pipeline` 均支持 `-c configs/train_v2.yaml`，优先从配置文件读取 dataset_id、raw_dir、model_dir、cache_dir 等变量，减少重复 CLI 参数
- **统一 V2 分割先验缓存**: V2 分类网络统一读取 `seg_prob/*.npz`、`seg_mask/*.png` 和 `polar_contour/*.npz`，缓存可来自 nnUNetv2、数据集真实 mask 或算法生成概率图
- **算法概率图生成**: `jwzt nnunet export -c configs/train_v2.yaml --prior-source generated_prob --prob-mode distance` 支持从数据集 mask 生成 binary / gaussian / distance / hybrid 概率图缓存
- **nnUNet 概率保存修复**: `jwzt nnunet predict` 新增 `--save-probabilities`，并在 V2 模板中默认启用，确保导出的缓存包含分类网络需要的概率图
- **V2 缓存缺失提示优化**: `jwzt train` 和 `jwzt pred` 在 V2 模式下会提前检查缓存完整性，缺失时输出具体 image_id 和修复命令

### V1.0.13.post7 新特性

- **UPDATE.md 内容修复**: 修复 `jwzt update` 执行更新后版本差距始终显示为 0 且 UPDATE.md 内容为空的问题。CSV 读取时机从 pip install 前移至安装成功后，确保读取新安装包的更新日志数据
- **信息面板优化**: 移除信息面板中不准确的「版本差距」行

### V1.0.13.post6 新特性

- **update.log 日志补全**: 修复 `jwzt update` 在「已是最新版本」和「PyPI 连接失败」时未写入 `~/.jwztumor/update.log` 的问题。修复测试未 mock `log_update` 导致测试数据污染真实日志文件

### V1.0.13.post5 新特性

- **版本自动检测修复**: 修复 `jwzt` 命令执行后版本自动检测从未运行的问题（`app()` 抛出 `SystemExit` 导致检测代码不可达）。新增 `~/.jwztumor/update_detect.json` 审计文件，每次检测后记录时间戳、当前版本、最新版本和检测状态

### V1.0.13.post4 新特性

- **Windows 自更新修复**: 修复 Windows 上 `jwzt update` 因文件锁（jwzt.exe 被占用）导致安装失败并破坏现有安装的问题。Windows 平台自动使用分离 .bat 脚本等待文件锁释放后执行 pip install，Linux/macOS 不受影响
- **更新失败恢复提示**: pip 安装失败时显示手动恢复命令 `pip install JwzTumor --upgrade`

### V1.0.13.post3 新特性

- **版本自动检测修复**: 修复执行 jwzt 命令时版本检测不生效的问题。缓存迁移到 `~/.jwztumor/`，检测间隔从 3h 缩短到 10min
- **jwzt update 修复**: 修复部分设备因 PyPI CDN 延迟导致更新失败。移除强制 `--index-url`，添加 `--no-cache-dir`，失败自动回退并重试
- **更新日志**: 新增 `~/.jwztumor/update.log` 记录用户更新历史

### V1.0.13.post2 新特性

- **V2 模板完整注释**: V2 训练配置模板所有变量已补充详细中文注释（90+ 个变量），与 V1 模板保持一致
- **experiment.note 和 experiment_name**: 新增用户备注和实验运行名称变量，方便记录配置修改原因
- **训练配置自动备份**: 训练启动前自动备份配置文件到 `experiments/{name}/config_{name}.yaml`，保留注释，experiment 段置顶
- **--experiment-name 必须指定**: 不再有默认值，未指定时从配置文件读取，两者都为空则报错

### V1.0.13.post1 新特性

- **get 配置模板增强**: V2 训练配置模板所有变量已补充中文注释（nnunet 段 11 个变量 + contour 段 7 个变量）。`-t all` 改为在目标目录生成独立配置文件而非单一合并文件
- **HELP.md V1/V2 双完整工作流**: 第3章快速上手已包含 V1 和 V2 两条完整工作流路径（数据→训练→推理→Server），第5章推理模式增加了 V2 数据流图和 Server 配置示例

### V1.0.13 新特性

- **`jwzt update` 命令**：新增 `jwzt update` 命令，支持自动检测 PyPI 最新版本并执行 `pip install` 升级。更新成功后在当前目录生成 `UPDATE.md` 文件（覆盖式），包含当前版本到最新版本的更新日志和迁移步骤
- **`jwzt helpme` 命令**：新增 `jwzt helpme` 命令，支持导出完整帮助文档 `HELP.md` 到指定目录
- **版本自动检测**：每次执行 `jwzt` 命令时自动检测 PyPI 最新版本（3h 缓存 + 3s 超时），有新版本时在终端末尾显示黄色提示

### V1.0.12 新特性

- **nnUNet 集成**：新增 `jwzt nnunet` 命令组，支持 prepare → preprocess → train → pipeline → predict → export 完整流水线
- **Server V2 推理**：FastAPI 服务支持 V2 nnUNetv2 分割先验推理引擎，含极坐标轮廓特征
- **前端共享轮廓视图**：临床工作台新增轮廓可视化功能

---

## 2. 安装与环境配置

### 2.1 前置要求

- Python >= 3.10
- PyTorch >= 2.0（CUDA 可选，GPU 加速训练）
- pip 或 uv

### 2.2 安装项目

```bash
# 用户安装（推荐）
pip install JwzTumor --index-url https://pypi.org/simple/

# 已安装但需要更新到最新版本
pip install JwzTumor --upgrade --index-url https://pypi.org/simple/

# 使用 jwzt update 自动更新（推荐）
jwzt update

# 开发模式安装
pip install -e .

# 开发模式（含 dev 依赖）
pip install -e ".[dev]"
```

### 2.3 验证安装

```bash
# 查看版本号
jwzt version
# 输出: JwzTumor v1.0.13.post11

# 导出帮助文档
jwzt helpme --path ./docs/
```

### 2.4 导出默认配置模板

```bash
# 导出所有配置模板到 configs/ 目录（生成 4 个独立文件）
jwzt get -t all -o configs/

# 导出单个配置模板
jwzt get -t train -o configs/train.yaml
jwzt get -t train_v2 -o configs/train_v2.yaml
jwzt get -t server -o configs/server.yaml
```

---

## 3. 快速上手

JwzTumor 提供两套推理模式，对应不同的工作流路径：

| | V1 标准模式 | V2 nnUNet 模式 |
|---|---|---|
| 分割先验 | 内置 LABDG-Pre | 外部 nnUNetv2 |
| 训练阶段 | 四阶段渐进式 | 单阶段分类 + nnUNet |
| 轮廓特征 | 瘤周环形 | 极坐标轮廓 |
| 适用场景 | 快速部署、标准推理 | 高精度、临床辅助诊断 |

---

### 3.1 V1 标准模式完整工作流

V1 模式使用内置的 LABDG-Pre 分割先验，四阶段渐进式训练，无需额外依赖。

#### 第一步：准备数据

将训练数据（BUSBRA）和测试数据（BUSI）放置到 `dataset/` 目录：

```
dataset/
├── BUSBRA/                    # 训练集
│   ├── Images/
│   │   ├── bus_001-left.png   # 超声图像
│   │   └── ...
│   ├── Masks/
│   │   ├── mask_001-left.png  # 分割掩码
│   │   └── ...
│   ├── bus_data.csv           # 病理标签
│   └── 5-fold-cv.csv          # 交叉验证划分
└── Dataset_BUSI_with_GT/      # 测试集
    ├── benign/
    │   ├── ben (1).png
    │   └── ben (1)_mask.png
    └── malignant/
        ├── mal (1).png
        └── mal (1)_mask.png
```

#### 第二步：审计数据集

```bash
jwzt audit-data --data-root dataset --output outputs/dataset_audit_summary.json
```

#### 第三步：导出 V1 训练配置

```bash
# 导出所有配置模板（生成 train_full.yaml, train_v2.yaml, pred.yaml, server.yaml）
jwzt get -t all -o configs/

# 或仅导出训练配置
jwzt get -t train -o configs/train.yaml
```

#### 第四步：四阶段渐进式训练

V1 采用四阶段训练策略，**必须按顺序执行**：

```bash
# 阶段1: 训练 LABDG-Pre 预处理模块（粗定位 + 结构图）
jwzt train -c configs/train.yaml --stage pretrain_pre --fold 1 --experiment-name v1_exp

# 阶段2: 训练 DGBC-MTLNet 分割（编码器 + 解码器）
jwzt train -c configs/train.yaml --stage pretrain_seg --fold 1 --experiment-name v1_exp

# 阶段3: 训练 MPTC-Head 分类头（冻结编码器 + 预处理）
jwzt train -c configs/train.yaml --stage train_cls --fold 1 --experiment-name v1_exp

# 阶段4: 端到端微调（全部损失）
jwzt train -c configs/train.yaml --stage finetune_all --fold 1 --experiment-name v1_exp
```

**训练输出：**
```
experiments/
└── v1_exp/
    ├── config.yaml              # 配置快照
    ├── checkpoints/
    │   ├── best_auc.ckpt        # 最佳 AUC 检查点
    │   ├── best_f1.ckpt         # 最佳 F1 检查点
    │   └── latest.ckpt          # 最新检查点
    └── logs/
        └── training.log
```

#### 第五步：V1 推理预测

```bash
# 导出推理配置
jwzt get -t pred -o configs/pred.yaml

# 执行批量推理
jwzt pred \
  -c configs/pred.yaml \
  --model experiments/v1_exp/checkpoints/best_auc.ckpt \
  --data dataset/Dataset_BUSI_with_GT \
  --output outputs/v1_predictions
```

#### 第六步：评估

```bash
jwzt eval \
  -c configs/pred.yaml \
  --pred outputs/v1_predictions \
  --data dataset/Dataset_BUSI_with_GT
```

#### 第七步：启动 V1 推理服务

```bash
# 导出 Server 配置
jwzt get -t server -o configs/server.yaml

# 基本启动
jwzt server \
  --model experiments/v1_exp/checkpoints/best_auc.ckpt \
  -c configs/server.yaml \
  --inference-mode v1 \
  --host 0.0.0.0 \
  --port 8000

# 启动并启用前端 UI
jwzt server \
  --model experiments/v1_exp/checkpoints/best_auc.ckpt \
  -c configs/server.yaml \
  --inference-mode v1 \
  --with-ui \
  --host 0.0.0.0 \
  --port 8000
```

---

### 3.2 V2 nnUNet 模式完整工作流

V2 模式使用外部 nnUNetv2 高精度分割先验 + 极坐标轮廓特征，适用于需要更高精度的场景。

#### 第一步：准备数据

数据准备与 V1 相同（见 3.1 第一步）。

#### 第二步：审计数据集

```bash
jwzt audit-data --data-root dataset --output outputs/dataset_audit_summary.json
```

#### 第三步：导出 V2 训练配置

```bash
# 导出所有配置模板（生成 train_full.yaml, train_v2.yaml, pred.yaml, server.yaml）
jwzt get -t all -o configs/

# 或仅导出 V2 训练配置
jwzt get -t train_v2 -o configs/train_v2.yaml
```

#### 第四步：nnUNet 数据准备

将训练数据的图像/掩码对导出为 nnUNetv2 格式：

```bash
jwzt nnunet prepare -c configs/train_v2.yaml
```

**输出目录结构：**
```
dataset/nnUNet_raw/
└── Dataset001_BUS_Tumor2D/
    ├── dataset.json
    ├── imagesTr/
    │   ├── BUS_000_0000.nii.gz   # 图像
    │   └── ...
    └── labelsTr/
        ├── BUS_000.nii.gz        # 掩码
        └── ...
```

#### 第五步：nnUNet 预处理 + 训练

```bash
# 方式1: 使用 pipeline 一键执行（推荐）
jwzt nnunet pipeline -c configs/train_v2.yaml

# 方式2: 分步执行
# 步骤 5a: 预处理
jwzt nnunet preprocess -c configs/train_v2.yaml

# 步骤 5b: 训练
jwzt nnunet train -c configs/train_v2.yaml
```

**训练输出：**
```
experiments/nnUNet_results/
└── Dataset001_BUS_Tumor2D/
    └── nnUNetTrainer__nnUNetPlans__2d/
        ├── fold_0/
        │   ├── checkpoint_best.pth
        │   └── checkpoint_final.pth
        └── plans.json
```

#### 第六步：nnUNet 预测 + 导出缓存

```bash
# 步骤 6a: 使用训练好的 nnUNet 模型预测（生成概率图和掩码）
jwzt nnunet predict -c configs/train_v2.yaml --save-probabilities

# 步骤 6b: 导出概率图和掩码到 V2 缓存目录
jwzt nnunet export -c configs/train_v2.yaml

# 需要查看实时日志时，可为 prepare/export/predict/pipeline 追加 --verbose
jwzt nnunet export -c configs/train_v2.yaml --verbose
```

如果需要不依赖 nnUNetv2，直接从数据集 mask 生成同名 V2 缓存：

```bash
# 推荐：配置 prior_source: dataset 后直接生成概率图和 mask 缓存
jwzt nnunet predict -c configs/train_v2.yaml

# 临时覆盖概率图生成模式
jwzt nnunet export -c configs/train_v2.yaml --prior-source dataset --prob-mode distance
```

注意：nnUNet 原始输出目录中的 PNG 是 0/1 标签图，普通图片查看器里可能近似全黑；`jwzt nnunet export` 写入的 `seg_mask/*.png` 是 0/255 二值图。

如需中断外部 nnUNet 执行，可直接按 `Ctrl+C`；CLI 会进入统一清理路径并以非 0 状态退出。

**V2 缓存目录结构：**
```
dataset/v2_cache/
├── nnunet_pred/               # nnUNet 原始预测输出
├── seg_prob/                  # 概率图缓存（.npz 格式，V2 分类主输入）
│   ├── BUS_000.npz
│   └── ...
├── seg_mask/                  # 二值掩码缓存
│   ├── BUS_000.png
│   └── ...
└── polar_contour/             # 极坐标轮廓缓存（训练时自动生成）
    ├── BUS_000.npz
    └── ...
```

#### 第七步：V2 分类训练

```bash
jwzt train \
  -c configs/train_v2.yaml \
  --stage train_cls_nnunet_prior \
  --fold 1 \
  --experiment-name v2_exp
```

**V2 训练说明：**
- 训练阶段为 `train_cls_nnunet_prior`（使用统一分割先验缓存训练分类头）
- `seg_prob` 和 `seg_mask` 缓存可来自 nnUNetv2、数据集 mask 或算法生成概率图
- 训练前会检查缓存完整性，缺失时提示具体 image_id 和修复命令
- 训练时自动检测并生成极坐标轮廓缓存（首次运行较慢）
- 只训练分类头，不训练分割模块（分割由 nnUNet 完成）
- 模型需要 `nnunet` 和 `contour` 配置段指向正确的缓存路径

#### 第八步：启动 V2 推理服务

V2 Server 在推理时自动执行：nnUNet 分割 → 极坐标轮廓生成 → V2 分类

```bash
jwzt server \
  --model experiments/v2_exp/checkpoints/best_auc.ckpt \
  -c configs/server.yaml \
  --inference-mode v2 \
  --with-ui \
  --host 0.0.0.0 \
  --port 8000
```

**V2 Server 配置需要包含 nnunet 和 contour 段**，在 `configs/server.yaml` 中添加：

```yaml
server:
  inference_mode: v2

nnunet:
  enabled: true
  dataset_id: '001'
  dataset_name: BUS_Tumor2D
  configuration: 2d
  fold: '0'
  model_dir: experiments/nnUNet_results/Dataset001_BUS_Tumor2D/nnUNetTrainer__nnUNetPlans__2d
  folds: ['0']
  checkpoint: checkpoint_best.pth
  raw_dir: dataset/nnUNet_raw
  preprocessed_dir: dataset/nnUNet_preprocessed
  results_dir: experiments/nnUNet_results
  predict_input_dir: dataset/nnUNet_raw/Dataset001_BUS_Tumor2D/imagesTr
  predict_output_dir: dataset/v2_cache/nnunet_pred
  prior_source: nnunet        # nnunet / dataset
  prior_dataset: train        # train / test
  dataset_prob_mode: binary   # dataset 模式: binary / gaussian / distance / hybrid
  prob_mode: binary           # 旧字段兼容；推荐使用 dataset_prob_mode
  prob_sigma: 3.0
  foreground_channel: -1
  threshold: 0.5
  save_probabilities: true
  prob_dir: dataset/v2_cache/seg_prob
  mask_dir: dataset/v2_cache/seg_mask

contour:
  enabled: true
  strategy: polar_contour
  cache_dir: dataset/v2_cache/polar_contour
  height: 16
  outer_height: 8
  inner_height: 8
  degrees: 360
```

---

### 3.3 V1 与 V2 工作流对比

| 步骤 | V1 标准模式 | V2 nnUNet 模式 |
|------|-------------|----------------|
| 数据准备 | BUSBRA + BUSI | 同 V1 |
| 数据审计 | `jwzt audit-data` | 同 V1 |
| 配置导出 | `jwzt get -t train` | `jwzt get -t train_v2` |
| 分割训练 | 四阶段（pretrain_pre → seg → cls → finetune） | nnUNet pipeline（独立训练） |
| 分割预测 | 内置 LABDG-Pre | `jwzt nnunet predict` |
| 缓存导出 | 不需要 | `jwzt nnunet export` |
| 分类训练 | 四阶段中的后两步 | `jwzt train --stage train_cls_nnunet_prior` |
| 推理 | `jwzt pred` 或 Server V1 | Server V2 |
| Server 模式 | `--inference-mode v1` | `--inference-mode v2` |

---

## 4. 完整命令参考

### 4.1 `jwzt version` — 显示版本号

```bash
jwzt version
```

显示当前安装的 JwzTumor 版本号、模型名称和环境信息（PyTorch 版本、CUDA 可用性）。

---

### 4.2 `jwzt train` — 训练模型

```bash
jwzt train --config <配置文件> [OPTIONS]
```

| 选项 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `--config` / `-c` | TEXT | **（必填）** | 训练配置 YAML 文件路径 |
| `--stage` | TEXT | `finetune_all` | 训练阶段: `pretrain_pre` / `pretrain_seg` / `train_cls` / `finetune_all` / `train_cls_nnunet_prior` |
| `--experiment-name` / `-e` | TEXT | 无默认值 | 实验名称（未指定时使用配置文件 experiment.experiment_name，两者都为空则报错） |
| `--fold` | INT | 1 | 交叉验证折号 |
| `--debug` | FLAG | false | 调试模式 |

**训练阶段说明：**

| 阶段 | 说明 | 适用模式 |
|------|------|----------|
| `pretrain_pre` | 训练 LABDG-Pre 预处理模块（粗定位 + 结构图） | V1 |
| `pretrain_seg` | 训练 DGBC-MTLNet 分割（编码器 + 解码器） | V1 |
| `train_cls` | 训练 MPTC-Head 分类头（冻结编码器 + 预处理） | V1 |
| `finetune_all` | 端到端微调（全部损失） | V1 |
| `train_cls_nnunet_prior` | 使用 nnUNet 先验训练分类头 | V2 |

---

### 4.3 `jwzt pred` — 推理预测

```bash
jwzt pred --config <配置> --model <检查点> --data <数据> [OPTIONS]
```

| 选项 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `--config` / `-c` | TEXT | **（必填）** | 推理配置 YAML 文件路径 |
| `--model` / `-m` | TEXT | **（必填）** | 模型检查点路径 (.ckpt) |
| `--data` | TEXT | **（必填）** | 数据目录或 CSV 路径 |
| `--output` / `-o` | TEXT | `outputs/pred` | 预测结果输出目录 |
| `--tta` | FLAG | false | 启用测试时增强 (TTA) |

---

### 4.4 `jwzt eval` — 评估预测结果

```bash
jwzt eval --config <配置> --pred <预测目录> --data <数据目录>
```

| 选项 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `--config` / `-c` | TEXT | **（必填）** | 评估配置 YAML 文件路径 |
| `--pred` | TEXT | **（必填）** | 预测结果目录 |
| `--data` | TEXT | **（必填）** | 原始数据目录 |
| `--output` / `-o` | TEXT | `outputs/eval` | 评估结果输出目录 |

---

### 4.5 `jwzt get` — 导出默认配置模板

```bash
jwzt get [OPTIONS]
```

| 选项 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `--type` / `-t` | TEXT | `all` | 配置类型: `train` / `train_v2` / `pred` / `server` / `all` |
| `--output` / `-o` | TEXT | `-` (stdout) | 输出路径（目录或文件路径） |

**`-t all` 行为说明：**
- 输出到目录时：生成 4 个独立文件（`train_full.yaml`, `train_v2.yaml`, `pred.yaml`, `server.yaml`）
- 输出到 stdout 时：合并所有模板输出

```bash
# 生成所有配置模板到 configs/ 目录
jwzt get -t all -o configs/

# 导出单个模板
jwzt get -t train -o configs/train.yaml
jwzt get -t train_v2 -o configs/train_v2.yaml

# 输出到 stdout
jwzt get -t server
```

---

### 4.6 `jwzt audit-data` — 审计数据集

```bash
jwzt audit-data --data-root <目录> --output <输出文件>
```

| 选项 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `--data-root` | TEXT | **（必填）** | 数据集根目录 |
| `--output` / `-o` | TEXT | `outputs/audit.json` | 审计报告输出路径 |

---

### 4.7 `jwzt server` — 启动推理服务

```bash
jwzt server [OPTIONS]
```

| 选项 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `--model` / `-m` | TEXT | 无 | 模型检查点路径 |
| `--config` / `-c` | TEXT | 无 | 配置文件路径 |
| `--inference-mode` | TEXT | `v1` | 推理模式: `v1` / `v2` |
| `--host` | TEXT | `127.0.0.1` | 监听地址 |
| `--port` | INT | `8000` | 监听端口 |
| `--device` | TEXT | `auto` | 推理设备: `auto` / `cuda` / `cpu` |
| `--tta` / `--no-tta` | FLAG | false | 启用/禁用 TTA |
| `--with-ui` / `--no-with-ui` | FLAG | false | 启用/禁用前端界面 |
| `--ui-port` | INT | 无 | 前端独立端口 |

详细参数和部署模式见 [第6章 Server 部署与前端工作台](#6-server-部署与前端工作台)。

---

### 4.8 `jwzt nnunet` — nnUNet 集成

```bash
jwzt nnunet <子命令> [OPTIONS]
```

| 子命令 | 说明 |
|--------|------|
| `prepare` | 导出 PNG 图像对到 nnUNetv2 格式 |
| `preprocess` | 运行 nnUNetv2 plan_and_preprocess |
| `train` | 运行 nnUNetv2_train |
| `pipeline` | 按配置执行 prepare / preprocess / train / predict / export |
| `predict` | 运行 nnUNetv2 预测，支持 `--save-probabilities` |
| `export` | 导出统一 V2 概率/掩码缓存，支持 nnUNet 输出、数据集 mask 和算法概率图 |

V2 推荐使用配置驱动方式：

```bash
jwzt nnunet prepare -c configs/train_v2.yaml
jwzt nnunet preprocess -c configs/train_v2.yaml
jwzt nnunet train -c configs/train_v2.yaml
jwzt nnunet predict -c configs/train_v2.yaml --save-probabilities
jwzt nnunet export -c configs/train_v2.yaml
```

---

### 4.9 `jwzt update` — 更新到最新版本

```bash
jwzt update
```

检查 PyPI 最新版本并执行 `pip install` 升级。更新成功后：
- 在当前目录生成 `UPDATE.md`（覆盖式），包含当前版本到最新版本的更新日志和迁移步骤
- 终端显示 Rich 美化的更新日志和迁移步骤面板

---

### 4.10 `jwzt helpme` — 导出帮助文档

```bash
jwzt helpme [--path <目录>]
```

| 选项 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `--path` | TEXT | `./docs/` | HELP.md 导出目录 |

导出完整帮助文档 HELP.md 到指定目录。如文件已存在则跳过。

---

## 5. V1/V2 推理模式

### 5.1 V1 标准推理

V1 模式使用内置的 LABDG-Pre 分割先验，端到端完成分割+分类：

```
超声图像 → LABDG-Pre → DGBC-MTLNet → MPTC-Head → 良恶性概率
              │              │             │
           结构图×4      分割掩码      分类概率
                        边缘图        不确定性图
                        SDM
```

```bash
# CLI 推理
jwzt pred --config configs/pred.yaml --model checkpoints/best_auc.ckpt --data dataset/Dataset_BUSI_with_GT

# Server V1
jwzt server --model checkpoints/best_auc.ckpt --inference-mode v1
```

**特点：**
- 端到端推理，无需外部依赖
- 输出：分割掩码 + 边缘图 + SDM + 不确定性图 + 分类概率
- 适用于标准推理和快速部署场景

### 5.2 V2 nnUNet 推理

V2 模式使用 nnUNetv2 高精度分割先验 + 极坐标轮廓特征，分步完成分割和分类：

```
超声图像 → nnUNetv2 → 分割概率图 + 掷码
                │
                ▼
       ┌─── 极坐标轮廓特征 ───┐
       │  从掩码边界提取        │
       │  肿瘤外 8 行 + 内 8 行  │
       │  360° 角度采样        │
       └────────┬─────────────┘
                │
                ▼
超声图像 + 概率图 + 轮廓特征 → V2 分类器 → 良恶性概率
```

```bash
# Server V2（推理时自动执行 nnUNet 分割 + 轮廓生成 + V2 分类）
jwzt server \
  --model experiments/v2_exp/checkpoints/best_auc.ckpt \
  --config configs/server.yaml \
  --inference-mode v2
```

**特点：**
- nnUNetv2 分割精度高于内置 LABDG-Pre
- 极坐标轮廓特征捕获肿瘤边界形态信息
- Server V2 推理时自动执行完整流水线（nnUNet 分割 → 轮廓生成 → 分类）
- 适用于高精度推理和临床辅助诊断场景

### 5.3 模式选择

| 场景 | 推荐模式 | 说明 |
|------|----------|------|
| 快速推理 | V1 | 无需额外依赖，端到端 |
| 高精度推理 | V2 | nnUNet 分割精度更高 |
| 批量处理 | V1 | 速度更快 |
| 临床辅助诊断 | V2 + Server | 精度优先，Server 自动流水线 |
| 已有 nnUNet 模型 | V2 | 充分利用已有高精度分割模型 |

### 5.4 V1/V2 模型检查点

V1 和 V2 使用不同的模型架构，检查点不通用：

| 检查点来源 | 适用模式 |
|------------|----------|
| `--stage finetune_all` 训练产出 | V1 |
| `--stage train_cls_nnunet_prior` 训练产出 | V2 |

---

## 6. Server 部署与前端工作台

### 6.1 安装服务端依赖

```bash
pip install -e ".[server]"
```

### 6.2 启动推理服务

```bash
# 基本启动（V1）
jwzt server \
  --model checkpoints/best_auc.ckpt \
  --host 0.0.0.0 \
  --port 8000

# 使用 YAML 配置文件
jwzt get -t server -o configs/server.yaml
jwzt server -c configs/server.yaml

# 使用环境变量
export JWZT_MODEL=checkpoints/best_auc.ckpt
export JWZT_PORT=8000
jwzt server
```

### 6.3 V1/V2 引擎

Server 支持 V1 和 V2 推理引擎：

```bash
# V1 引擎（默认）
jwzt server --model checkpoints/best_auc.ckpt --inference-mode v1

# V2 引擎（需要 nnUNet 缓存）
jwzt server --model checkpoints/best_auc.ckpt --inference-mode v2 \
  -c configs/server.yaml
```

### 6.4 报告生成

Server 提供三种报告生成模式：

| 模式 | 说明 |
|------|------|
| `rule` | 确定性规则模板 |
| `llm` | LLM 生成可编辑报告 |
| `hybrid` | 规则模板 + LLM 润色（LLM 失败时回退规则） |

```bash
# 配置 LLM（OpenAI 兼容）
export JWZT_REPORT_LLM_BASE_URL=https://your-openai-compatible.example.com/v1
export JWZT_REPORT_LLM_API_KEY=sk-...
export JWZT_REPORT_LLM_MODEL=gpt-4.1-mini
```

### 6.5 前端临床工作台

#### 同端口模式

```bash
jwzt server \
  --model checkpoints/best_auc.ckpt \
  --with-ui \
  --host 0.0.0.0 \
  --port 8000
```

- API: `http://127.0.0.1:8000/api/...`
- UI: `http://127.0.0.1:8000/`

#### 独立端口模式

```bash
jwzt server \
  --model checkpoints/best_auc.ckpt \
  --with-ui \
  --port 8000 \
  --ui-host 0.0.0.0 \
  --ui-port 8080 \
  --ui-api-base-url http://127.0.0.1:8000
```

#### 前端功能

- 单图/双图诊断模式
- 患者元数据和超声结构化字段录入
- 异步推理进度显示
- 可编辑结构化报告渲染
- 浏览器本地草稿/历史记录
- JSON 导出和 PDF 导出

### 6.6 环境变量参考

| 环境变量 | 对应 CLI 选项 |
|----------|---------------|
| `JWZT_MODEL` | `--model` |
| `JWZT_CONFIG` | `--config` |
| `JWZT_HOST` | `--host` |
| `JWZT_PORT` | `--port` |
| `JWZT_DEVICE` | `--device` |
| `JWZT_TTA` | `--tta/--no-tta` |
| `JWZT_INFERENCE_MODE` | `--inference-mode` |
| `JWZT_WITH_UI` | `--with-ui` |
| `JWZT_UI_PORT` | `--ui-port` |
| `JWZT_REPORT_LLM_BASE_URL` | `--report-llm-base-url` |
| `JWZT_REPORT_LLM_API_KEY` | `--report-llm-api-key` |
| `JWZT_REPORT_LLM_MODEL` | `--report-llm-model` |

---

## 7. 配置文件参考

### 7.1 V1 训练配置

训练配置包含模型结构、训练超参数、损失函数等：

```yaml
model:
  name: LABDG_DGBC_MTLNet_MPTC
  raw_input_channels: 1        # 输入通道 (1=灰度)
  pre_channels: 16             # 预处理输出通道
  encoder_channels: [64, 128, 256, 512]
  use_mamba: true
  dropout: 0.2

training:
  epochs: 80
  batch_size: 8
  learning_rate: 0.0001
  scheduler: cosine
  warmup_epochs: 5
  device: auto

loss:
  seg_loss: dice_bce          # 分割损失
  cls_loss: asymmetric_focal  # 分类损失
  edge_loss: boundary_bce     # 边缘损失
  lambda_cls: 1.0
  lambda_edge: 1.0
```

### 7.2 V2 训练配置

V2 配置在 V1 基础上增加 nnUNet 和轮廓段：

```yaml
config_type: train_v2
config_version: '2.0'

nnunet:
  enabled: true
  dataset_id: '001'
  dataset_name: BUS_Tumor2D
  model_dir: experiments/nnUNet_results/Dataset001_BUS_Tumor2D/nnUNetTrainer__nnUNetPlans__2d
  folds: ['0']
  checkpoint: checkpoint_best.pth
  prob_dir: dataset/v2_cache/seg_prob
  mask_dir: dataset/v2_cache/seg_mask

contour:
  enabled: true
  strategy: polar_contour
  cache_dir: dataset/v2_cache/polar_contour
  outer_height: 8
  inner_height: 8
  degrees: 360
```

### 7.3 推理配置

```yaml
inference:
  model_path: checkpoints/best_auc.ckpt
  use_tta: true
  threshold: 0.5
  use_largest_component: true
  save_overlay: true
```

### 7.4 Server 配置

```yaml
server:
  model: checkpoints/best_auc.ckpt
  inference_mode: v1        # v1 或 v2
  host: 0.0.0.0
  port: 8000
  with_ui: true
  max_queue: 32
  max_upload_mb: 10

report_llm:
  enabled: false
  base_url: ''
  api_key: ''
  model: ''
  timeout: 60
```

### 7.5 nnUNet 配置

```yaml
nnunet:
  dataset_id: 001
  dataset_name: BUS_Tumor2D
  raw_dir: dataset/nnUNet_raw
  preprocessed_dir: dataset/nnUNet_preprocessed
  results_dir: experiments/nnUNet_results
  configuration: 2d
  fold: '0'
  save_probabilities: true
  prior_source: nnunet
```

---

## 8. 目录结构说明

### 8.1 项目根目录

```
JwzTumor/
├── configs/                # YAML 配置文件
├── dataset/                # BUSBRA + BUSI 数据
│   └── v2_cache/           # V2 缓存（概率图、掩码、轮廓）
├── web/                    # React + Vite + TypeScript 前端源码
├── scripts/                # 构建和维护脚本
├── src/JwzTumor/
│   ├── cli/                # CLI 命令实现
│   ├── data/               # 数据集、预处理、增强、缓存、审计
│   │   └── update_log.csv  # 版本更新日志数据
│   ├── models/             # LABDG-Pre, DGBCEncoder, MPP, Decoder, MPTC-Head
│   ├── contour/            # 极坐标轮廓特征提取
│   ├── losses/             # 7 个损失模块 + 工厂
│   ├── training/           # Stage 训练器、调度器、回调
│   ├── inference/          # 预测器、TTA、后处理、可视化
│   ├── evaluation/         # 分类 + 分割指标
│   ├── server/             # FastAPI 推理服务
│   │   ├── report/         # 规则/LLM/混合报告生成
│   │   └── ui/             # 打包的前端静态文件
│   ├── nnunet/             # nnUNet 集成（prepare、predict、export）
│   ├── utils/              # 配置、种子、日志、I/O、注册
│   ├── HELP.md             # 帮助文档（随 package 打包）
│   └── __version__.py      # 版本号定义
├── tests/                  # Python 测试
├── pyproject.toml          # 项目配置
└── README.md
```

### 8.2 实验输出目录

```
experiments/
├── <v1_exp>/                     # V1 实验目录
│   ├── config.yaml               # 配置快照
│   ├── checkpoints/
│   │   ├── best_auc.ckpt
│   │   └── latest.ckpt
│   └── logs/
│       └── training.log
├── <v2_exp>/                     # V2 实验目录
│   └── checkpoints/
│       └── best_auc.ckpt
└── nnUNet_results/               # nnUNet 训练结果
    └── Dataset001_BUS_Tumor2D/
        └── nnUNetTrainer__nnUNetPlans__2d/
            └── fold_0/
                └── checkpoint_best.pth
```

### 8.3 推理输出目录

```
outputs/
├── predictions/
│   ├── cls_results.csv      # 分类结果
│   ├── seg_masks/           # 分割掩码
│   └── visualizations/      # 可解释性可视化
└── eval/
    ├── metrics.json         # 评估指标
    └── reports/             # 评估报告
```

---

## 9. 常见问题

### Q: CUDA 不可用？

确保已安装 CUDA 版本的 PyTorch：
```bash
nvidia-smi  # 查看 CUDA 版本
pip install torch torchvision --index-url https://download.pytorch.org/whl/cu124
```

### Q: 如何选择 V1 还是 V2 模式？

- **V1 模式**：四阶段渐进式训练，端到端推理，适合快速部署和标准场景
- **V2 模式**：需要先训练 nnUNet 分割模型，再用分割先验训练 V2 分类器，适合追求更高精度的场景
- 如果没有 nnUNet 训练经验，建议从 V1 开始

### Q: 如何选择训练阶段？

**V1 四阶段训练（必须按顺序执行）：**
1. `pretrain_pre` — 训练 LABDG-Pre 预处理模块
2. `pretrain_seg` — 训练 DGBC-MTLNet 分割
3. `train_cls` — 训练 MPTC-Head 分类头
4. `finetune_all` — 端到端微调

**V2 单阶段训练：**
- `train_cls_nnunet_prior` — 使用 nnUNet 先验训练分类头（需要先完成 nnUNet 训练和缓存导出）

### Q: 如何调整训练参数？

编辑配置文件或导出新模板：
```bash
# 导出模板
jwzt get -t train -o configs/my_train.yaml
jwzt get -t train_v2 -o configs/my_train_v2.yaml

# 编辑配置中的 training 段
# training.epochs、training.batch_size、training.learning_rate 等
```

### Q: V2 训练时提示缓存不存在？

V2 训练需要统一分割先验缓存。优先按配置生成：
```bash
jwzt nnunet predict -c configs/train_v2.yaml --save-probabilities
jwzt nnunet export -c configs/train_v2.yaml
```

如果只想使用数据集 mask 或算法 soft prob 进行分类实验：
```bash
jwzt nnunet predict -c configs/train_v2.yaml
jwzt nnunet export -c configs/train_v2.yaml --prior-source dataset --prob-mode distance
```

极坐标轮廓缓存会在训练时自动生成（首次运行较慢，后续使用缓存）。

### Q: Server 部署时前端无法访问？

1. 确保使用 `--with-ui` 参数
2. 检查 `--ui-port` 是否被占用
3. 如果使用独立端口模式，确保 `--ui-api-base-url` 指向正确的 API 地址

### Q: 如何更新 JwzTumor？

```bash
# 方法1：使用 jwzt update（推荐）
jwzt update

# 方法2：手动 pip 更新
pip install JwzTumor --upgrade

# 方法3：开发模式更新
git pull
pip install -e .
```

### Q: 报告生成失败？

1. 检查 LLM 环境变量是否正确设置
2. 报告服务会自动回退到 `rule` 模式
3. 使用 `hybrid` 模式可获得最佳体验

### Q: nnUNet 训练失败？

1. 确保已安装 nnunet 依赖：`pip install -e ".[nnunet]"`
2. 检查数据格式是否正确
3. 确保 `nnUNet_raw`、`nnUNet_preprocessed`、`nnUNet_results` 环境变量已设置

### Q: 如何查看版本更新日志？

```bash
# 方法1：运行 jwzt update（自动生成 UPDATE.md）
jwzt update

# 方法2：导出帮助文档查看版本特性
jwzt helpme --path ./docs/
```
