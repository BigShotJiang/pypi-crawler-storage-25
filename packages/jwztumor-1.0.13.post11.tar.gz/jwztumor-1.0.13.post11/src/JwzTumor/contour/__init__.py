"""Contour feature extraction for JwzTumor V2."""

