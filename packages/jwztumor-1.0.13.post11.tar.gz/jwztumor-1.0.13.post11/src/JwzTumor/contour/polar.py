"""2D polar contour extraction from tumor masks."""
from __future__ import annotations

import math

import numpy as np


def compute_tumor_mask_centroid(mask: np.ndarray) -> tuple[int, int]:
    """Return the foreground geometric centroid as `(cy, cx)`."""
    ys, xs = np.nonzero(np.asarray(mask) > 0)
    if ys.size == 0:
        raise ValueError("mask is empty")
    return int(np.rint(ys.mean())), int(np.rint(xs.mean()))


def build_polar_contour(
    image: np.ndarray,
    mask: np.ndarray,
    outer_height: int = 8,
    inner_height: int = 8,
    degrees: int = 360,
) -> tuple[np.ndarray, np.ndarray]:
    """Build a `[outer+inner, degrees]` contour matrix around a 2D mask.

    Rows `0..outer_height-1` sample outside the first tumor exit point.
    Rows `outer_height..outer_height+inner_height-1` sample inside the tumor
    near the same radial boundary. Outside samples that re-enter tumor are
    marked and repaired by same-height angular imputation.
    """
    image_arr = np.asarray(image, dtype=np.float32)
    mask_arr = np.asarray(mask) > 0
    if image_arr.ndim != 2 or mask_arr.ndim != 2:
        raise ValueError("image and mask must be 2D arrays")
    if image_arr.shape != mask_arr.shape:
        raise ValueError("image and mask must have the same shape")

    total_height = outer_height + inner_height
    contour = np.zeros((total_height, degrees), dtype=np.float32)
    reentry = np.zeros((outer_height, degrees), dtype=np.uint8)
    valid_outer = np.ones((outer_height, degrees), dtype=bool)
    cy, cx = compute_tumor_mask_centroid(mask_arr)
    max_radius = int(math.ceil(math.hypot(*image_arr.shape))) + total_height + 2

    for angle_idx in range(degrees):
        theta = (2.0 * math.pi * angle_idx) / degrees
        dy = math.sin(theta)
        dx = math.cos(theta)
        exit_radius = _find_first_exit_radius(mask_arr, cy, cx, dy, dx, max_radius)

        for h in range(outer_height):
            y = cy + dy * (exit_radius + h)
            x = cx + dx * (exit_radius + h)
            contour[h, angle_idx] = _sample_bilinear(image_arr, y, x)
            if _sample_mask(mask_arr, y, x):
                reentry[h, angle_idx] = 1
                valid_outer[h, angle_idx] = False

        for h in range(inner_height):
            y = cy + dy * (exit_radius - h - 1)
            x = cx + dx * (exit_radius - h - 1)
            contour[outer_height + h, angle_idx] = _sample_bilinear(image_arr, y, x)

    _repair_reentry(contour, valid_outer, outer_height=outer_height)
    return contour, reentry


def _find_first_exit_radius(
    mask: np.ndarray,
    cy: int,
    cx: int,
    dy: float,
    dx: float,
    max_radius: int,
) -> int:
    """Find first radius where a ray leaves tumor after seeing foreground."""
    seen_tumor = False
    last_tumor_radius = 0
    for radius in range(max_radius + 1):
        inside = _sample_mask(mask, cy + dy * radius, cx + dx * radius)
        if inside:
            seen_tumor = True
            last_tumor_radius = radius
        elif seen_tumor:
            return radius
    return last_tumor_radius


def _sample_mask(mask: np.ndarray, y: float, x: float) -> bool:
    yy = int(round(y))
    xx = int(round(x))
    if yy < 0 or xx < 0 or yy >= mask.shape[0] or xx >= mask.shape[1]:
        return False
    return bool(mask[yy, xx])


def _sample_bilinear(image: np.ndarray, y: float, x: float) -> float:
    y = float(np.clip(y, 0, image.shape[0] - 1))
    x = float(np.clip(x, 0, image.shape[1] - 1))
    y0 = int(math.floor(y))
    x0 = int(math.floor(x))
    y1 = min(y0 + 1, image.shape[0] - 1)
    x1 = min(x0 + 1, image.shape[1] - 1)
    wy = y - y0
    wx = x - x0
    top = (1.0 - wx) * image[y0, x0] + wx * image[y0, x1]
    bottom = (1.0 - wx) * image[y1, x0] + wx * image[y1, x1]
    return float((1.0 - wy) * top + wy * bottom)


def _repair_reentry(contour: np.ndarray, valid_outer: np.ndarray, outer_height: int) -> None:
    for row in range(outer_height):
        valid_indices = np.flatnonzero(valid_outer[row])
        invalid_indices = np.flatnonzero(~valid_outer[row])
        if invalid_indices.size == 0:
            continue
        if valid_indices.size == 0:
            contour[row, invalid_indices] = float(np.mean(contour[row]))
            continue
        global_mean = float(np.mean(contour[row, valid_indices]))
        for angle_idx in invalid_indices:
            contour[row, angle_idx] = _weighted_angular_value(
                values=contour[row],
                valid_indices=valid_indices,
                angle_idx=int(angle_idx),
                degrees=contour.shape[1],
                fallback=global_mean,
            )


def _weighted_angular_value(
    values: np.ndarray,
    valid_indices: np.ndarray,
    angle_idx: int,
    degrees: int,
    fallback: float,
    neighbors_per_side: int = 3,
) -> float:
    candidates: list[tuple[int, float]] = []
    valid_set = set(int(idx) for idx in valid_indices)
    for direction in (-1, 1):
        found = 0
        for dist in range(1, degrees // 2 + 1):
            idx = (angle_idx + direction * dist) % degrees
            if idx in valid_set:
                candidates.append((dist, float(values[idx])))
                found += 1
                if found >= neighbors_per_side:
                    break
    if not candidates:
        return fallback
    weights = np.asarray([1.0 / dist for dist, _ in candidates], dtype=np.float32)
    vals = np.asarray([val for _, val in candidates], dtype=np.float32)
    return float(np.sum(weights * vals) / np.sum(weights))
