"""V2 predictor using external nnUNet segmentation priors."""
from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, List, Optional

import torch

from ..data.collate import multitask_collate_fn
from .predictor import MultiTaskPredictor


def should_use_v2_predictor(config) -> bool:
    """Return True when the loaded config belongs to the V2 model family."""
    return getattr(getattr(config, "meta", None), "config_type", "") == "train_v2"


class MultiTaskPredictorV2(MultiTaskPredictor):
    """Batch predictor that forwards V2 prior tensors into the model."""

    def predict_batch(
        self,
        dataset,
        output_dir: str,
        use_tta: bool = False,
        tta_fn=None,
        verbose: bool = False,
        display=None,
        batch_size: Optional[int] = None,
    ) -> List[Dict[str, Any]]:
        from torch.utils.data import DataLoader
        from .postprocessing import postprocess_segmentation, postprocess_classification
        from .visualization import save_prediction_outputs

        output_dir = Path(output_dir)
        output_dir.mkdir(parents=True, exist_ok=True)
        if batch_size is None:
            batch_size = self.config.training.batch_size

        use_cuda = self.device.type == "cuda"
        loader = DataLoader(
            dataset,
            batch_size=batch_size,
            shuffle=False,
            num_workers=0,
            collate_fn=multitask_collate_fn,
            pin_memory=use_cuda,
        )
        predictions: List[Dict[str, Any]] = []

        if display is not None:
            display.start(total=len(loader), description="Predicting V2")
            progress = task_id = None
        else:
            from ..utils.rich_display import create_prediction_progress
            progress, task_id = create_prediction_progress(total_steps=len(loader), description="Predicting V2")

        try:
            for batch_idx, batch in enumerate(loader):
                images = batch["image"].to(self.device, non_blocking=use_cuda)
                external_seg_prob = batch["external_seg_prob"].to(self.device, non_blocking=use_cuda)
                polar_contour = batch["polar_contour"].to(self.device, non_blocking=use_cuda)

                with torch.inference_mode():
                    outputs = self.model(
                        images,
                        external_seg_prob=external_seg_prob,
                        polar_contour=polar_contour,
                    )

                for i in range(images.shape[0]):
                    meta = batch["meta"][i] if "meta" in batch else {}
                    pred = {
                        "image_id": meta.get("image_id", f"sample_{batch_idx}_{i}"),
                        "cls_prob": outputs["cls_prob"][i].cpu() if "cls_prob" in outputs else None,
                        "seg_prob": outputs["seg_prob"][i].cpu() if "seg_prob" in outputs else None,
                        "contour_preview": batch["polar_contour"][i].cpu(),
                        "polar_reentry_preview": batch.get("polar_reentry_mask", [None])[i].cpu()
                        if "polar_reentry_mask" in batch else None,
                        "meta": meta,
                        "true_label": batch["label"][i].item() if "label" in batch else None,
                    }
                    if pred["seg_prob"] is not None:
                        pred["seg_mask"] = postprocess_segmentation(
                            pred["seg_prob"].unsqueeze(0),
                            threshold=self.config.inference.threshold,
                        ).squeeze(0)
                    if pred["cls_prob"] is not None:
                        pred.update(postprocess_classification(pred["cls_prob"]))
                    predictions.append(pred)

                done = len(predictions)
                if display is not None:
                    display.update_progress(advance=1, postfix=f"done={done}")
                elif progress is not None and task_id is not None:
                    progress.update(task_id, advance=1, postfix=f"done={done}")
        finally:
            if display is not None:
                display.stop()
            elif progress is not None:
                progress.stop()

        save_prediction_outputs(predictions, output_dir)
        return predictions
