"""Training implementation for JwzTumor CLI."""
import logging
import re
import time
from pathlib import Path
from typing import Dict, Optional

from ..utils.config import load_config
from ..utils.seed import set_seed
from ..utils.logging import setup_logging
from ..models.model_factory import create_model
from ..data.dataset_factory import create_dataloaders
from ..data.cache import DatasetCache
from ..training.stage_trainer import StageTrainer
from ..nnunet.cache_prepare import prepare_v2_artifacts

logger = logging.getLogger(__name__)


def _backup_config(
    config_path: str,
    experiment_name: str,
    save_dir: str,
) -> None:
    """Backup the source config file with experiment section at top.

    Reads the original YAML (preserving comments), updates experiment fields,
    and writes to ``{save_dir}/{experiment_name}/config_{experiment_name}.yaml``
    with the experiment section moved to the top.
    """
    src = Path(config_path)
    if not src.exists():
        logger.warning("Config source file not found: %s", config_path)
        return

    raw_text = src.read_text(encoding="utf-8")

    # Split into sections: find the experiment: section and everything else
    lines = raw_text.split("\n")

    # Find experiment section boundaries
    exp_start = None
    exp_end = None
    for i, line in enumerate(lines):
        stripped = line.strip()
        if re.match(r"^experiment\s*:", stripped):
            exp_start = i
        elif exp_start is not None and exp_end is None:
            # Section ends when we hit a top-level key (no indent) or EOF
            if stripped and not stripped.startswith("#") and ":" in stripped and not line.startswith(" ") and not line.startswith("\t"):
                exp_end = i
                break

    if exp_start is None:
        logger.warning("No 'experiment' section found in config, backup unchanged")
        exp_section_lines = []
        remaining_lines = lines
    else:
        if exp_end is None:
            exp_end = len(lines)
        exp_section_lines = lines[exp_start:exp_end]
        remaining_lines = lines[:exp_start] + lines[exp_end:]

    # Update experiment_name and note in the experiment section
    updated_exp = []
    found_experiment_name = False
    for line in exp_section_lines:
        if re.match(r"^\s+experiment_name\s*:", line):
            updated_exp.append(re.sub(r"(:\s*).*$", f": '{experiment_name}'", line))
            found_experiment_name = True
        else:
            updated_exp.append(line)

    # Build header
    header = [
        f"# 实验配置备份: {experiment_name}",
        f"# 原始配置: {config_path}",
        "",
    ]

    # Assemble: header + experiment section + remaining sections
    output_lines = header + updated_exp
    if remaining_lines:
        # Remove leading blank lines from remaining
        while remaining_lines and not remaining_lines[0].strip():
            remaining_lines.pop(0)
        if remaining_lines:
            output_lines.append("")
            output_lines.extend(remaining_lines)

    # Write backup
    exp_dir = Path(save_dir) / experiment_name
    exp_dir.mkdir(parents=True, exist_ok=True)
    backup_path = exp_dir / f"config_{experiment_name}.yaml"
    backup_path.write_text("\n".join(output_lines), encoding="utf-8")
    logger.info("Config backed up to %s", backup_path)


def run_training(
    config_path: str,
    resume_path: Optional[str] = None,
    init_weight_path: Optional[str] = None,
    experiment_name: Optional[str] = None,
    overrides: Optional[Dict] = None,
    verbose: bool = False,
) -> None:
    """Run the training pipeline.

    Args:
        config_path: Path to YAML config file.
        resume_path: Optional checkpoint path to resume from.
            Restores full training state (optimizer, scheduler, scaler,
            epoch, history, best_values). Mutually exclusive with
            ``init_weight_path``.
        init_weight_path: Optional path to pretrained model weights.
            Only loads model state_dict as initialization; starts a
            completely fresh training run (epoch 0, new optimizer, etc.).
            Mutually exclusive with ``resume_path``; when both are
            specified, ``resume_path`` takes priority.
        experiment_name: Name for this experiment.
        overrides: Dict of config overrides.
        verbose: Enable verbose logging with live display.
    """
    import torch

    from ..utils.rich_display import (
        VerboseLiveDisplay,
        SimpleProgressDisplay,
        set_active_display,
        print_training_config,
        print_training_results,
        close_file_log,
    )

    # Load config
    config = load_config(config_path)

    # Resolve experiment name: CLI > config > error
    resolved_name = experiment_name or config.experiment.experiment_name
    if not resolved_name:
        logger.error(
            "实验名称未指定。请使用 --experiment-name 或在配置文件中设置 experiment.experiment_name"
        )
        raise SystemExit(1)
    config.experiment.name = resolved_name
    config.experiment.experiment_name = resolved_name

    if overrides:
        config.apply_overrides(**overrides)

    # Backup config before training starts
    _backup_config(config_path, resolved_name, config.experiment.save_dir)

    # Setup
    set_seed(config.training.random_seed)
    log_dir = Path(config.experiment.save_dir) / resolved_name / "logs"

    # Auto-discover latest checkpoint when neither --resume nor --init-weight is provided
    ckpt_dir = Path(config.experiment.save_dir) / resolved_name / "checkpoints"
    if resume_path is None and init_weight_path is None:
        auto_ckpt = ckpt_dir / "latest_model.ckpt"
        if auto_ckpt.exists():
            resume_path = str(auto_ckpt)
            logger.info("Auto-discovered checkpoint: %s", resume_path)

    # Create display BEFORE setup_logging so the handler can find it
    if verbose:
        display = VerboseLiveDisplay(max_log_lines=25)
    else:
        display = SimpleProgressDisplay()
    set_active_display(display)

    setup_logging(
        level=logging.DEBUG if verbose else logging.INFO,
        log_dir=str(log_dir),
        experiment_name=resolved_name,
        use_rich=True,
    )

    logger.info("Config: %s", config)

    # Validate V2 prior caches before model construction or optimizer setup.
    prepare_v2_artifacts(config)

    # Create model with init_seed for reproducible weight initialization
    init_seed = config.training.init_seed
    set_seed(init_seed)
    logger.info("Init seed set to %d for model creation", init_seed)
    model = create_model(config)
    logger.info("Model created: %s (init_seed=%d)", config.model.name, init_seed)

    # Restore training seed for the rest of the pipeline
    set_seed(config.training.random_seed)

    # Resume from checkpoint (full state restoration)
    start_epoch = 0
    optimizer_state = None
    scheduler_state = None
    scaler_state = None
    history = None
    best_values = None
    if resume_path:
        ckpt = torch.load(resume_path, map_location="cpu", weights_only=False)
        model.load_state_dict(ckpt["model_state_dict"])
        start_epoch = ckpt.get("epoch", 0) + 1  # stored 0-based, resume from next
        optimizer_state = ckpt.get("optimizer_state_dict")
        scheduler_state = ckpt.get("scheduler_state_dict")
        scaler_state = ckpt.get("scaler_state_dict")
        history = ckpt.get("history")
        best_values = ckpt.get("best_values")
        logger.info(
            "Resumed from %s (epoch=%d, will start from epoch %d, best_values=%s)",
            resume_path, ckpt.get("epoch", -1), start_epoch, best_values,
        )
    elif init_weight_path:
        # Load pretrained weights as initialization (fresh training)
        ckpt = torch.load(init_weight_path, map_location="cpu", weights_only=False)
        if "model_state_dict" in ckpt:
            state_dict = ckpt["model_state_dict"]
        else:
            state_dict = ckpt
        missing, unexpected = model.load_state_dict(state_dict, strict=False)
        if missing:
            logger.warning("Missing keys when loading init weights: %s", missing)
        if unexpected:
            logger.warning("Unexpected keys in init weights (ignored): %s", unexpected)
        logger.info(
            "Loaded init weights from %s (fresh training, missing=%d, unexpected=%d)",
            init_weight_path, len(missing), len(unexpected),
        )

    # Create data
    cache = DatasetCache(mode=config.dataset.cache_mode)
    train_loader, val_loader, test_loader = create_dataloaders(config, cache=cache)

    # Preload val dataset into cache to avoid slow train->val switching
    if config.dataset.cache_mode == "ram":
        logger.info("Preloading validation dataset into RAM cache...")
        preload_start = time.time()
        val_dataset = val_loader.dataset
        for i in range(len(val_dataset)):
            val_dataset[i]
        logger.info(
            "Validation dataset preloaded: %d samples in %.1fs",
            len(val_dataset), time.time() - preload_start,
        )

    # Print Rich config panel (before progress bar takes over terminal)
    print_training_config(config)

    # Start display
    display.start(
        total=config.training.epochs,
        initial=start_epoch,
        description=f"[{config.training.stage}]",
    )

    start_time = time.time()
    try:
        # Train
        trainer = StageTrainer(
            config=config,
            model=model,
            train_loader=train_loader,
            val_loader=val_loader,
            test_loader=test_loader,
            display=display,
            start_epoch=start_epoch,
            optimizer_state=optimizer_state,
            scheduler_state=scheduler_state,
            scaler_state=scaler_state,
            history=history,
            best_values=best_values,
        )
        summary = trainer.train()

        logger.info("Training complete: %s", {k: v for k, v in summary.items() if k != "history"})
    finally:
        display.stop()
        set_active_display(None)

    # Print Rich results panel (after progress bar is cleaned up)
    print_training_results(config, summary, time.time() - start_time)

    # Save final config snapshot
    config_save_path = Path(config.experiment.save_dir) / resolved_name / "config.yaml"
    config.save_to_yaml(str(config_save_path))

    close_file_log()
