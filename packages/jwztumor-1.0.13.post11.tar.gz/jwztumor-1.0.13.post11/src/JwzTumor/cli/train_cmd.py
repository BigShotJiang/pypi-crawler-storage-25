"""Train command for JwzTumor CLI."""
import typer
from typing import Optional

train_app = typer.Typer(help="训练多任务诊断模型")


@train_app.callback(invoke_without_command=True)
def train(
    config: str = typer.Option("configs/train_full.yaml", "--config", "-c", help="YAML 配置文件路径"),
    resume: Optional[str] = typer.Option(None, "--resume", help="恢复训练的检查点路径（恢复完整训练状态）"),
    init_weight: Optional[str] = typer.Option(None, "--init-weight", "-w", help="预训练权重路径（仅加载模型权重，从头训练）"),
    experiment_name: Optional[str] = typer.Option(None, "--experiment-name", "-e", help="实验名称（未指定时使用配置文件中的 experiment.experiment_name）"),
    stage: Optional[str] = typer.Option(None, "--stage", help="训练阶段: pretrain_pre / pretrain_seg / train_cls / finetune_all / train_cls_nnunet_prior"),
    fold: Optional[int] = typer.Option(None, "--fold", help="交叉验证折数 ID"),
    cv_file: Optional[str] = typer.Option(None, "--cv-file", help="CV 文件名: 5-fold-cv.csv 或 10-fold-cv.csv"),
    case_level_split: bool = typer.Option(True, "--case-level-split/--no-case-level-split", help="按病例级分割数据（防止数据泄漏）"),
    cache_mode: Optional[str] = typer.Option(None, "--cache-mode", help="缓存模式: ram / disk / none"),
    verbose: bool = typer.Option(False, "--verbose", "-v", help="详细日志模式（含实时日志面板）"),
):
    """训练 JwzTumor 多任务诊断模型。"""
    from .train_impl import run_training

    overrides = {}
    if stage:
        overrides["training.stage"] = stage
    if fold is not None:
        overrides["dataset.fold"] = fold
    if cv_file:
        overrides["dataset.cv_file"] = cv_file
    if cache_mode:
        overrides["dataset.cache_mode"] = cache_mode

    run_training(
        config_path=config,
        resume_path=resume,
        init_weight_path=init_weight,
        experiment_name=experiment_name,
        overrides=overrides,
        verbose=verbose,
    )
