"""CLI Main Entry Point for JwzTumor."""
import typer

app = typer.Typer(
    name="jwzt",
    help="JwzTumor: 乳腺超声良恶性诊断 - 分割辅助多任务学习框架",
    no_args_is_help=True,
)

from .train_cmd import train_app
from .pred_cmd import predict_app
from .eval_cmd import eval_app
from .get_cmd import get_app
from .audit_cmd import audit_app
from .server_cmd import server_app
from .version_cmd import version_cmd
from .nnunet_cmd import nnunet_app
from .update_cmd import app as update_app
from .helpme_cmd import app as helpme_app

app.add_typer(train_app, name="train")
app.add_typer(predict_app, name="pred")
app.add_typer(eval_app, name="eval")
app.add_typer(get_app, name="get")
app.add_typer(audit_app, name="audit-data")
app.add_typer(server_app, name="server")
app.add_typer(nnunet_app, name="nnunet")
app.add_typer(update_app, name="update")
app.add_typer(helpme_app, name="helpme")
app.command(name="version")(version_cmd)


def run():
    exit_code = 0
    try:
        app()
    except SystemExit as e:
        exit_code = e.code if isinstance(e.code, int) else (e.code or 0)
    # Post-command update notification (never breaks normal usage)
    try:
        from JwzTumor.cli.version_check import notify_if_update_available
        from rich.console import Console
        notify_if_update_available(Console())
    except Exception:
        pass
    if exit_code:
        raise SystemExit(exit_code)


if __name__ == "__main__":
    run()
