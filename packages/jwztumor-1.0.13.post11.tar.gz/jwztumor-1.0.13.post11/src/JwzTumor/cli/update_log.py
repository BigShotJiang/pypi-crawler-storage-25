"""Version changelog utilities: CSV reader, UPDATE.md generator, Rich renderer.

The changelog CSV is bundled with the package at
``JwzTumor/data/update_log.csv`` and read at runtime via
``importlib.resources``.
"""

from __future__ import annotations

import csv
import importlib.resources
from datetime import datetime
from typing import Any

from rich.console import Console
from rich.panel import Panel
from rich.text import Text

from packaging.version import Version


# ---------------------------------------------------------------------------
# CSV path helper
# ---------------------------------------------------------------------------

def _csv_path() -> str:
    """Return the absolute path to the bundled ``update_log.csv``."""
    ref = importlib.resources.files("JwzTumor").joinpath("data", "update_log.csv")
    return str(ref)


# ---------------------------------------------------------------------------
# CSV reader
# ---------------------------------------------------------------------------

def load_update_log() -> list[dict[str, str]]:
    """Load the bundled CSV and return rows as list of dicts.

    Rows are ordered newest-first (same order as the CSV file).
    """
    path = _csv_path()
    with open(path, newline="", encoding="utf-8") as fh:
        return list(csv.DictReader(fh))


# ---------------------------------------------------------------------------
# Version-range filter
# ---------------------------------------------------------------------------

def filter_updates(
    rows: list[dict[str, str]],
    current: str,
    latest: str,
) -> list[dict[str, str]]:
    """Return rows whose version is in (current, latest].

    Uses ``packaging.version.Version`` for PEP 440 comparison.
    Lower bound is **exclusive** (don't show current version's own changes).
    """
    v_current = Version(current)
    v_latest = Version(latest)
    return [
        r for r in rows
        if v_current < Version(r["version"]) <= v_latest
    ]


# ---------------------------------------------------------------------------
# UPDATE.md generator
# ---------------------------------------------------------------------------

_TYPE_LABEL: dict[str, str] = {
    "feature": "新特性",
    "fix": "修复",
    "change": "变更",
    "breaking": "破坏性变更",
}


def _group_by_version(
    rows: list[dict[str, str]],
) -> list[tuple[str, list[dict[str, str]]]]:
    """Group rows by version, preserving CSV order (newest first)."""
    groups: list[tuple[str, list[dict[str, str]]]] = []
    current_ver = ""
    current_rows: list[dict[str, str]] = []
    for row in rows:
        if row["version"] != current_ver:
            if current_rows:
                groups.append((current_ver, current_rows))
            current_ver = row["version"]
            current_rows = [row]
        else:
            current_rows.append(row)
    if current_rows:
        groups.append((current_ver, current_rows))
    return groups


def render_update_md(
    rows: list[dict[str, str]],
    current: str,
    latest: str,
) -> str:
    """Generate UPDATE.md content as a string.

    Changelog section: versions newest-to-oldest.
    Migration section: versions oldest-to-new (execution order).
    """
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    lines: list[str] = [
        "# JwzTumor 更新日志",
        "",
        f"> 从 V{current} 更新到 V{latest}",
        f"> 生成时间: {now}",
        "",
        "---",
        "",
    ]

    # --- Changelog section (newest -> oldest) ---
    groups = _group_by_version(rows)
    for ver, ver_rows in groups:
        type_label = _TYPE_LABEL.get(ver_rows[0]["type"], ver_rows[0]["type"])
        lines.append(f"## V{ver} {type_label}")
        lines.append("")
        for r in ver_rows:
            desc = r["description"].replace("\\n", "\n")
            lines.append(f"- **{r['title']}**: {desc}")
        lines.append("")

    lines.append("---")
    lines.append("")
    lines.append("## 迁移步骤")
    lines.append("")

    # --- Migration section (oldest -> newest) ---
    for ver, ver_rows in reversed(groups):
        lines.append(f"### V{ver}")
        lines.append("")
        steps: list[str] = []
        for r in ver_rows:
            step_text = r["migration_steps"].replace("\\n", "\n").strip()
            if step_text and step_text not in steps:
                steps.append(step_text)
        for step in steps:
            lines.append(step)
        lines.append("")

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Rich terminal renderer
# ---------------------------------------------------------------------------

def render_rich_changelog(
    rows: list[dict[str, str]],
    console: Console,
) -> None:
    """Print Rich changelog panel (versions newest-to-oldest)."""
    groups = _group_by_version(rows)
    parts: list[Any] = []

    for ver, ver_rows in groups:
        type_label = _TYPE_LABEL.get(ver_rows[0]["type"], ver_rows[0]["type"])
        ver_text = Text(f"V{ver} {type_label}", style="bold cyan")
        items: list[str] = []
        for r in ver_rows:
            desc = r["description"].replace("\\n", " ")
            items.append(f"  \u2022 {r['title']}: {desc}")
        parts.append(ver_text)
        parts.append(Text("\n".join(items)))
        parts.append(Text(""))

    content = Text("\n").join([p if isinstance(p, Text) else Text(str(p)) for p in parts])
    console.print(Panel(content, title="更新日志", border_style="blue", expand=False))


def render_rich_migration(
    rows: list[dict[str, str]],
    console: Console,
) -> None:
    """Print Rich migration steps panel (versions oldest-to-newest)."""
    groups = list(reversed(_group_by_version(rows)))
    parts: list[Any] = []

    for ver, ver_rows in groups:
        ver_text = Text(f"V{ver}", style="bold yellow")
        steps: list[str] = []
        for r in ver_rows:
            step_text = r["migration_steps"].replace("\\n", " ").strip()
            if step_text and step_text not in steps:
                steps.append(step_text)
        parts.append(ver_text)
        parts.append(Text("\n".join(f"  {s}" for s in steps)))
        parts.append(Text(""))

    content = Text("\n").join([p if isinstance(p, Text) else Text(str(p)) for p in parts])
    console.print(Panel(content, title="迁移步骤（按执行顺序）", border_style="yellow", expand=False))
