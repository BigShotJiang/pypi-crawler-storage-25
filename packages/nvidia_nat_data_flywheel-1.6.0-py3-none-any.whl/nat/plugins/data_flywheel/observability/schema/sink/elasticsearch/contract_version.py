# SPDX-FileCopyrightText: Copyright (c) 2024-2025, NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from enum import StrEnum

from pydantic import BaseModel

from nat.plugins.data_flywheel.observability.schema.schema_registry import SchemaRegistry


class ContractVersion(StrEnum):
    """The contract version for Elasticsearch schema."""

    V1_0 = "1.0"
    V1_1 = "1.1"

    def get_contract_class(self) -> type[BaseModel]:
        """Get the Pydantic model class for this contract version."""
        return SchemaRegistry.get_schema("elasticsearch", self.value)
