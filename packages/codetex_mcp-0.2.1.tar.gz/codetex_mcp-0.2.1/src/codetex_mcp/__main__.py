from codetex_mcp.cli.app import main

if __name__ == "__main__":
    main()
