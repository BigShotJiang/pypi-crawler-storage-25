"""User contents protobuf definitions."""
