"""Tieba post detail protobuf package."""
