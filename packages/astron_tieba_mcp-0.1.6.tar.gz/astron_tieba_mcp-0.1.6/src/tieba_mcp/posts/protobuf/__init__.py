"""Post detail protobuf definitions."""
