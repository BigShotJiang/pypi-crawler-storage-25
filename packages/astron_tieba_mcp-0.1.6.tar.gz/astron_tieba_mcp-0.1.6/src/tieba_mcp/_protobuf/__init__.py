"""Vendored protobuf definitions for Tieba MCP."""
