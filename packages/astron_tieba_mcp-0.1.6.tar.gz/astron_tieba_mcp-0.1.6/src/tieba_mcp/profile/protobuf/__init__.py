"""Profile protobuf definitions."""
