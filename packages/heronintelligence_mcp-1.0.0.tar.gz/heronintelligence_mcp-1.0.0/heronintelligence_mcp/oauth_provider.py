"""OAuth 2.1 Authorization Server provider for the Heron Intelligence MCP.

Durable state (DCR clients, auth codes, refresh tokens) is persisted by the
Heron Intelligence backend and reached over HTTP via `oauth_storage_client`.
Tokens are JWTs (HS256) with a shared secret.

Two parallel flows are supported:

  A. **Manual** clients — pre-provisioned and bound 1:1 to a user. /authorize
     auto-approves without `login_hint`.
  B. **DCR** clients — created at runtime via `POST /register`. /authorize
     requires a `login_hint` (the user's seat email) to resolve per-user
     identity; unknown emails get `access_denied`.
"""
from __future__ import annotations

import contextvars
import logging
import time
from dataclasses import dataclass
from typing import Optional

import httpx
from mcp.server.auth.provider import (
    AccessToken,
    AuthorizationCode,
    AuthorizationParams,
    AuthorizeError,
    OAuthAuthorizationServerProvider,
    RefreshToken,
    RegistrationError,
    TokenError,
)
from mcp.shared.auth import (
    InvalidRedirectUriError,
    OAuthClientInformationFull,
    OAuthToken,
)
from pydantic import AnyUrl

from heronintelligence_mcp import jwt_service
from heronintelligence_mcp._context import (
    _request_api_key,
    _request_user_email,
    _request_user_id,
)
from heronintelligence_mcp.oauth_storage_client import (
    OAuthClientView,
    get_storage_client,
)

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# login_hint propagation
# ---------------------------------------------------------------------------
# FastMCP's AuthorizationRequest schema does not include login_hint, so we
# intercept the query param in DualAuthMiddleware (http_app.py) before
# FastMCP's handler runs, and stash it here. The provider's authorize()
# pops it back out.
_current_login_hint: contextvars.ContextVar[Optional[str]] = contextvars.ContextVar(
    "heron_oauth_login_hint", default=None
)


def set_login_hint(hint: Optional[str]) -> None:
    _current_login_hint.set(hint)


def get_login_hint() -> Optional[str]:
    return _current_login_hint.get()


# ---------------------------------------------------------------------------
# Client metadata wrapper
# ---------------------------------------------------------------------------
# We stash the resolved OAuthClientView on the FastMCP-compatible client
# object so authorize() can consult it without re-fetching.
_client_view_by_id: dict[str, OAuthClientView] = {}


class _HeronClientInfo(OAuthClientInformationFull):
    """Permissive redirect_uri validation (auth enforced via secret + PKCE)."""

    def validate_redirect_uri(self, redirect_uri: AnyUrl | None) -> AnyUrl:  # type: ignore[override]
        if redirect_uri is None:
            raise InvalidRedirectUriError(
                "redirect_uri must be provided"
            )
        return redirect_uri


# ---------------------------------------------------------------------------
# Internal tracking (per-auth-code hand-off)
# ---------------------------------------------------------------------------

@dataclass
class _PendingCode:
    """Cached context for a fresh auth code.

    FastMCP verifies PKCE between load_authorization_code() and
    exchange_authorization_code(), so load() must return the REAL code_challenge.
    The atomic DB consume happens only in exchange(). We keep the in-memory
    snapshot to avoid a peek-endpoint round-trip on the critical path.

    Limitation: an MCP restart drops this dict, and any in-flight auth codes
    (<= 10min old, unexchanged) become unusable — Claude will re-auth. For
    multi-instance deployments, add a storage peek endpoint instead.
    """
    mcp_client_id: str
    consumption_user_id: Optional[str]
    client_id: str
    code_challenge: str
    redirect_uri: str
    scopes: list[str]
    resource: Optional[str]
    expires_at: float


_pending_codes: dict[str, _PendingCode] = {}


async def issue_auth_code(
    *,
    oauth_client_id: str,
    mcp_client_id: str,
    consumption_user_id: Optional[str],
    redirect_uri: str,
    code_challenge: str,
    scopes: list[str],
    resource: Optional[str],
    state: Optional[str],
) -> str:
    """Mint an auth code via storage and cache the PKCE/redirect context.

    Shared by HeronOAuthProvider.authorize() (DCR + manual with login_hint
    or bound identity) and the consent-page handler in http_app.py.
    """
    storage = get_storage_client()
    canonical_resource = resource or jwt_service.get_canonical_uri()
    code = await storage.create_auth_code(
        oauth_client_id=oauth_client_id,
        mcp_client_id=mcp_client_id,
        consumption_user_id=consumption_user_id,
        redirect_uri=redirect_uri,
        code_challenge=code_challenge,
        code_challenge_method="S256",
        scopes=scopes,
        resource=canonical_resource,
        state=state,
    )
    _pending_codes[code] = _PendingCode(
        mcp_client_id=mcp_client_id,
        consumption_user_id=consumption_user_id,
        client_id=oauth_client_id,
        code_challenge=code_challenge,
        redirect_uri=redirect_uri,
        scopes=scopes,
        resource=canonical_resource,
        expires_at=time.time() + 600,
    )
    return code


# ---------------------------------------------------------------------------
# Provider
# ---------------------------------------------------------------------------

class HeronOAuthProvider(
    OAuthAuthorizationServerProvider[AuthorizationCode, RefreshToken, AccessToken]
):
    """MCP-facing AS provider backed by the Heron Intelligence backend storage + JWT tokens."""

    # ------------------------------------------------------------------
    # Client registration / lookup
    # ------------------------------------------------------------------

    async def register_client(
        self, client_info: OAuthClientInformationFull
    ) -> None:
        """RFC 7591 Dynamic Client Registration.

        FastMCP fills `client_info.client_id` before calling us ONLY if we
        populate it. We delegate to the Heron Intelligence backend to mint a
        fresh DCR client_id + secret and mutate `client_info` in place.

        Backend errors are translated into a clean RegistrationError so the
        OAuth /register endpoint returns a spec-compliant JSON body instead
        of a 500 with a stack trace.
        """
        storage = get_storage_client()
        redirect_uris = [str(u) for u in (client_info.redirect_uris or [])]
        try:
            client_id, raw_secret = await storage.create_dcr_client(
                client_name=client_info.client_name,
                redirect_uris=redirect_uris,
                grant_types=list(
                    client_info.grant_types or ["authorization_code", "refresh_token"]
                ),
                token_endpoint_auth_method=client_info.token_endpoint_auth_method
                    or "client_secret_post",
            )
        except httpx.HTTPStatusError as exc:
            logger.exception(
                "DCR registration failed at storage backend: status=%s",
                exc.response.status_code,
            )
            raise RegistrationError(
                error="invalid_client_metadata",
                error_description=(
                    "Dynamic client registration is temporarily unavailable. "
                    "Please retry shortly or contact support."
                ),
            ) from exc
        except Exception as exc:
            logger.exception("DCR registration failed at storage backend")
            raise RegistrationError(
                error="invalid_client_metadata",
                error_description=(
                    "Dynamic client registration is temporarily unavailable. "
                    "Please retry shortly or contact support."
                ),
            ) from exc

        client_info.client_id = client_id
        client_info.client_secret = raw_secret
        client_info.client_id_issued_at = int(time.time())
        client_info.client_secret_expires_at = 0  # never expires

    async def get_client(self, client_id: str) -> Optional[_HeronClientInfo]:
        storage = get_storage_client()
        view = await storage.get_client(client_id)
        if not view:
            return None

        _client_view_by_id[client_id] = view

        return _HeronClientInfo.model_construct(
            client_id=view.client_id,
            client_secret=None,  # validated server-side via storage.verify_client_secret
            client_id_issued_at=None,
            client_secret_expires_at=None,
            redirect_uris=None,  # permissive validator in _HeronClientInfo
            grant_types=view.grant_types or ["authorization_code", "refresh_token"],
            response_types=["code"],
            token_endpoint_auth_method=view.token_endpoint_auth_method
                or "client_secret_post",
            client_name=view.client_name,
            scope="mcp:read mcp:write",  # all supported scopes — FastMCP validates requests against this
        )

    # ------------------------------------------------------------------
    # /authorize
    # ------------------------------------------------------------------

    async def authorize(
        self,
        client: OAuthClientInformationFull,
        params: AuthorizationParams,
    ) -> str:
        storage = get_storage_client()
        client_id = client.client_id or ""
        view = _client_view_by_id.get(client_id) or await storage.get_client(client_id)
        if not view:
            raise AuthorizeError(
                error="invalid_request",
                error_description=f"Unknown client_id: {client_id}",
            )

        # Branch on registration source
        mcp_client_id: Optional[str] = None
        consumption_user_id: Optional[str] = None

        if view.source == "manual":
            # Grouper B: client is bound 1:1 to a user. Ignore login_hint.
            mcp_client_id = view.mcp_client_id
            consumption_user_id = view.consumption_user_id
            if not mcp_client_id:
                raise AuthorizeError(
                    error="server_error",
                    error_description="Manual client missing mcp_client_id binding",
                )

        elif view.source == "dcr":
            # Grupo C: per-user identity via login_hint
            login_hint = get_login_hint()
            if not login_hint:
                raise AuthorizeError(
                    error="access_denied",
                    error_description="login_hint is required for DCR clients",
                )
            user_view = await storage.get_mcp_client_by_email(login_hint)
            if not user_view:
                raise AuthorizeError(
                    error="access_denied",
                    error_description=f"No active MCP user registered for email '{login_hint}'",
                )
            mcp_client_id = user_view.id
            consumption_user_id = user_view.consumption_user_id

        else:
            raise AuthorizeError(
                error="server_error",
                error_description=f"Unknown client source: {view.source}",
            )

        code = await issue_auth_code(
            oauth_client_id=client_id,
            mcp_client_id=mcp_client_id,
            consumption_user_id=consumption_user_id,
            redirect_uri=str(params.redirect_uri),
            code_challenge=params.code_challenge,
            scopes=params.scopes or [],
            resource=params.resource,
            state=params.state,
        )

        redirect = str(params.redirect_uri)
        sep = "&" if "?" in redirect else "?"
        redirect += f"{sep}code={code}"
        if params.state:
            redirect += f"&state={params.state}"
        return redirect

    # ------------------------------------------------------------------
    # /token — authorization_code grant
    # ------------------------------------------------------------------

    async def load_authorization_code(
        self,
        client: OAuthClientInformationFull,
        authorization_code: str,
    ) -> Optional[AuthorizationCode]:
        """Called by FastMCP before exchange — returns the real PKCE challenge
        so FastMCP can verify it against the presented code_verifier. The
        atomic DB consume is deferred to exchange_authorization_code().
        """
        pending = _pending_codes.get(authorization_code)
        if not pending:
            return None
        if time.time() > pending.expires_at:
            _pending_codes.pop(authorization_code, None)
            return None

        return AuthorizationCode(
            code=authorization_code,
            scopes=pending.scopes,
            expires_at=pending.expires_at,
            client_id=pending.client_id,
            code_challenge=pending.code_challenge,
            redirect_uri=AnyUrl(pending.redirect_uri),
            redirect_uri_provided_explicitly=True,
            resource=pending.resource,
        )

    async def exchange_authorization_code(
        self,
        client: OAuthClientInformationFull,
        authorization_code: AuthorizationCode,
    ) -> OAuthToken:
        storage = get_storage_client()
        # Atomic consume — returns the real row from DB.
        row = await storage.consume_auth_code(authorization_code.code)
        if not row:
            raise TokenError(
                error="invalid_grant",
                error_description="Authorization code is invalid, expired, or already used",
            )
        _pending_codes.pop(authorization_code.code, None)

        access_token, expires_in = jwt_service.encode_access_token(
            mcp_client_id=row.mcp_client_id,
            consumption_user_id=row.consumption_user_id,
            client_id=row.oauth_client_id,
            scopes=row.scopes,
        )

        refresh_token = await storage.create_refresh_token(
            oauth_client_id=row.oauth_client_id,
            mcp_client_id=row.mcp_client_id,
            consumption_user_id=row.consumption_user_id,
            resource=row.resource,
            scopes=row.scopes,
        )

        return OAuthToken(
            access_token=access_token,
            token_type="Bearer",
            expires_in=expires_in,
            refresh_token=refresh_token,
            scope=" ".join(row.scopes) if row.scopes else None,
        )

    # ------------------------------------------------------------------
    # /token — refresh_token grant
    # ------------------------------------------------------------------

    async def load_refresh_token(
        self,
        client: OAuthClientInformationFull,
        refresh_token: str,
    ) -> Optional[RefreshToken]:
        """FastMCP calls this for basic validation; actual rotation happens
        in exchange_refresh_token.

        We can't cheaply verify without calling storage, so we return a
        RefreshToken object with the raw token; exchange handles failures.
        """
        return RefreshToken(
            token=refresh_token,
            client_id=client.client_id or "",
            scopes=[],
            expires_at=None,
        )

    async def exchange_refresh_token(
        self,
        client: OAuthClientInformationFull,
        refresh_token: RefreshToken,
        scopes: list[str],
    ) -> OAuthToken:
        storage = get_storage_client()
        result = await storage.rotate_refresh_token(refresh_token.token)
        if not result:
            raise TokenError(
                error="invalid_grant",
                error_description="Refresh token is invalid, expired, or revoked",
            )

        new_scopes = scopes or result.scopes
        access_token, expires_in = jwt_service.encode_access_token(
            mcp_client_id=result.mcp_client_id,
            consumption_user_id=result.consumption_user_id,
            client_id=result.oauth_client_id,
            scopes=new_scopes,
        )
        return OAuthToken(
            access_token=access_token,
            token_type="Bearer",
            expires_in=expires_in,
            refresh_token=result.refresh_token,
            scope=" ".join(new_scopes) if new_scopes else None,
        )

    # ------------------------------------------------------------------
    # Access token validation (per-request)
    # ------------------------------------------------------------------

    async def load_access_token(self, token: str) -> Optional[AccessToken]:
        # Legacy mode: raw hk-* keys passed as Bearer by DualAuthMiddleware.
        if token.startswith("hk-"):
            _request_api_key.set(token)
            _request_user_id.set(None)
            _request_user_email.set(None)
            return AccessToken(
                token=token,
                client_id=f"legacy-{token}",
                scopes=[],
                expires_at=None,
            )

        claims = jwt_service.decode_access_token(token)
        if not claims:
            return None

        mcp_client_id = claims.get("mcp_client_id")
        user_id = claims.get("sub") or None
        client_id = claims.get("client_id") or ""
        scope = claims.get("scope", "")
        exp = claims.get("exp")

        if not mcp_client_id:
            return None

        # Resolve api_key via the Heron Intelligence backend (cached 300s)
        storage = get_storage_client()
        mcp_row = await storage.get_mcp_client_by_id(mcp_client_id)
        if not mcp_row or mcp_row.status != "active":
            return None

        _request_api_key.set(mcp_row.api_key)
        _request_user_id.set(user_id)
        _request_user_email.set(mcp_row.email)

        return AccessToken(
            token=token,
            client_id=client_id,
            scopes=scope.split() if scope else [],
            expires_at=exp,
        )

    # ------------------------------------------------------------------
    # /revoke
    # ------------------------------------------------------------------

    async def revoke_token(
        self,
        token: AccessToken | RefreshToken | None,
    ) -> None:
        if not token or not hasattr(token, "token"):
            return
        raw = token.token
        if raw.startswith("hk-"):
            return  # legacy tokens are not revocable through OAuth
        # Best-effort: treat as refresh token (access tokens are stateless JWTs).
        storage = get_storage_client()
        await storage.revoke_refresh_token(raw)


# ---------------------------------------------------------------------------
# Singleton
# ---------------------------------------------------------------------------

_provider: Optional[HeronOAuthProvider] = None


def get_oauth_provider() -> HeronOAuthProvider:
    global _provider
    if _provider is None:
        _provider = HeronOAuthProvider()
    return _provider
