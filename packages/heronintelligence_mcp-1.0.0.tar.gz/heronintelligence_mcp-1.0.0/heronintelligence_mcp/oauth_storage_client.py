"""HTTP wrapper over the Heron Intelligence backend's OAuth storage endpoints.

All durable OAuth state (DCR clients, auth codes, refresh tokens, MCP client
directory) lives on the backend. This module is the MCP's gateway to it.

Endpoints hit:
    POST   /api/v1/oauth/dcr-clients
    GET    /api/v1/oauth/clients/{client_id}
    POST   /api/v1/oauth/clients/{client_id}/verify-secret
    GET    /api/v1/oauth/mcp-clients/by-email?email=...
    GET    /api/v1/oauth/mcp-clients/{mcp_client_id}
    POST   /api/v1/oauth/auth-codes
    POST   /api/v1/oauth/auth-codes/consume
    POST   /api/v1/oauth/refresh-tokens
    POST   /api/v1/oauth/refresh-tokens/rotate
    POST   /api/v1/oauth/refresh-tokens/revoke
"""
from __future__ import annotations

import os
import time
from dataclasses import dataclass
from typing import Optional

import httpx

# Both values are required at request time. They are resolved lazily so stdio
# mode (which never reaches the OAuth storage backend) can still start without
# them.
_API_URL: str = os.environ.get("HERON_BASE_URL", "")
_SERVICE_KEY: str = os.environ.get("MCP_SERVICE_KEY", "")
_CLIENT_CACHE_TTL = 300  # seconds
_HTTP_TIMEOUT = 10.0


def _require_base_url() -> str:
    if not _API_URL:
        raise RuntimeError(
            "HERON_BASE_URL is not set. Configure it via the MCP server "
            "environment before starting the OAuth flow."
        )
    return _API_URL


def _require_service_key() -> str:
    if not _SERVICE_KEY:
        raise RuntimeError(
            "MCP_SERVICE_KEY is not set. Configure it via the MCP server "
            "environment before starting the OAuth flow."
        )
    return _SERVICE_KEY


def _headers() -> dict[str, str]:
    return {"X-Service-Key": _require_service_key(), "Content-Type": "application/json"}


# ---------------------------------------------------------------------------
# View dataclasses (mirror the backend response schemas)
# ---------------------------------------------------------------------------

@dataclass
class OAuthClientView:
    client_id: str
    source: str  # "dcr" or "manual"
    redirect_uris: list[str]
    client_name: Optional[str]
    token_endpoint_auth_method: str
    grant_types: list[str]
    status: str
    mcp_client_id: Optional[str]
    consumption_user_id: Optional[str]
    email: Optional[str]


@dataclass
class MCPClientView:
    id: str
    full_name: Optional[str]
    email: Optional[str]
    api_key: str
    status: str
    tier: str
    oauth_client_id: Optional[str]
    consumption_user_id: Optional[str]
    registration_source: str


@dataclass
class AuthCodeView:
    code: str
    oauth_client_id: str
    mcp_client_id: str
    consumption_user_id: Optional[str]
    redirect_uri: str
    code_challenge: str
    code_challenge_method: str
    scopes: list[str]
    resource: str
    state: Optional[str]


@dataclass
class RotateResult:
    refresh_token: str
    oauth_client_id: str
    mcp_client_id: str
    consumption_user_id: Optional[str]
    resource: str
    scopes: list[str]


# ---------------------------------------------------------------------------
# Client
# ---------------------------------------------------------------------------

class OAuthStorageClient:
    """HTTP wrapper with a tiny TTL cache for client lookups."""

    def __init__(self) -> None:
        # client_id → (view, cached_at)
        self._client_cache: dict[str, tuple[OAuthClientView, float]] = {}
        # mcp_client_id → (view, cached_at)
        self._mcp_client_cache: dict[str, tuple[MCPClientView, float]] = {}

    # ------------------------------------------------------------------
    # DCR
    # ------------------------------------------------------------------

    async def create_dcr_client(
        self,
        *,
        client_name: Optional[str],
        redirect_uris: list[str],
        grant_types: list[str],
        token_endpoint_auth_method: str,
    ) -> tuple[str, str]:
        """POST /dcr-clients — returns (client_id, raw_secret)."""
        async with httpx.AsyncClient(timeout=_HTTP_TIMEOUT) as http:
            resp = await http.post(
                f"{_require_base_url()}/api/v1/oauth/dcr-clients",
                headers=_headers(),
                json={
                    "client_name": client_name,
                    "redirect_uris": redirect_uris,
                    "grant_types": grant_types,
                    "token_endpoint_auth_method": token_endpoint_auth_method,
                },
            )
            resp.raise_for_status()
            data = resp.json()
            return data["client_id"], data["client_secret"]

    # ------------------------------------------------------------------
    # Client lookup
    # ------------------------------------------------------------------

    async def get_client(self, client_id: str) -> Optional[OAuthClientView]:
        """GET /clients/{id} with 300s TTL cache."""
        cached = self._client_cache.get(client_id)
        if cached and (time.time() - cached[1]) < _CLIENT_CACHE_TTL:
            return cached[0]

        async with httpx.AsyncClient(timeout=_HTTP_TIMEOUT) as http:
            try:
                resp = await http.get(
                    f"{_require_base_url()}/api/v1/oauth/clients/{client_id}",
                    headers=_headers(),
                )
            except httpx.HTTPError:
                return None

        if resp.status_code == 404:
            return None
        if resp.status_code != 200:
            return None

        d = resp.json()
        view = OAuthClientView(
            client_id=d["client_id"],
            source=d["source"],
            redirect_uris=d.get("redirect_uris") or [],
            client_name=d.get("client_name"),
            token_endpoint_auth_method=d.get("token_endpoint_auth_method", "client_secret_post"),
            grant_types=d.get("grant_types") or [],
            status=d.get("status", "active"),
            mcp_client_id=d.get("mcp_client_id"),
            consumption_user_id=d.get("consumption_user_id"),
            email=d.get("email"),
        )
        self._client_cache[client_id] = (view, time.time())
        return view

    def invalidate_client_cache(self, client_id: Optional[str] = None) -> None:
        if client_id:
            self._client_cache.pop(client_id, None)
        else:
            self._client_cache.clear()

    async def verify_client_secret(self, client_id: str, secret: str) -> bool:
        async with httpx.AsyncClient(timeout=_HTTP_TIMEOUT) as http:
            resp = await http.post(
                f"{_require_base_url()}/api/v1/oauth/clients/{client_id}/verify-secret",
                headers=_headers(),
                json={"client_secret": secret},
            )
            if resp.status_code != 200:
                return False
            return bool(resp.json().get("valid"))

    # ------------------------------------------------------------------
    # MCP clients directory
    # ------------------------------------------------------------------

    async def get_mcp_client_by_email(self, email: str) -> Optional[MCPClientView]:
        async with httpx.AsyncClient(timeout=_HTTP_TIMEOUT) as http:
            resp = await http.get(
                f"{_require_base_url()}/api/v1/oauth/mcp-clients/by-email",
                headers=_headers(),
                params={"email": email},
            )
        if resp.status_code == 404:
            return None
        if resp.status_code != 200:
            return None
        return self._parse_mcp_client(resp.json())

    async def get_mcp_client_by_id(self, mcp_client_id: str) -> Optional[MCPClientView]:
        cached = self._mcp_client_cache.get(mcp_client_id)
        if cached and (time.time() - cached[1]) < _CLIENT_CACHE_TTL:
            return cached[0]

        async with httpx.AsyncClient(timeout=_HTTP_TIMEOUT) as http:
            try:
                resp = await http.get(
                    f"{_require_base_url()}/api/v1/oauth/mcp-clients/{mcp_client_id}",
                    headers=_headers(),
                )
            except httpx.HTTPError:
                return None

        if resp.status_code != 200:
            return None
        view = self._parse_mcp_client(resp.json())
        self._mcp_client_cache[mcp_client_id] = (view, time.time())
        return view

    @staticmethod
    def _parse_mcp_client(d: dict) -> MCPClientView:
        return MCPClientView(
            id=d["id"],
            full_name=d.get("full_name"),
            email=d.get("email"),
            api_key=d["api_key"],
            status=d["status"],
            tier=d["tier"],
            oauth_client_id=d.get("oauth_client_id"),
            consumption_user_id=d.get("consumption_user_id"),
            registration_source=d["registration_source"],
        )

    # ------------------------------------------------------------------
    # Auth codes
    # ------------------------------------------------------------------

    async def create_auth_code(
        self,
        *,
        oauth_client_id: str,
        mcp_client_id: str,
        consumption_user_id: Optional[str],
        redirect_uri: str,
        code_challenge: str,
        code_challenge_method: str,
        scopes: list[str],
        resource: str,
        state: Optional[str],
        ttl_seconds: int = 600,
    ) -> str:
        async with httpx.AsyncClient(timeout=_HTTP_TIMEOUT) as http:
            resp = await http.post(
                f"{_require_base_url()}/api/v1/oauth/auth-codes",
                headers=_headers(),
                json={
                    "oauth_client_id": oauth_client_id,
                    "mcp_client_id": mcp_client_id,
                    "consumption_user_id": consumption_user_id,
                    "redirect_uri": redirect_uri,
                    "code_challenge": code_challenge,
                    "code_challenge_method": code_challenge_method,
                    "scopes": scopes,
                    "resource": resource,
                    "state": state,
                    "ttl_seconds": ttl_seconds,
                },
            )
            resp.raise_for_status()
            return resp.json()["code"]

    async def consume_auth_code(self, code: str) -> Optional[AuthCodeView]:
        async with httpx.AsyncClient(timeout=_HTTP_TIMEOUT) as http:
            resp = await http.post(
                f"{_require_base_url()}/api/v1/oauth/auth-codes/consume",
                headers=_headers(),
                json={"code": code},
            )
        if resp.status_code != 200:
            return None
        d = resp.json()
        return AuthCodeView(
            code=d["code"],
            oauth_client_id=d["oauth_client_id"],
            mcp_client_id=d["mcp_client_id"],
            consumption_user_id=d.get("consumption_user_id"),
            redirect_uri=d["redirect_uri"],
            code_challenge=d["code_challenge"],
            code_challenge_method=d["code_challenge_method"],
            scopes=d.get("scopes") or [],
            resource=d["resource"],
            state=d.get("state"),
        )

    # ------------------------------------------------------------------
    # Refresh tokens
    # ------------------------------------------------------------------

    async def create_refresh_token(
        self,
        *,
        oauth_client_id: str,
        mcp_client_id: str,
        consumption_user_id: Optional[str],
        resource: str,
        scopes: list[str],
        ttl_seconds: int = 2592000,
    ) -> str:
        async with httpx.AsyncClient(timeout=_HTTP_TIMEOUT) as http:
            resp = await http.post(
                f"{_require_base_url()}/api/v1/oauth/refresh-tokens",
                headers=_headers(),
                json={
                    "oauth_client_id": oauth_client_id,
                    "mcp_client_id": mcp_client_id,
                    "consumption_user_id": consumption_user_id,
                    "resource": resource,
                    "scopes": scopes,
                    "ttl_seconds": ttl_seconds,
                },
            )
            resp.raise_for_status()
            return resp.json()["refresh_token"]

    async def rotate_refresh_token(
        self, refresh_token: str, *, ttl_seconds: int = 2592000
    ) -> Optional[RotateResult]:
        async with httpx.AsyncClient(timeout=_HTTP_TIMEOUT) as http:
            resp = await http.post(
                f"{_require_base_url()}/api/v1/oauth/refresh-tokens/rotate",
                headers=_headers(),
                json={"refresh_token": refresh_token, "ttl_seconds": ttl_seconds},
            )
        if resp.status_code != 200:
            return None
        d = resp.json()
        return RotateResult(
            refresh_token=d["refresh_token"],
            oauth_client_id=d["oauth_client_id"],
            mcp_client_id=d["mcp_client_id"],
            consumption_user_id=d.get("consumption_user_id"),
            resource=d["resource"],
            scopes=d.get("scopes") or [],
        )

    async def revoke_refresh_token(self, refresh_token: str) -> None:
        async with httpx.AsyncClient(timeout=_HTTP_TIMEOUT) as http:
            try:
                await http.post(
                    f"{_require_base_url()}/api/v1/oauth/refresh-tokens/revoke",
                    headers=_headers(),
                    json={"refresh_token": refresh_token},
                )
            except httpx.HTTPError:
                pass  # best-effort


_client: Optional[OAuthStorageClient] = None


def get_storage_client() -> OAuthStorageClient:
    global _client
    if _client is None:
        _client = OAuthStorageClient()
    return _client
