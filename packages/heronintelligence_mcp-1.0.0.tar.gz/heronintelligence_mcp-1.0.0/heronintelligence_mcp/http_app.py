"""HTTP transport wrapper for the Heron Intelligence MCP server.

Supports OAuth 2.1 (with PKCE + DCR) over Streamable HTTP. A backwards-
compatible URL-path API key form is also accepted.

Discovery endpoints exposed:
    GET /.well-known/oauth-protected-resource
    GET /.well-known/oauth-authorization-server
    GET /health
"""
from __future__ import annotations

import os

from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import JSONResponse
from starlette.routing import Route

from heronintelligence_mcp._context import _request_api_key
from heronintelligence_mcp.consent_page import (
    handle_consent_submit,
    render_consent_form,
)
from heronintelligence_mcp.oauth_provider import set_login_hint
from heronintelligence_mcp.server import mcp

_MCP_CANONICAL_URI = os.environ.get(
    "MCP_CANONICAL_URI", "https://mcp.heron-intelligence.com"
)

_NO_AUTH_PREFIXES = (
    "/.well-known/",
    "/authorize",
    "/token",
    "/register",
    "/revoke",
    "/health",
)

_DEFAULT_ALLOWED_ORIGINS = (
    "https://claude.ai",
    "https://app.claude.ai",
    "https://api.claude.ai",
    _MCP_CANONICAL_URI,
)
_ALLOWED_ORIGINS = frozenset(
    o.strip()
    for o in os.environ.get(
        "MCP_ALLOWED_ORIGINS", ",".join(_DEFAULT_ALLOWED_ORIGINS)
    ).split(",")
    if o.strip()
)

_WWW_AUTH_CHALLENGE = (
    f'Bearer resource_metadata="{_MCP_CANONICAL_URI}/.well-known/oauth-protected-resource"'
)


class DualAuthMiddleware(BaseHTTPMiddleware):
    """Routes incoming requests through the supported auth modes."""

    async def dispatch(self, request: Request, call_next):
        path = request.url.path
        method = request.method

        origin = request.headers.get("Origin", "")
        if origin and origin not in _ALLOWED_ORIGINS:
            return JSONResponse(
                status_code=403,
                content={"error": f"Origin '{origin}' is not allowed."},
            )

        if path == "/authorize/consent" and method == "POST":
            return await handle_consent_submit(request)

        if any(path.startswith(p) for p in _NO_AUTH_PREFIXES):
            if path.startswith("/authorize"):
                hint = request.query_params.get("login_hint")
                if hint:
                    set_login_hint(hint)
                elif method == "GET":
                    consent = await render_consent_form(request)
                    if consent is not None:
                        return consent
            return await call_next(request)

        auth_header = request.headers.get("Authorization", "")
        if auth_header.startswith("Bearer "):
            return await call_next(request)

        parts = path.lstrip("/").split("/", 1)
        if len(parts) == 2 and parts[1].startswith("mcp"):
            api_key = parts[0]
            if api_key:
                request.scope["path"] = "/" + parts[1]
                raw_headers = [
                    (k, v)
                    for k, v in request.scope["headers"]
                    if k.lower() != b"authorization"
                ]
                raw_headers.append(
                    (b"authorization", f"Bearer {api_key}".encode())
                )
                request.scope["headers"] = raw_headers
                ctx_token = _request_api_key.set(api_key)
                try:
                    return await call_next(request)
                finally:
                    _request_api_key.reset(ctx_token)

        return JSONResponse(
            status_code=401,
            content={"error": "Authentication required."},
            headers={"WWW-Authenticate": _WWW_AUTH_CHALLENGE},
        )


async def health(_request: Request) -> JSONResponse:
    return JSONResponse({"status": "ok", "service": "heronintelligence-mcp"})


def create_app():
    starlette_app = mcp.streamable_http_app()
    starlette_app.router.routes.insert(
        0, Route("/health", health, methods=["GET"])
    )
    starlette_app.add_middleware(DualAuthMiddleware)
    return starlette_app
