import os
from heronintelligence_mcp.server import mcp


def main() -> None:
    transport = os.environ.get("MCP_TRANSPORT", "stdio").lower()
    if transport == "http":
        import uvicorn
        uvicorn.run(
            "heronintelligence_mcp.http_app:create_app",
            factory=True,
            host="0.0.0.0",
            port=int(os.environ.get("PORT", "8080")),
            workers=int(os.environ.get("WORKERS", "2")),
            log_level="info",
            timeout_keep_alive=300,
            proxy_headers=True,
            forwarded_allow_ips="*",
        )
    else:
        mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
