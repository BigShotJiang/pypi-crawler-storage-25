"""Heron Intelligence MCP — Financial research layer for AI assistants."""
__version__ = "1.0.0"
