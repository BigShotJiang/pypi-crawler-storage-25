from __future__ import annotations

import contextvars
from typing import Optional


_request_api_key: contextvars.ContextVar[str] = contextvars.ContextVar(
    "heron_request_api_key", default=""
)
_request_user_id: contextvars.ContextVar[Optional[str]] = contextvars.ContextVar(
    "heron_request_user_id", default=None
)
_request_user_email: contextvars.ContextVar[Optional[str]] = contextvars.ContextVar(
    "heron_request_user_email", default=None
)
