"""Tests for heronintelligence_mcp.jwt_service

Verifies HS256 encode/decode roundtrip, claim shape, and expiry/audience/issuer
rejection.
"""
from __future__ import annotations

import importlib
import time

import pytest


@pytest.fixture(autouse=True)
def _set_env(monkeypatch):
    monkeypatch.setenv("OAUTH_JWT_SECRET", "test-secret-with-enough-entropy-abc123")
    monkeypatch.setenv("OAUTH_JWT_ISSUER", "https://mcp.test")
    monkeypatch.setenv("MCP_CANONICAL_URI", "https://mcp.test")
    monkeypatch.setenv("OAUTH_ACCESS_TOKEN_TTL", "60")
    # Force module re-import so env vars take effect.
    import heronintelligence_mcp.jwt_service as js
    importlib.reload(js)


def _jwt_service():
    import heronintelligence_mcp.jwt_service as js
    return js


def test_encode_decode_roundtrip():
    js = _jwt_service()
    token, ttl = js.encode_access_token(
        mcp_client_id="mcp-1",
        consumption_user_id="user-abc",
        client_id="hc-xyz",
        scopes=["mcp:read", "mcp:write"],
    )
    assert ttl == 60
    claims = js.decode_access_token(token)
    assert claims is not None
    assert claims["sub"] == "user-abc"
    assert claims["mcp_client_id"] == "mcp-1"
    assert claims["client_id"] == "hc-xyz"
    assert claims["aud"] == "https://mcp.test"
    assert claims["iss"] == "https://mcp.test"
    assert claims["scope"] == "mcp:read mcp:write"
    assert claims["exp"] > claims["iat"]


def test_decode_rejects_tampered_signature():
    js = _jwt_service()
    token, _ = js.encode_access_token(
        mcp_client_id="mcp-1",
        consumption_user_id=None,
        client_id="hc-xyz",
        scopes=[],
    )
    # Corrupt the signature segment
    parts = token.split(".")
    parts[2] = "AAAA" + parts[2][4:]
    bad = ".".join(parts)
    assert js.decode_access_token(bad) is None


def test_decode_rejects_expired(monkeypatch):
    js = _jwt_service()
    token, _ = js.encode_access_token(
        mcp_client_id="mcp-1",
        consumption_user_id=None,
        client_id="hc-xyz",
        scopes=[],
        ttl_seconds=1,
    )
    time.sleep(1.5)
    assert js.decode_access_token(token) is None


def test_decode_rejects_wrong_audience(monkeypatch):
    js = _jwt_service()
    token, _ = js.encode_access_token(
        mcp_client_id="mcp-1",
        consumption_user_id=None,
        client_id="hc-xyz",
        scopes=[],
    )
    # Reload with a different expected audience
    monkeypatch.setenv("MCP_CANONICAL_URI", "https://different.audience")
    importlib.reload(js)
    assert js.decode_access_token(token) is None


def test_consumption_user_id_empty_string_when_none():
    js = _jwt_service()
    token, _ = js.encode_access_token(
        mcp_client_id="mcp-1",
        consumption_user_id=None,
        client_id="hc-xyz",
        scopes=["mcp:read"],
    )
    claims = js.decode_access_token(token)
    assert claims["sub"] == ""
