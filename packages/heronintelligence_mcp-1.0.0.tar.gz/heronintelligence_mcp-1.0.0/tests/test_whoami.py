"""Tests for the whoami MCP tool.

The tool reads _request_user_email, which the OAuth provider populates on
every JWT-authenticated request. We verify both the happy path and the
legacy-fallback path (api_key-only sessions).
"""
from __future__ import annotations

import json

import pytest


@pytest.fixture(autouse=True)
def _set_env(monkeypatch):
    # Required by server.py import chain.
    monkeypatch.setenv("OAUTH_JWT_SECRET", "test-secret-with-enough-entropy-abc123")
    monkeypatch.setenv("OAUTH_JWT_ISSUER", "https://mcp.test")
    monkeypatch.setenv("MCP_CANONICAL_URI", "https://mcp.test")
    monkeypatch.setenv("HERON_API_KEY", "hk-fallback")
    # Don't reload _context: server.py and oauth_provider both hold references
    # to the module-level ContextVars. Reloading would split the identity.


@pytest.fixture
def anyio_backend():
    return "asyncio"


@pytest.mark.anyio
async def test_whoami_returns_email_from_context(monkeypatch):
    import heronintelligence_mcp._context as ctx
    ctx._request_user_email.set("user@example.com")
    # Import after ContextVar is set so the tool uses the live module.
    import heronintelligence_mcp.server as srv
    result = await srv.whoami()
    assert json.loads(result) == {"email": "user@example.com"}


@pytest.mark.anyio
async def test_whoami_returns_null_for_legacy_sessions(monkeypatch):
    import heronintelligence_mcp._context as ctx
    ctx._request_user_email.set(None)
    import heronintelligence_mcp.server as srv
    result = await srv.whoami()
    assert json.loads(result) == {"email": None}
