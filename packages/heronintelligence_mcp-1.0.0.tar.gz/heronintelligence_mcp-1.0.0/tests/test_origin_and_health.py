"""Tests for the public /health endpoint and Origin-header validation.

/health gives orchestrators and reviewers a low-cost liveness probe, and the
Origin validation guards against DNS-rebinding / cross-origin attacks.
"""
from __future__ import annotations

import importlib

import pytest


@pytest.fixture(autouse=True)
def _set_env(monkeypatch):
    monkeypatch.setenv("OAUTH_JWT_SECRET", "test-secret-with-enough-entropy-abc123")
    monkeypatch.setenv("OAUTH_JWT_ISSUER", "https://mcp.heron-intelligence.com")
    monkeypatch.setenv("MCP_CANONICAL_URI", "https://mcp.heron-intelligence.com")
    import heronintelligence_mcp.jwt_service as js
    importlib.reload(js)
    import heronintelligence_mcp.oauth_provider as op
    importlib.reload(op)
    import heronintelligence_mcp.server as srv
    importlib.reload(srv)
    import heronintelligence_mcp.http_app as http_app
    importlib.reload(http_app)


def _client():
    from starlette.testclient import TestClient
    from heronintelligence_mcp.http_app import create_app
    return TestClient(create_app())


# ---------------------------------------------------------------------------
# /health
# ---------------------------------------------------------------------------

def test_health_returns_200_without_auth():
    resp = _client().get("/health")
    assert resp.status_code == 200
    body = resp.json()
    assert body["status"] == "ok"
    assert body["service"] == "heronintelligence-mcp"


def test_health_does_not_set_www_authenticate():
    resp = _client().get("/health")
    assert "WWW-Authenticate" not in resp.headers


# ---------------------------------------------------------------------------
# Origin validation
# ---------------------------------------------------------------------------

def test_request_without_origin_passes_through():
    """Server-to-server clients (e.g. the Claude.ai MCP runtime) typically omit
    Origin. Those requests should not be blocked by the Origin guard.
    """
    resp = _client().get("/health")
    assert resp.status_code == 200


def test_request_with_allowed_origin_passes():
    resp = _client().get("/health", headers={"Origin": "https://claude.ai"})
    assert resp.status_code == 200


def test_request_with_disallowed_origin_returns_403():
    resp = _client().get("/health", headers={"Origin": "https://evil.example"})
    assert resp.status_code == 403
    body = resp.json()
    assert "evil.example" in body["error"]


def test_disallowed_origin_blocks_mcp_endpoint_too():
    """Origin check must run before auth so it cannot be bypassed by sending a
    forged Authorization header from a hostile origin.
    """
    resp = _client().post(
        "/mcp",
        json={},
        headers={"Origin": "https://evil.example", "Authorization": "Bearer foo"},
    )
    assert resp.status_code == 403


def test_canonical_mcp_uri_is_in_default_allowlist():
    resp = _client().get(
        "/health", headers={"Origin": "https://mcp.heron-intelligence.com"}
    )
    assert resp.status_code == 200


def test_custom_allowed_origins_via_env(monkeypatch):
    monkeypatch.setenv(
        "MCP_ALLOWED_ORIGINS",
        "https://custom.example,https://other.example",
    )
    import heronintelligence_mcp.http_app as http_app
    importlib.reload(http_app)

    from starlette.testclient import TestClient
    client = TestClient(http_app.create_app())

    assert client.get(
        "/health", headers={"Origin": "https://custom.example"}
    ).status_code == 200
    assert client.get(
        "/health", headers={"Origin": "https://claude.ai"}
    ).status_code == 403
