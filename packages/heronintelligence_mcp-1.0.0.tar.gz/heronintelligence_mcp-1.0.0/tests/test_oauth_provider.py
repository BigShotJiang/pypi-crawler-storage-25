"""Tests for heronintelligence_mcp.oauth_provider

Mocks OAuthStorageClient so nothing hits the network. Covers:
  - DCR register_client
  - authorize() manual path (Grupo B: no login_hint)
  - authorize() DCR path (Grupo C: login_hint required)
  - load_authorization_code returns real PKCE challenge
  - exchange_authorization_code issues JWT + refresh
  - load_access_token validates JWTs and legacy hk-*
"""
from __future__ import annotations

import importlib
import uuid
from unittest.mock import AsyncMock, MagicMock

import pytest
from mcp.server.auth.provider import AuthorizationParams, AuthorizeError, TokenError
from mcp.shared.auth import OAuthClientInformationFull
from pydantic import AnyUrl


@pytest.fixture(autouse=True)
def _set_env(monkeypatch):
    monkeypatch.setenv("OAUTH_JWT_SECRET", "test-secret-with-enough-entropy-abc123")
    monkeypatch.setenv("OAUTH_JWT_ISSUER", "https://mcp.test")
    monkeypatch.setenv("MCP_CANONICAL_URI", "https://mcp.test")
    monkeypatch.setenv("OAUTH_ACCESS_TOKEN_TTL", "60")
    import heronintelligence_mcp.jwt_service as js
    importlib.reload(js)
    import heronintelligence_mcp.oauth_provider as op
    importlib.reload(op)


@pytest.fixture
def anyio_backend():
    return "asyncio"


def _provider_and_storage(monkeypatch):
    import heronintelligence_mcp.oauth_provider as op
    provider = op.HeronOAuthProvider()
    storage = MagicMock()
    monkeypatch.setattr(op, "get_storage_client", lambda: storage)
    # Reset module-level caches so tests don't leak
    op._client_view_by_id.clear()
    op._pending_codes.clear()
    op.set_login_hint(None)
    return provider, storage, op


def _client_view(source="dcr", **overrides):
    from heronintelligence_mcp.oauth_storage_client import OAuthClientView
    base = dict(
        client_id="hc-1",
        source=source,
        redirect_uris=["https://claude.ai/cb"],
        client_name="test",
        token_endpoint_auth_method="client_secret_post",
        grant_types=["authorization_code", "refresh_token"],
        status="active",
        mcp_client_id=None,
        consumption_user_id=None,
        email=None,
    )
    base.update(overrides)
    return OAuthClientView(**base)


def _mcp_user_view(**overrides):
    from heronintelligence_mcp.oauth_storage_client import MCPClientView
    base = dict(
        id=str(uuid.uuid4()),
        full_name="User",
        email="u@org.com",
        api_key="hk-abc",
        status="active",
        tier="starter",
        oauth_client_id=None,
        consumption_user_id=str(uuid.uuid4()),
        registration_source="manual",
    )
    base.update(overrides)
    return MCPClientView(**base)


# ---------------------------------------------------------------------------
# DCR
# ---------------------------------------------------------------------------

@pytest.mark.anyio
async def test_register_client_calls_storage_and_populates_secret(monkeypatch):
    provider, storage, op = _provider_and_storage(monkeypatch)
    storage.create_dcr_client = AsyncMock(return_value=("hc-new", "cs-new"))

    info = OAuthClientInformationFull.model_construct(
        redirect_uris=[AnyUrl("https://claude.ai/cb")],
        client_name="my-org",
        grant_types=["authorization_code", "refresh_token"],
        response_types=["code"],
        token_endpoint_auth_method="client_secret_post",
    )
    await provider.register_client(info)
    assert info.client_id == "hc-new"
    assert info.client_secret == "cs-new"


# ---------------------------------------------------------------------------
# Authorize — Manual path (Grupo B)
# ---------------------------------------------------------------------------

@pytest.mark.anyio
async def test_authorize_manual_auto_approves_without_login_hint(monkeypatch):
    provider, storage, op = _provider_and_storage(monkeypatch)
    view = _client_view(
        source="manual",
        mcp_client_id="mcp-1",
        consumption_user_id="user-1",
        email="existing@personal.com",
    )
    storage.get_client = AsyncMock(return_value=view)
    storage.create_auth_code = AsyncMock(return_value="code-abc")
    # login_hint NOT set — manual path ignores it
    op.set_login_hint(None)

    params = AuthorizationParams(
        state="s1",
        scopes=["mcp:read"],
        code_challenge="ch-xyz",
        redirect_uri=AnyUrl("https://claude.ai/cb"),
        redirect_uri_provided_explicitly=True,
        resource="https://mcp.test",
    )
    client = OAuthClientInformationFull.model_construct(
        client_id="hc-manual",
        redirect_uris=[AnyUrl("https://claude.ai/cb")],
    )

    redirect = await provider.authorize(client, params)
    assert "code=code-abc" in redirect
    assert "state=s1" in redirect
    storage.create_auth_code.assert_awaited_once()
    # Assert bound user was used
    kwargs = storage.create_auth_code.await_args.kwargs
    assert kwargs["mcp_client_id"] == "mcp-1"
    assert kwargs["consumption_user_id"] == "user-1"


@pytest.mark.anyio
async def test_authorize_manual_errors_if_no_binding(monkeypatch):
    provider, storage, op = _provider_and_storage(monkeypatch)
    view = _client_view(source="manual", mcp_client_id=None)
    storage.get_client = AsyncMock(return_value=view)

    params = AuthorizationParams(
        state=None, scopes=[], code_challenge="ch",
        redirect_uri=AnyUrl("https://claude.ai/cb"),
        redirect_uri_provided_explicitly=True,
        resource="https://mcp.test",
    )
    client = OAuthClientInformationFull.model_construct(client_id="hc-1")
    with pytest.raises(AuthorizeError):
        await provider.authorize(client, params)


# ---------------------------------------------------------------------------
# Authorize — DCR path (Grupo C)
# ---------------------------------------------------------------------------

@pytest.mark.anyio
async def test_authorize_dcr_requires_login_hint(monkeypatch):
    provider, storage, op = _provider_and_storage(monkeypatch)
    storage.get_client = AsyncMock(return_value=_client_view(source="dcr"))
    op.set_login_hint(None)

    params = AuthorizationParams(
        state=None, scopes=[], code_challenge="ch",
        redirect_uri=AnyUrl("https://claude.ai/cb"),
        redirect_uri_provided_explicitly=True,
        resource="https://mcp.test",
    )
    client = OAuthClientInformationFull.model_construct(client_id="hc-dcr")
    with pytest.raises(AuthorizeError) as exc:
        await provider.authorize(client, params)
    assert exc.value.error == "access_denied"


@pytest.mark.anyio
async def test_authorize_dcr_resolves_user_from_email(monkeypatch):
    provider, storage, op = _provider_and_storage(monkeypatch)
    user = _mcp_user_view(email="seat@org.com")
    storage.get_client = AsyncMock(return_value=_client_view(source="dcr"))
    storage.get_mcp_client_by_email = AsyncMock(return_value=user)
    storage.create_auth_code = AsyncMock(return_value="code-dcr")
    op.set_login_hint("seat@org.com")

    params = AuthorizationParams(
        state="s", scopes=["mcp:read"], code_challenge="ch",
        redirect_uri=AnyUrl("https://claude.ai/cb"),
        redirect_uri_provided_explicitly=True,
        resource="https://mcp.test",
    )
    client = OAuthClientInformationFull.model_construct(client_id="hc-dcr")
    redirect = await provider.authorize(client, params)
    assert "code=code-dcr" in redirect
    kwargs = storage.create_auth_code.await_args.kwargs
    assert kwargs["mcp_client_id"] == user.id
    assert kwargs["consumption_user_id"] == user.consumption_user_id


@pytest.mark.anyio
async def test_authorize_dcr_denies_unknown_email(monkeypatch):
    provider, storage, op = _provider_and_storage(monkeypatch)
    storage.get_client = AsyncMock(return_value=_client_view(source="dcr"))
    storage.get_mcp_client_by_email = AsyncMock(return_value=None)
    op.set_login_hint("unknown@org.com")

    params = AuthorizationParams(
        state=None, scopes=[], code_challenge="ch",
        redirect_uri=AnyUrl("https://claude.ai/cb"),
        redirect_uri_provided_explicitly=True,
        resource="https://mcp.test",
    )
    client = OAuthClientInformationFull.model_construct(client_id="hc-dcr")
    with pytest.raises(AuthorizeError) as exc:
        await provider.authorize(client, params)
    assert exc.value.error == "access_denied"


# ---------------------------------------------------------------------------
# load_authorization_code — returns real PKCE challenge
# ---------------------------------------------------------------------------

@pytest.mark.anyio
async def test_load_authorization_code_returns_real_challenge(monkeypatch):
    provider, storage, op = _provider_and_storage(monkeypatch)
    view = _client_view(source="manual", mcp_client_id="mcp-1",
                        consumption_user_id="u-1")
    storage.get_client = AsyncMock(return_value=view)
    storage.create_auth_code = AsyncMock(return_value="code-xyz")

    params = AuthorizationParams(
        state=None, scopes=[], code_challenge="REAL-CHALLENGE",
        redirect_uri=AnyUrl("https://claude.ai/cb"),
        redirect_uri_provided_explicitly=True,
        resource="https://mcp.test",
    )
    client = OAuthClientInformationFull.model_construct(client_id="hc-m")
    await provider.authorize(client, params)

    # Now load the code
    auth_code = await provider.load_authorization_code(client, "code-xyz")
    assert auth_code is not None
    assert auth_code.code_challenge == "REAL-CHALLENGE"


@pytest.mark.anyio
async def test_load_authorization_code_returns_none_when_unknown(monkeypatch):
    provider, storage, op = _provider_and_storage(monkeypatch)
    client = OAuthClientInformationFull.model_construct(client_id="hc-m")
    assert await provider.load_authorization_code(client, "unknown") is None


# ---------------------------------------------------------------------------
# exchange_authorization_code
# ---------------------------------------------------------------------------

@pytest.mark.anyio
async def test_exchange_authorization_code_issues_jwt_and_refresh(monkeypatch):
    provider, storage, op = _provider_and_storage(monkeypatch)

    from heronintelligence_mcp.oauth_storage_client import AuthCodeView
    row = AuthCodeView(
        code="code-xyz",
        oauth_client_id="hc-1",
        mcp_client_id="mcp-1",
        consumption_user_id="user-1",
        redirect_uri="https://claude.ai/cb",
        code_challenge="ch",
        code_challenge_method="S256",
        scopes=["mcp:read"],
        resource="https://mcp.test",
        state=None,
    )
    storage.consume_auth_code = AsyncMock(return_value=row)
    storage.create_refresh_token = AsyncMock(return_value="rt-raw")

    from mcp.server.auth.provider import AuthorizationCode
    ac = AuthorizationCode(
        code="code-xyz",
        scopes=["mcp:read"],
        expires_at=9_999_999_999,
        client_id="hc-1",
        code_challenge="ch",
        redirect_uri=AnyUrl("https://claude.ai/cb"),
        redirect_uri_provided_explicitly=True,
        resource="https://mcp.test",
    )
    client = OAuthClientInformationFull.model_construct(client_id="hc-1")
    token_resp = await provider.exchange_authorization_code(client, ac)
    assert token_resp.token_type == "Bearer"
    assert token_resp.refresh_token == "rt-raw"
    assert token_resp.expires_in > 0
    # The access token is a JWT — decode it
    import heronintelligence_mcp.jwt_service as js
    claims = js.decode_access_token(token_resp.access_token)
    assert claims is not None
    assert claims["sub"] == "user-1"
    assert claims["mcp_client_id"] == "mcp-1"


@pytest.mark.anyio
async def test_exchange_authorization_code_fails_when_consumed(monkeypatch):
    provider, storage, op = _provider_and_storage(monkeypatch)
    storage.consume_auth_code = AsyncMock(return_value=None)

    from mcp.server.auth.provider import AuthorizationCode
    ac = AuthorizationCode(
        code="used",
        scopes=[],
        expires_at=9_999_999_999,
        client_id="hc-1",
        code_challenge="ch",
        redirect_uri=AnyUrl("https://claude.ai/cb"),
        redirect_uri_provided_explicitly=True,
        resource="https://mcp.test",
    )
    client = OAuthClientInformationFull.model_construct(client_id="hc-1")
    with pytest.raises(TokenError):
        await provider.exchange_authorization_code(client, ac)


# ---------------------------------------------------------------------------
# load_access_token
# ---------------------------------------------------------------------------

@pytest.mark.anyio
async def test_load_access_token_hk_legacy_bypasses_jwt(monkeypatch):
    from heronintelligence_mcp._context import _request_api_key, _request_user_id
    provider, storage, op = _provider_and_storage(monkeypatch)
    at = await provider.load_access_token("hk-abc123")
    assert at is not None
    assert at.token == "hk-abc123"
    assert _request_api_key.get() == "hk-abc123"
    assert _request_user_id.get() is None


@pytest.mark.anyio
async def test_load_access_token_jwt_sets_both_context_vars(monkeypatch):
    from heronintelligence_mcp._context import (
        _request_api_key,
        _request_user_email,
        _request_user_id,
    )
    import heronintelligence_mcp.jwt_service as js
    provider, storage, op = _provider_and_storage(monkeypatch)

    token, _ = js.encode_access_token(
        mcp_client_id="mcp-1",
        consumption_user_id="user-1",
        client_id="hc-1",
        scopes=["mcp:read"],
    )
    user = _mcp_user_view(id="mcp-1", consumption_user_id="user-1", email="u@org.com")
    storage.get_mcp_client_by_id = AsyncMock(return_value=user)

    at = await provider.load_access_token(token)
    assert at is not None
    assert at.client_id == "hc-1"
    assert _request_api_key.get() == user.api_key
    assert _request_user_id.get() == "user-1"
    assert _request_user_email.get() == "u@org.com"


@pytest.mark.anyio
async def test_load_access_token_rejects_invalid_jwt(monkeypatch):
    provider, _, _ = _provider_and_storage(monkeypatch)
    assert await provider.load_access_token("not-a-jwt") is None


@pytest.mark.anyio
async def test_load_access_token_rejects_inactive_mcp_client(monkeypatch):
    import heronintelligence_mcp.jwt_service as js
    provider, storage, op = _provider_and_storage(monkeypatch)
    token, _ = js.encode_access_token(
        mcp_client_id="mcp-1",
        consumption_user_id=None,
        client_id="hc-1",
        scopes=[],
    )
    inactive = _mcp_user_view(id="mcp-1", status="inactive")
    storage.get_mcp_client_by_id = AsyncMock(return_value=inactive)
    assert await provider.load_access_token(token) is None
