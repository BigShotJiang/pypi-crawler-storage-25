"""Tests for heronintelligence_mcp.consent_page

All storage/network calls are mocked. Focus:
  - render_consent_form: only fires for DCR clients
  - handle_consent_submit: validates creds, mints code, redirects
"""
from __future__ import annotations

import importlib
from unittest.mock import AsyncMock, MagicMock

import pytest
from starlette.requests import Request


@pytest.fixture(autouse=True)
def _set_env(monkeypatch):
    monkeypatch.setenv("OAUTH_JWT_SECRET", "test-secret-with-enough-entropy-abc123")
    monkeypatch.setenv("OAUTH_JWT_ISSUER", "https://mcp.test")
    monkeypatch.setenv("MCP_CANONICAL_URI", "https://mcp.test")
    import heronintelligence_mcp.jwt_service as js
    importlib.reload(js)
    import heronintelligence_mcp.oauth_provider as op
    importlib.reload(op)
    import heronintelligence_mcp.consent_page as cp
    importlib.reload(cp)


@pytest.fixture
def anyio_backend():
    return "asyncio"


def _client_view(source, **overrides):
    from heronintelligence_mcp.oauth_storage_client import OAuthClientView
    base = dict(
        client_id="hc-dcr",
        source=source,
        redirect_uris=["https://claude.ai/api/mcp/auth_callback"],
        client_name="test",
        token_endpoint_auth_method="client_secret_post",
        grant_types=["authorization_code", "refresh_token"],
        status="active",
        mcp_client_id=None,
        consumption_user_id=None,
        email=None,
    )
    base.update(overrides)
    return OAuthClientView(**base)


def _make_get_request(query: dict) -> Request:
    qs = "&".join(f"{k}={v}" for k, v in query.items()).encode()
    scope = {
        "type": "http",
        "method": "GET",
        "path": "/authorize",
        "query_string": qs,
        "headers": [],
    }
    return Request(scope)


def _make_post_request(form: dict) -> Request:
    """Build a Request with an in-memory form body."""
    from urllib.parse import urlencode
    body_bytes = urlencode(form).encode()
    scope = {
        "type": "http",
        "method": "POST",
        "path": "/authorize/consent",
        "query_string": b"",
        "headers": [
            (b"content-type", b"application/x-www-form-urlencoded"),
            (b"content-length", str(len(body_bytes)).encode()),
        ],
    }
    sent = {"done": False}

    async def receive():
        if sent["done"]:
            return {"type": "http.disconnect"}
        sent["done"] = True
        return {"type": "http.request", "body": body_bytes, "more_body": False}

    return Request(scope, receive)


# ---------------------------------------------------------------------------
# render_consent_form
# ---------------------------------------------------------------------------

@pytest.mark.anyio
async def test_render_consent_form_dcr_returns_html(monkeypatch):
    import heronintelligence_mcp.consent_page as cp
    storage = MagicMock()
    storage.get_client = AsyncMock(return_value=_client_view("dcr"))
    monkeypatch.setattr(cp, "get_storage_client", lambda: storage)

    req = _make_get_request({
        "client_id": "hc-dcr",
        "response_type": "code",
        "redirect_uri": "https://claude.ai/api/mcp/auth_callback",
        "code_challenge": "abc",
        "state": "xyz",
    })
    resp = await cp.render_consent_form(req)
    assert resp is not None
    assert resp.status_code == 200
    body = resp.body.decode()
    assert "Connect to Heron Intelligence" in body
    # hidden fields preserve the original OAuth params
    assert 'name="client_id" value="hc-dcr"' in body
    assert 'name="state" value="xyz"' in body


@pytest.mark.anyio
async def test_render_consent_form_manual_returns_none(monkeypatch):
    """Manual clients auto-approve, no consent page."""
    import heronintelligence_mcp.consent_page as cp
    storage = MagicMock()
    storage.get_client = AsyncMock(return_value=_client_view("manual"))
    monkeypatch.setattr(cp, "get_storage_client", lambda: storage)

    req = _make_get_request({"client_id": "hc-manual"})
    resp = await cp.render_consent_form(req)
    assert resp is None


@pytest.mark.anyio
async def test_render_consent_form_unknown_client_returns_none(monkeypatch):
    import heronintelligence_mcp.consent_page as cp
    storage = MagicMock()
    storage.get_client = AsyncMock(return_value=None)
    monkeypatch.setattr(cp, "get_storage_client", lambda: storage)

    req = _make_get_request({"client_id": "hc-missing"})
    resp = await cp.render_consent_form(req)
    assert resp is None


@pytest.mark.anyio
async def test_render_consent_form_no_client_id_returns_none(monkeypatch):
    import heronintelligence_mcp.consent_page as cp
    req = _make_get_request({})
    resp = await cp.render_consent_form(req)
    assert resp is None


@pytest.mark.anyio
async def test_render_consent_form_escapes_query_params(monkeypatch):
    """Malicious state/scope must not break out of the hidden fields."""
    import heronintelligence_mcp.consent_page as cp
    storage = MagicMock()
    storage.get_client = AsyncMock(return_value=_client_view("dcr"))
    monkeypatch.setattr(cp, "get_storage_client", lambda: storage)

    # URL-encode the payload so Starlette parses it back with the quotes.
    req = _make_get_request({
        "client_id": "hc-dcr",
        "state": "xyz%22%3E%3Cscript%3Ealert(1)%3C/script%3E",
    })
    resp = await cp.render_consent_form(req)
    body = resp.body.decode()
    assert "<script>" not in body
    assert "&lt;script&gt;" in body or "&quot;&gt;&lt;script&gt;" in body


# ---------------------------------------------------------------------------
# handle_consent_submit
# ---------------------------------------------------------------------------

@pytest.mark.anyio
async def test_handle_consent_submit_happy_path_redirects_with_code(monkeypatch):
    import heronintelligence_mcp.consent_page as cp
    import heronintelligence_mcp.oauth_provider as op

    dcr_view = _client_view("dcr", client_id="hc-dcr")
    manual_view = _client_view(
        "manual",
        client_id="hc-user",
        mcp_client_id="uuid-user",
        consumption_user_id="uuid-cons",
    )
    storage = MagicMock()
    storage.get_client = AsyncMock(side_effect=[dcr_view, manual_view])
    storage.verify_client_secret = AsyncMock(return_value=True)
    storage.create_auth_code = AsyncMock(return_value="new-code-123")
    monkeypatch.setattr(cp, "get_storage_client", lambda: storage)
    monkeypatch.setattr(op, "get_storage_client", lambda: storage)

    req = _make_post_request({
        "response_type": "code",
        "client_id": "hc-dcr",
        "redirect_uri": "https://claude.ai/api/mcp/auth_callback",
        "code_challenge": "ch-abc",
        "code_challenge_method": "S256",
        "state": "xyz",
        "scope": "mcp:read mcp:write",
        "resource": "https://mcp.test/",
        "user_client_id": "hc-user",
        "user_client_secret": "cs-secret",
    })
    resp = await cp.handle_consent_submit(req)
    assert resp.status_code == 302
    location = resp.headers["location"]
    assert location.startswith("https://claude.ai/api/mcp/auth_callback?")
    assert "code=new-code-123" in location
    assert "state=xyz" in location

    # Auth code was minted against the DCR client_id (what Claude uses at /token)
    # but with the manual client's user identity.
    create_kwargs = storage.create_auth_code.await_args.kwargs
    assert create_kwargs["oauth_client_id"] == "hc-dcr"
    assert create_kwargs["mcp_client_id"] == "uuid-user"
    assert create_kwargs["consumption_user_id"] == "uuid-cons"

    # And the PKCE/redirect context is cached for load_authorization_code.
    assert "new-code-123" in op._pending_codes
    cached = op._pending_codes["new-code-123"]
    assert cached.code_challenge == "ch-abc"
    assert cached.mcp_client_id == "uuid-user"


@pytest.mark.anyio
async def test_handle_consent_submit_missing_field_rerenders(monkeypatch):
    import heronintelligence_mcp.consent_page as cp
    storage = MagicMock()
    monkeypatch.setattr(cp, "get_storage_client", lambda: storage)

    req = _make_post_request({
        "client_id": "hc-dcr",
        "redirect_uri": "https://claude.ai/cb",
        "code_challenge": "ch",
        "user_client_id": "",  # missing
        "user_client_secret": "cs",
    })
    resp = await cp.handle_consent_submit(req)
    assert resp.status_code == 400
    assert b"All fields are required" in resp.body


@pytest.mark.anyio
async def test_handle_consent_submit_unknown_user_client_rerenders(monkeypatch):
    import heronintelligence_mcp.consent_page as cp
    dcr_view = _client_view("dcr", client_id="hc-dcr")
    storage = MagicMock()
    storage.get_client = AsyncMock(side_effect=[dcr_view, None])
    monkeypatch.setattr(cp, "get_storage_client", lambda: storage)

    req = _make_post_request({
        "client_id": "hc-dcr",
        "redirect_uri": "https://claude.ai/cb",
        "code_challenge": "ch",
        "code_challenge_method": "S256",
        "state": "",
        "scope": "",
        "resource": "",
        "response_type": "code",
        "user_client_id": "hc-missing",
        "user_client_secret": "cs",
    })
    resp = await cp.handle_consent_submit(req)
    assert resp.status_code == 401
    assert b"Invalid client ID or client secret" in resp.body


@pytest.mark.anyio
async def test_handle_consent_submit_wrong_secret_rerenders(monkeypatch):
    import heronintelligence_mcp.consent_page as cp
    dcr_view = _client_view("dcr", client_id="hc-dcr")
    manual_view = _client_view(
        "manual", client_id="hc-user", mcp_client_id="uuid-u",
        consumption_user_id="uuid-c",
    )
    storage = MagicMock()
    storage.get_client = AsyncMock(side_effect=[dcr_view, manual_view])
    storage.verify_client_secret = AsyncMock(return_value=False)
    monkeypatch.setattr(cp, "get_storage_client", lambda: storage)

    req = _make_post_request({
        "client_id": "hc-dcr",
        "redirect_uri": "https://claude.ai/cb",
        "code_challenge": "ch",
        "code_challenge_method": "S256",
        "state": "",
        "scope": "",
        "resource": "",
        "response_type": "code",
        "user_client_id": "hc-user",
        "user_client_secret": "cs-wrong",
    })
    resp = await cp.handle_consent_submit(req)
    assert resp.status_code == 401
    assert b"Invalid client ID or client secret" in resp.body


@pytest.mark.anyio
async def test_handle_consent_submit_rejects_dcr_as_user_client(monkeypatch):
    """A malicious submission that reuses the DCR client_id as the user's
    credentials must be rejected — DCR rows have no bound mcp_client_id."""
    import heronintelligence_mcp.consent_page as cp
    dcr_view = _client_view("dcr", client_id="hc-dcr")
    storage = MagicMock()
    storage.get_client = AsyncMock(side_effect=[dcr_view, dcr_view])
    monkeypatch.setattr(cp, "get_storage_client", lambda: storage)

    req = _make_post_request({
        "client_id": "hc-dcr",
        "redirect_uri": "https://claude.ai/cb",
        "code_challenge": "ch",
        "code_challenge_method": "S256",
        "state": "",
        "scope": "",
        "resource": "",
        "response_type": "code",
        "user_client_id": "hc-dcr",
        "user_client_secret": "anything",
    })
    resp = await cp.handle_consent_submit(req)
    assert resp.status_code == 401
