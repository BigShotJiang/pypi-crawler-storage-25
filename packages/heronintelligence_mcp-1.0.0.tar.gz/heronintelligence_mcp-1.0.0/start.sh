#!/bin/bash
set -e
echo "Starting Heron Intelligence MCP HTTP server..."

export MCP_TRANSPORT=http

exec uvicorn heronintelligence_mcp.http_app:create_app \
    --factory \
    --host 0.0.0.0 \
    --port "${PORT:-8080}" \
    --workers 1 \
    --log-level info \
    --timeout-keep-alive 300 \
    --proxy-headers \
    --forwarded-allow-ips "*"
