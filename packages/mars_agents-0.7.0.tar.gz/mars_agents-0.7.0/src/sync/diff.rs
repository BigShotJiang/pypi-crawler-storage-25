use std::path::Path;

use crate::error::MarsError;
use crate::hash;
use crate::lock::{CANONICAL_TARGET_ROOT, LockFile, LockIndex, LockedItem};
use crate::sync::target::{TargetItem, TargetState};
use crate::types::ContentHash;

/// The diff between current disk state and desired target state.
#[derive(Debug, Clone)]
pub struct SyncDiff {
    pub items: Vec<DiffEntry>,
}

/// A single diff entry — one of six cases from the merge matrix.
#[derive(Debug, Clone)]
pub enum DiffEntry {
    /// New item not in lock or on disk.
    Add { target: TargetItem },
    /// Source changed, local unchanged → clean update.
    Update {
        target: TargetItem,
        locked: LockedItem,
    },
    /// Source unchanged, local unchanged → skip.
    Unchanged {
        target: TargetItem,
        locked: LockedItem,
    },
    /// Source changed AND local changed → needs merge.
    Conflict {
        target: TargetItem,
        locked: LockedItem,
        local_hash: ContentHash,
    },
    /// In lock but not in target → should be removed.
    Orphan { locked: LockedItem },
    /// Local modification, source unchanged → keep local.
    LocalModified {
        target: TargetItem,
        locked: LockedItem,
        local_hash: ContentHash,
    },
}

/// Compute the diff between current disk state + lock and target state.
///
/// Uses dual checksums from the lock file:
/// - `source_checksum`: what the source provided
/// - `installed_checksum`: what mars wrote to disk
///
/// Compares current disk hash against lock checksums to determine the diff entry variant.
pub fn compute(
    root: &Path,
    lock: &LockFile,
    target: &TargetState,
    force: bool,
) -> Result<SyncDiff, MarsError> {
    let mut items = Vec::new();
    let lock_index = LockIndex::new(lock);

    // Process each target item
    for (_dest_key, target_item) in &target.items {
        if let Some(locked_item) =
            lock_index.find_output(CANONICAL_TARGET_ROOT, &target_item.dest_path)
        {
            // Item exists in lock — compare checksums
            let source_changed = target_item.source_hash != locked_item.source_checksum
                || rewritten_installed_checksum(target_item)
                    .is_some_and(|checksum| checksum != locked_item.installed_checksum);

            // Check disk hash against the expected baseline.
            // In --force mode, baseline is source_checksum so conflicted files
            // are treated as local modifications and get overwritten.
            let expected_disk_checksum = if force {
                &locked_item.source_checksum
            } else {
                &locked_item.installed_checksum
            };

            let disk_path = target_item.dest_path.resolve(root);
            let hash_path = hash_path_for_kind(&disk_path, target_item.id.kind);
            let local_changed = if hash_path.exists() {
                let disk_hash = hash::compute_hash(&hash_path, target_item.id.kind)?;
                let disk_hash = ContentHash::from(disk_hash);
                if disk_hash != *expected_disk_checksum {
                    Some(disk_hash)
                } else {
                    None
                }
            } else {
                // File was deleted locally — treat as if local changed to "nothing"
                // In this case, we should reinstall it
                None
            };

            match (source_changed, &local_changed) {
                (false, None) => {
                    // Neither changed → skip
                    if hash_path.exists() {
                        items.push(DiffEntry::Unchanged {
                            target: target_item.clone(),
                            locked: locked_item.clone(),
                        });
                    } else {
                        // File was deleted but hashes match lock — reinstall
                        items.push(DiffEntry::Add {
                            target: target_item.clone(),
                        });
                    }
                }
                (true, None) => {
                    // Source changed, local unchanged → clean update
                    items.push(DiffEntry::Update {
                        target: target_item.clone(),
                        locked: locked_item.clone(),
                    });
                }
                (false, Some(local_hash)) => {
                    // Local changed, source unchanged → keep local
                    items.push(DiffEntry::LocalModified {
                        target: target_item.clone(),
                        locked: locked_item.clone(),
                        local_hash: local_hash.clone(),
                    });
                }
                (true, Some(local_hash)) => {
                    // Both changed → conflict
                    items.push(DiffEntry::Conflict {
                        target: target_item.clone(),
                        locked: locked_item.clone(),
                        local_hash: local_hash.clone(),
                    });
                }
            }
        } else {
            // Not in lock → new item
            items.push(DiffEntry::Add {
                target: target_item.clone(),
            });
        }
    }

    // Find orphans: items in lock but not in target
    for (dest_path, locked_item) in lock.canonical_flat_items() {
        if !target.items.contains_key(&dest_path) {
            items.push(DiffEntry::Orphan {
                locked: locked_item,
            });
        }
    }

    Ok(SyncDiff { items })
}

fn rewritten_installed_checksum(target_item: &TargetItem) -> Option<ContentHash> {
    target_item
        .rewritten_content
        .as_ref()
        .map(|content| ContentHash::from(hash::hash_bytes(content.as_bytes())))
}

fn hash_path_for_kind(path: &Path, kind: crate::lock::ItemKind) -> std::path::PathBuf {
    if kind == crate::lock::ItemKind::BootstrapDoc {
        path.parent()
            .map(Path::to_path_buf)
            .unwrap_or_else(|| path.to_path_buf())
    } else {
        path.to_path_buf()
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::hash;
    use crate::lock::{ItemId, ItemKind, LockedItemV2, OutputRecord};
    use crate::types::{ItemName, SourceName};
    use indexmap::IndexMap;
    use std::fs;
    use std::path::PathBuf;
    use tempfile::TempDir;

    /// Create a minimal target item for testing.
    fn make_target_item(
        name: &str,
        kind: ItemKind,
        source_hash: &str,
        source_path: PathBuf,
    ) -> TargetItem {
        let dest_path = match kind {
            ItemKind::Agent => PathBuf::from("agents").join(format!("{name}.md")),
            ItemKind::Skill => PathBuf::from("skills").join(name),
            ItemKind::Hook => PathBuf::from("hooks").join(name),
            ItemKind::McpServer => PathBuf::from("mcp").join(name),
            ItemKind::BootstrapDoc => PathBuf::from("bootstrap").join(name).join("BOOTSTRAP.md"),
        };
        TargetItem {
            id: ItemId {
                kind,
                name: ItemName::from(name),
            },
            source_name: SourceName::from("test-source"),
            origin: crate::types::SourceOrigin::Dependency(SourceName::from("test-source")),
            source_id: crate::types::SourceId::Path {
                canonical: source_path.clone(),
                subpath: None,
            },
            source_path,
            dest_path: dest_path.to_string_lossy().to_string().into(),
            source_hash: ContentHash::from(source_hash),
            is_flat_skill: false,
            rewritten_content: None,
        }
    }

    /// Build a v2 `(key, LockedItemV2)` pair for inserting into `LockFile.items`.
    fn make_v2_item(
        name: &str,
        kind: ItemKind,
        source_checksum: &str,
        installed_checksum: &str,
    ) -> (String, LockedItemV2) {
        let dest_path = match kind {
            ItemKind::Agent => format!("agents/{name}.md"),
            ItemKind::Skill => format!("skills/{name}"),
            ItemKind::Hook => format!("hooks/{name}"),
            ItemKind::McpServer => format!("mcp/{name}"),
            ItemKind::BootstrapDoc => format!("bootstrap/{name}/BOOTSTRAP.md"),
        };
        let key = format!("{kind}/{name}");
        let item = LockedItemV2 {
            source: SourceName::from("test-source"),
            kind,
            version: None,
            source_checksum: ContentHash::from(source_checksum),
            outputs: vec![OutputRecord {
                target_root: ".mars".to_string(),
                dest_path: dest_path.into(),
                installed_checksum: ContentHash::from(installed_checksum),
            }],
        };
        (key, item)
    }

    #[test]
    fn new_item_produces_add() {
        let root = TempDir::new().unwrap();
        let source_dir = TempDir::new().unwrap();
        let source_path = source_dir.path().join("agents/coder.md");
        fs::create_dir_all(source_dir.path().join("agents")).unwrap();
        fs::write(&source_path, "# new agent").unwrap();

        let hash = hash::hash_bytes(b"# new agent");

        let target_item = make_target_item("coder", ItemKind::Agent, &hash, source_path);
        let mut target_items = IndexMap::new();
        target_items.insert("agents/coder.md".into(), target_item);
        let target = TargetState {
            items: target_items,
        };

        let lock = LockFile::empty();
        let diff = compute(root.path(), &lock, &target, false).unwrap();

        assert_eq!(diff.items.len(), 1);
        assert!(matches!(&diff.items[0], DiffEntry::Add { .. }));
    }

    #[test]
    fn unchanged_item_produces_unchanged() {
        let root = TempDir::new().unwrap();
        let content = b"# existing agent";
        let hash = hash::hash_bytes(content);

        // Write file to disk
        let agents_dir = root.path().join("agents");
        fs::create_dir_all(&agents_dir).unwrap();
        fs::write(agents_dir.join("coder.md"), content).unwrap();

        let source_path = PathBuf::from("/tmp/source/agents/coder.md");

        let target_item = make_target_item("coder", ItemKind::Agent, &hash, source_path);
        let mut target_items = IndexMap::new();
        target_items.insert("agents/coder.md".into(), target_item);
        let target = TargetState {
            items: target_items,
        };

        let mut lock_items = IndexMap::new();
        let (k, v) = make_v2_item("coder", ItemKind::Agent, &hash, &hash);
        lock_items.insert(k, v);
        let lock = LockFile {
            version: 2,
            dependencies: IndexMap::new(),
            items: lock_items,
            config_entries: std::collections::BTreeMap::new(),
        };

        let diff = compute(root.path(), &lock, &target, false).unwrap();
        assert_eq!(diff.items.len(), 1);
        assert!(matches!(&diff.items[0], DiffEntry::Unchanged { .. }));
    }

    #[test]
    fn source_changed_local_unchanged_produces_update() {
        let root = TempDir::new().unwrap();
        let old_content = b"# old version";
        let old_hash = hash::hash_bytes(old_content);
        let new_hash = hash::hash_bytes(b"# new version");

        // Write old content to disk (matching lock's installed_checksum)
        let agents_dir = root.path().join("agents");
        fs::create_dir_all(&agents_dir).unwrap();
        fs::write(agents_dir.join("coder.md"), old_content).unwrap();

        let source_path = PathBuf::from("/tmp/source/agents/coder.md");

        // Target has new hash
        let target_item = make_target_item("coder", ItemKind::Agent, &new_hash, source_path);
        let mut target_items = IndexMap::new();
        target_items.insert("agents/coder.md".into(), target_item);
        let target = TargetState {
            items: target_items,
        };

        // Lock has old hash
        let mut lock_items = IndexMap::new();
        let (k, v) = make_v2_item("coder", ItemKind::Agent, &old_hash, &old_hash);
        lock_items.insert(k, v);
        let lock = LockFile {
            version: 2,
            dependencies: IndexMap::new(),
            items: lock_items,
            config_entries: std::collections::BTreeMap::new(),
        };

        let diff = compute(root.path(), &lock, &target, false).unwrap();
        assert_eq!(diff.items.len(), 1);
        assert!(matches!(&diff.items[0], DiffEntry::Update { .. }));
    }

    #[test]
    fn local_changed_source_unchanged_produces_local_modified() {
        let root = TempDir::new().unwrap();
        let original_content = b"# original";
        let original_hash = hash::hash_bytes(original_content);
        let local_content = b"# locally modified";

        // Write locally modified content to disk
        let agents_dir = root.path().join("agents");
        fs::create_dir_all(&agents_dir).unwrap();
        fs::write(agents_dir.join("coder.md"), local_content).unwrap();

        let source_path = PathBuf::from("/tmp/source/agents/coder.md");

        // Target has same source hash as lock (no upstream change)
        let target_item = make_target_item("coder", ItemKind::Agent, &original_hash, source_path);
        let mut target_items = IndexMap::new();
        target_items.insert("agents/coder.md".into(), target_item);
        let target = TargetState {
            items: target_items,
        };

        // Lock also has original hash
        let mut lock_items = IndexMap::new();
        let (k, v) = make_v2_item("coder", ItemKind::Agent, &original_hash, &original_hash);
        lock_items.insert(k, v);
        let lock = LockFile {
            version: 2,
            dependencies: IndexMap::new(),
            items: lock_items,
            config_entries: std::collections::BTreeMap::new(),
        };

        let diff = compute(root.path(), &lock, &target, false).unwrap();
        assert_eq!(diff.items.len(), 1);
        assert!(matches!(&diff.items[0], DiffEntry::LocalModified { .. }));
    }

    #[test]
    fn both_changed_produces_conflict() {
        let root = TempDir::new().unwrap();
        let original_hash = hash::hash_bytes(b"# original");
        let new_source_hash = hash::hash_bytes(b"# new upstream");
        let local_content = b"# locally modified";

        // Write locally modified content
        let agents_dir = root.path().join("agents");
        fs::create_dir_all(&agents_dir).unwrap();
        fs::write(agents_dir.join("coder.md"), local_content).unwrap();

        let source_path = PathBuf::from("/tmp/source/agents/coder.md");

        // Target has new source hash (upstream changed)
        let target_item = make_target_item("coder", ItemKind::Agent, &new_source_hash, source_path);
        let mut target_items = IndexMap::new();
        target_items.insert("agents/coder.md".into(), target_item);
        let target = TargetState {
            items: target_items,
        };

        // Lock has original hash
        let mut lock_items = IndexMap::new();
        let (k, v) = make_v2_item("coder", ItemKind::Agent, &original_hash, &original_hash);
        lock_items.insert(k, v);
        let lock = LockFile {
            version: 2,
            dependencies: IndexMap::new(),
            items: lock_items,
            config_entries: std::collections::BTreeMap::new(),
        };

        let diff = compute(root.path(), &lock, &target, false).unwrap();
        assert_eq!(diff.items.len(), 1);
        assert!(matches!(&diff.items[0], DiffEntry::Conflict { .. }));
    }

    #[test]
    fn orphan_detected() {
        let root = TempDir::new().unwrap();

        // Empty target — no items wanted
        let target = TargetState {
            items: IndexMap::new(),
        };

        // Lock has an item
        let mut lock_items = IndexMap::new();
        let (k, v) = make_v2_item("old-agent", ItemKind::Agent, "sha256:aaa", "sha256:aaa");
        lock_items.insert(k, v);
        let lock = LockFile {
            version: 2,
            dependencies: IndexMap::new(),
            items: lock_items,
            config_entries: std::collections::BTreeMap::new(),
        };

        let diff = compute(root.path(), &lock, &target, false).unwrap();
        assert_eq!(diff.items.len(), 1);
        assert!(matches!(&diff.items[0], DiffEntry::Orphan { .. }));
    }

    #[test]
    fn dual_checksum_prevents_false_conflict() {
        // When mars rewrites frontmatter, source_checksum != installed_checksum.
        // The disk should match installed_checksum (what mars wrote).
        // This should NOT be detected as a local modification.
        let root = TempDir::new().unwrap();

        let source_hash = hash::hash_bytes(b"# original source");
        let installed_content = b"# rewritten by mars";
        let installed_hash = hash::hash_bytes(installed_content);

        // Disk has the mars-rewritten content
        let agents_dir = root.path().join("agents");
        fs::create_dir_all(&agents_dir).unwrap();
        fs::write(agents_dir.join("coder.md"), installed_content).unwrap();

        let source_path = PathBuf::from("/tmp/source/agents/coder.md");

        // Target has same source hash as before (no upstream change)
        let target_item = make_target_item("coder", ItemKind::Agent, &source_hash, source_path);
        let mut target_items = IndexMap::new();
        target_items.insert("agents/coder.md".into(), target_item);
        let target = TargetState {
            items: target_items,
        };

        // Lock has different source_checksum and installed_checksum
        let mut lock_items = IndexMap::new();
        let (k, v) = make_v2_item("coder", ItemKind::Agent, &source_hash, &installed_hash);
        lock_items.insert(k, v);
        let lock = LockFile {
            version: 2,
            dependencies: IndexMap::new(),
            items: lock_items,
            config_entries: std::collections::BTreeMap::new(),
        };

        let diff = compute(root.path(), &lock, &target, false).unwrap();
        assert_eq!(diff.items.len(), 1);
        // Should be Unchanged because disk matches installed_checksum
        // and source_hash matches source_checksum
        assert!(
            matches!(&diff.items[0], DiffEntry::Unchanged { .. }),
            "expected Unchanged, got {:?}",
            diff.items[0]
        );
    }

    #[test]
    fn mixed_diff_entries() {
        let root = TempDir::new().unwrap();
        let agents_dir = root.path().join("agents");
        fs::create_dir_all(&agents_dir).unwrap();

        let hash_a = hash::hash_bytes(b"# unchanged");
        let hash_b_old = hash::hash_bytes(b"# old version");
        let hash_b_new = hash::hash_bytes(b"# new version");

        // Write unchanged file
        fs::write(agents_dir.join("stable.md"), b"# unchanged").unwrap();

        // Write file with old content (will be updated)
        fs::write(agents_dir.join("updating.md"), b"# old version").unwrap();

        let source_path_a = PathBuf::from("/tmp/source/agents/stable.md");
        let source_path_b = PathBuf::from("/tmp/source/agents/updating.md");
        let source_path_c = PathBuf::from("/tmp/source/agents/new.md");

        let mut target_items = IndexMap::new();
        target_items.insert(
            "agents/stable.md".into(),
            make_target_item("stable", ItemKind::Agent, &hash_a, source_path_a),
        );
        target_items.insert(
            "agents/updating.md".into(),
            make_target_item("updating", ItemKind::Agent, &hash_b_new, source_path_b),
        );
        target_items.insert(
            "agents/new.md".into(),
            make_target_item(
                "new",
                ItemKind::Agent,
                &hash::hash_bytes(b"# brand new"),
                source_path_c,
            ),
        );
        let target = TargetState {
            items: target_items,
        };

        let mut lock_items = IndexMap::new();
        let (k, v) = make_v2_item("stable", ItemKind::Agent, &hash_a, &hash_a);
        lock_items.insert(k, v);
        let (k, v) = make_v2_item("updating", ItemKind::Agent, &hash_b_old, &hash_b_old);
        lock_items.insert(k, v);
        let (k, v) = make_v2_item("orphan", ItemKind::Agent, "sha256:xxx", "sha256:xxx");
        lock_items.insert(k, v);
        let lock = LockFile {
            version: 2,
            dependencies: IndexMap::new(),
            items: lock_items,
            config_entries: std::collections::BTreeMap::new(),
        };

        let diff = compute(root.path(), &lock, &target, false).unwrap();
        assert_eq!(diff.items.len(), 4); // Unchanged + Update + Add + Orphan

        let unchanged_count = diff
            .items
            .iter()
            .filter(|d| matches!(d, DiffEntry::Unchanged { .. }))
            .count();
        let update_count = diff
            .items
            .iter()
            .filter(|d| matches!(d, DiffEntry::Update { .. }))
            .count();
        let add_count = diff
            .items
            .iter()
            .filter(|d| matches!(d, DiffEntry::Add { .. }))
            .count();
        let orphan_count = diff
            .items
            .iter()
            .filter(|d| matches!(d, DiffEntry::Orphan { .. }))
            .count();

        assert_eq!(unchanged_count, 1);
        assert_eq!(update_count, 1);
        assert_eq!(add_count, 1);
        assert_eq!(orphan_count, 1);
    }

    #[test]
    fn force_uses_source_checksum_for_local_change_detection() {
        let root = TempDir::new().unwrap();
        let upstream_content = b"# upstream";
        let conflicted_content = b"<<<<<<< local\n# local\n=======\n# upstream\n>>>>>>> upstream\n";

        let source_hash = hash::hash_bytes(upstream_content);
        let installed_hash = hash::hash_bytes(conflicted_content);

        // Disk matches prior conflicted content from last sync.
        let agents_dir = root.path().join("agents");
        fs::create_dir_all(&agents_dir).unwrap();
        fs::write(agents_dir.join("coder.md"), conflicted_content).unwrap();

        let mut target_items = IndexMap::new();
        target_items.insert(
            "agents/coder.md".into(),
            make_target_item(
                "coder",
                ItemKind::Agent,
                &source_hash,
                PathBuf::from("/tmp/source/agents/coder.md"),
            ),
        );
        let target = TargetState {
            items: target_items,
        };

        let mut lock_items = IndexMap::new();
        lock_items.insert(
            "agent/coder".to_string(),
            LockedItemV2 {
                source: "test-source".into(),
                kind: ItemKind::Agent,
                version: None,
                source_checksum: source_hash.clone().into(),
                outputs: vec![OutputRecord {
                    target_root: ".mars".to_string(),
                    dest_path: "agents/coder.md".into(),
                    installed_checksum: installed_hash.into(),
                }],
            },
        );
        let lock = LockFile {
            version: 2,
            dependencies: IndexMap::new(),
            items: lock_items,
            config_entries: std::collections::BTreeMap::new(),
        };

        let normal = compute(root.path(), &lock, &target, false).unwrap();
        assert!(matches!(&normal.items[0], DiffEntry::Unchanged { .. }));

        let forced = compute(root.path(), &lock, &target, true).unwrap();
        assert!(matches!(&forced.items[0], DiffEntry::LocalModified { .. }));
    }

    #[test]
    fn canonical_diff_ignores_non_canonical_output_checksum() {
        let root = TempDir::new().unwrap();
        let canonical_content = b"# canonical";
        let canonical_hash = hash::hash_bytes(canonical_content);
        let pi_hash = hash::hash_bytes(b"# pi rewrite");

        let agents_dir = root.path().join("agents");
        fs::create_dir_all(&agents_dir).unwrap();
        fs::write(agents_dir.join("coder.md"), canonical_content).unwrap();

        let mut target_items = IndexMap::new();
        target_items.insert(
            "agents/coder.md".into(),
            make_target_item(
                "coder",
                ItemKind::Agent,
                &canonical_hash,
                PathBuf::from("/tmp/source/agents/coder.md"),
            ),
        );
        let target = TargetState {
            items: target_items,
        };

        let mut lock_items = IndexMap::new();
        lock_items.insert(
            "agent/coder".to_string(),
            LockedItemV2 {
                source: SourceName::from("test-source"),
                kind: ItemKind::Agent,
                version: None,
                source_checksum: canonical_hash.clone().into(),
                outputs: vec![
                    OutputRecord {
                        target_root: ".mars".to_string(),
                        dest_path: "agents/coder.md".into(),
                        installed_checksum: canonical_hash.clone().into(),
                    },
                    OutputRecord {
                        target_root: ".pi".to_string(),
                        dest_path: "agents/coder.md".into(),
                        installed_checksum: pi_hash.into(),
                    },
                ],
            },
        );
        let lock = LockFile {
            version: 2,
            dependencies: IndexMap::new(),
            items: lock_items,
            config_entries: std::collections::BTreeMap::new(),
        };

        let diff = compute(root.path(), &lock, &target, false).unwrap();
        assert_eq!(diff.items.len(), 1);
        assert!(
            matches!(&diff.items[0], DiffEntry::Unchanged { .. }),
            "expected Unchanged, got {:?}",
            diff.items[0]
        );
    }

    #[test]
    fn rewritten_content_change_produces_update() {
        let root = TempDir::new().unwrap();

        let source_content = b"---\nskills:\n- planning\n---\n# Agent\n";
        let source_hash = hash::hash_bytes(source_content);
        let old_installed_content = b"---\nskills:\n- planning\n---\n# Agent\n";
        let old_installed_hash = hash::hash_bytes(old_installed_content);
        let rewritten_content = "---\nskills:\n- strategy\n---\n# Agent\n";
        let rewritten_hash = hash::hash_bytes(rewritten_content.as_bytes());

        let agents_dir = root.path().join("agents");
        fs::create_dir_all(&agents_dir).unwrap();
        fs::write(agents_dir.join("coder.md"), old_installed_content).unwrap();

        let mut target_items = IndexMap::new();
        target_items.insert(
            "agents/coder.md".into(),
            TargetItem {
                id: ItemId {
                    kind: ItemKind::Agent,
                    name: "coder".into(),
                },
                source_name: SourceName::from("test-source"),
                origin: crate::types::SourceOrigin::Dependency(SourceName::from("test-source")),
                source_id: crate::types::SourceId::Path {
                    canonical: PathBuf::from("/tmp/source/agents/coder.md"),
                    subpath: None,
                },
                source_path: PathBuf::from("/tmp/source/agents/coder.md"),
                dest_path: "agents/coder.md".into(),
                source_hash: source_hash.clone().into(),
                is_flat_skill: false,
                rewritten_content: Some(rewritten_content.to_string()),
            },
        );
        let target = TargetState {
            items: target_items,
        };

        let mut lock_items = IndexMap::new();
        lock_items.insert(
            "agent/coder".to_string(),
            LockedItemV2 {
                source: SourceName::from("test-source"),
                kind: ItemKind::Agent,
                version: None,
                source_checksum: source_hash.into(),
                outputs: vec![OutputRecord {
                    target_root: ".mars".to_string(),
                    dest_path: "agents/coder.md".into(),
                    installed_checksum: old_installed_hash.clone().into(),
                }],
            },
        );
        let lock = LockFile {
            version: 2,
            dependencies: IndexMap::new(),
            items: lock_items,
            config_entries: std::collections::BTreeMap::new(),
        };

        let diff = compute(root.path(), &lock, &target, false).unwrap();
        assert_eq!(diff.items.len(), 1);
        assert!(matches!(&diff.items[0], DiffEntry::Update { .. }));

        assert_ne!(rewritten_hash, old_installed_hash);
    }
}
